# Session Log — Windows UI/Notation Fix — v0.0.20.19
**Datum:** 2026-02-08  
**Kollege:** GPT-5.2  
**Ziel:** Windows-Darstellungsprobleme entschärfen + Notation Editor standardmäßig sichtbar machen.

## Beobachtung
- Auf Windows ist QSettings initial leer → `ui/enable_notation_tab` war default False → Notation Tab „fehlt“.
- Zusätzlich kann Windows Native Style + DPI zu inkonsistenter QSS-Darstellung führen.

## Änderungen
1) **Notation Default ON**
- `pydaw/ui/main_window.py`: Default `ui_enable_notation_tab=True` + First-Run Initialisierung.

2) **View Toggle Sync**
- `pydaw/ui/main_window.py`: `Ansicht → Editor` wird beim Start auf tatsächliche Dock-Sichtbarkeit synchronisiert.

3) **Windows Fusion Style**
- `pydaw/app.py`: unter Windows `app.setStyle("Fusion")` + HiDPI-RoundingPolicy (PassThrough).

4) **Rendering Fallback**
- `pydaw/platform/windows_qt_init.py`: Env `CHRONOSCALE_QT_OPENGL=angle|desktop|software`.
- `INSTALL.md`: Troubleshooting Abschnitt ergänzt.

## Testplan (Windows)
- Start ohne Settings (frische Installation): Notation Tab sichtbar.
- Menü Ansicht: Notation aus/an.
- Bei Darstellungsproblemen: `CHRONOSCALE_QT_OPENGL=desktop` testen.

## Nächste Schritte
- Optional: GUI-Einstellung „Rendering Mode“ + „Reset Layout“ Button.
