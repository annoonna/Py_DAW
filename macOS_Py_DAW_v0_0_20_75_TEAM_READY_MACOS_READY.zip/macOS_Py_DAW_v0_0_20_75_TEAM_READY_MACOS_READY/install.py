"""Installer helper for ChronoScaleStudio (Py_DAW).

Usage:
    python3 install.py

It will:
- warn if you're not inside a virtual environment
- install/upgrade pip
- install platform-appropriate requirements

Notes:
- Linux: JACK/PipeWire system components are not installed here (distro packages).
- macOS: CoreAudio is used via PortAudio (sounddevice). You may need Homebrew libs.
"""

from __future__ import annotations

import os
import sys
import subprocess
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def _platform_requirements_file(here: Path) -> Path:
    # Prefer a dedicated macOS requirements file to avoid optional Linux-only deps.
    if sys.platform == "darwin":
        mac = here / "requirements_macos.txt"
        if mac.exists():
            return mac
    return here / "requirements.txt"


def main() -> int:
    here = Path(__file__).resolve().parent
    req = _platform_requirements_file(here)
    if not req.exists():
        print(f"{req.name} not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        print("      Empfehlung: python3 -m venv myenv && source myenv/bin/activate")

    if sys.platform == "darwin":
        print("\nmacOS Hinweise (CoreAudio/Metal):")
        print("- Audio: sounddevice nutzt PortAudio → ggf. Homebrew: brew install portaudio")
        print("- soundfile nutzt libsndfile → ggf. Homebrew: brew install libsndfile")
        print("- MIDI: python-rtmidi → ggf. Homebrew: brew install rtmidi")
        print("- Grafik: Qt6 nutzt Metal automatisch (Qt RHI).")

    py = sys.executable
    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    _run([py, "-m", "pip", "install", "-r", str(req)])

    print("\nOK. Starte danach mit: python3 main.py")
    if sys.platform != "darwin":
        print("Optional: Audio/MIDI Abhängigkeiten können Systempakete erfordern (PipeWire-JACK/JACK/qpwgraph).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
