# CHANGELOG v0.0.20.777 — C-Speed Built-in FX + Vectorized DSP

**Datum:** 2026-03-23
**Autor:** Claude Opus 4.6
**Aufgabe:** Alle vektorisierbaren FX auf C-Speed / numpy bringen

## Zusammenfassung

Systematische Analyse aller 22 per-sample Python Loops im Audio-Code.
7 wurden in dieser Session vektorisiert (+ 3 aus v775/v776).
7 weitere sind nicht vektorisierbar (IIR-Feedback in Reverb/Delay/Chorus/Phaser/Flanger/SVF/Ladder).

## Vektorisierte FX (v0.0.20.777)

| FX | Technik | Speedup |
|---|---|---|
| **Compressor** | Peak-array numpy, envelope tight-loop, gain-apply numpy | ~5-8x |
| **Limiter** | np.abs+maximum peaks, envelope loop, np.multiply gains | ~5-8x |
| **Distortion** | Numpy LUT fancy-indexing, scipy tone filter | ~20x |
| **Tremolo** | Numpy phase array + LUT lookup + gain multiply | ~15x |
| **StereoWidener** | Pure numpy M/S encode/decode (kein Loop) | ~30x |
| **Utility** | Pure numpy gain/pan/phase/swap, scipy DC blocker | ~20x |
| **EQ** (v776) | scipy.signal.lfilter C-level biquad | ~50x |

## Nicht vektorisierbar (Feedback-Loops)

| FX | Grund |
|---|---|
| Reverb | 4 Comb + 4 Allpass Feedback (Schroeder) |
| Delay | Feedback Delay Line |
| Chorus | Modulierte Delay Line mit Feedback |
| Phaser | Allpass Feedback Chain |
| Flanger | Modulierte Delay Line mit Feedback |
| SVF Filter | IIR Zero-Delay Feedback (Cytomic) |
| Moog Ladder | 4-Pole IIR Feedback |

→ Diese brauchen **Rust** für echte C-Speed (Phasen R2-R4 bereits implementiert).

## Gesamtübersicht alle Sessions (v775-v777)

| Datei | v775 | v776 | v777 |
|---|---|---|---|
| rt_thread.py | **NEU** | — | — |
| audio_engine.py | RT + Hot-Swap + Lock-Free | — | — |
| vst2_host.py | Lock-Free Callback | — | — |
| main_window.py | Hot-Swap + Debounce | — | — |
| sampler_engine.py | — | Fast-Path | — |
| multisample_engine.py | — | Voice Fast-Path | — |
| builtin_fx.py | — | EQ scipy | Compressor + Limiter |
| creative_fx.py | — | — | Distortion + Tremolo |
| utility_fx.py | — | — | StereoWidener + Utility |
