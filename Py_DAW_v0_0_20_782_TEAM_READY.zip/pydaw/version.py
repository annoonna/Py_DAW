__version__ = "0.0.20.782"
VERSION = __version__
