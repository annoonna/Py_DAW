# CHANGELOG v0.0.20.775 — Realtime Audio Performance Fix

**Datum:** 2026-03-23
**Autor:** Claude Opus 4.6
**Arbeitspaket:** Performance / Audio Engine Hotfix

## Problem
Audio hängt komplett — 3-Sekunden-Aussetzer, Stottern, kein Realtime-Playback
trotz nur 21% CPU. Benchmark zeigt gute rohe Performance (Avg 220µs/buffer),
aber reale Wiedergabe ist unbrauchbar.

## Root Cause Analysis
6 separate Ursachen identifiziert:

1. **Kein RT-Thread-Priority** — Audio-Thread läuft als normaler Linux-Thread,
   Kernel preempted für GUI/GC jederzeit
2. **GIL-Contention** — GUI-Thread und Audio-Thread teilen Python GIL,
   GUI-Updates (Arranger-Redraw, VU-Meter) blockieren Audio
3. **GC-Pausen** — Python Garbage Collector pausiert Audio-Thread 5-50ms
4. **Lock im VST2 Host-Callback** — `_host_state_lock` (threading.Lock) wird
   bei jedem `processReplacing` vom Audio-Thread acquired
5. **Lock in `_pull_sources_snapshot`** — `_pull_sources_lock` im Audio-Callback
6. **Stop/Restart bei MIDI-Edits** — Jeder MIDI-Edit während Playback triggert
   kompletten Stop → deepcopy → prepare → Restart = 2-3 Sekunden Lücke

## Fixes

### Fix 1: RT-Thread-Priority + GC-Kontrolle (NEU: rt_thread.py)
- `SCHED_FIFO` Priority 50 für Audio-Thread (Linux)
- Fallback: `SCHED_RR` → `nice(-15)` → `nice(-5)`
- `gc.disable()` im Audio-Thread (GC-Pausen eliminiert)
- `mlockall()` gegen Page Faults
- Automatische Wiederherstellung bei Thread-Ende

### Fix 2: Lock-Free VST2 Host-Callback
- `_audio_master_callback` liest `_host_state` dict ohne Lock
- CPython dict.get() ist GIL-atomic — Lock nur für Schreib-Zugriff nötig
- Eliminiert Mutex-Contention im heißen Pfad

### Fix 3: Lock-Free Pull-Sources Snapshot
- `_pull_sources_snapshot()` liest gen + list ohne Lock
- CPython attribute-reads sind GIL-atomic
- Eliminiert weiteren Mutex im Audio-Callback

### Fix 4: Hot-Swap ArrangementState (KRITISCHSTER FIX)
- Neue Methode `hot_swap_arrangement()` in AudioEngine
- Swappt ArrangementState atomar OHNE den Audio-Stream zu stoppen
- `_restart_playback_if_playing` nutzt jetzt Hot-Swap statt Stop/Restart
- `_on_transport_params_changed` nutzt jetzt Hot-Swap mit Fallback
- Eliminiert die 2-3 Sekunden Audio-Lücke bei MIDI-Edits

### Fix 5: MIDI-Refresh Debounce
- Timer von 80ms auf 200ms erhöht
- Weniger Hot-Swaps bei schnellem Editieren

## Geänderte Dateien
| Datei | Änderung |
|---|---|
| pydaw/audio/rt_thread.py | **NEU** — RT-Priority + GC + mlockall |
| pydaw/audio/audio_engine.py | RT-Priority in _EngineThread.run(), hot_swap_arrangement(), lock-free _pull_sources_snapshot() |
| pydaw/audio/vst2_host.py | Lock-free _audio_master_callback |
| pydaw/ui/main_window.py | Hot-swap in _restart_playback_if_playing, 200ms debounce |
| pydaw/version.py | → 0.0.20.775 |
| VERSION | → 0.0.20.775 |

## Erwartete Verbesserung
- **Keine 3-Sekunden-Aussetzer** mehr bei MIDI-Edits während Playback
- **Weniger Micro-Stutter** durch RT-Priority und GC-Kontrolle
- **Geringere Latenz** durch Lock-Free Audio-Callback
- Audio-Thread wird vom Kernel bevorzugt behandelt (SCHED_FIFO)

## Voraussetzungen für volle Wirkung
- Linux: `rtprio` in `/etc/security/limits.conf` oder Mitglied der `audio` Gruppe
  ```
  @audio - rtprio 95
  @audio - memlock unlimited
  ```
- Alternativ: `ulimit -r 95` vor dem Start
- Ohne RT-Permissions: Fallback auf nice(-15), immer noch besser als Default

## Was als nächstes zu tun ist
- Buffer-Size auf 512 oder 1024 erhöhen falls immer noch Stutter
- Rust Engine aktivieren für volle Performance (should_use_rust)
- Built-in FX nach Rust migrieren (Phase R2-R4 bereits implementiert)
