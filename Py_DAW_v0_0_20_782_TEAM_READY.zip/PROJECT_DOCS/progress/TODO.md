# TODO.md — Offene Aufgaben

## v0.0.20.782 — IPC-Only Engine (cpal entfernt, Listener-Loop)

- [x] (Claude Opus 4.6, 2026-03-23): **cpal Audio-Output entfernt** — Engine produziert keinen eigenen PipeWire-Node mehr
- [x] (Claude Opus 4.6, 2026-03-23): **Listener-Loop** — Engine überlebt Client-Disconnects, wartet auf Reconnect
- [x] (Claude Opus 4.6, 2026-03-23): **Command-Drain-Ticker** — 100Hz Thread ersetzt cpal-Callback
- [x] (Claude Opus 4.6, 2026-03-23): **Rust Engine Disconnect** — Root Cause war Buffer-Size-Mismatch (cpal 1024 vs Graph 512)

- [ ] AVAILABLE: **cargo build --release testen** — Build ohne cpal sollte schneller sein + keine ALSA-Dev nötig
- [ ] AVAILABLE: **PipeWire Graph verifizieren** — Nur noch 1 Audio-Node (Python), nicht 2
- [ ] AVAILABLE: **Export testen** — Realtime-Capture sollte jetzt funktionieren (kein Engine-Crash mehr)
- [ ] AVAILABLE: **Phase R12: IPC Audio-Buffer Bridge** — Rust rendert Tracks → Python holt Buffers via IPC

## v0.0.20.777 — C-Speed Built-in FX

- [x] (Claude Opus 4.6, 2026-03-23): **Compressor** — numpy peaks + tight envelope + numpy gain
- [x] (Claude Opus 4.6, 2026-03-23): **Limiter** — numpy abs/max + envelope + numpy multiply
- [x] (Claude Opus 4.6, 2026-03-23): **Distortion** — numpy LUT indexing + scipy tone
- [x] (Claude Opus 4.6, 2026-03-23): **Tremolo** — numpy phase + LUT + gain
- [x] (Claude Opus 4.6, 2026-03-23): **StereoWidener** — pure numpy M/S (kein Loop)
- [x] (Claude Opus 4.6, 2026-03-23): **Utility** — numpy gain/pan/phase + scipy DC blocker

## v0.0.20.776 — Vectorized Sampler DSP

- [x] (Claude Opus 4.6, 2026-03-23): **ProSampler Fast-Path** — Vektorisierter pull_fast(), ~24x schneller
- [x] (Claude Opus 4.6, 2026-03-23): **MultiSample Fast-Path** — Vektorisierter render_voice_fast(), ~20x schneller
- [x] (Claude Opus 4.6, 2026-03-23): **Block-ADSR** — generate_envelope_block() numpy statt per-sample
- [x] (Claude Opus 4.6, 2026-03-23): **EQ C-Level** — scipy.signal.lfilter statt Python Biquad Loop, ~50x schneller

## v0.0.20.775 — Realtime Audio Performance Fix

- [x] (Claude Opus 4.6, 2026-03-23): **RT-Thread-Priority** — SCHED_FIFO + GC disable + mlockall
- [x] (Claude Opus 4.6, 2026-03-23): **Hot-Swap ArrangementState** — Eliminiert 3s Aussetzer bei MIDI-Edits
- [x] (Claude Opus 4.6, 2026-03-23): **Lock-Free Audio Callback** — VST2 host + pull_sources ohne Locks
- [x] (Claude Opus 4.6, 2026-03-23): **MIDI Debounce 200ms** — Weniger Hot-Swaps bei schnellem Editieren

- [ ] AVAILABLE: **Fusion Synth vektorisieren** — 4631 Zeilen, viele per-sample Python Loops
- [ ] AVAILABLE: **RT-Permissions testen** — ulimit -r prüfen, limits.conf @audio Gruppe
- [ ] AVAILABLE: **Rust Engine aktivieren** — should_use_rust() → True für Built-in FX
- [ ] AVAILABLE: **Hardware-Test BRRR PADsynth** — A/B-Vergleich mit ZynAdd, alle Tonlagen
- [ ] AVAILABLE: **Rust bauen + P0A testen** — `cd pydaw_engine && cargo build --release`
- [ ] AVAILABLE: **P0D Beta-Changelog** — CHANGELOG v0.1.0-beta schreiben
- [ ] AVAILABLE: **P1A Recording-Workflow** — Input-Monitoring < 10ms, Waveform-Preview während Recording

