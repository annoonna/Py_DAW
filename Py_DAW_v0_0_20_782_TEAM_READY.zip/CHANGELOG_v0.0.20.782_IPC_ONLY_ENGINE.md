# CHANGELOG v0.0.20.782 — IPC-Only Engine (cpal entfernt, Listener-Loop)

**Datum:** 2026-03-23
**Autor:** Claude Opus 4.6
**Arbeitspaket:** Bugfix — Rust Engine Crash-Reconnect-Zyklus

## Problem

Die Rust Audio-Engine crashte sofort nach dem Connect in einer Endlosschleife:

1. `start_daw.sh` startete Engine mit `--sr 48000 --buf 1024`
2. Engine öffnete einen **cpal ALSA-Stream** → eigener PipeWire-Node "PipeWire ALSA [pydaw_engine]"
3. Python sendete `Configure(sr=44100, buf=512)` → Graph-Buffers auf 512 resized
4. cpal-Callback rief weiter `process_audio(output, 1024, 2)` mit 1024 Frames auf
5. **Buffer-Overflow** im Renderer (1024 Frames in 512er-Buffers) → Panic → Prozess-Tod
6. Python erkannte EOF → Auto-Reconnect → Engine-Neustart → selber Crash
7. Nach 3 Fehlversuchen → Fallback auf Python-Engine

Zusätzliches Problem: Engine exitierte sofort nach Client-Disconnect (kein Listener-Loop).

## Lösung

### 1. cpal Audio-Output komplett entfernt (`main.rs`)
- Kein eigener ALSA-Stream mehr → kein "PipeWire ALSA [pydaw_engine]" Node
- Audio-Playback bleibt komplett bei Python (sounddevice/PipeWire)
- Eliminiert die Buffer-Size-Mismatch-Problematik vollständig

### 2. Command-Drain-Ticker (100Hz)
- Ersetzt den cpal-Callback als Treiber für `drain_commands()`
- Eigener Thread pollt die Command-Queue alle 10ms
- ScanPlugins, Configure, SyncProject etc. werden sofort verarbeitet

### 3. Listener-Loop für Multi-Connect
- Engine überlebt Client-Disconnects und wartet auf nächste Verbindung
- Frische EngineState pro Connection (kein Stale State)
- Nur `Shutdown`-Command beendet die Engine
- Python-Bridge kann ohne Engine-Kill reconnecten

### 4. start_daw.sh angepasst
- ALSA Dev-Headers Check entfernt (nicht mehr nötig ohne cpal)
- Version-Kommentar aktualisiert

## Geänderte Dateien

| Datei | Änderung |
|---|---|
| pydaw_engine/src/main.rs | Komplett umgeschrieben: cpal entfernt, Listener-Loop, Command-Drain-Ticker |
| start_daw.sh | ALSA-Header-Check entfernt, Version aktualisiert |
| VERSION | → 0.0.20.782 |
| pydaw/version.py | → 0.0.20.782 |

## Nicht geänderte Dateien (bereits korrekt)

| Datei | Status |
|---|---|
| pydaw_engine/Cargo.toml | cpal war bereits in v0.0.20.781 auskommentiert |
| pydaw/services/rust_engine_bridge.py | Reconnect-Logik war bereits in v0.0.20.781 auf Socket-Reconnect umgestellt |

## Was als nächstes zu tun ist

1. `cargo build --release` ausführen (sollte schneller bauen ohne cpal/ALSA)
2. Testen: PipeWire Graph sollte NUR "PipeWire ALSA [python3.13]" zeigen
3. Engine-Stabilität testen: Connect → Disconnect → Reconnect ohne Crash
4. Export testen: Realtime-Capture sollte jetzt technisch funktionieren

## Bekannte Einschränkungen

- Die Rust Engine produziert aktuell KEINEN Audio-Output — sie ist ein reiner IPC-Server
- Audio-Rendering für Export müsste über IPC-Buffer-Transfer implementiert werden (Phase R12)
- Die `process_audio()`-Methode in engine.rs existiert noch, wird aber nicht mehr aufgerufen
