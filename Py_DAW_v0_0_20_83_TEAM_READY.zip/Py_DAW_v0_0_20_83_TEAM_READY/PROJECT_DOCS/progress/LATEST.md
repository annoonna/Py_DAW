v0.0.20.83

- Optional: CPU Anzeige in der Statusbar (opt-in, Default OFF, QTimer 1000ms, ohne psutil)
- Hotfix v0.0.20.82: Mixer VU-Meter wieder korrekt verdrahtet (Track-ID→Index Map im Hybrid Callback)
- Feature v0.0.20.81: Device Drop "Insert at Position" in der Chain

Nächste sinnvolle Schritte:
- Re-test Drag&Drop (Samples/Clips/Devices) + Menü-Aktionen (keine SIGABRTs)
- Audio Import Sample-Rate Edgecases (44.1k ↔ 48k): Erkennen + Resample-Strategie + UI-Warnung/Option
- Performance: UI Update-Raten (VU/Waveform) prüfen, ggf. Throttling-Optionen
