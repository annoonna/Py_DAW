# LATEST — v0.0.20.68

✅ Browser → Device Chain Add/Doppelklick + Drag&Drop (Ableton/Bitwig UX)
- Instruments / Note-FX / Audio-FX: Add/DoubleClick or Drag creates a **NEW instance** in the bottom Device chain.
- Browser bleibt Katalog/Vorlagen (nie „editieren“ oder entfernen).

✅ Device Panel: echte, lineare Device‑Chain (stabil)
Order (strict):
  Note‑FX → Instrument (Anchor, fix) → Audio‑FX
- Kein erzwungener CHAIN‑Container im MVP (kein Rekursions-Render).

✅ Bulletproof Drag&Drop
- DropForwardHost + Child‑EventFilter: Drops verpuffen nicht mehr in Child‑Widgets.

✅ Device Cards (Note‑FX & Audio‑FX)
- Up/Down (Reorder), Power (Enable/Disable), Remove
- Audio‑FX: nach Add/Remove/Reorder/Enable → AudioEngine.rebuild_fx_maps()

✅ Note‑FX Parameter UI in Cards (musikalisch testbar)
- Chord, Arp, ScaleSnap, Transpose, VelScale, Random

Next:
- Instrument Power/BYPASS (optional)
- Drop „Insert at position“ (statt append)

Hotfix (v0.0.20.64):
- Playback: fix `beats_to_samples()` signature mismatch in legacy MIDI scheduling.
- SF2 Anchor: DevicePanel shows a real SF2 card (Load + Bank/Preset) instead of failing.

Fix (v0.0.20.68):
- Pro Audio Sampler + Pro Drum Machine sind wieder hörbar im Arrangement (MIDI Scheduling Regression fix).
- Audio Settings: Sample-Rate Presets (inkl. 44100 Hz) + weiterhin Custom.

Hotfix (v0.0.20.65):
- Pro Audio Sampler + Pro Drum Machine are no longer silent when running at 44.1kHz.
  Their engines now derive `target_sr` from AudioEngine audio settings (instead of hardcoding 48k).
  DrumMachine also registers into SamplerRegistry so PianoRoll/Notation note preview routes correctly.
