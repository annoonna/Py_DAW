"""Project domain model (v0.0.9).

v0.0.5: MIDI notes per clip (Piano Roll).
v0.0.7: Clip Launcher mapping slot_key -> clip_id.
v0.0.8: Clip Launcher settings (quantize/mode).
v0.0.9: Audio clip params (gain/pan/pitch + per-clip loop/slices) for AudioEventEditor.

Persistence: JSON via dataclasses.asdict in file_manager.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid

from .midi import MidiNote


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:10]}"


@dataclass
class MediaItem:
    kind: str  # "audio" | "midi"
    path: str
    label: str = ""
    id: str = field(default_factory=lambda: new_id("media"))


@dataclass
class Track:
    id: str = field(default_factory=lambda: new_id("trk"))
    kind: str = "audio"  # "audio" | "instrument" | "bus" | "master" | "fx" | "group"
    name: str = "Track"
    muted: bool = False
    solo: bool = False
    automation_mode: str = "off"  # off|read|write
    volume: float = 0.8
    pan: float = 0.0
    record_arm: bool = False

    # Audio I/O routing (JACK-first): choose which stereo input pair is used for
    # monitoring/recording (1..N). Output pair is reserved for future submix/bus routing.
    input_pair: int = 1
    output_pair: int = 1
    monitor: bool = False

    # v0.0.20.518: Send-FX routing (Bitwig-Style)
    # Each entry: {"target_track_id": "trk_...", "amount": 0.5, "pre_fader": False}
    # amount: 0.0=off .. 1.0=full send. pre_fader: send before or after track fader.
    sends: list = field(default_factory=list)

    # v0.0.20.46: Plugin-based instrument routing (Pro-DAW-Style!)
    # This determines which instrument engine processes MIDI clips on this track
    # Options: "sampler", "drum_machine", "sf2", None (no instrument)
    # If None but sf2_path is set: auto-detected as "sf2" for backwards compatibility
    plugin_type: Optional[str] = None
    # v0.0.20.80: Instrument Power/Bypass — when False, the instrument is bypassed
    # (no MIDI dispatch, no SF2 render, no pull-source audio). Track stays visible.
    instrument_enabled: bool = True
    # Instrument-spezifischer Persistenz-Speicher (Sampler/Drum/etc.)
    # Wird automatisch in der Projektdatei gespeichert (dataclass -> asdict).
    instrument_state: Dict[str, Any] = field(default_factory=dict)

    # Phase 3: SF2 instrument state (kept for backwards compatibility)
    # When plugin_type="sf2" or plugin_type=None with sf2_path set, these are used
    sf2_path: Optional[str] = None
    sf2_bank: int = 0
    sf2_preset: int = 0
    midi_channel: int = 0

    # v0.0.20.56: Device Chains (Engine-First)
    # Note-FX Chain: MIDI/Notenbearbeitung vor dem Instrument
    note_fx_chain: dict = field(default_factory=lambda: {"devices": []})

    # Audio-FX Chain: serielle Effekte nach dem Instrument (mit Dry/Wet + Wet Gain)
    audio_fx_chain: dict = field(default_factory=lambda: {"type": "chain", "mix": 1.0, "wet_gain": 1.0, "devices": []})

    # v0.0.20.254: Safe organisational track grouping (UI/project-level only).
    # This is intentionally NOT audio bus routing yet; it is used for
    # selection/organisation without touching the engine.
    track_group_id: str = ""
    track_group_name: str = ""

@dataclass
class AudioEvent:
    """Non-destructive segment inside an audio clip.

    Timeline inside the clip is expressed in beats (quarter-note beats).
    - start_beats: position inside clip content (0..clip.length_beats)
    - length_beats: duration of this segment
    - source_offset_beats: offset inside the underlying source (beats) relative to clip offset
      (placeholder until we add sample-accurate seconds based editing).
    """
    id: str = field(default_factory=lambda: new_id("aev"))
    start_beats: float = 0.0
    length_beats: float = 0.0
    source_offset_beats: float = 0.0
    reversed: bool = False  # per-event non-destructive reverse (v0.0.20.160)


@dataclass
class Clip:
    id: str = field(default_factory=lambda: new_id("clip"))
    kind: str = "audio"  # "audio" | "midi"
    track_id: str = ""
    start_beats: float = 0.0
    length_beats: float = 4.0
    # content offset inside source (for left trim/extend)
    offset_beats: float = 0.0
    offset_seconds: float = 0.0
    label: str = "Clip"
    media_id: Optional[str] = None
    source_path: Optional[str] = None

    # Optional: if the clip's source tempo is known (e.g. parsed from the
    # filename "*_150bpm.wav"), playback can be time-scaled to match the project BPM.
    source_bpm: Optional[float] = None
    # Optional: used for simple grouping (move/edit multiple clips together)
    group_id: str = ""

    # --- Audio Clip non-destructive params (used by AudioEventEditor / Launcher)
    gain: float = 1.0          # linear (1.0 = unity)
    pan: float = 0.0           # -1.0 (L) .. 0.0 .. +1.0 (R)
    pitch: float = 0.0         # semitones
    formant: float = 0.0       # semitones (placeholder)
    stretch: float = 1.0       # time-stretch factor (1.0 = original)
    reversed: bool = False     # non-destructive reverse playback
    muted: bool = False        # non-destructive clip mute
    fade_in_beats: float = 0.0   # fade-in length in beats (0 = no fade)
    fade_out_beats: float = 0.0  # fade-out length in beats (0 = no fade)

    # Per-clip loop region in beats (relative to clip start inside its content)
    # If loop_end_beats <= loop_start_beats -> treated as "full clip length"
    loop_start_beats: float = 0.0
    loop_end_beats: float = 0.0

    # Non-destructive slice markers (beats relative to clip content start)
    audio_slices: List[float] = field(default_factory=list)
    # Optional transient/onset markers (beats relative to clip content start)
    onsets: List[float] = field(default_factory=list)

    # Phase 2: non-destructive events inside the audio clip (derived from slices if missing)
    audio_events: List[AudioEvent] = field(default_factory=list)

    # Per-clip automation envelopes (Bitwig/Ableton style)
    # Dict of param_name -> list of breakpoints [{"beat": float, "value": float}, ...]
    # param_name: "gain", "pan", "pitch", "formant"
    # value: 0.0..1.0 normalized (mapped to param range by editor)
    clip_automation: Dict[str, List[Dict[str, float]]] = field(default_factory=dict)

    # Warp/Stretch markers: list of beat positions (float)
    # Used by audio editor to define custom warp points for time-stretching
    stretch_markers: List[dict] = field(default_factory=list)

    # Render/Bounce metadata (forward-compatible, non-destructive history)
    # Used by Consolidate/Bounce to store source references + flags + ranges.
    render_meta: Dict[str, Any] = field(default_factory=dict)

    # Clip exists only in Clip-Launcher (not shown on Arranger timeline)
    launcher_only: bool = False

    # --- Bitwig-Style per-Clip Launcher Properties (v0.0.20.147) ---
    # Per-clip start quantize: "Project" (use global), "Off", "1 Bar", "1 Beat",
    # "1/2", "1/4", "1/8", "1/16"
    launcher_start_quantize: str = "Project"
    # ALT start quantize (Bitwig: held with modifier key)
    launcher_alt_start_quantize: str = "Project"
    # Playback mode: "Trigger ab Start", "Legato vom Clip", "Legato vom Projekt"
    launcher_playback_mode: str = "Trigger ab Start"
    # ALT playback mode
    launcher_alt_playback_mode: str = "Trigger ab Start"
    # Release action: "Fortsetzen", "Stopp", "Zurück", "Nächste Aktion"
    launcher_release_action: str = "Stopp"
    # ALT release action
    launcher_alt_release_action: str = "Stopp"
    # Q auf Loop (quantize on loop boundary): True/False
    launcher_q_on_loop: bool = True
    # Nächste Aktion (Next Action): "Stopp", "Nächsten abspielen", "Vorherigen abspielen",
    # "Ersten abspielen", "Letzten abspielen", "Zufälligen abspielen", "Anderen abspielen",
    # "Round-robin", "Zum Arrangement zurückkehren"
    launcher_next_action: str = "Stopp"
    # Next action repeat count (how many loops before executing next action, 0=infinite)
    launcher_next_action_count: int = 1
    # Shuffle amount (0.0 - 1.0)
    launcher_shuffle: float = 0.0
    # Accent strength (0.0 - 1.0)
    launcher_accent: float = 0.0
    # Seed / start value: "Random" or fixed int
    launcher_seed: str = "Random"
    # Clip color index (0-15, maps to color palette)
    launcher_color: int = 0


@dataclass
class Project:
    # Keep this in sync with VERSION / pydaw.version.__version__ for new projects.
    version: str = '0.0.20.371'
    name: str = "Neues Projekt"
    created_utc: str = field(default_factory=lambda: datetime.utcnow().isoformat(timespec="seconds"))
    modified_utc: str = field(default_factory=lambda: datetime.utcnow().isoformat(timespec="seconds"))

    sample_rate: int = 48000
    bpm: float = 120.0
    time_signature: str = "4/4"
    snap_division: str = "1/16"
    automation_lanes: dict = None  # legacy/simple lanes
    # v0.0.20.175: Enhanced AutomationManager persistence (parameter_id -> lane dict)
    automation_manager_lanes: Dict[str, Any] = field(default_factory=dict)
    # v0.0.20.349: Arranger/UI state for collapsed organisational groups.
    arranger_collapsed_group_ids: List[str] = field(default_factory=list)
    midi_mappings: list = None  # placeholder: list of mappings

    media: List[MediaItem] = field(default_factory=list)
    tracks: List[Track] = field(default_factory=list)
    clips: List[Clip] = field(default_factory=list)

    # clip_id -> notes
    midi_notes: Dict[str, List[MidiNote]] = field(default_factory=dict)

    # slot_key -> clip_id
    clip_launcher: Dict[str, str] = field(default_factory=dict)

    # Clip Launcher settings (placeholder)
    launcher_quantize: str = "1 Bar"  # Off | 1 Beat | 1 Bar
    launcher_mode: str = "Trigger"    # Trigger | Toggle | Gate

    # Ghost Notes / Layered Editing state (persisted)
    # JSON-safe dict produced by LayerManager.to_dict()
    ghost_layers: Dict[str, Any] = field(default_factory=dict)
    # Notation marks / annotations (sticky notes, rests, ornaments, ties, etc.)
    # Stored as list of JSON-safe dicts. Rendering/editor can interpret these.
    notation_marks: List[Dict[str, Any]] = field(default_factory=list)


    def __post_init__(self) -> None:
        if not self.tracks:
            self.tracks = [Track(kind="master", name="Master")]

    

    def tracks_by_id(self) -> Dict[str, Track]:
        """Convenience: map track_id -> Track.

        Used across UI/Engine to avoid repeated linear scans.
        """
        return {str(getattr(t, 'id', '')): t for t in (self.tracks or []) if str(getattr(t, 'id', ''))}

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Project":
        # Robust loader: ignore unknown keys (forward-compatible) and convert nested dataclasses.
        from dataclasses import fields as _dc_fields

        media = [MediaItem(**m) for m in d.get("media", []) if isinstance(m, dict)]

        # Filter Track keys
        track_keys = {f.name for f in _dc_fields(Track)}
        tracks = []
        for td in d.get("tracks", []) or []:
            if not isinstance(td, dict):
                continue
            td2 = {k: v for k, v in td.items() if k in track_keys}
            tracks.append(Track(**td2))

        # Convert Clip + AudioEvents
        clip_keys = {f.name for f in _dc_fields(Clip)}
        clips = []
        for cd in d.get("clips", []) or []:
            if not isinstance(cd, dict):
                continue
            # audio_events may be list[dict]
            evs = cd.get("audio_events", None)
            if isinstance(evs, list):
                conv = []
                for e in evs:
                    if isinstance(e, dict):
                        try:
                            conv.append(AudioEvent(**e))
                        except Exception:
                            # best-effort: ignore malformed
                            continue
                cd = dict(cd)
                cd["audio_events"] = conv
            cd2 = {k: v for k, v in cd.items() if k in clip_keys}
            clips.append(Clip(**cd2))

        midi_notes: Dict[str, List[MidiNote]] = {}
        # Robust loader: filter unknown MidiNote keys (forward compatible)
        note_keys = {f.name for f in _dc_fields(MidiNote)}
        raw_notes = d.get("midi_notes", {}) or {}
        if isinstance(raw_notes, dict):
            for clip_id, notes in raw_notes.items():
                nl: List[MidiNote] = []
                if isinstance(notes, list):
                    for n in notes:
                        if isinstance(n, dict):
                            try:
                                n2 = {k: v for k, v in n.items() if k in note_keys}
                                nl.append(MidiNote(**n2).clamp())
                            except Exception:
                                continue
                midi_notes[str(clip_id)] = nl

        clip_launcher: Dict[str, str] = {}
        raw_cl = d.get("clip_launcher", {}) or {}
        if isinstance(raw_cl, dict):
            clip_launcher = {str(k): str(v) for k, v in raw_cl.items() if v}

        lq = str(d.get("launcher_quantize", "1 Bar"))
        lm = str(d.get("launcher_mode", "Trigger"))

        obj = cls(
            version=str(d.get("version", "0.0.19.7.52")),
            name=str(d.get("name", "Projekt")),
            created_utc=str(d.get("created_utc", "")),
            modified_utc=str(d.get("modified_utc", "")),
            sample_rate=int(d.get("sample_rate", 48000)),
            bpm=float(d.get("bpm", 120.0)),
            time_signature=str(d.get("time_signature", "4/4")),
            snap_division=str(d.get("snap_division", "1/16")),
            automation_lanes=dict(d.get("automation_lanes", {})) if d.get("automation_lanes") is not None else {},
            automation_manager_lanes=dict(d.get("automation_manager_lanes", {})) if isinstance(d.get("automation_manager_lanes", {}), dict) else {},
            arranger_collapsed_group_ids=[str(x) for x in (d.get("arranger_collapsed_group_ids", []) or []) if str(x)],
            midi_mappings=list(d.get("midi_mappings", [])) if d.get("midi_mappings") is not None else [],
            media=media,
            tracks=tracks,
            clips=clips,
            midi_notes=midi_notes,
            clip_launcher=clip_launcher,
            launcher_quantize=lq,
            launcher_mode=lm,
            ghost_layers=dict(d.get("ghost_layers", {})) if isinstance(d.get("ghost_layers", {}), dict) else {},
            notation_marks=[m for m in (d.get("notation_marks", []) or []) if isinstance(m, dict)],
        )
        if not obj.tracks:
            obj.tracks = [Track(kind="master", name="Master")]
        return obj
