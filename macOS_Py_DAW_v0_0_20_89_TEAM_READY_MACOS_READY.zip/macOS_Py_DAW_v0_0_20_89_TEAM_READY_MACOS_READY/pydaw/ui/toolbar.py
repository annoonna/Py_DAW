from __future__ import annotations

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import QWidget, QHBoxLayout, QLabel, QComboBox, QToolButton, QSizePolicy

from .python_logo_button import PythonLogoButton


class ToolBarPanel(QWidget):
    """Tool row (below transport): Werkzeug / Grid + right-aligned Automation & Python logo.

    Requirements:
    - Must be lightweight; no heavy work inside timer callbacks.
    - Python logo button: round, flat, seamless.
    - Optional color overlay toggled by a QTimer every 2 minutes.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("toolBarPanel")

        # Critical for the "full-width" Pro-DAW-like tools row.
        # When embedded into a QToolBar via addWidget(), Qt may otherwise keep
        # the widget at its sizeHint(), which can clip right-aligned controls
        # (Automation + Python logo).
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setMinimumWidth(1)

        self._py_anim_enabled: bool = True
        self._py_orange: bool = False

        self._py_anim_timer = QTimer(self)
        # 2 minutes. Single-shot keeps overhead minimal and avoids jitter.
        self._py_anim_timer.setInterval(120_000)
        self._py_anim_timer.setSingleShot(True)
        self._py_anim_timer.timeout.connect(self._on_py_anim_timeout)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(6, 2, 6, 2)
        layout.setSpacing(8)

        lbl_tool = QLabel("Werkzeug:")
        lbl_tool.setStyleSheet("color: #BBBBBB;")
        self.cmb_tool = QComboBox()
        self.cmb_tool.addItems(["Zeiger (V)", "Pencil", "Eraser", "Knife"])

        lbl_grid = QLabel("Grid/Snap:")
        lbl_grid.setStyleSheet("color: #BBBBBB;")
        self.cmb_grid = QComboBox()
        self.cmb_grid.addItems(["1/4", "1/8", "1/16", "1/32"])

        self.btn_auto = QToolButton()
        self.btn_auto.setText("Automation")
        self.btn_auto.setAutoRaise(True)
        self.btn_auto.setCursor(Qt.CursorShape.PointingHandCursor)

        # --- Python logo button (top-right, next to Automation) ---
        # Asset-free, vector-rendered via QPainterPath.
        self.btn_python = PythonLogoButton()
        self.btn_python.setObjectName("pythonLogoBtn")
        self.btn_python.setText("")

        # Left part
        layout.addWidget(lbl_tool)
        layout.addWidget(self.cmb_tool)
        layout.addSpacing(10)
        layout.addWidget(lbl_grid)
        layout.addWidget(self.cmb_grid)

        # Stretch pushes Automation + Python to the right edge
        layout.addStretch(1)
        layout.addWidget(self.btn_auto)
        layout.addWidget(self.btn_python)

        # Initial sizing
        self._sync_python_btn_size()

    # ---------------- Python logo animation ----------------

    def python_logo_animation_enabled(self) -> bool:
        return bool(self._py_anim_enabled)

    def set_python_logo_animation_enabled(self, enabled: bool) -> None:
        enabled = bool(enabled)
        self._py_anim_enabled = enabled

        if not enabled:
            try:
                self._py_anim_timer.stop()
            except Exception:
                pass
            self._py_orange = False
            try:
                self.btn_python.reset_default_colors()
            except Exception:
                pass
            return

        # enabled: start in original colors, then change after 2 minutes
        self._py_orange = False
        try:
            self.btn_python.reset_default_colors()
        except Exception:
            pass
        if self._py_anim_timer.isActive():
            self._py_anim_timer.stop()
        self._py_anim_timer.start()

    def _on_py_anim_timeout(self) -> None:
        if not self._py_anim_enabled:
            return
        # After 2 minutes, switch both snakes to orange.
        self._py_orange = True
        try:
            self.btn_python.set_orange()
        except Exception:
            pass

    # ---------------- Sizing & icon loading ----------------

    def _sync_python_btn_size(self) -> None:
        # Keep button perfectly round and as large as possible within this bar.
        try:
            h = max(22, min(40, int(self.height()) - 6))
            self.btn_python.setFixedSize(h, h)
        except Exception:
            pass

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._sync_python_btn_size()

    def closeEvent(self, event):
        try:
            self._py_anim_timer.stop()
        except Exception:
            pass
        super().closeEvent(event)
