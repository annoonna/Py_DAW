# -*- coding: utf-8 -*-
"""Drum Machine audio engine (pull-based).

Design constraints:
- DO NOT change DAW core: engine must look like existing sampler engines.
- Per-slot isolation: each pad owns its own ProSamplerEngine instance.
- Pull API: pull(frames, sr) -> (frames,2) float32 or None.
- Note trigger API: trigger_note(pitch, velocity, duration_ms) -> bool.

This makes it compatible with the existing SamplerRegistry routing:
MainWindow routes note_preview to the selected track's registered engine.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

import numpy as np

from pydaw.plugins.sampler.sampler_engine import ProSamplerEngine


AUDIO_EXTS = {".wav", ".flac", ".ogg", ".mp3", ".aif", ".aiff"}


@dataclass
class DrumSlotState:
    index: int
    name: str
    sample_path: str = ""
    # Additional per-slot UI state can go here later (pattern roles, colors, etc.)


class DrumSlot:
    """One pad/slot: isolated sampler engine + metadata."""

    def __init__(self, index: int, name: str, base_note: int = 36, target_sr: int = 48000):
        self.state = DrumSlotState(index=int(index), name=str(name), sample_path="")
        self.engine = ProSamplerEngine(target_sr=int(target_sr))
        self.base_note = int(base_note)
        self.set_midi_note(self.base_note + int(index))

        # Make it a bit lighter by default (drums usually want no huge FX)
        try:
            self.engine.set_filter(ftype="off")
            self.engine.set_fx(chorus_mix=0.0, delay_mix=0.0, reverb_mix=0.0)
            self.engine.set_distortion(0.0)
            self.engine.set_textures(0.0)
            self.engine.set_grain(0.0)
        except Exception:
            pass

    def set_midi_note(self, note: int) -> None:
        note = int(max(0, min(127, note)))
        try:
            self.engine.set_root(note)
        except Exception:
            try:
                self.engine.root_note = note
            except Exception:
                pass

    def has_sample(self) -> bool:
        return bool(self.engine.samples is not None)

    def load_sample(self, path: str) -> bool:
        p = Path(str(path))
        if p.suffix.lower() not in AUDIO_EXTS:
            return False
        ok = bool(self.engine.load_wav(str(p)))
        if ok:
            self.state.sample_path = str(p)
        return ok

    def clear_sample(self) -> None:
        try:
            with self.engine._lock:
                self.engine.samples = None
                self.engine.sample_name = ""
                self.engine.state.playing = False
        except Exception:
            pass
        self.state.sample_path = ""


class DrumMachineEngine:
    """Summing engine for N drum slots."""

    def __init__(self, slots: int = 16, base_note: int = 36, target_sr: int = 48000):
        self.base_note = int(base_note)
        self.target_sr = int(target_sr)

        default_names = [
            "Kick", "Snare", "CHat", "OHat",
            "Clap", "Tom", "Perc", "Rim",
            "FX1", "FX2", "Ride", "Crash",
            "Pad13", "Pad14", "Pad15", "Pad16",
        ]
        self.slots: List[DrumSlot] = []
        for i in range(int(slots)):
            nm = default_names[i] if i < len(default_names) else f"Pad{i+1}"
            self.slots.append(DrumSlot(i, nm, base_note=self.base_note, target_sr=self.target_sr))

        # Cache to reduce allocations on sum
        self._mix_buf: Optional[np.ndarray] = None

    # ---------------- Mapping
    def pitch_to_slot_index(self, pitch: int) -> Optional[int]:
        try:
            p = int(pitch)
        except Exception:
            return None
        idx = p - int(self.base_note)
        if 0 <= idx < len(self.slots):
            return int(idx)
        return None

    # ---------------- Note APIs (compatible with SamplerRegistry)
    def trigger_note(self, pitch: int, velocity: int = 100, duration_ms: int | None = 140) -> bool:
        idx = self.pitch_to_slot_index(pitch)
        if idx is None:
            return False
        slot = self.slots[idx]
        # Keep pitch stable by triggering with its own root note
        try:
            root = int(getattr(slot.engine, "root_note", self.base_note + idx))
        except Exception:
            root = self.base_note + idx
        return bool(slot.engine.trigger_note(root, int(velocity), duration_ms))

    def note_on(self, pitch: int, velocity: int = 100) -> bool:
        # Drums are usually one-shots; treat note_on as a sustain-less trigger.
        return self.trigger_note(pitch, velocity, 140)

    def note_off(self) -> None:
        # Not needed for one-shots; keep for API compatibility.
        return

    def all_notes_off(self) -> None:
        for s in self.slots:
            try:
                s.engine.all_notes_off()
            except Exception:
                pass

    def stop_all(self) -> None:
        self.all_notes_off()

    # ---------------- Pull render
    def pull(self, frames: int, sr: int) -> Optional[np.ndarray]:
        frames = int(frames)
        if frames <= 0:
            return None
        # v0.0.20.67: Allow sample rate mismatch - better to output than silence.
        # The slot engines will handle their own SR checks. If a mismatch exists,
        # the audio may be pitched wrong, but at least there's output.
        # Log a warning once per engine instance.
        if int(sr) != int(self.target_sr):
            if not getattr(self, "_sr_warn_logged", False):
                try:
                    import logging
                    logging.getLogger(__name__).warning(
                        f"DrumMachineEngine: SR mismatch (got {sr}, expected {self.target_sr}). "
                        "Audio may be pitched incorrectly."
                    )
                except Exception:
                    pass
                self._sr_warn_logged = True
            # Update target_sr dynamically to match the audio callback
            self.target_sr = int(sr)
            for s in self.slots:
                try:
                    s.engine.target_sr = int(sr)
                except Exception:
                    pass

        mix = None
        for s in self.slots:
            try:
                b = s.engine.pull(frames, sr)
            except Exception:
                b = None
            if b is None:
                continue
            if mix is None:
                # lazily allocate
                if self._mix_buf is None or self._mix_buf.shape[0] != frames:
                    self._mix_buf = np.zeros((frames, 2), dtype=np.float32)
                else:
                    self._mix_buf.fill(0.0)
                mix = self._mix_buf
                mix[:frames, :2] = b[:frames, :2]
            else:
                try:
                    mix[:frames, :2] += b[:frames, :2]
                except Exception:
                    mix[:frames, :2] = mix[:frames, :2] + b[:frames, :2]

        return mix

    # ---------------- Session IO (future)
    def export_state(self) -> dict:
        out = {"base_note": int(self.base_note), "slots": []}
        for s in self.slots:
            try:
                out["slots"].append(
                    {
                        "index": int(s.state.index),
                        "name": str(s.state.name),
                        "sample_path": str(s.state.sample_path),
                        "sampler": s.engine.export_state(),
                    }
                )
            except Exception:
                out["slots"].append({"index": int(s.state.index), "name": str(s.state.name), "sample_path": str(s.state.sample_path)})
        return out

    def import_state(self, d: dict) -> None:
        try:
            self.base_note = int(d.get("base_note", self.base_note))
        except Exception:
            pass
        slots = d.get("slots", []) or []
        for sd in slots:
            try:
                idx = int(sd.get("index", -1))
                if not (0 <= idx < len(self.slots)):
                    continue
                s = self.slots[idx]
                s.state.name = str(sd.get("name", s.state.name))
                sp = str(sd.get("sample_path", ""))
                if sp:
                    s.load_sample(sp)
                try:
                    sampler_state = sd.get("sampler", None)
                    if sampler_state:
                        s.engine.import_state(sampler_state)
                except Exception:
                    pass
                s.set_midi_note(self.base_note + idx)
            except Exception:
                continue
