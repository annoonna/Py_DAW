v0.0.20.88

- macOS Install/Deps: CoreAudio via sounddevice + Metal readiness (wgpu) + neuer install.py Preflight.
