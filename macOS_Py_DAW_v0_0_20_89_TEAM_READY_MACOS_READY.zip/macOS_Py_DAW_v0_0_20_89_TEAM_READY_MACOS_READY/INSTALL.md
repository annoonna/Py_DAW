# 📦 ChronoScaleStudio (Py_DAW) — Installation

## System Requirements
- **Python:** 3.10+ (3.13 wird unterstützt; einige Performance-Features sind optional)
- **GUI:** PyQt6
- **Audio Backends:**
  - **Linux:** PipeWire-JACK / JACK (Routing via qpwgraph optional) oder sounddevice
  - **macOS:** **CoreAudio** via sounddevice (PortAudio) ✅ default
  - **Windows:** WASAPI via sounddevice

---

## Quick Install (alle OS)

```bash
# 1) Unzip
unzip Py_DAW_v0_0_20_89_TEAM_READY.zip
cd Py_DAW_v0_0_20_89_TEAM_READY

# 2) venv
python3 -m venv myenv
source myenv/bin/activate

# 3) Install (inkl. OS-Hinweisen)
python3 install.py

# 4) Start
python3 main.py
```

> Windows: `py -m venv myenv` und dann `myenv\Scripts\activate`

---

## macOS (CoreAudio + Metal readiness)

### Homebrew Abhängigkeiten
```bash
brew install portaudio libsndfile
brew install fluidsynth
brew install ffmpeg
```

> `pyfluidsynth` (Python) nutzt die **System-Library** von FluidSynth.
> Deshalb ist `brew install fluidsynth` auf macOS Pflicht, wenn du SF2 nutzen willst.

Optional (nur wenn du JACK nutzen willst):
- JACK installieren (z.B. JackOSX oder `brew install jack`)
- Danach zusätzlich: `pip install JACK-Client`

### Audio-Backend
- Standard ist **sounddevice** → CoreAudio.
- In der App: **Einstellungen → Audio** (Output-Device wählen, Sample-Rate/Buffer).

### Metal
- Die GUI läuft über Qt6. GPU-Overlays nutzen aktuell **PyOpenGL** (wenn aktiviert).
- Zusätzlich installieren wir optional `wgpu` (WebGPU), das auf macOS **Metal** nutzt – als Basis für zukünftige Metal-Overlays.

---

## Linux (PipeWire-JACK / JACK)

### PipeWire-JACK (empfohlen)
```bash
sudo apt update
sudo apt install pipewire-jack qpwgraph
```

Start:
```bash
python3 main.py
# wenn du explizit als JACK Client in qpwgraph auftauchen willst:
pw-jack python3 main.py
```

### JACK (klassisch)
```bash
sudo apt install jackd2
jack_control start
```

---

## Troubleshooting

### "sounddevice/soundfile Import fehlgeschlagen"
- macOS: `brew install portaudio libsndfile`
- Linux: `sudo apt install portaudio19-dev libsndfile1`

### Vulkan (Linux) — System packages
```bash
sudo apt update
sudo apt install libvulkan1 mesa-vulkan-drivers vulkan-tools
```

---

## Done!
Run: `python3 main.py`
