"""Installer helper for Py_DAW.

Usage:
    python install.py

It will:
- warn if you're not inside a virtual environment
- install/upgrade pip
- install requirements (Windows prefers requirements_windows.txt)

Note:
- System-level audio components (JACK/PipeWire/ASIO drivers) are not installed here.
"""

from __future__ import annotations

import os
import sys
import subprocess
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def _in_venv() -> bool:
    return (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))


def main() -> int:
    here = Path(__file__).resolve().parent

    req_default = here / "requirements.txt"
    req_win = here / "requirements_windows.txt"
    req = req_default

    if sys.platform.startswith("win") and req_win.exists():
        req = req_win

    if not req.exists():
        print(f"{req.name} not found.")
        return 2

    if not _in_venv():
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        if sys.platform.startswith("win"):
            print("      Empfehlung (Windows): py -m venv .venv && .\\.venv\\Scripts\\activate")
        else:
            print("      Empfehlung: python3 -m venv myenv && source myenv/bin/activate")

    py = sys.executable
    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    _run([py, "-m", "pip", "install", "-r", str(req)])

    print("\nOK. Starte danach mit: python main.py")
    if sys.platform.startswith("win"):
        print("Hinweis (Windows): Standard ist WASAPI. Optional:")
        print("  setx PYDAW_SD_HOSTAPI wasapi")
        print("  setx PYDAW_WASAPI_EXCLUSIVE 1")
        print("  setx PYDAW_QT_OPENGL angle")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
