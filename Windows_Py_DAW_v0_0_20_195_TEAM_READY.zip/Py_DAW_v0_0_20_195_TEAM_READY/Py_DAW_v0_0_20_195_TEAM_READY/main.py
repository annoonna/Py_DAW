"""Entry point for Py DAW."""

from __future__ import annotations

import faulthandler
import os
import shutil
import signal
import sys
# --- Windows Qt bootstrap (must happen BEFORE importing PyQt6)
if sys.platform.startswith('win'):
    try:
        from pydaw.platform.windows_qt_init import configure_windows_qt
        configure_windows_qt()
    except Exception:
        pass
    os.environ.setdefault('PYDAW_SD_HOSTAPI', 'wasapi')


from pathlib import Path

faulthandler.enable(all_threads=True)
try:
    faulthandler.register(signal.SIGABRT, all_threads=True)
except Exception:
    pass


def _purge_local_pycache(project_root: Path) -> None:
    """Remove stale __pycache__/pyc from the local project folder.

    Users often unzip a new TEAM_READY build over an existing folder.
    Python may then load old *.pyc files whose timestamps still match the
    extracted sources (zip preserves mtimes). This can lead to "ghost" bugs
    like missing methods even though the source looks correct.

    Safe: only touches the current project folder.
    """

    try:
        for p in project_root.rglob("__pycache__"):
            shutil.rmtree(p, ignore_errors=True)
        for p in project_root.rglob("*.pyc"):
            try:
                p.unlink()
            except Exception:
                pass
    except Exception:
        pass


# Avoid writing new bytecode (keeps project folders clean).
try:
    sys.dont_write_bytecode = True
except Exception:
    pass

# Purge local caches unless user explicitly disables it.
if os.environ.get("PYDAW_PURGE_PYCACHE", "1").lower() not in ("0", "false", "no", "off"):
    _purge_local_pycache(Path(__file__).resolve().parent)

# --- Graphics backend selection (must happen BEFORE importing PyQt6)
# Linux default: Vulkan (when available). Override via:
#   PYDAW_GFX_BACKEND=opengl python3 main.py
try:
    from pydaw.utils.gfx_backend import configure_graphics_backend

    configure_graphics_backend()
except Exception:
    # Never block startup.
    pass

from pydaw.app import run

if __name__ == "__main__":
    run()
