"""Platform-specific paths (Windows/macOS/Linux) for cache/config/data.

Avoid hard-coded ~/.cache and ~/.config on Windows.

Overrides (optional):
  PYDAW_CACHE_DIR
  PYDAW_CONFIG_DIR
  PYDAW_DATA_DIR
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


def is_windows() -> bool:
    return sys.platform.startswith("win")


def _env_path(var: str) -> Path | None:
    v = os.environ.get(var)
    if v:
        try:
            return Path(v).expanduser().resolve()
        except Exception:
            return Path(v).expanduser()
    return None


def cache_root() -> Path:
    p = _env_path("PYDAW_CACHE_DIR")
    if p is not None:
        return p
    if is_windows():
        base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base)
    return Path(os.environ.get("XDG_CACHE_HOME") or (Path.home() / ".cache"))


def config_root() -> Path:
    p = _env_path("PYDAW_CONFIG_DIR")
    if p is not None:
        return p
    if is_windows():
        base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        return Path(base)
    return Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config"))


def data_root() -> Path:
    p = _env_path("PYDAW_DATA_DIR")
    if p is not None:
        return p
    if is_windows():
        base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base)
    return Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))


def get_cache_dir(app_name: str) -> Path:
    return cache_root() / app_name


def get_config_dir(app_name: str) -> Path:
    return config_root() / app_name


def get_data_dir(app_name: str) -> Path:
    return data_root() / app_name


def ensure_dir(p: Path) -> Path:
    try:
        p.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return p
