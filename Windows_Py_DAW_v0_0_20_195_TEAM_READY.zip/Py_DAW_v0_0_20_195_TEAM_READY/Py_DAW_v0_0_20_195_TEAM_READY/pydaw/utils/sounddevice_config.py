"""sounddevice helper for safer defaults on Windows (non-invasive)."""

from __future__ import annotations

import os
import sys
from typing import Optional, Any

try:
    import sounddevice as sd  # type: ignore
except Exception:  # pragma: no cover
    sd = None  # type: ignore


def is_windows() -> bool:
    return sys.platform.startswith("win")


def _truthy(v: str | None) -> bool:
    return (v or "").strip().lower() in ("1", "true", "yes", "on")


def get_preferred_hostapi() -> str:
    return (os.environ.get("PYDAW_SD_HOSTAPI") or "wasapi").strip().lower()


def pick_device(kind: str, prefer_hostapi: str = "wasapi", prefer_name: str = "") -> Optional[int]:
    if sd is None:
        return None
    try:
        devices = sd.query_devices()
        hostapis = sd.query_hostapis()
    except Exception:
        return None

    want_input = kind.lower().startswith("in")
    prefer_hostapi = (prefer_hostapi or "").lower()

    cands: list[tuple[int, int]] = []
    for idx, d in enumerate(devices):
        try:
            max_in = int(d.get("max_input_channels") or 0)
            max_out = int(d.get("max_output_channels") or 0)
            name = str(d.get("name") or "")
            hostapi_idx = int(d.get("hostapi") or 0)
            hostapi_name = str(hostapis[hostapi_idx].get("name") or "").lower()
        except Exception:
            continue

        if want_input and max_in <= 0:
            continue
        if (not want_input) and max_out <= 0:
            continue
        if prefer_name and prefer_name.lower() not in name.lower():
            continue

        score = 0
        if prefer_hostapi and prefer_hostapi in hostapi_name:
            score += 50
        if "default" in name.lower():
            score += 10
        cands.append((score, idx))

    if not cands:
        return None
    cands.sort(reverse=True)
    return cands[0][1]


def default_output_device() -> Optional[int]:
    if not is_windows():
        return None
    host = get_preferred_hostapi()
    name = os.environ.get("PYDAW_SD_OUTPUT_NAME") or ""
    return pick_device("output", prefer_hostapi=host, prefer_name=name)


def default_input_device() -> Optional[int]:
    if not is_windows():
        return None
    host = get_preferred_hostapi()
    name = os.environ.get("PYDAW_SD_INPUT_NAME") or ""
    return pick_device("input", prefer_hostapi=host, prefer_name=name)


def get_wasapi_settings() -> Any:
    if sd is None or not is_windows():
        return None
    if not _truthy(os.environ.get("PYDAW_WASAPI_EXCLUSIVE")):
        return None
    try:
        return sd.WasapiSettings(exclusive=True)  # type: ignore[attr-defined]
    except Exception:
        return None
