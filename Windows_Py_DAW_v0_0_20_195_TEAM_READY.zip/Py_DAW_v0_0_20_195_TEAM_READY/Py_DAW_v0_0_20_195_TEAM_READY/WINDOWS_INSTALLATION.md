# Py_DAW (ChronoScaleStudio) – Windows Installation

## Setup (PowerShell)
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install --upgrade pip setuptools wheel
py install.py
py main.py
```

## Audio (WASAPI)
Optional:
- `setx PYDAW_SD_HOSTAPI wasapi`
- `setx PYDAW_WASAPI_EXCLUSIVE 1`

## Qt/Rendering
Optional:
- `setx PYDAW_QT_OPENGL angle`
- `setx PYDAW_QT_OPENGL software`
- `setx PYDAW_QT_OPENGL desktop`

## FluidSynth (SF2 Rendering)
Optional:
- `setx FLUIDSYNTH_PATH C:\\Path\\to\\fluidsynth.exe`
