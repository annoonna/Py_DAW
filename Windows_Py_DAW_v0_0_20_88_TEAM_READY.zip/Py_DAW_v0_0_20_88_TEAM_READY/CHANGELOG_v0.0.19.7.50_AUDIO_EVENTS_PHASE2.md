# v0.0.19.7.50 – Audio Events (Phase 2)

- AudioEvent dataclass + Clip.audio_events
- Knife Tool splittet AudioEvents non-destructive
- Eraser Tool merged Events an Boundary
- Context Menu: Split at Playhead (Transport.current_beat)
- Legacy: audio_slices bleibt als abgeleitete Boundary-Liste für Launcher/Preview
