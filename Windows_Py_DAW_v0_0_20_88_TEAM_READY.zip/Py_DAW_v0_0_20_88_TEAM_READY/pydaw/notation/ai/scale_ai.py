
import random
from pydaw.notation.scales.database import SCALES

def random_scale():
    return random.choice(list(SCALES.keys()))
