"""Graphics backend selection.

Goal:
- Keep configuration *early* (before importing PyQt6 / creating QApplication).
- Never hard-crash the app just because a GPU backend is missing.

Defaults:
- Windows: D3D11 via Qt RHI (QSG_RHI_BACKEND=d3d11)
- Linux: Vulkan if loader present, else OpenGL

Configuration:
- Environment variable `PYDAW_GFX_BACKEND`:
    * auto (default)
    * d3d11   (Windows recommended)
    * vulkan
    * opengl
    * software

Notes:
- The current UI is QWidget-based, so this mostly prepares future Qt Quick / RHI
  usage and keeps the app stable on problematic systems.
"""

from __future__ import annotations

import ctypes.util
import os
import platform
from typing import Literal

Backend = Literal["auto", "d3d11", "vulkan", "opengl", "software"]


def _sys() -> str:
    try:
        return platform.system().lower()
    except Exception:
        return ""


def _is_linux() -> bool:
    return _sys() == "linux"


def _is_windows() -> bool:
    return _sys() == "windows"


def _vulkan_loader_present() -> bool:
    """Best-effort check for a Vulkan loader on the system."""
    try:
        if ctypes.util.find_library("vulkan"):
            return True
    except Exception:
        pass

    # Common loader names/paths (Debian/Ubuntu)
    candidates = (
        "/usr/lib/x86_64-linux-gnu/libvulkan.so.1",
        "/usr/lib/aarch64-linux-gnu/libvulkan.so.1",
        "/usr/lib/libvulkan.so.1",
        "/lib/x86_64-linux-gnu/libvulkan.so.1",
        "/lib/aarch64-linux-gnu/libvulkan.so.1",
        "/lib/libvulkan.so.1",
    )
    return any(os.path.exists(p) for p in candidates)


def configure_graphics_backend() -> str:
    """Configure the preferred graphics backend.

    Returns the chosen backend string.
    """
    requested = str(os.environ.get("PYDAW_GFX_BACKEND", "auto")).strip().lower()
    if requested not in ("auto", "d3d11", "vulkan", "opengl", "software"):
        requested = "auto"

    backend: Backend
    if requested == "auto":
        if _is_windows():
            backend = "d3d11"
        elif _is_linux() and _vulkan_loader_present():
            backend = "vulkan"
        else:
            backend = "opengl"
    else:
        backend = requested  # type: ignore

    # These env vars must be set BEFORE importing Qt / creating QApplication.
    if backend in ("d3d11", "vulkan", "opengl"):
        os.environ.setdefault("QT_QUICK_BACKEND", "rhi")
        os.environ.setdefault("QSG_RHI_BACKEND", backend)
    elif backend == "software":
        os.environ.setdefault("QT_QUICK_BACKEND", "software")

    os.environ["PYDAW_GFX_BACKEND_EFFECTIVE"] = backend
    return backend
