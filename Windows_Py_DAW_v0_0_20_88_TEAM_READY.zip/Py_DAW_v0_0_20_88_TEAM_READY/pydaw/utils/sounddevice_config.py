"""sounddevice (PortAudio) configuration helpers.

Windows goals:
- Prefer WASAPI by default (stable, low-latency).
- Optionally enable WASAPI Exclusive Mode via env var.
- Pick a sensible default output/input device if the project/settings don't
  specify one.

Env vars:
- PYDAW_SD_HOSTAPI: wasapi | asio | directsound | mme | auto
- PYDAW_WASAPI_EXCLUSIVE: 1 to enable exclusive mode (best-effort)
- PYDAW_SD_OUTPUT_DEVICE: int index OR substring match on device name
- PYDAW_SD_INPUT_DEVICE:  int index OR substring match on device name

These helpers are best-effort and NEVER raise.
"""

from __future__ import annotations

import os
import platform
from typing import Any, Optional, Tuple


def _is_windows() -> bool:
    try:
        return platform.system().lower() == "windows"
    except Exception:
        return False


def _norm(s: str) -> str:
    return " ".join(str(s).strip().lower().split())


def preferred_hostapi() -> str:
    v = _norm(os.environ.get("PYDAW_SD_HOSTAPI", "auto"))
    if v in ("", "auto", "default"):
        return "auto"
    if v in ("ds", "directsound", "direct sound"):
        return "directsound"
    return v


def _parse_device_override(raw: str) -> Tuple[Optional[int], Optional[str]]:
    raw = str(raw).strip()
    if not raw:
        return None, None
    try:
        return int(raw), None
    except Exception:
        return None, raw


def _find_hostapi_index(sd: Any, prefer: str) -> Optional[int]:
    try:
        hostapis = sd.query_hostapis()
    except Exception:
        return None
    prefer_n = _norm(prefer)
    if prefer_n in ("auto", ""):
        return None

    for i, h in enumerate(hostapis or []):
        name = _norm(h.get("name", ""))
        if prefer_n in name:
            return i

    # Heuristics for Windows names
    if prefer_n == "wasapi":
        for i, h in enumerate(hostapis or []):
            if "wasapi" in _norm(h.get("name", "")):
                return i
    if prefer_n == "asio":
        for i, h in enumerate(hostapis or []):
            if "asio" in _norm(h.get("name", "")):
                return i
    if prefer_n == "directsound":
        for i, h in enumerate(hostapis or []):
            if "directsound" in _norm(h.get("name", "")) or "direct sound" in _norm(h.get("name", "")):
                return i
    if prefer_n == "mme":
        for i, h in enumerate(hostapis or []):
            if "mme" in _norm(h.get("name", "")):
                return i

    return None


def _device_matches_name(dev: Any, needle: str) -> bool:
    try:
        return needle and _norm(needle) in _norm(dev.get("name", ""))
    except Exception:
        return False


def choose_output_device(sd: Any, current: Optional[int]) -> Optional[int]:
    """Return a good output device index (best-effort)."""
    # explicit override
    idx_override, name_override = _parse_device_override(os.environ.get("PYDAW_SD_OUTPUT_DEVICE", ""))
    if idx_override is not None:
        return idx_override

    prefer = preferred_hostapi()

    try:
        devs = sd.query_devices()
    except Exception:
        return current

    # if current is set and valid, keep it
    if current is not None:
        try:
            _ = devs[int(current)]
            return int(current)
        except Exception:
            pass

    # substring override
    if name_override:
        for i, d in enumerate(devs or []):
            try:
                if int(d.get("max_output_channels", 0)) > 0 and _device_matches_name(d, name_override):
                    return i
            except Exception:
                continue

    hostapi_idx = _find_hostapi_index(sd, prefer)

    # Prefer default output device if it matches hostapi
    try:
        default_out = None
        try:
            default_out = sd.default.device[1]
        except Exception:
            default_out = None
        if default_out is not None:
            d = devs[int(default_out)]
            if int(d.get("max_output_channels", 0)) > 0:
                if hostapi_idx is None or int(d.get("hostapi", -1)) == int(hostapi_idx):
                    return int(default_out)
    except Exception:
        pass

    # Pick first device that matches hostapi (if requested)
    for i, d in enumerate(devs or []):
        try:
            if int(d.get("max_output_channels", 0)) <= 0:
                continue
            if hostapi_idx is not None and int(d.get("hostapi", -1)) != int(hostapi_idx):
                continue
            return i
        except Exception:
            continue

    # Last resort: any output device
    for i, d in enumerate(devs or []):
        try:
            if int(d.get("max_output_channels", 0)) > 0:
                return i
        except Exception:
            continue

    return None


def choose_input_device(sd: Any, current: Optional[int]) -> Optional[int]:
    """Return a good input device index (best-effort)."""
    idx_override, name_override = _parse_device_override(os.environ.get("PYDAW_SD_INPUT_DEVICE", ""))
    if idx_override is not None:
        return idx_override

    prefer = preferred_hostapi()

    try:
        devs = sd.query_devices()
    except Exception:
        return current

    if current is not None:
        try:
            _ = devs[int(current)]
            return int(current)
        except Exception:
            pass

    if name_override:
        for i, d in enumerate(devs or []):
            try:
                if int(d.get("max_input_channels", 0)) > 0 and _device_matches_name(d, name_override):
                    return i
            except Exception:
                continue

    hostapi_idx = _find_hostapi_index(sd, prefer)

    try:
        default_in = None
        try:
            default_in = sd.default.device[0]
        except Exception:
            default_in = None
        if default_in is not None:
            d = devs[int(default_in)]
            if int(d.get("max_input_channels", 0)) > 0:
                if hostapi_idx is None or int(d.get("hostapi", -1)) == int(hostapi_idx):
                    return int(default_in)
    except Exception:
        pass

    for i, d in enumerate(devs or []):
        try:
            if int(d.get("max_input_channels", 0)) <= 0:
                continue
            if hostapi_idx is not None and int(d.get("hostapi", -1)) != int(hostapi_idx):
                continue
            return i
        except Exception:
            continue

    for i, d in enumerate(devs or []):
        try:
            if int(d.get("max_input_channels", 0)) > 0:
                return i
        except Exception:
            continue

    return None


def build_wasapi_extra_settings(sd: Any) -> Any:
    """Return sounddevice WasapiSettings or None."""
    if not _is_windows():
        return None

    exclusive = str(os.environ.get("PYDAW_WASAPI_EXCLUSIVE", "0")).strip().lower() in ("1", "true", "yes", "on")
    if not exclusive:
        return None

    try:
        WasapiSettings = getattr(sd, "WasapiSettings", None)
        if WasapiSettings is None:
            return None
        return WasapiSettings(exclusive=True)
    except Exception:
        return None
