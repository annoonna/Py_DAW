"""MIDI domain helpers.

We keep MIDI note data in a clip-scoped structure.

Notes are primarily represented as simple rectangles for the Piano Roll.
For upcoming notation support we also store a minimal "spelling" (accidental)
and a tie flag. These fields are optional, backward compatible, and do *not*
change existing playback.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple


@dataclass
class MidiNote:
    pitch: int        # 0..127
    start_beats: float
    length_beats: float
    velocity: int = 100
    # Notation helpers (optional)
    accidental: int = 0      # -2=bb, -1=b, 0=natural/none, 1=#, 2=##
    tie_to_next: bool = False

    def clamp(self) -> "MidiNote":
        self.pitch = max(0, min(127, int(self.pitch)))
        self.length_beats = max(0.125, float(self.length_beats))
        self.start_beats = max(0.0, float(self.start_beats))
        self.velocity = max(1, min(127, int(self.velocity)))
        self.accidental = max(-2, min(2, int(getattr(self, "accidental", 0))))
        self.tie_to_next = bool(getattr(self, "tie_to_next", False))
        return self

    # ----------------- Notation conversion -----------------
    #
    # Staff position model (minimal, stable):
    #   - line: diatonic step within octave (C=0..B=6)
    #   - octave: scientific octave number where C4 == MIDI 60
    #
    # This is NOT a full engraving model; it is just enough to map a MIDI pitch
    # to a predictable staff position for WIP notation rendering.

    _PC_TO_LINE_ACC = {
        0: (0, 0),   # C
        1: (0, 1),   # C#
        2: (1, 0),   # D
        3: (1, 1),   # D#
        4: (2, 0),   # E
        5: (3, 0),   # F
        6: (3, 1),   # F#
        7: (4, 0),   # G
        8: (4, 1),   # G#
        9: (5, 0),   # A
        10: (5, 1),  # A#
        11: (6, 0),  # B
    }

    _LINE_TO_NATURAL_PC = {
        0: 0,   # C
        1: 2,   # D
        2: 4,   # E
        3: 5,   # F
        4: 7,   # G
        5: 9,   # A
        6: 11,  # B
    }

    def to_staff_position(self) -> Tuple[int, int]:
        """Convert this MIDI note's pitch to a minimal staff position.

        Returns:
            (line, octave) where line is 0..6 (C..B) and octave follows the
            scientific convention (C4 == MIDI 60).

        Side effect:
            Updates ``self.accidental`` to match the derived pitch spelling.
        """

        p = int(self.pitch)
        p = max(0, min(127, p))
        octave = (p // 12) - 1
        pc = p % 12

        line, acc = self._PC_TO_LINE_ACC.get(pc, (0, 0))
        self.accidental = int(acc)
        return int(line), int(octave)

    @staticmethod
    def from_staff_position(line: int, octave: int, accidental: int = 0) -> int:
        """Convert a staff position back to a MIDI pitch.

        Args:
            line: diatonic step in octave (C=0..B=6)
            octave: scientific octave number where C4 == MIDI 60
            accidental: optional chromatic alteration (-2..2)

        Returns:
            MIDI pitch (0..127)
        """

        if int(line) not in MidiNote._LINE_TO_NATURAL_PC:
            raise ValueError(f"Invalid staff line index: {line} (expected 0..6)")

        natural_pc = MidiNote._LINE_TO_NATURAL_PC[int(line)]
        acc = max(-2, min(2, int(accidental)))
        pitch = (int(octave) + 1) * 12 + int(natural_pc) + acc
        return max(0, min(127, int(pitch)))


MidiClipNotes = Dict[str, List[MidiNote]]
