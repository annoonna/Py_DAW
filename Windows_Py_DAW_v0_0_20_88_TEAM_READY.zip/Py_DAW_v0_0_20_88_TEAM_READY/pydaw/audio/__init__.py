"""Audio subsystem (v0.0.2: backend detection + settings dialog hooks)."""
