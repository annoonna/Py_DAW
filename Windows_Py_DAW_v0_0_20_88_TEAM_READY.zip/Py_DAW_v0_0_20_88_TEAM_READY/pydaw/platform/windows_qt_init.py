"""Windows Qt/Graphics early init.

Why:
- On Windows, QWidget/OpenGL initialization can be fragile depending on GPU
  drivers, remote desktop, or VM environments.
- A safe default is to route Qt's OpenGL through ANGLE (Direct3D 11).
- If Qt Quick / RHI is used, prefer the native D3D11 backend.

This module MUST be executed BEFORE importing PyQt6.

Env overrides:
- PYDAW_QT_OPENGL:   'angle' | 'desktop' | 'software' (maps to QT_OPENGL)
- PYDAW_QT_ANGLE:    'd3d11' | 'd3d9' (maps to QT_ANGLE_PLATFORM)
- PYDAW_QT_RHI:      e.g. 'd3d11' | 'opengl' | 'vulkan' (maps to QSG_RHI_BACKEND)
"""

from __future__ import annotations

import os


def configure_windows_qt() -> None:
    """Apply Windows-safe Qt rendering defaults (best effort)."""

    # QWidget OpenGL path
    qt_opengl = str(os.environ.get("PYDAW_QT_OPENGL", "")).strip().lower()
    if qt_opengl:
        os.environ.setdefault("QT_OPENGL", qt_opengl)
    else:
        # default: ANGLE (Direct3D)
        os.environ.setdefault("QT_OPENGL", "angle")

    # ANGLE backend
    qt_angle = str(os.environ.get("PYDAW_QT_ANGLE", "")).strip().lower()
    if qt_angle:
        os.environ.setdefault("QT_ANGLE_PLATFORM", qt_angle)
    else:
        os.environ.setdefault("QT_ANGLE_PLATFORM", "d3d11")

    # Qt Quick / RHI backend (harmless even if UI is QWidget-only)
    os.environ.setdefault("QT_QUICK_BACKEND", "rhi")
    qt_rhi = str(os.environ.get("PYDAW_QT_RHI", "")).strip().lower()
    if qt_rhi:
        os.environ.setdefault("QSG_RHI_BACKEND", qt_rhi)
    else:
        os.environ.setdefault("QSG_RHI_BACKEND", "d3d11")

    # Some users run PyDAW in RDP/VM. Qt can choose software fallback.
    # We do not force it, but allow users to set PYDAW_QT_OPENGL=software.
