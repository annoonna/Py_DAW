"""Platform-specific helpers.

This package intentionally contains *no* Qt imports, so helpers can be called
very early (before importing PyQt6) from `main.py`.
"""
