# 🎹 PyDAW v0.0.20.88 - Windows Installations-Anleitung

**Komplette Schritt-für-Schritt Anleitung für Windows 10/11**

---

## 📋 Voraussetzungen

- **Windows 10 oder 11** (64-bit)
- **Python 3.10+** (Empfehlung: 3.11 oder 3.12; 3.13 geht auch, aber Numba ist dort ggf. noch nicht verfügbar)
- **ca. 500 MB freier Speicherplatz**

---

## 🚀 Installation

### Schritt 1: Python installieren

1. Lade Python von https://www.python.org/downloads/ herunter
2. **Wichtig:** Aktiviere beim Installieren **"Add Python to PATH"** ✅
3. Verifiziere:

```cmd
python --version
```

---

### Schritt 2: PyDAW entpacken

1. Entpacke `Windows_Py_DAW_v0_0_20_88_TEAM_READY.zip` z.B. nach:

```text
C:\Users\<dein-name>\Documents\PyDAW\Windows_Py_DAW_v0_0_20_88_TEAM_READY
```

---

### Schritt 3: Virtuelle Umgebung + Pakete

Öffne **CMD** oder **PowerShell** und gehe in den Ordner:

```cmd
cd C:\Users\<dein-name>\Documents\PyDAW\Windows_Py_DAW_v0_0_20_88_TEAM_READY
```

Virtuelle Umgebung erstellen:

```cmd
py -m venv .venv
```

Aktivieren (CMD):

```cmd
.venv\Scripts\activate
```

Aktivieren (PowerShell):

```powershell
.\.venv\Scripts\Activate.ps1
```

Pakete installieren:

```cmd
py install.py
```

---

## 🎵 Start

```cmd
py main.py
```

---

## 🔊 Windows Audio Hinweise (WASAPI)

PyDAW nutzt **sounddevice (PortAudio)**.

Standard (automatisch): **WASAPI**.

Optionen per Umgebungsvariable:

- Host-API wählen:
  - `PYDAW_SD_HOSTAPI=wasapi` (Default)
  - `PYDAW_SD_HOSTAPI=directsound`
  - `PYDAW_SD_HOSTAPI=mme`
  - `PYDAW_SD_HOSTAPI=asio` (nur wenn ASIO-Treiber installiert sind)

- Optional: WASAPI Exclusive Mode:
  - `PYDAW_WASAPI_EXCLUSIVE=1`

Beispiel (nur für aktuelles Terminal):

```cmd
set PYDAW_SD_HOSTAPI=wasapi
set PYDAW_WASAPI_EXCLUSIVE=0
py main.py
```

---

## 🎹 MIDI/SF2 Rendering: FluidSynth installieren

Für MIDI→WAV Rendering (SF2 SoundFonts) braucht PyDAW **FluidSynth CLI**.

### 1) FluidSynth herunterladen

1. https://github.com/FluidSynth/fluidsynth/releases/latest
2. Lade das Windows x64 ZIP (z.B. `fluidsynth-...-win10-x64-...zip`)
3. Entpacke z.B. nach:

```text
C:\fluidsynth
```

Struktur sollte sein:

```text
C:\fluidsynth\bin\fluidsynth.exe
```

### 2) PATH + FLUIDSYNTH_PATH setzen

**Option A: GUI**
- Umgebungsvariablen öffnen → Benutzervariablen
- `Path` erweitern um: `C:\fluidsynth\bin`
- Neue Variable:
  - `FLUIDSYNTH_PATH = C:\fluidsynth\bin\fluidsynth.exe`

**Option B: PowerShell**

```powershell
[Environment]::SetEnvironmentVariable("Path", $env:Path + ";C:\fluidsynth\bin", "User")
[Environment]::SetEnvironmentVariable("FLUIDSYNTH_PATH", "C:\fluidsynth\bin\fluidsynth.exe", "User")
```

Dann **neues Terminal** öffnen und testen:

```cmd
where fluidsynth
fluidsynth --version
```

---

## 🧰 Troubleshooting

### "FluidSynth CLI nicht gefunden"

- Prüfe:
  - `where fluidsynth`
  - `echo %FLUIDSYNTH_PATH%`

Temporär (nur dieses Terminal):

```cmd
set FLUIDSYNTH_PATH=C:\fluidsynth\bin\fluidsynth.exe
set PATH=%PATH%;C:\fluidsynth\bin
py main.py
```

### "ModuleNotFoundError"

```cmd
py -m pip install -r requirements.txt
```

### Qt/Render-Probleme (schwarzes Fenster / Crash)

Standard ist **ANGLE/D3D11**.
Du kannst testweise umstellen:

```cmd
set PYDAW_QT_OPENGL=software
py main.py
```

Oder Desktop OpenGL:

```cmd
set PYDAW_QT_OPENGL=desktop
py main.py
```

