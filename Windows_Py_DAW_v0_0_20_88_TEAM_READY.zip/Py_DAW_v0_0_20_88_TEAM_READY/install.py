"""Installer helper for ChronoScaleStudio / Py_DAW.

Windows (empfohlen):
    py -m venv .venv
    .venv\Scripts\activate
    py install.py
    py main.py

PowerShell Aktivierung:
    .\.venv\Scripts\Activate.ps1

Linux/macOS (empfohlen):
    python3 -m venv .venv
    source .venv/bin/activate
    python3 install.py
    python3 main.py

Dieses Script installiert NUR Python-Pakete (requirements.txt).
System-Komponenten wie Audio-Treiber, ASIO, FluidSynth-Binary usw. musst du
separat installieren (Windows Anleitung siehe WINDOWS_INSTALLATION.md).
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def _in_venv() -> bool:
    return (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))


def _is_windows() -> bool:
    try:
        return platform.system().lower() == "windows"
    except Exception:
        return os.name == "nt"


def _hint_venv() -> None:
    if _is_windows():
        print("\nEmpfehlung (Windows):")
        print("  py -m venv .venv")
        print("  .venv\\Scripts\\activate")
        print("  py install.py")
    else:
        print("\nEmpfehlung (Linux/macOS):")
        print("  python3 -m venv .venv")
        print("  source .venv/bin/activate")
        print("  python3 install.py")


def _check_fluidsynth() -> None:
    """Best-effort hint for MIDI->WAV rendering."""
    fs_env = os.environ.get("FLUIDSYNTH_PATH")
    fs_path = None
    if fs_env and Path(fs_env).exists():
        fs_path = fs_env
    else:
        fs_path = shutil.which("fluidsynth") or shutil.which("fluidsynth.exe")

    if not fs_path:
        print("\nHINWEIS: FluidSynth CLI wurde nicht gefunden.")
        print("  Für SF2/MIDI-Rendering bitte FluidSynth installieren und FLUIDSYNTH_PATH setzen.")
        print("  Siehe: WINDOWS_INSTALLATION.md")
    else:
        print(f"\nOK: FluidSynth gefunden: {fs_path}")


def main() -> int:
    here = Path(__file__).resolve().parent
    req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    if not _in_venv():
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        _hint_venv()

    py = sys.executable

    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    _run([py, "-m", "pip", "install", "-r", str(req)])

    print("\nOK. Starte danach mit:")
    print(f"  {py} main.py")

    if _is_windows():
        print("\nWindows Audio Defaults:")
        print("  - sounddevice HostAPI: WASAPI (env: PYDAW_SD_HOSTAPI=wasapi)")
        print("  - Optional Exclusive Mode: set PYDAW_WASAPI_EXCLUSIVE=1")
        _check_fluidsynth()
    else:
        print("\nOptional: Für Linux kann PipeWire-JACK/JACK/qpwgraph genutzt werden (Systempakete).")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
