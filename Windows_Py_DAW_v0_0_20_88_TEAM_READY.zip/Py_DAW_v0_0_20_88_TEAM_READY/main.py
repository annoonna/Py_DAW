"""Entry point for Py DAW."""

import faulthandler
import os
import platform
import signal

faulthandler.enable(all_threads=True)
try:
    faulthandler.register(signal.SIGABRT, all_threads=True)
except Exception:
    pass

# --- Windows early init (MUST run BEFORE importing PyQt6)
# Safer defaults:
#   - Qt rendering via ANGLE/D3D11 (reduces OpenGL driver issues)
#   - sounddevice host API default: WASAPI
try:
    if platform.system().lower() == "windows":
        from pydaw.platform.windows_qt_init import configure_windows_qt

        configure_windows_qt()
        os.environ.setdefault("PYDAW_SD_HOSTAPI", "wasapi")
except Exception:
    # Never block startup.
    pass

# --- Graphics backend selection (must happen BEFORE importing PyQt6)
# Linux default: Vulkan (when available). Windows default: D3D11 (via RHI).
# Override via:
#   PYDAW_GFX_BACKEND=opengl python main.py
try:
    from pydaw.utils.gfx_backend import configure_graphics_backend

    configure_graphics_backend()
except Exception:
    # Never block startup.
    pass

from pydaw.app import run

if __name__ == "__main__":
    run()
