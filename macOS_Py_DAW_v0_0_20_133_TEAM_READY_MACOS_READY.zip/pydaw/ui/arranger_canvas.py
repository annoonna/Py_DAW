"""Arranger canvas (v0.0.20.98)

Additions in v0.0.20.98:
- FIXED: Ruler zoom now works Bitwig/Ableton-style across the FULL ruler height
- Magnifier cursor appears when hovering anywhere in the ruler (not just top 14px)
- Loop handles are prioritized: clicking near start/end loop markers edits the loop
- Double-click anywhere in ruler resets zoom
- Resize cursor shown near loop handles for discoverability
- QScrollArea viewport mouse tracking enabled for reliable hover events

Additions in v0.0.20.79:
- Ghost-clip overlay during cross-project drag (semi-transparent preview at cursor)
- Visual feedback for external file drops (audio/midi ghost preview)

Additions in v0.0.20.15:
- Optional GPU-accelerated waveform overlay via WaveformGLRenderer (QOpenGLWidget)
- Automatic fallback to QPainter software rendering if OpenGL unavailable
- GL overlay syncs viewport + playhead with main canvas

Previous additions (v0.0.19.2.0+):
- Default mouse-wheel zoom (like many DAWs); Shift+Wheel = track-height zoom; Alt+Wheel passthrough
- Zoom +/- actions in context menu (and API hooks used by ArrangerView buttons)
- Clip handles on BOTH sides (right: resize/extend, left: trim/extend with content offset)
- Audio waveform preview (threaded peak-cache) + MIDI mini-preview
- Track volume influences waveform height (dB curve mapping) + shown as dB text
- Right-click menu includes Snap toggle + Grid division (1/1..1/64)
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
import math
import os
from pathlib import Path

from PyQt6.QtWidgets import QWidget, QMenu, QApplication
from PyQt6.QtGui import QPainter, QPen, QBrush, QDrag, QColor, QKeyEvent, QPixmap
from PyQt6.QtCore import Qt, QRectF, pyqtSignal, QPointF, QMimeData, QRect

from pydaw.services.project_service import ProjectService
from pydaw.services.transport_service import TransportService
from pydaw.ui.arranger_keyboard import ArrangerKeyboardHandler
from pydaw.ui.cross_project_drag import MIME_CROSS_PROJECT, parse_cross_project_drop
from pydaw.ui.widgets.ruler_zoom_handle import paint_magnifier, make_magnifier_cursor



log = logging.getLogger(__name__)

try:
    import numpy as np  # type: ignore
except Exception:  # pragma: no cover
    np = None  # type: ignore

try:
    import soundfile as sf  # type: ignore
except Exception:  # pragma: no cover
    sf = None  # type: ignore


@dataclass
class _DragMove:
    clip_id: str
    dx_beats: float


@dataclass
class _DragMoveMulti:
    """Move multiple selected clips as a group (Arranger lasso + drag).

    We anchor snapping on the primary dragged clip and keep all other selected
    clips at their relative offsets.
    """

    anchor_clip_id: str
    dx_beats: float
    # clip_id -> (origin_start_beats, origin_track_idx)
    origins: dict
    anchor_track_idx: int


@dataclass
class _DragResizeRight:
    clip_id: str
    origin_len: float
    origin_x: float


@dataclass
class _DragResizeLeft:
    clip_id: str
    origin_start: float
    origin_len: float
    origin_x: float
    origin_offset_beats: float
    origin_offset_seconds: float


@dataclass
class _DragLoop:
    mode: str  # "new" | "start" | "end"
    origin_beat: float


@dataclass
class _DragNewClip:
    """Drag-create a new MIDI clip in empty arranger space."""

    track_id: str
    start_beat: float
    cur_beat: float


@dataclass
class _DragLasso:
    """Lasso selection - drag rectangle to select multiple clips."""
    
    start_x: float
    start_y: float
    current_x: float
    current_y: float
    initial_selection: set  # Clips selected before lasso started (for Shift+Lasso)


@dataclass
class _PeaksData:
    mtime_ns: int
    block_size: int
    samplerate: int
    peaks: "np.ndarray"  # type: ignore

    @property
    def peaks_per_second(self) -> float:
        return float(self.samplerate) / float(max(1, self.block_size))


class ArrangerCanvas(QWidget):
    zoom_changed = pyqtSignal(float)  # pixels_per_beat
    clip_activated = pyqtSignal(str)
    clip_selected = pyqtSignal(str)
    request_rename_clip = pyqtSignal(str)
    request_duplicate_clip = pyqtSignal(str)
    request_delete_clip = pyqtSignal(str)
    request_import_audio = pyqtSignal(str, float)  # track_id, start_beats
    request_add_track = pyqtSignal(str)  # FIXED v0.0.19.7.19: track_kind ("audio", "instrument", "bus")
    status_message = pyqtSignal(str, int)  # (message, timeout_ms) - v0.0.19.7.0

    loop_region_committed = pyqtSignal(bool, float, float)

    def __init__(self, project: ProjectService, parent=None):
        super().__init__(parent)
        self.project = project
        self.transport: TransportService | None = None
        self._tab_service = None  # v0.0.20.78: set via set_tab_service()

        # v0.0.20.79: Ghost-clip overlay during cross-project / external drag
        self._drag_ghost_pos: QPointF | None = None  # cursor pos during drag-over
        self._drag_ghost_label: str = ""  # label for ghost-clip preview
        self._drag_ghost_kind: str = ""  # "cross-project" | "audio" | "midi" | ""

        self.setAcceptDrops(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        # Needed so hover can update the cursor for discoverable ruler controls.
        self.setMouseTracking(True)

        self.pixels_per_beat = 80.0
        self.track_height = 70
        self.ruler_height = 28

        # Ruler zoom handle (magnifier icon) — Ableton/Bitwig-style discoverable zoom control.
        # Drag the magnifier up/down to zoom time horizontally. Double-click resets.
        self._default_pixels_per_beat = float(self.pixels_per_beat)
        # Slightly larger hitbox so it's easy to hit (and visible on HiDPI).
        self._zoom_handle_rect = QRect(8, 1, 14, 14)  # in widget coords (ruler zoom band)
        self._zoom_drag_active = False
        self._zoom_drag_origin_y = 0.0
        self._zoom_drag_origin_ppb = float(self.pixels_per_beat)

        # Lazily created custom cursor (magnifier) for ruler zoom handle.
        self._magnifier_cursor = None
        self._hover_zoom_handle = False
        # v0.0.20.98: Track override cursor state to avoid stacking
        self._cursor_override_active: str = ""  # "" | "magnifier" | "loop_handle"

        # Ruler layout (Bitwig-style, top-to-bottom):
        #   [0 .. _ruler_zoom_band_h)   = Zoom zone (magnifier cursor, drag = zoom)
        #   [_ruler_zoom_band_h .. ruler_height] = Loop/playhead zone (drag = loop)
        # This gives a thin zoom strip at the very top edge and a larger loop area below.
        self._ruler_zoom_band_h = 10  # px — thin zoom strip at very top (Bitwig-style)
        self._zoom_handle_visible = False
        self._zoom_anchor_beat = 0.0
        self._zoom_anchor_view_x = 0.0

        self.playhead_beat = 0.0
        self.loop_enabled = False
        self.loop_start = 0.0
        self.loop_end = 16.0

        self.snap_beats = 0.25

        self.selected_clip_ids: set[str] = set()
        self.selected_clip_id: str = ""

        # Clip pixmap cache (Grafik-Turbo: pre-rendered clip visuals)
        self._clip_pixmap_cache: dict[str, QPixmap] = {}

        # Tool state (Pro-DAW-Style)
        self._active_tool: str = "select"  # select, knife, draw, erase

        self._drag_move: _DragMove | None = None
        self._drag_move_multi: _DragMoveMulti | None = None
        self._drag_resize_r: _DragResizeRight | None = None
        self._drag_resize_l: _DragResizeLeft | None = None
        self._drag_loop: _DragLoop | None = None
        self._drag_new_clip: _DragNewClip | None = None
        self._drag_lasso: _DragLasso | None = None

        self._dnd_drag_start: QPointF | None = None
        self._dnd_clip_id: str = ""

        # Ctrl+Drag horizontal copy mode (v0.0.19.7.0 - FIXED!)
        self._drag_is_copy: bool = False  # True if Ctrl was held during press
        self._drag_copy_source_clip_id: str = ""  # Original clip to copy from
        self._drag_copy_original_start: float = 0.0  # Original position before drag
        self._drag_copy_original_track: str = ""  # Original track before drag

        # Auto-loop extension
        self._pending_auto_loop_end: float | None = None
        # v0.0.20.98: Suppress context menu after right-click loop drawing
        self._suppress_next_context_menu: bool = False

        # Waveform cache
        self._peaks_cache: dict[str, _PeaksData] = {}
        self._peaks_pending: set[str] = set()

        # Keyboard Handler for standard DAW shortcuts (v0.0.19.7.0)
        self.keyboard_handler = ArrangerKeyboardHandler(self.project)
        self.keyboard_handler.status_message.connect(self._on_keyboard_status)
        self.keyboard_handler.request_update.connect(self.update)

        self.project.project_updated.connect(self._on_project_updated)
        self._update_minimum_size()

        # v0.0.20.18: GPU waveform overlay is OFF by default.
        #
        # Why: QOpenGLWidget is composited above its parent. On some drivers/compositors
        # it can cover the arranger grid if it paints an opaque background.
        #
        # The preferred way is via View → "GPU Waveforms" (persisted). For debugging
        # you can still force enable via env:
        #   PYDAW_GPU_WAVEFORMS=1 python3 main.py
        self._gl_overlay = None
        self._gl_enabled = False
        self._gpu_force_env = str(os.environ.get("PYDAW_GPU_WAVEFORMS", "0")).strip().lower() in ("1", "true", "yes", "on")
        if self._gpu_force_env:
            self.set_gpu_waveforms_enabled(True)

    def _get_magnifier_cursor(self):
        """Return (and cache) a magnifier cursor for ruler zoom controls.
        
        v0.0.20.98: First tries custom pixmap cursor. If that fails or looks
        invisible (common on Wayland/GNOME), falls back to CrossCursor.
        """
        try:
            if self._magnifier_cursor is None:
                # Try custom pixmap first
                col = self.palette().text().color()
                custom = make_magnifier_cursor(col)
                # Verify it's not just a fallback arrow
                if custom.shape() == Qt.CursorShape.ArrowCursor:
                    # Fallback failed, use standard cross cursor
                    self._magnifier_cursor = Qt.CursorShape.CrossCursor
                else:
                    self._magnifier_cursor = custom
            return self._magnifier_cursor
        except Exception:
            return Qt.CursorShape.CrossCursor

    def _set_override_cursor(self, kind: str) -> None:
        """Set application-level override cursor (works through QScrollArea + Wayland).
        
        Uses QApplication.setOverrideCursor which bypasses all widget-level cursor
        issues (QScrollArea eating setCursor, Wayland ignoring pixmap cursors, etc.).
        """
        try:
            if self._cursor_override_active == kind:
                return  # Already set, avoid stacking
            # Restore previous override if any
            if self._cursor_override_active:
                QApplication.restoreOverrideCursor()
                self._cursor_override_active = ""
            
            if kind == "magnifier":
                # Try XCursor "zoom-in" (real magnifier icon on most Linux desktops)
                cursor = self._get_zoom_cursor()
                QApplication.setOverrideCursor(cursor)
            elif kind == "loop_handle":
                QApplication.setOverrideCursor(Qt.CursorShape.SizeHorCursor)
            elif kind == "copy":
                QApplication.setOverrideCursor(Qt.CursorShape.DragCopyCursor)
            else:
                return
            self._cursor_override_active = kind
        except Exception:
            log.debug("_set_override_cursor failed for %s", kind, exc_info=True)

    def _get_zoom_cursor(self) -> QCursor:
        """Get a zoom/magnifier cursor. Tries multiple strategies:
        1. XCursor 'zoom-in' (real magnifier on GNOME/KDE)
        2. Custom painted magnifier pixmap (high contrast)
        3. CrossCursor fallback
        """
        if not hasattr(self, '_cached_zoom_cursor'):
            self._cached_zoom_cursor = None
            # Strategy 1: XCursor name (works on X11 and most Wayland compositors)
            try:
                from PyQt6.QtGui import QCursor
                test = QCursor(Qt.CursorShape.CrossCursor)
                # QCursor doesn't have a string-name constructor in PyQt6,
                # but we can try via the xcb cursor name through QPixmap workaround.
                # Actually, the best approach for Linux: build a visible magnifier pixmap.
                pass
            except Exception:
                pass
            
            # Strategy 2: Compact magnifier pixmap (24x24, crisp)
            try:
                size = 24
                pm = QPixmap(size, size)
                pm.fill(Qt.GlobalColor.transparent)
                p = QPainter(pm)
                p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                
                # Glass circle
                glass_cx, glass_cy, glass_r = 9, 9, 6
                
                # Black outline (shadow)
                pen_bg = QPen(QColor(0, 0, 0, 220))
                pen_bg.setWidthF(2.5)
                p.setPen(pen_bg)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(glass_cx - glass_r, glass_cy - glass_r, 
                              glass_r * 2, glass_r * 2)
                hx1 = glass_cx + int(glass_r * 0.7)
                hy1 = glass_cy + int(glass_r * 0.7)
                p.drawLine(hx1, hy1, size - 3, size - 3)
                
                # White foreground
                pen_fg = QPen(QColor(255, 255, 255, 255))
                pen_fg.setWidthF(1.5)
                pen_fg.setCapStyle(Qt.PenCapStyle.RoundCap)
                p.setPen(pen_fg)
                p.drawEllipse(glass_cx - glass_r, glass_cy - glass_r,
                              glass_r * 2, glass_r * 2)
                p.drawLine(hx1, hy1, size - 3, size - 3)
                
                # Small plus
                plus = 3
                p.drawLine(glass_cx - plus, glass_cy, glass_cx + plus, glass_cy)
                p.drawLine(glass_cx, glass_cy - plus, glass_cx, glass_cy + plus)
                
                p.end()
                self._cached_zoom_cursor = QCursor(pm, glass_cx, glass_cy)
            except Exception:
                pass
            
            # Strategy 3: Fallback
            if self._cached_zoom_cursor is None:
                self._cached_zoom_cursor = QCursor(Qt.CursorShape.CrossCursor)
        
        return self._cached_zoom_cursor

    def _clear_override_cursor(self) -> None:
        """Remove the application-level override cursor."""
        try:
            if self._cursor_override_active:
                QApplication.restoreOverrideCursor()
                self._cursor_override_active = ""
        except Exception:
            pass

    
    def _find_hscrollbar(self):
        """Find a parent QScrollArea horizontal scrollbar (if any)."""
        try:
            w = self.parentWidget()
            while w is not None:
                if hasattr(w, 'horizontalScrollBar'):
                    try:
                        return w.horizontalScrollBar()
                    except Exception:
                        pass
                w = w.parentWidget()
        except Exception:
            pass
        return None

    def _update_zoom_handle_rect(self, x: float) -> None:
        """Move the magnifier hitbox to follow the mouse X inside the ruler."""
        try:
            size = int(self._zoom_handle_rect.width())
        except Exception:
            size = 20
        try:
            half = size // 2
            nx = int(x) - half
            nx = max(4, min(nx, max(4, self.width() - size - 4)))
            ny = 1
            new_rect = QRect(nx, ny, size, size)
            if new_rect != self._zoom_handle_rect:
                self._zoom_handle_rect = new_rect
        except Exception:
            pass

    def _apply_ppb_anchored(self, new_ppb: float) -> None:
        """Apply pixels-per-beat change while keeping the anchor beat under the cursor stable."""
        try:
            new_ppb = float(new_ppb)
        except Exception:
            return
        new_ppb = max(20.0, min(320.0, new_ppb))

        self.pixels_per_beat = float(new_ppb)
        self._update_minimum_size()

        try:
            beat = float(getattr(self, '_zoom_anchor_beat', 0.0) or 0.0)
            view_x = float(getattr(self, '_zoom_anchor_view_x', 0.0) or 0.0)
            bar = self._find_hscrollbar()
            if bar is not None:
                new_content_x = beat * float(new_ppb)
                new_scroll = int(max(0.0, new_content_x - view_x))
                bar.setValue(new_scroll)
        except Exception:
            pass

    def set_gpu_waveforms_enabled(self, enabled: bool) -> None:
        """Enable/disable the optional GPU waveform overlay.

        This is purely a visual overlay (waveforms) and must never affect editing.
        """
        enabled = bool(enabled)
        if enabled and self._gl_overlay is not None:
            self._gl_enabled = True
            try:
                self._gl_overlay.show()
                self._gl_overlay.raise_()
            except Exception:
                pass
            self._sync_gl_overlay()
            return

        if (not enabled) and self._gl_overlay is None:
            self._gl_enabled = False
            return

        if not enabled:
            # Disable and destroy overlay widget to avoid any compositor surprises.
            try:
                self._gl_overlay.hide()
            except Exception:
                pass
            try:
                self._gl_overlay.setParent(None)
            except Exception:
                pass
            try:
                self._gl_overlay.deleteLater()
            except Exception:
                pass
            self._gl_overlay = None
            self._gl_enabled = False
            self.update()
            return

        # Enable (create overlay)
        try:
            from pydaw.ui.gpu_waveform_renderer import WaveformGLRenderer, _GL_AVAILABLE
            if not bool(_GL_AVAILABLE):
                self._gl_overlay = None
                self._gl_enabled = False
                return
            self._gl_overlay = WaveformGLRenderer(parent=self)
            self._gl_overlay.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
            try:
                self._gl_overlay.setAutoFillBackground(False)
            except Exception:
                pass
            self._gl_overlay.raise_()
            self._gl_enabled = True
            self._sync_gl_overlay()
        except Exception:
            self._gl_overlay = None
            self._gl_enabled = False

    # --- external setters

    def set_transport(self, transport: TransportService | None) -> None:
        self.transport = transport

    def set_tab_service(self, tab_service) -> None:
        """Set ProjectTabService for cross-project drag&drop (v0.0.20.78)."""
        self._tab_service = tab_service

    def set_playhead(self, beat: float) -> None:
        self.playhead_beat = max(0.0, float(beat))
        # v0.0.20.14: sync GL overlay
        if self._gl_overlay is not None:
            try:
                # Note: overlay currently operates in pixel-space (uses clip rects).
                # Convert beat -> px for correct cursor alignment.
                self._gl_overlay.set_playhead(self.playhead_beat * float(self.pixels_per_beat))
            except Exception:
                pass
        self.update()

    def set_loop_region(self, enabled: bool, start: float, end: float) -> None:
        self.loop_enabled = bool(enabled)
        self.loop_start = max(0.0, float(start))
        self.loop_end = max(self.loop_start + self.snap_beats, float(end))
        self.update()

    def set_snap_division(self, div: str) -> None:
        """Set snap/grid division and update snap_beats."""
        # Beat unit is quarter = 1.0
        div = str(div or "1/16")
        mapping = {
            "1/1": 4.0,
            "1/2": 2.0,
            "1/4": 1.0,
            "1/8": 0.5,
            "1/16": 0.25,
            "1/32": 0.125,
            "1/64": 0.0625,
        }
        self.snap_beats = float(mapping.get(div, 0.25))

    # --- zoom helpers (used by ArrangerView buttons + context menu)

    def _zoom_by_factor(self, factor: float) -> None:
        self.pixels_per_beat = max(20.0, min(320.0, float(self.pixels_per_beat) * float(factor)))
        self._update_minimum_size()
        self._sync_gl_overlay()
        self.update()
        self.zoom_changed.emit(float(self.pixels_per_beat))

    def zoom_in(self) -> None:
        self._zoom_by_factor(1.1)

    def zoom_out(self) -> None:
        self._zoom_by_factor(0.9)

    def set_tool(self, tool: str) -> None:
        """Set active tool (select, knife, draw, erase, time_select)."""
        if tool in ("select", "knife", "draw", "erase", "time_select"):
            self._active_tool = str(tool)
            self.update()
    
    def get_tool(self) -> str:
        """Get current active tool."""
        return self._active_tool

    # --- model helpers

    def _beats_per_bar(self) -> float:
        """Return beats per bar based on Project.time_signature (num/den)."""
        ts = getattr(self.project.ctx.project, "time_signature", "4/4") or "4/4"
        try:
            num_s, den_s = str(ts).split("/")
            num = float(num_s)
            den = float(den_s)
            return float(num) * (4.0 / max(1.0, den))
        except Exception:
            return 4.0

    def _tracks(self):
        return list(self.project.ctx.project.tracks)

    def _arranger_clips(self):
        """Return clips that belong to the Arranger timeline (exclude Clip-Launcher-only clips)."""
        return [c for c in self.project.ctx.project.clips if not getattr(c, 'launcher_only', False)]

    def _track_at_y(self, y: float):
        tracks = self._tracks()
        if y <= self.ruler_height:
            return None
        idx = int((y - self.ruler_height) // self.track_height)
        if idx < 0 or idx >= len(tracks):
            return None
        return tracks[idx]

    def _clip_rects(self):
        tracks = self._tracks()
        rects = []
        for clip in self._arranger_clips():
            track_idx = next((i for i, t in enumerate(tracks) if t.id == clip.track_id), None)
            if track_idx is None:
                continue
            x = float(clip.start_beats) * self.pixels_per_beat
            w = max(10.0, float(clip.length_beats) * self.pixels_per_beat)
            y = self.ruler_height + track_idx * self.track_height + 8
            h = self.track_height - 16
            rects.append((clip.id, QRectF(x, y, w, h), clip))
        return rects

    def _clip_at_pos(self, pos: QPointF) -> str:
        for cid, r, _clip in self._clip_rects():
            if r.contains(pos):
                return cid
        return ""

    def _clip_rect(self, clip_id: str):
        for cid, r, clip in self._clip_rects():
            if cid == clip_id:
                return r, clip
        return None, None

    def _hit_resize_handle_right(self, rect: QRectF, pos: QPointF) -> bool:
        handle = QRectF(rect.right() - 6, rect.top(), 12, rect.height())
        return handle.contains(pos)

    def _hit_resize_handle_left(self, rect: QRectF, pos: QPointF) -> bool:
        handle = QRectF(rect.left() - 6, rect.top(), 12, rect.height())
        return handle.contains(pos)

    def _hit_loop_handle(self, pos: QPointF) -> str:
        if pos.y() > self.ruler_height:
            return ""
        x = pos.x()
        x1 = self.loop_start * self.pixels_per_beat
        x2 = self.loop_end * self.pixels_per_beat
        if abs(x - x1) <= 6:
            return "start"
        if abs(x - x2) <= 6:
            return "end"
        return ""

    def _get_lasso_rect(self) -> QRectF:
        """Get lasso selection rectangle."""
        if self._drag_lasso is None:
            return QRectF()
        
        x1 = min(self._drag_lasso.start_x, self._drag_lasso.current_x)
        x2 = max(self._drag_lasso.start_x, self._drag_lasso.current_x)
        y1 = min(self._drag_lasso.start_y, self._drag_lasso.current_y)
        y2 = max(self._drag_lasso.start_y, self._drag_lasso.current_y)
        
        return QRectF(x1, y1, x2 - x1, y2 - y1)

    def _x_to_beats(self, x: float) -> float:
        return max(0.0, float(x) / float(self.pixels_per_beat))

    def _snap(self, beat: float) -> float:
        g = float(self.snap_beats)
        if g <= 0.0:
            return max(0.0, float(beat))
        return max(0.0, round(float(beat) / g) * g)

    def _beats_to_seconds(self, beats: float) -> float:
        bpm = float(getattr(self.project.ctx.project, "bpm", 120.0) or 120.0)
        return (float(beats) * 60.0) / max(1e-6, bpm)

    # --- auto-loop extension

    def _mark_auto_loop_end_for_clip(self, clip_id: str) -> None:
        """Auto-loop extension disabled - loop region stays fixed."""
        # User feedback: "Loop verschwindet beim Clip erstellen - nervt!"
        # Solution: Loop region is now completely manual, no auto-extension
        pass

    def _commit_auto_loop_end(self) -> None:
        """Auto-loop extension disabled - loop stays manual."""
        # No longer automatically extending loop region
        pass

    def _disable_loop(self) -> None:
        self.loop_enabled = False
        self.loop_region_committed.emit(False, float(self.loop_start), float(self.loop_end))
        if self.transport is not None:
            try:
                self.transport.set_loop(False, float(self.loop_start), float(self.loop_end))
            except Exception:
                pass
        self.update()

    # --- waveform cache

    def _volume_to_db(self, vol: float) -> float:
        """Visual-only mapping: fader position -> dB."""
        v = float(vol)
        if v <= 0.0:
            return -120.0
        if v <= 1.0:
            return -60.0 + (60.0 * v)
        v = min(v, 2.0)
        return 6.0 * (v - 1.0)

    def _db_to_gain(self, db: float) -> float:
        if db <= -120.0:
            return 0.0
        return float(10.0 ** (float(db) / 20.0))

    def _display_gain_for_volume(self, vol: float) -> tuple[float, float]:
        db = self._volume_to_db(float(vol))
        return (self._db_to_gain(db), db)

    def _get_peaks_for_path(self, path_str: str) -> _PeaksData | None:
        if sf is None or np is None:
            return None
        if not path_str:
            return None
        try:
            p = os.path.abspath(path_str)
            st = os.stat(p)
            mtime = int(st.st_mtime_ns)
        except Exception:
            return None

        cached = self._peaks_cache.get(p)
        if cached and int(cached.mtime_ns) == mtime:
            return cached

        if p not in self._peaks_pending:
            self._peaks_pending.add(p)
            self._submit_peaks_compute(p, mtime)
        return None

    def _submit_peaks_compute(self, abs_path: str, mtime_ns: int) -> None:
        def fn():
            return self._compute_peaks(abs_path)

        def ok(res):
            try:
                if res is None:
                    return
                peaks_arr, sr, bs = res
                self._peaks_cache[str(abs_path)] = _PeaksData(
                    mtime_ns=int(mtime_ns),
                    block_size=int(bs),
                    samplerate=int(sr),
                    peaks=peaks_arr,
                )
            finally:
                self._peaks_pending.discard(str(abs_path))
                self.update()

        def err(_msg: str):
            self._peaks_pending.discard(str(abs_path))

        try:
            self.project._submit(fn, ok, err)  # type: ignore[attr-defined]
        except Exception:
            try:
                res = self._compute_peaks(abs_path)
                if res is not None:
                    peaks_arr, sr, bs = res
                    self._peaks_cache[str(abs_path)] = _PeaksData(
                        mtime_ns=int(mtime_ns),
                        block_size=int(bs),
                        samplerate=int(sr),
                        peaks=peaks_arr,
                    )
            finally:
                self._peaks_pending.discard(str(abs_path))
                self.update()

    def _compute_peaks(self, abs_path: str):
        if sf is None or np is None:
            return None
        try:
            f = sf.SoundFile(abs_path)
        except Exception:
            return None

        block_size = 2048
        sr = int(getattr(f, "samplerate", 48000) or 48000)
        peaks_list = []
        try:
            for block in f.blocks(blocksize=block_size, dtype="float32", always_2d=True):
                if block is None or block.shape[0] == 0:
                    continue
                a = np.max(np.abs(block), axis=1)
                peaks_list.append(float(np.max(a)))
        except Exception:
            try:
                data = f.read(dtype="float32", always_2d=True)
                if data is None or data.shape[0] == 0:
                    return None
                a = np.max(np.abs(data), axis=1)
                n = int(a.shape[0])
                n_chunks = (n + block_size - 1) // block_size
                for i in range(n_chunks):
                    s = i * block_size
                    e = min(n, (i + 1) * block_size)
                    peaks_list.append(float(np.max(a[s:e])))
            except Exception:
                return None
        finally:
            try:
                f.close()
            except Exception:
                pass

        if not peaks_list:
            return None
        arr = np.asarray(peaks_list, dtype="float32")
        arr = np.clip(arr, 0.0, 1.0)
        return arr, sr, block_size

    # --- drawing helpers

    def _draw_handle_strips(self, p: QPainter, rect: QRectF, is_sel: bool) -> None:
        w = 6.0
        col = self.palette().highlight().color() if is_sel else self.palette().dark().color()
        p.fillRect(QRectF(rect.left(), rect.top(), w, rect.height()), QBrush(col))
        p.fillRect(QRectF(rect.right() - w, rect.top(), w, rect.height()), QBrush(col))

    def _draw_audio_waveform(self, p: QPainter, rect: QRectF, clip, track_volume: float) -> None:
        peaks = self._get_peaks_for_path(str(getattr(clip, "source_path", "") or ""))
        if peaks is None or np is None:
            p.setPen(QPen(self.palette().mid().color()))
            p.drawText(rect.adjusted(6, 2, -6, -2), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, "Waveform…")
            return

        beats_to_sec = self._beats_to_seconds(1.0)
        offset_sec = float(getattr(clip, "offset_seconds", 0.0) or 0.0)
        length_sec = float(getattr(clip, "length_beats", 0.0) or 0.0) * beats_to_sec
        if length_sec <= 0.0:
            return

        start_i = int(max(0.0, offset_sec * peaks.peaks_per_second))
        end_i = int(max(start_i + 1, (offset_sec + length_sec) * peaks.peaks_per_second))
        seg = peaks.peaks[start_i:min(end_i, len(peaks.peaks))]
        if seg.size == 0:
            return

        n = max(8, int(rect.width()))
        if seg.size != n:
            x_old = np.linspace(0.0, 1.0, num=int(seg.size), dtype=np.float32)
            x_new = np.linspace(0.0, 1.0, num=int(n), dtype=np.float32)
            seg = np.interp(x_new, x_old, seg).astype(np.float32)

        gain, _db = self._display_gain_for_volume(track_volume)
        seg = np.clip(seg * float(gain), 0.0, 1.0)

        mid_y = rect.center().y()
        amp_h = rect.height() * 0.45

        p.setPen(QPen(self.palette().text().color()))
        x0 = int(rect.left())
        top = rect.top()
        bottom = rect.bottom()
        for i, a in enumerate(seg):
            if float(a) <= 0.0005:
                continue
            x = x0 + i
            dy = float(a) * amp_h
            y1 = max(top, mid_y - dy)
            y2 = min(bottom, mid_y + dy)
            p.drawLine(int(x), int(y1), int(x), int(y2))

    def _draw_midi_preview(self, p: QPainter, rect: QRectF, clip) -> None:
        notes = []
        try:
            notes = list(self.project.ctx.project.midi_notes.get(clip.id, []))
        except Exception:
            notes = []
        if not notes:
            p.setPen(QPen(self.palette().mid().color()))
            p.drawText(rect.adjusted(6, 2, -6, -2), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, "MIDI…")
            return

        off_beats = float(getattr(clip, "offset_beats", 0.0) or 0.0)
        clip_len = max(1e-6, float(getattr(clip, "length_beats", 1.0) or 1.0))

        vis = []
        for n in notes:
            st = float(getattr(n, "start_beats", 0.0) or 0.0) - off_beats
            en = st + float(getattr(n, "length_beats", 0.0) or 0.0)
            if en < 0.0 or st > clip_len:
                continue
            vis.append(n)
        if not vis:
            p.setPen(QPen(self.palette().mid().color()))
            p.drawText(rect.adjusted(6, 2, -6, -2), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, "MIDI…")
            return

        pitches = [int(getattr(n, "pitch", 60) or 60) for n in vis]
        pmin = min(pitches)
        pmax = max(pitches)
        if pmax <= pmin:
            pmax = pmin + 1

        def y_for_pitch(pitch: int) -> float:
            t = (pitch - pmin) / float(pmax - pmin)
            return rect.bottom() - (t * rect.height())

        # Draw MIDI preview bars with VISIBLE borders but SUBTLE fill
        # User wants: "100% MIDI bausteine sehen" with "3% füllfarbe"
        border_color = self.palette().highlight().color()
        border_color.setAlpha(180)  # Visible border (70%)
        p.setPen(QPen(border_color, 1))  # 1px border
        
        # Fill color: VERY subtle (3% as requested)
        fill_color = self.palette().highlight().color()
        fill_color.setAlpha(8)  # 3% fill
        p.setBrush(QBrush(fill_color))
        
        for n in vis:
            st = float(getattr(n, "start_beats", 0.0) or 0.0) - off_beats
            ln = float(getattr(n, "length_beats", 0.0) or 0.0)
            pitch = int(getattr(n, "pitch", 60) or 60)
            x1 = rect.left() + (st / clip_len) * rect.width()
            x2 = rect.left() + ((st + ln) / clip_len) * rect.width()
            y = y_for_pitch(pitch)
            h = max(3.0, rect.height() / 12.0)
            r = QRectF(x1, y - h, max(2.0, x2 - x1), h)
            p.drawRect(r)  # Draw with border + fill

    # --- Drag&Drop (Arranger target + source)

    def _start_clip_drag(self, clip_id: str) -> None:
        drag = QDrag(self)
        md = QMimeData()
        md.setData("application/x-pydaw-clipid", clip_id.encode("utf-8"))
        drag.setMimeData(md)
        drag.exec(Qt.DropAction.CopyAction)

    def dragEnterEvent(self, event):  # noqa: ANN001
        # IMPORTANT: Never let exceptions escape from Qt virtual overrides.
        # PyQt6 + SIP can turn this into a Qt fatal (SIGABRT).
        try:
            md = event.mimeData()
            if md and md.hasFormat("application/x-pydaw-clipid"):
                event.acceptProposedAction()
                self._drag_ghost_kind = ""  # internal drag — no ghost needed
                return
            if md and md.hasFormat(MIME_CROSS_PROJECT):
                event.acceptProposedAction()
                # v0.0.20.79: set ghost metadata from cross-project payload
                self._drag_ghost_kind = "cross-project"
                try:
                    payload = parse_cross_project_drop(md)
                    if payload:
                        itype = payload.get("item_type", "")
                        ids = payload.get("track_ids", []) or payload.get("clip_ids", [])
                        count = len(ids) if ids else 1
                        self._drag_ghost_label = f"↗ {count} {itype.title()}"
                    else:
                        self._drag_ghost_label = "↗ Cross-Project"
                except Exception:
                    self._drag_ghost_label = "↗ Cross-Project"
                self._drag_ghost_pos = QPointF(event.position())
                self.update()
                return
            if md and md.hasUrls():
                event.acceptProposedAction()
                # v0.0.20.79: ghost for audio/midi file drops
                try:
                    pth = md.urls()[0].toLocalFile() if md.urls() else ""
                    ext = Path(pth).suffix.lower() if pth else ""
                    if ext in (".mid", ".midi"):
                        self._drag_ghost_kind = "midi"
                        self._drag_ghost_label = f"🎵 {Path(pth).name}"
                    else:
                        self._drag_ghost_kind = "audio"
                        self._drag_ghost_label = f"🔊 {Path(pth).name}"
                except Exception:
                    self._drag_ghost_kind = "audio"
                    self._drag_ghost_label = "🔊 Audio"
                self._drag_ghost_pos = QPointF(event.position())
                self.update()
                return
        except Exception:
            log.exception("ArrangerCanvas.dragEnterEvent failed")
        try:
            super().dragEnterEvent(event)
        except Exception:
            pass

    def dragMoveEvent(self, event):  # noqa: ANN001
        """Accept drag-move for all supported MIME types (v0.0.20.78).
        
        v0.0.20.79: Also tracks cursor position for ghost-clip overlay.
        """
        try:
            md = event.mimeData()
            if md and (md.hasFormat("application/x-pydaw-clipid")
                       or md.hasFormat(MIME_CROSS_PROJECT)
                       or md.hasUrls()):
                event.acceptProposedAction()
                # v0.0.20.79: update ghost position
                if self._drag_ghost_kind:
                    self._drag_ghost_pos = QPointF(event.position())
                    self.update()
                return
        except Exception:
            log.exception("ArrangerCanvas.dragMoveEvent failed")
        try:
            super().dragMoveEvent(event)
        except Exception:
            pass

    def dragLeaveEvent(self, event):  # noqa: ANN001
        """v0.0.20.79: Clear ghost-clip overlay when drag leaves canvas."""
        try:
            self._drag_ghost_pos = None
            self._drag_ghost_kind = ""
            self._drag_ghost_label = ""
            self.update()
        except Exception:
            pass
        try:
            super().dragLeaveEvent(event)
        except Exception:
            pass

    def dropEvent(self, event):  # noqa: ANN001
        # IMPORTANT: Never let exceptions escape from Qt virtual overrides.
        # PyQt6 + SIP can turn this into a Qt fatal (SIGABRT).
        # v0.0.20.79: clear ghost overlay on drop
        self._drag_ghost_pos = None
        self._drag_ghost_kind = ""
        self._drag_ghost_label = ""
        try:
            md = event.mimeData()
            if not md:
                try:
                    event.ignore()
                except Exception:
                    pass
                return

            # external files (audio/midi)
            if md.hasUrls() and not md.hasFormat("application/x-pydaw-clipid"):
                urls = md.urls()
                if not urls:
                    return
                pth = urls[0].toLocalFile()
                if not pth:
                    return
                path = Path(pth)
                pos = event.position()
                trk = self._track_at_y(pos.y())
                if not trk:
                    return
                beat = self._snap(self._x_to_beats(pos.x()))
                ext = path.suffix.lower()
                if ext in (".mid", ".midi"):
                    self.project.import_midi_to_track_at(trk.id, path, start_beats=beat)
                else:
                    source_bpm_override = None
                    try:
                        if md.hasFormat("application/x-pydaw-audio-bpm"):
                            raw = bytes(md.data("application/x-pydaw-audio-bpm")).decode("utf-8")
                            source_bpm_override = float(raw.strip())
                    except Exception:
                        source_bpm_override = None
                    self.project.add_audio_clip_from_file_at(
                        trk.id,
                        path,
                        start_beats=beat,
                        source_bpm_override=source_bpm_override,
                    )
                event.acceptProposedAction()
                return

            # Cross-project drag&drop: tracks/clips from another tab (v0.0.20.78)
            if md.hasFormat(MIME_CROSS_PROJECT):
                payload = parse_cross_project_drop(md)
                if payload and self._tab_service:
                    try:
                        src_idx = payload.get("source_tab_index", -1)
                        item_type = payload.get("item_type", "")
                        pos = event.position()
                        trk = self._track_at_y(pos.y())
                        target_idx = self._tab_service.active_index

                        if item_type == "tracks" and src_idx != target_idx:
                            track_ids = payload.get("track_ids", [])
                            if track_ids:
                                self._tab_service.copy_tracks_between_tabs(
                                    src_idx, target_idx, track_ids,
                                    include_clips=payload.get("include_clips", True),
                                    include_device_chains=payload.get("include_device_chains", True),
                                )
                                # v0.0.20.86: emit project_updated so TrackList/Mixer/etc. refresh
                                try:
                                    self.project.project_updated.emit()
                                except Exception:
                                    pass
                                self.update()
                                log.info("Cross-project: copied %d track(s) from tab %d → %d",
                                         len(track_ids), src_idx, target_idx)

                        elif item_type == "clips" and src_idx != target_idx:
                            clip_ids = payload.get("clip_ids", [])
                            if clip_ids and trk:
                                self._tab_service.copy_clips_between_tabs(
                                    src_idx, target_idx, clip_ids,
                                    target_track_id=trk.id,
                                )
                                # v0.0.20.86: emit project_updated
                                try:
                                    self.project.project_updated.emit()
                                except Exception:
                                    pass
                                self.update()
                                log.info("Cross-project: copied %d clip(s) from tab %d → %d",
                                         len(clip_ids), src_idx, target_idx)
                    except Exception:
                        log.exception("Cross-project drop failed")
                event.acceptProposedAction()
                return

            # internal clip drag (copy)
            if not md.hasFormat("application/x-pydaw-clipid"):
                return
            clip_id = bytes(md.data("application/x-pydaw-clipid")).decode("utf-8")
            src = next((c for c in self._arranger_clips() if c.id == clip_id), None)
            if not src:
                return

            pos = event.position()
            trk = self._track_at_y(pos.y())
            if not trk:
                return

            beat = self._snap(self._x_to_beats(pos.x()))
            self.project.duplicate_clip(clip_id)
            dup_id = self.project.ctx.project.clips[-1].id
            self.project.move_clip(dup_id, beat, snap_beats=self.snap_beats)
            self.project.move_clip_track(dup_id, trk.id)
            self.selected_clip_ids = {dup_id}
            self.selected_clip_id = dup_id
            self.clip_selected.emit(dup_id)
            self._mark_auto_loop_end_for_clip(dup_id)
            self.update()
            event.acceptProposedAction()
        except Exception:
            log.exception("ArrangerCanvas.dropEvent failed")
            try:
                event.ignore()
            except Exception:
                pass

    # --- interactions

    def contextMenuEvent(self, event):  # noqa: ANN001
        # v0.0.20.98: Suppress after right-click loop drawing or lasso
        if self._suppress_next_context_menu:
            self._suppress_next_context_menu = False
            event.accept()
            return
        pos = QPointF(event.pos())

        def add_grid_menu(menu: QMenu) -> None:
            menu.addSeparator()
            a_snap = menu.addAction("Snap")
            a_snap.setCheckable(True)
            a_snap.setChecked(bool(self.snap_beats and self.snap_beats > 0))

            sub = menu.addMenu("Grid")
            current = str(getattr(self.project.ctx.project, "snap_division", "1/16") or "1/16")
            for d in ["1/1", "1/2", "1/4", "1/8", "1/16", "1/32", "1/64"]:
                a = sub.addAction(d)
                a.setCheckable(True)
                a.setChecked(d == current)

            menu.addSeparator()
            a_zi = menu.addAction("Zoom +")
            a_zo = menu.addAction("Zoom -")

            return a_snap, sub, a_zi, a_zo

        # Ruler
        if pos.y() <= self.ruler_height:
            menu = QMenu(self)
            a_off = menu.addAction("Loop Off")
            a_off.setShortcut("Ctrl+L")
            a_snap, sub, a_zi, a_zo = add_grid_menu(menu)
            act = menu.exec(event.globalPos())
            if act == a_off:
                self._disable_loop()
                return
            if act == a_snap:
                if self.snap_beats and self.snap_beats > 0:
                    self.snap_beats = 0.0
                else:
                    self.set_snap_division(str(getattr(self.project.ctx.project, "snap_division", "1/16") or "1/16"))
                self.update()
                return
            if act in sub.actions():
                div = act.text()
                try:
                    self.project.set_snap_division(div)
                except Exception:
                    setattr(self.project.ctx.project, "snap_division", div)
                self.set_snap_division(div)
                self.update()
                return
            if act == a_zi:
                self.zoom_in()
                return
            if act == a_zo:
                self.zoom_out()
                return
            return

        # Clip
        cid = self._clip_at_pos(pos)
        if cid:
            self.selected_clip_ids = {cid}
            self.selected_clip_id = cid
            self.clip_selected.emit(cid)
            self.update()

            menu = QMenu(self)
            a_rename = menu.addAction("Umbenennen…")
            a_dup = menu.addAction("Duplizieren")
            
            # FIXED v0.0.19.7.15: Export MIDI (nur für MIDI Clips)
            a_export_midi = None
            clip = next((c for c in self._arranger_clips() if c.id == cid), None)
            if clip and getattr(clip, "kind", "") == "midi":
                menu.addSeparator()
                a_export_midi = menu.addAction("Export as MIDI...")
            
            # Split Clip (nur ein Clip selektiert)
            a_split = None
            if len(self.selected_clip_ids) == 1:
                menu.addSeparator()
                a_split = menu.addAction("Clip teilen (an Cursor)")
                a_split.setShortcut("K")
            
            # Join Clips (nur wenn mehrere selektiert)
            a_join = None
            if len(self.selected_clip_ids) >= 2:
                menu.addSeparator()
                a_join = menu.addAction(f"Clips vereinen ({len(self.selected_clip_ids)} Clips)")
                a_join.setShortcut("Ctrl+J")
            
            menu.addSeparator()
            a_del = menu.addAction("Löschen")
            a_snap, sub, a_zi, a_zo = add_grid_menu(menu)
            act = menu.exec(event.globalPos())

            if act == a_rename:
                self.request_rename_clip.emit(cid)
                return
            if act == a_dup:
                self.request_duplicate_clip.emit(cid)
                return
            if a_export_midi and act == a_export_midi:
                # FIXED v0.0.19.7.15: Export MIDI Clip
                self._export_midi_clip(cid)
                return
            if a_split and act == a_split:
                # Split clip at mouse cursor position
                try:
                    beat = self._snap(self._x_to_beats(pos.x()))
                    result = self.project.split_clip(cid, float(beat))
                    if result:
                        left_id, right_id = result
                        self.selected_clip_ids = {right_id}
                        self.selected_clip_id = right_id
                        self.clip_selected.emit(right_id)
                        self.update()
                except Exception:
                    pass
                return
            if a_join and act == a_join:
                # Join selected clips
                try:
                    clip_ids = list(self.selected_clip_ids)
                    new_id = self.project.join_clips(clip_ids)
                    if new_id:
                        self.selected_clip_ids = {new_id}
                        self.selected_clip_id = new_id
                        self.clip_selected.emit(new_id)
                        self.update()
                except Exception:
                    pass
                return
            if act == a_del:
                self.request_delete_clip.emit(cid)
                return
            if act == a_snap:
                if self.snap_beats and self.snap_beats > 0:
                    self.snap_beats = 0.0
                else:
                    self.set_snap_division(str(getattr(self.project.ctx.project, "snap_division", "1/16") or "1/16"))
                self.update()
                return
            if act in sub.actions():
                div = act.text()
                try:
                    self.project.set_snap_division(div)
                except Exception:
                    setattr(self.project.ctx.project, "snap_division", div)
                self.set_snap_division(div)
                self.update()
                return
            if act == a_zi:
                self.zoom_in()
                return
            if act == a_zo:
                self.zoom_out()
                return
            return

        # Empty area: Grid/Zoom + Add Tracks (v0.0.19.7.19)
        menu = QMenu(self)
        
        # FIXED v0.0.19.7.19: Add Track Options im Context Menu! ✅
        a_add_inst = menu.addAction("🎹 Instrument Track hinzufügen")
        a_add_audio = menu.addAction("🔊 Audio Track hinzufügen")
        a_add_bus = menu.addAction("🎚️ Bus Track hinzufügen")
        menu.addSeparator()
        
        a_snap, sub, a_zi, a_zo = add_grid_menu(menu)
        act = menu.exec(event.globalPos())
        
        # Handle Add Track actions
        if act == a_add_inst:
            self.request_add_track.emit("instrument")
            return
        if act == a_add_audio:
            self.request_add_track.emit("audio")
            return
        if act == a_add_bus:
            self.request_add_track.emit("bus")
            return
        
        if act == a_snap:
            if self.snap_beats and self.snap_beats > 0:
                self.snap_beats = 0.0
            else:
                self.set_snap_division(str(getattr(self.project.ctx.project, "snap_division", "1/16") or "1/16"))
            self.update()
            return
        if act in sub.actions():
            div = act.text()
            try:
                self.project.set_snap_division(div)
            except Exception:
                setattr(self.project.ctx.project, "snap_division", div)
            self.set_snap_division(div)
            self.update()
            return
        if act == a_zi:
            self.zoom_in()
            return
        if act == a_zo:
            self.zoom_out()
            return

    def wheelEvent(self, event):  # noqa: ANN001
        mods = event.modifiers()
        delta = event.angleDelta().y()

        if mods & Qt.KeyboardModifier.AltModifier:
            super().wheelEvent(event)
            return

        if mods & Qt.KeyboardModifier.ShiftModifier:
            factor = 1.1 if delta > 0 else 0.9
            self.track_height = int(max(40, min(140, self.track_height * factor)))
            self._update_minimum_size()
            self.update()
            event.accept()
            return

        factor = 1.1 if delta > 0 else 0.9
        self._zoom_by_factor(factor)
        event.accept()

    def mousePressEvent(self, event):  # noqa: ANN001
        pos = event.position()
        cid = self._clip_at_pos(pos)

        # Right-Click in ruler = draw loop, otherwise let contextMenuEvent handle it
        if event.button() == Qt.MouseButton.RightButton:
            if pos.y() <= self.ruler_height:
                # Right-click in ruler = draw new loop region
                b = self._snap(self._x_to_beats(pos.x()))
                handle = self._hit_loop_handle(pos) if self.loop_enabled else ""
                if handle:
                    self._drag_loop = _DragLoop(mode=handle, origin_beat=b)
                else:
                    self._drag_loop = _DragLoop(mode="new", origin_beat=b)
                    self.loop_enabled = True
                    self.loop_start = b
                    self.loop_end = b + max(self.snap_beats, 1.0)
                self._suppress_next_context_menu = True
                self.update()
                return
            # Below ruler: do NOT intercept — let Qt fire contextMenuEvent normally
            return

        if event.button() == Qt.MouseButton.LeftButton:
            self.setFocus(Qt.FocusReason.MouseFocusReason)

            # Bitwig-style ruler with two zones:
            # Top strip (0..zoom_band_h): zoom drag
            # Lower area (zoom_band_h..ruler_height): loop editing
            try:
                zoom_band = float(self._ruler_zoom_band_h)
                if pos.y() <= self.ruler_height:
                    if pos.y() <= zoom_band:
                        # === TOP ZONE: Zoom drag ===
                        self._update_zoom_handle_rect(float(pos.x()))
                        self._zoom_handle_visible = True
                        self._zoom_drag_active = True
                        self._zoom_drag_origin_y = float(pos.y())
                        self._zoom_drag_origin_ppb = float(self.pixels_per_beat)
                        self._zoom_anchor_beat = float(pos.x()) / max(1e-9, float(self.pixels_per_beat))
                        bar = self._find_hscrollbar()
                        self._zoom_anchor_view_x = float(pos.x()) - float(bar.value()) if bar is not None else float(pos.x())
                        self._set_override_cursor("magnifier")
                        event.accept()
                        return
                    else:
                        # === LOWER ZONE: Loop editing ===
                        handle = self._hit_loop_handle(pos)
                        b = self._snap(self._x_to_beats(pos.x()))
                        if handle:
                            self._drag_loop = _DragLoop(mode=handle, origin_beat=b)
                        else:
                            self._drag_loop = _DragLoop(mode="new", origin_beat=b)
                            self.loop_enabled = True
                            self.loop_start = b
                            self.loop_end = b + max(self.snap_beats, 1.0)
                        self.update()
                        return
            except Exception:
                pass

            # Selection (Shift toggles multi-select)
            if cid:
                # TOOL HANDLING
                # Knife Tool: Split clip at click position
                if self._active_tool == "knife":
                    try:
                        beat = self._snap(self._x_to_beats(pos.x()))
                        result = self.project.split_clip(cid, float(beat))
                        if result:
                            left_id, right_id = result
                            self.selected_clip_ids = {right_id}
                            self.selected_clip_id = right_id
                            self.clip_selected.emit(right_id)
                        self.update()
                    except Exception:
                        pass
                    return
                
                # Erase Tool: Delete clip
                if self._active_tool == "erase":
                    try:
                        self.project.delete_clip(cid)
                        self.selected_clip_ids.discard(cid)
                        if self.selected_clip_id == cid:
                            self.selected_clip_id = ""
                            self.clip_selected.emit("")
                        self.update()
                    except Exception:
                        pass
                    return
                
                # Select Tool: Normal selection behavior
                if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                    if cid in self.selected_clip_ids:
                        self.selected_clip_ids.remove(cid)
                    else:
                        self.selected_clip_ids.add(cid)
                else:
                    # DAW-style: if the user clicks on a clip that is already part
                    # of the current multi-selection, keep the selection intact.
                    # This enables "lasso-select -> drag any selected clip -> move group".
                    if cid not in self.selected_clip_ids:
                        self.selected_clip_ids = {cid}
            else:
                if not (event.modifiers() & Qt.KeyboardModifier.ShiftModifier):
                    self.selected_clip_ids = set()

            self.selected_clip_id = cid
            self.clip_selected.emit(cid)
            self.update()

            # --- Lasso Selection or empty click ---
            # FIXED v0.0.19.7.22: Removed Draw Tool single-click creation!
            # Normal-Drag on empty space = Lasso (better UX!)
            # Double-Click on track = Create clip (see mouseDoubleClickEvent)
            if (not cid) and pos.y() > self.ruler_height:
                trk = self._track_at_y(pos.y())
                mods = event.modifiers()
                
                # Draw Tool is REMOVED! Use Double-Click instead!
                # Old behavior: Single-click with Draw Tool created clip ❌
                # New behavior: Only Double-Click creates clip ✅
                
                # Lasso: Normal-Drag on empty space (default for all tools)
                if not (mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier)):
                    self._drag_lasso = _DragLasso(
                        start_x=pos.x(),
                        start_y=pos.y(),
                        current_x=pos.x(),
                        current_y=pos.y(),
                        initial_selection=set(self.selected_clip_ids)
                    )
                    if not (mods & Qt.KeyboardModifier.ShiftModifier):
                        self.selected_clip_ids = set()
                    self.update()
                    return

            # DnD start
            self._dnd_drag_start = pos
            self._dnd_clip_id = cid

            # FIXED v0.0.19.7.5: Cursor shows "+" when Ctrl+Drag!
            # Instead of creating new track immediately, we set a flag and copy on drop
            if cid and (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
                self._drag_is_copy = True
                self._drag_copy_source_clip_id = cid
                # Store original position so we can restore it after drag
                _src = next((c for c in self._arranger_clips() if c.id == cid), None)
                self._drag_copy_original_start = float(getattr(_src, "start_beats", 0.0)) if _src else 0.0
                self._drag_copy_original_track = str(getattr(_src, "track_id", "")) if _src else ""
                self._set_override_cursor("copy")
                
                # DON'T duplicate yet! Wait for mouseRelease to create copy on SAME track
            else:
                self._drag_is_copy = False
                self._drag_copy_source_clip_id = ""
            
            if cid:
                rect, clip = self._clip_rect(cid)
                if rect and clip:
                    if self._hit_resize_handle_right(rect, pos):
                        self._drag_resize_r = _DragResizeRight(
                            clip_id=cid,
                            origin_len=float(clip.length_beats),
                            origin_x=pos.x(),
                        )
                        self._drag_resize_l = None
                        self._drag_move = None
                        self._drag_move_multi = None
                    elif self._hit_resize_handle_left(rect, pos):
                        self._drag_resize_l = _DragResizeLeft(
                            clip_id=cid,
                            origin_start=float(clip.start_beats),
                            origin_len=float(clip.length_beats),
                            origin_x=pos.x(),
                            origin_offset_beats=float(getattr(clip, "offset_beats", 0.0) or 0.0),
                            origin_offset_seconds=float(getattr(clip, "offset_seconds", 0.0) or 0.0),
                        )
                        self._drag_resize_r = None
                        self._drag_move = None
                        self._drag_move_multi = None
                    else:
                        beat = self._x_to_beats(pos.x())
                        # If multiple clips are selected and the user drags one of them,
                        # move the whole selection as a group (DAW-style).
                        if cid in self.selected_clip_ids and len(self.selected_clip_ids) > 1:
                            tracks = self._tracks()
                            origins: dict[str, tuple[float, int]] = {}
                            anchor_track_idx = 0
                            for c2 in self._arranger_clips():
                                c2id = str(c2.id)
                                if c2id not in self.selected_clip_ids:
                                    continue
                                tidx = next((i for i, t in enumerate(tracks) if t.id == c2.track_id), 0)
                                origins[c2id] = (float(getattr(c2, "start_beats", 0.0) or 0.0), int(tidx))
                                if c2id == str(cid):
                                    anchor_track_idx = int(tidx)
                            self._drag_move_multi = _DragMoveMulti(
                                anchor_clip_id=str(cid),
                                dx_beats=float(beat - float(clip.start_beats)),
                                origins=origins,
                                anchor_track_idx=int(anchor_track_idx),
                            )
                            self._drag_move = None
                        else:
                            self._drag_move = _DragMove(clip_id=cid, dx_beats=beat - float(clip.start_beats))
                            self._drag_move_multi = None
                        self._drag_resize_r = None
                        self._drag_resize_l = None


            super().mousePressEvent(event)
            return

        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):  # noqa: ANN001
        pos = event.position()
        # Hover feedback: thin zoom strip at top of ruler shows magnifier,
        # lower ruler area shows normal or loop-handle cursor.
        try:
            if not getattr(self, '_zoom_drag_active', False) and event.buttons() == Qt.MouseButton.NoButton:
                zoom_band = float(self._ruler_zoom_band_h)
                in_zoom_strip = bool(pos.y() <= zoom_band)
                in_loop_zone = bool(zoom_band < pos.y() <= self.ruler_height)
                
                if in_zoom_strip:
                    # Top zoom strip → magnifier cursor
                    self._update_zoom_handle_rect(float(pos.x()))
                    if not getattr(self, '_zoom_handle_visible', False):
                        self._zoom_handle_visible = True
                        self.update()
                    self._hover_zoom_handle = True
                    self._set_override_cursor("magnifier")
                elif in_loop_zone:
                    # Lower ruler area → check loop handles
                    if self._zoom_handle_visible:
                        self._zoom_handle_visible = False
                        self.update()
                    self._hover_zoom_handle = False
                    loop_handle = self._hit_loop_handle(pos) if self.loop_enabled else ""
                    if loop_handle:
                        self._set_override_cursor("loop_handle")
                    else:
                        self._clear_override_cursor()
                else:
                    # Below ruler
                    if self._zoom_handle_visible:
                        self._zoom_handle_visible = False
                        self.update()
                    if self._hover_zoom_handle:
                        self._hover_zoom_handle = False
                    self._clear_override_cursor()
        except Exception:
            pass

        # Zoom handle drag (magnifier)
        if getattr(self, '_zoom_drag_active', False):
            try:
                dy = float(pos.y()) - float(self._zoom_drag_origin_y)
                # Up = zoom in, Down = zoom out
                factor = 1.0 + (-dy / 160.0)
                factor = max(0.25, min(4.0, factor))
                new_ppb = max(20.0, min(320.0, float(self._zoom_drag_origin_ppb) * float(factor)))
                self._apply_ppb_anchored(float(new_ppb))
                self._sync_gl_overlay()
                self.update()
                self.zoom_changed.emit(float(self.pixels_per_beat))
                event.accept()
                return
            except Exception:
                pass
        
        # FIXED v0.0.19.7.5: Update cursor if Ctrl is released during drag
        if self._drag_is_copy and not (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
            # User released Ctrl during drag - cancel copy mode
            self._drag_is_copy = False
            self._drag_copy_source_clip_id = ""
            self._clear_override_cursor()
            # print(f"[ArrangerCanvas.mouseMoveEvent] Ctrl released - copy mode cancelled, cursor reset")

        # Lasso selection - update rectangle
        if self._drag_lasso is not None:
            self._drag_lasso.current_x = pos.x()
            self._drag_lasso.current_y = pos.y()
            
            # Find all clips in lasso rectangle
            lasso_rect = self._get_lasso_rect()
            clips_in_lasso = set()
            
            for clip in self._arranger_clips():
                clip_rect, _c = self._clip_rect(str(clip.id))
                if clip_rect and lasso_rect.intersects(clip_rect):
                    clips_in_lasso.add(str(clip.id))
            
            # Update selection based on Shift modifier
            if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                # Shift+Lasso: Add to initial selection
                self.selected_clip_ids = self._drag_lasso.initial_selection | clips_in_lasso
            else:
                # Normal Lasso: Replace selection
                self.selected_clip_ids = clips_in_lasso
            
            self.update()
            return

        if self._drag_new_clip is not None:
            b = self._snap(self._x_to_beats(pos.x()))
            self._drag_new_clip.cur_beat = float(b)
            self.update()
            return

        if self._drag_loop is not None:
            b = self._snap(self._x_to_beats(pos.x()))
            if self._drag_loop.mode == "new":
                s = min(self._drag_loop.origin_beat, b)
                e = max(self._drag_loop.origin_beat, b)
                self.loop_start = s
                self.loop_end = max(s + self.snap_beats, e)
                self.loop_enabled = True
            elif self._drag_loop.mode == "start":
                self.loop_start = min(b, self.loop_end - self.snap_beats)
            elif self._drag_loop.mode == "end":
                self.loop_end = max(b, self.loop_start + self.snap_beats)
            self.update()
            return
        # Alt+DnD drag source from arranger
        if self._dnd_drag_start is not None and self._dnd_clip_id and (event.modifiers() & Qt.KeyboardModifier.AltModifier):
            dist = (pos - self._dnd_drag_start).manhattanLength()
            if dist >= 8:
                self._drag_move = None
                self._drag_move_multi = None
                self._drag_resize_r = None
                self._drag_resize_l = None
                cid = self._dnd_clip_id
                self._dnd_drag_start = None
                self._dnd_clip_id = ""
                self._start_clip_drag(cid)
                return

        if self._drag_resize_r is not None:
            _rect, clip = self._clip_rect(self._drag_resize_r.clip_id)
            if not clip:
                return
            dx = pos.x() - self._drag_resize_r.origin_x
            dbeats = dx / self.pixels_per_beat
            new_len = max(self.snap_beats, self._drag_resize_r.origin_len + dbeats)
            self.project.resize_clip(self._drag_resize_r.clip_id, new_len, snap_beats=self.snap_beats)
            self._mark_auto_loop_end_for_clip(self._drag_resize_r.clip_id)
            return

        if self._drag_resize_l is not None:
            _rect, clip = self._clip_rect(self._drag_resize_l.clip_id)
            if not clip:
                return
            dx = pos.x() - self._drag_resize_l.origin_x
            dbeats = dx / self.pixels_per_beat

            new_start = self._snap(self._drag_resize_l.origin_start + dbeats)
            delta = float(new_start) - float(self._drag_resize_l.origin_start)
            new_len = float(self._drag_resize_l.origin_len) - delta

            min_len = max(self.snap_beats, 0.25)
            if new_len < min_len:
                new_len = min_len
                # recompute start to keep right edge stable
                new_start = float(self._drag_resize_l.origin_start) + (float(self._drag_resize_l.origin_len) - new_len)
                new_start = self._snap(new_start)
                delta = float(new_start) - float(self._drag_resize_l.origin_start)

            # Content offset (beats + seconds)
            off_beats = max(0.0, float(self._drag_resize_l.origin_offset_beats) + delta)
            off_secs = max(0.0, float(self._drag_resize_l.origin_offset_seconds) + self._beats_to_seconds(delta))
            self.project.trim_clip_left(self._drag_resize_l.clip_id, new_start, new_len, off_beats, off_secs, snap_beats=self.snap_beats)
            self._mark_auto_loop_end_for_clip(self._drag_resize_l.clip_id)
            return

        if self._drag_move_multi is not None:
            d = self._drag_move_multi
            # anchor clip must still exist
            _rect, clip = self._clip_rect(d.anchor_clip_id)
            if not clip:
                return
            # Compute new anchor start (snap on anchor only).
            anchor_new = self._snap(self._x_to_beats(pos.x()) - float(d.dx_beats))
            anchor_origin = float(d.origins.get(str(d.anchor_clip_id), (float(getattr(clip, 'start_beats', 0.0) or 0.0), d.anchor_track_idx))[0])
            delta_beats = float(anchor_new) - float(anchor_origin)
            # Track delta derived from where the mouse is currently hovering.
            tracks = self._tracks()
            trk = self._track_at_y(pos.y())
            if trk is not None:
                try:
                    target_idx = next((i for i, t in enumerate(tracks) if t.id == trk.id), d.anchor_track_idx)
                except Exception:
                    target_idx = d.anchor_track_idx
            else:
                target_idx = d.anchor_track_idx
            delta_idx = int(target_idx) - int(d.anchor_track_idx)
            # Move each selected clip preserving relative offsets.
            for cid, (o_start, o_tidx) in d.origins.items():
                new_start = max(0.0, float(o_start) + float(delta_beats))
                # Avoid per-clip re-snapping: snap is anchored already.
                self.project.move_clip(str(cid), float(new_start), snap_beats=None)
                # Vertical track move (optional): keep relative track positions.
                new_tidx = int(o_tidx) + int(delta_idx)
                if tracks:
                    new_tidx = max(0, min(new_tidx, len(tracks) - 1))
                    new_track_id = str(tracks[new_tidx].id)
                    try:
                        # Only move if different
                        cobj = next((c for c in self._arranger_clips() if str(c.id) == str(cid)), None)
                        if cobj and str(getattr(cobj, 'track_id', '')) != new_track_id:
                            self.project.move_clip_track(str(cid), new_track_id)
                    except Exception:
                        pass
                self._mark_auto_loop_end_for_clip(str(cid))
            return

        if self._drag_move is not None:
            _rect, clip = self._clip_rect(self._drag_move.clip_id)
            if not clip:
                return
            beat = self._snap(self._x_to_beats(pos.x()) - self._drag_move.dx_beats)
            self.project.move_clip(self._drag_move.clip_id, beat, snap_beats=self.snap_beats)

            trk = self._track_at_y(pos.y())
            if trk and trk.id != clip.track_id:
                self.project.move_clip_track(self._drag_move.clip_id, trk.id)
            self._mark_auto_loop_end_for_clip(self._drag_move.clip_id)
            return

        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):  # noqa: ANN001
        # Zoom drag release
        if getattr(self, '_zoom_drag_active', False):
            self._zoom_drag_active = False
            try:
                pos = event.position()
                if pos.y() <= float(self._ruler_zoom_band_h):
                    self._set_override_cursor("magnifier")
                else:
                    self._clear_override_cursor()
            except Exception:
                pass
            event.accept()
            return

        # Lasso selection - finalize
        if self._drag_lasso is not None:
            # Selection is already updated in mouseMoveEvent
            # Just clean up and emit signal if needed
            if self.selected_clip_ids:
                # Set selected_clip_id to first in set (for single-clip context)
                self.selected_clip_id = next(iter(self.selected_clip_ids)) if self.selected_clip_ids else ""
                self.clip_selected.emit(self.selected_clip_id)
            self._drag_lasso = None
            self.update()
            return

        if self._drag_new_clip is not None:
            try:
                d = self._drag_new_clip
                start = float(min(d.start_beat, d.cur_beat))
                end = float(max(d.start_beat, d.cur_beat))
                length = float(end - start)

                # If the user just clicked (tiny drag), create one bar by default.
                if length < float(self.snap_beats) * 1.5:
                    length = float(self._beats_per_bar())
                length = max(float(self.snap_beats), float(self._snap(length)))

                trk = next((t for t in self.project.ctx.project.tracks if t.id == str(d.track_id)), None)
                if trk and str(getattr(trk, "kind", "audio")) == "audio":
                    # On audio tracks we import an audio file at the position instead of creating a MIDI clip.
                    self.request_import_audio.emit(str(d.track_id), float(start))
                    self.update()
                    return

                new_id = self.project.add_midi_clip_at(d.track_id, start_beats=start, length_beats=length)  # label auto-generated!
                self.selected_clip_ids = {new_id}
                self.selected_clip_id = new_id
                self.clip_selected.emit(new_id)
                self._mark_auto_loop_end_for_clip(new_id)
                self.update()
                # Open the created clip immediately.
                self.clip_activated.emit(new_id)
            finally:
                self._drag_new_clip = None
            return

        if self._drag_loop is not None:
            self._drag_loop = None
            self.loop_region_committed.emit(bool(self.loop_enabled), float(self.loop_start), float(self.loop_end))
            self.update()
            return

        self._commit_auto_loop_end()
        
        # FIXED v0.0.20.98: Ctrl+Drag = keep original, create COPY at drop position
        if self._drag_is_copy and self._drag_copy_source_clip_id and self._drag_move:
            try:
                import copy as copy_mod
                moved_clip = next((c for c in self._arranger_clips() 
                                 if c.id == self._drag_move.clip_id), None)
                
                if moved_clip:
                    # Save the drop position (where the clip is NOW after dragging)
                    drop_start = float(moved_clip.start_beats)
                    drop_track = str(moved_clip.track_id)
                    
                    # Move the original clip BACK to where it was before drag
                    orig_start = getattr(self, '_drag_copy_original_start', drop_start)
                    orig_track = getattr(self, '_drag_copy_original_track', drop_track)
                    self.project.move_clip(moved_clip.id, orig_start, snap_beats=0)
                    if str(moved_clip.track_id) != orig_track and orig_track:
                        self.project.move_clip_track(moved_clip.id, orig_track)
                    
                    # Generate label
                    original_label = str(getattr(moved_clip, "label", ""))
                    new_label = original_label if original_label.endswith(" Copy") else (original_label + " Copy")
                    
                    # Create copy at DROP position
                    new_id = None
                    if moved_clip.kind == "midi":
                        new_id = self.project.add_midi_clip_at(
                            drop_track, start_beats=drop_start,
                            length_beats=float(moved_clip.length_beats), label=new_label
                        )
                        notes = self.project.ctx.project.midi_notes.get(moved_clip.id, [])
                        self.project.ctx.project.midi_notes[new_id] = [copy_mod.deepcopy(n) for n in notes]
                        self.project._emit_updated()
                    elif moved_clip.kind == "audio":
                        audio_path = str(getattr(moved_clip, "source_path", ""))
                        if audio_path:
                            new_id = self.project.add_audio_clip_from_file_at(
                                drop_track, audio_path, start_beats=drop_start
                            )
                            if new_id:
                                new_c = next((c for c in self._arranger_clips() if c.id == new_id), None)
                                if new_c:
                                    new_c.label = new_label
                    
                    if new_id:
                        self.selected_clip_ids = {new_id}
                        self.selected_clip_id = new_id
                        self.clip_selected.emit(new_id)
                        self.status_message.emit("Clip kopiert (Strg+Drag)", 2000)
                    
            except Exception:
                import traceback
                traceback.print_exc()
        
        # Reset copy flags and cursor
        if self._drag_is_copy:
            # Reset cursor back to normal ✅
            self._clear_override_cursor()
        
        self._drag_is_copy = False
        self._drag_copy_source_clip_id = ""

        self._drag_move = None
        self._drag_move_multi = None
        self._drag_resize_r = None
        self._drag_resize_l = None
        self._dnd_drag_start = None
        self._dnd_clip_id = ""

        super().mouseReleaseEvent(event)

    def leaveEvent(self, event):
        """Ensure we don't leave the magnifier cursor stuck when leaving the widget."""
        try:
            self._hover_zoom_handle = False
            self._zoom_handle_visible = False
            self._clear_override_cursor()
        except Exception:
            pass
        super().leaveEvent(event)

    def mouseDoubleClickEvent(self, event):  # noqa: ANN001
        """Double click handling.

        IMPORTANT: Do not let Python exceptions escape into Qt. Depending on the
        PyQt6 configuration, uncaught exceptions inside event handlers/slots can
        trigger a Qt fatal error (SIGABRT).
        """
        try:
            pos = event.position()
            # Double-click in zoom strip -> reset zoom
            try:
                if pos.y() <= float(self._ruler_zoom_band_h):
                    self.pixels_per_beat = float(getattr(self, "_default_pixels_per_beat", 80.0) or 80.0)
                    self._update_minimum_size()
                    self._sync_gl_overlay()
                    self.update()
                    self.zoom_changed.emit(float(self.pixels_per_beat))
                    event.accept()
                    return
            except Exception:
                pass

            cid = self._clip_at_pos(pos)
            if cid:
                self.clip_activated.emit(cid)
                super().mouseDoubleClickEvent(event)
                return

            # Double-click empty space -> create a 1-bar clip on that track (Region-first workflow).
            if pos.y() > self.ruler_height:
                trk = self._track_at_y(pos.y())
                if trk and str(getattr(trk, "kind", "")) != "master":
                    start = float(self._snap(self._x_to_beats(pos.x())))
                    length = float(self._beats_per_bar())

                    if str(getattr(trk, "kind", "audio")) == "instrument":
                        new_id = self.project.add_midi_clip_at(
                            str(trk.id), start_beats=start, length_beats=length
                        )  # label auto-generated!
                        self.selected_clip_ids = {new_id}
                        self.selected_clip_id = new_id
                        self.clip_selected.emit(new_id)
                        self._mark_auto_loop_end_for_clip(new_id)
                        self.update()
                        # Open immediately (PianoRoll)
                        self.clip_activated.emit(new_id)
                    else:
                        # audio/bus: create placeholder clip (no import dialog)
                        new_id = self.project.add_audio_clip_placeholder_at(
                            str(trk.id), start_beats=start, length_beats=length, label="Audio Clip"
                        )
                        self.selected_clip_ids = {new_id}
                        self.selected_clip_id = new_id
                        self.clip_selected.emit(new_id)
                        self._mark_auto_loop_end_for_clip(new_id)
                        self.update()
        except Exception:
            # swallow: safety first (prevent SIGABRT)
            pass

        super().mouseDoubleClickEvent(event)

    def keyPressEvent(self, event):  # noqa: ANN001
        """Handle keyboard shortcuts."""
        
        # Space: Play/Pause toggle (DAW standard!)
        if event.key() == Qt.Key.Key_Space:
            try:
                if self.transport is not None:
                    self.transport.toggle_play()
            except Exception:
                pass
            event.accept()
            return
        
        # TOOL SHORTCUTS (Pro-DAW-Style)
        # V: Select Tool
        if event.key() == Qt.Key.Key_V:
            self.set_tool("select")
            event.accept()
            return
        
        # K: Knife Tool (split)
        if event.key() == Qt.Key.Key_K:
            self.set_tool("knife")
            event.accept()
            return
        
        # D: Draw Tool
        if event.key() == Qt.Key.Key_D:
            self.set_tool("draw")
            event.accept()
            return
        
        # E: Erase Tool
        if event.key() == Qt.Key.Key_E:
            self.set_tool("erase")
            event.accept()
            return
        
        # Ctrl+J: Join selected clips (Pro-DAW-Style)
        if event.key() == Qt.Key.Key_J and (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
            if len(self.selected_clip_ids) >= 2:
                try:
                    clip_ids = list(self.selected_clip_ids)
                    new_id = self.project.join_clips(clip_ids)
                    if new_id:
                        self.selected_clip_ids = {new_id}
                        self.selected_clip_id = new_id
                        self.clip_selected.emit(new_id)
                        self.update()
                        event.accept()
                        return
                except Exception:
                    pass
            event.accept()
            return
        
        # Ctrl+D: Duplicate selected clips
        if event.key() == Qt.Key.Key_D and (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
            if self.selected_clip_ids:
                try:
                    for clip_id in list(self.selected_clip_ids):
                        self.project.duplicate_clip(clip_id)
                    self.update()
                    event.accept()
                    return
                except Exception:
                    pass
        
        # Delete key: Delete selected clips
        if event.key() == Qt.Key.Key_Delete or event.key() == Qt.Key.Key_Backspace:
            if self.selected_clip_ids:
                try:
                    for clip_id in list(self.selected_clip_ids):
                        self.project.delete_clip(clip_id)
                    self.selected_clip_ids = set()
                    self.selected_clip_id = ""
                    self.clip_selected.emit("")
                    self.update()
                    event.accept()
                    return
                except Exception:
                    pass
        
        # Ctrl+A: Select all clips
        if event.key() == Qt.Key.Key_A and (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
            try:
                self.selected_clip_ids = {str(c.id) for c in self._arranger_clips()}
                if self.selected_clip_ids:
                    self.selected_clip_id = next(iter(self.selected_clip_ids))
                    self.clip_selected.emit(self.selected_clip_id)
                self.update()
                event.accept()
                return
            except Exception:
                pass
        
        # NEW in v0.0.19.7.0: Standard DAW shortcuts via Keyboard Handler
        # (Strg+C/V/X, ESC, Undo/Redo placeholders)
        # print(f"[ArrangerCanvas] Calling keyboard_handler with key={event.key()}")
        if self.keyboard_handler.handle_key_press(event, self.selected_clip_ids, self.selected_clip_id):
            event.accept()
            return
        
        super().keyPressEvent(event)
    
    def _on_keyboard_status(self, message: str, timeout_ms: int) -> None:
        """Forward keyboard handler status messages."""
        # print(f"[ArrangerCanvas._on_keyboard_status] {message}")
        self.status_message.emit(message, timeout_ms)
    
    def _export_midi_clip(self, clip_id: str) -> None:
        """FIXED v0.0.19.7.15: Export MIDI Clip to .mid file."""
        from PyQt6.QtWidgets import QFileDialog
        from pydaw.audio.midi_export import export_midi_clip
        
        # Get clip
        clip = next((c for c in self._arranger_clips() if c.id == clip_id), None)
        if not clip or getattr(clip, "kind", "") != "midi":
            return
        
        # Get notes
        notes = self.project.ctx.project.midi_notes.get(clip_id, [])
        if not notes:
            self.status_message.emit("Clip hat keine Noten zum Exportieren!", 3000)
            return
        
        # Get clip name for default filename
        clip_name = getattr(clip, "name", "midi_clip")
        default_filename = f"{clip_name}.mid"
        
        # Ask user for save location
        filepath, _ = QFileDialog.getSaveFileName(
            self,
            "MIDI Clip exportieren",
            default_filename,
            "MIDI Files (*.mid);;All Files (*)"
        )
        
        if not filepath:
            return  # User cancelled
        
        # Ensure .mid extension
        if not filepath.lower().endswith('.mid'):
            filepath += '.mid'
        
        # Export
        bpm = float(getattr(self.project.ctx.project, "bpm", 120.0))
        success = export_midi_clip(clip, notes, Path(filepath), bpm)
        
        if success:
            self.status_message.emit(f"MIDI exportiert: {Path(filepath).name}", 3000)
        else:
            self.status_message.emit("MIDI Export fehlgeschlagen!", 3000)

    # --- painting

    def paintEvent(self, event):  # noqa: ANN001
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.fillRect(self.rect(), self.palette().base())

        bpb = max(0.5, float(self._beats_per_bar()))

        # Loop shading
        if self.loop_enabled:
            x1 = int(self.loop_start * self.pixels_per_beat)
            x2 = int(self.loop_end * self.pixels_per_beat)
            p.fillRect(QRectF(x1, 0, max(0, x2 - x1), self.height()), QBrush(self.palette().alternateBase()))

        # Ruler background
        p.fillRect(0, 0, self.width(), self.ruler_height, self.palette().window())
        # Subtle darker tint for the zoom strip at top (visual hint for the user)
        zoom_h = int(self._ruler_zoom_band_h)
        zoom_tint = QColor(self.palette().window().color().darker(115))
        p.fillRect(0, 0, self.width(), zoom_h, zoom_tint)
        # Thin separator line between zoom strip and loop zone
        p.setPen(QPen(QColor(255, 255, 255, 30)))
        p.drawLine(0, zoom_h, self.width(), zoom_h)
        # Ruler helper text padding (keep small; magnifier is drawn on top and follows mouse).
        ruler_left_pad = 6

        # Loop handles in ruler
        if self.loop_enabled:
            pen = QPen(self.palette().highlight().color())
            pen.setWidth(2)
            p.setPen(pen)
            x1 = int(self.loop_start * self.pixels_per_beat)
            x2 = int(self.loop_end * self.pixels_per_beat)
            p.drawLine(x1, 0, x1, self.ruler_height)
            p.drawLine(x2, 0, x2, self.ruler_height)
            # Keep the LOOP label from colliding with the zoom handle.
            lx = max(min(x1, x2) + 6, ruler_left_pad)
            p.drawText(lx, 18, "LOOP")
        else:
            p.setPen(QPen(self.palette().mid().color()))
            p.drawText(ruler_left_pad, 18, "Loop: Off (Lineal klicken+ziehen)")

        # Grid (Bar / Beat / Snap subdivisions)
        width_beats = self.width() / self.pixels_per_beat
        bpb = float(self._beats_per_bar())
        beat_count = int(math.ceil(width_beats)) + 1
        bar_count = int(math.ceil(width_beats / bpb)) + 2

        # Contrast-tuned grid colors (match PianoRoll readability)
        grid_sub = QColor(70, 74, 84, 140)   # ~55% alpha
        grid_beat = QColor(92, 96, 110, 180) # ~70% alpha
        grid_bar = QColor(130, 134, 152, 220)

        # Alternate bar shading for easier placement
        shade = QColor(255, 255, 255, 0)
        try:
            shade = QColor(self.palette().alternateBase().color())
        except Exception:
            pass
        for k in range(bar_count):
            if k % 2 == 1:
                x = int(k * bpb * self.pixels_per_beat)
                w = int(bpb * self.pixels_per_beat)
                p.setOpacity(0.12)  # stronger than before
                p.fillRect(QRectF(x, self.ruler_height, w, self.height() - self.ruler_height), QBrush(shade))
                p.setOpacity(1.0)

        # Snap subdivision lines (e.g. 1/16)
        snap = float(self.snap_beats or 1.0)
        if 0.0 < snap < 1.0:
            pen_sub = QPen(grid_sub)
            pen_sub.setStyle(Qt.PenStyle.SolidLine)
            pen_sub.setWidth(1)
            p.setPen(pen_sub)
            sub_count = int(math.ceil(width_beats / snap)) + 1
            for i in range(sub_count):
                beat = i * snap
                # Skip full beats (handled by beat lines)
                if abs((beat % 1.0)) < 1e-6:
                    continue
                x = int(beat * self.pixels_per_beat)
                p.drawLine(x, self.ruler_height, x, self.height())

        # Beat lines (stronger)
        pen_beat = QPen(grid_beat)
        pen_beat.setStyle(Qt.PenStyle.SolidLine)
        pen_beat.setWidth(1)
        p.setPen(pen_beat)
        for b in range(beat_count):
            x = int(b * self.pixels_per_beat)
            p.drawLine(x, self.ruler_height, x, self.height())

        # Bar lines + labels
        pen_bar = QPen(grid_bar)
        pen_bar.setWidth(2)
        p.setPen(pen_bar)
        for k in range(bar_count):
            beat = k * bpb
            x = int(beat * self.pixels_per_beat)
            p.drawLine(x, 0, x, self.height())
            # Keep the first label from overlapping the zoom handle.
            tx = x + 4
            if tx < ruler_left_pad:
                tx = ruler_left_pad
            p.drawText(tx, 18, f"Bar {k+1}")

        # Zoom handle icon (magnifier) — draw LAST so it stays visible on top.
        try:
            if bool(getattr(self, '_zoom_handle_visible', False)) or bool(getattr(self, '_zoom_drag_active', False)):
                bg = QColor(self.palette().base().color())
                bg.setAlpha(185)
                box = self._zoom_handle_rect.adjusted(-4, -4, 4, 4)
                p.fillRect(box, bg)
                p.setPen(QPen(self.palette().mid().color()))
                p.drawRect(box)
                paint_magnifier(p, self._zoom_handle_rect, color=self.palette().text().color())
        except Exception:
            pass

        # Track lanes
        p.setPen(QPen(self.palette().dark().color()))
        tracks = self._tracks()
        for i, _ in enumerate(tracks):
            y = self.ruler_height + i * self.track_height
            p.drawLine(0, y, self.width(), y)

        # New-clip ghost (while drag-creating)
        if self._drag_new_clip is not None:
            try:
                d = self._drag_new_clip
                idx = next((i for i, t in enumerate(tracks) if getattr(t, "id", "") == d.track_id), -1)
                if idx >= 0:
                    s = float(min(d.start_beat, d.cur_beat))
                    e = float(max(d.start_beat, d.cur_beat))
                    ln = float(e - s)
                    if ln < float(self.snap_beats) * 1.5:
                        ln = float(self._beats_per_bar())
                    x = s * self.pixels_per_beat
                    y = self.ruler_height + idx * self.track_height + 2
                    w = max(16.0, ln * self.pixels_per_beat)
                    h = float(self.track_height) - 4.0
                    ghost = QRectF(x, y, w, h)
                    p.setPen(QPen(self.palette().highlight().color()))
                    p.setBrush(QBrush(self.palette().alternateBase().color()))
                    p.setOpacity(0.55)
                    p.drawRect(ghost)
                    p.setOpacity(1.0)
            except Exception:
                p.setOpacity(1.0)

        # Clips (with QPixmap cache for performance)
        for cid, rect, clip in self._clip_rects():
            is_sel = cid in self.selected_clip_ids if self.selected_clip_ids else (cid == self.selected_clip_id)

            # Cache key based on clip state + dimensions
            trk = next((t for t in tracks if t.id == clip.track_id), None)
            vol = float(getattr(trk, "volume", 1.0) or 1.0) if trk else 1.0
            w_i = max(1, int(rect.width()))
            h_i = max(1, int(rect.height()))
            cache_key = f"{cid}:{w_i}:{h_i}:{vol:.2f}:{getattr(clip,'gain',1.0):.2f}:{clip.kind}:{getattr(clip,'reversed',False)}:{getattr(clip,'muted',False)}"

            cached = self._clip_pixmap_cache.get(cache_key)
            if cached is None or cached.width() != w_i or cached.height() != h_i:
                # Render clip to pixmap
                pxm = QPixmap(w_i, h_i)
                pxm.fill(QColor(0, 0, 0, 0))
                pp = QPainter(pxm)
                pp.setRenderHint(QPainter.RenderHint.Antialiasing, True)

                local_rect = QRectF(0, 0, w_i, h_i)

                # Clip background
                if clip.kind == "audio":
                    base = self.palette().alternateBase()
                else:
                    base_color = self.palette().base().color().darker(110)
                    base = base_color
                pp.fillRect(local_rect, QBrush(base))
                pp.setPen(QPen(self.palette().text().color()))
                pp.drawRect(local_rect)

                # Muted clip overlay
                if getattr(clip, "muted", False):
                    pp.setOpacity(0.5)
                    pp.fillRect(local_rect, QBrush(QColor(60, 60, 60, 140)))
                    pp.setOpacity(1.0)

                # Preview region
                inner = local_rect.adjusted(8, 18, -8, -6)
                if inner.width() > 20 and inner.height() > 10:
                    if clip.kind == "audio":
                        self._draw_audio_waveform(pp, inner, clip, vol)
                    else:
                        self._draw_midi_preview(pp, inner, clip)

                # Title + volume
                kind_tag = "AUDIO" if clip.kind == "audio" else "MIDI"
                label = str(getattr(clip, "label", "") or kind_tag)
                rev_tag = " ◄" if getattr(clip, "reversed", False) else ""
                mute_tag = " [M]" if getattr(clip, "muted", False) else ""
                _gain, db = self._display_gain_for_volume(vol)

                pp.setPen(QPen(self.palette().text().color()))
                pp.drawText(local_rect.adjusted(10, 2, -10, -2), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop, f"[ {kind_tag}: {label}{rev_tag}{mute_tag} ]")
                pp.setPen(QPen(self.palette().mid().color()))
                pp.drawText(local_rect.adjusted(10, 2, -10, -2), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop, f"VOL: {db:+.1f} dB")

                # Handle strips
                self._draw_handle_strips(pp, local_rect, is_sel)

                pp.end()
                self._clip_pixmap_cache[cache_key] = pxm
                cached = pxm

                # Limit cache size
                if len(self._clip_pixmap_cache) > 200:
                    keys = list(self._clip_pixmap_cache.keys())
                    for k in keys[:100]:
                        del self._clip_pixmap_cache[k]

            # Draw cached pixmap
            p.drawPixmap(int(rect.x()), int(rect.y()), cached)

            if is_sel:
                sel_color = self.palette().highlight().color()
                sel_color.setAlpha(200)
                pen_sel = QPen(sel_color)
                pen_sel.setWidth(2)
                p.setPen(pen_sel)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(rect.adjusted(1, 1, -1, -1))

        # Playline
        x = int(self.playhead_beat * self.pixels_per_beat)
        pen_play = QPen(Qt.GlobalColor.red)
        pen_play.setWidth(2)
        p.setPen(pen_play)
        p.drawLine(x, 0, x, self.height())

        # Lasso selection rectangle
        if self._drag_lasso is not None:
            lasso_rect = self._get_lasso_rect()
            if not lasso_rect.isEmpty():
                # Draw semi-transparent fill
                p.setPen(Qt.PenStyle.NoPen)
                lasso_color = self.palette().highlight().color()
                lasso_color.setAlpha(50)
                p.setBrush(QBrush(lasso_color))
                p.drawRect(lasso_rect)
                
                # Draw border
                pen_lasso = QPen(self.palette().highlight().color())
                pen_lasso.setWidth(2)
                pen_lasso.setStyle(Qt.PenStyle.DashLine)
                p.setPen(pen_lasso)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(lasso_rect)

        # v0.0.20.79: Ghost-clip overlay during cross-project / external drag
        if self._drag_ghost_pos is not None and self._drag_ghost_kind:
            try:
                gx = self._drag_ghost_pos.x()
                gy = self._drag_ghost_pos.y()
                trk = self._track_at_y(gy)
                if trk:
                    idx_g = next((i for i, t in enumerate(tracks) if getattr(t, "id", "") == trk.id), -1)
                    if idx_g >= 0:
                        # Snap to grid
                        beat_g = self._snap(self._x_to_beats(gx))
                        x_g = beat_g * self.pixels_per_beat
                        y_g = self.ruler_height + idx_g * self.track_height + 2
                        # Default ghost width: 4 beats (1 bar in 4/4)
                        w_g = max(40.0, self._beats_per_bar() * self.pixels_per_beat)
                        h_g = float(self.track_height) - 4.0
                        ghost_rect = QRectF(x_g, y_g, w_g, h_g)

                        # Color by drag type
                        if self._drag_ghost_kind == "cross-project":
                            ghost_fill = QColor(80, 160, 255, 60)   # blue tint
                            ghost_border = QColor(80, 160, 255, 180)
                        elif self._drag_ghost_kind == "midi":
                            ghost_fill = QColor(120, 200, 120, 60)  # green tint
                            ghost_border = QColor(120, 200, 120, 180)
                        else:  # audio
                            ghost_fill = QColor(200, 160, 80, 60)   # amber tint
                            ghost_border = QColor(200, 160, 80, 180)

                        p.setOpacity(0.7)
                        p.setBrush(QBrush(ghost_fill))
                        pen_ghost = QPen(ghost_border)
                        pen_ghost.setWidth(2)
                        pen_ghost.setStyle(Qt.PenStyle.DashLine)
                        p.setPen(pen_ghost)
                        p.drawRoundedRect(ghost_rect, 4.0, 4.0)

                        # Label
                        p.setPen(QPen(QColor(255, 255, 255, 220)))
                        p.drawText(
                            ghost_rect.adjusted(8, 4, -4, -4),
                            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                            self._drag_ghost_label,
                        )
                        p.setOpacity(1.0)
            except Exception:
                p.setOpacity(1.0)

        p.end()

    # --- canvas size management

    def _update_minimum_size(self) -> None:
        tracks = self._tracks()
        width_beats = 0.0
        for c in self._arranger_clips():
            width_beats = max(width_beats, float(c.start_beats) + float(c.length_beats) + 4.0)
        # Also ensure loop end is visible
        width_beats = max(width_beats, float(self.loop_end) + 2.0)
        w = int(max(640, width_beats * self.pixels_per_beat))
        h = int(max(320, self.ruler_height + len(tracks) * self.track_height + 20))
        self.setMinimumSize(w, h)

    def _on_project_updated(self) -> None:
        # Invalidate clip pixmap cache (content may have changed)
        self._clip_pixmap_cache.clear()
        # Keep snap division in sync with project (if present)
        try:
            div = str(getattr(self.project.ctx.project, "snap_division", "1/16") or "1/16")
            self.set_snap_division(div)
        except Exception:
            pass
        self._update_minimum_size()
        self._sync_gl_overlay()
        self.update()

    def _sync_gl_overlay(self) -> None:
        """Sync the GPU overlay with current canvas state."""
        if self._gl_overlay is None:
            return
        try:
            # Resize overlay to match canvas
            self._gl_overlay.setGeometry(0, 0, self.width(), self.height())

            # Build clip data for GL renderer
            clips_data = []
            tracks = self._tracks()
            for cid, rect, clip in self._clip_rects():
                if clip.kind != "audio":
                    continue
                clips_data.append({
                    "x": float(rect.x()),
                    "y": float(rect.y()),
                    "width": float(rect.width()),
                    "height": float(rect.height()),
                })

            # Update viewport (pixel coords)
            w = max(1.0, float(self.width()))
            h = max(1.0, float(self.height()))
            self._gl_overlay.set_viewport(0, 0, w, h)
            self._gl_overlay.set_clips(clips_data)
            self._gl_overlay.set_playhead(self.playhead_beat * float(self.pixels_per_beat))
        except Exception:
            pass

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._sync_gl_overlay()
