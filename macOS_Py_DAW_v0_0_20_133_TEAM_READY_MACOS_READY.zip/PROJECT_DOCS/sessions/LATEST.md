v0.0.20.133
- macOS Installer/Requirements Refresh: CoreAudio (PortAudio) + SF2/FluidSynth Checks + wgpu/Metal-ready Basis in install.py/requirements.txt
