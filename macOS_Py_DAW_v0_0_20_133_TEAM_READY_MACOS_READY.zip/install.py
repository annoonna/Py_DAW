"""Installer helper for Py_DAW (cross-platform aware).

Usage:
    python3 install.py

It will:
- warn if you're not inside a virtual environment
- install/upgrade pip tooling
- install requirements.txt
- run postflight import checks for common audio/SF2 deps

Notes:
- System libraries (e.g. PortAudio / libsndfile / FluidSynth) are not installed
  automatically here. The script prints the correct platform-specific commands.
"""

from __future__ import annotations

import importlib
import os
import platform
import subprocess
import sys
from pathlib import Path

OS_NAME = platform.system()  # Linux / Darwin / Windows


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def _print_platform_hints() -> None:
    print("\n=== Plattform-Erkennung ===")
    print(f"OS: {OS_NAME}")
    print(f"Python: {sys.version.split()[0]}")

    if OS_NAME == "Darwin":
        print("\nmacOS Hinweise (CoreAudio + Metal-ready Basis):")
        print("  brew install portaudio libsndfile fluidsynth ffmpeg")
        print("  (wgpu wird via pip installiert und nutzt auf macOS Metal unter der Haube)")
    elif OS_NAME == "Linux":
        print("\nLinux Hinweise (PipeWire-JACK / JACK):")
        print("  sudo apt install libsndfile1 ffmpeg qpwgraph")
        print("  # optional je nach Setup: pipewire-jack oder jackd2")
    elif OS_NAME == "Windows":
        print("\nWindows Hinweise:")
        print("  - PortAudio / libsndfile / FluidSynth muessen ggf. separat installiert werden.")
        print("  - Bei SF2/FluidSynth sicherstellen, dass die DLLs im PATH verfuegbar sind.")


def _check_import(module_name: str, label: str, help_text: str, required: bool = True) -> bool:
    try:
        importlib.import_module(module_name)
        print(f"OK   {label} ({module_name})")
        return True
    except Exception as exc:
        level = "FEHLT" if required else "HINWEIS"
        print(f"{level} {label} ({module_name}): {exc.__class__.__name__}: {exc}")
        if help_text:
            print(f"      -> {help_text}")
        return False


def _postflight_checks() -> None:
    print("\n=== Postflight Import-Checks ===")
    if OS_NAME == "Darwin":
        brew_hint = "macOS: brew install portaudio libsndfile fluidsynth ffmpeg"
        _check_import("sounddevice", "Audio Backend (CoreAudio via PortAudio)", brew_hint)
        _check_import("soundfile", "Audio File IO (libsndfile)", brew_hint)
        _check_import("fluidsynth", "SF2 Engine (pyfluidsynth + FluidSynth)", brew_hint)
        _check_import(
            "wgpu",
            "WebGPU / Metal-ready Basis (optional)",
            "Optional fuer spaeteren GPU/Metal-Renderer",
            required=False,
        )
    elif OS_NAME == "Linux":
        _check_import("sounddevice", "Audio Backend", "Systempakete + Audio-Server (PipeWire/JACK) pruefen")
        _check_import("soundfile", "Audio File IO", "sudo apt install libsndfile1")
        _check_import("fluidsynth", "SF2 Engine (pyfluidsynth + FluidSynth)", "sudo apt install fluidsynth")
        _check_import("wgpu", "WebGPU Basis (optional)", "Optional; Linux nutzt typischerweise Vulkan", required=False)
    else:
        _check_import("sounddevice", "Audio Backend", "PortAudio installieren / PATH pruefen")
        _check_import("soundfile", "Audio File IO", "libsndfile installieren / PATH pruefen")
        _check_import("fluidsynth", "SF2 Engine (pyfluidsynth + FluidSynth)", "FluidSynth DLLs installieren / PATH pruefen")
        _check_import("wgpu", "WebGPU Basis (optional)", "Optional fuer spaeteren GPU-Renderer", required=False)


def main() -> int:
    here = Path(__file__).resolve().parent
    req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        if OS_NAME == "Windows":
            print(r"      Empfehlung: py -m venv myenv && myenv\Scripts\activate")
        else:
            print("      Empfehlung: python3 -m venv myenv && source myenv/bin/activate")

    _print_platform_hints()

    py = sys.executable
    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    _run([py, "-m", "pip", "install", "-r", str(req)])

    _postflight_checks()

    print("\nOK. Starte danach mit: python3 main.py")
    if OS_NAME == "Darwin":
        print("macOS Audio: sounddevice nutzt CoreAudio (via PortAudio).")
        print("Metal: wgpu ist nur die Basis (Metal-ready); ein echter Metal-Renderer ist ein separater Task.")
    elif OS_NAME == "Linux":
        print("Optional: Audio/MIDI Abhaengigkeiten koennen Systempakete erfordern (PipeWire-JACK/JACK/qpwgraph).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
