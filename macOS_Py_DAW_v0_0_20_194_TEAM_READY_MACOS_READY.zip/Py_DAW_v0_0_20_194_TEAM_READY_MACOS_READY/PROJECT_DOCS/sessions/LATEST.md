# Session: v0.0.20.194 — Hotfix: add_track(name=...) API

**Datum:** 2026-03-02  
**Ziel:** Crash/Popup-Fix auf macOS: `ProjectService.add_track() got an unexpected keyword argument 'name'`  

## Ursache
`import_midi()` (und ggf. weitere UI-Callsites) verwenden `add_track(kind='instrument', name='Instrument Track')`,
während `add_track()` nur `kind` akzeptierte und `None` zurückgab.

## Lösung (safe)
- `add_track(kind, name=None, **kwargs)` akzeptiert `name=` und ignoriert unbekannte kwargs.
- `add_track()` gibt ein `Track`-Objekt zurück (Callers können `.id` nutzen; ältere Callers ignorieren Return).
- Fix in **ProjectService** und **AltProjectService**.

## Geänderte Dateien
- `pydaw/services/project_service.py`
- `pydaw/services/altproject_service.py`
- `VERSION`, `pydaw/version.py`

## Test-Checkliste
- [ ] Programm startet ohne Popup
- [ ] Track hinzufügen funktioniert (Instrument/Audio)
- [ ] MIDI import erzeugt Instrument Track ohne Crash
