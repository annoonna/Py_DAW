"""Installer helper for ChronoScaleStudio (Py_DAW).

Usage:
    python3 install.py

What it does:
- warns if you're not inside a virtual environment
- upgrades pip tooling
- installs requirements.txt

Platform notes:
- Linux: JACK/PipeWire system components are NOT installed here.
- macOS: installs common native deps via Homebrew (portaudio, libsndfile, fluidsynth)
         so CoreAudio (sounddevice) + SF2 rendering work out-of-the-box.

This script is intentionally "best effort": it never blocks installation just
because a native dependency step fails.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def _run_optional(cmd: list[str]) -> None:
    try:
        _run(cmd)
    except Exception as exc:
        print("WARN:", " ".join(cmd), "failed:", exc)


def _is_macos() -> bool:
    try:
        return platform.system().lower() == "darwin"
    except Exception:
        return False


def _ensure_macos_native_deps() -> None:
    """Install native libs on macOS via Homebrew (best effort)."""
    brew = shutil.which("brew")
    if not brew:
        print("WARN: Homebrew nicht gefunden.")
        print("      Bitte installiere Homebrew (https://brew.sh) und danach:")
        print("      brew install portaudio libsndfile fluidsynth")
        return

    # Don't force `brew update` here (can be slow); just install missing packages.
    pkgs = ["portaudio", "libsndfile", "fluidsynth"]

    for pkg in pkgs:
        try:
            # If installed, `brew list --versions <pkg>` returns 0.
            r = subprocess.run([brew, "list", "--versions", pkg], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if r.returncode == 0:
                continue
        except Exception:
            # ignore detection errors, try install
            pass

        print(f"INFO: brew install {pkg}")
        _run_optional([brew, "install", pkg])


def main() -> int:
    here = Path(__file__).resolve().parent
    req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        print("      Empfehlung: python3 -m venv myenv && source myenv/bin/activate")

    if _is_macos():
        print("INFO: macOS erkannt – bereite native Abhängigkeiten für CoreAudio/Metal vor…")
        _ensure_macos_native_deps()

    py = sys.executable

    # pip tooling
    _run_optional([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])

    # python deps
    _run([py, "-m", "pip", "install", "-r", str(req)])

    # Optional: pyfluidsynth provides `import fluidsynth` (SF2 engine integration).
    # The DAW can also use the `fluidsynth` binary, but having the module improves features.
    if _is_macos():
        print("INFO: Optional (macOS): installiere pyfluidsynth für SF2/FluidSynth-Integration…")
        _run_optional([py, "-m", "pip", "install", "pyfluidsynth"])

    print("\nOK. Starte danach mit: python3 main.py")
    if _is_macos():
        print("macOS Tipps:")
        print("  - Default GFX: Metal (auto). Override: PYDAW_GFX_BACKEND=opengl python3 main.py")
        print("  - Audio: sounddevice nutzt CoreAudio (System Default Output)")
    else:
        print("Optional: Audio/MIDI Abhängigkeiten können Systempakete erfordern (PipeWire-JACK/JACK/qpwgraph).")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
