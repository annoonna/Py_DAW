# SESSION v0.0.20.191 — macOS Metal + CoreAudio (Installer/Requirements)

**Datum:** 2026-03-02
**Bearbeiter:** GPT-5.2 Thinking (ChatGPT)

## Ziel
macOS-Support stabilisieren, ohne Linux/JACK/Wayland zu beeinflussen:
- **Graphics:** Metal default (Qt RHI)
- **Audio:** CoreAudio via sounddevice (PortAudio)
- **Installation:** Homebrew native deps + saubere pip requirements

## Änderungen

### 1) Metal Default (Qt RHI)
- Datei: `pydaw/utils/gfx_backend.py`
- `PYDAW_GFX_BACKEND=auto`:
  - macOS → **metal**
  - Linux → vulkan (wenn loader vorhanden), sonst opengl
  - sonst → opengl
- Override bleibt möglich:
  - `PYDAW_GFX_BACKEND=opengl python3 main.py`

### 2) requirements.txt: JACK-Client Linux-only
- Datei: `requirements.txt`
- Änderung:
  - `JACK-Client>=0.5.5` → `JACK-Client>=0.5.5; platform_system=="Linux"`
- Effekt:
  - macOS Install bricht nicht mehr an libjack/python-jack-client.

### 3) install.py: macOS Homebrew Setup
- Datei: `install.py`
- macOS:
  - best-effort `brew install portaudio libsndfile fluidsynth`
  - danach `pip install -r requirements.txt`
  - optional: `pip install pyfluidsynth` (nicht fatal)

### 4) Dokumentation
- Datei: `INSTALL.md`
- macOS Abschnitt ergänzt (Metal/CoreAudio + Brew)

## Ergebnis / Erwartetes Verhalten
- Auf macOS startet die App mit:
  - Metal als Default GFX backend (auto)
  - CoreAudio über sounddevice (System Default Output)
- Installation läuft über:
  - `python3 install.py`

## Hinweise
- UI ist aktuell QWidget-basiert; Metal/RHI ist Vorbereitung für zukünftige Qt Quick Renderer.
- `pyfluidsynth` ist optional; SF2 Render kann weiterhin über `fluidsynth` binary funktionieren.
