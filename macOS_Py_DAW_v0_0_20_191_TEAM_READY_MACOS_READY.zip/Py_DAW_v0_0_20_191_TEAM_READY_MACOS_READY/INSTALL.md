# 📦 ChronoScaleStudio (Py_DAW) Installation

## System Requirements
- **OS:** Linux *oder* macOS
- **Python:** 3.10+ (getestet mit neueren 3.x Versionen)
- **GUI:** Qt6 (PyQt6 via pip)
- **Audio:**
  - Linux: JACK oder PipeWire-JACK
  - macOS: CoreAudio (via `sounddevice`/PortAudio)

---

## Quick Install (alle Plattformen)

```bash
# 1) Unzip
unzip Py_DAW_*.zip
cd Py_DAW_*

# 2) Virtual Environment
python3 -m venv myenv
source myenv/bin/activate

# 3) Install (empfohlen: nutzt install.py)
python3 install.py

# 4) Start
python3 main.py
```

---

## macOS (Metal + CoreAudio)

### Native Dependencies (Homebrew)

Für **CoreAudio/PortAudio** und **SoundFile/SF2** sind native Libraries nötig:

```bash
# Homebrew installieren (falls noch nicht vorhanden): https://brew.sh
brew install portaudio libsndfile fluidsynth
```

> Hinweis: `python3 install.py` versucht diese Pakete auf macOS automatisch via Homebrew zu installieren (best effort).

### Metal (Qt RHI)

Standard auf macOS ist **Metal** (wenn `PYDAW_GFX_BACKEND=auto`).

Override/Fallback:
```bash
PYDAW_GFX_BACKEND=opengl python3 main.py
```

### Optional: pyfluidsynth

Für die SF2/FluidSynth Integration (Python Modul `import fluidsynth`):

```bash
pip install pyfluidsynth
```

---

## Linux (JACK / PipeWire-JACK)

### JACK
```bash
sudo apt install jackd2
jack_control start
```

### PipeWire-JACK
```bash
sudo apt install pipewire-jack
# Läuft auf vielen modernen Distros bereits automatisch
```

### qpwgraph (Optional)
```bash
sudo apt install qpwgraph
qpwgraph &
```

---

## Troubleshooting

### Vulkan (Linux) - System packages

Wenn du unter Linux Vulkan als Default-Backend nutzen willst, installiere:

```bash
sudo apt update
sudo apt install libvulkan1 mesa-vulkan-drivers vulkan-tools
```

Test:

```bash
vulkaninfo | head
```

Fallback:

```bash
PYDAW_GFX_BACKEND=opengl python3 main.py
```

### "ModuleNotFoundError"
```bash
pip install --upgrade -r requirements.txt
```

---

## Done!
Run: `python3 main.py`
