# 📦 PyDAW Installation

## System Requirements
- **OS:** Linux (Ubuntu/Debian recommended) oder macOS
- **Python:** 3.10+
- **Audio:** Linux: JACK oder PipeWire-JACK | macOS: CoreAudio (sounddevice/PortAudio)
- **Tools:** qpwgraph (optional, for audio routing)

## Quick Install

```bash
# 1. Unzip
unzip Py_DAW_v0_0_20_17_TEAM_READY.zip
cd Py_DAW_v0_0_20_17_TEAM_READY

# 2. Create Virtual Environment
python3 -m venv myenv
source myenv/bin/activate

# 3. Install Dependencies
pip install -r requirements.txt

# 4. Start
python3 main.py
```



## macOS Setup (CoreAudio + Metal)

**Ziel:** macOS soll out-of-the-box mit **CoreAudio** laufen (über `sounddevice`/PortAudio).
Grafik-Backend ist standardmäßig **Metal** (Qt RHI).

### Systempakete (Homebrew)
```bash
brew install portaudio libsndfile fluidsynth
# Optional, falls du Audio-Imports (pydub) nutzt:
brew install ffmpeg
```

### Install + Start
```bash
python3 -m venv myenv
source myenv/bin/activate
python3 install.py
python3 main.py
```

### Grafik-Override (falls nötig)
```bash
PYDAW_GFX_BACKEND=opengl python3 main.py
PYDAW_GFX_BACKEND=software python3 main.py
```


## Audio Backend Setup

### JACK
```bash
sudo apt install jackd2
jack_control start
```

### PipeWire-JACK
```bash
sudo apt install pipewire-jack
# Already running on most modern Linux
```

### qpwgraph (Optional)
```bash
sudo apt install qpwgraph
qpwgraph &
```

## Troubleshooting

### Vulkan (Linux) - System packages

Wenn du unter Linux Vulkan als Default-Backend nutzen willst (v0.0.20.18),
installiere die System-Pakete:

```bash
sudo apt update
sudo apt install libvulkan1 mesa-vulkan-drivers vulkan-tools
```

Test:

```bash
vulkaninfo | head
```

Override (z. B. wenn dein Treiber kein Vulkan kann):

```bash
PYDAW_GFX_BACKEND=opengl python3 main.py
```

### "No audio devices found"
```bash
# Check JACK
jack_lsp

# Or PipeWire
pw-cli ls
```

### "ModuleNotFoundError"
```bash
pip install --upgrade -r requirements.txt
```

## Done!
Run: `python3 main.py`
