# -*- coding: utf-8 -*-
"""Effects Browser (Note-FX + Audio-FX) — drag into the Device Chain.

Bitwig/Ableton rule:
- Browser entries are templates.
- Drop creates a new instance on the selected track.

Mime payload:
    application/x-pydaw-plugin  (JSON bytes)
    {"kind":"note_fx|audio_fx|instrument", "plugin_id":"...", "name":"..."}

We keep this isolated so DeviceBrowser stays clean.
"""
from __future__ import annotations

import json
from typing import Callable, Optional

from PyQt6.QtCore import Qt, QMimeData
from PyQt6.QtGui import QDrag
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QListWidget, QListWidgetItem, QPushButton, QLineEdit, QTabWidget
)

from .fx_specs import get_note_fx, get_audio_fx, FxSpec


_MIME = "application/x-pydaw-plugin"


class _DragList(QListWidget):
    def __init__(self, kind: str, parent=None):
        super().__init__(parent)
        self.kind = kind
        self.setSelectionMode(QListWidget.SelectionMode.SingleSelection)
        self.setDragEnabled(True)
        self.setDragDropMode(QListWidget.DragDropMode.DragOnly)
        self.setDefaultDropAction(Qt.DropAction.CopyAction)

    def startDrag(self, supportedActions):  # noqa: N802
        it = self.currentItem()
        if it is None:
            return
        payload = it.data(Qt.ItemDataRole.UserRole) or {}
        if not isinstance(payload, dict):
            return
        payload = dict(payload)
        payload.setdefault("kind", self.kind)
        md = QMimeData()
        md.setData(_MIME, json.dumps(payload).encode("utf-8"))
        drag = QDrag(self)
        drag.setMimeData(md)
        drag.exec(Qt.DropAction.CopyAction)


class EffectsBrowserWidget(QWidget):
    def __init__(
        self,
        on_add_note_fx: Optional[Callable[[str], None]] = None,
        on_add_audio_fx: Optional[Callable[[str], None]] = None,
        parent=None
    ):
        super().__init__(parent)
        self._on_add_note = on_add_note_fx
        self._on_add_audio = on_add_audio_fx
        self._note_specs = list(get_note_fx())
        self._audio_specs = list(get_audio_fx())
        self._build()

    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(8)

        header = QLabel("Effects")
        header.setObjectName("effectsBrowserTitle")

        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.TabPosition.North)

        # --- Note-FX tab
        note_tab = QWidget()
        v1 = QVBoxLayout(note_tab)
        v1.setContentsMargins(0, 0, 0, 0)
        v1.setSpacing(6)

        row1 = QHBoxLayout()
        self.search_note = QLineEdit()
        self.search_note.setPlaceholderText("Suchen… (Note-FX)")
        self.search_note.textChanged.connect(self._refilter_note)
        self.btn_add_note = QPushButton("Add")
        self.btn_add_note.clicked.connect(self._add_note_selected)
        row1.addWidget(self.search_note, 1)
        row1.addWidget(self.btn_add_note, 0)

        self.list_note = _DragList("note_fx")
        self.list_note.itemDoubleClicked.connect(lambda _: self._add_note_selected())

        hint1 = QLabel("Tipp: Drag & Drop in die Device-Chain (unten) oder Doppelklick → Add.")
        hint1.setStyleSheet("color:#9a9a9a;")

        v1.addLayout(row1)
        v1.addWidget(self.list_note, 1)
        v1.addWidget(hint1)

        # --- Audio-FX tab
        audio_tab = QWidget()
        v2 = QVBoxLayout(audio_tab)
        v2.setContentsMargins(0, 0, 0, 0)
        v2.setSpacing(6)

        row2 = QHBoxLayout()
        self.search_audio = QLineEdit()
        self.search_audio.setPlaceholderText("Suchen… (Audio-FX)")
        self.search_audio.textChanged.connect(self._refilter_audio)
        self.btn_add_audio = QPushButton("Add")
        self.btn_add_audio.clicked.connect(self._add_audio_selected)
        row2.addWidget(self.search_audio, 1)
        row2.addWidget(self.btn_add_audio, 0)

        self.list_audio = _DragList("audio_fx")
        self.list_audio.itemDoubleClicked.connect(lambda _: self._add_audio_selected())

        hint2 = QLabel("Tipp: Drag & Drop in die Device-Chain (unten) oder Doppelklick → Add.")
        hint2.setStyleSheet("color:#9a9a9a;")

        v2.addLayout(row2)
        v2.addWidget(self.list_audio, 1)
        v2.addWidget(hint2)

        self.tabs.addTab(note_tab, "🎹 Note-FX")
        self.tabs.addTab(audio_tab, "🎚️ Audio-FX")

        root.addWidget(header)
        root.addWidget(self.tabs, 1)

        self._refilter_note()
        self._refilter_audio()

    def _refilter_note(self) -> None:
        q = (self.search_note.text() or "").strip().lower()
        self.list_note.clear()
        for s in self._note_specs:
            hay = f"{s.name} {s.plugin_id}".lower()
            if q and q not in hay:
                continue
            it = QListWidgetItem(f"{s.name}   —   {s.plugin_id}")
            it.setData(Qt.ItemDataRole.UserRole, {"plugin_id": s.plugin_id, "name": s.name})
            self.list_note.addItem(it)
        self.btn_add_note.setEnabled(self.list_note.count() > 0)

    def _refilter_audio(self) -> None:
        q = (self.search_audio.text() or "").strip().lower()
        self.list_audio.clear()
        for s in self._audio_specs:
            hay = f"{s.name} {s.plugin_id}".lower()
            if q and q not in hay:
                continue
            it = QListWidgetItem(f"{s.name}   —   {s.plugin_id}")
            it.setData(Qt.ItemDataRole.UserRole, {"plugin_id": s.plugin_id, "name": s.name})
            self.list_audio.addItem(it)
        self.btn_add_audio.setEnabled(self.list_audio.count() > 0)

    def _add_note_selected(self) -> None:
        if self._on_add_note is None:
            return
        it = self.list_note.currentItem()
        if it is None and self.list_note.count() > 0:
            it = self.list_note.item(0)
        if it is None:
            return
        pid = (it.data(Qt.ItemDataRole.UserRole) or {}).get("plugin_id")
        if isinstance(pid, str) and pid:
            self._on_add_note(pid)

    def _add_audio_selected(self) -> None:
        if self._on_add_audio is None:
            return
        it = self.list_audio.currentItem()
        if it is None and self.list_audio.count() > 0:
            it = self.list_audio.item(0)
        if it is None:
            return
        pid = (it.data(Qt.ItemDataRole.UserRole) or {}).get("plugin_id")
        if isinstance(pid, str) and pid:
            self._on_add_audio(pid)
