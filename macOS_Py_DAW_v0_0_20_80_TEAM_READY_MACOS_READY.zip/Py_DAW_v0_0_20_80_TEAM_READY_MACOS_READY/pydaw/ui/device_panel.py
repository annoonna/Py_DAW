# -*- coding: utf-8 -*-
"""Device Panel — per-track device chain (Pro-DAW-Style).

v0.0.20.65 — Device Chain MVP + Hotfixes (Ableton/Bitwig UX)
- Browser entries are templates; adding creates a NEW instance in the chain.
- Chain order is strict:
    [Note-FX] -> [Instrument (Anchor, fixed)] -> [Audio-FX]
- Drag&Drop is bulletproof: a DropForwardHost + event-filter forwards drops from child widgets.
- Per Device-Card: Up/Down + Power (enable/disable) + Remove.
- AudioEngine.rebuild_fx_maps() is called after Audio-FX add/remove/reorder/enable/disable.
- All Qt slots are wrapped in try/except to avoid fatal Qt crashes (SIGABRT) on exceptions.

v0.0.20.64 Hotfix:
- Legacy playback: fix beats_to_samples signature mismatch (no more "takes 1 positional arg but 3 were given").
- SF2 instrument anchor: show a minimal SF2 UI instead of "Instrument failed to load".

v0.0.20.65 Hotfix:
- Pro Sampler / Pro Drum Machine: target sample-rate is derived from AudioEngine settings
  (no more silent output when the user runs 44.1k instead of 48k).
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional, Tuple

from PyQt6.QtCore import Qt, QObject, QEvent, QSize, QTimer
from PyQt6.QtWidgets import (
    QWidget,
    QLabel,
    QVBoxLayout,
    QHBoxLayout,
    QScrollArea,
    QFrame,
    QSizePolicy,
    QToolButton,
    QSpinBox,
    QFileDialog,
)

from pydaw.model.project import new_id
from pydaw.plugins.registry import get_instruments

from .chrono_icons import icon as chrono_icon
from .fx_device_widgets import make_audio_fx_widget, make_note_fx_widget


_MIME = "application/x-pydaw-plugin"


def _parse_payload(event) -> Optional[dict]:  # noqa: ANN001
    try:
        md = event.mimeData()
        if md is None or not md.hasFormat(_MIME):
            return None
        raw = bytes(md.data(_MIME))
        payload = json.loads(raw.decode("utf-8", "ignore"))
        if not isinstance(payload, dict):
            return None
        return payload
    except Exception:
        return None


def _find_track(project_obj: Any, track_id: str):
    try:
        for t in getattr(project_obj, "tracks", []) or []:
            if str(getattr(t, "id", "")) == str(track_id):
                return t
    except Exception:
        pass
    return None


class _DropForwardFilter(QObject):
    """Forwards drag/drop events from arbitrary child widgets to the DevicePanel."""
    def __init__(self, panel: "DevicePanel"):
        super().__init__(panel)
        self._panel = panel

    def eventFilter(self, obj, event):  # noqa: N802, ANN001
        try:
            t = event.type()
            if t in (QEvent.Type.DragEnter, QEvent.Type.DragMove, QEvent.Type.Drop):
                # Only handle our custom plugin mime.
                payload = _parse_payload(event)
                if payload and payload.get("kind") in ("instrument", "note_fx", "audio_fx"):
                    return self._panel._forward_drag_event(event)
        except Exception:
            return False
        return False


class _DropForwardHost(QWidget):
    """Host widget inside the scroll area. Receives drops and forwards them."""
    def __init__(self, panel: "DevicePanel", parent=None):
        super().__init__(parent)
        self._panel = panel
        try:
            self.setAcceptDrops(True)
        except Exception:
            pass

    def dragEnterEvent(self, event):  # noqa: N802, ANN001
        self._panel._forward_drag_event(event)

    def dragMoveEvent(self, event):  # noqa: N802, ANN001
        self._panel._forward_drag_event(event)

    def dropEvent(self, event):  # noqa: N802, ANN001
        self._panel._forward_drag_event(event)


class _ToolBtn(QToolButton):
    def __init__(self, icon_name: str, tooltip: str, parent=None, *, checkable: bool = False):
        super().__init__(parent)
        self.setAutoRaise(True)
        self.setToolTip(tooltip)
        self.setIcon(chrono_icon(icon_name, 16))
        self.setIconSize(QSize(16, 16))
        self.setCheckable(bool(checkable))
        self.setFixedSize(QSize(22, 22))


class _DeviceCard(QFrame):
    """A single device card with controls + inner widget."""
    def __init__(
        self,
        title: str,
        inner: QWidget,
        *,
        enabled: bool = True,
        can_up: bool = False,
        can_down: bool = False,
        on_up=None,
        on_down=None,
        on_power=None,
        on_remove=None,
        parent=None,
    ):
        super().__init__(parent)
        self.setObjectName("deviceCard")
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumWidth(420)
        self.setMaximumWidth(1400)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(8, 6, 8, 8)
        outer.setSpacing(6)

        top = QHBoxLayout()
        top.setSpacing(6)

        self.lab = QLabel(title)
        self.lab.setObjectName("deviceCardTitle")
        self.lab.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        btn_up = _ToolBtn("up", "Move up", self)
        btn_dn = _ToolBtn("down", "Move down", self)
        btn_pw = _ToolBtn("power", "Enable/Disable", self, checkable=True)
        btn_rm = _ToolBtn("close", "Remove device", self)

        btn_up.setEnabled(bool(can_up) and callable(on_up))
        btn_dn.setEnabled(bool(can_down) and callable(on_down))
        btn_pw.setEnabled(callable(on_power))
        btn_rm.setEnabled(callable(on_remove))

        if callable(on_up):
            btn_up.clicked.connect(lambda _=False: on_up())
        if callable(on_down):
            btn_dn.clicked.connect(lambda _=False: on_down())
        if callable(on_power):
            btn_pw.clicked.connect(lambda _=False: on_power(btn_pw.isChecked()))
        if callable(on_remove):
            btn_rm.clicked.connect(lambda _=False: on_remove())

        btn_pw.setChecked(bool(enabled))

        top.addWidget(self.lab, 1)
        top.addWidget(btn_up, 0)
        top.addWidget(btn_dn, 0)
        top.addWidget(btn_pw, 0)
        top.addWidget(btn_rm, 0)

        outer.addLayout(top)
        self.inner_widget = inner
        outer.addWidget(inner, 1)

        self.set_enabled_visual(bool(enabled))

    def set_enabled_visual(self, enabled: bool) -> None:
        try:
            if enabled:
                self.lab.setStyleSheet("")
                self.setStyleSheet("")
            else:
                self.lab.setStyleSheet("color:#7a7a7a;")
                self.setStyleSheet("background-color: rgba(255,255,255,0.02);")
        except Exception:
            pass


class _Sf2InstrumentWidget(QWidget):
    """Minimal SF2 anchor UI.

    Wichtig: SF2 ist (noch) kein Qt-Instrument-Plugin in der Registry,
    aber wird von der Engine über Offline-Render (FluidSynth) unterstützt.
    Track.plugin_type == "sf2" ist daher ein valider Instrument-Anker.
    """

    def __init__(self, panel: "DevicePanel", track_id: str, *, sf2_path: str = "", bank: int = 0, preset: int = 0, parent=None):
        super().__init__(parent)
        self._panel = panel
        self._track_id = str(track_id or "")

        self._path = str(sf2_path or "")
        self._apply_pending = False  # avoid UI rebuild during spinbox events

        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(8)

        row = QHBoxLayout()
        row.setSpacing(6)

        self._path_lab = QLabel()
        self._path_lab.setWordWrap(True)
        self._path_lab.setStyleSheet("color:#bdbdbd;")

        self._btn_load = _ToolBtn("plus", "Load SF2 (SoundFont)", self)
        self._btn_load.clicked.connect(self._on_load)

        row.addWidget(self._path_lab, 1)
        row.addWidget(self._btn_load, 0)
        root.addLayout(row)

        row2 = QHBoxLayout()
        row2.setSpacing(10)

        lab_bank = QLabel("Bank")
        lab_bank.setStyleSheet("color:#9a9a9a;")
        self._bank = QSpinBox()
        self._bank.setRange(0, 127)
        self._bank.setValue(int(bank) if bank is not None else 0)
        self._bank.valueChanged.connect(self._on_bank_preset)

        lab_preset = QLabel("Preset")
        lab_preset.setStyleSheet("color:#9a9a9a;")
        self._preset = QSpinBox()
        self._preset.setRange(0, 127)
        self._preset.setValue(int(preset) if preset is not None else 0)
        self._preset.valueChanged.connect(self._on_bank_preset)

        row2.addWidget(lab_bank)
        row2.addWidget(self._bank)
        row2.addSpacing(8)
        row2.addWidget(lab_preset)
        row2.addWidget(self._preset)
        row2.addStretch(1)

        root.addLayout(row2)

        hint = QLabel("SF2 wird beim Playback gerendert. Tipp: Wenn du gerade abspielst, stop/start erneut für sofortigen Wechsel.")
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#7f7f7f; font-size:11px;")
        root.addWidget(hint)

        self._refresh_label()

    def _refresh_label(self) -> None:
        try:
            if self._path:
                name = os.path.basename(self._path)
                self._path_lab.setText(f"SF2: {name}")
            else:
                self._path_lab.setText("No SF2 loaded. Click + to load a SoundFont.")
        except Exception:
            pass

    def _on_load(self) -> None:
        try:
            path, _ = QFileDialog.getOpenFileName(
                self,
                "SoundFont (SF2) auswählen",
                "",
                "SoundFont (*.sf2);;Alle Dateien (*)",
            )
            if not path:
                return
            self._path = str(path)
            self._schedule_apply_sf2()
        except Exception:
            return

    def _schedule_apply_sf2(self) -> None:
        """Defer SF2 apply to next event-loop tick.

        Hintergrund: set_track_soundfont() emittiert project_updated, was das DevicePanel
        neu rendert. Wenn das während eines QSpinBox-Mouse-Events passiert (Bank/Preset),
        kann Qt den SpinBox-Widget-Zustand invalidieren -> SIGSEGV in QAbstractSpinBox::stepBy.
        """
        try:
            if getattr(self, "_apply_pending", False):
                return
            self._apply_pending = True
            QTimer.singleShot(0, self._apply_sf2_deferred)
        except Exception:
            try:
                self._apply_pending = False
            except Exception:
                pass
            try:
                self._apply_sf2()
            except Exception:
                pass

    def _apply_sf2_deferred(self) -> None:
        try:
            self._apply_pending = False
            # if no file selected, just refresh label (do not touch project)
            if not getattr(self, "_path", ""):
                try:
                    self._refresh_label()
                except Exception:
                    pass
                return
            self._apply_sf2()
        except RuntimeError:
            # Qt wrapper deleted (track switched / panel rerendered)
            return
        except Exception:
            try:
                self._apply_pending = False
            except Exception:
                pass
            return

    def _on_bank_preset(self, _=None) -> None:
        # allow setting bank/preset before picking a file
        if not self._path:
            try:
                self._refresh_label()
            except Exception:
                pass
            return
        self._schedule_apply_sf2()

    def _apply_sf2(self) -> None:
        """Write SF2 settings into track model + emit updates."""
        if not self._track_id:
            return
        try:
            proj, project_obj, trk = self._panel._get_project_track(self._track_id)
            if trk is None:
                return

            # Ensure routing mode
            try:
                trk.plugin_type = "sf2"
            except Exception:
                pass

            try:
                trk.sf2_path = str(self._path)
                trk.sf2_bank = int(self._bank.value())
                trk.sf2_preset = int(self._preset.value())
            except Exception:
                pass

            # Prefer service API (emits status/project_updated)
            try:
                if proj is not None and hasattr(proj, "set_track_soundfont"):
                    proj.set_track_soundfont(self._track_id, str(self._path), bank=int(self._bank.value()), preset=int(self._preset.value()))
            except Exception:
                pass

            self._refresh_label()
            self._panel._restart_if_playing()
        except Exception:
            return


class DevicePanel(QWidget):
    """Bottom device view — per-track strict device chain."""

    def __init__(self, services=None, parent=None):
        super().__init__(parent)
        self.setObjectName("devicePanel")
        self._services = services
        self._current_track: str = ""

        # Keep instrument widgets alive per track (state preservation).
        self._track_instruments: Dict[str, dict] = {}  # track_id -> {plugin_id, widget}

        self._drop_filter = _DropForwardFilter(self)

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 8, 12, 8)
        root.setSpacing(6)

        title = QLabel("Device")
        title.setObjectName("devicePanelTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFrameShadow(QFrame.Shadow.Sunken)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)

        self.chain_host = _DropForwardHost(self)
        self.chain_host.setObjectName("deviceChainHost")
        self.chain_host.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        self.chain = QHBoxLayout(self.chain_host)
        self.chain.setContentsMargins(0, 0, 0, 0)
        self.chain.setSpacing(8)

        self.empty_label = QLabel("Track auswählen.\\nDann Devices aus dem Browser hierher ziehen oder doppelklicken.")
        self.empty_label.setObjectName("devicePanelEmpty")
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.empty_label.setStyleSheet("color:#9a9a9a;")
        self.chain.addWidget(self.empty_label)
        self.chain.addStretch(1)

        self.scroll.setWidget(self.chain_host)

        root.addWidget(title)
        root.addWidget(sep)
        root.addWidget(self.scroll, 1)

        try:
            self.setAcceptDrops(True)
        except Exception:
            pass

        # project updated -> refresh (SAFE)
        try:
            proj = getattr(self._services, "project", None) if self._services else None
            if proj is not None and hasattr(proj, "project_updated"):
                proj.project_updated.connect(self._safe_render_current_track)
        except Exception:
            pass

    # ----------------- public API -----------------

    def show_track(self, track_id: str) -> None:
        self._current_track = str(track_id or "")
        self._safe_render_current_track()

    def has_device_for_track(self, track_id: str) -> bool:
        return bool(self._track_instruments.get(str(track_id or "")))

    def get_track_devices(self, track_id: str) -> list:
        """Return instrument widgets for this track (used by mixer routing / VU)."""
        tid = str(track_id or "")
        ent = self._track_instruments.get(tid)
        if ent and ent.get("widget") is not None:
            return [ent["widget"]]
        return []

    def remove_track_devices(self, track_id: str) -> None:
        tid = str(track_id or "")
        try:
            self._remove_instrument(tid)
        except Exception:
            pass

    def add_instrument(self, plugin_id: str) -> bool:
        """Add instrument to CURRENT track (compat helper)."""
        if not self._current_track:
            return False
        return self.add_instrument_to_track(self._current_track, plugin_id)

    def add_instrument_to_track(self, track_id: str, plugin_id: str) -> bool:
        track_id = str(track_id or "")
        plugin_id = (plugin_id or "").strip()
        if not track_id or not plugin_id:
            return False

        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return False

        instruments = {i.plugin_id: i for i in get_instruments()}
        spec = instruments.get(plugin_id)
        if spec is None:
            return False

        # Update model
        try:
            trk.plugin_type = plugin_id
            # If we switch away from SF2 routing, clear any lingering SF2 metadata
            # so the anchor doesn't show stale soundfont info.
            if hasattr(trk, "sf2_path"):
                trk.sf2_path = ""
            if hasattr(trk, "sf2_bank"):
                trk.sf2_bank = 0
            if hasattr(trk, "sf2_preset"):
                trk.sf2_preset = 0
        except Exception:
            pass

        # Build/replace widget
        self._create_or_replace_instrument_widget(track_id, plugin_id, spec)

        self._emit_project_updated()
        return True

    # ---- FX API (called by DnD and by Browser "Add")

    def add_note_fx_to_track(self, track_id: str, plugin_id: str) -> bool:
        track_id = str(track_id or "")
        plugin_id = str(plugin_id or "").strip()
        if not track_id or not plugin_id:
            return False

        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return False

        chain = getattr(trk, "note_fx_chain", None)
        if not isinstance(chain, dict):
            trk.note_fx_chain = {"devices": []}
            chain = trk.note_fx_chain

        dev_id = new_id("nfx")
        defaults = {}
        try:
            from .fx_specs import get_note_fx
            spec = next((s for s in get_note_fx() if s.plugin_id == plugin_id), None)
            if spec is not None:
                defaults = dict(spec.defaults)
        except Exception:
            defaults = {}

        chain.setdefault("devices", [])
        chain["devices"].append({
            "id": dev_id,
            "plugin_id": plugin_id,
            "name": plugin_id.split(".")[-1],
            "enabled": True,
            "params": defaults,
        })

        # (Optional) re-trigger playback for immediate effect.
        self._restart_if_playing()
        self._emit_project_updated()
        return True

    def add_audio_fx_to_track(self, track_id: str, plugin_id: str) -> bool:
        track_id = str(track_id or "")
        plugin_id = str(plugin_id or "").strip()
        if not track_id or not plugin_id:
            return False

        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return False

        chain = getattr(trk, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            trk.audio_fx_chain = {"type": "chain", "mix": 1.0, "wet_gain": 1.0, "devices": []}
            chain = trk.audio_fx_chain

        dev_id = new_id("afx")
        defaults = {}
        try:
            from .fx_specs import get_audio_fx
            spec = next((s for s in get_audio_fx() if s.plugin_id == plugin_id), None)
            if spec is not None:
                defaults = dict(spec.defaults)
        except Exception:
            defaults = {}

        chain.setdefault("devices", [])
        chain["devices"].append({
            "id": dev_id,
            "plugin_id": plugin_id,
            "name": plugin_id.split(".")[-1],
            "enabled": True,
            "params": defaults,
        })

        self._rebuild_audio_fx(project_obj)
        self._restart_if_playing()
        self._emit_project_updated()
        return True

    def remove_note_fx_device(self, track_id: str, device_id: str) -> None:
        track_id = str(track_id or "")
        device_id = str(device_id or "")
        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or trk is None:
            return
        chain = getattr(trk, "note_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        chain["devices"] = [d for d in devs if not (isinstance(d, dict) and str(d.get("id","")) == device_id)]
        self._restart_if_playing()
        self._emit_project_updated()

    def remove_audio_fx_device(self, track_id: str, device_id: str) -> None:
        track_id = str(track_id or "")
        device_id = str(device_id or "")
        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return
        chain = getattr(trk, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        chain["devices"] = [d for d in devs if not (isinstance(d, dict) and str(d.get("id","")) == device_id)]
        self._rebuild_audio_fx(project_obj)
        self._restart_if_playing()
        self._emit_project_updated()

    # ----------------- DnD plumbing -----------------

    def _forward_drag_event(self, event) -> bool:  # noqa: ANN001
        """Forwarded from host or child widgets."""
        try:
            payload = _parse_payload(event)
            if payload is None:
                event.ignore()
                return True
            kind = str(payload.get("kind") or "")
            if kind not in ("instrument", "note_fx", "audio_fx"):
                event.ignore()
                return True

            if event.type() in (QEvent.Type.DragEnter, QEvent.Type.DragMove):
                event.setDropAction(Qt.DropAction.CopyAction)
                event.accept()
                return True

            if event.type() == QEvent.Type.Drop:
                event.setDropAction(Qt.DropAction.CopyAction)
                event.accept()
                plugin_id = str(payload.get("plugin_id") or "")
                if not self._current_track:
                    return True
                if kind == "instrument":
                    self.add_instrument_to_track(self._current_track, plugin_id)
                elif kind == "note_fx":
                    self.add_note_fx_to_track(self._current_track, plugin_id)
                elif kind == "audio_fx":
                    self.add_audio_fx_to_track(self._current_track, plugin_id)
                return True
        except Exception:
            try:
                event.ignore()
            except Exception:
                pass
            return True

        return False

    def dragEnterEvent(self, event):  # noqa: N802, ANN001
        self._forward_drag_event(event)

    def dragMoveEvent(self, event):  # noqa: N802, ANN001
        self._forward_drag_event(event)

    def dropEvent(self, event):  # noqa: N802, ANN001
        self._forward_drag_event(event)

    # ----------------- render -----------------

    def _safe_render_current_track(self) -> None:
        try:
            self._render_current_track()
        except Exception:
            # never crash Qt thread
            return

    def _render_current_track(self) -> None:
        # clear layout
        self._clear_chain()

        if not self._current_track:
            self.chain.addWidget(self.empty_label)
            self.chain.addStretch(1)
            return

        proj, project_obj, trk = self._get_project_track(self._current_track)
        if proj is None or project_obj is None or trk is None:
            self.chain.addWidget(self.empty_label)
            self.chain.addStretch(1)
            return

        # NOTE-FX (left)
        note_chain = getattr(trk, "note_fx_chain", None)
        note_devs = note_chain.get("devices", []) if isinstance(note_chain, dict) else []
        note_devs = [d for d in (note_devs or []) if isinstance(d, dict)]

        for i, dev in enumerate(note_devs):
            did = str(dev.get("id") or "")
            title = str(dev.get("name") or dev.get("plugin_id") or "Note-FX")
            enabled = bool(dev.get("enabled", True))
            inner = make_note_fx_widget(self._services, self._current_track, dev) or QLabel("No UI")
            self._install_drop_filter(inner)

            card = _DeviceCard(
                title,
                inner,
                enabled=enabled,
                can_up=i > 0,
                can_down=i < (len(note_devs) - 1),
                on_up=lambda tid=self._current_track, d=did: self._move_fx(tid, "note_fx", d, -1),
                on_down=lambda tid=self._current_track, d=did: self._move_fx(tid, "note_fx", d, +1),
                on_power=lambda checked, tid=self._current_track, d=did: self._set_fx_enabled(tid, "note_fx", d, bool(checked)),
                on_remove=lambda tid=self._current_track, d=did: self.remove_note_fx_device(tid, d),
            )
            self._install_drop_filter(card)
            self.chain.addWidget(card, 1)

        # INSTRUMENT (anchor, fixed)
        inst_card = self._make_instrument_anchor_card(project_obj, trk)
        self._install_drop_filter(inst_card)
        self.chain.addWidget(inst_card, 2)

        # AUDIO-FX (right)
        audio_chain = getattr(trk, "audio_fx_chain", None)
        audio_devs = audio_chain.get("devices", []) if isinstance(audio_chain, dict) else []
        audio_devs = [d for d in (audio_devs or []) if isinstance(d, dict)]

        for i, dev in enumerate(audio_devs):
            did = str(dev.get("id") or "")
            title = str(dev.get("name") or dev.get("plugin_id") or "Audio-FX")
            enabled = bool(dev.get("enabled", True))
            inner = make_audio_fx_widget(self._services, self._current_track, dev) or QLabel("No UI")
            self._install_drop_filter(inner)

            card = _DeviceCard(
                title,
                inner,
                enabled=enabled,
                can_up=i > 0,
                can_down=i < (len(audio_devs) - 1),
                on_up=lambda tid=self._current_track, d=did: self._move_fx(tid, "audio_fx", d, -1),
                on_down=lambda tid=self._current_track, d=did: self._move_fx(tid, "audio_fx", d, +1),
                on_power=lambda checked, tid=self._current_track, d=did: self._set_fx_enabled(tid, "audio_fx", d, bool(checked)),
                on_remove=lambda tid=self._current_track, d=did: self.remove_audio_fx_device(tid, d),
            )
            self._install_drop_filter(card)
            self.chain.addWidget(card, 1)

        self.chain.addStretch(1)

    def _make_instrument_anchor_card(self, project_obj: Any, trk: Any) -> QWidget:
        tid = str(getattr(trk, "id", "") or "")
        plugin_id = str(getattr(trk, "plugin_type", "") or "")

        # legacy SF2 info
        sf2_path = str(getattr(trk, "sf2_path", "") or "")
        sf2_bank = getattr(trk, "sf2_bank", 0)
        sf2_preset = getattr(trk, "sf2_preset", 0)

        # SF2 ist aktuell kein Qt-Instrument-Plugin aus der Registry.
        # Trotzdem ist plugin_type == "sf2" ein valider Instrument-Anker (Engine render...)
        if plugin_id == "sf2" or (not plugin_id and sf2_path):
            w = _Sf2InstrumentWidget(self, tid, sf2_path=sf2_path, bank=int(sf2_bank or 0), preset=int(sf2_preset or 0))
            self._install_drop_filter(w)
            card = _DeviceCard(
                "Instrument — SF2",
                w,
                enabled=True,
                can_up=False,
                can_down=False,
                on_up=None,
                on_down=None,
                on_power=None,
                on_remove=lambda tid=tid: self._remove_instrument(tid),
            )
            return card

        if plugin_id:
            # Ensure widget exists for this plugin id
            if tid not in self._track_instruments or self._track_instruments[tid].get("plugin_id") != plugin_id:
                instruments = {i.plugin_id: i for i in get_instruments()}
                spec = instruments.get(plugin_id)
                if spec is not None:
                    self._create_or_replace_instrument_widget(tid, plugin_id, spec)

            w = self._track_instruments.get(tid, {}).get("widget")
            if w is None:
                w = QLabel("Instrument failed to load.")
            else:
                # ensure track context
                try:
                    if hasattr(w, "set_track_context"):
                        w.set_track_context(tid)
                except Exception:
                    pass

            self._install_drop_filter(w)
            card = _DeviceCard(
                f"Instrument — {plugin_id.split('.')[-1]}",
                w,
                enabled=True,
                can_up=False,
                can_down=False,
                on_up=None,
                on_down=None,
                on_power=None,  # instrument bypass not in MVP
                on_remove=lambda tid=tid: self._remove_instrument(tid),
            )
            return card

        # No plugin instrument: show placeholder (anchor)
        lab = QLabel("Instrument (Anchor)\nDrop an Instrument here or double‑click in Browser.")
        lab.setStyleSheet("color:#9a9a9a;")
        lab.setWordWrap(True)

        if sf2_path:
            try:
                import os
                name = os.path.basename(sf2_path)
            except Exception:
                name = sf2_path
            lab.setText(
                f"Instrument (Anchor)\nSF2: {name} (Bank {sf2_bank}, Preset {sf2_preset})\n"
                "Drop an Instrument plugin here to replace."
            )

        card = _DeviceCard(
            "Instrument — (empty)",
            lab,
            enabled=True,
            can_up=False,
            can_down=False,
            on_up=None,
            on_down=None,
            on_power=None,
            on_remove=None,
        )
        return card

    # ----------------- model mutations -----------------

    def _move_fx(self, track_id: str, kind: str, device_id: str, delta: int) -> None:
        track_id = str(track_id or "")
        device_id = str(device_id or "")
        delta = int(delta)
        if not track_id or not device_id or delta == 0:
            return
        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return

        chain = getattr(trk, "note_fx_chain" if kind == "note_fx" else "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        devs = [d for d in devs if isinstance(d, dict)]
        idx = next((i for i, d in enumerate(devs) if str(d.get("id","")) == device_id), None)
        if idx is None:
            return
        j = idx + delta
        if j < 0 or j >= len(devs):
            return
        devs[idx], devs[j] = devs[j], devs[idx]
        chain["devices"] = devs

        if kind == "audio_fx":
            self._rebuild_audio_fx(project_obj)

        self._emit_project_updated()

    def _set_fx_enabled(self, track_id: str, kind: str, device_id: str, enabled: bool) -> None:
        track_id = str(track_id or "")
        device_id = str(device_id or "")
        enabled = bool(enabled)
        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return
        chain = getattr(trk, "note_fx_chain" if kind == "note_fx" else "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        for d in devs:
            if isinstance(d, dict) and str(d.get("id","")) == device_id:
                d["enabled"] = bool(enabled)
                break
        if kind == "audio_fx":
            self._rebuild_audio_fx(project_obj)
        self._emit_project_updated()

    def _remove_instrument(self, track_id: str) -> None:
        track_id = str(track_id or "")
        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or trk is None:
            return
        try:
            trk.plugin_type = None
        except Exception:
            pass
        # SF2 cleanup (falls Track zuvor als SF2-Instrument geroutet war)
        try:
            if hasattr(trk, "sf2_path"):
                trk.sf2_path = ""
            if hasattr(trk, "sf2_bank"):
                trk.sf2_bank = 0
            if hasattr(trk, "sf2_preset"):
                trk.sf2_preset = 0
        except Exception:
            pass
        ent = self._track_instruments.pop(track_id, None)
        if ent and ent.get("widget") is not None:
            try:
                ent["widget"].setParent(None)
            except Exception:
                pass
        self._emit_project_updated()

    def _create_or_replace_instrument_widget(self, track_id: str, plugin_id: str, spec) -> None:  # noqa: ANN001
        track_id = str(track_id or "")
        if not track_id:
            return
        proj = getattr(self._services, "project", None) if self._services else None
        ae = getattr(self._services, "audio_engine", None) if self._services else None

        # Remove old widget if any
        old = self._track_instruments.get(track_id)
        if old and old.get("widget") is not None:
            try:
                old["widget"].setParent(None)
            except Exception:
                pass

        try:
            w = spec.factory(project_service=proj, audio_engine=ae)
        except Exception as e:
            w = QLabel(f"Instrument error: {e}")

        try:
            w.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        except Exception:
            pass

        # Track context (important for pull-source routing)
        try:
            if hasattr(w, "set_track_context"):
                w.set_track_context(track_id)
        except Exception:
            pass
        try:
            if hasattr(w, "track_id"):
                w.track_id = track_id
        except Exception:
            pass

        self._install_drop_filter(w)
        self._track_instruments[track_id] = {"plugin_id": plugin_id, "widget": w}

    # ----------------- helpers -----------------

    def _install_drop_filter(self, w: QWidget) -> None:
        try:
            if w is None:
                return
            w.installEventFilter(self._drop_filter)
            # Also install for children to avoid drops "verpuffen"
            for ch in w.findChildren(QWidget):
                try:
                    ch.installEventFilter(self._drop_filter)
                except Exception:
                    pass
        except Exception:
            pass

    def _clear_chain(self) -> None:
        try:
            persistent = set()
            try:
                for ent in (self._track_instruments or {}).values():
                    w0 = ent.get("widget") if isinstance(ent, dict) else None
                    if w0 is not None:
                        persistent.add(w0)
            except Exception:
                persistent = set()

            while self.chain.count():
                it = self.chain.takeAt(0)
                w = it.widget()
                if w is None:
                    continue

                # If this is a card wrapping a persistent instrument widget, detach it first.
                try:
                    inner = getattr(w, "inner_widget", None)
                    if inner is not None and inner in persistent:
                        inner.setParent(None)
                except Exception:
                    pass

                w.setParent(None)
        except Exception:
            pass

    def _emit_project_updated(self) -> None:
        try:
            proj = getattr(self._services, "project", None) if self._services else None
            if proj is not None and hasattr(proj, "project_updated"):
                proj.project_updated.emit()
        except Exception:
            pass

    def _get_project_track(self, track_id: str) -> Tuple[Any, Any, Any]:
        proj = getattr(self._services, "project", None) if self._services else None
        if proj is None:
            return None, None, None
        ctx = getattr(proj, "ctx", None)
        project_obj = getattr(ctx, "project", None) if ctx is not None else None
        if project_obj is None:
            return proj, None, None
        trk = _find_track(project_obj, track_id)
        return proj, project_obj, trk

    def _rebuild_audio_fx(self, project_obj: Any) -> None:
        ae = getattr(self._services, "audio_engine", None) if self._services else None
        try:
            if ae is not None and hasattr(ae, "rebuild_fx_maps"):
                ae.rebuild_fx_maps(project_obj)
        except Exception:
            pass

    def _restart_if_playing(self) -> None:
        try:
            transport = getattr(self._services, "transport", None) if self._services else None
            ae = getattr(self._services, "audio_engine", None) if self._services else None
            if transport is None or ae is None:
                return
            playing = bool(getattr(transport, "is_playing", False) or getattr(transport, "playing", False))
            if not playing:
                return
            try:
                ae.stop()
            except Exception:
                pass
            try:
                ae.start_arrangement_playback()
            except Exception:
                pass
        except Exception:
            pass
