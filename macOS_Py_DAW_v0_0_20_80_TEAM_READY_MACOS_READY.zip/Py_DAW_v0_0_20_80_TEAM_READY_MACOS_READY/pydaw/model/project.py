"""Project domain model (v0.0.9).

v0.0.5: MIDI notes per clip (Piano Roll).
v0.0.7: Clip Launcher mapping slot_key -> clip_id.
v0.0.8: Clip Launcher settings (quantize/mode).
v0.0.9: Audio clip params (gain/pan/pitch + per-clip loop/slices) for AudioEventEditor.

Persistence: JSON via dataclasses.asdict in file_manager.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid

from .midi import MidiNote


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:10]}"


@dataclass
class MediaItem:
    kind: str  # "audio" | "midi"
    path: str
    label: str = ""
    id: str = field(default_factory=lambda: new_id("media"))


@dataclass
class Track:
    id: str = field(default_factory=lambda: new_id("trk"))
    kind: str = "audio"  # "audio" | "instrument" | "bus" | "master"
    name: str = "Track"
    muted: bool = False
    solo: bool = False
    automation_mode: str = "off"  # off|read|write
    volume: float = 0.8
    pan: float = 0.0
    record_arm: bool = False

    # Audio I/O routing (JACK-first): choose which stereo input pair is used for
    # monitoring/recording (1..N). Output pair is reserved for future submix/bus routing.
    input_pair: int = 1
    output_pair: int = 1
    monitor: bool = False

    # v0.0.20.46: Plugin-based instrument routing (Pro-DAW-Style!)
    # This determines which instrument engine processes MIDI clips on this track
    # Options: "sampler", "drum_machine", "sf2", None (no instrument)
    # If None but sf2_path is set: auto-detected as "sf2" for backwards compatibility
    plugin_type: Optional[str] = None
    # Instrument-spezifischer Persistenz-Speicher (Sampler/Drum/etc.)
    # Wird automatisch in der Projektdatei gespeichert (dataclass -> asdict).
    instrument_state: Dict[str, Any] = field(default_factory=dict)

    # Phase 3: SF2 instrument state (kept for backwards compatibility)
    # When plugin_type="sf2" or plugin_type=None with sf2_path set, these are used
    sf2_path: Optional[str] = None
    sf2_bank: int = 0
    sf2_preset: int = 0
    midi_channel: int = 0

    # v0.0.20.56: Device Chains (Engine-First)
    # Note-FX Chain: MIDI/Notenbearbeitung vor dem Instrument
    note_fx_chain: dict = field(default_factory=lambda: {"devices": []})

    # Audio-FX Chain: serielle Effekte nach dem Instrument (mit Dry/Wet + Wet Gain)
    audio_fx_chain: dict = field(default_factory=lambda: {"type": "chain", "mix": 1.0, "wet_gain": 1.0, "devices": []})

@dataclass
class AudioEvent:
    """Non-destructive segment inside an audio clip.

    Timeline inside the clip is expressed in beats (quarter-note beats).
    - start_beats: position inside clip content (0..clip.length_beats)
    - length_beats: duration of this segment
    - source_offset_beats: offset inside the underlying source (beats) relative to clip offset
      (placeholder until we add sample-accurate seconds based editing).
    """
    id: str = field(default_factory=lambda: new_id("aev"))
    start_beats: float = 0.0
    length_beats: float = 0.0
    source_offset_beats: float = 0.0


@dataclass
class Clip:
    id: str = field(default_factory=lambda: new_id("clip"))
    kind: str = "audio"  # "audio" | "midi"
    track_id: str = ""
    start_beats: float = 0.0
    length_beats: float = 4.0
    # content offset inside source (for left trim/extend)
    offset_beats: float = 0.0
    offset_seconds: float = 0.0
    label: str = "Clip"
    media_id: Optional[str] = None
    source_path: Optional[str] = None

    # Optional: if the clip's source tempo is known (e.g. parsed from the
    # filename "*_150bpm.wav"), playback can be time-scaled to match the project BPM.
    source_bpm: Optional[float] = None
    # Optional: used for simple grouping (move/edit multiple clips together)
    group_id: str = ""

    # --- Audio Clip non-destructive params (used by AudioEventEditor / Launcher)
    gain: float = 1.0          # linear (1.0 = unity)
    pan: float = 0.0           # -1.0 (L) .. 0.0 .. +1.0 (R)
    pitch: float = 0.0         # semitones
    formant: float = 0.0       # semitones (placeholder)
    stretch: float = 1.0       # time-stretch factor (1.0 = original)
    reversed: bool = False     # non-destructive reverse playback
    muted: bool = False        # non-destructive clip mute

    # Per-clip loop region in beats (relative to clip start inside its content)
    # If loop_end_beats <= loop_start_beats -> treated as "full clip length"
    loop_start_beats: float = 0.0
    loop_end_beats: float = 0.0

    # Non-destructive slice markers (beats relative to clip content start)
    audio_slices: List[float] = field(default_factory=list)
    # Optional transient/onset markers (beats relative to clip content start)
    onsets: List[float] = field(default_factory=list)

    # Phase 2: non-destructive events inside the audio clip (derived from slices if missing)
    audio_events: List[AudioEvent] = field(default_factory=list)

    # Clip exists only in Clip-Launcher (not shown on Arranger timeline)
    launcher_only: bool = False


@dataclass
class Project:
    # Keep this in sync with VERSION / pydaw.version.__version__ for new projects.
    version: str = '0.0.20.79'
    name: str = "Neues Projekt"
    created_utc: str = field(default_factory=lambda: datetime.utcnow().isoformat(timespec="seconds"))
    modified_utc: str = field(default_factory=lambda: datetime.utcnow().isoformat(timespec="seconds"))

    sample_rate: int = 48000
    bpm: float = 120.0
    time_signature: str = "4/4"
    snap_division: str = "1/16"
    automation_lanes: dict = None  # placeholder
    midi_mappings: list = None  # placeholder: list of mappings

    media: List[MediaItem] = field(default_factory=list)
    tracks: List[Track] = field(default_factory=list)
    clips: List[Clip] = field(default_factory=list)

    # clip_id -> notes
    midi_notes: Dict[str, List[MidiNote]] = field(default_factory=dict)

    # slot_key -> clip_id
    clip_launcher: Dict[str, str] = field(default_factory=dict)

    # Clip Launcher settings (placeholder)
    launcher_quantize: str = "1 Bar"  # Off | 1 Beat | 1 Bar
    launcher_mode: str = "Trigger"    # Trigger | Toggle | Gate

    # Ghost Notes / Layered Editing state (persisted)
    # JSON-safe dict produced by LayerManager.to_dict()
    ghost_layers: Dict[str, Any] = field(default_factory=dict)
    # Notation marks / annotations (sticky notes, rests, ornaments, ties, etc.)
    # Stored as list of JSON-safe dicts. Rendering/editor can interpret these.
    notation_marks: List[Dict[str, Any]] = field(default_factory=list)


    def __post_init__(self) -> None:
        if not self.tracks:
            self.tracks = [Track(kind="master", name="Master")]

    

    def tracks_by_id(self) -> Dict[str, Track]:
        """Convenience: map track_id -> Track.

        Used across UI/Engine to avoid repeated linear scans.
        """
        return {str(getattr(t, 'id', '')): t for t in (self.tracks or []) if str(getattr(t, 'id', ''))}

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Project":
        # Robust loader: ignore unknown keys (forward-compatible) and convert nested dataclasses.
        from dataclasses import fields as _dc_fields

        media = [MediaItem(**m) for m in d.get("media", []) if isinstance(m, dict)]

        # Filter Track keys
        track_keys = {f.name for f in _dc_fields(Track)}
        tracks = []
        for td in d.get("tracks", []) or []:
            if not isinstance(td, dict):
                continue
            td2 = {k: v for k, v in td.items() if k in track_keys}
            tracks.append(Track(**td2))

        # Convert Clip + AudioEvents
        clip_keys = {f.name for f in _dc_fields(Clip)}
        clips = []
        for cd in d.get("clips", []) or []:
            if not isinstance(cd, dict):
                continue
            # audio_events may be list[dict]
            evs = cd.get("audio_events", None)
            if isinstance(evs, list):
                conv = []
                for e in evs:
                    if isinstance(e, dict):
                        try:
                            conv.append(AudioEvent(**e))
                        except Exception:
                            # best-effort: ignore malformed
                            continue
                cd = dict(cd)
                cd["audio_events"] = conv
            cd2 = {k: v for k, v in cd.items() if k in clip_keys}
            clips.append(Clip(**cd2))

        midi_notes: Dict[str, List[MidiNote]] = {}
        raw_notes = d.get("midi_notes", {}) or {}
        if isinstance(raw_notes, dict):
            for clip_id, notes in raw_notes.items():
                nl: List[MidiNote] = []
                if isinstance(notes, list):
                    for n in notes:
                        if isinstance(n, dict):
                            nl.append(MidiNote(**n).clamp())
                midi_notes[str(clip_id)] = nl

        clip_launcher: Dict[str, str] = {}
        raw_cl = d.get("clip_launcher", {}) or {}
        if isinstance(raw_cl, dict):
            clip_launcher = {str(k): str(v) for k, v in raw_cl.items() if v}

        lq = str(d.get("launcher_quantize", "1 Bar"))
        lm = str(d.get("launcher_mode", "Trigger"))

        obj = cls(
            version=str(d.get("version", "0.0.19.7.52")),
            name=str(d.get("name", "Projekt")),
            created_utc=str(d.get("created_utc", "")),
            modified_utc=str(d.get("modified_utc", "")),
            sample_rate=int(d.get("sample_rate", 48000)),
            bpm=float(d.get("bpm", 120.0)),
            time_signature=str(d.get("time_signature", "4/4")),
            snap_division=str(d.get("snap_division", "1/16")),
            automation_lanes=dict(d.get("automation_lanes", {})) if d.get("automation_lanes") is not None else {},
            midi_mappings=list(d.get("midi_mappings", [])) if d.get("midi_mappings") is not None else [],
            media=media,
            tracks=tracks,
            clips=clips,
            midi_notes=midi_notes,
            clip_launcher=clip_launcher,
            launcher_quantize=lq,
            launcher_mode=lm,
            ghost_layers=dict(d.get("ghost_layers", {})) if isinstance(d.get("ghost_layers", {}), dict) else {},
            notation_marks=[m for m in (d.get("notation_marks", []) or []) if isinstance(m, dict)],
        )
        if not obj.tracks:
            obj.tracks = [Track(kind="master", name="Master")]
        return obj
