"""Automatable Parameter System (v0.0.20.89).

Unified parameter system for DAW-grade automation — inspired by JUCE AudioProcessorParameter,
Ableton Live, and Bitwig Studio.

Architecture:
- AutomatableParameter: Base class for any controllable parameter.
  Supports multiple simultaneous input sources: Manual (GUI), Timeline Automation, Modulators.
- AutomationManager: Central routing service.
  Connects parameters to lanes, modulators, and UI. Decouples widgets from the arranger.
- ModulationSource: LFO/Envelope that adds offset to a parameter (Bitwig-style).

Thread Safety:
- GUI thread sets values via set_value() / set_automation_value()
- Audio thread reads via get_effective_value() — lock-free via RTParamStore
- No direct writes from GUI into audio variables — ever

Usage:
    mgr = AutomationManager(project_service, rt_params)
    param = mgr.register_parameter("trk:abc:vol", "Volume", 0.0, 1.0, 0.8, track_id="abc")
    param.set_value(0.5)           # from GUI
    param.add_modulation(0.1)      # from LFO
    effective = param.get_effective_value()  # 0.6
"""
from __future__ import annotations

import math
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

from PyQt6.QtCore import QObject, pyqtSignal


class CurveType(Enum):
    """Interpolation type between automation breakpoints."""
    LINEAR = "linear"
    BEZIER = "bezier"
    STEP = "step"          # discrete steps (for ComboBox / enum params)
    SMOOTH = "smooth"      # S-curve (cubic ease-in-out)


@dataclass
class BreakPoint:
    """A single automation breakpoint on the timeline.

    beat: position in beats (quarter notes)
    value: normalized 0..1 (mapped to param range by AutomatableParameter)
    curve_type: interpolation to next point
    bezier_cx / bezier_cy: control point for Bezier curves (relative 0..1 within segment)
    """
    beat: float = 0.0
    value: float = 0.0
    curve_type: CurveType = CurveType.LINEAR
    bezier_cx: float = 0.5
    bezier_cy: float = 0.5

    def to_dict(self) -> dict:
        d = {"beat": self.beat, "value": self.value, "curve_type": self.curve_type.value}
        if self.curve_type == CurveType.BEZIER:
            d["bezier_cx"] = self.bezier_cx
            d["bezier_cy"] = self.bezier_cy
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "BreakPoint":
        ct = CurveType.LINEAR
        try:
            ct = CurveType(d.get("curve_type", "linear"))
        except (ValueError, KeyError):
            pass
        return cls(
            beat=float(d.get("beat", 0.0)),
            value=float(d.get("value", 0.0)),
            curve_type=ct,
            bezier_cx=float(d.get("bezier_cx", 0.5)),
            bezier_cy=float(d.get("bezier_cy", 0.5)),
        )


@dataclass
class AutomationLane:
    """Automation data for one parameter on one track.

    Contains breakpoints sorted by beat, plus metadata.
    """
    parameter_id: str = ""
    track_id: str = ""
    param_name: str = ""
    points: List[BreakPoint] = field(default_factory=list)
    enabled: bool = True
    color: str = "#00BFFF"  # default: deep sky blue

    def sort_points(self) -> None:
        self.points.sort(key=lambda p: p.beat)

    def interpolate(self, beat: float) -> Optional[float]:
        """Sample-accurate interpolation at a given beat position.

        Returns None if no points exist. Supports Linear, Bezier, Step, Smooth.
        """
        if not self.points:
            return None
        pts = self.points  # assumed sorted
        if not pts:
            return None

        # Clamp before first / after last
        if beat <= pts[0].beat:
            return pts[0].value
        if beat >= pts[-1].beat:
            return pts[-1].value

        # Find the segment
        for i in range(len(pts) - 1):
            p0 = pts[i]
            p1 = pts[i + 1]
            if p0.beat <= beat <= p1.beat:
                span = p1.beat - p0.beat
                if span <= 0:
                    return p1.value
                t = (beat - p0.beat) / span

                if p0.curve_type == CurveType.STEP:
                    return p0.value

                if p0.curve_type == CurveType.SMOOTH:
                    # Cubic ease-in-out (S-curve)
                    t = t * t * (3.0 - 2.0 * t)
                    return p0.value + t * (p1.value - p0.value)

                if p0.curve_type == CurveType.BEZIER:
                    # Quadratic Bezier through control point
                    cx = p0.bezier_cx
                    cy = p0.bezier_cy
                    # Map cx/cy to absolute values
                    ctrl_val = p0.value + cy * (p1.value - p0.value)
                    # Quadratic Bezier: B(t) = (1-t)²P0 + 2(1-t)tC + t²P1
                    one_t = 1.0 - t
                    return (one_t * one_t * p0.value +
                            2.0 * one_t * t * ctrl_val +
                            t * t * p1.value)

                # Default: LINEAR
                return p0.value + t * (p1.value - p0.value)

        return pts[-1].value

    def to_dict(self) -> dict:
        return {
            "parameter_id": self.parameter_id,
            "track_id": self.track_id,
            "param_name": self.param_name,
            "points": [p.to_dict() for p in self.points],
            "enabled": self.enabled,
            "color": self.color,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "AutomationLane":
        pts = [BreakPoint.from_dict(p) for p in d.get("points", []) if isinstance(p, dict)]
        lane = cls(
            parameter_id=str(d.get("parameter_id", "")),
            track_id=str(d.get("track_id", "")),
            param_name=str(d.get("param_name", "")),
            points=pts,
            enabled=bool(d.get("enabled", True)),
            color=str(d.get("color", "#00BFFF")),
        )
        lane.sort_points()
        return lane


class AutomatableParameter:
    """A single automatable parameter with multiple input sources.

    Value stack (order of priority):
    1. base_value: Set by user via GUI (manual mode)
    2. automation_value: Set by timeline automation playback (read mode)
    3. modulation_offset: Sum of all active modulators (LFO/Envelope)

    effective_value = clamp(automation_value or base_value + modulation_offset)

    Thread safety: All writes happen in GUI thread. Audio thread reads
    the final value from RTParamStore (set by AutomationManager.tick()).
    """

    def __init__(
        self,
        parameter_id: str,
        name: str,
        min_val: float = 0.0,
        max_val: float = 1.0,
        default_val: float = 0.0,
        track_id: str = "",
        display_format: str = "{:.2f}",
        unit: str = "",
        is_discrete: bool = False,
    ):
        self.parameter_id = parameter_id
        self.name = name
        self.min_val = min_val
        self.max_val = max_val
        self.default_val = default_val
        self.track_id = track_id
        self.display_format = display_format
        self.unit = unit
        self.is_discrete = is_discrete

        self._base_value = default_val
        self._automation_value: Optional[float] = None
        self._modulation_offset = 0.0
        self._modulation_sources: Dict[str, float] = {}  # source_id -> offset

        # Callbacks notified when effective value changes
        self._listeners: List[Callable[[float], None]] = []

    @property
    def base_value(self) -> float:
        return self._base_value

    def set_value(self, value: float) -> None:
        """Set base value from GUI interaction."""
        self._base_value = self._clamp(value)
        self._notify()

    def set_automation_value(self, value: Optional[float]) -> None:
        """Set from timeline automation playback. None = no automation active."""
        if value is not None:
            self._automation_value = self._clamp(value)
        else:
            self._automation_value = None
        self._notify()

    def add_modulation(self, source_id: str, offset: float) -> None:
        """Add/update a modulation source offset (Bitwig-style)."""
        self._modulation_sources[source_id] = offset
        self._recalc_modulation()

    def remove_modulation(self, source_id: str) -> None:
        """Remove a modulation source."""
        self._modulation_sources.pop(source_id, None)
        self._recalc_modulation()

    def _recalc_modulation(self) -> None:
        self._modulation_offset = sum(self._modulation_sources.values())
        self._notify()

    @property
    def modulation_offset(self) -> float:
        return self._modulation_offset

    def get_effective_value(self) -> float:
        """The final output value (base or automation + modulation)."""
        base = self._automation_value if self._automation_value is not None else self._base_value
        return self._clamp(base + self._modulation_offset)

    def get_normalized(self) -> float:
        """Effective value as 0..1 normalized."""
        span = self.max_val - self.min_val
        if span <= 0:
            return 0.0
        return (self.get_effective_value() - self.min_val) / span

    def from_normalized(self, norm: float) -> float:
        """Convert 0..1 to parameter range."""
        return self.min_val + max(0.0, min(1.0, norm)) * (self.max_val - self.min_val)

    def get_display_value(self) -> str:
        """Formatted string for UI display."""
        try:
            return self.display_format.format(self.get_effective_value()) + self.unit
        except Exception:
            return str(self.get_effective_value())

    def add_listener(self, callback: Callable[[float], None]) -> None:
        if callback not in self._listeners:
            self._listeners.append(callback)

    def remove_listener(self, callback: Callable[[float], None]) -> None:
        try:
            self._listeners.remove(callback)
        except ValueError:
            pass

    def _clamp(self, value: float) -> float:
        v = max(self.min_val, min(self.max_val, float(value)))
        if self.is_discrete:
            v = round(v)
        return v

    def _notify(self) -> None:
        val = self.get_effective_value()
        for cb in self._listeners:
            try:
                cb(val)
            except Exception:
                pass


class AutomationManager(QObject):
    """Central automation routing service.

    Responsibilities:
    - Registry of all AutomatableParameters
    - Registry of AutomationLanes (timeline breakpoint data)
    - Signal hub: requestShowAutomation(parameter_id) from any widget
    - Tick function: called per playback frame to apply automation

    Usage from widget:
        # Widget fires signal:
        automation_manager.request_show_automation.emit(param.parameter_id)
        # AutomationLanePanel catches it and opens the lane

    Modular: Does NOT depend on ArrangerCanvas or specific widgets.
    """

    # Signal: a widget requests to show automation for parameter_id
    request_show_automation = pyqtSignal(str)  # parameter_id
    # Signal: a parameter's effective value changed
    parameter_changed = pyqtSignal(str, float)  # parameter_id, new_value
    # Signal: automation lane data changed
    lane_data_changed = pyqtSignal(str)  # parameter_id

    def __init__(self, parent: QObject = None):
        super().__init__(parent)
        self._parameters: Dict[str, AutomatableParameter] = {}
        self._lanes: Dict[str, AutomationLane] = {}

    # --- Parameter registration ---

    def register_parameter(
        self,
        parameter_id: str,
        name: str,
        min_val: float = 0.0,
        max_val: float = 1.0,
        default_val: float = 0.0,
        track_id: str = "",
        **kwargs,
    ) -> AutomatableParameter:
        """Register (or retrieve) an automatable parameter."""
        if parameter_id in self._parameters:
            return self._parameters[parameter_id]
        param = AutomatableParameter(
            parameter_id=parameter_id,
            name=name,
            min_val=min_val,
            max_val=max_val,
            default_val=default_val,
            track_id=track_id,
            **kwargs,
        )
        param.add_listener(lambda v, pid=parameter_id: self.parameter_changed.emit(pid, v))
        self._parameters[parameter_id] = param
        return param

    def get_parameter(self, parameter_id: str) -> Optional[AutomatableParameter]:
        return self._parameters.get(parameter_id)

    def get_parameters_for_track(self, track_id: str) -> List[AutomatableParameter]:
        return [p for p in self._parameters.values() if p.track_id == track_id]

    def unregister_parameter(self, parameter_id: str) -> None:
        self._parameters.pop(parameter_id, None)
        self._lanes.pop(parameter_id, None)

    # --- Lane management ---

    def get_or_create_lane(self, parameter_id: str, track_id: str = "", param_name: str = "") -> AutomationLane:
        if parameter_id in self._lanes:
            return self._lanes[parameter_id]
        lane = AutomationLane(
            parameter_id=parameter_id,
            track_id=track_id or (self._parameters.get(parameter_id, None) or AutomatableParameter("", "")).track_id,
            param_name=param_name or (self._parameters.get(parameter_id, None) or AutomatableParameter("", "")).name,
        )
        self._lanes[parameter_id] = lane
        return lane

    def get_lane(self, parameter_id: str) -> Optional[AutomationLane]:
        return self._lanes.get(parameter_id)

    def get_lanes_for_track(self, track_id: str) -> List[AutomationLane]:
        return [l for l in self._lanes.values() if l.track_id == track_id]

    def remove_lane(self, parameter_id: str) -> None:
        self._lanes.pop(parameter_id, None)

    # --- Playback tick ---

    def tick(self, beat: float) -> None:
        """Called per playback frame. Applies automation values from lanes to parameters.

        This is called from the GUI thread (via transport timer), NOT from the audio thread.
        The RTParamStore bridge (in AutomationPlaybackService) writes to the audio thread.
        """
        for pid, lane in self._lanes.items():
            if not lane.enabled or not lane.points:
                continue
            param = self._parameters.get(pid)
            if param is None:
                continue
            # Sample the lane at current beat
            norm_val = lane.interpolate(beat)
            if norm_val is not None:
                # Lane values are normalized 0..1 — convert to param range
                actual = param.from_normalized(norm_val)
                param.set_automation_value(actual)

    def clear_automation_values(self) -> None:
        """Clear all automation overrides (e.g. when transport stops)."""
        for param in self._parameters.values():
            param.set_automation_value(None)

    # --- Serialization (to/from project) ---

    def export_lanes(self) -> Dict[str, dict]:
        """Export all lanes as JSON-safe dict."""
        return {pid: lane.to_dict() for pid, lane in self._lanes.items()}

    def import_lanes(self, data: Dict[str, dict]) -> None:
        """Import lanes from project data."""
        self._lanes.clear()
        if not isinstance(data, dict):
            return
        for pid, lane_data in data.items():
            if isinstance(lane_data, dict):
                try:
                    self._lanes[str(pid)] = AutomationLane.from_dict(lane_data)
                except Exception:
                    continue

    # --- Legacy bridge (for existing automation_lanes dict) ---

    def import_legacy_lanes(self, automation_lanes: dict) -> None:
        """Import from old Project.automation_lanes format.

        Old format: automation_lanes[track_id][param_name] = [{"beat": ..., "value": ...}, ...]
        New format: _lanes[parameter_id] = AutomationLane(...)
        """
        if not isinstance(automation_lanes, dict):
            return
        for track_id, params in automation_lanes.items():
            if not isinstance(params, dict):
                continue
            for param_name, points_data in params.items():
                pid = f"trk:{track_id}:{param_name}"
                pts = []
                if isinstance(points_data, list):
                    for p in points_data:
                        if isinstance(p, dict):
                            pts.append(BreakPoint(
                                beat=float(p.get("beat", 0.0)),
                                value=float(p.get("value", 0.0)),
                            ))
                elif isinstance(points_data, dict) and "points" in points_data:
                    # Newer sub-format with points key
                    for p in points_data.get("points", []):
                        if isinstance(p, dict):
                            pts.append(BreakPoint(
                                beat=float(p.get("beat", 0.0)),
                                value=float(p.get("value", 0.0)),
                            ))
                if pts:
                    lane = AutomationLane(
                        parameter_id=pid,
                        track_id=str(track_id),
                        param_name=str(param_name),
                        points=pts,
                    )
                    lane.sort_points()
                    self._lanes[pid] = lane
