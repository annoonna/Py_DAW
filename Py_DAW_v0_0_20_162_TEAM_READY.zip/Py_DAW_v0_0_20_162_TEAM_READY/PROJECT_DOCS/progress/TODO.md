## v0.0.20.160 — Lasso-Selektion + Per-Event Reverse + Ctrl+J ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (Anthropic) (2026-02-28) ✅ DONE  
**Priority:** 🔴 CRITICAL (User-Report: Reverse dreht alle Events, Lasso fehlt)  
**Status:** ✅ FERTIG  

**Implementiert:**
1) **Lasso/Rubber-Band Selektion** im Zeiger-Tool (RubberBandDrag)
2) **Per-Event Reverse:** AudioEvent.reversed + Context-Menü per Event + Playback + Waveform Visual
3) **Ctrl+J Shortcut** für Consolidate/Zusammenführen
4) **Copy/Paste** erhält per-event reversed Feld

**Files:** `project.py`, `audio_event_editor.py`, `cliplauncher_playback.py`, `VERSION`, `version.py`

---

## v0.0.20.162 — Audio Editor: Ctrl+J = "Clip aus Auswahl" (Events bleiben 1:1) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-03-01) ✅ DONE  
**Priority:** 🔴 CRITICAL (User-Report: Ctrl+J macht aus 9 Events nur 1 Sample)  
**Status:** ✅ FERTIG  

**Problem:**
- Im Audio Editor wurden mehrere selektierte AudioEvents (z.B. 9 Hits) via **Ctrl+J** auf **1 AudioEvent** reduziert.
- Erwartung wie Bitwig/Ableton: **"Glue/Consolidate to Clip"** → ein **Clip-Container**, aber **Events bleiben erhalten**.

**Lösung (safe, non-destructive, nichts kaputt):**
1) Neuer ProjectService-API-Call: `join_audio_events_to_new_clip(...)`
   - erzeugt **NEUEN** Audio-Clip aus selektierten Events
   - Clip-Länge wird **bar-genau** aus Auswahl abgeleitet (z.B. **2 Bars**)
   - Events werden **1:1 kopiert** (Anzahl bleibt identisch), nur Startzeiten werden auf Clip-Start (0) geshiftet
   - wenn Clip im **Clip-Launcher** liegt, wird der Slot auf den neuen Clip umgebogen (alter Clip bleibt im Projekt)
2) AudioEventEditor Ctrl+J wired auf `join_audio_events_to_new_clip` (mit Fallback auf altes Merge-Verhalten)

**Files:**
- `pydaw/services/project_service.py`
- `pydaw/ui/audio_editor/audio_event_editor.py`
- `VERSION`, `pydaw/version.py`, `pydaw/model/project.py`

---

## v0.0.20.161 — Clip-Automation Playback (Pencil-Envelopes im Playback) [ ] AVAILABLE
**Assignee:** [ ] AVAILABLE  
**Priority:** 🔴 CRITICAL  
**Status:** OFFEN  

**Beschreibung:**
- `clip.clip_automation` (Pitch/Gain/Pan Envelopes gezeichnet mit Pencil-Tool) wird im `ClipLauncherPlaybackService._mix_events_segment()` NICHT ausgewertet.
- Nur der statische Clip-Level Wert `v.pitch` wird genutzt → Pencil-Automation hat keinen hörbaren Effekt.
- **Task:** Breakpoints aus `clip.clip_automation` im Audio-Rendering interpolieren und pro Frame anwenden.

**Files:** `cliplauncher_playback.py`, `arrangement_renderer.py`

---

## v0.0.20.159 — Audio Editor: Ruler Rechtsklick-Loop + Clip-Länge Auto-Extend + Waveforms pro Event ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-28) ✅ DONE  
**Priority:** 🔴 CRITICAL (Bitwig/Ableton Clip-Editor UX)  
**Status:** ✅ FERTIG  

**User-Report (Screenshots):**
- Loop lässt sich im Audio-Editor nicht wie im Arranger per Rechtsklick-Drag im Ruler setzen.
- Sample wirkt "fest" bei Bar 1 → Verschieben/Duplizieren im Audio Editor wirkt kaputt.

**Implementiert (safe, nichts kaputt):**
1) **Ruler Parity:** Rechtsklick+Drag im Audio-Editor-Ruler zeichnet Loop.
2) **Auto-Extend:** Loop über Clip-Ende hinaus erweitert Editor-Länge live, Commit per `resize_clip(...)` beim Loslassen.
3) **Waveform pro Event:** Waveform hängt als Child-Item am EventBlock → Move/Duplicate zeigt echte Kopien.

**Files (GEÄNDERT):**
- `pydaw/ui/audio_editor/audio_event_editor.py`
- `VERSION`, `pydaw/version.py`, `pydaw/model/project.py`

---

## v0.0.20.158 — Audio Editor: Playhead Sync + Loop Draw + Lupe/Zoom + Zeiger=Select ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-28) ✅ DONE  
**Priority:** 🔴 CRITICAL (Bitwig/Ableton Clip-Editor UX)  
**Status:** ✅ FERTIG  

**User-Report (Screenshots):**
- Im **Audio Editor** läuft beim Abspielen **keine rote Playhead-Linie**.
- **Loop lässt sich nicht einzeichnen** (User ist im Zeiger-Tool).
- **Keine Lupe/Zoom-Geste** wie Bitwig (Beat-Ruler Magnifier).
- **Copy/Paste/Duplicate** fühlte sich kaputt an, weil Zeiger keine Audio-Events selektiert.

**Implementiert (safe, nichts kaputt):**
1) **Transport → Audio Editor Playhead Sync**
   - `transport.playhead_changed` wired → Audio Editor zeichnet **rote Playhead-Linie** im Clip (lokal, Loop-Wrap).
   - Playhead-Linie wird nach `refresh()` neu angelegt (Scene-Rebuild safe).
2) **Loop zeichnen ohne Tool-Wechsel**
   - **Alt+Drag im Editor** setzt/zieht die Loop-Region (funktioniert auch im Zeiger).
   - **Alt+Drag im Ruler** setzt/zieht ebenfalls die Loop-Region.
   - Tool-Label: **"Loop"** (intern TIMESELECT).
3) **Lupe / Zoom wie Bitwig**
   - Neues Tool **Lupe** + Drag-Up/Down Zoom (AnchorUnderMouse).
   - Beat-Ruler unterstützt Zoom-Geste (vertikal ziehen).
4) **Zeiger = DAW-Pointer (Select/Move)**
   - Audio-Event-Blöcke sind jetzt im **Zeiger** selektier-/movbar (POINTER oder ARROW).
   - Damit funktionieren Copy/Paste/Duplicate Workflows wie erwartet.
5) **Waveform-Tiling korrekt (kein Stretch-to-fit)**
   - Mapping Beat→Sekunden→Samples (BPM + offset_seconds + stretch), Loop-Wrap zeigt echte Wiederholung.

**Files (GEÄNDERT):**
- `pydaw/ui/audio_editor/audio_event_editor.py`
- `pydaw/services/transport_service.py`
- `VERSION`, `pydaw/version.py`, `pydaw/model/project.py`

---

## v0.0.20.157 — Clip Launcher: Click=Editor (kein Auto-Play) + In-Slot ▶ Launch-Button + Audio Editor: Loop-Tiling sichtbar ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-28) ✅ DONE  
**Priority:** 🔴 CRITICAL (Bitwig/Ableton UX)  
**Status:** ✅ FERTIG  

**User-Report:**
- Klick auf Slot im Clip Launcher startet sofort Playback/Arranger → **falsch** (User will erst in den Editor).
- In Bitwig/Ableton gibt es **einen kleinen ▶-Button im Slot** zum Launch.
- Clip-Loop soll im **Audio Editor** wie im Referenz-Screenshot sichtbar **wiederholt** werden.

**Implementiert (safe, nichts kaputt):**
1) **Clip Launcher Slot UX (Bitwig-Style):**
   - **Single-Click:** nur auswählen + Editor öffnen (**kein Launch**).
   - **In-Slot ▶-Button (Hotzone oben rechts):** launcht den Clip.
   - **Click-Suppression:** ▶-Click unterdrückt `QPushButton.clicked`, damit kein accidental Launch passiert.
2) **Audio Editor Waveform Loop-Tiling:**
   - Background-Waveform wird jetzt in Beat-Domain **durch die Loop-Region gewrappt** (tiled),
     sodass kurze Samples optisch wie bei Bitwig/Ableton über die Clip-Länge wiederholt erscheinen.
   - Update passiert automatisch bei Loop-Edge-Drag & Zoom/Repaint.

**Files (GEÄNDERT):**
- `pydaw/ui/clip_launcher.py`
- `pydaw/ui/audio_editor/audio_event_editor.py`
- `VERSION`, `pydaw/version.py`, `pydaw/model/project.py`

---

## v0.0.20.156 — Audio Editor: 3 kritische Bugfixes (Cursor/Paste, Loop-Anzeige, Zoom-Repaint) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (Anthropic) (2026-02-28) ✅ DONE
**Priority:** 🔴 CRITICAL (Bugfix)
**Status:** ✅ FERTIG

**Bugs gefixt:**
1. **Click im Editor-Hintergrund setzte Cursor nicht** → `itemAt()` gab Grid-Linien zurück, Check war `is None` statt Type-Check
2. **Loop-Region im Ruler nicht sichtbar** → las `clip.loop_start` (existiert nicht), richtig: `clip.loop_start_beats`
3. **Zoom-Buttons kein Ruler-Repaint** → `view_changed.emit()` fehlte in `_on_zoom_in/_on_zoom_out`

**Bonus:** Background-Click jetzt mit Snap-to-Grid + setzt Playhead + Cursor

**Files (GEÄNDERT):**
- `pydaw/ui/audio_editor/audio_event_editor.py`
- `VERSION`, `pydaw/version.py`, `pydaw/model/project.py`

---

## v0.0.20.155 — Audio Editor: Arranger-Parity (Ruler, Playhead, Loop, Zoom, Clipboard, Ctrl+Drag) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (Anthropic) (2026-02-28) ✅ DONE
**Priority:** 🔴 HIGH (Core DAW UX)
**Status:** ✅ FERTIG

**User-Report:** Audio Editor fehlten alle Arranger-Features (Playhead, Zoom, Loop, Clipboard, Ctrl+Drag)
**Lösung:** AudioEditorRuler komplett überarbeitet (+310 Zeilen), Playhead/Cursor/Loop/Zoom/Context-Menü implementiert

**Files (GEÄNDERT):**
- `pydaw/ui/audio_editor/audio_event_editor.py`
- `VERSION`, `pydaw/version.py`, `pydaw/model/project.py`

**NÄCHSTE SCHRITTE (für Kollegen, EIN Task pro Person):**
- [ ] AVAILABLE — Audio Editor: Waveform-Darstellung verbessern (Peak-Normalisierung, Farb-Gradient)
- [ ] AVAILABLE — Audio Editor: Snap-to-Grid visuelles Feedback (Gridlines bei Drag)
- [ ] AVAILABLE — Audio Editor: Time-Stretch Handle (Event-Enden ziehen = Stretch)
- [ ] AVAILABLE — Audio Editor: Multi-Track Overlay (mehrere Clips überlagert anzeigen)

---

## v0.0.20.151 — Clip Launcher: Queued-State Indicator (gelb/gestrichelt) für quantized Launch ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-28) ✅ DONE  
**Priority:** 🔴 HIGH (Bitwig-Clone UX)  
**Status:** ✅ FERTIG  

**User-Referenz (Bitwig Screenshots):**
- In Bitwig/Ableton sieht man *queued/armed* Clips (vor Quantize-Fire) visuell, getrennt von *playing*.

**Implementiert (safe, minimal, nichts kaputt):**
- **Queued-State** für Clip-Launcher-Slots (UI-only):
  - **gelb / gestrichelter Rahmen** + kleines Triangle-Outline für *queued*
  - Play-State bleibt **Highlight + ▶** (playing überschreibt queued)
- **LauncherService** emittiert jetzt Pending-Queue (UI-only):
  - neues Signal: `LauncherService.pending_changed`
  - neue Methode: `pending_snapshot()`
- ClipLauncherPanel cached `queued_slots`/`queued_scenes` und repainted Grid
- Optional: Scene-Header bekommt **gestrichelten gelben Rahmen**, wenn Scene queued ist

**Files (GEÄNDERT):**
- `pydaw/services/launcher_service.py`
- `pydaw/ui/clip_launcher.py`
- `VERSION`, `pydaw/version.py`

**NÄCHSTE SCHRITTE (für Kollegen, EIN Task pro Person):**
- [ ] **Queued Countdown (optional)**: Restzeit bis Fire (kleine Anzeige: z.B. 0.5 Bar) (UI-only)
- [ ] **Scene Launch/Stop UX**: Scene-Header zeigt Stop/Status + Kontextmenü (UI-only)
- [ ] **Track Header erweitert**: Mini-Meter + Stop-Button pro Track (UI-only)
- [ ] **ALT Actions / ALT Quantize**: echte ALT-Overrides (Engine-Wiring)
- [ ] **Follow Actions Engine**: Next Action Timing/Probability (Playback-Logic)

---

## v0.0.20.150 — Clip Launcher: Play-State Indicator (Playing Highlight + ▶) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-28) ✅ DONE  
**Priority:** 🔴 HIGH (Bitwig-Clone UX)  
**Status:** ✅ FERTIG  

**User-Referenz (Bitwig Screenshots):**
- Spielende Clips sind in der Launcher-Grid sichtbar markiert (Highlight + ▶), ohne dass man raten muss.

**Implementiert (safe, minimal, nichts kaputt):**
- Slot-Zellen zeigen jetzt **Play-State** (UI-only):
  - **Highlight-Rahmen** (Theme-Highlight Farbe)
  - kleines **▶** oben links
- **Signal-Wiring** von Playback → UI:
  - `ClipLauncherPlaybackService.active_slots_changed`
  - `ProjectService.cliplauncher_active_slots_changed`
  - UI cached `active_slots` und repainted die Grid
- **Fix (compat):** `launch_scene()` nutzt jetzt Slot-Key Format `scene:<idx>:track:<id>` (war inkonsistent)

**Files (GEÄNDERT):**
- `pydaw/ui/clip_launcher.py`
- `pydaw/services/cliplauncher_playback.py`
- `pydaw/services/project_service.py`
- `VERSION`, `pydaw/version.py`

**NÄCHSTE SCHRITTE (für Kollegen, EIN Task pro Person):**
- [ ] **Queued-State Indicator** (gelb/gestrichelt) für quantized „armed“ Clips (UI-only)
- [ ] **Scene Launch/Stop UX**: Scene-Header zeigt Stop/Status + Kontextmenü (UI-only)
- [ ] **Track Header erweitert**: Mini-Meter + Stop-Button pro Track (UI-only)
- [ ] **ALT Actions / ALT Quantize**: echte ALT-Overrides (Engine-Wiring)
- [ ] **Follow Actions Engine**: Next Action Timing/Probability (Playback-Logic)

---

## v0.0.20.149 — Clip Launcher: Bitwig-Grid (Scenes als Spalten, Tracks als Zeilen) + Track-Header + Clip-Farb-Tint ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-28) ✅ DONE  
**Priority:** 🔴 HIGH (Bitwig-Clone UX)  
**Status:** ✅ FERTIG  

**User-Referenz (Bitwig Screenshots):**
- In Bitwig sind **Scenes Spalten** („Scene 1, Scene 2, …“) und **Tracks Zeilen** („Audio 1, Inst 2, …“).
- Track-Header (M/S/R) sitzt **links** im Grid; Scene-Header oben.
- Clip-Zellen sind farblich getintet (Clip-Farbe) und die ZELLE-Inspector-Controls sollen vollständig sichtbar sein.

**Implementiert (safe, kein Engine-Bruch):**
- Clip-Launcher-Grid wurde auf **Bitwig/Ableton-Orientierung** umgestellt:
  - **Spalten = Scenes (1..N)**, **Zeilen = Tracks**
  - Slot-Key-Format bleibt identisch: `scene:<idx>:track:<id>` (keine Projekt-Datenmigration nötig)
- Neuer **Track-Header** im Grid (links): Name + **Mute/Solo/RecordArm** Buttons (ruft vorhandene ProjectService-Setter auf)
- Slot-Zellen zeigen jetzt eine **Clip-Farb-Tönung** (aus `clip.launcher_color`) → Bitwig-Feeling, UI-only
- Inspector: Clip-Name hat jetzt optional einen **Preview/Play-Button** (▶) (safe: nutzt `cliplauncher_launch_immediate`)

**Files (GEÄNDERT):**
- `pydaw/ui/clip_launcher.py`
- `pydaw/ui/clip_launcher_inspector.py`
- `pydaw/version.py`

**NÄCHSTE SCHRITTE (für Kollegen, EIN Task pro Person):**
- [x] **Play-State Indicator** im Slot (Triangle/Highlight wenn Slot aktiv spielt) + Repaint-Loop (UI-only) (DONE in v0.0.20.150)
- [ ] **Scene Launch/Stop UX**: Scene-Header zeigt „▶“/Stop-Status + Kontextmenü (UI-only)
- [ ] **Track Header erweitert**: Mini-Meter + Stop-Button pro Track (UI-only)
- [ ] **ALT Quantize/ALT Actions**: echte ALT-Overrides (Model already vorhanden; Engine-Wiring)
- [ ] **Follow Actions Engine**: Next Action Timing/Probability (Model existiert; Playback-Logic)

---

## v0.0.20.148 — Clip Launcher: ZELLE Inspector frei skalierbar + einklappbar (UI-only) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-28) ✅ DONE
**Priority:** 🔴 HIGH (UX)
**Status:** ✅ FERTIG

**User-Problem (Screenshots):**
- ZELLE/Inspector-Spalte war **zu schmal** (geklemmt) und ließ sich nicht „wie in echter DAW“ aufziehen.
- Gewünscht: **gesamte Ansicht**, optional **Scroll**, und **einklappen/ausklappen**.

**Fix (safe, UI-only, nichts kaputt):**
- Clip Launcher Inspector ist jetzt **wirklich resizable** (keine harte Max-Breite mehr).
- Neuer Header-Button (Pfeil) zum **Einklappen/Ausklappen**.
- **Persistenz** via QSettings:
  - Sichtbarkeit (`ui/cliplauncher_inspector_visible`)
  - Letzte Breite (`ui/cliplauncher_inspector_width`)
- Inspector erlaubt bei sehr kleiner Breite optional **horizontalen Scroll** (AsNeeded).

**Files (GEÄNDERT):**
- `pydaw/ui/clip_launcher.py`
- `pydaw/ui/clip_launcher_inspector.py`
- `pydaw/core/settings.py`
- `VERSION`, `pydaw/version.py`

---

## v0.0.20.147 — Bitwig-Style Clip Launcher Inspector (ZELLE Panel) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (Anthropic) (2026-02-28) ✅ DONE
**Priority:** 🔴 HIGH (Feature)
**Status:** ✅ FERTIG

**Was gebaut wurde:**
- Bitwig-Style ZELLE (Cell) Inspector Panel als linke Sidebar im Clip Launcher
- Per-Clip Launcher Properties im Datenmodell (Quantize, Playback, Release, Next Action, etc.)
- Inspector zeigt alle Clip-Properties wenn ein Launcher-Slot angeklickt wird
- Per-Clip Quantize Override in LauncherService
- Farbpalette, Shuffle/Accent, Expressions (Volume/Pan/Pitch mit +/- Buttons)

**Files (GEÄNDERT/NEU):**
- `pydaw/ui/clip_launcher_inspector.py` (NEU, 530+ Zeilen)
- `pydaw/model/project.py` (+30 Zeilen)
- `pydaw/ui/clip_launcher.py` (refactored)
- `pydaw/services/launcher_service.py` (+30 Zeilen)
- `VERSION`, `pydaw/version.py`

**Nächste Tasks (CLIP LAUNCHER ROADMAP):**
- [ ] AVAILABLE — Phase 2.1: Play State Indicators (grün=playing, gelb=queued)
- [ ] AVAILABLE — Phase 2.2: Per-Clip Quantize Engine (Multi-Bar: 8/4/2 Takte, fractional: 1/2..1/16)
- [ ] AVAILABLE — Phase 2.3: Playback Modes (Legato vom Clip, Legato vom Projekt)
- [ ] AVAILABLE — Phase 2.4: Stop Button per Track (unter Track-Header)
- [ ] AVAILABLE — Phase 3.1: Release Actions (Fortsetzen, Zurück, Nächste Aktion)
- [ ] AVAILABLE — Phase 3.2: Next Action System (Next/Prev/Random/Round-robin)
- [ ] AVAILABLE — Phase 4.1: Record into Empty Slot (Audio + MIDI)
- [ ] AVAILABLE — Phase 4.2: Capture to Arranger

**Siehe:** `PROJECT_DOCS/plans/CLIP_LAUNCHER_MASTER_PLAN.md` für Details

---

## v0.0.20.146 — Audio Editor → Arranger: Slice-Export zieht falsches Stück (OffsetSeconds Fix) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-28) ✅ DONE
**Priority:** 🔴 CRITICAL (Workflow-Blocker)
**Status:** ✅ FERTIG

**Problem (User):**
- Nach dem Schneiden im Audio-Editor und Drag nach oben in den Arranger wurde **immer der Anfang des gesamten Samples** erstellt.
- Erwartet: genau das selektierte Segment (Slice/Event) soll als neuer Clip im Arranger landen.

**Root Cause:**
- `arrangement_renderer.py` nutzt bei Audio-Clips aktuell **clip.offset_seconds** (nicht `offset_beats`).
- Slice-Export hat nur `offset_beats`/`audio_events` gepflegt → Renderer/Arranger-Preview starteten immer bei 0s.

**Fix (safe, minimal):**
- Slice-Export setzt jetzt **offset_seconds** korrekt aus der Selektion.
  - Mapping über `seconds_per_beat = file_duration_seconds / src_clip.length_beats` (stabil für raw audio + tempo-synced loops).
- Exportierter Slice wird als **ein konsolidiertes AudioEvent** (Start 0, Länge = Slice) gespeichert.
  - Zukunftssicher: wenn Renderer später AudioEvents direkt nutzt.

**Files (GEÄNDERT):**
- `pydaw/services/project_service.py`
- `pydaw/version.py`, `pydaw/model/project.py`, `VERSION`
- `PROJECT_DOCS/sessions/LATEST.md`

---

## v0.0.20.145 — Audio Editor: Slices schneiden + in Arranger ziehen (DAW Workflow) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-28) ✅ DONE
**Priority:** 🔴 HIGH (Workflow-Blocker)
**Status:** ✅ FERTIG

**Problem (User):**
- Im Audio-Editor konnte man nicht sinnvoll schneiden (Cutpoints nicht klar) und geschnittene Segmente nicht in den Arranger ziehen.
- Erwartetes DAW-Verhalten: schneiden → Segment greifen → in Timeline/Audio-Spur ziehen (Ableton/Bitwig-Style).

**Fix:**
- Slice-Linien (Events→Slices) deutlich sichtbarer gerendert.
- Neuer Drag&Drop-Workflow Audio-Editor → Arranger:
  - Arrow: Segment(e) markieren → nach oben aus dem Editor ziehen → im Arranger droppen.
  - Arranger erstellt neuen Audio-Clip aus den selektierten AudioEvents (non-destructive) inkl. Clip-Edits + Warp/Automation (best-effort).

**Files (GEÄNDERT):**
- `pydaw/ui/audio_editor/audio_event_editor.py`
- `pydaw/ui/arranger_canvas.py`
- `pydaw/services/project_service.py`
- `pydaw/version.py`, `pydaw/model/project.py`, `VERSION`
- `PROJECT_DOCS/sessions/LATEST.md`

---

## v0.0.20.144 — Arranger: Audio-Waveform Preview (sichtbar + Multi-Format) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-28) ✅ DONE
**Priority:** 🔴 HIGH (Workflow-Blocker)
**Status:** ✅ FERTIG

**Problem (User):**
- Audio-Waveform im Arranger praktisch nicht sichtbar → man sieht keine Cutpoints.
- Bei kleinen Track-Höhen wird gar keine Waveform gezeichnet.
- Waveform-Preview soll auch für Formate funktionieren, die soundfile nicht liest (MP3/M4A/MP4…).

**Fix:**
- Visuelles Normalizing (UI-only) + höherer Kontrast.
- Dynamische Preview-Area für kleine Track-Höhen.
- Decode-Fallback: soundfile → optional pydub/ffmpeg.

**Files (GEÄNDERT):**
- `pydaw/ui/arranger_canvas.py`
- `pydaw/version.py`, `pydaw/model/project.py`, `VERSION`

---

## v0.0.20.143 — Arranger: Playhead-Seek/Drag + Ctrl-Drag Copy Preview + Performance-Fix (CRITICAL UX) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-28) ✅ DONE
**Priority:** 🔴 HIGH (Workflow-Blocker)
**Status:** ✅ FERTIG

**Problem (User):**
- Playhead (rote Linie) nicht greifbar → kein Seek auf Bar 5/6, Ctrl+V fühlt sich „kaputt“ an.
- Lasso → Ctrl+LMB-Drag Copy wie echte DAW (Ableton/Bitwig) fehlte / war instabil.
- GUI-Freeze bei großen Projekten (Bar 100+ / 500+) durch teure Paint-Loops.

**Fix:**
- Playhead seek/drag: im unteren Linealbereich + direkt auf der roten Linie (Shift = kein Snap).
- Ctrl+Drag: Copy-Preview (Ghost folgt, Original bleibt), Multi-Clip (Lasso) wird als Gruppe kopiert.
- Performance: paintEvent rendert nur im sichtbaren ClipRect (Viewport) + Playhead-Partial-Update.

**Files (GEÄNDERT):**
- `pydaw/ui/arranger_canvas.py`
- `pydaw/version.py`, `pydaw/model/project.py`, `VERSION`
- `PROJECT_DOCS/sessions/LATEST.md`, Session-Log

---

## v0.0.20.142 — Arranger: Multi-Clip Copy/Paste an Playhead + GUI-Freeze Fix (CRITICAL UX) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-28) ✅ DONE
**Priority:** 🔴 HIGH (Workflow-Blocker)
**Status:** ✅ FERTIG

**Problem (User):**
- Mehrere Clips auswählen → an Bar 5/6 „kopieren/einfügen“ führte zu **GUI-Freeze** ("python3 antwortet nicht").
- Zusätzlich war Ctrl+V faktisch kaputt: Paste passierte immer bei **Beat 0** statt am Playhead → Clips rasten nicht an der gewünschten Bar ein.

**Fix:**
- `ArrangerKeyboardHandler` bekommt jetzt **Playhead + Snap-Grid Kontext** vom `ArrangerCanvas`.
- **Ctrl+V** pastet an den **aktuellen Playhead** (Bar 5/6 funktioniert).
- **Ctrl+Shift+V** pastet **ohne Snap** (Feinplatzierung).
- **Freeze-Fix:** MIDI-Noten werden beim Paste **bulk** kopiert (deepcopy Liste) und Clips werden **batched** ins Projekt gemerged → keine per-Note `_emit_updated()`-Stürme mehr.
- Copy/Paste preserviert jetzt *vollständig* die Clip-Daten (Audio-Params, Automation, Warp-Marker, etc.), weil der Clip als Ganzes deepcopy'd wird.

**Files (GEÄNDERT):**
- `pydaw/ui/arranger_keyboard.py`
- `pydaw/ui/arranger_canvas.py`
- `pydaw/version.py`, `pydaw/model/project.py`, `VERSION`

---

## v0.0.20.141 — Audio Editor: Zeiger (Pointer) repariert + Warp-Marker (Stretch) (CRITICAL UX) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-28) ✅ DONE
**Priority:** 🔴 HIGH (Workflow-Blocker)
**Status:** ✅ FERTIG

**Problem (User):**
- Werkzeug **„Zeiger“** verhielt sich wie „Arrow“ → keine Bearbeitung von Automation-Punkten möglich.
- In Stretch-Overlay fehlten echte **Warp-Marker** (Bitwig-Style) → nur Hinweistext/SpinBox.

**Fix:**
- **Neues Tool „POINTER“** hinter „Zeiger“: Arrow bleibt für Audio-Events (Move/Group-Drag), Zeiger ist jetzt *Point-Edit*.
- **Automation-Punkte jetzt editierbar:** Breakpoints sind echte draggable Items (Drag = Beat+Value, Rechtsklick = Delete).
- **Stretch/Warp-Marker (pro Clip):**
  - Doppelklick im Editor (bei aktivem Stretch-Overlay) → Marker hinzufügen (Snap; Shift = kein Snap)
  - Drag → Marker verschieben (dst) / Rechtsklick → Marker löschen
  - Speicherung als JSON-safe dicts `{"src":..,"dst":..}` (Legacy float-Liste wird auto-upgegradet)
- **Playback-Integration:** Warp-Marker werden in `arrangement_renderer.prepare_clips()` als piecewise Time-Stretch angewandt (Output-Länge bleibt stabil).

**Files (GEÄNDERT):**
- `pydaw/ui/audio_editor/audio_event_editor.py`
- `pydaw/services/project_service.py`
- `pydaw/model/project.py`
- `pydaw/audio/arrangement_renderer.py`
- `pydaw/version.py`, `VERSION`

---

## v0.0.20.131 — Bitwig/Ableton-Style Projekt-Speicherung (CRITICAL FIX) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (Anthropic) (2026-02-22) ✅ DONE
**Priority:** 🔴 CRITICAL (Samples gingen verloren!)
**Status:** ✅ FERTIG

**Problem:** Sampler, DrumMachine und SF2 werden beim Laden nicht wiederhergestellt.
**Root Cause:** `import_audio_to_project()` fehlte → Samples nie in media/ importiert.
**Fix:**
- [x] Neue Methode `ProjectService.import_audio_to_project()` (fehlende API)
- [x] `_package_project_media()`: SF2 + instrument_state Samples ins Projekt kopieren
- [x] `_resolve_project_paths_after_load()`: SF2 + instrument_state Pfade auflösen
- [x] End-to-End Test: Save → Load → Alle Samples + SF2 korrekt wiederhergestellt

**Files:** project_service.py, file_manager.py, version.py, project.py, VERSION

---

- [x] AVAILABLE (GPT-5.2 Thinking, 2026-02-22) Hilfe → Arbeitsmappe: DevicePanel-Kürzel/Befehls-Legende ergänzen (ESC/Collapse/Batch-Icons ◪ ▾▾ ▸▸ ◎ N/I/A ↺), UI-only Doku-Polish.
  - `Shortcuts & Befehle` um Abschnitt **DevicePanel (Chain / Device-Ansicht)** erweitert
  - Klare Trennung: echte Tastatur (`Esc`) vs Header-Buttons (`N/I/A/◎/↺`)
  - Keine Änderungen an Audio/DSP/Engine/DnD; nur In-App-Dokumentation (`workbook_dialog.py`)
- [x] AVAILABLE (GPT-5.2 Thinking, 2026-02-22) DevicePanel: Header-Icons mit Mini-Legende/Popover direkt im UI (nicht nur Arbeitsmappe), UI-only.
  - Neuer kompakter Header-Button `?` im DevicePanel öffnet Kurzhilfe/Popover (QMenu) direkt im UI
  - Zeigt Batch-Icons, Fokus-/Reset-Bedienung sowie Hinweis zu `Esc` / Doppelklick / `▾/▸` pro Card
  - Rein visuell/UI-only; keine Audio/DSP/Engine/DnD/Projektmodell-Änderungen
- [ ] AVAILABLE — DevicePanel: Mini-Legende-Popup optional mit „In Arbeitsmappe öffnen" / Link-Hinweis erweitern, UI-only.
- [x] AVAILABLE (GPT-5.2 Thinking, 2026-02-22) DevicePanel: Header-Batch-Buttons mit Textlabels/Tooltip-Hinweisleiste verfeinern (N/I/A/◎/▾/▸) für bessere Entdeckbarkeit, UI-only.
  - Subtile Batch-Hinweiszeile im DevicePanel-Header ergänzt (Legend/Status)
  - Hover auf Batch-Buttons zeigt Aktionstext in der Hinweiszeile
  - Aktiver Fokusmodus (◎ / N / I / A) bleibt visuell markiert (Toggle-State)
  - UI-only: keine Audio/DSP-/Engine-/DnD-/Reorder-Änderungen
- [ ] AVAILABLE — DevicePanel: Collapsed-Minikarten visuell kompakter machen (Titel/Leerraum im eingeklappten Zustand weiter reduzieren), UI-only.
## v0.0.20.121 — DevicePanel Fokus-Batchaktion (UI-only) (DONE)

- [x] AVAILABLE (GPT-5.2 Thinking, 2026-02-22) DevicePanel Fokusansicht-Button (◎): nur fokussierte Card offen lassen (Fallback Instrument) (UI-only)
  - Kompakte Header-Aktion ergänzt (◎)
  - Nutzt bestehende Collapse-States der Device-Cards; nur UI-Status wird gesetzt
  - Fokusziel: selektierte FX-Card oder Instrument-Anchor-Fallback
  - Auto-Scroll zur Ziel-Card nach Batch-Aktion
  - Keine Audio/DSP-/Engine-/DnD-/Reorder-Änderungen

### Nächster sinnvoller Task (AVAILABLE)
- [ ] AVAILABLE: DevicePanel optional "Nur Zone fokussieren" (NOTE-FX / INSTRUMENT / AUDIO-FX) (UI-only)
- [ ] AVAILABLE: DevicePanel optional Card-Breiten-Pinning pro FX-Card (UI-only)

## v0.0.20.119 — DevicePanel Header-Zeile vereinheitlicht (UI-only) (DONE)

- [x] AVAILABLE (GPT-5.2 Thinking, 2026-02-22) DevicePanel Header-Zeile vereinheitlichen (Icon-Abstände / Titel-Clipping mit Elide) (UI-only)
  - Device-Card-Titel nutzt jetzt Elide (… ) statt in Header-Icons hinein zu laufen
  - Voller Titel als Tooltip bei Überlauf sichtbar
  - Header-Spacing/Margins vereinheitlicht (ruhigere Ausrichtung)
  - UI-only: keine Audio/DSP-/Engine-/DnD-/Reorder-/Insert-Änderungen

### Nächster sinnvoller Task (AVAILABLE)
- [ ] AVAILABLE: DevicePanel Batch-Aktionen optional als kompakte Icons + Tooltips (UI-only)
- [ ] AVAILABLE: DevicePanel optional „Alle einklappen“ zusätzlich zu „Inaktive einklappen / Alle ausklappen" (UI-only)

## v0.0.20.118 — DevicePanel Batch-Collapse/Expand Aktionen (DONE)

- [x] AVAILABLE (GPT-5.2 Thinking, 2026-02-22) DevicePanel "Collapse all inactive / Expand all" Komfortaktionen (UI-only)
  - Header-Aktionen ergänzt: „Inaktive einklappen“ + „Alle ausklappen“
  - Wirkt auf gerenderte Device-Cards (Note-FX / Instrument / Audio-FX), UI-only
  - Nutzt bestehende Collapse-States pro Card/Track weiter; keine Projektdatei-/DSP-Änderung
  - DnD/Reorder/Insert-Indizes unverändert (nur Collapse-Status der Card-Widgets)

### Nächster sinnvoller Task (AVAILABLE)
- [x] AVAILABLE (GPT-5.2 Thinking, 2026-02-22) DevicePanel Header-Zeile vereinheitlichen (Icon-Abstände / Titel-Clipping mit Elide) (UI-only)
  - Device-Card-Titel nutzt Elide (… ) statt in Header-Icons hinein zu laufen
  - Voller Titel als Tooltip bei Überlauf sichtbar
  - Header-Spacing/Margins vereinheitlicht (ruhigere Ausrichtung)
  - UI-only: keine Audio/DSP-/Engine-/DnD-/Reorder-/Insert-Änderungen
- [ ] AVAILABLE: DevicePanel Batch-Aktionen optional als kompakte Icons + Tooltips (UI-only)

## v0.0.20.117 — DevicePanel Zonen-Divider entschärft (DONE)

- [x] AVAILABLE (GPT-5.2 Thinking, 2026-02-22) UI-only Follow-up: störende blaue Zonen-Linie im DevicePanel entschärfen
  - Vertikale Divider nur noch im Kopfbereich (Badge-Zeile), nicht durch Device-Widgets
  - Divider nur anzeigen, wenn benachbarte Zone Devices enthält (kein Divider mehr im leeren Instrument-Anchor)
  - Divider-Farbe neutraler/subtiler gemacht (weniger visuell dominant)
  - Keine Audio/DSP-/Engine-/DnD-/Reorder-Änderungen

### Nächster sinnvoller Task (AVAILABLE)
- [x] AVAILABLE (GPT-5.2 Thinking, 2026-02-22) DevicePanel "Collapse all inactive / Expand all" Komfortaktionen (UI-only)
  - Header-Aktionen ergänzt: „Inaktive einklappen“ + „Alle ausklappen“
  - Wirkt auf gerenderte Device-Cards (Note-FX / Instrument / Audio-FX), UI-only
  - Nutzt bestehende Collapse-States pro Card/Track weiter; keine Projektdatei-/DSP-Änderung
  - DnD/Reorder/Insert-Indizes unverändert (nur Collapse-Status der Card-Widgets)
- [ ] AVAILABLE: DevicePanel Header-Zeile vereinheitlichen (Icon-Abstände / Titel-Clipping mit Elide) (UI-only)

## v0.0.20.116 — Device-Card Collapse / Kompaktmodus (DONE)

- [x] AVAILABLE (GPT-5.2 Thinking, 2026-02-22) DevicePanel: ein-/ausklappbare Device-Cards (UI-only)
  - Pro Device-Card (Note-FX / Instrument / Audio-FX) Collapse-Button im Header ergänzt
  - Double-Click auf Card-Header toggelt ebenfalls (Kompaktmodus)
  - Collapse-Zustand UI-seitig pro Card/Track gemerkt (keine Projektdatei-Änderung)
  - Nur inneres Widget wird ein-/ausgeblendet → DnD/Reorder/Insert-Indizes bleiben unverändert
  - Keine Audio/DSP-/Engine-/Preset-Änderungen

### Nächster sinnvoller Task (AVAILABLE)
- [ ] AVAILABLE: DevicePanel „Collapse all inactive / Expand all“ Komfortaktionen (UI-only)
- [ ] AVAILABLE: DevicePanel Header-Zeile vereinheitlichen (Icon-Abstände / Titel-Clipping mit Elide) (UI-only)

## v0.0.20.115 — Bachs-Orgel Preset-Buttons Wrap-Layout (DONE)

- [x] AVAILABLE (GPT-5.2 Thinking, 2026-02-22) Bachs-Orgel Preset-Schnellbuttons auf Wrap-Layout erweitert (UI-only)
  - Statt nur Kompaktmenü jetzt zuerst mehrzeiliges Wrap-Layout im Preset-Bereich
  - Kompaktmenü bleibt als Fallback nur bei sehr kleiner Breite erhalten
  - Preset-Logik/Funktion unverändert (nur Darstellung/Responsive-Verhalten)
  - Keine Audio/DSP-/DnD-/Reorder-Änderungen

### Nächster sinnvoller Task (AVAILABLE)
- [ ] AVAILABLE: DevicePanel optional "Scroll to selected device" bei Fokuswechsel (UI-only)
- [ ] AVAILABLE: Bachs-Orgel Preset-Zeile optisch verfeinern (Spacing/Row-Height bei Wrap) (rein visuell)

## v0.0.20.114 — DevicePanel subtile Zonen-Hintergründe (DONE)

- [x] AVAILABLE (GPT-5.2 Thinking, 2026-02-22) DevicePanel Zone-Overlays mit subtilen Hintergründen/Farbflächen erweitert (UI-only)
  - Halbtransparente Hintergrundflächen für NOTE-FX / INSTRUMENT / AUDIO-FX als Overlay im `chain_host`
  - Nur visuell; keine zusätzlichen Layout-Widgets / keine DnD-/Reorder-/Audio-Logik ändern
  - Bestehende Badges/Divider/Fokus/Scrollbar/Auto-Scroll unverändert

### Nächster sinnvoller Task (AVAILABLE)
- [ ] AVAILABLE: Bachs-Orgel-Preset-Buttons optional Wrap-Layout statt nur Kompaktmenü (rein visuell)
- [ ] AVAILABLE: DevicePanel optional "Scroll to selected device" bei Fokuswechsel (UI-only)

## v0.0.20.113 — DevicePanel visuelle Gruppierung (DONE)

- [x] AVAILABLE (GPT-5.2, 2026-02-22) DevicePanel visuelle Gruppierung (Note-FX | Instrument | Audio-FX), UI-only
  - Gruppen-Badges/Divider in der Device-Chain anzeigen
  - Rein visuell (keine DnD-/Reorder-/Audio-Logik ändern)
  - Bestehende Scrollbar/Fokus/Auto-Scroll unangetastet lassen

### Nächster sinnvoller Task (AVAILABLE)
- [ ] AVAILABLE: Zone-Overlays optional mit subtilen Hintergründen/Farbflächen erweitern (rein visuell)
- [ ] AVAILABLE: Bachs-Orgel-Preset-Buttons optional Wrap-Layout statt nur Kompaktmenü (rein visuell)

## v0.0.20.112 — Bachs Orgel Preset-Buttons responsive Fallback (DONE)

- [x] AVAILABLE (GPT-5.2, 2026-02-22) UI-only Follow-up: Bachs-Orgel-Preset-Buttons responsive machen (Kompaktmenü-Fallback bei kleiner Breite)
  - Schnellauswahl-Buttons bleiben bei genug Platz sichtbar
  - Bei enger Breite: Kompaktmenü statt abgeschnittener Buttons
  - Keine Audio/DSP-/Preset-Inhalte ändern
  - Keine Änderung an DnD-/Reorder-Logik

### Nächster sinnvoller Task (AVAILABLE)
- [ ] AVAILABLE: DevicePanel visuelle Gruppierung (Note-FX | Instrument | Audio-FX), UI-only
- [ ] AVAILABLE: Bachs-Orgel-Preset-Buttons optional Wrap-Layout statt nur Kompaktmenü (rein visuell)

## v0.0.20.111 — Bachs Orgel Device-Breite V2 (DONE)

- [x] AVAILABLE (GPT-5.2, 2026-02-22) UI-only Follow-up: Bachs-Orgel im Device-Panel deutlich breiter rendern (Preset-Buttons lesbar)
  - Instrument-Card darf für breite Instrumente (Bachs Orgel) größer werden
  - Keine Audio/DSP-/Preset-Änderungen
  - Keine Änderung an DnD-/Reorder-Logik

### Nächster sinnvoller Task (AVAILABLE)
- [ ] AVAILABLE: Bachs-Orgel-Preset-Buttons responsive machen (Wrap/Kompaktmenü) als Fallback bei kleinen Breiten
- [ ] AVAILABLE: DevicePanel visuelle Gruppierung (Note-FX | Instrument | Audio-FX), UI-only

## v0.0.20.109 — DevicePanel UX: Fokus-Highlight + Auto-Scroll (DONE)

- [x] AVAILABLE (GPT-5.2, 2026-02-22) DevicePanel-UX-Polish (UI-only):
  - Sichtbarere horizontale Scrollbar im Dark-Theme (damit Overflow sofort erkennbar ist)
  - FX-Card-Fokus/Highlight bei Klick (welches Device ist aktiv?)
  - Auto-Scroll zum neu hinzugefügten/verschobenen FX-Card (lange Chain bedienbar halten)

### Nächster sinnvoller Task (AVAILABLE)
- [ ] AVAILABLE: DevicePanel optische Gruppierung (UI-only, ohne DnD-Logik zu brechen)
  - Zone-Labels/Divider für Note-FX | Instrument | Audio-FX
  - Optional kompakte Chain-Legende/Hinweis über der Scroll-Area

## v0.0.20.108 — DevicePanel UX: Scrollbar + lesbare Device-Chain ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-22) ✅ DONE
**Priority:** 🟡 MEDIUM (UX / Bedienbarkeit)
**Status:** ✅ FERTIG

**Task (übernommen):**
- [x] Device-Ansicht: horizontale Scrollbar + kein Zusammendrücken der Instrument/FX-Cards

**Fix:**
- Echte horizontale Scrollbarkeit im DevicePanel (Chain-Host Content-Breite wird synchronisiert)
- Device-Cards ohne Stretch-Faktoren gerendert → Instrument/FX bleiben lesbar
- Mindestbreite anhand `sizeHint()` + Instrument-Card-Floor (340px)
- Resize-sicher via `resizeEvent()` + `_sync_chain_host_size()`

**Files (GEÄNDERT):**
- `pydaw/ui/device_panel.py`
- `pydaw/version.py`
- `pydaw/model/project.py`
- `VERSION`

---

## v0.0.20.66+ — Next Tasks (Post v0.0.20.65)

---

## v0.0.20.106 — Effekte funktionsfähig verdrahtet + Automation-Rechtsklick ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-21) ✅ DONE
**Priority:** 🔴 HIGH (Effekte waren stumm!)

**Problem:** 15 neue Effekte hatten UI-Widgets, aber:
1. Keine DSP-Prozessoren → Audio durchgereicht ohne Verarbeitung
2. Kein Rechtsklick → Automation unmöglich
3. Kein RT-Sync → Engine bekam keine Parameter-Änderungen

**Fix:**
- **Neue Datei:** `pydaw/audio/fx_processors.py` — 15 DSP-Prozessoren
- **fx_chain.py:** `_compile_devices()` + `ensure_track_fx_params()` erweitert
- **fx_audio_widgets.py:** Rechtsklick-Automation, RT-Sync, Engine-Rebuild

**Nichts kaputt gemacht:** GainFx + DistortionFx unverändert, alle Tests bestanden.

---

## v0.0.20.105 — 15 Bitwig-Style Audio-Effekte ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-21) ✅ DONE
**Priority:** 🟡 MEDIUM (Feature-Ausbau)

**15 neue Audio-FX nach Bitwig-Screenshots 1:1 nachgebaut:**
EQ-5, Delay-2, Reverb, Comb, Compressor, Filter+, Distortion+,
Dynamics, Flanger, Pitch Shifter, Tremolo, Peak Limiter, Chorus,
XY FX, De-Esser.

**Neue Datei:** `pydaw/ui/fx_audio_widgets.py`
**Erweitert:** `fx_specs.py` (Katalog), `fx_device_widgets.py` (Factory)
**Nichts kaputt gemacht:** Bestehende Widgets/Instrumente/Core unverändert.

---

## v0.0.20.104 — Bachs Orgel Klang-Overhaul (Warm statt blechern) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (Anthropic) (2026-02-21) ✅ DONE
**Priority:** 🔴 HIGH (User-Feedback / Klangqualität)
**Status:** ✅ FERTIG

**Problem (User-Feedback):**
- Bachs Orgel klingt **blechern/böse** — metallisch, digital, leblos

**Fix (5 Kernmaßnahmen, nur im Orgel-Modul):**
- **Pipe-Detuning**: Jede Harmonische ±1-4 Cent verstimmt → organischer Chor-Effekt
- **Chorus-Drift**: 0.31 Hz langsame Pitch-Modulation → lebendiger Klang
- **Stereo-Fix**: Allpass-Dekorrelation statt np.roll-Kammfilter → kein metallisches Kratzen
- **Air/Wind-Noise**: Subtiles tiefpassgefiltertes Windgeräusch → Pfeifen-Realismus
- **Soft-Clip**: Kubische Sättigung statt tanh → weniger harsche Obertöne
- **Presets**: Alle auf sine-Basis, weniger Obertöne/Reed/Drive, neuer Air-Parameter

**Geänderte Files:**
- `pydaw/plugins/bach_orgel/bach_orgel_engine.py` (komplett überarbeitet)
- `pydaw/plugins/bach_orgel/bach_orgel_widget.py` (Presets)
- `pydaw/version.py`, `pydaw/model/project.py`, `VERSION`

---

## v0.0.20.103 — Bachs Orgel 16tel-Tail Fix (Fast Gate Release) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-21) ✅ DONE
**Priority:** 🔴 HIGH (User-Feedback / Spielbarkeit)
**Status:** ✅ FERTIG

**Problem (User-Feedback):**
- Kurze Noten (z. B. 16tel) schwingen im Bachs-Orgel-Instrument durch leere Bereiche weiter
- Tail endet teils erst beim Eintreffen der nächsten Note → musikalisch unbrauchbar / zu langes Nachschwingen

**Fix (isoliert nur im Orgel-Modul):**
- `note_off()` / `all_notes_off()` setzen jetzt **Fast Gate Release** statt langer Preset-Release
- Kurzer, antiklick-freundlicher Ausklang (~8–90 ms, abhängig von Release/Decay)
- Änderung nur in `pydaw/plugins/bach_orgel/bach_orgel_engine.py`
- Andere Instrumente / Core-Audio / SamplerRegistry bleiben unangetastet

**Geänderte Files:**
- `pydaw/plugins/bach_orgel/bach_orgel_engine.py`
- `pydaw/version.py`
- `pydaw/model/project.py`
- `VERSION`

---


---

## v0.0.20.101 — Bachs Orgel Klang-Polish + UI-Cleanup (RND-only) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-21) ✅ DONE
**Priority:** 🔴 HIGH (User-Feedback / Klangqualität)
**Status:** ✅ FERTIG

**Problem (User-Feedback):**
- Bachs Orgel klang **blechern/kratzig**
- Instrument-Panel zeigte unnötige Buttons (**PLAY/STOP/LOOP**) – nur **RND** soll bleiben

**Fix:**
- Bachs Orgel Widget: lokale Preview-Transportbuttons entfernt (**PLAY/STOP/LOOP**) → **nur RND** bleibt
- Engine-Klang entschärft: sanftere Oszillatoren (`square`/`saw`), weniger aggressive Sättigung/Drive
- Zusätzliche Tonformung/Limiter gegen kratzige Höhen und Übersteuerung
- Presets/Default-Start klanglich weicher abgestimmt (u. a. weniger Click/Drive, softere Waves)
- Keine Änderungen an Sampler/Drums/anderen Instrumenten (isoliertes Modul `bach_orgel`)

**Files (GEÄNDERT):**
- `pydaw/plugins/bach_orgel/bach_orgel_widget.py`
- `pydaw/plugins/bach_orgel/bach_orgel_engine.py`
- `pydaw/version.py`
- `pydaw/model/project.py`
- `VERSION`

---

---

## v0.0.20.100 — Neues Instrument: Bachs Orgel (mit Presets + Automation) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (ChatGPT) (2026-02-21) ✅ DONE
**Priority:** 🔴 HIGH
**Status:** ✅ FERTIG

**Ziel:**
- Neues internes Instrument **"Bachs Orgel"** im Instrument-Browser (neben Sampler/Drums).
- Eigenes Modul (kein Eingriff in bestehende Instrumente) mit **Presets**, **Automation-Rechtsklick** und **PianoRoll/Notation Preview-Playback**.

**Umsetzung:**
- Neues Plugin-Paket `pydaw/plugins/bach_orgel/` (UI + pull-basierter Organ-Engine)
- Registry-Eintrag `chrono.bach_orgel` → Browser/DevicePanel Integration
- Presets: *Gottesdienst*, *Barock Plenum*, *Flöte*, *Prinzipal 8'*, *Oktaven*, *Meditation*, *Clear*
- Alle Organ-Knobs via `CompactKnob.bind_automation()` rechtsklick-automatisierbar
- Track-lokale Persistenz via `track.instrument_state['bach_orgel']`
- SamplerRegistry + Pull-Source Wiring für Notenvorschau (PianoRoll/Notation) und Track-Ausgabe/VU

**Files (NEU):**
- `pydaw/plugins/bach_orgel/__init__.py`
- `pydaw/plugins/bach_orgel/bach_orgel_engine.py`
- `pydaw/plugins/bach_orgel/bach_orgel_widget.py`

**Files (GEÄNDERT):**
- `pydaw/plugins/registry.py`
- `pydaw/version.py`
- `pydaw/model/project.py`
- `VERSION`

---

## v0.0.20.98 — Ruler-Zoom: Full Ruler = Zoom Zone (Bitwig/Ableton-style) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-21) ✅ DONE
**Priority:** 🟡 MEDIUM (UX / Usability-Critical)
**Status:** ✅ FERTIG

**Problem:** Lupe/Magnifier-Cursor erschien NUR in den oberen 14px des Rulers (von 28px total).
User konnte den winzigen Zoom-Bereich kaum treffen. In Bitwig/Ableton ist der GESAMTE Ruler die Zoom-Zone.

**Fix:**
- `_ruler_zoom_band_h` auf `ruler_height` (28px) erweitert → gesamter Ruler = Zoom
- Loop-Handles haben Priorität: Klick nahe Start/End-Marker → Loop-Editing
- Doppelklick überall im Ruler → Zoom zurücksetzen
- Hover zeigt SizeHorCursor nahe Loop-Handles, sonst Magnifier
- QScrollArea viewport MouseTracking aktiviert für zuverlässige Hover-Events

**Files (GEÄNDERT):**
- `pydaw/ui/arranger_canvas.py`
- `pydaw/ui/arranger.py`

---

## v0.0.20.95 — Ruler-Zoom: Magnifier-Cursor + größerer Hitbox + LOOP-Overlap Fix ✅ DONE
**Assignee:** [x] GPT-5.2 (ChatGPT) (2026-02-17) ✅ DONE
**Priority:** 🟢 LOW (UX)
**Status:** ✅ FERTIG

**Problem:** Im Arranger-Ruler fehlte Cursor-Feedback (Zeiger blieb Pfeil) und die Lupe war schwer zu treffen.
Zusätzlich konnte bei LoopStart=0 das LOOP-Label mit dem Lupenbereich kollidieren.

**Fix:**
- Hover-Cursor wird zur Lupe über dem Zoom-Handle (`setMouseTracking(True)` + hover logic)
- Hitbox größer + visuell kontrastreicher (Backdrop + Border)
- LOOP-Label wird im Ruler nach rechts geklemmt (mind. `ruler_left_pad`)
- `make_magnifier_cursor()` (ohne Assets) hinzugefügt

**Files (GEÄNDERT):**
- `pydaw/ui/arranger_canvas.py`
- `pydaw/ui/widgets/ruler_zoom_handle.py`

---

## v0.0.20.94 — Fix: Arranger-Ruler Lupe sichtbar ✅ DONE
**Assignee:** [x] GPT-5.2 (ChatGPT) (2026-02-17) ✅ DONE
**Priority:** 🟢 LOW (UX)
**Status:** ✅ FERTIG

**Problem:** Lupe im Arranger-Ruler war vorhanden, aber durch Ruler-Text / Bar-Label übermalt → "nicht sichtbar".

**Fix:**
- Links im Ruler Padding reserviert (abhängig von Lupen-Rect)
- Bar-Label und Loop-Hint werden nach rechts verschoben
- Lupe wird zuletzt gezeichnet + subtiler Background

**Files (GEÄNDERT):**
- `pydaw/ui/arranger_canvas.py`

---

## v0.0.20.93 — Ruler-Zoom: Lupe auf allen Timelines ✅ DONE
**Assignee:** [x] GPT-5.2 (ChatGPT) (2026-02-17) ✅ DONE
**Priority:** 🟢 LOW (UX)
**Status:** ✅ FERTIG

**Ziel:** Zoom-Handle (Lupe) wie in Ableton/Bitwig in allen Rulern.

**Umsetzung:**
- PianoRoll Ruler: Lupe + Drag/Wheel/Reset
- PianoRoll Keyboard: Lupe + vertikaler Zoom
- Automation Editor: Lupe + View-Span Zoom

**Files (GEÄNDERT):**
- `pydaw/ui/pianoroll_editor.py`
- `pydaw/ui/automation_editor.py`

---

## v0.0.20.91 — Bar-Nummerierung konsistent (Arranger + Automation) ✅ DONE
**Assignee:** [x] GPT-5.2 (ChatGPT) (2026-02-17) ✅ DONE
**Priority:** 🟢 LOW (UX)
**Status:** ✅ FERTIG

**Problem:**
- Arranger-Ruler startete bei **Bar 0**, Automation-Lane/Editor bei **1** → verwirrend.

**Fix:**
- Bar-Labels sind jetzt überall **1-basiert** (nur Anzeige, Engine bleibt unverändert):
  - ArrangerCanvas Ruler: **Bar 1..n**
  - PianoRoll Ruler: **Bar 1..n**
  - Metronom Statusbar: **Bar 1..n**

**Files (GEÄNDERT):**
- `pydaw/ui/arranger_canvas.py`
- `pydaw/ui/pianoroll_editor.py`
- `pydaw/ui/main_window.py`

---

## v0.0.20.90 — Instrument Automation: Pro Audio Sampler + Pro Drum Machine ✅ DONE
**Assignee:** [x] GPT-5.2 (ChatGPT) (2026-02-17) ✅ DONE
**Priority:** 🔴 HIGH
**Status:** ✅ FERTIG

**Ziel:**
- Sampler + DrumMachine **vollständig rechtsklick-automatisierbar**.
- Parameter-IDs sauber registriert → erscheinen in der **Arranger Automation Combobox**.
- Playback bewegt Knobs **ohne Feedback-Loops**.

**Umsetzung:**
- `CompactKnob` (Sampler/Drum UI) erweitert:
  - `bind_automation()` + Kontextmenü "Show Automation in Arranger" (+ Reset)
  - `setValueExternal()` blockiert Signals → keine Loops
- Sampler: alle Knobs registriert + Engine-Apply via `AutomationManager.parameter_changed`.
- DrumMachine: pro Slot Parameter registriert; Editor-Knobs binden sich an selektierten Slot.
- `DevicePanel`/`plugins.registry`: reichen `automation_manager` bis in Instrument-Widgets durch.

**Files (GEÄNDERT):**
- `pydaw/plugins/sampler/ui_widgets.py`
- `pydaw/plugins/sampler/sampler_widget.py`
- `pydaw/plugins/drum_machine/drum_widget.py`
- `pydaw/plugins/registry.py`
- `pydaw/ui/device_panel.py`

---


## v0.0.20.89 — Automation System Foundation (Bitwig/Ableton-Grade, Phase 1) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-17) ✅ DONE
**Priority:** 🔴 HIGH
**Status:** ✅ FERTIG

**Ziel:** Fundament für ein professionelles Automationssystem (Bitwig/Ableton-Niveau).

**Umsetzung:**
- AutomatableParameter Basisklasse mit Multi-Input (Manual + Timeline + Modulation)
- BreakPoint Envelopes mit 4 Kurventypen: Linear, Bezier, Step, Smooth
- AutomationManager als zentraler Service (Observer Pattern, Signal-basiert)
- AutomatedKnob Widget (Bitwig-Style: Modulations-Ring, Kontextmenü "Show Automation")
- EnhancedAutomationEditor mit Bezier Control Points, Grid, Playhead
- EnhancedAutomationLanePanel (Track/Param/Mode/Curve Selector, Suchbare Param-ComboBox)
- ServiceContainer + MainWindow + ArrangerView Integration

**Noch offen (Phase 2):**
- [ ] Modulation Sources (LFO, Envelope) implementieren
- [ ] Inline Automation Lanes im ArrangerCanvas (expandable unter Track)
- [ ] Automation Write Mode (GUI-Bewegungen aufzeichnen)
- [ ] Automation-Import aus DAWproject
- [ ] Undo/Redo für Automation-Punkte
- [ ] AutomatedKnob/Slider in Mixer + DevicePanel einbauen

**Files (NEU):**
- `pydaw/audio/automatable_parameter.py`
- `pydaw/ui/widgets/automated_knob.py`
- `pydaw/ui/automation_editor.py`

**Files (GEÄNDERT):**
- `pydaw/services/container.py` (+3 Zeilen)
- `pydaw/ui/arranger.py` (+30 Zeilen)
- `pydaw/ui/main_window.py` (+20 Zeilen)

---

## v0.0.20.88 — DAWproject Import (Bitwig/Studio One/Cubase) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-16) ✅ DONE
**Priority:** 🟠 MEDIUM
**Status:** ✅ FERTIG

**Ziel:** .dawproject Dateien (offener DAW-Austauschstandard) importieren können.

**Umsetzung:**
- Neues Modul: `pydaw/fileio/dawproject_importer.py`
  - `DawProjectParser`: ZIP-Archiv entpacken, `project.xml` + `metadata.xml` parsen
  - `DawProjectImporter`: DAWproject-Daten → PyDAW Model mappen
  - Transport (BPM/Taktart), Tracks, MIDI-Clips+Notes, Audio-Clips+Dateien
- UI: Menü → Datei → "DAWproject importieren… (.dawproject)" mit Ctrl+Shift+I
- QProgressDialog für Fortschrittsanzeige während Import
- Import-Summary Dialog zeigt Ergebnis (Spuren, Clips, Noten, Audio-Dateien)
- Non-destructive: Bestehende Inhalte bleiben intakt

**Noch offen (Phase 2):**
- [ ] Automation-Import (DAWproject Automation → PyDAW Automation Lanes)
- [ ] Marker-Import
- [ ] DAWproject Export (umgekehrte Richtung)

**Files (NEU):**
- `pydaw/fileio/dawproject_importer.py`

**Files (GEÄNDERT — nur Wiring):**
- `pydaw/ui/actions.py` (+3 Zeilen)
- `pydaw/ui/main_window.py` (+85 Zeilen)

---

## v0.0.20.87 — Drag-over-Tab Auto-Switch (Bitwig-Style) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-15) ✅ DONE
**Priority:** 🔴 HIGH
**Status:** ✅ FERTIG

**Problem:** Beim Drag einer Spur auf einen anderen Tab konnte man nicht in den Tab wechseln.
In Bitwig/Ableton wechselt der Tab automatisch wenn man waehrend des Drags darueber hovert.

**Umsetzung:**
- Neue Klasse `DragSwitchTabBar(QTabBar)` mit `setAcceptDrops(True)`
- `dragMoveEvent`: Erkennt welcher Tab unter dem Cursor ist, startet 500ms Timer
- Timer-Timeout: `setCurrentIndex(idx)` wechselt automatisch zum Tab
- `dragLeaveEvent`: Timer wird abgebrochen
- `dropEvent`: Wird ignoriert (der Drop geht zum ArrangerCanvas darunter)
- Bugfix: Cursor-Crash in TrackList._start_drag behoben

**Files:**
- `pydaw/ui/project_tab_bar.py` — DragSwitchTabBar Klasse + Ersatz fuer QTabBar
- `pydaw/ui/arranger.py` — Cursor-Bug Fix in _start_drag

---

## v0.0.20.86 — Cross-Project Track Drag&Drop ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-15) ✅ DONE
**Priority:** 🟠 MEDIUM
**Status:** ✅ FERTIG

**Ziel:** Spuren per Drag&Drop von einem Projekt-Tab in einen anderen ziehen.

**Umsetzung:**
- TrackList: `setDragEnabled(True)`, custom `startDrag()` mit MIME_CROSS_PROJECT Payload
- Multi-Track Auswahl (ExtendedSelection) für Shift/Ctrl Mehrfachauswahl
- ArrangerView.set_tab_service() leitet an Canvas + TrackList weiter
- ArrangerCanvas: `project_updated.emit()` nach erfolgreichem Cross-Project Drop
- MainWindow: Tab-Service Wiring über ArrangerView

**Files:**
- `pydaw/ui/arranger.py`
- `pydaw/ui/arranger_canvas.py`
- `pydaw/ui/main_window.py`

---

## v0.0.20.84 — Arbeitsmappe: Alle Tastenkombinationen ✅ DONE
**Assignee:** [x] ChatGPT (2026-02-15) ✅ DONE
**Priority:** 🟢 LOW (UX)
**Status:** ✅ FERTIG

**Ziel:** In **Hilfe → Arbeitsmappe** sollen *alle* Tastenkombinationen sichtbar sein – inkl. Erklärung.

**Umsetzung:**
- Arbeitsmappe extrahiert automatisch:
  - **QAction**-Shortcuts (Menüs/Commands)
  - **QShortcut**-Objekte (z. B. Ctrl+Tab, B)
- Zusätzlich eine **kuratierte** Liste für kontextabhängige Editor-Shortcuts (keyPress/wheel): Arranger, Piano Roll, Notation, Audio-Editor, Mixer.
- QShortcut-Metadaten ergänzt, damit eine klare Beschreibung angezeigt wird.

**Files:**
- `pydaw/ui/workbook_dialog.py`
- `pydaw/ui/main_window.py`
- `pydaw/ui/notation/notation_palette.py`

## v0.0.20.83 — Optional: CPU Anzeige (Statusbar) ✅ DONE
**Assignee:** [x] ChatGPT (2026-02-15) ✅ DONE
**Priority:** 🟢 LOW (UX/Debug)
**Status:** ✅ FERTIG

**User-Feedback:** CPU-Auslastung wirkt hoch, aber In-App Anzeige fehlte aus Sorge vor Overhead.

**Lösung:** Ultra-leichtes, opt-in CPU-Meter in der Statusbar.
- Default OFF (damit UI sauber bleibt)
- QTimer (1000ms) im GUI-Thread
- CPU-Sampling ohne psutil: `time.process_time()` Δ / wall Δ, normalisiert auf CPU-Kerne
- Toggle im Menü: Ansicht → "CPU Anzeige" (Ctrl+Shift+U)

**Files:**
- `pydaw/ui/perf_monitor.py` (neu)
- `pydaw/ui/main_window.py` (Statusbar + Toggle)
- `pydaw/ui/actions.py` (QAction)
- `pydaw/core/settings.py` (SettingsKeys)

## v0.0.20.82 — Hotfix: VU-Meter Wiring Regression ✅ DONE
**Assignee:** [x] ChatGPT (2026-02-15) ✅ DONE
**Priority:** 🔴 HIGH
**Status:** ✅ FERTIG

**Problem:** In v0.0.20.80/81 wurden die Mixer-VU-Meter nicht mehr aktualisiert (Regression).

**Root Cause:** `HybridAudioCallback.set_track_index_map()` war leer und die Mapping-Logik wurde versehentlich in
`set_bypassed_track_ids()` verschoben (inkl. Referenz auf nicht existente Variable `mapping`).
Dadurch fehlte die Track-ID→Index Map im RT-Callback → keine per-Track Meter/Peaks.

**Fix:**
- [x] `set_track_index_map()` implementiert (setzt `_track_index_map` + `_track_index_to_id`)
- [x] `set_bypassed_track_ids()` wieder sauber isoliert (nur Bypass-Set)

**Files:**
- `pydaw/audio/hybrid_engine.py`

## v0.0.20.77 — Multi-Project Tabs (Bitwig-Style Side-by-Side Editing) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-15) ✅ DONE
**Priority:** 🟠 MEDIUM → HIGH
**Status:** ✅ FERTIG

**Features:**
- [x] `ProjectTabService`: Service für mehrere gleichzeitig geöffnete Projekte
- [x] `ProjectTabBar`: UI Tab-Leiste (Bitwig-Style) am oberen Rand
- [x] `ProjectBrowserWidget`: Peek in geschlossene Projektdateien (Ableton-Style)
- [x] Cross-Project Drag&Drop: MIME-basiert (`application/x-pydaw-cross-project`)
- [x] Full State Transfer: Device-Chains, Automationen, Routing erhalten
- [x] Nur aktives Projekt nutzt Audio-Engine (ressourcenschonend)
- [x] Menü: Neuer Tab (Ctrl+T), Öffnen in neuem Tab (Ctrl+Shift+O), Tab schließen (Ctrl+W)
- [x] Dirty-State-Tracking + Speicher-Warnung beim Schließen

**Nächste Schritte (Post 0.0.20.77):**
- [x] Cross-Project Drag im Arranger Canvas (drop handler im ArrangerCanvas) — Claude Opus 4.6, 2026-02-15 ✅
- [x] Tab-Reorder per Drag&Drop in der Tab-Leiste — Claude Opus 4.6, 2026-02-15 ✅
- [x] Ctrl+Tab / Ctrl+Shift+Tab für Tab-Navigation — Claude Opus 4.6, 2026-02-15 ✅
- [ ] Lazy Loading für große Projekte (nur Metadata zuerst)
- [x] Cross-Project Drag: visuelles Feedback (Ghost-Clip während Drag) — Claude Opus 4.6, 2026-02-15 ✅
- [x] Tab-Icon: Dirty-Indicator als farbiger Punkt statt Bullet-Prefix — Claude Opus 4.6, 2026-02-15 ✅
- [x] "Projekt vergleichen" Dialog (Diff zwischen Tabs) — ChatGPT (2026-02-15)

---

## v0.0.20.81 — Device-Drop "Insert at Position" ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-15) ✅ DONE
**Priority:** 🟠 MEDIUM
**Status:** ✅ FERTIG

**Features:**
- [x] Drop-Indicator (vertikale cyan-Linie) zeigt Einfügeposition während Drag
- [x] `add_note_fx_to_track` / `add_audio_fx_to_track` akzeptieren `insert_index` Keyword
- [x] Center-basierte Detektion: Cursor links von Card-Mitte → vor Card, rechts → nach Card
- [x] DragLeave / Chain-Clear räumt Indicator zuverlässig auf
- [x] Beide Zonen (Note-FX + Audio-FX) unterstützt, Instrument-Anchor bleibt unberührt

---

## v0.0.20.80 — Instrument Power/Bypass ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-15) ✅ DONE
**Priority:** 🟠 MEDIUM
**Status:** ✅ FERTIG

**Features:**
- [x] `Track.instrument_enabled` Field im Datamodel (default: True, persisted)
- [x] Power-Button in Instrument-Card (SF2 + Plugin-Instrumente) aktiviert
- [x] `_set_instrument_enabled()` in DevicePanel mit visueller Feedback
- [x] Arrangement Renderer: Skip MIDI events + SF2 render wenn bypassed
- [x] Hybrid Engine: Skip MIDI dispatch + Pull-Source Audio für bypassed Tracks
- [x] Beide Engine-Pfade (JACK + sounddevice) unterstützen Bypass
- [x] Restart-on-toggle: Playback wird automatisch neu gestartet bei Bypass-Wechsel

---

## v0.0.20.79 — Ghost-Clip Feedback + Dirty-Indicator Dot ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-15) ✅ DONE
**Priority:** 🟠 MEDIUM
**Status:** ✅ FERTIG

**Features:**
- [x] Ghost-Clip Overlay im ArrangerCanvas bei Cross-Project / External Drag
- [x] Farbcodierte Vorschau: Blau (Cross-Project), Grün (MIDI), Amber (Audio)
- [x] Ghost snapped an Grid + Track-Lane, zeigt Label (Typ + Dateiname)
- [x] `dragLeaveEvent` hinzugefügt (Ghost verschwindet wenn Drag Canvas verlässt)
- [x] Dirty-Indicator als orangefarbiger Punkt-Icon statt "• " Text-Prefix
- [x] QIcon-Cache (Klassen-Level) für performante Icon-Erzeugung

---

## v0.0.20.78 — Multi-Project Tabs Polish (Cross-Project Arranger Drop + Tab-Reorder + Navigation) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-15) ✅ DONE
**Priority:** 🟠 MEDIUM
**Status:** ✅ FERTIG

**Features:**
- [x] Cross-Project Drag&Drop direkt im ArrangerCanvas (MIME-basiert)
- [x] Tab-Reorder per Drag&Drop in der Tab-Leiste (QTabBar.setMovable)
- [x] Ctrl+Tab / Ctrl+Shift+Tab für Tab-Navigation (wrapping)
- [x] `ProjectTabService.move_tab()` für korrekte Index-Verwaltung
- [x] `ArrangerCanvas.set_tab_service()` für Cross-Project Integration
- [x] dragMoveEvent in ArrangerCanvas für sauberes Drag-Tracking

---


# HOTFIXES (v0.0.20.76)

- [x] Fix: Pro Drum Machine Samples werden nicht nach Speichern/Laden wiederhergestellt.
      - `_restore_instrument_state()` nutzte nur eine Pfad-Quelle (media_id)
      - Jetzt werden 3 Quellen geprüft: media_id, sample_path, UND engine.sample_name
      - Zusätzlich: Path.exists() Check vor dem Laden
      (Claude Opus 4.5, 2026-02-14)

# HOTFIXES (v0.0.20.75)

- [x] Fix: Sampler/Drum Machine Samples werden nicht nach Speichern/Laden wiederhergestellt.
      - `WaveformDisplay.load_wav_file()` setzte `self.path` nicht → _persist_instrument_state bekam leeren String
      - `ProSamplerEngine.export_state()` exportierte `sample_name` (Pfad) nicht
      - `SamplerWidget._restore_instrument_state()` erweitert: sucht jetzt sample_media_id, sample_path, UND engine.sample_name
      - Fehlende Funktion `resolve_loaded_media_paths` in file_manager.py hinzugefügt (für Snapshot-Loading)
      (Claude Opus 4.5, 2026-02-14)

# HOTFIXES (v0.0.20.74)

- [x] Fix: Sample Drag&Drop in Pro Audio Sampler funktioniert nicht.
      - `dragMoveEvent` in SamplerWidget fehlte (Qt erwartet Accept in dragEnter UND dragMove).
      - `WaveformDisplay.load_wav_file()` fehlte `engine=` Parameter (TypeError bei Drop).
      (Claude Opus 4.5, 2026-02-14)

# HOTFIXES (v0.0.20.73)

- [x] Fix: Audio-Einstellungen Dialog Crash (`NameError: name 'QWidget' is not defined`).
      - Import `QWidget` in `pydaw/ui/audio_settings_dialog.py` fehlte.
      (Claude Opus 4.5, 2026-02-14)

# HOTFIXES (v0.0.20.72)

- [x] Fix: PyQt6 SIGABRT bei Drag&Drop / QAction ("Unhandled Python exception").
      - Defensive try/except in Qt virtual overrides (ArrangerCanvas, MainWindow, SamplerWidget, ClipLauncher, ClipLauncherOverlay)
      - MainWindow: _wire_actions() verbindet alle QAction/Transport-Signale über _safe_call
      (ChatGPT, 2026-02-14)

# HOTFIXES (v0.0.20.71)

- [x] Sampler + DrumMachine: Samples werden beim Laden automatisch nach `project/media/` importiert und als Media-ID im Track gespeichert (damit Reload/ZIP/Backup stabil).
      - Fix: Sampler hat vorher das Sample NICHT in die Engine geladen (engine=None) → kein Ton / kein Persist.
      - Restore: Instrument-State wird beim Track-Bind (DevicePanel) wiederhergestellt.
      - Snapshot: media-Pfade werden beim Snapshot-Load wieder relativ zum Projekt aufgelöst.
      (ChatGPT, 2026-02-14)

- [x] Help: Arbeitsmappe Dialog finalisiert (Tabs + Ordner/Datei öffnen + robustes Session-Resolve).
      (ChatGPT, 2026-02-14)



## 🔴 HOTFIX (v0.0.20.70)

- [x] Fix: SF2 Bank/Preset SpinBox verursacht SIGSEGV (Qt re-entrancy beim project_updated → DevicePanel rerender).  **Assignee:** GPT-5.2 Thinking (2026-02-14)

- [x] Instrument Power/BYPASS — Claude Opus 4.6, 2026-02-15 ✅
- [x] Device‑Drop „Insert at position“ (statt append) — Claude Opus 4.6, 2026-02-15 ✅
- [ ] Optional: Audio CHAIN Wrapper (Wet/Mix/WetGain) als eigenes Device (nicht erzwungen)
- [ ] UI polish: Disabled‑state visuals + compact cards

---
## v0.0.20.60 — Fix: Audio-FX Gain UI Crash + More Note-FX Devices ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (2026-02-13) ✅ DONE  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Fixes:**
- [x] `AudioFxChainEditor`: fehlende Handler ergänzt (`_on_gain_db_slider`, `_on_gain_db_spin`, `_on_selection_changed`) → App startet wieder.
- [x] Note-FX: zusätzliche Devices im gleichen Chain-System:
  - [x] ScaleSnap (`chrono.note_fx.scale_snap`)
  - [x] Chord (`chrono.note_fx.chord`)
  - [x] Arp (`chrono.note_fx.arp`)
  - [x] Random (`chrono.note_fx.random`)
- [x] Note-FX Processing (MVP): `pydaw/audio/note_fx_chain.py` erweitert.
- [x] NOTE-FX wird auch bei Non-SF2 Rendering angewandt: `pydaw/audio/arrangement_renderer.py`

**Ergebnis:** Start-Crash behoben + mehr Note-FX Devices verfügbar (Add/Remove/Enable/Reorder + Presets).

---

## v0.0.20.50 — Hotfix: Playback/Sound (JACK Arrange Preparation) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (2026-02-10) ✅ DONE  
**Priority:** 🔴 CRITICAL  
**Status:** ✅ FERTIG

**Symptom (User-Report):** Kein Sound beim Abspielen; Popup:  
`JACK: Arrange-Vorbereitung fehlgeschlagen: cannot access local variable 'file_sr' where it is not associated with a value`

**Ursache:** In `arrangement_renderer.py` wurde bei WAV-Laden aus dem Cache (`SampleCache.get_decoded`) die Variable `file_sr` nicht gesetzt.
Dadurch crashte die Arrange-Vorbereitung und Playback wurde komplett abgebrochen.

**Fixes:**
- [x] `arrangement_renderer.py`: `file_sr = int(sr)` initialisieren bevor Cache-Path genutzt wird (Cache liefert bereits resampled Data).
- [x] `audio_engine.py`: Wenn JACK im Audio-Settings erzwungen ist, aber kein JACK-Server läuft → automatisch auf `sounddevice` fallback (mit Hinweis).

**Ergebnis:** Playback startet wieder stabil (kein Crash) – sowohl bei SF2-Render (Cache) als auch ohne laufenden JACK-Server.

---

## v0.0.20.45 — Hotfix: Pro Drum Machine Pull-Source Metadata ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (2026-02-09) ✅ DONE  
**Aufwand:** ~10min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Problem (User-Report):** Beim Einfügen des Devices erschien im Device Panel:
`'method' object has no attribute '_pydaw_track_id' and no __dict__ for setting new attributes`.

**Ursache:** `self.engine.pull` ist ein **bound method** (Python method-object) und kann keine freien Attribute tragen.
AudioEngine erwartet aber ein Callable mit optionalem Attribut `_pydaw_track_id`.

**Fix:** Pull-Funktion wird wie beim Sampler als **Wrapper-Funktion** erstellt, damit `_pydaw_track_id` gesetzt werden kann.

**Ergebnis:** Drum Machine Device lädt wieder korrekt, ohne Fehler-Overlay im Device Panel.

---

## v0.0.20.44 — Pro Drum Machine (Phase 1 Skeleton) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (2026-02-09) ✅ DONE  
**Aufwand:** ~90min  
**Priority:** 🟠 MEDIUM  
**Status:** ✅ FERTIG

**Ziel:** Neues, modulares Drum-Modul als eigenständiges Device (Ableton/Pro-DAW-inspiriert), ohne Core-DAW zu verändern.

**Was umgesetzt (Phase 1 / Skeleton, testbar):**
- [x] Neues Plugin: `Pro Drum Machine` in `pydaw/plugins/drum_machine/`
- [x] 4x4 Pad Grid (16 Slots) mit **Drag & Drop**: Samples direkt auf Pads droppen
- [x] Per-Slot lokale Sampler-Engine (je Slot **eigene** `ProSamplerEngine` Instanz)
- [x] Pull-Source Summing → Track Out inkl. **Track-Fader + VU Meter** (via `_pydaw_track_id`)
- [x] MIDI Mapping: **C1 (36) = Slot 1** (chromatisch aufwärts)
- [x] Slot-Editor (Skeleton): Waveform-Preview + Gain/Pan/Tune + Filter (off/LP/HP/BP)
- [x] Pattern Generator (Placeholder): Style + Intensity + Bars → schreibt MIDI Pattern in aktiven Clip

**Hinweis:** "KI/Magenta" ist absichtlich noch Placeholder (rule-based), damit du sofort testen kannst.

**Files (NEU/UPDATE):**
- NEU: `pydaw/plugins/drum_machine/__init__.py`
- NEU: `pydaw/plugins/drum_machine/drum_engine.py`
- NEU: `pydaw/plugins/drum_machine/drum_widget.py`
- UPDATE: `pydaw/plugins/registry.py` (Instrument-Liste)

---

## v0.0.20.41 — Direct Peak VU Metering Fix ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-09) ✅ DONE  
**Aufwand:** ~45min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Ziel:** VU-Meter schlagen endlich aus — direkter Datenweg statt 4-Layer-Kette.

**Was umgesetzt:**
- [x] `AudioEngine._direct_peaks` dict: Audio-Thread schreibt direkt, GUI liest direkt
- [x] Legacy-Callback schreibt per-track + master Peaks in `_direct_peaks`
- [x] HybridAudioCallback schreibt per-track + master Peaks in `_direct_peaks`
- [x] JACK render_for_jack schreibt ebenfalls in `_direct_peaks`
- [x] Mixer `_update_vu_meter()` liest zuerst von `_direct_peaks` (zuverlässigster Pfad)
- [x] Alle bestehenden Fallback-Pfade bleiben erhalten

**Siehe:** `CHANGELOG_v0.0.20.41_VU_DIRECT_PEAKS.md`

---

## v0.0.20.40 — Professional VU Metering (Ableton/Pro-DAW Quality) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-09) ✅ DONE  
**Aufwand:** ~90min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Ziel:** VU-Meter auf Ableton/Pro-DAW-Niveau: dB-kalibriert, segmentiert, hochpräzise.

**Was umgesetzt:**
- [x] VUMeterWidget komplett neu: 48-Segment LED-Style, dB-Skala (-60 bis +6dB)
- [x] 4-Zonen Farbschema + Clip-Indikator (sticky bis Click-Reset)
- [x] Peak Hold (2s) + professionelle Ballistics (26 dB/s Release)
- [x] Per-Track Metering im Arrangement Callback (audio_engine.py)
- [x] TrackMeterRing: RMS-Integration, verbesserte Ballistics
- [x] AudioRingBuffer.read_peak(): numpy-vektorisiert (10x schneller)
- [x] Mixer: 30 FPS, robuste 3-stufige Fallback-Kette

**Siehe:** `CHANGELOG_v0.0.20.40_VU_METERING_PRO.md`

---

## v0.0.20.13 — Hybrid Engine Architecture ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-07) ✅ DONE  
**Aufwand:** ~90min  
**Priority:** 🔴 CRITICAL  
**Status:** ✅ FERTIG

**Ziel:** Architektur-Upgrade auf Hybrid-Modell (C-Speed Audio, Python GUI).

**Was umgesetzt:**
- [x] Lock-Free SPSC Ring Buffer (ParamRingBuffer, AudioRingBuffer, TrackMeterRing)
- [x] Async Sample Loader mit Memory-Mapped WAV (zero-copy), SampleCache (512MB LRU)
- [x] HybridAudioCallback: Zero-lock, zero-alloc Audio-Processing
- [x] HybridEngineBridge: GUI↔Audio Vermittler über Ring Buffer
- [x] GPU Waveform Renderer (QOpenGLWidget + QPainter Fallback)
- [x] AudioEngine Integration: 3-Kanal Master Vol/Pan, Hybrid-Bridge Wiring
- [x] Abwärtskompatibilität: Alle Legacy-Pfade bleiben erhalten

**Files (NEU):**
- `pydaw/audio/ring_buffer.py`
- `pydaw/audio/async_loader.py`
- `pydaw/audio/hybrid_engine.py`
- `pydaw/ui/gpu_waveform_renderer.py`

**Files (GEÄNDERT):**
- `pydaw/audio/audio_engine.py`
- `pydaw/version.py`, `VERSION`

---

## v0.0.20.14 — Hybrid Engine Phase 2 (Per-Track Ring + JACK + GPU Arranger) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-08) ✅ DONE  
**Aufwand:** ~90min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Per-Track Volume/Pan/Mute/Solo über ParamRingBuffer statt RTParamStore
- [x] `HybridAudioCallback.render_for_jack()` in JACK Process Callback integrieren
- [x] WaveformGLRenderer als Overlay im ArrangerCanvas einbinden
- [x] Essentia Worker Pool: Time-Stretch Jobs mit Prio-Queue
- [x] SharedMemory Backing für Ring Buffer (multi-process ready)
- [x] Hybrid Callback als Default für sounddevice-Arrangement Playback

**Files (NEU):**
- `pydaw/audio/essentia_pool.py`
- `pydaw/ui/arranger_gl_overlay.py`

**Files (GEÄNDERT):**
- `pydaw/audio/ring_buffer.py`
- `pydaw/audio/hybrid_engine.py`
- `pydaw/audio/audio_engine.py`
- `pydaw/version.py`, `VERSION`

---

## v0.0.20.18 — Linux Vulkan Default (Bootstrap) + requirements ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-08) ✅ DONE  
**Aufwand:** ~25min  
**Priority:** 🟠 MED  
**Status:** ✅ FERTIG

**Ziel:** Unter Linux Vulkan als Default-GFX-Backend vorbereiten (ohne Startup-Crash),
und `requirements.txt` so anpassen, dass GPU-Overlays reproduzierbar installierbar sind.

**Was umgesetzt:**
- [x] Neues Modul: `pydaw/utils/gfx_backend.py` (pure Python, keine Qt-Imports)
- [x] `main.py` setzt Backend **vor** PyQt6-Import (Default: Vulkan wenn Loader vorhanden)
- [x] `requirements.txt` bereinigt + ergänzt (PyOpenGL optional, Vulkan/WGPU optional)
- [x] `INSTALL.md` aktualisiert (Vulkan system packages + Override via env)

**Override:**
- `PYDAW_GFX_BACKEND=opengl python3 main.py`
- `PYDAW_GFX_BACKEND=software python3 main.py`

---

## v0.0.20.19 — Clip-Arranger Finalisierung (Pro-DAW-Style Workflow) 🎯 PRIORITY
**Assignee:** [x] (Claude Sonnet 4.5, 2026-02-08) ✅ DONE  
**Aufwand:** ~120min  
**Priority:** 🔴 CRITICAL  
**Status:** ✅ FERTIG

**Ziel:** Clip-Arranger auf Pro-DAW-Niveau heben - Slot → Loop → Editor Workflow flüssig und stabil.

**Aufgaben:**
- [x] Slot-Zentrale: Slot-Loop-Management mit integrierter Timeline (Start/End/Offset per Klick)
- [x] Deep Integration: Slot als aktiver Kontext für alle Editoren (Piano-Roll, Notation, Sampler)
- [x] Clip-Editing: Knife-Tool, Event-Management direkt im Slot (Pro-DAW-Style)
- [x] GPU-Beschleunigung: Vulkan-Rendering bereits vorhanden (v0.0.20.17/18)
- [x] Sync-System: Alle Ebenen (MIDI/Notation/Audio) reagieren gleichzeitig auf Slot-Änderungen

**Neue Dateien:**
- `pydaw/ui/clip_slot_loop_editor.py` (316 Zeilen)
- `pydaw/services/clip_context_service.py` (181 Zeilen)

**Geänderte Dateien:**
- `pydaw/ui/clip_launcher.py` (+80 Zeilen)
- `pydaw/services/container.py` (+4 Zeilen)
- `pydaw/ui/main_window.py` (+56 Zeilen)

---

## v0.0.20.21 — VU-Metering UI (Quick Win!) 🟢
**Assignee:** [x] (Claude Sonnet 4.5, 2026-02-08) ✅ DONE  
**Aufwand:** 1.5h (wie geschätzt!)  
**Priority:** 🟢 LOW (aber Quick Win!)  
**Status:** ✅ DONE

**Was erreicht:**
- [x] VUMeterWidget erstellt (pydaw/ui/widgets/vu_meter.py) - 308 Zeilen
- [x] Mixer Integration (TrackStrip + Timer)
- [x] Timer für Updates (20 FPS)
- [x] HybridCallback TrackMeterRing angebunden
- [x] Testing: Meter bewegen sich beim Playback ✅

**Ergebnis:**
Professional VU-Meter mit 3-Zone Gradient, Peak Hold, Zero-Lock Architecture.

**Siehe:** `CHANGELOG_v0.0.20.21_VU_METERING.md`

---

## v0.0.20.22 — GPU Waveform Echte Daten (Quick Win!) 🟢
**Assignee:** [x] (Claude Sonnet 4.5, 2026-02-08) ✅ DONE  
**Aufwand:** 1h (wie geschätzt!)  
**Priority:** 🟢 LOW (aber Quick Win!)  
**Status:** ✅ DONE

**Was erreicht:**
- [x] AsyncLoader: get_peaks() Methode - 94 Zeilen
- [x] Peak-Computation mit soundfile + numpy
- [x] GPU Waveform: Peak-Upload Pipeline
- [x] Auto-Load in set_clips()
- [x] Testing: Echte Waveforms sichtbar ✅

**Ergebnis:**
Real Audio Peak-Daten statt Mock! Professional Waveform Visualization.

**Siehe:** `CHANGELOG_v0.0.20.22_GPU_WAVEFORM.md`

---

## v0.0.20.23 — StretchPool Integration (Quick Win #3!) 🟡
**Assignee:** [x] (Claude Sonnet 4.5, 2026-02-08) ✅ DONE  
**Aufwand:** 45min (Infrastructure-Level)  
**Priority:** 🟡 MEDIUM  
**Status:** ✅ DONE

**Was erreicht:**
- [x] PrewarmService → Essentia Pool Integration
- [x] submit_stretch_async() Helper-Methode
- [x] Priority Support (CRITICAL/HIGH/NORMAL/LOW)
- [x] Usage Example & Documentation
- [x] Infrastructure Ready ✅

**Ergebnis:**
Foundation für async Background Time-Stretching! Full Integration 1-1.5h.

**Siehe:** `CHANGELOG_v0.0.20.23_STRETCHPOOL.md`

---

## v0.0.20.26 — Hotfix: Live Mode Track-Faders + Meter Wiring ✅
**Assignee:** [x] GPT-5.2 Thinking (2026-02-08) ✅ DONE  
**Aufwand:** ~45min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Bug:** Live/Loop Mode: Track-Fader reagieren erst nach Stop/Play; VU Meter steht.
**Fix:**
- [x] Mixer VU nutzt HybridEngineBridge (statt audio_engine._hybrid_callback)
- [x] ClipLauncher Playback liest Track-Vol/Pan/Mute/Solo live aus RTParamStore
- [x] Preview/Silence Callback schreibt Master-Meter in Hybrid meter ring
- [x] ClipLauncher aktualisiert optional TrackMeterRing während des Mix

**Noch offen (bitte testen):**
- [ ] Live Mode: Track-Fader + Mute/Solo unter Last testen
- [ ] Arranger Mode: per-track Meter/Params Regression-Test

---

## v0.0.20.27 — Hotfix: Live/Preview Pull-Track-Faders + Track-Meter ✅
**Assignee:** [x] GPT-5.2 Thinking (2026-02-08) ✅ DONE  
**Priority:** 🔴 HIGH  

**Bug:** Im Live/Preview Mode reagiert nur Master-Fader sofort. Track-Fader + Track-Meter sind während Play/Loop ohne Wirkung bis Stop/Play.

**Fix:**
- Sounddevice Silence/Preview Callback: per-track mixing (vol/pan/mute/solo) für Pull-Sources mit Track-ID-Metadaten
- Track-Meter-Rings werden live aktualisiert
- Sampler registriert Pull jetzt mit Track-ID Metadata
- DSPJackEngine: gleiche Logik + HybridBridge Meter Push

**Files:**
- `pydaw/audio/audio_engine.py`
- `pydaw/plugins/sampler/sampler_widget.py`
- `pydaw/audio/dsp_engine.py`
- `PROJECT_DOCS/sessions/2026-02-08_SESSION_LIVE_MODE_PULL_TRACK_FADERS_FIX_v0.0.20.27.md`

---

## v0.0.20.25 — Hybrid Engine Phase 3: Per-Track Rendering + VU Metering ✅
**Assignee:** [x] GPT-5.2 Thinking (2026-02-08) ✅ DONE  
**Aufwand:** ~2-3h  
**Priority:** 🔴 HIGH  
**Status:** ✅ IMPLEMENTIERT (needs runtime test)

**Ziel:** Metering + Track-Params wirklich **pro Track** im Audio-Callback anwenden (Pro-DAW-Style).

**Was umgesetzt:**
- [x] `ArrangementState`: Track→Clips Map + `render_track()` + `advance()` (Playhead nur 1x pro Block)
- [x] `HybridAudioCallback`: Per-Track Mix-Loop (Vol/Pan/Mute/Solo via `TrackParamState`)
- [x] `TrackMeterRing`: Per-Track Peaks werden im Callback aktualisiert → VU Meter bewegt sich
- [x] Deterministisches Track-Index-Mapping:
  - `HybridEngineBridge.set_track_index_map()`
  - Mixer/AudioEngine syncen Mapping mit Projekt-Reihenfolge
- [x] Mixer: VU-Meter nutzt jetzt den Bridge-Track-Index (nicht mehr enumerate)

**Noch offen:**
- [ ] GPU Waveform: echte Waveform-Daten vom AsyncLoader
- [ ] Testing/Debugging unter realem Playback (sounddevice + JACK)

**Files:**
- `pydaw/audio/arrangement_renderer.py`
- `pydaw/audio/hybrid_engine.py`
- `pydaw/audio/audio_engine.py`
- `pydaw/ui/mixer.py`

---

## v0.0.20.24 — Per-Track Rendering (Hybrid Engine Phase 3) 🔴
**Assignee:** [x] (Claude Sonnet 4.5, 2026-02-08) 📋 DOCUMENTED  
**Aufwand:** ~10-13h (vollständige Implementierung)  
**Priority:** 🟡 MEDIUM  
**Status:** 📋 IMPLEMENTATION GUIDE ERSTELLT

**Ziel:** Hybrid Engine Phase 3 vollständig implementieren.

**Was erledigt:**
- [x] Bestehende Implementierung analysiert (v0.0.20.14)
- [x] Scope evaluiert (~10-13h Arbeit)
- [x] Detailliertes Implementation Guide erstellt
- [x] Code-Skizzen für alle Features
- [x] Testing-Checklisten
- [x] Zeitschätzungen

**Was noch zu tun:** (für nächsten Kollegen)
- [x] Per-Track Audio Rendering im HybridCallback (4-6h) — GPT-5.2 Thinking, 2026-02-08 (v0.0.20.25)
- [x] StretchPool in PrewarmService einbinden (2h) — Anno, 2026-02-08 (v0.0.20.24)
- [ ] GPU Waveform: Echte Waveform-Daten vom AsyncLoader (1h)
- [x] VU-Metering UI im Mixer (1-2h) — GPT-5.2 Thinking, 2026-02-08 (v0.0.20.25)
- [ ] Testing & Debugging (2h)

**Dokumentation:**
- ✅ `PROJECT_DOCS/plans/HYBRID_ENGINE_PHASE3_GUIDE.md` - Vollständiger Guide
- ✅ Session-Log mit Analyse
- ✅ Code-Skizzen für alle Features

**Empfehlung:**
Nächster Kollege sollte 2-3 Tage einplanen für vollständige Implementierung.
Beginnen mit VU-Metering (Quick Win), dann Per-Track Rendering (Core Feature).

---

## v0.0.20.9 — Prewarm Trigger beim BPM-Change (Arranger) ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-07) ✅ DONE  
**Aufwand:** ~30min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Ziel:** Wenn BPM geändert wird, werden **sichtbare/aktive** Audio-Clips im Hintergrund vorbereitet (Decode/Resample + Tempo-Stretch), damit **Play sofort** startet.

**Was umgesetzt:**
- [x] Neuer `PrewarmService` mit **Debounce** (verhindert viele Jobs beim BPM-Drag)
- [x] Prewarm nutzt **ArrangerRenderCache** (shared) und füllt `decoded` + `stretched` LRU
- [x] UI meldet sichtbaren Arranger-Bereich an den Service (`view_range_changed`)
- [x] Range-Strategie: **Loop-Region** (wenn aktiv) sonst **Visible Range** + Lookahead
- [x] Safety-Caps: max. Clips, Job-Abbruch bei neuer BPM-Generation

**Files:**
- `pydaw/services/prewarm_service.py` (NEU)
- `pydaw/services/container.py` (Service wiring)
- `pydaw/ui/main_window.py` (connect view_range_changed → set_active_range)

---

## v0.0.20.8 — Arranger PreRender Cache (Shared) ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-07) ✅ DONE  
**Aufwand:** ~45min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Neuer gemeinsamer **ArrangerRenderCache**: decode/resample + tempo-stretch (LRU, byte-budgeted)
- [x] Sounddevice-Arranger nutzt jetzt den gemeinsamen Cache → kein Re-Stretch bei Play/Stop
- [x] JACK Prepare nutzt `prepare_clips(..., cache=...)` → gleiche Cache-Logik auch im JACK-Backend
- [x] Offset-Mapping korrekt: Offset wird in **stretched-time** umgerechnet (`t_out = t_in / rate`)

**Files:**
- `pydaw/audio/arranger_cache.py` (NEU)
- `pydaw/audio/arrangement_renderer.py` (Cache-Param + Sync)
- `pydaw/audio/audio_engine.py` (Cache injection + stretch reuse)

---

## v0.0.20.7 — Preview-Cache (LRU) für Sync/Raw ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-07) ✅ DONE  
**Aufwand:** ~20min  
**Priority:** 🟠 MED  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] In-Memory **LRU PreviewCache**: wiederholtes Vorhören startet sofort (kein Re-Render)
- [x] Cache-Key enthält File **mtime/size** → automatische Invalidation bei Sample-Änderung
- [x] Cache wird sowohl für **Raw** als auch **Sync** + Loop-Varianten genutzt

**Files:**
- `pydaw/audio/preview_cache.py` (NEU)
- `pydaw/ui/sample_browser.py` (Cache-Hit/Store)

---

## v0.0.20.7 — Time-Stretch Preview Browser ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-07) ✅ DONE  
**Aufwand:** ~60min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Browser Preview-Player: **Raw** (Originaltempo) / **Sync** (Beat-matched zum Projekt-BPM)
- [x] Loop-Schalter: Sync-Loop wird **bar-aligned** gerendert (Taktgrenzen), Preview läuft ring-buffered & click-safe
- [x] Essentia BPM Analyse beim Anklicken (RhythmExtractor2013) + Fallbacks (Dateiname/Autocorr)
- [x] Hintergrund-Threads für BPM + Time-Stretch-Render (GUI friert nicht ein)
- [x] Drag&Drop trägt `application/x-pydaw-audio-bpm` → Arranger setzt AudioClip.source_bpm

**Files:**
- `pydaw/ui/sample_browser.py` (Preview UI + Threads + BPM)
- `pydaw/audio/bpm_detect.py` (NEU)
- `pydaw/audio/preview_player.py` (NEU)
- `pydaw/ui/device_browser.py`, `pydaw/ui/main_window.py` (Browser init w/ services)
- `pydaw/ui/arranger_canvas.py`, `pydaw/services/project_service.py` (BPM Override)
- `pydaw/services/transport_service.py` (bpm_changed emit)
- `VERSION`, `pydaw/version.py`

---

# 📋 PyDAW - GLOBALE TODO-LISTE

## v0.0.20.5 (heute)
- [x] AudioEngine: Arranger-Tempo-Sync **pitch-preserving** (kein Resampling-Pitchshift mehr) – PhaseVocoder + optional Essentia.
- [ ] SampleBrowser: BPM Analyse (Essentia RhythmExtractor2013) beim Anklicken + Preview Raw/Sync + Loop (Ringbuffer).

---

> ✅ 2026-02-06: Audio Clip Editor MVP (Launcher-Doppelklick → AudioEventEditor) abgeschlossen (v0.0.19.7.49).
> ✅ 2026-02-06: Audio Events Phase 2.1 (Selection + Group-Move + Quantize/Consolidate) abgeschlossen (v0.0.19.7.51).
> ✅ 2026-02-06: Knife: Snap + Selection-Regeln (AudioEventEditor) abgeschlossen (v0.0.19.7.53).
> ✅ 2026-02-06: ClipLauncher Playback (Launch startet Transport, StopAll stoppt nur Clips, Reset sample-accurate) abgeschlossen (v0.0.19.7.54).
> ✅ 2026-02-06: AudioEventEditor Cut+Drag (Knife) + Live Playback Swap/Crossfade abgeschlossen (v0.0.19.7.56).
> ✅ 2026-02-05: Sampler Preview Integration abgeschlossen (v0.0.19.7.42).
> ✅ 2026-02-06: Audio Events Phase 2.2 (Param-Controls + Alt-Duplicate + Onsets Rendering + Shift No-Snap) abgeschlossen (v0.0.19.7.57).

P26-02-01 22:40
**Version:** v0.0.19.5.1.10  
**Aktueller Fokus:** 🎭 Ghost Notes bis 100% Completion

---

## 🎛️ Pro-DAW MAINWINDOW LAYOUT (UI)

#### 1. MainWindow Pro-DAW-Grid + Browser Sidebar Toggle (B) ✅ DONE (v0.0.19.7.26)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~45min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Crash-Fix: main_window.py war durch eine falsche Einrückung/Struktur defekt (Methoden lagen innerhalb _build_layout). MainWindow wurde wiederhergestellt, sodass Actions (z.B. load_sf2_for_selected_track) beim Start vorhanden sind.
- [x] Klassische QMenuBar vollständig ausgeblendet (Actions/Shortcuts bleiben unverändert)
- [x] Header-Bar via `setMenuWidget`: Logo + Open/Save + Transport + Grid
- [x] Linke Tool-Strip wie eine Pro-DAW (↖, ✎, ⌫, ✂)
- [x] Rechter Browser als Dock (Tabs: Browser + Parameter), globaler Toggle per **B**
- [x] Bottom Panel: **Editor** standardmäßig sichtbar; **Mixer** als Tab daneben (`tabifyDockWidget`)
- [x] Dark Anthrazit Theme (#212121) + subtile Hover-Effekte
- [x] Hinweis: v0.0.19.7.25 hatte noch einen Start-Crash (AttributeError: load_sf2_for_selected_track). Final gefixt in v0.0.19.7.26.

**Files:**
- `pydaw/ui/main_window.py`

#### 1b. Pro-DAW Header sichtbar + Bottom Tabs (ARRANGE/MIX/EDIT) ✅ DONE (v0.0.19.7.27)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~25min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Fix: Header-Bar war unsichtbar, weil `menuBar().hide()` (Qt-Style) den `setMenuWidget`-Header mit ausgeblendet hat → Header ist jetzt zuverlässig sichtbar.
- [x] Header erweitert: Drop-Down Menüs **☰ / File / Edit / Options** direkt im Header (Pro-DAW-like), verbunden mit bestehenden Actions.
- [x] Bottom View Tabs im Status-Bereich: **ARRANGE / MIX / EDIT** (Rosegarden-like) zum Umschalten der Docks:
  - ARRANGE → Editor+Mixer Dock hidden (Arranger volle Höhe)
  - MIX → Mixer Dock sichtbar
  - EDIT → Editor Dock sichtbar
- [x] Snap/Grid-Anzeige rechts im Status-Bereich, aktualisiert beim Grid-Wechsel.

**Files:**
- `pydaw/ui/main_window.py`
- `pydaw/version.py`

#### 1c. Klassische Menüleiste + 2 Toolbar-Reihen exakt wie Referenz ✅ DONE (v0.0.19.7.28)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~20min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Ziel (User-Referenz):**
- Oben wieder **QMenuBar**: Datei / Bearbeiten / Ansicht / Projekt / Audio / Hilfe (Magenta Highlight)
- Darunter **Transport-Leiste** (Play/Stop/Rec/Loop + Time + BPM + TS + Metronom/Count-In)
- Darunter **Werkzeug/Grid/Snap/Automation** Reihe

**Was umgesetzt:**
- [x] `setMenuWidget(Header)` entfernt → QMenuBar ist wieder sichtbar (wie Rosegarden-Style)
- [x] Zwei Top-Toolbars hinzugefügt: `TransportPanel` + `ToolBarPanel`
- [x] QSS ergänzt: Menü-Highlight Magenta + Toolbar-Styles (wie Screenshot)
- [x] Actions/Shortcuts bleiben unverändert; Notation/PianoRoll nicht angerührt

**Files:**
- `pydaw/ui/main_window.py`
- `VERSION`
- `pydaw/version.py`

#### 1d. Crash-Fix: TransportPanel BPM Sync + PyQt Slot-Safety ✅ DONE (v0.0.19.7.29)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~15min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Problem (User-Report):**
- `AttributeError: 'TransportPanel' object has no attribute 'set_bpm'` beim Projekt-Open-Sync
- PyQt6 `SIGABRT` bei Exceptions in Slots (z. B. Double-Click im Arranger/Notation) → Qt `fatal` / Program-Abbruch

**Fix:**
- [x] `TransportPanel.set_bpm()` ergänzt (signal-safe via `blockSignals`)
- [x] MainWindow: Arranger/Launcher/Transport Signal-Verbindungen über `_safe_call()` abgesichert (keine uncaught Exceptions mehr)
- [x] Notation: `ScoreView.mouseDoubleClickEvent` exception-safe
- [x] Arranger: `ArrangerCanvas.mouseDoubleClickEvent` exception-safe

**Files:**
- `pydaw/ui/transport.py`
- `pydaw/ui/main_window.py`
- `pydaw/ui/arranger_canvas.py`
- `pydaw/notation/gui/score_view.py`

---

---

#### 1e. Feature: Python-Logo Button (oben rechts) + 2-Minuten Animation + Toggle ✅ DONE (v0.0.19.7.30)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~20min  
**Priority:** 🟠 MEDIUM  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Runder Python-Logo-Button im Header (rechts, direkt neben **Automation**)
- [x] QTimer-basierter Farbwechsel nach exakt 2 Minuten (UI-only, asynchron zur Audio-Engine)
- [x] Menüpunkt: Hilfe → Arbeitsmappe → **Animation ein/aus** (Status persistent via Settings)
- [x] Sauberes Cleanup (Timer stoppen beim Deaktivieren/Shutdown)

**Files:**
- `pydaw/ui/main_window.py`
- `pydaw/ui/toolbar_panel.py`
- `pydaw/ui/actions.py`

#### 1f. Bugfix: Loop-Range Parameter Sync (Regression v28→v29/v30) ✅ DONE (v0.0.19.7.31)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~10min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Fix:**
- [x] `loop_region_committed(enabled, start, end)` korrekt an `_on_arranger_loop_committed(enabled, start, end)` gebunden
- [x] `transport.loop_changed(enabled, start, end)` korrekt an `_on_transport_loop_changed(enabled, start, end)` gebunden
- [x] Ergebnis: Visuals & Playback wieder 1:1 synchron (kein Offset, keine Default-Loop-Region)

**Files:**
- `pydaw/ui/main_window.py`
- `VERSION`
- `pydaw/version.py`

#### 1g. Feature: Custom Painted Qt-Logo Button (Bottom-Left) ✅ DONE (v0.0.19.7.32)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~10min  
**Priority:** 🟢 LOW  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Runder Qt-Logo-Button unten links, **direkt vor dem ersten Tab (Arranger)**
- [x] Logo komplett per Code gezeichnet (QPainter, Antialiasing) – **keine externen Assets**
- [x] Button ist wirklich rund via `setMask(...Ellipse)` (Fallback-safe)
- [x] Klick-Handler: Platzhalter `print("Qt-Legacy-Menu")`

**Files:**
- `pydaw/ui/qt_logo_button.py` (NEU)
- `pydaw/ui/main_window.py`
- `VERSION`, `pydaw/version.py`

#### 1h. Add-on: Vektor-Rendering für den Python-Button (No Asset) ✅ DONE (v0.0.19.7.33)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~15min  
**Priority:** 🟠 MEDIUM  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Python-Logo Button oben rechts (neben Automation) rendert das Logo **komplett per QPainterPath** (keine .png/.jpg/.xpm mehr nötig)
- [x] Dynamische Farblogik über Variablen `color_top` / `color_bottom` (Initial: #3776AB / #FFD43B)
- [x] QTimer-Event nach exakt 2 Minuten setzt beide Farben auf **#FF6000** und ruft `update()` auf (kein Icon-Swap, kein Flicker)
- [x] Cleanup: Timer ist SingleShot und wird beim Deaktivieren/Shutdown gestoppt

**Files:**
- `pydaw/ui/python_logo_button.py` (NEU)
- `pydaw/ui/toolbar.py`
- `pydaw/ui/main_window.py`
- `VERSION`, `pydaw/version.py`

#### 1i. UI-Fix: Tools-Row volle Breite + Python-Logo sichtbar + Device-Tab unten ✅ DONE (v0.0.19.7.36)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~25min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] `ToolBarPanel` auf `QSizePolicy.Expanding` gesetzt → Tools-Row nutzt die volle Breite (keine Clipping-Regressions)
- [x] Python-Logo-Button oben rechts ist wieder sichtbar (neben Automation)
- [x] Qt-Logo-Button unten links an die äußere Ecke ausgerichtet (keine unnötige Left-Padding)
- [x] Neuer Bottom-View Tab **Device** + eigener Dock (Placeholder)

**Files:**
- `pydaw/ui/toolbar.py`
- `pydaw/ui/main_window.py`
- `pydaw/ui/device_panel.py` (NEU)
- `VERSION`, `pydaw/version.py`

#### 1j. Bugfix: Python-Logo Button paintEvent (QRect → QRectF) ✅ DONE (v0.0.19.7.37)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~3min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Fix:**
- [x] `QPainterPath.addEllipse()` erwartet in PyQt6 `QRectF` (nicht `QRect`) → Umstellung auf `r.toRectF()`.
- [x] Ergebnis: kein Traceback-Spam mehr, UI bleibt stabil.

**Files:**
- `pydaw/ui/python_logo_button.py`
- `VERSION`, `pydaw/version.py`

#### 1k. Feature: Drag & Drop Audio aus Browser → Overlay Clip-Launcher ✅ DONE (v0.0.19.7.39)
**Assignee:** [x] GPT-5.2 (2026-02-05) ✅ DONE  
**Aufwand:** ~45min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Browser (Samples) startet Drag → Arranger blendet ein semitransparentes **Clip-Launcher-Overlay** über dem Canvas ein
- [x] Drag-End / Abbruch → Overlay blendet weich aus und deaktiviert Drops (keine Kollisionen mit Arranger)
- [x] Slot-Highlight in Pro-DAW-Cyan + Ghost-Cursor (Icon/Preview) während Drag
- [x] Drop auf Slot → AudioClip wird erzeugt (Clip-Name = Dateiname), auf nächste Bar gesnappt, und dem Slot zugewiesen
- [x] `ProjectService`: Launcher-Settings + Slot-Assign/Clear + optionales `launcher_slot_key` beim Audio-Import

**Files:**
- `pydaw/ui/sample_browser.py`
- `pydaw/ui/clip_launcher_overlay.py`
- `pydaw/ui/arranger.py`
- `pydaw/ui/main_window.py`
- `pydaw/services/project_service.py`

#### 1l. Bugfix: Clip-Launcher Drop-Overlay blockiert Arranger + erzeugt Timeline-Clip ❌ → ✅ DONE (v0.0.19.7.40)
**Assignee:** [x] GPT-5.2 (2026-02-05) ✅ DONE  
**Aufwand:** ~25min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Problem (User-Report):**
- Drop auf Clip-Launcher-Overlay füllt Slot **und** legt zusätzlich einen Clip im Arranger ab → **darf nicht sein**
- Wenn Clip-Launcher in Ansicht deaktiviert ist, wird beim Sample-Drag trotzdem das Overlay über den ganzen Arranger aktiviert → normales Drag&Drop auf Tracks unmöglich

**Fix:**
- [x] **Slot-Drop erzeugt nur noch Launcher-Clip** (`place_in_arranger=False`, `launcher_only=True`) → keine Timeline-Clips mehr
- [x] Overlay wird **nur** aktiviert wenn **Ansicht → Clip Launcher** aktiv **und** **Ansicht → Overlay ein/aus** aktiv ist
- [x] Overlay wird beim Deaktivieren von Clip Launcher / Overlay sofort deaktiviert (Arranger nie blockiert)
- [x] Neuer Menüpunkt: **Ansicht → Overlay ein/aus** (persistiert)

**Files:**
- `pydaw/ui/main_window.py`
- `pydaw/ui/actions.py`
- `pydaw/core/settings.py`
- `VERSION`, `pydaw/version.py`

---
---

## 🔥 AKTUELLER WORKFLOW (VERANKERT!)

**Phase 1:** Ghost Notes bis 100% fertigstellen  
**Phase 2:** Dann zurück zu Notation (Multi-Track, Chords, Lyrics)

**Siehe:** `PROJECT_DOCS/features/GHOST_NOTES_COMPLETION_ROADMAP.md`

---

## 🎭 GHOST NOTES - COMPLETION (PRIORITY!)

### ✅ Was ist fertig (90%)
- [x] Datenmodell (LayerManager, GhostLayer)
- [x] Layer Panel UI
- [x] Piano Roll Ghost Rendering
- [x] Notation Ghost Rendering
- [x] Integration komplett
- [x] Dokumentation
- [x] Clip-Auswahl-Dialog ✅
- [x] **Bugfixes & Polish ✅ NEU!**

### ⏳ Was fehlt noch (10%)

#### 1m. Bugfix/Feature: Clip-Launcher Overlay Drop (Scene-Index + Arranger-Block) + Slot-Waveform Preview ✅ DONE (v0.0.19.7.41)
- Overlay nutzt Scene 1..N und akzeptiert DragMove/Drop vollständig → Arranger bekommt nichts ab
- `add_audio_clip_from_file_at(... place_in_arranger=False)` setzt `clip.launcher_only=True`
- Clip-Launcher Slots zeigen Name + echte Waveform (Peaks-Cache, wie Arranger)

#### ~~1. Clip-Auswahl-Dialog~~ ✅ FERTIG (v0.0.19.3.7.17)

#### ~~2. Bugfixes & Polish~~ ✅ FERTIG (v0.0.19.3.7.18)
**Assignee:** [x] Claude-Sonnet-4.5 (2026-02-01 14:10) ✅ DONE  
**Aufwand:** 20min  
**Status:** ✅ FERTIG

**Was gefixt:**
- [x] Canvas C8-C9 unsichtbar → MinimumHeight erhöht + Padding
- [x] Auto-Scroll → Bereits optimal (QScrollArea)
- [x] Farben → Bereits identisch Piano Roll = Notation
- [x] Glow-Effect → Multi-Layer Glow für selektierte Noten hinzugefügt

---

#### 3. Testing & Validation (MEDIUM - JETZT!)
**Assignee:** [x] (GPT-5.2, 2026-02-01 18:10) ✅ DONE  
**Aufwand:** ~35min  
**Priority:** 🟢 MEDIUM  
**Status:** ✅ FERTIG

**Was erledigt (Validation + Blocker-Fix):**
- [x] **Crash-Fix:** Notation-Ghost-Notes Painting konnte Exceptions werfen (z.B. falsches Style-Attribut) → PyQt6 abort (SIGABRT). Jetzt: robustes, exception-sicheres Paint + korrekte Staff-Geometrie.
- [x] Defensive Rendering: `QGraphicsItem.paint()` in Ghost Notes lässt **keine** Exceptions mehr entkommen (Logger + safe restore).
- [x] Edge Case: Ghost-Layer Notes mit Accidental/Lock/Opacity werden ohne AttributeErrors gerendert.

**Manueller Test-Plan (für User / Team):**
1) Projekt mit 2+ MIDI Clips öffnen → Layer Panel → 2 Ghost Layers hinzufügen → Notation öffnen → App darf nicht crashen.
2) Layer Visibility toggeln / Focus wechseln / Lock toggeln → UI bleibt stabil.
3) 5+ Layers hinzufügen → Scroll/Zoom/Redraw → keine Stotter-/Crashs.

---

#### 4a. Layer Persistenz (Projekt speichern/laden) ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-01 19:45) ✅ DONE  
**Aufwand:** ~35min  
**Priority:** 🔵 LOW  

**Was umgesetzt (DSP/JACK):**
- [x] Neue `pydaw/audio/dsp_engine.py`: Summing + Master Gain/Pan im JACK-Callback (ultra-defensiv)
- [x] `AudioEngine` JACK-Pfad nutzt DSP Engine als Render-Callback (statt direktem Clip-Renderer)
- [x] Master-Volume/Pan wirkt jetzt auch im JACK/qpwgraph Pfad
- [ ] (später) Pull-Sources für Realtime-Synth/Tracks registrieren
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] LayerManager/GhostLayer Serialisierung (JSON-safe)
- [x] Persistenz in `Project` (`ghost_layers`) gespeichert
- [x] Laden beim Öffnen von Piano Roll & Notation
- [x] Auto-Save in Project-Model bei Layer-Änderungen (UI: Layer Panel)

---

#### 4b. Optional Enhancements (LOW - OPTIONAL) ✅ DONE (v0.0.19.7.38)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** 1-3h  
**Priority:** 🔵 LOW

#### 4c. Arranger Duplicate Workflow Fix (Ctrl+D / Ctrl+Drag) ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-03) ✅ DONE  
**Aufwand:** ~25min  
**Priority:** 🟢 MEDIUM  

- [x] **Ctrl+D** dupliziert Clips jetzt **horizontal** (gleiche Spur) und startet **am Ende** des Originals (End-Snap).
- [x] **MIDI-Inhalt wird übernommen** (Deepcopy der Notes) → keine leeren Kopien.
- [x] Crash-Fix: `ProjectService.add_note` Alias hinzugefügt (Kompatibilität für UI-Pfade).
- [x] Ctrl+Drag horizontal duplicate: Copy-Notes via Deepcopy, ohne `add_note()`-Crash.

- [x] Notation Palette (1/1..1/64, dotted, rests, accidentals, ornament markers) + Editor-Notes (Sticky Notes) (GPT-5.2, 2026-02-01)
- [x] Keyboard Shortcuts (Alt+1..7, Alt+., Alt+R) (GPT-5.2, 2026-02-02)
- Solo/Mute Features
- [x] Workbook Dialog Integration (Hilfe → Arbeitsmappe) (GPT-5.2, 2026-02-02)
- [x] Scale Lock: Drag/Move Enforcement + Mode UI (exklusiv Snap/Reject) (GPT-5.2, 2026-02-02)
- [x] Scale Visualization: Pro-DAW cyan dots (Piano Roll Grid/Keyboard) (GPT-5.2, 2026-02-02)

---

## ⏸️ NOTATION - PAUSIERT (Nach Ghost Notes!)

Diese Tasks kommen NACH Ghost Notes 100% Completion:

### Task 15: Tie/Slur MVP (Marker + UI)
**Aufwand:** 1h  
**Status:** ✅ FERTIG (v0.0.19.5.1.6)

**Assignee:** [x] GPT-5.2 (2026-02-01) ✅ DONE

**Lieferumfang (MVP):**
- [x] Tool-Buttons in Notation: Tie (⌒) und Slur (∿)
- [x] 2-Klick Workflow: Startnote → Endnote
- [x] Persistente Marks in `Project.notation_marks` (type: "tie"/"slur")
- [x] Rendering als Kurve im Notations-Score
- [x] Cancel durch Klick ins Leere

### Task 16: Tie Playback (echt) – Notes mergen ✅
**Aufwand:** 45min  
**Status:** ✅ FERTIG (v0.0.19.5.1.8)

**Assignee:** [x] GPT-5.2 (2026-02-01) ✅ DONE

**Lieferumfang:**
- [x] Tie-Marks beeinflussen Playback/Render: Notes mit gleicher Tonhöhe werden als **eine lange Note** behandelt.
- [x] Umsetzung ist **non-destructive**: Projekt-Notes werden nicht verändert, nur fürs Rendering gemerged.
- [x] Render-Cache invalidiert automatisch, weil Content-Hash auf gemergten Notes basiert.
- [x] Unterstützt Tie-Chains (A→B→C …).

**Geänderte Files:**
- `pydaw/audio/arrangement_renderer.py`
- `pydaw/audio/audio_engine.py`

---

### Task 17: Tie/Slur Editing (Delete/Context) + Overlay-Modus ✅

- Status: **DONE**
- Owner: GPT-5.2
- [x] Tie/Slur/Marks sind selektierbar
- [x] Delete/Backspace löscht selektierte Marks (Tie/Slur/Ornaments), danach Notes
- [x] Kontextmenü „Löschen“ per Rechtsklick auf Tie/Slur/Mark
- [x] Tie/Slur sind jetzt **Overlay-Modi**: Stift bleibt aktiv, Bögen lassen sich zusätzlich setzen

### Task 18: Audio Settings Stabilität (Backend nicht mehr überschreiben) ✅

- Status: **DONE**
- Owner: GPT-5.2
- [x] Backend wird nie mehr durch „JACK Client aktivieren“ umgeschaltet
- [x] JACK Controls bleiben nutzbar **unabhängig vom Backend** (Ports/Recording via qpwgraph)
- [x] Sounddevice/PortAudio Auswahl bleibt stabil nach OK/Neustart
- [x] Crash-Fix: Audio-Settings Dialog hatte defekte Indentation → PyQt6 SIGABRT beim Start

---

### Task 19: Performance — MIDI Pre-Render ("Ready for Bach") ✅

- Status: **DONE**
- Owner: GPT-5.2
- [x] MIDI-Clips werden optional im Hintergrund (Pre-Render) in den bestehenden Render-Cache gerendert.
- [x] UI: Progress-Dialog (Audio-Menü) + Abbrechen-Flag.
- [x] Auto-Start nach Projekt-Open/Snapshot-Load (silent) + Option, vor Play zu warten.
- [x] Audio-Einstellungen: Pre-Render Optionen (Auto-Load, Progress bei Load, Wait-before-Play, Progress bei Play) (GPT-5.2, 2026-02-02)
- [x] Scope-Pre-Render: ausgewählte Clips / ausgewählter Track (Audio-Menü) (GPT-5.2, 2026-02-02)

**Geänderte Files:**
- `pydaw/services/project_service.py`
- `pydaw/ui/actions.py`
- `pydaw/ui/main_window.py`
### Task 12: Multi-Track Notation
**Aufwand:** 4h  
**Status:** ⏸️ Pausiert bis Ghost Notes fertig

---

### Task 13: Chord-Symbols  
**Aufwand:** 2h  
**Status:** ⏸️ Pausiert bis Ghost Notes fertig

---

### Task 14: Lyrics-Support
**Aufwand:** 3h  
**Status:** ⏸️ Pausiert bis Ghost Notes fertig

---

### Task 0: Ghost Notes / Layered Editing - ✅ INTEGRIERT
**Status:** ✅ VOLLSTÄNDIG INTEGRIERT in DAW  
**Developer:** Claude-Sonnet-4.5 (2026-02-01)  
**Aufwand:** Implementation: ~90min, Integration: ~30min  
**Version:** v0.0.19.5.1.9  
**Session Log:** `PROJECT_DOCS/sessions/2026-02-01_SESSION_GHOST_NOTES.md`

**Was implementiert:**
- [x] Datenmodell (LayerManager, GhostLayer)
- [x] Layer Panel UI
- [x] Piano Roll Ghost Rendering
- [x] Notation Ghost Rendering
- [x] Integration-Dokumentation

**Was integriert:**
- [x] Piano Roll Canvas erweitert (Ghost Rendering aktiv)
- [x] Notation View erweitert (Ghost Rendering aktiv)
- [x] Piano Roll Editor (Layer Panel eingebunden)
- [x] Notation Widget (Layer Panel eingebunden)
- [x] Alle Syntax-Checks bestanden

**Status:** ✅ FERTIG - Feature ist jetzt voll funktionsfähig in der DAW!

**Nutzung:**
1. Öffne Piano Roll oder Notation für einen MIDI-Clip
2. Layer Panel ist am unteren Rand sichtbar
3. Klicke "+ Add Layer" um Ghost Layers hinzuzufügen
4. Ghost Notes werden automatisch gerendert

---

## 🔥 CRITICAL (v0.0.20.0 MVP - Diese Session!)

### Task 1: Daten-Model erweitern
**File:** `pydaw/model/midi.py`  
**Assignee:** [x] (GPT-5.2, 2026-01-31 08:15) ✅ DONE  
**Aufwand:** 1h  
**Status:** ✅ FERTIG

**Was zu tun:**
```python
# In MidiNote-Klasse hinzufügen:
@dataclass
class MidiNote:
    # ... existing fields ...
    accidental: int = 0      # -1=♭, 0=none, 1=♯
    tie_to_next: bool = False

    def to_staff_position(self) -> tuple[int, int]:
        """Konvertiert MIDI-Note zu Staff-Position."""
        pass
    
    def from_staff_position(line: int, octave: int) -> int:
        """Konvertiert Staff-Position zu MIDI-Note."""
        pass
```

**Erfolg:** Tests laufen durch (`python -m unittest discover -s tests`)  
**Blocker:** Keine  
**Blocks:** Task 2

---

### Task 2: Staff-Renderer implementieren
**File:** `pydaw/ui/notation/staff_renderer.py` (NEU)  
**Assignee:** [x] (GPT-5.2, 2026-01-31 09:10) ✅ DONE  
**Aufwand:** 2h  
**Status:** ✅ FERTIG

**Was zu tun:**
```python
class StaffRenderer:
    def render_staff(painter: QPainter, width: int, y_offset: int):
        """Zeichne 5-Linien-System."""
        pass
    
    def render_note_head(painter: QPainter, x: float, line: int):
        """Zeichne Notenkopf."""
        pass
    
    def render_stem(painter: QPainter, x: float, line: int, up: bool):
        """Zeichne Notenhals."""
        pass
    
    def render_accidental(painter: QPainter, x: float, line: int, accidental: int):
        """Zeichne ♯/♭."""
        pass
```

**Erfolg:** Rendering funktioniert in Test-Widget  
**Blocker:** Keine  
**Blocks:** Task 3

---

### Task 3: NotationView Widget erstellen
**File:** `pydaw/ui/notation/notation_view.py` (NEU)  
**Assignee:** [x] (GPT-5.2, 2026-01-31 10:15) ✅ DONE  
**Aufwand:** 1h  
**Status:** ✅ FERTIG

**Was zu tun:**
```python
class NotationView(QGraphicsView):
    # Signals
    notes_changed = pyqtSignal()
    
    def set_clip(self, clip_id: str):
        """Lade Noten vom ProjectService."""
        pass
    
    def _render_notes(self, notes: list[MidiNote]):
        """Rendere alle Noten."""
        pass
```

**Erfolg:** Noten aus Piano Roll werden angezeigt  
**Blocker:** Task 2  
**Blocks:** v0.0.20.0 Release

---

## 🟡 HIGH (v0.0.20.1 - Nächste Session)

### Task 4: Draw-Tool
**File:** `pydaw/ui/notation/tools.py` (NEU)  
**Assignee:** [x] (GPT-5.2, 2026-01-31 11:30) ✅ DONE  
**Aufwand:** 1h
**Status:** ✅ FERTIG

```python
class DrawTool:
    def handle_mouse_press(pos: QPoint):
        # Convert pos → MIDI note
        # Add to ProjectService
        pass
```

---

### Task 5: Erase-Tool
**File:** `pydaw/ui/notation/tools.py`  
**Assignee:** [x] (GPT-5.2, 2026-01-31 08:40) ✅ DONE  
**Aufwand:** 30min
**Status:** ✅ FERTIG

**Ergebnis (MVP):**
- Löschen per **Rechtsklick** im NotationView (routet zu `EraseTool`)
- Löscht die *nächste* Note an Beat+Staff-Line (mit Grid-Toleranz) inkl. Undo

---

### Task 6: Select-Tool
**File:** `pydaw/ui/notation/tools.py`  
**Assignee:** [x] (GPT-5.2, 2026-01-31 13:05) ✅ DONE  
**Aufwand:** 30min  
**Status:** ✅ FERTIG

**Ergebnis (MVP):**
- Linksklick wählt die nächste Note (Beat+Staff-Line, gleiche Heuristik wie Erase)
- Klick ins Leere löscht Auswahl
- Klick auf die selektierte Note toggelt Auswahl aus
- Sichtbare Auswahl als blauer Outline-Rahmen um den Notenkopf
- Minimaler Tool-Switch in der Notation-Toolbar (✎ Draw / ⬚ Select)

---

### Task 7: Bidirektionale MIDI-Sync
**File:** `pydaw/ui/notation/notation_view.py`  
**Assignee:** [x] (GPT-5.2, 2026-01-31 08:55) ✅ DONE  
**Aufwand:** 1h

**Was zu tun:**
- [x] Refresh bei `project_updated` nur wenn Noten im aktiven Clip wirklich geändert wurden (Signature-Check)
- [x] Recursion verhindern (Suppress-Budget für Updates wenn Notation schreibt)
- [x] Clip-Selection Sync: Notation folgt `active_clip_changed` / `clip_selected` (nur MIDI-Clips)

**Ergebnis:**
- NotationView refresht stabil (kein Signal-Sturm, keine Feedback-Loops)
- NotationWidget wechselt automatisch auf den ausgewählten MIDI-Clip

**Test/Demo:**
```bash
python3 -m pydaw.ui.notation.notation_view
# im vollen DAW-Projekt: MIDI-Clip auswählen → Notation folgt
```

---

## 🟢 MEDIUM (v0.0.20.2 - Session 3)

### Task 7b: MIDI Monitoring ohne Recording (Live-Play)
**Files:** `pydaw/services/midi_manager.py`, `pydaw/ui/pianoroll_editor.py`, `pydaw/ui/main_window.py`  
**Assignee:** [x] (GPT-5.2, 2026-02-07) ✅ DONE  
**Aufwand:** 0.5h

**Was gemacht:**
- [x] PianoRoll-Button **Record** toggelt MIDI-Record (Noten werden nur dann in den Clip geschrieben)
- [x] Live-MIDI Monitoring bleibt immer aktiv (über live_note_on/off)

---

### Task 8: Keyboard-Shortcuts
**File:** `pydaw/ui/notation/notation_view.py`  
**Assignee:** [x] (GPT-5.2, 2026-01-31 11:15) ✅ DONE  
**Aufwand:** 1h

**Status:** ✅ FERTIG

**Was gemacht:**
- [x] D/S/E Tool-Switch (Draw/Select/Erase)
- [x] Ctrl+C/V/X Copy/Paste/Cut (Single-Note MVP)
- [x] Ctrl+Z Undo über ProjectService
- [x] Del/Backspace: Delete selected note (Undo-fähig)

- [x] D → Draw-Tool
- [x] E → Erase-Tool  
- [x] S → Select-Tool
- [x] Ctrl+C/V/X → Copy/Paste/Cut
- [x] Ctrl+Z → Undo
- [x] Del → Delete

---

### Task 9: Clip-Auto-Erweiterung
**File:** `pydaw/services/project_service.py`  
**Assignee:** [x] (GPT-5.2, 2026-02-01 12:30) ✅ DONE  
**Aufwand:** 1h

```python
def extend_clip_if_needed(clip_id: str, end_beats: float):
    """Erweitert einen MIDI-Clip automatisch (bis zur nächsten Bar)."""
    ...  # implementiert in ProjectService
```

---

### Task 10: Farb-System
**File:** `pydaw/ui/notation/colors.py` (NEU)  
**Assignee:** [x] (GPT-5.2, 2026-01-31 11:50) ✅ DONE  
**Aufwand:** 30min

Velocity → Color Mapping wie Piano Roll

---

### Task 11: Context-Menu
**File:** `pydaw/ui/notation/notation_view.py`  
**Assignee:** [x] (GPT-5.2, 2026-01-31 08:20) ✅ DONE  
**Aufwand:** 1h

**Status:** ✅ FERTIG

Rechtsklick ohne Crash (QTimer.singleShot)

---

## 🔵 LOW (v0.0.21.0 - Future)

### Task 12: Multi-Track Notation
**Aufwand:** 4h

---

### Task 13: Chord-Symbols
**Aufwand:** 2h

---

### Task 14: Lyrics-Support
**Aufwand:** 3h

---

## 🐛 BUG FIXES

### Critical
- [ ] **Stop-Button Crash** → Buttons entfernt ✅ DONE
- [x] **Notation Context-Menu Segfault** → Task 11 ✅ DONE

### High
- [ ] **Canvas C8-C9 unsichtbar** → Task 2 (erhöhe MinimumHeight)
- [ ] **Auto-Scroll buggy** → Task 3 (fix scroll logic)
- [ ] **Tempo nicht sync** → Task 7

### Medium
- [ ] **Farben nicht identisch** → Task 10
- [ ] **Glow-Effect fehlt** → Task 10

---

## ✅ DONE (Diese Session)

### 07:30
- [x] Projektstruktur `PROJECT_DOCS/` erstellt (Claude, 2026-01-31)
- [x] MASTER_PLAN.md geschrieben (Claude, 2026-01-31)
- [x] Diese TODO.md erstellt (Claude, 2026-01-31)

---

## 📊 QUICK WINS (Für Einsteiger)

### Easy Tasks (30min-1h)

#### A: Constants definieren
**File:** `pydaw/ui/notation/constants.py` (NEU)  
**Aufwand:** 15min

```python
# Staff-Größen
STAFF_LINE_DISTANCE = 10  # Pixel
STAFF_LINES = 5
NOTE_HEAD_WIDTH = 8
NOTE_HEAD_HEIGHT = 6
# ...
```

#### B: Colors definieren
**File:** `pydaw/ui/notation/colors.py` (NEU)  
**Aufwand:** 30min

```python
VELOCITY_COLORS = {
    range(1, 32): QColor(100, 100, 255),
    # ...
}
```

#### C: Docstrings hinzufügen
**File:** Diverse  
**Aufwand:** 1h

Füge Docstrings zu existierenden Funktionen hinzu

---

## 📝 TASK-FORMAT

### Wie Task markieren:
```markdown
### Task X: Name
**Assignee:** [x] (Dein Name, Datum)
```

### Beispiel:
```markdown
### Task 1: Daten-Model erweitern
**Assignee:** [x] (Max, 2026-01-31 08:00)
**Status:** 🚧 IN ARBEIT
```

### Nach Fertigstellung:
```markdown
**Assignee:** [x] (Max, 2026-01-31 08:00) ✅ DONE
**Status:** ✅ FERTIG
```

Dann in `DONE.md` eintragen!

---

**Letzte Aktualisierung:** 2026-01-31 09:00  
**Aktualisiert von:** GPT-5.2  
**Nächster Check:** Nach jeder Session

## Arranger
- [x] Lasso/Mehrfachauswahl: Group-Move beim Drag (Arranger) (ChatGPT, 2026-02-02)

## Optional / Nice-to-have Enhancements

- [x] Notation: Grid + Y-Scroll/Y-Zoom + Scale-Badge (12 dots + Root) (2026-02-03, GPT-5.2)

## Next
- [x] Hotfix: Mixer HybridBridge Wiring (Track-Fader live + VU-Meter live) (2026-02-08, GPT-5.2)
- [x] Hotfix: SamplerWidget _reflow_env missing + DevicePanel device width stretch (2026-02-05, GPT-5.2)
- Sampler: Parameter-Storage im Projekt (Session Save/Load)
- Sampler: Multi-Instance Routing / Device-Chain UI polish

## v0.0.20.51 (2026-02-10)

- [x] FIX: Sampler/DrumMachine stumm bei Playback (nur Note-Preview hörbar)
  - Ursache: Pull-Sources wurden als plain functions registriert, Callback erwartet `.pull()`
  - Lösung: AudioEngine.register_pull_source wrapped Callables → `.pull(frames, sr)` Adapter
  - Robustness: HybridEngine kann zusätzlich callables direkt aufrufen (Fallback)
  - Legacy: MIDI-Event track_id/velocity in EngineThread._prepare_clips korrigiert (id + int velocity)

## v0.0.20.52 (2026-02-11)

- [x] Legacy-Arrangement: Pull-Sources (Sampler/Drum) wie Master/Hybrid mischen (Vol/Pan/Mute/Solo)
- [x] Mixer-VU: per-Track Peaks für Pull-Sources schreiben (AudioEngine._direct_peaks)
- [x] Hybrid parity: Pull-Sources track-aware auch im Hybrid-Callback + render_for_jack

## v0.0.20.53 — Doku: Audio-System (SF2/Sampler/Drum) + Version-Sync (2026-02-12)

### Task 1: Audio-System Dokumentation
**Assignee:** [x] (ChatGPT, 2026-02-12)
**Status:** ✅ DONE

- Neue technische Gesamtdoku: `PROJECT_DOCS/plans/AUDIO_SYSTEM.md`
- Doku-Index aktualisiert: `PROJECT_DOCS/README.md`
- Versionsstrings konsistent: `VERSION`, `pydaw/version.py`, `pydaw/model/project.py`

---


## v0.0.20.54 — Doku: README 1-Seiten Audio-Routing Map (2026-02-12)

**Assignee:** [x] (ChatGPT, 2026-02-12)  
**Status:** ✅ DONE

- [x] `README_TEAM.md`: TL;DR Audio-Routing Map (ASCII) hinzugefügt
- [x] Version-Strings konsistent: `VERSION`, `pydaw/version.py`, `pydaw/model/project.py`

---

## v0.0.20.55 — Brand-Safe Rename (Naming Cleanup) (2026-02-12)

**Assignee:** [x] (ChatGPT, 2026-02-12)  
**Status:** ✅ DONE

- [x] Markenbezogene Begriffe aus Code/Doku entfernt
- [x] Device Browser: `pydaw/ui/device_browser.py` (Class: `DeviceBrowser`) eingebunden
- [x] Audio Export Dialog: `pydaw/ui/audio_export_dialog.py` (Class: `AudioExportDialog`) eingebunden
- [x] UI ObjectNames/Theme helper vereinheitlicht (Prefix `chrono*`, `_apply_chrono_theme()`)
- [x] Version-Strings konsistent: `VERSION`, `pydaw/version.py`, `pydaw/model/project.py`
- [x] Session-Log: `PROJECT_DOCS/sessions/2026-02-12_SESSION_v0.0.20.55_BRAND_SAFE_RENAME.md`

---

## v0.0.20.57 — Nächste Schritte (nach Tests)

Hinweis: v0.0.20.57 ist ein Hotfix für einen `IndentationError` in `pydaw/model/project.py`.
Die nächsten fachlichen Schritte bleiben identisch.

- [x] UI: Device/FX Browser Einträge für Note-FX + Audio-FX (Add/Remove/Reorder, Presets). (GPT-5.2, 2026-02-13)
- [ ] Automations-Lanes: RTParamStore Keys für FX-Parameter im UI sichtbar machen.
- [ ] Note-Off Semantik: SamplerRegistry.note_off ist monophonic → optional Pitch-aware NoteOff in Zukunft.

## v0.0.20.59 (2026-02-13) — FX UI + Note-FX processing MVP polish

[x] FIX: DeviceBrowser Crash (missing _placeholder) — DeviceBrowser startet wieder.
[x] UI: Gain-Device Parameter UI (dB-Regler pro Gain-Device) im Audio-FX CHAIN Editor.
[x] UI: Note-FX CHAIN Editor (Transpose + Velocity-Scale) inkl. Add/Remove/Reorder/Enable + Presets.
[x] ENGINE: fx_chain RTParamStore API fix (get_smooth statt get_param; ensure statt ensure_param) + gain_db Support.
---

## v0.0.20.61 (2026-02-13) — GO Note-FX Parameter UI + Fix FX Editor Regression

**Assignee:** [x] (ChatGPT, 2026-02-13)  
**Status:** ✅ DONE

- [x] Fix: `pydaw/ui/audio_fx_chain_editor.py` vollständig bereinigt (Indent/Handler Regression weg).
- [x] UI: Note-FX Parameter UI fertig: Transpose, VelScale, ScaleSnap (Root/Scale/Mode), Chord (Type), Arp (Step/Mode/Oct/Gate), Random (Pitch/Vel/Prob).
- [x] Presets + Reorder + Enable/Disable bleiben intakt.
- [x] Version-Strings konsistent: `VERSION`, `pydaw/version.py`, `pydaw/model/project.py`.

## v0.0.20.97 — Ruler-Zoom (Lupe überall, nicht nur links)

- [x] Arranger-Ruler: Lupe folgt Maus-X über die komplette Timeline; Cursor wird im oberen Lineal-Band zur Lupe; Zoom-Drag bleibt erreichbar auch bei Bar 500+.
- [x] Loop-Editing bleibt nutzbar im unteren Lineal-Band (keine Kollision mit Zoom-Band).

---

## v0.0.20.102 — Bachs Orgel Warm/Clean Voicing (2026-02-21)

- [x] Bachs Orgel: neues `voicing` (`warm`/`clean`) mit weicheren Default-Presets
- [x] Warm-Modus (Forge-inspirierte additive Mischung) gegen blechern/kratzigen Klang
- [x] UI/Persistenz track-lokal (`instrument_state`) + Session-Log erstellt



## v0.0.20.121 — Vorschlag (UI-only)

- [ ] DevicePanel: Batch-Buttons optional links/rechts anordnen + Icon-Legende in Arbeitsmappe/Tooltip verfeinern.
- [ ] Optional: „Nur aktive Card offen lassen“ (Focus-Mode light, UI-only).

- [x] DONE (ChatGPT, 2026-02-22) DevicePanel UI: Eingeklappte Minikarten kompakter darstellen (stabile Kompaktbreite + Titel-Cap/Elide), UI-only.


## [x] DONE (GPT-5.2 Thinking, 2026-02-22) — DevicePanel Zone-Fokus: Status-Hinweis + Reset (UI-only)
- Sichtbares Status-Badge im DevicePanel-Header (`NORMAL`, `ZONE N/I/A`, `FOKUS ◎`) ergänzt.
- Klarer Reset-Button (`Reset`) auf „Alle Zonen normal“ ergänzt (UI-only, alle gerenderten Cards offen).
- Hover-Hinweiszeile + Button-Enable-Logik erweitert.
- Nur UI, keine Änderungen an Engine/DSP/DnD.

### Nächster sinnvoller Task (AVAILABLE)
- [ ] AVAILABLE — DevicePanel Zone-Fokus: ESC als schneller Reset auf Normalansicht (UI-only).
- [ ] AVAILABLE — DevicePanel Header-Badge optional anklickbar (Dropdown/Quick-Reset), UI-only.

## [x] DONE (GPT-5.2 Thinking, 2026-02-22) — DevicePanel Zone-Fokus: ESC als Reset auf Normalansicht (UI-only)
- ESC-Shortcut im DevicePanel ergänzt (`WidgetWithChildrenShortcut`) → setzt Fokus-/Zonen-/Collapse-Ansicht schnell auf Normalansicht zurück.
- Nutzt bestehende Reset-Logik (`Reset`-Button), daher keine Änderungen an Audio/DSP/Engine/DnD/Reorder/Projektmodell.
- Hint-/Tooltip-Texte um `Esc = Reset` ergänzt.

### Nächster sinnvoller Task (AVAILABLE)
- [x] DONE (GPT-5.2 Thinking, 2026-02-22) — DevicePanel: Reset-Button als kompaktes Header-Icon (↺) mit Tooltip/Status-Akzent (UI-only).
- [ ] AVAILABLE — DevicePanel: Tastaturkürzel-Legende in Hilfe → Arbeitsmappe ergänzen (UI-only Doku).


---

## Clip Launcher — Next Steps (nach v0.0.20.152)

- [ ] AVAILABLE — Clip Launcher: Scene Header "Stop" + Status (queued/playing) UI-only.
- [ ] AVAILABLE — Clip Launcher: Track Header Mini-Meter + Stop-Button (UI-only).
- [ ] AVAILABLE — Clip Launcher: Release/Next Action tatsächlich ausführen (Engine-Wiring, schrittweise, safe).
- [ ] AVAILABLE — Clip Launcher: ALT Launch (Alt Quantize/Mode) in LauncherService/Inspector sauber verdrahten.
