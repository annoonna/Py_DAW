"""Recording service for PipeWire and JACK audio backends.

v0.0.20.632 — AP2 Phase 2A: Solides Single-Track Recording

Features:
- Record-Arm per Track (model flag + visual feedback)
- Pre-Roll / Count-In with metronome integration
- WAV file writing to project media folder (24-bit float)
- Automatic clip creation after recording stop
- Input monitoring (passthrough of hardware input)
- Backend auto-detection: JACK > PipeWire > sounddevice
- Input routing: which hardware input pair → which track
"""

from __future__ import annotations

import logging
import os
import queue
import struct
import threading
import time
import wave
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Optional

try:
    import numpy as np
    _NP_AVAILABLE = True
except ImportError:
    np = None
    _NP_AVAILABLE = False

if TYPE_CHECKING:
    from pydaw.services.transport_service import TransportService

log = logging.getLogger(__name__)


class RecordingService:
    """Service for recording audio through PipeWire/JACK/sounddevice.

    v0.0.20.632 enhancements:
    - Pre-roll / count-in bars before recording starts
    - WAV files saved to project media folder (24-bit)
    - Auto clip creation on stop
    - Input monitoring support
    - Per-track input routing
    """

    def __init__(self):
        self._recording = False
        self._record_thread: threading.Thread | None = None
        self._audio_queue: queue.Queue = queue.Queue()
        self._backend = "sounddevice"  # default
        self._sample_rate = 48000
        self._channels = 2
        self._output_path: Path | None = None
        self._recorded_frames: list = []

        # v0.0.20.632: Enhanced recording state
        self._armed_track_id: str | None = None
        self._armed_input_pair: int = 1  # 1-based stereo pair index
        self._recording_start_beat: float = 0.0
        self._count_in_bars: int = 0  # 0 = no count-in
        self._count_in_active: bool = False
        self._input_monitoring: bool = False
        self._bit_depth: int = 24  # 16, 24, or 32

        # Callback for clip creation (set by MainWindow)
        self._on_recording_complete: Optional[Callable] = None

        # Transport reference (set by ServiceContainer)
        self._transport: Optional[TransportService] = None

        # Project media path (set before recording)
        self._project_media_path: Path | None = None

        # Streams
        self._sd_stream: Any = None
        self._jack_client: Any = None
        self._jack_ports: list = []

        # Detect available backends
        self._detect_backend()

    def _detect_backend(self) -> None:
        """Detect which audio backend is available."""
        # Check for JACK
        try:
            import jack
            self._backend = "jack"
            log.info("Recording backend: JACK")
            return
        except ImportError:
            pass

        # Check for PipeWire via sounddevice
        try:
            import sounddevice as sd
            devices = sd.query_devices()
            for dev in devices:
                if 'pipewire' in str(dev.get('name', '')).lower():
                    self._backend = "pipewire"
                    log.info("Recording backend: PipeWire (via sounddevice)")
                    return
        except Exception:
            pass

        # Fallback to sounddevice
        self._backend = "sounddevice"
        log.info("Recording backend: sounddevice (fallback)")

    # --- Configuration ---------------------------------------------------

    def set_transport(self, transport: TransportService) -> None:
        """Set transport reference for beat-sync recording."""
        self._transport = transport

    def set_project_media_path(self, path: Path | str) -> None:
        """Set the project media folder for saving recordings."""
        self._project_media_path = Path(path)
        self._project_media_path.mkdir(parents=True, exist_ok=True)

    def set_on_recording_complete(self, callback: Callable) -> None:
        """Set callback for when recording is complete.

        Callback signature: callback(wav_path: Path, track_id: str, start_beat: float)
        """
        self._on_recording_complete = callback

    def set_count_in_bars(self, bars: int) -> None:
        """Set number of count-in bars before recording starts."""
        self._count_in_bars = max(0, int(bars))

    def set_input_monitoring(self, enabled: bool) -> None:
        """Enable/disable input monitoring (passthrough)."""
        self._input_monitoring = bool(enabled)

    def set_bit_depth(self, depth: int) -> None:
        """Set recording bit depth (16, 24, or 32)."""
        if depth in (16, 24, 32):
            self._bit_depth = depth

    def get_backend(self) -> str:
        """Get current recording backend."""
        return self._backend

    def is_recording(self) -> bool:
        """Check if currently recording."""
        return self._recording

    @property
    def armed_track_id(self) -> str | None:
        """Currently armed track ID."""
        return self._armed_track_id

    # --- Record Arm Management -------------------------------------------

    def arm_track(self, track_id: str, input_pair: int = 1) -> None:
        """Arm a track for recording.

        Args:
            track_id: Track identifier.
            input_pair: Stereo input pair (1-based). Pair 1 = inputs 1+2.
        """
        self._armed_track_id = str(track_id)
        self._armed_input_pair = max(1, int(input_pair))
        log.info("Armed track '%s' with input pair %d", track_id, input_pair)

    def disarm_track(self, track_id: str | None = None) -> None:
        """Disarm a track (or all tracks if track_id is None)."""
        if track_id is None or track_id == self._armed_track_id:
            self._armed_track_id = None
            log.info("Disarmed recording")

    # --- Start / Stop Recording ------------------------------------------

    def start_recording(
        self,
        output_path: str | Path | None = None,
        sample_rate: int = 48000,
        channels: int = 2,
        track_id: str | None = None,
        input_pair: int | None = None,
    ) -> bool:
        """Start recording audio.

        Args:
            output_path: Path where to save the WAV file.
                If None, auto-generates path in project media folder.
            sample_rate: Sample rate in Hz.
            channels: Number of audio channels (2 = stereo).
            track_id: Track to record to (overrides armed track).
            input_pair: Input pair to use (overrides armed input pair).

        Returns:
            True if recording started successfully.
        """
        if self._recording:
            log.warning("Already recording")
            return False

        # Resolve track
        tid = track_id or self._armed_track_id
        if not tid:
            log.error("No track armed for recording")
            return False
        self._armed_track_id = tid

        if input_pair is not None:
            self._armed_input_pair = max(1, int(input_pair))

        self._sample_rate = sample_rate
        self._channels = channels
        self._recorded_frames = []

        # Record start beat position
        if self._transport:
            self._recording_start_beat = float(
                getattr(self._transport, 'current_beat', 0.0) or 0.0
            )
        else:
            self._recording_start_beat = 0.0

        # Resolve output path
        if output_path is not None:
            self._output_path = Path(output_path)
        else:
            self._output_path = self._generate_wav_path()

        if self._output_path is None:
            log.error("No output path for recording")
            return False

        self._output_path.parent.mkdir(parents=True, exist_ok=True)

        log.info(
            "Starting recording: track=%s, pair=%d, sr=%d, path=%s",
            tid, self._armed_input_pair, sample_rate, self._output_path,
        )

        # Count-in handling
        if self._count_in_bars > 0 and self._transport:
            self._count_in_active = True
            log.info("Count-in: %d bars", self._count_in_bars)
            # The actual recording starts after count-in completes.
            # Count-in is managed by transport (metronome ticks).
            # We start the audio stream immediately but discard frames
            # until count-in is done.

        # Start recording based on backend
        if self._backend == "jack":
            success = self._start_jack_recording()
        elif self._backend == "pipewire":
            success = self._start_pipewire_recording()
        else:
            success = self._start_sounddevice_recording()

        if success:
            self._recording = True
            log.info("Recording started successfully")
        else:
            log.error("Failed to start recording")

        return success

    def stop_recording(self) -> Path | None:
        """Stop recording and save the audio file.

        Returns:
            Path to the saved WAV file, or None if recording failed.
        """
        if not self._recording:
            return None

        log.info("Stopping recording...")
        self._recording = False
        self._count_in_active = False

        # Stop streams
        self._stop_streams()

        # Wait for recording thread to finish
        if self._record_thread and self._record_thread.is_alive():
            self._record_thread.join(timeout=3.0)

        # Save recorded audio to WAV file
        if self._recorded_frames and self._output_path:
            try:
                wav_path = self._save_wav()
                log.info("Recording saved: %s", wav_path)

                # Auto clip creation callback
                if self._on_recording_complete and wav_path:
                    try:
                        self._on_recording_complete(
                            wav_path,
                            str(self._armed_track_id or ""),
                            float(self._recording_start_beat or 0.0),
                        )
                    except Exception as e:
                        log.error("Clip creation callback failed: %s", e)

                return wav_path
            except Exception as e:
                log.error("Error saving recording: %s", e)
                return None

        log.warning("No frames recorded")
        return None

    def _stop_streams(self) -> None:
        """Stop all active audio streams."""
        # Close JACK client if active
        if self._jack_client is not None:
            try:
                self._jack_client.deactivate()
                self._jack_client.close()
            except Exception:
                pass
            self._jack_client = None
            self._jack_ports = []

        # Close sounddevice stream if active
        if self._sd_stream is not None:
            try:
                self._sd_stream.stop()
                self._sd_stream.close()
            except Exception:
                pass
            self._sd_stream = None

    # --- Path Generation -------------------------------------------------

    def _generate_wav_path(self) -> Path | None:
        """Generate a unique WAV file path in the project media folder."""
        base = self._project_media_path
        if base is None:
            # Fallback to cache directory
            base = Path(os.path.expanduser("~/.cache/Py_DAW/recordings"))
            base.mkdir(parents=True, exist_ok=True)

        ts = time.strftime("%Y%m%d_%H%M%S")
        track_name = (self._armed_track_id or "track").replace("/", "_").replace(" ", "_")
        filename = f"rec_{track_name}_{ts}.wav"
        return base / filename

    # --- Backend Implementations -----------------------------------------

    def _start_jack_recording(self) -> bool:
        """Start JACK recording."""
        try:
            import jack

            client = jack.Client("PyDAW_Recorder")
            self._jack_client = client

            # Create input ports
            self._jack_ports = []
            for i in range(self._channels):
                port = client.inports.register(f"input_{i + 1}")
                self._jack_ports.append(port)

            # Process callback
            rec_frames = self._recorded_frames
            recording_ref = [True]  # mutable ref for closure
            count_in_ref = [self._count_in_active]

            @client.set_process_callback
            def process(frames):
                if not recording_ref[0]:
                    raise jack.CallbackExit
                # Read from input ports
                if _NP_AVAILABLE:
                    chunk = np.column_stack(
                        [p.get_array() for p in self._jack_ports]
                    )
                    if not count_in_ref[0]:
                        rec_frames.append(chunk.copy())

            client.activate()

            # Auto-connect to system capture ports
            pair_offset = (self._armed_input_pair - 1) * 2
            capture_ports = client.get_ports(
                is_physical=True, is_output=True, is_audio=True
            )
            for i, port in enumerate(self._jack_ports):
                src_idx = pair_offset + i
                if src_idx < len(capture_ports):
                    client.connect(capture_ports[src_idx], port)

            # Store ref for stop
            self._jack_recording_ref = recording_ref
            self._jack_countin_ref = count_in_ref

            return True

        except Exception as e:
            log.error("JACK recording failed: %s", e)
            return False

    def _start_pipewire_recording(self) -> bool:
        """Start PipeWire recording via sounddevice."""
        return self._start_sounddevice_recording()

    def _start_sounddevice_recording(self) -> bool:
        """Start sounddevice recording (works with PipeWire too)."""
        try:
            import sounddevice as sd

            count_in_active = self._count_in_active
            rec_frames = self._recorded_frames

            def audio_callback(indata, frames, time_info, status):
                if status:
                    log.debug("Recording status: %s", status)
                if self._recording and not self._count_in_active:
                    rec_frames.append(indata.copy())

            # Determine input device
            device = None  # default
            try:
                # Try to use the specific input pair
                if self._armed_input_pair > 1:
                    # For sounddevice, we can specify channel mapping
                    pass  # TODO: channel mapping for multi-input interfaces
            except Exception:
                pass

            self._sd_stream = sd.InputStream(
                samplerate=self._sample_rate,
                channels=self._channels,
                callback=audio_callback,
                dtype='float32',
                device=device,
            )
            self._sd_stream.start()

            return True

        except Exception as e:
            log.error("Sounddevice recording failed: %s", e)
            return False

    # --- WAV File Writing ------------------------------------------------

    def _save_wav(self) -> Path:
        """Save recorded frames to WAV file (24-bit or 16-bit)."""
        if not self._output_path:
            raise ValueError("No output path set")

        self._output_path.parent.mkdir(parents=True, exist_ok=True)

        if not self._recorded_frames:
            raise ValueError("No recorded frames")

        if not _NP_AVAILABLE:
            raise RuntimeError("numpy required for recording")

        # Concatenate all recorded frames
        audio_data = np.concatenate(self._recorded_frames, axis=0)

        # Determine sample width and conversion
        if self._bit_depth == 32:
            # 32-bit float WAV (IEEE)
            sample_width = 4
            audio_bytes = audio_data.astype(np.float32).tobytes()
        elif self._bit_depth == 24:
            # 24-bit integer WAV
            sample_width = 3
            # Clamp and scale to 24-bit range
            clamped = np.clip(audio_data, -1.0, 1.0)
            scaled = (clamped * 8388607.0).astype(np.int32)
            # Pack as 3 bytes per sample (little-endian)
            audio_bytes = bytearray()
            for sample in scaled.flat:
                s = int(sample)
                audio_bytes.extend(struct.pack('<i', s)[:3])
            audio_bytes = bytes(audio_bytes)
        else:
            # 16-bit integer WAV
            sample_width = 2
            audio_int16 = (np.clip(audio_data, -1.0, 1.0) * 32767).astype(np.int16)
            audio_bytes = audio_int16.tobytes()

        with wave.open(str(self._output_path), 'wb') as wf:
            wf.setnchannels(self._channels)
            wf.setsampwidth(sample_width)
            wf.setframerate(self._sample_rate)
            wf.writeframes(audio_bytes)

        log.info(
            "WAV saved: %s (%d frames, %d-bit, %dHz)",
            self._output_path,
            len(audio_data),
            self._bit_depth,
            self._sample_rate,
        )
        return self._output_path

    # --- Count-In Management ---------------------------------------------

    def finish_count_in(self) -> None:
        """Called by transport/metronome when count-in bars are complete.

        After this call, recorded audio frames will be kept (not discarded).
        """
        if self._count_in_active:
            self._count_in_active = False
            log.info("Count-in complete, recording started")
            # Also update JACK callback ref if applicable
            if hasattr(self, '_jack_countin_ref'):
                self._jack_countin_ref[0] = False

    # --- Input Monitoring ------------------------------------------------

    def get_input_level(self) -> tuple[float, float]:
        """Get current input level (peak L, peak R).

        For use in VU meter display of armed tracks.
        Returns (0.0, 0.0) if not monitoring.
        """
        if not self._recording or not self._recorded_frames:
            return (0.0, 0.0)
        try:
            last_chunk = self._recorded_frames[-1]
            if _NP_AVAILABLE and len(last_chunk) > 0:
                if last_chunk.ndim == 2 and last_chunk.shape[1] >= 2:
                    return (
                        float(np.abs(last_chunk[:, 0]).max()),
                        float(np.abs(last_chunk[:, 1]).max()),
                    )
                else:
                    peak = float(np.abs(last_chunk).max())
                    return (peak, peak)
        except Exception:
            pass
        return (0.0, 0.0)

    # --- Cleanup ---------------------------------------------------------

    def cleanup(self) -> None:
        """Clean up resources."""
        if self._recording:
            self.stop_recording()
        self._stop_streams()
