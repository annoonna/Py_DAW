"""Mixer Panel — Pro-DAW-Style vertical fader strips (v0.0.20.14).

Features:
- Vertical fader strips (90px wide) with VU meters
- Mute / Solo buttons per track
- Pan knob (horizontal slider)
- Volume fader (vertical, 0-127 → 0.0-1.0, logarithmic dB display)
- Automation mode selector
- All parameters routed through RTParamStore + HybridRingBuffer for click-free real-time audio
- Per-track params via lock-free ParamRingBuffer (v0.0.20.14)
- Track rename via double-click
- Add/Remove track buttons
"""
from __future__ import annotations

import math
from typing import Optional

from PyQt6.QtCore import Qt, QTimer, QRectF
from PyQt6.QtGui import QPainter, QColor, QLinearGradient, QPen
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea, QFrame,
    QSlider, QComboBox, QPushButton, QSizePolicy, QMenu, QInputDialog,
    QDial,
)

from pydaw.services.project_service import ProjectService

# v0.0.20.21: Professional VU Meter
try:
    from pydaw.ui.widgets.vu_meter import VUMeterWidget
    VU_METER_AVAILABLE = True
except ImportError:
    VU_METER_AVAILABLE = False


# ---- VU Meter Widget (Legacy - kept for backward compatibility)

class _VUMeter(QWidget):
    """Stereo VU meter — 8px wide, gradient fill, peak hold."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(10)
        self.setMinimumHeight(60)
        self._peak_l = 0.0
        self._peak_r = 0.0
        self._hold_l = 0.0
        self._hold_r = 0.0

    def set_levels(self, left: float, right: float) -> None:
        self._peak_l = max(0.0, min(1.0, left))
        self._peak_r = max(0.0, min(1.0, right))
        self._hold_l = max(self._hold_l * 0.92, self._peak_l)
        self._hold_r = max(self._hold_r * 0.92, self._peak_r)
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        w = self.width()
        h = self.height()
        half = w // 2

        # Background
        p.fillRect(0, 0, w, h, QColor(30, 30, 30))

        for i, (peak, hold) in enumerate(
            [(self._peak_l, self._hold_l), (self._peak_r, self._hold_r)]
        ):
            x = 0 if i == 0 else half
            bar_h = int(peak * h)
            if bar_h > 0:
                grad = QLinearGradient(0, h, 0, 0)
                grad.setColorAt(0.0, QColor(0, 200, 80))
                grad.setColorAt(0.65, QColor(220, 220, 0))
                grad.setColorAt(1.0, QColor(255, 40, 40))
                p.fillRect(x, h - bar_h, half, bar_h, grad)

            # Peak hold line
            hold_y = h - int(hold * h)
            p.setPen(QPen(QColor(255, 255, 255, 180), 1))
            p.drawLine(x, hold_y, x + half - 1, hold_y)

        p.end()


# ---- Mixer Strip

class _MixerStrip(QFrame):
    """Single vertical mixer strip (90px wide)."""

    def __init__(self, project: ProjectService, track_id: str,
                 audio_engine=None, rt_params=None, hybrid_bridge=None, parent=None):
        super().__init__(parent)
        self.project = project
        self.track_id = track_id
        self.audio_engine = audio_engine
        self.rt_params = rt_params
        self.hybrid_bridge = hybrid_bridge  # v0.0.20.14: lock-free per-track ring

        # v0.0.20.28: Fallback to AudioEngine's HybridEngineBridge when not passed in.
        if self.hybrid_bridge is None and self.audio_engine is not None:
            try:
                hb = getattr(self.audio_engine, "_hybrid_bridge", None)
                if hb is None:
                    hb = getattr(self.audio_engine, "hybrid_bridge", None)
                if hb is not None:
                    self.hybrid_bridge = hb
            except Exception:
                pass

        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setFixedWidth(92)
        self.setSizePolicy(QSizePolicy.Policy.Fixed,
                           QSizePolicy.Policy.Expanding)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(3)

        # Track name (click to rename)
        self.lbl_name = QLabel("")
        self.lbl_name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_name.setWordWrap(True)
        self.lbl_name.setMaximumHeight(32)
        self.lbl_name.setStyleSheet(
            "QLabel { font-size: 10px; padding: 2px; }"
            "QLabel:hover { background: #444; border-radius: 3px; }"
        )
        self.lbl_name.setCursor(Qt.CursorShape.PointingHandCursor)
        self.lbl_name.mouseDoubleClickEvent = lambda ev: self._rename_track()
        lay.addWidget(self.lbl_name)

        # Automation mode
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["off", "read", "write"])
        self.cmb_mode.setFixedHeight(22)
        self.cmb_mode.setStyleSheet("font-size: 9px;")
        self.cmb_mode.currentTextChanged.connect(self._on_mode)
        lay.addWidget(self.cmb_mode)

        # Pan slider (horizontal)
        self.sld_pan = QSlider(Qt.Orientation.Horizontal)
        self.sld_pan.setRange(-100, 100)
        self.sld_pan.setValue(0)
        self.sld_pan.setFixedHeight(18)
        self.sld_pan.setToolTip("Pan: L ← → R")
        self.sld_pan.valueChanged.connect(self._on_pan)
        lay.addWidget(self.sld_pan)

        # v0.0.20.521: Send knobs with thin scrollbar + numbered FX labels
        self._send_knobs: dict[str, QDial] = {}  # fx_track_id -> QDial
        self._send_labels: dict[str, QLabel] = {}
        self._send_inner = QWidget()
        self._send_layout = QVBoxLayout(self._send_inner)
        self._send_layout.setContentsMargins(0, 0, 0, 0)
        self._send_layout.setSpacing(0)
        self._send_scroll = QScrollArea()
        self._send_scroll.setWidget(self._send_inner)
        self._send_scroll.setWidgetResizable(True)
        self._send_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._send_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self._send_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._send_scroll.setFixedHeight(80)
        self._send_scroll.setStyleSheet(
            "QScrollArea { background: transparent; border: none; }"
            "QScrollBar:vertical { width: 6px; background: transparent; }"
            "QScrollBar::handle:vertical { background: #666; border-radius: 3px; min-height: 16px; }"
            "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }"
            "QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }"
        )
        lay.addWidget(self._send_scroll)

        # Fader + VU area
        fader_row = QHBoxLayout()
        fader_row.setSpacing(2)

        self.sld_vol = QSlider(Qt.Orientation.Vertical)
        self.sld_vol.setRange(0, 127)
        self.sld_vol.setValue(100)
        self.sld_vol.setMinimumHeight(80)
        self.sld_vol.setToolTip("Volume fader")
        self.sld_vol.valueChanged.connect(self._on_vol)
        fader_row.addWidget(self.sld_vol, 1)

        # VU Meter (v0.0.20.21: New professional widget if available)
        if VU_METER_AVAILABLE:
            self.vu = VUMeterWidget()
        else:
            self.vu = _VUMeter()
        fader_row.addWidget(self.vu, 0)

        lay.addLayout(fader_row, 1)

        # dB label
        self.lbl_db = QLabel("0.0 dB")
        self.lbl_db.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_db.setStyleSheet("font-size: 9px; color: #aaa;")
        lay.addWidget(self.lbl_db)

        # Mute / Solo buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(2)

        self.btn_mute = QPushButton("M")
        self.btn_mute.setCheckable(True)
        self.btn_mute.setFixedSize(34, 22)
        self.btn_mute.setStyleSheet(
            "QPushButton { font-size: 10px; font-weight: bold; }"
            "QPushButton:checked { background: #c44; color: white; }"
        )
        self.btn_mute.toggled.connect(self._on_mute)
        btn_row.addWidget(self.btn_mute)

        self.btn_solo = QPushButton("S")
        self.btn_solo.setCheckable(True)
        self.btn_solo.setFixedSize(34, 22)
        self.btn_solo.setStyleSheet(
            "QPushButton { font-size: 10px; font-weight: bold; }"
            "QPushButton:checked { background: #cc4; color: black; }"
        )
        self.btn_solo.toggled.connect(self._on_solo)
        btn_row.addWidget(self.btn_solo)

        # v0.0.20.632: Record-Arm button (AP2 Phase 2A)
        self.btn_rec_arm = QPushButton("R")
        self.btn_rec_arm.setCheckable(True)
        self.btn_rec_arm.setFixedSize(34, 22)
        self.btn_rec_arm.setStyleSheet(
            "QPushButton { font-size: 10px; font-weight: bold; }"
            "QPushButton:checked { background: #e33; color: white; border: 1px solid #f66; }"
        )
        self.btn_rec_arm.setToolTip("Record Arm (R)")
        self.btn_rec_arm.toggled.connect(self._on_rec_arm)
        btn_row.addWidget(self.btn_rec_arm)

        lay.addLayout(btn_row)

        self.refresh_from_model()
        
        # v0.0.20.584: VU meter updates are now driven by a SINGLE timer
        # in MixerPanel (instead of N individual timers per strip).
        # This reduces timer callback overhead from N*30fps to 1*30fps.
        self._track_idx = None  # Will be set by MixerPanel

    # ---- Model sync

    def _track(self):
        return next(
            (t for t in self.project.ctx.project.tracks
             if t.id == self.track_id), None)

    def refresh_from_model(self) -> None:
        t = self._track()
        if not t:
            return

        self.lbl_name.setText(f"{t.name}")
        self.lbl_name.setToolTip(f"{t.name} [{t.kind}]")

        self.cmb_mode.blockSignals(True)
        self.cmb_mode.setCurrentText(getattr(t, "automation_mode", "off"))
        self.cmb_mode.blockSignals(False)

        # Volume: 0.0-1.0 → 0-127
        vol = float(getattr(t, "volume", 0.8))
        self.sld_vol.blockSignals(True)
        self.sld_vol.setValue(int(round(vol * 127.0)))
        self.sld_vol.blockSignals(False)

        # Pan: -1.0..+1.0 → -100..+100
        pan = float(getattr(t, "pan", 0.0))
        self.sld_pan.blockSignals(True)
        self.sld_pan.setValue(int(round(pan * 100.0)))
        self.sld_pan.blockSignals(False)

        # Mute / Solo
        self.btn_mute.blockSignals(True)
        self.btn_mute.setChecked(bool(getattr(t, "muted", False)))
        self.btn_mute.blockSignals(False)

        self.btn_solo.blockSignals(True)
        self.btn_solo.setChecked(bool(getattr(t, "solo", False)))
        self.btn_solo.blockSignals(False)

        # v0.0.20.632: Record-Arm sync
        self.btn_rec_arm.blockSignals(True)
        self.btn_rec_arm.setChecked(bool(getattr(t, "record_arm", False)))
        self.btn_rec_arm.blockSignals(False)

        self._update_db_label(vol)
        self._sync_rt_params()
        self._rebuild_send_knobs()

    # ---- Send knobs (v0.0.20.518 Bitwig-style)

    def _rebuild_send_knobs(self) -> None:
        """Rebuild send knobs to match current FX tracks in project.

        v0.0.20.519: Compact Bitwig-style layout — each send is one tiny row:
        [3-char label] [20px knob] all stacked vertically in minimal space.
        """
        try:
            t = self._track()
            if not t:
                return
            track_kind = str(getattr(t, "kind", "") or "")
            # FX and master tracks don't show sends (they ARE the receive end)
            if track_kind in ("fx", "master"):
                self._send_scroll.setVisible(False)
                return

            fx_tracks = list(self.project.get_fx_tracks()) if hasattr(self.project, "get_fx_tracks") else []
            if not fx_tracks:
                self._send_scroll.setVisible(False)
                return

            self._send_scroll.setVisible(True)
            sends = {str(s.get("target_track_id", "")): s for s in list(getattr(t, "sends", []) or []) if isinstance(s, dict)}

            # Remove knobs for deleted FX tracks
            fx_ids = {str(getattr(fx, "id", "")) for fx in fx_tracks}
            for fid in list(self._send_knobs.keys()):
                if fid not in fx_ids:
                    try:
                        self._send_knobs.pop(fid).deleteLater()
                    except Exception:
                        pass
                    try:
                        self._send_labels.pop(fid).deleteLater()
                    except Exception:
                        pass

            # Clear layout
            while self._send_layout.count():
                item = self._send_layout.takeAt(0)
                # Don't delete widgets — we reuse them

            # Add/update knobs for each FX track — compact horizontal rows
            for fx_num, fx_trk in enumerate(fx_tracks, 1):
                fid = str(getattr(fx_trk, "id", ""))
                raw_name = str(getattr(fx_trk, "name", "FX"))
                # Short label with number for quick identification
                short = f"{raw_name[:3]}{fx_num}" if len(fx_tracks) > 1 else raw_name[:5]
                amount = float(sends.get(fid, {}).get("amount", 0.0) if fid in sends else 0.0)
                is_pre = bool(sends.get(fid, {}).get("pre_fader", False) if fid in sends else False)

                if fid not in self._send_knobs:
                    knob = QDial()
                    knob.setRange(0, 100)
                    knob.setFixedSize(22, 22)
                    knob.setNotchesVisible(False)
                    knob.setWrapping(False)
                    knob.setStyleSheet(
                        "QDial { background: transparent; }"
                    )
                    knob.valueChanged.connect(lambda val, _fid=fid: self._on_send(val, _fid))
                    # v0.0.20.527: Right-click Pre/Post toggle (Bitwig-style)
                    knob.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
                    knob.customContextMenuRequested.connect(lambda pos, _fid=fid, _knob=knob: self._on_send_context_menu(_knob, _fid, pos))
                    self._send_knobs[fid] = knob

                    lbl = QLabel(short)
                    lbl.setFixedHeight(14)
                    lbl.setFixedWidth(38)
                    lbl.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
                    self._send_labels[fid] = lbl

                # v0.0.20.528: Register send as automatable parameter
                self._register_send_automation(fid, raw_name, fx_num)

                knob = self._send_knobs[fid]
                lbl = self._send_labels[fid]

                # v0.0.20.529: Tag knob with param_id for MIDI Learn CC recording
                knob._pydaw_param_id = f"trk:{self.track_id}:send:{fid}"

                # Update values
                knob.blockSignals(True)
                knob.setValue(int(round(amount * 100.0)))
                knob.blockSignals(False)
                lbl.setText(short)
                pct = int(round(amount * 100.0))
                pre_post = "Pre-Fader" if is_pre else "Post-Fader"
                knob.setToolTip(f"Send {fx_num} → {raw_name} ({pct}%)\n{pre_post}\nRechtsklick: Pre/Post")

                # Color: yellow=post, blue=pre (Bitwig-style)
                color = "#6af" if is_pre else "#fa3"
                active = amount > 0.001
                lbl.setStyleSheet(
                    f"font-size: 8px; color: {color if active else '#555'}; padding: 0; margin: 0;"
                )

                # Build compact row: [label][knob]
                row = QHBoxLayout()
                row.setContentsMargins(0, 0, 0, 0)
                row.setSpacing(2)
                row.addWidget(lbl)
                row.addWidget(knob)
                row.addStretch(1)
                self._send_layout.addLayout(row)

        except Exception:
            pass

    def _on_send(self, val: int, fx_track_id: str) -> None:
        """Handle send knob change."""
        try:
            amount = float(val) / 100.0
            t = self._track()
            if not t:
                return
            if amount > 0.001:
                self.project.add_send(self.track_id, fx_track_id, amount=amount)
            else:
                self.project.remove_send(self.track_id, fx_track_id)
        except Exception:
            pass

    def _on_send_context_menu(self, knob: QDial, fx_track_id: str, pos) -> None:
        """v0.0.20.527+528+529: Right-click context menu on Send knob."""
        try:
            t = self._track()
            if not t:
                return
            sends = {str(s.get("target_track_id", "")): s for s in list(getattr(t, "sends", []) or []) if isinstance(s, dict)}
            current_send = sends.get(fx_track_id, {})
            is_pre = bool(current_send.get("pre_fader", False))
            has_send = fx_track_id in sends and float(current_send.get("amount", 0)) > 0.001

            # Find FX track name
            fx_name = "FX"
            try:
                fx_trk = next((ft for ft in self.project.ctx.project.tracks if str(getattr(ft, "id", "")) == fx_track_id), None)
                if fx_trk:
                    fx_name = str(getattr(fx_trk, "name", "FX"))
            except Exception:
                pass

            am = getattr(self.project, "automation_manager", None)

            menu = QMenu(knob)
            menu.setStyleSheet("QMenu { font-size: 10px; }")

            # v0.0.20.528: Show Automation in Arranger
            param_id = f"trk:{self.track_id}:send:{fx_track_id}"
            a_auto = menu.addAction("📈 Automation im Arranger zeigen")

            # v0.0.20.529: MIDI Learn
            has_mapping = bool(getattr(knob, "_midi_cc_mapping", None))
            if has_mapping:
                cc_info = getattr(knob, "_midi_cc_mapping", (0, 0))
                a_learn = menu.addAction(f"🎛 MIDI Learn (CC {cc_info[1]})")
                a_unlearn = menu.addAction("🚫 MIDI Learn zurücksetzen")
            else:
                a_learn = menu.addAction("🎛 MIDI Learn")
                a_unlearn = None

            menu.addSeparator()

            # Pre/Post toggle
            toggle_label = "Auf Pre-Fader umschalten" if not is_pre else "Auf Post-Fader umschalten"
            toggle_icon = "🔵" if not is_pre else "🟡"
            a_toggle = menu.addAction(f"{toggle_icon} {toggle_label}")
            a_toggle.setEnabled(has_send)

            menu.addSeparator()

            # Send amount shortcuts
            a_50 = menu.addAction("50%")
            a_100 = menu.addAction("100%")

            menu.addSeparator()

            # Remove send
            a_remove = menu.addAction("❌ Send entfernen")
            a_remove.setEnabled(has_send)

            chosen = menu.exec(knob.mapToGlobal(pos))
            if chosen is None:
                return

            if chosen == a_auto:
                if am is not None and hasattr(am, "request_show_automation"):
                    am.request_show_automation.emit(param_id)
            elif chosen == a_learn:
                self._start_send_midi_learn(knob, fx_track_id)
            elif a_unlearn is not None and chosen == a_unlearn:
                self._reset_send_midi_learn(knob, fx_track_id)
            elif chosen == a_toggle:
                if hasattr(self.project, "toggle_send_pre_fader"):
                    self.project.toggle_send_pre_fader(self.track_id, fx_track_id)
                else:
                    amt = float(current_send.get("amount", 0.5))
                    self.project.add_send(self.track_id, fx_track_id, amount=amt, pre_fader=not is_pre)
            elif chosen == a_50:
                self.project.add_send(self.track_id, fx_track_id, amount=0.5, pre_fader=is_pre)
            elif chosen == a_100:
                self.project.add_send(self.track_id, fx_track_id, amount=1.0, pre_fader=is_pre)
            elif chosen == a_remove:
                self.project.remove_send(self.track_id, fx_track_id)
        except Exception:
            pass

    # ---- MIDI Learn for Send knobs (v0.0.20.529)

    def _start_send_midi_learn(self, knob: QDial, fx_track_id: str) -> None:
        """Enter MIDI Learn mode: next CC assigns to this send knob."""
        try:
            am = getattr(self.project, "automation_manager", None)
            if am is None:
                return
            # Visual feedback: red border while waiting for CC
            knob.setStyleSheet("QDial { background: transparent; border: 2px solid #cc3333; border-radius: 11px; }")
            # Set learn target — AutomationManager.handle_midi_message() picks it up
            am._midi_learn_knob = knob
        except Exception:
            pass

    def _reset_send_midi_learn(self, knob: QDial, fx_track_id: str) -> None:
        """Remove MIDI CC mapping from this send knob."""
        try:
            am = getattr(self.project, "automation_manager", None)
            if am is None:
                return
            mapping = getattr(knob, "_midi_cc_mapping", None)
            if mapping:
                # Remove from live listeners
                cc_listeners = getattr(am, "_midi_cc_listeners", None)
                if cc_listeners and mapping in cc_listeners:
                    del cc_listeners[mapping]
                # Remove from persistent registry
                pid = getattr(knob, "_pydaw_param_id", "")
                persistent = getattr(am, "_persistent_cc_map", None)
                if persistent and pid in persistent:
                    del persistent[pid]
                knob._midi_cc_mapping = None
            # Reset visual
            knob.setStyleSheet("QDial { background: transparent; }")
        except Exception:
            pass

    # ---- Send automation (v0.0.20.528)

    _send_automation_connected: set = None  # type: ignore  # lazy init

    def _register_send_automation(self, fx_track_id: str, fx_name: str, fx_num: int) -> None:
        """Register a send amount as automatable parameter in AutomationManager."""
        try:
            am = getattr(self.project, "automation_manager", None)
            if am is None:
                return
            param_id = f"trk:{self.track_id}:send:{fx_track_id}"
            am.register_parameter(
                param_id,
                f"Send {fx_num} → {fx_name}",
                min_val=0.0,
                max_val=1.0,
                default_val=0.0,
                track_id=self.track_id,
            )
            # Connect parameter_changed once per strip to update knob during playback
            if self._send_automation_connected is None:
                self._send_automation_connected = set()
                try:
                    am.parameter_changed.connect(self._on_send_automation_changed)
                except Exception:
                    pass

            # v0.0.20.529: Re-register CC mapping from persistent registry (survives widget rebuild)
            knob = self._send_knobs.get(fx_track_id)
            if knob is not None:
                persistent = getattr(am, '_persistent_cc_map', None)
                if persistent and param_id in persistent:
                    saved_cc = persistent[param_id]
                    cc_listeners = getattr(am, '_midi_cc_listeners', None)
                    if cc_listeners is None:
                        am._midi_cc_listeners = {}
                        cc_listeners = am._midi_cc_listeners
                    cc_listeners[saved_cc] = knob
                    knob._midi_cc_mapping = saved_cc
        except Exception:
            pass

    def _on_send_automation_changed(self, parameter_id: str, value: float) -> None:
        """Update send knob when automation plays back a send parameter."""
        try:
            # Only handle send params for this track: "trk:{self.track_id}:send:{fx_id}"
            prefix = f"trk:{self.track_id}:send:"
            if not parameter_id.startswith(prefix):
                return
            fx_id = parameter_id[len(prefix):]
            knob = self._send_knobs.get(fx_id)
            if knob is None:
                return
            knob.blockSignals(True)
            knob.setValue(int(round(float(value) * 100.0)))
            knob.blockSignals(False)
        except Exception:
            pass

    # ---- RT param sync

    def _sync_rt_params(self) -> None:
        """Push current values into RTParamStore + HybridBridge for real-time audio."""
        t = self._track()
        if not t:
            return
        vol = float(getattr(t, "volume", 0.8))
        pan = float(getattr(t, "pan", 0.0))

        # Master track → master params
        if getattr(t, "kind", "") == "master":
            if self.audio_engine:
                self.audio_engine.set_master_volume(vol)
                self.audio_engine.set_master_pan(pan)
            if self.rt_params:
                self.rt_params.set_param("master:vol", vol)
                self.rt_params.set_param("master:pan", pan)
        else:
            # NEW v0.0.20.37: Write to atomic dicts (LIKE MASTER!)
            if self.audio_engine and hasattr(self.audio_engine, 'set_track_volume'):
                try:
                    self.audio_engine.set_track_volume(self.track_id, vol)
                    self.audio_engine.set_track_pan(self.track_id, pan)
                    self.audio_engine.set_track_mute(self.track_id, bool(getattr(t, "muted", False)))
                    self.audio_engine.set_track_solo(self.track_id, bool(getattr(t, "solo", False)))
                except Exception:
                    pass
            # Legacy: Per-track RT params
            if self.rt_params:
                self.rt_params.set_track_vol(self.track_id, vol)
                self.rt_params.set_track_pan(self.track_id, pan)
                self.rt_params.set_track_mute(
                    self.track_id, bool(getattr(t, "muted", False)))
                self.rt_params.set_track_solo(
                    self.track_id, bool(getattr(t, "solo", False)))
            # v0.0.20.14: Per-track via lock-free ring buffer
            if self.hybrid_bridge:
                try:
                    self.hybrid_bridge.set_track_volume(self.track_id, vol)
                    self.hybrid_bridge.set_track_pan(self.track_id, pan)
                    self.hybrid_bridge.set_track_mute(
                        self.track_id, bool(getattr(t, "muted", False)))
                    self.hybrid_bridge.set_track_solo(
                        self.track_id, bool(getattr(t, "solo", False)))
                except Exception:
                    pass

    # ---- UI callbacks

    def _on_vol(self, v: int) -> None:
        t = self._track()
        if not t:
            return
        vol = max(0.0, min(1.0, float(v) / 127.0))
        t.volume = vol
        self._update_db_label(vol)

        # Live RT param update
        if getattr(t, "kind", "") == "master":
            if self.audio_engine:
                self.audio_engine.set_master_volume(vol)
            if self.rt_params:
                self.rt_params.set_param("master:vol", vol)
        else:
            # NEW v0.0.20.33: Write to atomic dict (additional channel, SAFE!)
            if self.audio_engine and hasattr(self.audio_engine, 'set_track_volume'):
                try:
                    self.audio_engine.set_track_volume(self.track_id, vol)
                except Exception:
                    pass
            # Legacy channels (keep for compatibility)
            if self.rt_params:
                self.rt_params.set_track_vol(self.track_id, vol)
            # v0.0.20.14: lock-free ring
            if self.hybrid_bridge:
                try:
                    self.hybrid_bridge.set_track_volume(self.track_id, vol)
                except Exception:
                    pass
        # No project_updated during drag (performance)

    def _on_pan(self, v: int) -> None:
        t = self._track()
        if not t:
            return
        pan = max(-1.0, min(1.0, float(v) / 100.0))
        t.pan = pan

        if getattr(t, "kind", "") == "master":
            if self.audio_engine:
                self.audio_engine.set_master_pan(pan)
            if self.rt_params:
                self.rt_params.set_param("master:pan", pan)
        else:
            # NEW v0.0.20.33: Write to atomic dict (SAFE!)
            if self.audio_engine and hasattr(self.audio_engine, 'set_track_pan'):
                try:
                    self.audio_engine.set_track_pan(self.track_id, pan)
                except Exception:
                    pass
            # Legacy channels
            if self.rt_params:
                self.rt_params.set_track_pan(self.track_id, pan)
            # v0.0.20.14: lock-free ring
            if self.hybrid_bridge:
                try:
                    self.hybrid_bridge.set_track_pan(self.track_id, pan)
                except Exception:
                    pass

    def _on_mute(self, checked: bool) -> None:
        t = self._track()
        if not t:
            return
        t.muted = bool(checked)
        # NEW v0.0.20.33: Write to atomic dict (SAFE!)
        if self.audio_engine and hasattr(self.audio_engine, 'set_track_mute'):
            try:
                self.audio_engine.set_track_mute(self.track_id, checked)
            except Exception:
                pass
        # Legacy channels
        if self.rt_params:
            self.rt_params.set_track_mute(self.track_id, checked)
        # v0.0.20.14: lock-free ring
        if self.hybrid_bridge:
            try:
                self.hybrid_bridge.set_track_mute(self.track_id, checked)
            except Exception:
                pass

    def _on_solo(self, checked: bool) -> None:
        t = self._track()
        if not t:
            return
        t.solo = bool(checked)
        # NEW v0.0.20.33: Write to atomic dict (SAFE!)
        if self.audio_engine and hasattr(self.audio_engine, 'set_track_solo'):
            try:
                self.audio_engine.set_track_solo(self.track_id, checked)
            except Exception:
                pass
        # Legacy channels
        if self.rt_params:
            self.rt_params.set_track_solo(self.track_id, checked)
        # v0.0.20.14: lock-free ring
        if self.hybrid_bridge:
            try:
                self.hybrid_bridge.set_track_solo(self.track_id, checked)
            except Exception:
                pass

    def _on_rec_arm(self, checked: bool) -> None:
        """Toggle record-arm for this track (v0.0.20.632, AP2 Phase 2A)."""
        t = self._track()
        if not t:
            return
        t.record_arm = bool(checked)
        # Visual feedback: tint strip background when armed
        try:
            if checked:
                self.setStyleSheet("QFrame { border-left: 3px solid #e33; }")
            else:
                self.setStyleSheet("")
        except Exception:
            pass

    def _on_mode(self, mode: str) -> None:
        t = self._track()
        if not t:
            return
        t.automation_mode = str(mode)
        self.project.project_updated.emit()

    def _rename_track(self) -> None:
        t = self._track()
        if not t or t.kind == "master":
            return
        new_name, ok = QInputDialog.getText(
            self, "Track umbenennen",
            f"Neuer Name für '{t.name}':", text=t.name)
        if ok and new_name.strip():
            try:
                self.project.rename_track(t.id, new_name.strip())
            except Exception:
                pass

    def _update_db_label(self, vol: float) -> None:
        if vol <= 0.001:
            self.lbl_db.setText("-∞ dB")
        else:
            db = 20.0 * math.log10(max(1e-10, vol))
            self.lbl_db.setText(f"{db:+.1f} dB")
    
    def _update_vu_meter(self) -> None:
        """Update VU meter (30 FPS, GUI thread).

        v0.0.20.41: Direct peak path (most reliable) + fallback chain.
        Sources (in priority order):
        1. AudioEngine._direct_peaks (written directly from audio callback)
        2. HybridEngineBridge → TrackMeterRing
        3. HybridEngineBridge → read_track_peak() / read_master_peak()
        4. AudioEngine.read_track_peak() / read_master_peak()
        """
        try:
            t = self._track()
            if t is None:
                return

            is_master = str(getattr(t, "kind", "")) == "master"
            l, r = 0.0, 0.0
            got_data = False

            # --- Source 1: Direct peaks (v0.0.20.41 — most reliable)
            ae = self.audio_engine
            if ae is not None and hasattr(ae, "read_direct_track_peak"):
                try:
                    if is_master:
                        l, r = ae.read_master_peak()
                        got_data = (l > 0.0001 or r > 0.0001)
                    else:
                        l, r = ae.read_direct_track_peak(self.track_id)
                        got_data = (l > 0.0001 or r > 0.0001)
                except Exception:
                    pass

            # --- Source 2: Hybrid bridge (fallback)
            if not got_data:
                hb = self.hybrid_bridge
                if hb is not None:
                    try:
                        if is_master:
                            l, r = hb.read_master_peak()
                            got_data = True
                        elif self._track_idx is not None:
                            cb = getattr(hb, "callback", None)
                            if cb is not None:
                                meter = cb.get_track_meter(int(self._track_idx))
                                l, r = meter.read_and_decay()
                                got_data = True
                    except Exception:
                        pass

                    # Source 3: Bridge-level read_track_peak
                    if not got_data and not is_master:
                        try:
                            l, r = hb.read_track_peak(self.track_id)
                            got_data = True
                        except Exception:
                            pass

            # --- Source 4: AudioEngine helper (legacy / non-hybrid)
            if not got_data:
                if ae is not None:
                    try:
                        if is_master and hasattr(ae, "read_master_peak"):
                            l, r = ae.read_master_peak()
                            got_data = True
                        elif hasattr(ae, "read_track_peak"):
                            l, r = ae.read_track_peak(self.track_id)
                            got_data = True
                    except Exception:
                        pass

            if got_data:
                self.vu.set_levels(float(l), float(r))

        except Exception:
            # Fail silently - never break UI update loop
            pass


# ---- Mixer Panel

class MixerPanel(QWidget):
    """Pro-DAW-Style horizontal scrolling mixer with vertical fader strips."""

    def __init__(self, project: ProjectService, audio_engine=None,
                 rt_params=None, hybrid_bridge=None, parent=None):
        super().__init__(parent)
        self.project = project
        self.audio_engine = audio_engine
        self.rt_params = rt_params
        self.hybrid_bridge = hybrid_bridge  # v0.0.20.14

        # v0.0.20.28: Auto-wire HybridEngineBridge from AudioEngine when not explicitly provided.
        if self.hybrid_bridge is None and self.audio_engine is not None:
            try:
                hb = getattr(self.audio_engine, "_hybrid_bridge", None)
                if hb is None:
                    hb = getattr(self.audio_engine, "hybrid_bridge", None)
                if hb is not None:
                    self.hybrid_bridge = hb
            except Exception:
                pass
        self._strips: dict[str, _MixerStrip] = {}

        self._build_ui()
        self.project.project_updated.connect(self.refresh)
        self.refresh()

        # v0.0.20.584: Single VU meter timer for ALL strips (replaces N per-strip timers).
        # At 10 tracks the old design fired 300 callbacks/s, now it's just 30/s total.
        self._vu_timer = QTimer(self)
        self._vu_timer.setInterval(33)  # 30 FPS
        self._vu_timer.timeout.connect(self._tick_all_vu_meters)
        if self.isVisible():
            self._vu_timer.start()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 4, 6, 4)
        layout.setSpacing(4)

        # Header
        header = QHBoxLayout()
        header.setSpacing(6)
        lbl = QLabel("MIXER")
        lbl.setStyleSheet("font-weight: bold; font-size: 11px;")
        header.addWidget(lbl)

        self.btn_add = QPushButton("+ Add")
        self.btn_add.setFixedWidth(70)
        self.btn_add.clicked.connect(self._show_add_menu)
        header.addWidget(self.btn_add)

        self.btn_remove = QPushButton("− Remove")
        self.btn_remove.setFixedWidth(80)
        self.btn_remove.clicked.connect(self._remove_selected_track)
        header.addWidget(self.btn_remove)

        header.addStretch(1)
        layout.addLayout(header)

        # Scroll area with horizontal strip layout
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        layout.addWidget(self.scroll, 1)

        self.inner = QWidget()
        self.inner_layout = QHBoxLayout(self.inner)
        self.inner_layout.setContentsMargins(0, 0, 0, 0)
        self.inner_layout.setSpacing(2)
        self.inner_layout.addStretch(1)
        self.scroll.setWidget(self.inner)

        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def _show_add_menu(self) -> None:
        menu = QMenu(self)
        a_audio = menu.addAction("Audio-Spur")
        a_inst = menu.addAction("Instrumenten-Spur")
        a_bus = menu.addAction("FX/Bus-Spur")
        menu.addSeparator()
        a_fx = menu.addAction("FX-Spur (Return)")
        action = menu.exec(
            self.btn_add.mapToGlobal(self.btn_add.rect().bottomLeft()))
        if action == a_audio:
            self.project.add_track("audio")
        elif action == a_inst:
            self.project.add_track("instrument")
        elif action == a_bus:
            self.project.add_track("bus")
        elif action == a_fx:
            self.project.add_track("fx")

    def _remove_selected_track(self) -> None:
        tid = getattr(self.project, "selected_track_id", "") or ""
        if not tid:
            return
        trk = next(
            (t for t in self.project.ctx.project.tracks
             if t.id == tid), None)
        if trk and getattr(trk, "kind", "") == "master":
            return
        try:
            self.project.delete_track(tid)
        except Exception:
            pass

    def keyPressEvent(self, event) -> None:
        if event.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            self._remove_selected_track()
            event.accept()
            return
        super().keyPressEvent(event)

    def refresh(self) -> None:
        existing_ids = {t.id for t in self.project.ctx.project.tracks}

        # v0.0.20.25: Keep HybridEngineBridge track indices aligned with project order
        if self.hybrid_bridge is not None and hasattr(self.hybrid_bridge, "set_track_index_map"):
            try:
                mapping = {t.id: int(i) for i, t in enumerate(self.project.ctx.project.tracks)}
                self.hybrid_bridge.set_track_index_map(mapping)
            except Exception:
                pass

        # Remove strips for deleted tracks
        for tid in list(self._strips.keys()):
            if tid not in existing_ids:
                w = self._strips.pop(tid)
                w.deleteLater()

        # Clear layout completely
        while self.inner_layout.count():
            item = self.inner_layout.takeAt(0)
            w = item.widget()
            if w and not isinstance(w, _MixerStrip):
                w.deleteLater()
            elif w:
                w.setParent(None)

        # v0.0.20.571: Bitwig-style layout — Normal tracks left, FX+Master right
        normal_tracks = []  # instrument, audio, bus, group
        fx_tracks = []      # fx (return)
        master_track = None

        for trk in self.project.ctx.project.tracks:
            kind = str(getattr(trk, "kind", "") or "")
            if kind == "master":
                master_track = trk
            elif kind == "fx":
                fx_tracks.append(trk)
            else:
                normal_tracks.append(trk)

        # Rebuild strips in Bitwig order
        all_ordered = normal_tracks + fx_tracks + ([master_track] if master_track else [])

        for track_idx_orig, trk in enumerate(self.project.ctx.project.tracks):
            strip = self._strips.get(trk.id)
            if strip is None:
                strip = _MixerStrip(
                    self.project, trk.id, self.audio_engine,
                    self.rt_params, self.hybrid_bridge)
                self._strips[trk.id] = strip

            if self.hybrid_bridge is not None and hasattr(self.hybrid_bridge, "get_track_idx"):
                try:
                    strip._track_idx = int(self.hybrid_bridge.get_track_idx(trk.id))
                except Exception:
                    strip._track_idx = track_idx_orig
            else:
                strip._track_idx = track_idx_orig

            strip.refresh_from_model()

        # Add normal tracks (left side)
        for trk in normal_tracks:
            strip = self._strips.get(trk.id)
            if strip is not None:
                self.inner_layout.addWidget(strip)

        # Add visual separator if there are FX or master tracks
        if fx_tracks or master_track:
            sep = QFrame()
            sep.setFrameShape(QFrame.Shape.VLine)
            sep.setStyleSheet("color: #555; background: #555; max-width: 2px;")
            sep.setFixedWidth(2)
            self.inner_layout.addWidget(sep)

        # Add FX tracks (right side)
        for trk in fx_tracks:
            strip = self._strips.get(trk.id)
            if strip is not None:
                self.inner_layout.addWidget(strip)

        # Master always last (rightmost)
        if master_track is not None:
            strip = self._strips.get(master_track.id)
            if strip is not None:
                self.inner_layout.addWidget(strip)

        self.inner_layout.addStretch(1)

    # v0.0.20.584: Centralized VU metering (single timer for all strips)

    def _tick_all_vu_meters(self) -> None:
        """Update VU meters for all strips in one callback (~30 FPS).

        Replaces N individual QTimers (one per strip) with a single iteration.
        At 10 tracks: 300 callbacks/s → 30/s. At 20 tracks: 600 → 30.
        """
        try:
            for strip in self._strips.values():
                try:
                    strip._update_vu_meter()
                except Exception:
                    pass
        except Exception:
            pass

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        try:
            if not self._vu_timer.isActive():
                self._vu_timer.start()
        except Exception:
            pass

    def hideEvent(self, event) -> None:  # noqa: N802
        super().hideEvent(event)
        try:
            if self._vu_timer.isActive():
                self._vu_timer.stop()
        except Exception:
            pass


# ---- Library Panel (placeholder — kept for compatibility)

class LibraryPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)
        layout.addWidget(QLabel("Bibliothek/Browser (Platzhalter)"))
        layout.addWidget(QLabel(
            "Hier kommen später: Samples, Plugins, Presets, Medienpool…"))
        layout.addStretch(1)
