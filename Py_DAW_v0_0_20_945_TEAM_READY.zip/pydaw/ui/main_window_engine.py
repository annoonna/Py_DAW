"""Engine & Rust Mixin — Extracted from main_window.py (v0.0.20.907).

Contains Rust engine toggle, CPU meter, GPU waveforms, engine migration,
Rust badge management, and browser scan trigger.

Self-contained: only references self.services, self.statusBar(),
self.arranger, self.library, SettingsKeys, set_value/get_value,
and engine state attrs — all provided by MainWindow.

~280 lines extracted.
"""

from __future__ import annotations

import logging
import os

from pydaw.core.settings import SettingsKeys
from pydaw.core.settings_store import get_value, set_value
from .perf_monitor import CpuUsageMonitor

log = logging.getLogger(__name__)


class EngineRustMixin:
    """Engine/Rust toggle and CPU/GPU monitoring — mixed into MainWindow."""

    def _init_menu_rust_badge(self, menu_bar=None) -> None:
        """Legacy no-op.

        The Rust badge was moved into the bottom status signature in
        v0.0.20.651. We keep this method so older call-sites remain harmless.
        """
        self._teardown_menu_rust_badge()


    def _teardown_menu_rust_badge(self) -> None:
        """Hide/remove the old menu-row Rust badge if it exists."""
        try:
            badge = getattr(self, "_menu_rust_badge", None)
            if badge is not None:
                try:
                    badge.hide()
                except Exception:
                    pass
                try:
                    badge.setParent(None)
                except Exception:
                    pass
            self._menu_rust_badge = None
        except Exception:
            log.error("Unexpected error", exc_info=True)


    def _reposition_menu_rust_badge(self) -> None:
        """Legacy no-op after moving the badge to the status strip."""
        self._teardown_menu_rust_badge()


    def _on_engine_migration_dialog(self) -> None:
        """Open the Engine Migration Dialog (Rust ↔ Python).

        v0.0.20.665 — Wired from Audio menu action.
        """
        try:
            from pydaw.ui.engine_migration_settings import EngineMigrationDialog
            dlg = EngineMigrationDialog(parent=self)
            dlg.exec()
        except Exception as exc:
            self.statusBar().showMessage(
                f"Engine Migration Dialog konnte nicht geöffnet werden: {exc}", 5000
            )


    def _toggle_gpu_waveforms(self, checked: bool) -> None:
        """Enable/disable the optional GPU waveform overlay in the Arranger.

        Safety: the overlay is opt-in. On some compositors/drivers an OpenGL
        overlay can hide the grid if it paints an opaque background.
        """
        checked = bool(checked)
        try:
            set_value(SettingsKeys.ui_gpu_waveforms_enabled, checked)
        except Exception:
            pass

        # Apply to ArrangerCanvas
        try:
            if hasattr(self, "arranger") and hasattr(self.arranger, "canvas"):
                self.arranger.canvas.set_gpu_waveforms_enabled(checked)
        except Exception:
            pass

        # Visible indicator
        try:
            if getattr(self, "_gpu_status_label", None) is not None:
                self._gpu_status_label.setText("GPU: ON" if checked else "GPU: OFF")
        except Exception:
            pass
        try:
            self.statusBar().showMessage("GPU Waveforms: ON" if checked else "GPU Waveforms: OFF", 2000)
        except Exception:
            pass


    def _toggle_cpu_meter(self, checked: bool) -> None:
        """Enable/disable a tiny CPU indicator in the status bar.

        This is intentionally very cheap:
        - QTimer in GUI thread (default 1000ms)
        - `time.process_time()` deltas / wall deltas
        - No audio-thread involvement

        Default is OFF (opt-in), to keep the UI minimal.
        """
        self._apply_cpu_meter_state(bool(checked), persist=True)


    def _apply_cpu_meter_state(self, enabled: bool, persist: bool = True) -> None:
        enabled = bool(enabled)

        if persist:
            try:
                set_value(SettingsKeys.ui_cpu_meter_enabled, enabled)
            except Exception:
                pass

        # Label visibility
        try:
            if getattr(self, "_cpu_status_label", None) is not None:
                self._cpu_status_label.setVisible(enabled)
                if not enabled:
                    self._cpu_status_label.setText("")
        except Exception:
            pass

        if not enabled:
            try:
                if getattr(self, "_cpu_monitor", None) is not None:
                    self._cpu_monitor.stop()
            except Exception:
                pass
            try:
                self.statusBar().showMessage("CPU Anzeige: OFF", 1500)
            except Exception:
                pass
            return

        # Lazy create monitor
        if getattr(self, "_cpu_monitor", None) is None:
            try:
                self._cpu_monitor = CpuUsageMonitor(interval_ms=1000, parent=self)
                self._cpu_monitor.updated.connect(self._on_cpu_meter_updated)
            except Exception:
                self._cpu_monitor = None

        try:
            if self._cpu_monitor is not None:
                self._cpu_monitor.start()
        except Exception:
            pass

        try:
            self.statusBar().showMessage("CPU Anzeige: ON", 1500)
        except Exception:
            pass


    def _on_cpu_meter_updated(self, pct: float) -> None:
        try:
            if getattr(self, "_cpu_status_label", None) is None:
                return
            # round for stability; avoid flicker
            val = int(round(float(pct)))
            if val < 0:
                val = 0
            # very high values can happen on weird timers; clamp for display
            if val > 999:
                val = 999
            self._cpu_status_label.setText(f"CPU: {val}%")
        except Exception:
            pass

    # ── v0.0.20.696: Rust Audio-Engine Toggle ──────────────────────────────


    def _toggle_rust_engine(self, checked: bool) -> None:
        """Toggle the Rust Audio-Engine on/off.

        Persists to QSettings AND sets the USE_RUST_ENGINE env var so the
        engine_migration controller and rust_engine_bridge pick it up
        immediately. Takes effect on next playback start.
        """
        self._apply_rust_engine_state(bool(checked), persist=True)


    def _apply_rust_engine_state(self, enabled: bool, persist: bool = True) -> None:
        import os
        enabled = bool(enabled)

        # Persist to QSettings
        if persist:
            try:
                set_value(SettingsKeys.audio_rust_engine_enabled, enabled)
            except Exception:
                pass

        # Set env var for immediate effect
        os.environ["USE_RUST_ENGINE"] = "1" if enabled else "0"

        # Update status label
        try:
            lbl = getattr(self, "_rust_status_label", None)
            if lbl is not None:
                if enabled:
                    lbl.setText("R: ON")
                    lbl.setStyleSheet(
                        "QLabel { color: #ff6e40; font-weight: bold; "
                        "padding: 0 4px; }"
                    )
                else:
                    lbl.setText("R: OFF")
                    lbl.setStyleSheet(
                        "QLabel { color: #666; padding: 0 4px; }"
                    )
        except Exception:
            pass

        # Status bar feedback
        try:
            if enabled:
                self.statusBar().showMessage(
                    "🦀 Rust Audio-Engine: AKTIV — wird beim nächsten Play wirksam", 3000
                )
            else:
                self.statusBar().showMessage(
                    "🐍 Python Audio-Engine — Rust deaktiviert", 3000
                )
        except Exception:
            pass

        # v0.0.20.739: When Rust engine is toggled ON, trigger a background
        # plugin scan so the browser shows Rust-discovered plugins immediately
        # without requiring a manual Rescan click.
        if enabled:
            try:
                from PyQt6.QtCore import QTimer
                QTimer.singleShot(3000, self._trigger_rust_browser_scan)
            except Exception:
                pass

    # ── v0.0.20.701: Plugin Sandbox Toggle ─────────────────────────────────


    def _trigger_rust_browser_scan(self) -> None:
        """v0.0.20.739: Forward Rust plugin scan result to the plugin browser.

        Called 3 s after the Rust engine is toggled ON, giving the engine time
        to start its IPC socket.  Finds the PluginsBrowserWidget inside the
        DeviceBrowser and calls _trigger_rust_scan_if_available() on it —
        fully guarded, nothing breaks if the browser isn't open.
        """
        try:
            library = getattr(self, "library", None)
            if library is None:
                return
            plugins_tab = getattr(library, "plugins_tab", None)
            if plugins_tab is None:
                return
            trigger = getattr(plugins_tab, "_trigger_rust_scan_if_available", None)
            if callable(trigger):
                trigger()
        except Exception:
            pass


