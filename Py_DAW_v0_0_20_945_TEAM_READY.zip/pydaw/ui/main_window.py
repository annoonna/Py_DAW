"""Main window (v0.0.19.0).

import logging
log = logging.getLogger(__name__)


v0.0.14:
- Fix: ServiceContainer includes metronome (no crash)
- Project Settings (central BPM/TS/Grid)
- Metronome audio click (best effort via sounddevice, non-blocking)
- Grid/Snap division control (toolbar + project persistence)
- Automation lanes panel (placeholder, toggleable)
- MIDI Settings (best effort via mido) + message monitor in status bar
- JACK/PipeWire-JACK presence (best effort): registers ports to appear in qpwgraph
"""

from __future__ import annotations

from pathlib import Path
import os
import subprocess
import sys
import traceback
import logging

log = logging.getLogger(__name__)

from PyQt6.QtGui import QGuiApplication, QAction, QKeySequence, QShortcut

from PyQt6.QtWidgets import (

    QApplication,
    QMainWindow,
    QWidget,
    QToolButton,
    QComboBox,
    QLabel,
    QHBoxLayout,
    QVBoxLayout,
    QSplitter,
    QFileDialog,
    QMessageBox,
    QDockWidget,
    QInputDialog,
    QTabWidget,
    QMenu,
)
from PyQt6.QtCore import Qt, QTimer

from pydaw.services.container import ServiceContainer
from pydaw.core.settings import SettingsKeys
from pydaw.core.settings_store import get_value, set_value
from .actions import build_actions
from .transport import TransportPanel
from .toolbar import ToolBarPanel
from .arranger import ArrangerView
from .mixer import MixerPanel, LibraryPanel
from .track_parameters import TrackParametersPanel
from .audio_settings_dialog import AudioSettingsDialog
from .midi_settings_dialog import MidiSettingsDialog
from .midi_mapping_dialog import MidiMappingDialog
from .editor_tabs import EditorTabs
from .clip_launcher import ClipLauncherPanel
from .time_signature_dialog import TimeSignatureDialog
from .project_settings_dialog import ProjectSettingsDialog
from .qt_logo_button import QtLogoButton
from .rust_logo_button import RustLogoButton
from .sqlite_logo_button import SQLiteLogoButton
from .device_panel import DevicePanel
from .project_tab_bar import ProjectTabBar
from .main_window_smartdrop import SmartDropMixin
from .main_window_tabs import ProjectTabsMixin
from .main_window_screen_layout import ScreenLayoutMixin
from .main_window_fileio import FileIOMixin
from .main_window_docks import DockTogglesMixin
from .main_window_sandbox import SandboxMixin
from .main_window_transport import TransportRecordingMixin
from .main_window_engine import EngineRustMixin
from .project_browser_widget import ProjectBrowserWidget
from .perf_monitor import CpuUsageMonitor
from .screen_layout import PanelId  # used by ScreenLayoutMixin (re-export safety)


class MainWindow(TransportRecordingMixin, EngineRustMixin, FileIOMixin, DockTogglesMixin, SandboxMixin, SmartDropMixin, ProjectTabsMixin, ScreenLayoutMixin, QMainWindow):
    def _set_status(self, text: str, timeout_ms: int = 3000) -> None:
        """Central helper to show a status message.

        Some features (snapshots, SF2 handling, imports) want a single place to
        report feedback without raising exceptions inside Qt slots.
        """
        try:
            self.statusBar().showMessage(str(text), int(timeout_ms))
        except Exception:
            pass

    def _safe_project_call(self, method: str, *args, **kwargs):
        """Call ProjectService methods defensively.

        PyQt kann bei Exceptions in Slots hart abbrechen. Deshalb: abfangen,
        in Statusbar melden und weiterlaufen.
        """
        try:
            fn = getattr(self.services.project, method, None)
            if callable(fn):
                return fn(*args, **kwargs)
            self.statusBar().showMessage(f"ProjectService: '{method}' nicht verfügbar.", 4000)
        except Exception as exc:
            try:
                self.services.project.error.emit(str(exc))
            except Exception:
                pass
            self.statusBar().showMessage(f"Fehler in ProjectService.{method}: {exc}", 6000)
        return None

    def _safe_call(self, fn, *args, **kwargs):
        """Call any callable defensively.

        IMPORTANT: On some PyQt6 setups, uncaught Python exceptions inside Qt
        event handlers / slots can lead to a Qt fatal error (SIGABRT). This
        helper ensures we never let exceptions escape into Qt.
        """
        try:
            return fn(*args, **kwargs)
        except Exception as exc:
            try:
                self._set_status(f"Fehler: {exc}", 8000)
            except Exception:
                pass
            try:
                log.error("Unexpected error", exc_info=True)
            except Exception:
                pass
            return None


    def _dispatch_edit(self, op: str) -> None:
        """Dispatch global Edit actions (Copy/Cut/Paste/SelectAll) to the focused panel.

        Rationale: avoids Qt "Ambiguous shortcut" warnings and provides consistent DAW-style editing.
        Paste in PianoRoll uses the last mouse position (grid anchor) and snaps to the current grid.
        """
        try:
            w = QApplication.focusWidget()
        except Exception:
            w = None

        # 1) PianoRoll (inside EditorTabs)
        try:
            pr = None
            et = getattr(self, "editor_tabs", None)
            if et is not None:
                pr = getattr(et, "pianoroll", None)

            if pr is not None and w is not None and pr.isVisible() and pr.isAncestorOf(w):
                c = getattr(pr, "canvas", None)
                if c is None:
                    return
                if op == "copy":
                    c.copy_selected()
                    self.statusBar().showMessage("PianoRoll: Copy", 900)
                    return
                if op == "cut":
                    c.cut_selected()
                    self.statusBar().showMessage("PianoRoll: Cut", 900)
                    return
                if op == "paste":
                    c.paste_at_last_mouse()
                    self.statusBar().showMessage("PianoRoll: Paste", 900)
                    return
                if op == "select_all":
                    c.select_all()
                    self.statusBar().showMessage("PianoRoll: Select All", 900)
                    return
        except Exception as e:
            try:
                self.statusBar().showMessage(f"Edit dispatch error: {e}", 3000)
            except Exception:
                pass

        # 2) Other panels (Arranger/ClipLauncher/Mixer) – TODO: implement.
        try:
            self.statusBar().showMessage("Edit: noch nicht für dieses Panel implementiert.", 2000)
        except Exception:
            pass
    def __init__(self, services: ServiceContainer | None = None):
        super().__init__()
        self.services = services or ServiceContainer.create_default()

        self.actions = build_actions(self)
        try:
            self.addAction(self.actions.edit_undo)
            self.addAction(self.actions.edit_redo)
        except Exception:
            pass
        self._build_menus()
        self._build_layout()
        self._wire_actions()

        # --- Status bar indicators (permanent)
        # Keep tiny, always-visible state like performance toggles here.
        try:
            self._cpu_status_label = QLabel("")
            self._cpu_status_label.setObjectName("cpuStatusLabel")
            self._cpu_status_label.setVisible(False)  # opt-in
            self.statusBar().addPermanentWidget(self._cpu_status_label)
        except Exception:
            self._cpu_status_label = None

        try:
            self._gpu_status_label = QLabel("GPU: OFF")
            self._gpu_status_label.setObjectName("gpuStatusLabel")
            self.statusBar().addPermanentWidget(self._gpu_status_label)
        except Exception:
            self._gpu_status_label = None

        # v0.0.20.696: Rust Engine status indicator (next to CPU/GPU)
        try:
            self._rust_status_label = QLabel("")
            self._rust_status_label.setObjectName("rustStatusLabel")
            self._rust_status_label.setToolTip(
                "🦀 Rust Audio-Engine Status\n\n"
                "R: ON  = Audio wird in Rust gerendert (schneller)\n"
                "R: OFF = Python Audio-Engine (Fallback)\n\n"
                "Umschalten: Audio → 🦀 Rust Audio-Engine\n"
                "Shortcut: Ctrl+Shift+R"
            )
            self.statusBar().addPermanentWidget(self._rust_status_label)
        except Exception:
            self._rust_status_label = None

        # v0.0.20.702: Plugin Sandbox status indicator
        try:
            from pydaw.ui.crash_indicator_widget import SandboxStatusWidget
            self._sandbox_status = SandboxStatusWidget(self)
            self._sandbox_status.setObjectName("sandboxStatusWidget")
            self.statusBar().addPermanentWidget(self._sandbox_status)
        except Exception:
            self._sandbox_status = None

        # CPU monitor object (created lazily). Must never run in audio callback.
        self._cpu_monitor = None

        # Sync view menu checks with current widget state (without emitting signals)
        try:
            self.actions.view_toggle_notation.blockSignals(True)
            self.actions.view_toggle_notation.setChecked(self.editor_tabs.is_notation_tab_visible())
        finally:
            self.actions.view_toggle_notation.blockSignals(False)

        # Sync Clip Launcher + Overlay toggles from persisted settings
        try:
            cl_visible = bool(get_value(SettingsKeys.ui_cliplauncher_visible, False))
        except Exception:
            cl_visible = False
        try:
            ov_enabled = bool(get_value(SettingsKeys.ui_cliplauncher_overlay_enabled, True))
        except Exception:
            ov_enabled = True

        # Sync GPU Waveform overlay toggle (OFF by default)
        try:
            raw = get_value(SettingsKeys.ui_gpu_waveforms_enabled, False)
            # QSettings may return strings: "true"/"false" instead of bool
            if isinstance(raw, str):
                gpu_enabled = raw.lower() in ("true", "1", "yes", "on")
            else:
                gpu_enabled = bool(raw)
        except Exception:
            gpu_enabled = False

        # Sync CPU meter toggle (OFF by default)
        try:
            cpu_enabled = bool(get_value(SettingsKeys.ui_cpu_meter_enabled, False))
        except Exception:
            cpu_enabled = False

        # Sync Rust Engine toggle (OFF by default — experimentell)
        try:
            _rust_raw = get_value(SettingsKeys.audio_rust_engine_enabled, None)
            if _rust_raw is None:
                # First run: default OFF (Rust can't render Python instruments yet)
                rust_enabled = False
            elif isinstance(_rust_raw, str):
                rust_enabled = _rust_raw.lower() in ("true", "1", "yes", "on")
            else:
                rust_enabled = bool(_rust_raw)
        except Exception:
            rust_enabled = False

        # Sync Plugin Sandbox toggle (OFF by default)
        try:
            _sbx_raw = get_value(SettingsKeys.audio_plugin_sandbox_enabled, None)
            if _sbx_raw is None:
                sandbox_enabled = False
            elif isinstance(_sbx_raw, str):
                sandbox_enabled = _sbx_raw.lower() in ("true", "1", "yes", "on")
            else:
                sandbox_enabled = bool(_sbx_raw)
        except Exception:
            sandbox_enabled = False

        # Apply without emitting signals
        try:
            self.actions.view_toggle_cliplauncher.blockSignals(True)
            self.actions.view_toggle_cliplauncher.setChecked(cl_visible)
        finally:
            self.actions.view_toggle_cliplauncher.blockSignals(False)
        try:
            self.actions.view_toggle_drop_overlay.blockSignals(True)
            self.actions.view_toggle_drop_overlay.setChecked(ov_enabled)
        finally:
            self.actions.view_toggle_drop_overlay.blockSignals(False)

        try:
            self.actions.view_toggle_gpu_waveforms.blockSignals(True)
            self.actions.view_toggle_gpu_waveforms.setChecked(bool(gpu_enabled))
        finally:
            self.actions.view_toggle_gpu_waveforms.blockSignals(False)

        try:
            self.actions.view_toggle_cpu_meter.blockSignals(True)
            self.actions.view_toggle_cpu_meter.setChecked(bool(cpu_enabled))
        finally:
            self.actions.view_toggle_cpu_meter.blockSignals(False)

        # Rust Engine toggle sync
        try:
            self.actions.audio_toggle_rust_engine.blockSignals(True)
            self.actions.audio_toggle_rust_engine.setChecked(bool(rust_enabled))
        finally:
            self.actions.audio_toggle_rust_engine.blockSignals(False)

        # Plugin Sandbox toggle sync
        try:
            self.actions.audio_toggle_plugin_sandbox.blockSignals(True)
            self.actions.audio_toggle_plugin_sandbox.setChecked(bool(sandbox_enabled))
        finally:
            self.actions.audio_toggle_plugin_sandbox.blockSignals(False)

        # Apply to UI
        try:
            self.launcher_dock.setVisible(bool(cl_visible))
        except Exception:
            pass
        try:
            # overlay toggle is only meaningful when clip-launcher is visible
            self.actions.view_toggle_drop_overlay.setEnabled(bool(cl_visible))
        except Exception:
            pass

        # Apply GPU overlay to ArrangerCanvas
        try:
            if hasattr(self, "arranger") and hasattr(self.arranger, "canvas"):
                self.arranger.canvas.set_gpu_waveforms_enabled(bool(gpu_enabled))
        except Exception:
            pass
        try:
            if getattr(self, "_gpu_status_label", None) is not None:
                self._gpu_status_label.setText("GPU: ON" if bool(gpu_enabled) else "GPU: OFF")
        except Exception:
            pass

        # Apply CPU meter (opt-in)
        try:
            self._apply_cpu_meter_state(bool(cpu_enabled), persist=False)
        except Exception:
            pass

        # Apply Rust Engine state
        try:
            self._apply_rust_engine_state(bool(rust_enabled), persist=False)
        except Exception:
            pass
        # Undo/Redo state updates
        try:
            self.services.project.undo_changed.connect(self._update_undo_redo_actions)
        except Exception:
            pass
        self._update_undo_redo_actions()

        # Python logo animation (UI-only, QTimer based)
        self._init_python_logo_animation()

        # Make sure the window is usable on different desktop sizes/DPI settings.
        self._fit_to_screen()

        # Prime parameter inspector with the current track selection.
        try:
            self._on_track_selected(self._selected_track_id())
        except Exception:
            pass

        self.statusBar().showMessage(
            "Bereit (v0.0.20.18: Vulkan Default + JACK-Client Hotfix + GPU Waveforms Opt-In)"
        )

        self.services.project.project_changed.connect(self._update_window_title)
        self.services.project.status.connect(lambda m: self.statusBar().showMessage(m, 3000))
        self.services.project.error.connect(self._show_error)
        try:
            self.services.audio_engine.error.connect(self._show_error)
            self.services.audio_engine.running_changed.connect(
                lambda r: self.statusBar().showMessage(
                    "Audio: läuft" if r else "Audio: gestoppt", 1200
                )
            )
        except Exception:
            pass
        self.services.midi.message_received.connect(lambda t: self.statusBar().showMessage(t, 1200))
        self._update_window_title(self.services.project.display_name())

        # JACK per-track monitoring routes (Input Monitoring per Track)
        try:
            self.services.project.project_updated.connect(self._update_jack_monitor_routes)
        except Exception:
            pass
        try:
            self._update_jack_monitor_routes()
        except Exception:
            pass

        # note_preview → SamplerRegistry for track-specific routing
        try:
            from pydaw.plugins.sampler.sampler_registry import get_sampler_registry
            self._sampler_registry = get_sampler_registry()
            self.services.project.note_preview.connect(self._on_note_preview_routed)
            # v0.0.20.42: Wire sampler registry to audio engine for live MIDI→Sampler
            try:
                self.services.audio_engine._sampler_registry = self._sampler_registry
            except Exception:
                pass
        except Exception:
            self._sampler_registry = None

        # Live MIDI -> Notation: Ghost Noteheads (Input Monitoring)
        try:
            self.services.midi.live_note_on.connect(self.editor_tabs.notation.handle_live_note_on)
            self.services.midi.live_note_off.connect(self.editor_tabs.notation.handle_live_note_off)
            self.services.midi.panic.connect(self.editor_tabs.notation.handle_midi_panic)
        except Exception:
            pass

        # Live MIDI -> Sampler (sustain while key held)
        try:
            self.services.midi.live_note_on.connect(self._on_live_note_on_route_to_sampler)
            self.services.midi.live_note_off.connect(self._on_live_note_off_route_to_sampler)
        except Exception:
            pass

        # PianoRoll "Record" toggle -> MIDI record enable (write into clip)
        try:
            self.editor_tabs.pianoroll.record_toggled.connect(self.services.midi.set_record_enabled)
        except Exception:
            pass

        # Notation "Record" toggle -> same MIDI record path (v0.0.20.449)
        try:
            self.editor_tabs.notation.record_toggled.connect(self.services.midi.set_record_enabled)
        except Exception:
            pass


        # Panic also stops all sampler voices (No-Hang)
        try:
            self.services.midi.panic.connect(self._on_midi_panic)
        except Exception:
            pass

        # v0.0.20.609: Computer Keyboard MIDI (Bitwig-Style QWERTY→MIDI)
        self._computer_kb_midi = None
        try:
            from pydaw.services.computer_keyboard_midi import ComputerKeyboardMidi
            ckm = ComputerKeyboardMidi(midi_manager=self.services.midi, parent=self)
            from PyQt6.QtWidgets import QApplication
            app = QApplication.instance()
            if app is not None:
                app.installEventFilter(ckm)
            self._computer_kb_midi = ckm
            # Wire menu toggle
            if hasattr(self, '_a_computer_kb') and self._a_computer_kb is not None:
                self._a_computer_kb.toggled.connect(ckm.set_enabled)
                ckm.enabled_changed.connect(self._a_computer_kb.setChecked)
                ckm.octave_changed.connect(
                    lambda o: self.statusBar().showMessage(f"Computer Keyboard: Oktave {o}", 2000)
                )
            # v0.0.20.610: Dezentes Overlay mit Tastenbelegung
            try:
                from pydaw.ui.computer_keyboard_overlay import ComputerKeyboardOverlay
                overlay = ComputerKeyboardOverlay(parent=self)
                self._ckb_overlay = overlay
                ckm.enabled_changed.connect(overlay.set_visible_animated)
                ckm.octave_changed.connect(overlay.set_octave)
                ckm.key_pressed.connect(overlay.key_pressed)
                ckm.key_released.connect(overlay.key_released)
            except Exception:
                pass
        except Exception:
            pass

        # v0.0.20.609: Touch Keyboard (on-screen piano — toggleable dock)
        self._touch_kb_dock = None
        self._touch_kb_widget = None
        try:
            from pydaw.ui.touch_keyboard import TouchKeyboardWidget
            tkw = TouchKeyboardWidget(midi_manager=self.services.midi, parent=self)
            self._touch_kb_widget = tkw

            tkd = QDockWidget("Touch Keyboard", self)
            tkd.setWidget(tkw)
            tkd.setAllowedAreas(Qt.DockWidgetArea.BottomDockWidgetArea | Qt.DockWidgetArea.TopDockWidgetArea)
            self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, tkd)
            tkd.hide()  # start hidden
            self._touch_kb_dock = tkd

            # Wire menu toggle
            if hasattr(self, '_a_touch_kb') and self._a_touch_kb is not None:
                self._a_touch_kb.toggled.connect(lambda on: tkd.setVisible(on))
                tkd.visibilityChanged.connect(lambda vis: self._a_touch_kb.setChecked(vis) if self._a_touch_kb else None)
        except Exception:
            pass

        # ClipContextService → Editor Integration (Pro-DAW-Style pyqtSlot → Editor Workflow)
        try:
            self.services.clip_context.active_slot_changed.connect(self._on_active_slot_changed)
        except Exception:
            pass

        # v0.0.20.173: Crash recovery + autosave (Bitwig-style prompt on restart)
        try:
            self._init_recovery()
        except Exception:
            pass


    # --- menus

    def _build_menus(self) -> None:
        mb = self.menuBar()

        m_file = mb.addMenu("Datei")
        m_file.addAction(self.actions.file_new)
        m_file.addAction(self.actions.file_open)
        m_file.addAction(self.actions.file_save)
        m_file.addAction(self.actions.file_save_as)
        m_file.addSeparator()

        # Multi-Project Tab actions (v0.0.20.77)
        self._act_new_tab = QAction("Neuer Tab", self)
        self._act_new_tab.setShortcut("Ctrl+T")
        self._act_new_tab.triggered.connect(lambda _=False: self._safe_call(self._on_project_tab_new))
        m_file.addAction(self._act_new_tab)

        self._act_open_in_tab = QAction("Öffnen in neuem Tab…", self)
        self._act_open_in_tab.setShortcut("Ctrl+Shift+O")
        self._act_open_in_tab.triggered.connect(lambda _=False: self._safe_call(self._on_project_tab_open))
        m_file.addAction(self._act_open_in_tab)

        self._act_close_tab = QAction("Tab schließen", self)
        self._act_close_tab.setShortcut("Ctrl+W")
        self._act_close_tab.triggered.connect(
            lambda: self._safe_call(
                self._on_project_tab_close,
                getattr(self, '_project_tab_service', None) and self._project_tab_service.active_index or 0
            )
        )
        m_file.addAction(self._act_close_tab)
        m_file.addSeparator()

        # Tab navigation shortcuts (v0.0.20.78)
        self._shortcut_next_tab = QShortcut(QKeySequence("Ctrl+Tab"), self)
        self._shortcut_next_tab.activated.connect(lambda: self._safe_call(self._on_tab_next))
        # Metadata for Hilfe → Arbeitsmappe (Shortcuts-Liste)
        try:
            self._shortcut_next_tab.setObjectName("shortcut_next_tab")
            self._shortcut_next_tab.setProperty("pydaw_desc", "Nächster Projekt-Tab")
        except Exception:
            pass
        self._shortcut_prev_tab = QShortcut(QKeySequence("Ctrl+Shift+Tab"), self)
        self._shortcut_prev_tab.activated.connect(lambda: self._safe_call(self._on_tab_prev))
        try:
            self._shortcut_prev_tab.setObjectName("shortcut_prev_tab")
            self._shortcut_prev_tab.setProperty("pydaw_desc", "Vorheriger Projekt-Tab")
        except Exception:
            pass

        m_file.addAction(self.actions.file_import_audio)
        m_file.addAction(self.actions.file_import_midi)
        m_file.addAction(self.actions.file_import_dawproject)  # v0.0.20.88
        m_file.addAction(self.actions.file_export_dawproject)  # v0.0.20.359
        m_file.addSeparator()
        m_file.addAction(self.actions.file_export)
        m_file.addAction(self.actions.file_export_midi_clip)  # FIXED v0.0.19.7.15
        m_file.addAction(self.actions.file_export_midi_track)  # FIXED v0.0.19.7.15
        m_file.addSeparator()
        m_file.addAction(self.actions.file_exit)

        m_edit = mb.addMenu("Bearbeiten")
        m_edit.addAction(self.actions.edit_undo)
        m_edit.addAction(self.actions.edit_redo)
        m_edit.addSeparator()
        m_edit.addAction(self.actions.edit_cut)
        m_edit.addAction(self.actions.edit_copy)
        m_edit.addAction(self.actions.edit_paste)
        m_edit.addSeparator()
        m_edit.addAction(self.actions.edit_select_all)

        m_view = mb.addMenu("Ansicht")
        m_view.addAction(self.actions.view_dummy)
        m_view.addSeparator()
        m_view.addAction(self.actions.view_toggle_pianoroll)
        m_view.addAction(self.actions.view_toggle_notation)
        m_view.addAction(self.actions.view_toggle_cliplauncher)
        m_view.addAction(self.actions.view_toggle_drop_overlay)
        m_view.addAction(self.actions.view_toggle_gpu_waveforms)
        m_view.addAction(self.actions.view_toggle_cpu_meter)
        m_view.addAction(self.actions.view_toggle_automation)

        # Screen Layout submenu (Bitwig-Style multi-monitor)
        m_layout = m_view.addMenu("Bildschirm-Layout")
        m_layout.setObjectName("screenLayoutMenu")
        # Will be populated after panels are created in _build_layout
        self._screen_layout_menu = m_layout

        # v0.0.20.817: New View menu items
        try:
            m_view.addSeparator()

            # Live Performance Mode (P4A)
            a_live = QAction("🎭 Live-Performance (F11)", self)
            a_live.setShortcut(QKeySequence("F11"))
            a_live.triggered.connect(lambda _=False: self._safe_call(self._toggle_live_performance))
            m_view.addAction(a_live)

            # Community Preset Browser (P6C)
            a_presets = QAction("🎛 Community Presets…", self)
            a_presets.setShortcut(QKeySequence("Ctrl+Alt+B"))
            a_presets.triggered.connect(lambda _=False: self._safe_call(self._toggle_preset_browser_dock))
            m_view.addAction(a_presets)

            # Theme Switcher (Tech Debt)
            m_themes = m_view.addMenu("🎨 Theme")
            for theme_key, theme_name in [
                ("dark", "Dark (Standard)"), ("light", "Light"),
                ("midnight", "Midnight"), ("solarized_dark", "Solarized Dark"),
                ("high_contrast", "High Contrast"),
            ]:
                a = QAction(theme_name, self)
                a.triggered.connect(
                    lambda _=False, k=theme_key: self._safe_call(self._switch_theme, k)
                )
                m_themes.addAction(a)

            # Video Track (P7A)
            a_video = QAction("🎬 Video-Spur…", self)
            a_video.triggered.connect(lambda _=False: self._safe_call(self._toggle_video_track))
            m_view.addAction(a_video)

            # Video-KI Assistent (VK8, v0.0.20.920)
            a_video_ki = QAction("🧠 Video-KI Assistent…", self)
            a_video_ki.triggered.connect(lambda _=False: self._safe_call(self._toggle_video_ki_panel))
            m_view.addAction(a_video_ki)

            # Podcast Mode (P7B)
            a_podcast = QAction("🎙 Podcast-Modus…", self)
            a_podcast.triggered.connect(lambda _=False: self._safe_call(self._toggle_podcast_mode))
            m_view.addAction(a_podcast)
        except Exception:
            pass

        m_proj = mb.addMenu("Projekt")
        m_proj.addAction(self.actions.project_add_audio_track)
        m_proj.addAction(self.actions.project_add_instrument_track)
        m_proj.addAction(self.actions.project_add_bus_track)
        m_proj.addSeparator()
        m_proj.addAction(self.actions.project_add_placeholder_clip)
        m_proj.addAction(self.actions.project_remove_selected_track)
        m_proj.addSeparator()
        m_proj.addAction(self.actions.project_time_signature)
        m_proj.addAction(self.actions.project_settings)
        m_proj.addSeparator()
        m_proj.addAction(self.actions.project_save_snapshot)
        m_proj.addAction(self.actions.project_load_snapshot)
        m_proj.addSeparator()
        m_proj.addAction(self.actions.project_load_sf2)

        # Project Compare (Diff between open project tabs) — v0.0.20.85
        self._act_compare_tabs = QAction("Projekt vergleichen…", self)
        self._act_compare_tabs.setShortcut("Ctrl+Alt+D")
        self._act_compare_tabs.triggered.connect(lambda _=False: self._safe_call(self._show_project_compare_dialog))
        m_proj.addSeparator()
        m_proj.addAction(self._act_compare_tabs)

        # AI Orchestrator (multi-track ensemble generator) — v0.0.20.195
        self._act_ai_orchestrator = QAction("AI Orchestrator…", self)
        try:
            self._act_ai_orchestrator.setShortcut("Ctrl+Alt+O")
        except Exception:
            pass
        self._act_ai_orchestrator.triggered.connect(lambda _=False: self._safe_call(self._show_ai_orchestrator_dialog))
        m_proj.addAction(self._act_ai_orchestrator)

        # v0.0.20.747 P2A: KI-Kompositions-Assistent (Claude API)
        self._act_ki_assistant = QAction("🤖 KI-Assistent…", self)
        try:
            self._act_ki_assistant.setShortcut("Ctrl+Alt+K")
        except Exception:
            pass
        self._act_ki_assistant.triggered.connect(lambda _=False: self._safe_call(self._toggle_ki_assistant_dock))
        m_proj.addAction(self._act_ki_assistant)
        # v0.0.20.910 C4.8: Smart Mixer Heatmap
        self._act_smart_mixer = QAction("🎛️ Smart Mixer…", self)
        self._act_smart_mixer.setToolTip(
            "Frequenz-Heatmap und Auto-Gain-Staging"
        )
        self._act_smart_mixer.triggered.connect(
            lambda _=False: self._safe_call(self._open_smart_mixer)
        )
        m_proj.addAction(self._act_smart_mixer)

        # v0.0.20.798 P5A: Collaboration Panel
        self._act_collab_panel = QAction("🤝 Kollaboration…", self)
        try:
            self._act_collab_panel.setShortcut("Ctrl+Alt+C")
        except Exception:
            pass
        self._act_collab_panel.triggered.connect(lambda _=False: self._safe_call(self._toggle_collab_dock))
        m_proj.addAction(self._act_collab_panel)

        # v0.0.20.798 P6A: Python Scripting Console
        self._act_scripting = QAction("🐍 Python Console…", self)
        try:
            self._act_scripting.setShortcut("Ctrl+Alt+P")
        except Exception:
            pass
        self._act_scripting.triggered.connect(lambda _=False: self._safe_call(self._toggle_scripting_dock))
        m_proj.addAction(self._act_scripting)

        # v0.0.20.897: SQLite Console
        self._act_sqlite_console = QAction("🗄️ SQLite Console…", self)
        try:
            self._act_sqlite_console.setShortcut("Ctrl+Alt+S")
        except Exception:
            pass
        self._act_sqlite_console.triggered.connect(lambda _=False: self._safe_call(self._toggle_sqlite_console_dock))
        m_proj.addAction(self._act_sqlite_console)

        # v0.0.20.899: Time-Travel Panel
        self._act_time_travel = QAction("🕰️ Time Travel…", self)
        try:
            self._act_time_travel.setShortcut("Ctrl+Shift+Z")
        except Exception:
            pass
        self._act_time_travel.triggered.connect(lambda _=False: self._safe_call(self._toggle_time_travel_dock))
        m_proj.addAction(self._act_time_travel)

        # v0.0.20.901: Sound Search Panel
        self._act_sound_search = QAction("🔍 Sound-Suche…", self)
        self._act_sound_search.triggered.connect(lambda _=False: self._safe_call(self._toggle_sound_search_dock))
        m_proj.addAction(self._act_sound_search)

        # v0.0.20.901: Undo Tree Panel
        self._act_undo_tree = QAction("🌳 Undo-Baum…", self)
        self._act_undo_tree.triggered.connect(lambda _=False: self._safe_call(self._toggle_undo_tree_dock))
        m_proj.addAction(self._act_undo_tree)

        # v0.0.20.901: Session Heatmap Panel
        self._act_heatmap = QAction("🔥 Session Heatmap…", self)
        self._act_heatmap.triggered.connect(lambda _=False: self._safe_call(self._toggle_heatmap_dock))
        m_proj.addAction(self._act_heatmap)

        # v0.0.20.904: SENTINEL Dashboard
        self._act_sentinel = QAction("🛡️ SENTINEL Dashboard…", self)
        self._act_sentinel.triggered.connect(lambda _=False: self._safe_call(self._toggle_sentinel_dock))
        m_proj.addAction(self._act_sentinel)

        # v0.0.20.817: Session Share + Cloud (P5B)
        try:
            m_proj.addSeparator()
            a_share = QAction("📤 Session teilen…", self)
            a_share.triggered.connect(lambda _=False: self._safe_call(self._create_session_share))
            m_proj.addAction(a_share)

            a_cloud = QAction("☁️ Cloud-Speicher…", self)
            a_cloud.triggered.connect(lambda _=False: self._safe_call(self._show_cloud_dialog))
            m_proj.addAction(a_cloud)
        except Exception:
            pass

        m_audio = mb.addMenu("Audio")
        m_audio.addAction(self.actions.audio_settings)
        m_audio.addSeparator()
        m_audio.addAction(self.actions.audio_prerender_midi)
        m_audio.addAction(self.actions.audio_prerender_selected_clip)
        m_audio.addAction(self.actions.audio_prerender_selected_track)
        m_audio.addSeparator()
        m_audio.addAction(self.actions.midi_settings)
        m_audio.addAction(self.actions.midi_mapping)
        m_audio.addAction(self.actions.midi_panic)
        m_audio.addSeparator()
        # v0.0.20.609: Computer Keyboard MIDI (Bitwig-Style)
        self._a_computer_kb = None
        try:
            a_ckb = QAction("Computer Keyboard MIDI (,/. = Oktave)", self)
            a_ckb.setCheckable(True)
            a_ckb.setShortcut(QKeySequence("Ctrl+Shift+K"))
            a_ckb.setToolTip("QWERTY-Tastatur als MIDI-Controller (Bitwig-Style)")
            m_audio.addAction(a_ckb)
            self._a_computer_kb = a_ckb
        except Exception:
            pass
        # v0.0.20.609: Touch Keyboard (on-screen piano)
        self._a_touch_kb = None
        try:
            a_tkb = QAction("Touch Keyboard (On-Screen Piano)", self)
            a_tkb.setCheckable(True)
            a_tkb.setShortcut(QKeySequence("Ctrl+Shift+T"))
            a_tkb.setToolTip("On-Screen Klaviatur — Mausklick erzeugt MIDI-Noten")
            m_audio.addAction(a_tkb)
            self._a_touch_kb = a_tkb
        except Exception:
            pass

        # v0.0.20.665: Engine Migration Dialog (Rust ↔ Python)
        try:
            m_audio.addSeparator()
            # v0.0.20.696: Rust Engine Toggle (checkable)
            m_audio.addAction(self.actions.audio_toggle_rust_engine)

            # v0.0.20.704: Plugin Sandbox Submenu (P6C)
            m_sandbox = m_audio.addMenu("🛡️ Plugin Sandbox")
            m_sandbox.addAction(self.actions.audio_toggle_plugin_sandbox)
            m_sandbox.addSeparator()

            a_sandbox_restart_all = QAction("🔄 Alle Plugins neu starten", self)
            a_sandbox_restart_all.setToolTip("Alle Sandbox-Worker killen und neu starten")
            a_sandbox_restart_all.triggered.connect(self._on_sandbox_restart_all)
            m_sandbox.addAction(a_sandbox_restart_all)
            self._a_sandbox_restart_all = a_sandbox_restart_all

            a_sandbox_status = QAction("Sandbox-Status…", self)
            a_sandbox_status.setToolTip("Übersicht aller Plugin-Worker und deren Zustand")
            a_sandbox_status.triggered.connect(self._on_sandbox_status_dialog)
            m_sandbox.addAction(a_sandbox_status)

            m_sandbox.addSeparator()

            a_crash_log = QAction("🔥 Plugin Crash Log…", self)
            a_crash_log.setToolTip("Zeigt alle Plugin-Abstürze und Fehlermeldungen")
            a_crash_log.triggered.connect(self._on_crash_log_dialog)
            m_sandbox.addAction(a_crash_log)

            # v0.0.20.725: Plugin Blacklist Dialog
            a_blacklist = QAction("💀 Plugin-Blacklist…", self)
            a_blacklist.setToolTip(
                "Zeigt alle geblacklisteten Plugins (Crash-Isolierung) "
                "und erlaubt manuelles Entsperren"
            )
            a_blacklist.triggered.connect(self._on_plugin_blacklist_dialog)
            m_sandbox.addAction(a_blacklist)

            a_migration = QAction("Engine Migration (Rust ↔ Python)…", self)
            a_migration.setToolTip("Subsysteme zwischen Python- und Rust-Engine umschalten, Benchmark starten")
            a_migration.triggered.connect(self._on_engine_migration_dialog)
            m_audio.addAction(a_migration)
        except Exception:
            pass

        m_help = mb.addMenu("Hilfe")
        m_help.addAction(self.actions.help_workbook)
        m_help.addAction(self.actions.help_toggle_python_animation)

        # v0.0.20.651: the three tech badges now live together in the
        # bottom-right status strip. Keep the legacy menu overlay disabled so
        # the top area stays calm and music-focused.
        self._menu_rust_anchor_action = m_help.menuAction()
        self._teardown_menu_rust_badge()


    def _build_status_tech_signature(self) -> None:
        """Assemble a compact Qt | Python | Rust signature in the status bar.

        Design intent:
        - logos live near CPU/GPU/engine state instead of occupying toolbar space
        - existing Python animation remains intact by reusing the same button
        - purely visual; no transport/audio behaviour changes
        """
        try:
            existing = getattr(self, "_tech_signature_widget", None)
            if existing is not None:
                self._sync_status_tech_signature_sizes()
                return

            self._teardown_menu_rust_badge()

            sb = self.statusBar()
            if sb is None:
                return

            box = QWidget()
            box.setObjectName("chronoTechSignature")
            row = QHBoxLayout(box)
            row.setContentsMargins(6, 0, 6, 0)
            row.setSpacing(6)

            self.btn_qt_logo = QtLogoButton()
            self.btn_qt_logo.setObjectName("statusQtLogoButton")
            self.btn_qt_logo.setToolTip("Qt UI Layer")
            self.btn_qt_logo.clicked.connect(lambda _=False: self._set_status("Qt UI Layer", 2000))

            py_btn = None
            tp = getattr(self, "toolbar_panel", None)
            if tp is not None:
                py_btn = getattr(tp, "btn_python", None)
            if py_btn is not None:
                try:
                    lay = tp.layout()
                    if lay is not None:
                        lay.removeWidget(py_btn)
                except Exception:
                    pass
                try:
                    py_btn.setParent(box)
                except Exception:
                    pass
                py_btn.setObjectName("statusPythonLogoButton")
                py_btn.setToolTip("Python App Layer")
                try:
                    py_btn.clicked.disconnect()
                except (TypeError, RuntimeError):
                    pass
                py_btn.clicked.connect(lambda _=False: self._set_status("Python App Layer", 2000))

            self.btn_rust_logo = RustLogoButton()
            self.btn_rust_logo.setObjectName("statusRustLogoButton")
            self.btn_rust_logo.setToolTip("Rust Core")
            self.btn_rust_logo.clicked.connect(lambda _=False: self._set_status("Rust Core", 2000))

            # v0.0.20.894: SQLite badge — data persistence layer
            self.btn_sqlite_logo = SQLiteLogoButton()
            self.btn_sqlite_logo.setObjectName("statusSQLiteLogoButton")
            self.btn_sqlite_logo.clicked.connect(lambda _=False: self._show_sqlite_stats())
            # v0.0.20.897: Right-click → context menu
            self.btn_sqlite_logo.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            self.btn_sqlite_logo.customContextMenuRequested.connect(self._sqlite_badge_context_menu)

            row.addWidget(self.btn_qt_logo)
            if py_btn is not None:
                row.addWidget(py_btn)
            row.addWidget(self.btn_sqlite_logo)
            row.addWidget(self.btn_rust_logo)

            self._tech_signature_widget = box
            try:
                sb.addPermanentWidget(box)
            except Exception:
                sb.addWidget(box)

            self._sync_status_tech_signature_sizes()
            QTimer.singleShot(0, self._sync_status_tech_signature_sizes)
            # v0.0.20.747 P0D: First-Run-Experience — einmalig beim ersten Start
            QTimer.singleShot(500, self._maybe_show_first_run)
            # v0.0.20.898: Start Time-Travel Journal (after UI is ready)
            QTimer.singleShot(2000, self._start_time_travel_journal)
        except Exception:
            log.error("Unexpected error", exc_info=True)

    def _sync_status_tech_signature_sizes(self) -> None:
        """Keep the status-strip logos consistent and at the approved Rust size."""
        try:
            sb = self.statusBar()
            base = 30
            if sb is not None:
                base = max(28, min(30, int(sb.height()) - 4))
            for name in ("btn_qt_logo", "btn_rust_logo", "btn_sqlite_logo"):
                btn = getattr(self, name, None)
                if btn is not None:
                    btn.setFixedSize(base, base)
            py_btn = None
            tp = getattr(self, "toolbar_panel", None)
            if tp is not None:
                py_btn = getattr(tp, "btn_python", None)
            if py_btn is not None:
                py_btn.setFixedSize(base, base)
        except Exception:
            log.error("Unexpected error", exc_info=True)

    def _sqlite_badge_context_menu(self, pos) -> None:
        """v0.0.20.897: Context menu for SQLite badge."""
        try:
            from PyQt6.QtWidgets import QMenu
            from PyQt6.QtGui import QAction as QAct
            menu = QMenu(self)
            act_status = menu.addAction("📊 DB-Status anzeigen…")
            act_console = menu.addAction("🗄️ SQLite Console öffnen…")
            act_path = menu.addAction("📁 DB-Pfad kopieren")
            chosen = menu.exec(self.btn_sqlite_logo.mapToGlobal(pos))
            if chosen == act_status:
                self._show_sqlite_stats()
            elif chosen == act_console:
                self._toggle_sqlite_console_dock()
            elif chosen == act_path:
                from PyQt6.QtWidgets import QApplication
                path = str(Path.home() / ".config" / "ChronoScaleStudio")
                QApplication.clipboard().setText(path)
                self._set_status(f"DB-Pfad kopiert: {path}", 3000)
        except Exception:
            pass

    def _show_sqlite_stats(self) -> None:
        """Open SQLite health dialog when badge is clicked."""
        try:
            from pydaw.ui.sqlite_health_dialog import SQLiteHealthDialog
            dlg = SQLiteHealthDialog(parent=self)
            dlg.exec()
        except Exception:
            # Fallback: show basic info in status bar
            try:
                from pydaw.services.db_manager import DbManager
                db = DbManager.get()
                db.ensure_ready()
                conn = db.connection()
                if conn is None:
                    self._set_status("SQLite: DB nicht verfügbar", 3000)
                    return
                row = conn.execute(
                    "SELECT COUNT(*) as cnt FROM sqlite_master WHERE type='table'"
                ).fetchone()
                tables = row["cnt"] if row else 0
                import os
                db_path = str(db.db_path)
                size_mb = 0.0
                if os.path.exists(db_path):
                    size_mb = os.path.getsize(db_path) / (1024 * 1024)
                self._set_status(
                    f"SQLite: {tables} Tabellen, {size_mb:.1f} MB — "
                    f"Alle Parameter änderbar (Audio → Einstellungen)",
                    5000,
                )
            except Exception:
                self._set_status("SQLite Datenbank aktiv", 2000)

    def _show_ai_orchestrator_dialog(self) -> None:
        """Open the multi-track AI Orchestrator tool."""
        try:
            from pydaw.ui.orchestrator_dialog import OrchestratorDialog
            dlg = OrchestratorDialog(self.services, parent=self)
            dlg.exec()
        except Exception:
            log.error("Unexpected error", exc_info=True)
            try:
                QMessageBox.warning(self, "AI Orchestrator", "Konnte den AI Orchestrator nicht öffnen. Details siehe Terminal/Log.")
            except Exception:
                pass

    # v0.0.20.747 P2A — KI-Kompositions-Assistent
    def _start_time_travel_journal(self) -> None:
        """v0.0.20.898: Start the Time-Travel Journal (continuous event logging)."""
        try:
            from pydaw.services.time_travel_journal import TimeTravelJournal
            journal = TimeTravelJournal.get()
            ps = getattr(self, 'services', None)
            project_svc = getattr(ps, 'project', None) if ps else None
            midi_mgr = getattr(ps, 'midi', None) if ps else None
            transport_svc = getattr(ps, 'transport', None) if ps else None
            journal.start(project_svc, midi_mgr, transport_svc)
            self._time_travel_journal = journal
            log.info("[MainWindow] Time-Travel Journal started")
            # v0.0.20.901: Start auto-tagger
            try:
                from pydaw.services.time_travel_tagger import TimeTravelTagger
                tagger = TimeTravelTagger.get()
                tagger.start(journal)
                self._time_travel_tagger = tagger
                log.info("[MainWindow] Time-Travel Auto-Tagger started")
            except Exception as te:
                log.debug("[MainWindow] Auto-Tagger not started: %s", te)
            # v0.0.20.904: Start SENTINEL diagnostics engine
            try:
                from pydaw.services.sentinel_recorder import SentinelRecorder
                from pydaw.services.sentinel_anomaly import SentinelAnomaly
                from pydaw.services.sentinel_crash_analyzer import SentinelCrashAnalyzer
                ps = getattr(self.services, 'project', None)
                recorder = SentinelRecorder.get()
                recorder.start(project_service=ps)
                self._sentinel_recorder = recorder
                anomaly = SentinelAnomaly.get()
                anomaly.start(recorder=recorder)
                self._sentinel_anomaly = anomaly
                crash_analyzer = SentinelCrashAnalyzer.get()
                crash_analyzer.install(recorder=recorder, session_id=journal.session_id)
                self._sentinel_crash_analyzer = crash_analyzer
                # Status bar heart icon
                try:
                    from pydaw.ui.sentinel_widgets import SentinelStatusWidget
                    heart = SentinelStatusWidget(self)
                    heart.clicked.connect(lambda: self._safe_call(self._toggle_sentinel_dock))
                    self.statusBar().addPermanentWidget(heart)
                    self._sentinel_heart = heart
                    # Update heart color on anomaly
                    anomaly.anomaly_detected.connect(
                        lambda sev, t, d: heart.set_status(
                            "critical" if sev >= 5 else "warning"))
                    anomaly.anomaly_resolved.connect(
                        lambda aid, t: heart.set_status("healthy"))
                except Exception:
                    pass
                log.info("[MainWindow] SENTINEL started (Recorder + Anomaly + Crash)")
                # v0.0.20.905: S8 Pattern Learner
                try:
                    from pydaw.services.sentinel_patterns import SentinelPatternLearner
                    plearner = SentinelPatternLearner.get()
                    plearner.start(recorder=recorder, anomaly_detector=anomaly)
                    self._sentinel_pattern_learner = plearner
                    log.info("[MainWindow] SENTINEL PatternLearner started")
                except Exception as pe:
                    log.debug("[MainWindow] SENTINEL PatternLearner not started: %s", pe)
                # v0.0.20.905: S9 API Server
                try:
                    from pydaw.services.sentinel_api import SentinelAPIServer
                    api_srv = SentinelAPIServer.get()
                    api_srv.start(
                        recorder=recorder, anomaly=anomaly,
                        crash_analyzer=crash_analyzer,
                        pattern_learner=getattr(self, '_sentinel_pattern_learner', None),
                    )
                    self._sentinel_api_server = api_srv
                    log.info("[MainWindow] SENTINEL API Server on %s", api_srv.base_url)
                except Exception as ae:
                    log.debug("[MainWindow] SENTINEL API not started: %s", ae)
                # v0.0.20.905: S10 AI Analyzer
                try:
                    from pydaw.services.sentinel_ai_analyzer import SentinelAIAnalyzer
                    ai = SentinelAIAnalyzer.get()
                    ai.start()
                    ai.load_key_from_keyring()
                    self._sentinel_ai = ai
                    # Register AI callback with API server
                    api_srv_ref = getattr(self, '_sentinel_api_server', None)
                    if api_srv_ref and ai.has_api_key:
                        from pydaw.services.sentinel_api import SentinelAPIHandler
                        SentinelAPIHandler._analyze_callback = ai.analyze_crash
                    log.info("[MainWindow] SENTINEL AI Analyzer ready (key=%s)",
                             "set" if ai.has_api_key else "not set")
                except Exception as aie:
                    log.debug("[MainWindow] SENTINEL AI not started: %s", aie)
            except Exception as se:
                log.debug("[MainWindow] SENTINEL not started: %s", se)
        except Exception as exc:
            log.debug("[MainWindow] Time-Travel Journal not started: %s", exc)

        # v0.0.20.933: Process-level performance optimizations
        try:
            from pydaw.services.perf_service import setup_process_optimizations
            setup_process_optimizations()
        except Exception:
            pass

        # v0.0.20.936: Load persisted video clip properties from SQLite
        try:
            from pydaw.ui.video_clip_properties import ClipVideoProps
            ClipVideoProps.load_all_from_db()
        except Exception:
            pass

        # v0.0.20.936: Load video filter chains from DB
        try:
            from pydaw.services.video_filter_service import VideoFilterService
            from pydaw.services.final_state_db import FinalStateDB
            vfs = VideoFilterService.instance()
            fdb = FinalStateDB.instance()
            if fdb:
                vfs.load_from_db(fdb._conn())
        except Exception:
            pass

    def _time_travel_bookmark(self) -> None:
        """v0.0.20.898: Set a bookmark at the current moment (Ctrl+B)."""
        try:
            journal = getattr(self, '_time_travel_journal', None)
            if journal is None:
                from pydaw.services.time_travel_journal import TimeTravelJournal
                journal = TimeTravelJournal.get()
            if journal.is_running:
                journal.bookmark()
                self.statusBar().showMessage("⭐ Bookmark gesetzt", 2000)
            else:
                self.statusBar().showMessage("Time-Travel Journal nicht aktiv", 2000)
        except Exception:
            pass

    def _maybe_show_first_run(self) -> None:
        """P0D: Zeigt den First-Run-Wizard einmalig beim allerersten Start."""
        try:
            from pydaw.ui.first_run_dialog import maybe_show_first_run
            maybe_show_first_run(parent=self)
        except Exception:
            pass  # Nicht kritisch — DAW startet trotzdem

    def _on_scripting_ui_sync(self, param_name: str, value) -> None:
        """v0.0.20.799: Sync GUI when a script changes project parameters.

        Called from ScriptingService._ProjectProxy when BPM, name,
        time_signature, etc. change. Updates the transport display,
        mixer faders, and arranger so the user sees the effect immediately.
        """
        try:
            if param_name == "bpm":
                # Update transport panel BPM spinbox
                self.transport.set_bpm(float(value))
                self.statusBar().showMessage(f"BPM → {float(value):.0f}", 2000)
            elif param_name == "time_signature":
                # Update time signature display if available
                try:
                    ts_combo = getattr(self.transport, '_time_sig_combo', None)
                    if ts_combo:
                        ts_combo.blockSignals(True)
                        idx = ts_combo.findText(str(value))
                        if idx >= 0:
                            ts_combo.setCurrentIndex(idx)
                        ts_combo.blockSignals(False)
                except Exception:
                    pass
            elif param_name == "name":
                self.setWindowTitle(f"Py_DAW — {value}")

            # Refresh arranger to show any track/clip changes
            try:
                ac = getattr(self, 'arranger_canvas', None)
                if ac:
                    ac.update()
            except Exception:
                pass
            # Refresh mixer for volume/pan/mute/solo changes
            try:
                mx = getattr(self, 'mixer_widget', None) or getattr(self, '_mixer', None)
                if mx and hasattr(mx, 'refresh'):
                    mx.refresh()
                elif mx and hasattr(mx, 'update'):
                    mx.update()
            except Exception:
                pass
        except Exception:
            pass

    def _on_ki_insert_notes(self, notes: list, track_id: str) -> None:
        """MIDI-Noten vom KI-Assistent in einen Track einfügen."""
        try:
            ps = self.services.project
            # Track-ID auflösen: leer → aktuell selektierten Track verwenden
            tid = track_id or self._selected_track_id()
            if not tid:
                tid = ps.ensure_instrument_track()
            # Startposition: Ende des letzten Clips auf diesem Track
            try:
                proj = ps.ctx.project
                clips_on_track = [
                    c for c in proj.clips
                    if c.track_id == tid and c.kind == "midi"
                ]
                if clips_on_track:
                    start_b = max(
                        float(c.start_beats) + float(c.length_beats)
                        for c in clips_on_track
                    )
                else:
                    start_b = 0.0
            except Exception:
                start_b = 0.0
            # Länge aus den Noten berechnen
            try:
                end_b = max(
                    float(n.start_beats) + float(n.length_beats) for n in notes
                )
                length_b = max(1.0, end_b)
            except Exception:
                length_b = 4.0
            # v0.0.20.772: BUGFIX — add_midi_clip_at (nicht add_midi_clip!)
            clip_id = ps.add_midi_clip_at(
                track_id=tid,
                start_beats=start_b,
                length_beats=length_b,
                label="KI Clip",
            )
            if not clip_id:
                self.statusBar().showMessage("KI: Clip konnte nicht erstellt werden", 3000)
                return
            # Noten einfügen
            ps.set_midi_notes(clip_id, notes)
            # Clip auswählen → Piano Roll zeigt die Noten
            ps.select_clip(clip_id)
            # Arranger + Piano Roll explizit refreshen
            try:
                if hasattr(self, 'arranger') and self.arranger:
                    self.arranger.update()
                if hasattr(self, 'editor_tabs'):
                    self.editor_tabs.set_clip(clip_id)
            except Exception:
                pass
            self.statusBar().showMessage(
                f"KI: {len(notes)} Noten eingefügt (Clip '{clip_id[:8]}')", 4000
            )
        except Exception:
            log.error("Unexpected error", exc_info=True)
            self.statusBar().showMessage("KI: Fehler beim Einfügen — siehe Terminal", 4000)

    # --- layout


    # --- layout

    def _build_layout(self) -> None:
        """Pro-DAW-like main layout (Header + Left Tool Strip + Right Browser + Bottom Editor).

        Safety-first: keeps all existing logic/methods. Only rearranges widgets.
        """
        # ---- Multi-Project Tab Bar (Bitwig-Style: tabs at the top)
        try:
            self._project_tab_service = self.services.project_tabs
            self.project_tab_bar = ProjectTabBar(self._project_tab_service, parent=self)
            self.project_tab_bar.setObjectName("projectTabBarWidget")

            # Adopt the current project as Tab 0
            self._project_tab_service.adopt_existing_project(
                self.services.project.ctx,
                self.services.project.undo_stack,
            )

            # Wire tab bar signals
            self.project_tab_bar.request_switch_tab.connect(
                lambda idx: self._safe_call(self._on_project_tab_switch, idx)
            )
            self.project_tab_bar.request_new_project.connect(
                lambda: self._safe_call(self._on_project_tab_new)
            )
            self.project_tab_bar.request_open_project.connect(
                lambda: self._safe_call(self._on_project_tab_open)
            )
            self.project_tab_bar.request_close_tab.connect(
                lambda idx: self._safe_call(self._on_project_tab_close, idx)
            )
            self.project_tab_bar.request_save_tab.connect(
                lambda idx: self._safe_call(self._on_project_tab_save, idx)
            )
            self.project_tab_bar.request_save_tab_as.connect(
                lambda idx: self._safe_call(self._on_project_tab_save_as, idx)
            )
            self.project_tab_bar.request_rename_tab.connect(
                lambda idx, name: self._safe_call(self._project_tab_service.rename_tab, idx, name)
            )
            self.project_tab_bar.request_rust_badge_clicked.connect(
                lambda: self.statusBar().showMessage("Rust Core Badge", 2000)
            )

            # Add as top toolbar
            tab_toolbar = self.addToolBar("Projects")
            tab_toolbar.setObjectName("projectTabToolBar")
            tab_toolbar.setMovable(False)
            tab_toolbar.setFloatable(False)
            try:
                tab_toolbar.setAllowedAreas(Qt.ToolBarArea.TopToolBarArea)
            except Exception:
                pass
            tab_toolbar.addWidget(self.project_tab_bar)
            self._project_tab_toolbar = tab_toolbar

            # v0.0.20.645: Keep project tabs on their own row so transport +
            # tools stay readable even on smaller widths. Without an explicit
            # break, Qt may squeeze all top toolbars into a single line.
            try:
                self.addToolBarBreak(Qt.ToolBarArea.TopToolBarArea)
            except Exception:
                pass
        except Exception:
            log.error("Unexpected error", exc_info=True)
            self._project_tab_service = None
            self.project_tab_bar = None

        # ---- Top Menus + Toolbars (Pro-DAW hybrid)
        # We keep the classic QMenuBar (Datei/Bearbeiten/Ansicht/Projekt/Audio/Hilfe)
        # and add two compact toolbars below it: Transport + Tools/Grid.
        proj = self.services.project.ctx.project

        self.transport = TransportPanel()
        self.transport.setObjectName("transportPanel")

        # initialize transport UI from project
        try:
            self.transport.bpm.setValue(int(round(float(getattr(proj, "bpm", 120.0) or 120.0))))
        except Exception:
            pass
        ts = getattr(proj, "time_signature", "4/4") or "4/4"
        try:
            self.transport.set_time_signature(str(ts))
        except Exception:
            pass

        snap = getattr(proj, "snap_division", "1/16") or "1/16"

        # Transport row (like your reference screenshot)
        self.transport_toolbar = self.addToolBar("Transport")
        self.transport_toolbar.setObjectName("transportToolBar")
        self.transport_toolbar.setMovable(False)
        self.transport_toolbar.setFloatable(False)
        try:
            self.transport_toolbar.setAllowedAreas(Qt.ToolBarArea.TopToolBarArea)
        except Exception:
            pass
        self.transport_toolbar.addWidget(self.transport)

        # Tools/Grid row
        self.toolbar_panel = ToolBarPanel()
        self.toolbar_panel.setObjectName("toolBarPanel")
        try:
            # ensure snap exists in the combo
            items = [self.toolbar_panel.cmb_grid.itemText(i) for i in range(self.toolbar_panel.cmb_grid.count())]
            if str(snap) not in items:
                snap = "1/16"
            self.toolbar_panel.cmb_grid.setCurrentText(str(snap))
        except Exception:
            pass

        self.tools_toolbar = self.addToolBar("Tools")
        self.tools_toolbar.setObjectName("toolsToolBar")
        self.tools_toolbar.setMovable(False)
        self.tools_toolbar.setFloatable(False)
        try:
            self.tools_toolbar.setAllowedAreas(Qt.ToolBarArea.TopToolBarArea)
        except Exception:
            pass
        self.tools_toolbar.addWidget(self.toolbar_panel)

        # ---- Central area: Left tool strip + Arranger
        center = QWidget()
        center.setObjectName("chronoCenter")
        cl = QHBoxLayout(center)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(0)

        # Left tool strip (Pro-DAW-Style)
        tool_strip = QWidget()
        tool_strip.setObjectName("chronoToolStrip")
        tl = QVBoxLayout(tool_strip)
        tl.setContentsMargins(6, 6, 6, 6)
        tl.setSpacing(6)

        def _mk_tool(txt: str, tool_key: str, tip: str):
            b = QToolButton()
            b.setText(txt)
            b.setToolTip(tip)
            b.setObjectName("chronoToolButton")
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setAutoRaise(True)
            b.setFixedSize(34, 34)
            b.clicked.connect(lambda _=False: self._on_tool_changed_from_toolbar(tool_key))
            return b

        tl.addWidget(_mk_tool("↖", "select", "Zeiger (Select)"))
        tl.addWidget(_mk_tool("✎", "draw", "Stift (Draw)"))
        tl.addWidget(_mk_tool("⌫", "erase", "Radiergummi (Erase)"))
        tl.addWidget(_mk_tool("✂", "knife", "Messer (Knife)"))
        tl.addStretch(1)
        tool_strip.setFixedWidth(48)

        self.arranger = ArrangerView(self.services.project)
        # Inject transport into arranger canvas for DAW-consistent loop behavior
        try:
            self.arranger.canvas.set_transport(self.services.transport)
            try:
                # v0.0.20.86: wire tab_service through ArrangerView → canvas + TrackList
                self.arranger.set_tab_service(getattr(self, '_project_tab_service', None))
            except Exception:
                pass
            try:
                # v0.0.20.608: wire MidiManager for MIDI input routing dropdown
                self.arranger.set_midi_manager(getattr(self.services, 'midi', None))
            except Exception:
                pass
            try:
                self.arranger.set_transport(self.services.transport)
            except Exception:
                pass
        except Exception:
            pass

        # Prewarm: let the service know which arranger range is currently visible
        try:
            self.arranger.view_range_changed.connect(self.services.prewarm.set_active_range)
            # seed initial range
            a, b = self.arranger.visible_range_beats()
            self.services.prewarm.set_active_range(a, b)
        except Exception:
            pass

        # automation panel lives inside arranger view
        self.automation = self.arranger.automation
        # v0.0.20.89: Wire AutomationManager for enhanced Bezier automation editor
        try:
            self.arranger.set_automation_manager(self.services.automation_manager)
        except Exception:
            pass
        try:
            self.arranger.set_snap_division(str(snap))
        except Exception:
            pass
        self.arranger.set_automation_visible(False)

        # Arranger wiring
        # NOTE: PyQt6 can abort the process on uncaught exceptions in slots.
        # Always use _safe_call wrappers for user-triggered interactions.
        self.arranger.clip_activated.connect(lambda cid: self._safe_call(self._on_clip_activated, cid))
        self.arranger.clip_selected.connect(lambda cid: self._safe_call(self._on_clip_selected, cid))
        self.arranger.request_rename_clip.connect(lambda cid: self._safe_call(self._rename_clip_dialog, cid))
        self.arranger.request_duplicate_clip.connect(lambda cid: self._safe_call(self.services.project.duplicate_clip, cid))
        self.arranger.request_delete_clip.connect(lambda cid: self._safe_call(self.services.project.delete_clip, cid))
        self.arranger.status_message.connect(lambda msg: self._safe_call(self._set_status, msg))

        # loop edits in arranger drive transport
        self.arranger.canvas.loop_region_committed.connect(
            lambda enabled, start, end: self._safe_call(self._on_arranger_loop_committed, enabled, start, end)
        )
        # v0.0.20.637: Punch region edits in arranger drive transport
        self.arranger.canvas.punch_region_committed.connect(
            lambda enabled, in_b, out_b: self._safe_call(self._on_arranger_punch_committed, enabled, in_b, out_b)
        )
        self.arranger.canvas.request_import_audio.connect(lambda pos: self._safe_call(self._import_audio_at_position, pos))
        self.arranger.canvas.request_add_track.connect(lambda kind: self._safe_call(self._add_track_from_context_menu, kind))
        self.arranger.canvas.request_smartdrop_new_instrument_track.connect(
            lambda payload: self._safe_call(self._on_arranger_smartdrop_new_instrument_track, payload)
        )
        self.arranger.canvas.request_smartdrop_instrument_to_track.connect(
            lambda track_id, payload: self._safe_call(self._on_arranger_smartdrop_instrument_to_track, track_id, payload)
        )
        self.arranger.canvas.request_smartdrop_fx_to_track.connect(
            lambda track_id, payload: self._safe_call(self._on_arranger_smartdrop_fx_to_track, track_id, payload)
        )
        self.arranger.canvas.request_smartdrop_instrument_morph_guard.connect(
            lambda track_id, payload: self._safe_call(self._on_arranger_smartdrop_instrument_morph_guard, track_id, payload)
        )
        self.arranger.tracks.request_smartdrop_instrument_to_track.connect(
            lambda track_id, payload: self._safe_call(self._on_arranger_smartdrop_instrument_to_track, track_id, payload)
        )
        self.arranger.tracks.request_smartdrop_fx_to_track.connect(
            lambda track_id, payload: self._safe_call(self._on_arranger_smartdrop_fx_to_track, track_id, payload)
        )
        self.arranger.tracks.request_smartdrop_instrument_morph_guard.connect(
            lambda track_id, payload: self._safe_call(self._on_arranger_smartdrop_instrument_morph_guard, track_id, payload)
        )

        # Synchronize automation editor time range with Arranger scroll/zoom
        self.arranger.view_range_changed.connect(self.automation.set_view_range)
        # v0.0.20.89: Also sync enhanced automation editor
        try:
            eap = getattr(self.arranger, '_enhanced_automation', None)
            if eap is not None:
                self.arranger.view_range_changed.connect(eap.set_view_range)
        except Exception:
            pass
        try:
            s, e = self.arranger.visible_range_beats()
            self.automation.set_view_range(s, e)
        except Exception:
            pass

        # Track selection drives parameter inspector
        self.arranger.tracks.selected_track_changed.connect(lambda tid: self._safe_call(self._on_track_selected, tid))
        # Phase 2: Track-Header ▾ requests (Routing/Arm/Monitor/Add Device) — UI-only, additiv
        try:
            self.arranger.tracks.request_open_browser_tab.connect(
                lambda tid, tab: self._safe_call(self._on_track_header_open_browser, tid, tab)
            )
            self.arranger.tracks.request_show_device_panel.connect(
                lambda tid: self._safe_call(self._on_track_header_show_device, tid)
            )
            # Phase 3: 1-click device insert directly from Track-Header ▾
            self.arranger.tracks.request_add_device.connect(
                lambda tid, kind, pid: self._safe_call(self._on_track_header_add_device, tid, kind, pid)
            )
        except Exception:
            pass

        cl.addWidget(tool_strip, 0)
        cl.addWidget(self.arranger, 1)
        self.setCentralWidget(center)

        # ---- Right Browser Dock (toggle with 'B')
        from .device_browser import DeviceBrowser
        self.library = DeviceBrowser(
                on_add_instrument=lambda pid: self._safe_call(self._add_instrument_to_device, pid),
                get_add_scope=lambda kind="": self._safe_call(self._browser_add_scope_info, kind) or ("Ziel: Spur", "Aktive Spur konnte nicht ermittelt werden."),
                # NOTE: callbacks accept optional (name, params) so external plugins can be inserted
                # as *placeholders* without touching hosting/audio engine.
                on_add_note_fx=lambda pid, name="", params=None: self._safe_call(
                    self.device_panel.add_note_fx_to_track, self._selected_track_id(), pid, name=name, params=params
                ),
                on_add_audio_fx=lambda pid, name="", params=None: self._safe_call(
                    self.device_panel.add_audio_fx_to_track, self._selected_track_id(), pid, name=name, params=params
                ),
                audio_engine=self.services.audio_engine,
                transport=self.services.transport,
                project_service=self.services.project,
            )

        # Browser Sample Drag → Arranger Overlay Clip-Launcher (v0.0.19.7.39)
        try:
            sb = getattr(self.library, 'samples_tab', None)
            if sb is not None:
                sb.audio_drag_started.connect(lambda lbl: self._safe_call(self._on_sample_drag_started, lbl))
                sb.audio_drag_ended.connect(lambda: self._safe_call(self._on_sample_drag_ended))
        except Exception:
            pass

        # Overlay drop → Import AudioClip + assign to Launcher slot (v0.0.19.7.39)
        try:
            self.arranger.request_import_audio_file.connect(
                lambda file_path, track_id, start_beats, slot_key: self._safe_call(
                    self._import_audio_file_to_slot, file_path, track_id, start_beats, slot_key
                )
            )
        except Exception:
            pass
        self.track_params = TrackParametersPanel(project=self.services.project)

        right_tabs = QTabWidget()
        right_tabs.addTab(self.library, "Browser")
        right_tabs.addTab(self.track_params, "Parameter")
        # Phase 2/3: keep a handle so Track-Header ▾ can switch Browser tabs safely
        self._right_tabs = right_tabs

        # Project Browser (Ableton-style: peek into closed projects)
        try:
            self._project_browser = ProjectBrowserWidget(
                tab_service=self._project_tab_service,
                parent=right_tabs,
            )
            right_tabs.addTab(self._project_browser, "Projekte")
            # Wire signals
            self._project_browser.request_open_in_tab.connect(
                lambda path_str: self._safe_call(self._on_project_browser_open, path_str)
            )
            self._project_browser.request_import_tracks.connect(
                lambda path_str, tids: self._safe_call(self._on_project_browser_import, path_str, tids)
            )
            self._project_browser.status_message.connect(
                lambda msg: self._set_status(msg)
            )
        except Exception:
            log.error("Unexpected error", exc_info=True)
            self._project_browser = None
        right_tabs.setObjectName("chronoBrowserTabs")

        # Allow the right dock to be resized "almost closed".
        # We must neutralize minimum-size constraints coming from the tab bar and
        # internal widgets; otherwise the dock separator stops too early.
        try:
            from PyQt6.QtWidgets import QSizePolicy
            right_tabs.setMinimumWidth(0)
            right_tabs.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
            tb = right_tabs.tabBar()
            tb.setUsesScrollButtons(True)
            tb.setExpanding(False)
            try:
                tb.setElideMode(Qt.TextElideMode.ElideRight)
            except Exception:
                pass
            tb.setMinimumWidth(0)
            tb.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        except Exception:
            pass

        self.browser_dock = QDockWidget("Browser", self)
        self.browser_dock.setObjectName("chronoBrowserDock")
        self.browser_dock.setWidget(right_tabs)
        self.browser_dock.setAllowedAreas(Qt.DockWidgetArea.RightDockWidgetArea)
        # Allow shrinking the Browser panel almost closed (user requested).
        # Any minimum constraints here will stop the dock separator early.
        try:
            from PyQt6.QtWidgets import QSizePolicy
            right_tabs.setMinimumSize(0, 0)
            self.library.setMinimumSize(0, 0)
            self.track_params.setMinimumSize(0, 0)
            self.browser_dock.setMinimumSize(0, 0)
            self.browser_dock.setMinimumWidth(0)
            self.browser_dock.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        except Exception:
            pass
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.browser_dock)

        # v0.0.20.747 P2A — KI-Kompositions-Assistent Dock
        try:
            from pydaw.ui.ki_assistant_panel import KiAssistantPanel
            self._ki_panel = KiAssistantPanel(services=self.services, parent=self)
            self._ki_dock = QDockWidget("🤖 KI-Assistent", self)
            self._ki_dock.setObjectName("chronoKiAssistantDock")
            self._ki_dock.setWidget(self._ki_panel)
            self._ki_dock.setAllowedAreas(
                Qt.DockWidgetArea.RightDockWidgetArea | Qt.DockWidgetArea.LeftDockWidgetArea
            )
            self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self._ki_dock)
            self.tabifyDockWidget(self.browser_dock, self._ki_dock)
            self._ki_dock.hide()  # Standardmäßig ausgeblendet
            # Signal-Verbindungen
            self._ki_panel.insert_notes_requested.connect(
                lambda notes, tid: self._safe_call(self._on_ki_insert_notes, notes, tid)
            )
            self._ki_panel.status_message.connect(
                lambda m: self.statusBar().showMessage(m, 3000)
            )
        except Exception as _ki_exc:
            logging.getLogger(__name__).warning("KI-Panel init fehler: %s", _ki_exc)
            self._ki_panel = None
            self._ki_dock = None

        # v0.0.20.798 P5A — Collaboration Dock (Git, Collab, Review)
        try:
            from pydaw.ui.collab_panel import CollabPanel
            self._collab_panel = CollabPanel(parent=self, project_service=self.services.project)
            # Wire services
            git_svc = getattr(self.services, 'git', None)
            review_svc = getattr(self.services, 'review', None)
            self._collab_panel.set_services(
                git_service=git_svc,
                review_service=review_svc,
                collab_server=getattr(self.services, 'collab_server', None),
                collab_client=getattr(self.services, 'collab_client', None),
            )
            self._collab_dock = QDockWidget("🤝 Kollaboration", self)
            self._collab_dock.setObjectName("chronoCollabDock")
            self._collab_dock.setWidget(self._collab_panel)
            self._collab_dock.setAllowedAreas(
                Qt.DockWidgetArea.RightDockWidgetArea | Qt.DockWidgetArea.LeftDockWidgetArea
            )
            self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self._collab_dock)
            self.tabifyDockWidget(self.browser_dock, self._collab_dock)
            self._collab_dock.hide()  # Standardmäßig ausgeblendet
            self._collab_panel.status_message.connect(
                lambda m, t=3000: self.statusBar().showMessage(m, t)
            )
            # v0.0.20.858: Wire arranger canvas for cursor sharing
            try:
                if hasattr(self, 'arranger') and self.arranger:
                    canvas = getattr(self.arranger, 'canvas', None)
                    if canvas:
                        self._collab_panel.set_arranger_canvas(canvas)
                        canvas.cursor_moved.connect(
                            lambda beat, tid: self._collab_panel.send_local_cursor(beat, tid)
                        )
            except Exception:
                pass
            # v0.0.20.859: Wire transport for play/stop/bpm/loop sync
            try:
                transport = getattr(self.services, 'transport', None)
                if transport:
                    self._collab_panel.set_transport(transport)
            except Exception:
                pass
            # v0.0.20.881: Wire Preset Universe → Collab preset sync
            try:
                if hasattr(self, 'library') and self.library:
                    pt = getattr(self.library, 'presets_tab', None)
                    if pt and hasattr(pt, 'preset_load_requested'):
                        pt.preset_load_requested.connect(
                            self._collab_panel.send_preset_sync
                        )
            except Exception:
                pass
        except Exception as _collab_exc:
            logging.getLogger(__name__).warning("Collab-Panel init fehler: %s", _collab_exc)
            self._collab_panel = None
            self._collab_dock = None

        # v0.0.20.798 P6A — Python Scripting Console Dock
        try:
            from pydaw.ui.scripting_panel import ScriptingPanel
            scripting_svc = getattr(self.services, 'scripting', None)
            self._scripting_panel = ScriptingPanel(parent=self, scripting_service=scripting_svc)
            self._scripting_dock = QDockWidget("🐍 Python Console", self)
            self._scripting_dock.setObjectName("chronoScriptingDock")
            self._scripting_dock.setWidget(self._scripting_panel)
            self._scripting_dock.setAllowedAreas(
                Qt.DockWidgetArea.BottomDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea
            )
            self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self._scripting_dock)
            self._scripting_dock.hide()  # Standardmäßig ausgeblendet
            self._scripting_panel.status_message.connect(
                lambda m, t=3000: self.statusBar().showMessage(m, t)
            )
            # v0.0.20.799: Wire UI sync callback so script changes
            # (BPM, name, etc.) update the transport display + arranger
            if scripting_svc:
                scripting_svc.set_on_ui_sync(self._on_scripting_ui_sync)
        except Exception as _script_exc:
            logging.getLogger(__name__).warning("Scripting-Panel init fehler: %s", _script_exc)
            self._scripting_panel = None
            self._scripting_dock = None

        self._shortcut_toggle_browser = QShortcut(QKeySequence("B"), self)
        self._shortcut_toggle_browser.activated.connect(lambda: self._safe_call(self._toggle_browser))

        # v0.0.20.757: I = Input-Monitoring toggle (Pro-DAW standard: Logic/Cubase)
        self._shortcut_monitor = QShortcut(QKeySequence("I"), self)
        self._shortcut_monitor.activated.connect(lambda: self._safe_call(self._toggle_input_monitor))

        # v0.0.20.98: Global Space shortcut for Play/Pause (DAW standard!)
        self._shortcut_space_play = QShortcut(QKeySequence("Space"), self)
        self._shortcut_space_play.activated.connect(lambda: self._safe_call(self._on_play_clicked))

        # v0.0.20.898: Time-Travel Bookmark (Ctrl+B)
        self._shortcut_bookmark = QShortcut(QKeySequence("Ctrl+B"), self)
        self._shortcut_bookmark.activated.connect(lambda: self._safe_call(self._time_travel_bookmark))

        # Metadata for Hilfe → Arbeitsmappe (Shortcuts-Liste)
        try:
            self._shortcut_toggle_browser.setObjectName("shortcut_toggle_browser")
            self._shortcut_toggle_browser.setProperty("pydaw_desc", "Browser Panel ein/aus")
        except Exception:
            pass

        # ---- Bottom Editor Dock (Piano Roll / Notation)
        self.editor_tabs = EditorTabs(
            self.services.project,
            transport=self.services.transport,
            editor_timeline=getattr(self.services, 'editor_timeline', None),  # v0.0.20.613
            status_cb=lambda t, ms=1500: self.statusBar().showMessage(str(t), int(ms)),
            enable_notation_tab=bool(get_value(SettingsKeys.ui_enable_notation_tab, False)),
        )
        self.editor_dock = QDockWidget("Editor", self)
        self.editor_dock.setObjectName("chronoEditorDock")
        self.editor_dock.setWidget(self.editor_tabs)

        # Backwards-compatibility: older code expects separate docks.
        # We now host editors in a single dock with tabs.
        self.pianoroll_dock = self.editor_dock
        self.notation_dock = self.editor_dock
        self.editor_dock.setAllowedAreas(Qt.DockWidgetArea.BottomDockWidgetArea)
        self.editor_dock.setMinimumHeight(150)  # v0.0.20.618: prevent full collapse
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.editor_dock)

        # Mixer as tab next to editor (Pro-DAW-like)
        _rt = getattr(self.services.audio_engine, "rt_params", None)
        _hb = getattr(self.services.audio_engine, "_hybrid_bridge", None)
        if _hb is None:
            _hb = getattr(self.services.audio_engine, "hybrid_bridge", None)
        self.mixer = MixerPanel(self.services.project, self.services.audio_engine, rt_params=_rt, hybrid_bridge=_hb)
        # v0.0.20.408: Wire audio engine to MIDI mapping for RT param access
        try:
            self.services.midi_mapping.set_audio_engine(self.services.audio_engine)
        except Exception:
            pass
        self.mixer_dock = QDockWidget("Mixer", self)
        self.mixer_dock.setObjectName("chronoMixerDock")
        self.mixer_dock.setWidget(self.mixer)
        self.mixer_dock.setAllowedAreas(Qt.DockWidgetArea.BottomDockWidgetArea)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.mixer_dock)
        self.tabifyDockWidget(self.editor_dock, self.mixer_dock)
        self.mixer_dock.hide()  # start like Pro-DAW: editor visible

        # ---- Bottom Device Dock (Pro-DAW-like) – placeholder
        self.device_panel = DevicePanel(self.services)
        self.device_dock = QDockWidget("Device", self)
        self.device_dock.setObjectName("chronoDeviceDock")
        self.device_dock.setWidget(self.device_panel)
        self.device_dock.setAllowedAreas(Qt.DockWidgetArea.BottomDockWidgetArea)
        self.device_dock.setMinimumHeight(0)  # v0.0.20.597: allow full collapse
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.device_dock)
        try:
            self.tabifyDockWidget(self.editor_dock, self.device_dock)
        except Exception:
            pass
        self.device_dock.hide()  # start hidden; becomes visible in "Device" view

        # v0.0.20.884: Wire Preset Universe → DevicePanel (apply preset params)
        try:
            pt = getattr(self.library, 'presets_tab', None) if hasattr(self, 'library') else None
            if pt and hasattr(pt, 'preset_load_requested') and hasattr(self.device_panel, 'apply_universe_preset'):
                pt.preset_load_requested.connect(self.device_panel.apply_universe_preset)
                logging.getLogger(__name__).info("[PRESET-WIRE] preset_load_requested → apply_universe_preset CONNECTED")
            else:
                logging.getLogger(__name__).warning("[PRESET-WIRE] FAILED: pt=%s, has_signal=%s, has_apply=%s",
                    bool(pt), hasattr(pt, 'preset_load_requested') if pt else False,
                    hasattr(self.device_panel, 'apply_universe_preset'))
        except Exception:
            pass

        # ---- Bottom view tabs (Pro-Style): ARRANGE / MIX / EDIT
        # These tabs control which bottom dock is visible and give the Arranger full height in ARRANGE mode.
        self._build_bottom_view_tabs(initial_snap=str(snap))
        self._set_view_mode("arrange", force=True)


        # Keep editors in sync with the currently active clip.
        try:
            self.services.project.active_clip_changed.connect(self.editor_tabs.set_clip)
        except Exception:
            pass

        # Clip Launcher Dock (optional) – tabify with Browser
        self.launcher_panel = ClipLauncherPanel(
            self.services.project,
            self.services.launcher,
            self.services.clip_context  # NEU: ClipContextService
        )
        self.launcher_panel.clip_activated.connect(lambda cid: self._safe_call(self._on_clip_activated, cid))
        self.launcher_panel.clip_edit_requested.connect(lambda cid: self._safe_call(self._on_clip_edit_requested, cid))

        self.launcher_dock = QDockWidget("Clip Launcher", self)
        self.launcher_dock.setWidget(self.launcher_panel)
        self.launcher_dock.setAllowedAreas(Qt.DockWidgetArea.RightDockWidgetArea)
        # Important: the Browser dock is tabified with this launcher dock.
        # Any minimum width here will limit how far the right dock area can be collapsed.
        try:
            from PyQt6.QtWidgets import QSizePolicy
            self.launcher_panel.setMinimumSize(0, 0)
            self.launcher_dock.setMinimumSize(0, 0)
            self.launcher_dock.setMinimumWidth(0)
            self.launcher_dock.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        except Exception:
            pass
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.launcher_dock)
        try:
            self.tabifyDockWidget(self.browser_dock, self.launcher_dock)
        except Exception:
            pass
        self.launcher_dock.hide()

        # TransportService -> UI
        self.services.transport.playhead_changed.connect(lambda beat: self._safe_call(self._update_playhead, beat))
        self.services.transport.loop_changed.connect(
            lambda enabled, start, end: self._safe_call(self._on_transport_loop_changed, enabled, start, end)
        )
        self.services.transport.time_signature_changed.connect(lambda ts: self._safe_call(self._on_transport_ts_changed, ts))
        self.services.transport.metronome_tick.connect(lambda: self._safe_call(self._on_metronome_tick))

        # v0.0.20.637: Punch In/Out (AP2 Phase 2C)
        self.services.transport.punch_changed.connect(
            lambda enabled, in_b, out_b: self._safe_call(self._on_transport_punch_changed, enabled, in_b, out_b)
        )
        self.services.transport.punch_triggered.connect(
            lambda boundary: self._safe_call(self._on_punch_triggered, boundary)
        )

        # v0.0.20.639: Loop-Recording / Take-Lanes (AP2 Phase 2D)
        self.services.transport.loop_boundary_reached.connect(
            lambda: self._safe_call(self._on_loop_boundary_reached)
        )

        # v0.0.20.639: Wire TakeService into arranger canvas
        try:
            self.arranger.canvas._take_service = getattr(self.services, 'take', None)
        except Exception:
            pass

        # Initialize TS into transport service
        try:
            self.services.transport.set_time_signature(str(ts))
        except Exception:
            pass

        # loop state into UI + arranger
        self._on_transport_loop_changed(
            self.services.transport.loop_enabled,
            self.services.transport.loop_start,
            self.services.transport.loop_end,
        )
        # v0.0.20.637: punch state into UI + arranger
        self._on_transport_punch_changed(
            self.services.transport.punch_enabled,
            self.services.transport.punch_in_beat,
            self.services.transport.punch_out_beat,
        )
        self._update_playhead(self.services.transport.current_beat)

        # Apply Pro-DAW-like dark theme
        self._apply_chrono_theme()

        # --- Screen Layout Manager (Bitwig-Style multi-monitor, v0.0.20.444) ---
        try:
            self._init_screen_layout_manager()
        except Exception:
            log.error("Unexpected error", exc_info=True)
            self._screen_layout_mgr = None


    def _build_bottom_view_tabs(self, initial_snap: str = "1/16") -> None:
        """Create bottom navigation tabs wie Pro-DAW: Arranger / Mixer / Editor / Device.

        We keep this lightweight: it only toggles which bottom docks are visible.
        """
        sb = self.statusBar()
        try:
            sb.setSizeGripEnabled(False)
        except Exception:
            pass

        nav = QWidget()
        nav.setObjectName("chronoBottomNav")
        hl = QHBoxLayout(nav)
        # v0.0.20.651: the tech badges moved to the right status strip, so the
        # left navigation can breathe with a small but calm inset.
        hl.setContentsMargins(6, 4, 6, 4)
        hl.setSpacing(0)

        def mk_tab(text: str) -> QToolButton:
            b = QToolButton()
            b.setText(text)
            b.setCheckable(True)
            b.setAutoRaise(True)
            b.setObjectName("chronoViewTab")
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            return b

        # View tabs (Pro-Style) – labels are user-facing.
        self.btn_view_arrange = mk_tab("Arranger")
        self.btn_view_mix = mk_tab("Mixer")
        self.btn_view_edit = mk_tab("Editor")
        self.btn_view_device = mk_tab("Device")

        self.btn_view_arrange.clicked.connect(lambda _=False: self._set_view_mode("arrange"))
        self.btn_view_mix.clicked.connect(lambda _=False: self._set_view_mode("mix"))
        self.btn_view_edit.clicked.connect(lambda _=False: self._set_view_mode("edit"))
        self.btn_view_device.clicked.connect(lambda _=False: self._set_view_mode("device"))

        hl.addWidget(self.btn_view_arrange)
        hl.addWidget(self.btn_view_mix)
        hl.addWidget(self.btn_view_edit)
        hl.addWidget(self.btn_view_device)

        # Left aligned nav
        try:
            sb.addWidget(nav, 1)
        except Exception:
            sb.addWidget(nav)

        # Snap indicator on the right
        self.lbl_snap = QLabel(str(initial_snap))
        self.lbl_snap.setObjectName("chronoSnapLabel")
        try:
            sb.addPermanentWidget(self.lbl_snap)
        except Exception:
            sb.addWidget(self.lbl_snap)

        # v0.0.20.651: group Qt/Python/Rust together as a compact tech signature
        # near the performance indicators, instead of scattering logos over the UI.
        self._build_status_tech_signature()

    def _set_view_mode(self, mode: str, force: bool = False) -> None:
        mode = (mode or "").strip().lower()
        if not force and getattr(self, "_view_mode", None) == mode:
            return
        self._view_mode = mode

        # Default: show arranger always
        try:
            self.arranger.setVisible(True)
        except Exception:
            pass

        if mode == "mix":
            try:
                self.editor_dock.hide()
            except Exception:
                pass
            try:
                self.device_dock.hide()
            except Exception:
                pass
            try:
                self.mixer_dock.show()
                self.mixer_dock.raise_()
            except Exception:
                pass
        elif mode == "edit":
            try:
                self.mixer_dock.hide()
            except Exception:
                pass
            try:
                self.device_dock.hide()
            except Exception:
                pass
            try:
                self.editor_dock.show()
                self.editor_dock.raise_()
            except Exception:
                pass
        elif mode == "device":
            try:
                self.mixer_dock.hide()
            except Exception:
                pass
            try:
                self.editor_dock.hide()
            except Exception:
                pass
            try:
                self.device_dock.show()
                self.device_dock.raise_()
            except Exception:
                pass
        else:  # arrange
            try:
                self.editor_dock.hide()
            except Exception:
                pass
            try:
                self.mixer_dock.hide()
            except Exception:
                pass
            try:
                self.device_dock.hide()
            except Exception:
                pass

        # Update tab checked states without recursion
        for btn, name in [
            (getattr(self, "btn_view_arrange", None), "arrange"),
            (getattr(self, "btn_view_mix", None), "mix"),
            (getattr(self, "btn_view_edit", None), "edit"),
            (getattr(self, "btn_view_device", None), "device"),
        ]:
            if btn is None:
                continue
            try:
                btn.blockSignals(True)
                btn.setChecked(mode == name)
                btn.blockSignals(False)
            except Exception:
                pass

        try:
            self.statusBar().showMessage(f"View: {mode}", 900)
        except Exception:
            pass

    def _add_instrument_to_device(self, plugin_id: str) -> None:
        """Add an instrument plugin to the selected track's device chain."""
        track_id = self._selected_track_id()
        if not track_id:
            try:
                self.statusBar().showMessage("Bitte zuerst einen Instrument-Track auswählen.", 3000)
            except Exception:
                pass
            return

        # v0.0.20.361: Actually wire through to device_panel (was missing!)
        ok = False
        try:
            ok = bool(self.device_panel.add_instrument_to_track(str(track_id), str(plugin_id)))
        except Exception:
            ok = False

        if ok:
            try:
                self.device_panel.show_track(str(track_id))
            except Exception:
                pass
            try:
                self._set_view_mode("device", force=True)
            except Exception:
                pass
            try:
                self._set_status(f"Instrument hinzugefügt: {plugin_id}", 2000)
            except Exception:
                pass

    # ── SmartDrop methods: see main_window_smartdrop.py (SmartDropMixin) ──

    # --- Phase 2/3: Track-Header ▾ helpers (UI-only) ---

    def _on_track_header_open_browser(self, track_id: str, tab_key: str) -> None:
        """Open the Browser dock and select a tab (instruments/effects/samples)."""
        try:
            self.browser_dock.setVisible(True)
        except Exception:
            pass

        # Ensure Browser tab is active in the right dock
        try:
            rt = getattr(self, "_right_tabs", None)
            if rt is not None:
                rt.setCurrentIndex(0)
        except Exception:
            pass

        # Switch inside DeviceBrowser
        try:
            idx = {"samples": 0, "instruments": 1, "effects": 2}.get(str(tab_key).lower(), 0)
            self.library.tabs.setCurrentIndex(int(idx))
        except Exception:
            pass

        try:
            self._set_status(f"Browser: {tab_key}", 1200)
        except Exception:
            pass


    def _on_track_header_show_device(self, track_id: str) -> None:
        """Show the Device panel and bind it to the given track."""
        try:
            self.device_panel.show_track(str(track_id))
        except Exception:
            pass
        try:
            self._set_view_mode("device", force=True)
        except Exception:
            pass


    def _on_track_header_add_device(self, track_id: str, kind: str, plugin_id: str) -> None:
        """Insert a device directly to the given track (1-click)."""
        tid = str(track_id)
        k = str(kind).lower()
        pid = str(plugin_id)
        ok = False
        try:
            if k in ("instrument", "instr"):
                ok = bool(self.device_panel.add_instrument_to_track(tid, pid))
            elif k in ("note_fx", "notefx", "note"):
                ok = bool(self.device_panel.add_note_fx_to_track(tid, pid))
            elif k in ("audio_fx", "audiofx", "fx"):
                ok = bool(self.device_panel.add_audio_fx_to_track(tid, pid))
        except Exception:
            ok = False

        if ok:
            try:
                self.device_panel.show_track(tid)
            except Exception:
                pass
            try:
                self._set_view_mode("device", force=True)
            except Exception:
                pass
            try:
                self._set_status(f"Added {k}: {pid}", 1800)
            except Exception:
                pass
            return
        try:
            ok = bool(self.device_panel.add_instrument_to_track(track_id, plugin_id))
        except Exception:
            ok = False
        if ok:
            try:
                self._set_view_mode("device", force=True)
            except Exception:
                pass
            # v0.0.20.42: Register new sampler in global registry for MIDI routing
            try:
                from pydaw.plugins.sampler.sampler_registry import get_sampler_registry
                registry = get_sampler_registry()
                if not registry.has_sampler(track_id):
                    devices = self.device_panel.get_track_devices(track_id)
                    for dev in devices:
                        engine = getattr(dev, "engine", None)
                        if engine is not None and hasattr(engine, "trigger_note"):
                            registry.register(track_id, engine, dev)
                            
                            # v0.0.20.46: Set plugin_type on track for Pro-DAW-Style routing
                            try:
                                track = self.services.project.ctx.project.tracks_by_id().get(track_id)
                                if track:
                                    # Detect plugin type from plugin_id
                                    if "sampler" in str(plugin_id).lower():
                                        track.plugin_type = "sampler"
                                    elif "drum" in str(plugin_id).lower():
                                        track.plugin_type = "drum_machine"
                                    self.services.project.mark_dirty()
                            except Exception:
                                pass
                            
                            break
            except Exception:
                pass


    def _toggle_browser(self) -> None:
        try:
            vis = bool(self.browser_dock.isVisible())
            self.browser_dock.setVisible(not vis)
        except Exception:
            pass

    def _apply_chrono_theme(self) -> None:
        """Minimal dark QSS — see chrono_theme_css.py for the full stylesheet."""
        from .chrono_theme_css import CHRONO_THEME_CSS
        self.setStyleSheet(CHRONO_THEME_CSS)


    def _fit_to_screen(self) -> None:

        """Resize and center the window to fit the active desktop."""
        screen = self.screen() or QGuiApplication.primaryScreen()
        if not screen:
            return
        geo = screen.availableGeometry()
        if geo.width() <= 0 or geo.height() <= 0:
            return

        # Use a conservative default size that still leaves room for panels.
        target_w = int(geo.width() * 0.92)
        target_h = int(geo.height() * 0.9)
        self.resize(max(900, min(target_w, geo.width())), max(600, min(target_h, geo.height())))
        # v0.0.20.597: Allow user to resize the window freely (small minimum)
        self.setMinimumSize(400, 300)

        # v0.0.20.606: Set right dock to ~30% width (compact Clip Launcher)
        try:
            right_w = max(200, int(target_w * 0.28))
            self.resizeDocks([self.browser_dock], [right_w], Qt.Orientation.Horizontal)
        except Exception:
            pass

        # Center on screen
        frame = self.frameGeometry()
        frame.moveCenter(geo.center())
        self.move(frame.topLeft())

    def _wire_actions(self) -> None:
        # File
        self.actions.file_new.triggered.connect(lambda _=False: self._safe_call(self._new_project))
        self.actions.file_open.triggered.connect(lambda _=False: self._safe_call(self._open_project))
        self.actions.file_save.triggered.connect(lambda _=False: self._safe_call(self._save_project))
        self.actions.file_save_as.triggered.connect(lambda _=False: self._safe_call(self._save_project_as))
        self.actions.file_import_audio.triggered.connect(lambda _=False: self._safe_call(self._import_audio))
        self.actions.file_import_midi.triggered.connect(lambda _=False: self._safe_call(self._import_midi))
        self.actions.file_import_dawproject.triggered.connect(lambda _=False: self._safe_call(self._import_dawproject))
        self.actions.file_export_dawproject.triggered.connect(lambda _=False: self._safe_call(self._export_dawproject))
        self.actions.file_export.triggered.connect(lambda _=False: self._safe_call(self._export_audio_placeholder))
        self.actions.file_export_midi_clip.triggered.connect(lambda _=False: self._safe_call(self._export_midi_clip))  # FIXED v0.0.19.7.15
        self.actions.file_export_midi_track.triggered.connect(lambda _=False: self._safe_call(self._export_midi_track))  # FIXED v0.0.19.7.15
        self.actions.file_exit.triggered.connect(lambda _=False: self._safe_call(self.close))

        # View
        self.actions.view_dummy.triggered.connect(lambda _=False: self._safe_call(self.statusBar().showMessage, "Ansicht (Platzhalter)", 2000))
        self.actions.view_toggle_pianoroll.toggled.connect(lambda checked: self._safe_call(self._toggle_pianoroll, checked))
        self.actions.view_toggle_notation.toggled.connect(lambda checked: self._safe_call(self._toggle_notation, checked))
        self.actions.view_toggle_cliplauncher.toggled.connect(lambda checked: self._safe_call(self._toggle_cliplauncher, checked))
        self.actions.view_toggle_drop_overlay.toggled.connect(lambda checked: self._safe_call(self._toggle_drop_overlay, checked))
        self.actions.view_toggle_gpu_waveforms.toggled.connect(lambda checked: self._safe_call(self._toggle_gpu_waveforms, checked))
        self.actions.view_toggle_cpu_meter.toggled.connect(lambda checked: self._safe_call(self._toggle_cpu_meter, checked))
        # v0.0.20.696: Rust Engine toggle
        self.actions.audio_toggle_rust_engine.toggled.connect(lambda checked: self._safe_call(self._toggle_rust_engine, checked))
        # v0.0.20.701: Plugin Sandbox toggle
        self.actions.audio_toggle_plugin_sandbox.toggled.connect(lambda checked: self._safe_call(self._toggle_plugin_sandbox, checked))
        self.actions.view_toggle_automation.toggled.connect(lambda checked: self._safe_call(self._toggle_automation, checked))

        # Edit (Undo/Redo)
        self.actions.edit_undo.triggered.connect(lambda _=False: self._safe_call(self.services.project.undo))
        self.actions.edit_redo.triggered.connect(lambda _=False: self._safe_call(self.services.project.redo))
        self.actions.edit_cut.triggered.connect(lambda _=False: self._safe_call(self._dispatch_edit, 'cut'))
        self.actions.edit_copy.triggered.connect(lambda _=False: self._safe_call(self._dispatch_edit, 'copy'))
        self.actions.edit_paste.triggered.connect(lambda _=False: self._safe_call(self._dispatch_edit, 'paste'))
        self.actions.edit_select_all.triggered.connect(lambda _=False: self._safe_call(self._dispatch_edit, 'select_all'))

        # Project / tracks
        self.actions.project_add_audio_track.triggered.connect(lambda _=False: self._safe_project_call('add_track', 'audio'))
        self.actions.project_add_instrument_track.triggered.connect(lambda _=False: self._safe_project_call('add_track', 'instrument'))
        self.actions.project_add_bus_track.triggered.connect(lambda _=False: self._safe_project_call('add_track', 'bus'))
        self.actions.project_add_placeholder_clip.triggered.connect(lambda _=False: self._safe_call(self._add_clip_to_selected_track))
        self.actions.project_remove_selected_track.triggered.connect(lambda _=False: self._safe_call(self._remove_selected_track))
        self.actions.project_time_signature.triggered.connect(lambda _=False: self._safe_call(self._show_time_signature))
        self.actions.project_settings.triggered.connect(lambda _=False: self._safe_call(self._show_project_settings))
        self.actions.project_save_snapshot.triggered.connect(lambda _=False: self._safe_call(self._save_snapshot))
        self.actions.project_load_snapshot.triggered.connect(lambda _=False: self._safe_call(self._load_snapshot))

        # Audio + MIDI dialogs
        self.actions.audio_settings.triggered.connect(lambda _=False: self._safe_call(self._show_audio_settings))
        self.actions.audio_prerender_midi.triggered.connect(lambda _=False: self._safe_call(self._start_midi_prerender, show_dialog=True))
        self.actions.audio_prerender_selected_clip.triggered.connect(lambda _=False: self._safe_call(self._on_prerender_selected_clips))
        self.actions.audio_prerender_selected_track.triggered.connect(lambda _=False: self._safe_call(self._on_prerender_selected_track))
        self.actions.midi_settings.triggered.connect(lambda _=False: self._safe_call(self._show_midi_settings))
        self.actions.midi_mapping.triggered.connect(lambda _=False: self._safe_call(self._show_midi_mapping))
        self.actions.midi_panic.triggered.connect(lambda _=False: self._safe_call(self.services.midi.panic_all, 'user'))

        # Help
        self.actions.help_workbook.triggered.connect(lambda _=False: self._safe_call(self._show_workbook))
        self.actions.help_toggle_python_animation.toggled.connect(lambda checked: self._safe_call(self._on_python_logo_animation_toggled, checked))

        # Transport panel
        self.transport.bpm_changed.connect(lambda bpm: self._safe_call(self._on_bpm_changed_from_ui, bpm))
        self.transport.play_clicked.connect(lambda: self._safe_call(self._on_play_clicked))
        self.transport.stop_clicked.connect(lambda: self._safe_call(self._on_stop_clicked))
        self.transport.rew_clicked.connect(lambda: self._safe_call(self.services.transport.rewind))
        self.transport.ff_clicked.connect(lambda: self._safe_call(self.services.transport.fast_forward))
        self.transport.record_clicked.connect(lambda checked: self._safe_call(self._on_record_toggled, checked))
        self.transport.loop_toggled.connect(lambda enabled: self._safe_call(self.services.transport.set_loop, enabled))
        self.transport.time_signature_changed.connect(lambda ts: self._safe_call(self._on_ts_changed_from_ui, ts))

        self.transport.metronome_toggled.connect(lambda enabled: self._safe_call(self._on_metronome_enabled, enabled))
        self.transport.count_in_changed.connect(lambda v: self._safe_call(self._on_count_in_changed, v))

        # v0.0.20.637: Punch In/Out (AP2 Phase 2C)
        self.transport.punch_toggled.connect(lambda enabled: self._safe_call(self._on_punch_toggled_from_ui, enabled))
        self.transport.pre_roll_changed.connect(lambda v: self._safe_call(self._on_pre_roll_changed, v))
        self.transport.post_roll_changed.connect(lambda v: self._safe_call(self._on_post_roll_changed, v))

        # v0.0.20.757: Input-Monitoring
        try:
            self.transport.monitor_toggled.connect(
                lambda v: self._safe_call(self._on_monitor_toggled, v)
            )
        except Exception:
            pass

        # Grid/Tools (toolbar row + optional left strip)
        try:
            if hasattr(self, "toolbar_panel") and self.toolbar_panel is not None:
                self.toolbar_panel.grid_changed.connect(self._on_grid_changed_from_ui)
                self.toolbar_panel.tool_changed.connect(self._on_tool_changed_from_toolbar)
                self.toolbar_panel.automation_toggled.connect(self._toggle_automation)
        except Exception:
            pass

        # v0.0.20.438: Wire Follow Playhead toggle
        try:
            if hasattr(self, "toolbar_panel") and self.toolbar_panel is not None:
                self.toolbar_panel.follow_changed.connect(self._on_follow_changed)
        except Exception:
            pass

        # v0.0.20.438: Wire Loop fields ↔ Transport
        try:
            if hasattr(self, "toolbar_panel") and self.toolbar_panel is not None:
                self.toolbar_panel.loop_changed.connect(self._on_toolbar_loop_changed)
        except Exception:
            pass

        # Live MIDI edits while playing: restart arrangement playback so the
        # rendered MIDI->WAV cache is refreshed without requiring manual stop/play.
        self._recording_active = False
        self._recording_track_id = None
        self._recording_start_beat = 0.0
        self._recording_wav_path = None

        self._midi_refresh_timer = QTimer(self)
        self._midi_refresh_timer.setSingleShot(True)
        self._midi_refresh_timer.timeout.connect(self._restart_playback_if_playing)
        try:
            self.services.project.midi_notes_committed.connect(self._on_midi_notes_committed)
        except Exception:
            pass

        # FIXED v0.0.19.7.2: Sync BPM and Time Signature when project loads!
        try:
            self.services.project.project_opened.connect(self._on_project_opened)
        except Exception:
            pass

        # Project open/lifecycle: optionally start pre-render so playback is snappy.
        try:
            self.services.project.project_opened.connect(self._maybe_autoprerender_after_load)
        except Exception:
            pass

        # Pre-render progress hooks (used by Ready-for-Bach progress dialog)
        self._prerender_dialog = None
        self._play_after_prerender = False
        try:
            self.services.project.prerender_label.connect(self._on_prerender_label)
            self.services.project.prerender_progress.connect(self._on_prerender_progress)
            self.services.project.prerender_finished.connect(self._on_prerender_finished)
        except Exception:
            pass


    def _update_undo_redo_actions(self) -> None:
        try:
            can_undo = bool(self.services.project.can_undo())
            can_redo = bool(self.services.project.can_redo())
            ulab = self.services.project.undo_label()
            rlab = self.services.project.redo_label()
        except Exception:
            can_undo = False
            can_redo = False
            ulab = ""
            rlab = ""

        self.actions.edit_undo.setEnabled(can_undo)
        self.actions.edit_redo.setEnabled(can_redo)

        # Pro-DAW-like: show operation name in menu
        self.actions.edit_undo.setText("Rückgängig" + (f" ({ulab})" if ulab else ""))
        self.actions.edit_redo.setText("Wiederholen" + (f" ({rlab})" if rlab else ""))


    def _on_grid_changed_from_ui(self, div: str) -> None:
        self.services.project.set_snap_division(div)
        self.arranger.set_snap_division(div)
        self.statusBar().showMessage(f"Grid/Snap gesetzt: {div}", 1500)

        try:
            if hasattr(self, "lbl_snap") and self.lbl_snap is not None:
                self.lbl_snap.setText(str(div))
        except Exception:
            pass


    def _on_tool_changed_from_toolbar(self, tool: str) -> None:
        """Propagate tool change to Arranger + Editor (Piano Roll).

        Tools:
        - select, draw, erase, knife, time_select
        PianoRoll expects: select, pen, erase, knife, time
        """
        tool = (tool or "").strip()

        # Arranger
        try:
            if hasattr(self.arranger, "canvas"):
                self.arranger.canvas.set_tool(str(tool))
        except Exception:
            pass

        # PianoRoll (best effort)
        try:
            et = getattr(self, "editor_tabs", None)
            pr = getattr(et, "pianoroll", None) if et is not None else None
            canvas = getattr(pr, "canvas", None) if pr is not None else None
            if canvas is not None:
                mapping = {
                    "select": "select",
                    "draw": "pen",
                    "erase": "erase",
                    "knife": "knife",
                    "time_select": "time",
                }
                canvas.set_tool_mode(mapping.get(tool, tool))
        except Exception:
            pass

        try:
            self.statusBar().showMessage(f"Tool: {tool}", 900)
        except Exception:
            pass

    def _on_play_clicked(self) -> None:
        """Play button handler.

        If MIDI pre-render is enabled, we optionally build cache..."""
        try:
            if bool(self.services.transport.playing):
                self.services.transport.toggle_play()
                return
        except Exception:
            pass

        # Not currently playing: optional MIDI pre-render gate (performance mode)
        try:
            keys = SettingsKeys()
            wait = self._setting_bool(keys.prerender_wait_before_play, True)
            show = self._setting_bool(keys.prerender_show_progress_on_play, True)
        except Exception:
            wait = True
            show = True

        if wait:
            started = False
            try:
                started = self._start_midi_prerender(show_dialog=show, play_after=True)
            except Exception:
                started = False
            if started:
                return

        try:
            self.services.transport.toggle_play()
        except Exception:
            pass

    def _on_stop_clicked(self) -> None:
        """DAW-style stop: first press stops, second press resets to 0."""
        try:
            if bool(self.services.transport.playing):
                self.services.transport.stop()
                # Fail-safe: Audio-Engine immer hart stoppen (sounddevice *und* JACK).
                # Hintergrund: In manchen Versionen ist die Transport->Audio-Bindung
                # nicht vollständig, oder JACK-Playback läuft ohne Engine-Thread.
                try:
                    self.services.audio_engine.stop()
                except Exception:
                    pass
            else:
                self.services.transport.reset()
        except Exception:
            # Fallback: stop only
            try:
                self.services.transport.stop()
            except Exception:
                pass

        # Zweiter Fail-safe: falls noch JACK-Render aktiv ist, sicher entfernen.
        try:
            if hasattr(self.services, "jack"):
                self.services.jack.clear_render_callback()
        except Exception:
            pass

    def _on_midi_notes_committed(self, clip_id: str) -> None:
        """When MIDI edits are committed, refresh playback while playing."""
        try:
            if bool(self.services.transport.playing):
                # Debounce to avoid restart storms during rapid edits.
                self._midi_refresh_timer.start(200)  # v0.0.20.775: 200ms debounce (was 80ms)
        except Exception:
            pass

    def _restart_playback_if_playing(self) -> None:
        """v0.0.20.775: Hot-swap arrangement state instead of full restart.

        Previously this called start_arrangement_playback() which killed the
        audio stream (2-3 second gap). Now we atomically swap the arrangement
        state in the running callback — zero audio interruption.
        """
        try:
            if bool(self.services.transport.playing):
                ae = self.services.audio_engine
                # Try hot-swap first (glitch-free)
                if hasattr(ae, 'hot_swap_arrangement') and ae.hot_swap_arrangement():
                    return
                # Fallback: full restart (legacy, causes gap)
                ae.start_arrangement_playback()
        except Exception:
            pass

    # --- performance / pre-render

    def _setting_bool(self, key: str, default: bool) -> bool:
        """Read a bool-like value from SettingsStore."""
        try:
            v = str(get_value(key, "1" if default else "0")).strip().lower()
            return v in ("1", "true", "yes", "on")
        except Exception:
            return bool(default)

    def _on_project_opened(self) -> None:
        """Sync BPM and Time Signature from loaded project to Transport Service.
        
        FIXED v0.0.19.7.2: Loop Bug Fix!
        
        PROBLEM:
        - Project saved at 181 BPM
        - On load: Transport still at 120 BPM (DEFAULT!)
        - Loop at Bar 6: 
          - At 181 BPM = 7.95 seconds
          - At 120 BPM = 7.95 seconds = Bar 4! ❌
        
        SOLUTION:
        - Load BPM from project FIRST
        - Then loop calculations are correct! ✅
        """
        try:
            project = self.services.project.ctx.project
            
            # Set BPM from loaded project
            bpm = float(getattr(project, "bpm", 120.0))
            self.services.transport.set_bpm(bpm)
            log.debug(f"[MainWindow._on_project_opened] Set BPM to {bpm} from project")
            
            # Set Time Signature from loaded project
            ts = str(getattr(project, "time_signature", "4/4"))
            self.services.transport.set_time_signature(ts)
            log.debug(f"[MainWindow._on_project_opened] Set Time Signature to {ts} from project")
            
            # Update Transport Bar UI
            self.transport.set_bpm(bpm)
            self.transport.set_time_signature(ts)
            
        except Exception as e:
            log.debug(f"[MainWindow._on_project_opened] Error syncing BPM/TS: {e}")
            log.error("Unexpected error", exc_info=True)

        # v0.0.20.896: Restore Arranger/PianoRoll UI state from SQLite
        self._restore_ui_state_from_db()

    def _restore_ui_state_from_db(self) -> None:
        """v0.0.20.896: Restore arranger/pianoroll zoom/scroll from FinalStateDB."""
        try:
            pp = str(getattr(self.services.project.ctx, 'path', '') or '')
            if not pp:
                return
            from pydaw.services.final_state_db import FinalStateDB
            fdb = FinalStateDB.get()
            fdb.ensure_loaded()

            # Arranger state
            a_state = fdb.get_arranger_state(pp)
            if a_state:
                canvas = getattr(self, 'arranger', None)
                canvas = getattr(canvas, 'canvas', canvas)
                if canvas is not None:
                    ppb = a_state.get("pixels_per_beat")
                    if ppb and float(ppb) > 0:
                        canvas.pixels_per_beat = float(ppb)
                    th = a_state.get("track_height")
                    if th and int(th) > 0:
                        canvas.track_height = int(th)
                    try:
                        canvas.update()
                    except Exception:
                        pass

            # PianoRoll state
            pr_state = fdb.get_pianoroll_state(pp)
            if pr_state:
                editor = getattr(self, 'editor_tabs', None)
                pr_canvas = getattr(editor, '_piano_roll_canvas', None) if editor else None
                if pr_canvas is not None:
                    ppb = pr_state.get("pixels_per_beat")
                    if ppb and float(ppb) > 0:
                        pr_canvas.pixels_per_beat = float(ppb)
                    try:
                        pr_canvas.update()
                    except Exception:
                        pass
        except Exception:
            pass

    def _save_ui_state_to_db(self) -> None:
        """v0.0.20.896: Save arranger/pianoroll zoom/scroll to FinalStateDB."""
        try:
            pp = str(getattr(self.services.project.ctx, 'path', '') or '')
            if not pp:
                return
            from pydaw.services.final_state_db import FinalStateDB
            fdb = FinalStateDB.get()
            fdb.ensure_loaded()

            # Arranger state
            canvas = getattr(self, 'arranger', None)
            canvas = getattr(canvas, 'canvas', canvas)
            if canvas is not None:
                fdb.save_arranger_state(
                    pp,
                    pixels_per_beat=float(getattr(canvas, 'pixels_per_beat', 80.0)),
                    track_height=int(getattr(canvas, 'track_height', 70)),
                )

            # PianoRoll state
            editor = getattr(self, 'editor_tabs', None)
            pr_canvas = getattr(editor, '_piano_roll_canvas', None) if editor else None
            if pr_canvas is not None:
                fdb.save_pianoroll_state(
                    pp,
                    pixels_per_beat=float(getattr(pr_canvas, 'pixels_per_beat', 90.0)),
                )
        except Exception:
            pass

    def _maybe_autoprerender_after_load(self) -> None:
        """Optionally start background pre-render after project/stand load."""
        try:
            keys = SettingsKeys()
            if not self._setting_bool(keys.prerender_auto_on_load, True):
                return
            show = self._setting_bool(keys.prerender_show_progress_on_load, False)
        except Exception:
            show = False
        try:
            self._start_midi_prerender(show_dialog=show, play_after=False)
        except Exception:
            pass

    def _on_prerender_selected_clips(self) -> None:
        """Pre-render only the currently selected MIDI clips (Arranger selection)."""
        clip_ids = []
        try:
            clip_ids = list(getattr(self.arranger.canvas, "selected_clip_ids", set()) or [])
        except Exception:
            clip_ids = []

        if not clip_ids:
            try:
                self.statusBar().showMessage("Pre-Render: keine Clips ausgewählt.", 2000)
            except Exception:
                pass
            return

        self._start_midi_prerender(show_dialog=True, play_after=False, clip_ids=clip_ids)

    def _on_prerender_selected_track(self) -> None:
        """Pre-render only the currently selected track (all its MIDI clips)."""
        try:
            tid = str(getattr(self.services.project, "selected_track_id", "") or "")
        except Exception:
            tid = ""

        if not tid:
            try:
                self.statusBar().showMessage("Pre-Render: kein Track ausgewählt.", 2000)
            except Exception:
                pass
            return

        self._start_midi_prerender(show_dialog=True, play_after=False, track_id=tid)

    def _start_midi_prerender(
        self,
        show_dialog: bool = False,
        play_after: bool = False,
        clip_ids: list[str] | None = None,
        track_id: str | None = None,
    ) -> bool:
        """Start background MIDI->WAV pre-render.

        Returns True if a job was started.
        """
        ps = self.services.project
        try:
            # Avoid duplicate runs
            if bool(getattr(ps, "_prerender_running", False)):
                if show_dialog:
                    self.statusBar().showMessage("Pre-Render läuft bereits…", 1500)
                return True
        except Exception:
            pass

        try:
            total = int(ps.midi_prerender_job_count(clip_ids=clip_ids, track_id=track_id))
        except Exception:
            total = 0

        if total <= 0:
            if show_dialog:
                self.statusBar().showMessage("Pre-Render: keine MIDI-Clips zum Rendern.", 2000)
            return False

        if play_after:
            self._play_after_prerender = True

        if show_dialog and self._prerender_dialog is None:
            try:
                from PyQt6.QtWidgets import QProgressDialog
                scope = "alle MIDI-Clips"
                if clip_ids:
                    scope = f"{len(clip_ids)} Clip(s)"
                elif track_id:
                    scope = "ausgewählter Track"
                dlg = QProgressDialog(f"MIDI Pre-Render: {scope}…", "Abbrechen", 0, 100, self)
                dlg.setWindowTitle("Ready for Bach")
                dlg.setMinimumDuration(0)
                dlg.setAutoClose(True)
                dlg.setAutoReset(True)
                dlg.setValue(0)
                try:
                    dlg.canceled.connect(ps.cancel_prerender)
                except Exception:
                    pass
                dlg.show()
                self._prerender_dialog = dlg
            except Exception:
                self._prerender_dialog = None

        try:
            ps.prerender_midi_clips(clip_ids=clip_ids, track_id=track_id)
            return True
        except Exception as e:
            if show_dialog:
                self.statusBar().showMessage(f"Pre-Render Start fehlgeschlagen: {e}", 4000)
            return False

    def _on_prerender_label(self, text: str) -> None:
        try:
            if self._prerender_dialog is not None:
                self._prerender_dialog.setLabelText(str(text))
                return
        except Exception:
            pass
        try:
            self.statusBar().showMessage(str(text), 1500)
        except Exception:
            pass

    def _on_prerender_progress(self, percent: int) -> None:
        try:
            if self._prerender_dialog is not None:
                self._prerender_dialog.setValue(int(percent))
        except Exception:
            pass

    def _on_prerender_finished(self, ok: bool) -> None:
        try:
            if self._prerender_dialog is not None:
                try:
                    self._prerender_dialog.setValue(100)
                except Exception:
                    pass
                try:
                    self._prerender_dialog.close()
                except Exception:
                    pass
                self._prerender_dialog = None
        except Exception:
            self._prerender_dialog = None

        if ok:
            try:
                self.statusBar().showMessage("Pre-Render fertig.", 2000)
            except Exception:
                pass
        else:
            try:
                self.statusBar().showMessage("Pre-Render abgebrochen/fehlgeschlagen.", 3000)
            except Exception:
                pass

        if bool(self._play_after_prerender):
            self._play_after_prerender = False
            try:
                self.services.transport.toggle_play()
            except Exception:
                pass

    # --- dialogs

    def _show_midi_settings(self) -> None:
        dlg = MidiSettingsDialog(self.services.midi, self)
        dlg.exec()

    def _show_midi_mapping(self) -> None:
        try:
            dlg = MidiMappingDialog(self.services.project, self.services.midi_mapping, parent=self)
            dlg.exec()
        except Exception as e:
            try:
                self.statusBar().showMessage(f"MIDI-Mapping konnte nicht geöffnet werden: {e}", 4000)
            except Exception:
                pass

    def _show_time_signature(self) -> None:
        cur = getattr(self.services.project.ctx.project, "time_signature", "4/4")
        dlg = TimeSignatureDialog(current=cur, parent=self)
        if dlg.exec() == dlg.DialogCode.Accepted:
            self._on_ts_changed_from_ui(dlg.value())

    def _show_project_settings(self) -> None:
        proj = self.services.project.ctx.project
        dlg = ProjectSettingsDialog(
            bpm=float(getattr(proj, "bpm", 120.0)),
            time_signature=str(getattr(proj, "time_signature", "4/4")),
            snap_division=str(getattr(proj, "snap_division", "1/16")),
            parent=self,
        )
        if dlg.exec() == dlg.DialogCode.Accepted:
            bpm, ts, grid = dlg.values()
            self.transport.bpm.setValue(int(round(bpm)))
            self._on_ts_changed_from_ui(ts)
            try:
                self.toolbar_panel.cmb_grid.blockSignals(True)
                self.toolbar_panel.cmb_grid.setCurrentText(grid)
            finally:
                self.toolbar_panel.cmb_grid.blockSignals(False)
            self._on_grid_changed_from_ui(grid)
            self.statusBar().showMessage("Project Settings angewendet.", 2000)

    def _restart_app(self, via_pw_jack: bool = False) -> None:
        """Startet PyDAW neu (bei JACK/PipeWire Wechseln nötig).

        Unter PipeWire ist JACK oftmals nur mit `pw-jack` erreichbar.
        """
        # Wichtig: Restart muss das aktuelle Terminal behalten (stdout/stderr),
        # damit Debug-Ausgaben sichtbar bleiben. Daher kein subprocess.Popen()+quit,
        # sondern Prozess-Ersetzung via exec.
        main_script = os.path.abspath(sys.argv[0] or "main.py")
        argv = [sys.executable, main_script] + sys.argv[1:]
        env = os.environ.copy()
        # Unbuffered, damit Logs nicht verschwinden.
        env.setdefault("PYTHONUNBUFFERED", "1")
        if via_pw_jack:
            env["PYDAW_PWJACK"] = "1"

        # Aktuelles Projekt nach Restart wieder öffnen.
        try:
            cur = getattr(self.services.project.ctx, "path", None)
            if cur:
                env["PYDAW_REOPEN_PROJECT"] = str(cur)
        except Exception:
            pass

        def _do_exec() -> None:
            try:
                try:
                    import sys as _sys
                    _sys.stdout.flush()
                    _sys.stderr.flush()
                except Exception:
                    pass
                if via_pw_jack:
                    os.execvpe("pw-jack", ["pw-jack"] + argv, env)
                else:
                    os.execvpe(sys.executable, argv, env)
            except Exception as e:
                self.statusBar().showMessage(f"Neustart fehlgeschlagen: {e}", 8000)

        # Kurz in die Eventloop zurück, damit Dialog/Statusbar noch zeichnen kann.
        QTimer.singleShot(50, _do_exec)

    def _show_workbook(self) -> None:
        """Open TEAM workbook dialog (Help -> Arbeitsmappe)."""
        try:
            from .workbook_dialog import WorkbookDialog
            dlg = WorkbookDialog(parent=self)
            dlg.exec()
        except Exception as e:
            try:
                self._show_error(f"Arbeitsmappe konnte nicht geöffnet werden: {e}")
            except Exception:
                pass

    def _show_project_compare_dialog(self) -> None:
        """Open Project Compare dialog (Projekt -> Projekt vergleichen…)."""
        try:
            svc = getattr(self.services, "project_tabs", None)
            if svc is None:
                self.statusBar().showMessage("Project Tabs Service nicht verfügbar.", 4000)
                return
            from .project_compare_dialog import ProjectCompareDialog

            dlg = ProjectCompareDialog(tab_service=svc, parent=self)
            dlg.show()
            dlg.raise_()
            dlg.activateWindow()
        except Exception as e:
            try:
                self._show_error(f"Projekt vergleichen konnte nicht geöffnet werden: {e}")
            except Exception:
                pass

    def _init_python_logo_animation(self) -> None:
        """Initialize Python logo button animation state from persistent settings."""
        try:
            raw = get_value(SettingsKeys.ui_python_logo_animation_enabled, default="1")
            enabled = str(raw).strip().lower() not in ("0", "false", "no", "off", "")
        except Exception:
            enabled = True

        # Update menu check state without re-entering handler.
        try:
            self.actions.help_toggle_python_animation.blockSignals(True)
            self.actions.help_toggle_python_animation.setChecked(enabled)
        finally:
            try:
                self.actions.help_toggle_python_animation.blockSignals(False)
            except Exception:
                pass

        # Apply to toolbar
        self._apply_python_logo_animation_state(enabled)

    def _on_python_logo_animation_toggled(self, checked: bool) -> None:
        self._apply_python_logo_animation_state(bool(checked))
        try:
            set_value(SettingsKeys.ui_python_logo_animation_enabled, "1" if checked else "0")
        except Exception:
            pass

    def _apply_python_logo_animation_state(self, enabled: bool) -> None:
        try:
            if hasattr(self, "toolbar_panel") and self.toolbar_panel is not None:
                self.toolbar_panel.set_python_logo_animation_enabled(enabled)
        except Exception:
            pass

    def _show_audio_settings(self) -> None:
        dlg = AudioSettingsDialog(self.services.audio_engine, jack=self.services.jack, parent=self)
        if dlg.exec() == dlg.DialogCode.Accepted:
            if getattr(dlg, "restart_requested", False):
                via_pw = bool(getattr(dlg, "restart_via_pw_jack", False))
                self.statusBar().showMessage("Audio-Einstellungen: Neustart wird durchgeführt...", 2000)
                self._restart_app(via_pw_jack=via_pw)
                return
            self.statusBar().showMessage("Audio-Einstellungen gespeichert.", 2000)

    def _add_track_from_context_menu(self, track_kind: str) -> None:
        """FIXED v0.0.19.7.19: Add track from arranger context menu.
        
        Args:
            track_kind: "audio", "instrument", or "bus"
        """
        self._safe_project_call('add_track', track_kind)
        self.statusBar().showMessage(f"{track_kind.capitalize()} Track hinzugefügt", 2000)

    def _selected_track_id(self) -> str:
        try:
            return self.arranger.tracks.selected_track_id()
        except Exception:
            return ""

    def _browser_add_scope_info(self, kind: str = ""):
        try:
            dp = getattr(self, "device_panel", None)
            if dp is not None and hasattr(dp, "browser_add_scope"):
                return dp.browser_add_scope(kind)
        except Exception:
            pass
        return ("Ziel: Spur", "Aktive Spur konnte nicht sicher ermittelt werden.")

    def _on_track_selected(self, track_id: str) -> None:
        try:
            self.services.project._selected_track_id = str(track_id or "")
        except Exception:
            pass
        # Drive the parameter inspector.
        try:
            self.track_params.set_track(self.services.project, track_id)
        except Exception:
            pass

        # Switch device panel to selected track (Pro-DAW-Style per-track binding)
        try:
            self.device_panel.show_track(track_id)
        except Exception:
            pass

        try:
            self.library.set_selected_track(track_id)
        except Exception:
            pass

        # v0.0.20.747: KI-Panel Kontext aktualisieren
        try:
            ki = getattr(self, "_ki_panel", None)
            if ki is not None:
                trk = next(
                    (t for t in self.services.project.ctx.project.tracks if t.id == track_id),
                    None,
                )
                name = getattr(trk, "name", track_id) if trk else track_id
                ki.set_selected_track_name(str(name or ""))
                # v0.0.20.752: Ersten MIDI-Clip des Tracks automatisch als aktiven Clip setzen
                try:
                    clips = self.services.project.ctx.project.clips
                    track_clips = [c for c in clips
                                   if str(getattr(c, "track_id", "")) == str(track_id)
                                   and str(getattr(c, "kind", "")) == "midi"]
                    if track_clips:
                        # Clip mit den meisten Noten bevorzugen
                        best = max(track_clips,
                                   key=lambda c: len(self.services.project.ctx.project
                                                      .midi_notes.get(str(c.id), []) or []),
                                   default=track_clips[0])
                        self.services.project._active_clip_id = str(best.id)
                    elif not self.services.project._active_clip_id:
                        # Audio-Clip als Fallback
                        any_clip = next(
                            (c for c in clips if str(getattr(c, "track_id", "")) == str(track_id)),
                            None
                        )
                        if any_clip:
                            self.services.project._active_clip_id = str(any_clip.id)
                except Exception:
                    pass
                ki.refresh_context()
        except Exception:
            pass

        # v0.0.20.42: Instrument tracks start EMPTY (Ableton/Pro-DAW behavior).
        # The user adds instruments explicitly via Browser → Instruments → 'Add to Device'.
        # We still register existing samplers in the global registry for note routing.
        try:
            trk = next(
                (t for t in self.services.project.ctx.project.tracks if t.id == track_id),
                None,
            )
            if trk and getattr(trk, "kind", "") == "instrument":
                # Register sampler in global registry for unified note routing
                try:
                    from pydaw.plugins.sampler.sampler_registry import get_sampler_registry
                    registry = get_sampler_registry()
                    if not registry.has_sampler(track_id):
                        devices = self.device_panel.get_track_devices(track_id)
                        for dev in devices:
                            engine = getattr(dev, "engine", None)
                            if engine is not None and hasattr(engine, "trigger_note"):
                                registry.register(track_id, engine, dev)
                                break
                except Exception:
                    pass
        except Exception:
            pass

    def _remove_selected_track(self) -> None:
        tid = self._selected_track_id()
        if not tid:
            return
        # Unregister from sampler registry before deleting
        try:
            if self._sampler_registry:
                self._sampler_registry.unregister(tid)
        except Exception:
            pass
        self.services.project.remove_track(tid)

    def _on_note_preview_routed(self, pitch: int, velocity: int,
                                 duration_ms: int) -> None:
        """Route note_preview to the selected track's sampler via registry.
        v0.0.20.43: Ensures preview output is active after triggering.
        """
        try:
            tid = self._selected_track_id() or ""
            triggered = False
            if tid and self._sampler_registry:
                if self._sampler_registry.trigger_note(tid, pitch, velocity,
                                                        duration_ms):
                    triggered = True
            # Fallback: broadcast to all registered samplers
            if not triggered and self._sampler_registry:
                for t in self._sampler_registry.all_track_ids():
                    if self._sampler_registry.trigger_note(t, pitch, velocity,
                                                             duration_ms):
                        triggered = True
                        break
            # v0.0.20.43: Ensure audio engine output is active for preview
            if triggered:
                try:
                    self.services.audio_engine.ensure_preview_output()
                except Exception:
                    pass
        except Exception:
            pass

    def _on_midi_panic(self, _reason: str = "") -> None:
        """Stop all sampler voices and clear stuck notes."""
        try:
            if getattr(self, "_sampler_registry", None):
                self._sampler_registry.all_notes_off()
        except Exception:
            pass


    def _on_live_note_on_route_to_sampler(self, clip_id: str, track_id: str, pitch: int,
                                         velocity: int, channel: int, start_beats: float) -> None:
        """Route live MIDI key-down to sampler registry AND VST instruments (sustained).

        v0.0.20.398: Also routes to VST2/VST3 instrument engines.
        """
        try:
            if getattr(self, "_sampler_registry", None):
                ok = bool(self._sampler_registry.note_on(str(track_id), int(pitch), int(velocity)))
                if not ok:
                    # Try VST instrument engines
                    ok = self._route_live_note_to_vst(track_id, pitch, velocity, is_on=True)
                if not ok:
                    import time
                    now = time.time()
                    last = float(getattr(self, "_last_no_sample_warn_ts", 0.0) or 0.0)
                    if (now - last) > 1.25:
                        self._last_no_sample_warn_ts = now
                        try:
                            self.statusBar().showMessage(
                                "Kein Sound: Im Device-Tab den Sampler öffnen und ein Sample laden (oder Audio-Backend prüfen).",
                                3000,
                            )
                        except Exception:
                            pass
            else:
                # No sampler registry — try VST instruments directly
                self._route_live_note_to_vst(track_id, pitch, velocity, is_on=True)
        except Exception:
            pass

    def _on_live_note_off_route_to_sampler(self, clip_id: str, track_id: str, pitch: int, channel: int) -> None:
        """Route live MIDI key-up to sampler registry AND VST instruments (release).

        v0.0.20.398: Also routes to VST2/VST3 instrument engines.
        """
        try:
            if getattr(self, "_sampler_registry", None):
                self._sampler_registry.note_off(str(track_id), pitch=int(pitch))
            # Always also try VST instruments
            self._route_live_note_to_vst(track_id, pitch, 0, is_on=False)
        except Exception:
            pass

    def _route_live_note_to_vst(self, track_id: str, pitch: int, velocity: int, is_on: bool) -> bool:
        """Route live MIDI to VST2/VST3 instrument engines.

        v0.0.20.398: Enables live keyboard → VST instrument sound.
        Returns True if an engine was found and the note was sent.
        """
        try:
            ae = getattr(self.services, "audio_engine", None)
            if ae is None:
                return False
            engines = getattr(ae, "_vst_instrument_engines", None)
            if not isinstance(engines, dict):
                return False
            engine = engines.get(str(track_id))
            if engine is None:
                return False
            # v0.0.20.557: Skip layer dispatchers — SamplerRegistry handles them
            if getattr(engine, "_is_layer_dispatcher", False):
                return False
            if is_on:
                engine.note_on(int(pitch), int(velocity))
            else:
                engine.note_off(int(pitch))
            return True
        except Exception:
            return False


    def _add_clip_to_selected_track(self) -> None:
        tid = self._selected_track_id()
        if not tid:
            return
        trk = next((t for t in self.services.project.ctx.project.tracks if t.id == tid), None)
        kind = "midi" if (trk and trk.kind == "instrument") else "audio"
        before = [c.id for c in self.services.project.ctx.project.clips]
        self.services.project.add_placeholder_clip_to_track(tid, kind=kind)
        after = [c.id for c in self.services.project.ctx.project.clips]
        new_ids = [x for x in after if x not in before]
        if kind == "midi" and new_ids:
            self._safe_call(self._on_clip_activated, new_ids[-1])

    # --- Arranger selection + context actions

    def _on_clip_selected(self, clip_id: str) -> None:
        self._safe_project_call('select_clip', clip_id or "")
        try:
            clip = next((c for c in (self.services.project.ctx.project.clips or []) if str(getattr(c, "id", "") or "") == str(clip_id or "")), None)
            track_id = str(getattr(clip, "track_id", "") or "") if clip is not None else ""
            if track_id and hasattr(self.arranger, 'tracks') and hasattr(self.arranger.tracks, 'select_track'):
                self.arranger.tracks.select_track(track_id)
        except Exception:
            pass

    def _rename_clip_dialog(self, clip_id: str) -> None:
        clip = next((c for c in self.services.project.ctx.project.clips if c.id == clip_id), None)
        if not clip:
            return
        text, ok = QInputDialog.getText(self, "Clip umbenennen", "Neuer Name:", text=clip.label)
        if ok and text.strip():
            self.services.project.rename_clip(clip_id, text.strip())

    # --- docks / panels

    def _toggle_pianoroll(self, checked: bool) -> None:
        self.pianoroll_dock.setVisible(bool(checked))

    def _toggle_notation(self, checked: bool) -> None:
        """Enable/disable the Notation tab (WIP).

        This toggles the Notation editor tab (WIP). The editor is lightweight and safe.
        """
        checked = bool(checked)
        try:
            set_value(SettingsKeys.ui_enable_notation_tab, checked)
        except Exception:
            # settings failure should not block the UI
            pass
        try:
            self.editor_tabs.set_notation_tab_visible(checked)
            if checked:
                self.editor_tabs.show_notation()
        except Exception:
            # Do not crash the app if something goes wrong
            pass

    def _toggle_cliplauncher(self, checked: bool) -> None:
        checked = bool(checked)
        self.launcher_dock.setVisible(checked)
        # Persist
        try:
            set_value(SettingsKeys.ui_cliplauncher_visible, checked)
        except Exception:
            pass
        # Enable/disable overlay toggle based on visibility
        try:
            self.actions.view_toggle_drop_overlay.setEnabled(checked)
        except Exception:
            pass
        # If launcher is hidden, ensure overlay can't block arranger
        if not checked:
            try:
                self.arranger.deactivate_clip_overlay()
            except Exception:
                pass

    def _toggle_drop_overlay(self, checked: bool) -> None:
        checked = bool(checked)
        # Persist
        try:
            set_value(SettingsKeys.ui_cliplauncher_overlay_enabled, checked)
        except Exception:
            pass
        # If disabled, ensure overlay is not active
        if not checked:
            try:
                self.arranger.deactivate_clip_overlay()
            except Exception:
                pass

    def _on_sample_drag_started(self, label: str) -> None:
        """Called when a sample drag starts in the Browser.

        Important: Only activate the Clip-Launcher overlay if:
        - Clip Launcher view is enabled
        - Overlay toggle is enabled
        Otherwise: keep overlay off so normal Arranger drops work.
        """
        try:
            if not bool(self.actions.view_toggle_cliplauncher.isChecked()):
                # safety: ensure overlay is off
                try:
                    self.arranger.deactivate_clip_overlay()
                except Exception:
                    pass
                return
            if hasattr(self.actions, 'view_toggle_drop_overlay') and not bool(self.actions.view_toggle_drop_overlay.isChecked()):
                try:
                    self.arranger.deactivate_clip_overlay()
                except Exception:
                    pass
                return
        except Exception:
            # In doubt, do not block arranger
            try:
                self.arranger.deactivate_clip_overlay()
            except Exception:
                pass
            return

        self.arranger.activate_clip_overlay(str(label))

    def _on_sample_drag_ended(self) -> None:
        try:
            self.arranger.deactivate_clip_overlay()
        except Exception:
            pass

    def _toggle_automation(self, checked: bool) -> None:
        self.arranger.set_automation_visible(bool(checked))
        # keep actions + toolbar in sync
        if self.actions.view_toggle_automation.isChecked() != bool(checked):
            self.actions.view_toggle_automation.blockSignals(True)
            self.actions.view_toggle_automation.setChecked(bool(checked))
            self.actions.view_toggle_automation.blockSignals(False)

        # keep toolbar "Automation" button in sync (if present)
        try:
            tp = getattr(self, "toolbar_panel", None)
            btn = getattr(tp, "btn_auto", None) if tp is not None else None
            if btn is not None and btn.isChecked() != bool(checked):
                btn.blockSignals(True)
                btn.setChecked(bool(checked))
                btn.blockSignals(False)
        except Exception:
            pass

    def _on_clip_activated(self, clip_id: str) -> None:
        clip = next((c for c in self.services.project.ctx.project.clips if c.id == clip_id), None)
        if not clip:
            return

        self.services.project.select_clip(clip_id)

        # v0.0.20.612: Dual-Clock Phase D — Arranger-Fokus setzen
        # NUR wenn der Fokus nicht bereits vom Launcher für denselben Clip gesetzt wurde
        try:
            cc = getattr(self.services, 'clip_context', None)
            if cc is not None:
                existing = cc.get_editor_focus()
                # Überspringen wenn Launcher bereits Fokus für diesen Clip gesetzt hat
                if not (existing and existing.is_launcher and existing.clip_id == clip_id):
                    ctx = cc.build_arranger_focus(clip_id)
                    if ctx is not None:
                        cc.set_editor_focus(ctx)
        except Exception:
            pass

        if clip.kind == "midi":
            # Switch to edit view (was missing!)
            self._set_view_mode("edit", force=True)
            self.editor_dock.show()
            self.editor_dock.raise_()
            try:
                # Prefer notation if it's the current tab, otherwise piano roll
                if (self.editor_tabs.is_notation_tab_visible()
                        and self.editor_tabs.tabs.currentWidget() == getattr(self.editor_tabs, 'notation', None)):
                    self.editor_tabs.show_notation()
                else:
                    self.editor_tabs.show_pianoroll()
            except Exception:
                pass
            self.actions.view_toggle_pianoroll.setChecked(True)
        elif clip.kind == "audio":
            self._set_view_mode("edit", force=True)
            self.editor_dock.show()
            self.editor_dock.raise_()
            try:
                self.editor_tabs.show_audio()
            except Exception:
                pass
        elif clip.kind == "video":
            # v0.0.20.931: Open Video Editor on double-click
            self._set_view_mode("edit", force=True)
            self.editor_dock.show()
            self.editor_dock.raise_()
            try:
                self.editor_tabs.show_video()
            except Exception:
                pass
        else:
            self.statusBar().showMessage("Unbekannter Clip-Typ.", 2000)

    # --- Drag & Drop import (WAV/AIFF/MID)

    def _on_clip_edit_requested(self, clip_id: str) -> None:
        """Open the dedicated editor on double click (Clip Launcher)."""
        clip = next((c for c in self.services.project.ctx.project.clips if c.id == clip_id), None)
        if not clip:
            return

        self.services.project.select_clip(clip_id)

        # ensure editor dock visible
        self.editor_dock.show()
        self.actions.view_toggle_pianoroll.setChecked(True)

        if getattr(clip, "kind", "") == "midi":
            # prefer current editor if it's Notation and enabled; otherwise PianoRoll
            try:
                if self.editor_tabs.is_notation_tab_visible() and self.editor_tabs.tabs.currentWidget() == self.editor_tabs.notation:
                    self.editor_tabs.show_notation()
                else:
                    self.editor_tabs.show_pianoroll()
            except Exception:
                pass
            return

        if getattr(clip, "kind", "") == "audio":
            try:
                self.editor_tabs.show_audio()
            except Exception:
                pass
            return

        # v0.0.20.931: Video clip → open Video Editor
        if getattr(clip, "kind", "") == "video":
            try:
                self.editor_tabs.show_video()
            except Exception:
                pass
            return

        self.statusBar().showMessage("Unbekannter Clip-Typ.", 2000)


    def dragEnterEvent(self, event):  # type: ignore[override]
        # IMPORTANT: Never let exceptions escape from Qt virtual overrides.
        # PyQt6 + SIP can turn this into a Qt fatal (SIGABRT).
        try:
            md = event.mimeData()
            if md and md.hasUrls():
                event.acceptProposedAction()
            else:
                event.ignore()
        except Exception:
            try:
                event.ignore()
            except Exception:
                pass

    def dropEvent(self, event):  # type: ignore[override]
        # IMPORTANT: Never let exceptions escape from Qt virtual overrides.
        # PyQt6 + SIP can turn this into a Qt fatal (SIGABRT).
        try:
            md = event.mimeData()
            if not md or not md.hasUrls():
                event.ignore(); return

            paths: list[Path] = []
            for url in md.urls():
                try:
                    p = Path(url.toLocalFile())
                except Exception:
                    continue
                if p.exists() and p.is_file():
                    paths.append(p)

            if not paths:
                self.statusBar().showMessage("Keine Datei erkannt.", 2000)
                return

            imported = 0
            for p in paths:
                suf = p.suffix.lower()
                try:
                    if suf in (".mid", ".midi"):
                        self.services.project.import_midi(p)
                        imported += 1
                    elif suf in (".wav", ".aif", ".aiff", ".flac", ".ogg"):
                        self.services.project.import_audio(p)
                        imported += 1
                except Exception as e:  # noqa: BLE001
                    self.statusBar().showMessage(f"Import-Fehler ({p.name}): {e}", 4000)

            if imported:
                self.statusBar().showMessage(f"Importiert: {imported} Datei(en)", 3000)
            else:
                self.statusBar().showMessage("Keine unterstützten Formate (wav/aiff/flac/ogg/mid).", 4000)
        except Exception:
            try:
                event.ignore()
            except Exception:
                pass

    # --- Multi-Project Tab Handlers: see main_window_tabs.py (ProjectTabsMixin) ---

    # --- misc

    def _update_window_title(self, text: str | None = None, *args) -> None:
        if not text:
            try:
                text = self.services.project.display_name()
            except Exception:
                text = "Projekt"
        # Add tab count if multi-project tabs are active
        try:
            ts = getattr(self, '_project_tab_service', None)
            if ts and ts.count > 1:
                tab_info = f" [Tab {ts.active_index + 1}/{ts.count}]"
                self.setWindowTitle(f"Py DAW — {text}{tab_info}")
                return
        except Exception:
            pass
        self.setWindowTitle(f"Py DAW — {text}")

    def _show_error(self, msg: str) -> None:
        QMessageBox.warning(self, "Py DAW", msg)

    def _on_active_slot_changed(self, scene_idx: int, track_id: str, clip_id: str) -> None:
        """Handle aktiven pyqtSlot-Wechsel - Pro-DAW-Style Deep Integration.
        
        Wenn ein pyqtSlot im Clip-Launcher angeklickt wird:
        1. Piano-Roll wechselt auf den Clip (wenn MIDI)
        2. Notation folgt dem Clip (wenn MIDI)
        3. Mixer fokussiert den Track
        4. Audio Event Editor kann geöffnet werden (wenn Audio)
        """
        if not clip_id:
            return
            
        try:
            # Clip-Art ermitteln
            clip = self.services.project.get_clip(clip_id)
            if not clip:
                return
                
            kind = str(getattr(clip, 'kind', ''))
            
            # MIDI Clip -> Piano-Roll + Notation
            if kind == 'midi':
                # Piano-Roll auf Clip setzen
                try:
                    if hasattr(self.editor_tabs, 'pianoroll'):
                        # Trigger Clip-Wechsel im Piano-Roll
                        self.services.project.set_active_clip(clip_id)
                except Exception as e:
                    log.debug(f"Piano-Roll Update fehlgeschlagen: {e}")
                    
                # Notation auf Clip setzen
                try:
                    if hasattr(self.editor_tabs, 'notation'):
                        # Notation folgt automatisch via active_clip_changed pyqtSignal
                        pass
                except Exception as e:
                    log.debug(f"Notation Update fehlgeschlagen: {e}")
                    
            # Audio Clip -> Kann in Audio Event Editor bearbeitet werden
            # (wird bei Doppelklick im Launcher geöffnet)
            
            # Status-Message
            try:
                label = str(getattr(clip, 'label', 'Clip'))
                self.statusBar().showMessage(f"Aktiver pyqtSlot: {label} (Track: {track_id})", 2000)
            except Exception:
                pass
                
        except Exception as e:
            log.debug(f"Fehler in _on_active_slot_changed: {e}")

    def _init_recovery(self) -> None:
        """Install autosave timer + show restore prompt if last session was unclean."""
        from PyQt6.QtCore import QTimer

        # periodic autosave (safe JSON only)
        self._recovery_timer = QTimer(self)
        self._recovery_timer.setInterval(60_000)  # 60 seconds
        self._recovery_timer.timeout.connect(self._autosave_tick)
        self._recovery_timer.start()

        # prompt once after the window is shown
        QTimer.singleShot(400, self._prompt_recovery_if_needed)

    def _autosave_tick(self) -> None:
        try:
            from pydaw.fileio import recovery
            ctx = getattr(self.services, 'project', None).ctx if getattr(self, 'services', None) else None
            if ctx is None:
                return
            p = getattr(ctx, 'path', None)
            if not p:
                return
            # ensure enhanced automation lanes are persisted into the project dict
            try:
                self.services.project._sync_automation_manager_to_project()  # type: ignore[attr-defined]
            except Exception:
                pass
            recovery.write_autosave(p, ctx.project)
        except Exception:
            pass

    def _prompt_recovery_if_needed(self) -> None:
        try:
            from pydaw.fileio import recovery
            from PyQt6.QtWidgets import QMessageBox
            from datetime import datetime
            from pathlib import Path

            proj_path, autosave_path = recovery.should_prompt_restore()
            if proj_path is None or autosave_path is None:
                return

            try:
                ts = datetime.fromtimestamp(autosave_path.stat().st_mtime).strftime('%Y-%m-%d %H:%M:%S')
            except Exception:
                ts = str(autosave_path.name)

            msg = (
                "Beim letzten Start wurde ChronoScaleStudio nicht sauber beendet.\n\n"
                f"Projekt: {Path(proj_path).name}\n"
                f"Autosave: {ts}\n\n"
                "Wollen Sie den letzten Autosave wiederherstellen?"
            )
            res = QMessageBox.question(
                self,
                "Projekt wiederherstellen?",
                msg,
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes,
            )

            if res == QMessageBox.StandardButton.Yes:
                # Open original project, then load the autosave snapshot into it.
                ps = self.services.project

                def _once():
                    try:
                        ps.project_opened.disconnect(_once)
                    except Exception:
                        pass
                    try:
                        ps.load_snapshot(Path(autosave_path))
                    except Exception:
                        pass

                try:
                    ps.project_opened.connect(_once)
                except Exception:
                    pass
                try:
                    ps.open_project(Path(proj_path))
                except Exception:
                    # fallback: open autosave directly
                    try:
                        ps.open_project(Path(autosave_path))
                    except Exception:
                        pass
            else:
                try:
                    self.services.project.new_project("Neues Projekt")
                except Exception:
                    pass
        except Exception:
            pass

    def resizeEvent(self, event):  # noqa: ANN001, N802
        """Reposition overlays and keep the status-strip tech signature sized."""
        super().resizeEvent(event)
        try:
            overlay = getattr(self, '_ckb_overlay', None)
            if overlay is not None:
                ow = self.width() - 20
                oh = overlay.height()
                sb_h = self.statusBar().height() if self.statusBar() else 22
                overlay.setGeometry(10, self.height() - oh - sb_h - 4, ow, oh)
                overlay.raise_()
        except Exception:
            pass
        try:
            self._sync_status_tech_signature_sizes()
        except Exception:
            pass

    def closeEvent(self, event):  # noqa: ANN001
        # v0.0.20.625: Save + clean shutdown to prevent SIP SEGFAULT at exit
        # v0.0.20.885: Stop ALL timers FIRST — a timer firing during teardown
        # accesses deleted C++ objects and triggers SIGSEGV/SIGABRT.
        for timer_attr in ('_recovery_timer', '_midi_refresh_timer',
                           '_rec_waveform_timer', '_sandbox_timer',
                           '_collab_timer', '_meter_timer', '_vu_timer'):
            try:
                t = getattr(self, timer_attr, None)
                if t is not None:
                    t.stop()
            except Exception:
                pass
        try:
            mgr = getattr(self, '_screen_layout_mgr', None)
            if mgr is not None:
                mgr.save_state()
                mgr.shutdown()
                self._screen_layout_mgr = None
        except Exception:
            pass
        # v0.0.20.173: mark clean exit for crash-recovery
        try:
            journal = getattr(self, '_time_travel_journal', None)
            if journal is not None:
                journal.stop()
        except Exception:
            pass
        try:
            from pydaw.fileio import recovery
            recovery.mark_clean_exit()
        except Exception:
            pass
        try:
            self.services.metronome.shutdown()
        except Exception:
            pass
        try:
            self.services.midi.shutdown()
        except Exception:
            pass
        try:
            self.services.jack.shutdown()
        except Exception:
            pass
        try:
            self.services.audio_engine.shutdown_instruments()
        except Exception:
            pass
        try:
            self.services.audio_engine.stop()
        except Exception:
            pass
        # v0.0.20.779: Stop active sounddevice streams (safe, no _terminate!)
        # sd._terminate() kills PortAudio globally → breaks Bitwig + all other apps!
        try:
            import sounddevice as sd
            sd.stop()
        except Exception:
            pass
        try:
            # Newer containers expose a global shutdown hook.
            if hasattr(self.services, "shutdown"):
                self.services.shutdown()  # type: ignore[attr-defined]
        except Exception:
            pass
        # v0.0.20.869: Shutdown collab panel (mDNS discovery, WebSocket, MediaSync)
        # Must happen BEFORE sandbox/essentia shutdown to prevent zeroconf segfault
        try:
            cp = getattr(self, '_collab_panel', None)
            if cp is not None and hasattr(cp, 'shutdown'):
                cp.shutdown()
        except Exception:
            pass
        # v0.0.20.820: Shutdown essentia pool BEFORE sandbox manager —
        # worker threads access C extensions (numpy/scipy) that get unloaded
        # during interpreter teardown → SEGFAULT if threads are still alive.
        try:
            from pydaw.audio.essentia_pool import _shutdown_global_pool
            _shutdown_global_pool()
        except Exception:
            pass
        # v0.0.20.702: Shutdown sandbox process manager (kill all plugin workers)
        try:
            self._stop_sandbox_monitor()
            from pydaw.services.sandbox_process_manager import get_process_manager

            get_process_manager().shutdown()
        except Exception:
            pass

        # v0.0.20.885: Explicitly shutdown Rust engine bridge subprocess
        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            bridge = RustEngineBridge.instance()
            if bridge and bridge.is_enabled():
                bridge.shutdown()
        except Exception:
            pass

        # v0.0.20.885: Force GC before super().closeEvent to prevent
        # dangling C++ pointers when Python objects are collected out of order
        try:
            import gc
            gc.collect()
        except Exception:
            pass

        super().closeEvent(event)
