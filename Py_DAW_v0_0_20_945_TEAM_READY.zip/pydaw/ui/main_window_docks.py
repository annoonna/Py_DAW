"""Dock Toggles Mixin — Extracted from main_window.py (v0.0.20.906).

Contains all dock toggle handlers: KI-Assistent, Collab, Scripting,
SQLite Console, Time-Travel, Sound-Search, Undo-Tree, Heatmap,
SENTINEL, Live-Performance, Preset Browser, Video Track, Podcast Mode,
Session Share, Cloud Dialog, Theme Switching.

Self-contained: only references self.services, self.statusBar(),
self._set_status, self.addDockWidget, and dock/panel instance attrs
— all provided by MainWindow.

~600 lines extracted.
"""

from __future__ import annotations

import logging
import traceback

from PyQt6.QtWidgets import QDockWidget, QMessageBox
from PyQt6.QtCore import Qt

log = logging.getLogger(__name__)


class DockTogglesMixin:
    """Dock panel toggle handlers — mixed into MainWindow."""

    def _toggle_ki_assistant_dock(self) -> None:
        """KI-Assistent Dock ein-/ausblenden."""
        try:
            dock = getattr(self, "_ki_dock", None)
            if dock is None:
                QMessageBox.information(self, "KI-Assistent",
                    "KI-Assistent konnte nicht geladen werden.\n"
                    "Prüfe pydaw/ui/ki_assistant_panel.py")
                return
            if dock.isVisible():
                dock.hide()
            else:
                dock.show()
                dock.raise_()
                ki = getattr(self, "_ki_panel", None)
                if ki:
                    ki.refresh_context()
        except Exception:
            log.error("KI-Assistent dock toggle failed", exc_info=True)

    def _toggle_collab_dock(self) -> None:
        """v0.0.20.798: Collaboration Dock ein-/ausblenden."""
        try:
            dock = getattr(self, "_collab_dock", None)
            if dock is None:
                QMessageBox.information(self, "Kollaboration",
                    "Collab-Panel konnte nicht geladen werden.\n"
                    "Prüfe pydaw/ui/collab_panel.py")
                return
            if dock.isVisible():
                dock.hide()
            else:
                dock.show()
                dock.raise_()
                panel = getattr(self, "_collab_panel", None)
                if panel:
                    panel.refresh_all()
        except Exception:
            log.error("Collab dock toggle failed", exc_info=True)

    def _toggle_scripting_dock(self) -> None:
        """v0.0.20.798: Python Scripting Console ein-/ausblenden."""
        try:
            dock = getattr(self, "_scripting_dock", None)
            if dock is None:
                QMessageBox.information(self, "Python Console",
                    "Scripting-Panel konnte nicht geladen werden.\n"
                    "Prüfe pydaw/ui/scripting_panel.py")
                return
            if dock.isVisible():
                dock.hide()
            else:
                dock.show()
                dock.raise_()
        except Exception:
            log.error("Scripting dock toggle failed", exc_info=True)

    def _toggle_sqlite_console_dock(self) -> None:
        """v0.0.20.897: SQLite Console ein-/ausblenden."""
        try:
            dock = getattr(self, "_sqlite_console_dock", None)
            if dock is None:
                # Lazy-create the dock
                try:
                    from pydaw.ui.sqlite_console_panel import SQLiteConsolePanel
                    panel = SQLiteConsolePanel(parent=self)
                    dock = QDockWidget("🗄️ SQLite Console", self)
                    dock.setObjectName("sqliteConsoleDock")
                    dock.setWidget(panel)
                    dock.setAllowedAreas(
                        Qt.DockWidgetArea.BottomDockWidgetArea
                        | Qt.DockWidgetArea.RightDockWidgetArea
                    )
                    self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, dock)
                    self._sqlite_console_dock = dock
                    self._sqlite_console_panel = panel
                    try:
                        panel.status_message.connect(
                            lambda m: self.statusBar().showMessage(m, 3000)
                        )
                    except Exception:
                        pass
                except Exception as e:
                    QMessageBox.information(self, "SQLite Console",
                        f"SQLite Console konnte nicht geladen werden:\n{e}")
                    return
            if dock.isVisible():
                dock.hide()
            else:
                dock.show()
                dock.raise_()
        except Exception:
            log.error("SQLite console dock toggle failed", exc_info=True)

    def _toggle_time_travel_dock(self) -> None:
        """v0.0.20.901: Time-Travel Panel ein-/ausblenden."""
        try:
            dock = getattr(self, "_time_travel_dock", None)
            if dock is None:
                try:
                    from pydaw.ui.time_travel_panel import TimeTravelPanel
                    from pydaw.services.time_travel_restore import TimeTravelRestore
                    ps = getattr(self.services, 'project', None)
                    panel = TimeTravelPanel(project_service=ps, parent=self)
                    dock = QDockWidget("🕰️ Time Travel", self)
                    dock.setObjectName("timeTravelDock")
                    dock.setWidget(panel)
                    dock.setAllowedAreas(
                        Qt.DockWidgetArea.BottomDockWidgetArea
                        | Qt.DockWidgetArea.RightDockWidgetArea
                    )
                    self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)
                    self._time_travel_dock = dock
                    self._time_travel_panel = panel
                    # v0.0.20.901: Wire services (journal + restore)
                    journal = getattr(self, '_time_travel_journal', None)
                    if journal and ps:
                        restore = TimeTravelRestore(ps, journal)
                        panel.set_services(project_service=ps, journal=journal,
                                           restore=restore)
                except Exception as e:
                    QMessageBox.information(self, "Time Travel",
                        f"Time-Travel Panel konnte nicht geladen werden:\n{e}")
                    return
            if dock.isVisible():
                dock.hide()
            else:
                dock.show()
                dock.raise_()
        except Exception:
            log.error("Time-Travel dock toggle failed", exc_info=True)

    def _toggle_sound_search_dock(self) -> None:
        """v0.0.20.901: Sound-Suche Panel ein-/ausblenden."""
        try:
            dock = getattr(self, "_sound_search_dock", None)
            if dock is None:
                try:
                    from pydaw.ui.sound_search_panel import SoundSearchPanel
                    from pydaw.services.time_travel_restore import TimeTravelRestore
                    ps = getattr(self.services, 'project', None)
                    panel = SoundSearchPanel(parent=self, project_service=ps)
                    journal = getattr(self, '_time_travel_journal', None)
                    if journal and ps:
                        restore = TimeTravelRestore(ps, journal)
                        panel.set_services(project_service=ps, restore=restore)
                    dock = QDockWidget("🔍 Sound-Suche", self)
                    dock.setObjectName("soundSearchDock")
                    dock.setWidget(panel)
                    dock.setAllowedAreas(
                        Qt.DockWidgetArea.BottomDockWidgetArea
                        | Qt.DockWidgetArea.RightDockWidgetArea
                    )
                    self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)
                    self._sound_search_dock = dock
                except Exception as e:
                    log.warning("[MainWindow] Sound Search dock failed: %s", e)
                    return
            if dock.isVisible():
                dock.hide()
            else:
                dock.show()
                dock.raise_()
        except Exception:
            log.error("Sound-Search dock toggle failed", exc_info=True)

    def _toggle_undo_tree_dock(self) -> None:
        """v0.0.20.901: Undo-Baum Panel ein-/ausblenden."""
        try:
            dock = getattr(self, "_undo_tree_dock", None)
            if dock is None:
                try:
                    from pydaw.ui.undo_tree_widget import UndoTreeWidget
                    from pydaw.services.undo_tree import UndoTree
                    panel = UndoTreeWidget(parent=self)
                    journal = getattr(self, '_time_travel_journal', None)
                    if journal:
                        tree = UndoTree(journal)
                        tree.ensure_main_branch()
                        panel.set_undo_tree(tree)
                    dock = QDockWidget("🌳 Undo-Baum", self)
                    dock.setObjectName("undoTreeDock")
                    dock.setWidget(panel)
                    dock.setAllowedAreas(
                        Qt.DockWidgetArea.BottomDockWidgetArea
                        | Qt.DockWidgetArea.RightDockWidgetArea
                        | Qt.DockWidgetArea.LeftDockWidgetArea
                    )
                    self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)
                    self._undo_tree_dock = dock
                except Exception as e:
                    log.warning("[MainWindow] Undo Tree dock failed: %s", e)
                    return
            if dock.isVisible():
                dock.hide()
            else:
                dock.show()
                dock.raise_()
        except Exception:
            log.error("Undo-Tree dock toggle failed", exc_info=True)

    def _toggle_heatmap_dock(self) -> None:
        """v0.0.20.901: Session Heatmap ein-/ausblenden."""
        try:
            dock = getattr(self, "_heatmap_dock", None)
            if dock is None:
                try:
                    from pydaw.ui.session_heatmap_widget import SessionHeatmapPanel
                    from pydaw.services.time_travel_restore import TimeTravelRestore
                    ps = getattr(self.services, 'project', None)
                    panel = SessionHeatmapPanel(parent=self)
                    journal = getattr(self, '_time_travel_journal', None)
                    if journal and ps:
                        restore = TimeTravelRestore(ps, journal)
                        panel.set_services(project_service=ps, journal=journal,
                                           restore=restore)
                    dock = QDockWidget("🔥 Session Heatmap", self)
                    dock.setObjectName("heatmapDock")
                    dock.setWidget(panel)
                    dock.setAllowedAreas(
                        Qt.DockWidgetArea.BottomDockWidgetArea
                        | Qt.DockWidgetArea.RightDockWidgetArea
                    )
                    self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, dock)
                    self._heatmap_dock = dock
                except Exception as e:
                    log.warning("[MainWindow] Heatmap dock failed: %s", e)
                    return
            if dock.isVisible():
                dock.hide()
            else:
                dock.show()
                dock.raise_()
        except Exception:
            log.error("Heatmap dock toggle failed", exc_info=True)

    def _toggle_sentinel_dock(self) -> None:
        """v0.0.20.904: SENTINEL Dashboard ein-/ausblenden."""
        try:
            dock = getattr(self, "_sentinel_dock", None)
            if dock is None:
                try:
                    from pydaw.ui.sentinel_widgets import SentinelDashboard
                    panel = SentinelDashboard(parent=self)
                    recorder = getattr(self, '_sentinel_recorder', None)
                    anomaly = getattr(self, '_sentinel_anomaly', None)
                    panel.set_services(recorder=recorder, anomaly=anomaly)
                    dock = QDockWidget("🛡️ SENTINEL", self)
                    dock.setObjectName("sentinelDock")
                    dock.setWidget(panel)
                    dock.setAllowedAreas(
                        Qt.DockWidgetArea.BottomDockWidgetArea
                        | Qt.DockWidgetArea.RightDockWidgetArea
                    )
                    self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)
                    self._sentinel_dock = dock
                except Exception as e:
                    log.warning("[MainWindow] SENTINEL dock failed: %s", e)
                    return
            if dock.isVisible():
                dock.hide()
            else:
                dock.show()
                dock.raise_()
        except Exception:
            log.error("SENTINEL dock toggle failed", exc_info=True)

    # --- PRO Features ---

    def _open_smart_mixer(self) -> None:
        """v0.0.20.910 C4.8: Open Smart Mixer Heatmap dialog."""
        try:
            from pydaw.ui.smart_mixer_heatmap import SmartMixerDialog
            ps = getattr(self.services, 'project', None)
            dlg = SmartMixerDialog(parent=self, project_service=ps)
            try:
                dlg._panel.status_message.connect(
                    lambda m, t=3000: self.statusBar().showMessage(m, t)
                )
            except Exception:
                pass
            dlg.exec()
        except Exception as exc:
            log.warning("[MainWindow] Smart Mixer dialog failed: %s", exc)
            self._set_status(f"Smart Mixer Fehler: {exc}", 5000)

    def _toggle_live_performance(self) -> None:
        """Open the Live Performance fullscreen panel (P4A)."""
        try:
            from pydaw.ui.live_performance_panel import LivePerformancePanel
            panel = LivePerformancePanel(
                transport=getattr(self.services, 'transport', None),
                project_service=getattr(self.services, 'project', None),
                clip_launcher=getattr(self.services, 'cliplauncher_playback', None),
                parent=None,
            )
            panel.showFullScreen()
            self._set_status("🎭 Live-Performance-Modus gestartet", 3000)
        except Exception as exc:
            self._set_status(f"Live-Performance Fehler: {exc}", 5000)

    def _toggle_preset_browser_dock(self) -> None:
        """Toggle the Community Preset Browser dock (P6C)."""
        try:
            dock = getattr(self, '_preset_browser_dock', None)
            if dock is not None:
                dock.setVisible(not dock.isVisible())
                return
            from pydaw.ui.community_preset_browser import (
                CommunityPresetBrowser, PresetRepositoryService,
            )
            repo = PresetRepositoryService()
            browser = CommunityPresetBrowser(repository=repo, parent=self)
            browser.status_message.connect(self._set_status)
            dock = QDockWidget("Community Presets", self)
            dock.setWidget(browser)
            self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)
            self._preset_browser_dock = dock
            repo.scan_local()
            self._set_status("🎛 Community Preset Browser geöffnet", 3000)
        except Exception as exc:
            self._set_status(f"Preset-Browser Fehler: {exc}", 5000)

    def _switch_theme(self, theme_key: str) -> None:
        """Switch to a different theme."""
        try:
            from pydaw.ui.theme_manager import ThemeManager
            mgr = getattr(self, '_theme_manager', None)
            if mgr is None:
                mgr = ThemeManager(self)
                self._theme_manager = mgr
            if mgr.set_theme(theme_key):
                self._set_status(f"🎨 Theme: {mgr.current_theme.name}", 3000)
        except Exception as exc:
            self._set_status(f"Theme-Fehler: {exc}", 5000)

    def _toggle_video_track(self) -> None:
        """Toggle video track panel (VO1–VO5, v0.0.20.918)."""
        try:
            dock = getattr(self, '_video_dock', None)
            if dock is None:
                try:
                    from pydaw.ui.video_panel import VideoPanel
                    panel = VideoPanel(services=self.services, parent=self)
                    dock = QDockWidget("🎬 Video", self)
                    dock.setObjectName("videoDock")
                    dock.setWidget(panel)
                    dock.setAllowedAreas(
                        Qt.DockWidgetArea.BottomDockWidgetArea
                        | Qt.DockWidgetArea.RightDockWidgetArea
                        | Qt.DockWidgetArea.LeftDockWidgetArea
                    )
                    self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)
                    self._video_dock = dock
                    self._video_panel = panel
                    try:
                        panel.status.connect(self._set_status)
                    except Exception:
                        pass
                    # v0.0.20.927: Register with VideoConnector so video drops auto-load
                    try:
                        from pydaw.services.video_connector import VideoConnector
                        vc = VideoConnector.instance()
                        vc.register_video_panel(panel)
                        # Also register transport + project_service if available
                        if hasattr(self, 'services') and self.services:
                            transport = (getattr(self.services, 'transport', None)
                                         or getattr(self.services, 'transport_service', None))
                            if transport:
                                vc.register_transport(transport)
                            ps = (getattr(self.services, 'project', None)
                                  or getattr(self.services, 'project_service', None))
                            if ps:
                                vc.register_project_service(ps)
                    except Exception:
                        pass
                except Exception as e:
                    QMessageBox.information(self, "Video-Spur",
                        f"Video-Panel konnte nicht geladen werden:\n{e}")
                    return
            if dock.isVisible():
                dock.hide()
            else:
                dock.show()
                dock.raise_()
        except Exception as exc:
            self._set_status(f"Video-Track Fehler: {exc}", 5000)

    def _toggle_video_ki_panel(self) -> None:
        """Toggle Video-KI Assistent panel (VK8, v0.0.20.920)."""
        try:
            dock = getattr(self, '_video_ki_dock', None)
            if dock is None:
                try:
                    from pydaw.ui.video_ki_panel import VideoKIPanel
                    panel = VideoKIPanel(services=self.services, parent=self)
                    dock = QDockWidget("🧠 Video-KI", self)
                    dock.setObjectName("videoKIDock")
                    dock.setWidget(panel)
                    dock.setAllowedAreas(
                        Qt.DockWidgetArea.BottomDockWidgetArea
                        | Qt.DockWidgetArea.RightDockWidgetArea
                        | Qt.DockWidgetArea.LeftDockWidgetArea
                    )
                    self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)
                    self._video_ki_dock = dock
                    self._video_ki_panel = panel
                    try:
                        panel.status.connect(self._set_status)
                    except Exception:
                        pass
                    # Auto-connect video path from VideoPanel if available
                    try:
                        vp = getattr(self, '_video_panel', None)
                        if vp and hasattr(vp, '_video_path') and vp._video_path:
                            panel.set_video_path(vp._video_path)
                    except Exception:
                        pass
                except Exception as e:
                    QMessageBox.information(self, "Video-KI",
                        f"Video-KI Panel konnte nicht geladen werden:\n{e}")
                    return
            if dock.isVisible():
                dock.hide()
            else:
                dock.show()
                dock.raise_()
        except Exception as exc:
            self._set_status(f"Video-KI Fehler: {exc}", 5000)

    def _toggle_podcast_mode(self) -> None:
        """Toggle podcast mode panel (PO1–PO4, v0.0.20.917)."""
        try:
            dock = getattr(self, '_podcast_dock', None)
            if dock is None:
                try:
                    from pydaw.ui.podcast_panel import PodcastPanel
                    panel = PodcastPanel(services=self.services, parent=self)
                    dock = QDockWidget("🎙 Podcast", self)
                    dock.setObjectName("podcastDock")
                    dock.setWidget(panel)
                    dock.setAllowedAreas(
                        Qt.DockWidgetArea.BottomDockWidgetArea
                        | Qt.DockWidgetArea.RightDockWidgetArea
                        | Qt.DockWidgetArea.LeftDockWidgetArea
                    )
                    self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)
                    self._podcast_dock = dock
                    self._podcast_panel = panel
                    # Connect status signal
                    try:
                        panel.status.connect(self._set_status)
                    except Exception:
                        pass
                except Exception as e:
                    QMessageBox.information(self, "Podcast-Modus",
                        f"Podcast-Panel konnte nicht geladen werden:\n{e}")
                    return
            if dock.isVisible():
                dock.hide()
            else:
                dock.show()
                dock.raise_()
        except Exception as exc:
            self._set_status(f"Podcast-Modus Fehler: {exc}", 5000)

    def _create_session_share(self) -> None:
        """Create a shareable session package (P5B)."""
        try:
            from pydaw.services.session_share import SessionShareService
            svc = getattr(self, '_session_share', None)
            if svc is None:
                svc = SessionShareService(
                    project_service=getattr(self.services, 'project', None),
                    parent=self,
                )
                svc.status.connect(self._set_status)
                self._session_share = svc
            from PyQt6.QtWidgets import QInputDialog
            desc, ok = QInputDialog.getText(
                self, "Session teilen", "Beschreibung (optional):",
            )
            if ok:
                link = svc.create_share(description=desc)
                if link:
                    QMessageBox.information(
                        self, "Session geteilt",
                        f"Share-ID: {link.share_id}\n"
                        f"Datei: {link.file_path}\n\n"
                        f"Die .pydaw-share Datei kann direkt weitergegeben werden.",
                    )
        except Exception as exc:
            self._set_status(f"Session-Share Fehler: {exc}", 5000)

    def _show_cloud_dialog(self) -> None:
        """Show cloud storage info dialog (P5B)."""
        try:
            from pydaw.services.cloud_service import CloudStorageService
            cloud = getattr(self, '_cloud_service', None)
            if cloud is None:
                cloud = CloudStorageService(parent=self)
                cloud.status.connect(self._set_status)
                self._cloud_service = cloud
            stats = cloud.get_stats()
            QMessageBox.information(
                self, "☁️ Cloud-Speicher",
                f"Projekte: {stats['projects']}\n"
                f"Samples: {stats['samples']}\n"
                f"Presets: {stats['presets']}\n"
                f"Sammlungen: {stats['collections']}\n"
                f"Größe: {stats['total_size_mb']} MB\n\n"
                f"Verzeichnis: {stats['cloud_dir']}",
            )
        except Exception as exc:
            self._set_status(f"Cloud-Fehler: {exc}", 5000)
