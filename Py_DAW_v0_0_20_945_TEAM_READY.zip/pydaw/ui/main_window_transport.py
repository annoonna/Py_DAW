"""Transport & Recording Mixin — Extracted from main_window.py (v0.0.20.907).

Contains transport, punch, loop, monitoring, recording, metronome,
BPM/TS handlers, JACK monitor routing, and waveform preview.

Self-contained: only references self.services, self.transport,
self.arranger, self.automation, self.toolbar_panel, self.statusBar(),
and recording state attrs — all provided by MainWindow.

~760 lines extracted.
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path

from PyQt6.QtCore import QTimer

from pydaw.core.settings import SettingsKeys
from pydaw.core.settings_store import get_value

log = logging.getLogger(__name__)


class TransportRecordingMixin:
    """Transport, punch, loop, recording handlers — mixed into MainWindow."""

    def _toggle_input_monitor(self) -> None:
        """v0.0.20.757: Input-Monitoring via Taste I umschalten."""
        try:
            btn = self.transport.btn_monitor
            btn.setChecked(not btn.isChecked())
        except Exception:
            pass


    def _on_arranger_loop_committed(self, enabled: bool, start: float, end: float) -> None:
        self.services.transport.set_loop(bool(enabled))
        self.services.transport.set_loop_region(float(start), float(end))

    # ──────────────────────────────────────────────────────
    # v0.0.20.637: Punch In/Out handlers (AP2 Phase 2C)
    # ──────────────────────────────────────────────────────


    def _on_arranger_punch_committed(self, enabled: bool, in_beat: float, out_beat: float) -> None:
        """Arranger canvas punch region edit → TransportService + Project Model."""
        self.services.transport.set_punch_region(float(in_beat), float(out_beat))
        if enabled:
            self.services.transport.set_punch(True)
        else:
            self.services.transport.set_punch(False)
        # Persist to project model
        try:
            proj = self.services.project.ctx.project
            proj.punch_enabled = bool(enabled)
            proj.punch_in_beat = float(in_beat)
            proj.punch_out_beat = float(out_beat)
        except Exception:
            pass


    def _on_transport_punch_changed(self, enabled: bool, in_beat: float, out_beat: float) -> None:
        """TransportService punch change → Arranger + Transport panel UI."""
        self.arranger.canvas.set_punch_region(bool(enabled), float(in_beat), float(out_beat))
        try:
            self.transport.set_punch(bool(enabled))
        except Exception:
            pass
        # Sync RecordingService punch state
        rec = getattr(self.services, 'recording', None)
        if rec:
            try:
                rec.set_punch(bool(enabled), float(in_beat), float(out_beat))
            except Exception:
                pass


    def _on_punch_toggled_from_ui(self, enabled: bool) -> None:
        """Transport panel punch checkbox → TransportService."""
        self.services.transport.set_punch(bool(enabled))
        # Persist
        try:
            self.services.project.ctx.project.punch_enabled = bool(enabled)
        except Exception:
            pass


    def _on_punch_triggered(self, boundary: str) -> None:
        """TransportService fires when playhead crosses punch_in or punch_out.

        Forwards to RecordingService for automatic punch record start/stop.
        v0.0.20.753: Auto-Punch — startet/stoppt Recording automatisch.
        """
        rec = getattr(self.services, 'recording', None)
        if rec and rec.is_recording():
            try:
                rec.on_punch_triggered(boundary)
            except Exception:
                pass

        # v0.0.20.753: Auto-Punch IN → Recording automatisch starten
        if boundary == "in" and not self._recording_active:
            try:
                t = self.services.transport
                if t.punch_enabled:
                    self.statusBar().showMessage("Auto-Punch IN — Recording startet…", 1500)
                    # REC-Button aktivieren → triggert _on_record_toggled(True)
                    self.transport.btn_rec.blockSignals(True)
                    self.transport.btn_rec.setChecked(True)
                    self.transport.btn_rec.blockSignals(False)
                    self._on_record_toggled(True)
            except Exception:
                pass

        if boundary == "out":
            self.statusBar().showMessage("Auto-Punch OUT — Recording gestoppt", 2000)
            try:
                self.transport.btn_rec.blockSignals(True)
                self.transport.btn_rec.setChecked(False)
                self.transport.set_recording_visual(False)
                self.transport.btn_rec.blockSignals(False)
                self._recording_active = False
                # Auch RecordingService stoppen
                if rec and rec.is_recording():
                    rec.stop_recording()
            except Exception:
                pass


    def _on_monitor_toggled(self, enabled: bool) -> None:
        """v0.0.20.757: Input-Monitoring ein/aus.

        Startet/stoppt den Echtzeit-Audio-Passthrough (Mikrofon → Lautsprecher).
        Latenz: ~10ms bei Buffer 512 / 48000Hz.
        Wird automatisch gestoppt wenn Recording läuft (kein Feedback).
        """
        enabled = bool(enabled)
        mon = getattr(self.services, 'input_monitor', None)
        if mon is None:
            self.statusBar().showMessage(
                "Input-Monitoring: sounddevice nicht verfügbar", 3000)
            try:
                self.transport.btn_monitor.blockSignals(True)
                self.transport.btn_monitor.setChecked(False)
                self.transport.btn_monitor.blockSignals(False)
            except Exception:
                pass
            return

        if enabled:
            # Sicherheit: kein Monitoring während Recording (Rückkopplung)
            rec = getattr(self.services, 'recording', None)
            if rec and rec.is_recording():
                self.statusBar().showMessage(
                    "Input-Monitoring: nicht möglich während Recording", 2000)
                try:
                    self.transport.btn_monitor.blockSignals(True)
                    self.transport.btn_monitor.setChecked(False)
                    self.transport.btn_monitor.blockSignals(False)
                except Exception:
                    pass
                return

            # Buffer-Größe aus Audio-Einstellungen synchronisieren
            try:
                from pydaw.core.settings import SettingsKeys
                from pydaw.core.settings_store import get_value
                _buf = int(get_value(SettingsKeys().buffer_size, 512) or 512)
                _sr  = int(getattr(self.services.audio_engine,
                                   'get_effective_sample_rate',
                                   lambda: 48000)() or 48000)
                mon.configure(sample_rate=_sr, buffer_size=_buf)
            except Exception:
                pass

            ok = mon.start()
            if ok:
                lat = mon.get_latency_ms()
                self.statusBar().showMessage(
                    f"Input-Monitoring aktiv — Latenz: {lat:.1f}ms", 3000)
                # Button grün färben
                try:
                    self.transport.btn_monitor.setStyleSheet(
                        "QPushButton:checked { background: #2d6a2d; color: #7fff7f; }"
                    )
                except Exception:
                    pass
            else:
                self.statusBar().showMessage(
                    "Input-Monitoring: Fehler beim Öffnen des Audio-Streams", 3000)
                try:
                    self.transport.btn_monitor.blockSignals(True)
                    self.transport.btn_monitor.setChecked(False)
                    self.transport.btn_monitor.blockSignals(False)
                except Exception:
                    pass
        else:
            mon.stop()
            self.statusBar().showMessage("Input-Monitoring gestoppt", 1500)
            try:
                self.transport.btn_monitor.setStyleSheet("")
            except Exception:
                pass


    def _on_pre_roll_changed(self, bars: int) -> None:
        """Transport panel pre-roll spinbox → TransportService + Project."""
        self.services.transport.set_pre_roll_bars(int(bars))
        try:
            self.services.project.ctx.project.pre_roll_bars = int(bars)
        except Exception:
            pass


    def _on_post_roll_changed(self, bars: int) -> None:
        """Transport panel post-roll spinbox → TransportService + Project."""
        self.services.transport.set_post_roll_bars(int(bars))
        try:
            self.services.project.ctx.project.post_roll_bars = int(bars)
        except Exception:
            pass

    # ──────────────────────────────────────────────────────
    # v0.0.20.639: Loop-Recording / Take-Lanes (AP2 Phase 2D)
    # ──────────────────────────────────────────────────────


    def _on_loop_boundary_reached(self) -> None:
        """Transport loop wraps → save current take, start new pass."""
        rec = getattr(self.services, 'recording', None)
        if rec and rec.is_loop_recording():
            try:
                rec.on_loop_boundary()
            except Exception:
                pass


    def _setup_loop_recording_for_record_start(self) -> None:
        """Enable loop-recording if transport loop is active when Record starts.

        Called from _on_record_toggled() before start_recording().
        """
        rec = getattr(self.services, 'recording', None)
        if not rec:
            return
        try:
            t = self.services.transport
            take_svc = getattr(self.services, 'take', None)

            if t.loop_enabled:
                rec.set_loop_recording(True)
                if take_svc:
                    rec.set_take_service(take_svc)

                # Set up take-creation callback
                def _on_take_created(wav_path, track_id, start_beat, tkg_id, take_idx):
                    try:
                        clip_id = self.services.project.add_audio_clip_from_file_at(
                            track_id=track_id,
                            path=wav_path,
                            start_beats=start_beat,
                        )
                        if clip_id and take_svc:
                            # Find the created clip and assign take metadata
                            for c in self.services.project.ctx.project.clips:
                                if str(getattr(c, 'id', '')) == str(clip_id):
                                    take_svc.add_take_to_group(tkg_id, c, make_active=True)
                                    c.label = f"Take {take_idx + 1}"
                                    break
                            # Show take lanes on this track
                            for trk in self.services.project.ctx.project.tracks:
                                if str(getattr(trk, 'id', '')) == str(track_id):
                                    trk.take_lanes_visible = True
                                    break
                        self.statusBar().showMessage(
                            f"Take {take_idx + 1} gespeichert: {wav_path.name}", 2000
                        )
                    except Exception as e:
                        self.statusBar().showMessage(f"Take-Import fehlgeschlagen: {e}", 4000)

                rec.set_on_take_created(_on_take_created)
            else:
                rec.set_loop_recording(False)
        except Exception:
            pass


    def _on_transport_loop_changed(self, enabled: bool, start: float, end: float) -> None:
        self.arranger.canvas.set_loop_region(bool(enabled), float(start), float(end))
        if self.transport.chk_loop.isChecked() != bool(enabled):
            self.transport.chk_loop.blockSignals(True)
            self.transport.chk_loop.setChecked(bool(enabled))
            self.transport.chk_loop.blockSignals(False)
        # v0.0.20.438: Sync toolbar loop fields
        try:
            if hasattr(self, "toolbar_panel") and self.toolbar_panel is not None:
                self.toolbar_panel.set_loop_from_transport(bool(enabled), float(start), float(end))
        except Exception:
            pass
        # v0.0.20.736: Forward loop region to Rust MidiScheduler so it can
        # correctly emit notes across the loop-wrap boundary without stuck notes.
        try:
            bridge = getattr(self, "_rust_bridge", None)
            if bridge is None:
                from pydaw.services.rust_engine_bridge import RustEngineBridge
                bridge = RustEngineBridge.instance()
            if bridge is not None and bridge.is_enabled():
                bridge.set_loop(bool(enabled), float(start), float(end))
        except Exception:
            pass


    def _on_follow_changed(self, follow: bool) -> None:
        """v0.0.20.438: Toggle Bitwig-style playhead follow in arranger."""
        try:
            self.arranger.canvas._follow_playhead = bool(follow)
        except Exception:
            pass


    def _on_toolbar_loop_changed(self, enabled: bool, start_beat: float, end_beat: float) -> None:
        """v0.0.20.438: Loop fields in toolbar → Transport + Arranger."""
        try:
            self.services.transport.set_loop(bool(enabled))
            self.services.transport.set_loop_region(float(start_beat), float(end_beat))
            self.arranger.canvas.set_loop_region(bool(enabled), float(start_beat), float(end_beat))
            # Sync transport panel checkbox
            if self.transport.chk_loop.isChecked() != bool(enabled):
                self.transport.chk_loop.blockSignals(True)
                self.transport.chk_loop.setChecked(bool(enabled))
                self.transport.chk_loop.blockSignals(False)
        except Exception:
            pass


    def _on_transport_ts_changed(self, ts: str) -> None:
        self.transport.set_time_signature(ts)
        self.arranger.canvas.update()


    def _update_playhead(self, beat: float) -> None:
        self.arranger.canvas.set_playhead(float(beat))
        self.transport.set_time(float(beat), self.services.transport.bpm)
        try:
            self.automation.set_playhead(float(beat))
        except Exception:
            pass
        # v0.0.20.89: Enhanced automation playhead + tick
        try:
            eap = getattr(self.arranger, '_enhanced_automation', None)
            if eap is not None:
                eap.set_playhead(float(beat))
        except Exception:
            pass
        try:
            self.services.automation_manager.tick(float(beat))
        except Exception:
            pass

    # --- metronome click


    def _on_metronome_tick(self, bar_index: int, beat_in_bar: int, is_countin: bool) -> None:
        prefix = "Count-In" if is_countin else "Metronom"
        self.statusBar().showMessage(f"{prefix}: Bar {bar_index + 1}, Beat {beat_in_bar}", 350)

        # audio click (best effort): accent on downbeat
        accent = (beat_in_bar == 1)
        try:
            self.services.metronome.play_click(accent=accent)
        except Exception:
            pass

    # --- wiring


    def _on_bpm_changed_from_ui(self, bpm: float) -> None:
        self.services.transport.set_bpm(bpm)
        self.services.project.ctx.project.bpm = float(bpm)
        self.services.project.project_updated.emit()


    def _on_ts_changed_from_ui(self, ts: str) -> None:
        self.services.project.set_time_signature(ts)
        self.services.transport.set_time_signature(ts)
        self.statusBar().showMessage(f"Time Signature gesetzt: {ts}", 2000)


    def _on_metronome_enabled(self, enabled: bool) -> None:
        self.services.transport.set_metronome(bool(enabled))
        # Enable click service either when metronome enabled or count-in > 0
        enabled_click = bool(enabled) or int(self.services.transport.count_in_bars) > 0
        self.services.metronome.set_enabled(enabled_click)


    def _on_count_in_changed(self, bars: int) -> None:
        self.services.transport.set_count_in_bars(int(bars))
        enabled_click = self.transport.chk_met.isChecked() or int(bars) > 0
        self.services.metronome.set_enabled(enabled_click)


    def _on_record_toggled(self, enabled: bool) -> None:
        """Start/stop audio recording (v0.0.20.636 — AP2 Phase 2B).

        Uses RecordingService which auto-detects backend:
        JACK > PipeWire > sounddevice.  Falls back to legacy JACK path
        if RecordingService is not wired.

        v0.0.20.636: Supports multiple armed tracks simultaneously.
        """
        enabled = bool(enabled)

        rec = getattr(self.services, 'recording', None)
        if rec is None:
            # Legacy fallback: JACK-only (pre-v0.0.20.632)
            self._on_record_toggled_legacy(enabled)
            return

        if enabled and not rec.is_recording():
            # --- START RECORDING ---

            # v0.0.20.636: Collect ALL armed tracks (multi-track recording)
            armed_tracks = []  # list of (track_id, input_pair)
            try:
                for t in self.services.project.ctx.project.tracks:
                    if bool(getattr(t, "record_arm", False)):
                        tid = str(t.id)
                        pair = max(1, int(getattr(t, "input_pair", 1) or 1))
                        armed_tracks.append((tid, pair))
            except Exception:
                pass

            if not armed_tracks:
                # Fallback: ensure at least one audio track
                tid = None
                try:
                    tid = str(self.services.project.ensure_audio_track())
                except Exception:
                    pass
                if not tid:
                    self.statusBar().showMessage("Recording: Kein Track verfügbar.", 2500)
                    try:
                        self.transport.btn_rec.blockSignals(True)
                        self.transport.btn_rec.setChecked(False)
                        self.transport.set_recording_visual(False)
                        self.transport.btn_rec.blockSignals(False)
                    except Exception:
                        pass
                    return
                armed_tracks = [(tid, 1)]

            # Configure recording service
            rec.set_transport(self.services.transport)

            # Disarm previous state, then arm all tracks
            rec.disarm_track(None)  # clear all
            for tid, pair in armed_tracks:
                rec.arm_track(tid, pair)

            # Set project media path if available
            try:
                proj_path = getattr(self.services.project.ctx, 'project_path', None)
                if proj_path:
                    from pathlib import Path
                    media_dir = Path(proj_path).parent / "media" / "recordings"
                    rec.set_project_media_path(media_dir)
            except Exception:
                pass

            # Set auto clip creation callback (fires per track)
            def _on_rec_complete(wav_path, track_id, start_beat):
                try:
                    self.services.project.add_audio_clip_from_file_at(
                        track_id=track_id,
                        path=wav_path,
                        start_beats=start_beat,
                    )
                    self.statusBar().showMessage(f"Recording importiert: {wav_path.name}", 3000)
                except Exception as e:
                    self.statusBar().showMessage(f"Recording Import fehlgeschlagen: {e}", 4000)

            rec.set_on_recording_complete(_on_rec_complete)

            # Determine sample rate from audio engine
            sr = 48000
            try:
                sr = int(getattr(self.services.audio_engine, 'sample_rate', 48000) or 48000)
            except Exception:
                pass

            # v0.0.20.636: Sync buffer size from audio settings
            try:
                _keys = SettingsKeys()
                _buf = int(get_value(_keys.buffer_size, 512))
                _buf = int(get_value(_keys.buffer_size, 512))
                rec.set_buffer_size(_buf)
            except Exception:
                pass

            # v0.0.20.637: Sync punch state to RecordingService
            try:
                t = self.services.transport
                rec.set_punch(
                    bool(t.punch_enabled),
                    float(t.punch_in_beat),
                    float(t.punch_out_beat),
                )
            except Exception:
                pass

            # v0.0.20.638: Pre-Roll Auto-Seek (Pro Tools/Logic style)
            # When punch+record: seek playhead to punch_in minus pre-roll bars
            try:
                t = self.services.transport
                if t.punch_enabled:
                    seek_beat = t.get_punch_play_start_beat()
                    t.seek(seek_beat)
            except Exception:
                pass

            # v0.0.20.639: Setup loop-recording if transport loop is active
            self._setup_loop_recording_for_record_start()

            # Start recording (uses all armed tracks)
            success = rec.start_recording(
                sample_rate=sr,
                channels=2,
            )

            if success:
                self._recording_active = True
                self._recording_track_id = armed_tracks[0][0]  # compat: first track
                self._recording_start_beat = float(
                    getattr(self.services.transport, "current_beat", 0.0) or 0.0
                )
                backend = rec.get_backend()
                n_tracks = len(armed_tracks)
                self.statusBar().showMessage(
                    f"Recording: {n_tracks} Track(s), {backend}, Buffer {rec.get_buffer_size()}",
                    2000,
                )
                # v0.0.20.757: Input-Monitoring stoppen (Rückkopplungsschutz)
                try:
                    mon = getattr(self.services, 'input_monitor', None)
                    if mon and mon.is_active():
                        mon.stop()
                        self.transport.btn_monitor.blockSignals(True)
                        self.transport.btn_monitor.setChecked(False)
                        self.transport.btn_monitor.blockSignals(False)
                except Exception:
                    pass
                # v0.0.20.751 P1A: Live-Waveform-Preview Timer starten
                try:
                    if not hasattr(self, '_rec_waveform_timer'):
                        self._rec_waveform_timer = QTimer(self)
                        self._rec_waveform_timer.setInterval(100)  # 10 Hz
                        self._rec_waveform_timer.timeout.connect(self._update_recording_waveform_preview)
                    self._rec_waveform_armed_tracks = [t[0] for t in armed_tracks]
                    self._rec_waveform_start_beat = float(
                        getattr(self.services.transport, "current_beat", 0.0) or 0.0
                    )
                    self._rec_waveform_timer.start()
                except Exception:
                    pass
            else:
                self.statusBar().showMessage(
                    f"Recording Start fehlgeschlagen ({rec.get_backend()})", 4000
                )
                try:
                    self.transport.btn_rec.blockSignals(True)
                    self.transport.btn_rec.setChecked(False)
                    self.transport.set_recording_visual(False)
                    self.transport.btn_rec.blockSignals(False)
                except Exception:
                    pass
            return

        if (not enabled) and rec.is_recording():
            # --- STOP RECORDING ---
            # v0.0.20.751: Live-Waveform-Timer stoppen
            try:
                t = getattr(self, '_rec_waveform_timer', None)
                if t and t.isActive():
                    t.stop()
            except Exception:
                pass
            n_armed = len(rec.get_armed_track_ids())
            wav_path = rec.stop_recording()
            self._recording_active = False

            if wav_path:
                self.statusBar().showMessage(
                    f"Recording gespeichert: {n_armed} Track(s)", 3000
                )
            else:
                self.statusBar().showMessage("Recording: Keine Daten aufgenommen.", 3000)

            self._recording_track_id = None
            self._recording_wav_path = None
            self._recording_start_beat = 0.0
            return


    def _update_recording_waveform_preview(self) -> None:
        """v0.0.20.751 P1A: Live-Waveform-Vorschau während der Aufnahme.

        Wird alle 100ms aufgerufen. Holt die aktuellen Peak-Daten aus dem
        RecordingService und speichert sie im ArrangerCanvas-Cache damit
        der nächste Repaint die wachsende Waveform zeigt.
        """
        try:
            rec = getattr(self.services, 'recording', None)
            if not rec or not rec.is_recording():
                t = getattr(self, '_rec_waveform_timer', None)
                if t:
                    t.stop()
                return

            canvas = getattr(self.arranger, 'canvas', None)
            if canvas is None:
                return

            armed_tracks = getattr(self, '_rec_waveform_armed_tracks', [])
            for track_id in armed_tracks:
                maxs, mins = rec.get_live_waveform_peaks(track_id, num_pixels=300)
                if maxs is None:
                    continue
                # Live-Waveform-Cache auf dem Canvas speichern
                if not hasattr(canvas, '_live_waveform_cache'):
                    canvas._live_waveform_cache = {}
                canvas._live_waveform_cache[track_id] = {
                    "maxs": maxs,
                    "mins": mins,
                    "start_beat": float(getattr(self, '_rec_waveform_start_beat', 0.0)),
                    "end_beat": float(
                        getattr(self.services.transport, "current_beat", 0.0) or 0.0
                    ),
                    "track_id": track_id,
                }

            # Nur den sichtbaren Bereich neuzeichnen (kein volles repaint)
            canvas.update()

        except Exception:
            pass


    def _on_record_toggled_legacy(self, enabled: bool) -> None:
        """Legacy JACK-only recording path (pre-v0.0.20.632)."""
        enabled = bool(enabled)
        # Only JACK backend for now
        if str(self.services.audio_engine.backend) != "jack":
            self.statusBar().showMessage("Recording: aktuell nur im JACK-Backend (Audio → Einstellungen) unterstützt.", 3000)
            try:
                self.transport.btn_rec.blockSignals(True)
                self.transport.btn_rec.setChecked(False)
                self.transport.set_recording_visual(False)
                self.transport.btn_rec.blockSignals(False)
            except Exception:
                pass
            return

        if enabled and not self._recording_active:
            # choose armed track
            tid = None
            try:
                for t in self.services.project.ctx.project.tracks:
                    if bool(getattr(t, "record_arm", False)):
                        tid = str(t.id)
                        break
            except Exception:
                tid = None
            if not tid:
                # fallback: ensure audio track
                try:
                    tid = str(self.services.project.ensure_audio_track())
                except Exception:
                    tid = None
            if not tid:
                self.statusBar().showMessage("Recording: Kein Track verfügbar.", 2500)
                return

            self._recording_track_id = tid
            self._recording_start_beat = float(getattr(self.services.transport, "current_beat", 0.0) or 0.0)

            # temp wav path (project import happens on stop)
            import os
            from pathlib import Path
            import time
            cache = Path(os.path.expanduser("~/.cache/Py_DAW/recordings"))
            cache.mkdir(parents=True, exist_ok=True)
            ts = time.strftime("%Y%m%d_%H%M%S")
            wav_path = cache / f"rec_{ts}.wav"
            self._recording_wav_path = str(wav_path)

            # Determine stereo input pair from the armed track (defaults to 1)
            pair = 1
            try:
                trk = next((t for t in self.services.project.ctx.project.tracks if str(getattr(t, "id", "")) == str(tid)), None)
                pair = max(1, int(getattr(trk, "input_pair", 1) or 1)) if trk is not None else 1
            except Exception:
                pair = 1

            # Push per-track monitoring routes so input monitoring works immediately
            try:
                self._update_jack_monitor_routes()
            except Exception:
                pass

            try:
                self.services.jack.start_async(client_name="PyDAW")
                self.services.jack.start_recording(str(wav_path), stereo_pair=pair)
                self._recording_active = True
                self.statusBar().showMessage(f"Recording: läuft (Stereo {pair})…", 2000)
            except Exception as e:
                self._recording_active = False
                self.statusBar().showMessage(f"Recording Start fehlgeschlagen: {e}", 4000)
                try:
                    self.transport.btn_rec.blockSignals(True)
                    self.transport.btn_rec.setChecked(False)
                    self.transport.set_recording_visual(False)
                    self.transport.btn_rec.blockSignals(False)
                except Exception:
                    pass
            return

        if (not enabled) and self._recording_active:
            # stop recording and create clip
            try:
                self.services.jack.stop_recording()
            except Exception:
                pass
            self._recording_active = False

            try:
                from pathlib import Path
                wav_path = Path(str(self._recording_wav_path or ""))
                if wav_path.exists():
                    self.services.project.add_audio_clip_from_file_at(
                        track_id=str(self._recording_track_id or ""),
                        path=wav_path,
                        start_beats=float(self._recording_start_beat or 0.0),
                    )
                    self.statusBar().showMessage("Recording: Import läuft…", 2000)
                else:
                    self.statusBar().showMessage("Recording: WAV-Datei nicht gefunden.", 3000)
            except Exception as e:
                self.statusBar().showMessage(f"Recording Import fehlgeschlagen: {e}", 4000)

            self._recording_track_id = None
            self._recording_wav_path = None
            self._recording_start_beat = 0.0
            return


    def _update_jack_monitor_routes(self) -> None:
        """Push per-track monitoring routes into the JACK client.

        - Each audio/bus track can enable monitoring ("I")
        - Each track chooses an input stereo pair (Stereo 1..N)
        - Output pair is reserved for future submix routing (defaults to Out 1)
        """
        try:
            if str(getattr(self.services.audio_engine, "backend", "")) != "jack":
                return
        except Exception:
            return

        routes: list[tuple[int, int, float]] = []
        try:
            for t in self.services.project.ctx.project.tracks:
                if getattr(t, "kind", "") not in ("audio", "bus"):
                    continue
                if not bool(getattr(t, "monitor", False)):
                    continue
                ip = max(1, int(getattr(t, "input_pair", 1) or 1))
                op = max(1, int(getattr(t, "output_pair", 1) or 1))
                gain = float(getattr(t, "volume", 1.0) or 1.0)
                routes.append((ip, op, gain))
        except Exception:
            routes = []

        try:
            self.services.jack.set_monitor_routes(routes)
        except Exception:
            pass


