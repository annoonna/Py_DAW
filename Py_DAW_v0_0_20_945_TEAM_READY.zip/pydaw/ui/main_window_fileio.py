"""FileIO Mixin — Extracted from main_window.py (v0.0.20.906).

Contains all file I/O handlers: project new/open/save/save-as,
snapshots, audio/MIDI import, DAWproject import/export, SF2 loading,
MIDI export, audio export dialog.

Self-contained: only references self.services, self.transport,
self.toolbar_panel, self.arranger, self.statusBar(),
self._set_status, self._save_project_as, self._safe_project_call,
self._selected_track_id, self._on_ts_changed_from_ui,
self._save_ui_state_to_db — all provided by MainWindow.

~670 lines extracted.
"""

from __future__ import annotations

import logging
import traceback
from pathlib import Path

from PyQt6.QtWidgets import (
    QFileDialog, QInputDialog, QMessageBox,
)

log = logging.getLogger(__name__)


class FileIOMixin:
    """Project file I/O handlers — mixed into MainWindow."""

    def _new_project(self) -> None:
        self.services.project.new_project("Neues Projekt")
        proj = self.services.project.ctx.project
        self.transport.bpm.setValue(int(round(proj.bpm)))
        self._on_ts_changed_from_ui(getattr(proj, "time_signature", "4/4"))
        try:
            self.toolbar_panel.cmb_grid.blockSignals(True)
            self.toolbar_panel.cmb_grid.setCurrentText(getattr(proj, "snap_division", "1/16"))
        finally:
            self.toolbar_panel.cmb_grid.blockSignals(False)
        self.arranger.set_snap_division(getattr(proj, "snap_division", "1/16"))

    def _open_project(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Projekt öffnen",
            "",
            "Py DAW Projekt (*.pydaw.json *.json);;Alle Dateien (*)",
        )
        if not path:
            return
        self.services.project.open_project(Path(path))

    def _save_project(self) -> None:
        # v0.0.20.896: Persist UI state to DB before saving
        self._save_ui_state_to_db()
        ctx = self.services.project.ctx
        if ctx.path:
            self.services.project.save_project_as(ctx.path)
        else:
            self._save_project_as()

    def _save_project_as(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Projekt speichern",
            "",
            "Py DAW Projekt (*.pydaw.json);;JSON (*.json);;Alle Dateien (*)",
        )
        if not path:
            return
        self.services.project.save_project_as(Path(path))

    def _save_snapshot(self) -> None:
        """Speichert einen Projektstand (Snapshot) in <Projektordner>/stamps."""
        ctx = self.services.project.ctx
        if not ctx.path:
            self._set_status("Bitte zuerst das Projekt speichern (Datei → Speichern).")
            return

        label, ok = QInputDialog.getText(
            self,
            "Projektstand speichern",
            "Name/Notiz (optional):",
        )
        if not ok:
            return
        self.services.project.save_snapshot(str(label).strip())

    def _load_snapshot(self) -> None:
        """Lädt einen Projektstand (Snapshot) aus <Projektordner>/stamps."""
        ctx = self.services.project.ctx
        if not ctx.path:
            self._set_status("Kein Projektpfad vorhanden. Bitte zuerst ein Projekt speichern/öffnen.")
            return

        stamps_dir = ctx.path.parent / "stamps"
        stamps_dir.mkdir(parents=True, exist_ok=True)

        path, _ = QFileDialog.getOpenFileName(
            self,
            "Projektstand laden",
            str(stamps_dir),
            "Projektstände (*.pydaw.json *.json);;Alle Dateien (*)",
        )
        if not path:
            return
        self.services.project.load_snapshot(Path(path))

    def _import_audio(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Audio importieren",
            "",
            "Audio (*.wav *.flac *.ogg *.mp3 *.m4a *.aac *.mp4);;Alle Dateien (*)",
        )
        if not path:
            return
        # v0.0.20.735: Defer to avoid COM re-entrancy on Windows
        from PyQt6.QtCore import QTimer
        _path = Path(path)
        QTimer.singleShot(0, lambda: self._safe_project_call('import_audio', _path))

    def _import_audio_file_to_slot(self, file_path: str, track_id: str, start_beats: float, slot_key: str) -> None:
        """Import a specific audio file into the given track at the given position.

        Used by the clip-launcher overlay drop target.
        """
        p = Path(str(file_path))
        if not p.exists():
            self._set_status(f"Audio-Datei nicht gefunden: {p}", 4500)
            return
        try:
            self._safe_project_call(
                "add_audio_clip_from_file_at",
                str(track_id),
                p,
                float(start_beats),
                launcher_slot_key=str(slot_key) if slot_key else None,
                place_in_arranger=False,
            )
        except Exception as e:
            self._set_status(f"Import fehlgeschlagen: {e}", 5000)

    def _import_audio_at_position(self, track_id: str, start_beats: float) -> None:
        """Import an audio file and place it at (track_id, start_beats)."""
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Audio importieren",
            "",
            "Audio (*.wav *.flac *.ogg *.mp3 *.m4a *.aac *.mp4);;Alle Dateien (*)",
        )
        if not path:
            return
        # v0.0.20.735: Defer to avoid COM re-entrancy on Windows
        from PyQt6.QtCore import QTimer
        _path, _tid, _sb = Path(path), str(track_id), float(start_beats)
        QTimer.singleShot(0, lambda: self._safe_project_call(
            'import_audio_to_track_at', _path, track_id=_tid, start_beats=_sb,
        ))

    def _import_midi(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "MIDI importieren",
            "",
            "MIDI (*.mid *.midi);;Alle Dateien (*)",
        )
        if not path:
            return
        # v0.0.20.735: Defer the actual import to the next event-loop tick.
        from PyQt6.QtCore import QTimer
        _path = Path(path)
        QTimer.singleShot(0, lambda: self._safe_project_call(
            'import_midi',
            _path,
            track_id=self.services.project.active_track_id,
            start_beats=0.0,
        ))

    # --- DAWproject Export (v0.0.20.359) ---

    def _export_dawproject(self) -> None:
        """Export the current project as .dawproject via the safe snapshot exporter."""
        from PyQt6.QtWidgets import QProgressDialog
        from PyQt6.QtCore import Qt

        if bool(getattr(self, "_dawproject_export_running", False)):
            self._set_status("DAWproject Export läuft bereits …", 2500)
            return

        try:
            from pydaw.fileio import build_dawproject_export_request, DawProjectExportRunnable
            from pydaw.version import __version__
        except Exception as exc:
            QMessageBox.critical(
                self,
                "DAWproject Export Fehler",
                f"Exporter konnte nicht geladen werden:\n{exc}",
            )
            self._set_status(f"DAWproject Export initialisierung fehlgeschlagen: {exc}", 5000)
            return

        ctx = self.services.project.ctx
        project = getattr(ctx, "project", None)
        if project is None:
            self._set_status("Kein Projekt zum Exportieren geladen.", 3500)
            return

        default_dir = ctx.path.parent if getattr(ctx, "path", None) else Path.home()
        default_name = getattr(project, "name", "Py_DAW_Projekt") or "Py_DAW_Projekt"
        try:
            if getattr(ctx, "path", None):
                default_name = str(ctx.path.name)
                if default_name.endswith(".pydaw.json"):
                    default_name = default_name[:-11]
                else:
                    default_name = Path(default_name).stem
        except Exception:
            default_name = str(default_name)
        default_name = str(default_name).strip() or "Py_DAW_Projekt"
        default_target = default_dir / f"{default_name}.dawproject"

        path, _ = QFileDialog.getSaveFileName(
            self,
            "DAWproject exportieren",
            str(default_target),
            "DAWproject (*.dawproject);;Alle Dateien (*)",
        )
        if not path:
            return

        target_path = Path(path)
        project_root = ctx.path.parent if getattr(ctx, "path", None) else ctx.resolve_media_dir().parent

        request = build_dawproject_export_request(
            live_project=project,
            target_path=target_path,
            project_root=project_root,
            include_media=True,
            validate_archive=True,
            metadata={
                "title": str(getattr(project, "name", "Py_DAW Export") or "Py_DAW Export"),
                "comment": f"Exported by ChronoScaleStudio {__version__}",
            },
        )

        progress = QProgressDialog("DAWproject exportieren …", "", 0, 100, self)
        progress.setWindowTitle("DAWproject Export")
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(0)
        progress.setAutoClose(False)
        progress.setAutoReset(False)
        progress.setCancelButton(None)
        progress.setValue(0)
        progress.setLabelText(f"Erzeuge {target_path.name} …")
        progress.show()

        runnable = DawProjectExportRunnable(request)
        self._dawproject_export_running = True
        self._dawproject_export_dialog = progress
        self._dawproject_export_runnable = runnable

        def _cleanup() -> None:
            self._dawproject_export_running = False
            self._dawproject_export_runnable = None
            self._dawproject_export_dialog = None

        def _on_progress(percent: int, message: str) -> None:
            try:
                progress.setValue(int(percent))
                progress.setLabelText(str(message))
            except Exception:
                pass

        def _on_finished(result) -> None:
            try:
                progress.setValue(100)
                progress.close()
            except Exception:
                pass
            _cleanup()
            warnings = list(getattr(result, "warnings", []) or [])
            summary_lines = [
                f"Ziel: {Path(getattr(result, 'output_path', target_path)).name}",
                f"Spuren exportiert: {getattr(result, 'tracks_exported', 0)}",
                f"Clips exportiert: {getattr(result, 'clips_exported', 0)}",
                f"Noten exportiert: {getattr(result, 'notes_exported', 0)}",
                f"Audio-Dateien eingebettet: {getattr(result, 'audio_files_embedded', 0)}",
                f"Plugin-States eingebettet: {getattr(result, 'plugin_states_embedded', 0)}",
            ]
            if warnings:
                summary_lines.append("")
                summary_lines.append(f"Warnungen ({len(warnings)}):")
                for warning in warnings[:5]:
                    summary_lines.append(f"  • {warning}")
                if len(warnings) > 5:
                    summary_lines.append(f"  … und {len(warnings) - 5} weitere")
            QMessageBox.information(
                self,
                "DAWproject Export abgeschlossen",
                "\n".join(summary_lines),
            )
            self._set_status(f"DAWproject exportiert: {Path(getattr(result, 'output_path', target_path)).name}", 5000)

        def _on_error(message: str) -> None:
            try:
                progress.close()
            except Exception:
                pass
            _cleanup()
            QMessageBox.critical(
                self,
                "DAWproject Export Fehler",
                f"Export fehlgeschlagen:\n{message}",
            )
            self._set_status(f"DAWproject Export fehlgeschlagen: {message}", 5000)

        runnable.signals.progress.connect(_on_progress)
        runnable.signals.finished.connect(_on_finished)
        runnable.signals.error.connect(_on_error)
        self.services.threadpool.pool.start(runnable)

    # --- DAWproject Import (v0.0.20.88) ---

    def _import_dawproject(self) -> None:
        """Import a .dawproject file (Bitwig/Studio One/Cubase exchange format)."""
        from PyQt6.QtWidgets import QProgressDialog, QCheckBox
        from PyQt6.QtCore import Qt

        path, _ = QFileDialog.getOpenFileName(
            self,
            "DAWproject importieren",
            "",
            "DAWproject (*.dawproject);;Alle Dateien (*)",
        )
        if not path:
            return

        dawproject_path = Path(path)

        # Ask user about transport settings
        update_transport = True
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("DAWproject Import")
        msg_box.setText(
            f"DAWproject importieren:\n{dawproject_path.name}\n\n"
            "Soll BPM und Taktart aus dem Projekt übernommen werden?"
        )
        msg_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        msg_box.setDefaultButton(QMessageBox.StandardButton.Yes)
        reply = msg_box.exec()
        update_transport = (reply == QMessageBox.StandardButton.Yes)

        # Progress dialog
        progress = QProgressDialog("DAWproject importieren…", "Abbrechen", 0, 100, self)
        progress.setWindowTitle("DAWproject Import")
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(0)
        progress.setValue(0)

        def on_progress(pct: int, msg: str):
            if progress.wasCanceled():
                return
            progress.setValue(pct)
            progress.setLabelText(msg)
            # Process events to keep UI responsive
            from PyQt6.QtWidgets import QApplication
            QApplication.processEvents()

        try:
            from pydaw.fileio.dawproject_importer import import_dawproject

            project = self.services.project.ctx.project
            media_dir = self.services.project.ctx.resolve_media_dir()

            result = import_dawproject(
                dawproject_path=dawproject_path,
                project=project,
                media_dir=media_dir,
                update_transport=update_transport,
                progress_cb=on_progress,
            )

            progress.close()

            # Trigger UI refresh
            self.services.project._emit_updated()

            # Summary dialog
            summary_lines = [
                f"Import aus: {result.source_app or 'Unbekannt'}",
                f"Projekt: {result.project_name}",
                "",
                f"Spuren erstellt: {result.tracks_created}",
                f"Clips erstellt: {result.clips_created}",
                f"MIDI-Noten importiert: {result.notes_imported}",
                f"Audio-Dateien kopiert: {result.audio_files_copied}",
            ]
            if result.warnings:
                summary_lines.append("")
                summary_lines.append(f"Warnungen ({len(result.warnings)}):")
                for w in result.warnings[:5]:
                    summary_lines.append(f"  • {w}")
                if len(result.warnings) > 5:
                    summary_lines.append(f"  … und {len(result.warnings) - 5} weitere")

            QMessageBox.information(
                self,
                "DAWproject Import abgeschlossen",
                "\n".join(summary_lines),
            )

            self._set_status(
                f"DAWproject Import: {result.tracks_created} Spuren, "
                f"{result.clips_created} Clips, {result.notes_imported} Noten",
                5000,
            )

        except Exception as e:
            progress.close()
            log.error("DAWproject import failed: %s", e, exc_info=True)
            QMessageBox.critical(
                self,
                "DAWproject Import Fehler",
                f"Import fehlgeschlagen:\n{e}",
            )
            self._set_status(f"DAWproject Import fehlgeschlagen: {e}", 5000)

    def load_sf2_for_selected_track(self) -> None:
        """Load a SoundFont (SF2) for an INSTRUMENT track (with selection dialog).

        FIXED v0.0.19.7.3: Wenn mehrere Instrument Tracks existieren,
        zeigt Dialog zur Track-Auswahl!
        """
        # Get all instrument tracks
        tracks = self.services.project.ctx.project.tracks
        instrument_tracks = [t for t in tracks if getattr(t, "kind", "") == "instrument"]

        if not instrument_tracks:
            self._set_status("Keine Instrument-Tracks vorhanden. Bitte zuerst einen erstellen.")
            return

        # If only one instrument track, use it directly
        if len(instrument_tracks) == 1:
            tid = instrument_tracks[0].id
            trk = instrument_tracks[0]
        else:
            # Multiple instrument tracks - show selection dialog
            # FIXED v0.0.19.7.6: Show only track names (no IDs)
            track_names = []
            name_count: dict[str, int] = {}  # Track duplicate names

            for t in instrument_tracks:
                name = getattr(t, 'name', 'Instrument Track')

                # If duplicate name, add number suffix
                if name in name_count:
                    name_count[name] += 1
                    display_name = f"{name} ({name_count[name]})"
                else:
                    name_count[name] = 1
                    display_name = name

                track_names.append(display_name)

            # Try to find currently selected track as default
            current_tid = getattr(self.services.project, "active_track_id", "") or \
                         getattr(self.services.project, "selected_track_id", "") or ""
            default_idx = 0
            for i, t in enumerate(instrument_tracks):
                if t.id == current_tid:
                    default_idx = i
                    break

            selected_name, ok = QInputDialog.getItem(
                self,
                "Track auswählen",
                "Für welchen Instrument-Track SF2 laden?",
                track_names,
                default_idx,
                False
            )

            if not ok or not selected_name:
                return

            # Find selected track
            selected_idx = track_names.index(selected_name)
            trk = instrument_tracks[selected_idx]
            tid = trk.id

        # File picker for SF2
        path, _ = QFileDialog.getOpenFileName(
            self,
            "SoundFont (SF2) auswählen",
            "",
            "SoundFont (*.sf2);;Alle Dateien (*)"
        )
        if not path:
            return

        # Bank and Preset selection
        bank, ok1 = QInputDialog.getInt(
            self,
            "Bank",
            "SoundFont Bank (CC0):",
            int(getattr(trk, "sf2_bank", 0)),
            0, 127, 1
        )
        if not ok1:
            return

        preset, ok2 = QInputDialog.getInt(
            self,
            "Preset",
            "Program/Preset (0-127):",
            int(getattr(trk, "sf2_preset", 0)),
            0, 127, 1
        )
        if not ok2:
            return

        # Apply SF2 to track
        self.services.project.set_track_soundfont(tid, path, bank=bank, preset=preset)

        # v0.0.20.46: Set plugin_type for Pro-DAW-Style routing
        try:
            track = self.services.project.ctx.project.tracks_by_id().get(tid)
            if track:
                track.plugin_type = "sf2"
                self.services.project.mark_dirty()
        except Exception:
            pass

        self._set_status(f"SF2 geladen auf Track: {getattr(trk, 'name', 'Instrument')}")

    def _export_audio_placeholder(self) -> None:
        """FIXED v0.0.19.7.16: Professional Audio Export Dialog (Pro-DAW-Style!)"""
        from .audio_export_dialog import AudioExportDialog

        dialog = AudioExportDialog(self.services.project, self)
        dialog.exec()

    def _export_midi_clip(self) -> None:
        """FIXED v0.0.19.7.15: Export selected MIDI clip to .mid file."""
        from pydaw.audio.midi_export import export_midi_clip

        # Get selected clip from arranger
        if not hasattr(self.arranger, 'canvas') or not hasattr(self.arranger.canvas, 'selected_clip_id'):
            self.statusBar().showMessage("Kein Clip ausgewählt!", 3000)
            return

        clip_id = self.arranger.canvas.selected_clip_id
        if not clip_id:
            self.statusBar().showMessage("Bitte MIDI Clip auswählen!", 3000)
            return

        # Get clip
        clip = next((c for c in self.services.project.ctx.project.clips if c.id == clip_id), None)
        if not clip or getattr(clip, "kind", "") != "midi":
            self.statusBar().showMessage("Nur MIDI Clips können exportiert werden!", 3000)
            return

        # Get notes
        notes = self.services.project.ctx.project.midi_notes.get(clip_id, [])
        if not notes:
            self.statusBar().showMessage("Clip hat keine Noten zum Exportieren!", 3000)
            return

        # Ask for save location
        clip_name = getattr(clip, "name", "midi_clip")
        default_filename = f"{clip_name}.mid"

        filepath, _ = QFileDialog.getSaveFileName(
            self,
            "MIDI Clip exportieren",
            default_filename,
            "MIDI Files (*.mid);;All Files (*)"
        )

        if not filepath:
            return

        # Ensure .mid extension
        if not filepath.lower().endswith('.mid'):
            filepath += '.mid'

        # Export
        bpm = float(getattr(self.services.project.ctx.project, "bpm", 120.0))
        success = export_midi_clip(clip, notes, Path(filepath), bpm)

        if success:
            self.statusBar().showMessage(f"MIDI exportiert: {Path(filepath).name}", 3000)
        else:
            self.statusBar().showMessage("MIDI Export fehlgeschlagen!", 3000)

    def _export_midi_track(self) -> None:
        """FIXED v0.0.19.7.15: Export all MIDI clips from selected track to .mid file."""
        from pydaw.audio.midi_export import export_midi_track

        # Get selected track
        track_id = self._selected_track_id()
        if not track_id:
            self.statusBar().showMessage("Bitte Track auswählen!", 3000)
            return

        track = next((t for t in self.services.project.ctx.project.tracks if t.id == track_id), None)
        if not track:
            self.statusBar().showMessage("Track nicht gefunden!", 3000)
            return

        # Get all MIDI clips for this track
        clips = [c for c in self.services.project.ctx.project.clips
                if getattr(c, 'track_id', '') == track_id and getattr(c, 'kind', '') == 'midi']

        if not clips:
            self.statusBar().showMessage("Track hat keine MIDI Clips zum Exportieren!", 3000)
            return

        # Ask for save location
        track_name = getattr(track, "name", "track")
        default_filename = f"{track_name}.mid"

        filepath, _ = QFileDialog.getSaveFileName(
            self,
            "MIDI Track exportieren",
            default_filename,
            "MIDI Files (*.mid);;All Files (*)"
        )

        if not filepath:
            return

        # Ensure .mid extension
        if not filepath.lower().endswith('.mid'):
            filepath += '.mid'

        # Export
        bpm = float(getattr(self.services.project.ctx.project, "bpm", 120.0))
        midi_notes_map = self.services.project.ctx.project.midi_notes
        success = export_midi_track(track, self.services.project.ctx.project.clips, midi_notes_map, Path(filepath), bpm)

        if success:
            self.statusBar().showMessage(f"Track exportiert: {Path(filepath).name}", 3000)
        else:
            self.statusBar().showMessage("MIDI Track Export fehlgeschlagen!", 3000)
