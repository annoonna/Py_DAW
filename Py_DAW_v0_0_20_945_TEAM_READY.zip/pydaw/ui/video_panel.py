"""video_panel.py — Video-Spur Panel (v0.0.20.918).

Complete video track panel with:
- VO1: Video preview (QLabel + QPixmap) + transport controls
- VO2: Frame extraction via ffmpeg pipe → QImage → QPixmap
- VO3: Transport sync (playhead → frame update, SMPTE display)
- VO4: Chapter editor UI (add/remove/export)
- VO5: Video+Audio export (ffmpeg merge)

Usage:
    panel = VideoPanel(services=self.services, parent=self)
    dock = QDockWidget("🎬 Video", self)
    dock.setWidget(panel)
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import threading
import time
from typing import Any, Dict, List, Optional

from PyQt6.QtCore import Qt, pyqtSignal, QTimer, QSize
from PyQt6.QtGui import QImage, QPixmap
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QListWidget, QGroupBox, QSpinBox, QDoubleSpinBox,
    QLineEdit, QMessageBox, QFileDialog, QScrollArea, QFrame,
    QSizePolicy, QSlider,
)

log = logging.getLogger(__name__)

# Preview size
_PREVIEW_W = 480
_PREVIEW_H = 270


# ══════════════════════════════════════════════════════════════
# VO2: Frame extraction via ffmpeg
# ══════════════════════════════════════════════════════════════

def _extract_frame_ffmpeg(video_path: str, time_seconds: float,
                          width: int = _PREVIEW_W,
                          height: int = _PREVIEW_H) -> Optional[QImage]:
    """Extract a single frame from a video file using ffmpeg.

    Pipes raw RGB24 data to stdout — no temp files needed.
    Returns QImage or None on failure.
    """
    if not video_path or not os.path.isfile(video_path):
        return None
    try:
        cmd = [
            "ffmpeg", "-ss", f"{max(0, time_seconds):.3f}",
            "-i", video_path,
            "-vframes", "1",
            "-vf", f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
                   f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:color=black",
            "-pix_fmt", "rgb24",
            "-f", "rawvideo",
            "-v", "quiet",
            "pipe:1",
        ]
        # v0.0.20.933: Lower priority so ffmpeg doesn't steal from audio/GUI
        try:
            from pydaw.services.perf_service import nice_subprocess_args
            cmd = nice_subprocess_args(cmd)
        except Exception:
            pass
        result = subprocess.run(cmd, capture_output=True, timeout=5)
        if result.returncode != 0 or not result.stdout:
            return None

        expected = width * height * 3
        data = result.stdout[:expected]
        if len(data) < expected:
            return None

        img = QImage(data, width, height, width * 3, QImage.Format.Format_RGB888)
        # Must copy — data buffer goes out of scope
        return img.copy()
    except Exception as e:
        log.debug("[VideoPanel] frame extraction failed: %s", e)
        return None


def _generate_thumbnail(video_path: str, time_seconds: float = 0.5,
                        width: int = 160, height: int = 90) -> Optional[QPixmap]:
    """Generate a small thumbnail for the video."""
    img = _extract_frame_ffmpeg(video_path, time_seconds, width, height)
    if img is None:
        return None
    return QPixmap.fromImage(img)


# ══════════════════════════════════════════════════════════════
# Video Panel Widget
# ══════════════════════════════════════════════════════════════

class VideoPanel(QWidget):
    """Full video track panel (v0.0.20.918).

    Sections:
    1. Video Preview (QLabel with frame from ffmpeg)
    2. Transport / SMPTE display
    3. Video Info
    4. Chapter Markers
    5. Export
    """

    status = pyqtSignal(str)

    def __init__(self, services=None, parent=None):
        super().__init__(parent)
        self._services = services
        self._video_service = None
        self._video_path = ""
        self._video_duration = 0.0
        self._video_fps = 24.0
        self._last_frame_sec = -1.0
        self._is_syncing = False

        # v0.0.20.929: Async frame extraction (no UI freeze)
        self._pending_frame: Optional[QImage] = None
        self._pending_lock = threading.Lock()
        self._bg_thread: Optional[threading.Thread] = None

        # Frame update timer — 2 fps is plenty for preview sync
        # (v0.0.20.929: was 125ms/8fps — caused UI freeze with sync ffmpeg)
        self._frame_timer = QTimer(self)
        self._frame_timer.setInterval(500)  # 2 Hz
        self._frame_timer.timeout.connect(self._on_frame_tick)

        self._init_service()
        self._build_ui()

    def _init_service(self) -> None:
        try:
            from pydaw.services.video_track import VideoTrackService
            transport = None
            if self._services:
                transport = (getattr(self._services, 'transport', None)
                             or getattr(self._services, 'transport_service', None))
            self._video_service = VideoTrackService(transport=transport, parent=self)
            self._video_service.status.connect(self._on_status)
        except Exception as e:
            log.warning("[VideoPanel] Service init failed: %s", e)

    # ──────────────────────────────────────────────────────────
    # UI Build
    # ──────────────────────────────────────────────────────────

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(8)

        # Title
        title = QLabel("🎬 Video-Spur")
        title.setStyleSheet("font-size: 14px; font-weight: bold; color: #e0e0e0;")
        root.addWidget(title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        content = QWidget()
        content_lay = QVBoxLayout(content)
        content_lay.setContentsMargins(0, 0, 0, 0)
        content_lay.setSpacing(8)

        # ── Section 1: Preview ──
        self._build_preview_section(content_lay)

        # ── Section 2: Transport / SMPTE ──
        self._build_transport_section(content_lay)

        # ── Section 3: Video Info ──
        self._build_info_section(content_lay)

        # ── Section 4: Chapters ──
        self._build_chapter_section(content_lay)

        # ── Section 5: Export ──
        self._build_export_section(content_lay)

        content_lay.addStretch(1)
        scroll.setWidget(content)
        root.addWidget(scroll, 1)

    def _build_preview_section(self, parent_lay) -> None:
        grp = QGroupBox("🖥 Preview")
        grp.setStyleSheet(self._grp_style())
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        # Preview label (shows video frame)
        self._lbl_preview = QLabel("Kein Video geladen")
        self._lbl_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._lbl_preview.setFixedSize(_PREVIEW_W, _PREVIEW_H)
        self._lbl_preview.setStyleSheet(
            "QLabel { background: #0a0a14; color: #666; border: 1px solid #333; "
            "border-radius: 4px; font-size: 12px; }"
        )
        lay.addWidget(self._lbl_preview, 0, Qt.AlignmentFlag.AlignCenter)

        # Load / Scrub controls
        ctrl_row = QHBoxLayout()
        self._btn_load = QPushButton("📂 Video laden")
        self._btn_load.setStyleSheet(self._btn_style("#2a3a4a", "#5588bb"))
        self._btn_load.clicked.connect(self._load_video)
        ctrl_row.addWidget(self._btn_load)

        self._btn_sync = QPushButton("▶ Sync starten")
        self._btn_sync.setStyleSheet(self._btn_style("#2a3a2a", "#4a804a"))
        self._btn_sync.setEnabled(False)
        self._btn_sync.clicked.connect(self._toggle_sync)
        ctrl_row.addWidget(self._btn_sync)
        ctrl_row.addStretch(1)
        lay.addLayout(ctrl_row)

        # Scrub slider
        scrub_row = QHBoxLayout()
        scrub_row.addWidget(QLabel("Scrub:"))
        self._sld_scrub = QSlider(Qt.Orientation.Horizontal)
        self._sld_scrub.setRange(0, 1000)
        self._sld_scrub.setValue(0)
        self._sld_scrub.setEnabled(False)
        self._sld_scrub.valueChanged.connect(self._on_scrub)
        scrub_row.addWidget(self._sld_scrub, 1)
        self._lbl_scrub_time = QLabel("00:00")
        self._lbl_scrub_time.setStyleSheet("color: #aaa; font-size: 11px; min-width: 40px;")
        scrub_row.addWidget(self._lbl_scrub_time)
        lay.addLayout(scrub_row)

        parent_lay.addWidget(grp)

    def _build_transport_section(self, parent_lay) -> None:
        row = QHBoxLayout()

        # SMPTE display
        self._lbl_smpte = QLabel("00:00:00:00")
        self._lbl_smpte.setStyleSheet(
            "font-family: 'Courier New', monospace; font-size: 18px; "
            "font-weight: bold; color: #4fc3f7; background: #0a0a14; "
            "border: 1px solid #333; border-radius: 4px; padding: 4px 8px;"
        )
        self._lbl_smpte.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._lbl_smpte.setFixedWidth(180)
        row.addWidget(self._lbl_smpte)

        # FPS selector
        row.addWidget(QLabel("FPS:"))
        self._cmb_fps = QComboBox()
        self._cmb_fps.addItems(["23.976", "24", "25", "29.97", "30", "50", "59.94", "60"])
        self._cmb_fps.setCurrentText("24")
        self._cmb_fps.setFixedWidth(70)
        self._cmb_fps.currentTextChanged.connect(self._on_fps_changed)
        row.addWidget(self._cmb_fps)

        # Offset
        row.addWidget(QLabel("Offset:"))
        self._spn_offset = QDoubleSpinBox()
        self._spn_offset.setRange(-3600.0, 3600.0)
        self._spn_offset.setValue(0.0)
        self._spn_offset.setSuffix(" s")
        self._spn_offset.setDecimals(3)
        self._spn_offset.setFixedWidth(90)
        self._spn_offset.valueChanged.connect(self._on_offset_changed)
        row.addWidget(self._spn_offset)

        row.addStretch(1)
        parent_lay.addLayout(row)

    def _build_info_section(self, parent_lay) -> None:
        self._lbl_info = QLabel("Kein Video geladen")
        self._lbl_info.setStyleSheet("color: #9aa0a6; font-size: 11px;")
        self._lbl_info.setWordWrap(True)
        parent_lay.addWidget(self._lbl_info)

    def _build_chapter_section(self, parent_lay) -> None:
        grp = QGroupBox("📑 Video-Kapitel")
        grp.setStyleSheet(self._grp_style())
        lay = QVBoxLayout(grp)
        lay.setSpacing(6)

        self._lst_chapters = QListWidget()
        self._lst_chapters.setMaximumHeight(120)
        self._lst_chapters.setStyleSheet(
            "QListWidget { background: #1a1a2e; color: #d0d0d8; border: 1px solid #333; }"
        )
        lay.addWidget(self._lst_chapters)

        add_row = QHBoxLayout()
        add_row.addWidget(QLabel("Name:"))
        self._txt_chapter = QLineEdit()
        self._txt_chapter.setPlaceholderText("z.B. Intro, Interview, Credits")
        add_row.addWidget(self._txt_chapter, 1)

        add_row.addWidget(QLabel("bei:"))
        self._spn_ch_min = QSpinBox()
        self._spn_ch_min.setRange(0, 999)
        self._spn_ch_min.setSuffix("m")
        self._spn_ch_min.setFixedWidth(55)
        add_row.addWidget(self._spn_ch_min)
        self._spn_ch_sec = QSpinBox()
        self._spn_ch_sec.setRange(0, 59)
        self._spn_ch_sec.setSuffix("s")
        self._spn_ch_sec.setFixedWidth(50)
        add_row.addWidget(self._spn_ch_sec)
        lay.addLayout(add_row)

        btn_row = QHBoxLayout()
        btn_add = QPushButton("➕")
        btn_add.setFixedWidth(36)
        btn_add.clicked.connect(self._add_chapter)
        btn_row.addWidget(btn_add)
        btn_rm = QPushButton("➖")
        btn_rm.setFixedWidth(36)
        btn_rm.clicked.connect(self._remove_chapter)
        btn_row.addWidget(btn_rm)
        btn_pos = QPushButton("⏱ Position")
        btn_pos.setToolTip("Aktuelle Playhead-Position als Kapitelzeit")
        btn_pos.clicked.connect(self._chapter_from_playhead)
        btn_row.addWidget(btn_pos)
        btn_row.addStretch(1)
        lay.addLayout(btn_row)

        parent_lay.addWidget(grp)

    def _build_export_section(self, parent_lay) -> None:
        grp = QGroupBox("💾 Export")
        grp.setStyleSheet(self._grp_style())
        lay = QVBoxLayout(grp)
        lay.setSpacing(6)

        row = QHBoxLayout()
        self._btn_export = QPushButton("🎬 Video + Audio exportieren")
        self._btn_export.setStyleSheet(self._btn_style("#2a2a3a", "#5555aa"))
        self._btn_export.setEnabled(False)
        self._btn_export.clicked.connect(self._export_video)
        row.addWidget(self._btn_export)
        row.addStretch(1)
        lay.addLayout(row)

        self._lbl_export_status = QLabel("")
        self._lbl_export_status.setStyleSheet("color: #9aa0a6; font-size: 11px;")
        lay.addWidget(self._lbl_export_status)

        parent_lay.addWidget(grp)

    # ──────────────────────────────────────────────────────────
    # Style helpers
    # ──────────────────────────────────────────────────────────

    @staticmethod
    def _grp_style() -> str:
        return (
            "QGroupBox { font-weight: bold; color: #c8c8d4; border: 1px solid #444; "
            "border-radius: 6px; margin-top: 8px; padding-top: 16px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }"
        )

    @staticmethod
    def _btn_style(bg: str, border: str) -> str:
        return (
            f"QPushButton {{ background: {bg}; border: 1px solid {border}; "
            f"border-radius: 4px; color: #d0d0d8; font-size: 12px; padding: 6px 12px; }}"
            f"QPushButton:hover {{ background: {bg.replace('2a', '3a')}; }}"
            f"QPushButton:disabled {{ color: #666; border-color: #444; }}"
        )

    # ──────────────────────────────────────────────────────────
    # Video Load
    # ──────────────────────────────────────────────────────────

    def _load_video(self) -> None:
        try:
            path, _ = QFileDialog.getOpenFileName(
                self, "Video laden", "",
                "Video (*.mp4 *.mkv *.avi *.mov *.webm);;Alle (*)",
            )
            if not path:
                return
            self._do_load_video(path)
        except Exception as e:
            log.error("[VideoPanel] load failed: %s", e)

    def _do_load_video(self, path: str) -> None:
        """Load video and show first frame."""
        try:
            from pydaw.services.video_track import is_ffmpeg_available
            if not is_ffmpeg_available():
                QMessageBox.warning(self, "Video",
                    "ffmpeg/ffprobe nicht gefunden.\n\n"
                    "Installieren mit: sudo apt install ffmpeg")
                return

            if not self._video_service:
                self._init_service()

            ok = self._video_service.load_video(path) if self._video_service else False
            if not ok:
                self._lbl_info.setText(f"❌ Video konnte nicht geladen werden: {path}")
                return

            info = self._video_service.video_info
            self._video_path = path
            self._video_duration = info.duration_seconds if info else 0.0
            self._video_fps = info.fps if info and info.fps > 0 else 24.0

            # Update FPS combo
            fps_str = f"{self._video_fps:.3f}".rstrip('0').rstrip('.')
            idx = self._cmb_fps.findText(fps_str)
            if idx >= 0:
                self._cmb_fps.setCurrentIndex(idx)

            # Show info
            if info:
                self._lbl_info.setText(
                    f"📁 {os.path.basename(path)}\n"
                    f"🎞 {info.width}×{info.height} @ {info.fps:.2f} fps, "
                    f"{info.codec}, {info.duration_seconds:.1f}s\n"
                    f"💾 {info.file_size_mb:.1f} MB"
                    + (f" | 🔊 Audio: {info.audio_channels}ch @ {info.audio_sample_rate}Hz"
                       if info.has_audio else " | 🔇 Kein Audio")
                )

            # Enable controls
            self._btn_sync.setEnabled(True)
            self._btn_export.setEnabled(True)
            self._sld_scrub.setEnabled(True)

            # v0.0.20.929: Show first frame asynchronously (don't block UI)
            self._lbl_preview.setText("⏳ Lade erstes Frame…")
            self._request_frame_async(0.5)
            # One-shot timer to apply the async result
            QTimer.singleShot(800, self._apply_pending_frame)
            QTimer.singleShot(2000, self._apply_pending_frame)  # retry

        except Exception as e:
            self._lbl_info.setText(f"❌ Fehler: {e}")
            log.error("[VideoPanel] load: %s", e, exc_info=True)

    def _show_frame_at(self, seconds: float) -> None:
        """Extract and display a single frame (SYNC — for manual scrub/initial load).

        v0.0.20.929: Only used for one-shot loads (scrub, initial frame).
        During sync playback, _request_frame_async() is used instead.
        """
        if not self._video_path:
            return
        try:
            img = _extract_frame_ffmpeg(self._video_path, seconds,
                                         _PREVIEW_W, _PREVIEW_H)
            if img is not None:
                pix = QPixmap.fromImage(img)
                self._lbl_preview.setPixmap(pix)
                self._last_frame_sec = seconds
            else:
                self._lbl_preview.setText("⚠ Frame konnte nicht geladen werden")
        except Exception as e:
            log.debug("[VideoPanel] show_frame: %s", e)

    # v0.0.20.929: Async frame extraction (prevents UI freeze)

    def _request_frame_async(self, seconds: float) -> None:
        """Request frame extraction in background thread (non-blocking)."""
        if not self._video_path:
            return
        # Don't start a new extraction if one is already running
        if self._bg_thread is not None and self._bg_thread.is_alive():
            return
        # Skip if frame hasn't changed significantly
        if abs(seconds - self._last_frame_sec) < 0.3:
            return

        video_path = self._video_path
        self._bg_thread = threading.Thread(
            target=self._bg_extract_frame,
            args=(video_path, seconds),
            daemon=True,
        )
        self._bg_thread.start()

    def _bg_extract_frame(self, video_path: str, seconds: float) -> None:
        """Background worker — extracts frame via ffmpeg (runs in thread)."""
        try:
            img = _extract_frame_ffmpeg(video_path, seconds, _PREVIEW_W, _PREVIEW_H)
            with self._pending_lock:
                self._pending_frame = img
                self._pending_frame_sec = seconds
        except Exception:
            pass

    def _apply_pending_frame(self) -> None:
        """Apply pending frame from background thread (called from timer on main thread)."""
        img = None
        sec = -1.0
        with self._pending_lock:
            if self._pending_frame is not None:
                img = self._pending_frame
                sec = getattr(self, '_pending_frame_sec', -1.0)
                self._pending_frame = None
        if img is not None:
            try:
                pix = QPixmap.fromImage(img)
                self._lbl_preview.setPixmap(pix)
                self._last_frame_sec = sec
            except Exception:
                pass

    # ──────────────────────────────────────────────────────────
    # VO3: Transport Sync
    # ──────────────────────────────────────────────────────────

    def _toggle_sync(self) -> None:
        """Toggle frame sync with transport."""
        if self._is_syncing:
            self._stop_sync()
        else:
            self._start_sync()

    def _start_sync(self) -> None:
        try:
            self._is_syncing = True
            self._frame_timer.start()
            self._btn_sync.setText("⏹ Sync stoppen")
            self._btn_sync.setStyleSheet(self._btn_style("#3a2a2a", "#804a4a"))

            # Connect to transport playhead signal
            transport = self._get_transport()
            if transport and hasattr(transport, 'playhead_changed'):
                try:
                    transport.playhead_changed.connect(self._on_playhead_changed)
                except Exception:
                    pass
        except Exception:
            pass

    def _stop_sync(self) -> None:
        try:
            self._is_syncing = False
            self._frame_timer.stop()
            self._btn_sync.setText("▶ Sync starten")
            self._btn_sync.setStyleSheet(self._btn_style("#2a3a2a", "#4a804a"))

            transport = self._get_transport()
            if transport and hasattr(transport, 'playhead_changed'):
                try:
                    transport.playhead_changed.disconnect(self._on_playhead_changed)
                except Exception:
                    pass
        except Exception:
            pass

    def _get_transport(self):
        """Get transport service."""
        try:
            if self._services:
                return (getattr(self._services, 'transport', None)
                        or getattr(self._services, 'transport_service', None))
        except Exception:
            pass
        return None

    def _get_bpm(self) -> float:
        try:
            transport = self._get_transport()
            if transport:
                return float(getattr(transport, 'bpm', 120.0) or 120.0)
            ps = getattr(self._services, 'project', None) if self._services else None
            if ps is None:
                ps = getattr(self._services, 'project_service', None) if self._services else None
            if ps:
                proj = getattr(ps, 'project', None)
                if proj is None:
                    ctx = getattr(ps, 'ctx', None)
                    proj = getattr(ctx, 'project', None) if ctx else None
                if proj:
                    return float(getattr(proj, 'bpm', 120.0) or 120.0)
        except Exception:
            pass
        return 120.0

    def _on_playhead_changed(self, beat: float) -> None:
        """Called when transport playhead moves — update SMPTE display."""
        try:
            bpm = self._get_bpm()
            offset = self._spn_offset.value()
            seconds = (beat / bpm) * 60.0 + offset

            # Update SMPTE
            fps = float(self._cmb_fps.currentText() or 24)
            from pydaw.services.video_track import SmpteTimecode
            tc = SmpteTimecode.from_seconds(max(0, seconds), fps)
            self._lbl_smpte.setText(str(tc))
        except Exception:
            pass

    def _on_frame_tick(self) -> None:
        """Timer tick — extract frame at current transport position.

        v0.0.20.929: Uses async frame extraction — never blocks UI thread.
        1. Apply any pending frame from background thread
        2. Request next frame extraction (non-blocking)
        """
        # Always check for pending frames from background thread
        self._apply_pending_frame()

        if not self._video_path or not self._is_syncing:
            return
        try:
            transport = self._get_transport()
            if not transport:
                return

            is_playing = bool(getattr(transport, 'playing', False))
            if not is_playing:
                return

            beat = float(getattr(transport, 'current_beat', 0.0))
            bpm = self._get_bpm()
            offset = self._spn_offset.value()
            seconds = (beat / bpm) * 60.0 + offset

            if seconds < 0 or seconds > self._video_duration:
                return

            # Request async frame extraction (non-blocking)
            self._request_frame_async(seconds)

            # Update SMPTE (lightweight, always on main thread)
            fps = float(self._cmb_fps.currentText() or 24)
            from pydaw.services.video_track import SmpteTimecode
            tc = SmpteTimecode.from_seconds(max(0, seconds), fps)
            self._lbl_smpte.setText(str(tc))

        except Exception:
            pass

    # ──────────────────────────────────────────────────────────
    # Scrub slider
    # ──────────────────────────────────────────────────────────

    def _on_scrub(self, value: int) -> None:
        """Manual scrub — show frame at slider position.

        v0.0.20.929: Uses async extraction to prevent UI freeze during drag.
        """
        if not self._video_path or self._video_duration <= 0:
            return
        try:
            seconds = (value / 1000.0) * self._video_duration
            # Async frame extraction (non-blocking)
            self._request_frame_async(seconds)
            # Lightweight UI updates (always on main thread)
            m = int(seconds) // 60
            s = int(seconds) % 60
            self._lbl_scrub_time.setText(f"{m:02d}:{s:02d}")
            fps = float(self._cmb_fps.currentText() or 24)
            from pydaw.services.video_track import SmpteTimecode
            tc = SmpteTimecode.from_seconds(max(0, seconds), fps)
            self._lbl_smpte.setText(str(tc))
            # Apply result on next timer tick or one-shot
            QTimer.singleShot(600, self._apply_pending_frame)
        except Exception:
            pass

    # ──────────────────────────────────────────────────────────
    # FPS / Offset
    # ──────────────────────────────────────────────────────────

    def _on_fps_changed(self, text: str) -> None:
        try:
            fps = float(text or 24)
            if self._video_service:
                self._video_service.set_smpte_framerate(fps)
        except Exception:
            pass

    def _on_offset_changed(self, value: float) -> None:
        try:
            if self._video_service:
                self._video_service.set_offset(value)
        except Exception:
            pass

    # ──────────────────────────────────────────────────────────
    # VO4: Chapters
    # ──────────────────────────────────────────────────────────

    def _add_chapter(self) -> None:
        try:
            name = self._txt_chapter.text().strip() or f"Kapitel {self._lst_chapters.count() + 1}"
            start_sec = self._spn_ch_min.value() * 60 + self._spn_ch_sec.value()

            if self._video_service:
                from pydaw.services.video_track import VideoChapter
                self._video_service.add_chapter(VideoChapter(
                    name=name, start_seconds=float(start_sec)))
                self._refresh_chapters()
                self._txt_chapter.clear()
        except Exception as e:
            log.error("[VideoPanel] add_chapter: %s", e)

    def _remove_chapter(self) -> None:
        try:
            row = self._lst_chapters.currentRow()
            if row >= 0 and self._video_service:
                self._video_service.remove_chapter(row)
                self._refresh_chapters()
        except Exception:
            pass

    def _chapter_from_playhead(self) -> None:
        """Use current transport position for chapter start."""
        try:
            transport = self._get_transport()
            if not transport:
                return
            beat = float(getattr(transport, 'current_beat', 0.0))
            bpm = self._get_bpm()
            seconds = (beat / bpm) * 60.0 + self._spn_offset.value()
            m = int(max(0, seconds)) // 60
            s = int(max(0, seconds)) % 60
            self._spn_ch_min.setValue(m)
            self._spn_ch_sec.setValue(s)
        except Exception:
            pass

    def _refresh_chapters(self) -> None:
        try:
            self._lst_chapters.clear()
            if not self._video_service:
                return
            for ch in self._video_service.chapters:
                m = int(ch.start_seconds) // 60
                s = int(ch.start_seconds) % 60
                self._lst_chapters.addItem(f"{m:02d}:{s:02d}  —  {ch.name}")
        except Exception:
            pass

    # ──────────────────────────────────────────────────────────
    # VO5: Export
    # ──────────────────────────────────────────────────────────

    def _export_video(self) -> None:
        """Export video + DAW audio mix."""
        try:
            if not self._video_path:
                QMessageBox.information(self, "Export", "Kein Video geladen.")
                return

            # First export audio
            self._lbl_export_status.setText("⏳ Audio wird exportiert…")
            self._lbl_export_status.setStyleSheet("color: #d4b070; font-size: 11px;")

            # Ask for output path
            out_path, _ = QFileDialog.getSaveFileName(
                self, "Video + Audio exportieren",
                os.path.splitext(os.path.basename(self._video_path))[0] + "_mix.mp4",
                "MP4 (*.mp4);;MKV (*.mkv);;Alle (*)",
            )
            if not out_path:
                self._lbl_export_status.setText("")
                return

            # Export audio to temp WAV first
            import tempfile
            audio_tmp = tempfile.mktemp(suffix=".wav")

            # Try to use the DAW's audio export
            try:
                ps = getattr(self._services, 'project', None) if self._services else None
                if ps is None:
                    ps = getattr(self._services, 'project_service', None) if self._services else None
                ae = getattr(self._services, 'audio_export', None) if self._services else None
                if ae is None:
                    ae = getattr(self._services, 'audio_export_service', None) if self._services else None

                if ae and hasattr(ae, 'export_audio'):
                    ae.export_audio(audio_tmp)
                else:
                    # Fallback: silent audio
                    QMessageBox.warning(self, "Export",
                        "Audio-Export nicht verfügbar.\n"
                        "Video wird ohne Audio-Mix exportiert.\n\n"
                        "Tipp: Erst Datei → Exportieren, dann hier den WAV verwenden.")
                    # Simple copy without audio
                    import shutil
                    shutil.copy2(self._video_path, out_path)
                    self._lbl_export_status.setText(f"✅ Video kopiert: {out_path}")
                    self._lbl_export_status.setStyleSheet("color: #7bd389; font-size: 11px;")
                    return
            except Exception:
                pass

            # Merge video + audio
            self._lbl_export_status.setText("⏳ Video + Audio werden zusammengeführt…")
            if self._video_service:
                ok = self._video_service.export_with_audio(audio_tmp, out_path)
                if ok:
                    self._lbl_export_status.setText(f"✅ Exportiert: {out_path}")
                    self._lbl_export_status.setStyleSheet("color: #7bd389; font-size: 11px;")
                else:
                    self._lbl_export_status.setText("❌ Export fehlgeschlagen")
                    self._lbl_export_status.setStyleSheet("color: #d49090; font-size: 11px;")

            # Cleanup
            try:
                if os.path.exists(audio_tmp):
                    os.unlink(audio_tmp)
            except Exception:
                pass

        except Exception as e:
            self._lbl_export_status.setText(f"❌ {e}")
            self._lbl_export_status.setStyleSheet("color: #d49090; font-size: 11px;")
            log.error("[VideoPanel] export: %s", e, exc_info=True)

    # ──────────────────────────────────────────────────────────
    # Misc
    # ──────────────────────────────────────────────────────────

    def _on_status(self, msg: str) -> None:
        try:
            self.status.emit(msg)
        except Exception:
            pass

    def load_video_file(self, path: str) -> None:
        """Public API — load a video file (called from main_window / VideoConnector).

        v0.0.20.929: Does NOT auto-start sync (that caused UI freeze).
        Loads video metadata + shows first frame asynchronously.
        """
        if not path or path == self._video_path:
            return  # already loaded
        self._do_load_video(path)

    def shutdown(self) -> None:
        try:
            self._frame_timer.stop()
            if self._video_service:
                self._video_service.shutdown()
        except Exception:
            pass
