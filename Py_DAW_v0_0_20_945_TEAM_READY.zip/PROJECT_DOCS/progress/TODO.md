## v0.0.20.927 — Video-Drop → VideoPanel Auto-Load Fix

- [x] Bug: Video-Drop im Arranger → VideoPanel bekommt Pfad nicht
- [x] Fix: VideoConnector Benachrichtigung in project_service
- [x] Fix: VideoPanel Registration beim VideoConnector
- [x] Fix: Auto-Open Video-Panel bei Video-Drop
- [x] Fix: Auto-Start Sync bei externem Video-Laden
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno (21 Items)
- [ ] AVAILABLE: **PRO_ROADMAP P0 offene Tests** — Rust-Engine, Comping, Plugin-Tests

## v0.0.20.925 — Video-Integration Pro KOMPLETT (VP1–VP10)

- [x] VP9 Fortgeschrittene KI — Gesichtserkennung, Emotion, Style, Re-Edit
- [x] VP10 Multi-Video A/B — Split-View, PiP, Multi-Cam, ffmpeg Export
- [x] VP6 UI — Slider-Panel für Video-Filter
- **VIDEO-INTEGRATION PRO: 10/10 PHASEN ERLEDIGT** ✅
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno (21 Items)

## v0.0.20.924 — Video-Integration Pro (VP2+VP3+VP4+VP6+VP8)

- [x] VP2 Thumbnails — echte Video-Frames im Arranger-Clip
- [x] VP3 Szenen-Marker — farbige Marker im Arranger-Ruler + Kontextmenü
- [x] VP4 Cross-Module Sync — Clip-Click → Video-Panel + KI
- [x] VP6 Video-Filter-Chain — 10 Filter + 6 Presets + DB + ffmpeg Export
- [x] VP8 Scene-Aware Editing — Auto-Split + Ripple-Delete
- [ ] AVAILABLE: **VP9 Fortgeschrittene KI** — Gesichtserkennung, Style Transfer
- [ ] AVAILABLE: **VP10 Multi-Video A/B** — Split-View, PiP
- [ ] AVAILABLE: **VP6 UI** — Slider-Panel für Video-Filter (Service fertig, UI offen)
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno

## v0.0.20.923 — Video-Integration Pro (VP1+VP5+VP7)

- [x] VideoConnector + Vertonen→Track+MIDI + DB-Persistence
- [ ] AVAILABLE: **VP2 Thumbnails** — echte Video-Frames im Arranger-Clip
- [ ] AVAILABLE: **VP3 Szenen-Marker** — farbige Marker im Arranger-Ruler
- [ ] AVAILABLE: **VP6 Video-Filter** — Brightness/Contrast/LUT per Clip
- [ ] AVAILABLE: **VP8 Scene-Aware Editing** — Auto-Split an Szenen
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno

## v0.0.20.922 — Echte Video-Spur im Arranger

- [x] (Claude Opus 4.6, 2026-04-01): **Video-Track + Clip + DnD + Rendering + Clip-Ops**
- [ ] AVAILABLE: **VK7 Thumbnail-Strip** — echte Video-Frames im Arranger (statt Filmstrip-Pattern)
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno (21 Items)

## v0.0.20.921 — ALLE offenen Items erledigt

- [x] VK4+VK5+VK6+PO5+PO6 komplett
- [ ] AVAILABLE: **VK7 Thumbnail-Strip** — Filmstreifen im Arranger (kosmetisch)
- [ ] AVAILABLE: **VK9 Annotationen** + **VK10 Multi-Video** (Zukunft)
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno (21 Items)

## v0.0.20.920 — Video-KI Panel (VK8)

- [x] (Claude Opus 4.6, 2026-04-01): **VK8 komplett** — Szenen/Dialog/Sounds Tabs + Auto-Duck + Vertonen
- [ ] AVAILABLE: **VK4 Untertitel** — Whisper-Integration (optional)
- [ ] AVAILABLE: **VK5 Beat-to-Cut** — Beats an Szenen-Grenzen ausrichten
- [ ] AVAILABLE: **VK6 ADR/Foley Cue-Sheet** — Professionelles Post-Production
- [ ] AVAILABLE: **VK7 Thumbnail-Strip** — Filmstreifen im Arranger
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno

## v0.0.20.919 — Video-KI Engine (VK1+VK2+VK3)

- [x] (Claude Opus 4.6, 2026-04-01): **VK1+VK2+VK3 + 54 Tests + Roadmap**

## v0.0.20.918 — Video-Spur komplett (VO1–VO5)

- [x] (Claude Opus 4.6, 2026-04-01): **VideoPanel + Frame-Extraktion + SMPTE + Chapters + Export**
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno (21 Items)

## v0.0.20.917 — Podcast-System komplett (PO1–PO4)

- [x] (Claude Opus 4.6, 2026-04-01): **PodcastPanel + Speech-EQ Apply + Chapters + Silence Detection**
- [ ] AVAILABLE: **PO5: Vereinfachtes Layout** — Podcast-Modus blendet Piano Roll/Clip Launcher aus
- [ ] AVAILABLE: **PO6: Streaming** — ffmpeg-subprocess für RTMP/Icecast
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno (21 Items)

## v0.0.20.916 — Pin + Einrollen für alle abkoppelbaren Panels

- [x] (Claude Opus 4.6, 2026-04-01): **Floating Panels** — 📌 Pin + 🔽/🔼 Shade + ⮐ Dock-Back
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno (21 Items, 2 Rechner, echte Plugins)

## v0.0.20.915 — O1 Optional Polish (5/5 erledigt)

- [x] (Claude Opus 4.6, 2026-04-01): **O1.1–O1.5 KOMPLETT** — VST2 frameless, Patch-Name, Watchdog, Safe-Mode
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno (21 Items, 2 Rechner, echte Plugins)

## v0.0.20.914 — C6 ProjectState Crash Recovery + DB Round-Trip

- [x] (Claude Opus 4.6, 2026-03-31): **C6.1–C6.12 KOMPLETT** — Crash Recovery, Sync-on-Open, 36 Tests
- [x] (Claude Opus 4.6, 2026-03-31): Gesamt: 319 passed, 21 skipped, 0 failed (+36)
- [ ] AVAILABLE: **O1: Optionale Polish** — VST2 Editor frameless, Patch-Name, Watchdog, Safe-Mode
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno (21 Items)

## v0.0.20.913 — Time-Travel + Sentinel Unit-Tests

- [x] (Claude Opus 4.6, 2026-03-31): **62 neue Unit-Tests** für Time-Travel Engine (T1–T14)
- [x] (Claude Opus 4.6, 2026-03-31): **44 neue Unit-Tests** für Sentinel System (S1–S12)
- [x] (Claude Opus 4.6, 2026-03-31): Gesamt: 283 passed, 21 skipped, 0 failed (+106)
- [ ] AVAILABLE: **O1: Optionale Polish** — VST2 Editor frameless, Patch-Name, Watchdog, Safe-Mode
- [ ] AVAILABLE: **C6: DB Phase 5+** — ProjectState in SQLite (großer Umbau)
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno (21 Items)

## v0.0.20.912 — C5 PRO Features + HardwareController + RecordingService Tests

- [x] (Claude Opus 4.6, 2026-03-31): **C5.1+C5.3 HardwareController** — 7 Profile, Auto-Detect, Grid Mapping, OSC
- [x] (Claude Opus 4.6, 2026-03-31): **C5.2–C5.14** — 12 bestehende Services als erledigt verifiziert und abgehakt
- [x] (Claude Opus 4.6, 2026-03-31): **C3A.8 RecordingService Tests** — 8 Tests
- [x] (Claude Opus 4.6, 2026-03-31): **29 neue Tests** — HardwareController + RecordingService (Gesamt: 177)
- [ ] AVAILABLE: **C6: DB Phase 5+** — ProjectState in SQLite (großer Umbau)
- [ ] AVAILABLE: **H1: Hardware-Tests** — nur Anno (21 Items)
- [ ] AVAILABLE: **O1: Optionale Polish** — VST2 Editor, Patch-Name, Surge XT Shell

## v0.0.20.911 — Tech Debt: Tests, Logging, Accessibility

- [x] (Claude Opus 4.6, 2026-03-31): **C3A.6 ProjectService Tests** — 14 Tests (new/save/open, Track CRUD)
- [x] (Claude Opus 4.6, 2026-03-31): **C3A.7 SQLite DB Tests** — 25 Tests (Settings, Presets, PluginCache, Conflict)
- [x] (Claude Opus 4.6, 2026-03-31): **C3B.1 print→logging** — qt_patch.py, qt_compat.py
- [x] (Claude Opus 4.6, 2026-03-31): **C3B.2 Accessibility** — 35 Tooltips für alle Actions
- [x] (Claude Opus 4.6, 2026-03-31): **C4.6+C4.7** — als erledigt verifiziert und abgehakt
- [ ] AVAILABLE: **C3A.8: RecordingService Tests** — arm/start/stop (braucht Audio-Mock)
- [ ] AVAILABLE: **C5: PRO Features** — MIDI-Mapping, Live-Performance, Macro-System

## v0.0.20.910 — Collab Conflict-UI + KI-Services + Smart Mixer Heatmap

- [x] (Claude Opus 4.6, 2026-03-31): **C2A.2 Undo Automation** — Bereits v0.0.20.886, abgehakt
- [x] (Claude Opus 4.6, 2026-03-31): **C2A.3 Undo Device-Chain** — Bereits v0.0.20.886, abgehakt
- [x] (Claude Opus 4.6, 2026-03-31): **C2B.4 Weitere Sync-Ops** — device_sync, automation_sync verdrahtet
- [x] (Claude Opus 4.6, 2026-03-31): **C2C.2 Conflict-UI** — Non-modaler QDialog: Keep Mine / Accept Remote / Dismiss
- [x] (Claude Opus 4.6, 2026-03-31): **C2C.4 Services verdrahten** — CollabServer/Client im ServiceContainer + Shutdown
- [x] (Claude Opus 4.6, 2026-03-31): **C4.3 Mix-Analyse** — MixAnalyzer: Spectral, LUFS, Stereo, Crest, Konflikte
- [x] (Claude Opus 4.6, 2026-03-31): **C4.4 Kontrapunkt-Assistent** — 7 Stile, Scale-Snap, Parallelen-Fix, Quality-Score
- [x] (Claude Opus 4.6, 2026-03-31): **C4.8 Smart Mixer Heatmap UI** — Frequenz-Heatmap, Auto-Gain, Dialog+Menu
- [x] (Claude Opus 4.6, 2026-03-31): **28 neue Tests** — MixAnalyzer, Counterpoint, Conflict, SmartMixer (Gesamt: 123)
- [ ] AVAILABLE: **C3A.6–C3A.8: Weitere Tests** — ProjectService, SQLite DB, RecordingService
- [ ] AVAILABLE: **C3B: Code-Qualität** — print→logging Restmigration, Accessibility
- [ ] AVAILABLE: **C5: PRO Features** — MIDI-Mapping, Live-Performance, Macro-System
- [ ] AVAILABLE: **C4.7: Smart Mixer Backend** — bereits erledigt (v0.0.20.808) ✅
- [ ] AVAILABLE: **C4.6: Synth-Preset-Generator** — bereits erledigt (v0.0.20.809) ✅

## v0.0.20.909 — KI-Komposition: Chords + Variations + Bassline

- [x] (Claude Opus 4.6, 2026-03-31): **ChordProgressionAI** — Markov-Chain, 8 Presets, 9 Skalen, Tonart-Erkennung
- [x] (Claude Opus 4.6, 2026-03-31): **VariationsGenerator** — 7 Variationstypen (Transpose, Invert, Retrograde, etc.)
- [x] (Claude Opus 4.6, 2026-03-31): **BasslineGenerator** — 5 Styles (Root, Walking, Octave, Syncopated, Arpeggio)
- [x] (Claude Opus 4.6, 2026-03-31): **C2 Status-Audit** — Mixer/Transport-Sync, Cursor, mDNS als erledigt verifiziert
- [x] (Claude Opus 4.6, 2026-03-31): **37 neue Tests** — ChordAI, Variations, Bassline (Gesamt: 95 passed)
- [ ] AVAILABLE: **C4.3: Mix-Analyse** — Spektral-Balance, LUFS, Stereo-Breite
- [ ] AVAILABLE: **C4.4: Kontrapunkt-Assistent** — Regelbasierte Gegenstimme
- [ ] AVAILABLE: **C4.6: Synth-Preset-Generator** — Textbeschreibung → AETERNA/Fusion Preset

## v0.0.20.908 — OPEN_ITEMS_ROADMAP + Unit-Tests

- [x] (Claude Opus 4.6, 2026-03-31): **OPEN_ITEMS_ROADMAP.md** — 116 offene Items kategorisiert, priorisiert, dokumentiert
- [x] (Claude Opus 4.6, 2026-03-31): **DB-Status-Audit** — Alle 10 C1 DB-Integrationen als erledigt verifiziert
- [x] (Claude Opus 4.6, 2026-03-31): **pytest Setup + 58 Tests** — Models, TempoMap, CollabUndo, WarpStretch
- [ ] AVAILABLE: **C2: Collab-Erweiterungen** — Undo verdrahten, Mixer/Transport-Sync, Cursor-Sharing
- [ ] AVAILABLE: **C3A.6–8: Weitere Tests** — ProjectService, SQLite DB, RecordingService
- [ ] AVAILABLE: **C4: KI/Komposition** — Chord-AI, Variations, Mix-Analyse, Bassline-Gen

## v0.0.20.907 — Tech Debt: Transport/Engine Mixin-Extraktion

- [x] (Claude Opus 4.6, 2026-03-31): **TransportRecordingMixin extrahiert** — 25 Methoden, 787 Zeilen → main_window_transport.py
- [x] (Claude Opus 4.6, 2026-03-31): **EngineRustMixin extrahiert** — 11 Methoden, 276 Zeilen → main_window_engine.py
- [ ] AVAILABLE: **Unit-Tests** — pytest für kritische Services
- [ ] AVAILABLE: **Hardware-Tests** — PRO_ROADMAP_2026 offene Items

## v0.0.20.906 — Tech Debt: main_window.py Splitting + Logging

- [x] (Claude Opus 4.6, 2026-03-31): **FileIOMixin extrahiert** — 16 Methoden, 648 Zeilen → main_window_fileio.py
- [x] (Claude Opus 4.6, 2026-03-31): **DockTogglesMixin extrahiert** — 16 Methoden, 443 Zeilen → main_window_docks.py
- [x] (Claude Opus 4.6, 2026-03-31): **SandboxMixin extrahiert** — 8 Methoden, 195 Zeilen → main_window_sandbox.py
- [x] (Claude Opus 4.6, 2026-03-31): **print→logging Migration** — 10× traceback.print_exc() → log.error() in main_window.py
- [ ] AVAILABLE: **Weitere Mixin-Extraktionen** — Transport/Recording (~500Z), Engine/Rust (~400Z)
- [ ] AVAILABLE: **Unit-Tests** — pytest für kritische Services
- [ ] AVAILABLE: **Hardware-Tests** — PRO_ROADMAP_2026 offene Items

## v0.0.20.905 — SENTINEL S8-S12 (ROADMAP KOMPLETT)

- [x] (Claude Opus 4.6, 2026-03-31): **S8 Pattern Learning** — Crash-Precursor, Echtzeit-Matching, FP-Learning, Export/Import
- [x] (Claude Opus 4.6, 2026-03-31): **S9 API Server** — HTTP localhost:9750, 7 Endpoints, Rate-Limiting
- [x] (Claude Opus 4.6, 2026-03-31): **S10 KI-Anbindung** — Claude API, Anonymisierung, Keyring, Fallback
- [x] (Claude Opus 4.6, 2026-03-31): **S11 Health Dashboard** — CPU-Graph, Patterns, API-Status
- [x] (Claude Opus 4.6, 2026-03-31): **S12 Live-Mode Safeguards** — Toggle, Pre-Show Check, Post-Show Report

## v0.0.20.904 — SENTINEL S1-S7

- [x] (Claude Opus 4.6, 2026-03-31): **S1 DB Schema** — 5 Tabellen, SentinelDB Singleton
- [x] (Claude Opus 4.6, 2026-03-31): **S2 Flight Recorder** — CPU/Mem/Audio/Threads 500ms-2s
- [x] (Claude Opus 4.6, 2026-03-31): **S3 Anomaly Detector** — Echo-Loop/CPU/Memory/Disk
- [x] (Claude Opus 4.6, 2026-03-31): **S4 Health UI** — Herz-Icon, Alert-Banner, Dashboard
- [x] (Claude Opus 4.6, 2026-03-31): **S5 Crash Analyzer** — excepthook + SIGSEGV + Blackbox
- [x] (Claude Opus 4.6, 2026-03-31): **S6 Self-Healing UI** — Alert-Banner mit Undo
- [x] (Claude Opus 4.6, 2026-03-31): **S7 Echo-Loop Breaker** — collab_panel Hook, 50msg/s Schwelle

## v0.0.20.903 — Collab Device-Sync Echo-Loop Fix

- [x] (Claude Opus 4.6, 2026-03-31): **Echo-Loop gefixt** — 3s Cooldown + Hash-Cache Update + Suppress-Check
- [x] (Claude Opus 4.6, 2026-03-31): **show_track() entfernt** — kein Fenster-Focus-Steal mehr
- [x] (Claude Opus 4.6, 2026-03-31): **send_device_change Cooldown** — kein Rueck-Echo bei Remote-Sync

## v0.0.20.901 — Time-Travel Engine COMPLETE (T1-T14)

- [x] (Claude Opus 4.6, 2026-03-31): **T3 State Restore** — Snapshot+Replay, Selective, Preview, Safety Guard, MIDI-Restore
- [x] (Claude Opus 4.6, 2026-03-31): **T4 Time-Travel UI** — TimeTravelPanel, Timeline Canvas, Restore-Punkte, Shortcuts
- [x] (Claude Opus 4.6, 2026-03-31): **T5 FTS5 Suche** — Volltext-Suche, Zeit-Filter, Ergebnis-Liste
- [x] (Claude Opus 4.6, 2026-03-31): **T6 KI-Auto-Tagging** — MIDI/Param/Context-Analyse, 10s Timer
- [x] (Claude Opus 4.6, 2026-03-31): **T7 Sound Search UI** — Text+Stimmungs+Plugin-Suche, Ergebnis-Cards
- [x] (Claude Opus 4.6, 2026-03-31): **T8 Undo-Baum** — Git-Style UndoTree Data Layer + Branch-Ops
- [x] (Claude Opus 4.6, 2026-03-31): **T9 Undo-Baum UI** — QPainter Git-Graph, farbige Nodes, Kontextmenue
- [x] (Claude Opus 4.6, 2026-03-31): **T10+T11 Sound DNA** — 128-dim Fingerprint + Cross-Projekt-Suche
- [x] (Claude Opus 4.6, 2026-03-31): **T12+T13 Live Recall** — Smooth Transition + A/B Morph + Kurven
- [x] (Claude Opus 4.6, 2026-03-31): **T14 Session Heatmap** — Tracks×Zeit Heatmap, Tooltips, Click-to-Jump
- [ ] AVAILABLE: **Integration** — Panels in main_window.py als Dock-Widgets einbauen
- [ ] AVAILABLE: **Hardware-Test** — Time-Travel mit echten Plugins testen

## v0.0.20.896 — DB-First Read-Pfade (ALLE Read-Pfade umgestellt)

- [x] (Claude Opus 4.6, 2026-03-31): **midi_mapping_service** — mappings(), get_mapping_for_param(), CC dispatch DB-first
- [x] (Claude Opus 4.6, 2026-03-31): **preset_universe_tab** — _lazy_scan() PresetDatabase-first + Hintergrund-Rescan
- [x] (Claude Opus 4.6, 2026-03-31): **macro_recorder** — history property DB-first via ExtendedStateDB
- [x] (Claude Opus 4.6, 2026-03-31): **scripting_service** — get_history() DB-first via ExtendedStateDB
- [x] (Claude Opus 4.6, 2026-03-31): **main_window** — Arranger/PianoRoll UI state restore/save via FinalStateDB
- [x] (Claude Opus 4.6, 2026-03-31): **crash_indicator_widget** — Tooltip mit DB crash history
- [x] (Claude Opus 4.6, 2026-03-31): **groove_templates** — get_factory_grooves() DB-first
- [x] (Claude Opus 4.6, 2026-03-31): **plugin_scanner** — load_cache() PluginCacheDB-first
- [x] (Claude Opus 4.6, 2026-03-31): **SQLite Badge** — Status-Bar Widget mit Stats-Klick
- **🎯 Alle Read-Pfade jetzt DB-first mit sicherem Fallback**

## v0.0.20.894 — SQLite Migration COMPLETE 🎉 (42/42 Phasen)

- [x] (Claude Opus 4.6, 2026-03-31): **Phase 27: CloudSync** — cloud_sync_log + cloud_conflicts Tabellen
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 31: ArrangerState** — arranger_state Tabelle
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 32: PianoRollState** — pianoroll_state Tabelle
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 33: NotationState** — notation_state Tabelle
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 39: VideoState** — video_state + Integration video_track.py
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 40: PodcastState** — podcast_state + Integration podcast_mode.py
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 41: MasteringPresets** — mastering_presets Tabelle
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 42: UndoCommands** — undo_command_meta Tabelle
- **🎯 SQLite Migration Roadmap: ALLE 42 PHASEN ABGESCHLOSSEN**

## v0.0.20.893 — SQLite P5 ProjectState + P10-P18, P23-24, P29-30

- [x] (Claude Opus 4.6, 2026-03-31): **Phase 5: ProjectState** — 5 Tabellen (meta/tracks/clips/midi/automation), sync_project() in project_service
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 10: MixerState** — volume/pan/mute/solo/sends/routing in project_tracks (in P5 enthalten)
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 12: ClipLauncher State** — clip_launcher/scenes in project_meta.extra_json (in P5 enthalten)
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 13: TransportState** — BPM/punch/roll in project_meta (in P5 enthalten)
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 11: AutomationState** — project_automation Tabelle mit Query-API (in P5 enthalten)
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 14: UndoHistory** — undo_history Tabelle mit Snapshot-Pruning
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 16: MacroRecordings** — macro_recordings Tabelle + Integration in macro_recorder.py
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 17: CollabState** — collab_sessions Tabelle + Integration in collab_service.py
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 18: ScriptingHistory** — script_history Tabelle + Integration in scripting_service.py
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 23: NoteExpressions** — note_expression_index Tabelle
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 24: GitIntegration** — git_history Tabelle + Integration in git_integration_service.py
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 29: FXSystem** — fx_chain_presets Tabelle
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 30: AudioEngineState** — engine_state Key-Value Tabelle
- [ ] AVAILABLE: **Phase 27** — CloudSync (P5+P6-abhängig)
- [ ] AVAILABLE: **Phase 31-33** — Arranger/PianoRoll/Notation UI State (P5+P20-abhängig)
- [ ] AVAILABLE: **Phase 39-42** — Video/Podcast/Mastering/UndoCommands

## v0.0.20.892 — SQLite P28+P35+P36 + Integrationen

- [x] (Claude Opus 4.6, 2026-03-31): **Integration: midi_mapping_service.py** — add/remove mapping → MidiMappingDB sync
- [x] (Claude Opus 4.6, 2026-03-31): **Integration: preset_universe_tab.py** — _do_scan() → PresetDatabase batch sync
- [x] (Claude Opus 4.6, 2026-03-31): **Integration: preset_browser_service.py** — PluginStateManager push_undo → PluginHostStateDB
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 28: PluginHostStateDB** — plugin_states Tabelle, save/get/remove, RAM-Cache
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 35: FileIO State** — recent_projects, recent_media, export_history Tabellen
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 36: PluginSandbox Crash Log** — plugin_crash_log + Integration in _monitor_loop
- [x] (Claude Opus 4.6, 2026-03-31): **Integration: project_service.py** — open_project() → FileIOStateDB recent tracking
- [x] (Claude Opus 4.6, 2026-03-31): **Integration: audio_export_service.py** — export_audio() → FileIOStateDB export history
- [ ] AVAILABLE: **Phase 5: ProjectState** — Größter Umbau (Tracks/Clips/Automation in SQLite)
- [ ] AVAILABLE: **Phase 10-14** — MixerState, Automation, ClipLauncher, Transport, Undo (alle P5-abhängig)
- [ ] AVAILABLE: **Phase 16-18** — MacroRecordings, CollabState, ScriptingHistory (P5-abhängig)
- [ ] AVAILABLE: **Phase 23-24** — NoteExpressions, GitIntegration (P5-abhängig)
- [ ] AVAILABLE: **Phase 27** — CloudSync (P5+P6-abhängig)
- [ ] AVAILABLE: **Phase 29-30** — FXSystem, AudioEngineState (P5-abhängig)
- [ ] AVAILABLE: **Phase 31-33** — Arranger/PianoRoll/Notation State (P5+P20-abhängig)
- [ ] AVAILABLE: **Phase 39-42** — Video/Podcast/Mastering/UndoCommands (diverse Abhängigkeiten)

## v0.0.20.891 — Integration Layer + Phase 34, 37, 38

- [x] (Claude Opus 4.6, 2026-03-31): **Integration: settings_store.py** — SQLite-first, QSettings Fallback
- [x] (Claude Opus 4.6, 2026-03-31): **Integration: plugin_scanner.py** — save_cache() → PluginCacheDB sync
- [x] (Claude Opus 4.6, 2026-03-31): **Integration: registry.py** — display_name + icon Helpers via InstrumentRegistry
- [x] (Claude Opus 4.6, 2026-03-31): **Integration: groove_templates.py** — get_grooves_from_db() via GrooveScaleDB
- [x] (Claude Opus 4.6, 2026-03-31): **Integration: theme_manager.py** — User-Themes + set_active aus ThemeDatabase
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 34+37+38** — ai_config, accessibility_config, input_config Tabellen
- [ ] AVAILABLE: **Phase 5: ProjectState** — Größter Umbau (Tracks/Clips/Automation in SQLite)
- [ ] AVAILABLE: **Phase 10-14** — MixerState, Automation, ClipLauncher, Transport, Undo (alle P5-abhängig)
- [ ] AVAILABLE: **Phase 16-18** — MacroRecordings, CollabState, ScriptingHistory (P5-abhängig)
- [ ] AVAILABLE: **Phase 23-24** — NoteExpressions, GitIntegration (P5-abhängig)
- [ ] AVAILABLE: **Phase 27** — CloudSync (P5+P6-abhängig)
- [ ] AVAILABLE: **Phase 28** — PluginHostState (VST2/3/CLAP/LV2/LADSPA — Hoch-Priorität)
- [ ] AVAILABLE: **Phase 29-30** — FXSystem, AudioEngineState (P5-abhängig)
- [ ] AVAILABLE: **Phase 31-33** — Arranger/PianoRoll/Notation State (P5+P20-abhängig)
- [ ] AVAILABLE: **Phase 35-36** — FileIO, PluginSandbox
- [ ] AVAILABLE: **Phase 39-42** — Video/Podcast/Mastering/UndoCommands (diverse Abhängigkeiten)

## v0.0.20.890 — SQLite Phase 8+9+15+19-26

- [x] (Claude Opus 4.6, 2026-03-31): **Phase 8: MidiMappingDB** — MIDI Mappings + 5 Controller Profiles in SQLite
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 9: ThemeDatabase** — 5 Themes mit 30+ Palette-Farben in SQLite
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 15: GrooveScaleDB** — 12 Grooves + 42 Scales in SQLite
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 19-26: AppDatabase** — KeyBindings, UILayout, AudioConfig, RecordingConfig, ExportConfig, BrowserPlaces/Recents
- [ ] AVAILABLE: **Integration: theme_manager.py** — Themes aus ThemeDatabase laden
- [ ] AVAILABLE: **Integration: midi_mapping_service.py** — Mappings aus MidiMappingDB
- [ ] AVAILABLE: **Integration: groove_templates.py** — Grooves aus GrooveScaleDB
- [ ] AVAILABLE: **Integration: arranger_keyboard.py** — Shortcuts aus AppDatabase.keybindings
- [ ] AVAILABLE: **Integration: browser_places_tab.py** — Places aus AppDatabase
- [ ] AVAILABLE: **Phase 5: ProjectState** — Größter Umbau (Tracks/Clips/Automation)
- [ ] AVAILABLE: **Phase 10: MixerState** — Fader/Pan/Sends (nach P5)
- [ ] AVAILABLE: **Phase 13: TransportState** — BPM/Loop/Punch (nach P5)
- [ ] AVAILABLE: **Phase 14: UndoHistory** — Undo-Stack in SQLite (nach P5)

## v0.0.20.889 — SQLite Phase 3+4+6+7

- [x] (Claude Opus 4.6, 2026-03-31): **Phase 3: InstrumentRegistry** — 7 Instrumente in SQLite
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 4: FactorySampleRegistry** — 30 Samples in SQLite
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 6: SettingsDatabase** — QSettings → SQLite mit Dual-Write
- [x] (Claude Opus 4.6, 2026-03-31): **Phase 7: PluginCacheDB** — JSON → SQLite mit Migration
- [ ] AVAILABLE: **Integration: registry.py** — get_instruments() → InstrumentRegistry lesen
- [ ] AVAILABLE: **Integration: factory_sample_gen.py** — Definitionen aus FactorySampleRegistry
- [ ] AVAILABLE: **Integration: settings_store.py** — get_value()/set_value() → SettingsDatabase
- [ ] AVAILABLE: **Integration: plugin_scanner.py** — load_cache()/save_cache() → PluginCacheDB
- [ ] AVAILABLE: **Phase 5: ProjectState** — Größter Umbau, Tracks/Clips/Automation in SQLite
- [ ] AVAILABLE: **Phase 8: MIDI Mappings** — midi_mappings + controller_profiles in SQLite
- [ ] AVAILABLE: **Phase 9: ThemeSystem** — Themes in SQLite

## v0.0.20.888 — SQLite Phase 2: PresetDatabase

- [x] (Claude Opus 4.6, 2026-03-31): **preset_database.py** — FTS5 Volltext-Suche, Favorites, Play Count, Export
- [ ] AVAILABLE: **PresetUniverseTab Integration** — _do_scan() → PresetDatabase lesen/schreiben
- [ ] AVAILABLE: **Phase 3: InstrumentDefinitions** — Plugin-Metadaten in DB
- [ ] AVAILABLE: **Phase 4: FactorySamples** — Sample-Definitionen in DB

## v0.0.20.887 — SQLite Phase 1: ParamRegistry

- [x] (Claude Opus 4.6, 2026-03-31): **db_manager.py** — Singleton DB Manager, WAL mode, Backup
- [x] (Claude Opus 4.6, 2026-03-31): **param_registry.py** — 40+ Factory-Parameter, 7 Instrumente, RAM-Cache
- [x] (Claude Opus 4.6, 2026-03-31): **device_panel.py Integration** — ParamRegistry als First-Try in apply_universe_preset()
- [ ] AVAILABLE: **Live-Test** — Preset Universe Doppelklick → Sound über ParamRegistry?
- [ ] AVAILABLE: **Phase 2: PresetDatabase** — Alle Presets in SQLite mit FTS5 Volltext-Suche
- [ ] AVAILABLE: **Phase 3: InstrumentDefinitions** — Plugin-Metadaten in DB statt hardcodiert
- [ ] AVAILABLE: **Phase 4: FactorySamples** — Sample-Definitionen in DB

## v0.0.20.886 — Mixer Remote Flash + Automation Undo

- [x] (Claude Opus 4.6, 2026-03-31): **flash_remote_change()** — MixerStrip blitzt bei Remote-Änderung auf
- [x] (Claude Opus 4.6, 2026-03-31): **Automation Undo** — send_automation_change() cached alte Breakpoints
- [x] (Claude Opus 4.6, 2026-03-31): **Device/FX-Chain Undo** — send_device_change() cached kompletten Device-State
- [x] (Claude Opus 4.6, 2026-03-31): **_last_remote_user Tracking** — Remote-User-Name für Flash verfügbar
- [ ] AVAILABLE: **Live-Test** — Mixer-Flash + Automation Undo + Device Undo auf 2 Rechnern testen

## v0.0.20.885 — Collab Undo-Erweiterung + Exit-Segfault Fix

- [x] (Claude Opus 4.6, 2026-03-31): **_build_inverse_payload()** — Zentrale Undo-Inverse-Methode für 9 Op-Typen
- [x] (Claude Opus 4.6, 2026-03-31): **BPM Undo** — _on_local_bpm_changed() cached alten Wert + erstellt Inverse
- [x] (Claude Opus 4.6, 2026-03-31): **Clip Move/Resize/Remove/Rename/Mute Undo** — project_service sendet _old_* Felder
- [x] (Claude Opus 4.6, 2026-03-31): **Track Add/Remove/Rename Undo** — Inverse-Ops mit Name/Kind/Index
- [x] (Claude Opus 4.6, 2026-03-31): **Exit-Segfault Fix** — Alle Timer in closeEvent() als Erstes gestoppt
- [x] (Claude Opus 4.6, 2026-03-31): **CollapPanel Timer-Stop** — _collab_timer in shutdown() gestoppt
- [ ] AVAILABLE: **Live-Test** — Collab Undo für BPM/Track/Clip auf 2 Rechnern testen
- [ ] AVAILABLE: **Live-Test** — DAW schließen nach Collab → kein Segfault?
- [ ] AVAILABLE: **Undo-Erweiterung** — Automation-Punkt-Änderungen, Device-Chain-Änderungen

## v0.0.20.882 — Collab Preset Sync

- [x] (Claude Opus 4.6, 2026-03-30): **send_preset_sync()** — Preset-Aktionen (Laden/KI/Random) an Collab-Partner senden
- [x] (Claude Opus 4.6, 2026-03-30): **_apply_remote_preset_sync()** — Remote KI-Presets in lokales Universe injizieren + Chat-Notification
- [x] (Claude Opus 4.6, 2026-03-30): **Signal-Wiring** — PresetUniverseTab → CollabPanel in main_window.py
- [ ] AVAILABLE: **Live-Test** — Collab KI-Preset generieren → erscheint bei Partner? Chat-Notification?

## v0.0.20.881 — Drag-to-Track + External Plugin Integration + Auto-Detection

- [x] (Claude Opus 4.6, 2026-03-30): **Drag-to-Track** — Preset-Karten per QDrag auf Arranger/DevicePanel ziehen, application/x-pydaw-plugin MIME
- [x] (Claude Opus 4.6, 2026-03-30): **External Plugin Scan** — VST3/CLAP/LV2/VST2 aus Scanner-Cache + PresetBrowserService Factory+User Presets
- [x] (Claude Opus 4.6, 2026-03-30): **Auto-Detection** — QFileSystemWatcher + 5min Rescan für neue Plugins/Presets
- [x] (Claude Opus 4.6, 2026-03-30): **Filter-Erweiterungen** — Synth: VST3/CLAP/LV2/VST2, Kategorie: Instrument/Effect, Quelle: Installed/KI
- [ ] AVAILABLE: **Live-Test** — Surge XT / Dexed Presets im Universe, Drag auf Track, Auto-Detection
- [x] (Claude Opus 4.6, 2026-03-30): **Collab-Sync** — erledigt in v0.0.20.882

## v0.0.20.880 — Semantic Preset Universe

- [x] (Claude Opus 4.6, 2026-03-30): **PresetUniverseTab** — Cross-Plugin KI-Preset-Browser mit semantischer Suche, Auto-Tagging, Tag-Cloud, Mini-ADSR, Ähnlichkeits-Suche, KI-Generierung, Smart Randomize
- [x] (Claude Opus 4.6, 2026-03-30): **device_browser.py Integration** — Placeholder durch PresetUniverseTab ersetzt (safe try/except/fallback)
- [x] (Claude Opus 4.6, 2026-03-30): **20 Factory-Presets** — kuratierte AETERNA Presets (Init bis Evolving Texture)
- [ ] AVAILABLE: **Live-Test** — Presets-Tab öffnen, suchen, KI-Preset generieren, Ähnliche finden
- [x] (Claude Opus 4.6, 2026-03-30): **Drag-to-Track** — erledigt in v0.0.20.881
- [x] (Claude Opus 4.6, 2026-03-30): **VST3/CLAP Integration** — erledigt in v0.0.20.881

## v0.0.20.879 — Collab Device Sync Fix: External Plugins + All Device Ops

- [x] (Claude Opus 4.6, 2026-03-29): **_emit_collab_device_sync() Helper** — zentraler Collab-Hook mit explizitem track_id
- [x] (Claude Opus 4.6, 2026-03-29): **add_audio_fx_to_track() Collab-Hook** — externe VST2/VST3/CLAP/LV2 senden jetzt device_sync
- [x] (Claude Opus 4.6, 2026-03-29): **add_note_fx_to_track() Collab-Hook** — Note FX sendet device_sync
- [x] (Claude Opus 4.6, 2026-03-29): **Alle Device-Ops mit Collab-Hook** — remove, move, toggle, reorder, containers, batch (14 Stellen)
- [ ] AVAILABLE: **Live-Test** — Dexed VST2 / Helm VST2 / Nekobi VST3 bei Kollaboration zuweisen und prüfen

## v0.0.20.878 — Externe VST2/VST3 Instrumente Collab Fix

- [x] (Claude Opus 4.6, 2026-03-29): **show_track() für FX-Chain-Rendering** — externe Plugins werden jetzt via FX-Chain gerendert
- [ ] AVAILABLE: **Live-Test** — VST2 Instrumente (Dexed, Helm) bei Kollaboration

## v0.0.20.877 — CRITICAL: Instrument Collab Attribut-Tippfehler

- [x] (Claude Opus 4.6, 2026-03-29): **_device_panel → device_panel** — 4 Stellen in collab_panel.py referenzierten falsches Attribut, show_track() wurde nie aufgerufen
- [ ] AVAILABLE: **Live-Test** — Instrumente bei Kollaboration müssen jetzt funktionieren

## v0.0.20.876 — Collab Undo/Redo Fix

- [x] (Claude Opus 4.6, 2026-03-29): **Undo/Redo war komplett tot** — _record_for_undo() nie aufgerufen, lokale Anwendung fehlte, kein Value-Cache
- [x] (Claude Opus 4.6, 2026-03-29): **_push_undo() + _undo_mixer_cache** — neuer Helper + Value-Cache für Mixer-Ops
- [x] (Claude Opus 4.6, 2026-03-29): **_apply_undo_redo_locally()** — Undo/Redo wird jetzt auch lokal angewendet
- [x] (Claude Opus 4.6, 2026-03-29): **send_mixer_change() mit Undo** — Volume/Pan/Mute/Solo recordet Undo
- [ ] AVAILABLE: **Live-Test** — Collab Undo/Redo Buttons im Collab-Panel testen
- [ ] AVAILABLE: **Undo-Erweiterung** — Track Add/Remove, Clip Move, BPM etc.

## v0.0.20.875 — Collab Instrument + Ctrl+J + Track Move/Group Fix

- [x] (Claude Opus 4.6, 2026-03-29): **Instrument Ghost Method Fix** — set_instrument_on_track() existierte nirgendwo, alle 4 Aufrufe versagten still; ersetzt durch show_track()
- [x] (Claude Opus 4.6, 2026-03-29): **Full-Sync Late-Joiner Instrument Fix** — gleicher Ghost-Method-Fix für den full_sync Handler
- [x] (Claude Opus 4.6, 2026-03-29): **MIDI Join Collab Sync** — midi_notes_sync nach Noten-Kopie, damit Remote den Inhalt bekommt
- [x] (Claude Opus 4.6, 2026-03-29): **Audio Consolidate Collab Sync** — clip_add_audio + MediaSync nach Bounce
- [x] (Claude Opus 4.6, 2026-03-29): **clip_add_audio Handler erweitert** — offset_beats/gain/pan aus Payload setzen
- [x] (Claude Opus 4.6, 2026-03-29): **Track-Verschieben Collab** — move_track/move_group_block/move_tracks_block senden track_reorder
- [x] (Claude Opus 4.6, 2026-03-29): **Track-Gruppieren Collab** — group_tracks sendet track_group, Remote erstellt Group-Track
- [x] (Claude Opus 4.6, 2026-03-29): **Track-Entgruppieren Collab** — ungroup_tracks sendet track_ungroup, Remote räumt auf
- [x] (Claude Opus 4.6, 2026-03-29): **Server-Passthrough** — track_reorder/track_group/track_ungroup/clip_scale in collab_service
- [x] (Claude Opus 4.6, 2026-03-29): **Alt+Drag Stretch Collab** — clip_scale Op für MIDI (Clip-Länge) + Audio (Länge+Stretch)
- [ ] AVAILABLE: **Live-Test** — Instrumente + Strg+J + Track Move/Group + Alt+Drag auf 2 Rechnern
- [ ] AVAILABLE: **Collab Undo/Redo** — _record_for_undo() wird nirgendwo aufgerufen, braucht eigene Session

## v0.0.20.873 — Collab Arranger Ops + VST3 Spam Fix

- [x] (Claude Opus 4.6, 2026-03-28): **Clip Move/Resize/Trim Collab Sync** — 7 neue Hooks in project_service
- [x] (Claude Opus 4.6, 2026-03-28): **Ctrl+Drag Batch Copy Collab** — clip_copy_batch mit MIDI-Notes
- [x] (Claude Opus 4.6, 2026-03-28): **Track/Clip Rename Collab** — track_name + clip_rename sync
- [x] (Claude Opus 4.6, 2026-03-28): **VST3 Process Error Rate-Limit** — max 5 Logs, dann suppress
- [x] (Claude Opus 4.6, 2026-03-28): **MediaSync Hash-Dedup** — gleicher Content nie re-offered
- [ ] AVAILABLE: **Live-Test** — Arranger Ops + Ctrl+Drag + VST3 Spam + MediaSync

## v0.0.20.872 — Collab Deep Fix

- [x] (Claude Opus 4.6, 2026-03-28): **BPM-Sync bidirektional** — TransportPanel UI-Spinbox wird bei Remote-BPM-Änderung aktualisiert
- [x] (Claude Opus 4.6, 2026-03-28): **Playhead-Sync** — Neuer `transport_seek` Op, throttled ~8Hz, bidirektional
- [x] (Claude Opus 4.6, 2026-03-28): **Plugin-Instanziierung Remote** — Fingerprint-Cache invalidiert vor rebuild_fx_maps
- [x] (Claude Opus 4.6, 2026-03-28): **DevicePanel always show_track** — nicht mehr nur wenn Track aktiv angezeigt
- [x] (Claude Opus 4.6, 2026-03-28): **Loop-UI-Sync** — chk_loop Checkbox wird bei Remote-Loop-Änderung aktualisiert
- [x] (Claude Opus 4.6, 2026-03-28): **MediaSync Cooldown** — 30s → 3s für Multi-Clip-Szenarien
- [x] (Claude Opus 4.6, 2026-03-28): **Full-Sync verbessert** — BPM UI + Engine-Fingerprint bei Late-Join
- [ ] AVAILABLE: **Live-Test** — BPM bidirektional, Playhead-Sync, Plugin-Laden bei Remote

## v0.0.20.870 — Offer-Spam + Segfault Fix

- [x] (Claude Opus 4.6, 2026-03-28): **Offer-Spam-Loop** — 30s Cooldown pro Datei, kein endloses offered/dedup mehr
- [x] (Claude Opus 4.6, 2026-03-28): **Segfault beim Beenden** — CollabPanel.shutdown() in closeEvent, mDNS sauber gestoppt
- [x] (Claude Opus 4.6, 2026-03-28): **Log-Spam** — dedup "already have" von INFO auf DEBUG

## v0.0.20.869 — Instrument Sample Sync

- [x] (Claude Opus 4.6, 2026-03-28): **Instrument-Sample-Sync** — Pro Audio Sampler, Drum Machine, Advanced Sampler Samples über MediaSync
- [x] (Claude Opus 4.6, 2026-03-28): **Late-Join Sample Request** — Spät beitretende Teilnehmer fordern alle Samples automatisch an
- [x] (Claude Opus 4.6, 2026-03-28): **Pfad-Umschreibung** — Remote-Pfade → lokale Projekt-Media-Pfade
- [x] (Claude Opus 4.6, 2026-03-28): **6 Unit-Tests bestanden**
- [ ] AVAILABLE: **Live-Test** — 2 Rechner im LAN, Collab-Session, Sample-Sync prüfen

## v0.0.20.868 — Offline KI

- [x] (Claude Opus 4.6, 2026-03-28): **Lokale Musik-KI** — Melodie/Chords/Bass/Drums/Full-Sketch, 12 Tests
- [x] (Claude Opus 4.6, 2026-03-28): **Cloud/Lokal Modus** im KI-Panel

## v0.0.20.867 — Ultimate Collab

- [x] (Claude Opus 4.6, 2026-03-28): **Full-Sync Late-Join** — kompletter Projekt-State bei Verbindung
- [x] (Claude Opus 4.6, 2026-03-28): **TLS/WSS** — optionale Verschlüsselung
- [x] (Claude Opus 4.6, 2026-03-28): **Max-User-Limit** — default 8, UI-Spinbox
- [x] (Claude Opus 4.6, 2026-03-28): **Cross-Track Clip-Drag** — clip_move synct track_id
- [x] (Claude Opus 4.6, 2026-03-28): **9 E2E Tests bestanden**

## v0.0.20.866 — Audio File Streaming

- [x] (Claude Opus 4.6, 2026-03-28): **Content-Addressed Media Streaming** — SHA-256 Dedup, 64KB Chunks, Background-Thread
- [x] (Claude Opus 4.6, 2026-03-28): **MediaSyncService** — Angebot/Anfrage/Stream/Assembly Protokoll
- [x] (Claude Opus 4.6, 2026-03-28): **9 E2E Tests bestanden**

## v0.0.20.865 — Plugin/FX + Send Routing + Clip Duplicate Sync

- [x] (Claude Opus 4.6, 2026-03-28): **Plugin/FX-Chain Sync** — DevicePanel Hook
- [x] (Claude Opus 4.6, 2026-03-28): **Clip Duplicate Sync** — Ctrl+D synchronisiert
- [x] (Claude Opus 4.6, 2026-03-28): **Send/Return Routing Sync** — add/remove send
- [x] (Claude Opus 4.6, 2026-03-28): **10 E2E Tests bestanden**

## v0.0.20.864 — MIDI-Noten + Automation Sync

- [x] (Claude Opus 4.6, 2026-03-28): **MIDI-Noten Sync** — Noten werden per Snapshot synchronisiert
- [x] (Claude Opus 4.6, 2026-03-28): **Automation Sync** — Breakpoints werden synchronisiert
- [x] (Claude Opus 4.6, 2026-03-28): **8 E2E Tests bestanden**

## v0.0.20.863 — Clip/Track Add-Remove Sync

- [x] (Claude Opus 4.6, 2026-03-28): **track_add/remove + clip_add_midi/remove** — gemeinsam Clips und Tracks erstellen/löschen
- [x] (Claude Opus 4.6, 2026-03-28): **ProjectService._collab_notify Hook** — Echo-Loop-Schutz
- [x] (Claude Opus 4.6, 2026-03-28): **8 E2E Tests bestanden**

## v0.0.20.862 — Chat/Ops Deduplizierung

- [x] (Claude Opus 4.6, 2026-03-28): **Broadcast exclude=sender_id** — kein Echo mehr
- [x] (Claude Opus 4.6, 2026-03-28): **Server-Callback Guard** — kein Doppel wenn Host+Client

## v0.0.20.861 — Thread-Safe Signal Fix

- [x] (Claude Opus 4.6, 2026-03-28): **pyqtSignal statt QTimer.singleShot** — 8 Signals, alle Callbacks thread-safe, Chat kommt jetzt an
- [ ] AVAILABLE: **LAN-Test** — Chat, Cursor, Transport, Mixer zwischen 2 Rechnern verifizieren

## v0.0.20.860 — mDNS + Conflict Detection + Undo/Redo

- [x] (Claude Opus 4.6, 2026-03-28): **mDNS/Zeroconf** — Sessions automatisch im LAN finden + registrieren
- [x] (Claude Opus 4.6, 2026-03-28): **Conflict Detection** — Warnung wenn 2 User gleichzeitig gleichen Parameter bearbeiten
- [x] (Claude Opus 4.6, 2026-03-28): **Collab Undo/Redo** — Inverse-Ops, Per-User, max 200 Eintraege
- [x] (Claude Opus 4.6, 2026-03-28): **17 E2E Tests bestanden**
- [ ] AVAILABLE: **LAN-Test** — Alle Collab-Features zwischen 2 Rechnern testen

## v0.0.20.859 — Transport Sync + Mixer Live Sync

- [x] (Claude Opus 4.6, 2026-03-28): **Transport Sync** — Play/Stop/BPM/Loop zwischen allen Teilnehmern synchronisiert
- [x] (Claude Opus 4.6, 2026-03-28): **Mixer Live Sync** — Fader/Pan/Mute/Solo via _MixerStrip._collab_hook live synchronisiert
- [x] (Claude Opus 4.6, 2026-03-28): **Remote-Op Router** — _on_remote_operation verarbeitet alle eingehenden Ops + UI-Refresh
- [x] (Claude Opus 4.6, 2026-03-28): **15 E2E Tests bestanden**
- [ ] AVAILABLE: **LAN-Test** — Alles zwischen 2 Rechnern testen
- [ ] AVAILABLE: **Undo/Redo ueber Collab** — Remote-Undo rückgaengig machen
- [ ] AVAILABLE: **Conflict-UI** — Dialog bei gleichzeitigem Parameter-Edit
- [ ] AVAILABLE: **mDNS/Zeroconf** — Sessions automatisch im LAN finden

## v0.0.20.858 — Cursor Sharing + Extended Ops

- [x] (Claude Opus 4.6, 2026-03-28): **Cursor Sharing** — farbige gestrichelte Linien + Name-Labels im Arranger fuer Remote-User
- [x] (Claude Opus 4.6, 2026-03-28): **ArrangerCanvas.cursor_moved Signal** — Seek emittiert Position an Collab-Panel
- [x] (Claude Opus 4.6, 2026-03-28): **Server on_cursor Callback** — Cursor-Position pro User gespeichert + broadcast
- [x] (Claude Opus 4.6, 2026-03-28): **5 neue Op-Typen** — track_color, track_record_arm, clip_color, clip_resize, clip_mute
- [x] (Claude Opus 4.6, 2026-03-28): **Cursor-Cleanup** — Disconnect/Stop/User-Leave raeumt Cursor auf
- [ ] AVAILABLE: **LAN-Test** — Cursor-Sharing zwischen 2 Rechnern testen
- [ ] AVAILABLE: **Mixer-Sync** — Remote-Fader-Bewegungen live anzeigen
- [ ] AVAILABLE: **Transport-Sync** — Play/Stop/Loop synchronisieren

## v0.0.20.857 — Collab Thread-Leak Fix

- [x] (Claude Opus 4.6, 2026-03-28): **Thread-Leak bei Mehrfach-Klick** — connect() killt alten Thread, Auto-Reconnect nur nach Erstverbindung, Button disabled waehrend Versuch
- [x] (Claude Opus 4.6, 2026-03-28): **16 E2E Tests** — alle bestanden inkl. Thread-Leak, Rapid-Reconnect, First-Failure-No-Retry
- [ ] AVAILABLE: **LAN-Test** — Collab zwischen 2 Rechnern testen
- [ ] AVAILABLE: **Cursor-Sharing** — Cursor-Position visuell im Arranger rendern

## v0.0.20.856 — Collaboration Module Repair

- [x] (Claude Opus 4.6, 2026-03-28): **collab_service.py neu geschrieben** — websockets v16 API, async with serve(), proper threading, Host-Broadcast, Auto-Reconnect, clean disconnect
- [x] (Claude Opus 4.6, 2026-03-28): **collab_panel.py erweitert** — Host-Chat Broadcast fix, Port/Passwort UI, Disconnect-Button, periodischer Status-Refresh
- [x] (Claude Opus 4.6, 2026-03-28): **13 E2E Tests** — Server, Client, Sync, Chat, Ops, Locking, Disconnect, Password, Multi-Client
- [ ] AVAILABLE: **LAN-Test** — Collab zwischen 2 Rechnern im LAN testen (Session starten, verbinden, Chat, Parameter-Sync)
- [ ] AVAILABLE: **Cursor-Sharing** — Cursor-Position visuell im Arranger rendern (farbige Linien pro User)
- [ ] AVAILABLE: **Weitere Ops** — FX-Chain, Automation, Clip-Add/Remove als synchronisierte Operationen

## v0.0.20.843 — Automation Time-Signature Fix

- [x] (Claude Opus 4.6, 2026-03-27): **Automation Editor beats_per_bar** — liest jetzt aus Projekt-Taktart statt hardcoded 4.0; 3/4, 6/8 etc. werden korrekt dargestellt

## v0.0.20.842 — Surge XT Rollback + CLAP Spec Fix

- [x] (Claude Opus 4.6, 2026-03-27): **Surge XT UI Rollback** — fx_device_widgets.py auf v837-Stand zurueckgesetzt
- [x] (Claude Opus 4.6, 2026-03-27): **CLAP set_state() Spec-Fix** — stoppt Processing vor State-Load (clap_host.py), gleiches Pattern wie close()
- [x] (Claude Opus 4.6, 2026-03-27): **Ghost Notes Logger Fix behalten** — 5 Dateien aus v838
- [ ] AVAILABLE: **Hardware-Test** — Surge XT Presets wechseln, Ton muss sich jetzt aendern
- [ ] AVAILABLE: **Ghost Notes Hardware-Test** — + Add klicken, Clip-Liste muss laden

## v0.0.20.841 — Surge XT CLAP-nativer Editor (ROLLED BACK in v842)

- [x] (Claude Opus 4.6, 2026-03-27): **VST3-Surrogate deaktiviert** — `_resolve_vst3_surrogate_for_external_editor()` gibt immer ("","") zurueck
- [x] (Claude Opus 4.6, 2026-03-27): **CLAP-Helper State-Sync** — `_send_current_state_to_external_editor()` akzeptiert jetzt "clap" Modus
- [ ] AVAILABLE: **Hardware-Test** — Surge XT CLAP Editor oeffnen, Presets wechseln, Ton muss sich aendern
- [ ] AVAILABLE: **Hardware-Test** — Parameter-Sync in beide Richtungen pruefen

## v0.0.20.840 — Surge XT Preset-Sync Fix

- [x] (Claude Opus 4.6, 2026-03-27): **Preset-Sync Fix** — VST3-State-Blob nicht mehr auf CLAP anwenden, nur Parameter-Snapshot (775 Werte)
- [ ] AVAILABLE: **Hardware-Test** — Surge XT CLAP Presets wechseln, Ton muss sich aendern
- [ ] AVAILABLE: **Hardware-Test** — Shell Frameless (v0.0.20.839) pruefen

## v0.0.20.839 — Surge XT Shell Frameless Fix

- [x] (Claude Opus 4.6, 2026-03-27): **Surge XT Shell Frameless** — VstEditorContainer nutzt FramelessWindowHint, kein doppelter WM-Rahmen mehr
- [x] (Claude Opus 4.6, 2026-03-27): **Toolbar Drag-Handling** — frameless Fenster per Toolbar verschiebbar
- [ ] AVAILABLE: **Hardware-Test** — Surge XT CLAP Shell: nur noch ein Rahmen, Drag, Pin, Einrollen pruefen
- [ ] AVAILABLE: **Optional** — VST2 Editor (Dexed) ebenfalls frameless machen falls gewuenscht

## v0.0.20.838 — Ghost Notes Logger Fix

- [x] (Claude Opus 4.6, 2026-03-27): **Ghost Notes Dialog gefixt** — Logger war im Docstring eingesperrt, "Error loading clips: name 'log' is not defined" behoben
- [x] (Claude Opus 4.6, 2026-03-27): **4 weitere Logger-im-Docstring Bugs gefixt** — chronoscale_widget.py, track_list.py, jit_effects.py, jit_kernels.py
- [ ] AVAILABLE: **Ghost Notes Hardware-Test** — + Add klicken, Clip-Liste muss jetzt laden, Ghost Layer hinzufuegen und im Piano Roll sehen
- [ ] AVAILABLE: **P0B Sampler-Persistenz-Tests** — Zone laden, speichern, neustarten, pruefen
- [ ] AVAILABLE: **P0C Rust Engine Live-Validierung** — CLAP/LV2, A/B Vergleich, 20 Tracks
- [ ] AVAILABLE: **P1A Comping-Workflow** — Loop-Recording, Take-Lanes, Flatten auf Hardware testen

## v0.0.20.837 — Surge XT Shell Start/Raise Stabilize

- [x] (GPT-5.4 Thinking, 2026-03-27): **Sofort sichtbare Surge-Shell** — externer Surge-XT-Editor zeigt direkt eine Platzhalter-Huelle mit Pin/Einrollen und dockt das echte X11-Fenster spaeter daran an.
- [x] (GPT-5.4 Thinking, 2026-03-27): **Start-Klicks entwaffnet** — weitere Editor-Klicks waehrend des Helper-Starts schliessen den laufenden Start nicht mehr versehentlich.
- [x] (GPT-5.4 Thinking, 2026-03-27): **Window-Watcher wieder sofortig** — der X11-Helper meldet wieder direkt das groesste gefundene Plugin-Fenster, damit Surge XT auf echter Hardware wieder sichtbar wird.
- [ ] AVAILABLE: **Hardware-Test** — Surge XT CLAP OOP Shell auf sichtbaren Start, korrekte Groesse, Pin, Einrollen und Preset-Wechsel pruefen.
- [ ] AVAILABLE: **Optional** — Falls Preset-Wechsel weiter denselben Ton liefern: gezielt Snapshot-vs-MIDI/Patch-Refresh gegenhoeren, ohne den Audio-Pfad breit umzubauen.

## v0.0.20.836 — Surge XT Shell Size Stabilize

- [x] (GPT-5.4 Thinking, 2026-03-27): **Mini-Shell verhindert** — externe Surge-XT-Shell uebernimmt keine fruehen/zu kleinen Geometrien mehr; Groessenhints werden nur noch vergroessert und fuer den Surge-Surrogate konservativ bei mindestens 960x720 gehalten.
- [x] (GPT-5.4 Thinking, 2026-03-27): **Groesstes Helper-Fenster bevorzugt** — der X11-Watcher wartet kurz auf ein stabiles Plugin-Fenster und meldet nicht mehr sofort den ersten kleinen Kandidaten.
- [x] (GPT-5.4 Thinking, 2026-03-27): **Duplicate-State-Loads reduziert** — identische Surrogate-State-Blobs werden nicht erneut auf die laufende CLAP-Engine gespielt.
- [ ] AVAILABLE: **Hardware-Test** — Surge XT CLAP OOP-Shell auf korrekte Groesse, Pin, Einrollen und Preset-Wechsel pruefen.
- [ ] AVAILABLE: **Optional** — Falls weiter leerer Rand bleibt: Shell-Hoehe aus stabiler WM-/Frame-Geometrie statt Client-Geometrie ableiten.

## v0.0.20.835 — Surge XT Overlay Geometry + VST3 Safe-Reset-Fix

- [x] (GPT-5.4 Thinking, 2026-03-27): **Overlay-Geometrie entprellt** — das Surge-XT-Shell-Fenster synchronisiert X11-Move/Resize nur noch bei echten Aenderungen; permanentes Flackern durch dauerndes Re-Raise wird reduziert.
- [x] (GPT-5.4 Thinking, 2026-03-27): **Echte Editor-Groesse ueber Helper rueckgemeldet** — der VST3-Surrogate-Helper liefert Breite/Hoehe des nativen Fensters an Py_DAW; die Shell wird nicht mehr blind mit 960x720 gebaut.
- [x] (GPT-5.4 Thinking, 2026-03-27): **Safe-Reset fuer Main-Thread-VST3s** — Surge XT / Nekobi verwenden beim SR-Warmup nur noch `reset=False`, damit der bekannte Main-Thread-Reset-Fehler den Load nicht sofort erneut blockiert.
- [ ] AVAILABLE: **Hardware-Test** — Surge XT CLAP OOP Shell auf Flackern, Pin, Einrollen und Preset-Reaktion pruefen.
- [ ] AVAILABLE: **Hardware-Test** — Surge XT / Nekobi als VST3 erneut laden und auf Ton / Parameterliste / Preset-Reaktion pruefen.

## v0.0.20.834 — Surge XT Shell Overlay + Preset-Menü-Safe-Docking

- [x] (GPT-5.4 Thinking, 2026-03-27): **Shell-Overlay statt hartem Reparent** — der originale Surge-XT-Pedalboard-Editor bleibt erhalten und wird dekorationslos in eine Py_DAW-Huelle eingedockt.
- [x] (GPT-5.4 Thinking, 2026-03-27): **Pin/Einrollen auf Overlay erweitert** — Toolbar-Aktionen der Huelle steuern jetzt auch das externe X11-Fenster (Map/Unmap/Always-on-top/Move/Resize).
- [x] (GPT-5.4 Thinking, 2026-03-27): **Preset-Menue-Pfad geschuetzt** — der Preset-/Patch-Browser bleibt im originalen Pedalboard-Fenster aktiv; der bewaehrte State-Blob-Sync zur CLAP-Instanz bleibt unveraendert.
- [ ] AVAILABLE: **Hardware-Test** — Surge XT CLAP: Shell-Overlay, Pin, Einrollen und Preset-Wechsel unter Linux/X11 gegenhoeren.
- [ ] AVAILABLE: **Optional** — Falls das WM weiter Rahmen zeigt: gezielt `_MOTIF_WM_HINTS`/Transient-Verhalten auf dem Zielsystem feinjustieren.

## v0.0.20.832 — Surge XT External Editor Shell + Preset Snapshot Sync

- [x] (GPT-5.4 Thinking, 2026-03-27): **Externe Surge-XT-Editorhuelle** — X11-Wid aus dem Surrogate-Helper an Py_DAW gemeldet und in `VstEditorContainer` mit Pin/Einrollen uebernommen.
- [x] (GPT-5.4 Thinking, 2026-03-27): **Preset-/Patch-Snapshot-Sync** — State-Events vom VST3-Surrogate bringen jetzt einen kompletten Parameter-Snapshot mit, der auf die laufende CLAP-Instanz zurueckgespielt wird.
- [x] (GPT-5.4 Thinking, 2026-03-27): **Normierte Param-Bridge** — Surrogate-Rohwerte werden zwischen VST3-Editor und CLAP-Instanz sauber normiert/denormiert.
- [ ] AVAILABLE: **Hardware-Test** — Surge XT CLAP: Preset-Wechsel / unterschiedliche Toene / Pin / Einrollen unter Linux/X11 pruefen.
- [ ] AVAILABLE: **Patch-Name im Device spiegeln** — Optional aktuellen Surrogate-Patchnamen im Status/Preset-Feld anzeigen.

## v0.0.20.831 — VST3 Sound Restore + Surge Editor Launch Guard

- [x] (GPT-5.4 Thinking, 2026-03-27): **Bekannte Main-Thread-VST3s preemptiv defer** — Surge XT / Nekobi werden vor dem ersten Worker-Touch direkt zur Main-Thread-Finalisierung geschickt.
- [x] (GPT-5.4 Thinking, 2026-03-27): **Pedalboard Worker-Block fuer Surge XT / Nekobi** — `_load_pedalboard_plugin()` verweigert diese Plugins ab jetzt off-main-thread, statt spaetere Loads zu vergiften.
- [x] (GPT-5.4 Thinking, 2026-03-27): **Surge CLAP Editor Launch Guard** — externer Helper wird waehrend des Starts nicht mehrfach parallel erzeugt.
- [ ] AVAILABLE: **Hardware-Test** — Surge XT / Nekobi als VST3 unter Linux/X11 erneut laden und auf Ton pruefen.
- [ ] AVAILABLE: **UI-Nacharbeit** — externe Surge-XT-Editorhuelle mit Pin/Einrollen angleichen, ohne Audio-/Editorpfad erneut zu riskieren.

## v0.0.20.829 — VST3 Instrument Fix (Nekobi Ton + Symbol)

- [x] (Claude Opus 4.6, 2026-03-26): **Blanket VST3 Deferral entfernt** — Nekobi etc. laden wieder normal auf Worker-Thread
- [x] (Claude Opus 4.6, 2026-03-26): **Nekobi in Known-Instruments** — Scanner + Runtime erkennen Nekobi als Instrument
- [x] (Claude Opus 4.6, 2026-03-26): **Main-Thread-Fehler = Instrument** — Surge XT wird korrekt als Instrument erkannt

- [ ] IMPORTANT: **Rescan nötig** — Nach Update im Plugin-Browser "Rescan" klicken damit Nekobi-Cache aktualisiert wird
- [ ] AVAILABLE: **Surge XT CLAP OOP Editor testen** — Helper-Prozess (clap_gui_process.py) prüfen

## v0.0.20.826 — Surge XT CLAP OOP Editor

- [x] (GPT-5.4 Thinking, 2026-03-26): **Surge XT CLAP OOP Editor** — Surge XT unter Linux/X11 auf gezielten Detached-Helper-Prozess umgestellt; Audio/DSP bleibt im Hauptprozess
- [ ] AVAILABLE: **Hardware-Test** — Surge XT CLAP externen Editor unter Linux/X11 öffnen, schließen und Parameter hörbar gegen die Live-Instanz prüfen
- [ ] AVAILABLE: **Optionaler Watchdog** — Nur falls der Helper selbst beim Start hängen sollte: sanftes Timeout-/Feedback im Button/Status ergänzen

## v0.0.20.825 — Surge XT CLAP Async Stage 1

- [x] (GPT-5.4 Thinking, 2026-03-26): **Surge XT CLAP Async Stage 1** — blockierenden Stage-1-Create aus dem Qt-GUI-Thread herausgenommen; Stage 2/3 bleiben auf Main-Thread
- [ ] AVAILABLE: **Hardware-Test** — Surge XT CLAP Editor erneut unter Linux/X11 öffnen und prüfen, ob Stage 1/2/3 vollständig durchlaufen
- [ ] AVAILABLE: **Nur falls weiter nötig** — optionalen Out-of-Process-Editorpfad nur für Surge XT evaluieren

## v0.0.20.824 — Surge XT CLAP Editor Restore

- [x] (GPT-5.4 Thinking, 2026-03-26): **Surge XT CLAP Editor Restore** — UI-Blockade entfernt; staged CLAP-Editor-Flow wieder aktiv
- [ ] AVAILABLE: **Hardware-Test** — Surge XT CLAP Editor unter Linux/X11 real öffnen/schließen
- [ ] AVAILABLE: **Optionaler Safe-Mode** — Editor-Blockade nur als benutzerseitiger Fallback-Schalter statt harter Sperre

# TODO.md — Offene Aufgaben

## v0.0.20.822 — CLAP XWayland-Schutz, Takte 999

- [x] (Claude Opus 4.6, 2026-03-26): **CLAP XWayland-Schutz** — QMessageBox statt deadlock
- [x] (Claude Opus 4.6, 2026-03-26): **Takte-Limit** — 3 SpinBoxes von 64 auf 999

- [ ] AVAILABLE: **CLAP Editor unter X11** — Ohne Wayland testen
- [ ] AVAILABLE: **Carla Bridge** — CLAP-Editor in separatem Prozess

## v0.0.20.821 — CLAP Editor Freeze Fix, Samplerate Init

- [x] (Claude Opus 4.6, 2026-03-26): **CLAP Editor Freeze** — process_events Callback in create_gui()
- [x] (Claude Opus 4.6, 2026-03-26): **Samplerate Init** — reset=True first, Fallback reset=False

- [ ] AVAILABLE: **Hardware-Test** — CLAP Editor (Surge XT) auf echtem System testen
- [ ] AVAILABLE: **P0 Hardware-Tests** — Rust-Engine, Sampler, CLAP/LV2 (braucht echte Hardware)
- [ ] AVAILABLE: **Rust-Engine Default** — should_use_rust() → True nach A/B-Test

## v0.0.20.820 — KRITISCHER BUGFIX: Logger flush=, Segfault, VST3 Main-Thread

- [x] (Claude Opus 4.6, 2026-03-26): **Logger flush= Bug** — 35 Stellen in 9 Dateien: `flush=True`/`file=stderr` aus Logger-Calls entfernt
- [x] (Claude Opus 4.6, 2026-03-26): **Segfault beim Beenden** — atexit-Hook + closeEvent Essentia-Pool Shutdown
- [x] (Claude Opus 4.6, 2026-03-26): **VST3 Main-Thread** — Deferred-Loading für Surge XT in _finalize_rebuild()

- [ ] AVAILABLE: **Hardware-Test** — Dexed (VST2), Surge XT (VST3/CLAP), ZynAddSubFX, LSP auf echtem System testen
- [ ] AVAILABLE: **P0 Hardware-Tests** — Rust-Engine, Sampler, CLAP/LV2 (braucht echte Hardware)
- [ ] AVAILABLE: **Rust-Engine Default** — should_use_rust() → True nach A/B-Test

## v0.0.20.817 — P5B Cloud/Share + Feature-Integration

- [x] (Claude Opus 4.6, 2026-03-26): **Session Share** — session_share.py: ShareLink, HTML-Export, ZIP-Package, Comments
- [x] (Claude Opus 4.6, 2026-03-26): **Cloud Service** — cloud_service.py: SHA-256 Dedup, Manifest, Sample/Preset/Project, Collections
- [x] (Claude Opus 4.6, 2026-03-26): **Menü-Integration** — 7 neue Menüeinträge + 8 Handler in main_window.py

- [ ] AVAILABLE: **P0 Hardware-Tests** — Rust-Engine, Sampler, CLAP/LV2 (braucht echte Hardware)
- [ ] AVAILABLE: **Rust-Engine Default** — should_use_rust() → True nach A/B-Test

## v0.0.20.816 — Tech Debt: main_window.py Splitting (Tabs + ScreenLayout)

- [x] (Claude Opus 4.6, 2026-03-26): **ProjectTabsMixin** — 287Z, 10 Methoden, Multi-Projekt-Tab-Handler
- [x] (Claude Opus 4.6, 2026-03-26): **ScreenLayoutMixin** — 270Z, 5 Methoden + 6 Restore-Fns, Multi-Monitor
- [x] (Claude Opus 4.6, 2026-03-26): **Ergebnis** — main_window.py 8494→5246 (-38%), 4 Mixins, 357/357 fehlerfrei

- [ ] AVAILABLE: **P0 Hardware-Tests** — Rust-Engine, Sampler, CLAP/LV2
- [ ] AVAILABLE: **Integration** — VideoTrack, Podcast, Community-Browser in main_window
- [ ] AVAILABLE: **Rust-Engine Default** — should_use_rust() → True nach A/B-Test
- [ ] AVAILABLE: **P5B Cloud** — Session-Share, Preset-Cloud, Sample-Cloud

## v0.0.20.815 — Tech Debt: main_window.py Splitting

- [x] (Claude Opus 4.6, 2026-03-26): **SmartDrop Mixin** — 2624 Zeilen extrahiert, SmartDropMixin Klasse, Mixin-Vererbung
- [x] (Claude Opus 4.6, 2026-03-26): **Theme CSS** — 145 Zeilen CHRONO_THEME_CSS in chrono_theme_css.py
- [x] (Claude Opus 4.6, 2026-03-26): **Ergebnis** — main_window.py 8494→5758 (-32%), 355/355 fehlerfrei

- [ ] AVAILABLE: **Weitere Mixin-Extraktionen** — Tabs (519Z), IO (350Z), ScreenLayout (248Z)
- [ ] AVAILABLE: **P0 Hardware-Tests** — Rust-Engine, Sampler, CLAP/LV2
- [ ] AVAILABLE: **Integration** — VideoTrack, Podcast, Community-Browser in main_window
- [ ] AVAILABLE: **Rust-Engine Default** — should_use_rust() → True nach A/B-Test

## v0.0.20.814 — Tech Debt: Accessibility + print-Audit + Splitting-Plan

- [x] (Claude Opus 4.6, 2026-03-26): **Accessibility** — accessibility.py: Service+Config, Screen-Reader, Shortcuts, FocusNav, CSS
- [x] (Claude Opus 4.6, 2026-03-26): **print→logging Audit** — 0 print() in echtem Code, Codebase sauber
- [x] (Claude Opus 4.6, 2026-03-26): **main_window Splitting-Plan** — MAIN_WINDOW_SPLIT_PLAN.md, 5 Mixin-Schritte dokumentiert

- [ ] AVAILABLE: **main_window.py Splitting ausführen** — braucht GUI-Test auf Hardware
- [ ] AVAILABLE: **P0 Hardware-Tests** — Rust-Engine, Sampler, CLAP/LV2 auf echter Hardware
- [ ] AVAILABLE: **Rust-Engine als Default** — should_use_rust() → True nach A/B-Test
- [ ] AVAILABLE: **Integration** — Neue Services (Accessibility, Theme, Podcast, Video) in main_window verdrahten

## v0.0.20.813 — Tech Debt: Theming + Unit-Tests + User-Manual

- [x] (Claude Opus 4.6, 2026-03-26): **Theming-System** — 5 Themes, ThemePalette 30+ Farben, YAML, Live-Switch, Qt-Stylesheet
- [x] (Claude Opus 4.6, 2026-03-26): **Unit-Tests** — 37 Tests, 12 Module, PyTest-kompatibel, Qt-Skip-Decorators
- [x] (Claude Opus 4.6, 2026-03-26): **User-Manual** — 16 Kapitel, alle Features, Tastaturkürzel, Fehlerbehebung

- [ ] AVAILABLE: **Tech Debt: main_window.py aufteilen** — 7961 Zeilen → Module
- [ ] AVAILABLE: **Tech Debt: print→logging** — 373 Stellen migrieren
- [ ] AVAILABLE: **Tech Debt: Accessibility** — Screen-Reader, Keyboard-Nav
- [ ] AVAILABLE: **P0 Hardware-Tests** — Rust-Engine, Sampler, CLAP/LV2

## v0.0.20.812 — P6B JSFX/Faust + P6C Preset-Browser + P7A Video + P7B Podcast

- [x] (Claude Opus 4.6, 2026-03-25): **JSFX Runtime** — Parser, Transpiler, Sandbox-Executor, 3 Built-in Scripts
- [x] (Claude Opus 4.6, 2026-03-25): **Faust Integration** — faust_compile(), FaustDspInstance, 3 Built-in Faust
- [x] (Claude Opus 4.6, 2026-03-25): **LV2 Builder** — TTL-Generator, Python-Wrapper, Auto-Port-Discovery
- [x] (Claude Opus 4.6, 2026-03-25): **Community Preset Browser** — Scan/Search/Install/Favoriten Widget
- [x] (Claude Opus 4.6, 2026-03-25): **Video Track** — ffprobe, SMPTE Timecode, Chapter-Marker, export_with_audio
- [x] (Claude Opus 4.6, 2026-03-25): **Podcast Mode** — 6 Speech-EQ-Presets, Silence Detection, Streaming Stub, 3 Chapter-Export-Formate

- [ ] AVAILABLE: **Tech Debt: main_window.py aufteilen** — 7961 Zeilen → Module
- [ ] AVAILABLE: **Tech Debt: print→logging** — alle print(stderr) ersetzen
- [ ] AVAILABLE: **Tech Debt: Unit-Tests** — PyTest für kritische Module
- [ ] AVAILABLE: **Tech Debt: Theming** — Hell/Dunkel/YAML Farbschemata
- [ ] AVAILABLE: **Tech Debt: Accessibility** — Screen-Reader, Keyboard-Nav

## v0.0.20.811 — Dependency-Fix + P6A Macro/Docs + P6C Preset-Format

- [x] (Claude Opus 4.6, 2026-03-25): **Dependency-Fix** — pygame, python-osc in requirements.txt, install.py, setup_all.py
- [x] (Claude Opus 4.6, 2026-03-25): **Macro-Recorder** — MacroRecorder Service, Action Recording, Script-Export
- [x] (Claude Opus 4.6, 2026-03-25): **Plugin-Dokumentation** — PLUGIN_API_TUTORIAL.md: Effekt/Instrument/MidiFx in 10 Min
- [x] (Claude Opus 4.6, 2026-03-25): **Preset-Format** — .pydaw-preset YAML, Serum FXP Importer, 5 Factory Presets

- [ ] AVAILABLE: **P6B JSFX/Faust** — DSP-Plugins in Python/Faust
- [ ] AVAILABLE: **P6C Community-Browser** — Preset-Browser direkt in der DAW
- [ ] AVAILABLE: **P7A Video-Sync** — Video-Spur im Arranger
- [ ] AVAILABLE: **P7B Podcast-Mode** — Vereinfachtes UI für Sprache

## v0.0.20.810 — P4A Live-Performance + P4B Hardware-Integration

- [x] (Claude Opus 4.6, 2026-03-25): **Controller Profiles** — 6 Profile (Launchpad/APC/Push), Auto-Detect, Pad/Fader/Knob/Button Map, LED Feedback
- [x] (Claude Opus 4.6, 2026-03-25): **Live-Performance-Panel** — 8x8 Grid, Transport Bar, Scene Launch, Level Meters, F11 Fullscreen
- [x] (Claude Opus 4.6, 2026-03-25): **OSC Controller** — 15+ Adressen, bidirektionaler Feedback 30Hz, TouchOSC/Lemur
- [x] (Claude Opus 4.6, 2026-03-25): **CV/Gate Service** — 1V/Oct Pitch, Gate, Velocity, Mod, Calibration, Portamento
- [x] (Claude Opus 4.6, 2026-03-25): **Gamepad Input** — pygame, 2 Profile (Instrument+Drums), Button→Note, Axis→CC

- [ ] AVAILABLE: **P6A Macro-System** — Aktionen aufzeichnen → Script exportieren
- [ ] AVAILABLE: **P6A Dokumentation** — "Schreibe deinen ersten Plugin in 10 Minuten"
- [ ] AVAILABLE: **P6B JSFX/Faust** — DSP-Plugins in Python/Faust
- [ ] AVAILABLE: **P6C Preset-Format** — .pydaw-preset YAML standardisieren
- [ ] AVAILABLE: **P7A Video-Sync** — Video-Spur im Arranger

## v0.0.20.809 — P2B KI-Analyse + P2D Preset-Generator

- [x] (Claude Opus 4.6, 2026-03-25): **Genre-Detektion** — 15 Genre-Profile, Multi-Feature-Matching, Konfidenz-Scoring
- [x] (Claude Opus 4.6, 2026-03-25): **Reference Track Analyse** — AudioProfile, 6-Band Spectral, LUFS/Peak/Stereo Compare, Severity+Suggestions
- [x] (Claude Opus 4.6, 2026-03-25): **Preset-Generator** — Description→Preset (40+ Keywords), Sound-Matching, Smart-Randomize (5 Characters), Describe
- [x] (Claude Opus 4.6, 2026-03-25): **KI-Panel** — 6 neue Quick Prompts (Genre/Referenz/Preset-Gen/Smart-Rnd/Preset-Info)

- [ ] AVAILABLE: **P4A MIDI-Mapping** — Launchpad/APC40 Hardware-Mapping
- [ ] AVAILABLE: **P4A Live-Performance-Modus** — Vollbild, Touch-optimiert
- [ ] AVAILABLE: **P4B Hardware Auto-Config** — Controller-Erkennung, OSC
- [ ] AVAILABLE: **P6A Macro-System** — Aktionen aufzeichnen → Script exportieren
- [ ] AVAILABLE: **P6A Dokumentation** — "Schreibe deinen ersten Plugin in 10 Minuten"
- [ ] AVAILABLE: **P7A Video-Sync** — Video-Spur im Arranger

## v0.0.20.808 — P2C Melodie/Kontrapunkt + P3A/B/C Smart Mixer/Auto-Mix/Mastering + P4C Live FX

- [x] (Claude Opus 4.6, 2026-03-25): **Melody Generator** — Bassline (5 Stile), Melody (5 Contours), Counterpoint, Motif Development (8 Techniken)
- [x] (Claude Opus 4.6, 2026-03-25): **Smart Mixer** — LUFS/Peak/RMS, Spectral Analysis, Stereo, Freq Conflicts, Auto-Gain, Recommendations
- [x] (Claude Opus 4.6, 2026-03-25): **Auto-Mix** — One-Click-Mix (6 Genres), Reference Matching, Track Role Detection, Demucs Stub
- [x] (Claude Opus 4.6, 2026-03-25): **Mastering** — Full Chain, 8 Platform Targets, True-Peak Limiter, A/B Comparison
- [x] (Claude Opus 4.6, 2026-03-25): **Live FX** — Stutter, Live Looper (State Machine), Beat Repeat, Capture MIDI
- [x] (Claude Opus 4.6, 2026-03-25): **KI-Panel** — 6 neue Quick Prompts (Bassline/Melodie/Kontrapunkt/Motiv/Mix-Check)

- [ ] AVAILABLE: **P2D Synth-Preset-Generator** — Beschreibung → AETERNA-Preset
- [ ] AVAILABLE: **P4A MIDI-Mapping** — Launchpad/APC40 Hardware-Mapping
- [ ] AVAILABLE: **P4A Live-Performance-Modus** — Vollbild, Touch-optimiert
- [ ] AVAILABLE: **P4B Hardware Auto-Config** — Controller-Erkennung
- [ ] AVAILABLE: **Smart Mixer UI** — Heatmap-Visualisierung im Mixer

## v0.0.20.807 — P2A/P2B/P2E KI-Komposition + Harmonie/Rhythmus-Analyse

- [x] (Claude Opus 4.6, 2026-03-25): **Harmony Analysis Engine** — Key Detection, Chord Recognition, Roman Numerals, Tension Curve
- [x] (Claude Opus 4.6, 2026-03-25): **Rhythm Analysis Engine** — Density, Syncopation, Swing, Genre Hints, Groove Extraction
- [x] (Claude Opus 4.6, 2026-03-25): **Chord Progression Generator** — 10 Stile, Auto-Insert, Voicings
- [x] (Claude Opus 4.6, 2026-03-25): **KI-Panel Erweiterung** — 3 neue Quick Prompts (Harmonie/Rhythmus/ChordProg)

- [ ] AVAILABLE: **P2B Mix-Analyse** — Audio-basierte Mix-Empfehlungen
- [ ] AVAILABLE: **P2C Kontrapunkt-Assistent** — KI-Gegenstimme zu Melodie
- [ ] AVAILABLE: **P2C Bassline-Generator** — Chord Progression → Bassline
- [ ] AVAILABLE: **P2D Synth-Preset-Generator** — Beschreibung → AETERNA-Preset
- [ ] AVAILABLE: **P3A Smart Mixer** — Auto-Gain-Staging, Frequenz-Konflikte

## v0.0.20.806 — P1B Pitch Correction + Spectral Repair + P1C Audio Quantize

- [x] (Claude Opus 4.6, 2026-03-25): **Pitch Correction Engine** — YIN detection, PitchBlob, auto-correct chromatic/scale, PV pitch-shift
- [x] (Claude Opus 4.6, 2026-03-25): **Spectral Repair Engine** — STFT, noise profile, spectral subtraction, freq-band edit, hum removal
- [x] (Claude Opus 4.6, 2026-03-25): **Audio Quantize Engine** — Transient detection, grid quantize, MPC swing, elastic audio
- [x] (Claude Opus 4.6, 2026-03-25): **UI Integration** — 3 Kontextmenü-Submenüs + 13 Aktionen im Audio-Editor

- [ ] AVAILABLE: **Pitch Correction Blob-Editor UI** — Melodyne-ähnliche Noten-Ansicht im Audio-Editor
- [ ] AVAILABLE: **Spectral Repair View** — Spektrogramm-Ansicht mit Selektions-Werkzeug
- [ ] AVAILABLE: **P2A Variations-Generator** — Clip → 4 KI-Variationen generieren
- [ ] AVAILABLE: **P2A Chord-Progression-AI** — Akkordfolgen vorschlagen
- [ ] AVAILABLE: **P2B Mix-Analyse** — KI-basierte Mix-Empfehlungen

## v0.0.20.800 — Batch-Processing CLI + Custom Plugin API

- [x] (Claude Opus 4.6, 2026-03-24): **Batch-Processing CLI** — batch_process.py: --exec/--script/--export/--info/--project-dir
- [x] (Claude Opus 4.6, 2026-03-24): **Custom Plugin API** — PyDawEffect/Instrument/MidiFx + Registry + Scanner
- [x] (Claude Opus 4.6, 2026-03-24): **Scripting UI-Sync** — BPM/Track-Attribute → GUI-Update (v0.0.20.799)

- [ ] AVAILABLE: **Custom Plugins Device Panel** — Laden/Anzeigen/Parameter-Knobs in der GUI
- [ ] AVAILABLE: **P6A Macro-System** — UI-Aktionen aufzeichnen → Script exportieren
- [ ] AVAILABLE: **P5B Cloud-Projekt-Management** — Preset-Cloud, Sample-Cloud
- [ ] AVAILABLE: **Dokumentation + Tutorials** — User-Manual, Plugin-Tutorial

## v0.0.20.798 — Phase 5A Wiring + Phase 6A Python Scripting

- [x] (Claude Opus 4.6, 2026-03-24): **CollabPanel in MainWindow** — Dock-Widget, Ctrl+Alt+C
- [x] (Claude Opus 4.6, 2026-03-24): **Services verdrahtet** — Git/Review/Scripting im ServiceContainer
- [x] (Claude Opus 4.6, 2026-03-24): **websockets Dependency** — requirements.txt + install.py
- [x] (Claude Opus 4.6, 2026-03-24): **ScriptingService** — Sandboxed Python, Proxy-API, Built-in Scripts
- [x] (Claude Opus 4.6, 2026-03-24): **ScriptingPanel** — Console + Library UI, Ctrl+Alt+P
- [x] (Claude Opus 4.6, 2026-03-24): **Menü-Einträge** — Kollaboration + Python Console im Projekt-Menü

- [ ] AVAILABLE: **Hardware-Test Console** — Ctrl+Alt+P → project.bpm = 140 → BPM ändert sich
- [ ] AVAILABLE: **Hardware-Test Collab** — Ctrl+Alt+C → Git Init → Commit → Branch
- [ ] AVAILABLE: **P6A Macro-System** — UI-Aktionen aufzeichnen → Script exportieren
- [ ] AVAILABLE: **P5B Cloud-Projekt-Management** — Preset-Cloud, Sample-Cloud

## v0.0.20.797 — Phase 5A: Kollaboration & Git-Integration

- [x] (Claude Opus 4.6, 2026-03-24): **Git Integration Service** — init, commit, branch, merge, push/pull, stash, tags
- [x] (Claude Opus 4.6, 2026-03-24): **Collab Server** — WebSocket, Track-Locking, Chat, Presence, Full Sync
- [x] (Claude Opus 4.6, 2026-03-24): **Collab Client** — Connect, Callbacks, send_op/cursor/chat/lock
- [x] (Claude Opus 4.6, 2026-03-24): **Review Service** — Comments, Markers, Tasks, Markdown Export
- [x] (Claude Opus 4.6, 2026-03-24): **Collab Panel UI** — 3-Tab Dock-Widget (Git/Collab/Review)
- [x] (Claude Opus 4.6, 2026-03-24): **Project.review_data** — Persistenz-Feld im Model

- [ ] AVAILABLE: **CollabPanel in MainWindow einbinden** — als Dock-Widget registrieren
- [ ] AVAILABLE: **Services verdrahten** — Git/Collab/Review im ServiceContainer
- [ ] AVAILABLE: **websockets Dependency** — pip install websockets, requirements.txt
- [ ] AVAILABLE: **P5B Cloud-Projekt-Management** — Preset-Cloud, Sample-Cloud
- [ ] AVAILABLE: **Git Workflow testen** — Init → Commit → Branch → Merge auf Hardware

## v0.0.20.796 — CLAP Segfault Fix + Comping Workflow

- [x] (Claude Opus 4.6, 2026-03-24): **CLAP Segfault Root Cause** — Race: process() auf destroyed plugin_ptr
- [x] (Claude Opus 4.6, 2026-03-24): **Fix _ClapPlugin.close()** — _ok=False first, 20ms sleep, local refs
- [x] (Claude Opus 4.6, 2026-03-24): **Fix ClapFx/ClapInstrumentEngine.shutdown()** — _ok=False first
- [x] (Claude Opus 4.6, 2026-03-24): **Fix ClapInstrumentEngine.pull()** — local ref caching
- [x] (Claude Opus 4.6, 2026-03-24): **Fix Vst3InstrumentEngine** — shutdown _ok first + pull local ref
- [x] (Claude Opus 4.6, 2026-03-24): **Fix audio_engine Phase 4** — unregister→sleep→shutdown
- [x] (Claude Opus 4.6, 2026-03-24): **Drag-Comp-Tool** — Region-Auswahl per Drag in Take-Lanes
- [x] (Claude Opus 4.6, 2026-03-24): **Take-Lane Farben** — 8-Farben-Palette + Nummerierung
- [x] (Claude Opus 4.6, 2026-03-24): **flatten_comp()** — Audio-Merge mit Crossfades
- [x] (Claude Opus 4.6, 2026-03-24): **Flatten Comp Menü** — Kontextmenü-Aktion im Arranger

- [ ] AVAILABLE: **Hardware-Test CLAP Segfault** — Surge XT laden, Tracks wechseln, kein Crash
- [ ] AVAILABLE: **Comping-Test** — Loop-Recording → Take-Lanes → Drag → Flatten
- [ ] AVAILABLE: **P1B Pitch-Correction** — Melodyne-ähnlich
- [ ] AVAILABLE: **P1C Audio-Quantisierung** — Transientenbasiert

## v0.0.20.792 — Rust-Engine Disconnect-Loop Fix

- [x] (Claude Opus 4.6, 2026-03-24): **Root Cause** — start_engine() löschte Socket der externen Engine
- [x] (Claude Opus 4.6, 2026-03-24): **Fix start_engine()** — Try existing socket first, nur Subprocess wenn nötig
- [x] (Claude Opus 4.6, 2026-03-24): **Fix reconnect** — Socket-first auch ohne self._process

- [ ] AVAILABLE: **Zielrechner-Test** — Disconnect-Loop sollte weg sein

## v0.0.20.790 — C-Speed ALL FX Complete

- [x] (Claude Opus 4.6, 2026-03-24): **Gate C-Extension** — 1275x RT, SC-Fallback
- [x] (Claude Opus 4.6, 2026-03-24): **DeEsser C-Extension** — 528x RT, Listen-Fallback
- [x] (Claude Opus 4.6, 2026-03-24): **10 C-Funktionen total** — Alle per-sample FX auf C portiert

- [ ] AVAILABLE: **Hardware-Test** — Alle C-Extensions auf Zielrechner
- [ ] AVAILABLE: **should_use_rust() aktivieren** — Hybrid-Mode freischalten

## v0.0.20.789 — C-Speed Creative FX (Chorus/Phaser/Flanger)

- [x] (Claude Opus 4.6, 2026-03-24): **Chorus C-Extension** — Multi-Voice Delay + LUT, 37x RT
- [x] (Claude Opus 4.6, 2026-03-24): **Phaser C-Extension** — N-Stage Allpass + Sweep, 41x RT
- [x] (Claude Opus 4.6, 2026-03-24): **Flanger C-Extension** — Modulated Comb + Feedback, 38x RT

- [x] (Claude Opus 4.6, 2026-03-24): **Utility FX C portiert** — Gate/DeEsser/StereoWidener
- [ ] AVAILABLE: **Hardware-Test** — Alle C-Extensions auf Zielrechner testen

## v0.0.20.788 — C-Speed Reverb + Delay

- [x] (Claude Opus 4.6, 2026-03-24): **Reverb C-Extension** — Schroeder 4C+4AP, 201x RT
- [x] (Claude Opus 4.6, 2026-03-24): **Delay C-Extension** — Stereo+LP+PingPong, 610x RT
- [x] (Claude Opus 4.6, 2026-03-24): **Auto-Compile Loader** — _load_builtin_fx_lib() mit gcc Fallback

- [x] (Claude Opus 4.6, 2026-03-24): **Creative FX C portiert** — Chorus/Phaser/Flanger/Distortion/Tremolo
- [x] (Claude Opus 4.6, 2026-03-24): **Utility FX C portiert** — Gate/DeEsser/StereoWidener

## v0.0.20.787 — Comb C-Extension + Export Verification + Beta Changelog

- [x] (Claude Opus 4.6, 2026-03-24): **Comb Filter C anbinden** — 1630x RT via fast_filters.so
- [x] (Claude Opus 4.6, 2026-03-24): **Export + Audio verifiziert** — 6 OSC-Typen, WAV, Dither OK
- [x] (Claude Opus 4.6, 2026-03-24): **Beta-Changelog v0.1.0 aktualisiert** — Performance-Sektion, Fusion erweitert

- [ ] AVAILABLE: **Hardware-Test auf Zielrechner** — FusionEngine + C-Filter auf Linux/Debian testen
- [ ] AVAILABLE: **should_use_rust() aktivieren** — Hybrid-Mode für Built-in FX freischalten
- [ ] AVAILABLE: **cargo build --release** — Rust-Engine kompilieren + testen
- [ ] AVAILABLE: **Recording-Workflow** — Input-Monitoring < 10ms, Waveform-Preview

## v0.0.20.786 — C-Speed Filters (SVF/Ladder/Comb)

## v0.0.20.785 — Vectorized Bite/Union/Swarm Oscillators

- [x] (Claude Opus 4.6, 2026-03-24): **Union vektorisiert** — 3 Phasen numpy, 178x RT
- [x] (Claude Opus 4.6, 2026-03-24): **Bite RING+PWM vektorisiert** — _vec_wave Helpers, 410x RT (RING)
- [x] (Claude Opus 4.6, 2026-03-24): **Swarm Saw vektorisiert** — _vec_saw_polyblep, 107x RT (8 Voices)
- [x] (Claude Opus 4.6, 2026-03-24): **Shared Helpers** — _vec_saw_polyblep, _vec_pulse_polyblep, _vec_wave

- [x] (Claude Opus 4.6, 2026-03-24): **SVF/Ladder C-Extension** — Erledigt in v0.0.20.786
- [ ] N/A: **Phase1 vektorisieren** — Feedback-Loop macht Vektorisierung unmöglich, bleibt per-sample (~51x RT, ausreichend)

## v0.0.20.784 — Vectorized Fusion Synth DSP

- [x] (Claude Opus 4.6, 2026-03-24): **Fusion Synth vektorisieren** — Saw/Pulse/Sine-Fold/Triangle-Fold Oscillatoren, ADSR/AR/AD/Pluck Envelopes, Highpass, Brown Noise
- [x] (Claude Opus 4.6, 2026-03-24): **ADSR Hybrid Render** — 37x schneller, numpy für Sustain/OFF, per-sample für Transitionen
- [x] (Claude Opus 4.6, 2026-03-24): **PluckEnvelope scipy.lfilter** — LP-Filter vektorisiert mit Fallback
- [x] (Claude Opus 4.6, 2026-03-24): **Brown Noise np.cumsum** — Ersetzt per-sample Loop

- [x] (Claude Opus 4.6, 2026-03-24): **SVF/Ladder C-Extension** — Erledigt in v0.0.20.786
- [x] (Claude Opus 4.6, 2026-03-24): **Bite/Union/Swarm vektorisiert** — Siehe v0.0.20.785
- [ ] AVAILABLE: **Fusion Hardware-Test** — A/B Vergleich Oszillator-Output vor/nach Vektorisierung

## v0.0.20.783 — Export Fix (Offline-Rendering + Dateiname)

- [x] (Claude Opus 4.6, 2026-03-23): **render_offline() umgeschrieben** — Echtes Offline-Rendering statt kaputtem Realtime-Capture
- [x] (Claude Opus 4.6, 2026-03-23): **Export-Dialog Save-Dialog** — User wählt Dateiname + Ordner statt nur Ordner
- [x] (Claude Opus 4.6, 2026-03-23): **Export-Service Dateiname** — User-Input direkt nutzen, kein BPM-Suffix
- [x] (Claude Opus 4.6, 2026-03-23): **Stem-Export track_ids Filter** — Einzelne Spuren exportierbar

- [x] (Claude Opus 4.6, 2026-03-24): **Export getestet** — Datei → Exportieren → Dateiname → Datei im Ordner prüfen
- [x] (Claude Opus 4.6, 2026-03-24): **Audio-Inhalt verifiziert** — Nicht nur Stille, sondern echte Instrument-Audio

## v0.0.20.782 — IPC-Only Engine (cpal entfernt, Listener-Loop)

- [x] (Claude Opus 4.6, 2026-03-23): **cpal Audio-Output entfernt** — Engine produziert keinen eigenen PipeWire-Node mehr
- [x] (Claude Opus 4.6, 2026-03-23): **Listener-Loop** — Engine überlebt Client-Disconnects, wartet auf Reconnect
- [x] (Claude Opus 4.6, 2026-03-23): **Command-Drain-Ticker** — 100Hz Thread ersetzt cpal-Callback
- [x] (Claude Opus 4.6, 2026-03-23): **Rust Engine Disconnect** — Root Cause war Buffer-Size-Mismatch (cpal 1024 vs Graph 512)

- [ ] AVAILABLE: **cargo build --release testen** — Build ohne cpal sollte schneller sein + keine ALSA-Dev nötig
- [ ] AVAILABLE: **PipeWire Graph verifizieren** — Nur noch 1 Audio-Node (Python), nicht 2
- [x] (Claude Opus 4.6, 2026-03-23): **Export testen** — Offline-Rendering implementiert in v0.0.20.783
- [ ] AVAILABLE: **Phase R12: IPC Audio-Buffer Bridge** — Rust rendert Tracks → Python holt Buffers via IPC

## v0.0.20.777 — C-Speed Built-in FX

- [x] (Claude Opus 4.6, 2026-03-23): **Compressor** — numpy peaks + tight envelope + numpy gain
- [x] (Claude Opus 4.6, 2026-03-23): **Limiter** — numpy abs/max + envelope + numpy multiply
- [x] (Claude Opus 4.6, 2026-03-23): **Distortion** — numpy LUT indexing + scipy tone
- [x] (Claude Opus 4.6, 2026-03-23): **Tremolo** — numpy phase + LUT + gain
- [x] (Claude Opus 4.6, 2026-03-23): **StereoWidener** — pure numpy M/S (kein Loop)
- [x] (Claude Opus 4.6, 2026-03-23): **Utility** — numpy gain/pan/phase + scipy DC blocker

## v0.0.20.776 — Vectorized Sampler DSP

- [x] (Claude Opus 4.6, 2026-03-23): **ProSampler Fast-Path** — Vektorisierter pull_fast(), ~24x schneller
- [x] (Claude Opus 4.6, 2026-03-23): **MultiSample Fast-Path** — Vektorisierter render_voice_fast(), ~20x schneller
- [x] (Claude Opus 4.6, 2026-03-23): **Block-ADSR** — generate_envelope_block() numpy statt per-sample
- [x] (Claude Opus 4.6, 2026-03-23): **EQ C-Level** — scipy.signal.lfilter statt Python Biquad Loop, ~50x schneller

## v0.0.20.775 — Realtime Audio Performance Fix

- [x] (Claude Opus 4.6, 2026-03-23): **RT-Thread-Priority** — SCHED_FIFO + GC disable + mlockall
- [x] (Claude Opus 4.6, 2026-03-23): **Hot-Swap ArrangementState** — Eliminiert 3s Aussetzer bei MIDI-Edits
- [x] (Claude Opus 4.6, 2026-03-23): **Lock-Free Audio Callback** — VST2 host + pull_sources ohne Locks
- [x] (Claude Opus 4.6, 2026-03-23): **MIDI Debounce 200ms** — Weniger Hot-Swaps bei schnellem Editieren

- [x] (Claude Opus 4.6, 2026-03-24): **Fusion Synth vektorisiert** — Saw/Pulse/Sine/Triangle/ADSR/AR/AD/Pluck/HP/Noise
- [ ] AVAILABLE: **RT-Permissions testen** — ulimit -r prüfen, limits.conf @audio Gruppe
- [ ] AVAILABLE: **Rust Engine aktivieren** — should_use_rust() → True für Built-in FX
- [ ] AVAILABLE: **Hardware-Test BRRR PADsynth** — A/B-Vergleich mit ZynAdd, alle Tonlagen
- [ ] AVAILABLE: **Rust bauen + P0A testen** — `cd pydaw_engine && cargo build --release`
- [x] (Claude Opus 4.6, 2026-03-24): **Beta-Changelog geschrieben** — CHANGELOG v0.1.0-beta schreiben
- [ ] AVAILABLE: **P1A Recording-Workflow** — Input-Monitoring < 10ms, Waveform-Preview während Recording



## v0.0.20.828 — VST3 Main-Thread Instrument Load

- [x] (OpenAI GPT-5.4 Thinking, 2026-03-26): **VST3-Instrument-Load entkoppelt** — Worker beruehrt Surge XT / Nekobi / andere VST3-Instrumente nicht mehr vor dem Main-Thread
- [ ] AVAILABLE: **Hardware-Test VST3-Instrumente** — Surge XT.vst3 + Nekobi.vst3 auf Sound, Editor, Reopen, Parameter pruefen
- [ ] AVAILABLE: **Hardware-Test Surge XT CLAP Editor-Surrogate** — Linux/X11: Editor oeffnen/schliessen, Parameter-Sync, Preset-Wechsel pruefen
