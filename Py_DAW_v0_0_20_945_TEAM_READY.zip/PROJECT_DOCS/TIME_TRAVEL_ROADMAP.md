# 🕰️ Py_DAW TIME-TRAVEL ENGINE — Roadmap

**Projekt:** Py_DAW (ChronoScaleStudio)
**Feature:** Time-Travel Engine + KI-Sound-Gedächtnis
**Erstellt:** 2026-03-31 (v0.0.20.897)
**Autor:** Anno (Konzept) + Claude Opus 4.6 (Architektur + KI-Innovationen)

---

## ⚠️ OBERSTE DIREKTIVE — FÜR ALLE KOLLEGEN

```
🔴 DU DARFST NICHTS KAPUTT MACHEN. DAS IST DIE OBERSTE DIREKTIVE.
🔴 Alle bestehenden Features müssen nach deiner Arbeit funktionieren.
🔴 Die Time-Travel Engine ist ein NEUES Subsystem — kein bestehendes umbauen.
🔴 Teste IMMER mit: python3 -c "import py_compile; ..."
```

---

## 🧠 VISION — Was es so noch nie gab

### Das Problem (jede DAW hat es)
Du schraubst an einem Sound, spielst rum, findest etwas Geniales —
und 5 Minuten später ist es weg. Du weißt nicht mehr welche Regler
wo standen. Ableton hat "Capture MIDI" aber das fängt nur Noten ein,
nicht den Sound selbst. Kein einziges DAW hat:

- "Geh zurück zu dem Sound von vor 3 Minuten" (Parameter + Noten + FX)
- "Finde den warmen Pad-Sound den ich letzte Woche Dienstag gemacht habe"
- "Zeig mir alle Momente wo ich am Filter gedreht habe"
- "Morph langsam von meinem aktuellen Sound zu dem von vor 10 Minuten"

### Py_DAW wird die ERSTE DAW die das kann.

### Was uns einzigartig macht (Feature-Matrix)

```
Feature                     Ableton  Bitwig  Cubase  Py_DAW
─────────────────────────────────────────────────────────────
Capture MIDI                  ✅      ❌      ❌      ✅
Capture Parameter-State       ❌      ❌      ❌      ✅ NEU
Undo (linear)                 ✅      ✅      ✅      ✅
Undo-Baum (Git-Style)         ❌      ❌      ❌      ✅ NEU
Zeitpunkt-Suche (FTS5)        ❌      ❌      ❌      ✅ NEU
Sound-Suche per Text          ❌      ❌      ❌      ✅ NEU
KI-Auto-Tagging der Session   ❌      ❌      ❌      ✅ NEU
Parameter-Morphing (A→B)      ❌      ✅*     ❌      ✅ NEU
Cross-Projekt Sound-DNA        ❌      ❌      ❌      ✅ NEU
Live Recall (ohne Stop)       ❌      ❌      ❌      ✅ NEU
Session-Heatmap (Aktivität)   ❌      ❌      ❌      ✅ NEU

* Bitwig hat Parameter-Modulation, aber kein historisches Morphing
```

---

## 🏗️ ARCHITEKTUR

```
┌─────────────────────────────────────────────────────────┐
│  Qt6 GUI (Python)                                        │
│  ┌─────────────────┐ ┌──────────────┐ ┌───────────────┐ │
│  │ Time-Travel      │ │ Sound Search │ │ Session       │ │
│  │ Timeline Widget  │ │ Panel (FTS5) │ │ Heatmap       │ │
│  │ (Slider + Ghost) │ │ "warm pad"   │ │ Visualizer    │ │
│  └────────┬─────────┘ └──────┬───────┘ └───────┬───────┘ │
│           │                  │                 │         │
│  ┌────────▼──────────────────▼─────────────────▼───────┐ │
│  │ TimeTravel Service (Python)                          │ │
│  │ - Koordiniert GUI ↔ Journal ↔ Restore               │ │
│  │ - Verwaltet Undo-Baum (nicht Stack!)                │ │
│  │ - KI-Auto-Tagging + Semantic Search                 │ │
│  └────────┬────────────────────────────────────────────┘ │
└───────────┼──────────────────────────────────────────────┘
            │ IPC (MessagePack / SharedMem)
┌───────────▼──────────────────────────────────────────────┐
│  Rust Audio Engine                                        │
│  ┌──────────────────────────────────────────────────────┐ │
│  │ Journal Writer (Lock-Free Ringbuffer)                 │ │
│  │ - MIDI Events: Note, CC, Pitch Bend, Aftertouch      │ │
│  │ - Param Changes: Plugin-ID + Param-ID + Value + Time  │ │
│  │ - Audio Fingerprints: 128-dim Vektor alle 500ms       │ │
│  │ → Flush zu SQLite (Background Thread, WAL mode)       │ │
│  └──────────────────────────────────────────────────────┘ │
│  ┌──────────────────────────────────────────────────────┐ │
│  │ State Reconstructor                                   │ │
│  │ - Baut den kompletten Engine-State aus Journal auf    │ │
│  │ - Kann zu jedem Zeitpunkt t rekonstruieren            │ │
│  │ - Diff-basiert: nur Änderungen gespeichert            │ │
│  └──────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────┘
            │
┌───────────▼──────────────────────────────────────────────┐
│  SQLite (pydaw.db)                                        │
│  ┌──────────────────────────────────────────────────────┐ │
│  │ journal_events       — Rohe Events (MIDI + Params)    │ │
│  │ journal_snapshots    — Periodische Voll-Snapshots     │ │
│  │ journal_tags         — KI-generierte Beschreibungen   │ │
│  │ journal_tags_fts     — FTS5 Volltext-Suche            │ │
│  │ journal_audio_fp     — Audio-Fingerprints (Vektoren)  │ │
│  │ journal_branches     — Undo-Baum (Git-Style)          │ │
│  │ sound_dna            — Cross-Projekt Sound-Signaturen │ │
│  └──────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────┘
```

---

## 📋 PHASEN-PLAN

### Abhängigkeiten

```
T1 (Journal DB) → T2 (Journal Writer) → T3 (Restore) → T4 (UI)
                                       ↗ T5 (Search)
T2 → T6 (Auto-Tag) → T7 (Sound Search)
T3 → T8 (Undo-Baum) → T9 (Branch UI)
T6 → T10 (Sound DNA) → T11 (Cross-Projekt)
T3 → T12 (Live Recall) → T13 (Parameter Morphing)
T4 → T14 (Session Heatmap)
```

### Empfohlene Reihenfolge

```
T1 → T2 → T3 → T4 → T5 → T6 → T7 (Kern-Feature, ~8-10 Sessions)
T8 → T9 (Undo-Baum, ~3 Sessions)
T10 → T11 (Sound DNA, ~3 Sessions)
T12 → T13 (Live Morphing, ~3 Sessions)
T14 (Heatmap, ~1 Session)
```

---

## 🔧 PHASE T1: Journal Database Schema

**Priorität:** 🔴 KRITISCH — Fundament für alles
**Aufwand:** 1 Session
**Datei:** `pydaw/services/time_travel_db.py`

### Tabellen

- [x] `journal_events`  *(v0.0.20.898)* — Alle Events (MIDI + Parameter-Änderungen)
  ```sql
  CREATE TABLE journal_events (
      id            INTEGER PRIMARY KEY,
      session_id    TEXT NOT NULL,        -- Pro DAW-Session eine ID
      timestamp_ms  INTEGER NOT NULL,     -- Millisekunden seit Session-Start
      wall_clock    REAL NOT NULL,        -- Unix-Timestamp (für "letzte Woche")
      event_type    TEXT NOT NULL,        -- 'midi_note_on','midi_note_off','midi_cc',
                                          -- 'param_change','plugin_load','plugin_remove'
      track_id      TEXT NOT NULL DEFAULT '',
      plugin_id     TEXT NOT NULL DEFAULT '',
      param_id      TEXT NOT NULL DEFAULT '',
      value_float   REAL,                 -- Param-Wert oder Velocity
      value_int     INTEGER,              -- MIDI Note, CC Number
      value_text    TEXT DEFAULT '',       -- Plugin-Name, Preset-Name
      meta_json     TEXT DEFAULT '{}'      -- Zusätzliche Daten
  );
  CREATE INDEX idx_je_time ON journal_events(session_id, timestamp_ms);
  CREATE INDEX idx_je_track ON journal_events(track_id, timestamp_ms);
  CREATE INDEX idx_je_type ON journal_events(event_type, timestamp_ms);
  ```

- [x] `journal_snapshots`  *(v0.0.20.898)* — Periodische Voll-Snapshots (alle 30s)
  ```sql
  CREATE TABLE journal_snapshots (
      id            INTEGER PRIMARY KEY,
      session_id    TEXT NOT NULL,
      timestamp_ms  INTEGER NOT NULL,
      wall_clock    REAL NOT NULL,
      snapshot_json TEXT NOT NULL,          -- Kompletter State als JSON
      track_count   INTEGER DEFAULT 0,
      clip_count    INTEGER DEFAULT 0,
      bpm           REAL DEFAULT 120.0,
      label         TEXT DEFAULT ''         -- User-Label oder Auto-Label
  );
  CREATE INDEX idx_js_time ON journal_snapshots(session_id, timestamp_ms);
  ```

- [x] `journal_tags`  *(v0.0.20.898)* — KI-generierte Beschreibungen
  ```sql
  CREATE TABLE journal_tags (
      id            INTEGER PRIMARY KEY,
      session_id    TEXT NOT NULL,
      timestamp_ms  INTEGER NOT NULL,
      wall_clock    REAL NOT NULL,
      tag_text      TEXT NOT NULL,          -- "Warmer Pad, Filter Sweep, C-Moll"
      confidence    REAL DEFAULT 1.0,
      source        TEXT DEFAULT 'auto'     -- 'auto','user','ai'
  );
  ```

- [x] `journal_tags_fts`  *(v0.0.20.898)* — FTS5 Volltext-Suche über Tags
  ```sql
  CREATE VIRTUAL TABLE journal_tags_fts USING fts5(
      tag_text,
      content='journal_tags',
      content_rowid='id'
  );
  ```

- [x] `journal_audio_fp`  *(v0.0.20.898)* — Audio-Fingerprints (Sound-Signaturen)
  ```sql
  CREATE TABLE journal_audio_fp (
      id            INTEGER PRIMARY KEY,
      session_id    TEXT NOT NULL,
      timestamp_ms  INTEGER NOT NULL,
      track_id      TEXT DEFAULT '',
      fingerprint   BLOB NOT NULL,         -- 128-dim Float32 Vektor
      spectral_centroid REAL DEFAULT 0,    -- Für schnelle Vorfilterung
      rms_db        REAL DEFAULT -60,
      dominant_pitch REAL DEFAULT 0
  );
  CREATE INDEX idx_jafp_time ON journal_audio_fp(session_id, timestamp_ms);
  ```

- [x] `journal_branches`  *(v0.0.20.898)* — Undo-Baum (Git-Style)
  ```sql
  CREATE TABLE journal_branches (
      id            INTEGER PRIMARY KEY,
      session_id    TEXT NOT NULL,
      branch_name   TEXT NOT NULL DEFAULT 'main',
      parent_branch_id INTEGER,            -- NULL = Root
      fork_timestamp_ms INTEGER NOT NULL,  -- Wann abgezweigt
      snapshot_id   INTEGER,               -- Referenz auf journal_snapshots
      is_active     INTEGER DEFAULT 0,
      created_at    REAL NOT NULL,
      description   TEXT DEFAULT ''
  );
  ```

- [x] `sound_dna`  *(v0.0.20.898)* — Cross-Projekt Sound-Signaturen
  ```sql
  CREATE TABLE sound_dna (
      id            INTEGER PRIMARY KEY,
      project_path  TEXT NOT NULL,
      track_id      TEXT NOT NULL,
      plugin_id     TEXT NOT NULL,
      preset_name   TEXT DEFAULT '',
      param_hash    TEXT NOT NULL,          -- SHA256 der sortierten Param-Werte
      fingerprint   BLOB,                  -- Audio-Fingerprint
      tags          TEXT DEFAULT '',
      created_at    REAL NOT NULL,
      UNIQUE(project_path, track_id, param_hash)
  );
  CREATE INDEX idx_sdna_plugin ON sound_dna(plugin_id);
  ```

- [x] `TimeTravel DB Service`  *(v0.0.20.898)* — Singleton mit ensure_loaded(), WAL mode
- [x] Compile-Test + Doku  *(v0.0.20.898)*

---

## 🔧 PHASE T2: Journal Writer (Python-first, Rust später)

**Priorität:** 🔴 KRITISCH
**Aufwand:** 2 Sessions
**Dateien:** `pydaw/services/time_travel_journal.py`

### Was wird geloggt

- [x] MIDI Events: Note On/Off  *(v0.0.20.898)*, CC, Pitch Bend, Aftertouch
  - Hook in: `midi_manager.py` → `message_received` Signal
  - Daten: track_id, channel, note/cc, velocity/value, timestamp

- [x] Parameter-Änderungen: Jeder Regler  *(v0.0.20.898)*, jeder Fader
  - Hook in: `midi_mapping_service.py` → nach apply_value()
  - Hook in: `device_panel.py` → nach Slider/Knob change
  - Hook in: `mixer.py` → nach Volume/Pan/Mute/Solo change
  - Daten: track_id, plugin_id, param_name, old_value, new_value

- [x] Plugin-Events: Load, Remove  *(v0.0.20.898)*, Preset-Wechsel
  - Hook in: `device_panel.py` → nach add/remove device
  - Daten: track_id, plugin_id, plugin_name, preset_name

- [x] Transport-Events: Play, Stop  *(v0.0.20.898)*, Record, BPM-Change
  - Hook in: `transport_service.py`
  - Daten: action, bpm, position

### Snapshot-Timer

- [x] Alle 30 Sekunden: Kompletter  *(v0.0.20.898)* Projekt-State als JSON-Snapshot
  - Nutzt bestehenden `Project.to_dict()` → JSON
  - Speichert nur Diff zum letzten Snapshot (Platzersparnis)
  - Label: Auto-generiert aus den letzten Events
    ("Filter Sweep auf Track 3", "MIDI Recording auf Bass")

### Performance-Design

- [x] Batch-Writer: Events werden  *(v0.0.20.898)* in Memory-Queue gesammelt
  - Flush alle 500ms oder bei 100+ Events in Queue
  - SQLite WAL mode → kein GUI-Blocking
  - Maximale Write-Latenz: < 2ms

- [x] Session-Management:  *(v0.0.20.898)*
  - Neue Session-ID bei jedem DAW-Start
  - Session-Metadata: Start-Zeit, Projekt-Pfad, BPM

- [x] Speicher-Budget:  *(v0.0.20.898)*
  - Max 50.000 Events pro Session (dann älteste löschen)
  - Max 200 Snapshots pro Session
  - Konfigurierbarer Zeitraum (Default: letzte 2 Stunden)

---

## 🔧 PHASE T3: State Reconstruction (Restore)

**Priorität:** 🔴 KRITISCH
**Aufwand:** 2 Sessions
**Datei:** `pydaw/services/time_travel_restore.py`

### Restore-Algorithmus

- [x] **Snapshot + Replay**  *(v0.0.20.901)*: Um Zustand zum Zeitpunkt t zu rekonstruieren:
  1. Finde den letzten Snapshot VOR Zeitpunkt t
  2. Lade den Snapshot als Basis-State
  3. Replay alle Events zwischen Snapshot und t
  4. Ergebnis = exakter State zum Zeitpunkt t

- [x] **Selective Restore**  *(v0.0.20.901)*: Nicht alles wiederherstellen
  - Nur Track X → nur Events für track_id=X replayed
  - Nur Mixer → nur volume/pan/mute Events
  - Nur ein Plugin → nur param_change für plugin_id=X
  - Nur MIDI → nur Noten, keine Parameter

- [x] **Preview Mode**  *(v0.0.20.901)*: State temporär laden ohne Commit
  - "Probehören" eines alten Zustands
  - Cancel → zurück zum aktuellen State
  - Confirm → State übernehmen + als Undo-Punkt speichern

- [x] **Safety Guard**  *(v0.0.20.901)*:
  - Vor jedem Restore: aktuellen State als Snapshot sichern
  - "Restore rückgängig machen" ist immer möglich (undo_restore())
  - Kein Datenverlust bei Restore — nur Überschreiben

### Anwendung auf Engine

- [x] Mixer-Restore: Volume/Pan/Mute/Solo auf Tracks setzen  *(v0.0.20.901)*
- [x] Plugin-Param-Restore: Parameter auf Plugin-Instanzen anwenden  *(v0.0.20.901)*
- [x] MIDI-Restore: Noten als neuen Clip in Timeline einfügen  *(v0.0.20.901)*
- [x] BPM/Transport-Restore: Projekt-Tempo setzen  *(v0.0.20.901)*

---

## 🔧 PHASE T4: Time-Travel UI

**Priorität:** 🟠 HOCH
**Aufwand:** 2-3 Sessions
**Datei:** `pydaw/ui/time_travel_panel.py`

### Timeline Widget

- [x] Horizontaler Slider mit Zeitskala (letzte 2 Stunden)  *(v0.0.20.901)*
- [x] Hover → Ghost-Preview: zeigt Mixer-State zu dem Zeitpunkt  *(v0.0.20.901)*
  - Fader-Positionen als transparente Overlay-Linien
  - Aktive Plugins als Icons
  - MIDI-Noten als Mini-Pianoroll

- [x] Klick → Preview Mode: lädt den State temporär  *(v0.0.20.901)*
- [x] Doppelklick → Restore: übernimmt den State  *(v0.0.20.901)*

- [x] Event-Markers auf der Timeline:  *(v0.0.20.901)*
  - 🎹 MIDI-Input (blaue Punkte)
  - 🎛️ Parameter-Änderung (orange Punkte)
  - 🔌 Plugin-Load/Preset (grüne Punkte)
  - 📸 Snapshot (graue Linien)
  - ⭐ User-Bookmark (gelbe Sterne)

### Steuerung

- [x] "Bookmark setzen" Button — markiert aktuellen Moment  *(v0.0.20.901)*
- [x] "Letzte 30s einfangen" → wie Ableton Capture aber für ALLES  *(v0.0.20.901)*
- [x] "A/B Vergleich" → aktueller State vs. ausgewählter Zeitpunkt  *(v0.0.20.901)*
- [x] Track-Filter: nur bestimmte Tracks in der Timeline anzeigen  *(v0.0.20.901)*

### Keyboard Shortcuts

- [x] `Ctrl+Z` → normales Undo (wie bisher)  *(v0.0.20.901)*
- [x] `Ctrl+Shift+Z` → Time-Travel-Panel öffnen  *(v0.0.20.901)*
- [x] `Ctrl+B` → Bookmark setzen  *(v0.0.20.901)*
- [x] `Ctrl+Shift+B` → Letzte 30s einfangen (Capture All)  *(v0.0.20.901)*

---

## 🔧 PHASE T5: Zeitpunkt-Suche (FTS5)

**Priorität:** 🟠 HOCH
**Aufwand:** 1-2 Sessions
**Datei:** In `time_travel_db.py` + `time_travel_panel.py`

### Suchfunktionen

- [x] Volltext-Suche in journal_tags_fts:  *(v0.0.20.901)*
  ```
  "filter sweep"  → alle Momente mit Filter-Bewegung
  "C-Moll pad"    → alle Momente mit Pad-Sound in C-Moll
  "Surge XT"      → alle Momente wo Surge XT benutzt wurde
  "bass recording" → alle Bass-Aufnahmen
  ```

- [x] Zeit-Filter kombinierbar:  *(v0.0.20.901)*
  ```
  "warm pad" + "heute"
  "filter" + "letzte Stunde"
  "bass" + "Dienstag"
  ```

- [x] Ergebnis-Liste mit Preview-Button pro Treffer  *(v0.0.20.901)*
- [x] Such-Historie (letzte 20 Suchen gespeichert)  *(v0.0.20.901)*

---

## 🔧 PHASE T6: KI-Auto-Tagging

**Priorität:** 🟡 MITTEL — Das Alleinstellungsmerkmal
**Aufwand:** 2-3 Sessions
**Datei:** `pydaw/services/time_travel_tagger.py`

### Automatische Beschreibungen (lokal, kein API-Key nötig)

Die KI analysiert die Events und generiert menschenlesbare Tags:

- [x] **MIDI-Analyse** → Tags generieren:  *(v0.0.20.901)*
  - Tonart erkennen (vorhandene `harmony_analysis.py` nutzen)
  - Rhythmus-Charakter ("straight", "swing", "syncopated")
  - Dichte ("spärlich", "voll", "polyphon")
  - Register ("Bass", "Mid", "High")
  - Beispiel-Tag: "C-Moll Arpeggio, synkopiert, mittleres Register"

- [x] **Parameter-Analyse** → Tags generieren:  *(v0.0.20.901)*
  - Filter-Bewegung erkennen ("Filter Sweep aufwärts", "Cutoff-Automation")
  - Effekt-Charakter ("Hall-lastig", "Delay-Feedback", "Distortion")
  - Dynamik ("leiser werdend", "Crescendo", "stabil")
  - Beispiel-Tag: "Warmer Pad-Sound, Filter öffnet langsam, Hall"

- [x] **Kontext-Analyse** → Tags generieren:  *(v0.0.20.901)*
  - Welcher Track war aktiv
  - Welches Plugin/Preset wurde benutzt
  - Was wurde gleichzeitig auf anderen Tracks gespielt
  - Beispiel-Tag: "Bass-Line mit Surge XT 'Deep Sub', während Drums laufen"

- [x] **Tagging-Intervall**: Alle 10 Sekunden wenn sich etwas ändert  *(v0.0.20.901)*
  - Nur taggen wenn neue Events vorhanden
  - Keine Duplikate (ähnliche Tags zusammenfassen)

---

## 🔧 PHASE T7: Sound Search — "Finde den Sound von letzter Woche"

**Priorität:** 🟡 MITTEL — Das hat KEINE andere DAW
**Aufwand:** 2 Sessions
**Datei:** `pydaw/ui/sound_search_panel.py`

### Sucharten

- [x] **Text-Suche**: "warmer pad sound letzte woche"  *(v0.0.20.901)*
  - Nutzt FTS5 über journal_tags_fts
  - Kombiniert mit wall_clock Zeitfilter

- [x] **Ähnlichkeits-Suche**: "Finde Sounds ähnlich zu JETZT"  *(v0.0.20.901)*
  - Aktuellen Audio-Fingerprint berechnen
  - Vergleich mit journal_audio_fp via Cosine Similarity
  - Top-10 ähnlichste Momente anzeigen

- [x] **Plugin-Suche**: "Alle Surge XT Sounds dieser Woche"  *(v0.0.20.901)*
  - SQL: `WHERE plugin_id='surge-xt' AND wall_clock > last_week`

- [x] **Stimmungs-Suche** (KI): "fröhlich", "dunkel", "aggressiv"  *(v0.0.20.901)*
  - Mapped auf Tags: "fröhlich" → dur, hoch, schnell
  - "dunkel" → moll, tief, langsam, filter zu

### Such-UI

- [x] Suchfeld oben im Panel  *(v0.0.20.901)*
- [x] Ergebnis-Karten mit:  *(v0.0.20.901)*
  - Zeitstempel + Datum
  - Auto-Tags als Badges
  - Mini-Waveform/Pianoroll Preview
  - "▶ Probehören" und "↩ Restore" Buttons
- [x] Gruppierung: "Heute", "Gestern", "Diese Woche", "Älter"  *(v0.0.20.901)*

---

## 🔧 PHASE T8: Undo-Baum (Git-Style)

**Priorität:** 🟡 MITTEL — Kein DAW hat das
**Aufwand:** 2-3 Sessions
**Dateien:** `pydaw/services/undo_tree.py`, `pydaw/ui/undo_tree_widget.py`

### Konzept

Statt linearem Undo (A → B → C, Undo = C → B → A) ein Baum:

```
          A (Start)
          │
          B (Bass hinzugefügt)
         ╱ ╲
        C   D (Branch: anderer Bass-Sound)
        │   │
        E   F
        │
        G (← du bist hier)
```

Du kannst zu D springen ohne C/E/G zu verlieren.

### Implementierung

- [x] `UndoTree` Datenstruktur (nicht UndoStack):  *(v0.0.20.901)*
  - Jeder Knoten = Snapshot + Liste von Events seit Parent
  - Branches werden in `journal_branches` gespeichert
  - Aktiver Branch wird markiert

- [x] Branch-Operationen:  *(v0.0.20.901)*
  - "Branch erstellen" → forkt am aktuellen Zeitpunkt
  - "Branch wechseln" → Restore auf den Branch-Tip
  - "Branches mergen" → kombiniert zwei States
  - "Branch löschen" → mit Sicherheitsabfrage

- [x] UI: Baum-Visualisierung (vertikal, wie Git-Graph)  *(v0.0.20.901 — in T9 UndoTreeWidget)*
  - Knoten anklickbar → Preview
  - Doppelklick → Restore + Wechsel auf Branch
  - Rechtsklick → Branch/Merge/Delete

---

## 🔧 PHASE T9: Undo-Baum UI

**Priorität:** 🟢 NORMAL
**Aufwand:** 1-2 Sessions
**Datei:** `pydaw/ui/undo_tree_widget.py`

- [x] Vertikaler Baum-Graph (SVG oder QPainter)  *(v0.0.20.901)*
- [x] Farben pro Branch (wie Git)  *(v0.0.20.901)*
- [x] Hover → Snapshot-Info (BPM, Tracks, Tags)  *(v0.0.20.901)*
- [x] Drag-Handle zum Verschieben der Ansicht  *(v0.0.20.901)*
- [x] "Vergleichen" Modus: zwei Knoten nebeneinander  *(v0.0.20.901)*

---

## 🔧 PHASE T10: Sound DNA — Audio-Fingerprinting

**Priorität:** 🟢 NORMAL — Zukunftssicher
**Aufwand:** 2 Sessions
**Datei:** `pydaw/services/sound_dna_service.py`

### Konzept

Jeder Sound bekommt einen "genetischen Fingerabdruck" — ein 128-dimensionaler
Vektor der den Klang-Charakter beschreibt (unabhängig von Lautstärke/Tonhöhe).

### Berechnung (ohne externe KI-Modelle, rein numpy)

- [x] FFT-basierter Fingerprint:  *(v0.0.20.901)*
  1. 2s Audio-Buffer nehmen
  2. STFT → Mel-Spektrogramm (128 Bänder)
  3. Mittelwert über Zeit → 128-dim Vektor
  4. L2-Normalisierung

- [x] Zusätzliche Features:  *(v0.0.20.901)*
  - Spectral Centroid (hell/dunkel)
  - Spectral Flatness (noisy/tonal)
  - RMS (laut/leise)
  - Zero-Crossing-Rate (perkussiv/sustain)

- [x] Gespeichert in `journal_audio_fp` und `sound_dna`  *(v0.0.20.901)*

### Ähnlichkeitssuche

- [x] Cosine Similarity zwischen Fingerprints  *(v0.0.20.901)*
- [x] "Finde ähnliche Sounds" → sortiert nach Ähnlichkeit  *(v0.0.20.901)*
- [x] Threshold: > 0.85 = "sehr ähnlich", > 0.70 = "ähnlich"  *(v0.0.20.901)*

---

## 🔧 PHASE T11: Cross-Projekt Sound-Suche

**Priorität:** 🟢 NORMAL
**Aufwand:** 1-2 Sessions
**Datei:** In `sound_dna_service.py`

- [x] `sound_dna`  *(v0.0.20.898)* Tabelle speichert Fingerprints ALLER Projekte
- [x] "Finde diesen Sound in meinen anderen Projekten"  *(v0.0.20.901)*
- [x] "Welche Projekte nutzen einen ähnlichen Bass-Sound?"  *(v0.0.20.901)*
- [x] Ergebnis: Projekt-Name + Track + Plugin + Preset + Zeitpunkt  *(v0.0.20.901)*

---

## 🔧 PHASE T12: Live Recall (ohne Playback-Stop)

**Priorität:** 🟡 MITTEL — Killer-Feature für Live-Performance
**Aufwand:** 2 Sessions
**Datei:** `pydaw/services/live_recall.py`

### Konzept

Du spielst live und willst OHNE STOP zurück zu einem Sound.
Das System morph die Parameter in Echtzeit zum Ziel-State.

- [x] "Recall to Timestamp" Befehl → smooth Transition  *(v0.0.20.901)*
  - Alle Fader/Knobs bewegen sich gleichzeitig zum Ziel
  - Transition-Zeit einstellbar (0.5s, 1s, 2s, 5s)
  - Nur Parameter, nicht MIDI (keine Noten-Rückspulung)

- [x] Integration mit Clip Launcher:  *(v0.0.20.901)*
  - "Recall + Launch Scene" → Sound + Pattern gleichzeitig wechseln

- [x] MIDI-Controller Binding:  *(v0.0.20.901)*
  - Ein Knopf am Controller → "Recall letzter Bookmark"
  - Zwei Knöpfe → "Recall A" / "Recall B" (A/B Vergleich)

---

## 🔧 PHASE T13: Parameter Morphing (A↔B)

**Priorität:** 🟢 NORMAL — Einzigartig
**Aufwand:** 2 Sessions
**Datei:** `pydaw/services/param_morph.py`

### Konzept

Zwei Zeitpunkte auswählen → stufenlos dazwischen morphen.

- [x] State A = Zeitpunkt 1, State B = Zeitpunkt 2  *(v0.0.20.901)*
- [x] Morph-Slider: 0% = State A, 100% = State B  *(v0.0.20.901)*
  - Lineare Interpolation aller numerischen Parameter
  - Plugin-Wechsel bei 50% Schwelle
  - Preset-Wechsel bei 50% Schwelle

- [x] Morph-Kurven:  *(v0.0.20.901)*
  - Linear (Standard)
  - Exponentiell (schnell am Anfang)
  - S-Curve (sanfter Übergang)
  - Random-Walk (für kreative Zwecke)

- [x] Automations-Export:  *(v0.0.20.901)*
  - Morph-Bewegung als Automation-Lane aufzeichnen
  - "Morph von A nach B über 8 Takte" → Automation in Arranger

---

## 🔧 PHASE T14: Session Heatmap

**Priorität:** 🟢 NIEDRIG — Nice to have
**Aufwand:** 1 Session
**Datei:** `pydaw/ui/session_heatmap_widget.py`

- [x] Horizontale Timeline (Breite = Session-Dauer)  *(v0.0.20.901)*
- [x] Vertikale Achse = Tracks  *(v0.0.20.901)*
- [x] Farbe = Aktivitätsdichte (dunkel = wenig, hell = viel)  *(v0.0.20.901)*
- [x] Hover → Tooltip mit Event-Details  *(v0.0.20.901)*
- [x] Klick → springt zum Zeitpunkt im Time-Travel Panel  *(v0.0.20.901)*

---

## 📊 GESAMTÜBERSICHT

| Phase | Feature | Priorität | Sessions | Abhängigkeit |
|-------|---------|-----------|----------|-------------|
| T1 | Journal DB Schema | 🔴 KRITISCH | 1 | — |
| T2 | Journal Writer | 🔴 KRITISCH | 2 | T1 |
| T3 | State Restore | 🔴 KRITISCH | 2 | T2 |
| T4 | Time-Travel UI | 🟠 HOCH | 2-3 | T3 |
| T5 | FTS5 Suche | 🟠 HOCH | 1-2 | T1 |
| T6 | KI Auto-Tagging | 🟡 MITTEL | 2-3 | T2 |
| T7 | Sound Search UI | 🟡 MITTEL | 2 | T5+T6 |
| T8 | Undo-Baum | 🟡 MITTEL | 2-3 | T3 |
| T9 | Undo-Baum UI | 🟢 NORMAL | 1-2 | T8 |
| T10 | Sound DNA/Fingerprint | 🟢 NORMAL | 2 | T2 |
| T11 | Cross-Projekt Suche | 🟢 NORMAL | 1-2 | T10 |
| T12 | Live Recall | 🟡 MITTEL | 2 | T3 |
| T13 | Parameter Morphing | 🟢 NORMAL | 2 | T3 |
| T14 | Session Heatmap | 🟢 NIEDRIG | 1 | T2 |
| **TOTAL** | | | **~22-28** | |

---

## 🛡️ DESIGN-PRINZIPIEN

### 1. Nichts kaputt machen
Das Time-Travel-System ist ein **reines Add-On**. Es:
- Fügt neue Tabellen hinzu (kein bestehendes Schema ändern)
- Hookt sich über Signals ein (kein bestehender Code geändert)
- Kann komplett deaktiviert werden (Feature-Flag)
- Hat keinen Einfluss auf Audio-Performance (Background-Thread)

### 2. Performance-Budget
- Journal Write: < 2ms pro Flush (Background-Thread)
- Snapshot: < 50ms (nur Diff speichern)
- Restore: < 200ms (Snapshot laden + Events replayed)
- FTS5 Suche: < 10ms (auch bei 100.000+ Tags)

### 3. Speicher-Budget
- ~10 MB pro Stunde Session (Events + Snapshots)
- Auto-Pruning: Sessions älter als 30 Tage werden komprimiert
- Sound DNA: ~1 KB pro Sound-Signatur
- Konfigurierbar: Max DB-Größe einstellbar

### 4. Zukunftssicher
- SQLite = überall verfügbar, ewig stabil
- FTS5 = Standard-Extension, keine externen Deps
- Audio-Fingerprints = numpy-only, kein ML-Framework nötig
- Rust-Migration möglich: Journal Writer kann später in Rust laufen

---

## 🔮 ZUKUNFTS-IDEEN (nach v1.0)

Diese Ideen sind bewusst NICHT in der Roadmap oben — sie erfordern
externe Abhängigkeiten oder sind noch zu experimentell:

1. **Voice-to-Search**: "Hey Py_DAW, finde den Bass von gestern"
   - Whisper STT → Text → FTS5 Suche
   - Braucht: Whisper-Model (700 MB)

2. **AI Sound Matching**: Referenz-Audio hochladen → "Finde einen
   ähnlichen Sound in meinen Sessions"
   - Braucht: CLAP Audio-Model oder eigenes Training

3. **Collaborative Time-Travel**: Zwei User sehen dieselbe Timeline
   - "Zeig mir was du vor 5 Minuten gemacht hast"
   - Braucht: Collab-System muss Journal synchronisieren

4. **Automatic Versioning**: Jede "gute" Stelle automatisch als
   Git-Commit speichern
   - KI erkennt: "User hat gerade was Gutes gefunden" (wiederholtes
     Abspielen, Bookmark, Lächeln via Webcam 🤪)

5. **Dream Machine**: Nachts analysiert die KI alle deine Sessions
   und generiert "Sound-Vorschläge" für den nächsten Tag
   - "Basierend auf deinen letzten 50 Sessions magst du: ..."

---

*Dieses Dokument wird mit jeder Phase aktualisiert.*
*Nächster Kollege: Lies T1, implementiere die DB-Tabellen, hake ab.*
*Erstellt: v0.0.20.897 — 2026-03-31*
