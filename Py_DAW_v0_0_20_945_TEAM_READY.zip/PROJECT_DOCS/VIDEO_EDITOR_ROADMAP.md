# 🎬 VIDEO-EDITOR PRO ROADMAP — Py_DAW ChronoScaleStudio

**Erstellt:** 2026-04-01 (v0.0.20.937)
**Vision:** Die erste Open-Source DAW mit professionellem Video-Editor + KI-Tools

---

## ⚠️ OBERSTE DIREKTIVE
```
🔴 NICHTS KAPUTT MACHEN. Alle bestehenden Features müssen funktionieren.
```

---

## 📊 STATUS ÜBERSICHT

```
VE1  Video-Editor Canvas + Filmstrip          ✅ v0.0.20.930
VE2  Multi-Clip + Ghost Clips                 ✅ v0.0.20.931-932
VE3  Grid + Snap + Loop                       ✅ v0.0.20.934
VE4  Clip Properties + Filter + KI-Tools      ✅ v0.0.20.935
VE5  SQLite Persistence                       ✅ v0.0.20.936
VE6  Transparenz + Dreieck-Menü               ✅ v0.0.20.937
VE7  Lasso + Ripple + Hand + Group            ✅ v0.0.20.938 ← AKTUELL
VE8  Timecode Pro + Smart Context             [ ] nächste Phase
VE9  Automation Draw (Opacity-Kurven)          [ ]
VE10 Transition Engine                        [ ]
VE11 KI Text-Editing (Whisper)                [ ]
VE12 KI Smart Cut (Pausen/Ähms entfernen)     [ ]
VE13 KI Mood Matcher (Referenz-Grading)       [ ]
VE14 GPU Video Decode (Vulkan)                [ ]
VE15 Multi-Cam Sync                           [ ]
VE16 AAF/XML/OMF Export                       [ ]
VE17 Dolby Atmos / Ambisonics                 [ ]
VE18 Cloud-Collaboration (Video)              [ ]
```

---

## 🔧 PHASE VE7: Lasso + Ripple + Hand + Group (v0.0.20.938)

### Klassische NLE-Werkzeuge

- [x] **Lasso Selection** — Rechteck-Auswahl über mehrere Clips
  - Maus ziehen = Auswahlrechteck
  - Alle Clips die das Rechteck berührt werden selektiert
  - Shift+Klick = zur Auswahl hinzufügen/entfernen
  - Ctrl+A = alle Clips selektieren

- [x] **Ripple Delete** — Clip löschen + Lücke schließen
  - Shift+Del = Clip löschen UND nachfolgende Clips nach links schieben
  - Wie "Ripple Edit" in Premiere Pro / DaVinci Resolve

- [x] **Hand Tool** (H) — Timeline scrollen
  - Cursor wird zur Hand
  - Klick+Drag = Pan in beide Richtungen

- [x] **Group/Ungroup** — Clips zusammenfassen
  - Ctrl+G = ausgewählte Clips gruppieren
  - Ctrl+Shift+G = Gruppe auflösen
  - Gruppierte Clips bewegen sich zusammen

- [x] **Zoom Tool** (Z) — Lupe
  - Klick = Zoom in
  - Alt+Klick = Zoom out
  - Drag = Zoom auf Bereich

---

## 🔧 PHASE VE8: Timecode Pro + Smart Context

### Timecodes (Professionell)

- [ ] Frame-genauer Timecode im Header (HH:MM:SS:FF)
- [ ] Drop-Frame / Non-Drop-Frame Unterstützung
- [ ] Timecode-Offset pro Clip (für externe Kameras)
- [ ] LTC (Linear Time Code) Sync über Audio-Spur
- [ ] Timecode-Eingabe: Springe zu exaktem Timecode

### Smart Context Tool

- [ ] Automatischer Tool-Wechsel je nach Klick-Position:
  - Klick auf Clip-Rand → Trim Tool
  - Klick auf Clip-Mitte → Move Tool
  - Klick auf leere Fläche → Selection
  - Klick in Header → Playhead setzen
  - Klick auf Automation-Lane → Draw Tool

---

## 🔧 PHASE VE9: Automation Draw (Opacity-Kurven)

- [ ] Opacity-Automation pro Clip (Kurve zeichnen)
- [ ] Speed-Ramping (Geschwindigkeits-Kurve)
- [ ] Volume-Automation synced zum Audio
- [ ] Breakpoint-Editor mit Bezier-Kurven
- [ ] Preset-Kurven: Fade In, Fade Out, S-Curve, Bell

---

## 🔧 PHASE VE10: Transition Engine

- [ ] Crossfade zwischen Video-Clips
- [ ] Überblendungen: Dissolve, Wipe, Slide, Push
- [ ] Dip to Black / Dip to White
- [ ] Transition-Dauer in Beats (beat-synced!)
- [ ] KI-Morph-Transition (Zwischenbilder berechnen)

---

## 🔧 PHASE VE11: KI Text-Editing (Whisper Integration)

- [ ] Whisper-Transkription (lokal, kein Cloud)
- [ ] Text-Editor neben der Timeline
- [ ] Wörter löschen → Video wird dort geschnitten
- [ ] Wörter verschieben → Video-Reihenfolge ändern
- [ ] Marker an Wort-Grenzen
- [ ] Untertitel-Export (SRT, VTT)

---

## 🔧 PHASE VE12: KI Smart Cut

- [ ] "Ähm"-Erkennung in Sprache → automatisch entfernen
- [ ] Pausen-Erkennung → kürzen oder entfernen
- [ ] Mimik-Analyse: "unsicher wirkende" Stellen markieren
- [ ] Ein-Klick "Highlight Reel" (beste Momente zusammenschneiden)
- [ ] Zusammenfassung: "Kürze auf 30 Sekunden"

---

## 🔧 PHASE VE13: KI Mood Matcher

- [ ] Referenz-Clip laden (z.B. aus einem Film)
- [ ] Color-Grading übertragen (Style Transfer)
- [ ] Audio-EQ/Kompression übertragen
- [ ] "Mix wie ein Marvel-Film" / "Look wie Blade Runner"
- [ ] Preset-Library mit Film-Looks

---

## 🔧 PHASE VE14: GPU Video Decode

- [ ] Vulkan-basiertes Video-Decoding (Linux)
- [ ] VAAPI Hardware-Decode für Intel/AMD
- [ ] NVDEC für NVIDIA GPUs
- [ ] 4K/8K Echtzeit-Vorschau
- [ ] GPU-beschleunigte Filter (Blur, Color Grade)

---

## 🔧 PHASE VE15: Multi-Cam Sync

- [ ] Mehrere Kameras synchronisieren (Audio-Wellenform)
- [ ] Multi-Cam Preview (4-fach Split)
- [ ] Ein-Klick Kamera-Wechsel während Playback
- [ ] Auto-Sync via Timecode / Clap Detection

---

## 🔧 PHASE VE16: AAF/XML/OMF Export

- [ ] AAF Export (Pro Tools kompatibel)
- [ ] XML Export (DaVinci/Premiere kompatibel)
- [ ] OMF Export (Legacy)
- [ ] EDL Export (Edit Decision List)

---

## 🔧 PHASE VE17: Immersives Audio

- [ ] Dolby Atmos Object-Audio (Renderer)
- [ ] Ambisonics (VR/360°)
- [ ] Binaural Monitoring
- [ ] 7.1.4 Surround Mixing

---

## 🔧 PHASE VE18: Cloud-Collaboration (Video)

- [ ] Mehrbenutzter-Timeline (WebSocket)
- [ ] Proxy-Video Streaming (niedrige Auflösung für Remote)
- [ ] Kommentar-Marker (Reviewer-Workflow)
- [ ] Version Control für Video-Projekte

---

## 📊 Feature-Matrix: Py_DAW vs. Industrie

```
Feature                    DaVinci  Premiere  Cubase  Py_DAW
──────────────────────────────────────────────────────────────
Video-Editor in DAW         ❌       ❌        ❌      ✅
Beat-synced Video Cuts      ❌       ❌        ❌      ✅
KI-Szenen → Auto-Schnitt    ❌       ❌        ❌      ✅
Ghost-Clips (Video)         ❌       ❌        ❌      ✅
Lasso Selection             ✅       ✅        ❌      ✅
Ripple Delete               ✅       ✅        ❌      ✅
Filter Presets              ✅       ✅        ❌      ✅
Per-Clip Opacity            ✅       ✅        ❌      ✅
SQLite Persistence          ❌       ❌        ❌      ✅
Musik-KI → Video Color      ❌       ❌        ❌      ✅
Open Source                 ❌       ❌        ❌      ✅
Kostenlos                   (Free)   ❌        ❌      ✅
```

---

## 🏗 ARCHITEKTUR

```
┌──────────────────────────────────────────────┐
│ Video-Editor UI (PyQt6)                       │
│ ┌──────────┐ ┌──────────┐ ┌───────────────┐  │
│ │ Canvas   │ │ Clip     │ │ Tool Panel    │  │
│ │ (Paint)  │ │ Props    │ │ (Context)     │  │
│ └────┬─────┘ └────┬─────┘ └───────┬───────┘  │
│      │            │               │           │
│ ┌────▼────────────▼───────────────▼────────┐  │
│ │ VideoFilterService (non-destructive)      │  │
│ │ → ffmpeg filter_complex at export         │  │
│ └────┬─────────────────────────────────────┘  │
│      │                                        │
│ ┌────▼────────────────────────────────────┐   │
│ │ FinalStateDB (SQLite)                    │   │
│ │ clip_video_props + clip_filter_chain     │   │
│ └──────────────────────────────────────────┘   │
└──────────────────────────────────────────────┘
```
