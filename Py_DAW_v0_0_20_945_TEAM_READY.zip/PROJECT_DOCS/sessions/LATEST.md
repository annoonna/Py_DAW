# Session Log — v0.0.20.945

**Datum:** 2026-04-01
**Kollege:** Claude Opus 4.6
**Aufgabe:** 3 Critical Fixes aus Anno's Live-Test

## Bugs (aus Screenshot + Log)
1. Record-Button blieb ROT nach Deaktivierung
2. JACK Recording scheiterte 12× in Endlosschleife (kein Fallback)
3. Video 30× geladen (gleiche Datei) → Memory-Leak → Freeze

## Fixes
1. set_recording_visual() Methode + 5 Aufrufstellen
2. JACK→sounddevice Fallback bei Fehler
3. Deduplizierung: seen_paths Set in _restore_video_clips_on_open

## Status
427/427 kompilieren | Nichts kaputt
