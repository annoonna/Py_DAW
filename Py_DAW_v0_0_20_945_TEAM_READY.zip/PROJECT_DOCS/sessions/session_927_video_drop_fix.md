# Session Log — v0.0.20.927

**Datum:** 2026-04-01
**Kollege:** Claude Opus 4.6
**Aufgabe:** Video-Drop → VideoPanel Auto-Load Fix (Bug von Anno gemeldet)

## Bug-Beschreibung (Anno)

> "Die Video-Spur im Arranger zeigt das Video nicht. Im Video-Panel wird das
> Video nicht reingeladen wenn ich es im Arranger auf die Spur ziehe. Deswegen
> sehe ich auch nichts wenn ich Play drücke im Arranger."

## Analyse

Die Signalkette war unterbrochen:

1. `dropEvent` in `arranger_canvas.py` ruft `project_service.add_video_clip_from_file_at()` auf ✅
2. Diese Methode erstellt den Clip korrekt ✅
3. **ABER:** Kein Aufruf an `VideoConnector.on_video_loaded()` ❌
4. **ABER:** VideoPanel war nie beim VideoConnector registriert ❌
5. **ABER:** Video-Panel wurde nicht automatisch geöffnet ❌
6. **ABER:** Sync wurde nicht automatisch gestartet ❌

## Fixes (4 Dateien)

### 1. `pydaw/services/project_service.py`
- Nach Clip-Erstellung: `VideoConnector.on_video_loaded(path, info)` aufrufen
- Info enthält: duration, clip_id, track_id

### 2. `pydaw/ui/main_window_docks.py`
- `_toggle_video_track()`: VideoPanel beim VideoConnector registrieren
- Transport + ProjectService auch registrieren (für BPM/Sync)

### 3. `pydaw/ui/arranger_canvas.py`
- `dropEvent()`: Video-Panel automatisch öffnen wenn Video gedroppt wird
- Falls versteckt → sichtbar machen

### 4. `pydaw/ui/video_panel.py`
- `load_video_file()`: Auto-Start Sync nach externem Laden
- Guard gegen doppeltes Laden desselben Videos

## Compile-Test
4/4 Dateien kompilieren ✅

## Nichts kaputt
- Bestehende Video-Funktionalität unverändert
- VideoConnector Singleton bleibt stabil
- Alle bisherigen Registrierungswege (Video-KI Panel) weiterhin aktiv

## Status
4 Dateien geändert | Compile OK | Nichts kaputt
