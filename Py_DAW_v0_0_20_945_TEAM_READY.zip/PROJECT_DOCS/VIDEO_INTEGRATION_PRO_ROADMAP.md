# 🎬 VIDEO-INTEGRATION PRO — Roadmap v2

**Projekt:** Py_DAW (ChronoScaleStudio)
**Stand:** v0.0.20.923
**Problem:** 3 Video-Module existieren als isolierte Inseln
**Ziel:** EIN integriertes System das es so in keiner DAW gibt

---

## 🔴 OBERSTE DIREKTIVE: NICHTS KAPUTT MACHEN

---

## 📊 IST-ZUSTAND: 3 Inseln

```
┌─────────────┐     ┌──────────────┐     ┌──────────────────┐
│  ARRANGER    │     │ VIDEO-PANEL  │     │  VIDEO-KI PANEL  │
│ (Clips)      │     │ (Preview)    │     │ (Analyse)        │
│              │     │              │     │                  │
│ • Teal-Clips │     │ • Frame-View │     │ • Szenen-Liste   │
│ • Filmstrip  │     │ • SMPTE      │     │ • Dialog-Regionen│
│ • Split/Move │     │ • Scrub      │     │ • Mood-Analyse   │
│ • DnD        │     │ • Chapters   │     │ • Sound-Vorschl. │
│              │     │ • FPS/Offset │     │ • Auto-Duck      │
│ KEINE        │     │ KEINE        │     │ KEINE            │
│ Thumbnails   │     │ Verbindung   │     │ Verbindung       │
│ KEINE Szenen │     │ zum Arranger │     │ zum Arranger     │
│ KEINE Sync   │     │ KEINE Sync   │     │ KEIN DB-Cache    │
└──────────────┘     └──────────────┘     └──────────────────┘
       ↕ 0                ↕ 0                    ↕ 0
   (isoliert)          (isoliert)            (isoliert)
```

## 🎯 SOLL-ZUSTAND: Ein verbundenes System

```
┌──────────────────────────────────────────────────────────────┐
│                    TRANSPORT (Playhead)                       │
│            beat ←→ seconds ←→ SMPTE ←→ frame                │
└──────┬────────────────────┬───────────────────┬──────────────┘
       │                    │                   │
       ▼                    ▼                   ▼
┌──────────────┐     ┌──────────────┐     ┌──────────────────┐
│  ARRANGER    │◄───►│ VIDEO-PANEL  │◄───►│  VIDEO-KI PANEL  │
│              │     │              │     │                  │
│ • Thumbnails │     │ • Preview    │     │ • Szenen-Liste   │
│   IN Clips   │     │   sync'd    │     │ • Dialog + Duck  │
│ • Szenen-    │     │ • Frame bei  │     │ • Mood + Sounds  │
│   Marker     │     │   Playhead   │     │ • MIDI-Gen       │
│ • Farb-Tint  │     │ • Scene-Info │     │ • DB persistent  │
│ • Filter-    │     │ • Filter-    │     │ • Cue-Sheet      │
│   Chain      │     │   Preview    │     │ • Untertitel     │
│              │     │              │     │                  │
│ Clip-Click   │     │ Scrub →      │     │ Scene-Click →    │
│ → Preview    │     │   Arranger   │     │   Playhead +     │
│ → KI-Detail  │     │   + KI       │     │   Preview        │
└──────────────┘     └──────────────┘     └──────────────────┘
       │                    │                   │
       └────────────────────┼───────────────────┘
                            ▼
                    ┌──────────────┐
                    │   SQLite DB  │
                    │              │
                    │ • Scenes     │
                    │ • Dialogs    │
                    │ • Subtitles  │
                    │ • Thumbnails │
                    │ • Moods      │
                    │ • Suggestions│
                    │ • Filters    │
                    └──────────────┘
```

---

## 📋 PHASEN-PLAN

### PHASE VP1: Video-Connector (Kern-Verdrahtung) 🔴 KRITISCH
**Aufwand:** 1 Session
**Datei:** `pydaw/services/video_connector.py` (NEU)

Zentraler Event-Bus der alle 3 Module verbindet:

```python
class VideoConnector(QObject):
    """Zentraler Hub — verbindet Arranger ↔ Video-Panel ↔ Video-KI."""

    # Signals
    playhead_to_video = pyqtSignal(float)     # beat → Video-Panel zeigt Frame
    scene_selected = pyqtSignal(int, float)    # scene_idx, seconds → alle Module
    video_loaded = pyqtSignal(str)             # path → alle Module laden Video
    analysis_done = pyqtSignal(str)            # video_path → Arranger + Panel aktualisieren
    clip_selected = pyqtSignal(str, float)     # clip_id, beat → Video-Panel + KI fokussieren
```

### PHASE VP2: Thumbnails im Arranger ✅ ERLEDIGT (v924)
**Aufwand:** 1-2 Sessions
**Dateien:** `arranger_canvas.py`, `video_ki_service.py`

Was der User in den Screenshots sieht: teal-Clips OHNE Bild.
Was er sehen SOLL: echte Video-Frames als Thumbnail-Streifen.

- Beim Video-Import: ffmpeg extrahiert 1 Frame/Sekunde → QPixmap Cache
- `_draw_video_preview()` rendert Thumbnails statt Filmstrip-Pattern
- Cache in SQLite BLOB (einmal extrahieren, immer verfügbar)
- Lazy Loading: nur sichtbare Clips generieren Thumbnails

### PHASE VP3: Szenen-Marker im Arranger ✅ ERLEDIGT (v924)
**Aufwand:** 1 Session
**Dateien:** `arranger_canvas.py`

- VK1 Szenen als farbige vertikale Marker im Ruler
- Farbe = Stimmungs-Farbe (warm=orange, kalt=blau, dunkel=violett)
- Rechtsklick auf Marker → "An Szene splitten" / "Szene vertonen"
- Hover zeigt Mood-Tags + BPM/Key als Tooltip

### PHASE VP4: Cross-Module Sync ✅ ERLEDIGT (v924)
**Aufwand:** 1 Session
**Dateien:** `video_connector.py`, alle 3 Panels

Szene in Video-KI klicken:
1. → Playhead springt zur Szenen-Startzeit
2. → Video-Panel zeigt Frame an der Position
3. → Arranger scrollt zum Clip + Highlight

Clip im Arranger klicken:
1. → Video-Panel zeigt Frame an Clip-Start
2. → Video-KI selektiert die Szene an dieser Position
3. → Mood-Bars aktualisieren sich

Video-Panel scrubben:
1. → SMPTE aktualisiert
2. → Arranger-Playhead folgt
3. → Video-KI zeigt aktuelle Szene

### PHASE VP5: "Szene vertonen" → Track + MIDI + Instrument ✅ ERLEDIGT (v923)
**Aufwand:** 1 Session
**Dateien:** `video_ki_panel.py`, `project_service.py`

"🎵 Vertonen" Button erzeugt:
1. Neuen Instrument-Track (Name = "Szene 3: Dark Pad")
2. AETERNA als Instrument mit generierten Preset-Params
3. MIDI-Clip an der Szenen-Position (start_beats aus seconds)
4. MIDI-Noten aus `generate_midi_for_suggestion()` (Pad/Arp/Bass/etc.)
5. Clip-Länge = Szenen-Dauer

Das hat KEINE andere DAW: Video analysieren → KI generiert passende
Musik mit konkreten Noten, Instrument-Preset und Position.

### PHASE VP6: Video-Filter-Chain ✅ ERLEDIGT (v924)
**Aufwand:** 2 Sessions
**Dateien:** `video_filter_service.py` (NEU), `video_panel.py`

Per-Clip Video-Filter (non-destructiv, wie Audio-FX-Chain):
- Brightness/Contrast/Saturation (Grundlagen)
- Color Grading (Lift/Gamma/Gain, 3-Way Color Corrector)
- LUT Import (.cube Dateien)
- Blur/Sharpen
- Vignette
- Alle als "Video-Devices" in der Device-Chain (neben Audio-FX)
- Export: ffmpeg Filter-Graph beim Rendern

### PHASE VP7: DB-Persistence für alle Module 🟡 MITTEL
**Aufwand:** 1 Session

- Video-KI lädt gecachte Analyse beim Projekt-Open
- Thumbnail-Cache in SQLite BLOBs
- Video-Filter-Chain pro Clip persistent
- Podcast-Panel liest/schreibt Chapters + EQ-State

### PHASE VP8: Scene-Aware Editing ✅ ERLEDIGT (v924)
**Aufwand:** 1 Session

- "Auto-Split an Szenen-Grenzen" → One-Click: alle Szenen werden separate Clips
- "Szenen sortieren" → Drag Szenen in neue Reihenfolge
- "Szene entfernen" → Ripple-Delete (nachfolgende Clips rutschen nach)
- "Szene verlängern/kürzen" → Trim-Handle snapped an Szenen-Grenzen

### PHASE VP9: Fortgeschrittene KI ✅ ERLEDIGT (v925)
**Aufwand:** 2-3 Sessions

- Gesichtserkennung → automatische Sprecher-Labels
- Bewegungserkennung → "Action" vs "Dialog" Klassifikation
- Emotionserkennung → feinere Mood-Analyse
- Style Transfer → "mach diese Szene wie einen Hitchcock-Film"
- KI-gesteuerte Schnittreihenfolge (Re-Edit Vorschläge)

### PHASE VP10: Multi-Video + A/B ✅ ERLEDIGT (v925)
**Aufwand:** 2 Sessions

- Mehrere Video-Tracks gleichzeitig
- A/B Vergleich (Split-View)
- Multi-Kamera Switching
- Bild-in-Bild (PiP)

---

## 🏗️ ARCHITEKTUR: VideoConnector (Kern)

```python
# pydaw/services/video_connector.py

class VideoConnector(QObject):
    """Zentraler Event-Hub für Video-Integration.
    
    Verbindet: Arranger ↔ VideoPanel ↔ VideoKIPanel ↔ VideoKIService ↔ DB
    
    Jedes Modul registriert sich und bekommt Events.
    Kein Modul muss das andere direkt kennen.
    """
    
    # === Signals ===
    video_loaded = pyqtSignal(str, dict)           # path, info
    playhead_moved = pyqtSignal(float, float)       # beat, seconds
    scene_selected = pyqtSignal(int, float, float)  # idx, start_s, end_s
    analysis_completed = pyqtSignal(str, dict)      # path, summary
    clip_selected = pyqtSignal(str)                 # clip_id
    
    # === Registrierte Module ===
    _arranger = None
    _video_panel = None
    _video_ki_panel = None
    _vki_service = None
    
    def register_arranger(self, arranger): ...
    def register_video_panel(self, panel): ...
    def register_video_ki_panel(self, panel): ...
    
    # === Cross-Module Actions ===
    def on_scene_click(self, scene_idx):
        """Video-KI Scene click → Playhead + Preview + Arranger."""
        ...
    
    def on_clip_click(self, clip_id, beat):
        """Arranger Clip click → Preview + KI-Detail."""
        ...
    
    def on_scrub(self, seconds):
        """Video-Panel Scrub → Playhead + KI-Scene."""
        ...
    
    def on_analysis_done(self, video_path):
        """KI Analysis fertig → Szenen-Marker im Arranger."""
        ...
```

---

## 📊 FEATURE-MATRIX: Was es so noch nie gab

```
Feature                            Pro Tools  Nuendo  DaVinci  Py_DAW
──────────────────────────────────────────────────────────────────────
Video auf Spur ziehen                 ✅        ✅       ✅       ✅
Split/Trim/Move Video                 ✅        ✅       ✅       ✅
Thumbnails in Clips                   ❌        ✅       ✅       ✅
SMPTE Timecode                        ✅        ✅       ✅       ✅
Scene Detection                       ❌        ❌       ✅*      ✅
Scene Markers in Timeline             ❌        ❌       ❌       ✅ ←UNIKAT
KI-Stimmungsanalyse pro Szene         ❌        ❌       ❌       ✅ ←UNIKAT
KI → Sound-Vorschläge                 ❌        ❌       ❌       ✅ ←UNIKAT
KI → MIDI-Noten generieren            ❌        ❌       ❌       ✅ ←UNIKAT
KI → Kompletter Track erstellen       ❌        ❌       ❌       ✅ ←UNIKAT
Auto-Duck bei Dialog                  ❌        ❌       ❌       ✅ ←UNIKAT
Cross-Module Sync (3 Panels)          ❌        ❌       ❌       ✅ ←UNIKAT
Video-Filter per Clip                 ❌        ❌       ✅       ✅
ADR/Foley Cue-Sheet                   ❌        ✅       ❌       ✅
Whisper-Untertitel                     ❌        ❌       ❌       ✅ ←UNIKAT
Beat-to-Cut Vorschläge                ❌        ❌       ❌       ✅ ←UNIKAT
Scene-Aware Auto-Split                ❌        ❌       ❌       ✅ ←UNIKAT

* DaVinci hat Scene Detection, aber nur im Video-Editor — nicht in der DAW
```

**8 Features die es in keiner DAW gibt.**

---

## 📋 EMPFOHLENE REIHENFOLGE FÜR KOLLEGEN

```
VP1 (Connector)  →  VP2 (Thumbnails)  →  VP3 (Szenen-Marker)
                                      →  VP4 (Cross-Sync)
                                      →  VP5 (Vertonen + MIDI)
                                      →  VP7 (DB-Persistence)
VP6 (Filter) und VP8 (Scene-Edit) können parallel gemacht werden.
VP9 und VP10 sind ERLEDIGT (v925).
```

---

## 🛡️ SICHERHEITS-REGELN

1. **VideoConnector ist ein reiner Signal-Hub** — keine Logik, nur Events weiterleiten
2. **Alle Module bleiben unabhängig startbar** — Connector ist optional
3. **Thumbnails sind lazy** — nur für sichtbare Clips generieren
4. **DB-Cache hat Fallback** — wenn DB leer → neu analysieren
5. **Kein Modul crashed wenn ein anderes fehlt** — alles in try/except
6. **NICHTS KAPUTT MACHEN** — alle Änderungen sind additiv

---

*Erstellt: v0.0.20.923 — Aktualisiert: v0.0.20.925 — 2026-04-01*
*VP1–VP10 KOMPLETT ✅ | VIDEO-INTEGRATION PRO ABGESCHLOSSEN*
