# 🗺️ OPEN ITEMS ROADMAP — Alle offenen Punkte (Stand v0.0.20.912)

**Erstellt:** 2026-03-31
**Autor:** Claude Opus 4.6
**Projekt:** Py_DAW / ChronoScaleStudio

---

## ⚠️ OBERSTE DIREKTIVE — FÜR ALLE KOLLEGEN

```
🔴 DU DARFST NICHTS KAPUTT MACHEN.
🔴 Teste IMMER: python3 -c "import py_compile; py_compile.compile('pydaw/DATEI.py', doraise=True)"
🔴 Im Zweifel: NICHT ändern.
```

---

## 📋 ÜBERSICHT

| Kategorie | Items | Wer | Priorität |
|-----------|-------|-----|-----------|
| C1: DB-Integrationen (standalone) | ~~10~~ ✅ ERLEDIGT | — | ✅ DONE |
| C2: Collab-Erweiterungen | 10 ✅ / 1 offen | Kollege | 🟡 MITTEL |
| C3: Tech Debt | ~~8~~ ✅ ERLEDIGT | — | ✅ DONE |
| C4: KI/Komposition Features | 8 ✅ ERLEDIGT | — | ✅ DONE |
| C5: PRO Features (P4–P7) | 14 ✅ ERLEDIGT | — | ✅ DONE |
| C6: DB-Integrationen (Phase 5+) | ~~12~~ ✅ ERLEDIGT | — | ✅ DONE |
| H1: Hardware-Tests | 21 | **Anno** | 🟢 HOCH |
| O1: Optionale Polish-Items | ~~5~~ ✅ ERLEDIGT | — | ✅ DONE |

**Empfohlene Reihenfolge: C2 → C3 → C4 → C5 → C6**
(H1 kann Anno jederzeit parallel machen)

---

## 🟢 C1: DB-Integrationen (standalone — BEREITS ERLEDIGT ✅)

**Status:** Alle 10 Items wurden in v0.0.20.890–896 erledigt.
Die Read-Pfade sind auf DB-first umgestellt. Schreibpfade existieren.

- [x] **C1.1: theme_manager.py** — ThemeDatabase integriert (v0.0.20.890)
- [x] **C1.2: midi_mapping_service.py** — MidiMappingDB integriert (v0.0.20.892)
- [x] **C1.3: groove_templates.py** — GrooveScaleDB integriert (v0.0.20.896)
- [x] **C1.4: arranger_keyboard.py** — Keine DB nötig (reine Keyboard-Shortcuts)
- [x] **C1.5: browser_places_tab.py** — BrowserPlacesPrefs (eigenes System)
- [x] **C1.6: registry.py** — InstrumentRegistry integriert (v0.0.20.890)
- [x] **C1.7: factory_sample_gen.py** — FactorySampleRegistry integriert (v0.0.20.890)
- [x] **C1.8: settings_store.py** — SettingsDatabase integriert (v0.0.20.890)
- [x] **C1.9: plugin_scanner.py** — PluginCacheDB integriert (v0.0.20.896)
- [x] **C1.10: preset_universe_tab.py** — PresetDatabase integriert (v0.0.20.892)

---

## 🟡 C2: Collab-Erweiterungen

**Beschreibung:** Das LAN-Collab-System (WebSocket, collab_service.py) funktioniert grundsätzlich.
Diese Items erweitern es um fehlende Operationen und UX.

**Aufwand:** Je 1–3 Stunden
**Risiko:** Mittel (Collab-Code ist komplex, Echo-Loop-Gefahr)

### Phase C2A — Undo/Redo verdrahten (1 Session)
- [x] **C2A.1: _record_for_undo() verdrahtet** (v0.0.20.885) — Wird aktuell nirgendwo aufgerufen. In collab_service.py bei jeder eingehenden Remote-Op einen Undo-Eintrag anlegen.
- [x] **C2A.2: Undo-Erweiterung Automation** (v0.0.20.910) — Automation-Punkt-Änderungen als Undo-Op registrieren
- [x] **C2A.3: Undo-Erweiterung Device-Chain** (v0.0.20.910) — Device Add/Remove/Reorder als Undo-Op

### Phase C2B — Sync-Erweiterungen (1–2 Sessions)
- [x] **C2B.1: Mixer-Sync** (v0.0.20.886 — mit flash_remote_change) — Remote-Fader/Pan/Mute/Solo live anzeigen (collab_op `mixer_param_change`)
- [x] **C2B.2: Transport-Sync** (v0.0.20.872 — play/stop/seek/loop) — Play/Stop/Seek/Loop synchronisieren (collab_op `transport_state`)
- [x] **C2B.3: Cursor-Sharing** (v0.0.20.858 — farbige Linien im Arranger) — Cursor-Position visuell im Arranger rendern (farbige vertikale Linien pro User, username als Label)
- [x] **C2B.4: Weitere Ops** (v0.0.20.910) — FX-Chain, Automation-Lane, Clip-Add/Remove als synchronisierte Operationen in `COLLAB_OPS` registrieren

### Phase C2C — UX & Discovery (1 Session)
- [x] **C2C.1: mDNS/Zeroconf** (v0.0.20.858 — ServiceBrowser + Registration) — Sessions automatisch im LAN finden (zeroconf Bibliothek, Service-Name `_pydaw-collab._tcp.local.`)
- [x] **C2C.2: Conflict-UI** (v0.0.20.910) — Dialog bei gleichzeitigem Parameter-Edit (z.B. beide ändern BPM → letzter gewinnt, Dialog informiert)
- [x] **C2C.3: CollabPanel in MainWindow** (v0.0.20.798 — als Dock-Widget) — Als Dock-Widget registrieren (aktuell manuell toggle)
- [x] **C2C.4: Services verdrahten** (v0.0.20.910) — Git/Collab/Review im ServiceContainer eintragen

### Relevante Dateien:
- `pydaw/services/collab_service.py` — WebSocket Collab-Engine
- `pydaw/ui/collab_panel.py` — Collab-UI
- `pydaw/services/collab_undo.py` — Undo/Redo für Collab (existiert, aber nicht verdrahtet)

---

## 🟡 C3: Tech Debt

**Beschreibung:** Code-Qualität verbessern ohne neue Features.

### Phase C3A — Unit-Tests (v0.0.20.908 teilweise erledigt ✅)
- [x] **C3A.1: pytest Setup** — `tests/` Ordner, conftest.py, pytest.ini, Fixtures
- [x] **C3A.2: Model Tests** — Track, Clip, Project, MidiNote (22 Tests)
- [x] **C3A.3: TempoMap Tests** — beat↔time, Tempo-Events, Serialization (12 Tests)
- [x] **C3A.4: CollabUndoLog Tests** — push/undo/redo, per-user, max-entries (10 Tests)
- [x] **C3A.5: WarpMarker/Stretch Tests** — Modes, Fades, Crossfade (14 Tests)
- [x] **C3A.6: ProjectService Tests** (v0.0.20.911) — new/open/save, Track CRUD (braucht PyQt6-Mock)
- [x] **C3A.7: SQLite DB Tests** (v0.0.20.911) — CRUD für DB-Klassen (braucht temp DB)
- [x] **C3A.8: RecordingService Tests** (v0.0.20.912) — arm/start/stop (braucht Audio-Mock)

### Phase C3B — Code-Qualität (1 Session)
- [x] **C3B.1: print→logging Restmigration** (v0.0.20.911) — Verbleibende print() in notation/, tools/ (nur echte Stellen, nicht Docstrings/Beispiele)
- [x] **C3B.2: Accessibility Grundlagen** (v0.0.20.911) — QAccessible-Roles für Hauptwidgets, Tab-Reihenfolge, Tooltip-Texte

---

## 🟡 C4: KI/Komposition Features

**Beschreibung:** KI-gestützte Musik-Features. Code existiert bereits teilweise.

**Aufwand:** Je 2–4 Stunden
**Risiko:** Gering (neue Module, kein bestehender Code betroffen)

- [x] **C4.1: P2A Chord-Progression-AI** (v0.0.20.909 — Markov + Presets) — Akkordfolgen vorschlagen (Markov-Chain oder Rule-Based, kein LLM nötig)
- [x] **C4.2: P2A Variations-Generator** (v0.0.20.909 — 7 Variationstypen) — Clip → 4 Variationen (Transposition, Rhythmus-Shift, Velocity-Randomize, Inversion)
- [x] **C4.3: P2B Mix-Analyse** (v0.0.20.910 — MixAnalyzer, 7 Bänder, LUFS, Stereo) — Audio-basierte Mix-Empfehlungen (Spektral-Balance, LUFS, Stereo-Breite)
- [x] **C4.4: P2C Kontrapunkt-Assistent** (v0.0.20.910 — 7 Stile, Scale-Snap, Quality-Score) — KI-Gegenstimme zu Melodie (regelbasiert: Terzen/Sexten, Gegenbewegung)
- [x] **C4.5: P2C Bassline-Generator** (v0.0.20.909 — 5 Styles) — Chord Progression → Bassline (Root, Walkbass, Syncopated)
- [x] **C4.6: P2D Synth-Preset-Generator** (v0.0.20.809) — Textbeschreibung → AETERNA/Fusion Preset-Parameter
- [x] **C4.7: P3A Smart Mixer** (v0.0.20.808) — Auto-Gain-Staging, Frequenz-Konflikt-Erkennung
- [x] **C4.8: Smart Mixer UI** (v0.0.20.910 — Heatmap-Widget, Auto-Gain, Menu-Eintrag) — Heatmap-Visualisierung im Mixer (Frequenz×Track Matrix)

### Relevante Dateien:
- `pydaw/services/ki_assistant.py` — Bestehender KI-Service
- `pydaw/ui/ki_assistant_panel.py` — KI-UI
- `pydaw/plugins/` — Built-in Synths (ChronoScale Fusion, AETERNA, BRRR)

---

## 🔵 C5: PRO Features (P4–P7)

**Beschreibung:** Größere Feature-Module. Code existiert bereits als Grundgerüst.

### P4: Hardware/Live (1–2 Sessions)
- [x] **C5.1: P4A MIDI-Mapping** (v0.0.20.912) — Launchpad/APC40 Hardware-Mapping (MIDI Learn für Clip Launcher)
- [x] **C5.2: P4A Live-Performance-Modus** (v0.0.20.810) — Vollbild, Touch-optimiert (LivePerformancePanel existiert)
- [x] **C5.3: P4B Hardware Auto-Config** (v0.0.20.912) — Controller-Erkennung via USB-ID, OSC-Support

### P5: Cloud/Share (1 Session)
- [x] **C5.4: P5B Cloud-Projekt-Management** (v0.0.20.817) — Preset-Cloud, Sample-Cloud (lokales Verzeichnis, kein Server nötig)

### P6: Scripting/Community (1–2 Sessions)
- [x] **C5.5: P6A Macro-System** (v0.0.20.811) — UI-Aktionen aufzeichnen → Python-Script exportieren
- [x] **C5.6: P6A Dokumentation** (v0.0.20.811) — „Schreibe deinen ersten Plugin in 10 Minuten" Tutorial
- [x] **C5.7: P6B JSFX/Faust** (v0.0.20.812) — DSP-Plugins in Python/Faust compilieren
- [x] **C5.8: P6C Preset-Format** (v0.0.20.811) — .pydaw-preset YAML standardisieren
- [x] **C5.9: P6C Community-Browser** (v0.0.20.811) — Preset-Browser direkt in der DAW (existiert)

### P7: Video/Podcast (1 Session)
- [x] **C5.10: P7A Video-Sync** (v0.0.20.812) — Video-Spur im Arranger synchronisieren (VideoTrackService existiert)
- [x] **C5.11: P7B Podcast-Mode** (v0.0.20.812) — Vereinfachtes UI für Sprache (PodcastModeService existiert)

### Audio (1–2 Sessions)
- [x] **C5.12: P1B Pitch-Correction** (v0.0.20.806) — Melodyne-ähnlicher Blob-Editor
- [x] **C5.13: P1C Audio-Quantisierung** (v0.0.20.806) — Transientenbasiertes Beat-Alignment
- [x] **C5.14: Spectral Repair View** (v0.0.20.806) — Spektrogramm mit Selektions-Werkzeug

---

## 🔵 C6: DB-Integrationen (Phase 5 abhängig — ERLEDIGT ✅)

**Status:** Alle 12 Items erledigt in v0.0.20.887–v0.0.20.914.
Schema + Write + Read + Crash Recovery + Tests komplett.
JSON bleibt PRIMARY — SQLite ist Mirror für Crash Recovery + Queries.

### Phase 5: ProjectState (v0.0.20.892–914, ERLEDIGT)
- [x] **C6.1: Phase 5 ProjectState** (v0.0.20.914) — Tracks/Clips/Automation in SQLite
  - Schema: project_meta/tracks/clips/midi_notes/automation Tabellen ✅
  - Sync: sync_project() bei Save + Open ✅
  - Crash Recovery: reconstruct_project_dict() + try_recover_project() ✅
  - Fallback: open_project() versucht SQLite bei JSON-Fehler ✅
  - 36 Unit-Tests ✅

### Nach Phase 5 (alle erledigt):
- [x] **C6.2: Phase 10 MixerState** (v0.0.20.893) — In project_tracks (volume/pan/muted/solo)
- [x] **C6.3: Phase 13 TransportState** (v0.0.20.893) — In project_meta (bpm/punch)
- [x] **C6.4: Phase 14 UndoHistory** (v0.0.20.893) — undo_history Tabelle
- [x] **C6.5: Phase 16–18** (v0.0.20.893) — macro_recordings, collab_sessions, script_history
- [x] **C6.6: Phase 23–24** (v0.0.20.893) — note_expression_index, git_history
- [x] **C6.7: Phase 27 CloudSync** (v0.0.20.894) — cloud_sync_log + cloud_conflicts
- [x] **C6.8: Phase 28 PluginHostState** (v0.0.20.892) — plugin_states + Integration
- [x] **C6.9: Phase 29–30** (v0.0.20.893) — fx_chain_presets, engine_state
- [x] **C6.10: Phase 31–33** (v0.0.20.894) — arranger/pianoroll/notation_state + Integrationen
- [x] **C6.11: Phase 35–36** (v0.0.20.892) — recent_projects/media, export_history, plugin_crash_log
- [x] **C6.12: Phase 39–42** (v0.0.20.894) — video/podcast/mastering/undo_command_meta

---

## 🟢 H1: Hardware-Tests (NUR ANNO)

**⚠️ Diese Tests brauchen das echte DAW-System mit Audio-Hardware, Plugins, 2 Rechnern.**
**Kein Kollege kann diese ausführen — nur Anno.**

### H1A: Rust-Engine (auf Annos System)
- [ ] `cd pydaw_engine && cargo build --release`
- [ ] `./start_daw.sh` → Engine bleibt verbunden → Ton nach 5 Minuten Play
- [ ] A/B Vergleich: 8-Track-Projekt Python vs Rust → CPU%, Latenz, XRuns
- [ ] 20 Tracks simultan → kein XRun unter normaler Last
- [ ] RT-Permissions: `ulimit -r` prüfen, limits.conf @audio Gruppe
- [ ] `should_use_rust()` → True aktivieren nach erfolgreichem A/B-Test
- [ ] PipeWire Graph: Nur noch 1 Audio-Node (Python), nicht 2

### H1B: Plugins (auf Annos System)
- [ ] CLAP-Plugin (Surge XT): Laden → NoteOn → Ton → State speichern/laden
- [ ] LV2-Plugin (Calf Mono Synth): Laden → NoteOn → Ton
- [ ] VST3 (Surge XT, Nekobi): Sound, Editor, Reopen, Parameter
- [ ] Surge XT CLAP Editor: Shell-Overlay, Pin, Einrollen, Preset-Wechsel
- [ ] FusionEngine + C-Filter auf Linux/Debian
- [ ] BRRR PADsynth A/B-Vergleich mit ZynAdd

### H1C: Recording/Sampler (auf Annos System)
- [ ] Sampler-Persistenz: Zone laden → speichern → neustarten → noch da?
- [ ] Chromatic-Map: 12 Samples → 12 Noten → alle 12 klingen?
- [ ] Drum-Map: GM-Drums → korrekte Note-Zuordnung
- [ ] Comping-Workflow: Loop-Recording → Take-Lanes → Flatten
- [ ] Recording: Input-Monitoring < 10ms, Waveform-Preview

### H1D: Collab (2 Rechner im LAN)
- [ ] Session starten, verbinden, Chat, Parameter-Sync
- [ ] BPM bidirektional, Playhead-Sync
- [ ] Instrumente + Ctrl+J + Track Move/Group + Alt+Drag
- [ ] VST2/VST3/CLAP/LV2 Plugins bei Collab zuweisen
- [ ] DAW schließen nach Collab → kein Segfault?

### H1E: Sonstige
- [ ] Ghost Notes: + Add klicken, Clip-Liste laden
- [ ] Scripting Console: Ctrl+Alt+P → project.bpm = 140
- [ ] Git Workflow: Init → Commit → Branch → Merge
- [ ] Preset Universe: Doppelklick → Sound über ParamRegistry

---

## ⚪ O1: Optionale Polish-Items — ERLEDIGT ✅

**v0.0.20.915 — Alle 5 Items erledigt.**

- [x] VST2 Editor (Dexed) frameless machen (v0.0.20.915, opt-in via `vst2_editor_frameless` Setting)
- [x] Patch-Name im Device-Panel spiegeln (v0.0.20.915, _lbl_status bei State-Event)
- [x] Surge XT Editor-Hülle angleichen (Pin/Einrollen) (v0.0.20.834, verifiziert v0.0.20.915)
- [x] Watchdog für Editor-Helper-Prozess (v0.0.20.915, 30s Timeout)
- [x] Safe-Mode Toggle für Editor-Blockade (v0.0.20.915, `editor_safe_mode` Setting)

---

## 🔄 WIE ARBEITEN KOLLEGEN MIT DIESER ROADMAP?

```
1. Lies diese Datei: PROJECT_DOCS/OPEN_ITEMS_ROADMAP.md
2. Wähle die nächste offene Kategorie (C1 → C2 → C3 → ...)
3. Innerhalb der Kategorie: erstes [ ] Item nehmen
4. Abarbeiten, [x] abhaken, dokumentieren
5. ZIP bauen, zurückgeben
```

**Keine Angst vor Phase 5 (C6)!** — Die C1–C5 Items sind alle OHNE Phase-5-Blocker machbar.
Phase 5 ist ein größerer Umbau, der separat geplant werden sollte.

---

*Letztes Update: v0.0.20.915 — 2026-04-01*
