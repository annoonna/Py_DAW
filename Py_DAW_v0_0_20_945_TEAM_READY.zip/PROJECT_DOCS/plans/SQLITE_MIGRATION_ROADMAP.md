# SQLite Migration Roadmap — Py_DAW → Datenbank-Architektur

**Autor:** Anno (Sebastian Heber) + Claude  
**Erstellt:** 2026-03-31  
**Status:** Phase 1-4, 6-9, 15, 19-22, 25-26, 34, 37-38 FERTIG + 5 Integrationen (18/42) — Rest P5-abhängig  
**Oberste Direktive:** NICHTS KAPUTT MACHEN — jede Phase ist unabhängig lauffähig

---

## Vision

Alle Parameter, Presets, Instrument-Definitionen und Mappings in einer SQLite-Datenbank.
Beim Start wird alles in den RAM geladen (wie zRAM) — schneller Zugriff, keine Datei-I/O
während der Laufzeit. Neue Instrumente brauchen nur Datenbank-Einträge, keinen Python-Code.

```
┌──────────────────────────────────────────────────┐
│                  Py_DAW Start                     │
│                                                   │
│  1. SQLite DB öffnen (~/.config/CSStudio/pydaw.db)│
│  2. Alle Tabellen → Python dicts im RAM laden     │
│  3. DB schließen (oder read-only halten)          │
│  4. Laufzeit: nur RAM-Zugriff (dict lookup)       │
│  5. Änderungen → Queue → Batch-Write alle 5s      │
│                                                   │
│  Ergebnis: <1ms Zugriff auf jeden Parameter       │
└──────────────────────────────────────────────────┘
```

## Warum SQLite?

- **Eingebaut:** `import sqlite3` — keine Installation nötig
- **Schnell:** 100.000+ Reads/Sekunde, auch auf langsamen Disks
- **Robust:** ACID-konform, crash-safe, korrupte DBs quasi unmöglich
- **Portabel:** Eine Datei, kopierbar, backupbar
- **Zukunft:** Kann später zu PostgreSQL/Redis migriert werden wenn nötig
- **Standard:** Firefox, Chrome, Android, iOS — alle nutzen SQLite

---

## Phasen-Übersicht

| Phase | Name | Aufwand | Abhängig von | Risiko | Bereich |
|-------|------|---------|-------------|--------|---------|
| **P1** | ParamRegistry | 1 Session | — | Niedrig | Instrument-Parameter |
| **P2** | PresetDatabase | 1-2 Sessions | P1 | Niedrig | Preset-Verwaltung |
| **P3** | InstrumentDefinitions | 1 Session | P1 | Niedrig | Plugin-Registrierung |
| **P4** | FactorySamples | 1 Session | P1 | Niedrig | Sample-Generierung |
| **P5** | ProjectState | 2-3 Sessions | P1-P3 | Mittel | Tracks/Clips/Automation |
| **P6** | UserSettings + AudioConfig | 1 Session | P1 | Niedrig | QSettings → SQLite |
| **P7** | PluginCache | 1 Session | P1 | Niedrig | Scanner-Cache |
| **P8** | MIDIMappings + ControllerProfiles | 1 Session | P1, P5 | Niedrig | MIDI Learn/CC |
| **P9** | ThemeSystem | 1 Session | P6 | Niedrig | CSS/Farben/Fonts |
| **P10** | MixerState | 1 Session | P5 | Mittel | Fader/Pan/Sends |
| **P11** | AutomationData | 1-2 Sessions | P5 | Mittel | Lanes/Kurven/Envelopes |
| **P12** | ClipLauncherState | 1 Session | P5 | Mittel | Szenen/Slots/Queues |
| **P13** | TransportState | 1 Session | P5 | Niedrig | BPM/Loop/Punch/Metro |
| **P14** | UndoHistory | 1 Session | P5 | Mittel | Snapshots/Undo-Stack |
| **P15** | GrooveTemplates + Scales | 1 Session | P1 | Niedrig | Swing/Humanize/Skalen |
| **P16** | MacroRecordings | 1 Session | P5 | Niedrig | Aufgezeichnete Aktionen |
| **P17** | CollabState | 1 Session | P5 | Mittel | WebSocket/Sync/Peers |
| **P18** | ScriptingHistory | 1 Session | P5 | Niedrig | Python-Console History |
| **P19** | KeyBindings + Shortcuts | 1 Session | P6 | Niedrig | Tastatur-Zuordnungen |
| **P20** | UILayout + WindowState | 1 Session | P6 | Niedrig | Dock-Positionen/Zoom |
| **P21** | AudioDeviceConfig | 1 Session | P6 | Niedrig | Backend/Buffer/SR |
| **P22** | RecordingConfig | 1 Session | P6, P13 | Niedrig | Punch/Count-In/Takes |
| **P23** | NoteExpressions | 1 Session | P5, P11 | Mittel | MPE/Polyphonic AT |
| **P24** | GitIntegration | 1 Session | P5 | Niedrig | Commits/Branches/Diff |
| **P25** | ExportSettings | 1 Session | P6 | Niedrig | Format/Quality/Stem |
| **P26** | BrowserState | 1 Session | P6 | Niedrig | Places/Favorites/Recents |
| **P27** | CloudSync | 1 Session | P5, P6 | Mittel | Session-Share/Storage |
| **P28** | PluginHostState | 2 Sessions | P5, P7 | Hoch | VST2/VST3/CLAP/LV2/LADSPA State |
| **P29** | FXSystem | 1-2 Sessions | P5, P10 | Mittel | Builtin/Note/Audio FX Params |
| **P30** | AudioEngineState | 1 Session | P5 | Mittel | Playhead/Routing/Master Vol |
| **P31** | ArrangerState | 1 Session | P5, P20 | Niedrig | Zoom/Scroll/Grid/Selection |
| **P32** | PianoRollState | 1 Session | P5, P20 | Niedrig | Zoom/Velocity/Ghost Notes |
| **P33** | NotationEditor | 1 Session | P5 | Niedrig | Score/Clef/Events/Symbols |
| **P34** | MusicAI | 1 Session | P1, P15 | Niedrig | Composer/Drummer/Orchestrator |
| **P35** | FileIO | 1 Session | P5 | Mittel | DAWproject/MIDI I-O/Recovery |
| **P36** | PluginSandbox | 1 Session | P7, P28 | Mittel | Prozesse/Crash-Recovery |
| **P37** | Accessibility | 1 Session | P20 | Niedrig | Screen Reader/High Contrast |
| **P38** | AlternativeInputs | 1 Session | P8 | Niedrig | CV-Gate/Gamepad/OSC |
| **P39** | VideoTrack | 1 Session | P5 | Niedrig | Timeline/Sync/Render |
| **P40** | PodcastMode | 1 Session | P5 | Niedrig | Segmente/Chapters/Export |
| **P41** | Mastering | 1 Session | P10, P29 | Niedrig | Reference/SmartMix/Limiter |
| **P42** | UndoCommands | 1 Session | P5, P14 | Mittel | Command-Pattern/Snapshots |

**Jede Phase ist eigenständig — man kann nach P1 aufhören und alles funktioniert.**

### Empfohlene Reihenfolge

```
SOFORT:     P1 (ParamRegistry) — löst das aktuelle Preset-Problem
DANN:       P2 (PresetDatabase) — bessere Suche, Favorites
DANACH:     P3 + P4 (Instrument + Samples)
MITTEL:     P6 + P9 + P19 + P20 (Settings/Theme/Keys/Layout)
AUDIO:      P28 + P29 + P30 (Plugin Hosts/FX/Engine State)
PROJEKT:    P5 (ProjectState) — größter Umbau, braucht Vorbereitung
DARAUF:     P10-P14 (Mixer/Automation/Launcher/Transport/Undo)
EDITOR:     P31 + P32 + P33 (Arranger/PianoRoll/Notation)
KI+IO:      P34 + P35 (Music AI/File I/O)
INFRA:      P7 + P36 (PluginCache/Sandbox)
REST:       P8, P15-P18, P21-P27, P37-P42
```

**Gesamtaufwand geschätzt: ~35-45 Sessions über mehrere Monate.**
**Jede Phase ist eigenständig testbar und bricht nichts.**

---

## Phase 1: ParamRegistry (PRIORITÄT)

### Ziel
Eine Tabelle die beschreibt wie jeder Parameter jedes Instruments funktioniert.
Ersetzt alle hardcodierten Mapper in `device_panel.py`.

### Datei
`pydaw/services/param_registry.py`

### Schema

```sql
CREATE TABLE IF NOT EXISTS param_registry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    
    -- Instrument-Identifikation
    instrument TEXT NOT NULL,          -- "aeterna", "fusion", "brrr", "bachorgel", "sampler", "drum_machine", "advanced_sampler"
    plugin_id TEXT NOT NULL,           -- "chrono.aeterna", "chrono.fusion", etc.
    
    -- Parameter-Identifikation
    param_name TEXT NOT NULL,          -- universeller Name: "filter_cutoff", "amp_attack", etc.
    engine_key TEXT NOT NULL,          -- Engine-spezifisch: "filter_cutoff" (aeterna), "flt.cutoff" (fusion), "bp_freq" (brrr)
    knob_key TEXT,                     -- Widget _knobs Key (kann = engine_key sein oder anders)
    
    -- Wertebereiche
    value_type TEXT DEFAULT 'linear',  -- "linear", "exponential", "quadratic", "discrete", "boolean"
    input_min REAL DEFAULT 0.0,        -- Bereich für KI-Generator / Preset-Werte
    input_max REAL DEFAULT 1.0,
    knob_min INTEGER DEFAULT 0,        -- Bereich für UI-Knob (int)
    knob_max INTEGER DEFAULT 100,
    engine_min REAL DEFAULT 0.0,       -- Bereich für Engine
    engine_max REAL DEFAULT 1.0,
    default_value REAL DEFAULT 0.5,
    
    -- Metadaten für KI-Suche
    category TEXT,                     -- "filter", "envelope", "oscillator", "effect", "output"
    tags TEXT,                         -- comma-separated: "cutoff,brightness,tone,filter"
    description TEXT,                  -- "Filter Cutoff Frequenz in Hz"
    unit TEXT,                         -- "Hz", "ms", "dB", "%", "semitones"
    
    -- Mapping-Methode
    apply_method TEXT DEFAULT 'set_param',  -- "set_param", "import_state", "knob_direct", "widget_method"
    apply_detail TEXT,                      -- z.B. Methodenname: "_apply_preset", "set_filter"
    
    UNIQUE(instrument, param_name)
);

-- Index für schnelle Lookups
CREATE INDEX IF NOT EXISTS idx_param_instrument ON param_registry(instrument);
CREATE INDEX IF NOT EXISTS idx_param_plugin ON param_registry(plugin_id);
CREATE INDEX IF NOT EXISTS idx_param_category ON param_registry(category);
```

### RAM-Cache Implementierung

```python
# pydaw/services/param_registry.py

import sqlite3
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any

log = logging.getLogger(__name__)

class ParamRegistry:
    """Zentrale Parameter-Registry — SQLite-backed, RAM-cached.
    
    Beim Start: DB → RAM (dict of dicts).
    Laufzeit: nur dict lookups (<1µs).
    Schreiben: selten (nur bei Plugin-Änderungen).
    """
    
    _instance = None  # Singleton
    
    @classmethod
    def get(cls) -> "ParamRegistry":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "param_registry.db"
        self._cache: Dict[str, Dict[str, dict]] = {}  # instrument → param_name → row
        self._plugin_cache: Dict[str, str] = {}        # plugin_id → instrument
        self._loaded = False
    
    def ensure_loaded(self) -> None:
        """Load DB into RAM cache. Idempotent."""
        if self._loaded:
            return
        self._init_db()
        self._load_to_ram()
        self._loaded = True
        log.info("[ParamRegistry] Loaded %d instruments, %d total params",
                 len(self._cache),
                 sum(len(v) for v in self._cache.values()))
    
    def _init_db(self) -> None:
        """Create DB + tables if not exists. Seed with factory data."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.executescript(_SCHEMA_SQL)
            # Check if empty → seed
            count = conn.execute("SELECT COUNT(*) FROM param_registry").fetchone()[0]
            if count == 0:
                self._seed_factory_data(conn)
            conn.commit()
        finally:
            conn.close()
    
    def _load_to_ram(self) -> None:
        """Load entire DB into nested dicts for O(1) lookup."""
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute("SELECT * FROM param_registry").fetchall()
            self._cache.clear()
            self._plugin_cache.clear()
            for row in rows:
                inst = row["instrument"]
                pname = row["param_name"]
                if inst not in self._cache:
                    self._cache[inst] = {}
                self._cache[inst][pname] = dict(row)
                # Plugin ID → instrument mapping
                pid = row["plugin_id"]
                if pid and pid not in self._plugin_cache:
                    self._plugin_cache[pid] = inst
        finally:
            conn.close()
    
    # ── Public API ──────────────────────────────────────────────
    
    def get_instrument(self, plugin_id: str) -> str:
        """plugin_id → instrument name."""
        self.ensure_loaded()
        return self._plugin_cache.get(plugin_id, "")
    
    def get_params(self, instrument: str) -> Dict[str, dict]:
        """All params for an instrument as {param_name: row_dict}."""
        self.ensure_loaded()
        return dict(self._cache.get(instrument, {}))
    
    def get_param(self, instrument: str, param_name: str) -> Optional[dict]:
        """Single param definition."""
        self.ensure_loaded()
        return self._cache.get(instrument, {}).get(param_name)
    
    def convert_to_knob(self, instrument: str, param_name: str, value: float) -> int:
        """Convert a real-world value (Hz, seconds, etc.) to a knob integer.
        
        Uses the value_type field to determine scaling:
        - linear: proportional mapping
        - exponential: sqrt mapping (knob → value is squared)
        - quadratic: square mapping
        """
        p = self.get_param(instrument, param_name)
        if p is None:
            return 50  # default
        
        vtype = p.get("value_type", "linear")
        in_min = float(p.get("input_min", 0))
        in_max = float(p.get("input_max", 1))
        k_min = int(p.get("knob_min", 0))
        k_max = int(p.get("knob_max", 100))
        
        # Normalize to 0..1
        span = in_max - in_min
        if span <= 0:
            return k_min
        normalized = max(0.0, min(1.0, (float(value) - in_min) / span))
        
        # Apply curve
        if vtype == "exponential":
            normalized = normalized ** 0.5  # sqrt → knob space
        elif vtype == "quadratic":
            normalized = normalized ** 2.0
        
        # Scale to knob range
        return int(round(k_min + normalized * (k_max - k_min)))
    
    def convert_to_engine(self, instrument: str, param_name: str, value: float) -> float:
        """Convert a real-world value to engine value."""
        p = self.get_param(instrument, param_name)
        if p is None:
            return float(value)
        
        e_min = float(p.get("engine_min", 0))
        e_max = float(p.get("engine_max", 1))
        in_min = float(p.get("input_min", 0))
        in_max = float(p.get("input_max", 1))
        
        span = in_max - in_min
        if span <= 0:
            return e_min
        normalized = max(0.0, min(1.0, (float(value) - in_min) / span))
        
        return e_min + normalized * (e_max - e_min)
    
    def apply_preset(self, widget, plugin_id: str, params: dict) -> int:
        """Universal preset apply — uses registry to route params correctly.
        
        Returns: number of params successfully applied.
        """
        instrument = self.get_instrument(plugin_id)
        if not instrument:
            return 0
        
        registry = self.get_params(instrument)
        if not registry:
            return 0
        
        applied = 0
        knobs = getattr(widget, "_knobs", None)
        engine = getattr(widget, "engine", None)
        
        for param_name, value in params.items():
            if param_name.startswith("__"):
                continue  # skip meta keys
            
            pdef = registry.get(param_name)
            if pdef is None:
                continue
            
            method = pdef.get("apply_method", "set_param")
            engine_key = pdef.get("engine_key", param_name)
            knob_key = pdef.get("knob_key", engine_key)
            
            try:
                if method == "set_param" and engine and hasattr(engine, "set_param"):
                    engine_val = self.convert_to_engine(instrument, param_name, value)
                    engine.set_param(engine_key, engine_val)
                    applied += 1
                    
                elif method == "import_state" and engine and hasattr(engine, "import_state"):
                    # Collected later, applied as batch
                    pass
                    
                elif method == "knob_direct" and isinstance(knobs, dict):
                    knob = knobs.get(knob_key)
                    if knob is not None:
                        knob_val = self.convert_to_knob(instrument, param_name, value)
                        knob.blockSignals(True)
                        try:
                            knob.setValue(knob_val)
                        finally:
                            knob.blockSignals(False)
                        applied += 1
                
                # Update UI knob if available
                if isinstance(knobs, dict) and knob_key in knobs:
                    knob = knobs[knob_key]
                    knob_val = self.convert_to_knob(instrument, param_name, value)
                    try:
                        if hasattr(knob, "setValueExternal"):
                            knob.setValueExternal(knob_val)
                    except Exception:
                        pass
                        
            except Exception:
                pass
        
        return applied
    
    def _seed_factory_data(self, conn: sqlite3.Connection) -> None:
        """Seed the registry with all known instrument parameters."""
        for row in _FACTORY_PARAMS:
            try:
                conn.execute(
                    "INSERT OR IGNORE INTO param_registry "
                    "(instrument, plugin_id, param_name, engine_key, knob_key, "
                    " value_type, input_min, input_max, knob_min, knob_max, "
                    " engine_min, engine_max, default_value, category, tags, "
                    " description, unit, apply_method) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    row
                )
            except Exception:
                pass


# ── Schema SQL ──────────────────────────────────────────────────

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS param_registry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    instrument TEXT NOT NULL,
    plugin_id TEXT NOT NULL,
    param_name TEXT NOT NULL,
    engine_key TEXT NOT NULL,
    knob_key TEXT,
    value_type TEXT DEFAULT 'linear',
    input_min REAL DEFAULT 0.0,
    input_max REAL DEFAULT 1.0,
    knob_min INTEGER DEFAULT 0,
    knob_max INTEGER DEFAULT 100,
    engine_min REAL DEFAULT 0.0,
    engine_max REAL DEFAULT 1.0,
    default_value REAL DEFAULT 0.5,
    category TEXT,
    tags TEXT,
    description TEXT,
    unit TEXT,
    apply_method TEXT DEFAULT 'set_param',
    apply_detail TEXT,
    UNIQUE(instrument, param_name)
);
CREATE INDEX IF NOT EXISTS idx_param_instrument ON param_registry(instrument);
CREATE INDEX IF NOT EXISTS idx_param_plugin ON param_registry(plugin_id);
"""

# ── Factory Data ──────────────────────────────────────────────────
# Format: (instrument, plugin_id, param_name, engine_key, knob_key,
#          value_type, input_min, input_max, knob_min, knob_max,
#          engine_min, engine_max, default_value, category, tags,
#          description, unit, apply_method)

_FACTORY_PARAMS = [
    # ═══ AETERNA ═══
    ("aeterna", "chrono.aeterna", "filter_cutoff", "filter_cutoff", "filter_cutoff",
     "linear", 20, 20000, 0, 100, 0.0, 1.0, 0.68, "filter", "cutoff,brightness,tone",
     "Filter Cutoff Frequenz", "Hz", "set_param"),
    ("aeterna", "chrono.aeterna", "filter_resonance", "filter_resonance", "filter_resonance",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.18, "filter", "resonance,q",
     "Filter Resonanz", "", "set_param"),
    ("aeterna", "chrono.aeterna", "amp_attack", "aeg_attack", "aeg_attack",
     "linear", 0.001, 5, 0, 100, 0.0, 1.0, 0.01, "envelope", "attack,adsr",
     "Amplitude Attack", "s", "set_param"),
    ("aeterna", "chrono.aeterna", "amp_decay", "aeg_decay", "aeg_decay",
     "linear", 0.001, 5, 0, 100, 0.0, 1.0, 0.3, "envelope", "decay,adsr",
     "Amplitude Decay", "s", "set_param"),
    ("aeterna", "chrono.aeterna", "amp_sustain", "aeg_sustain", "aeg_sustain",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.7, "envelope", "sustain,adsr",
     "Amplitude Sustain", "", "set_param"),
    ("aeterna", "chrono.aeterna", "amp_release", "aeg_release", "aeg_release",
     "linear", 0.001, 10, 0, 100, 0.0, 1.0, 0.5, "envelope", "release,adsr",
     "Amplitude Release", "s", "set_param"),
    ("aeterna", "chrono.aeterna", "chorus_mix", "chorus_mix", None,
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "chorus,modulation",
     "Chorus Mix", "", "set_param"),
    ("aeterna", "chrono.aeterna", "reverb_mix", "reverb_mix", None,
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "reverb,space",
     "Reverb Mix", "", "set_param"),
    ("aeterna", "chrono.aeterna", "delay_mix", "delay_mix", None,
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "delay,echo",
     "Delay Mix", "", "set_param"),
    ("aeterna", "chrono.aeterna", "drive", "drive", None,
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "drive,distortion,saturation",
     "Drive Amount", "", "set_param"),
    ("aeterna", "chrono.aeterna", "stereo_spread", "stereo_spread", "stereo_spread",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.34, "output", "stereo,width,spread",
     "Stereo Spread", "", "set_param"),
    
    # ═══ FUSION ═══
    ("fusion", "chrono.fusion", "filter_cutoff", "flt.cutoff", "flt.cutoff",
     "exponential", 20, 20000, 0, 100, 20.0, 20000.0, 8000, "filter", "cutoff,brightness",
     "SVF Filter Cutoff", "Hz", "knob_direct"),
    ("fusion", "chrono.fusion", "filter_resonance", "flt.resonance", "flt.resonance",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "filter", "resonance,q",
     "SVF Filter Resonance", "", "knob_direct"),
    ("fusion", "chrono.fusion", "amp_attack", "aeg.attack", "aeg.attack",
     "quadratic", 0, 10, 0, 100, 0.0, 10.0, 0.02, "envelope", "attack,adsr",
     "Amp Envelope Attack", "s", "knob_direct"),
    ("fusion", "chrono.fusion", "amp_decay", "aeg.decay", "aeg.decay",
     "quadratic", 0, 10, 0, 100, 0.0, 10.0, 2.0, "envelope", "decay,adsr",
     "Amp Envelope Decay", "s", "knob_direct"),
    ("fusion", "chrono.fusion", "amp_sustain", "aeg.sustain", "aeg.sustain",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.7, "envelope", "sustain,adsr",
     "Amp Envelope Sustain", "", "knob_direct"),
    ("fusion", "chrono.fusion", "amp_release", "aeg.release", "aeg.release",
     "quadratic", 0, 10, 0, 100, 0.0, 10.0, 0.3, "envelope", "release,adsr",
     "Amp Envelope Release", "s", "knob_direct"),
    ("fusion", "chrono.fusion", "drive", "flt.drive", "flt.drive",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "drive,saturation",
     "Filter Drive", "", "knob_direct"),
    
    # ═══ BRRR ═══
    ("brrr", "chrono.brrr", "amp_attack", "buzz_attack", "buzz_attack",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "envelope", "attack,adsr",
     "Buzz Layer Attack", "s", "import_state"),
    ("brrr", "chrono.brrr", "amp_decay", "buzz_decay", "buzz_decay",
     "linear", 0.01, 2, 1, 200, 0.01, 2.0, 0.4, "envelope", "decay,adsr",
     "Buzz Layer Decay", "s", "import_state"),
    ("brrr", "chrono.brrr", "amp_sustain", "buzz_sustain", "buzz_sustain",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.4, "envelope", "sustain,adsr",
     "Buzz Layer Sustain", "", "import_state"),
    ("brrr", "chrono.brrr", "amp_release", "buzz_release", "buzz_release",
     "linear", 0.01, 2, 1, 200, 0.01, 2.0, 0.2, "envelope", "release,adsr",
     "Buzz Layer Release", "s", "import_state"),
    ("brrr", "chrono.brrr", "filter_cutoff", "bp_freq", "bp_freq",
     "exponential", 20, 20000, 20, 20000, 20.0, 20000.0, 1000, "filter", "cutoff,bandpass",
     "Bandpass Filter Frequenz", "Hz", "import_state"),
    ("brrr", "chrono.brrr", "filter_resonance", "bp_q", "bp_q",
     "linear", 0.1, 30, 1, 300, 0.1, 30.0, 1.0, "filter", "resonance,q,bandpass",
     "Bandpass Filter Q", "", "import_state"),
    ("brrr", "chrono.brrr", "chorus_mix", "fm_depth", "fm_depth",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.2, "effect", "fm,modulation",
     "FM/PAD Depth", "", "import_state"),
    ("brrr", "chrono.brrr", "reverb_mix", "flutter_volume", "flutter_volume",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.5, "effect", "flutter,modulation",
     "Flutter/Modulation Amount", "", "import_state"),
    
    # ═══ BACHORGEL ═══
    # BachOrgel nutzt _apply_preset(name) für built-in Presets.
    # Für "normalized params" Fallback werden die Synth-Section-Knobs gemappt.
    ("bachorgel", "chrono.bach_orgel", "filter_cutoff", "cutoff", "cut",
     "linear", 20, 20000, 0, 100, 0.0, 1.0, 0.68, "filter", "cutoff,brightness",
     "Synthesis Cutoff", "Hz", "knob_direct"),
    ("bachorgel", "chrono.bach_orgel", "amp_attack", "attack", "attack",
     "linear", 0, 5, 0, 100, 0.0, 1.0, 0.03, "envelope", "attack",
     "Synthesis Attack", "s", "knob_direct"),
    ("bachorgel", "chrono.bach_orgel", "amp_release", "release", "release",
     "linear", 0, 5, 0, 100, 0.0, 1.0, 0.4, "envelope", "release",
     "Synthesis Release", "s", "knob_direct"),
    
    # ═══ SAMPLER ═══
    ("sampler", "chrono.pro_audio_sampler", "filter_cutoff", "cutoff_hz", "cutoff",
     "exponential", 20, 20000, 0, 100, 20.0, 20000.0, 8000, "filter", "cutoff",
     "Filter Cutoff", "Hz", "widget_method"),
    ("sampler", "chrono.pro_audio_sampler", "amp_attack", "a", "a",
     "linear", 0.001, 5, 0, 100, 0.001, 5.0, 0.02, "envelope", "attack",
     "ADSR Attack", "s", "widget_method"),
    ("sampler", "chrono.pro_audio_sampler", "chorus_mix", "chorus_mix", "chorus",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "chorus",
     "Chorus Send", "", "widget_method"),
    ("sampler", "chrono.pro_audio_sampler", "reverb_mix", "reverb_mix", "reverb",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "reverb",
     "Reverb Send", "", "widget_method"),
]
```

### Schritt-für-Schritt Implementierung (für Kollegen)

```
SCHRITT 1: Datei erstellen
  → pydaw/services/param_registry.py (oben stehender Code)
  → NICHTS ÄNDERN an bestehenden Dateien

SCHRITT 2: Unit-Test
  → python3 -c "from pydaw.services.param_registry import ParamRegistry; r = ParamRegistry.get(); r.ensure_loaded(); print(r.get_params('fusion'))"

SCHRITT 3: In device_panel.py einbinden (OPTIONAL, SAFE)
  → In apply_universe_preset() VOR den hardcodierten Branches:
    try:
        from pydaw.services.param_registry import ParamRegistry
        registry = ParamRegistry.get()
        n = registry.apply_preset(widget, plugin_id, params)
        if n > 0:
            log.info("[PRESET-APPLY] ParamRegistry applied %d params", n)
            return
    except Exception:
        pass  # Fallback zu hardcodierten Branches

SCHRITT 4: Validieren
  → Alle Instrumente testen (Doppelklick auf Presets)
  → grep "ParamRegistry" ~/.cache/ChronoScaleStudio/pydaw.log
```

---

## Phase 2: PresetDatabase

### Ziel
Alle Presets (Factory, User, Community, KI-generiert) in SQLite statt JSON/Dicts.

### Schema

```sql
CREATE TABLE IF NOT EXISTS presets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    instrument TEXT NOT NULL,
    plugin_id TEXT NOT NULL,
    category TEXT,
    source TEXT DEFAULT 'factory',     -- factory, user, community, ki
    author TEXT DEFAULT 'ChronoScaleStudio',
    tags TEXT,                         -- comma-separated
    description TEXT,
    character TEXT,                    -- "warm, bright, dark, ..."
    is_favorite INTEGER DEFAULT 0,
    params TEXT NOT NULL,              -- JSON blob
    factory_sample TEXT,               -- relative path to sample
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    play_count INTEGER DEFAULT 0,
    UNIQUE(name, instrument, source)
);

CREATE INDEX IF NOT EXISTS idx_preset_instrument ON presets(instrument);
CREATE INDEX IF NOT EXISTS idx_preset_category ON presets(category);
CREATE INDEX IF NOT EXISTS idx_preset_tags ON presets(tags);
CREATE INDEX IF NOT EXISTS idx_preset_source ON presets(source);
CREATE INDEX IF NOT EXISTS idx_preset_favorite ON presets(is_favorite);

-- Volltext-Suche für semantische Preset-Suche
CREATE VIRTUAL TABLE IF NOT EXISTS presets_fts USING fts5(
    name, tags, description, character,
    content='presets', content_rowid='id'
);
```

### Vorteile gegenüber aktuellem System
- **Suche:** FTS5 Volltext-Suche statt Python string matching
- **Favorites:** persistent in DB statt flüchtiges Attribut
- **Play Count:** Tracking welche Presets beliebt sind
- **Community:** Presets teilen via DB-Export/Import

---

## Phase 3: InstrumentDefinitions

### Ziel
Instrument-Metadaten (Name, Kategorie, Widget-Klasse, Engine-Klasse) in DB statt hardcodiert.

```sql
CREATE TABLE IF NOT EXISTS instruments (
    id TEXT PRIMARY KEY,               -- "chrono.aeterna"
    name TEXT NOT NULL,                -- "AETERNA"
    display_name TEXT NOT NULL,        -- "AETERNA — Flagship Synth"
    category TEXT,                     -- "synth", "sampler", "drum_machine", "organ"
    engine_class TEXT,                 -- "pydaw.plugins.aeterna.aeterna_engine.AeternaEngine"
    widget_class TEXT,                 -- "pydaw.plugins.aeterna.aeterna_widget.AeternaWidget"
    has_set_param INTEGER DEFAULT 1,
    has_import_state INTEGER DEFAULT 0,
    has_apply_preset INTEGER DEFAULT 0,
    needs_samples INTEGER DEFAULT 0,
    icon TEXT,                         -- emoji or path
    description TEXT,
    sort_order INTEGER DEFAULT 0
);
```

---

## Phase 4: FactorySamples

### Ziel
Factory-Sample-Definitionen in DB statt hardcodiert in `factory_sample_gen.py`.

```sql
CREATE TABLE IF NOT EXISTS factory_samples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,          -- "kick_808"
    filename TEXT NOT NULL,             -- "kick_808.wav"
    category TEXT NOT NULL,             -- "drums", "melodic"
    generator TEXT NOT NULL,            -- "_synth_kick"
    args TEXT,                          -- JSON: ["808"]
    description TEXT,
    tags TEXT
);
```

---

## Phase 5: ProjectState (GRÖSSTER UMBAU)

### Ziel
Track-Konfigurationen, Instrument-States, Clip-Daten in SQLite.

**ACHTUNG:** Dies ist der riskanteste Teil. Nur nach ausgiebigem Testen von P1-P4.

```sql
-- Pro Projekt eine separate DB: project_name.pydaw.db

CREATE TABLE tracks (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    kind TEXT NOT NULL,                 -- "instrument", "audio", "master"
    plugin_id TEXT,
    position INTEGER DEFAULT 0,
    muted INTEGER DEFAULT 0,
    solo INTEGER DEFAULT 0,
    record_arm INTEGER DEFAULT 0,
    midi_input TEXT DEFAULT 'All ins',
    volume REAL DEFAULT 0.8,
    pan REAL DEFAULT 0.0,
    color TEXT,
    group_id TEXT,
    instrument_state TEXT               -- JSON blob
);

CREATE TABLE clips (
    id TEXT PRIMARY KEY,
    track_id TEXT NOT NULL REFERENCES tracks(id),
    kind TEXT NOT NULL,                  -- "midi", "audio"
    start_beats REAL NOT NULL,
    length_beats REAL NOT NULL,
    name TEXT,
    color TEXT,
    offset_beats REAL DEFAULT 0,
    data TEXT                            -- JSON blob (notes, automation, etc.)
);
```

---

## Phase 6: UserSettings

```sql
CREATE TABLE settings (
    key TEXT PRIMARY KEY,
    value TEXT,
    category TEXT,                      -- "audio", "midi", "ui", "collab"
    updated_at TEXT DEFAULT (datetime('now'))
);
```

---

## Phase 7: PluginCache

```sql
CREATE TABLE plugin_cache (
    path TEXT PRIMARY KEY,
    name TEXT,
    vendor TEXT,
    format TEXT,                        -- "vst3", "clap", "lv2", "vst2"
    is_instrument INTEGER DEFAULT 0,
    category TEXT,
    fingerprint TEXT,
    last_scan TEXT,
    scan_ok INTEGER DEFAULT 1,
    preset_count INTEGER DEFAULT 0,
    presets TEXT                         -- JSON blob
);
```

---

## Technische Regeln für alle Phasen

1. **NICHTS KAPUTT MACHEN** — jede Phase hat Fallback zum alten System
2. **Dual-Mode:** Neues System parallel zum alten, altes als Fallback
3. **Tests:** Jede Phase muss `python3 -c "import ..."` bestehen
4. **Migration:** Alte Daten → neue DB beim ersten Start (einmalig)
5. **Backup:** DB wird vor jeder Migration gesichert
6. **Performance:** RAM-Cache ist Pflicht — kein DB-Zugriff im Audio-Thread
7. **Thread-Safety:** SQLite nur vom GUI-Thread, RAM-Cache ist read-only nach Start

## Dateien die entstehen

```
pydaw/services/param_registry.py     ← Phase 1 (NEU)
pydaw/services/preset_database.py    ← Phase 2 (NEU)
pydaw/services/instrument_registry.py ← Phase 3 (NEU)
pydaw/services/db_manager.py         ← Basis: Connection Pool, Migration (NEU)
```

## Dateien die GEÄNDERT werden (vorsichtig, mit Fallback)

```
pydaw/ui/device_panel.py             ← apply_universe_preset() nutzt ParamRegistry
pydaw/ui/preset_universe_tab.py      ← _do_scan() liest aus PresetDatabase
pydaw/audio/factory_sample_gen.py    ← Definitionen aus DB statt hardcodiert
pydaw/services/project_service.py    ← Phase 5: Projekt-State aus DB
```

---

## Zeitplan-Schätzung

| Phase | Sessions | Priorität |
|-------|----------|-----------|
| P1 ParamRegistry | 1 | HOCH — sofort machbar |
| P2 PresetDatabase | 1-2 | HOCH |
| P3 InstrumentDefs | 1 | MITTEL |
| P4 FactorySamples | 1 | MITTEL |
| P5 ProjectState | 2-3 | MITTEL — spät |
| P6 UserSettings | 1 | MITTEL |
| P7 PluginCache | 1 | MITTEL |
| P8 MIDI Mappings | 1 | MITTEL |
| P9 ThemeSystem | 1 | NIEDRIG |
| P10 MixerState | 1 | MITTEL (nach P5) |
| P11 AutomationData | 1-2 | MITTEL (nach P5) |
| P12 ClipLauncher | 1 | MITTEL (nach P5) |
| P13 TransportState | 1 | NIEDRIG |
| P14 UndoHistory | 1 | MITTEL |
| P15 Grooves+Scales | 1 | NIEDRIG |
| P16-P27 | je 1 | NIEDRIG |
| P28 PluginHostState | 2 | HOCH — VST2/3/CLAP/LV2/LADSPA |
| P29 FXSystem | 1-2 | MITTEL |
| P30 AudioEngine | 1 | MITTEL |
| P31-P33 Editors | je 1 | NIEDRIG |
| P34-P42 Rest | je 1 | NIEDRIG |
| **GESAMT** | **~38 Sessions** | **42 Phasen, 364 Dateien** |

**Empfehlung:** P1 in der nächsten Session. Wenn das funktioniert, P2 danach.
Alles andere kann warten bis die Grundlage steht.

---

## Phase 8: MIDI Mappings + Controller Profiles

### Aktuell
- MIDI Learn Zuordnungen in `project.midi_mappings` (JSON in Projekt-Datei)
- Controller Profiles hardcodiert in `controller_profiles.py`
- nanoKEY2/nanoKONTROL2 Profile in Python-Dicts

### Schema

```sql
CREATE TABLE midi_mappings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id TEXT,                    -- NULL = global, sonst projekt-spezifisch
    cc_number INTEGER NOT NULL,
    channel INTEGER DEFAULT -1,        -- -1 = omni
    source_port TEXT,                   -- "nanoKONTROL2:..." oder ""
    target_track_id TEXT,
    target_param TEXT NOT NULL,         -- "filter_cutoff", "volume", etc.
    target_plugin_id TEXT,
    min_value REAL DEFAULT 0.0,
    max_value REAL DEFAULT 1.0,
    curve TEXT DEFAULT 'linear',       -- linear, exponential, toggle
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE controller_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,          -- "nanoKONTROL2", "Akai APC40", etc.
    device_pattern TEXT,               -- Regex für Auto-Detect
    profile_data TEXT NOT NULL,         -- JSON: pads, faders, buttons
    is_builtin INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 0
);
```

### Betroffene Dateien
- `pydaw/services/midi_mapping_service.py` → liest/schreibt aus DB
- `pydaw/services/controller_profiles.py` → Profile aus DB
- `pydaw/ui/midi_mapping_dialog.py` → UI unverändert

---

## Phase 9: Theme System

### Aktuell
- Themes hardcodiert als Python-Dataclasses in `theme_manager.py`
- 5 Built-in Themes: dark, light, midnight, solarized_dark, high_contrast
- CSS-Generierung in Python

### Schema

```sql
CREATE TABLE themes (
    id TEXT PRIMARY KEY,                -- "dark", "midnight", "user_custom_1"
    name TEXT NOT NULL,
    is_builtin INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 0,
    palette TEXT NOT NULL,              -- JSON: {bg, fg, accent, track_colors, ...}
    css_overrides TEXT,                 -- Zusätzliches CSS
    font_family TEXT DEFAULT 'sans-serif',
    font_size INTEGER DEFAULT 11,
    created_at TEXT DEFAULT (datetime('now'))
);
```

### Betroffene Dateien
- `pydaw/ui/theme_manager.py` → Themes aus DB laden
- `pydaw/ui/chrono_theme_css.py` → CSS-Generierung unverändert

---

## Phase 10: Mixer State

### Aktuell
- Fader/Pan/Solo/Mute in `Track` Dataclass (project.py)
- Send-Routing in `audio_fx_chain`
- VU-Meter-Peaks flüchtig (nicht gespeichert)

### Schema

```sql
CREATE TABLE mixer_channels (
    track_id TEXT PRIMARY KEY,
    volume REAL DEFAULT 0.8,
    pan REAL DEFAULT 0.0,
    muted INTEGER DEFAULT 0,
    solo INTEGER DEFAULT 0,
    record_arm INTEGER DEFAULT 0,
    color TEXT,
    width TEXT DEFAULT 'normal',       -- normal, narrow, wide
    meter_peak_l REAL DEFAULT 0,       -- für Restore nach Neustart
    meter_peak_r REAL DEFAULT 0
);

CREATE TABLE sends (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_track_id TEXT NOT NULL,
    target_track_id TEXT NOT NULL,
    send_level REAL DEFAULT 0.5,
    pre_fader INTEGER DEFAULT 0,
    enabled INTEGER DEFAULT 1
);

CREATE TABLE inserts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    track_id TEXT NOT NULL,
    slot_index INTEGER NOT NULL,
    plugin_id TEXT NOT NULL,
    plugin_name TEXT,
    enabled INTEGER DEFAULT 1,
    state TEXT,                         -- JSON: Plugin-State
    UNIQUE(track_id, slot_index)
);
```

---

## Phase 11: Automation Data

### Aktuell
- Automation Lanes in `Project.automation_manager_lanes` (Dict)
- Per-Clip Automation in `Clip.clip_automation` (Dict)
- Automations-Punkte als Listen von {beat, value} Dicts

### Schema

```sql
CREATE TABLE automation_lanes (
    id TEXT PRIMARY KEY,
    track_id TEXT NOT NULL,
    param_id TEXT NOT NULL,             -- "chrono.aeterna:filter_cutoff"
    visible INTEGER DEFAULT 1,
    height INTEGER DEFAULT 60,
    color TEXT,
    mode TEXT DEFAULT 'read'            -- off, read, write, touch, latch
);

CREATE TABLE automation_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lane_id TEXT NOT NULL REFERENCES automation_lanes(id),
    clip_id TEXT,                       -- NULL = global lane, sonst clip-lokal
    beat REAL NOT NULL,
    value REAL NOT NULL,
    curve TEXT DEFAULT 'linear',        -- linear, exponential, step, bezier
    tension REAL DEFAULT 0.0,           -- für Bezier-Kurven
    INDEX idx_points_lane_beat (lane_id, beat)
);
```

---

## Phase 12: Clip Launcher State

### Aktuell
- Clip-Slots im Project Model (`Clip` mit `launcher_*` Feldern)
- Szenen nicht persistent

### Schema

```sql
CREATE TABLE launcher_scenes (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    position INTEGER NOT NULL,
    color TEXT,
    tempo_override REAL,               -- NULL = project BPM
    time_sig_override TEXT             -- NULL = project time sig
);

CREATE TABLE launcher_slots (
    id TEXT PRIMARY KEY,
    scene_id TEXT REFERENCES launcher_scenes(id),
    track_id TEXT NOT NULL,
    clip_id TEXT REFERENCES clips(id),
    state TEXT DEFAULT 'stopped',       -- stopped, playing, recording, queued
    launch_mode TEXT DEFAULT 'trigger', -- trigger, gate, toggle
    quantize TEXT DEFAULT '1bar',
    follow_action TEXT,                 -- JSON: {action, time, probability}
    color TEXT
);
```

---

## Phase 13: Transport State

### Aktuell
- BPM, Time Signature, Loop, Punch in `TransportService` (flüchtig)
- Metronom in `metronome_service.py`
- Count-In Einstellungen verstreut

### Schema

```sql
CREATE TABLE transport_state (
    key TEXT PRIMARY KEY,
    value TEXT
);
-- Keys: bpm, time_signature, loop_enabled, loop_start, loop_end,
--        punch_enabled, punch_in, punch_out, count_in_bars,
--        metronome_enabled, metronome_volume, metronome_accent,
--        metronome_sound, pre_roll, post_roll,
--        playhead_position, snap_grid, follow_playhead
```

---

## Phase 14: Undo History

### Aktuell
- Undo-Stack als Python-Liste von JSON-Snapshots
- 105 Referenzen auf Undo im project_service.py

### Schema

```sql
CREATE TABLE undo_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT NOT NULL,
    snapshot TEXT NOT NULL,              -- JSON: kompletter Projekt-State
    created_at TEXT DEFAULT (datetime('now')),
    is_current INTEGER DEFAULT 0
);
-- Max 50 Einträge, älteste werden gelöscht
```

---

## Phase 15: Groove Templates + Scales

### Aktuell
- Groove Templates hardcodiert in `groove_templates.py`
- Skalen in `notation/scales/scales.json`

### Schema

```sql
CREATE TABLE groove_templates (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT,                      -- "MPC", "Jazz", "Latin", "Custom"
    swing_pct REAL DEFAULT 0,
    timing_offsets TEXT,                -- JSON: [offset_per_step]
    velocity_pattern TEXT,             -- JSON: [velocity_per_step]
    is_builtin INTEGER DEFAULT 1
);

CREATE TABLE scales (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    intervals TEXT NOT NULL,            -- JSON: [0,2,4,5,7,9,11] für Dur
    category TEXT,                      -- "Western", "Oriental", "Jazz", etc.
    root_note INTEGER DEFAULT 0
);
```

---

## Phase 16-27: Kurzübersicht

| Phase | Tabelle | Aktuelle Quelle | Zeilen (geschätzt) |
|-------|---------|-----------------|-------------------|
| P16 MacroRecordings | `macros` | macro_recorder.py (RAM) | ~50 |
| P17 CollabState | `collab_peers`, `collab_history` | collab_service.py (WebSocket) | ~20 |
| P18 ScriptingHistory | `script_history` | scripting_service.py (RAM) | ~100 |
| P19 KeyBindings | `keybindings` | QShortcut hardcodiert | ~80 |
| P20 UILayout | `ui_layout` | QSettings (Registry/plist) | ~30 |
| P21 AudioDeviceConfig | `audio_config` | QSettings | ~15 |
| P22 RecordingConfig | `recording_config` | recording_service.py | ~10 |
| P23 NoteExpressions | `note_expr_config` | note_expression_engine.py | ~20 |
| P24 GitIntegration | `git_config` | git_integration_service.py | ~10 |
| P25 ExportSettings | `export_config` | audio_export_service.py | ~15 |
| P26 BrowserState | `browser_places`, `browser_recents` | browser_places_tab.py | ~30 |
| P27 CloudSync | `cloud_config` | cloud_service.py | ~10 |

---

## Komplettes Datenbankschema — Übersicht

```
pydaw.db (Hauptdatenbank, ~/.config/ChronoScaleStudio/)
├── param_registry          ← P1: Instrument-Parameter-Definitionen
├── presets                 ← P2: Alle Presets (Factory + User + KI)
├── presets_fts             ← P2: Volltext-Suche
├── instruments             ← P3: Instrument-Metadaten
├── factory_samples         ← P4: Sample-Definitionen
├── settings                ← P6: User-Einstellungen
├── plugin_cache            ← P7: VST3/CLAP/LV2 Scanner
├── midi_mappings           ← P8: MIDI Learn
├── controller_profiles     ← P8: Hardware-Controller
├── themes                  ← P9: Farb-/Font-Themes
├── groove_templates        ← P15: Swing/Humanize
├── scales                  ← P15: Tonleitern
├── keybindings             ← P19: Tastatur-Shortcuts
├── ui_layout               ← P20: Fenster-Positionen
├── audio_config            ← P21: Audio-Backend
├── browser_places          ← P26: Browser-Favoriten
└── browser_recents         ← P26: Zuletzt verwendet

project_name.pydaw.db (Pro Projekt, im Projektordner)
├── tracks                  ← P5: Track-Definitionen
├── clips                   ← P5: Clip-Daten
├── mixer_channels          ← P10: Mixer-State
├── sends                   ← P10: Send-Routing
├── inserts                 ← P10: Plugin-Inserts
├── automation_lanes        ← P11: Automation-Spuren
├── automation_points       ← P11: Automation-Punkte
├── launcher_scenes         ← P12: Clip-Launcher-Szenen
├── launcher_slots          ← P12: Clip-Launcher-Slots
├── transport_state         ← P13: BPM/Loop/Punch
├── undo_history            ← P14: Undo-Stack
├── macro_recordings        ← P16: Aufgezeichnete Makros
├── collab_history          ← P17: Collab-Verlauf
├── script_history          ← P18: Script-Verlauf
├── note_expr_config        ← P23: Note-Expression-Setup
├── recording_config        ← P22: Aufnahme-Settings
├── export_config           ← P25: Export-Settings
└── git_config              ← P24: Git-Branch/Remote
```

---

## Komplette Datei-Liste — Was entsteht, was wird geändert

### NEUE Dateien (eine pro Kernmodul)

```
pydaw/services/db_manager.py          ← Basis: Connection Pool, Migrations, Backup
pydaw/services/param_registry.py      ← P1: ParamRegistry (Singleton, RAM-Cache)
pydaw/services/preset_database.py     ← P2: PresetDatabase
pydaw/services/instrument_registry.py ← P3: InstrumentRegistry
pydaw/services/app_database.py        ← P6-P27: Alle App-weiten Tabellen
pydaw/services/project_database.py    ← P5+P10-P14: Projekt-spezifische Tabellen
```

### GEÄNDERTE Dateien (mit Fallback, NIE breaking)

```
PHASE 1:
  pydaw/ui/device_panel.py             ← apply_universe_preset() → ParamRegistry

PHASE 2:
  pydaw/ui/preset_universe_tab.py      ← _do_scan() → PresetDatabase

PHASE 3:
  pydaw/plugins/registry.py            ← get_instruments() → InstrumentRegistry

PHASE 4:
  pydaw/audio/factory_sample_gen.py    ← Definitionen aus DB

PHASE 5:
  pydaw/services/project_service.py    ← save/load → ProjectDatabase
  pydaw/model/project.py               ← Track/Clip Dataclasses bleiben, DB als Backend

PHASE 6:
  pydaw/core/settings_store.py         ← QSettings → SQLite (Fallback: QSettings)

PHASE 7:
  pydaw/services/plugin_scanner.py     ← Cache → SQLite

PHASE 8:
  pydaw/services/midi_mapping_service.py ← Mappings aus DB
  pydaw/services/controller_profiles.py  ← Profile aus DB

PHASE 9:
  pydaw/ui/theme_manager.py            ← Themes aus DB

PHASE 10:
  pydaw/ui/mixer.py                    ← Fader-State aus DB

PHASE 11:
  pydaw/services/automation_playback.py ← Lanes/Punkte aus DB
  pydaw/ui/automation_editor.py         ← UI liest aus DB

PHASE 12:
  pydaw/ui/clip_launcher.py            ← Szenen/Slots aus DB

PHASE 13:
  pydaw/services/transport_service.py   ← State aus DB
  pydaw/services/metronome_service.py   ← Settings aus DB

PHASE 14:
  pydaw/services/project_service.py     ← Undo-Stack in DB

PHASE 15:
  pydaw/audio/groove_templates.py       ← Templates aus DB

PHASE 16:
  pydaw/services/macro_recorder.py      ← Recordings in DB

PHASE 17:
  pydaw/services/collab_service.py      ← Peer-History in DB

PHASE 18:
  pydaw/services/scripting_service.py   ← History in DB

PHASE 19:
  pydaw/ui/arranger_keyboard.py         ← Shortcuts aus DB
  pydaw/ui/actions.py                   ← Actions aus DB

PHASE 20:
  pydaw/ui/main_window.py              ← Dock-State aus DB
  pydaw/ui/screen_layout.py            ← Layout aus DB

PHASE 21:
  pydaw/ui/audio_settings_dialog.py     ← Device aus DB

PHASE 22:
  pydaw/services/recording_service.py   ← Config aus DB

PHASE 23:
  pydaw/ui/note_expression_engine.py    ← Config aus DB

PHASE 24:
  pydaw/services/git_integration_service.py ← Config aus DB

PHASE 25:
  pydaw/services/audio_export_service.py ← Settings aus DB

PHASE 26:
  pydaw/ui/browser_places_tab.py        ← Places aus DB

PHASE 27:
  pydaw/services/cloud_service.py       ← Config aus DB
```

---

## Phase 28: Plugin Host State (VST2/VST3/CLAP/LV2/LADSPA)

### Aktuell
- VST2: ctypes-basiert, `_host_state` dict in vst2_host.py, Parameter via AEffect
- VST3: pedalboard-basiert, State als opaque blob, Parameter via get_param_infos
- CLAP: ctypes-basiert, clap_event_param_value_t, eigenes Event-System
- LV2: lilv-basiert, ControlInfo Ports, Probe-Cache als JSON
- LADSPA: ctypes LADSPA_Descriptor, keine State-Persistenz

### Schema

```sql
CREATE TABLE plugin_instances (
    id TEXT PRIMARY KEY,                -- "{track_id}:{slot_index}"
    track_id TEXT NOT NULL,
    slot_index INTEGER NOT NULL,
    format TEXT NOT NULL,               -- "vst2", "vst3", "clap", "lv2", "ladspa"
    plugin_path TEXT NOT NULL,          -- "/usr/lib/vst3/surge-xt.vst3"
    plugin_name TEXT,
    is_instrument INTEGER DEFAULT 0,
    state_blob BLOB,                    -- Opaque plugin state (VST3/CLAP getState)
    state_json TEXT,                    -- Readable params as JSON backup
    enabled INTEGER DEFAULT 1,
    bypassed INTEGER DEFAULT 0,
    latency_samples INTEGER DEFAULT 0,
    last_error TEXT,
    gui_visible INTEGER DEFAULT 0,
    gui_x INTEGER, gui_y INTEGER,       -- GUI window position
    gui_w INTEGER, gui_h INTEGER
);

CREATE TABLE plugin_params (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    instance_id TEXT NOT NULL REFERENCES plugin_instances(id),
    param_index INTEGER NOT NULL,
    param_id TEXT,                       -- CLAP/VST3 param ID string
    param_name TEXT,
    value REAL NOT NULL,
    min_value REAL DEFAULT 0.0,
    max_value REAL DEFAULT 1.0,
    default_value REAL DEFAULT 0.0,
    is_automated INTEGER DEFAULT 0,
    UNIQUE(instance_id, param_index)
);
```

### Betroffene Dateien
- `pydaw/audio/vst2_host.py` — `_host_state` dict → DB
- `pydaw/audio/vst3_host.py` — pedalboard state → DB blob
- `pydaw/audio/clap_host.py` — clap state → DB blob
- `pydaw/audio/lv2_host.py` — control values → DB
- `pydaw/audio/ladspa_host.py` — port values → DB
- `pydaw/plugin_workers/vst2_worker.py` — Sandbox state sync
- `pydaw/plugin_workers/vst3_worker.py` — Sandbox state sync
- `pydaw/plugin_workers/clap_worker.py` — Sandbox state sync
- `pydaw/plugin_workers/lv2_ladspa_worker.py` — Sandbox state sync

---

## Phase 29: FX System

### Aktuell
- Builtin FX: ParametricEqFx, CompressorFx, ReverbFx etc. in builtin_fx.py
- Creative FX: creative_fx.py (Granular, Spectral, Glitch)
- Live FX: live_fx.py (Monitor-Effekte)
- Note FX: Transpose, VelocityScale, ScaleSnap in fx_device_widgets.py
- FX Chain: fx_chain.py (_FxLayer, FxLayerContainer)
- FX Specs: fx_specs.py (FX-Definitionen für Browser)
- UI Widgets: fx_device_widgets.py (GainFxWidget, DistortionFxWidget, etc.)

### Schema

```sql
CREATE TABLE fx_definitions (
    id TEXT PRIMARY KEY,                -- "builtin.compressor", "builtin.reverb"
    name TEXT NOT NULL,
    category TEXT,                      -- "dynamics", "spatial", "modulation", "filter", "note_fx"
    type TEXT,                          -- "audio_fx", "note_fx", "midi_fx"
    widget_class TEXT,
    engine_class TEXT,
    param_count INTEGER DEFAULT 0,
    is_builtin INTEGER DEFAULT 1,
    description TEXT,
    icon TEXT
);

CREATE TABLE fx_presets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fx_id TEXT NOT NULL REFERENCES fx_definitions(id),
    name TEXT NOT NULL,
    params TEXT NOT NULL,               -- JSON: {param: value}
    is_factory INTEGER DEFAULT 0,
    author TEXT,
    UNIQUE(fx_id, name)
);

-- Per-track FX chain (supplements inserts table from P10)
CREATE TABLE fx_chain_slots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    track_id TEXT NOT NULL,
    chain_type TEXT NOT NULL,           -- "note_fx", "audio_insert", "audio_send"
    slot_index INTEGER NOT NULL,
    fx_id TEXT NOT NULL,                -- "builtin.compressor" or plugin_id
    params TEXT,                        -- JSON: current param values
    enabled INTEGER DEFAULT 1,
    UNIQUE(track_id, chain_type, slot_index)
);
```

### Betroffene Dateien
- `pydaw/audio/builtin_fx.py` — FX-State aus DB laden/speichern
- `pydaw/audio/creative_fx.py` — Creative FX params
- `pydaw/audio/live_fx.py` — Monitor FX State
- `pydaw/audio/fx_chain.py` — Chain-Konfiguration aus DB
- `pydaw/audio/fx_processors.py` — Processor-State
- `pydaw/audio/note_fx_chain.py` — Note-FX Chain
- `pydaw/audio/utility_fx.py` — Utility FX State
- `pydaw/ui/fx_device_widgets.py` — Widget-State aus DB
- `pydaw/ui/fx_specs.py` — FX-Definitionen aus DB
- `pydaw/ui/audio_fx_chain_editor.py` — Chain Editor

---

## Phase 30: Audio Engine State

### Aktuell
- Master Volume/Pan in AudioEngine Instanz
- Playhead Position flüchtig (TransportService)
- Pull-Source-Routing in _EngineThread
- Sample Rate / Buffer Size in AudioBackendInfo
- Arrangement Renderer State

### Schema

```sql
CREATE TABLE audio_engine_state (
    key TEXT PRIMARY KEY,
    value TEXT
);
-- Keys: master_volume, master_pan, sample_rate, buffer_size,
--        backend_name, backend_device, latency_ms,
--        playhead_samples, generation_counter,
--        rust_engine_enabled, rust_engine_path,
--        rt_priority, rt_policy, gc_disabled,
--        prerender_enabled, prerender_progress
```

### Betroffene Dateien
- `pydaw/audio/audio_engine.py` — Haupt-Engine State
- `pydaw/audio/arrangement_renderer.py` — Render-Cache State
- `pydaw/audio/arranger_cache.py` — Waveform-Cache
- `pydaw/audio/ring_buffer.py` — Buffer-Konfiguration
- `pydaw/audio/rt_thread.py` — RT-Thread Konfiguration
- `pydaw/audio/rt_params.py` — Echtzeit-Parameter
- `pydaw/audio/qt_audio_sink_backend.py` — Qt Audio Backend
- `pydaw/audio/hybrid_engine.py` — Rust/Python Hybrid State
- `pydaw/audio/preview_player.py` — Preview State
- `pydaw/audio/preview_cache.py` — Cache State
- `pydaw/services/rust_engine_bridge.py` — IPC State
- `pydaw/services/rust_hybrid_engine.py` — Hybrid State
- `pydaw/services/rust_audio_takeover.py` — Takeover State
- `pydaw/services/rust_project_sync.py` — Projekt-Sync
- `pydaw/services/rust_sample_sync.py` — Sample-Sync

---

## Phase 31: Arranger State

### Schema

```sql
CREATE TABLE arranger_state (
    key TEXT PRIMARY KEY,
    value TEXT
);
-- Keys: pixels_per_beat, vertical_zoom, scroll_x, scroll_y,
--        snap_grid, snap_enabled, follow_playhead,
--        selected_clip_ids, selected_track_id,
--        ruler_zoom_level, loop_handle_visible,
--        track_heights (JSON: {track_id: height}),
--        track_colors (JSON: {track_id: color}),
--        arranger_mode (arrange|edit|mix)
```

### Betroffene Dateien
- `pydaw/ui/arranger.py` — Track-Liste State
- `pydaw/ui/arranger_canvas.py` — Canvas Zoom/Scroll/Selection
- `pydaw/ui/arranger_view.py` — View-Modus
- `pydaw/ui/arranger_keyboard.py` — Keyboard Shortcuts State
- `pydaw/ui/arranger_gl_overlay.py` — GL Overlay State
- `pydaw/ui/track_list.py` — Track-Reihenfolge

---

## Phase 32: Piano Roll State

### Schema

```sql
CREATE TABLE pianoroll_state (
    key TEXT PRIMARY KEY,
    value TEXT
);
-- Keys: zoom_h, zoom_v, scroll_x, scroll_y,
--        snap_grid, velocity_mode, default_velocity,
--        ghost_layers (JSON), note_length_grid,
--        note_expression_param, note_expression_visible,
--        scale_highlight, root_note, selected_note_ids
```

### Betroffene Dateien
- `pydaw/ui/pianoroll_canvas.py` — Canvas State
- `pydaw/ui/pianoroll_editor.py` — Editor State
- `pydaw/ui/pianoroll_ghost_notes.py` — Ghost Notes Layer State
- `pydaw/ui/velocity_bar.py` — Velocity Bar State
- `pydaw/ui/note_expression_lane.py` — Expression Lane State
- `pydaw/ui/note_expression_engine.py` — Expression Engine Config
- `pydaw/model/ghost_notes.py` — Ghost Notes Model

---

## Phase 33: Notation Editor

### Schema

```sql
CREATE TABLE notation_config (
    key TEXT PRIMARY KEY,
    value TEXT
);
-- Keys: clef_type, key_signature, time_signature,
--        staff_spacing, note_size, show_accidentals,
--        show_dynamics, show_articulations,
--        playback_synth, playback_volume,
--        selected_tool, zoom_level

CREATE TABLE notation_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    clip_id TEXT NOT NULL,
    event_type TEXT NOT NULL,           -- "note", "rest", "dynamic", "articulation"
    beat REAL NOT NULL,
    pitch INTEGER,
    duration REAL,
    velocity INTEGER,
    symbol TEXT,                        -- "pp", "ff", "staccato", etc.
    voice INTEGER DEFAULT 0
);
```

### Betroffene Dateien
- `pydaw/ui/notation_editor.py` — Haupteditor
- `pydaw/ui/notation_editor_full.py` — Vollversion
- `pydaw/ui/notation_editor_lite.py` — Lite-Version
- `pydaw/ui/notation/notation_view.py` — View
- `pydaw/ui/notation/staff_renderer.py` — Rendering
- `pydaw/ui/notation/notation_palette.py` — Symbol-Palette
- `pydaw/ui/notation/notation_ghost_notes.py` — Ghost Notes
- `pydaw/ui/notation/clef_dialog.py` — Schlüssel-Dialog
- `pydaw/ui/notation/tools.py` — Werkzeuge
- `pydaw/notation/music/model.py` — Notation Model
- `pydaw/notation/music/notes.py` — Noten
- `pydaw/notation/music/events.py` — Events
- `pydaw/notation/music/sequence.py` — Sequenzen
- `pydaw/notation/music/automation.py` — Automation
- `pydaw/notation/music/tempo.py` — Tempo Map
- `pydaw/notation/music/tracks.py` — Notation Tracks
- `pydaw/notation/music/intervals.py` — Intervalle
- `pydaw/notation/scales/database.py` — Skalen-DB
- `pydaw/notation/ai/scale_ai.py` — KI-Skalen
- `pydaw/notation/audio/synth.py` — Playback Synth
- `pydaw/notation/audio/direct_synth.py` — Direct Synth
- `pydaw/notation/audio/playback_worker.py` — Playback
- `pydaw/notation/midi/midi_io.py` — MIDI I/O
- `pydaw/notation/midi/scale_player.py` — Scale Player
- `pydaw/notation/osc/osc_server.py` — OSC Server
- `pydaw/notation/gui/score_view.py` — Score View
- `pydaw/notation/gui/scale_browser.py` — Scale Browser
- `pydaw/notation/gui/toolbox.py` — Toolbox
- `pydaw/notation/gui/transport_bar.py` — Transport
- `pydaw/notation/gui/undo_stack.py` — Undo

---

## Phase 34: Music AI

### Schema

```sql
CREATE TABLE ai_config (
    key TEXT PRIMARY KEY,
    value TEXT
);
-- Keys: composer_style, composer_complexity, composer_scale,
--        drummer_genre, drummer_density, drummer_swing,
--        orchestrator_arrangement, orchestrator_voicing,
--        genre_detection_enabled, harmony_analysis_mode

CREATE TABLE ai_generation_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,                 -- "melody", "drums", "chord_progression", "arrangement"
    params TEXT NOT NULL,               -- JSON: generation parameters
    result TEXT,                        -- JSON: generated MIDI data
    rating INTEGER,                    -- User rating 1-5
    created_at TEXT DEFAULT (datetime('now'))
);
```

### Betroffene Dateien
- `pydaw/music/ai_composer.py` — Melody/Chord Generation
- `pydaw/music/ai_drummer.py` — Drum Pattern Generation
- `pydaw/music/ai_orchestrator.py` — Arrangement AI
- `pydaw/music/genre_detector.py` — Genre Detection
- `pydaw/music/harmony_analysis.py` — Harmonie-Analyse
- `pydaw/music/melody_generator.py` — Melodie-Generator
- `pydaw/music/rhythm_analysis.py` — Rhythmus-Analyse
- `pydaw/music/scales.py` — Skalen
- `pydaw/music/local_music_ai.py` — Lokale KI
- `pydaw/ui/ki_assistant_panel.py` — KI-Assistent UI
- `pydaw/ui/orchestrator_dialog.py` — Orchestrator Dialog
- `pydaw/services/preset_generator.py` — Preset KI

---

## Phase 35: File I/O

### Schema

```sql
CREATE TABLE io_config (
    key TEXT PRIMARY KEY,
    value TEXT
);
-- Keys: default_project_dir, recent_projects (JSON list),
--        auto_save_interval_sec, backup_count,
--        dawproject_export_version, dawproject_import_mapping,
--        midi_import_quantize, midi_export_format,
--        recovery_enabled, recovery_interval_sec

CREATE TABLE recent_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    path TEXT NOT NULL UNIQUE,
    type TEXT,                          -- "project", "sample", "midi", "preset"
    last_opened TEXT DEFAULT (datetime('now')),
    pin_order INTEGER DEFAULT 0         -- 0 = not pinned
);
```

### Betroffene Dateien
- `pydaw/fileio/file_manager.py` — Datei-Verwaltung
- `pydaw/fileio/project_io.py` — Projekt-I/O
- `pydaw/fileio/audio_formats.py` — Audio-Format-Erkennung
- `pydaw/fileio/midi_io.py` — MIDI Import/Export
- `pydaw/fileio/dawproject_exporter.py` — DAWproject Export
- `pydaw/fileio/dawproject_importer.py` — DAWproject Import
- `pydaw/fileio/dawproject_plugin_map.py` — Plugin-Mapping
- `pydaw/fileio/recovery.py` — Crash-Recovery
- `pydaw/audio/midi_export.py` — MIDI Export Engine
- `pydaw/audio/midi_render.py` — MIDI Render
- `pydaw/audio/sampler_render.py` — Sample Render

---

## Phase 36: Plugin Sandbox

### Schema

```sql
CREATE TABLE sandbox_config (
    key TEXT PRIMARY KEY,
    value TEXT
);
-- Keys: sandbox_enabled, max_processes, crash_restart_limit,
--        process_timeout_sec, memory_limit_mb,
--        watchdog_interval_sec, ipc_protocol

CREATE TABLE sandbox_processes (
    id TEXT PRIMARY KEY,                -- process UUID
    plugin_path TEXT NOT NULL,
    plugin_format TEXT,
    pid INTEGER,
    state TEXT DEFAULT 'starting',     -- starting, running, crashed, stopped
    crash_count INTEGER DEFAULT 0,
    last_crash TEXT,
    memory_mb REAL DEFAULT 0,
    cpu_percent REAL DEFAULT 0,
    started_at TEXT
);
```

### Betroffene Dateien
- `pydaw/services/plugin_sandbox.py` — Sandbox-Manager
- `pydaw/services/sandbox_process_manager.py` — Prozess-Manager
- `pydaw/services/sandboxed_fx.py` — Sandbox FX Wrapper
- `pydaw/services/sandbox_overrides.py` — Override Config
- `pydaw/services/plugin_ipc.py` — IPC Kommunikation
- `pydaw/services/plugin_probe.py` — Plugin-Probe
- `pydaw/audio/clap_gui_process.py` — CLAP GUI Prozess
- `pydaw/audio/vst_gui_process.py` — VST GUI Prozess
- `pydaw/ui/sandbox_status_dialog.py` — Status-Dialog

---

## Phase 37-42: Kurzschemas

### P37: Accessibility
```sql
CREATE TABLE accessibility_config (key TEXT PRIMARY KEY, value TEXT);
-- screen_reader_enabled, high_contrast, large_fonts, focus_indicators,
-- keyboard_navigation_mode, announce_transport, announce_notes
```
Dateien: `ui/accessibility.py`, `ui/accessibility_service.py`

### P38: Alternative Inputs
```sql
CREATE TABLE input_config (key TEXT PRIMARY KEY, value TEXT);
-- cv_gate_enabled, cv_device, gate_device, osc_port, osc_enabled,
-- gamepad_enabled, gamepad_mapping, touch_keyboard_layout
```
Dateien: `services/cv_gate_service.py`, `services/gamepad_input.py`, `services/osc_controller.py`, `services/osc_midi_input.py`, `services/computer_keyboard_midi.py`, `ui/touch_keyboard.py`, `ui/computer_keyboard_overlay.py`

### P39: Video Track
```sql
CREATE TABLE video_config (key TEXT PRIMARY KEY, value TEXT);
-- video_path, sync_mode, offset_ms, visible, render_quality
```
Dateien: `services/video_track.py`

### P40: Podcast Mode
```sql
CREATE TABLE podcast_config (key TEXT PRIMARY KEY, value TEXT);
-- chapters (JSON), segments (JSON), export_format, intro_path, outro_path
```
Dateien: `services/podcast_mode.py`

### P41: Mastering
```sql
CREATE TABLE mastering_config (key TEXT PRIMARY KEY, value TEXT);
-- reference_path, target_lufs, limiter_ceiling, eq_match_enabled,
-- stereo_width_target, auto_gain_enabled
```
Dateien: `services/mastering.py`, `services/reference_match.py`, `services/smart_mixer.py`, `services/auto_mix.py`, `audio/pitch_correction.py`, `audio/spectral_repair.py`, `audio/time_stretch.py`

### P42: Undo Command System
```sql
CREATE TABLE command_types (
    id TEXT PRIMARY KEY,                -- "note_add", "clip_move", "track_delete"
    category TEXT,                      -- "midi", "arranger", "mixer", "plugin"
    description TEXT,
    reversible INTEGER DEFAULT 1
);
```
Dateien: `commands/undo_stack.py`, `commands/midi_notes_edit.py`, `commands/project_snapshot_edit.py`

---

## KOMPLETT-INVENTAR: Alle 364 Python-Dateien → Phase-Zuordnung

| Verzeichnis | Dateien | Phasen |
|-------------|---------|--------|
| `pydaw/core/` | 4 | P6, P21 |
| `pydaw/model/` | 5 | P5, P11, P13, P32 |
| `pydaw/fileio/` | 10 | P5, P35 |
| `pydaw/commands/` | 4 | P14, P42 |
| `pydaw/music/` | 10 | P15, P34 |
| `pydaw/tools/` | 5 | Testing/Dev |
| `pydaw/utils/` | 3 | Infrastruktur |
| `pydaw/audio/` | 54 | P4, P7, P15, P21, P28-P30, P35 |
| `pydaw/plugins/` | 36 | P1, P3, P28, P29 |
| `pydaw/plugin_workers/` | 5 | P28, P36 |
| `pydaw/services/` | 73 | P1-P8, P13-P18, P21-P27, P34, P36, P38-P41 |
| `pydaw/ui/` | 112 | P2, P6, P9, P10, P12, P19-P20, P26, P29, P31-P33, P37 |
| `pydaw/notation/` | 43 | P15, P33 |
| **TOTAL** | **364** | **42 Phasen** |

Jede einzelne .py Datei ist einer Phase zugeordnet. Keine Lücken. 120% Abdeckung.
