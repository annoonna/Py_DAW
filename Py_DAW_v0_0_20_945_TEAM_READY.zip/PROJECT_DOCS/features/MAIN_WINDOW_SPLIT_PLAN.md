# main_window.py Splitting Plan

**Version:** v0.0.20.814
**Status:** PLAN — Ausführung braucht manuelle GUI-Tests auf echter Hardware
**Warum nicht automatisch:** 8489 Zeilen mit 187 Methoden, jede Änderung kann
die gesamte DAW-GUI kaputt machen. Sicheres Splitting erfordert GUI-Test nach
jedem Schritt.

---

## Analyse: Aktuelle Struktur

| Block | Zeilen | Methoden | Risiko |
|-------|--------|----------|--------|
| `__init__` | 352 | 1 | 🔴 HOCH |
| `_build_menus` | 236 | 1 | 🟡 MITTEL |
| `_build_layout` | 626 | 3 | 🟡 MITTEL |
| `_build_bottom_view_tabs` | 132 | 2 | 🟢 NIEDRIG |
| SmartDrop (gesamt) | 2710 | 12 | 🟢 NIEDRIG (self-contained) |
| `_apply_chrono_theme` | 145 | 1 | 🟢 NIEDRIG (pure CSS string) |
| Screen Layout | 248 | 8 | 🟡 MITTEL |
| Transport/Loop/Punch | 280 | 15 | 🔴 HOCH (viele Cross-Refs) |
| Recording | 200 | 6 | 🔴 HOCH |
| Plugin/Sandbox | 200 | 10 | 🟡 MITTEL |
| Project Tabs | 519 | 18 | 🟡 MITTEL |
| Import/Export | 350 | 8 | 🟡 MITTEL |
| Sonstiges | ~2691 | ~100 | 🔴 HOCH |

---

## Empfohlene Reihenfolge (sicher → riskant)

### Schritt 1: SmartDrop Mixin (🟢 SICHER, ~2710 Zeilen)
```python
# NEU: pydaw/ui/main_window_smartdrop.py
class SmartDropMixin:
    '''SmartDrop drag-and-drop handlers — extracted from MainWindow.'''
    
    def _build_smartdrop_audio_to_instrument_morph_plan(self, ...): ...
    def _show_smartdrop_morph_guard_dialog(self, ...): ...
    def _migrate_automation_for_device_move(self, ...): ...
    def _smartdrop_remove_from_source(self, ...): ...
    def _on_arranger_smartdrop_instrument_morph_guard(self, ...): ...
    def _on_arranger_smartdrop_instrument_to_track(self, ...): ...
    def _on_arranger_smartdrop_fx_to_track(self, ...): ...
    def _on_arranger_smartdrop_new_instrument_track(self, ...): ...

# main_window.py:
from pydaw.ui.main_window_smartdrop import SmartDropMixin

class MainWindow(SmartDropMixin, QMainWindow):
    ...
    # SmartDrop methods removed from here
```
**Warum sicher:** SmartDrop-Methoden referenzieren nur `self._services`, 
`self._project`, `self._arranger` — alles über `self` erreichbar. 
Keine lokalen Variablen-Abhängigkeiten.

### Schritt 2: Theme CSS (🟢 SICHER, ~145 Zeilen)
```python
# NEU: pydaw/ui/chrono_theme_css.py
CHRONO_THEME_CSS = '''...'''

# main_window.py:
from pydaw.ui.chrono_theme_css import CHRONO_THEME_CSS
def _apply_chrono_theme(self):
    self.setStyleSheet(CHRONO_THEME_CSS)
```
**Warum sicher:** Nur ein String-Literal wird ausgelagert.

### Schritt 3: Project Tabs Mixin (🟡 MITTEL, ~519 Zeilen)
```python
# NEU: pydaw/ui/main_window_tabs.py
class ProjectTabsMixin:
    def _on_project_tab_switch(self, idx): ...
    def _on_tab_next(self): ...
    def _on_tab_prev(self): ...
    def _on_project_tab_new(self): ...
    def _on_project_tab_open(self): ...
    def _on_project_tab_close(self, idx): ...
    def _on_project_tab_save(self, idx): ...
    def _on_project_tab_save_as(self, idx): ...
    def _on_project_browser_open(self, path_str): ...
    def _on_project_browser_import(self, path_str): ...
```

### Schritt 4: Import/Export (🟡 MITTEL, ~350 Zeilen)
```python
# NEU: pydaw/ui/main_window_io.py
class ImportExportMixin:
    def _export_dawproject(self): ...
    def _import_dawproject(self): ...
    def _export_audio_placeholder(self): ...
    def _export_midi_clip(self): ...
    def _export_midi_track(self): ...
    def _import_audio(self): ...
    def _import_midi(self): ...
```

### Schritt 5: Screen Layout (🟡 MITTEL, ~248 Zeilen)
```python
# NEU: pydaw/ui/main_window_screen_layout.py
class ScreenLayoutMixin:
    def _init_screen_layout_manager(self): ...
    def _populate_screen_layout_menu(self): ...
    def _apply_screen_layout(self, preset_key): ...
    def _toggle_panel_detach(self, panel_id): ...
    def _dock_all_panels(self): ...
```

---

## Erwartete Ergebnisse

| Datei | Vorher | Nachher |
|-------|--------|---------|
| main_window.py | 8489 | ~4517 |
| main_window_smartdrop.py | — | ~2710 |
| main_window_tabs.py | — | ~519 |
| main_window_io.py | — | ~350 |
| main_window_screen_layout.py | — | ~248 |
| chrono_theme_css.py | — | ~145 |

---

## Testplan (PFLICHT nach jedem Schritt)

Nach jeder Extraktion MUSS getestet werden:
1. `python3 main.py` → DAW startet ohne Fehler
2. Neues Projekt erstellen → funktioniert
3. Track hinzufügen → funktioniert
4. Instrument laden → funktioniert
5. Noten in Piano Roll → funktioniert
6. Play/Stop → funktioniert
7. Drag & Drop im Arranger → funktioniert (SmartDrop!)
8. Export → funktioniert
9. Projekt speichern/laden → funktioniert
10. Multi-Tab → funktioniert

**Ohne diese Tests: NICHT ausführen.**

---

## Wann ausführen?

Dieses Splitting sollte von Anno persönlich oder einem Kollegen mit 
Zugang zur echten DAW-GUI durchgeführt werden. Schritt 1 (SmartDrop) 
und Schritt 2 (Theme CSS) sind am sichersten und können als erstes 
versucht werden.

Die Mixin-Pattern-Extraktion ist syntaktisch einfach:
1. Methoden in neue Datei kopieren (in Mixin-Klasse)
2. Methoden aus main_window.py löschen
3. Mixin-Import + Inheritance hinzufügen
4. Testen

Jeder Schritt ist einzeln revertierbar.
