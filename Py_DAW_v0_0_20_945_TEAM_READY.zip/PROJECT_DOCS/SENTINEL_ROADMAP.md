# 🛡️ Py_DAW SENTINEL — Self-Healing Diagnostics Engine — Roadmap

**Projekt:** Py_DAW (ChronoScaleStudio)
**Feature:** SENTINEL — KI-gestützte Echtzeit-Überwachung & Bug-Hunting
**Erstellt:** 2026-03-31 (v0.0.20.903)
**Autor:** Anno (Konzept) + Claude Opus 4.6 (Architektur)

---

## ⚠️ OBERSTE DIREKTIVE — FÜR ALLE KOLLEGEN

```
🔴 DU DARFST NICHTS KAPUTT MACHEN. DAS IST DIE OBERSTE DIREKTIVE.
🔴 Alle bestehenden Features müssen nach deiner Arbeit funktionieren.
🔴 SENTINEL ist ein REINES ADD-ON — kein bestehendes System umbauen.
🔴 Teste IMMER mit: python3 -c "import py_compile; ..."
```

---

## 🛡️ DESIGN-PRINZIP #1 — NIEMALS FALSE POSITIVES

```
🟥 SENTINEL DARF NIE EIGENSTÄNDIG TRACKS STUMM SCHALTEN ODER DEAKTIVIEREN.
🟥 SENTINEL DARF NIE AUDIO UNTERBRECHEN OHNE EXPLIZITE USER-BESTÄTIGUNG.
🟥 SENTINEL DARF NIE DATEN LÖSCHEN, ÜBERSCHREIBEN ODER VERÄNDERN.
🟥 EIN FALSE POSITIVE DER DEN BASS MITTEN IM LIVE-SET KILLT
🟥 IST SCHLIMMER ALS JEDER BUG. LIEBER WARNEN ALS HANDELN.
```

### Stufenmodell (5 Stufen — nur Stufe 5 greift automatisch ein)

| Stufe | Schwere | SENTINEL Aktion | User-Eingriff nötig? |
|-------|---------|-----------------|---------------------|
| 1 — INFO | Auffälligkeit erkannt | Loggt intern, kein UI | Nein |
| 2 — HINWEIS | Muster erkannt | Kleines Icon in Status-Bar (gelb) | Nein |
| 3 — WARNUNG | Problem wahrscheinlich | Gelbes Banner + Ton + Detail-Panel | Nein |
| 4 — ALARM | Problem bestätigt | Rotes Banner + Vorschlag ("Track isolieren?") | **JA — User muss klicken** |
| 5 — NOTFALL | Plugin/Thread antwortet >5s nicht, Crash unmittelbar | Auto-Isolierung + SOFORT rückgängig machbar | Auto, aber 1-Klick-Undo |

### Sicherheitsregeln für Stufe 5 (Auto-Isolierung)

```
1. NUR bei bewiesenem Ausfall (Plugin antwortet >5s nicht,
   Segfault-Signal empfangen, Thread-Deadlock bestätigt)
2. NIEMALS bei Vermutungen, Heuristiken oder Anomalie-Scores
3. Track wird NUR isoliert (Audio-Output getrennt), NICHT gelöscht
4. Isolierung ist SOFORT mit einem Klick rückgängig machbar
   (wie Sicherungskasten: springt raus, drückst ihn rein)
5. JEDE Auto-Aktion wird geloggt + User wird benachrichtigt
6. User kann Auto-Isolierung komplett deaktivieren (Settings)
7. Im Live-Performance-Modus: KEINE Auto-Isolierung, nur Warnung
```

### Schutz vor False Positives

```
SENTINEL arbeitet mit BESTÄTIGTEM Beweis, nicht mit Vermutung.
- Anomalie-Score allein → maximal Stufe 3 (Warnung)
- CPU-Spike allein → maximal Stufe 2 (Hinweis) — kann legit sein
- Memory-Anstieg allein → maximal Stufe 2 — kann großes Sample sein
- Plugin-Timeout < 2s → Stufe 2 (kann bei komplexen Presets normal sein)
- Plugin-Timeout > 5s → Stufe 4 (Vorschlag), User entscheidet
- Plugin-Timeout > 10s ODER Segfault → Stufe 5 (Auto-Isolierung)
- Echo-Loop erkannt (>50 Messages/s gleicher Typ) → Stufe 5
  (Echo-Loop kann NICHT False Positive sein — 50 gleiche Messages
  in 1 Sekunde ist immer ein Bug, nie legitim)
```

---

## 🧠 VISION — Was es so noch nie gab

### Das Problem (jede DAW hat es)
- Plugin crasht → ganze Session weg, keine Ahnung warum
- Ableton zeigt "Ableton has crashed" — das war's
- Bitwig hat Sandbox (gut!) aber null Diagnose
- Kein DAW VERSTEHT warum etwas schiefgelaufen ist
- Kein DAW WARNT dich bevor es passiert
- Kein DAW LERNT aus vergangenen Crashes

### SENTINEL macht Py_DAW zur ERSTEN DAW die:
1. **Versteht** warum etwas crasht (Blackbox-Analyse)
2. **Warnt** bevor es crasht (Anomalie-Erkennung)
3. **Sich selbst heilt** wo sicher möglich (Echo-Loop-Breaker)
4. **Lernt** aus vergangenen Problemen (Pattern-DB)
5. **Kommuniziert** strukturiert mit KI-Assistenten (API)

### Feature-Matrix — Was niemand sonst hat

```
Feature                        Ableton  Bitwig  Cubase  Py_DAW+SENTINEL
──────────────────────────────────────────────────────────────────────────
Crash Log                        ✅      ✅      ✅      ✅
Plugin Sandbox                   ❌      ✅      ❌      ✅ (haben wir)
Flight Recorder (Blackbox)       ❌      ❌      ❌      ✅ NEU
Anomalie-Erkennung               ❌      ❌      ❌      ✅ NEU
Echo-Loop Auto-Breaker           ❌      ❌      ❌      ✅ NEU
Präventive Warnung               ❌      ❌      ❌      ✅ NEU
Pattern Learning (aus History)   ❌      ❌      ❌      ✅ NEU
Strukturierte Crash-API          ❌      ❌      ❌      ✅ NEU
KI-Analyse per API               ❌      ❌      ❌      ✅ NEU
Self-Healing (mit Safeguards)    ❌      ❌*     ❌      ✅ NEU
Health Dashboard                 ❌      ❌      ❌      ✅ NEU

* Bitwig restartet gecrashe Plugins, aber ohne Diagnose/Prävention
```

---

## 🏗️ ARCHITEKTUR

```
┌─────────────────────────────────────────────────────────────┐
│  Qt6 GUI                                                      │
│  ┌───────────────┐ ┌──────────────┐ ┌────────────────────┐  │
│  │ Health         │ │ Anomaly      │ │ Crash Report       │  │
│  │ Dashboard      │ │ Banner/Alerts│ │ Viewer             │  │
│  │ (CPU/Mem/Disk) │ │ (Stufe 2-4) │ │ (Blackbox Replay)  │  │
│  └───────┬────────┘ └──────┬───────┘ └─────────┬──────────┘  │
│          │                 │                   │              │
│  ┌───────▼─────────────────▼───────────────────▼──────────┐  │
│  │ SENTINEL Service (Python)                                │  │
│  │                                                          │  │
│  │ ┌──────────────┐ ┌────────────────┐ ┌────────────────┐  │  │
│  │ │ Flight       │ │ Anomaly        │ │ Self-Healing    │  │  │
│  │ │ Recorder     │ │ Detector       │ │ Engine          │  │  │
│  │ │ (Blackbox)   │ │ (Pattern Match)│ │ (Echo-Breaker)  │  │  │
│  │ └──────┬───────┘ └───────┬────────┘ └───────┬────────┘  │  │
│  │        │                 │                   │            │  │
│  │ ┌──────▼─────────────────▼───────────────────▼────────┐  │  │
│  │ │ SENTINEL DB (SQLite)                                 │  │  │
│  │ │ - sentinel_events (Flight Recorder Ringbuffer)       │  │  │
│  │ │ - sentinel_anomalies (erkannte Anomalien)            │  │  │
│  │ │ - sentinel_crashes (Crash-Reports + Blackbox)        │  │  │
│  │ │ - sentinel_patterns (gelerntes Wissen)               │  │  │
│  │ │ - sentinel_actions (was SENTINEL getan hat + Undo)   │  │  │
│  │ └─────────────────────────────────────────────────────┘  │  │
│  │                                                          │  │
│  │ ┌────────────────────────────────────────────────────┐   │  │
│  │ │ SENTINEL API (lokaler HTTP Server, Port 9750)      │   │  │
│  │ │ GET  /sentinel/health     → System-Status           │   │  │
│  │ │ GET  /sentinel/crashes    → Crash-Reports (JSON)    │   │  │
│  │ │ GET  /sentinel/anomalies  → Aktive Anomalien        │   │  │
│  │ │ GET  /sentinel/blackbox   → Letzte 60s Ringbuffer   │   │  │
│  │ │ POST /sentinel/analyze    → KI-Analyse anfordern    │   │  │
│  │ │ GET  /sentinel/patterns   → Gelernte Crash-Muster   │   │  │
│  │ │ POST /sentinel/heal       → Self-Healing triggern   │   │  │
│  │ └────────────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📋 PHASEN-PLAN

### Abhängigkeiten

```
S1 (DB Schema) → S2 (Flight Recorder) → S3 (Anomaly Detector) → S4 (Health UI)
S2 → S5 (Crash Analyzer)
S3 → S6 (Self-Healing) → S7 (Echo-Loop Breaker)
S5 → S8 (Pattern Learning)
S2 + S5 → S9 (API Server) → S10 (KI-Anbindung)
S4 → S11 (Health Dashboard)
S6 → S12 (Live-Mode Safeguards)
```

### Empfohlene Reihenfolge

```
S1 → S2 → S3 → S4 → S5 → S6 → S7  (Kern, ~10-12 Sessions)
S8 → S9 → S10                       (API + KI, ~5-6 Sessions)
S11 → S12                           (Dashboard + Live, ~3-4 Sessions)
```

---

## 🔧 PHASE S1: SENTINEL Database Schema

**Priorität:** 🔴 KRITISCH — Fundament
**Aufwand:** 1 Session
**Datei:** `pydaw/services/sentinel_db.py`

### Tabellen

- [x] `sentinel_events`  *(v0.0.20.904)* — Flight Recorder Ringbuffer (letzte 60s)
  ```sql
  CREATE TABLE sentinel_events (
      id            INTEGER PRIMARY KEY,
      timestamp     REAL NOT NULL,           -- time.time()
      category      TEXT NOT NULL,            -- 'cpu','memory','thread','plugin',
                                              -- 'signal','collab','audio','error'
      severity      INTEGER NOT NULL DEFAULT 1, -- 1=info, 2=hinweis, 3=warn, 4=alarm, 5=notfall
      source        TEXT NOT NULL DEFAULT '', -- 'track:trk_xxx', 'plugin:surge-xt', 'thread:audio'
      metric_name   TEXT NOT NULL DEFAULT '', -- 'cpu_percent', 'rss_mb', 'latency_ms'
      metric_value  REAL,
      message       TEXT DEFAULT '',
      context_json  TEXT DEFAULT '{}'         -- zusätzliche Daten
  );
  CREATE INDEX idx_se_time ON sentinel_events(timestamp);
  CREATE INDEX idx_se_severity ON sentinel_events(severity, timestamp);
  CREATE INDEX idx_se_source ON sentinel_events(source, timestamp);
  ```

- [x] `sentinel_anomalies`  *(v0.0.20.904)* — Erkannte Anomalien
  ```sql
  CREATE TABLE sentinel_anomalies (
      id            INTEGER PRIMARY KEY,
      detected_at   REAL NOT NULL,
      resolved_at   REAL DEFAULT 0,          -- 0 = noch aktiv
      anomaly_type  TEXT NOT NULL,            -- 'echo_loop', 'cpu_spike', 'memory_leak',
                                              -- 'thread_deadlock', 'plugin_timeout',
                                              -- 'signal_feedback', 'crash_pattern'
      severity      INTEGER NOT NULL DEFAULT 2,
      source        TEXT NOT NULL DEFAULT '',
      description   TEXT NOT NULL DEFAULT '',
      evidence_json TEXT DEFAULT '{}',        -- Beweise (Metriken, Timestamps)
      action_taken  TEXT DEFAULT '',           -- was SENTINEL getan hat (oder 'none')
      user_response TEXT DEFAULT '',           -- 'acknowledged', 'ignored', 'fixed'
      false_positive INTEGER DEFAULT 0        -- 1 = User hat als False Positive markiert
  );
  ```

- [x] `sentinel_crashes`  *(v0.0.20.904)* — Crash-Reports mit Blackbox-Daten
  ```sql
  CREATE TABLE sentinel_crashes (
      id            INTEGER PRIMARY KEY,
      crash_time    REAL NOT NULL,
      session_id    TEXT NOT NULL DEFAULT '',
      crash_type    TEXT NOT NULL,            -- 'segfault', 'exception', 'deadlock',
                                              -- 'oom', 'plugin_crash', 'timeout'
      component     TEXT NOT NULL DEFAULT '', -- 'plugin:surge-xt', 'engine', 'ui', 'collab'
      error_message TEXT DEFAULT '',
      traceback     TEXT DEFAULT '',
      blackbox_json TEXT DEFAULT '{}',        -- letzte 60s Metriken als JSON
      system_state  TEXT DEFAULT '{}',        -- CPU, RAM, Disk, Audio-Buffer-Status
      track_state   TEXT DEFAULT '{}',        -- welche Tracks, Plugins, FX aktiv
      resolved      INTEGER DEFAULT 0,
      resolution    TEXT DEFAULT ''           -- wie wurde es gelöst
  );
  ```

- [x] `sentinel_patterns`  *(v0.0.20.904)* — Gelerntes Wissen aus vergangenen Crashes
  ```sql
  CREATE TABLE sentinel_patterns (
      id            INTEGER PRIMARY KEY,
      pattern_type  TEXT NOT NULL,            -- 'crash_precursor', 'resource_hog',
                                              -- 'incompatible_combo', 'echo_loop_trigger'
      description   TEXT NOT NULL,
      conditions_json TEXT NOT NULL,          -- wann tritt es auf (JSON-Regeln)
      confidence    REAL DEFAULT 0.5,         -- 0..1 wie sicher sind wir
      occurrences   INTEGER DEFAULT 1,        -- wie oft beobachtet
      last_seen     REAL NOT NULL,
      prevention    TEXT DEFAULT '',           -- Empfehlung zur Vermeidung
      auto_action   TEXT DEFAULT 'warn'       -- 'warn' | 'suggest' | 'none'
                                              -- NIEMALS 'auto_mute' oder 'auto_disable'!
  );
  ```

- [x] `sentinel_actions`  *(v0.0.20.904)* — Was SENTINEL getan hat (Audit-Log + Undo)
  ```sql
  CREATE TABLE sentinel_actions (
      id            INTEGER PRIMARY KEY,
      action_time   REAL NOT NULL,
      action_type   TEXT NOT NULL,            -- 'warned', 'suggested', 'isolated',
                                              -- 'broke_loop', 'restarted_worker'
      target        TEXT NOT NULL DEFAULT '', -- was betroffen war
      reason        TEXT DEFAULT '',           -- warum
      severity      INTEGER DEFAULT 3,
      undone        INTEGER DEFAULT 0,        -- 1 = User hat rückgängig gemacht
      undone_at     REAL DEFAULT 0,
      auto_action   INTEGER DEFAULT 0         -- 1 = automatisch, 0 = user-bestätigt
  );
  ```

- [x] `SentinelDB`  *(v0.0.20.904)* Service — Singleton mit ensure_loaded(), WAL mode
- [x] Compile-Test + Doku  *(v0.0.20.904)*

---

## 🔧 PHASE S2: Flight Recorder (Blackbox)

**Priorität:** 🔴 KRITISCH
**Aufwand:** 2 Sessions
**Datei:** `pydaw/services/sentinel_recorder.py`

### Was wird aufgezeichnet (Ringbuffer, letzte 60 Sekunden)

- [x] **CPU-Metriken**  *(v0.0.20.904)* (alle 500ms):
  - Gesamt-CPU%
  - Pro-Track CPU-Anteil (geschätzt via Render-Time)
  - Pro-Plugin CPU-Anteil (wenn Sandbox aktiv)
  - Audio-Thread CPU vs. GUI-Thread CPU

- [x] **Memory-Metriken**  *(v0.0.20.904)* (alle 2s):
  - RSS (Resident Set Size) in MB
  - Delta zum letzten Messwert (für Leak-Detection)
  - Pro-Plugin Memory (wenn messbar)
  - GC-Statistiken (Python Garbage Collector)

- [x] **Audio-Metriken**  *(v0.0.20.904)* (alle 500ms):
  - Buffer-Underrun Counter (XRuns)
  - Aktuelle Latenz (ms)
  - Sample-Rate Mismatch Detection
  - PipeWire/JACK Connection Status

- [x] **Thread-Metriken**  *(v0.0.20.904)* (alle 1s):
  - Aktive Thread-Count
  - Thread-States (Running/Waiting/Blocked)
  - Deadlock-Detection (Thread wartet >3s auf Lock)
  - Plugin-Worker Health (Heartbeat)

- [x] **Plugin-Metriken**  *(v0.0.20.904)* (alle 1s):
  - Plugin-Load-Zeiten
  - Plugin-Process-Zeiten pro Audio-Buffer
  - Plugin-Error-Counter
  - Plugin-Restart-Counter (Sandbox)

- [x] **Signal-Metriken**  *(v0.0.20.904)* (alle 500ms):
  - Collab-Message-Rate (Messages/Sekunde pro Typ)
  - Qt Signal-Queue-Depth (wenn messbar)
  - WebSocket Latenz (Collab)

### Ringbuffer-Design

- [x] Feste Größe: 120  *(v0.0.20.905)* Einträge × 6 Kategorien = ~720 Datenpunkte
- [x] Älteste Einträge  *(v0.0.20.905)* werden überschrieben (kein DB-Wachstum)
- [x] Bei Crash  *(v0.0.20.904)*: Kompletter Buffer wird als JSON in sentinel_crashes gespeichert
- [x] Performance-Budget  *(v0.0.20.904)*: < 1% CPU für alle Messungen zusammen

---

## 🔧 PHASE S3: Anomaly Detector

**Priorität:** 🔴 KRITISCH
**Aufwand:** 2-3 Sessions
**Datei:** `pydaw/services/sentinel_anomaly.py`

### Erkennbare Anomalien

- [x] **Echo-Loop Detection**  *(v0.0.20.904)* (STUFE 5 bei >50 msg/s):
  - Zählt Messages pro Typ pro Sekunde
  - >50 gleiche Messages in 1 Sekunde = GARANTIERT ein Bug
  - Schwelle konfigurierbar (Default: 50/s)
  - Erkennt: Collab-Loops, Signal-Loops, Event-Floods

- [x] **CPU Spike Detection**  *(v0.0.20.904)* (STUFE 2-3):
  - Baseline: gleitender Durchschnitt über 30s
  - Spike: >200% der Baseline für >3s
  - Stufe 2 bei einmaligem Spike
  - Stufe 3 bei wiederholten Spikes (>3 in 60s)
  - NICHT Stufe 4/5 — CPU-Spikes können normal sein (großes Preset laden)

- [x] **Memory Leak Detection**  *(v0.0.20.904)* (STUFE 2-3):
  - Monotoner Anstieg >5 MB/Minute über >5 Minuten
  - Stufe 2 bei <50 MB Gesamtwachstum
  - Stufe 3 bei >50 MB oder >30 Minuten Wachstum
  - NICHT Stufe 4/5 — kann großes Sampleladen sein

- [x] **Plugin Timeout Detection**  *(v0.0.20.904)* (STUFE 2-5):
  - Plugin antwortet nicht auf Audio-Callback
  - <2s → Stufe 2 (kann beim Preset-Laden normal sein)
  - 2-5s → Stufe 3 (Warnung)
  - 5-10s → Stufe 4 (Vorschlag: "Plugin isolieren?")
  - >10s → Stufe 5 (Auto-Isolierung, sofort rückgängig machbar)

- [x] **Thread Deadlock Detection**  *(v0.0.20.904)* (STUFE 4-5):
  - Thread blockiert >5s auf einem Lock
  - Stufe 4: Warnung + "Welche Threads betroffen?"
  - Stufe 5 nur bei Audio-Thread (GUI darf blockieren, Audio nicht)

- [x] **Signal Feedback Detection**  *(v0.0.20.904)* (STUFE 3-5):
  - Audio-Output eines Tracks wird in seinen eigenen Input geroutet
  - Feedback-Schleife erkannt via Routing-Graph-Analyse
  - Stufe 3: Warnung "Feedback-Schleife erkannt auf Track X"
  - Stufe 5 nur bei gemessenem Pegelanstieg >+20dB in <1s

- [x] **Disk Space Warning**  *(v0.0.20.904)* (STUFE 2-3):
  - Projektverzeichnis Disk <500 MB frei → Stufe 2
  - <100 MB frei → Stufe 3
  - Warnung im Status-Bar

### False-Positive-Schutz

- [x] **Bestätigungs-Mechanismus**  *(v0.0.20.905)*:
  - Jede Anomalie hat eine `confidence` (0..1)
  - confidence < 0.7 → maximal Stufe 2
  - confidence < 0.9 → maximal Stufe 3
  - confidence >= 0.95 → Stufe 4 möglich
  - confidence == 1.0 (mathematisch bewiesen) → Stufe 5 möglich
  - BEISPIEL: Echo-Loop >50 msg/s hat confidence=1.0
  - BEISPIEL: CPU-Spike hat confidence=0.6 (kann normal sein)

- [x] **User Feedback Loop**  *(v0.0.20.904)*:
  - User kann jede Anomalie als "False Positive" markieren
  - Nach 3× False Positive für gleichen Typ → Schwelle anheben
  - Pattern wird in sentinel_patterns gespeichert
  - SENTINEL lernt: "Bei diesem Plugin sind CPU-Spikes normal"

---

## 🔧 PHASE S4: Health UI (Status-Widgets)

**Priorität:** 🟠 HOCH
**Aufwand:** 2 Sessions
**Datei:** `pydaw/ui/sentinel_widgets.py`

### Status-Bar Integration

- [x] **Health-Indikator**  *(v0.0.20.904)* in der Status-Bar (permanent sichtbar):
  - Grünes Herz 💚 = alles OK
  - Gelbes Herz 💛 = Hinweis/Warnung vorhanden
  - Rotes Herz ❤️ = Problem erkannt
  - Klick → öffnet SENTINEL Dashboard

- [x] **Alert-Banner**  *(v0.0.20.904)* (nur bei Stufe 3+):
  - Gelbes Banner am oberen Fensterrand bei Stufe 3
  - Rotes Banner bei Stufe 4-5
  - Text: "⚠️ [Problem-Beschreibung] — Details | Ignorieren"
  - Banner verschwindet nach Klick auf "Ignorieren" oder nach Lösung
  - NICHT modal — blockiert NICHT die DAW-Nutzung

- [x] **Track Health Icons**  *(v0.0.20.904)*:
  - Kleines Icon neben Track-Name im Mixer + Arranger
  - Grün = OK, Gelb = Hinweis, Rot = Problem
  - Tooltip zeigt Details ("CPU 45%, Memory +12 MB, 2 XRuns")

### Benachrichtigungs-Sound

- [x] Dezenter  *(v0.0.20.904)* Benachrichtigungston bei Stufe 3+ (optional, abschaltbar)
- [x] KEIN Alarm  *(v0.0.20.904)*-Sound bei Stufe 1-2 (nur visuell)

---

## 🔧 PHASE S5: Crash Analyzer

**Priorität:** 🟠 HOCH
**Aufwand:** 2 Sessions
**Datei:** `pydaw/services/sentinel_crash_analyzer.py`

### Crash-Report Generierung

- [x] **Automatischer Crash-Report**  *(v0.0.20.904)* bei jedem Crash/Exception:
  - Python Traceback (vollständig)
  - Flight Recorder Daten (letzte 60s Blackbox)
  - System-State: CPU, RAM, Disk, Audio-Config
  - Track-State: welche Tracks, Plugins, FX, Instrument-State
  - Collab-State: verbunden? wer? letzte 10 Messages
  - Session-ID + Timestamp + Version

- [x] **Crash-Klassifizierung**  *(v0.0.20.904)*:
  - `segfault` → Plugin-Crash (extern)
  - `exception` → Python-Bug (intern)
  - `deadlock` → Thread-Problem
  - `oom` → Out of Memory
  - `plugin_crash` → Plugin-Worker gestorben
  - `timeout` → Plugin/Thread antwortet nicht

- [x] **Crash-Viewer**  *(v0.0.20.904)* im SENTINEL Dashboard:
  - Liste aller vergangenen Crashes
  - Klick → Details mit Blackbox-Replay
  - "Ähnliche Crashes" Verknüpfung (gleiche Komponente)
  - Export als JSON/Markdown (für Bug-Reports)

### Signal-Handler

- [x] `SIGSEGV`  *(v0.0.20.904)* / `SIGABRT` Handler:
  - Fängt Segfaults ab BEVOR der Prozess stirbt
  - Schreibt Notfall-Crash-Report in sentinel_crashes
  - Speichert Projekt-State als Emergency-Backup
  - DANACH erst crash (oder graceful restart versuch)

---

## 🔧 PHASE S6: Self-Healing Engine

**Priorität:** 🟡 MITTEL
**Aufwand:** 2-3 Sessions
**Datei:** `pydaw/services/sentinel_healer.py`

### Heilungsstrategien (nach Stufe)

- [x] **Stufe 1-3: Nur  *(v0.0.20.904)* beobachten und warnen** — kein Eingriff

- [x] **Stufe 4: Vorschläge machen**  *(v0.0.20.905)* (User muss bestätigen):
  - "Track 3 (Surge XT) verbraucht 67% CPU — stumm schalten?"
  - "Plugin XY antwortet seit 7s nicht — Worker neustarten?"
  - "Collab-Verbindung instabil — erneut verbinden?"
  - Dialog mit "Ja" / "Nein" / "Ignorieren" / "Nie wieder fragen"

- [x] **Stufe 5: Auto-Isolierung**  *(v0.0.20.904)* (nur bei bewiesenem Ausfall):
  - Track-Isolierung: Audio-Output wird getrennt, Track bleibt sichtbar
  - Plugin-Worker-Restart: Sandbox-Worker wird neu gestartet
  - Echo-Loop-Break: Message-Flood wird unterbrochen (Cooldown)
  - JEDE Aktion wird in sentinel_actions geloggt
  - JEDE Aktion hat einen sofortigen Undo-Button im Banner

- [x] **Undo-Mechanismus  *(v0.0.20.904)* für Auto-Aktionen**:
  - Banner: "🛡️ SENTINEL hat Track 3 isoliert (Plugin-Timeout) — [Rückgängig] [Details]"
  - Klick auf "Rückgängig" → Track sofort wieder aktiv
  - sentinel_actions.undone = 1 wird gesetzt
  - Wenn User 3× Undo macht für gleichen Typ → Auto-Aktion wird deaktiviert

---

## 🔧 PHASE S7: Echo-Loop Breaker

**Priorität:** 🟡 MITTEL — Hätte den v900 Bug in 2 Sekunden gestoppt
**Aufwand:** 1-2 Sessions
**Datei:** In `sentinel_anomaly.py` + `sentinel_healer.py`

### Konzept

Der Echo-Loop-Breaker ist ein spezialisierter Anomalie-Detektor der
GENAU das Problem löst das wir in v0.0.20.900 hatten:

- [x] **Message-Rate-Limiter**  *(v0.0.20.904)* (generisch):
  - Zählt Messages pro (op_type, source) pro Sekunde
  - >50/s für gleichen Typ → ALARM (confidence=1.0)
  - Auto-Break: Cooldown von 5s auf den betroffenen op_type
  - Betrifft: Collab-Messages, Qt-Signals, Timer-Callbacks

- [x] **Collab-spezifischer  *(v0.0.20.904)* Loop-Breaker**:
  - Hook in collab_panel.py → _send_collab_op()
  - Zählt gesendete ops pro Typ pro Sekunde
  - >20 gleiche ops in 5 Sekunden → BREAK + Warnung
  - Automatischer Cooldown: 5 Sekunden für den betroffenen Typ
  - Log: "🛡️ SENTINEL: Echo-Loop unterbrochen (device_sync 47/s)"

- [x] **Signal-Loop-Breaker**  *(v0.0.20.904)*:
  - Erkennt wenn ein Qt-Signal sein eigenes emit() auslöst
  - Rekursions-Depth-Counter pro Signal
  - >10 rekursive Calls → BREAK + Warnung
  - Protection: Signal wird für 1s deaktiviert

---

## 🔧 PHASE S8: Pattern Learning

**Priorität:** 🟢 NORMAL
**Aufwand:** 2-3 Sessions
**Datei:** `pydaw/services/sentinel_patterns.py`

### Lern-Mechanismus

- [x] **Crash-Precursor-Analyse**  *(v0.0.20.905)*:
  - Nach jedem Crash: analysiere die Blackbox-Daten
  - Finde Muster in den letzten 60s VOR dem Crash
  - "Immer wenn CPU >80% UND Surge XT geladen UND >8 Voices → Crash"
  - Muster mit confidence speichern
  - Confidence steigt mit jedem weiteren Beweis

- [x] **Pattern-Matching in Echtzeit**  *(v0.0.20.905)*:
  - Vergleiche aktuellen State mit bekannten Crash-Mustern
  - Wenn ein Pattern matched → Warnung (Stufe 3)
  - "⚠️ Diese Konfiguration hat in 3 von 4 Fällen zu einem Crash geführt"
  - User entscheidet ob er weitermacht

- [x] **False-Positive-Learning**  *(v0.0.20.905)*:
  - User markiert Warnung als False Positive
  - Pattern-Confidence wird reduziert
  - Nach 3× False Positive → Pattern wird deaktiviert
  - Gespeichert in sentinel_patterns

- [x] **Export/Import von Patterns**  *(v0.0.20.905)*:
  - Patterns können als JSON exportiert werden
  - Community kann Patterns teilen ("Surge XT + PipeWire Quirks")
  - Import mit User-Bestätigung

---

## 🔧 PHASE S9: SENTINEL API Server

**Priorität:** 🟡 MITTEL — Das Tor zur KI-Anbindung
**Aufwand:** 2 Sessions
**Datei:** `pydaw/services/sentinel_api.py`

### HTTP API (lokaler Server, Port 9750)

- [x] `GET /sentinel/health`  *(v0.0.20.905)* → System-Status als JSON
  ```json
  {
    "status": "healthy",      // "healthy" | "warning" | "critical"
    "cpu_percent": 35.2,
    "memory_mb": 1240,
    "xrun_count": 0,
    "active_tracks": 8,
    "active_plugins": 12,
    "collab_connected": true,
    "anomaly_count": 0,
    "uptime_seconds": 3600
  }
  ```

- [x] `GET /sentinel/crashes`  *(v0.0.20.905)* → Crash-Reports (letzte 30 Tage)
  ```json
  {
    "crashes": [
      {
        "id": 42,
        "time": "2026-03-31T11:00:07",
        "type": "echo_loop",
        "component": "collab:device_sync",
        "message": "994 device_sync messages in 20 minutes",
        "blackbox_summary": { ... },
        "resolution": "Fixed in v0.0.20.903"
      }
    ]
  }
  ```

- [x] `GET /sentinel/anomalies`  *(v0.0.20.905)* → Aktive + kürzliche Anomalien

- [x] `GET /sentinel/blackbox`  *(v0.0.20.905)* → Letzte 60s Flight Recorder Daten

- [x] `POST /sentinel/analyze`  *(v0.0.20.905)* → KI-Analyse anfordern
  - Body: `{"crash_id": 42}` oder `{"anomaly_id": 7}`
  - Response: Strukturierter Crash-Report als Markdown
  - Kann lokal analysieren ODER an externe API weiterleiten

- [x] `GET /sentinel/patterns`  *(v0.0.20.905)* → Gelernte Muster

- [x] `POST /sentinel/heal`  *(v0.0.20.905)* → Self-Healing manuell triggern
  - Body: `{"action": "restart_plugin", "target": "surge-xt"}`
  - Nur mit Bestätigung (nicht blind ausführen)

### Sicherheit

- [x] Nur localhost (127.0.0.1)  *(v0.0.20.905)* — kein Zugriff von außen
- [x] Optional: API-Key  *(v0.0.20.905)* für zusätzliche Sicherheit
- [x] Rate-Limiting: max 60  *(v0.0.20.905)* Requests/Minute
- [x] Keine sensitiven Daten  *(v0.0.20.905)* (keine Projekt-Dateipfade in der API)

---

## 🔧 PHASE S10: KI-Anbindung (Claude API Integration)

**Priorität:** 🟡 MITTEL — Das hat KEIN anderes DAW
**Aufwand:** 2-3 Sessions
**Datei:** `pydaw/services/sentinel_ai_analyzer.py`

### Konzept

SENTINEL kann Crash-Reports und Anomalien automatisch an Claude senden
und bekommt eine strukturierte Analyse zurück.

- [x] **Automatische Crash-Analyse**  *(v0.0.20.905)*:
  - Crash passiert → SENTINEL sammelt Blackbox-Daten
  - User wird gefragt: "Soll ich eine KI-Analyse anfordern?"
  - Wenn ja: Blackbox-JSON → Anthropic API → Analyse-Text
  - Analyse wird in der UI angezeigt + in DB gespeichert
  - Kein Auto-Send ohne User-Bestätigung (Datenschutz!)

- [x] **Proaktive Empfehlungen**  *(v0.0.20.905)*:
  - SENTINEL sendet anonymisierte Patterns an die API
  - Bekommt Empfehlungen: "Dieses Plugin hat bekannte Probleme mit PipeWire"
  - User sieht Empfehlung im Health Dashboard

- [x] **Fix-Vorschläge**  *(v0.0.20.905)*:
  - "Bug liegt wahrscheinlich in collab_panel.py Zeile 1798"
  - "Empfehlung: Cooldown von 3s für device_sync nach Remote-Apply"
  - Für Entwickler: strukturierte Vorschläge mit Code-Kontext

### API-Key Management

- [x] User gibt seinen Anthropic  *(v0.0.20.905)* API-Key ein (oder eigenen Endpoint)
- [x] Key wird verschlüsselt in Keyring  *(v0.0.20.905)* gespeichert (nicht in Klartext)
- [x] Ohne Key: nur lokale  *(v0.0.20.905)* Analyse (Pattern-Matching)
- [x] Mit Key: lokale + KI  *(v0.0.20.905)*-gestützte Analyse

---

## 🔧 PHASE S11: Health Dashboard

**Priorität:** 🟢 NORMAL
**Aufwand:** 2-3 Sessions
**Datei:** `pydaw/ui/sentinel_dashboard.py`

### Dashboard-Widgets

- [x] **System-Übersicht**  *(v0.0.20.905)*:
  - CPU-Graph (live, letzte 5 Minuten)
  - Memory-Graph (live)
  - XRun-Counter
  - Disk-Space-Balken
  - Audio-Buffer-Status

- [x] **Track Health Matrix**  *(v0.0.20.905)*:
  - Tabelle: Track | CPU | Memory | Plugins | Status
  - Sortierbar nach CPU/Memory
  - Farbcodierung (grün/gelb/rot)
  - Klick → Track-Details

- [x] **Anomalie-Log**  *(v0.0.20.905)*:
  - Scrollbare Liste aller erkannten Anomalien
  - Filter: Alle / Aktive / Gelöste / False Positives
  - Klick → Details + Blackbox-Daten

- [x] **Crash-History**  *(v0.0.20.905)*:
  - Timeline mit Crash-Markern
  - Klick → Crash-Report-Viewer
  - "Ähnliche Crashes" Verknüpfung

- [x] **Pattern-Übersicht**  *(v0.0.20.905)*:
  - Gelernte Muster mit Confidence-Balken
  - "Aktiviert / Deaktiviert" Toggle pro Pattern
  - "False Positive markieren" Button

---

## 🔧 PHASE S12: Live-Mode Safeguards

**Priorität:** 🟢 NORMAL
**Aufwand:** 1-2 Sessions
**Datei:** In `sentinel_healer.py`

### Live-Performance Schutz

- [x] **Live-Mode Flag**  *(v0.0.20.905)* (manuell aktivierbar):
  - Wenn aktiv: KEINE Auto-Isolierung (Stufe 5 wird zu Stufe 4)
  - Nur Warnungen + Vorschläge, NIE automatische Eingriffe
  - Grund: Im Live-Set ist ein False Positive KATASTROPHAL
  - User muss bewusst entscheiden: "Ja, mach stumm" oder "Nein, lass laufen"

- [x] **Pre-Show Check**  *(v0.0.20.905)*:
  - "Alle Systeme OK für Live-Performance?"
  - Prüft: CPU-Baseline, Plugin-Stabilität, Collab-Verbindung, Disk-Space
  - Zeigt Warnungen BEVOR der Live-Set beginnt
  - Grünes Licht: "✅ Alles bereit für Live"

- [x] **Post-Show Report**  *(v0.0.20.905)*:
  - Zusammenfassung der Session: XRuns, Anomalien, CPU-Peaks
  - "Keine Probleme während der Show" oder "3 Warnungen aufgetreten"
  - Für den Musiker: Einfache Sprache, keine Technik-Details

---

## 📊 GESAMTÜBERSICHT

| Phase | Feature | Priorität | Sessions | Abhängigkeit |
|-------|---------|-----------|----------|-------------|
| S1 | SENTINEL DB Schema | 🔴 KRITISCH | 1 | — |
| S2 | Flight Recorder | 🔴 KRITISCH | 2 | S1 |
| S3 | Anomaly Detector | 🔴 KRITISCH | 2-3 | S2 |
| S4 | Health UI | 🟠 HOCH | 2 | S3 |
| S5 | Crash Analyzer | 🟠 HOCH | 2 | S2 |
| S6 | Self-Healing | 🟡 MITTEL | 2-3 | S3 |
| S7 | Echo-Loop Breaker | 🟡 MITTEL | 1-2 | S3+S6 |
| S8 | Pattern Learning | 🟢 NORMAL | 2-3 | S5 |
| S9 | API Server | 🟡 MITTEL | 2 | S2+S5 |
| S10 | KI-Anbindung | 🟡 MITTEL | 2-3 | S9 |
| S11 | Health Dashboard | 🟢 NORMAL | 2-3 | S4 |
| S12 | Live-Mode Safeguards | 🟢 NORMAL | 1-2 | S6 |
| **TOTAL** | | | **~22-30** | |

---

## 🛡️ DESIGN-PRINZIPIEN

### 1. Nichts kaputt machen
SENTINEL ist ein **reines Add-On**. Es:
- Fügt neue Tabellen hinzu (kein bestehendes Schema ändern)
- Hookt sich über Signals/Timer ein (kein bestehender Code geändert)
- Kann komplett deaktiviert werden (Feature-Flag in Settings)
- Hat keinen Einfluss auf Audio-Performance (<1% CPU Overhead)

### 2. Vorsicht vor False Positives (Annos Design-Vorgabe)
- SENTINEL darf **NIE** eigenständig Tracks stumm schalten
  die eigentlich nicht betroffen sind
- Nur **bewiesene** Probleme (confidence=1.0) lösen Auto-Aktionen aus
- Alles unter confidence=0.95 → nur Warnung, User entscheidet
- User kann JEDE Auto-Aktion sofort rückgängig machen
- User kann JEDE Warnung als False Positive markieren
- SENTINEL lernt aus False Positives und wird vorsichtiger

### 3. Performance-Budget
- Flight Recorder: < 0.5% CPU (Background-Thread, psutil)
- Anomaly Detection: < 0.3% CPU (Python-basiert, kein ML)
- API Server: < 0.2% CPU (nur bei Requests)
- Gesamt: < 1% CPU-Overhead
- SQLite WAL mode → kein GUI-Blocking

### 4. Privatsphäre
- Alle Daten lokal (SQLite)
- KI-Analyse nur mit expliziter User-Bestätigung
- Keine Telemetrie ohne Opt-In
- API-Key wird verschlüsselt gespeichert
- Lokale API nur auf localhost (127.0.0.1)

### 5. Zukunftssicher
- SQLite = überall verfügbar
- HTTP API = jede Sprache/Tool kann es nutzen
- JSON-Protokoll = leicht erweiterbar
- Pattern-Export = Community kann Wissen teilen
- API-agnostisch = funktioniert mit Claude, GPT, lokalen Modellen

---

*Dieses Dokument wird mit jeder Phase aktualisiert.*
*Nächster Kollege: Lies S1, implementiere die DB-Tabellen, hake ab.*
*Erstellt: v0.0.20.903 — 2026-03-31*
