# 🎵 Py_DAW — Quick Start

## Starten (Ein Befehl!)

```bash
./start_daw.sh
```

**Das ist alles.** Das Script erledigt automatisch:
- Python venv erstellen (falls nötig)
- Alle Pakete installieren (falls nötig)
- C-DSP-Extensions kompilieren (falls gcc vorhanden)
- Rust Audio-Engine starten (falls gebaut)
- DAW öffnen

### Beim allerersten Start

Der erste Start dauert 1-2 Minuten (Pakete werden installiert).
Danach startet die DAW in wenigen Sekunden.

```
📦 Erstelle Python Virtual Environment...
  ✅ venv erstellt
📦 Installiere Python-Pakete...
  ✅ Pakete installiert
  ⚡ 2 C-Extension(s) kompiliert (DSP-Turbo aktiv)
  🐍 Audio: Python-Engine
  🚀 Starte Py_DAW...
```

### Optionen

```bash
./start_daw.sh --rebuild           # Alles neu bauen
USE_RUST_ENGINE=0 ./start_daw.sh   # Ohne Rust-Engine
```

---

## System-Anforderungen

- **Linux** (Debian/Ubuntu/Kali/Fedora/Arch)
- **Python 3.11+** (`sudo apt install python3 python3-venv python3-pip`)
- **PipeWire** oder **JACK** (Audio-Backend)

### Optional (empfohlen)

```bash
sudo apt install build-essential    # C-DSP-Turbo (10-70x schnellere FX)
sudo apt install libjack-jackd2-dev # JACK-Support
```

### Optional (Rust Audio-Engine)

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
# Dann: ./start_daw.sh baut die Rust-Engine automatisch
```

---

## Erste Schritte

1. **Neues Projekt**: Datei → Neu
2. **Track erstellen**: Rechtsklick im Arranger
3. **Instrument wählen**: Track → Instrument → z.B. "Fusion Synth"
4. **MIDI-Clip zeichnen**: Stift-Tool → in Timeline klicken
5. **Noten eingeben**: Doppelklick auf Clip → Piano Roll
6. **Abspielen**: Leertaste

### Shortcuts

| Taste | Aktion |
|---|---|
| Leertaste | Play/Pause |
| R | Record |
| Strg+Z | Undo |
| Strg+S | Speichern |
| Strg+E | Exportieren |

---

## Probleme?

### Kein Sound
```bash
# PipeWire prüfen
systemctl --user status pipewire

# Audio-Settings in der DAW
Bearbeiten → Audio-Einstellungen → Backend: sounddevice
```

### Langsam / Knackser
```bash
# C-Extensions prüfen (sollten automatisch gebaut sein)
ls pydaw/audio/fast_*.so

# Falls fehlend:
sudo apt install build-essential
./start_daw.sh --rebuild
```

### Fehler beim Start
```bash
# Log prüfen
cat ~/.cache/ChronoScaleStudio/pydaw.log

# Debug-Modus
PYDAW_LOG_LEVEL=DEBUG ./start_daw.sh
```

---

**Version**: 0.0.20.790  
**Datum**: 2026-03-24
