#!/usr/bin/env python3
"""db_health_check.py — SQLite Datenbank Health Check für Py_DAW.

Aufruf:
    python3 db_health_check.py           # Übersicht
    python3 db_health_check.py --detail   # Mit Beispiel-Daten
    python3 db_health_check.py --path     # Nur DB-Pfad ausgeben

Zeigt:
- Ob die DB existiert und lesbar ist
- Alle Tabellen mit Zeilenanzahl
- DB-Dateigröße
- WAL-Modus Status
- Beispiel-Daten (mit --detail)
"""

import sqlite3
import sys
import os
from pathlib import Path
from datetime import datetime


DB_DIR = Path.home() / ".config" / "ChronoScaleStudio"
MAIN_DB = DB_DIR / "pydaw.db"
PRESET_DB = DB_DIR / "preset_database.db"
PARAM_DB = DB_DIR / "param_registry.db"


def file_size_str(path: Path) -> str:
    if not path.exists():
        return "nicht vorhanden"
    size = path.stat().st_size
    if size < 1024:
        return f"{size} B"
    elif size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    else:
        return f"{size / (1024 * 1024):.2f} MB"


def check_db(db_path: Path, label: str, detail: bool = False) -> bool:
    """Check a single DB file. Returns True if OK."""
    print(f"\n{'═' * 60}")
    print(f"  {label}")
    print(f"  Pfad: {db_path}")
    print(f"  Größe: {file_size_str(db_path)}")
    print(f"{'═' * 60}")

    if not db_path.exists():
        print("  ❌ Datei existiert nicht!")
        print("  → Wird beim ersten Start der DAW automatisch angelegt.")
        return False

    try:
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
    except Exception as e:
        print(f"  ❌ Kann nicht geöffnet werden: {e}")
        return False

    try:
        # WAL mode check
        wal = conn.execute("PRAGMA journal_mode").fetchone()
        wal_mode = str(wal[0]) if wal else "?"
        print(f"  Journal-Modus: {wal_mode}")

        # List all tables
        tables = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).fetchall()
        table_names = [t["name"] for t in tables]

        if not table_names:
            print("  ⚠️  Keine Tabellen gefunden (DB ist leer)")
            conn.close()
            return False

        print(f"  Tabellen: {len(table_names)}")
        print()

        total_rows = 0
        ok_count = 0
        empty_count = 0

        for name in table_names:
            try:
                row = conn.execute(f"SELECT COUNT(*) as cnt FROM [{name}]").fetchone()
                cnt = int(row["cnt"]) if row else 0
                total_rows += cnt

                if cnt > 0:
                    status = "✅"
                    ok_count += 1
                else:
                    status = "○ "
                    empty_count += 1

                print(f"  {status} {name:<30s} {cnt:>6d} Zeilen")

                # Show sample data with --detail
                if detail and cnt > 0:
                    try:
                        cols = conn.execute(f"PRAGMA table_info([{name}])").fetchall()
                        col_names = [c["name"] for c in cols]
                        sample = conn.execute(f"SELECT * FROM [{name}] LIMIT 1").fetchone()
                        if sample:
                            print(f"      Spalten: {', '.join(col_names)}")
                            # Show first 3 meaningful columns
                            shown = 0
                            for cn in col_names:
                                if cn == "id":
                                    continue
                                val = sample[cn]
                                if val is not None and str(val).strip():
                                    val_str = str(val)[:60]
                                    print(f"      {cn}: {val_str}")
                                    shown += 1
                                    if shown >= 3:
                                        break
                            print()
                    except Exception:
                        pass

            except Exception as e:
                print(f"  ❌ {name:<30s} FEHLER: {e}")

        print(f"\n  {'─' * 50}")
        print(f"  Gesamt: {total_rows} Zeilen in {len(table_names)} Tabellen")
        print(f"  Befüllt: {ok_count} | Leer: {empty_count}")

        if ok_count > 0:
            print(f"  ✅ DB funktioniert!")
        else:
            print(f"  ⚠️  DB existiert aber alle Tabellen sind leer.")
            print(f"     → Starte die DAW einmal, damit Daten geschrieben werden.")

        conn.close()
        return ok_count > 0

    except Exception as e:
        print(f"  ❌ Fehler beim Lesen: {e}")
        conn.close()
        return False


def main():
    detail = "--detail" in sys.argv or "-d" in sys.argv
    path_only = "--path" in sys.argv or "-p" in sys.argv

    if path_only:
        print(str(DB_DIR))
        return

    print()
    print("🔍 Py_DAW SQLite Datenbank Health Check")
    print(f"   Zeitpunkt: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"   DB-Verzeichnis: {DB_DIR}")

    if not DB_DIR.exists():
        print(f"\n❌ Verzeichnis existiert nicht: {DB_DIR}")
        print("→ Die DAW wurde noch nie gestartet oder nutzt einen anderen Pfad.")
        return

    results = []
    results.append(check_db(MAIN_DB, "Haupt-Datenbank (pydaw.db)", detail))
    results.append(check_db(PRESET_DB, "Preset-Datenbank (preset_database.db)", detail))
    results.append(check_db(PARAM_DB, "Parameter-Registry (param_registry.db)", detail))

    print(f"\n{'═' * 60}")
    print("  ZUSAMMENFASSUNG")
    print(f"{'═' * 60}")

    all_sizes = []
    for p in [MAIN_DB, PRESET_DB, PARAM_DB]:
        if p.exists():
            all_sizes.append(p.stat().st_size)
    total_size = sum(all_sizes)

    ok = sum(results)
    total = len(results)

    print(f"  Datenbanken: {ok}/{total} funktionieren")
    print(f"  Gesamtgröße: {total_size / (1024*1024):.2f} MB")

    if all(results):
        print(f"\n  🎉 Alles OK — SQLite läuft einwandfrei!")
    elif any(results):
        print(f"\n  ⚠️  Teilweise OK — manche DBs sind noch leer.")
        print(f"     Starte die DAW und speichere ein Projekt.")
    else:
        print(f"\n  ❌ Keine DB enthält Daten.")
        print(f"     Starte die DAW einmal, dann werden die Tabellen angelegt.")

    print()


if __name__ == "__main__":
    main()
