# 🎵 Py_DAW — Installation

## Schnellstart (Ein Befehl!)

```bash
./start_daw.sh
```

Fertig. Das Script macht alles automatisch.

---

## Was wird benötigt?

### Pflicht

| Paket | Debian/Ubuntu/Kali | Arch/SteamOS |
|---|---|---|
| Python 3.11+ | `sudo apt install python3 python3-venv python3-pip` | `sudo pacman -S python` |
| Audio-Backend | PipeWire (Standard) oder JACK | PipeWire (Standard auf SteamOS) |
| PortAudio | `sudo apt install libportaudio2` | `sudo pacman -S portaudio` |
| PipeWire-JACK | (meist vorinstalliert) | `sudo pacman -S pipewire-jack` |
| PipeWire-ALSA | (meist vorinstalliert) | `sudo pacman -S pipewire-alsa` |

### Empfohlen

| Paket | Debian/Ubuntu/Kali | Arch/SteamOS | Warum |
|---|---|---|---|
| gcc | `sudo apt install build-essential` | `sudo pacman -S base-devel` | C-DSP-Extensions (10-70x schneller) |
| JACK dev | `sudo apt install libjack-jackd2-dev` | (in pipewire-jack) | Niedrigere Latenz |

### Optional

| Paket | Debian/Ubuntu/Kali | Arch/SteamOS | Warum |
|---|---|---|---|
| Rust | `curl https://sh.rustup.rs \| sh` | `sudo pacman -S rust` | Rust Audio-Engine |
| FluidSynth | `sudo apt install libfluidsynth3` | `sudo pacman -S fluidsynth` | SF2 Soundfont |
| lilv | `sudo apt install liblilv-dev` | `sudo pacman -S lilv` | LV2 Plugins |

---

## Was `./start_daw.sh` automatisch macht

1. **Python venv** — Erstellt `myenv/` beim ersten Start
2. **pip install** — Installiert alle Pakete aus `requirements.txt`
3. **C-Extensions** — Kompiliert `fast_filters.so` und `fast_builtin_fx.so` (falls gcc da)
4. **Rust-Engine** — Baut `pydaw_engine` mit cargo (falls Rust installiert)
5. **DAW starten** — `python3 main.py`

### Neustart / Reparatur

```bash
./start_daw.sh --rebuild    # Alles komplett neu bauen
```

### Ohne Rust

```bash
USE_RUST_ENGINE=0 ./start_daw.sh
```

---

## Manuelle Installation (falls nötig)

```bash
# 1. venv
python3 -m venv myenv
source myenv/bin/activate

# 2. Pakete
pip install -r requirements.txt

# 3. C-Extensions (optional, empfohlen)
cd pydaw/audio
gcc -O3 -march=native -ffast-math -shared -fPIC -o fast_filters.so fast_filters.c -lm
gcc -O3 -march=native -ffast-math -shared -fPIC -o fast_builtin_fx.so fast_builtin_fx.c -lm
cd ../..

# 4. Rust (optional)
cd pydaw_engine && cargo build --release && cd ..

# 5. Starten
python3 main.py
```

---

## Unterstützte Plattformen

| Plattform | Status |
|---|---|
| Debian 12+ | ✅ Getestet |
| Ubuntu 22.04+ | ✅ Getestet |
| Kali Linux | ✅ Getestet |
| Arch Linux | ✅ Getestet (v0.0.20.805) |
| SteamOS (Steam Deck) | ✅ Unterstützt (v0.0.20.805) |
| Manjaro / EndeavourOS | ✅ Sollte funktionieren |
| Fedora 38+ | ✅ Sollte funktionieren |
| macOS | ⚠️ Experimentell (kein PipeWire) |
| Windows | ❌ Nicht unterstützt |

### Arch Linux / SteamOS — Schnellinstallation

```bash
# 1. System-Abhängigkeiten
sudo pacman -S --needed python pipewire-jack pipewire-alsa portaudio \
    lilv fluidsynth base-devel

# 2. Plugins (optional)
sudo pacman -S --needed lsp-plugins surge-xt zynaddsubfx

# 3. Starten (macht den Rest automatisch)
./start_daw.sh
```

---

**Version**: 0.0.20.805
**Datum**: 2026-03-25
