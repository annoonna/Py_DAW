#!/bin/bash
# ═══════════════════════════════════════════════════════════
#  Py_DAW — Build C Extensions
#  v0.0.20.790
#
#  Kompiliert alle C-Extensions für maximale DSP-Performance.
#  Ohne diese .so-Dateien laufen alle FX in reinem Python
#  (funktional identisch, aber ~10-70x langsamer).
#
#  Benötigt: gcc (apt install build-essential)
#  Aufruf:   ./build_c_extensions.sh
# ═══════════════════════════════════════════════════════════

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AUDIO_DIR="$SCRIPT_DIR/pydaw/audio"
CC="${CC:-gcc}"
CFLAGS="-O3 -march=native -ffast-math -shared -fPIC"

echo "🔧 Py_DAW C-Extensions Builder"
echo "   Compiler: $CC"
echo "   Flags: $CFLAGS"
echo ""

# Check gcc
if ! command -v "$CC" &>/dev/null; then
    echo "⚠️  $CC nicht gefunden."
    echo "   Installiere mit: sudo apt install build-essential"
    echo "   Ohne C-Extensions läuft alles in reinem Python (langsamer)."
    exit 0  # kein Fehler — Fallback funktioniert
fi

BUILT=0
FAILED=0

build_so() {
    local name="$1"
    local c_file="$AUDIO_DIR/$name.c"
    local so_file="$AUDIO_DIR/$name.so"

    if [ ! -f "$c_file" ]; then
        echo "   ⚠️  $name.c nicht gefunden — übersprungen"
        return
    fi

    echo -n "   Kompiliere $name.so ... "
    if $CC $CFLAGS -o "$so_file" "$c_file" -lm 2>/dev/null; then
        local size=$(wc -c < "$so_file")
        echo "✅ ($size bytes)"
        BUILT=$((BUILT + 1))
    else
        echo "❌ Kompilierung fehlgeschlagen"
        FAILED=$((FAILED + 1))
    fi
}

# Build all C extensions
build_so "fast_filters"        # SVF, Ladder, Comb (Fusion Filter)
build_so "fast_builtin_fx"     # Reverb, Delay, Chorus, Phaser, Flanger, Gate, DeEsser

echo ""
echo "═══════════════════════════════════════"
echo "  Ergebnis: $BUILT kompiliert, $FAILED fehlgeschlagen"
echo "═══════════════════════════════════════"

if [ $BUILT -gt 0 ]; then
    echo ""
    echo "  C-Extensions beschleunigen diese FX:"
    echo "    fast_filters.so:     SVF (2665x), Ladder (134x), Comb (1630x)"
    echo "    fast_builtin_fx.so:  Reverb (201x), Delay (610x), Chorus (37x),"
    echo "                         Phaser (41x), Flanger (38x), Gate (1275x),"
    echo "                         DeEsser (528x)"
    echo ""
    echo "  Zahlen = Vielfaches der Realtime-Geschwindigkeit @ 48kHz"
fi

if [ $FAILED -gt 0 ]; then
    echo ""
    echo "  ⚠️  Fehlgeschlagene Extensions laufen in reinem Python."
    echo "      Funktional identisch, nur langsamer."
fi
