# 🔌 Py_DAW Plugin API — Schreibe dein erstes Plugin in 10 Minuten

**Version:** 0.0.20.811
**Voraussetzung:** Python 3.12+, Py_DAW installiert

---

## 🎯 Was ist ein Py_DAW Plugin?

Ein Py_DAW Plugin ist eine Python-Datei die eine Klasse definiert.
Es gibt drei Typen:

| Typ | Basisklasse | Beispiel |
|-----|------------|---------|
| Audio-Effekt | `PyDawEffect` | EQ, Kompressor, Delay |
| Instrument | `PyDawInstrument` | Synthesizer, Sampler |
| MIDI-Effekt | `PyDawMidiFx` | Arpeggiator, Chord Generator |

---

## ⚡ Schnellstart: Dein erster Effekt in 5 Minuten

### 1. Erstelle eine Datei: `my_gain.py`

```python
"""Einfacher Gain-Effekt — mein erstes Py_DAW Plugin."""

from pydaw.plugins.custom_plugin_api import PyDawEffect, PluginParam

class MyGain(PyDawEffect):
    """Einfacher Gain-Regler mit dB-Anzeige."""

    # Plugin-Info (wird in der DAW angezeigt)
    PLUGIN_NAME = "My Gain"
    PLUGIN_ID = "my_gain_v1"
    PLUGIN_CATEGORY = "Utility"

    # Parameter definieren
    PARAMS = [
        PluginParam("gain_db", "Gain (dB)", min_val=-24.0, max_val=24.0, default=0.0),
        PluginParam("bypass", "Bypass", min_val=0.0, max_val=1.0, default=0.0, is_toggle=True),
    ]

    def process(self, buffer, sample_rate, params):
        \"\"\"Audio verarbeiten.

        Args:
            buffer: numpy array, shape (frames, channels)
            sample_rate: float (z.B. 44100.0)
            params: dict mit aktuellen Parameterwerten
        \"\"\"
        if params.get("bypass", 0) > 0.5:
            return buffer  # Bypass: Audio unverändert durchreichen

        import numpy as np
        gain_db = params.get("gain_db", 0.0)
        gain_linear = 10.0 ** (gain_db / 20.0)
        return buffer * gain_linear
```

### 2. Plugin in die DAW laden

Kopiere `my_gain.py` nach:
```
~/.pydaw/plugins/my_gain.py
```

Beim nächsten DAW-Start wird das Plugin automatisch erkannt!

Alternativ: In der DAW → Menü → Plugins → "Plugin-Ordner scannen"

### 3. Plugin verwenden

1. Track erstellen oder auswählen
2. FX-Kette öffnen (im Mixer oder Inspector)
3. "My Gain" aus der Plugin-Liste wählen
4. Gain-Regler drehen → Audio wird lauter/leiser

---

## 🎹 Instrument-Plugin Beispiel

```python
\"\"\"Einfacher Sinus-Synthesizer.\"\"\"

import math
from pydaw.plugins.custom_plugin_api import PyDawInstrument, PluginParam

class SineSynth(PyDawInstrument):
    PLUGIN_NAME = "Sine Synth"
    PLUGIN_ID = "sine_synth_v1"
    PLUGIN_CATEGORY = "Synthesizer"

    PARAMS = [
        PluginParam("volume", "Volume", 0.0, 1.0, 0.8),
        PluginParam("attack", "Attack (s)", 0.001, 2.0, 0.01),
        PluginParam("release", "Release (s)", 0.01, 5.0, 0.3),
    ]

    def __init__(self):
        super().__init__()
        self._phase = 0.0
        self._active_note = -1
        self._velocity = 0.0
        self._env = 0.0

    def note_on(self, pitch, velocity, channel=0):
        self._active_note = pitch
        self._velocity = velocity / 127.0

    def note_off(self, pitch, channel=0):
        if pitch == self._active_note:
            self._active_note = -1

    def render(self, num_frames, sample_rate, params):
        \"\"\"Render Audio-Frames.

        Returns:
            numpy array, shape (num_frames, 2) für Stereo
        \"\"\"
        import numpy as np
        output = np.zeros((num_frames, 2), dtype=np.float32)

        if self._active_note < 0:
            # Release phase
            self._env *= 0.999
            return output

        freq = 440.0 * (2.0 ** ((self._active_note - 69) / 12.0))
        vol = params.get("volume", 0.8) * self._velocity

        # Simple envelope
        self._env = min(1.0, self._env + 1.0 / (params.get("attack", 0.01) * sample_rate))

        for i in range(num_frames):
            sample = math.sin(2.0 * math.pi * self._phase) * vol * self._env
            self._phase += freq / sample_rate
            if self._phase >= 1.0:
                self._phase -= 1.0
            output[i, 0] = sample
            output[i, 1] = sample

        return output
```

---

## 🎵 MIDI-Effekt Beispiel

```python
\"\"\"Einfacher Oktav-Transposer.\"\"\"

from pydaw.plugins.custom_plugin_api import PyDawMidiFx, PluginParam

class OctaveShift(PyDawMidiFx):
    PLUGIN_NAME = "Octave Shift"
    PLUGIN_ID = "octave_shift_v1"
    PLUGIN_CATEGORY = "MIDI FX"

    PARAMS = [
        PluginParam("octaves", "Oktaven", -3.0, 3.0, 0.0),
    ]

    def process_notes(self, notes, params):
        \"\"\"MIDI-Noten verarbeiten.

        Args:
            notes: Liste von MidiNote Objekten (pitch, velocity, start_beats, length_beats)
            params: dict mit Parameterwerten

        Returns:
            Veränderte Liste von MidiNote Objekten
        \"\"\"
        octaves = int(params.get("octaves", 0))
        for note in notes:
            note.pitch = max(0, min(127, note.pitch + octaves * 12))
        return notes
```

---

## 📋 API-Referenz

### PluginParam

```python
PluginParam(
    name: str,           # Interner Name (eindeutig)
    label: str,          # Anzeigename im UI
    min_val: float = 0,  # Minimum
    max_val: float = 1,  # Maximum
    default: float = 0,  # Startwert
    is_toggle: bool = False,  # True = On/Off Button statt Knob
    unit: str = "",      # Einheit ("dB", "Hz", "ms", "%")
)
```

### PyDawEffect (Audio-Effekt)

| Methode | Beschreibung |
|---------|-------------|
| `process(buffer, sample_rate, params)` | Audio verarbeiten (numpy array) |
| `reset()` | State zurücksetzen (optional) |
| `get_latency()` | Latenz in Samples (optional, für PDC) |

### PyDawInstrument

| Methode | Beschreibung |
|---------|-------------|
| `note_on(pitch, velocity, channel)` | MIDI Note On |
| `note_off(pitch, channel)` | MIDI Note Off |
| `render(num_frames, sample_rate, params)` | Audio rendern |
| `all_notes_off()` | Panic (optional) |
| `reset()` | State zurücksetzen (optional) |

### PyDawMidiFx (MIDI-Effekt)

| Methode | Beschreibung |
|---------|-------------|
| `process_notes(notes, params)` | MIDI-Noten transformieren |
| `reset()` | State zurücksetzen (optional) |

---

## 📁 Plugin-Verzeichnisse

```
~/.pydaw/plugins/           ← User-Plugins (hier eigene ablegen)
  ├── my_gain.py
  ├── my_synth.py
  └── my_arp.py

pydaw/plugins/              ← Factory-Plugins (nicht ändern!)
  ├── aeterna/
  ├── fusion/
  ├── sampler/
  └── custom_plugin_api.py  ← API-Basisklassen
```

---

## 💡 Tipps

1. **Immer numpy verwenden** für Audio-Verarbeitung — Python-Loops sind zu langsam
2. **Keine Heap-Allokationen in process()** — Buffer vorher allokieren
3. **try/except um externen Code** — ein Plugin-Crash darf nie die DAW killen
4. **get_latency()** implementieren wenn dein Effekt einen Lookahead hat
5. **PLUGIN_ID muss eindeutig sein** — am besten mit Versionsnummer
6. Teste mit: `python3 -c "from my_plugin import MyEffect; print('OK')"`

---

## 🧪 Plugin testen

```python
# test_my_gain.py
import numpy as np
from my_gain import MyGain

fx = MyGain()
# Generiere Test-Signal (1 Sekunde Stille)
buffer = np.zeros((44100, 2), dtype=np.float32)
buffer[:, 0] = np.sin(np.linspace(0, 440 * 2 * np.pi, 44100))
buffer[:, 1] = buffer[:, 0]

# Verarbeite mit +6 dB
result = fx.process(buffer, 44100.0, {"gain_db": 6.0})
print(f"Input peak: {np.max(np.abs(buffer)):.4f}")
print(f"Output peak: {np.max(np.abs(result)):.4f}")
# Output sollte ~2x lauter sein (+6 dB ≈ ×2)
```

---

## 📚 Weiterführend

- Scripting Console: `Menü → Ansicht → Scripting Console`
- Macro-Recorder: `Menü → Extras → Macro aufnehmen`
- Batch-Processing: `python3 -m pydaw.services.batch_process --help`
- Community-Presets: `~/.pydaw/presets/` (`.pydaw-preset` YAML-Format)

---

*Py_DAW Plugin API v0.0.20.811 — Open Source, Python-scriptbar, KI-unterstützt.*
