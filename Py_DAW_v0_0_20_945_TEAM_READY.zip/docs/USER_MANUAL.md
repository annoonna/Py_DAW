# Py_DAW — User Manual

**Version:** 0.0.20.813
**Projekt:** ChronoScaleStudio / Py_DAW
**Lizenz:** Open Source

---

## Inhaltsverzeichnis

1. [Erste Schritte](#erste-schritte)
2. [Benutzeroberfläche](#benutzeroberfläche)
3. [Arranger](#arranger)
4. [Piano Roll](#piano-roll)
5. [Mixer](#mixer)
6. [Instrumente](#instrumente)
7. [Effekte](#effekte)
8. [Audio Recording](#audio-recording)
9. [Automation](#automation)
10. [MIDI](#midi)
11. [KI-Assistent](#ki-assistent)
12. [Live-Performance](#live-performance)
13. [Export & Import](#export--import)
14. [Einstellungen](#einstellungen)
15. [Tastaturkürzel](#tastaturkürzel)
16. [Fehlerbehebung](#fehlerbehebung)

---

## Erste Schritte

### Installation

```bash
# Repository klonen oder ZIP entpacken
cd Py_DAW

# Automatisch starten (installiert alles bei Bedarf)
./start_daw.sh

# ODER manuell:
python3 -m venv myenv
source myenv/bin/activate
pip install -r requirements.txt
python3 main.py
```

### Systemanforderungen

- Python 3.11+ (empfohlen: 3.12 oder 3.13)
- Linux (Debian/Ubuntu/Kali, Arch/Manjaro/SteamOS)
- PipeWire oder JACK für Audio
- Optional: Rust-Toolchain für die native Audio-Engine

### Erstes Projekt

1. Starte mit `./start_daw.sh`
2. Beim ersten Start erscheint der First-Run-Wizard
3. Wähle ein Audio-Backend (PipeWire empfohlen)
4. Erstelle ein neues Projekt oder öffne das Demo-Projekt

---

## Benutzeroberfläche

### Hauptbereiche

- **Toolbar (oben):** Transport, BPM, Taktart, Grid, Tools
- **Arranger (Mitte):** Timeline mit Clips, Tracks, Automation
- **Editor (unten):** Piano Roll, Notation, Audio Editor
- **Browser (rechts):** Instrumente, Effekte, Samples, Presets
- **Mixer (Tab):** Kanalzüge, FX-Ketten, Send/Return
- **KI-Panel (Dock):** KI-Kompositionsassistent

### Panels ein-/ausblenden

- `View → Panels` im Hauptmenü
- Panels sind andockbar (Dock-Widgets)
- Multi-Monitor: `View → Screen Layouts` für vorgefertigte Anordnungen

---

## Arranger

### Clips erstellen

- **MIDI-Clip:** Doppelklick auf leere Stelle oder Rechtsklick → "Neuer MIDI-Clip"
- **Audio-Clip:** Datei aus Browser/Dateisystem auf Track ziehen
- **Clip verschieben:** Klicken + Ziehen
- **Clip duplizieren:** Alt + Ziehen oder Ctrl+D
- **Clip löschen:** Auswählen + Entf

### Tracks

- **Track hinzufügen:** Plus-Button oder Rechtsklick → "Track hinzufügen"
- **Track-Typen:** Instrument, Audio, Gruppe, FX-Return
- **Track umbenennen:** Doppelklick auf Track-Header
- **Track-Farbe:** Rechtsklick → Farbe wählen

### Loop & Punch

- **Loop-Region:** Im Ruler ziehen oder Loop-Marker setzen
- **Punch In/Out:** Rote Marker im Arranger für automatisches Recording
- **Pre-Roll:** Einstellbar in der Transport-Leiste (1-4 Takte)

---

## Piano Roll

### Noten bearbeiten

- **Noten zeichnen:** Pencil-Tool (P) → Klick/Ziehen
- **Noten auswählen:** Select-Tool (V) → Klick oder Rechteck-Auswahl
- **Noten verschieben:** Auswählen + Ziehen
- **Noten-Länge ändern:** Rechte Kante der Note ziehen
- **Velocity:** Unterer Bereich des Piano Rolls
- **Noten löschen:** Eraser-Tool (E) oder Auswahl + Entf

### Expression Lanes

- Velocity, Pitch Bend, Mod Wheel, Aftertouch
- CC-Automation direkt im Piano Roll

### MIDI-Aufnahme

- Track mit Record-Arm (R-Button im Mixer)
- MIDI-Keyboard anschließen
- Transport → Record → Spielen
- Quantize nach Aufnahme: Edit → Quantize

---

## Mixer

### Kanalzüge

Jeder Track hat: Volume-Fader, Pan-Knob, Mute/Solo-Buttons, FX-Slots

### Send/Return

- **FX-Return-Track erstellen:** Rechtsklick → "FX Track"
- **Send hinzufügen:** Im Mixer unter dem Track
- **Pre/Post-Fader:** Rechtsklick auf Send-Knob

### Sidechain

- Rechtsklick auf einen Compressor/Gate → "Sidechain Source"
- Wähle den Quell-Track (z.B. Kick → Bass-Compressor)

### Group Tracks

- Mehrere Tracks in eine Gruppe fassen
- Volume/FX auf der Gruppe gelten für alle Unter-Tracks

---

## Instrumente

### AETERNA Synth

Professioneller Synthesizer mit:
- 2 Oszillatoren (Saw, Square, Sine, Triangle, Noise, Wavetable)
- Filter (LP/HP/BP) mit Envelope
- ADSR Amp + Filter Envelope
- LFO mit 5 Wellenformen
- Unison Engine (1-16 Voices)
- Wavetable Import (Serum .wav Format)
- Modulations-Matrix (8 Slots)

### Fusion Synth

Modularer Hybrid-Synthesizer:
- Scrawl-Oszillator
- Multiple Filter-Typen
- Flexible Routing-Matrix
- Performance-Presets

### Drum Machine

- 4×16 Pad-Grid (64 Pads)
- Pro Pad: Sample, Volume, Pan, Tune, FX
- Choke Groups (Hi-Hat Open/Closed)
- MIDI-Mapping: C1-D#5 (GM Drum Map)

### Advanced Sampler

- Multi-Zone Key/Velocity Mapping
- Round-Robin Gruppen
- Sample-Start/End/Loop-Punkte
- Filter + ADSR pro Zone

### BachOrgel

- 9 Drawbar-Register (16', 8', 5⅓', 4', 2⅔', 2', 1⅗', 1⅓', 1')
- 5 Registration Presets
- Rotary Speaker Emulation

---

## Effekte

### Essential FX

| Effekt | Beschreibung |
|--------|-------------|
| Parametric EQ | 8-Band EQ mit Bell, Shelf, HP/LP |
| Compressor | Feed-Forward mit Sidechain |
| Reverb | Algorithmic (Hall/Room/Plate) |
| Delay | Stereo, Tempo-Sync, Ping-Pong |
| Limiter | Brickwall Peak Limiter |

### Creative FX

| Effekt | Beschreibung |
|--------|-------------|
| Chorus | Multi-Voice, Stereo Spread |
| Phaser | N-Stage Allpass |
| Flanger | LFO-moduliertes Delay |
| Distortion | Soft/Hard/Tube/Tape/Bitcrush |
| Tremolo | Sine/Square/Triangle Amplitude |

### Utility FX

Gate, De-Esser, Stereo Widener, Utility, Spectrum Analyzer

---

## Audio Recording

### Aufnahme starten

1. Track Record-Arm aktivieren (R-Button im Mixer)
2. Input-Routing einstellen (Mixer → Input ComboBox)
3. Transport → Record (oder R-Taste)
4. Spielen — Aufnahme wird als WAV gespeichert

### Comping

1. Loop-Recording: Mehrere Durchläufe → separate Takes
2. Take-Lanes im Arranger einblenden
3. Comp-Tool: Bereiche aus verschiedenen Takes auswählen
4. Flatten: Comp zu einem Clip zusammenführen

### Pitch Correction

- Audio-Editor → Pitch-Analyse (YIN-Algorithmus)
- Einzelne Noten verschieben → Phase-Vocoder Korrektur
- Auto-Correct: Chromatisch oder Scale-basiert

---

## Automation

### Modi

- **Off:** Keine Automation
- **Read:** Automation wird abgespielt
- **Write:** Bewegungen werden aufgezeichnet (überschreibt)
- **Touch:** Nur während Berührung schreiben
- **Latch:** Ab Berührung dauerhaft schreiben

### Automation-Lanes

- Im Arranger: Track aufklappen → Automation-Lanes
- Parameter wählen: Volume, Pan, Send, Plugin-Parameter
- Breakpoints: Klicken zum Setzen, Ziehen zum Bewegen
- Kurven: Linear, Bezier, Step, Logarithmisch, S-Curve

---

## MIDI

### MIDI-Eingang

- Automatische Erkennung von MIDI-Keyboards
- Input-Monitoring: Echtzeit-Abhöre
- MIDI Learn: CC-Controller → Parameter zuordnen

### MIDI FX Chain

Vor dem Instrument geschaltete MIDI-Effekte:
- Arpeggiator (12+ Modi)
- Chord Generator (16 Akkordtypen)
- Scale Quantizer (8 Skalen)
- Note Echo, Velocity Curve, Randomizer

### MPE Support

- Per-Note Pitch Bend, Pressure, Slide
- Roli Seaboard, Linnstrument, Sensel Morph Presets

---

## KI-Assistent

### Zugang

- `View → KI-Assistent` oder Tastenkürzel
- API-Key eingeben (console.anthropic.com)

### Quick Prompts

| Button | Funktion |
|--------|----------|
| 🥁 Drum Groove | 8-Takt Drum-Pattern generieren |
| 🎹 Akkorde | Akkordfolge vorschlagen |
| 🎸 Bassline | Bassline aus Akkorden generieren |
| 🎵 Melodie | Melodie generieren |
| 🎼 Harmonie | Offline Akkord/Tonart-Analyse |
| 🥁 Rhythmus | Offline Groove-Analyse |
| 🎭 Genre | Genre-Erkennung aus MIDI |
| 🎛 Preset-Gen | Beschreibung → Synth-Preset |
| 🎲 Smart-Rnd | Musikalische Randomisierung |

### Offline-Features (kein API-Key nötig)

- Harmonie-Analyse, Rhythmus-Analyse
- Genre-Erkennung, Mix-Check
- Preset-Generator, Smart-Randomize

---

## Live-Performance

### Live-Modus

- `View → Live-Performance` oder F11
- Vollbild 8×8 Clip-Grid
- Touch-optimiert (≥60px Buttons)
- Transport, Scene-Launch, Level-Meter

### Controller-Support

- Novation Launchpad (Mini MK3, X)
- Akai APC Mini MK2, APC40 MK2
- Ableton Push 2
- Xbox/PS Gamepad (pygame)
- TouchOSC / Lemur (OSC-Protokoll)

### Live-Effekte

- Stutter, Live-Looper, Beat-Repeat
- Alle per MIDI-Controller steuerbar

---

## Export & Import

### Audio-Export

- Formate: WAV (16/24/32bit), FLAC, MP3, OGG
- Sample-Rates: 44.1/48/88.2/96 kHz
- Dither: Triangular, POW-R
- Normalisierung: Peak, LUFS
- Stem-Export: Alle Tracks als separate Dateien

### DAWproject

- Export/Import für Bitwig Studio, Studio One
- Clips, Automation, Plugin-Mapping

### Projekt-Backup

- Git-basierte Versionierung
- Projekt-Sharing per .pydaw-share Paket

---

## Einstellungen

### Audio-Einstellungen

- Backend: PipeWire (empfohlen), JACK, ALSA
- Buffer-Size: 64/128/256/512/1024/2048
- Sample-Rate: 44100/48000/96000 Hz

### Themes

5 eingebaute Themes: Dark (Standard), Light, Midnight, Solarized Dark, High Contrast.
Eigene Themes per YAML in `~/.pydaw/themes/`.

### Rust-Engine

- Optional: Rust Audio-Engine für bessere Performance
- Toggle in Einstellungen → "Rust Engine"
- Hybrid-Modus: Manche Tracks in Rust, manche in Python

---

## Tastaturkürzel

| Taste | Aktion |
|-------|--------|
| Space | Play/Stop |
| R | Record Toggle |
| Ctrl+S | Projekt speichern |
| Ctrl+Z | Undo |
| Ctrl+Shift+Z | Redo |
| Ctrl+N | Neues Projekt |
| Ctrl+O | Projekt öffnen |
| Ctrl+D | Clip duplizieren |
| Delete | Auswahl löschen |
| V | Select-Tool |
| P | Pencil-Tool |
| E | Eraser-Tool |
| K | Knife-Tool |
| F11 | Live-Performance Fullscreen |
| Escape | Live-Modus beenden |
| Ctrl+A | Alles auswählen |
| Ctrl+C/V | Kopieren/Einfügen |

---

## Fehlerbehebung

### Kein Ton

1. Audio-Backend prüfen: `Settings → Audio`
2. PipeWire/JACK läuft? `pw-cli info` oder `jack_lsp`
3. Track nicht gemutet?
4. Volume nicht auf 0?
5. Richtiger Output gewählt?

### Rust-Engine verbindet sich nicht

1. `./start_daw.sh` neu starten
2. Socket aufräumen: `rm -f /tmp/pydaw_engine.sock`
3. Fallback: `USE_RUST_ENGINE=0 ./start_daw.sh`

### Plugin läuft nicht

1. Plugin-Pfad prüfen: `/usr/lib/vst3/`, `~/.vst3/`
2. Plugin scannen: `View → Plugin-Scanner`
3. Sandbox-Modus ein/ausschalten

### Crash beim Starten

1. Log prüfen: `~/.pydaw/crash_log.txt`
2. Ohne Plugins starten: `python3 main.py --no-plugins`
3. Einstellungen zurücksetzen: `rm -rf ~/.config/ChronoScaleStudio/`

---

*Dieses Manual wird mit jeder Version aktualisiert.*
*Stand: v0.0.20.813*
