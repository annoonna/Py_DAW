## v0.0.20.360 — DAWproject Export Cross-Device Hotfix

- [x] FIXED (GPT-5, 2026-03-08): Kritischen Export-Fehler **`[Errno 18] Ungültiger Link über Gerätegrenzen hinweg`** behoben. Finale `.dawproject`-Datei wird jetzt als **temporäre Schwesterdatei im Zielordner** erzeugt und erst danach per `os.replace()` übernommen. Dadurch funktionieren Exporte auch dann, wenn `/tmp` und Benutzerordner auf unterschiedlichen Dateisystemen liegen.

## v0.0.20.359 — DAWproject Export UI Hook (sichtbar im Datei-Menü)

- [x] FIXED (GPT-5, 2026-03-08): Sicherer Menü-Hook **`Datei → DAWproject exportieren… (.dawproject)`** ergänzt, inklusive Hintergrund-Export via `DawProjectExportRunnable`, Progress-Dialog und Summary-Dialog — ohne Core-/Playback-Eingriff.
- [ ] AVAILABLE: Export-Dialog optional später um sehr kleine **Optionen** ergänzen (z. B. Audio einbetten an/aus, Validierung an/aus), weiterhin nur UI/FileIO.
- [ ] AVAILABLE: Ein kleiner **Roundtrip-Testpfad** `Export → neues leeres Projekt → Import` kann als separater sicherer QA-Schritt ergänzt werden.


## v0.0.20.358 — DAWproject Exporter Scaffold (snapshot-safe, ohne Core-Eingriff)

- [x] FIXED (GPT-5, 2026-03-08): Neuer entkoppelter **`DawProjectExporter`** als reiner **Data Mapper** ergänzt — arbeitet ausschließlich auf einer tief kopierten Snapshot-`Project`-Instanz.
- [x] FIXED (GPT-5, 2026-03-08): Sicherer **Temp-File-First Exportpfad** umgesetzt: Staging-Ordner → `project.xml` / `metadata.xml` / `audio/` → temporäre ZIP → XML/ZIP-Validierung → atomarer Move.
- [x] FIXED (GPT-5, 2026-03-08): **Automation-Lanes**, **Audio-Referenzen** und konservative **Base64-Plugin-State-Blobs** in ein erstes `.dawproject`-Export-Skelett gemappt, ohne Playback-/DSP-Core anzufassen.
- [x] FIXED (GPT-5, 2026-03-08): Optionalen **`DawProjectExportRunnable`** für non-blocking UI-Integration ergänzt, weiterhin ohne MainWindow-Hook.
- [ ] AVAILABLE: Sicheren **MainWindow-Menü-Hook** `Datei → DAWproject exportieren…` ergänzen, ausschließlich auf Basis des neuen Snapshot-Exporters.
- [ ] AVAILABLE: Kleinen **Export-ProgressDialog** mit `QThreadPool` / `DawProjectExportRunnable` ergänzen, ohne Audio-/Transport-Core anzufassen.
- [ ] AVAILABLE: **Roundtrip-Smoke-Test** (Export → Re-Import in leeres Projekt) ergänzen, weiterhin nur im FileIO-/Test-Bereich.

## v0.0.20.357 — Echter Group-Bus mit eigener Device-Chain (Bitwig-Style)

- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Echte Gruppenspur mit kind="group"** erstellt — Group-Track hat eigene `audio_fx_chain` durch die das summierte Audio aller Kindspuren fließt.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Group-Bus-Routing im Audio-Callback**: Kind-Audio → Kind-FX → Kind-Vol/Pan → Group-Buffer → Group-FX → Group-Vol/Pan → Master.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Pull-Sources (Sampler/Drum/SF2)** werden ebenfalls durch den Group-Bus geroutet.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Group-Header-Klick im Arranger** wählt den Group-Track aus → DevicePanel zeigt die Gruppen-Device-Chain.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Effects auf die Gruppe** landen jetzt auf der Gruppen-FX-Chain (nicht mehr auf kick).
- [ ] AVAILABLE: **Group-Fader im Mixer-View** als eigener Bus-Kanal anzeigen.
- [ ] AVAILABLE: **Group Mute/Solo Verhalten** (Bitwig: Group-Mute stummschaltet alle Kinder).
- [ ] AVAILABLE: **Sub-Lanes innerhalb einer eingeklappten Gruppe** statt Überlappung.

## v0.0.20.356 — Kritischer Bugfix: Collapsed-Group Clip-Track-Zuordnung

- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Clip-Track-Korruption bei Drag in eingeklappter Gruppe** behoben. Clips wurden beim horizontalen Drag stillschweigend auf `members[0]` (z.B. kick) umgehängt — damit spielten alle gruppierten Instrumente gleichzeitig.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Single-Clip, Multi-Clip und Copy-Drag** jeweils mit `_is_same_collapsed_group()` Guard geschützt.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Track-Lookup Fallback** für collapsed Groups: Volume-Anzeige für Non-First-Members korrigiert.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Spur-Name-Prefix in Clip-Labels** bei eingeklappter Gruppe (🔹kick: ..., 🔹open hi: ...) zur besseren Unterscheidbarkeit.
- [ ] AVAILABLE: **Sub-Lanes innerhalb einer eingeklappten Gruppe** statt Überlappung aller Clips auf einer Zeile.
- [ ] AVAILABLE: **Echte Group-Track / Group-Bus Device-Chain wie in Bitwig** bleibt ein separater Routing-/Mixer-Schritt.

## v0.0.20.355 — Browser Scope-Badges + Distortion Automation Guard

- [x] FIXED (GPT-5, 2026-03-08): Kleine **Scope-Badges direkt im Browser/Add-Flow** ergänzt (Instruments / Effects / Favorites / Recents), damit vor dem Hinzufügen sichtbar ist, dass Browser-Add weiter nur auf die **aktive Spur** zielt.
- [x] FIXED (GPT-5, 2026-03-08): Die Scope-Badges werden jetzt **trackbezogen aktualisiert**, sobald die aktive Spur wechselt.
- [x] FIXED (GPT-5, 2026-03-08): Safe Guard gegen den gemeldeten **DistortionFxWidget Automation-Callback auf gelöschte Slider/Spinboxen** ergänzt.
- [ ] AVAILABLE: Optional die Scope-Badges zusätzlich in **Plugins** und ggf. weiteren Browser-Tabs spiegeln, weiterhin UI-only.
- [ ] AVAILABLE: **Echte Group-Track / Group-Bus Device-Chain wie in Bitwig** bleibt ein separater Routing-/Mixer-Schritt und ist in diesem Safe-Block bewusst noch nicht umgesetzt.

## v0.0.20.354 — DevicePanel Gruppen-/Spur-Zieltrennung klarer

- [x] FIXED (GPT-5, 2026-03-08): DevicePanel zeigt jetzt eine zusätzliche **Aktive Spur-Ziel**-Hinweisbox; sichtbare Device-Kette unten wird klar als **aktive Spur** ausgewiesen, Gruppen-Aktionen separat als **NOTE→Gruppe / AUDIO→Gruppe** erklärt.
- [ ] AVAILABLE: Kleine **Scope-Badge direkt im Browser/Add-Flow** ergänzen, damit schon vor dem Hinzufügen klar ist, ob das Ziel die **aktive Spur** oder die **ganze Gruppe** ist.

## v0.0.20.353 — TrackList Drop-Markierung beim Maus-Reorder

- [x] FIXED (GPT-5, 2026-03-08): **Sichtbare Drop-Markierung in der linken Arranger-TrackList** ergänzt, damit beim Maus-Verschieben klar erkennbar ist, an welcher Position Spur oder Block eingefügt wird.
- [x] FIXED (GPT-5, 2026-03-08): Die Markierung reagiert sicher auf **same-widget Reorder-Drags** und bleibt damit vom bestehenden **Cross-Project-Track-Drag** getrennt.
- [ ] AVAILABLE: Optional die **Drop-Markierung zusätzlich als kleine Ziel-Highlight-Zone** pro Zeile erweitern, weiterhin ohne Routing-/DSP-Eingriff.
- [ ] AVAILABLE: Die **Gruppen-/Track-FX-Zieltrennung** im DevicePanel optional noch deutlicher visualisieren; echter Gruppenbus bleibt weiterhin ein separater Core-Schritt.

## v0.0.20.352 — Gruppenkopf-Mausdrag + Doppelklick-Umbenennen

- [x] FIXED (GPT-5, 2026-03-08): **Gruppenkopf in der Arranger-TrackList per Maus als kompletter Block verschiebbar** gemacht, ohne den bestehenden Cross-Project-Track-Drag anzutasten.
- [x] FIXED (GPT-5, 2026-03-08): **Doppelklick auf Track-/Gruppennamen** öffnet jetzt sicher den bestehenden Umbenennen-Dialog.
- [x] FIXED (GPT-5, 2026-03-08): DevicePanel-Gruppenhinweis klarer gemacht: **normales Add-to-Device wirkt nur auf die aktive Spur**, **N→G / A→G** auf die ganze Gruppe.

## v0.0.20.351 — Arranger Maus-Reorder in TrackList

- [x] FIXED (GPT-5, 2026-03-08): **Maus-Drag-Reorder im linken Arranger-Bereich** ergänzt, inklusive sicherem **Mehrfachauswahl-Blockmove** und ohne den bestehenden **Cross-Project-Track-Drag** zu brechen.
- [ ] AVAILABLE: Optional **Gruppenkopf ebenfalls per Maus als kompletter Block** verschiebbar machen, weiterhin ohne Routing-/DSP-Eingriff.
- [ ] AVAILABLE: Optional eine kleine **Drop-Ziel-Markierung** in der TrackList ergänzen, damit die Einfügeposition beim Maus-Drag noch klarer wird.

## v0.0.20.350 — Arranger Gruppen-Alignment + sichtbare Verschiebe-Pfeile

- [x] FIXED (GPT-5, 2026-03-08): **Ausgeklappte Gruppen im Arranger-Canvas an die linke TrackList angeglichen**: Gruppenkopf und alle Mitgliedsspuren werden jetzt korrekt untereinander gezeigt, statt dass Spuren optisch verschwinden oder zusammenrutschen.
- [x] FIXED (GPT-5, 2026-03-08): Das Gruppen-Alignment gilt jetzt sicher auch für **Audio- und Busspuren** innerhalb derselben Gruppendarstellung.
- [x] FIXED (GPT-5, 2026-03-08): **Sichtbare ▲/▼-Buttons direkt in Track-/Gruppenzeilen** ergänzt, damit das Verschieben nicht nur über Kontextmenü, sondern direkt im Arranger-Header funktioniert.
- [x] FIXED (GPT-5, 2026-03-08): **Gruppenkopf als kompletter Block nach oben/unten verschiebbar** gemacht, ohne Audio-/Routing-Core anzufassen.
- [ ] AVAILABLE: **Track-Reorder per Drag & Drop** separat evaluieren; nur sinnvoll, wenn Cross-Project-Drag dabei sicher erhalten bleibt.
- [ ] AVAILABLE: **Gruppenkopf-Lane im Canvas** optional noch mit kompakterem Titel/Badge visuell verfeinern.
- [ ] AVAILABLE: **Echte Audio-Gruppenbusse** weiterhin strikt getrennt als späteren Routing-/Mixer-Schritt behandeln.

## v0.0.20.349 — Gruppen-Fold-State + Arranger-Gruppen-Lane + Track-Reorder

- [x] FIXED (GPT-5, 2026-03-08): **Gruppen-Einklappstatus projektseitig gespeichert** (`arranger_collapsed_group_ids`), damit Fold-State beim Speichern/Laden erhalten bleibt.
- [x] FIXED (GPT-5, 2026-03-08): **Gruppen im Arranger-Canvas als eine Lane im eingeklappten Zustand** sichtbar gemacht; Clips aller Mitglieder laufen dann sicher auf einer gemeinsamen Gruppen-Lane zusammen.
- [x] FIXED (GPT-5, 2026-03-08): **Spuren im Arranger-Kontextmenü nach oben/unten verschiebbar** gemacht, damit neu angelegte Instrument-/Audio-/Busspuren sauber umsortiert werden können.
- [x] FIXED (GPT-5, 2026-03-08): **Neue Spur direkt in eine bestehende Gruppe einfügen** ergänzt (Gruppenkopf-Menü + Track-Menü „In diese Gruppe hinzufügen“), damit neue Instrumente/Busse nicht mehr nur unterhalb der Gruppe landen.
- [ ] AVAILABLE: **Collapsed Group Lane** optional um kleine kompakte Summen-/Member-Hinweise direkt im Canvas ergänzen, rein visuell.
- [ ] AVAILABLE: **Gruppen-Spur verschieben** optional als kompletter Block (alle Mitglieder zusammen) ergänzen; separat planen, weil das Verhalten klar definiert werden sollte.
- [ ] AVAILABLE: **Echte Audio-Gruppenbusse** weiterhin getrennt als späteren Routing-/Mixer-Schritt behandeln, nicht in diesem UI-safe Block.

## v0.0.20.348 — Master-FX / Global Undo / Arranger-Menü-Hotfixes

- [x] FIXED (GPT-5, 2026-03-08): **Master-Audio-FX hörbar gemacht**: Summen-/Master-FX werden jetzt im Master-Mixpfad wirklich verarbeitet.
- [x] FIXED (GPT-5, 2026-03-08): **Globales Projekt-Undo/Redo** per sicherem Snapshot-Fallback ergänzt, damit viele bislang undo-lose Projektänderungen rückgängig gemacht werden können.
- [x] FIXED (GPT-5, 2026-03-08): **Ctrl+Z / Ctrl+Shift+Z / Ctrl+Y** zusätzlich als globale Application-Shortcuts verdrahtet.
- [x] FIXED (GPT-5, 2026-03-08): **Track-Kontextmenü repariert/erweitert**: **Umbenennen**, **Track löschen**, **Instrument-/Audio-/Bus-Spur hinzufügen**.
- [x] FIXED (GPT-5, 2026-03-08): **Gruppenkopf einklappbar** im Arranger umgesetzt.
- [ ] AVAILABLE: **Gruppen-Einklappstatus projektseitig speichern**, damit Fold-State beim erneuten Laden erhalten bleibt.
- [ ] AVAILABLE: **Undo-Labels** für größere UI-Aktionen gezielter benennen statt generischem Snapshot-Label.
- [ ] AVAILABLE: **Master-DeviceCard** optisch noch klarer als Summenkanal ausweisen (rein UI-seitig).

## v0.0.20.347 — Arranger Track-/Gruppen-Flow + Gruppen-Sektion im DevicePanel

- [x] FIXED (GPT-5, 2026-03-08): **Clip → Track-Auswahl synchronisiert**: wenn im Arranger ein MIDI-/Audio-Clip aktiv ausgewählt wird, wird jetzt auch seine zugehörige Spur im Track-Header mit ausgewählt.
- [x] FIXED (GPT-5, 2026-03-08): **Rechtsklick-Menü direkt auf Track-/Instrument-Zeilen** im Arranger ergänzt, inkl. **Umbenennen**, **Auswahl gruppieren**, **Gruppe umbenennen**, **Gruppe auflösen**, Devices/Browser sowie bestehende Track-Aktionen.
- [x] FIXED (GPT-5, 2026-03-08): **Spurgruppierung visuell als echte Sektion** im Arranger-Trackbereich dargestellt: Gruppenkopf + eingerückte Mitglieder untereinander, ohne Eingriff in Playback-/Mixer-Core.
- [x] FIXED (GPT-5, 2026-03-08): **Gruppen-Sektion im DevicePanel** ergänzt: sichtbare Mitgliederliste plus sichere Batch-Aktionen **N→G** / **A→G**, um NOTE-FX bzw. AUDIO-FX auf alle Tracks der aktuellen Gruppe anzuwenden.
- [ ] AVAILABLE: **Gruppen-Kopf einklappbar** machen (nur UI), damit große Orchester-/Chorgruppen im Arranger kompakter werden.
- [ ] AVAILABLE: **Gruppen-DevicePanel** optional um eine kleine **Bypass-/Mute-Übersicht pro Mitglied** erweitern, weiterhin ohne Engine-/Routing-Umbau.
- [ ] AVAILABLE: **Echte Gruppen-Bus-/Summen-Spur** als späteren Architektur-Schritt separat planen, erst nach expliziter Freigabe, weil das ein Core-/Routing-Thema wäre.

## v0.0.20.338 — AETERNA Live ARP / Readability / Safe Note-FX Bridge

- [x] FIXED (GPT-5, 2026-03-07): **AETERNA Arp A** kann jetzt sicher **Live an/aus** geschaltet werden, indem lokal ein vorhandenes **Track Note-FX Arp** für diese AETERNA-Spur gepflegt wird — ohne Playback-Core-Umbau.
- [x] FIXED (GPT-5, 2026-03-07): Die bereits vorhandenen **16 Step-Daten** von AETERNA Arp A werden jetzt auch für den sicheren **Track Note-FX Arp** genutzt (**Transpose / Skip / Velocity / Gate / Shuffle / Note Type**), damit Live-ARP und ARP→MIDI näher zusammenliegen.
- [x] FIXED (GPT-5, 2026-03-07): **AETERNA-Readability** lokal weiter angehoben: etwas größere Card-/Hint-Schriften sowie klarerer **ARP Live / ARP→MIDI**-Header.
- [ ] AVAILABLE: Lokale **AETERNA-Familienkarten** noch weiter verdichten (z. B. kompakte Mini-Meter oder aktive Mod-Ziel-Badges direkt im Card-Kopf), nur Widget/State.
- [ ] AVAILABLE: Lokale **Signalfluss-Ansicht** noch feiner staffeln (z. B. aktive Slot-Ziele farbig im passenden Ziel-Bucket hervorheben), nur im AETERNA-Widget.

## v0.0.20.335 — Nächster sichere AETERNA-Polish-Block

- [x] FIXED (GPT-5, 2026-03-07): Größeren lokalen **AETERNA-Polish-Block** umgesetzt: stärkere **Farbtrennung**, neue **Familien-Legende**, deutlichere **Familienkarten** und eine kleine **grafische Signalfluss-Ansicht** direkt im Instrument, weiterhin ohne Core-Umbau.
- [x] FIXED (GPT-5, 2026-03-07): Bisher intern schon vorgesehene **Pitch / Shape / Pulse Width**- sowie **Drive / Feedback**-Familien jetzt auch als echte sichtbare **Synth-Panel-Karten mit Knobs** im Widget ergänzt, weiterhin nur lokal in AETERNA.
- [ ] AVAILABLE: Lokale **AETERNA-Familienkarten** noch weiter verdichten (z. B. kompakte Mini-Meter oder aktive Mod-Ziel-Badges direkt im Card-Kopf), nur Widget/State.
- [ ] AVAILABLE: Lokale **Signalfluss-Ansicht** noch feiner staffeln (z. B. aktive Slot-Ziele farbig im passenden Ziel-Bucket hervorheben), nur im AETERNA-Widget.

## v0.0.20.329 — Nächste sichere AETERNA-Mod-Rack-/Synth-Schritte

- [ ] AVAILABLE: Lokale **AETERNA-Targets** optional noch kompakter nach **Klang / Raum / Bewegung** gliedern, weiterhin nur im Widget.
- [x] FIXED (GPT-5, 2026-03-07): Lokales **AETERNA-SYNTH PANEL Stage 1** mit bereits stabilen Parametern aufgebaut und lesbar gruppiert.
- [x] FIXED (GPT-5, 2026-03-07): Lokales **AETERNA-SYNTH PANEL Stage 2** mit echtem **Filter Cutoff / Resonance / Filter Type** ergänzt.
- [x] FIXED (GPT-5, 2026-03-07): Lokales **AETERNA-SYNTH PANEL Stage 3** in sicheren Familien gestartet: zuerst **Voice** (**Pan / Glide / Retrig / Stereo-Spread**) und **AEG/FEG ADSR**.
- [ ] AVAILABLE: Nächste Stage-3-Familien weiterführen: **Unison/Voices/Detune**, **Sub/Sub-Oktave**, **Shape/Pulse Width**, **Noise**, **Drive/Feedback** — nur schrittweise und nie alles auf einmal.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-SYNTH PANEL Stage 3** um die Familie **Unison / Sub / Noise** erweitert: echte Klangparameter, lokale Comboboxen für **Voices**/**Sub-Oktave** sowie stabile Automation-/Mod-Ziele für **Unison Mix / Unison Detune / Sub Level / Noise Level / Noise Color**.
- [ ] AVAILABLE: Nächste Stage-3-Familien weiterführen: **Pitch/Shape/Pulse Width** sowie **Drive/Feedback** — weiterhin nur schrittweise und nur lokal in AETERNA.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA-Mod-Rack zeigt jetzt lokale **Amount-/Polaritätsanzeigen** direkt an den realen Web-A/B-Slots.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA hat jetzt eine kleine lokale **Signalfluss-Linienansicht** für die aktiven Web-A/B-Wege.

## v0.0.20.326 — Nächste sichere Bounce/Freeze- und AETERNA-Schritte

- [ ] AVAILABLE: **Bounce in Place** optional um einen kleinen lokalen Dialog ergänzen (z. B. Quelle stummschalten / Dry / +FX), weiterhin ohne Playback-Core-Umbau.
- [ ] AVAILABLE: **Freeze Track / Group Freeze** optional um einen sichtbaren kleinen Statusmarker im Track-Namen oder Kontextmenü ergänzen, weiterhin projekt-/UI-seitig.
- [ ] AVAILABLE: Lokale **AETERNA Random-Math-/Formel-Familien** weiter ausbauen (z. B. mehr kohärente/noise-/chaos-inspirierte Startideen), weiterhin nur im Widget.
- [x] FIXED (GPT-5, 2026-03-07): Erste sichere **Bounce/Freeze-Workflows** ergänzt: **Bounce in Place → neue Audiospur**, **Spur einfrieren (+FX/Dry)**, **Gruppe einfrieren** bei vorhandener Track-Gruppe sowie **Freeze-Quellen wieder aktivieren** — ohne Playback-Core-Umbau.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA-Formelhilfen und Randomizer lokal um **breitere mathematische Familien** erweitert, damit nicht immer nur reine **phase**-Varianten im Vordergrund stehen.

## v0.0.20.324 — Nächste sichere AETERNA-Performance-Schritte

- [ ] AVAILABLE: Lokale **AETERNA-Ladeprofil-Hinweise** im Widget noch etwas sichtbarer machen (z. B. leichte Ready-/Staged-Init-Hinweise), weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Composer-Phrasenlängen/-Dichten** feiner staffeln, weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Snapshot-/Preset-Schnellaufrufe** optional noch um einen kleinen aktiven Fokusmarker ergänzen, weiterhin nur in AETERNA.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA lädt lokal spürbar sanfter: **Restore-Signale werden gebündelt**, **Komfort-Refreshes gestaffelt nachgezogen** und **Button-Rebinds ohne blindes disconnect()** aktualisiert — weiterhin nur im Widget.

## v0.0.20.321 — Nächste sichere AETERNA-Schritte

- [ ] AVAILABLE: Lokale **Automation-Hinweise** an den bereits sicheren AETERNA-Knobs noch klarer verdichten, weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Snapshot-Karte** optional noch um eine sehr kleine „zuletzt gespeichert/recallt“-Hinweiszeile ergänzen, weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Preset-/Snapshot-Schnellaufrufe** optional noch um kleine Statusfarben oder „aktiv“-Marker verfeinern, weiterhin nur im Widget.

- [x] FIXED (GPT-5, 2026-03-07): Lokale **Preset-/Snapshot-Kombis** sind jetzt als kleine **Schnellaufrufe** direkt im AETERNA-Widget sichtbar, inklusive kompakter Buttons und Tooltips für Recall/Load — ohne Core-Eingriff.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **Formel-/Web-Kombitipps** werden jetzt direkt an passenden AETERNA-Presets sichtbarer gezeigt, inklusive Preset-Fokus, Kurzlistenzeile und erweiterten Schnellpreset-Tooltips.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA-Preset-Kurzliste zeigt jetzt lokale **Direktmarker für Kategorie/Charakter** im Schnellbereich.

---

- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt einen lokalen **Automation-Schnellzugriff** für alle stabilen Knobs/Rates/Amounts, inklusive klarerer **musikalischer Tooltip-Hinweise** direkt an den Reglern.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-Snapshot-Slots** um kleine **Farbbadges/Statusmarker** erweitert, inklusive klarerem Slot-Tooltip und deaktiviertem Recall für leere Slots.
## v0.0.20.318 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Automation-Ziele** optional noch nach "Sweep / Bewegung / Raum" kompakter gruppieren, weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Preset-Kurzliste** optional um kleine Direktmarker für Kategorie/Charakter ergänzen, weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Snapshot-Karte** optional noch um eine sehr kleine „zuletzt gespeichert/recallt“-Hinweiszeile ergänzen, weiterhin nur im Widget.


- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-Presetbibliothek** kompakter nach **Kategorie/Charakter** zusammengefasst, inklusive aktivem Preset-Fokus und kompakter Bibliotheksübersicht direkt im Widget.

- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-Formel-/Preset-Empfehlungen** um kompakte **Hörhinweise** ergänzt.
## v0.0.20.315 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **AETERNA-Presetbibliothek** kompakter nach Charakter/Kategorie zusammenfassen, nur im Widget.
- [ ] AVAILABLE: Lokale **Snapshot-Slots** optional um kleine Farbbadges/kurze Statusmarker ergänzen, weiterhin nur im Widget.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **Automation-ready-Knob-Hinweise** in AETERNA kompakter gemacht, inklusive **Schnellzugriff** auf alle stabilen Automation-Lanes und klarerer Tooltip-Hinweise direkt an den Reglern.

- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-Snapshot-Karte** kompakter und musikalischer lesbar gemacht.
## v0.0.20.314 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Formel-/Preset-Empfehlungen** um kleine Hörhinweise ergänzen (z. B. sakral, klar, getragen), weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **AETERNA-Presetbibliothek** kompakter nach Charakter/Kategorie zusammenfassen, nur im Widget.
- [ ] AVAILABLE: Lokale **Snapshot-Slots** optional um kleine Farbbadges/kurze Statusmarker ergänzen, weiterhin nur im Widget.

- [x] 2026-03-07 AETERNA: Web-Vorlagen Basis-Reset lokal ergänzt, inkl. Save/Load von aktivem Web-Template.
## v0.0.20.311 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Formel-/Preset-Empfehlungen** um kleine Hörhinweise ergänzen (z. B. sakral, klar, getragen), weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **AETERNA-Presetbibliothek** kompakter nach Charakter/Kategorie zusammenfassen, nur im Widget.
- [ ] AVAILABLE: Lokale **Web-Vorlagen** optional um eine kleine klare **„Reset auf Basiswerte“**-Funktion ergänzen, weiterhin nur lokal in AETERNA.

- [x] FIXED (GPT-5, 2026-03-07): Lokale **Web-Intensitätsstufen** für AETERNA-Startvorlagen ergänzt (**Sanft / Mittel / Präsent**), inklusive sauberem Save/Load im Instrument-State.

## v0.0.20.309 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **AETERNA-Presetbibliothek** kompakter nach Charakter/Kategorie zusammenfassen, nur im Widget.
- [ ] AVAILABLE: Lokale **Formel-/Preset-Empfehlungen** optional um kleine Hörhinweise ergänzen (z. B. sakral, klar, getragen), weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Web-A/Web-B-Startvorlagen** ergänzen (z. B. langsam/lebendig/organisch), weiterhin nur in AETERNA.

- [x] FIXED (GPT-5, 2026-03-07): Lokale **Macro-A/B-Feinsteuerung** in AETERNA lesbarer gemacht, mit klarer Source→Target→Amount-Karte und kompakten Nutzungshinweisen.

## v0.0.20.308 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Macro-A/B-Feinsteuerung** lesbarer machen, weiterhin ohne DAW-Core-Eingriff.
- [ ] AVAILABLE: Lokale **AETERNA-Presetbibliothek** kompakter nach Charakter/Kategorie zusammenfassen, nur im Widget.
- [ ] AVAILABLE: Lokale **Formel-/Preset-Empfehlungen** optional um kleine Hörhinweise ergänzen (z. B. sakral, klar, getragen), weiterhin nur im Widget.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA zeigt jetzt lokal sichtbar, **welche Formelidee zum aktuellen Preset passt**, inklusive Lade-Button und Statuszeile.

## v0.0.20.307 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Formula-/Preset-Verknüpfung** sichtbarer machen (z. B. welches Preset nutzt aktuell welche Formelidee), nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **Macro-A/B-Feinsteuerung** lesbarer machen, weiterhin ohne DAW-Core-Eingriff.
- [ ] AVAILABLE: Lokale **Preset-Kurzliste** um kleine Herkunftshinweise ergänzen (z. B. sakral/kristall/drone), weiterhin nur im Widget.

- [x] FIXED (GPT-5, 2026-03-07): Lokale **Preset-Kurzliste** in AETERNA um einen sicheren **Filter** erweitert (Alle / Sakral / Kristall / Drone / Favoriten).

---

## v0.0.20.306 — Nächste sichere AETERNA-Phase-3b-Schritte

- lokale Preset-Kurzliste optional um intelligente Filter (z. B. sakral / kristall / drone) erweitern
- kuratierte Formel-Preset-Karte weiter ausbauen
- weitere vorsichtige Klangverfeinerung nur lokal in AETERNA
- weiterhin keine Core-Eingriffe

## v0.0.20.304 — Nächste sichere AETERNA-Schritte nach Kristall-/Formel-Upgrade
- [ ] AVAILABLE: Lokale **Formel-Preset-Karte** noch kompakter mit kleinen Stil-Hinweisen (z. B. ruhig / sakral / organisch / drone) ergänzen, weiterhin nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **AETERNA-Knob-Hinweise** für langsame Sweeps vs. lebendige Modulation noch klarer ausweisen, ohne Core-Eingriff.
- [ ] AVAILABLE: Optional ein lokales **"Klar/Weich"-Voicing-Preset** für AETERNA ergänzen, weiterhin nur innerhalb des Instruments.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt zusätzliche kuratierte **Formel-Startbeispiele** (**Organisch**, **Drone**), ein lokales **klareres/kristallineres Voicing** und den lokalen Bugfix **`get_formula_status()`** für die Formelstatus-Anzeige.

## v0.0.20.303 — Nächste sichere AETERNA-Schritte nach Formel-Infozeile
- [ ] AVAILABLE: Kuratierte lokale **Formel-Preset-Karte** um weitere musikalische Startbeispiele (z. B. Organisch / Drone) ergänzen, weiterhin nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **Automation-ready**-Hinweise direkt an ausgewählten AETERNA-Knobs kompakter machen, ohne Core-Eingriff.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt eine lokale **Formel-Infozeile**, die klar zwischen **Beispiel geladen**, **manuell geändert**, **angewendet** und **noch nicht angewendet** unterscheidet.

## v0.0.20.302 — Nächste sichere AETERNA-Schritte nach freigegebenen Automationszielen

- [ ] AVAILABLE: Kleine lokale **Formel-Infozeile** ergänzen, die zeigt, ob ein Startbeispiel nur im Feld steht oder bereits angewendet wurde.
- [ ] AVAILABLE: Lokale **AETERNA-Makros/Knobs** optional um eine noch kompaktere **"Automation-ready"-Kurzansicht** direkt an den Reglern ergänzen, weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Kuratierte lokale **Formel-Preset-Karte** erweitern (z. B. Organisch / Drone), weiterhin nur im AETERNA-Widget.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA zeigt jetzt klar die **bereits lokal freigegebenen stabilen Automationsziele** (Knobs, Rates, Amounts) und erklärt die sichere Nutzung per **Rechtsklick → Show Automation in Arranger**.

---

## v0.0.20.301 — Nächste sichere AETERNA-Schritte nach lokaler Automation-Zielkarte

- [ ] AVAILABLE: Kleine lokale **Formel-Infozeile** ergänzen, die erklärt, ob ein Startbeispiel erst im Feld steht oder schon angewendet wurde.
- [ ] AVAILABLE: Lokale **Formel-Preset-Hinweise** noch deutlicher mit Preset-Metadaten verknüpfen, weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Automation-Ziele** optional um kurze Hinweise ergänzen, welche Ziele eher für langsame Sweeps und welche für lebendige Modulation sinnvoll sind.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt eine kompakte lokale **Automation-Zielkarte** mit klar benannten Gruppen und Sicherheits-Hinweis.

---

---

## v0.0.20.300 — Nächste sichere AETERNA-Schritte nach Phase 3a safe

- [ ] AVAILABLE: Lokale **Automation-Ziele** in AETERNA als kompakte, klar benannte Kurzliste/Karte sichtbar machen.
- [ ] AVAILABLE: Kleine lokale **Formel-Infozeile** ergänzen, die erklärt, ob ein Startbeispiel erst im Feld steht oder schon angewendet wurde.
- [ ] AVAILABLE: Lokale **Formel-Preset-Hinweise** noch deutlicher mit Preset-Metadaten verknüpfen, weiterhin nur im Widget.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt eine kompakte lokale **Badge-/Kurzansicht** für Preset-Metadaten direkt im Widget.

---

## v0.0.20.299 — Nächste sichere AETERNA-Phase-3a-Schritte

- [ ] AVAILABLE: Kleine lokale **Formel-Infozeile** ergänzen, die erklärt, ob ein Startbeispiel erst im Feld steht oder schon angewendet wurde.
- [ ] AVAILABLE: Lokale **Preset-Metadaten** in AETERNA noch klarer zusammenfassen (z. B. Badge-/Kurzansicht), weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Formel-Preset-Hinweise** noch deutlicher mit Preset-Metadaten verknüpfen, weiterhin nur im Widget.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt lokale **Preset-Metadaten mit Tags/Favorit**, weiterhin nur im Widget/State von AETERNA.


---

## v0.0.20.298 — Nächste sichere AETERNA-Phase-3a-Schritte

- [ ] AVAILABLE: Lokale **Formel-Makro-Slots** noch lesbarer gruppieren (z. B. Sound / Zeit / Chaos), weiterhin nur in AETERNA.
- [ ] AVAILABLE: Lokale **Preset-Metadaten** optional um Tags/Favorit erweitern, weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Kleine lokale **Formel-Infozeile** ergänzen, die erklärt, ob ein Startbeispiel erst im Feld steht oder schon angewendet wurde.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt eine lokale **Formel-Startkarte / Onboarding-Hilfe** mit sicheren Beispiel-Buttons direkt im Widget.

---

## v0.0.20.297 — Nächste sichere AETERNA-Phase-3a-Schritte

- [ ] AVAILABLE: Lokale **Formel-Startkarte / Onboarding-Hilfe** ergänzen, nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **Formel-Makro-Slots** noch lesbarer gruppieren (z. B. Sound / Zeit / Chaos), weiterhin nur in AETERNA.
- [ ] AVAILABLE: Lokale **Preset-Metadaten** optional um Tags/Favorit erweitern, weiterhin ohne Core-Eingriff.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA Formel-Eingabe wieder nutzbar gemacht (**mehrzeiliges Edit-Feld**) und **lokale Preset-Metadaten** ergänzt.

---

## v0.0.20.295 — Nächste sichere AETERNA-Phase-3a-Schritte

- [ ] AVAILABLE: Lokale **Formel-Makro-Slots** noch lesbarer gruppieren (z. B. Sound / Zeit / Chaos), weiterhin nur in AETERNA.
- [ ] AVAILABLE: Lokale **Formel-Hilfe** um ein kleines Beispiel-Panel ergänzen, weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Preset-Metadaten** ergänzen (z. B. Snapshot-Info oder kleiner Kommentar), weiterhin ohne Core-Eingriff.

- [x] FIXED (GPT-5, 2026-03-06): AETERNA Phase 3a safe erweitert: **Formel-Aliase** plus **sichtbare Formel-Mod-Slots** im Widget.

---

## v0.0.20.294 — Nächste sichere AETERNA-Phase-3a-Schritte

- [ ] AVAILABLE: Lokale **Formel-Mod-Slots** lesbar ergänzen (z. B. kleine Liste der aktuell genutzten Formelquellen), weiterhin nur in AETERNA.
- [ ] AVAILABLE: Lokale **Formel-Hilfe** noch klarer machen (z. B. Wrapping-Buttons oder Makro-Snippets), weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Preset-Metadaten** ergänzen (z. B. Snapshot-Info oder kleiner Kommentar), weiterhin ohne Core-Eingriff.

- [x] FIXED (GPT-5, 2026-03-06): AETERNA Phase 3a safe erweitert: **LFO/MSEG/Chaos-Formelhilfen** per **Klick** und **Drag&Drop** direkt in die Formel.


## v0.0.20.293 — Nächste sichere AETERNA-Phase-3a-Schritte

- [ ] AVAILABLE: Lokale **Phase-3a-Ansicht** weiter vereinfachen (z. B. noch klarere Basic/Advanced-Trennung nur in AETERNA).
- [ ] AVAILABLE: Lokale **Preset-Metadaten** ergänzen (z. B. Snapshot-Info oder kleiner Kommentar), weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Automation-Listen** optional noch kompakter machen (z. B. nur lesbare Namen statt Keys), weiterhin nur im AETERNA-Widget.

- [x] FIXED (GPT-5, 2026-03-06): AETERNA Phase 3a safe erweitert: **Preset A/B** plus **klarere Automation-Zielsektionen** im Phase-3a-Bereich.


---

## v0.0.20.305 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Preset-Kurzliste/Favoritenansicht** in AETERNA ergänzen, damit sakrale/kristalline Presets schneller auffindbar sind.
- [ ] AVAILABLE: Lokale **Formula-/Preset-Verknüpfung** sichtbarer machen (z. B. welches Preset nutzt aktuell welche Formelidee), nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **Macro-A/B-Feinsteuerung** lesbarer machen, weiterhin ohne DAW-Core-Eingriff.

---

## v0.0.20.310 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Web-A/Web-B-Feinmischung** um kleine Intensitätsstufen ergänzen (z. B. sanft / mittel / präsent), nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **Formel-/Web-Verknüpfung** sichtbarer machen (z. B. welche Web-Vorlage passt zu welcher Formelidee), ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Preset-/Web-Kombis** als kleine Kurztipps ergänzen, weiterhin nur in AETERNA.


## v0.0.20.313 — Nächste sichere AETERNA-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Lokale **Snapshot-Hinweise** in AETERNA weiter verdichtet: Badges, Tooltips, Recall-Status und neue **„Zuletzt: Store/Recall …“**-Hinweiszeile direkt an der Snapshot-Karte.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **Formel-/Web-Kombitipps** pro Preset ergänzt, damit der passende Startweg direkt sichtbar wird.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **Preset-/Snapshot-Kombis** als kleine Schnellaufrufe direkt im Widget sichtbar gemacht.
---

## v0.0.20.322 — Nächste sichere lokale AETERNA-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Lokale **Snapshot-Slot-Kurznamen** ergänzt (automatisch aus Preset/Hörbild abgeleitet), weiterhin nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **Snapshot-Vergleichshinweise** kompakter machen (z. B. was sich zwischen aktivem Zustand und Recall-Slot grob ändert), ohne Engine-/Core-Eingriff.
- [ ] AVAILABLE: Lokale **Preset-/Snapshot-Schnellaufrufe** optisch feiner staffeln (z. B. aktiver Slot klarer markiert), nur im Widget.

## v0.0.20.323 — Nächste sichere lokale AETERNA-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Lokalen **AETERNA Composer** mit Dreiecks-Menü ergänzt: mathematischer Weltstil-Mix für **Bass / Melodie / Lead / Pad / Arp** direkt als MIDI-Clip auf der aktuellen AETERNA-Spur, ohne Drum-Logik und ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **AETERNA-Composer-Vergleichshinweise** ergänzen (z. B. aktuelle Stil-Mischung vs. letzter Seed), weiterhin nur im Widget/State.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-Composer-Phrasenlängen/-Dichten** feiner gestaffelt: neue lokale Phrasenprofile und Dichteprofile im Widget, weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Snapshot-Vergleichshinweise** mit Composer-Kontext verbinden (z. B. ob Recall eher Bass/Pad/Lead-lastig ist), weiterhin ohne Engine-/Core-Eingriff.



## v0.0.20.325 — Nächste sichere lokale AETERNA-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-Ladezeit sichtbar gemacht** (Build / Restore / staged Refresh) direkt im Widget, ohne globales Profiling.
- [ ] AVAILABLE: Lokale **AETERNA-Composer-Vergleichshinweise** ergänzen (z. B. aktueller Mix vs. letzter Seed), weiterhin nur im Widget/State.
- [ ] AVAILABLE: Lokale **Snapshot-Vergleichshinweise** mit Composer-Kontext verbinden (z. B. Recall eher Bass/Pad/Lead-lastig), weiterhin ohne Engine-/Core-Eingriff.
- [ ] AVAILABLE: Lokale **AETERNA-Ladeprofil-Historie** kompakt ergänzen (z. B. letzter Restore vs. aktueller Restore), weiterhin nur im Widget.


## v0.0.20.327 — Nächste sichere Bounce/Freeze- und AETERNA-Schritte

- [ ] AVAILABLE: Kleinen **Freeze-Status im Arranger-Header** sichtbar machen, weiterhin ohne Playback-Core-Umbau.
- [ ] AVAILABLE: **Bounce/Freeze-Dialog** optional um „Proxy sofort solo/selektieren“ ergänzen, nur UI-seitig.
- [ ] AVAILABLE: AETERNA lokal um noch klarere **Math-/Random-Familien-Kategorien** im Formelbereich ergänzen, weiterhin ohne Engine-Eingriff.

## v0.0.20.330 — Nächste sichere AETERNA-Synth-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Lokales **AETERNA Synth Panel Stage 1** ergänzt: vorhandene stabile Parameter lesbar gruppiert, Bereichs-Navigation hinzugefügt und sichere UI-Preview für spätere Familien reserviert.
- [x] FIXED (GPT-5, 2026-03-07): Ersten echten **Filter-Block** nur in AETERNA ergänzt (**Cutoff / Resonance / Type**) – mit lokalem UI, Save/Load, stabiler Automation sowie lokalen Mod-Rack-Zielen, weiterhin ohne DAW-Core-Umbau.
- [x] FIXED (GPT-5, 2026-03-07): Größeren **Voice-Block** in AETERNA als zusammenhängende Familie ergänzt (**Pan / Glide / Retrig / Stereo-Spread**), inklusive lokaler UI, Save/Load, stabiler Automation für die kontinuierlichen Parameter und echter Audio-Wirkung innerhalb von AETERNA.
- [x] FIXED (GPT-5, 2026-03-07): Nächste **Envelope-Familie** in AETERNA gebündelt (**AEG ADSR / FEG ADSR** als lokale UI + State + sichere Audio-Wirkung), inklusive Filter-Envelope-Amount.
- [ ] AVAILABLE: Nächsten **Unison/Sub/Noise-Block** als eigene sichere Ausbau-Familie ergänzen, lokal in AETERNA und mit klarer Einklapp-/Signalflussdarstellung.
- [ ] AVAILABLE: Danach einen **Pitch/Shape/Pulse-Width-Block** als eigene sichere Familie ergänzen, lokal in AETERNA und ohne Core-Umbau.
- [ ] AVAILABLE: Anschließend **Drive/Feedback** als separate sichere Klangfamilie ergänzen, lokal in AETERNA und mit klarer Warn-/Stabilitätstrennung.



## v0.0.20.334 — Nächste sichere AETERNA-Synth-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Gebündelten lokalen **Pitch / Shape / Pulse Width**-Block in AETERNA ergänzt — mit echter Klangwirkung, Save/Load, Randomize, stabilen Automation-Zielen und lokalen Mod-Rack-Zielen, ohne Core-Umbau.
- [x] FIXED (GPT-5, 2026-03-07): Gebündelten lokalen **Drive / Feedback**-Block in AETERNA ergänzt — mit echter Audio-Wirkung, Save/Load, Randomize, stabilen Automation-Zielen und lokalen Mod-Rack-Zielen, weiterhin nur in AETERNA.
- [ ] AVAILABLE: Lokale **AETERNA-Unison/Sub/Noise-UX** weiter verdichten (z. B. kleine Voices-/Oktav-Hinweise direkt an den Familienkarten), nur Widget/State.
- [ ] AVAILABLE: Lokale **AETERNA-Mod-Rack-Visualisierung** für die neuen Pitch/Timbre-/Drive-Ziele weiter ausbauen (z. B. stärkere Zielhervorhebung), ohne Core-Eingriff.
- [ ] AVAILABLE: Nächsten sicheren **Feinpolish-Block** für AETERNA angehen (z. B. kompaktere Familienkarten, stärkere Farbtrennung, klarere Signalfluss-Linien), weiterhin lokal im Instrument.


## v0.0.20.336 — Nächste sichere AETERNA-UX-Schritte

- [x] FIXED (GPT-5, 2026-03-07): **Layer-Schnellschalter** im AETERNA Synth Panel repariert: die bisher irreführenden Vorschau-Checkboxen für **Unison / Sub / Noise** schalten jetzt die realen Layer-Level direkt lokal an/aus.
- [x] FIXED (GPT-5, 2026-03-07): **Familienkarten** um lokale **aktive Mod-Ziel-Badges** und kompakte **Mini-Meter** ergänzt, weiterhin nur im AETERNA-Widget.
- [x] FIXED (GPT-5, 2026-03-07): Kleine **Mini-Meter direkt an einzelnen AETERNA-Synth-Knobs** ergänzt, weiterhin nur Widget/State.
- [ ] AVAILABLE: **Layer-Voices/Sub-Oktave** noch direkter in den Familienkarten hervorheben, ohne Engine-Eingriff.


## v0.0.20.337 — Nächste sichere AETERNA-ARP-/Mod-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Lokalen **AETERNA Arp A (LOCAL SAFE)** ergänzt — als **Clip-Arpeggiator** nur für die aktuelle AETERNA-Spur, mit Pattern, Rate, Straight/Dotted/Triplets, 16 Steps sowie pro-Step **Transpose / Skip / Velocity / Gate**.
- [x] FIXED (GPT-5, 2026-03-07): **Per-Knob-Kontextmenü** in AETERNA erweitert: Rechtsklick bietet jetzt **Show Automation in Arranger** und **Add Modulator** (LFO1/LFO2/MSEG/Chaos/ENV/VEL) direkt für den angeklickten Ziel-Knob.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **Knob-Mod-Profilzustände** pro AETERNA-Ziel ergänzt, damit jeder Knob seinen eigenen gespeicherten Mod-Zuweisungszustand behalten kann.
- [x] FIXED (GPT-5, 2026-03-07): **Readability-Polish** lokal in AETERNA verstärkt (größere Karten-/Hint-Schriften, lesbarere Signalfluss-Karte, höhere Controls).
- [ ] AVAILABLE: **Arp B** als zweite lokale AETERNA-Instanz ergänzen (erst nach Praxistest von Arp A).
- [ ] AVAILABLE: **Per-Knob-Mod-Profile** später um frei speicherbare Amount-/Polaritäts-Presets erweitern, weiterhin lokal im Widget/State.
- [x] FIXED (GPT-5, 2026-03-07): Kleine **Knob-Mini-Meter** direkt an wichtigen AETERNA-Synth-Zielen sichtbar gemacht; aktive Mod-Badges werden jetzt pro Knob kompakt angedeutet.


## v0.0.20.340 — Nächste sichere AETERNA-/Qt-Schritte

- [x] FIXED (GPT-5, 2026-03-07): **Layer-Voices/Sub-Oktave** in den AETERNA-Familienkarten deutlicher sichtbar gemacht, weiterhin nur Widget/State.
- [x] FIXED (GPT-5, 2026-03-07): Den **Qt-/Selection-Rekursionspfad** aus dem GDB-Log gezielt lokal entschärft: Refresh-/Signalguards für TrackList, Arranger-TrackList, Automation-Lanes sowie koaleszierter AETERNA-Refresh bei Live-ARP.
- [ ] AVAILABLE: Den **AETERNA-ARP-Live-Pfad** nach Praxistest weiter verhärten (z. B. noch gezieltere Diff-Erkennung der Note-FX-Params), weiterhin ohne Playback-Core-Umbau.
- [ ] AVAILABLE: Die **Layer-/Noise-Familienkarten** zusätzlich um kleine **Mode-/Voices-Badges** verdichten, weiterhin rein lokal im Widget.
