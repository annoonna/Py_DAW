# -*- coding: utf-8 -*-
"""Device-Rack widgets for Note-FX + Audio-FX (Bitwig/Ableton style).

Goal:
- FX are visible as modules in the bottom Device panel.
- Each module owns a tiny MVP parameter UI (no right-browser editor needed).

This file intentionally stays lightweight — no heavy dependencies.
"""
from __future__ import annotations

import os
from typing import Any, Optional

from PyQt6.QtCore import Qt, QTimer, QSignalBlocker
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QDial, QSlider, QDoubleSpinBox, QSpinBox, QComboBox,
    QPushButton, QLineEdit, QGroupBox, QFormLayout, QFileDialog, QMessageBox, QMenu
)

try:
    # Optional widgets used by some devices (keep imports resilient).
    from PyQt6.QtWidgets import QScrollArea
except Exception:  # pragma: no cover
    QScrollArea = None


def _find_track(project: Any, track_id: str):
    try:
        for t in getattr(project, "tracks", []) or []:
            if getattr(t, "id", "") == track_id:
                return t
    except Exception:
        pass
    return None


def _get_automation_manager(services: Any):
    try:
        return getattr(services, "automation_manager", None) if services is not None else None
    except Exception:
        return None


def _qt_is_deleted(obj: Any) -> bool:
    if obj is None:
        return True
    try:
        from PyQt6 import sip  # type: ignore
        return bool(sip.isdeleted(obj))
    except Exception:
        try:
            import sip  # type: ignore
            return bool(sip.isdeleted(obj))
        except Exception:
            return False


def _qt_widgets_alive(*objs: Any) -> bool:
    try:
        return all(not _qt_is_deleted(obj) for obj in objs)
    except Exception:
        return False


def _register_automatable_param(services: Any, track_id: str, parameter_id: str, name: str,
                                min_val: float, max_val: float, default_val: float):
    am = _get_automation_manager(services)
    if am is None:
        return None
    try:
        # Safe override: some embedded/device-local FX (e.g. Pro Drum slot FX)
        # need a dedicated RT parameter prefix, but should still appear under the
        # owning track in the Arranger automation UI.
        ui_track_id = str(getattr(services, 'automation_track_id', '') or track_id or "")
    except Exception:
        ui_track_id = str(track_id or "")
    try:
        return am.register_parameter(
            str(parameter_id),
            str(name),
            min_val=float(min_val),
            max_val=float(max_val),
            default_val=float(default_val),
            track_id=ui_track_id,
        )
    except Exception:
        return None


def _install_automation_menu(parent: QWidget, widget: QWidget, parameter_id: str, default_getter):
    try:
        widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
    except Exception:
        return

    def _show_menu(pos):
        try:
            am = _get_automation_manager(getattr(parent, '_services', None))
            if am is None or not parameter_id:
                return
            menu = QMenu(parent)
            act_show = menu.addAction('Show Automation in Arranger')
            act_mod = menu.addAction('Add Modulator (LFO/ENV) — coming soon')
            try:
                act_mod.setEnabled(False)
            except Exception:
                pass
            menu.addSeparator()
            act_reset = menu.addAction('Reset to Default')
            chosen = menu.exec(widget.mapToGlobal(pos))
            if chosen == act_show:
                try:
                    am.request_show_automation.emit(str(parameter_id))
                except Exception:
                    pass
            elif chosen == act_reset:
                try:
                    param = am.get_parameter(str(parameter_id))
                except Exception:
                    param = None
                try:
                    dv = float(default_getter())
                except Exception:
                    dv = 0.0
                try:
                    if param is not None:
                        param.set_value(dv)
                        param.set_automation_value(None)
                except Exception:
                    pass
        except Exception:
            pass

    try:
        widget.customContextMenuRequested.connect(_show_menu)
    except Exception:
        pass


class AudioChainContainerWidget(QWidget):
    """CHAIN container device: Wet Gain + Mix (per track)."""

    def __init__(self, services: Any, track_id: str, parent=None):
        super().__init__(parent)
        self._services = services
        self._track_id = str(track_id or "")
        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(120)
        self._debounce.timeout.connect(self._flush_to_project)
        self._automation_param = None
        self._automation_connected = False
        self._ui_sync_timer = QTimer(self)
        self._ui_sync_timer.setInterval(50)
        self._ui_sync_timer.timeout.connect(self._sync_from_rt)
        try:
            self.destroyed.connect(self._disconnect_automation)
        except Exception:
            pass
        self._build()

    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(4)

        row = QHBoxLayout()
        row.setSpacing(12)

        # Wet Gain (0..200%)
        self.dial_wet = QDial()
        self.dial_wet.setNotchesVisible(True)
        self.dial_wet.setRange(0, 200)
        self.dial_wet.setValue(100)

        col_w = QVBoxLayout()
        col_w.addWidget(QLabel("Wet Gain"), 0, Qt.AlignmentFlag.AlignHCenter)
        col_w.addWidget(self.dial_wet, 1)
        self.lbl_wet = QLabel("100%")
        self.lbl_wet.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        col_w.addWidget(self.lbl_wet)

        # Mix (0..100%)
        self.dial_mix = QDial()
        self.dial_mix.setNotchesVisible(True)
        self.dial_mix.setRange(0, 100)
        self.dial_mix.setValue(100)

        col_m = QVBoxLayout()
        col_m.addWidget(QLabel("Mix"), 0, Qt.AlignmentFlag.AlignHCenter)
        col_m.addWidget(self.dial_mix, 1)
        self.lbl_mix = QLabel("100%")
        self.lbl_mix.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        col_m.addWidget(self.lbl_mix)

        row.addLayout(col_w, 1)
        row.addLayout(col_m, 1)

        root.addLayout(row)

        self.dial_wet.valueChanged.connect(self._on_change)
        self.dial_mix.valueChanged.connect(self._on_change)

        # v0.0.20.250: CHAIN wet/mix are automatable too (also for embedded slot FX).
        try:
            _install_automation_menu(self, self.dial_wet, self._key_wet(), lambda: 1.0)
            _install_automation_menu(self, self.lbl_wet, self._key_wet(), lambda: 1.0)
            _install_automation_menu(self, self.dial_mix, self._key_mix(), lambda: 1.0)
            _install_automation_menu(self, self.lbl_mix, self._key_mix(), lambda: 1.0)
            self._bind_automation()
        except Exception:
            pass

        self.refresh_from_project()
        try:
            self._ui_sync_timer.start()
        except Exception:
            pass

    def _rt(self):
        ae = getattr(self._services, "audio_engine", None) if self._services is not None else None
        return getattr(ae, "rt_params", None) if ae is not None else None

    def _key_wet(self) -> str:
        return f"afxchain:{self._track_id}:wet_gain"

    def _key_mix(self) -> str:
        return f"afxchain:{self._track_id}:mix"

    def _disconnect_automation(self, *_args) -> None:
        am = _get_automation_manager(self._services)
        if am is not None and self._automation_connected:
            try:
                am.parameter_changed.disconnect(self._on_automation_changed)
            except Exception:
                pass
        self._automation_connected = False

    def _bind_automation(self) -> None:
        self._automation_param = {
            "wet": _register_automatable_param(self._services, self._track_id, self._key_wet(), "Wet Gain", 0.0, 2.0, float(self.dial_wet.value()) / 100.0),
            "mix": _register_automatable_param(self._services, self._track_id, self._key_mix(), "Mix", 0.0, 1.0, float(self.dial_mix.value()) / 100.0),
        }
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _apply_ui_value(self, key: str, value: float) -> None:
        try:
            if key == self._key_wet():
                v = max(0.0, min(2.0, float(value)))
                with QSignalBlocker(self.dial_wet):
                    self.dial_wet.setValue(int(round(v * 100.0)))
                self.lbl_wet.setText(f"{self.dial_wet.value()}%")
            elif key == self._key_mix():
                v = max(0.0, min(1.0, float(value)))
                with QSignalBlocker(self.dial_mix):
                    self.dial_mix.setValue(int(round(v * 100.0)))
                self.lbl_mix.setText(f"{self.dial_mix.value()}%")
        except Exception:
            pass

    def _sync_from_rt(self) -> None:
        try:
            if not self.isVisible():
                return
        except Exception:
            pass
        rt = self._rt()
        if rt is None:
            return
        try:
            self._apply_ui_value(self._key_wet(), float(rt.get_target(self._key_wet(), float(self.dial_wet.value()) / 100.0)))
            self._apply_ui_value(self._key_mix(), float(rt.get_target(self._key_mix(), float(self.dial_mix.value()) / 100.0)))
        except Exception:
            pass

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        try:
            pid = str(parameter_id)
            if pid == self._key_wet() or pid == self._key_mix():
                self._apply_ui_value(pid, float(value))
        except RuntimeError:
            self._disconnect_automation()

    def refresh_from_project(self) -> None:
        project = getattr(self._services, "project", None)
        proj = getattr(project, "ctx", None)
        p = getattr(proj, "project", None) if proj is not None else getattr(project, "project", None)
        t = _find_track(p, self._track_id) if p is not None else None
        if t is None:
            return
        chain = getattr(t, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        wet = float(chain.get("wet_gain", 1.0) or 1.0)
        mix = float(chain.get("mix", 1.0) or 1.0)
        self.dial_wet.blockSignals(True)
        self.dial_mix.blockSignals(True)
        try:
            self.dial_wet.setValue(int(max(0, min(200, round(wet * 100.0)))))
            self.dial_mix.setValue(int(max(0, min(100, round(mix * 100.0)))))
        finally:
            self.dial_wet.blockSignals(False)
            self.dial_mix.blockSignals(False)
        self.lbl_wet.setText(f"{self.dial_wet.value()}%")
        self.lbl_mix.setText(f"{self.dial_mix.value()}%")

    def _on_change(self, *_args) -> None:
        self.lbl_wet.setText(f"{self.dial_wet.value()}%")
        self.lbl_mix.setText(f"{self.dial_mix.value()}%")
        # realtime params
        ae = getattr(self._services, "audio_engine", None)
        rt = getattr(ae, "rt_params", None) if ae is not None else None
        tid = self._track_id
        wet = float(self.dial_wet.value()) / 100.0
        mix = float(self.dial_mix.value()) / 100.0
        try:
            if rt is not None:
                rt.set_param(self._key_wet(), wet)
                rt.set_param(self._key_mix(), mix)
        except Exception:
            pass
        try:
            p = (self._automation_param or {}).get("wet") if isinstance(self._automation_param, dict) else None
            if p is not None:
                p.set_value(float(wet))
            p = (self._automation_param or {}).get("mix") if isinstance(self._automation_param, dict) else None
            if p is not None:
                p.set_value(float(mix))
        except Exception:
            pass
        # persist (debounced)
        self._debounce.start()

        # Update output selector (if plugin has multiple audio outs)
        try:
            self._update_output_selector()
        except Exception:
            pass


    def _flush_to_project(self) -> None:
        project_service = getattr(self._services, "project", None)
        if project_service is None:
            return
        ctx = getattr(project_service, "ctx", None)
        p = getattr(ctx, "project", None) if ctx is not None else getattr(project_service, "project", None)
        t = _find_track(p, self._track_id) if p is not None else None
        if t is None:
            return
        chain = getattr(t, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        chain["wet_gain"] = float(self.dial_wet.value()) / 100.0
        chain["mix"] = float(self.dial_mix.value()) / 100.0
        try:
            # notify UI; avoid "changed" spam
            if hasattr(project_service, "project_updated"):
                project_service.project_updated.emit()
        except Exception:
            pass


class GainFxWidget(QWidget):
    """Gain audio FX module: Gain (dB) -> RTParam gain linear."""

    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(parent)
        self._services = services
        self._track_id = str(track_id or "")
        self._device_id = str(device_id or "")
        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(120)
        self._debounce.timeout.connect(self._flush_to_project)
        self._automation_param = None
        self._automation_connected = False
        self._build()

    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(4)

        row = QHBoxLayout()
        row.setSpacing(6)

        self.sld = QSlider(Qt.Orientation.Horizontal)
        self.sld.setRange(-600, 240)  # -60..+24 dB * 10
        self.spn = QDoubleSpinBox()
        self.spn.setRange(-60.0, 24.0)
        self.spn.setSingleStep(0.1)
        self.spn.setDecimals(1)
        self.spn.setSuffix(" dB")
        self.spn.setMaximumWidth(110)

        row.addWidget(QLabel("Gain"), 0)
        row.addWidget(self.sld, 1)
        row.addWidget(self.spn, 0)
        root.addLayout(row)

        self.sld.valueChanged.connect(self._on_slider)
        self.spn.valueChanged.connect(self._on_spin)
        _install_automation_menu(self, self.sld, self._key(), lambda: 0.0)
        _install_automation_menu(self, self.spn, self._key(), lambda: 0.0)

        self.refresh_from_project()
        self._bind_automation()

    def _key(self) -> str:
        return f"afx:{self._track_id}:{self._device_id}:gain"

    def _key_wet(self) -> str:
        return f"afxchain:{self._track_id}:wet_gain"

    def _key_mix(self) -> str:
        return f"afxchain:{self._track_id}:mix"

    def _bind_automation(self) -> None:
        self._automation_param = {
            "wet": _register_automatable_param(self._services, self._track_id, self._key_wet(), "Wet Gain", 0.0, 2.0, float(self.dial_wet.value()) / 100.0),
            "mix": _register_automatable_param(self._services, self._track_id, self._key_mix(), "Mix", 0.0, 1.0, float(self.dial_mix.value()) / 100.0),
        }
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        try:
            pid = str(parameter_id)
            if pid == self._key_wet():
                v = max(0.0, min(2.0, float(value)))
                self.dial_wet.blockSignals(True)
                try:
                    self.dial_wet.setValue(int(round(v * 100.0)))
                finally:
                    self.dial_wet.blockSignals(False)
                self.lbl_wet.setText(f"{self.dial_wet.value()}%")
                self._on_change()
            elif pid == self._key_mix():
                v = max(0.0, min(1.0, float(value)))
                self.dial_mix.blockSignals(True)
                try:
                    self.dial_mix.setValue(int(round(v * 100.0)))
                finally:
                    self.dial_mix.blockSignals(False)
                self.lbl_mix.setText(f"{self.dial_mix.value()}%")
                self._on_change()
        except RuntimeError:
            self._disconnect_automation()

    def refresh_from_project(self) -> None:
        project_service = getattr(self._services, "project", None)
        ctx = getattr(project_service, "ctx", None) if project_service is not None else None
        p = getattr(ctx, "project", None) if ctx is not None else None
        t = _find_track(p, self._track_id) if p is not None else None
        if t is None:
            return
        chain = getattr(t, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        dev = next((d for d in devs if isinstance(d, dict) and str(d.get("id","")) == self._device_id), None)
        if dev is None:
            return
        params = dev.get("params", {}) if isinstance(dev.get("params"), dict) else {}
        db = float(params.get("gain_db", 0.0) or 0.0)
        self.sld.blockSignals(True)
        self.spn.blockSignals(True)
        try:
            self.sld.setValue(int(round(db * 10.0)))
            self.spn.setValue(db)
        finally:
            self.sld.blockSignals(False)
            self.spn.blockSignals(False)

    def _bind_automation(self) -> None:
        self._automation_param = _register_automatable_param(
            self._services, self._track_id, self._key(), "Gain", -60.0, 24.0, float(self.spn.value())
        )
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        if str(parameter_id) != self._key():
            return
        db = float(max(-60.0, min(24.0, float(value))))
        try:
            sld = getattr(self, "sld", None)
            spn = getattr(self, "spn", None)
            if sld is None or spn is None:
                return
            sld.blockSignals(True)
            spn.blockSignals(True)
            try:
                sld.setValue(int(round(db * 10.0)))
                spn.setValue(db)
            finally:
                try:
                    sld.blockSignals(False)
                    spn.blockSignals(False)
                except RuntimeError:
                    return
        except RuntimeError:
            return
        self._apply_rt(db)
        try:
            self._debounce.start()
        except RuntimeError:
            return

    def _apply_rt(self, db: float) -> None:
        ae = getattr(self._services, "audio_engine", None)
        rt = getattr(ae, "rt_params", None) if ae is not None else None
        if rt is None:
            return
        # linear
        g = float(10.0 ** (max(-120.0, min(24.0, float(db))) / 20.0))
        try:
            rt.set_param(self._key(), g)
        except Exception:
            pass

    def _on_slider(self, v: int) -> None:
        db = float(v) / 10.0
        self.spn.blockSignals(True)
        try:
            self.spn.setValue(db)
        finally:
            self.spn.blockSignals(False)
        self._apply_rt(db)
        try:
            if self._automation_param is not None:
                self._automation_param.set_value(float(db))
        except Exception:
            pass
        self._debounce.start()

    def _on_spin(self, db: float) -> None:
        self.sld.blockSignals(True)
        try:
            self.sld.setValue(int(round(float(db) * 10.0)))
        finally:
            self.sld.blockSignals(False)
        self._apply_rt(float(db))
        try:
            if self._automation_param is not None:
                self._automation_param.set_value(float(db))
        except Exception:
            pass
        self._debounce.start()

    def _flush_to_project(self) -> None:
        project_service = getattr(self._services, "project", None)
        ctx = getattr(project_service, "ctx", None) if project_service is not None else None
        p = getattr(ctx, "project", None) if ctx is not None else None
        t = _find_track(p, self._track_id) if p is not None else None
        if t is None:
            return
        chain = getattr(t, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        dev = next((d for d in devs if isinstance(d, dict) and str(d.get("id","")) == self._device_id), None)
        if dev is None:
            return
        params = dev.get("params", {})
        if not isinstance(params, dict):
            params = {}
            dev["params"] = params
        db = float(self.spn.value())
        params["gain_db"] = db
        params["gain"] = float(10.0 ** (db / 20.0))
        try:
            if hasattr(project_service, "project_updated"):
                project_service.project_updated.emit()
        except Exception:
            pass


class DistortionFxWidget(QWidget):
    """Simple distortion module (drive + mix)."""

    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(parent)
        self._services = services
        self._track_id = str(track_id or "")
        self._device_id = str(device_id or "")
        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(120)
        self._debounce.timeout.connect(self._flush_to_project)
        self._automation_params = {}
        self._automation_connected = False
        try:
            self.destroyed.connect(self._disconnect_automation)
        except Exception:
            pass
        self._build()

    def _disconnect_automation(self, *_args) -> None:
        am = _get_automation_manager(self._services)
        if am is not None and self._automation_connected:
            try:
                am.parameter_changed.disconnect(self._on_automation_changed)
            except Exception:
                pass
        self._automation_connected = False

    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(4)

        # Drive
        row1 = QHBoxLayout()
        self.sld_drive = QSlider(Qt.Orientation.Horizontal)
        self.sld_drive.setRange(0, 100)
        self.spn_drive = QDoubleSpinBox()
        self.spn_drive.setRange(0.0, 1.0)
        self.spn_drive.setSingleStep(0.01)
        self.spn_drive.setDecimals(2)
        self.spn_drive.setMaximumWidth(90)
        row1.addWidget(QLabel("Drive"), 0)
        row1.addWidget(self.sld_drive, 1)
        row1.addWidget(self.spn_drive, 0)
        root.addLayout(row1)

        # Mix
        row2 = QHBoxLayout()
        self.sld_mix = QSlider(Qt.Orientation.Horizontal)
        self.sld_mix.setRange(0, 100)
        self.spn_mix = QDoubleSpinBox()
        self.spn_mix.setRange(0.0, 1.0)
        self.spn_mix.setSingleStep(0.01)
        self.spn_mix.setDecimals(2)
        self.spn_mix.setMaximumWidth(90)
        row2.addWidget(QLabel("Mix"), 0)
        row2.addWidget(self.sld_mix, 1)
        row2.addWidget(self.spn_mix, 0)
        root.addLayout(row2)

        self.sld_drive.valueChanged.connect(self._on_drive_slider)
        self.spn_drive.valueChanged.connect(self._on_drive_spin)
        self.sld_mix.valueChanged.connect(self._on_mix_slider)
        self.spn_mix.valueChanged.connect(self._on_mix_spin)
        _install_automation_menu(self, self.sld_drive, self._key_drive(), lambda: 0.25)
        _install_automation_menu(self, self.spn_drive, self._key_drive(), lambda: 0.25)
        _install_automation_menu(self, self.sld_mix, self._key_mix(), lambda: 1.0)
        _install_automation_menu(self, self.spn_mix, self._key_mix(), lambda: 1.0)

        self.refresh_from_project()
        self._bind_automation()

    def _key_drive(self) -> str:
        return f"afx:{self._track_id}:{self._device_id}:drive"

    def _key_mix(self) -> str:
        return f"afx:{self._track_id}:{self._device_id}:mix"

    def _key_wet(self) -> str:
        return f"afxchain:{self._track_id}:wet_gain"

    def _key_mix(self) -> str:
        return f"afxchain:{self._track_id}:mix"

    def _bind_automation(self) -> None:
        self._automation_param = {
            "wet": _register_automatable_param(self._services, self._track_id, self._key_wet(), "Wet Gain", 0.0, 2.0, float(self.dial_wet.value()) / 100.0),
            "mix": _register_automatable_param(self._services, self._track_id, self._key_mix(), "Mix", 0.0, 1.0, float(self.dial_mix.value()) / 100.0),
        }
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        pid = str(parameter_id)
        if pid == self._key_wet():
            v = max(0.0, min(2.0, float(value)))
            self.dial_wet.blockSignals(True)
            try:
                self.dial_wet.setValue(int(round(v * 100.0)))
            finally:
                self.dial_wet.blockSignals(False)
            self.lbl_wet.setText(f"{self.dial_wet.value()}%")
            self._on_change()
        elif pid == self._key_mix():
            v = max(0.0, min(1.0, float(value)))
            self.dial_mix.blockSignals(True)
            try:
                self.dial_mix.setValue(int(round(v * 100.0)))
            finally:
                self.dial_mix.blockSignals(False)
            self.lbl_mix.setText(f"{self.dial_mix.value()}%")
            self._on_change()

    def refresh_from_project(self) -> None:
        project_service = getattr(self._services, "project", None)
        ctx = getattr(project_service, "ctx", None) if project_service is not None else None
        p = getattr(ctx, "project", None) if ctx is not None else None
        t = _find_track(p, self._track_id) if p is not None else None
        if t is None:
            return
        chain = getattr(t, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        dev = next((d for d in devs if isinstance(d, dict) and str(d.get("id","")) == self._device_id), None)
        if dev is None:
            return
        params = dev.get("params", {}) if isinstance(dev.get("params"), dict) else {}
        drive = float(params.get("drive", 0.25) or 0.25)
        mix = float(params.get("mix", 1.0) or 1.0)

        self.sld_drive.blockSignals(True); self.spn_drive.blockSignals(True)
        self.sld_mix.blockSignals(True); self.spn_mix.blockSignals(True)
        try:
            self.sld_drive.setValue(int(round(max(0.0, min(1.0, drive)) * 100.0)))
            self.spn_drive.setValue(max(0.0, min(1.0, drive)))
            self.sld_mix.setValue(int(round(max(0.0, min(1.0, mix)) * 100.0)))
            self.spn_mix.setValue(max(0.0, min(1.0, mix)))
        finally:
            self.sld_drive.blockSignals(False); self.spn_drive.blockSignals(False)
            self.sld_mix.blockSignals(False); self.spn_mix.blockSignals(False)

        # ensure RT keys exist
        ae = getattr(self._services, "audio_engine", None)
        rt = getattr(ae, "rt_params", None) if ae is not None else None
        try:
            if rt is not None:
                rt.ensure(self._key_drive(), drive)
                rt.ensure(self._key_mix(), mix)
        except Exception:
            pass

    def _bind_automation(self) -> None:
        self._automation_params["drive"] = _register_automatable_param(
            self._services, self._track_id, self._key_drive(), "Drive", 0.0, 1.0, float(self.spn_drive.value())
        )
        self._automation_params["mix"] = _register_automatable_param(
            self._services, self._track_id, self._key_mix(), "Mix", 0.0, 1.0, float(self.spn_mix.value())
        )
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        if not _qt_widgets_alive(self, getattr(self, "sld_drive", None), getattr(self, "spn_drive", None), getattr(self, "sld_mix", None), getattr(self, "spn_mix", None)):
            self._disconnect_automation()
            return
        pid = str(parameter_id)
        x = float(max(0.0, min(1.0, float(value))))
        if pid == self._key_drive():
            try:
                self.sld_drive.blockSignals(True); self.spn_drive.blockSignals(True)
                self.sld_drive.setValue(int(round(x * 100.0)))
                self.spn_drive.setValue(x)
            finally:
                try:
                    if _qt_widgets_alive(self.sld_drive, self.spn_drive):
                        self.sld_drive.blockSignals(False); self.spn_drive.blockSignals(False)
                except Exception:
                    pass
            self._apply_rt()
            self._debounce.start()
        elif pid == self._key_mix():
            try:
                self.sld_mix.blockSignals(True); self.spn_mix.blockSignals(True)
                self.sld_mix.setValue(int(round(x * 100.0)))
                self.spn_mix.setValue(x)
            finally:
                try:
                    if _qt_widgets_alive(self.sld_mix, self.spn_mix):
                        self.sld_mix.blockSignals(False); self.spn_mix.blockSignals(False)
                except Exception:
                    pass
            self._apply_rt()
            self._debounce.start()

    def _apply_rt(self) -> None:
        ae = getattr(self._services, "audio_engine", None)
        rt = getattr(ae, "rt_params", None) if ae is not None else None
        if rt is None:
            return
        try:
            rt.set_param(self._key_drive(), float(self.spn_drive.value()))
            rt.set_param(self._key_mix(), float(self.spn_mix.value()))
        except Exception:
            pass

    def _on_drive_slider(self, v: int) -> None:
        x = float(v) / 100.0
        self.spn_drive.blockSignals(True)
        try:
            self.spn_drive.setValue(x)
        finally:
            self.spn_drive.blockSignals(False)
        self._apply_rt()
        try:
            p = self._automation_params.get("drive")
            if p is not None:
                p.set_value(float(x))
        except Exception:
            pass
        self._debounce.start()

    def _on_drive_spin(self, x: float) -> None:
        self.sld_drive.blockSignals(True)
        try:
            self.sld_drive.setValue(int(round(max(0.0, min(1.0, float(x))) * 100.0)))
        finally:
            self.sld_drive.blockSignals(False)
        self._apply_rt()
        try:
            p = self._automation_params.get("drive")
            if p is not None:
                p.set_value(float(x))
        except Exception:
            pass
        self._debounce.start()

    def _on_mix_slider(self, v: int) -> None:
        x = float(v) / 100.0
        self.spn_mix.blockSignals(True)
        try:
            self.spn_mix.setValue(x)
        finally:
            self.spn_mix.blockSignals(False)
        self._apply_rt()
        try:
            p = self._automation_params.get("mix")
            if p is not None:
                p.set_value(float(x))
        except Exception:
            pass
        self._debounce.start()

    def _on_mix_spin(self, x: float) -> None:
        self.sld_mix.blockSignals(True)
        try:
            self.sld_mix.setValue(int(round(max(0.0, min(1.0, float(x))) * 100.0)))
        finally:
            self.sld_mix.blockSignals(False)
        self._apply_rt()
        try:
            p = self._automation_params.get("mix")
            if p is not None:
                p.set_value(float(x))
        except Exception:
            pass
        self._debounce.start()

    def _flush_to_project(self) -> None:
        project_service = getattr(self._services, "project", None)
        ctx = getattr(project_service, "ctx", None) if project_service is not None else None
        p = getattr(ctx, "project", None) if ctx is not None else None
        t = _find_track(p, self._track_id) if p is not None else None
        if t is None:
            return
        chain = getattr(t, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        dev = next((d for d in devs if isinstance(d, dict) and str(d.get("id","")) == self._device_id), None)
        if dev is None:
            return
        params = dev.get("params", {})
        if not isinstance(params, dict):
            params = {}
            dev["params"] = params
        params["drive"] = float(self.spn_drive.value())
        params["mix"] = float(self.spn_mix.value())
        try:
            if hasattr(project_service, "project_updated"):
                project_service.project_updated.emit()
        except Exception:
            pass


# --- NOTE-FX: small module UIs (MVP)

def _get_project_and_track(services: Any, track_id: str):
    ps = getattr(services, "project", None) if services is not None else None
    ctx = getattr(ps, "ctx", None) if ps is not None else None
    p = getattr(ctx, "project", None) if ctx is not None else None
    t = _find_track(p, track_id) if p is not None else None
    return ps, p, t


def _find_note_fx_dev(services: Any, track_id: str, device_id: str):
    ps, p, t = _get_project_and_track(services, track_id)
    if t is None:
        return None, None
    chain = getattr(t, "note_fx_chain", None)
    if not isinstance(chain, dict):
        return None, None
    devs = chain.get("devices", []) or []
    dev = next((d for d in devs if isinstance(d, dict) and str(d.get("id","")) == str(device_id)), None)
    if dev is None:
        return None, None
    params = dev.get("params", {})
    if not isinstance(params, dict):
        params = {}
        dev["params"] = params
    return dev, params


def _find_audio_fx_dev(services: Any, track_id: str, device_id: str):
    ps, p, t = _get_project_and_track(services, track_id)
    if t is None:
        return None, None
    chain = getattr(t, "audio_fx_chain", None)
    if not isinstance(chain, dict):
        return None, None
    devs = chain.get("devices", []) or []
    dev = next((d for d in devs if isinstance(d, dict) and str(d.get("id","")) == str(device_id)), None)
    if dev is None:
        return None, None
    params = dev.get("params", {})
    if not isinstance(params, dict):
        params = {}
        dev["params"] = params
    return dev, params


class Lv2AudioFxWidget(QWidget):
    """Generic LV2 Audio-FX parameter widget (MVP).

    - Reads LV2 control ports via lilv (optional dependency).
    - Writes to RTParamStore (smooth) and persists values into device params.
    """

    def __init__(self, services: Any, track_id: str, device_id: str, plugin_id: str, parent=None):
        super().__init__(parent)
        self._services = services
        self._track_id = str(track_id or "")
        self._device_id = str(device_id or "")
        self._plugin_id = str(plugin_id or "")
        self._uri = ""
        if self._plugin_id.startswith("ext.lv2:"):
            self._uri = self._plugin_id.split(":", 1)[1]

        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(160)
        self._debounce.timeout.connect(self._flush_to_project)

        self._controls = []
        self._rows = {}  # symbol -> (slider, spin, info)
        self._automation_params = {}
        self._automation_connected = False

        self._build()

    def _rt(self):
        ae = getattr(self._services, "audio_engine", None) if self._services is not None else None
        return getattr(ae, "rt_params", None) if ae is not None else None

    def _key(self, symbol: str) -> str:
        return f"afx:{self._track_id}:{self._device_id}:lv2:{symbol}"

    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(4)

        top = QHBoxLayout()
        lab = QLabel("LV2")
        lab.setStyleSheet("font-weight: 600;")
        top.addWidget(lab, 0)
        self._lbl_uri = QLabel(self._uri or "(unknown URI)")
        self._lbl_uri.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self._lbl_uri.setStyleSheet("color: #9aa0a6; font-size: 11px;")
        top.addWidget(self._lbl_uri, 1)
        root.addLayout(top)

        # availability / hint
        self._lbl_hint = QLabel("")
        self._lbl_hint.setWordWrap(True)
        self._lbl_hint.setStyleSheet("color: #b0b7c3; font-size: 11px;")
        root.addWidget(self._lbl_hint)

        # LV2 DSP status + quick action (SAFE): helps diagnose "UI works but no sound"
        self._row_status = QHBoxLayout()
        self._row_status.setContentsMargins(0, 0, 0, 0)
        self._row_status.setSpacing(6)
        self._lbl_dsp = QLabel("")
        self._lbl_dsp.setStyleSheet("color: #9aa0a6; font-size: 11px;")
        self._row_status.addWidget(self._lbl_dsp, 1)
        self._btn_audition = QPushButton("Audition")
        self._btn_audition.setToolTip("Make the LV2 effect clearly audible (heuristic: bypass off / wet on).")
        self._btn_audition.clicked.connect(self._audition_make_obvious)
        self._btn_audition.setVisible(True)
        self._row_status.addWidget(self._btn_audition, 0)

        # Output selection (SAFE): some LV2 plugins expose multiple audio outs (dry taps, monitor, wet).
        # If the host copies back the wrong pair, the effect can sound like no change.
        self._cmb_out = QComboBox()
        self._cmb_out.setToolTip("Select which LV2 audio output pair is used for playback (debug).")
        self._cmb_out.setVisible(False)
        self._cmb_out.currentIndexChanged.connect(self._on_out_sel_changed)
        self._row_status.addWidget(self._cmb_out, 0)

        self._btn_rebuild = QPushButton("Rebuild FX")
        self._btn_rebuild.setToolTip("Rebuild per-track Audio-FX maps (safe).")
        self._btn_rebuild.clicked.connect(self._safe_rebuild_fx_maps)
        self._btn_rebuild.setVisible(False)
        self._row_status.addWidget(self._btn_rebuild, 0)
        root.addLayout(self._row_status)

        # search
        self._search = QLineEdit()
        self._search.setPlaceholderText("Search parameter…")
        self._search.textChanged.connect(self._apply_filter)
        root.addWidget(self._search)

        # scroll
        if QScrollArea is None:
            self._scroll = None
            self._body = QWidget()
            self._body_l = QVBoxLayout(self._body)
            self._body_l.setContentsMargins(0, 0, 0, 0)
            self._body_l.setSpacing(3)
            root.addWidget(self._body, 1)
        else:
            self._scroll = QScrollArea()
            self._scroll.setWidgetResizable(True)
            self._scroll.setFrameShape(QScrollArea.Shape.NoFrame)
            self._body = QWidget()
            self._body_l = QVBoxLayout(self._body)
            self._body_l.setContentsMargins(0, 0, 0, 0)
            self._body_l.setSpacing(3)
            self._scroll.setWidget(self._body)
            root.addWidget(self._scroll, 1)

        self._load_controls_and_build_rows()
        self.refresh_from_project()
        try:
            self._ui_sync_timer.start()
        except Exception:
            pass

    def _dsp_is_active(self) -> bool:
        """Best-effort check if this LV2 FX is compiled into the audio thread.

        If python-lilv is available but the plugin instance fails to instantiate
        (missing required features, broken bundle, etc.), ChainFx will skip it.
        Then users see controls but hear no effect.
        """
        try:
            ae = getattr(self._services, "audio_engine", None) if self._services is not None else None
            fx_map = getattr(ae, "_track_audio_fx_map", None) if ae is not None else None
            if not isinstance(fx_map, dict):
                return False
            chain = fx_map.get(str(self._track_id))
            devs = getattr(chain, "devices", None)
            if not isinstance(devs, list):
                return False
            for fx in devs:
                try:
                    if str(getattr(fx, "device_id", "")) == str(self._device_id):
                        # We only care that *some* DSP object exists for this device id.
                        return True
                except Exception:
                    continue
        except Exception:
            return False
        return False

    def _get_runtime_fx(self):
        # Return the Lv2Fx object from the audio thread map (best-effort).
        try:
            ae = getattr(self._services, 'audio_engine', None) if self._services is not None else None
            fx_map = getattr(ae, '_track_audio_fx_map', None) if ae is not None else None
            if not isinstance(fx_map, dict):
                return None
            chain = fx_map.get(str(self._track_id))
            devs = getattr(chain, 'devices', None)
            if not isinstance(devs, list):
                return None
            for fx in devs:
                try:
                    if str(getattr(fx, 'device_id', '')) == str(self._device_id):
                        return fx
                except Exception:
                    continue
        except Exception:
            return None
        return None

    def _update_output_selector(self) -> None:
        # Populate output selector for plugins with >2 audio outputs.
        try:
            cmb = getattr(self, '_cmb_out', None)
            if cmb is None:
                return
            fx = self._get_runtime_fx()
            if fx is None or not hasattr(fx, 'get_output_options'):
                cmb.setVisible(False)
                return
            try:
                opts = list(fx.get_output_options() or [])
            except Exception:
                opts = []
            if len(opts) <= 2:
                cmb.setVisible(False)
                return

            pairs = []
            n = len(opts)
            for i in range(0, n, 2):
                a = i
                b = i + 1 if (i + 1) < n else i
                ma = opts[a]
                mb = opts[b]
                la = (str(ma.get('symbol') or ma.get('name') or '')).strip()
                lb = (str(mb.get('symbol') or mb.get('name') or '')).strip()
                label = f"Out {a}/{b}: {la or 'L'} | {lb or 'R'}"
                pairs.append((label, [a, b]))

            try:
                cur = list(fx.get_output_selection() or [])
            except Exception:
                cur = [0, 1]
            try:
                auto = list(fx.get_auto_output_selection() or [])
            except Exception:
                auto = [0, 1]

            from PyQt6.QtCore import QSignalBlocker
            with QSignalBlocker(cmb):
                cmb.clear()
                cmb.addItem(f"Auto ({auto[0]}/{auto[1]})", ['auto'])
                for label, sel in pairs:
                    cmb.addItem(label, sel)

                sel_key = [int(cur[0]), int(cur[1] if len(cur) > 1 else cur[0])]
                idx_match = -1
                for j in range(cmb.count()):
                    data = cmb.itemData(j)
                    if isinstance(data, list) and data and data[0] == 'auto':
                        continue
                    if isinstance(data, list) and len(data) >= 2:
                        if [int(data[0]), int(data[1])] == sel_key:
                            idx_match = j
                            break
                cmb.setCurrentIndex(idx_match if idx_match >= 0 else 0)

            cmb.setVisible(True)
        except Exception:
            try:
                self._cmb_out.setVisible(False)
            except Exception:
                pass

    def _on_out_sel_changed(self, idx: int) -> None:
        # Apply output selection to the runtime Lv2Fx and persist into project params.
        try:
            cmb = getattr(self, '_cmb_out', None)
            if cmb is None or idx < 0:
                return
            data = cmb.itemData(int(idx))
            fx = self._get_runtime_fx()
            if fx is None:
                return

            if isinstance(data, list) and data and data[0] == 'auto':
                try:
                    sel = list(getattr(fx, 'get_auto_output_selection')() or [0, 1])
                except Exception:
                    sel = [0, 1]
                try:
                    if hasattr(fx, 'set_output_selection'):
                        fx.set_output_selection(sel)
                except Exception:
                    pass
                try:
                    _dev, params = _find_audio_fx_dev(self._services, self._track_id, self._device_id)
                    if params is not None:
                        params.pop('__out_sel', None)
                except Exception:
                    pass
                try:
                    ps = getattr(self._services, 'project', None) if self._services is not None else None
                    if ps is not None and hasattr(ps, 'project_changed'):
                        ps.project_changed.emit()
                except Exception:
                    pass
                return

            if not (isinstance(data, list) and len(data) >= 2):
                return
            sel = [int(data[0]), int(data[1])]
            try:
                if hasattr(fx, 'set_output_selection'):
                    fx.set_output_selection(sel)
            except Exception:
                pass

            try:
                _dev, params = _find_audio_fx_dev(self._services, self._track_id, self._device_id)
                if params is not None:
                    params['__out_sel'] = sel
            except Exception:
                pass
            try:
                ps = getattr(self._services, 'project', None) if self._services is not None else None
                if ps is not None and hasattr(ps, 'project_changed'):
                    ps.project_changed.emit()
            except Exception:
                pass
        except Exception:
            return

    def _safe_rebuild_fx_maps(self) -> None:
        """Rebuild FX maps from current project snapshot (SAFE UI action)."""
        try:
            ae = getattr(self._services, "audio_engine", None) if self._services is not None else None
            if ae is None or not hasattr(ae, "rebuild_fx_maps"):
                return
            _ps, proj, _t = _get_project_and_track(self._services, self._track_id)
            if proj is None:
                return
            ae.rebuild_fx_maps(proj)
        except Exception:
            return
        # Refresh DSP status label/button after rebuild
        try:
            self._update_dsp_status()
        except Exception:
            pass


    def _audition_make_obvious(self) -> None:
        """Make the LV2 effect clearly audible (best-effort).

        Many LV2 plugins ship with subtle defaults or start in BYPASS.
        This applies simple heuristics (BYPASS->off, WET/MIX->max, etc.).
        """
        try:
            for c in (self._controls or []):
                sym = str(getattr(c, 'symbol', '') or '')
                if not sym or sym not in self._rows:
                    continue
                _row, sld, spn, (mn, mx, _df) = self._rows[sym]
                nm = str(getattr(c, 'name', '') or '')
                key = (sym + ' ' + nm).lower()

                target = None

                if 'bypass' in key:
                    target = mn
                elif ('dry/wet' in key) or ('dry_wet' in key) or ('drywet' in key):
                    # more wet (common convention: 0=dry, 1=wet)
                    target = mx
                elif ('wet_dry' in key) or ('wetdry' in key):
                    # more wet (some plugins use wet->dry fader)
                    target = mn
                elif (('mix' in key) or ('wet' in key)) and ('wet_dry' not in key and 'dry_wet' not in key):
                    target = mx
                elif ('dry' in key) and ('wet_dry' not in key and 'dry_wet' not in key):
                    target = mn
                elif 'feedback' in key:
                    target = mn + 0.75 * (mx - mn)
                elif 'depth' in key:
                    target = mx
                elif 'drive' in key:
                    target = mn + 0.70 * (mx - mn)
                elif ('level' in key or 'output' in key) and (mx - mn) <= 1.01:
                    target = mn + 0.85 * (mx - mn)

                if target is None:
                    continue

                try:
                    target = float(target)
                except Exception:
                    continue
                if target < mn:
                    target = mn
                if target > mx:
                    target = mx

                try:
                    pos = 0
                    if mx > mn:
                        pos = int(round(((target - mn) / (mx - mn)) * 1000.0))
                    with QSignalBlocker(sld):
                        sld.setValue(max(0, min(1000, pos)))
                    with QSignalBlocker(spn):
                        spn.setValue(float(target))
                except Exception:
                    pass

                self._set_value(sym, float(target))

            try:
                self._debounce.start()
            except Exception:
                pass
        except Exception:
            pass

    def _update_dsp_status(self) -> None:
        try:
            active = bool(self._dsp_is_active())
            if active:
                self._lbl_dsp.setText("DSP: ACTIVE")
                self._btn_rebuild.setVisible(False)
                try:
                    self._update_output_selector()
                except Exception:
                    pass
            else:
                # If Safe Mode blocked this plugin (probe crash/fail), show that explicitly.
                try:
                    from pydaw.audio import lv2_host
                    st, msg = lv2_host.get_probe_status(self._uri)
                    if lv2_host.safe_mode_enabled() and st == "blocked":
                        # keep short
                        short = (msg or "blocked").strip()
                        short = " ".join(short.split())
                        if len(short) > 80:
                            short = short[:77] + "…"
                        self._lbl_dsp.setText("DSP: BLOCKED (Safe Mode) — " + short)
                        self._btn_rebuild.setVisible(False)
                        return
                except Exception:
                    pass

                try:
                    self._cmb_out.setVisible(False)
                except Exception:
                    pass

                self._lbl_dsp.setText("DSP: INACTIVE (no audible effect) — try Rebuild FX")
                # Show the button only if LV2 hosting is available; otherwise user needs deps.
                try:
                    from pydaw.audio import lv2_host
                    self._btn_rebuild.setVisible(bool(lv2_host.is_available()))
                except Exception:
                    self._btn_rebuild.setVisible(True)
        except Exception:
            pass

    def _load_controls_and_build_rows(self) -> None:
        # clear
        while self._body_l.count():
            it = self._body_l.takeAt(0)
            w = it.widget()
            if w is not None:
                w.deleteLater()

        self._rows.clear()
        self._controls = []

        # query LV2
        try:
            from pydaw.audio import lv2_host
            avail = False
            try:
                avail = bool(lv2_host.is_available())
            except Exception:
                avail = False

            # Always try to build a parameter UI:
            # - best: python-lilv available
            # - fallback: lv2info parsing (UI-only) when python-lilv can't be imported
            try:
                self._controls = lv2_host.describe_controls(self._uri)
            except Exception:
                self._controls = []

            if not avail:
                # show actionable hint, but still allow UI fallback rows if we found controls
                hint = lv2_host.availability_hint()
                if self._controls:
                    hint = hint + "\n(Param-UI geladen; live processing bleibt deaktiviert.)"
                self._lbl_hint.setText(hint)
            else:
                self._lbl_hint.setText("OK")
        except Exception:
            self._controls = []

        if not self._controls:
            self._lbl_hint.setText("Keine LV2 Controls gefunden (Plugin URI ok? python-lilv installiert?).")
            return
        if "avail" in locals() and avail:
            # Show Safe Mode probe status (cache-only; does not run the probe here).
            try:
                st, msg = lv2_host.get_probe_status(self._uri)
                if lv2_host.safe_mode_enabled() and st == "blocked":
                    short = (msg or "blocked").strip()
                    short = " ".join(short.split())
                    if len(short) > 90:
                        short = short[:87] + "…"
                    self._lbl_hint.setText("Controls: " + str(len(self._controls)) + " — BLOCKED (Safe Mode): " + short)
                else:
                    self._lbl_hint.setText("Controls: " + str(len(self._controls)))
            except Exception:
                self._lbl_hint.setText("Controls: " + str(len(self._controls)))

        # Update DSP status AFTER we know the host availability
        self._update_dsp_status()

        for c in self._controls:
            sym = str(getattr(c, "symbol", "") or "")
            if not sym:
                continue
            nm = str(getattr(c, "name", sym) or sym)
            mn = float(getattr(c, "minimum", 0.0))
            mx = float(getattr(c, "maximum", 1.0))
            df = float(getattr(c, "default", 0.0))
            if mx <= mn:
                mx = mn + 1.0

            row = QWidget()
            rl = QHBoxLayout(row)
            rl.setContentsMargins(0, 0, 0, 0)
            rl.setSpacing(6)

            lbl = QLabel(nm)
            lbl.setMinimumWidth(130)
            lbl.setToolTip(sym)

            sld = QSlider(Qt.Orientation.Horizontal)
            sld.setRange(0, 1000)

            spn = QDoubleSpinBox()
            spn.setDecimals(4)
            spn.setRange(mn, mx)
            spn.setSingleStep((mx - mn) / 200.0)
            spn.setMaximumWidth(120)

            rl.addWidget(lbl, 0)
            rl.addWidget(sld, 1)
            rl.addWidget(spn, 0)

            self._body_l.addWidget(row)

            info = (mn, mx, df)
            self._rows[sym] = (row, sld, spn, info)
            pid = self._key(sym)
            _install_automation_menu(self, lbl, pid, lambda df=df: float(df))
            _install_automation_menu(self, sld, pid, lambda df=df: float(df))
            _install_automation_menu(self, spn, pid, lambda df=df: float(df))
            self._automation_params[sym] = _register_automatable_param(
                self._services, self._track_id, pid, nm, mn, mx, df
            )

            def _map_to_val(pos: int, mn=mn, mx=mx) -> float:
                return mn + (float(pos) / 1000.0) * (mx - mn)

            def _map_to_pos(val: float, mn=mn, mx=mx) -> int:
                if mx <= mn:
                    return 0
                t = (float(val) - mn) / (mx - mn)
                if t < 0.0:
                    t = 0.0
                if t > 1.0:
                    t = 1.0
                return int(round(t * 1000.0))

            def on_slider(v: int, sym=sym):
                row, sld2, spn2, info2 = self._rows.get(sym, (None, None, None, None))
                if sld2 is None or spn2 is None:
                    return
                val = _map_to_val(int(v))
                with QSignalBlocker(spn2):
                    spn2.setValue(val)
                self._set_value(sym, float(val))

            def on_spin(val: float, sym=sym):
                row, sld2, spn2, info2 = self._rows.get(sym, (None, None, None, None))
                if sld2 is None:
                    return
                with QSignalBlocker(sld2):
                    sld2.setValue(_map_to_pos(float(val)))
                self._set_value(sym, float(val))

            sld.valueChanged.connect(on_slider)
            spn.valueChanged.connect(on_spin)

        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _apply_filter(self, text: str) -> None:
        q = str(text or "").strip().lower()
        for sym, (row, _sld, _spn, _info) in self._rows.items():
            try:
                nm = row.findChild(QLabel).text().lower() if row is not None else ""
            except Exception:
                nm = ""
            show = (not q) or (q in sym.lower()) or (q in nm)
            try:
                row.setVisible(bool(show))
            except Exception:
                pass

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        pid = str(parameter_id)
        for sym, (_row, sld, spn, (mn, mx, _df)) in self._rows.items():
            if pid != self._key(sym):
                continue
            val = float(max(mn, min(mx, float(value))))
            pos = 0
            if mx > mn:
                pos = int(round(((val - mn) / (mx - mn)) * 1000.0))
            with QSignalBlocker(sld):
                sld.setValue(max(0, min(1000, pos)))
            with QSignalBlocker(spn):
                spn.setValue(val)
            self._set_value(sym, val, update_param=False)
            break

    def _set_value(self, symbol: str, value: float, update_param: bool = True) -> None:
        # RT write
        rt = self._rt()
        try:
            if rt is not None:
                rt.set_param(self._key(symbol), float(value))
        except Exception:
            pass
        if update_param:
            try:
                param = self._automation_params.get(str(symbol))
                if param is not None:
                    param.set_value(float(value))
            except Exception:
                pass
        # persist
        try:
            dev, params = _find_audio_fx_dev(self._services, self._track_id, self._device_id)
            if params is not None:
                params[str(symbol)] = float(value)
        except Exception:
            pass
        self._debounce.start()

    def _key_wet(self) -> str:
        return f"afxchain:{self._track_id}:wet_gain"

    def _key_mix(self) -> str:
        return f"afxchain:{self._track_id}:mix"

    def _bind_automation(self) -> None:
        self._automation_param = {
            "wet": _register_automatable_param(self._services, self._track_id, self._key_wet(), "Wet Gain", 0.0, 2.0, float(self.dial_wet.value()) / 100.0),
            "mix": _register_automatable_param(self._services, self._track_id, self._key_mix(), "Mix", 0.0, 1.0, float(self.dial_mix.value()) / 100.0),
        }
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        pid = str(parameter_id)
        if pid == self._key_wet():
            v = max(0.0, min(2.0, float(value)))
            self.dial_wet.blockSignals(True)
            try:
                self.dial_wet.setValue(int(round(v * 100.0)))
            finally:
                self.dial_wet.blockSignals(False)
            self.lbl_wet.setText(f"{self.dial_wet.value()}%")
            self._on_change()
        elif pid == self._key_mix():
            v = max(0.0, min(1.0, float(value)))
            self.dial_mix.blockSignals(True)
            try:
                self.dial_mix.setValue(int(round(v * 100.0)))
            finally:
                self.dial_mix.blockSignals(False)
            self.lbl_mix.setText(f"{self.dial_mix.value()}%")
            self._on_change()

    def refresh_from_project(self) -> None:
        dev, params = _find_audio_fx_dev(self._services, self._track_id, self._device_id)
        if params is None:
            return
        rt = self._rt()

        # seed defaults
        for c in (self._controls or []):
            sym = str(getattr(c, "symbol", "") or "")
            if not sym or sym not in self._rows:
                continue
            row, sld, spn, (mn, mx, df) = self._rows[sym]
            try:
                val = float(params.get(sym, df))
            except Exception:
                val = df
            # clamp
            if val < mn:
                val = mn
            if val > mx:
                val = mx

            # UI
            try:
                # map
                pos = 0
                if mx > mn:
                    pos = int(round(((val - mn) / (mx - mn)) * 1000.0))
                with QSignalBlocker(sld):
                    sld.setValue(max(0, min(1000, pos)))
                with QSignalBlocker(spn):
                    spn.setValue(float(val))
            except Exception:
                pass

            # RT
            try:
                if rt is not None and hasattr(rt, "ensure"):
                    rt.ensure(self._key(sym), float(val))
                elif rt is not None:
                    rt.set_param(self._key(sym), float(val))
            except Exception:
                pass

    def _flush_to_project(self) -> None:
        """Notify about persisted LV2 parameter changes (SAFE).

        Important UX note:
        The DevicePanel listens to `ProjectService.project_updated` and will
        rebuild the entire device chain UI on every emission.

        LV2 plugins can expose *many* parameters. Emitting `project_updated`
        while the user drags a slider will destroy/recreate this widget and the
        controls appear to "snap back".

        For LV2 parameter tweaks we therefore only emit `project_changed`
        (dirty indicator/window title) and avoid a full device-panel rebuild.
        """
        ps = getattr(self._services, "project", None) if self._services is not None else None
        try:
            if ps is not None and hasattr(ps, "project_changed"):
                ps.project_changed.emit()
        except Exception:
            pass


class _NoteFxBase(QWidget):
    """Small helper base with debounced project writes."""
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(parent)
        self._services = services
        self._track_id = str(track_id or "")
        self._device_id = str(device_id or "")
        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(120)
        self._debounce.timeout.connect(self._flush)

    def _emit_updated(self) -> None:
        ps = getattr(self._services, "project", None) if self._services is not None else None
        try:
            if ps is not None and hasattr(ps, "project_updated"):
                ps.project_updated.emit()
        except Exception:
            pass

    def _flush(self) -> None:
        # implemented by subclasses
        self._emit_updated()


class TransposeNoteFxWidget(_NoteFxBase):
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)
        root = QVBoxLayout(self); root.setContentsMargins(6,6,6,6); root.setSpacing(4)
        row = QHBoxLayout()
        row.addWidget(QLabel("Semitones"), 0)
        self.spn = QSpinBox(); self.spn.setRange(-24, 24); self.spn.setValue(0)
        row.addWidget(self.spn, 0)
        row.addStretch(1)
        root.addLayout(row)
        self.spn.valueChanged.connect(lambda _: self._debounce.start())
        self.refresh_from_project()

    def _key_wet(self) -> str:
        return f"afxchain:{self._track_id}:wet_gain"

    def _key_mix(self) -> str:
        return f"afxchain:{self._track_id}:mix"

    def _bind_automation(self) -> None:
        self._automation_param = {
            "wet": _register_automatable_param(self._services, self._track_id, self._key_wet(), "Wet Gain", 0.0, 2.0, float(self.dial_wet.value()) / 100.0),
            "mix": _register_automatable_param(self._services, self._track_id, self._key_mix(), "Mix", 0.0, 1.0, float(self.dial_mix.value()) / 100.0),
        }
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        pid = str(parameter_id)
        if pid == self._key_wet():
            v = max(0.0, min(2.0, float(value)))
            self.dial_wet.blockSignals(True)
            try:
                self.dial_wet.setValue(int(round(v * 100.0)))
            finally:
                self.dial_wet.blockSignals(False)
            self.lbl_wet.setText(f"{self.dial_wet.value()}%")
            self._on_change()
        elif pid == self._key_mix():
            v = max(0.0, min(1.0, float(value)))
            self.dial_mix.blockSignals(True)
            try:
                self.dial_mix.setValue(int(round(v * 100.0)))
            finally:
                self.dial_mix.blockSignals(False)
            self.lbl_mix.setText(f"{self.dial_mix.value()}%")
            self._on_change()

    def refresh_from_project(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        val = int(params.get("semitones", 0) or 0)
        self.spn.blockSignals(True)
        try:
            self.spn.setValue(val)
        finally:
            self.spn.blockSignals(False)

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        params["semitones"] = int(self.spn.value())
        self._emit_updated()


class VelocityScaleNoteFxWidget(_NoteFxBase):
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)
        root = QVBoxLayout(self); root.setContentsMargins(6,6,6,6); root.setSpacing(4)
        row = QHBoxLayout(); row.setSpacing(6)
        row.addWidget(QLabel("Vel Scale"), 0)
        self.sld = QSlider(Qt.Orientation.Horizontal)
        self.sld.setRange(0, 200)  # 0..2.0
        self.spn = QDoubleSpinBox()
        self.spn.setRange(0.0, 2.0)
        self.spn.setSingleStep(0.01)
        self.spn.setDecimals(2)
        self.spn.setMaximumWidth(90)
        row.addWidget(self.sld, 1)
        row.addWidget(self.spn, 0)
        root.addLayout(row)

        self.sld.valueChanged.connect(self._on_sld)
        self.spn.valueChanged.connect(self._on_spn)
        self.refresh_from_project()

    def _key_wet(self) -> str:
        return f"afxchain:{self._track_id}:wet_gain"

    def _key_mix(self) -> str:
        return f"afxchain:{self._track_id}:mix"

    def _bind_automation(self) -> None:
        self._automation_param = {
            "wet": _register_automatable_param(self._services, self._track_id, self._key_wet(), "Wet Gain", 0.0, 2.0, float(self.dial_wet.value()) / 100.0),
            "mix": _register_automatable_param(self._services, self._track_id, self._key_mix(), "Mix", 0.0, 1.0, float(self.dial_mix.value()) / 100.0),
        }
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        pid = str(parameter_id)
        if pid == self._key_wet():
            v = max(0.0, min(2.0, float(value)))
            self.dial_wet.blockSignals(True)
            try:
                self.dial_wet.setValue(int(round(v * 100.0)))
            finally:
                self.dial_wet.blockSignals(False)
            self.lbl_wet.setText(f"{self.dial_wet.value()}%")
            self._on_change()
        elif pid == self._key_mix():
            v = max(0.0, min(1.0, float(value)))
            self.dial_mix.blockSignals(True)
            try:
                self.dial_mix.setValue(int(round(v * 100.0)))
            finally:
                self.dial_mix.blockSignals(False)
            self.lbl_mix.setText(f"{self.dial_mix.value()}%")
            self._on_change()

    def refresh_from_project(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        x = float(params.get("scale", 1.0) or 1.0)
        x = max(0.0, min(2.0, x))
        self.sld.blockSignals(True); self.spn.blockSignals(True)
        try:
            self.sld.setValue(int(round(x * 100.0)))
            self.spn.setValue(x)
        finally:
            self.sld.blockSignals(False); self.spn.blockSignals(False)

    def _on_sld(self, v: int) -> None:
        x = float(v) / 100.0
        self.spn.blockSignals(True)
        try:
            self.spn.setValue(x)
        finally:
            self.spn.blockSignals(False)
        self._debounce.start()

    def _on_spn(self, x: float) -> None:
        x = max(0.0, min(2.0, float(x)))
        self.sld.blockSignals(True)
        try:
            self.sld.setValue(int(round(x * 100.0)))
        finally:
            self.sld.blockSignals(False)
        self._debounce.start()

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        params["scale"] = float(self.spn.value())
        self._emit_updated()


class ScaleSnapNoteFxWidget(_NoteFxBase):
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)
        root = QVBoxLayout(self); root.setContentsMargins(6,6,6,6); root.setSpacing(4)

        r1 = QHBoxLayout(); r1.setSpacing(6)
        r1.addWidget(QLabel("Root"), 0)
        self.cmb_root = QComboBox()
        self._roots = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]
        self.cmb_root.addItems(self._roots)
        r1.addWidget(self.cmb_root, 0)
        r1.addWidget(QLabel("Scale"), 0)
        self.cmb_scale = QComboBox()
        self.cmb_scale.addItems(["major","minor","dorian","phrygian","lydian","mixolydian","locrian","pentatonic","chromatic"])
        r1.addWidget(self.cmb_scale, 1)
        root.addLayout(r1)

        r2 = QHBoxLayout(); r2.setSpacing(6)
        r2.addWidget(QLabel("Mode"), 0)
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["nearest","down","up"])
        r2.addWidget(self.cmb_mode, 0)
        r2.addStretch(1)
        root.addLayout(r2)

        self.cmb_root.currentIndexChanged.connect(lambda _: self._debounce.start())
        self.cmb_scale.currentIndexChanged.connect(lambda _: self._debounce.start())
        self.cmb_mode.currentIndexChanged.connect(lambda _: self._debounce.start())

        self.refresh_from_project()

    def _key_wet(self) -> str:
        return f"afxchain:{self._track_id}:wet_gain"

    def _key_mix(self) -> str:
        return f"afxchain:{self._track_id}:mix"

    def _bind_automation(self) -> None:
        self._automation_param = {
            "wet": _register_automatable_param(self._services, self._track_id, self._key_wet(), "Wet Gain", 0.0, 2.0, float(self.dial_wet.value()) / 100.0),
            "mix": _register_automatable_param(self._services, self._track_id, self._key_mix(), "Mix", 0.0, 1.0, float(self.dial_mix.value()) / 100.0),
        }
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        pid = str(parameter_id)
        if pid == self._key_wet():
            v = max(0.0, min(2.0, float(value)))
            self.dial_wet.blockSignals(True)
            try:
                self.dial_wet.setValue(int(round(v * 100.0)))
            finally:
                self.dial_wet.blockSignals(False)
            self.lbl_wet.setText(f"{self.dial_wet.value()}%")
            self._on_change()
        elif pid == self._key_mix():
            v = max(0.0, min(1.0, float(value)))
            self.dial_mix.blockSignals(True)
            try:
                self.dial_mix.setValue(int(round(v * 100.0)))
            finally:
                self.dial_mix.blockSignals(False)
            self.lbl_mix.setText(f"{self.dial_mix.value()}%")
            self._on_change()

    def refresh_from_project(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        root_pc = int(params.get("root", 0) or 0) % 12
        scale = str(params.get("scale", "major") or "major")
        mode = str(params.get("mode", "nearest") or "nearest")
        self.cmb_root.blockSignals(True); self.cmb_scale.blockSignals(True); self.cmb_mode.blockSignals(True)
        try:
            self.cmb_root.setCurrentIndex(max(0, min(11, root_pc)))
            self.cmb_scale.setCurrentText(scale if scale in [self.cmb_scale.itemText(i) for i in range(self.cmb_scale.count())] else "major")
            self.cmb_mode.setCurrentText(mode if mode in [self.cmb_mode.itemText(i) for i in range(self.cmb_mode.count())] else "nearest")
        finally:
            self.cmb_root.blockSignals(False); self.cmb_scale.blockSignals(False); self.cmb_mode.blockSignals(False)

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        params["root"] = int(self.cmb_root.currentIndex()) % 12
        params["scale"] = str(self.cmb_scale.currentText() or "major")
        params["mode"] = str(self.cmb_mode.currentText() or "nearest")
        self._emit_updated()


class ChordNoteFxWidget(_NoteFxBase):
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)
        root = QVBoxLayout(self); root.setContentsMargins(6,6,6,6); root.setSpacing(4)

        row = QHBoxLayout(); row.setSpacing(6)
        row.addWidget(QLabel("Chord"), 0)
        self.cmb = QComboBox()
        self.cmb.addItems(["maj","min","power","maj7","min7","dim","aug"])
        row.addWidget(self.cmb, 1)
        root.addLayout(row)

        self.cmb.currentIndexChanged.connect(lambda _: self._debounce.start())
        self.refresh_from_project()

    def _key_wet(self) -> str:
        return f"afxchain:{self._track_id}:wet_gain"

    def _key_mix(self) -> str:
        return f"afxchain:{self._track_id}:mix"

    def _bind_automation(self) -> None:
        self._automation_param = {
            "wet": _register_automatable_param(self._services, self._track_id, self._key_wet(), "Wet Gain", 0.0, 2.0, float(self.dial_wet.value()) / 100.0),
            "mix": _register_automatable_param(self._services, self._track_id, self._key_mix(), "Mix", 0.0, 1.0, float(self.dial_mix.value()) / 100.0),
        }
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        pid = str(parameter_id)
        if pid == self._key_wet():
            v = max(0.0, min(2.0, float(value)))
            self.dial_wet.blockSignals(True)
            try:
                self.dial_wet.setValue(int(round(v * 100.0)))
            finally:
                self.dial_wet.blockSignals(False)
            self.lbl_wet.setText(f"{self.dial_wet.value()}%")
            self._on_change()
        elif pid == self._key_mix():
            v = max(0.0, min(1.0, float(value)))
            self.dial_mix.blockSignals(True)
            try:
                self.dial_mix.setValue(int(round(v * 100.0)))
            finally:
                self.dial_mix.blockSignals(False)
            self.lbl_mix.setText(f"{self.dial_mix.value()}%")
            self._on_change()

    def refresh_from_project(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        ch = str(params.get("chord", "maj") or "maj")
        self.cmb.blockSignals(True)
        try:
            self.cmb.setCurrentText(ch if ch in [self.cmb.itemText(i) for i in range(self.cmb.count())] else "maj")
        finally:
            self.cmb.blockSignals(False)

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        params["chord"] = str(self.cmb.currentText() or "maj")
        self._emit_updated()


class ArpNoteFxWidget(_NoteFxBase):
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)
        root = QVBoxLayout(self); root.setContentsMargins(6,6,6,6); root.setSpacing(4)

        r1 = QHBoxLayout(); r1.setSpacing(6)
        r1.addWidget(QLabel("Step"), 0)
        self.cmb_step = QComboBox()
        self._steps = [0.125, 0.25, 0.5, 1.0]
        self.cmb_step.addItems([f"{s:g}" for s in self._steps])
        r1.addWidget(self.cmb_step, 0)
        r1.addWidget(QLabel("Mode"), 0)
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["up","down","updown","random"])
        r1.addWidget(self.cmb_mode, 1)
        root.addLayout(r1)

        r2 = QHBoxLayout(); r2.setSpacing(6)
        r2.addWidget(QLabel("Oct"), 0)
        self.spn_oct = QSpinBox(); self.spn_oct.setRange(1, 4); self.spn_oct.setValue(1)
        r2.addWidget(self.spn_oct, 0)
        r2.addWidget(QLabel("Gate"), 0)
        self.sld_gate = QSlider(Qt.Orientation.Horizontal); self.sld_gate.setRange(10, 100); self.sld_gate.setValue(90)
        self.spn_gate = QDoubleSpinBox(); self.spn_gate.setRange(0.10, 1.00); self.spn_gate.setSingleStep(0.01); self.spn_gate.setDecimals(2); self.spn_gate.setMaximumWidth(80)
        r2.addWidget(self.sld_gate, 1)
        r2.addWidget(self.spn_gate, 0)
        root.addLayout(r2)

        self.cmb_step.currentIndexChanged.connect(lambda _: self._debounce.start())
        self.cmb_mode.currentIndexChanged.connect(lambda _: self._debounce.start())
        self.spn_oct.valueChanged.connect(lambda _: self._debounce.start())
        self.sld_gate.valueChanged.connect(self._on_gate_sld)
        self.spn_gate.valueChanged.connect(self._on_gate_spn)

        self.refresh_from_project()

    def _key_wet(self) -> str:
        return f"afxchain:{self._track_id}:wet_gain"

    def _key_mix(self) -> str:
        return f"afxchain:{self._track_id}:mix"

    def _bind_automation(self) -> None:
        self._automation_param = {
            "wet": _register_automatable_param(self._services, self._track_id, self._key_wet(), "Wet Gain", 0.0, 2.0, float(self.dial_wet.value()) / 100.0),
            "mix": _register_automatable_param(self._services, self._track_id, self._key_mix(), "Mix", 0.0, 1.0, float(self.dial_mix.value()) / 100.0),
        }
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        pid = str(parameter_id)
        if pid == self._key_wet():
            v = max(0.0, min(2.0, float(value)))
            self.dial_wet.blockSignals(True)
            try:
                self.dial_wet.setValue(int(round(v * 100.0)))
            finally:
                self.dial_wet.blockSignals(False)
            self.lbl_wet.setText(f"{self.dial_wet.value()}%")
            self._on_change()
        elif pid == self._key_mix():
            v = max(0.0, min(1.0, float(value)))
            self.dial_mix.blockSignals(True)
            try:
                self.dial_mix.setValue(int(round(v * 100.0)))
            finally:
                self.dial_mix.blockSignals(False)
            self.lbl_mix.setText(f"{self.dial_mix.value()}%")
            self._on_change()

    def refresh_from_project(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        step = float(params.get("step_beats", 0.5) or 0.5)
        mode = str(params.get("mode", "up") or "up")
        octv = int(params.get("octaves", 1) or 1)
        gate = float(params.get("gate", 0.9) or 0.9)
        # normalize
        try:
            idx = min(range(len(self._steps)), key=lambda i: abs(self._steps[i] - step))
        except Exception:
            idx = 2
        gate = max(0.10, min(1.00, gate))
        self.cmb_step.blockSignals(True); self.cmb_mode.blockSignals(True)
        self.spn_oct.blockSignals(True); self.sld_gate.blockSignals(True); self.spn_gate.blockSignals(True)
        try:
            self.cmb_step.setCurrentIndex(int(idx))
            self.cmb_mode.setCurrentText(mode if mode in [self.cmb_mode.itemText(i) for i in range(self.cmb_mode.count())] else "up")
            self.spn_oct.setValue(max(1, min(4, octv)))
            self.sld_gate.setValue(int(round(gate * 100.0)))
            self.spn_gate.setValue(gate)
        finally:
            self.cmb_step.blockSignals(False); self.cmb_mode.blockSignals(False)
            self.spn_oct.blockSignals(False); self.sld_gate.blockSignals(False); self.spn_gate.blockSignals(False)

    def _on_gate_sld(self, v: int) -> None:
        x = max(0.10, min(1.00, float(v) / 100.0))
        self.spn_gate.blockSignals(True)
        try:
            self.spn_gate.setValue(x)
        finally:
            self.spn_gate.blockSignals(False)
        self._debounce.start()

    def _on_gate_spn(self, x: float) -> None:
        x = max(0.10, min(1.00, float(x)))
        self.sld_gate.blockSignals(True)
        try:
            self.sld_gate.setValue(int(round(x * 100.0)))
        finally:
            self.sld_gate.blockSignals(False)
        self._debounce.start()

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        params["step_beats"] = float(self._steps[int(self.cmb_step.currentIndex())]) if self.cmb_step.currentIndex() >= 0 else 0.5
        params["mode"] = str(self.cmb_mode.currentText() or "up")
        params["octaves"] = int(self.spn_oct.value())
        params["gate"] = float(self.spn_gate.value())
        self._emit_updated()


class RandomNoteFxWidget(_NoteFxBase):
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)
        root = QVBoxLayout(self); root.setContentsMargins(6,6,6,6); root.setSpacing(4)

        r1 = QHBoxLayout(); r1.setSpacing(6)
        r1.addWidget(QLabel("Pitch ±"), 0)
        self.spn_pr = QSpinBox(); self.spn_pr.setRange(0, 24); self.spn_pr.setValue(0)
        r1.addWidget(self.spn_pr, 0)
        r1.addWidget(QLabel("Vel ±"), 0)
        self.spn_vr = QSpinBox(); self.spn_vr.setRange(0, 127); self.spn_vr.setValue(0)
        r1.addWidget(self.spn_vr, 0)
        r1.addStretch(1)
        root.addLayout(r1)

        r2 = QHBoxLayout(); r2.setSpacing(6)
        r2.addWidget(QLabel("Prob"), 0)
        self.sld_pb = QSlider(Qt.Orientation.Horizontal); self.sld_pb.setRange(0, 100); self.sld_pb.setValue(100)
        self.spn_pb = QDoubleSpinBox(); self.spn_pb.setRange(0.0, 1.0); self.spn_pb.setSingleStep(0.01); self.spn_pb.setDecimals(2); self.spn_pb.setMaximumWidth(80)
        r2.addWidget(self.sld_pb, 1)
        r2.addWidget(self.spn_pb, 0)
        root.addLayout(r2)

        self.spn_pr.valueChanged.connect(lambda _: self._debounce.start())
        self.spn_vr.valueChanged.connect(lambda _: self._debounce.start())
        self.sld_pb.valueChanged.connect(self._on_pb_sld)
        self.spn_pb.valueChanged.connect(self._on_pb_spn)

        self.refresh_from_project()

    def _key_wet(self) -> str:
        return f"afxchain:{self._track_id}:wet_gain"

    def _key_mix(self) -> str:
        return f"afxchain:{self._track_id}:mix"

    def _bind_automation(self) -> None:
        self._automation_param = {
            "wet": _register_automatable_param(self._services, self._track_id, self._key_wet(), "Wet Gain", 0.0, 2.0, float(self.dial_wet.value()) / 100.0),
            "mix": _register_automatable_param(self._services, self._track_id, self._key_mix(), "Mix", 0.0, 1.0, float(self.dial_mix.value()) / 100.0),
        }
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        pid = str(parameter_id)
        if pid == self._key_wet():
            v = max(0.0, min(2.0, float(value)))
            self.dial_wet.blockSignals(True)
            try:
                self.dial_wet.setValue(int(round(v * 100.0)))
            finally:
                self.dial_wet.blockSignals(False)
            self.lbl_wet.setText(f"{self.dial_wet.value()}%")
            self._on_change()
        elif pid == self._key_mix():
            v = max(0.0, min(1.0, float(value)))
            self.dial_mix.blockSignals(True)
            try:
                self.dial_mix.setValue(int(round(v * 100.0)))
            finally:
                self.dial_mix.blockSignals(False)
            self.lbl_mix.setText(f"{self.dial_mix.value()}%")
            self._on_change()

    def refresh_from_project(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        pr = int(params.get("pitch_range", 0) or 0)
        vr = int(params.get("vel_range", 0) or 0)
        pb = float(params.get("prob", 1.0) or 1.0)
        pr = max(0, min(24, pr))
        vr = max(0, min(127, vr))
        pb = max(0.0, min(1.0, pb))
        self.spn_pr.blockSignals(True); self.spn_vr.blockSignals(True)
        self.sld_pb.blockSignals(True); self.spn_pb.blockSignals(True)
        try:
            self.spn_pr.setValue(pr)
            self.spn_vr.setValue(vr)
            self.sld_pb.setValue(int(round(pb * 100.0)))
            self.spn_pb.setValue(pb)
        finally:
            self.spn_pr.blockSignals(False); self.spn_vr.blockSignals(False)
            self.sld_pb.blockSignals(False); self.spn_pb.blockSignals(False)

    def _on_pb_sld(self, v: int) -> None:
        x = max(0.0, min(1.0, float(v) / 100.0))
        self.spn_pb.blockSignals(True)
        try:
            self.spn_pb.setValue(x)
        finally:
            self.spn_pb.blockSignals(False)
        self._debounce.start()

    def _on_pb_spn(self, x: float) -> None:
        x = max(0.0, min(1.0, float(x)))
        self.sld_pb.blockSignals(True)
        try:
            self.sld_pb.setValue(int(round(x * 100.0)))
        finally:
            self.sld_pb.blockSignals(False)
        self._debounce.start()

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        params["pitch_range"] = int(self.spn_pr.value())
        params["vel_range"] = int(self.spn_vr.value())
        params["prob"] = float(self.spn_pb.value())
        self._emit_updated()


class AiComposerNoteFxWidget(_NoteFxBase):
    """Algorithmic MIDI composition engine (as Note-FX tool).

    Important UX constraints:
    - must never freeze the UI on load/refresh
    - must be fully visible / scrollable inside the device card

    This device does not apply processing in the audio engine yet. It is a
    *generator* UI: it writes MIDI notes into the selected clip or creates a new
    clip on the track.
    """

    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)

        from pydaw.music.ai_composer import GENRES, CONTEXTS, FORMS, INSTRUMENT_SETUPS

        outer = QVBoxLayout(self)
        outer.setContentsMargins(6, 6, 6, 6)
        outer.setSpacing(6)

        # Inside the DevicePanel chain, cards don't have vertical scroll.
        # Therefore, this widget must be self-scrollable to avoid clipped UI.
        content_parent = self
        if QScrollArea is not None:
            self._scroll = QScrollArea(self)
            self._scroll.setWidgetResizable(True)
            self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            self._scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            try:
                self._scroll.verticalScrollBar().setSingleStep(18)
            except Exception:
                pass
            content = QWidget(self._scroll)
            self._scroll.setWidget(content)
            outer.addWidget(self._scroll, 1)
            content_parent = content
        else:
            self._scroll = None

        root = QVBoxLayout(content_parent)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(6)

        # --- Controls
        box = QGroupBox("AI Composer — MIDI Generation")
        form = QFormLayout(box)
        form.setContentsMargins(8, 8, 8, 8)
        form.setSpacing(6)
        try:
            form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        except Exception:
            pass

        # Genres: use editable comboboxes so *any* genre can be typed.
        self.cmb_genre_a = QComboBox()
        self.cmb_genre_a.setEditable(True)
        try:
            self.cmb_genre_a.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        except Exception:
            pass
        self.cmb_genre_a.addItems(list(GENRES) + ["Custom"])

        self.txt_genre_a = QLineEdit()
        self.txt_genre_a.setPlaceholderText("Custom Genre A …")
        self._lab_custom_a = QLabel("Custom A")

        self.cmb_genre_b = QComboBox()
        self.cmb_genre_b.setEditable(True)
        try:
            self.cmb_genre_b.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        except Exception:
            pass
        self.cmb_genre_b.addItems(list(GENRES) + ["Custom"])

        self.txt_genre_b = QLineEdit()
        self.txt_genre_b.setPlaceholderText("Custom Genre B …")
        self._lab_custom_b = QLabel("Custom B")

        self.cmb_context = QComboBox(); self.cmb_context.addItems(list(CONTEXTS))
        self.cmb_form = QComboBox(); self.cmb_form.addItems(list(FORMS))
        self.cmb_instr = QComboBox(); self.cmb_instr.addItems(list(INSTRUMENT_SETUPS))

        self.spn_bars = QSpinBox(); self.spn_bars.setRange(1, 64); self.spn_bars.setValue(8)

        # Grid in beats: 1/16=0.25, 1/8=0.5, 1/4=1.0
        self.cmb_grid = QComboBox()
        self._grid_map = {
            "1/16": 0.25,
            "1/8": 0.5,
            "1/4": 1.0,
            "1/32": 0.125,
        }
        self.cmb_grid.addItems(list(self._grid_map.keys()))

        self.spn_swing = QDoubleSpinBox(); self.spn_swing.setRange(0.0, 1.0); self.spn_swing.setDecimals(2); self.spn_swing.setSingleStep(0.01)
        self.spn_density = QDoubleSpinBox(); self.spn_density.setRange(0.0, 1.0); self.spn_density.setDecimals(2); self.spn_density.setSingleStep(0.01)
        self.spn_hybrid = QDoubleSpinBox(); self.spn_hybrid.setRange(0.0, 1.0); self.spn_hybrid.setDecimals(2); self.spn_hybrid.setSingleStep(0.01)
        self.spn_seed = QSpinBox(); self.spn_seed.setRange(0, 2_000_000_000); self.spn_seed.setValue(1)

        form.addRow("Genre A (Struktur)", self.cmb_genre_a)
        form.addRow(self._lab_custom_a, self.txt_genre_a)
        form.addRow("Genre B (Rhythm)", self.cmb_genre_b)
        form.addRow(self._lab_custom_b, self.txt_genre_b)
        form.addRow("Kontext", self.cmb_context)
        form.addRow("Form", self.cmb_form)
        form.addRow("Instrument-Setup", self.cmb_instr)
        form.addRow("Länge (Bars)", self.spn_bars)
        form.addRow("Grid", self.cmb_grid)
        form.addRow("Swing", self.spn_swing)
        form.addRow("Density", self.spn_density)
        form.addRow("Hybrid (A↔B)", self.spn_hybrid)
        form.addRow("Seed", self.spn_seed)

        root.addWidget(box)

        # --- Hint
        self.lab_hint = QLabel(
            "Tipp: Genre A steuert Harmonik/Struktur (z.B. Barock/Fuge),\n"
            "Genre B steuert Rhythmus/Energie (z.B. Hardcore/Industrial).\n"
            "\nOutput: schreibt Noten in den ausgewählten MIDI-Clip oder erstellt einen neuen Clip auf der Spur."
        )
        self.lab_hint.setWordWrap(True)
        self.lab_hint.setStyleSheet("color:#7f7f7f; font-size:11px;")
        root.addWidget(self.lab_hint)

        # --- Actions (pinned below scroll)
        row = QHBoxLayout(); row.setSpacing(6)
        self.btn_generate = QPushButton("Generate → Clip")
        self.btn_overwrite = QPushButton("Overwrite Selected Clip")
        self.btn_snapshot_save = QPushButton("Save Snapshot…")
        self.btn_snapshot_load = QPushButton("Load Snapshot…")
        row.addWidget(self.btn_generate, 0)
        row.addWidget(self.btn_overwrite, 0)
        row.addStretch(1)
        row.addWidget(self.btn_snapshot_save, 0)
        row.addWidget(self.btn_snapshot_load, 0)
        outer.addLayout(row)

        # Wire changes → params (debounced)
        self.cmb_genre_a.currentTextChanged.connect(self._on_any_change)
        self.cmb_genre_b.currentTextChanged.connect(self._on_any_change)
        self.cmb_context.currentIndexChanged.connect(lambda _=0: self._on_any_change())
        self.cmb_form.currentIndexChanged.connect(lambda _=0: self._on_any_change())
        self.cmb_instr.currentIndexChanged.connect(lambda _=0: self._on_any_change())
        self.spn_bars.valueChanged.connect(lambda _=0: self._on_any_change())
        self.cmb_grid.currentIndexChanged.connect(lambda _=0: self._on_any_change())
        self.spn_swing.valueChanged.connect(lambda _=0: self._on_any_change())
        self.spn_density.valueChanged.connect(lambda _=0: self._on_any_change())
        self.spn_hybrid.valueChanged.connect(lambda _=0: self._on_any_change())
        self.spn_seed.valueChanged.connect(lambda _=0: self._on_any_change())
        self.txt_genre_a.textChanged.connect(lambda _="": self._on_any_change())
        self.txt_genre_b.textChanged.connect(lambda _="": self._on_any_change())

        # Actions
        self.btn_generate.clicked.connect(self._on_generate_new_clip)
        self.btn_overwrite.clicked.connect(self._on_overwrite_selected)
        self.btn_snapshot_save.clicked.connect(self._on_snapshot_save)
        self.btn_snapshot_load.clicked.connect(self._on_snapshot_load)

        self.refresh_from_project()
        self._update_custom_rows()

    def _on_any_change(self) -> None:
        # Keep UI responsive: update visibility without triggering loops.
        try:
            self._update_custom_rows()
        except Exception:
            pass
        self._debounce.start()

    def _update_custom_rows(self) -> None:
        """Show custom text fields only when explicitly requested.

        This keeps the card compact (often no vertical scroll needed) while still
        supporting arbitrary genres via editable comboboxes.
        """
        try:
            a_is_custom = str(self.cmb_genre_a.currentText() or "") == "Custom"
            b_is_custom = str(self.cmb_genre_b.currentText() or "") == "Custom"
            for w in (getattr(self, '_lab_custom_a', None), getattr(self, 'txt_genre_a', None)):
                if w is not None:
                    w.setVisible(bool(a_is_custom))
            for w in (getattr(self, '_lab_custom_b', None), getattr(self, 'txt_genre_b', None)):
                if w is not None:
                    w.setVisible(bool(b_is_custom))
        except Exception:
            pass

    def _params_from_ui(self) -> dict:
        return {
            "genre_a": str(self.cmb_genre_a.currentText()),
            "genre_b": str(self.cmb_genre_b.currentText()),
            "custom_genre_a": str(self.txt_genre_a.text() or ""),
            "custom_genre_b": str(self.txt_genre_b.text() or ""),
            "context": str(self.cmb_context.currentText()),
            "form": str(self.cmb_form.currentText()),
            "instrument_setup": str(self.cmb_instr.currentText()),
            "bars": int(self.spn_bars.value()),
            "grid": float(self._grid_map.get(str(self.cmb_grid.currentText()), 0.25)),
            "swing": float(self.spn_swing.value()),
            "density": float(self.spn_density.value()),
            "hybrid": float(self.spn_hybrid.value()),
            "seed": int(self.spn_seed.value()),
        }

    def _key_wet(self) -> str:
        return f"afxchain:{self._track_id}:wet_gain"

    def _key_mix(self) -> str:
        return f"afxchain:{self._track_id}:mix"

    def _bind_automation(self) -> None:
        self._automation_param = {
            "wet": _register_automatable_param(self._services, self._track_id, self._key_wet(), "Wet Gain", 0.0, 2.0, float(self.dial_wet.value()) / 100.0),
            "mix": _register_automatable_param(self._services, self._track_id, self._key_mix(), "Mix", 0.0, 1.0, float(self.dial_mix.value()) / 100.0),
        }
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        pid = str(parameter_id)
        if pid == self._key_wet():
            v = max(0.0, min(2.0, float(value)))
            self.dial_wet.blockSignals(True)
            try:
                self.dial_wet.setValue(int(round(v * 100.0)))
            finally:
                self.dial_wet.blockSignals(False)
            self.lbl_wet.setText(f"{self.dial_wet.value()}%")
            self._on_change()
        elif pid == self._key_mix():
            v = max(0.0, min(1.0, float(value)))
            self.dial_mix.blockSignals(True)
            try:
                self.dial_mix.setValue(int(round(v * 100.0)))
            finally:
                self.dial_mix.blockSignals(False)
            self.lbl_mix.setText(f"{self.dial_mix.value()}%")
            self._on_change()

    def refresh_from_project(self) -> None:
        """Refresh without re-entrancy loops.

        IMPORTANT: do *not* rely on self.blockSignals(True) because it does not
        block child widget signals. Use QSignalBlocker per widget.
        """
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return

        def _set_combo_text(cmb: QComboBox, value: str) -> None:
            try:
                ix = cmb.findText(str(value))
                if ix >= 0:
                    cmb.setCurrentIndex(ix)
                else:
                    # editable combobox: allow arbitrary text
                    cmb.setCurrentText(str(value))
            except Exception:
                try:
                    cmb.setCurrentText(str(value))
                except Exception:
                    pass

        blockers = []
        try:
            blockers = [
                QSignalBlocker(self.cmb_genre_a),
                QSignalBlocker(self.txt_genre_a),
                QSignalBlocker(self.cmb_genre_b),
                QSignalBlocker(self.txt_genre_b),
                QSignalBlocker(self.cmb_context),
                QSignalBlocker(self.cmb_form),
                QSignalBlocker(self.cmb_instr),
                QSignalBlocker(self.spn_bars),
                QSignalBlocker(self.cmb_grid),
                QSignalBlocker(self.spn_swing),
                QSignalBlocker(self.spn_density),
                QSignalBlocker(self.spn_hybrid),
                QSignalBlocker(self.spn_seed),
            ]
        except Exception:
            blockers = []

        try:
            _set_combo_text(self.cmb_genre_a, str(params.get("genre_a", "Barock (Bach/Fuge)")))
            _set_combo_text(self.cmb_genre_b, str(params.get("genre_b", "Electro")))
            self.txt_genre_a.setText(str(params.get("custom_genre_a", "") or ""))
            self.txt_genre_b.setText(str(params.get("custom_genre_b", "") or ""))
            _set_combo_text(self.cmb_context, str(params.get("context", "Neutral")))
            _set_combo_text(self.cmb_form, str(params.get("form", "Mini-Fuge (Subject/Answer)")))
            _set_combo_text(self.cmb_instr, str(params.get("instrument_setup", "Kammermusik-Setup")))
            self.spn_bars.setValue(int(params.get("bars", 8) or 8))

            grid_val = float(params.get("grid", 0.25) or 0.25)
            best_k = "1/16"; best_d = 999.0
            for k, v in self._grid_map.items():
                d = abs(float(v) - grid_val)
                if d < best_d:
                    best_k, best_d = k, d
            _set_combo_text(self.cmb_grid, best_k)

            self.spn_swing.setValue(float(params.get("swing", 0.0) or 0.0))
            self.spn_density.setValue(float(params.get("density", 0.65) or 0.65))
            self.spn_hybrid.setValue(float(params.get("hybrid", 0.55) or 0.55))
            self.spn_seed.setValue(int(params.get("seed", 1) or 1))
        finally:
            blockers = []

        self._update_custom_rows()

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        newp = self._params_from_ui()
        # Only emit project_updated if something actually changed.
        changed = False
        try:
            for k, v in newp.items():
                if params.get(k) != v:
                    changed = True
                    break
        except Exception:
            changed = True
        if not changed:
            return
        params.update(newp)
        self._emit_updated()

    # --- actions

    def _get_time_signature(self) -> str:
        ps = getattr(self._services, "project", None) if self._services is not None else None
        try:
            return str(getattr(ps.ctx.project, "time_signature", "4/4") or "4/4")
        except Exception:
            return "4/4"

    def _on_generate_new_clip(self) -> None:
        """Create a new MIDI clip on this track and fill it."""
        ps = getattr(self._services, "project", None) if self._services is not None else None
        if ps is None:
            return

        try:
            # Place at playhead if available, else bar 1
            transport = getattr(self._services, "transport", None) if self._services is not None else None
            start = float(getattr(transport, "current_beat", 0.0) if transport is not None else 0.0)
        except Exception:
            start = 0.0

        try:
            clip_id = ps.add_midi_clip_at(str(self._track_id), start_beats=float(start), length_beats=4.0, label="AI Clip")
        except Exception as e:
            try:
                QMessageBox.warning(self, "AI Composer", f"Konnte Clip nicht erstellen: {e}")
            except Exception:
                pass
            return

        self._render_into_clip(str(clip_id), overwrite=True)

    def _on_overwrite_selected(self) -> None:
        ps = getattr(self._services, "project", None) if self._services is not None else None
        if ps is None:
            return
        clip_id = ""
        try:
            clip_id = str(ps.active_clip_id() or "")
        except Exception:
            clip_id = str(getattr(ps, "_active_clip_id", "") or "")
        if not clip_id:
            try:
                QMessageBox.information(self, "AI Composer", "Kein Clip ausgewählt. Nutze 'Generate → Clip' oder wähle einen MIDI-Clip.")
            except Exception:
                pass
            return
        self._render_into_clip(str(clip_id), overwrite=True)

    def _render_into_clip(self, clip_id: str, *, overwrite: bool = True) -> None:
        ps = getattr(self._services, "project", None) if self._services is not None else None
        if ps is None:
            return
        try:
            from pydaw.music.ai_composer import ComposerParams, generate_clip_notes
            p = self._params_from_ui()
            params = ComposerParams(
                genre_a=str(p.get("genre_a", "Barock (Bach/Fuge)")),
                genre_b=str(p.get("genre_b", "Electro")),
                custom_genre_a=str(p.get("custom_genre_a", "")),
                custom_genre_b=str(p.get("custom_genre_b", "")),
                context=str(p.get("context", "Neutral")),
                form=str(p.get("form", "Mini-Fuge (Subject/Answer)")),
                instrument_setup=str(p.get("instrument_setup", "Kammermusik-Setup")),
                bars=int(p.get("bars", 8) or 8),
                grid=float(p.get("grid", 0.25) or 0.25),
                swing=float(p.get("swing", 0.0) or 0.0),
                density=float(p.get("density", 0.65) or 0.65),
                hybrid=float(p.get("hybrid", 0.55) or 0.55),
                seed=int(p.get("seed", 1) or 1),
            )

            ts = self._get_time_signature()
            start = 0.0
            new_notes = generate_clip_notes(start_beats=float(start), time_signature=ts, params=params)
        except Exception as e:
            try:
                QMessageBox.warning(self, "AI Composer", f"Komposition fehlgeschlagen: {e}")
            except Exception:
                pass
            return

        try:
            before = ps.snapshot_midi_notes(str(clip_id))
        except Exception:
            before = []

        try:
            if overwrite:
                ps.set_midi_notes(str(clip_id), list(new_notes))
            else:
                cur = list(ps.get_midi_notes(str(clip_id)) or [])
                cur.extend(list(new_notes))
                ps.set_midi_notes(str(clip_id), cur)
        except Exception as e:
            try:
                QMessageBox.warning(self, "AI Composer", f"Konnte Noten nicht schreiben: {e}")
            except Exception:
                pass
            return

        # register undo step for the MIDI note edit
        try:
            ps.commit_midi_notes_edit(str(clip_id), before=before, label="AI Composer")
        except Exception:
            # fallback: emit update
            try:
                ps.project_updated.emit()
            except Exception:
                pass

    def _on_snapshot_save(self) -> None:
        try:
            path, _ = QFileDialog.getSaveFileName(self, "AI Composer Snapshot speichern", "ai_composer_snapshot.json", "JSON (*.json)")
            if not path:
                return
            import json
            with open(str(path), "w", encoding="utf-8") as f:
                json.dump(self._params_from_ui(), f, indent=2, ensure_ascii=False)
        except Exception as e:
            try:
                QMessageBox.warning(self, "AI Composer", f"Snapshot speichern fehlgeschlagen: {e}")
            except Exception:
                pass

    def _on_snapshot_load(self) -> None:
        try:
            path, _ = QFileDialog.getOpenFileName(self, "AI Composer Snapshot laden", "", "JSON (*.json)")
            if not path:
                return
            import json
            with open(str(path), "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                return

            # write into device params (single source of truth)
            dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
            if dev is None:
                return
            params.update({k: data.get(k) for k in data.keys()})
            self.refresh_from_project()
            self._emit_updated()
        except Exception as e:
            try:
                QMessageBox.warning(self, "AI Composer", f"Snapshot laden fehlgeschlagen: {e}")
            except Exception:
                pass


class LadspaAudioFxWidget(QWidget):
    """Generic LADSPA/DSSI Audio-FX parameter widget.

    - Reads LADSPA control ports via ctypes (ladspa_host.py).
    - Writes to RTParamStore (smooth) and persists values into device params.
    """

    def __init__(self, services: Any, track_id: str, device_id: str, plugin_id: str, so_path: str, parent=None):
        super().__init__(parent)
        self._services = services
        self._track_id = str(track_id or "")
        self._device_id = str(device_id or "")
        self._plugin_id = str(plugin_id or "")
        self._so_path = str(so_path or "")

        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(160)
        self._debounce.timeout.connect(self._flush_to_project)

        self._controls: list = []  # LadspaPortInfo list
        self._rows: dict = {}  # port_index -> (row_widget, slider, spin, (mn, mx, df))
        self._automation_params: dict = {}
        self._automation_connected = False
        self._ui_sync_timer = QTimer(self)
        self._ui_sync_timer.setInterval(50)
        self._ui_sync_timer.timeout.connect(self._sync_from_rt)
        try:
            self.destroyed.connect(self._disconnect_automation)
        except Exception:
            pass

        self._build()

    def _rt(self):
        ae = getattr(self._services, "audio_engine", None) if self._services is not None else None
        return getattr(ae, "rt_params", None) if ae is not None else None

    def _disconnect_automation(self, *_args) -> None:
        am = _get_automation_manager(self._services)
        if am is not None and self._automation_connected:
            try:
                am.parameter_changed.disconnect(self._on_automation_changed)
            except Exception:
                pass
        self._automation_connected = False

    def _key(self, port_index: int) -> str:
        return f"afx:{self._track_id}:{self._device_id}:ladspa:{port_index}"

    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(4)

        # Header
        top = QHBoxLayout()
        kind = "LADSPA" if "ladspa" in self._plugin_id.lower() else "DSSI"
        lab = QLabel(kind)
        lab.setStyleSheet("font-weight: 600;")
        top.addWidget(lab, 0)

        # Show path
        short_path = os.path.basename(self._so_path) if self._so_path else "(unknown)"
        self._lbl_path = QLabel(short_path)
        self._lbl_path.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self._lbl_path.setStyleSheet("color: #9aa0a6; font-size: 11px;")
        top.addWidget(self._lbl_path, 1)
        root.addLayout(top)

        # Status row
        self._row_status = QHBoxLayout()
        self._lbl_dsp = QLabel("")
        self._lbl_dsp.setStyleSheet("font-size: 11px; color: #9aa0a6;")
        self._row_status.addWidget(self._lbl_dsp, 1)

        self._btn_rebuild = QPushButton("Rebuild FX")
        self._btn_rebuild.setToolTip("Rebuild per-track Audio-FX maps (safe).")
        self._btn_rebuild.clicked.connect(self._safe_rebuild_fx_maps)
        self._btn_rebuild.setVisible(False)
        self._row_status.addWidget(self._btn_rebuild, 0)
        root.addLayout(self._row_status)

        # Search
        self._search = QLineEdit()
        self._search.setPlaceholderText("Search parameter…")
        self._search.textChanged.connect(self._apply_filter)
        root.addWidget(self._search)

        # Scroll area for controls
        if QScrollArea is not None:
            self._scroll = QScrollArea()
            self._scroll.setWidgetResizable(True)
            self._scroll.setFrameShape(QScrollArea.Shape.NoFrame)
            self._body = QWidget()
            self._body_l = QVBoxLayout(self._body)
            self._body_l.setContentsMargins(0, 0, 0, 0)
            self._body_l.setSpacing(3)
            self._scroll.setWidget(self._body)
            root.addWidget(self._scroll, 1)
        else:
            self._scroll = None
            self._body = QWidget()
            self._body_l = QVBoxLayout(self._body)
            self._body_l.setContentsMargins(0, 0, 0, 0)
            self._body_l.setSpacing(3)
            root.addWidget(self._body, 1)

        self._load_controls_and_build_rows()
        self.refresh_from_project()
        try:
            self._ui_sync_timer.start()
        except Exception:
            pass

    def _load_controls_and_build_rows(self) -> None:
        self._load_error = ""  # Remember error for refresh_from_project
        try:
            from pydaw.audio.ladspa_host import describe_plugin, _resolve_plugin_index

            # Step 1: resolve index
            try:
                plugin_idx = _resolve_plugin_index(self._so_path, self._plugin_id)
            except Exception as e:
                self._load_error = f"Index resolve failed: {e}"
                self._show_error_label(self._load_error)
                return

            # Step 2: describe
            try:
                info = describe_plugin(self._so_path, plugin_idx)
            except Exception as e:
                self._load_error = f"describe_plugin failed: {e}"
                self._show_error_label(self._load_error)
                return

            if info is None:
                self._load_error = f"Cannot load {os.path.basename(self._so_path)} (describe returned None)"
                self._show_error_label(self._load_error)
                return

            # Plugin name header
            if info.name:
                self._lbl_path.setText(f"{info.name} ({os.path.basename(self._so_path)})")

            # Show port summary
            n_ain = sum(1 for p in info.ports if p.is_audio and p.is_input)
            n_aout = sum(1 for p in info.ports if p.is_audio and p.is_output)
            n_cin = sum(1 for p in info.ports if p.is_control and p.is_input)
            n_cout = sum(1 for p in info.ports if p.is_control and p.is_output)

            # Gather input control ports
            self._controls = [p for p in info.ports if p.is_control and p.is_input]

            if not self._controls:
                self._lbl_dsp.setText(f"Ports: ain={n_ain} aout={n_aout} — No controllable parameters")
                return

            self._lbl_dsp.setText(f"Controls: {len(self._controls)} | Audio: {n_ain}→{n_aout}")

            for port in self._controls:
                mn = port.lower
                mx = port.upper
                df = port.default

                row = QWidget()
                rl = QHBoxLayout(row)
                rl.setContentsMargins(0, 0, 0, 0)
                rl.setSpacing(4)

                lbl = QLabel(port.name)
                lbl.setFixedWidth(120)
                lbl.setToolTip(f"Port {port.index}: {port.name} [{mn:.4g} … {mx:.4g}]")
                rl.addWidget(lbl, 0)

                sld = QSlider(Qt.Orientation.Horizontal)
                sld.setRange(0, 1000)
                rl.addWidget(sld, 1)

                spn = QDoubleSpinBox()
                spn.setDecimals(4)
                spn.setRange(float(mn), float(mx))
                spn.setSingleStep(max(0.001, (mx - mn) / 200.0))
                spn.setFixedWidth(80)
                rl.addWidget(spn, 0)

                self._body_l.addWidget(row)
                self._rows[port.index] = (row, sld, spn, (mn, mx, df))
                pid = self._key(port.index)
                _install_automation_menu(self, lbl, pid, lambda df=df: float(df))
                _install_automation_menu(self, sld, pid, lambda df=df: float(df))
                _install_automation_menu(self, spn, pid, lambda df=df: float(df))
                self._automation_params[port.index] = _register_automatable_param(
                    self._services, self._track_id, pid, getattr(port, "name", f"Port {port.index}"), mn, mx, df
                )

                # Bidirectional slider <-> spin
                def _make_slider_cb(p_idx, s, sp, lo, hi):
                    def cb(v):
                        val = lo + (v / 1000.0) * (hi - lo)
                        with QSignalBlocker(sp):
                            sp.setValue(float(val))
                        self._set_value(p_idx, float(val))
                    return cb

                def _make_spin_cb(p_idx, s, sp, lo, hi):
                    def cb(val):
                        pos = 0
                        if hi > lo:
                            pos = int(round(((val - lo) / (hi - lo)) * 1000.0))
                        with QSignalBlocker(s):
                            s.setValue(max(0, min(1000, pos)))
                        self._set_value(p_idx, float(val))
                    return cb

                sld.valueChanged.connect(_make_slider_cb(port.index, sld, spn, mn, mx))
                spn.valueChanged.connect(_make_spin_cb(port.index, sld, spn, mn, mx))

            self._body_l.addStretch(1)

            am = _get_automation_manager(self._services)
            if am is not None and not self._automation_connected:
                try:
                    am.parameter_changed.connect(self._on_automation_changed)
                    self._automation_connected = True
                except Exception:
                    self._automation_connected = False

        except Exception as e:
            import traceback
            self._load_error = f"LADSPA load error: {e}"
            traceback.print_exc()
            self._show_error_label(self._load_error)

    def _show_error_label(self, msg: str) -> None:
        """Show a visible error in the scroll body."""
        try:
            err = QLabel(msg)
            err.setWordWrap(True)
            err.setStyleSheet("color: #ff6b6b; padding: 8px;")
            self._body_l.addWidget(err)
        except Exception:
            pass

    def _apply_ui_value(self, port_index: int, value: float) -> None:
        try:
            row = self._rows.get(int(port_index))
            if not row:
                return
            _row, sld, spn, (mn, mx, _df) = row
            val = float(max(mn, min(mx, float(value))))
            pos = 0
            if mx > mn:
                pos = int(round(((val - mn) / (mx - mn)) * 1000.0))
            with QSignalBlocker(sld):
                sld.setValue(max(0, min(1000, pos)))
            with QSignalBlocker(spn):
                spn.setValue(val)
        except Exception:
            pass

    def _sync_from_rt(self) -> None:
        try:
            if not self.isVisible():
                return
        except Exception:
            pass
        rt = self._rt()
        if rt is None:
            return
        try:
            for idx, (_row, _sld, _spn, (_mn, _mx, _df)) in self._rows.items():
                key = self._key(idx)
                default_val = float(getattr(_spn, 'value', lambda: 0.0)())
                val = default_val
                try:
                    if hasattr(rt, 'get_smooth'):
                        val = float(rt.get_smooth(key, default_val))
                    elif hasattr(rt, 'get_target'):
                        val = float(rt.get_target(key, default_val))
                except Exception:
                    val = default_val
                self._apply_ui_value(idx, val)
        except Exception:
            pass

    def _on_automation_changed(self, parameter_id: str, value: float) -> None:
        try:
            pid = str(parameter_id)
            for idx in self._rows.keys():
                if pid != self._key(idx):
                    continue
                val = float(value)
                self._apply_ui_value(idx, val)
                self._set_value(idx, val, update_param=False)
                break
        except RuntimeError:
            self._disconnect_automation()

    def _set_value(self, port_index: int, value: float, update_param: bool = True) -> None:
        # RT write
        rt = self._rt()
        try:
            if rt is not None:
                rt.set_param(self._key(port_index), float(value))
        except Exception:
            pass
        if update_param:
            try:
                param = self._automation_params.get(int(port_index))
                if param is not None:
                    param.set_value(float(value))
            except Exception:
                pass
        # Persist
        try:
            dev, params = _find_audio_fx_dev(self._services, self._track_id, self._device_id)
            if params is not None:
                params[str(port_index)] = float(value)
        except Exception:
            pass
        self._debounce.start()

    def _legacy_chain_key_wet_unused(self) -> str:
        return f"afxchain:{self._track_id}:wet_gain"

    def _legacy_chain_key_mix_unused(self) -> str:
        return f"afxchain:{self._track_id}:mix"

    def _legacy_chain_bind_automation_unused(self) -> None:
        self._automation_param = {
            "wet": _register_automatable_param(self._services, self._track_id, self._key_wet(), "Wet Gain", 0.0, 2.0, float(self.dial_wet.value()) / 100.0),
            "mix": _register_automatable_param(self._services, self._track_id, self._key_mix(), "Mix", 0.0, 1.0, float(self.dial_mix.value()) / 100.0),
        }
        am = _get_automation_manager(self._services)
        if am is not None and not self._automation_connected:
            try:
                am.parameter_changed.connect(self._on_automation_changed)
                self._automation_connected = True
            except Exception:
                self._automation_connected = False

    def _legacy_chain_on_automation_changed_unused(self, parameter_id: str, value: float) -> None:
        pid = str(parameter_id)
        if pid == self._key_wet():
            v = max(0.0, min(2.0, float(value)))
            self.dial_wet.blockSignals(True)
            try:
                self.dial_wet.setValue(int(round(v * 100.0)))
            finally:
                self.dial_wet.blockSignals(False)
            self.lbl_wet.setText(f"{self.dial_wet.value()}%")
            self._on_change()
        elif pid == self._key_mix():
            v = max(0.0, min(1.0, float(value)))
            self.dial_mix.blockSignals(True)
            try:
                self.dial_mix.setValue(int(round(v * 100.0)))
            finally:
                self.dial_mix.blockSignals(False)
            self.lbl_mix.setText(f"{self.dial_mix.value()}%")
            self._on_change()

    def refresh_from_project(self) -> None:
        # If loading failed, keep the error visible
        if getattr(self, '_load_error', ''):
            self._lbl_dsp.setText(self._load_error)
            self._lbl_dsp.setStyleSheet("font-size: 11px; color: #ff6b6b;")
            return
        dev, params = _find_audio_fx_dev(self._services, self._track_id, self._device_id)
        if params is None:
            return
        rt = self._rt()

        for port in self._controls:
            idx = port.index
            if idx not in self._rows:
                continue
            _row, sld, spn, (mn, mx, df) = self._rows[idx]
            try:
                val = float(params.get(str(idx), df))
            except Exception:
                val = df
            if val < mn:
                val = mn
            if val > mx:
                val = mx

            try:
                pos = 0
                if mx > mn:
                    pos = int(round(((val - mn) / (mx - mn)) * 1000.0))
                with QSignalBlocker(sld):
                    sld.setValue(max(0, min(1000, pos)))
                with QSignalBlocker(spn):
                    spn.setValue(float(val))
            except Exception:
                pass

            try:
                if rt is not None and hasattr(rt, "ensure"):
                    rt.ensure(self._key(idx), float(val))
                elif rt is not None:
                    rt.set_param(self._key(idx), float(val))
            except Exception:
                pass

        # DSP status check
        try:
            active = self._dsp_is_active()
            if active:
                n = len(self._controls)
                self._lbl_dsp.setText(f"DSP: ACTIVE — {n} controls")
                self._btn_rebuild.setVisible(False)
            else:
                # Try to find the error from the audio engine
                err_msg = ""
                try:
                    ae = getattr(self._services, "audio_engine", None)
                    fx_map = getattr(ae, "_track_audio_fx_map", None) if ae else None
                    if isinstance(fx_map, dict):
                        chain = fx_map.get(str(self._track_id))
                        if chain is None:
                            err_msg = "no FX chain for track"
                        elif not getattr(chain, "devices", None):
                            err_msg = "chain has 0 devices"
                except Exception:
                    pass
                hint = f" ({err_msg})" if err_msg else ""
                self._lbl_dsp.setText(f"DSP: INACTIVE{hint} — try Rebuild FX")
                self._btn_rebuild.setVisible(True)
        except Exception:
            pass

    def _dsp_is_active(self) -> bool:
        try:
            ae = getattr(self._services, "audio_engine", None) if self._services is not None else None
            fx_map = getattr(ae, "_track_audio_fx_map", None) if ae is not None else None
            if not isinstance(fx_map, dict):
                return False
            chain = fx_map.get(str(self._track_id))
            devs = getattr(chain, "devices", None)
            if not isinstance(devs, list):
                return False
            for fx in devs:
                try:
                    if str(getattr(fx, "device_id", "")) == str(self._device_id):
                        return True
                except Exception:
                    continue
        except Exception:
            return False
        return False

    def _flush_to_project(self) -> None:
        ps = getattr(self._services, "project", None) if self._services is not None else None
        try:
            if ps is not None and hasattr(ps, "project_changed"):
                ps.project_changed.emit()
        except Exception:
            pass

    def _safe_rebuild_fx_maps(self) -> None:
        try:
            ae = getattr(self._services, "audio_engine", None) if self._services is not None else None
            if ae is not None and hasattr(ae, "rebuild_fx_maps"):
                ps = getattr(self._services, "project", None) if self._services is not None else None
                proj = getattr(ps, "project", None) if ps is not None else None
                if proj is not None:
                    ae.rebuild_fx_maps(proj)
                    self.refresh_from_project()
        except Exception:
            pass

    def _apply_filter(self, text: str) -> None:
        text = (text or "").strip().lower()
        for idx, (row, _sld, _spn, _info) in self._rows.items():
            try:
                port = next((p for p in self._controls if p.index == idx), None)
                name = (port.name if port else "").lower()
                row.setVisible(not text or text in name or text in str(idx))
            except Exception:
                pass


def make_audio_fx_widget(services: Any, track_id: str, device: dict) -> Optional[QWidget]:
    pid_raw = str(device.get("plugin_id") or device.get("type") or "")
    pid = pid_raw.strip()
    pid_norm = pid.lower()
    did = str(device.get("id") or "")
    if not did:
        return None
    if pid == "chrono.fx.gain":
        return GainFxWidget(services, track_id, did)
    if pid == "chrono.fx.distortion":
        return DistortionFxWidget(services, track_id, did)
    # ── v105: Bitwig-Style Audio-FX ──────────────────────────────
    try:
        from pydaw.ui.fx_audio_widgets import (
            EQ5FxWidget, Delay2FxWidget, ReverbFxWidget, CombFxWidget,
            CompressorFxWidget, FilterPlusFxWidget, DistortionPlusFxWidget,
            DynamicsFxWidget, FlangerFxWidget, PitchShifterFxWidget,
            TremoloFxWidget, PeakLimiterFxWidget, ChorusFxWidget,
            XYFxWidget, DeEsserFxWidget,
        )
        _NEW_FX = {
            "chrono.fx.eq5": EQ5FxWidget,
            "chrono.fx.delay2": Delay2FxWidget,
            "chrono.fx.reverb": ReverbFxWidget,
            "chrono.fx.comb": CombFxWidget,
            "chrono.fx.compressor": CompressorFxWidget,
            "chrono.fx.filter_plus": FilterPlusFxWidget,
            "chrono.fx.distortion_plus": DistortionPlusFxWidget,
            "chrono.fx.dynamics": DynamicsFxWidget,
            "chrono.fx.flanger": FlangerFxWidget,
            "chrono.fx.pitch_shifter": PitchShifterFxWidget,
            "chrono.fx.tremolo": TremoloFxWidget,
            "chrono.fx.peak_limiter": PeakLimiterFxWidget,
            "chrono.fx.chorus": ChorusFxWidget,
            "chrono.fx.xy_fx": XYFxWidget,
            "chrono.fx.de_esser": DeEsserFxWidget,
        }
        cls = _NEW_FX.get(pid)
        if cls is not None:
            return cls(services, track_id, did)
    except Exception:
        pass
    if pid_norm.startswith("ext.lv2:"):
        # Normalize whitespace/case but keep exact URI part
        uri = pid.split(":", 1)[1] if ":" in pid else ""
        return Lv2AudioFxWidget(services, track_id, did, f"ext.lv2:{uri}")
    if pid_norm.startswith("ext.ladspa:") or pid_norm.startswith("ext.dssi:"):
        so_path = pid.split(":", 1)[1] if ":" in pid else ""
        return LadspaAudioFxWidget(services, track_id, did, pid, so_path)
    # unknown FX: show placeholder label
    lab = QLabel(f"{pid}\n(no UI yet)")
    lab.setWordWrap(True)
    return lab


def make_note_fx_widget(services: Any, track_id: str, device: dict) -> Optional[QWidget]:
    pid = str(device.get("plugin_id") or device.get("type") or "")
    did = str(device.get("id") or "")
    if not did:
        return None
    if pid == "chrono.note_fx.transpose":
        return TransposeNoteFxWidget(services, track_id, did)
    if pid == "chrono.note_fx.velocity_scale":
        return VelocityScaleNoteFxWidget(services, track_id, did)
    if pid == "chrono.note_fx.scale_snap":
        return ScaleSnapNoteFxWidget(services, track_id, did)
    if pid == "chrono.note_fx.chord":
        return ChordNoteFxWidget(services, track_id, did)
    if pid == "chrono.note_fx.arp":
        return ArpNoteFxWidget(services, track_id, did)
    if pid == "chrono.note_fx.random":
        return RandomNoteFxWidget(services, track_id, did)
    if pid == "chrono.note_fx.ai_composer":
        return AiComposerNoteFxWidget(services, track_id, did)
    # Others: show placeholder for forward compatibility
    lab = QLabel(f"{pid}\n(MVP UI missing)")
    lab.setWordWrap(True)
    return lab
