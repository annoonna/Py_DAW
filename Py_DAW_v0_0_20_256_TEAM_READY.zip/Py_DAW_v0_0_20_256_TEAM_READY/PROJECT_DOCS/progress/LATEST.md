# v0.0.20.240 — Aktueller Stand

## v0.0.20.240 — LV2: Output-Pair Selector (fix: Effekte hörbar machen)
- **Problem:** Einige LV2 Effekte wirken *nicht hörbar*, obwohl `DSP: ACTIVE`, weil Plugins **mehr als 2 Audio-Outs** liefern (z.B. Dry-Tap/Monitor/Wet/Aux).
  Auto-Select kann je nach Plugin trotzdem daneben liegen.
- **Neu (SAFE):** Im LV2 Device gibt es jetzt eine **Output-Auswahl** (Out 0/1, 2/3, … + Auto).
  → Du kannst live umschalten, welche Output-Paarung zurück in die DAW kopiert wird.
- **Persistenz:** Auswahl wird im Device unter `__out_sel` gespeichert (ohne UI-Rebuild-Spam).


## v0.0.20.239 — LV2: Auto-Select Wet Outputs ("DSP ACTIVE aber trocken")
- **Fix:** Einige LV2 Plugins liefern mehr als 2 Audio-Outs (Dry-Tap/Monitor/Aux). Trotz Port-Ordering konnte die erste Paarung weiterhin "dry" sein.
  → Der Host wählt jetzt beim Init automatisch die **hörbarste** Output-Paarung (winziger Impuls-Test, sehr leise) und kopiert diese zurück.
- **SAFE:** Alle Ports bleiben verbunden; nur die Rückgabe-Paarung wird gewählt. Keine Core-/Routing-Änderungen.

## v0.0.20.238 — LV2: Reverb/Delay hörbar + Offline Render wirklich SAFE
- **Fix:** Viele LV2 Effekte waren trotz `DSP: ACTIVE` praktisch **nicht hörbar**, weil einige Plugins mehrere Audio-Outs haben (z.B. Dry-Taps) und der Host bisher die *ersten* Output-Ports nach Index kopiert hat.
  → jetzt heuristische **Port-Auswahl/Ordering**: bevorzugt `out/output/wet/fx`, meidet `dry`.
- **Fix:** `Audition`/Insert-Heuristik für **Dry/Wet** ist jetzt weniger falsch (dry_wet→MAX, wet_dry→MIN).
- **Neu (SAFE):** „Offline: Render WAV through LV2…“ läuft jetzt **in einem Subprocess**.
  → crashende LV2 (.so) können den Host nicht mehr killen; im Subprocess wird `PYDAW_LV2_UNSAFE=1` genutzt.

# v0.0.20.227 — Aktueller Stand

## v0.0.20.227 — LV2: UI/Hint Fixes + Prefix Hardening
- Plugins-Tab Status zeigt jetzt den **LV2 Host-Status** (OK / Hinweis), statt „Hosting folgt separat“.
- LV2 Device UI Erkennung ist robuster (plugin_id strip/case), damit `ext.lv2:<URI>` nicht als „no UI yet“ fällt.
- Bugfix in `fx_chain.py` (tid/rt_params Referenzen) beim Seeden von LV2 Param Defaults.


## v0.0.20.210 — Pro Drum Machine: Region Start/End + Per‑Slot FX Rack (Safe)
- **Fix:** One‑Shot Playback/Preview läuft jetzt standardmäßig **bis zum Sample‑Ende** (oder bis `End`‑Marker).
- **Neu:** Region pro Slot: **Start** + **End** (0..100%) im Slot‑Editor.
- **Neu:** Per‑Slot **FX Rack…** Dialog: EQ5 (optional), Distortion, Delay (Mix/Time/FB), Reverb, Chorus.
- **UI:** Waveform‑Anzeige zeigt Start/End Marker zusätzlich.

## Hotfix / Stabilität
- **Qt/PyQt6 Hardening:** verhindert harte SIGABRT-Abstürze ("Unhandled Python exception") auf manchen Wayland/Qt6 Setups.
  - wrappt Qt-virtual Methods (paintEvent/eventFilter/…) für pydaw.ui Klassen und schluckt Exceptions (mit Log-Output).
- **PyQt6 Slot-Safety:** signal.connect wrappt Python-Slots defensiv (try/except), um qFatal("Unhandled Python exception") zu verhindern.
- TrackList startDrag Override defensiv (kein Start-Crash durch fehlende Methode).

## UI (Pro-Workflow)
- Track-Header ▾ (Routing/Arm/Monitor/Add Device) + Favorites/Recents + Search.
- Browser Tabs ⭐ Favorites / 🕘 Recents + Stern-Toggle direkt in Listen.
- Clip Micro-Controls: ▾ Menü + Fade-Handles + Gain/Pan Mini-Handles (Arranger + Audio Editor).


## v0.0.20.189 Hotfix — Regression-Fix (Nichts kaputt machen)
- Fix: QAction/QPushButton Signal-Signaturen wieder kompatibel (lambda _=False), damit Menüs/Buttons wie in v0.0.20.176 funktionieren.
- Fix: ProjectService.get_clip() (UI-Kompatibilität für Clip Launcher + Audio Editor).
- Fix: AudioEventEditor robustes Clip-Lookup (kein UI-Blocker bei fehlenden Helpern).
- Fix: Qt-Hardening Slot-Wrapper loggt nur noch 1× pro Fehler + ignoriert zusätzliche Signal-Args (verhindert Log-Spam/SIGKILL).


## v0.0.20.193 — Pro Drum Machine: AI‑Drum‑Generator + Smart‑Assign
- Drum‑Generator im Pro Drum Machine Instrument erweitert (Genre A/B + Mix, Kontext, Grid, Swing, Density, Intensity, Bars bis 64).
- Generierung ist deterministic/seeded (reine Mathematik/Stochastik) in `pydaw/music/ai_drummer.py`.
- Kanonisches Drum‑Mapping bleibt stabil (C2 Kick, C#2 Snare, …) → PianoRoll/Notation konsistent.
- Smart‑Assign beim Sample‑Load verhindert „HiHat spielt Kick“ (Keywords im Dateinamen → korrektes Slot).