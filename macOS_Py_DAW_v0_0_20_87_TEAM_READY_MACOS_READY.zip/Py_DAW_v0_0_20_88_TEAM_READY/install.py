"""Installer helper for ChronoScaleStudio (Py_DAW).

Usage:
    python3 install.py

Dieses Script installiert **nur** Python-Abhängigkeiten (pip).
System-Abhängigkeiten (Audio-Treiber/Libs) müssen je OS separat installiert werden.

✅ Unterstützte Backends:
- Linux: PipeWire-JACK / JACK (optional) + sounddevice
- macOS: CoreAudio via sounddevice (PortAudio)  ✅ default
- Windows: WASAPI via sounddevice

Hinweis:
- JACK/PipeWire selbst wird hier NICHT installiert.
"""

from __future__ import annotations

import os
import sys
import platform
import subprocess
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def _print_macos_system_deps() -> None:
    print("\nmacOS System-Dependencies (Homebrew):")
    print("  brew install portaudio libsndfile")
    print("  brew install fluidsynth        # empfohlen für SF2/Fluidsynth")
    print("  # Optional (nur wenn du JACK-Backend nutzen willst):")
    print("  # brew install jack && (oder JackOSX installieren)")
    print("\nDanach im venv: python3 install.py")


def _print_linux_system_deps() -> None:
    print("\nLinux System-Dependencies (Debian/Ubuntu Beispiele):")
    print("  sudo apt update")
    print("  sudo apt install -y libsndfile1 portaudio19-dev")
    print("  # Optional (JACK/PipeWire-JACK):")
    print("  # sudo apt install -y pipewire-jack jackd2 qpwgraph")


def _postflight_import_check() -> None:
    """Import-Test für die häufigsten 'läuft nicht wegen fehlender System-Libs' Fälle."""
    problems: list[str] = []

    # sounddevice → PortAudio
    try:
        import sounddevice  # noqa: F401
    except Exception as exc:  # pragma: no cover
        problems.append(f"- sounddevice Import fehlgeschlagen: {exc}")

    # soundfile → libsndfile
    try:
        import soundfile  # noqa: F401
    except Exception as exc:  # pragma: no cover
        problems.append(f"- soundfile Import fehlgeschlagen: {exc}")

    if problems:
        print("\n⚠️  Postflight-Check: Mindestens ein Audio-Modul konnte nicht importiert werden.")
        for p in problems:
            print(p)

        sysname = platform.system()
        if sysname == "Darwin":
            _print_macos_system_deps()
        elif sysname == "Linux":
            _print_linux_system_deps()
        else:
            print("\nWindows Hinweis:")
            print("  - Installiere ggf. ASIO/WASAPI Treiber für dein Interface.")
            print("  - Starte danach erneut: python3 main.py")


def main() -> int:
    here = Path(__file__).resolve().parent
    req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    sysname = platform.system()

    print("ChronoScaleStudio (Py_DAW) Installer")
    print("OS:", sysname)
    print("Python:", sys.version.split()[0])
    print()

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        if sysname == "Windows":
            print("      Empfehlung: py -m venv myenv && myenv\\Scripts\\activate")
        else:
            print("      Empfehlung: python3 -m venv myenv && source myenv/bin/activate")

    # OS-spezifische Hinweise VOR pip install:
    if sysname == "Darwin":
        _print_macos_system_deps()
    elif sysname == "Linux":
        _print_linux_system_deps()

    py = sys.executable
    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    _run([py, "-m", "pip", "install", "-r", str(req)])

    _postflight_import_check()

    print("\nOK. Starte danach mit: python3 main.py")
    print("Tipp: Audio-Backend kannst du in der App unter Einstellungen → Audio umstellen.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
