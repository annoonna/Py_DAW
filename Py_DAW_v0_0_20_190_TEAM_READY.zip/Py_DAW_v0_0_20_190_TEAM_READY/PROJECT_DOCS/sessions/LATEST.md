# Session: v0.0.20.190 — Hotfix: "Zombie"-Fenster / Pop-out bei DevicePanel Refresh

Siehe:
- `PROJECT_DOCS/sessions/SESSION_v0.0.20.190_HOTFIX_ZOMBIE_WINDOWS.md`
