"""Installer helper for ChronoScaleStudio (Py_DAW).

Usage:
    python3 install.py

What it does:
- Warn if you're not inside a virtual environment
- Upgrade pip/setuptools/wheel
- Install requirements.txt

Platform helpers:
- macOS: installs required Homebrew packages for CoreAudio/FluidSynth render:
    brew install portaudio libsndfile fluidsynth

Notes:
- Linux JACK/PipeWire packages are system-level and not installed here.
- macOS Audio default: sounddevice (PortAudio) -> CoreAudio.
- macOS Graphics default (Qt Quick/RHI preparation): Metal.
  Override at runtime with: PYDAW_GFX_BACKEND=opengl python3 main.py
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path


def _run(cmd: list[str], *, check: bool = True) -> int:
    print("\n>>", " ".join(cmd))
    p = subprocess.run(cmd, check=False)
    if check and p.returncode != 0:
        raise subprocess.CalledProcessError(p.returncode, cmd)
    return int(p.returncode)


def _is_macos() -> bool:
    try:
        return platform.system().lower() == "darwin"
    except Exception:
        return False


def _is_linux() -> bool:
    try:
        return platform.system().lower() == "linux"
    except Exception:
        return False


def _ensure_brew_pkgs(pkgs: list[str]) -> None:
    brew = shutil.which("brew")
    if not brew:
        print("\n[macOS] Homebrew wurde nicht gefunden.")
        print("Bitte Homebrew installieren und danach erneut ausführen.")
        print("(Website: brew.sh)")
        return

    # Install missing packages (best effort)
    for pkg in pkgs:
        try:
            rc = _run([brew, "list", "--versions", pkg], check=False)
            if rc == 0:
                print(f"[brew] OK: {pkg} ist bereits installiert")
                continue
        except Exception:
            pass

        try:
            _run([brew, "install", pkg], check=False)
        except Exception as exc:
            print(f"WARN: brew install {pkg} fehlgeschlagen: {exc}")


def main() -> int:
    here = Path(__file__).resolve().parent
    req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        print("      Empfehlung:")
        if _is_macos() or _is_linux():
            print("        python3 -m venv myenv && source myenv/bin/activate")
        else:
            print("        python -m venv myenv && myenv\\Scripts\\activate")

    # macOS system deps (CoreAudio + SF2 render via fluidsynth binary)
    if _is_macos():
        print("\n[macOS] Installiere (falls nötig) System-Abhängigkeiten via Homebrew …")
        _ensure_brew_pkgs(["portaudio", "libsndfile", "fluidsynth"])

    py = sys.executable
    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"], check=False)
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    # Install python deps
    try:
        _run([py, "-m", "pip", "install", "-r", str(req)])
    except Exception as exc:
        print("\nERROR: pip install -r requirements.txt fehlgeschlagen:")
        print(str(exc))
        if _is_macos():
            print("\nmacOS Tipp:")
            print("  brew install portaudio libsndfile fluidsynth")
            print("  (danach erneut: python3 install.py)")
        return 3

    print("\nOK.")
    print("Starte danach mit: python3 main.py")

    if _is_macos():
        print("\nmacOS Defaults:")
        print("  Audio: sounddevice -> CoreAudio (auto)")
        print("  Graphics: Metal (auto; Qt Quick/RHI Vorbereitung)")
        print("\nOverrides:")
        print("  PYDAW_GFX_BACKEND=opengl python3 main.py")
        print("  PYDAW_AUDIO_HOSTAPI=coreaudio python3 main.py")

    if _is_linux():
        print("\nLinux Hinweis: Für JACK/PipeWire-JACK benötigst du Systempakete (z.B. pipewire-jack, qpwgraph).")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
