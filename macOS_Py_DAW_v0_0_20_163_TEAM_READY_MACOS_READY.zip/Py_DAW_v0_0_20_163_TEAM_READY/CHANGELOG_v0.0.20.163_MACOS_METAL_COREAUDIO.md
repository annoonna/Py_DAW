# Changelog v0.0.20.163 — macOS: Metal + CoreAudio Setup (2026-03-01)

## Ziel
macOS-Setup robust machen:
- **Audio:** CoreAudio via `sounddevice`/PortAudio (stabile Defaults)
- **SF2-Render:** `fluidsynth` binary via Homebrew sicherstellen
- **Graphics:** Qt Quick/RHI Default auf **Metal** (Override möglich)

## Änderungen

### 1) requirements.txt (plattform-sicher)
- `JACK-Client` ist jetzt **Linux-only** (Marker), damit macOS Installationen nicht an libjack hängen.

### 2) install.py (macOS Support)
- macOS erkennt Homebrew und installiert (best-effort):
  - `portaudio`
  - `libsndfile`
  - `fluidsynth`
- Klarere Hinweise/Overrides für Metal + CoreAudio.

### 3) Graphics Backend (Metal Default auf macOS)
- `pydaw/utils/gfx_backend.py` unterstützt jetzt `metal`.
- `PYDAW_GFX_BACKEND=auto` → macOS **Metal**, Linux **Vulkan** (wenn vorhanden), sonst **OpenGL**.

### 4) Audio Defaults (CoreAudio)
- `pydaw/audio/audio_engine.py` setzt auf macOS best-effort:
  - HostAPI = **Core Audio** (wenn vorhanden)
  - Low-latency Preset (wenn supported)
- Bessere Fehlermeldung mit Brew-Tipp, wenn PortAudio fehlt.

## Dateien
- `requirements.txt`
- `install.py`
- `INSTALL.md`
- `pydaw/utils/gfx_backend.py`
- `pydaw/audio/audio_engine.py`
- `VERSION`, `pydaw/version.py`
