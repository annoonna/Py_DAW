v0.0.20.152

Clip Launcher (Bitwig/Ableton-Style, UI/UX + sichere Services):
- Bitwig-Grid Layout: Scenes = Spalten (oben), Tracks = Zeilen (links)
- ZELLE Inspector: resizable + einklappbar (Splitter + Persistenz)
- Play-State Indicator pro Slot: Highlight-Rahmen + ▶
- Queued-State Indicator pro Slot/Scene: gelb gestrichelt + Triangle-Outline
- Queued Countdown: zeigt "wann feuert es" (z.B. `0.5 Bar` / `0.2 Beat`) live während Pending-Launches

Nächster sinnvoller Schritt:
- Clip Launcher: "Stop/Return/Next" Actions (Release/Next Actions) wirklich abspielen lassen (Engine-Wiring)
