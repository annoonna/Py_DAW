# Session: v0.0.20.163 — macOS: Metal + CoreAudio Setup

**Datum:** 2026-03-01  
**Assignee:** GPT-5.2 Thinking (ChatGPT)  
**Status:** ✅ FERTIG  

---

## Ziel
macOS Setup wieder stabil machen:
- **Audio:** CoreAudio via sounddevice/PortAudio
- **SF2-Render:** fluidsynth binary via Homebrew
- **Graphics:** Metal Default (Qt Quick/RHI Vorbereitung)

---

## Umsetzung
- `requirements.txt`: `JACK-Client` Linux-only marker (macOS Install bricht nicht an libjack).
- `install.py`: macOS → best-effort `brew install portaudio libsndfile fluidsynth` + klare Hinweise.
- `gfx_backend.py`: `metal` Backend + macOS auto→Metal.
- `audio_engine.py`: CoreAudio HostAPI + low-latency Preset (defensiv), bessere Fehlermeldung.
- `INSTALL.md`: macOS Anleitung ergänzt.

---

## Geänderte Dateien
- `requirements.txt`
- `install.py`
- `INSTALL.md`
- `pydaw/utils/gfx_backend.py`
- `pydaw/audio/audio_engine.py`
- `VERSION`, `pydaw/version.py`
