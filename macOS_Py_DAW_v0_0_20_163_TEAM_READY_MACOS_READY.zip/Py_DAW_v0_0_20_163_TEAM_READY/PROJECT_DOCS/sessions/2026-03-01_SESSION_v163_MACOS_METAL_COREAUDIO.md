# Session: v0.0.20.163 — macOS: Metal + CoreAudio Setup

**Datum:** 2026-03-01
**Assignee:** GPT-5.2 Thinking (ChatGPT)
**Status:** ✅ FERTIG

---

## Ziel
User-Request: "Bitte passe alles erneut an das Soundsystem an und Metal / requirements.txt / install.py für macOS (Metal + CoreAudio)"

---

## Umsetzung

### macOS Audio (CoreAudio)
- `sounddevice` wird auf macOS best-effort mit **Core Audio HostAPI** initialisiert.
- Zusätzlich wird (wenn möglich) ein **Low Latency** Preset gesetzt.
- Das ist rein defensiv: darf niemals abstürzen, nur verbessern.

### macOS Graphics (Metal)
- `PYDAW_GFX_BACKEND=auto` wählt auf macOS jetzt **Metal** (Qt Quick RHI Backend).
- Override bleibt möglich: `PYDAW_GFX_BACKEND=opengl`.

### Installer / Dependencies
- `install.py` installiert auf macOS (best effort via Homebrew):
  - `portaudio` (sounddevice)
  - `libsndfile` (soundfile)
  - `fluidsynth` (SF2 render binary)
- `requirements.txt`: `JACK-Client` Linux-only marker, damit macOS Install nicht bricht.
- `INSTALL.md` um macOS Anleitung ergänzt.

---

## Geänderte Dateien
- `requirements.txt`
- `install.py`
- `INSTALL.md`
- `pydaw/utils/gfx_backend.py`
- `pydaw/audio/audio_engine.py`
- `VERSION`, `pydaw/version.py`

---

## Hinweise fürs Testen (macOS)

```bash
python3 -m venv myenv
source myenv/bin/activate
python3 install.py
python3 main.py
```

Optional:
```bash
PYDAW_GFX_BACKEND=opengl python3 main.py
PYDAW_AUDIO_HOSTAPI=coreaudio python3 main.py
```
