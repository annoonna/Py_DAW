# Changelog — v0.0.20.85

## Added
- Projekt → **„Projekt vergleichen…“**: Read-only Vergleich zwischen zwei offenen Projekt-Tabs.
  - Summary (Settings + Counts)
  - Unified Diff auf stabiler JSON-Serialisierung
  - Option „Zeitstempel ignorieren“ für weniger Diff-Noise

## Changed
- Menü „Projekt“ erweitert um Compare-Action.

## Shortcut
- Ctrl+Alt+D

## Files
- pydaw/ui/project_compare_dialog.py (new)
- pydaw/ui/main_window.py
- pydaw/version.py
- pydaw/model/project.py
- VERSION
