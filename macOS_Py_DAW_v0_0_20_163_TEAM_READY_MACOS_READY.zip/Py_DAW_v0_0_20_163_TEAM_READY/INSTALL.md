# 📦 ChronoScaleStudio (Py_DAW) – Installation

## System Requirements
- **Python:** 3.10+ (empfohlen: 3.12/3.13)
- **GUI:** PyQt6
- **Audio:**
  - **macOS:** CoreAudio (über `sounddevice`/PortAudio)
  - **Linux:** PipeWire-JACK/JACK oder sounddevice

---

## ✅ Quick Start (alle Systeme)

```bash
# 1) Unzip
unzip Py_DAW_v0_0_20_XXX_TEAM_READY.zip
cd Py_DAW_v0_0_20_XXX_TEAM_READY

# 2) Virtualenv
python3 -m venv myenv
source myenv/bin/activate

# 3) Install (inkl. Plattform-Hints)
python3 install.py

# 4) Start
python3 main.py
```

---

## 🍎 macOS (Metal + CoreAudio)

### 1) Homebrew Abhängigkeiten
Für **CoreAudio/PortAudio** + **SF2 Rendering via fluidsynth binary**:

```bash
brew install portaudio libsndfile fluidsynth
```

> `install.py` versucht diese Pakete ebenfalls (best effort) zu installieren.

### 2) Start
```bash
python3 main.py
```

### 3) Defaults / Overrides
- **Graphics Default:** `PYDAW_GFX_BACKEND=auto` → **Metal**
- Override (falls du GPU-Probleme siehst):

```bash
PYDAW_GFX_BACKEND=opengl python3 main.py
```

- **Audio Default:** `sounddevice` → **CoreAudio**
- Optional explizit:

```bash
PYDAW_AUDIO_HOSTAPI=coreaudio python3 main.py
```

---

## 🐧 Linux (PipeWire-JACK / JACK)

### PipeWire-JACK (empfohlen)
```bash
sudo apt update
sudo apt install pipewire-jack qpwgraph
qpwgraph &
python3 main.py
```

### JACK (klassisch)
```bash
sudo apt install jackd2
jack_control start
python3 main.py
```

---

## Troubleshooting

### "sounddevice nicht verfügbar" (macOS)
Meist fehlen Systemlibs:

```bash
brew install portaudio libsndfile fluidsynth
```

### Vulkan (Linux) – System packages
Wenn du unter Linux Vulkan als Default-Backend nutzen willst (Qt Quick / RHI Vorbereitung):

```bash
sudo apt update
sudo apt install libvulkan1 mesa-vulkan-drivers vulkan-tools
vulkaninfo | head
```

Override:
```bash
PYDAW_GFX_BACKEND=opengl python3 main.py
```

### "ModuleNotFoundError"
```bash
pip install --upgrade -r requirements.txt
```

---

## Done!
Run: `python3 main.py`
