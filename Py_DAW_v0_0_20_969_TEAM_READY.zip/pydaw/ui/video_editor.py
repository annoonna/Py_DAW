"""video_editor.py — Video-Editor (v0.0.20.950).

VE1: The FIRST DAW with an integrated NLE-style video editor in the
     clip editor panel — alongside Piano Roll, Audio Editor, Notation.

Features:
  - Visual timeline with real video frame thumbnails (filmstrip)
  - Beat grid overlay synced to DAW transport
  - Tools: Select, Knife (split), Trim (drag edges), Slip (shift content)
  - SMPTE timecode display (frame-accurate)
  - Scene markers from Video-KI analysis
  - Transport cursor (playhead) synced to DAW
  - Clip properties: opacity, speed, label
  - Keyboard shortcuts: S=split at playhead, Del=delete, Z=undo

VE8 (v0.0.20.946): Timecode Pro + Smart Context
  - Frame-accurate HH:MM:SS:FF with Drop-Frame/Non-Drop-Frame
  - Configurable FPS (23.976–60)
  - Timecode entry: jump to exact timecode (T key)
  - Smart Context tool (C key): auto-switches by click position
  - LTC sync framework

VE9 (v0.0.20.946): Automation Draw
  - Per-clip automation: Opacity, Speed, Volume curves
  - Breakpoint editor with Bezier interpolation
  - Preset curves: Fade In, Fade Out, S-Curve, Bell
  - Automation Draw tool (A key)

VE10 (v0.0.20.946): Transition Engine
  - Crossfade, Dissolve, Wipe, Slide, Push transitions
  - Dip to Black / Dip to White
  - Beat-synced transition durations
  - Context menu integration

VE11 (v0.0.20.950): KI Text-Editing (Whisper)
  - Whisper transcription (local, no cloud)
  - Text editor panel alongside timeline
  - Delete words → video jump cuts
  - Word boundary markers on timeline
  - SRT/VTT subtitle export

What NO other DAW has:
  - Video editing INSIDE the same editor panel as MIDI/Audio
  - Beat-synced video cuts (snap to bar/beat grid)
  - AI scene markers integrated into the video timeline
  - Frame-accurate editing with SMPTE in a music DAW
  - Automation Draw overlaid on video clips
  - Beat-synced transitions between clips

Usage:
    editor = VideoEditor(project_service, transport=transport)
    editor.set_clip(clip_id)  # loads the video clip for editing
"""

from __future__ import annotations

import logging
import math
import time as _time
import os
import threading
from typing import Any, Dict, List, Optional, Tuple

from PyQt6.QtCore import (
    Qt, pyqtSignal, QTimer, QRectF, QPointF, QSizeF,
)
from PyQt6.QtGui import (
    QBrush, QColor, QFont, QImage, QPainter, QPen, QPixmap,
    QWheelEvent, QMouseEvent, QKeyEvent,
)
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QToolButton, QSplitter, QScrollBar, QComboBox, QDoubleSpinBox,
    QFrame, QSizePolicy, QToolBar,
)

log = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════

_HEADER_HEIGHT = 28       # ruler / time header
_TRACK_HEIGHT = 80        # clip lane height (shows frames)
_TRACK_MIN_HEIGHT = 48
_TRACK_MAX_HEIGHT = 200
_FRAME_THUMB_W = 120      # thumbnail width inside clips
_SCROLL_SPEED = 30
_DEFAULT_PX_PER_BEAT = 40

# Colors
_CLR_BG = QColor(18, 18, 28)
_CLR_HEADER = QColor(28, 28, 42)
_CLR_GRID_BAR = QColor(60, 60, 80)
_CLR_GRID_BEAT = QColor(40, 40, 55)
_CLR_PLAYHEAD = QColor(255, 80, 80)
_CLR_CLIP_BG = QColor(22, 50, 60)
_CLR_CLIP_BORDER = QColor(60, 140, 160)
_CLR_CLIP_SELECTED = QColor(100, 200, 220)
_CLR_SCENE_MARKER = QColor(255, 200, 60, 120)
_CLR_TRIM_HANDLE = QColor(255, 255, 100, 200)
_CLR_KNIFE = QColor(255, 100, 100)
_CLR_TEXT = QColor(200, 200, 216)
_CLR_SMPTE = QColor(79, 195, 247)

# Tool IDs
TOOL_SELECT = "select"
TOOL_KNIFE = "knife"
TOOL_TRIM = "trim"
TOOL_SLIP = "slip"
TOOL_LASSO = "lasso"
TOOL_HAND = "hand"
TOOL_ZOOM = "zoom"
TOOL_SMART_CONTEXT = "smart_context"  # VE8: auto tool switch by click position
TOOL_AUTOMATION = "automation"        # VE9: draw automation curves


# ═══════════════════════════════════════════════════════════════
# v0.0.20.948: Video Collab Send Helpers (module-level, safe)
# ═══════════════════════════════════════════════════════════════

def _get_video_collab_from_widget(widget):
    """Find VideoCollabService from any widget via main window."""
    try:
        main_win = widget.window() if widget else None
        if not main_win:
            return None
        cp = getattr(main_win, '_collab_panel', None)
        if cp is None:
            cp = getattr(main_win, 'collab_panel', None)
        if cp:
            return getattr(cp, '_video_collab', None)
    except Exception:
        pass
    return None


def _video_collab_send_props(widget, clip_id: str, props: dict) -> None:
    """Send video clip properties to collab (safe, no-op if no collab)."""
    try:
        vcs = _get_video_collab_from_widget(widget)
        if vcs:
            vcs.send_clip_props(clip_id, props)
    except Exception:
        pass


def _video_collab_send_filter(widget, clip_id: str) -> None:
    """Send video filter chain to collab (safe)."""
    try:
        vcs = _get_video_collab_from_widget(widget)
        if not vcs:
            return
        from pydaw.services.video_filter_service import VideoFilterService
        svc = VideoFilterService.instance()
        if svc:
            chain = svc.save_all().get(clip_id, {})
            vcs.send_filter_sync(clip_id, chain)
    except Exception:
        pass


def _video_collab_send_automation(widget, clip_id: str, auto_data: dict) -> None:
    """Send video automation to collab (safe)."""
    try:
        vcs = _get_video_collab_from_widget(widget)
        if vcs:
            vcs.send_automation_sync(clip_id, auto_data)
    except Exception:
        pass


def _video_collab_send_transition(widget, tr_data: dict) -> None:
    """Send video transition to collab (safe)."""
    try:
        vcs = _get_video_collab_from_widget(widget)
        if vcs:
            vcs.send_transition_sync(tr_data)
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════
# Video Editor Canvas
# ═══════════════════════════════════════════════════════════════

class VideoEditorCanvas(QWidget):
    """Custom-painted video timeline canvas.

    Renders video clips as filmstrip thumbnails on a beat-synced timeline.
    All painting is done in paintEvent (no QGraphicsScene overhead).
    """

    status_message = pyqtSignal(str)
    clip_split = pyqtSignal(str, float)        # clip_id, beat_position
    clip_trimmed = pyqtSignal(str, float, str)  # clip_id, new_value, "start"|"end"
    clip_deleted = pyqtSignal(str)              # clip_id

    def __init__(self, project_service, transport=None, parent=None):
        super().__init__(parent)
        self._ps = project_service
        self._transport = transport
        self._bpm = 120.0

        # View state
        self._px_per_beat = _DEFAULT_PX_PER_BEAT
        self._scroll_x = 0.0   # beats
        self._track_height = _TRACK_HEIGHT

        # v0.0.20.934: Grid & Snap system
        self._snap_beats = 1.0     # snap resolution: 4=bar, 1=beat, 0.5=1/8, 0.25=1/16, 0=off
        self._grid_subdivisions = True  # show sub-beat grid lines

        # v0.0.20.934: Loop region (like Arranger/PianoRoll)
        self._loop_enabled = False
        self._loop_start = 0.0     # beats
        self._loop_end = 16.0      # beats
        self._loop_dragging: Optional[str] = None  # "start", "end", "body", None

        # Video clip state
        self._clip_id: Optional[str] = None
        self._clip = None
        self._video_path = ""
        self._video_duration = 0.0
        self._clip_start_beats = 0.0
        self._clip_length_beats = 0.0

        # v0.0.20.932: Multi-track + ghost clips
        self._all_tracks: List[Dict] = []
        self._ghost_enabled = True
        self._active_track_id = ""

        # v0.0.20.932: Clipboard for copy/paste
        self._clipboard: Optional[Dict] = None

        # v0.0.20.938: Multi-selection + Lasso + Groups
        self._selected_clip_ids: set = set()  # multi-selection
        self._lasso_start: Optional[QPointF] = None
        self._lasso_rect: Optional[QRectF] = None
        self._clip_groups: Dict[str, str] = {}  # clip_id → group_id
        self._next_group_id = 1

        # Tool state
        self._tool = TOOL_SELECT
        self._mouse_pos = QPointF(0, 0)
        self._dragging = False
        self._drag_start = QPointF(0, 0)
        self._drag_start_beat = 0.0
        self._drag_edge: Optional[str] = None
        self._ctrl_drag_copy = False
        self._selected = True

        # Scene markers from Video-KI
        self._scene_markers: List[Dict] = []

        # v0.0.20.946 VE8: Timecode Pro
        self._timecode_fps: float = 24.0
        self._timecode_drop_frame: bool = False
        self._timecode_offsets: Dict[str, float] = {}  # clip_id → offset_seconds
        self._ltc_sync = None  # LTCSync instance (lazy)

        # v0.0.20.946 VE9: Automation
        self._automation_store = None  # lazy VideoAutomationStore
        self._active_automation_lane: str = "opacity"  # opacity|speed|volume
        self._automation_visible: bool = True
        self._automation_drag_point: int = -1  # index of dragged point
        self._automation_drag_clip: str = ""

        # v0.0.20.946 VE10: Transitions
        self._transition_store = None  # lazy VideoTransitionStore

        # v0.0.20.950 VE11: Word boundary markers (from text editor)
        self._word_markers: List[Dict] = []

        # Thumbnail cache
        self._thumb_svc = None

        # Playhead timer — only update when playing
        self._playhead_timer = QTimer(self)
        self._playhead_timer.setInterval(66)
        self._playhead_timer.timeout.connect(self._on_playhead_tick)
        self._playhead_timer.start()

        # v0.0.20.933: Paint throttle (max 15fps repaints)
        try:
            from pydaw.services.perf_service import PaintThrottle
            self._throttle = PaintThrottle(self, fps_limit=15)
        except Exception:
            self._throttle = None

        # Widget setup
        self.setMinimumHeight(140)
        self.setMinimumWidth(300)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_context_menu)

    def _request_paint(self) -> None:
        """Request a throttled repaint (v0.0.20.933)."""
        if self._throttle:
            self._throttle.request()
        else:
            self._request_paint()

    def _on_playhead_tick(self) -> None:
        """Playhead timer — only repaint if transport is playing."""
        try:
            if self._transport and getattr(self._transport, 'playing', False):
                self._request_paint()
        except Exception:
            pass

    # ─────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────

    def set_clip(self, clip_id: Optional[str]) -> None:
        """Load a video clip for editing.

        v0.0.20.932: Multi-track view — shows all video tracks stacked.
        Active track has full-color clips, other tracks show ghost clips.
        """
        self._clip_id = clip_id
        self._clip = None
        self._video_path = ""
        self._video_duration = 0.0
        self._scene_markers = []
        self._all_clips: List = []
        self._all_tracks = []
        self._active_track_id = ""

        if not clip_id:
            self._request_paint()
            return

        try:
            proj = self._get_project()
            if not proj:
                return
            for c in proj.clips or []:
                if str(getattr(c, 'id', '')) == str(clip_id):
                    self._clip = c
                    break
            if not self._clip or str(getattr(self._clip, 'kind', '')) != 'video':
                self._clip = None
                self._request_paint()
                return

            self._video_path = str(getattr(self._clip, 'source_path', '') or '')
            self._clip_start_beats = float(getattr(self._clip, 'start_beats', 0))
            self._clip_length_beats = float(getattr(self._clip, 'length_beats', 0))
            self._bpm = self._get_bpm()
            self._video_duration = self._clip_length_beats * 60.0 / max(1, self._bpm)
            self._active_track_id = str(getattr(self._clip, 'track_id', ''))

            # Collect ALL video clips grouped by track
            track_clips: Dict[str, List] = {}
            track_names: Dict[str, str] = {}
            for c in (proj.clips or []):
                if str(getattr(c, 'kind', '')) == 'video':
                    tid = str(getattr(c, 'track_id', ''))
                    if tid not in track_clips:
                        track_clips[tid] = []
                    track_clips[tid].append(c)
            # Get track names
            for t in (proj.tracks or []):
                tid = str(getattr(t, 'id', ''))
                if tid in track_clips:
                    track_names[tid] = str(getattr(t, 'name', f'Track {tid[:6]}'))

            # Build track list (active track first)
            for tid in sorted(track_clips.keys(),
                              key=lambda t: 0 if t == self._active_track_id else 1):
                clips = sorted(track_clips[tid],
                               key=lambda c: float(getattr(c, 'start_beats', 0)))
                self._all_tracks.append({
                    "track_id": tid,
                    "name": track_names.get(tid, f"Track {tid[:6]}"),
                    "clips": clips,
                    "is_active": tid == self._active_track_id,
                })

            # Also set _all_clips for backward compat
            self._all_clips = track_clips.get(self._active_track_id, [])
            self._all_clips.sort(key=lambda c: float(getattr(c, 'start_beats', 0)))

            # Center view on clip
            self._scroll_x = max(0, self._clip_start_beats - 2)
            self._ensure_thumb_service()

        except Exception as e:
            log.debug("[VideoEditor] set_clip: %s", e)

        self._request_paint()

    def set_tool(self, tool: str) -> None:
        """Set the active editing tool."""
        self._tool = tool
        cursors = {
            TOOL_KNIFE: Qt.CursorShape.CrossCursor,
            TOOL_TRIM: Qt.CursorShape.SizeHorCursor,
            TOOL_HAND: Qt.CursorShape.OpenHandCursor,
            TOOL_ZOOM: Qt.CursorShape.CrossCursor,
            TOOL_LASSO: Qt.CursorShape.CrossCursor,
            TOOL_SMART_CONTEXT: Qt.CursorShape.ArrowCursor,
            TOOL_AUTOMATION: Qt.CursorShape.CrossCursor,
        }
        self.setCursor(cursors.get(tool, Qt.CursorShape.ArrowCursor))
        self._lasso_rect = None
        self._request_paint()
        try:
            names = {TOOL_SELECT: "Auswahl", TOOL_KNIFE: "Messer", TOOL_TRIM: "Trimmen",
                     TOOL_SLIP: "Slip", TOOL_LASSO: "Lasso", TOOL_HAND: "Hand",
                     TOOL_ZOOM: "Lupe", TOOL_SMART_CONTEXT: "Smart Context",
                     TOOL_AUTOMATION: "Automation Draw"}
            self.status_message.emit(f"🔧 Tool: {names.get(tool, tool)}")
        except Exception:
            pass

    def set_scene_markers(self, markers: List[Dict]) -> None:
        """Set scene markers from Video-KI analysis."""
        self._scene_markers = list(markers) if markers else []
        self._request_paint()

    def delete_selected_clip(self) -> None:
        """Delete the currently selected clip."""
        if not self._clip:
            return
        self.clip_deleted.emit(str(self._clip_id))
        try:
            self.status_message.emit(f"🗑 Clip gelöscht")
        except Exception:
            pass

    def ripple_delete(self) -> None:
        """Delete selected clip and shift all following clips left (Shift+Del)."""
        if not self._clip:
            return
        try:
            proj = self._get_project()
            if not proj:
                return
            cs = self._clip_start_beats
            cl = self._clip_length_beats
            track_id = self._active_track_id
            proj.clips = [c for c in proj.clips
                          if str(getattr(c, 'id', '')) != str(self._clip_id)]
            for c in proj.clips:
                if (str(getattr(c, 'track_id', '')) == track_id
                        and float(getattr(c, 'start_beats', 0)) > cs):
                    c.start_beats = max(0, float(getattr(c, 'start_beats', 0)) - cl)
            if hasattr(self._ps, '_emit_updated'):
                self._ps._emit_updated()
            remaining = [c for c in proj.clips
                         if str(getattr(c, 'kind', '')) == 'video'
                         and str(getattr(c, 'track_id', '')) == track_id]
            if remaining:
                self.set_clip(str(getattr(remaining[0], 'id', '')))
            else:
                self.set_clip(None)
            try:
                self.status_message.emit("🗑 Ripple Delete — Lücke geschlossen")
            except Exception:
                pass
        except Exception as e:
            log.debug("[VideoEditor] ripple_delete: %s", e)

    def select_all(self) -> None:
        """Select all clips on active track (Ctrl+A)."""
        clips = getattr(self, '_all_clips', [])
        self._selected_clip_ids = {str(getattr(c, 'id', '')) for c in clips}
        self._request_paint()
        try:
            self.status_message.emit(f"✅ {len(self._selected_clip_ids)} Clips ausgewählt")
        except Exception:
            pass

    def group_selected(self) -> None:
        """Group selected clips (Ctrl+G)."""
        if len(self._selected_clip_ids) < 2:
            return
        gid = f"grp_{self._next_group_id}"
        self._next_group_id += 1
        for cid in self._selected_clip_ids:
            self._clip_groups[cid] = gid
        try:
            self.status_message.emit(f"🔗 {len(self._selected_clip_ids)} Clips gruppiert")
        except Exception:
            pass
        self._request_paint()

    def ungroup_selected(self) -> None:
        """Ungroup selected clips (Ctrl+Shift+G)."""
        for cid in list(self._selected_clip_ids):
            self._clip_groups.pop(cid, None)
        try:
            self.status_message.emit("🔓 Gruppe aufgelöst")
        except Exception:
            pass
        self._request_paint()

    def select_clip_at(self, beat: float) -> Optional[str]:
        """Select the clip at the given beat position. Returns clip_id or None."""
        for clip in getattr(self, '_all_clips', []):
            cs = float(getattr(clip, 'start_beats', 0))
            ce = cs + float(getattr(clip, 'length_beats', 0))
            if cs <= beat <= ce:
                cid = str(getattr(clip, 'id', ''))
                if cid != self._clip_id:
                    self._clip_id = cid
                    self._clip = clip
                    self._video_path = str(getattr(clip, 'source_path', '') or '')
                    self._clip_start_beats = cs
                    self._clip_length_beats = float(getattr(clip, 'length_beats', 0))
                    self._request_paint()
                return cid
        return None

    # v0.0.20.932: Context Menu + Clipboard + Join
    # ─────────────────────────────────────────────────────

    # v0.0.20.937: Per-clip triangle menu (like Arranger clips)
    # ─────────────────────────────────────────────────────

    def _show_clip_triangle_menu(self, clip_id: str, global_pos) -> None:
        """Show per-clip context menu (triggered by triangle icon)."""
        from PyQt6.QtWidgets import QMenu
        from PyQt6.QtCore import QPoint

        # Select this clip first
        for clip in getattr(self, '_all_clips', []):
            if str(getattr(clip, 'id', '')) == clip_id:
                self._clip_id = clip_id
                self._clip = clip
                self._video_path = str(getattr(clip, 'source_path', '') or '')
                self._clip_start_beats = float(getattr(clip, 'start_beats', 0))
                self._clip_length_beats = float(getattr(clip, 'length_beats', 0))
                break

        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu { background: #2a2a3a; color: #ddd; border: 1px solid #555; }"
            "QMenu::item:selected { background: #3a5a7a; }"
            "QMenu::separator { background: #444; height: 1px; }"
        )

        # Clip identity
        label = str(getattr(self._clip, 'label', '') or clip_id[:8])
        a_title = menu.addAction(f"🎬 {label}")
        a_title.setEnabled(False)
        menu.addSeparator()

        # Properties
        a_props = menu.addAction("🎛 Eigenschaften...")

        # Quick opacity
        opacity_menu = menu.addMenu("🔍 Transparenz")
        a_op100 = opacity_menu.addAction("100% (voll sichtbar)")
        a_op75 = opacity_menu.addAction("75%")
        a_op50 = opacity_menu.addAction("50%")
        a_op25 = opacity_menu.addAction("25%")
        a_op10 = opacity_menu.addAction("10% (fast unsichtbar)")

        # Quick speed
        speed_menu = menu.addMenu("⏱ Geschwindigkeit")
        a_sp025 = speed_menu.addAction("¼× (Zeitlupe)")
        a_sp05 = speed_menu.addAction("½× (Langsam)")
        a_sp1 = speed_menu.addAction("1× (Normal)")
        a_sp2 = speed_menu.addAction("2× (Schnell)")
        a_sp4 = speed_menu.addAction("4× (Sehr schnell)")
        a_sp_rev = speed_menu.addAction("⏪ Rückwärts")

        # Quick filters
        filter_menu = menu.addMenu("🎨 Filter")
        a_f_warm = filter_menu.addAction("🌅 Warm")
        a_f_cold = filter_menu.addAction("❄ Kalt")
        a_f_bw = filter_menu.addAction("⬛ Schwarzweiß")
        a_f_cinema = filter_menu.addAction("🎬 Cinematic")
        a_f_vintage = filter_menu.addAction("📷 Vintage")
        a_f_reset = filter_menu.addAction("🔄 Reset")

        menu.addSeparator()

        # Clip operations
        a_split = menu.addAction("✂ Split am Playhead (S)")
        a_copy = menu.addAction("📋 Kopieren (Ctrl+C)")
        a_dup = menu.addAction("📄 Duplizieren (Ctrl+D)")
        a_delete = menu.addAction("🗑 Löschen (Del)")

        act = menu.exec(global_pos if isinstance(global_pos, QPoint)
                        else QPoint(int(global_pos.x()), int(global_pos.y())))
        if act is None:
            return

        # Handle actions
        if act == a_props:
            self._open_properties_dialog()
        elif act in (a_op100, a_op75, a_op50, a_op25, a_op10):
            opacity_map = {a_op100: 1.0, a_op75: 0.75, a_op50: 0.5, a_op25: 0.25, a_op10: 0.1}
            self._set_clip_opacity(clip_id, opacity_map[act])
        elif act in (a_sp025, a_sp05, a_sp1, a_sp2, a_sp4, a_sp_rev):
            speed_map = {a_sp025: 0.25, a_sp05: 0.5, a_sp1: 1.0, a_sp2: 2.0, a_sp4: 4.0, a_sp_rev: -1.0}
            self._set_clip_speed(clip_id, speed_map[act])
        elif act == a_f_warm:
            self._apply_filter_preset("warm")
        elif act == a_f_cold:
            self._apply_filter_preset("cold")
        elif act == a_f_bw:
            self._apply_filter_preset("bw")
        elif act == a_f_cinema:
            self._apply_filter_preset("cinema")
        elif act == a_f_vintage:
            self._apply_filter_preset("vintage")
        elif act == a_f_reset:
            self._apply_filter_preset("reset")
        elif act == a_split:
            self.split_at_playhead()
        elif act == a_copy:
            self.copy_clip()
        elif act == a_dup:
            self.duplicate_clip()
        elif act == a_delete:
            self.delete_selected_clip()

    def _set_clip_opacity(self, clip_id: str, opacity: float) -> None:
        """Set clip opacity and save to SQLite."""
        try:
            from pydaw.ui.video_clip_properties import ClipVideoProps
            props = ClipVideoProps.get(clip_id)
            props.opacity = opacity
            props.save(clip_id)
            self._request_paint()
            # v0.0.20.948: Collab send
            _video_collab_send_props(self, clip_id, {"opacity": opacity})
            try:
                self.status_message.emit(f"🔍 Opacity: {int(opacity * 100)}%")
            except Exception:
                pass
        except Exception as e:
            log.debug("[VideoEditor] set_opacity: %s", e)

    def _set_clip_speed(self, clip_id: str, speed: float) -> None:
        """Set clip speed and save to SQLite."""
        try:
            from pydaw.ui.video_clip_properties import ClipVideoProps
            props = ClipVideoProps.get(clip_id)
            props.speed = speed
            props.save(clip_id)
            self._request_paint()
            # v0.0.20.948: Collab send
            _video_collab_send_props(self, clip_id, {"speed": speed})
            try:
                self.status_message.emit(f"⏱ Speed: {speed:.2f}×")
            except Exception:
                pass
        except Exception as e:
            log.debug("[VideoEditor] set_speed: %s", e)

    def _show_context_menu(self, pos) -> None:
        """Right-click context menu with all editing operations."""
        from PyQt6.QtWidgets import QMenu
        from PyQt6.QtGui import QAction
        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu { background: #2a2a3a; color: #ddd; border: 1px solid #555; }"
            "QMenu::item:selected { background: #3a5a7a; }"
            "QMenu::separator { background: #444; height: 1px; }"
        )

        beat = self._x_to_beats(pos.x())

        # ── Clip Properties (top!) ──
        a_props = menu.addAction("🎛 Clip-Eigenschaften...")
        a_props.setEnabled(self._clip is not None)
        menu.addSeparator()

        # ── Tools ──
        tools_menu = menu.addMenu("🔧 Werkzeuge")
        a_select = tools_menu.addAction("👆 Auswahl (1)")
        a_knife = tools_menu.addAction("✂ Messer (2)")
        a_trim = tools_menu.addAction("↔ Trimmen (3)")
        a_slip = tools_menu.addAction("⇄ Slip (4)")
        a_lasso = tools_menu.addAction("☐ Lasso (Q)")
        a_hand = tools_menu.addAction("✋ Hand / Pan (H)")
        a_zoom_tool = tools_menu.addAction("🔍 Lupe / Zoom (Z)")

        # ── Quick Filters ──
        filter_menu = menu.addMenu("🎨 Filter")
        a_f_warm = filter_menu.addAction("🌅 Warm (Orange-Töne)")
        a_f_cold = filter_menu.addAction("❄ Kalt (Blau-Töne)")
        a_f_bw = filter_menu.addAction("⬛ Schwarzweiß")
        a_f_vintage = filter_menu.addAction("📷 Vintage (Sepia)")
        a_f_cinema = filter_menu.addAction("🎬 Cinematic (Teal & Orange)")
        a_f_dreamy = filter_menu.addAction("💫 Dreamy (Weich + Hell)")
        a_f_dark = filter_menu.addAction("🌑 Dark & Moody")
        a_f_vivid = filter_menu.addAction("🌈 Vivid (Sättigung+)")
        filter_menu.addSeparator()
        a_f_reset = filter_menu.addAction("🔄 Filter zurücksetzen")
        for a in [a_f_warm, a_f_cold, a_f_bw, a_f_vintage, a_f_cinema,
                  a_f_dreamy, a_f_dark, a_f_vivid, a_f_reset]:
            a.setEnabled(self._clip is not None)

        # ── AI Tools ──
        ai_menu = menu.addMenu("🤖 KI-Werkzeuge")
        a_ai_beat = ai_menu.addAction("🎵 Beat-Sync Cuts — Auto-Schnitt auf Takte")
        a_ai_mood = ai_menu.addAction("🎨 Mood Color — Farbe nach Musik-Stimmung")
        a_ai_motion = ai_menu.addAction("🏃 Motion Match — Speed folgt Energie")
        a_ai_fade = ai_menu.addAction("🌅 Auto-Fade — Ein/Ausblenden")
        a_ai_scene = ai_menu.addAction("🎬 Szenen-Farbe — Pro Szene eigene Stimmung")
        a_ai_freeze = ai_menu.addAction("❄ Freeze @ Peak — Standbild bei Höhepunkt")
        for a in [a_ai_beat, a_ai_mood, a_ai_motion, a_ai_fade, a_ai_scene, a_ai_freeze]:
            a.setEnabled(self._clip is not None)

        # ── VE10: Transitions ──
        trans_menu = menu.addMenu("✨ Übergänge")
        a_tr_cross = trans_menu.addAction("✕ Crossfade")
        a_tr_dissolve = trans_menu.addAction("◐ Dissolve")
        a_tr_wipe_l = trans_menu.addAction("◀ Wipe Links")
        a_tr_wipe_r = trans_menu.addAction("▶ Wipe Rechts")
        a_tr_slide = trans_menu.addAction("⇒ Slide")
        a_tr_push = trans_menu.addAction("⟹ Push")
        a_tr_dip_b = trans_menu.addAction("■ Dip to Black")
        a_tr_dip_w = trans_menu.addAction("□ Dip to White")
        trans_menu.addSeparator()
        a_tr_remove = trans_menu.addAction("🗑 Übergang entfernen")
        _trans_actions = {
            "crossfade": a_tr_cross, "dissolve": a_tr_dissolve,
            "wipe_left": a_tr_wipe_l, "wipe_right": a_tr_wipe_r,
            "slide_right": a_tr_slide, "push_right": a_tr_push,
            "dip_black": a_tr_dip_b, "dip_white": a_tr_dip_w,
        }
        # Enable only if there are adjacent clips
        has_adjacent = len(getattr(self, '_all_clips', [])) >= 2
        for a in _trans_actions.values():
            a.setEnabled(has_adjacent)

        menu.addSeparator()

        # ── Clip Operations ──
        a_split = menu.addAction("✂ Split am Playhead (S)")
        a_split.setEnabled(self._clip is not None)
        a_copy = menu.addAction("📋 Kopieren (Ctrl+C)")
        a_copy.setEnabled(self._clip is not None)
        a_paste = menu.addAction("📋 Einfügen (Ctrl+V)")
        a_paste.setEnabled(self._clipboard is not None)
        a_dup = menu.addAction("📄 Duplizieren (Ctrl+D)")
        a_dup.setEnabled(self._clip is not None)
        menu.addSeparator()

        a_join = menu.addAction("🔗 Clips verbinden (Ctrl+J)")
        a_join.setEnabled(len(getattr(self, '_all_clips', [])) > 1)
        a_delete = menu.addAction("🗑 Löschen (Del)")
        a_delete.setEnabled(self._clip is not None)
        menu.addSeparator()

        # ── Track creation ──
        track_menu = menu.addMenu("➕ Neue Spur")
        a_new_video = track_menu.addAction("🎬 Neue Video-Spur")
        a_new_audio = track_menu.addAction("🔊 Neue Audio-Spur")
        a_new_inst = track_menu.addAction("🎹 Neue Instrument-Spur")
        menu.addSeparator()

        # ── View ──
        a_fit = menu.addAction("🔍 Alles einpassen (F)")
        a_ghost = menu.addAction("👻 Ghost-Clips " + ("✅" if self._ghost_enabled else "❌"))
        a_loop = menu.addAction("🔁 Loop " + ("✅" if self._loop_enabled else "❌"))
        menu.addSeparator()

        # ── Track Management ──
        track_menu = menu.addMenu("🎞 Spuren")
        a_new_video_track = track_menu.addAction("➕ Neue Video-Spur")
        a_new_inst_track = track_menu.addAction("➕ Neue Instrument-Spur")
        a_new_audio_track = track_menu.addAction("➕ Neue Audio-Spur")

        act = menu.exec(self.mapToGlobal(pos))
        if act is None:
            return

        # ── Handle actions ──
        if act == a_props:
            self._open_properties_dialog()
        elif act == a_select:
            self.set_tool(TOOL_SELECT)
        elif act == a_knife:
            self.set_tool(TOOL_KNIFE)
        elif act == a_trim:
            self.set_tool(TOOL_TRIM)
        elif act == a_slip:
            self.set_tool(TOOL_SLIP)
        elif act == a_lasso:
            self.set_tool(TOOL_LASSO)
        elif act == a_hand:
            self.set_tool(TOOL_HAND)
        elif act == a_zoom_tool:
            self.set_tool(TOOL_ZOOM)
        elif act == a_split:
            self.split_at_playhead()
        elif act == a_copy:
            self.copy_clip()
        elif act == a_paste:
            self.paste_clip(beat)
        elif act == a_dup:
            self.duplicate_clip()
        elif act == a_join:
            self.join_clips()
        elif act == a_delete:
            self.delete_selected_clip()
        elif act == a_new_video:
            self._create_track("video")
        elif act == a_new_audio:
            self._create_track("audio")
        elif act == a_new_inst:
            self._create_track("instrument")
        elif act == a_fit:
            self._fit_view()
        elif act == a_ghost:
            self._ghost_enabled = not self._ghost_enabled
            self._request_paint()
        elif act == a_loop:
            self._loop_enabled = not self._loop_enabled
            if self._loop_enabled and self._clip:
                self._loop_start = self._clip_start_beats
                self._loop_end = self._clip_start_beats + self._clip_length_beats
            self._request_paint()
        # Track management
        elif act == a_new_video_track:
            self._create_track("video", "Video")
        elif act == a_new_inst_track:
            self._create_track("instrument", "Instrument Track")
        elif act == a_new_audio_track:
            self._create_track("audio", "Audio Track")
        # Quick Filters
        elif act == a_f_warm:
            self._apply_filter_preset("warm")
        elif act == a_f_cold:
            self._apply_filter_preset("cold")
        elif act == a_f_bw:
            self._apply_filter_preset("bw")
        elif act == a_f_vintage:
            self._apply_filter_preset("vintage")
        elif act == a_f_cinema:
            self._apply_filter_preset("cinema")
        elif act == a_f_dreamy:
            self._apply_filter_preset("dreamy")
        elif act == a_f_dark:
            self._apply_filter_preset("dark")
        elif act == a_f_vivid:
            self._apply_filter_preset("vivid")
        elif act == a_f_reset:
            self._apply_filter_preset("reset")
        # AI Tools
        elif act == a_ai_beat:
            self._open_properties_dialog_at("ai_beat_sync")
        elif act == a_ai_mood:
            self._open_properties_dialog_at("ai_mood_color")
        elif act == a_ai_motion:
            self._open_properties_dialog_at("ai_motion_match")
        elif act == a_ai_fade:
            self._open_properties_dialog_at("ai_auto_fade")
        elif act == a_ai_scene:
            self._open_properties_dialog_at("ai_scene_color")
        elif act == a_ai_freeze:
            self._open_properties_dialog_at("ai_freeze_peak")
        # VE10: Transitions
        elif act == a_tr_remove:
            self.remove_transition_at(beat)
        else:
            for tr_type, tr_action in _trans_actions.items():
                if act == tr_action:
                    self._add_transition_at_beat(beat, tr_type)
                    break

    def _open_properties_dialog(self) -> None:
        """Open the Clip Properties dialog."""
        if not self._clip:
            return
        try:
            from pydaw.ui.video_clip_properties import ClipPropertiesDialog
            label = str(getattr(self._clip, 'label', '') or '')
            dlg = ClipPropertiesDialog(
                self._clip_id, label,
                services=getattr(self, '_ps', None),
                parent=self,
            )
            dlg.properties_changed.connect(lambda cid: self.set_clip(cid))
            dlg.show()
        except Exception as e:
            log.error("[VideoEditor] properties dialog: %s", e)

    def _open_properties_dialog_at(self, ai_tool_id: str) -> None:
        """Open properties dialog and auto-trigger an AI tool."""
        if not self._clip:
            return
        try:
            from pydaw.ui.video_clip_properties import ClipPropertiesDialog
            label = str(getattr(self._clip, 'label', '') or '')
            dlg = ClipPropertiesDialog(
                self._clip_id, label,
                services=getattr(self, '_ps', None),
                parent=self,
            )
            dlg.properties_changed.connect(lambda cid: self.set_clip(cid))
            dlg.show()
            # Auto-trigger the AI tool
            dlg._run_ai_tool(ai_tool_id)
        except Exception as e:
            log.error("[VideoEditor] AI tool dialog: %s", e)

    def _create_track(self, kind: str, name: str) -> None:
        """Create a new track from the Video Editor context menu."""
        try:
            proj = self._get_project()
            if not proj:
                return
            from pydaw.model.project import Track
            trk = Track(kind=kind, name=name)
            proj.tracks.append(trk)
            if hasattr(self._ps, '_emit_updated'):
                self._ps._emit_updated()
            try:
                self.status_message.emit(f"➕ Neue Spur: {name}")
            except Exception:
                pass
        except Exception as e:
            log.debug("[VideoEditor] create_track: %s", e)

    def _apply_filter_preset(self, preset: str) -> None:
        """Apply a quick filter preset to the selected clip."""
        if not self._clip:
            return
        try:
            from pydaw.services.video_filter_service import VideoFilterService, VideoFilter
            svc = VideoFilterService.instance()

            presets = {
                "warm": [("brightness", 0.05), ("saturation", 1.3), ("contrast", 1.1)],
                "cold": [("brightness", -0.05), ("saturation", 0.8), ("contrast", 1.1)],
                "bw": [("saturation", 0.0)],
                "vintage": [("saturation", 0.6), ("contrast", 1.2), ("brightness", 0.1),
                            ("vignette", 0.4)],
                "cinema": [("contrast", 1.3), ("saturation", 0.9), ("vignette", 0.2)],
                "dreamy": [("blur", 2.0), ("brightness", 0.1), ("saturation", 1.2)],
                "dark": [("brightness", -0.2), ("contrast", 1.4), ("saturation", 0.7),
                          ("vignette", 0.5)],
                "vivid": [("saturation", 1.8), ("contrast", 1.2), ("sharpen", 1.0)],
                "reset": [],
            }

            filters = presets.get(preset, [])

            svc.clear_filters(self._clip_id)
            for kind, value in filters:
                svc.set_filter(self._clip_id, VideoFilter(kind=kind, value=value))

            name = {
                "warm": "🌅 Warm", "cold": "❄ Kalt", "bw": "⬛ Schwarzweiß",
                "vintage": "📷 Vintage", "cinema": "🎬 Cinematic",
                "dreamy": "💫 Dreamy", "dark": "🌑 Dark", "vivid": "🌈 Vivid",
                "reset": "🔄 Reset",
            }.get(preset, preset)

            try:
                self.status_message.emit(f"🎨 Filter: {name}")
            except Exception:
                pass
            self._request_paint()
            # v0.0.20.948: Send filter change to collab
            _video_collab_send_filter(self, self._clip_id)
        except Exception as e:
            log.debug("[VideoEditor] filter preset: %s", e)

    def copy_clip(self) -> None:
        """Copy selected clip to clipboard (Ctrl+C)."""
        if not self._clip:
            return
        self._clipboard = {
            "source_path": str(getattr(self._clip, 'source_path', '') or ''),
            "length_beats": float(getattr(self._clip, 'length_beats', 0)),
            "offset_seconds": float(getattr(self._clip, 'offset_seconds', 0) or 0),
            "label": str(getattr(self._clip, 'label', '') or ''),
        }
        try:
            self.status_message.emit("📋 Clip kopiert")
        except Exception:
            pass

    def paste_clip(self, at_beat: float = -1) -> None:
        """Paste clipboard clip at playhead or given beat (Ctrl+V)."""
        if not self._clipboard:
            return
        if at_beat < 0:
            at_beat = self._get_playhead_beat()

        try:
            from pydaw.model.project import Clip
            proj = self._get_project()
            if not proj:
                return

            new_clip = Clip(
                kind="video",
                track_id=self._active_track_id,
                label=self._clipboard["label"] + " (Kopie)",
                source_path=self._clipboard["source_path"],
                start_beats=self._snap_beat(at_beat),
                length_beats=self._clipboard["length_beats"],
                offset_seconds=self._clipboard["offset_seconds"],
            )
            proj.clips.append(new_clip)

            if hasattr(self._ps, '_emit_updated'):
                self._ps._emit_updated()

            self.set_clip(str(new_clip.id))
            try:
                self.status_message.emit(f"📋 Clip eingefügt bei Beat {at_beat:.1f}")
            except Exception:
                pass
        except Exception as e:
            log.debug("[VideoEditor] paste: %s", e)

    def duplicate_clip(self) -> None:
        """Duplicate selected clip right after it (Ctrl+D)."""
        if not self._clip:
            return
        self.copy_clip()
        end_beat = self._clip_start_beats + self._clip_length_beats
        self.paste_clip(end_beat)

    def join_clips(self) -> None:
        """Join/consolidate all clips on active track (Ctrl+J).

        Creates one clip spanning from first clip start to last clip end.
        """
        clips = getattr(self, '_all_clips', [])
        if len(clips) < 2:
            return
        try:
            proj = self._get_project()
            if not proj:
                return

            min_start = min(float(getattr(c, 'start_beats', 0)) for c in clips)
            max_end = max(
                float(getattr(c, 'start_beats', 0)) + float(getattr(c, 'length_beats', 0))
                for c in clips
            )
            first = clips[0]
            source_path = str(getattr(first, 'source_path', '') or '')
            first_offset = float(getattr(first, 'offset_seconds', 0) or 0)

            # Remove all but first clip
            keep_ids = {str(getattr(first, 'id', ''))}
            proj.clips = [c for c in proj.clips
                          if str(getattr(c, 'id', '')) in keep_ids
                          or str(getattr(c, 'kind', '')) != 'video'
                          or str(getattr(c, 'track_id', '')) != self._active_track_id]

            # Extend first clip to cover all
            first.start_beats = min_start
            first.length_beats = max_end - min_start
            first.offset_seconds = first_offset
            first.label = str(getattr(first, 'label', '')).replace(" (B)", "")

            if hasattr(self._ps, '_emit_updated'):
                self._ps._emit_updated()

            self.set_clip(str(getattr(first, 'id', '')))
            try:
                self.status_message.emit(f"🔗 {len(clips)} Clips verbunden")
            except Exception:
                pass
        except Exception as e:
            log.debug("[VideoEditor] join: %s", e)

    def _fit_view(self) -> None:
        """Fit all clips in view."""
        clips = getattr(self, '_all_clips', [])
        if not clips:
            return
        min_beat = min(float(getattr(c, 'start_beats', 0)) for c in clips)
        max_beat = max(
            float(getattr(c, 'start_beats', 0)) + float(getattr(c, 'length_beats', 0))
            for c in clips
        )
        span = max(4, max_beat - min_beat + 4)
        self._px_per_beat = max(10, min(200, self.width() / span))
        self._scroll_x = max(0, min_beat - 2)
        self._request_paint()

    def split_at_playhead(self) -> None:
        """Split the clip at the current playhead position."""
        if not self._clip:
            return
        beat = self._get_playhead_beat()
        cs = self._clip_start_beats
        ce = cs + self._clip_length_beats
        if cs < beat < ce:
            self.clip_split.emit(str(self._clip_id), beat)
            try:
                self.status_message.emit(f"✂ Video gesplittet bei Beat {beat:.1f}")
            except Exception:
                pass

    def _create_track(self, kind: str) -> None:
        """Create a new track from the Video Editor (v0.0.20.936).

        Supports: video, audio, instrument
        """
        try:
            if not self._ps:
                return
            names = {"video": "🎬 Video", "audio": "🔊 Audio", "instrument": "🎹 Instrument"}
            name = names.get(kind, kind.title())
            trk = self._ps.add_track(kind, name)
            if trk:
                try:
                    self.status_message.emit(f"➕ {name} Spur erstellt")
                except Exception:
                    pass
                # Refresh view
                if self._clip_id:
                    self.set_clip(self._clip_id)
        except Exception as e:
            log.debug("[VideoEditor] create_track: %s", e)

    # ─────────────────────────────────────────────────────
    # Internal helpers
    # ─────────────────────────────────────────────────────

    def _get_project(self):
        try:
            proj = getattr(self._ps, 'project', None)
            if proj is None:
                ctx = getattr(self._ps, 'ctx', None)
                proj = getattr(ctx, 'project', None) if ctx else None
            return proj
        except Exception:
            return None

    def _get_bpm(self) -> float:
        try:
            if self._transport:
                return float(getattr(self._transport, 'bpm', 120.0) or 120.0)
            proj = self._get_project()
            if proj:
                return float(getattr(proj, 'bpm', 120.0) or 120.0)
        except Exception:
            pass
        return 120.0

    def _get_playhead_beat(self) -> float:
        try:
            if self._transport:
                return float(getattr(self._transport, 'current_beat', 0.0))
        except Exception:
            pass
        return 0.0

    def _beats_to_x(self, beat: float) -> float:
        return (beat - self._scroll_x) * self._px_per_beat

    def _x_to_beats(self, x: float) -> float:
        return x / self._px_per_beat + self._scroll_x

    def _snap_beat(self, beat: float, grid: float = -1) -> float:
        """Snap beat to grid. Uses self._snap_beats if grid=-1."""
        g = grid if grid >= 0 else self._snap_beats
        if g <= 0:
            return max(0, beat)  # free (no snap)
        return max(0, round(beat / g) * g)

    def _ensure_thumb_service(self) -> None:
        if self._thumb_svc is None:
            try:
                from pydaw.services.video_thumbnail_service import VideoThumbnailService
                self._thumb_svc = VideoThumbnailService.instance()
                self._thumb_svc.register_on_ready(self.update)
            except Exception:
                pass

    def _beat_to_video_seconds(self, beat: float) -> float:
        """Convert a beat position to seconds within the video file."""
        offset_s = float(getattr(self._clip, 'offset_seconds', 0) or 0) if self._clip else 0
        clip_start = self._clip_start_beats
        return (beat - clip_start) * 60.0 / max(1, self._bpm) + offset_s

    # ─────────────────────────────────────────────────────
    # Paint
    # ─────────────────────────────────────────────────────

    def paintEvent(self, event) -> None:
        w = self.width()
        h = self.height()
        if w < 10 or h < 10:
            return

        _paint_t0 = _time.perf_counter()  # v0.0.20.944: paint timing
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)

        # Background
        p.fillRect(0, 0, w, h, _CLR_BG)

        bpm = self._get_bpm()
        self._bpm = bpm

        # v0.0.20.944: GIL-yield points between heavy sections
        self._draw_grid(p, w, h)
        _time.sleep(0)  # yield GIL for audio thread
        self._draw_loop(p, w, h)
        self._draw_scene_markers(p, w, h)
        self._draw_ghost_tracks(p, w, h)
        _time.sleep(0)  # yield GIL before heaviest section (clips)
        self._draw_clip(p, w, h)
        _time.sleep(0)  # yield GIL after clip rendering
        self._draw_header(p, w)
        self._draw_playhead(p, w, h)
        self._draw_tool_overlay(p, w, h)
        self._draw_lasso(p, w, h)
        self._draw_automation(p, w, h)       # VE9
        self._draw_transitions(p, w, h)      # VE10
        self._draw_word_markers(p, w, h)     # VE11
        self._draw_info_bar(p, w, h)

        p.end()

        # v0.0.20.944: Log slow video editor paints to Sentinel
        _paint_ms = (_time.perf_counter() - _paint_t0) * 1000.0
        if _paint_ms > 30:
            try:
                from pydaw.services.sentinel_recorder import SentinelRecorder
                rec = SentinelRecorder.get()
                if rec and hasattr(rec, '_db') and rec._db:
                    rec._db.log_event(
                        "performance", 2, "video_editor",
                        "slow_paint_ms", round(_paint_ms, 1),
                    )
            except Exception:
                pass

    def _draw_ghost_tracks(self, p: QPainter, w: int, h: int) -> None:
        """v0.0.20.932: Draw ghost clips from other video tracks (semi-transparent)."""
        if not self._ghost_enabled:
            return
        tracks = getattr(self, '_all_tracks', [])
        if len(tracks) <= 1:
            return

        # Ghost tracks below the active track area
        ghost_y_start = _HEADER_HEIGHT + self._track_height + 20
        ghost_h = 50  # smaller than active track

        track_idx = 0
        for track_info in tracks:
            if track_info.get("is_active"):
                continue
            y = ghost_y_start + track_idx * (ghost_h + 8)
            if y + ghost_h > h - 20:
                break

            # Track label
            p.setPen(QColor(120, 120, 150))
            p.setFont(QFont("Sans-Serif", 8))
            p.drawText(4, y - 2, f"👻 {track_info['name']}")

            # Ghost separator line
            p.setPen(QPen(QColor(50, 50, 70), 1, Qt.PenStyle.DashLine))
            p.drawLine(0, y - 4, w, y - 4)

            for clip in track_info.get("clips", []):
                cs = float(getattr(clip, 'start_beats', 0))
                cl = float(getattr(clip, 'length_beats', 0))
                x1 = self._beats_to_x(cs)
                x2 = self._beats_to_x(cs + cl)
                if x2 < 0 or x1 > w:
                    continue
                clip_x = max(0, x1)
                clip_w = min(w, x2) - clip_x
                if clip_w < 2:
                    continue

                rect = QRectF(clip_x, y, clip_w, ghost_h)

                # Semi-transparent background
                p.setOpacity(0.35)
                p.fillRect(rect, QBrush(QColor(40, 60, 80)))

                # Try to draw thumbnails
                video_path = str(getattr(clip, 'source_path', '') or '')
                if video_path and os.path.isfile(video_path):
                    self._draw_filmstrip_for_clip(p, rect, clip, video_path)

                # Border
                p.setOpacity(0.5)
                p.setPen(QPen(QColor(80, 120, 140), 1))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(rect)

                # Label
                p.setPen(QColor(150, 150, 170))
                p.setFont(QFont("Sans-Serif", 7))
                label = str(getattr(clip, 'label', '') or '')
                p.drawText(int(clip_x) + 4, int(y) + 12, label[:30])

                p.setOpacity(1.0)

            track_idx += 1

    def _draw_header(self, p: QPainter, w: int) -> None:
        """Draw time ruler at top with professional SMPTE timecodes (VE8)."""
        p.fillRect(0, 0, w, _HEADER_HEIGHT, _CLR_HEADER)

        font = QFont("Monospace", 8)
        p.setFont(font)

        # Import timecode utilities (VE8)
        try:
            from pydaw.services.video_timecode import beats_to_timecode
        except ImportError:
            beats_to_timecode = None

        # Draw bar numbers
        start_beat = max(0, self._scroll_x)
        end_beat = self._x_to_beats(w)

        bar_start = int(start_beat / 4)
        bar_end = int(end_beat / 4) + 2

        for bar in range(bar_start, bar_end):
            beat = bar * 4.0
            x = self._beats_to_x(beat)
            if x < -20 or x > w + 20:
                continue

            # Bar line
            p.setPen(QPen(_CLR_GRID_BAR, 1))
            p.drawLine(int(x), 0, int(x), _HEADER_HEIGHT)

            # Bar number
            p.setPen(_CLR_TEXT)
            p.drawText(int(x) + 3, _HEADER_HEIGHT - 6, f"Bar {bar + 1}")

            # VE8: Frame-accurate SMPTE timecode (HH:MM:SS:FF)
            if beats_to_timecode:
                tc = beats_to_timecode(
                    beat, self._bpm, fps=self._timecode_fps,
                    drop_frame=self._timecode_drop_frame)
                p.setPen(_CLR_SMPTE)
                p.drawText(int(x) + 3, 11, str(tc))
            else:
                secs = beat * 60.0 / max(1, self._bpm)
                m = int(secs) // 60
                s = int(secs) % 60
                f = int((secs - int(secs)) * self._timecode_fps)
                p.setPen(_CLR_SMPTE)
                sep = ";" if self._timecode_drop_frame else ":"
                p.drawText(int(x) + 3, 11, f"{m:02d}:{s:02d}{sep}{f:02d}")

        # Bottom line
        p.setPen(QPen(QColor(60, 60, 80), 1))
        p.drawLine(0, _HEADER_HEIGHT - 1, w, _HEADER_HEIGHT - 1)

    def _draw_grid(self, p: QPainter, w: int, h: int) -> None:
        """Draw beat/bar grid with subdivisions matching snap resolution."""
        start_beat = max(0, self._scroll_x)
        end_beat = self._x_to_beats(w)

        # Bar lines (every 4 beats)
        bar_start = int(start_beat / 4)
        bar_end = int(end_beat / 4) + 2
        for bar in range(bar_start, bar_end):
            beat = bar * 4.0
            x = int(self._beats_to_x(beat))
            if 0 <= x <= w:
                p.setPen(QPen(_CLR_GRID_BAR, 1))
                p.drawLine(x, _HEADER_HEIGHT, x, h)

        # Beat lines
        beat_start = int(start_beat)
        beat_end = int(end_beat) + 2
        for beat in range(beat_start, beat_end):
            if beat % 4 == 0:
                continue  # already drawn as bar line
            x = int(self._beats_to_x(beat))
            if 0 <= x <= w:
                p.setPen(QPen(_CLR_GRID_BEAT, 1))
                p.drawLine(x, _HEADER_HEIGHT, x, h)

        # Sub-beat grid lines (based on snap resolution)
        if self._grid_subdivisions and self._snap_beats > 0 and self._snap_beats < 1.0:
            sub_step = self._snap_beats
            sub_beat = max(0, int(start_beat / sub_step) * sub_step)
            p.setPen(QPen(QColor(35, 35, 50), 1, Qt.PenStyle.DotLine))
            while sub_beat <= end_beat:
                # Skip if it falls on a beat or bar line
                if abs(sub_beat - round(sub_beat)) > 0.01:
                    x = int(self._beats_to_x(sub_beat))
                    if 0 <= x <= w:
                        p.drawLine(x, _HEADER_HEIGHT, x, h)
                sub_beat += sub_step

    def _draw_loop(self, p: QPainter, w: int, h: int) -> None:
        """Draw loop region (semi-transparent overlay like Arranger)."""
        if not self._loop_enabled:
            return

        x1 = int(self._beats_to_x(self._loop_start))
        x2 = int(self._beats_to_x(self._loop_end))

        if x2 < 0 or x1 > w:
            return

        # Loop region fill
        loop_color = QColor(80, 200, 120, 30)
        p.fillRect(x1, 0, x2 - x1, h, QBrush(loop_color))

        # Loop boundaries
        p.setPen(QPen(QColor(80, 200, 120, 200), 2))
        if 0 <= x1 <= w:
            p.drawLine(x1, 0, x1, h)
        if 0 <= x2 <= w:
            p.drawLine(x2, 0, x2, h)

        # Loop markers in header
        p.setFont(QFont("Monospace", 7))
        p.setPen(QColor(80, 200, 120))
        if 0 <= x1 <= w:
            p.drawText(x1 + 2, _HEADER_HEIGHT - 3, "L")
        if 0 <= x2 <= w:
            p.drawText(x2 - 10, _HEADER_HEIGHT - 3, "R")

        # Loop handles (top of region)
        handle_w = 8
        handle_h = 10
        p.setBrush(QBrush(QColor(80, 200, 120, 180)))
        p.setPen(Qt.PenStyle.NoPen)
        if 0 <= x1 <= w:
            from PyQt6.QtGui import QPolygonF
            p.drawPolygon(QPolygonF([
                QPointF(x1, 0), QPointF(x1 + handle_w, 0), QPointF(x1, handle_h),
            ]))
        if 0 <= x2 <= w:
            from PyQt6.QtGui import QPolygonF
            p.drawPolygon(QPolygonF([
                QPointF(x2, 0), QPointF(x2 - handle_w, 0), QPointF(x2, handle_h),
            ]))

    def _draw_scene_markers(self, p: QPainter, w: int, h: int) -> None:
        """Draw Video-KI scene markers as colored vertical bands."""
        if not self._scene_markers:
            return

        for marker in self._scene_markers:
            beat = float(marker.get("beat", 0))
            x = int(self._beats_to_x(beat))
            if x < -10 or x > w + 10:
                continue

            color_str = marker.get("color", "#ffcc44")
            try:
                clr = QColor(color_str)
                clr.setAlpha(60)
            except Exception:
                clr = _CLR_SCENE_MARKER

            # Vertical line
            p.setPen(QPen(QColor(color_str), 2))
            p.drawLine(x, _HEADER_HEIGHT, x, h)

            # Label
            label = marker.get("label", "")
            if label:
                p.setPen(QColor(color_str))
                p.setFont(QFont("Monospace", 7))
                p.drawText(x + 3, _HEADER_HEIGHT + 12, label[:30])

    def _draw_clip(self, p: QPainter, w: int, h: int) -> None:
        """Draw ALL video clips on this track as filmstrips.

        v0.0.20.937: Per-clip opacity from ClipVideoProps + triangle menu icon.
        """
        clips = getattr(self, '_all_clips', [])
        if not clips and not self._clip:
            p.setPen(_CLR_TEXT)
            p.setFont(QFont("Sans-Serif", 11))
            p.drawText(
                QRectF(0, _HEADER_HEIGHT, w, h - _HEADER_HEIGHT),
                Qt.AlignmentFlag.AlignCenter,
                "🎬 Kein Video-Clip ausgewählt\n\n"
                "Doppelklicke auf einen Video-Clip im Arranger\n"
                "oder ziehe ein Video auf die Timeline"
            )
            return

        if not clips:
            clips = [self._clip] if self._clip else []

        y = _HEADER_HEIGHT + 4
        ch = self._track_height

        # Store clip rects for hit-testing (triangle clicks)
        self._clip_rects: List[tuple] = []  # [(clip_id, QRectF, triangle_QRectF)]

        _vclip_count = 0
        for clip in clips:
            # v0.0.20.944: Yield GIL every 4 clips
            _vclip_count += 1
            if _vclip_count % 4 == 0:
                _time.sleep(0)
            cs = float(getattr(clip, 'start_beats', 0))
            cl = float(getattr(clip, 'length_beats', 0))
            ce = cs + cl
            cid = str(getattr(clip, 'id', ''))
            is_selected = (cid == str(self._clip_id))

            x1 = self._beats_to_x(cs)
            x2 = self._beats_to_x(ce)

            if x2 < 0 or x1 > w:
                continue

            clip_x = max(0, x1)
            clip_w = min(w, x2) - clip_x
            if clip_w < 2:
                continue

            clip_rect = QRectF(clip_x, y, clip_w, ch)

            # v0.0.20.937: Apply per-clip opacity from ClipVideoProps
            try:
                from pydaw.ui.video_clip_properties import ClipVideoProps
                props = ClipVideoProps.get(cid)
                clip_opacity = max(0.0, min(1.0, props.opacity))
            except Exception:
                clip_opacity = 1.0

            p.setOpacity(clip_opacity)

            # Clip background
            bg = QColor(22, 50, 60) if is_selected else QColor(18, 38, 48)
            p.fillRect(clip_rect, QBrush(bg))

            # Draw real frame thumbnails
            video_path = str(getattr(clip, 'source_path', '') or '')
            self._draw_filmstrip_for_clip(p, clip_rect, clip, video_path)

            # Clip border
            if is_selected:
                p.setPen(QPen(_CLR_CLIP_SELECTED, 2))
            else:
                p.setPen(QPen(_CLR_CLIP_BORDER, 1))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(clip_rect)

            # Trim handles (when selected)
            if is_selected:
                handle_w = 6
                p.fillRect(QRectF(clip_x, y, handle_w, ch), QBrush(_CLR_TRIM_HANDLE))
                p.fillRect(QRectF(clip_x + clip_w - handle_w, y, handle_w, ch),
                            QBrush(_CLR_TRIM_HANDLE))

            p.setOpacity(1.0)  # Reset for text

            # Clip label
            p.setPen(QColor(220, 220, 230) if is_selected else QColor(170, 170, 180))
            p.setFont(QFont("Sans-Serif", 9, QFont.Weight.Bold))
            label = str(getattr(clip, 'label', '') or os.path.basename(video_path))
            p.drawText(int(clip_x) + 8, int(y) + 14, f"🎬 {label[:40]}")

            # Opacity indicator (if not 100%)
            if clip_opacity < 0.99:
                p.setPen(QColor(200, 200, 100))
                p.setFont(QFont("Monospace", 7))
                p.drawText(int(clip_x) + 8, int(y) + 26,
                           f"🔍 {int(clip_opacity * 100)}%")

            # Speed indicator (if not 1.0×)
            try:
                spd = props.speed if props else 1.0
                if abs(spd - 1.0) > 0.01:
                    p.setPen(QColor(200, 160, 100))
                    p.setFont(QFont("Monospace", 7))
                    spd_x = int(clip_x) + 8 + (70 if clip_opacity < 0.99 else 0)
                    p.drawText(spd_x, int(y) + 26, f"⏱{spd:.2f}×")
            except Exception:
                pass

            # Duration info
            dur_s = cl * 60.0 / max(1, self._bpm)
            p.setFont(QFont("Monospace", 7))
            p.setPen(QColor(120, 170, 190))
            p.drawText(int(clip_x) + 8, int(y + ch) - 6,
                       f"{dur_s:.1f}s | {cl:.1f} beats")

            # ── Triangle menu icon (top-right corner) ──
            tri_size = 14
            tri_x = int(clip_x + clip_w - tri_size - 4)
            tri_y = int(y + 3)
            tri_rect = QRectF(tri_x - 2, tri_y - 2, tri_size + 4, tri_size + 4)

            # Triangle background
            tri_bg = QColor(60, 60, 80, 180) if not is_selected else QColor(80, 180, 200, 180)
            p.setBrush(QBrush(tri_bg))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(tri_rect, 3, 3)

            # Triangle arrow (▼)
            from PyQt6.QtGui import QPolygonF
            p.setBrush(QBrush(QColor(220, 220, 230)))
            p.drawPolygon(QPolygonF([
                QPointF(tri_x + 2, tri_y + 3),
                QPointF(tri_x + tri_size - 2, tri_y + 3),
                QPointF(tri_x + tri_size // 2, tri_y + tri_size - 2),
            ]))

            # Store for hit-testing
            self._clip_rects.append((cid, clip_rect, tri_rect))

            # Gap indicator between clips
            idx_in_list = clips.index(clip)
            if idx_in_list < len(clips) - 1:
                next_clip = clips[idx_in_list + 1]
                next_start = float(getattr(next_clip, 'start_beats', 0))
                if next_start > ce + 0.01:
                    gap_x1 = self._beats_to_x(ce)
                    gap_x2 = self._beats_to_x(next_start)
                    if gap_x1 > 0 and gap_x2 < w:
                        p.setPen(QPen(QColor(100, 100, 60, 100), 1, Qt.PenStyle.DashLine))
                        gap_mid_y = y + ch // 2
                        p.drawLine(int(gap_x1), gap_mid_y, int(gap_x2), gap_mid_y)

    def _draw_filmstrip_for_clip(self, p: QPainter, rect: QRectF,
                                  clip, video_path: str) -> None:
        """Draw filmstrip thumbnails for a specific clip."""
        if not video_path or not os.path.isfile(video_path):
            return
        self._ensure_thumb_service()
        svc = self._thumb_svc
        if not svc:
            return

        x0 = rect.x()
        y0 = rect.y() + 20
        cw = rect.width()
        ch = rect.height() - 26
        if ch < 16 or cw < 16:
            return

        thumb_h = max(16, int(ch))
        thumb_w = max(16, int(thumb_h * 16 / 9))
        n_frames = max(1, int(cw / max(8, thumb_w)))
        frame_w = cw / max(1, n_frames)

        cl = float(getattr(clip, 'length_beats', 0))
        clip_len_s = cl * 60.0 / max(1, self._bpm)
        offset_s = float(getattr(clip, 'offset_seconds', 0) or 0)
        step_s = clip_len_s / max(1, n_frames) if clip_len_s > 0 else 1.0

        times = [offset_s + i * step_s for i in range(n_frames)]
        missing = []

        for i, t in enumerate(times):
            fx = x0 + i * frame_w
            if fx + frame_w < 0 or fx > self.width():
                continue
            pixmap = svc.get_frame(video_path, t, thumb_w, thumb_h)
            if pixmap is not None:
                p.drawPixmap(QRectF(fx, y0, frame_w, ch).toRect(), pixmap)
            else:
                p.fillRect(QRectF(fx, y0, frame_w, ch), QBrush(QColor(25, 50, 60)))
                missing.append(t)
            if i > 0:
                p.setPen(QPen(QColor(0, 0, 0, 100), 1))
                p.drawLine(int(fx), int(y0), int(fx), int(y0 + ch))

        if missing:
            svc.request_frames(video_path, missing, thumb_w, thumb_h)

    def _draw_playhead(self, p: QPainter, w: int, h: int) -> None:
        """Draw the transport playhead cursor."""
        beat = self._get_playhead_beat()
        x = int(self._beats_to_x(beat))
        if x < 0 or x > w:
            return

        p.setPen(QPen(_CLR_PLAYHEAD, 2))
        p.drawLine(x, 0, x, h)

        # Playhead triangle at top
        p.setBrush(QBrush(_CLR_PLAYHEAD))
        p.setPen(Qt.PenStyle.NoPen)
        from PyQt6.QtGui import QPolygonF
        tri = QPolygonF([
            QPointF(x - 5, 0),
            QPointF(x + 5, 0),
            QPointF(x, 8),
        ])
        p.drawPolygon(tri)

    def _draw_tool_overlay(self, p: QPainter, w: int, h: int) -> None:
        """Draw tool-specific overlays (knife line, etc)."""
        if self._tool == TOOL_KNIFE and self._clip:
            mx = self._mouse_pos.x()
            if 0 <= mx <= w:
                p.setPen(QPen(_CLR_KNIFE, 1, Qt.PenStyle.DashLine))
                p.drawLine(int(mx), _HEADER_HEIGHT, int(mx), h)

                # Show beat position
                beat = self._x_to_beats(mx)
                p.setPen(_CLR_KNIFE)
                p.setFont(QFont("Monospace", 8))
                p.drawText(int(mx) + 4, h - 8, f"Beat {beat:.2f}")

    def _draw_lasso(self, p: QPainter, w: int, h: int) -> None:
        """v0.0.20.938: Draw lasso selection rectangle + multi-selection highlights."""
        # Multi-selection highlight (blue glow on selected clips)
        if self._selected_clip_ids:
            for cid, clip_rect, tri_rect in getattr(self, '_clip_rects', []):
                if cid in self._selected_clip_ids:
                    p.setPen(QPen(QColor(80, 180, 255, 200), 2, Qt.PenStyle.DashLine))
                    p.setBrush(QBrush(QColor(80, 180, 255, 25)))
                    p.drawRect(clip_rect)

            # Group indicators
            groups_shown = set()
            for cid, clip_rect, tri_rect in getattr(self, '_clip_rects', []):
                gid = self._clip_groups.get(cid)
                if gid and gid not in groups_shown:
                    groups_shown.add(gid)
                    p.setPen(QColor(255, 200, 80))
                    p.setFont(QFont("Monospace", 7))
                    p.drawText(int(clip_rect.x()) + 8, int(clip_rect.y()) - 2,
                               f"🔗 {gid}")

        # Lasso rectangle
        if self._lasso_rect:
            p.setPen(QPen(QColor(100, 200, 255, 200), 1, Qt.PenStyle.DashLine))
            p.setBrush(QBrush(QColor(100, 200, 255, 30)))
            p.drawRect(self._lasso_rect)

    # ─────────────────────────────────────────────────────
    # VE9: Automation Drawing
    # ─────────────────────────────────────────────────────

    def _get_automation_store(self):
        """Lazy-init the automation store."""
        if self._automation_store is None:
            try:
                from pydaw.services.video_automation import VideoAutomationStore
                self._automation_store = VideoAutomationStore()
            except Exception:
                pass
        return self._automation_store

    def _draw_automation(self, p: QPainter, w: int, h: int) -> None:
        """VE9: Draw automation curves overlaid on clips."""
        if not self._automation_visible:
            return
        store = self._get_automation_store()
        if not store:
            return

        all_clips = getattr(self, '_all_clips', [])
        if not all_clips and self._clip:
            all_clips = [self._clip]

        for clip in all_clips:
            cid = str(getattr(clip, 'id', ''))
            auto = store.get(cid)
            if not auto or not auto.has_automation():
                continue

            cs = float(getattr(clip, 'start_beats', 0))
            cl = float(getattr(clip, 'length_beats', 0))
            if cl <= 0:
                continue

            x_start = self._beats_to_x(cs)
            x_end = self._beats_to_x(cs + cl)
            if x_end < 0 or x_start > w:
                continue

            # Draw each enabled lane
            lane_colors = {
                "opacity": QColor(79, 195, 247, 180),   # blue
                "speed": QColor(255, 200, 60, 180),      # yellow
                "volume": QColor(100, 220, 100, 180),    # green
            }

            for lane_name, curve in [("opacity", auto.opacity),
                                      ("speed", auto.speed),
                                      ("volume", auto.volume)]:
                if not curve.enabled or not curve.points:
                    continue

                color = lane_colors.get(lane_name, QColor(200, 200, 200, 180))
                pen = QPen(color, 2)
                p.setPen(pen)

                # Clip area for automation drawing
                clip_top = _HEADER_HEIGHT
                clip_bottom = h - 20  # above info bar
                auto_height = clip_bottom - clip_top

                # Draw curve line
                num_samples = max(2, int(x_end - x_start))
                prev_px = None
                for i in range(num_samples):
                    frac = i / max(1, num_samples - 1)
                    beat_pos = frac * cl  # relative to clip start
                    val = curve.evaluate(beat_pos)

                    px_x = int(x_start + frac * (x_end - x_start))
                    px_y = int(clip_bottom - val * auto_height)

                    if prev_px is not None:
                        p.drawLine(prev_px[0], prev_px[1], px_x, px_y)
                    prev_px = (px_x, px_y)

                # Draw breakpoints
                point_color = QColor(color.red(), color.green(), color.blue(), 255)
                for idx, pt in enumerate(curve.points):
                    px_x = int(x_start + (pt.position / cl) * (x_end - x_start))
                    px_y = int(clip_bottom - pt.value * auto_height)

                    # Highlight active lane
                    is_active = (lane_name == self._active_automation_lane)
                    size = 5 if is_active else 3
                    p.setPen(QPen(QColor(255, 255, 255), 1))
                    p.setBrush(QBrush(point_color))
                    p.drawEllipse(px_x - size, px_y - size, size * 2, size * 2)

                p.setBrush(Qt.BrushStyle.NoBrush)

    # ─────────────────────────────────────────────────────
    # VE10: Transition Drawing
    # ─────────────────────────────────────────────────────

    def _get_transition_store(self):
        """Lazy-init the transition store."""
        if self._transition_store is None:
            try:
                from pydaw.services.video_transitions import VideoTransitionStore
                self._transition_store = VideoTransitionStore()
            except Exception:
                pass
        return self._transition_store

    def _draw_transitions(self, p: QPainter, w: int, h: int) -> None:
        """VE10: Draw transition indicators between clips."""
        store = self._get_transition_store()
        if not store:
            return

        transitions = store.get_all()
        if not transitions:
            return

        clip_top = _HEADER_HEIGHT
        clip_bottom = h - 20
        mid_y = (clip_top + clip_bottom) // 2

        for tr in transitions:
            x_start = self._beats_to_x(tr.start_beat)
            x_end = self._beats_to_x(tr.end_beat)
            x_center = self._beats_to_x(tr.position_beats)

            if x_end < 0 or x_start > w:
                continue

            # Transition zone background
            tr_color = QColor(255, 160, 60, 50)
            p.fillRect(int(x_start), clip_top, int(x_end - x_start),
                       clip_bottom - clip_top, tr_color)

            # Border lines
            p.setPen(QPen(QColor(255, 160, 60, 150), 1, Qt.PenStyle.DashLine))
            p.drawLine(int(x_start), clip_top, int(x_start), clip_bottom)
            p.drawLine(int(x_end), clip_top, int(x_end), clip_bottom)

            # Center line (cut point)
            p.setPen(QPen(QColor(255, 200, 100, 200), 2))
            p.drawLine(int(x_center), clip_top, int(x_center), clip_bottom)

            # Transition type icon
            icons = {
                "crossfade": "✕", "dissolve": "◐", "wipe_left": "◀",
                "wipe_right": "▶", "wipe_up": "▲", "wipe_down": "▼",
                "slide_left": "⇐", "slide_right": "⇒",
                "push_left": "⟸", "push_right": "⟹",
                "dip_black": "■", "dip_white": "□",
                "ki_morph": "🤖",
            }
            icon = icons.get(tr.transition_type.value, "✕")
            p.setFont(QFont("Monospace", 10))
            p.setPen(QColor(255, 220, 120))
            p.drawText(int(x_center) - 6, mid_y + 4, icon)

            # Duration label
            p.setFont(QFont("Monospace", 7))
            p.setPen(QColor(255, 200, 100, 200))
            p.drawText(int(x_start) + 2, clip_top + 12,
                       f"{tr.duration_beats:.1f}b {tr.transition_type.value}")

    def _draw_word_markers(self, p: QPainter, w: int, h: int) -> None:
        """VE11: Draw word boundary markers from transcript."""
        if not self._word_markers:
            return

        bpm = self._bpm
        if bpm <= 0:
            return

        clip_top = _HEADER_HEIGHT
        clip_bottom = clip_top + self._track_height
        marker_y = clip_bottom - 6  # bottom of clip lane

        pen_active = QPen(QColor(100, 200, 255, 60))
        pen_active.setWidth(1)
        pen_deleted = QPen(QColor(255, 60, 60, 100))
        pen_deleted.setWidth(1)

        for m in self._word_markers:
            start_sec = m.get("start", 0)
            end_sec = m.get("end", 0)
            deleted = m.get("deleted", False)

            start_beat = start_sec * bpm / 60.0
            end_beat = end_sec * bpm / 60.0

            x_start = self._beats_to_x(start_beat)
            x_end = self._beats_to_x(end_beat)

            if x_end < 0 or x_start > w:
                continue

            if deleted:
                # Red overlay for deleted words
                p.setPen(pen_deleted)
                p.fillRect(int(x_start), clip_top,
                           max(1, int(x_end - x_start)),
                           self._track_height,
                           QColor(255, 30, 30, 25))
                p.drawLine(int(x_start), clip_top,
                           int(x_start), clip_bottom)
            else:
                # Subtle tick marks at word boundaries
                p.setPen(pen_active)
                p.drawLine(int(x_start), marker_y,
                           int(x_start), clip_bottom)

    def _draw_info_bar(self, p: QPainter, w: int, h: int) -> None:
        """Draw info bar at bottom with tool, snap, loop, cursor info."""
        bar_h = 20
        y = h - bar_h
        p.fillRect(0, y, w, bar_h, QColor(25, 25, 40))

        p.setFont(QFont("Monospace", 8))
        p.setPen(_CLR_TEXT)

        info = f"Tool: {self._tool.upper()}"
        if self._clip:
            info += f"  |  Clip: {self._clip_start_beats:.1f}–{self._clip_start_beats + self._clip_length_beats:.1f} beats"
        info += f"  |  Zoom: {self._px_per_beat:.0f}px/beat"
        info += f"  |  BPM: {self._bpm:.0f}"

        # Snap indicator
        snap = self._snap_beats
        snap_str = {0: "OFF", 0.25: "1/16", 0.5: "1/8", 1.0: "1/4", 2.0: "1/2", 4.0: "Bar"}.get(snap, f"{snap}")
        info += f"  |  📐{snap_str}"

        # Loop indicator
        if self._loop_enabled:
            info += f"  |  🔁{self._loop_start:.0f}–{self._loop_end:.0f}"

        beat = self._x_to_beats(self._mouse_pos.x())
        secs = beat * 60.0 / max(1, self._bpm)
        info += f"  |  Cursor: Beat {beat:.2f} ({secs:.1f}s)"

        p.drawText(4, y + 14, info)

    # ─────────────────────────────────────────────────────
    # Mouse Events
    # ─────────────────────────────────────────────────────

    def mousePressEvent(self, event: QMouseEvent) -> None:
        self._mouse_pos = event.position()
        beat = self._x_to_beats(event.position().x())

        if event.button() == Qt.MouseButton.LeftButton:
            # v0.0.20.937: Check triangle menu click first
            mx, my = event.position().x(), event.position().y()
            for cid, clip_rect, tri_rect in getattr(self, '_clip_rects', []):
                if tri_rect.contains(event.position()):
                    self._show_clip_triangle_menu(cid, event.globalPosition().toPoint())
                    return

            if self._tool == TOOL_KNIFE:
                # Split at click position — find which clip is under cursor
                snapped = self._snap_beat(beat)
                for clip in getattr(self, '_all_clips', []):
                    cs = float(getattr(clip, 'start_beats', 0))
                    ce = cs + float(getattr(clip, 'length_beats', 0))
                    if cs < snapped < ce:
                        cid = str(getattr(clip, 'id', ''))
                        self.clip_split.emit(cid, snapped)
                        try:
                            self.status_message.emit(f"✂ Split bei Beat {snapped:.1f}")
                        except Exception:
                            pass
                        break
                return

            if self._tool == TOOL_TRIM and self._clip:
                cs = self._clip_start_beats
                ce = cs + self._clip_length_beats
                x_start = self._beats_to_x(cs)
                x_end = self._beats_to_x(ce)
                mx = event.position().x()
                if abs(mx - x_start) < 10:
                    self._drag_edge = "start"
                    self._dragging = True
                elif abs(mx - x_end) < 10:
                    self._drag_edge = "end"
                    self._dragging = True
                return

            if self._tool == TOOL_LASSO:
                # v0.0.20.938: Start lasso selection rectangle
                self._lasso_start = event.position()
                self._lasso_rect = QRectF(event.position(), QSizeF(0, 0))
                self._dragging = True
                if not (event.modifiers() & Qt.KeyboardModifier.ShiftModifier):
                    self._selected_clip_ids.clear()
                return

            if self._tool == TOOL_HAND:
                # v0.0.20.938: Hand tool — pan
                self._dragging = True
                self._drag_start = event.position()
                self.setCursor(Qt.CursorShape.ClosedHandCursor)
                return

            if self._tool == TOOL_ZOOM:
                # v0.0.20.938: Zoom tool
                if event.modifiers() & Qt.KeyboardModifier.AltModifier:
                    self._px_per_beat = max(10, self._px_per_beat / 1.4)
                else:
                    self._px_per_beat = min(200, self._px_per_beat * 1.4)
                self._request_paint()
                return

            if self._tool == TOOL_SMART_CONTEXT:
                # VE8: Auto tool switch by click position
                mx, my = event.position().x(), event.position().y()
                self._smart_context_dispatch(mx, my, beat, event)
                return

            if self._tool == TOOL_AUTOMATION:
                # VE9: Add/move automation breakpoints
                mx, my = event.position().x(), event.position().y()
                self._automation_mouse_press(mx, my, beat, event)
                return

            if self._tool == TOOL_SELECT:
                # v0.0.20.934: Check for loop handle drag in header area
                my = event.position().y()
                if my < _HEADER_HEIGHT and self._loop_enabled:
                    x_ls = self._beats_to_x(self._loop_start)
                    x_le = self._beats_to_x(self._loop_end)
                    mx = event.position().x()
                    if abs(mx - x_ls) < 12:
                        self._loop_dragging = "start"
                        self._dragging = True
                        return
                    elif abs(mx - x_le) < 12:
                        self._loop_dragging = "end"
                        self._dragging = True
                        return

                ctrl = bool(event.modifiers() & Qt.KeyboardModifier.ControlModifier)

                # Click to select clip under cursor
                selected = self.select_clip_at(beat)

                if selected and ctrl:
                    self._ctrl_drag_copy = True
                    self._dragging = True
                    self._drag_start = event.position()
                    self._drag_start_beat = beat
                elif selected and not ctrl:
                    self._ctrl_drag_copy = False
                    self._dragging = True
                    self._drag_start = event.position()
                    self._drag_start_beat = beat

                # v0.0.20.934: Snap playhead to grid on click
                snapped = self._snap_beat(beat)
                if self._transport and hasattr(self._transport, 'set_position'):
                    try:
                        self._transport.set_position(snapped)
                    except Exception:
                        pass

        elif event.button() == Qt.MouseButton.MiddleButton:
            self._dragging = True
            self._drag_start = event.position()
            self._drag_edge = None

        self._request_paint()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        self._mouse_pos = event.position()

        if self._dragging:
            if event.buttons() & Qt.MouseButton.MiddleButton:
                # Pan view
                dx = event.position().x() - self._drag_start.x()
                self._scroll_x -= dx / self._px_per_beat
                self._scroll_x = max(0, self._scroll_x)
                self._drag_start = event.position()

            elif self._tool == TOOL_LASSO and self._lasso_start:
                # v0.0.20.938: Update lasso selection rectangle
                self._lasso_rect = QRectF(self._lasso_start, event.position()).normalized()

            elif self._tool == TOOL_HAND:
                # v0.0.20.938: Hand tool pan
                dx = event.position().x() - self._drag_start.x()
                self._scroll_x -= dx / self._px_per_beat
                self._scroll_x = max(0, self._scroll_x)
                self._drag_start = event.position()

            elif self._loop_dragging:
                # v0.0.20.934: Loop region drag
                beat = self._snap_beat(self._x_to_beats(event.position().x()))
                if self._loop_dragging == "start":
                    self._loop_start = max(0, min(beat, self._loop_end - self._snap_beats))
                elif self._loop_dragging == "end":
                    self._loop_end = max(self._loop_start + max(0.25, self._snap_beats), beat)

            elif self._drag_edge and self._clip:
                beat = self._snap_beat(self._x_to_beats(event.position().x()))
                if self._drag_edge == "start":
                    new_start = max(0, beat)
                    if new_start < self._clip_start_beats + self._clip_length_beats - 0.25:
                        diff = new_start - self._clip_start_beats
                        self._clip_start_beats = new_start
                        self._clip_length_beats -= diff
                elif self._drag_edge == "end":
                    new_end = max(self._clip_start_beats + 0.25, beat)
                    self._clip_length_beats = new_end - self._clip_start_beats

        # Cursor shape based on position
        if self._tool == TOOL_SELECT:
            mx = event.position().x()
            my = event.position().y()

            # Loop handle cursor
            if my < _HEADER_HEIGHT and self._loop_enabled:
                x_ls = self._beats_to_x(self._loop_start)
                x_le = self._beats_to_x(self._loop_end)
                if abs(mx - x_ls) < 12 or abs(mx - x_le) < 12:
                    self.setCursor(Qt.CursorShape.SizeHorCursor)
                    self._request_paint()
                    return

            # Trim handle cursor
            if self._clip:
                cs = self._clip_start_beats
                ce = cs + self._clip_length_beats
                x_start = self._beats_to_x(cs)
                x_end = self._beats_to_x(ce)
                if abs(mx - x_start) < 8 or abs(mx - x_end) < 8:
                    self.setCursor(Qt.CursorShape.SizeHorCursor)
                else:
                    self.setCursor(Qt.CursorShape.ArrowCursor)

        # VE9: Automation point drag
        if self._tool == TOOL_AUTOMATION and self._dragging:
            self._automation_mouse_move(event.position().x(), event.position().y())

        self._request_paint()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if self._dragging and self._drag_edge and self._clip:
            # Apply trim to clip model
            try:
                self._clip.start_beats = self._clip_start_beats
                self._clip.length_beats = self._clip_length_beats
                self.clip_trimmed.emit(
                    str(self._clip_id),
                    self._clip_start_beats if self._drag_edge == "start"
                    else self._clip_length_beats,
                    self._drag_edge,
                )
                try:
                    self.status_message.emit(
                        f"✂ Trimmed {self._drag_edge}: {self._clip_start_beats:.1f}–"
                        f"{self._clip_start_beats + self._clip_length_beats:.1f}")
                except Exception:
                    pass
                if hasattr(self._ps, '_emit_updated'):
                    self._ps._emit_updated()
            except Exception as e:
                log.debug("[VideoEditor] trim apply: %s", e)

        elif self._dragging and self._clip and not self._drag_edge:
            # v0.0.20.932: Ctrl+drag = copy, normal drag = move
            beat = self._x_to_beats(event.position().x())
            drag_dist = abs(beat - self._drag_start_beat)
            if drag_dist > 0.5:  # minimum drag distance
                if self._ctrl_drag_copy:
                    # Copy clip to new position
                    self.copy_clip()
                    self.paste_clip(self._snap_beat(beat))
                    try:
                        self.status_message.emit(f"📄 Clip kopiert zu Beat {beat:.1f}")
                    except Exception:
                        pass
                else:
                    # Move clip to new position
                    try:
                        new_start = self._snap_beat(beat - (self._drag_start_beat - self._clip_start_beats))
                        new_start = max(0, new_start)
                        self._clip.start_beats = new_start
                        self._clip_start_beats = new_start
                        if hasattr(self._ps, '_emit_updated'):
                            self._ps._emit_updated()
                        self.set_clip(self._clip_id)
                        try:
                            self.status_message.emit(f"↔ Clip verschoben zu Beat {new_start:.1f}")
                        except Exception:
                            pass
                    except Exception as e:
                        log.debug("[VideoEditor] move: %s", e)

        self._dragging = False
        self._drag_edge = None
        self._ctrl_drag_copy = False

        # VE9: Reset automation drag state
        self._automation_drag_point = -1
        self._automation_drag_clip = ""

        # v0.0.20.938: Finish lasso selection
        if self._tool == TOOL_LASSO and self._lasso_rect:
            for cid, clip_rect, tri_rect in getattr(self, '_clip_rects', []):
                if self._lasso_rect.intersects(clip_rect):
                    self._selected_clip_ids.add(cid)
            n = len(self._selected_clip_ids)
            try:
                if n:
                    self.status_message.emit(f"✅ {n} Clips ausgewählt")
            except Exception:
                pass
            self._lasso_rect = None
            self._lasso_start = None

        # v0.0.20.938: Hand tool cursor reset
        if self._tool == TOOL_HAND:
            self.setCursor(Qt.CursorShape.OpenHandCursor)

        # v0.0.20.934: Commit loop region to transport
        if self._loop_dragging:
            self._loop_dragging = None
            if self._transport and hasattr(self._transport, 'set_loop'):
                try:
                    self._transport.set_loop(self._loop_enabled, self._loop_start, self._loop_end)
                except Exception:
                    pass
        self._request_paint()

    def wheelEvent(self, event: QWheelEvent) -> None:
        delta = event.angleDelta().y()
        if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            # Zoom
            factor = 1.15 if delta > 0 else 0.87
            self._px_per_beat = max(10, min(200, self._px_per_beat * factor))
        else:
            # Scroll
            self._scroll_x -= delta / 120.0 * 2
            self._scroll_x = max(0, self._scroll_x)
        self._request_paint()

    def keyPressEvent(self, event: QKeyEvent) -> None:
        key = event.key()
        mods = event.modifiers()
        ctrl = bool(mods & Qt.KeyboardModifier.ControlModifier)

        # Ctrl+Key shortcuts
        if ctrl:
            shift = bool(mods & Qt.KeyboardModifier.ShiftModifier)
            if key == Qt.Key.Key_C:
                self.copy_clip()
                return
            elif key == Qt.Key.Key_V:
                self.paste_clip()
                return
            elif key == Qt.Key.Key_D:
                self.duplicate_clip()
                return
            elif key == Qt.Key.Key_J:
                self.join_clips()
                return
            elif key == Qt.Key.Key_A:
                self.select_all()
                return
            elif key == Qt.Key.Key_G and shift:
                self.ungroup_selected()
                return
            elif key == Qt.Key.Key_G and not shift:
                self.group_selected()
                return
            elif key == Qt.Key.Key_Z:
                try:
                    if hasattr(self._ps, 'undo'):
                        self._ps.undo()
                        self.set_clip(self._clip_id)
                except Exception:
                    pass
                return

        shift = bool(mods & Qt.KeyboardModifier.ShiftModifier)

        if key == Qt.Key.Key_S and not ctrl:
            self.split_at_playhead()
        elif (key == Qt.Key.Key_Delete or key == Qt.Key.Key_Backspace) and shift:
            # v0.0.20.938: Shift+Del = Ripple Delete
            self.ripple_delete()
        elif key == Qt.Key.Key_Delete or key == Qt.Key.Key_Backspace:
            self.delete_selected_clip()
        elif key == Qt.Key.Key_H:
            # v0.0.20.938: Hand tool
            self.set_tool(TOOL_HAND)
        elif key == Qt.Key.Key_Z and not ctrl:
            # v0.0.20.938: Zoom tool
            self.set_tool(TOOL_ZOOM)
        elif key == Qt.Key.Key_Q:
            # v0.0.20.938: Lasso tool
            self.set_tool(TOOL_LASSO)
        elif key == Qt.Key.Key_G and not ctrl:
            # Toggle ghost clips
            self._ghost_enabled = not self._ghost_enabled
            self._request_paint()
            try:
                self.status_message.emit(
                    f"👻 Ghost-Clips {'AN' if self._ghost_enabled else 'AUS'}")
            except Exception:
                pass
        elif key == Qt.Key.Key_L:
            # v0.0.20.934: Toggle loop
            self._loop_enabled = not self._loop_enabled
            if self._loop_enabled and self._clip:
                # Default: loop around selected clip
                self._loop_start = self._clip_start_beats
                self._loop_end = self._clip_start_beats + self._clip_length_beats
            if self._transport and hasattr(self._transport, 'set_loop'):
                try:
                    self._transport.set_loop(self._loop_enabled, self._loop_start, self._loop_end)
                except Exception:
                    pass
            self._request_paint()
            try:
                self.status_message.emit(
                    f"🔁 Loop {'AN' if self._loop_enabled else 'AUS'}"
                    + (f" ({self._loop_start:.0f}–{self._loop_end:.0f} beats)" if self._loop_enabled else ""))
            except Exception:
                pass
        elif key == Qt.Key.Key_5:
            # Snap: Off
            self._snap_beats = 0
            try: self.status_message.emit("📐 Snap: AUS")
            except: pass
            self._request_paint()
        elif key == Qt.Key.Key_6:
            # Snap: 1 beat
            self._snap_beats = 1.0
            try: self.status_message.emit("📐 Snap: 1 Beat")
            except: pass
            self._request_paint()
        elif key == Qt.Key.Key_7:
            # Snap: 1/2 beat
            self._snap_beats = 0.5
            try: self.status_message.emit("📐 Snap: 1/2 Beat")
            except: pass
            self._request_paint()
        elif key == Qt.Key.Key_8:
            # Snap: 1/4 beat (1/16 note)
            self._snap_beats = 0.25
            try: self.status_message.emit("📐 Snap: 1/4 Beat")
            except: pass
            self._request_paint()
        elif key == Qt.Key.Key_9:
            # Snap: Bar (4 beats)
            self._snap_beats = 4.0
            try: self.status_message.emit("📐 Snap: Bar (4 Beats)")
            except: pass
            self._request_paint()
        elif key == Qt.Key.Key_1:
            self.set_tool(TOOL_SELECT)
        elif key == Qt.Key.Key_2:
            self.set_tool(TOOL_KNIFE)
        elif key == Qt.Key.Key_3:
            self.set_tool(TOOL_TRIM)
        elif key == Qt.Key.Key_4:
            self.set_tool(TOOL_SLIP)
        elif key == Qt.Key.Key_C and not ctrl:
            # VE8: Smart Context tool
            self.set_tool(TOOL_SMART_CONTEXT)
        elif key == Qt.Key.Key_A and not ctrl:
            # VE9: Automation Draw tool
            self.set_tool(TOOL_AUTOMATION)
        elif key == Qt.Key.Key_T and not ctrl:
            # VE8: Timecode entry — jump to timecode
            self._show_timecode_entry()
        elif key == Qt.Key.Key_Plus or key == Qt.Key.Key_Equal:
            self._px_per_beat = min(200, self._px_per_beat * 1.2)
            self._request_paint()
        elif key == Qt.Key.Key_Minus:
            self._px_per_beat = max(10, self._px_per_beat / 1.2)
            self._request_paint()
        elif key == Qt.Key.Key_Home:
            self._scroll_x = 0
            self._request_paint()
        elif key == Qt.Key.Key_End:
            clips = getattr(self, '_all_clips', [])
            if clips:
                last_end = max(
                    float(getattr(c, 'start_beats', 0)) + float(getattr(c, 'length_beats', 0))
                    for c in clips
                )
                self._scroll_x = max(0, last_end - 8)
                self._request_paint()
        elif key == Qt.Key.Key_F:
            self._fit_view()
        elif key == Qt.Key.Key_Left:
            self._select_adjacent_clip(-1)
        elif key == Qt.Key.Key_Right:
            self._select_adjacent_clip(1)
        elif key == Qt.Key.Key_Space:
            if self._transport and hasattr(self._transport, 'toggle'):
                try:
                    self._transport.toggle()
                except Exception:
                    pass
        else:
            super().keyPressEvent(event)

    # ─────────────────────────────────────────────────────
    # VE8: Smart Context Tool
    # ─────────────────────────────────────────────────────

    def _smart_context_dispatch(self, mx: float, my: float,
                                beat: float, event) -> None:
        """VE8: Auto tool switch based on click position.

        - Click on clip edge → Trim
        - Click on clip center → Move (Select)
        - Click on empty area → Selection
        - Click in header → Playhead
        - Click on automation lane → Automation Draw
        """
        # Header area → set playhead
        if my < _HEADER_HEIGHT:
            snapped = self._snap_beat(beat)
            if self._transport and hasattr(self._transport, 'set_position'):
                try:
                    self._transport.set_position(snapped)
                except Exception:
                    pass
            try:
                self.status_message.emit(f"▶ Playhead → Beat {snapped:.1f}")
            except Exception:
                pass
            self._request_paint()
            return

        # Check clip edges for trim
        for clip in getattr(self, '_all_clips', []):
            cs = float(getattr(clip, 'start_beats', 0))
            cl = float(getattr(clip, 'length_beats', 0))
            ce = cs + cl
            x_start = self._beats_to_x(cs)
            x_end = self._beats_to_x(ce)

            # Near left edge → trim start
            if abs(mx - x_start) < 10 and cs <= beat <= ce:
                self._drag_edge = "start"
                self._dragging = True
                try:
                    self.status_message.emit("↔ Smart: Trim Start")
                except Exception:
                    pass
                return

            # Near right edge → trim end
            if abs(mx - x_end) < 10 and cs <= beat <= ce:
                self._drag_edge = "end"
                self._dragging = True
                try:
                    self.status_message.emit("↔ Smart: Trim End")
                except Exception:
                    pass
                return

            # Inside clip → move (select + drag)
            if x_start < mx < x_end:
                selected = self.select_clip_at(beat)
                if selected:
                    self._dragging = True
                    self._drag_start = event.position()
                    self._drag_start_beat = beat
                    try:
                        self.status_message.emit("👆 Smart: Move")
                    except Exception:
                        pass
                    return

        # Empty area → just set playhead
        snapped = self._snap_beat(beat)
        if self._transport and hasattr(self._transport, 'set_position'):
            try:
                self._transport.set_position(snapped)
            except Exception:
                pass
        self._request_paint()

    # ─────────────────────────────────────────────────────
    # VE8: Timecode Entry Dialog
    # ─────────────────────────────────────────────────────

    def _show_timecode_entry(self) -> None:
        """VE8: Show dialog to jump to a specific timecode."""
        try:
            from PyQt6.QtWidgets import QInputDialog
            text, ok = QInputDialog.getText(
                self, "Timecode eingeben",
                "Springe zu Timecode (HH:MM:SS:FF):",
                text="00:00:00:00")
            if ok and text.strip():
                try:
                    from pydaw.services.video_timecode import (
                        parse_timecode, timecode_to_seconds)
                    tc = parse_timecode(text.strip(), self._timecode_fps)
                    if tc:
                        secs = timecode_to_seconds(tc, self._timecode_fps)
                        beat = secs * self._bpm / 60.0
                        if self._transport and hasattr(self._transport, 'set_position'):
                            self._transport.set_position(beat)
                        self._scroll_x = max(0, beat - 4)
                        self._request_paint()
                        try:
                            self.status_message.emit(
                                f"▶ Springe zu {tc} (Beat {beat:.1f})")
                        except Exception:
                            pass
                    else:
                        try:
                            self.status_message.emit(
                                "⚠ Ungültiges Timecode-Format (HH:MM:SS:FF)")
                        except Exception:
                            pass
                except ImportError:
                    pass
        except Exception as e:
            log.debug("[VideoEditor] timecode entry: %s", e)

    # ─────────────────────────────────────────────────────
    # VE9: Automation Draw Tool Handlers
    # ─────────────────────────────────────────────────────

    def _automation_mouse_press(self, mx: float, my: float,
                                beat: float, event) -> None:
        """VE9: Handle click for automation draw tool."""
        store = self._get_automation_store()
        if not store:
            return

        clip_top = _HEADER_HEIGHT
        clip_bottom = self.height() - 20
        auto_height = clip_bottom - clip_top
        if auto_height <= 0:
            return

        # Find which clip the click is in
        target_clip = None
        target_cs = 0.0
        target_cl = 0.0
        for clip in getattr(self, '_all_clips', []):
            cs = float(getattr(clip, 'start_beats', 0))
            cl = float(getattr(clip, 'length_beats', 0))
            x_start = self._beats_to_x(cs)
            x_end = self._beats_to_x(cs + cl)
            if x_start <= mx <= x_end:
                target_clip = clip
                target_cs = cs
                target_cl = cl
                break

        if not target_clip and self._clip:
            target_clip = self._clip
            target_cs = self._clip_start_beats
            target_cl = self._clip_length_beats

        if not target_clip:
            return

        cid = str(getattr(target_clip, 'id', ''))
        auto = store.get_or_create(cid)
        lane_map = {"opacity": auto.opacity, "speed": auto.speed, "volume": auto.volume}
        curve = lane_map.get(self._active_automation_lane, auto.opacity)

        # Calculate relative position and value
        x_start = self._beats_to_x(target_cs)
        x_end = self._beats_to_x(target_cs + target_cl)
        clip_width = x_end - x_start
        if clip_width <= 0:
            return

        rel_pos = ((mx - x_start) / clip_width) * target_cl
        rel_pos = max(0.0, min(target_cl, rel_pos))
        value = 1.0 - (my - clip_top) / auto_height
        value = max(0.0, min(1.0, value))

        # Check if clicking near existing point (drag)
        for idx, pt in enumerate(curve.points):
            pt_x = x_start + (pt.position / target_cl) * clip_width
            pt_y = clip_bottom - pt.value * auto_height
            if abs(mx - pt_x) < 8 and abs(my - pt_y) < 8:
                # Right-click to delete
                if event.button() == Qt.MouseButton.RightButton:
                    curve.remove_point(idx)
                    try:
                        self.status_message.emit(
                            f"🗑 Automation-Punkt gelöscht")
                    except Exception:
                        pass
                    self._request_paint()
                    return
                # Start dragging existing point
                self._automation_drag_point = idx
                self._automation_drag_clip = cid
                self._dragging = True
                return

        # Add new point
        try:
            from pydaw.services.video_automation import InterpolationMode
            curve.add_point(rel_pos, value, InterpolationMode.LINEAR)
        except ImportError:
            curve.add_point(rel_pos, value)

        try:
            self.status_message.emit(
                f"📍 Automation: {self._active_automation_lane} = "
                f"{value:.2f} @ Beat {rel_pos:.1f}")
        except Exception:
            pass
        self._request_paint()

    def _automation_mouse_move(self, mx: float, my: float) -> None:
        """VE9: Drag automation breakpoint."""
        if self._automation_drag_point < 0:
            return

        store = self._get_automation_store()
        if not store:
            return

        cid = self._automation_drag_clip
        auto = store.get(cid)
        if not auto:
            return

        lane_map = {"opacity": auto.opacity, "speed": auto.speed, "volume": auto.volume}
        curve = lane_map.get(self._active_automation_lane, auto.opacity)

        idx = self._automation_drag_point
        if idx >= len(curve.points):
            return

        # Find clip dimensions
        clip_top = _HEADER_HEIGHT
        clip_bottom = self.height() - 20
        auto_height = clip_bottom - clip_top
        if auto_height <= 0:
            return

        target_clip = None
        for clip in getattr(self, '_all_clips', []):
            if str(getattr(clip, 'id', '')) == cid:
                target_clip = clip
                break
        if not target_clip and self._clip and str(getattr(self._clip, 'id', '')) == cid:
            target_clip = self._clip

        if not target_clip:
            return

        cs = float(getattr(target_clip, 'start_beats', 0))
        cl = float(getattr(target_clip, 'length_beats', 0))
        x_start = self._beats_to_x(cs)
        x_end = self._beats_to_x(cs + cl)
        clip_width = x_end - x_start
        if clip_width <= 0:
            return

        new_pos = ((mx - x_start) / clip_width) * cl
        new_pos = max(0.0, min(cl, new_pos))
        new_val = 1.0 - (my - clip_top) / auto_height
        new_val = max(0.0, min(1.0, new_val))

        curve.move_point(idx, new_pos, new_val)
        # Index may have changed after sort, update
        for i, pt in enumerate(curve.points):
            if abs(pt.position - new_pos) < 0.01:
                self._automation_drag_point = i
                break

        self._request_paint()

    # ─────────────────────────────────────────────────────
    # VE10: Transition Helpers
    # ─────────────────────────────────────────────────────

    def add_transition(self, clip_a_id: str, clip_b_id: str,
                       position_beats: float,
                       transition_type: str = "crossfade",
                       duration_beats: float = 2.0) -> None:
        """VE10: Add a transition between two clips."""
        store = self._get_transition_store()
        if not store:
            return
        try:
            from pydaw.services.video_transitions import TransitionType
            tt = TransitionType(transition_type)
        except (ImportError, ValueError):
            return
        tr = store.add(clip_a_id, clip_b_id, position_beats, tt, duration_beats)
        self._request_paint()
        # v0.0.20.948: Send transition to collab
        if tr:
            _video_collab_send_transition(self, tr.to_dict())

    def remove_transition_at(self, beat: float) -> None:
        """VE10: Remove transition at beat position."""
        store = self._get_transition_store()
        if not store:
            return
        tr = store.get_transition_at(beat)
        if tr:
            tr_id = tr.transition_id
            store.remove(tr_id)
            self._request_paint()
            # v0.0.20.948: Send removal to collab
            try:
                vcs = _get_video_collab_from_widget(self)
                if vcs:
                    vcs.send_transition_remove(tr_id)
            except Exception:
                pass

    def _add_transition_at_beat(self, beat: float, transition_type: str) -> None:
        """VE10: Find two adjacent clips near beat and add transition."""
        clips = sorted(
            getattr(self, '_all_clips', []),
            key=lambda c: float(getattr(c, 'start_beats', 0)))
        if len(clips) < 2:
            try:
                self.status_message.emit("⚠ Mindestens 2 Clips nötig")
            except Exception:
                pass
            return

        # Find closest clip boundary to click position
        best_pair = None
        best_dist = float('inf')
        for i in range(len(clips) - 1):
            end_a = float(getattr(clips[i], 'start_beats', 0)) + float(getattr(clips[i], 'length_beats', 0))
            start_b = float(getattr(clips[i + 1], 'start_beats', 0))
            boundary = (end_a + start_b) / 2.0
            dist = abs(beat - boundary)
            if dist < best_dist:
                best_dist = dist
                best_pair = (clips[i], clips[i + 1], boundary)

        if not best_pair:
            return

        clip_a, clip_b, pos = best_pair
        cid_a = str(getattr(clip_a, 'id', ''))
        cid_b = str(getattr(clip_b, 'id', ''))
        self.add_transition(cid_a, cid_b, pos, transition_type, duration_beats=2.0)
        try:
            self.status_message.emit(
                f"✨ {transition_type} zwischen {cid_a[:8]}…→{cid_b[:8]}… (2 beats)")
        except Exception:
            pass

    def _select_adjacent_clip(self, direction: int) -> None:
        """Select the next/previous clip on the track."""
        clips = getattr(self, '_all_clips', [])
        if not clips or not self._clip_id:
            return
        idx = -1
        for i, c in enumerate(clips):
            if str(getattr(c, 'id', '')) == str(self._clip_id):
                idx = i
                break
        if idx < 0:
            return
        new_idx = idx + direction
        if 0 <= new_idx < len(clips):
            new_clip = clips[new_idx]
            cid = str(getattr(new_clip, 'id', ''))
            self._clip_id = cid
            self._clip = new_clip
            self._video_path = str(getattr(new_clip, 'source_path', '') or '')
            self._clip_start_beats = float(getattr(new_clip, 'start_beats', 0))
            self._clip_length_beats = float(getattr(new_clip, 'length_beats', 0))
            # Scroll to selected clip
            self._scroll_x = max(0, self._clip_start_beats - 2)
            self._request_paint()


# ═══════════════════════════════════════════════════════════════
# Video Editor Widget (wraps Canvas + Toolbar)
# ═══════════════════════════════════════════════════════════════

class VideoEditor(QWidget):
    """Complete Video Editor widget with toolbar + canvas.

    Drop-in replacement for PianoRollEditor in EditorTabs.
    """

    status_message = pyqtSignal(str)

    def __init__(self, project_service, transport=None,
                 editor_timeline=None, parent=None):
        super().__init__(parent)
        self._ps = project_service
        self._transport = transport

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # ── Toolbar ──
        toolbar = QHBoxLayout()
        toolbar.setContentsMargins(4, 2, 4, 2)
        toolbar.setSpacing(4)

        lbl = QLabel("🎬 Video-Editor")
        lbl.setStyleSheet("font-weight: bold; color: #e0e0e0; font-size: 12px;")
        toolbar.addWidget(lbl)

        toolbar.addSpacing(8)

        # Tool buttons
        self._tool_btns = {}
        for tool_id, icon, tip in [
            (TOOL_SELECT, "👆", "Auswahl (1)"),
            (TOOL_KNIFE, "✂", "Messer / Split (2)"),
            (TOOL_TRIM, "↔", "Trimmen (3)"),
            (TOOL_SLIP, "⇄", "Slip (4)"),
            (TOOL_LASSO, "☐", "Lasso (Q)"),
            (TOOL_HAND, "✋", "Hand / Pan (H)"),
            (TOOL_ZOOM, "🔍", "Lupe / Zoom (Z)"),
            (TOOL_SMART_CONTEXT, "🎯", "Smart Context (C)"),
            (TOOL_AUTOMATION, "📈", "Automation Draw (A)"),
        ]:
            btn = QToolButton()
            btn.setText(icon)
            btn.setToolTip(tip)
            btn.setCheckable(True)
            btn.setFixedSize(28, 24)
            btn.setStyleSheet(
                "QToolButton { background: #2a2a3a; border: 1px solid #444; "
                "border-radius: 3px; color: #ddd; font-size: 13px; }"
                "QToolButton:checked { background: #3a5a7a; border-color: #6aa; }"
                "QToolButton:hover { background: #3a3a4a; }"
            )
            btn.clicked.connect(lambda checked, t=tool_id: self._on_tool_click(t))
            toolbar.addWidget(btn)
            self._tool_btns[tool_id] = btn

        self._tool_btns[TOOL_SELECT].setChecked(True)

        toolbar.addSpacing(12)

        # Split at playhead button
        btn_split = QPushButton("✂ Split (S)")
        btn_split.setFixedHeight(24)
        btn_split.setStyleSheet(
            "QPushButton { background: #3a2a2a; border: 1px solid #804a4a; "
            "border-radius: 3px; color: #ddd; font-size: 11px; padding: 0 8px; }"
            "QPushButton:hover { background: #4a3a3a; }"
        )
        btn_split.clicked.connect(self._on_split)
        toolbar.addWidget(btn_split)

        toolbar.addSpacing(8)

        # v0.0.20.934: Snap selector
        toolbar.addWidget(QLabel("📐"))
        self._cmb_snap = QComboBox()
        self._cmb_snap.addItems(["Bar", "Beat", "1/2", "1/4", "Off"])
        self._cmb_snap.setCurrentText("Beat")
        self._cmb_snap.setFixedWidth(60)
        self._cmb_snap.setFixedHeight(22)
        self._cmb_snap.setStyleSheet(
            "QComboBox { background: #2a2a3a; color: #ddd; border: 1px solid #444; "
            "border-radius: 3px; font-size: 10px; padding: 0 4px; }"
        )
        self._cmb_snap.currentTextChanged.connect(self._on_snap_changed)
        toolbar.addWidget(self._cmb_snap)

        toolbar.addSpacing(8)

        # v0.0.20.934: Loop toggle
        self._btn_loop = QToolButton()
        self._btn_loop.setText("🔁")
        self._btn_loop.setToolTip("Loop ein/aus (L)")
        self._btn_loop.setCheckable(True)
        self._btn_loop.setFixedSize(28, 24)
        self._btn_loop.setStyleSheet(
            "QToolButton { background: #2a2a3a; border: 1px solid #444; "
            "border-radius: 3px; color: #ddd; font-size: 13px; }"
            "QToolButton:checked { background: #2a4a3a; border-color: #5a8; color: #5d8; }"
        )
        self._btn_loop.clicked.connect(self._on_loop_toggle)
        toolbar.addWidget(self._btn_loop)

        toolbar.addSpacing(8)

        # VE8: FPS selector
        toolbar.addWidget(QLabel("🎬"))
        self._cmb_fps = QComboBox()
        self._cmb_fps.addItems(["23.976", "24", "25", "29.97", "30", "50", "59.94", "60"])
        self._cmb_fps.setCurrentText("24")
        self._cmb_fps.setFixedWidth(55)
        self._cmb_fps.setFixedHeight(22)
        self._cmb_fps.setStyleSheet(
            "QComboBox { background: #2a2a3a; color: #ddd; border: 1px solid #444; "
            "border-radius: 3px; font-size: 10px; padding: 0 4px; }"
        )
        self._cmb_fps.currentTextChanged.connect(self._on_fps_changed)
        toolbar.addWidget(self._cmb_fps)

        # VE8: Drop-Frame toggle
        self._btn_df = QToolButton()
        self._btn_df.setText("DF")
        self._btn_df.setToolTip("Drop-Frame / Non-Drop-Frame")
        self._btn_df.setCheckable(True)
        self._btn_df.setFixedSize(28, 24)
        self._btn_df.setStyleSheet(
            "QToolButton { background: #2a2a3a; border: 1px solid #444; "
            "border-radius: 3px; color: #ddd; font-size: 9px; }"
            "QToolButton:checked { background: #3a4a5a; border-color: #6aa; color: #adf; }"
        )
        self._btn_df.clicked.connect(self._on_df_toggle)
        toolbar.addWidget(self._btn_df)

        # VE8: Timecode entry button
        btn_tc = QPushButton("TC (T)")
        btn_tc.setFixedHeight(24)
        btn_tc.setStyleSheet(
            "QPushButton { background: #2a2a3a; border: 1px solid #444; "
            "border-radius: 3px; color: #4fc3f7; font-size: 10px; padding: 0 6px; }"
            "QPushButton:hover { background: #3a3a4a; }"
        )
        btn_tc.setToolTip("Zu Timecode springen (T)")
        btn_tc.clicked.connect(lambda: self._canvas._show_timecode_entry())
        toolbar.addWidget(btn_tc)

        toolbar.addSpacing(8)

        # VE9: Automation lane selector
        toolbar.addWidget(QLabel("📈"))
        self._cmb_auto_lane = QComboBox()
        self._cmb_auto_lane.addItems(["Opacity", "Speed", "Volume"])
        self._cmb_auto_lane.setCurrentText("Opacity")
        self._cmb_auto_lane.setFixedWidth(65)
        self._cmb_auto_lane.setFixedHeight(22)
        self._cmb_auto_lane.setStyleSheet(
            "QComboBox { background: #2a2a3a; color: #ddd; border: 1px solid #444; "
            "border-radius: 3px; font-size: 10px; padding: 0 4px; }"
        )
        self._cmb_auto_lane.currentTextChanged.connect(self._on_auto_lane_changed)
        toolbar.addWidget(self._cmb_auto_lane)

        # VE9: Automation preset button
        self._btn_auto_preset = QPushButton("Preset")
        self._btn_auto_preset.setFixedHeight(24)
        self._btn_auto_preset.setStyleSheet(
            "QPushButton { background: #2a3a2a; border: 1px solid #4a6a4a; "
            "border-radius: 3px; color: #ddd; font-size: 10px; padding: 0 6px; }"
            "QPushButton:hover { background: #3a4a3a; }"
        )
        self._btn_auto_preset.setToolTip("Automation-Preset anwenden")
        self._btn_auto_preset.clicked.connect(self._on_auto_preset)
        toolbar.addWidget(self._btn_auto_preset)

        toolbar.addStretch(1)

        # SMPTE display
        self._lbl_smpte = QLabel("00:00:00:00")
        self._lbl_smpte.setStyleSheet(
            "font-family: 'Courier New', monospace; font-size: 13px; "
            "font-weight: bold; color: #4fc3f7; background: #0a0a14; "
            "border: 1px solid #333; border-radius: 3px; padding: 2px 6px;"
        )
        toolbar.addWidget(self._lbl_smpte)

        toolbar_w = QWidget()
        toolbar_w.setLayout(toolbar)
        toolbar_w.setFixedHeight(32)
        toolbar_w.setStyleSheet("background: #1e1e2e; border-bottom: 1px solid #333;")
        lay.addWidget(toolbar_w)

        # ── Canvas ──
        self._canvas = VideoEditorCanvas(project_service, transport=transport,
                                          parent=self)
        self._canvas.status_message.connect(self.status_message)
        self._canvas.clip_split.connect(self._do_split)
        self._canvas.clip_deleted.connect(self._do_delete)

        # VE11: Text editor panel (Whisper transcription)
        self._text_editor = None
        try:
            from pydaw.ui.video_text_editor import VideoTextEditorPanel
            self._text_editor = VideoTextEditorPanel(
                project_service=project_service,
                transport=transport, parent=self)
            self._text_editor.word_clicked.connect(self._on_text_seek)
            self._text_editor.words_changed.connect(self._on_words_changed)
            self._text_editor.word_markers_ready.connect(
                self._on_word_markers)
        except Exception as exc:
            log.debug("Text editor init: %s", exc)
            self._text_editor = None

        if self._text_editor:
            from PyQt6.QtWidgets import QSplitter
            splitter = QSplitter(Qt.Orientation.Horizontal)
            splitter.addWidget(self._canvas)
            splitter.addWidget(self._text_editor)
            splitter.setStretchFactor(0, 3)  # Canvas gets 75%
            splitter.setStretchFactor(1, 1)  # Text editor gets 25%
            splitter.setHandleWidth(3)
            splitter.setStyleSheet(
                "QSplitter::handle { background: #333; }")
            lay.addWidget(splitter, 1)
        else:
            lay.addWidget(self._canvas, 1)

        # SMPTE update timer
        self._smpte_timer = QTimer(self)
        self._smpte_timer.setInterval(100)
        self._smpte_timer.timeout.connect(self._update_smpte)
        self._smpte_timer.start()

    def set_clip(self, clip_id: Optional[str]) -> None:
        """Load a video clip for editing."""
        # Only handle video clips
        if clip_id:
            try:
                proj = None
                ps = self._ps
                proj = getattr(ps, 'project', None)
                if proj is None:
                    ctx = getattr(ps, 'ctx', None)
                    proj = getattr(ctx, 'project', None) if ctx else None
                if proj:
                    for c in proj.clips or []:
                        if str(getattr(c, 'id', '')) == str(clip_id):
                            if str(getattr(c, 'kind', '')) != 'video':
                                return  # Not a video clip — ignore
                            break
            except Exception:
                pass

        self._canvas.set_clip(clip_id)

        # VE11: Update text editor with video path
        if self._text_editor and clip_id:
            try:
                video_path = self._canvas._video_path
                if video_path:
                    self._text_editor.set_video_path(video_path)
            except Exception:
                pass

        # Try to get scene markers from VideoConnector
        try:
            from pydaw.services.video_connector import VideoConnector
            vc = VideoConnector.instance()
            vki = getattr(vc, '_video_ki_panel', None)
            if vki:
                vki_svc = getattr(vki, '_vki', None)
                if vki_svc and hasattr(vki_svc, 'scenes'):
                    bpm = self._canvas._bpm
                    markers = []
                    for scene in vki_svc.scenes:
                        beat = scene.start_seconds * bpm / 60.0
                        r, g, b = scene.dominant_color
                        markers.append({
                            "beat": beat,
                            "color": f"#{r:02x}{g:02x}{b:02x}",
                            "label": f"Szene {scene.index + 1}",
                        })
                    self._canvas.set_scene_markers(markers)
        except Exception:
            pass

    def _on_snap_changed(self, text: str) -> None:
        """v0.0.20.934: Snap resolution changed from combo."""
        snap_map = {"Bar": 4.0, "Beat": 1.0, "1/2": 0.5, "1/4": 0.25, "Off": 0}
        self._canvas._snap_beats = snap_map.get(text, 1.0)
        self._canvas._grid_subdivisions = (text in ("1/2", "1/4"))
        self._canvas._request_paint()

    # ── VE11: Text editor handlers ──

    def _on_text_seek(self, seconds: float) -> None:
        """Seek playhead to timestamp from text editor word click."""
        try:
            bpm = self._canvas._get_bpm()
            beat = seconds * bpm / 60.0 if bpm > 0 else 0
            if self._transport:
                if hasattr(self._transport, 'set_position_beats'):
                    self._transport.set_position_beats(beat)
                elif hasattr(self._transport, 'seek_beat'):
                    self._transport.seek_beat(beat)
            self._canvas._playhead_beat = beat
            self._canvas._request_paint()
        except Exception as exc:
            log.debug("Text seek: %s", exc)

    def _on_words_changed(self) -> None:
        """Handle word deletion/restoration from text editor."""
        self._canvas._request_paint()

    def _on_word_markers(self, markers: list) -> None:
        """Receive word boundary markers from text editor."""
        self._canvas._word_markers = markers
        self._canvas._request_paint()

    def _on_loop_toggle(self, checked: bool) -> None:
        """v0.0.20.934: Loop button toggled."""
        self._canvas._loop_enabled = checked
        if checked and self._canvas._clip:
            self._canvas._loop_start = self._canvas._clip_start_beats
            self._canvas._loop_end = self._canvas._clip_start_beats + self._canvas._clip_length_beats
        transport = self._transport
        if transport and hasattr(transport, 'set_loop'):
            try:
                transport.set_loop(checked, self._canvas._loop_start, self._canvas._loop_end)
            except Exception:
                pass
        self._canvas._request_paint()

    def _on_tool_click(self, tool: str) -> None:
        for t, btn in self._tool_btns.items():
            btn.setChecked(t == tool)
        self._canvas.set_tool(tool)

    def _on_split(self) -> None:
        self._canvas.split_at_playhead()

    def _do_split(self, clip_id: str, beat: float) -> None:
        """Perform the actual clip split in the project model.

        v0.0.20.931: After split, refreshes multi-clip view to show both parts.
        """
        try:
            ps = self._ps
            proj = getattr(ps, 'project', None)
            if proj is None:
                ctx = getattr(ps, 'ctx', None)
                proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                return

            # Find clip
            src = None
            for c in proj.clips:
                if str(getattr(c, 'id', '')) == str(clip_id):
                    src = c
                    break
            if not src:
                return

            cs = float(getattr(src, 'start_beats', 0))
            cl = float(getattr(src, 'length_beats', 0))
            ce = cs + cl
            if beat <= cs or beat >= ce:
                return

            from pydaw.model.project import Clip

            # Shorten original clip
            src.length_beats = beat - cs

            # Create new clip after split point
            new_clip = Clip(
                kind="video",
                track_id=str(getattr(src, 'track_id', '')),
                label=str(getattr(src, 'label', '')) + " (B)",
                source_path=str(getattr(src, 'source_path', '')),
                start_beats=beat,
                length_beats=ce - beat,
                offset_seconds=float(getattr(src, 'offset_seconds', 0) or 0)
                    + (beat - cs) * 60.0 / max(1, self._canvas._bpm),
            )
            proj.clips.append(new_clip)

            # Emit changes → Arranger refreshes
            if hasattr(ps, '_emit_updated'):
                ps._emit_updated()
            elif hasattr(ps, '_emit_changed'):
                ps._emit_changed()

            # Refresh multi-clip view — shows both parts now
            self._canvas.set_clip(str(clip_id))

            # v0.0.20.946: Send to collab
            self._send_video_clip_split(str(clip_id), beat)

        except Exception as e:
            log.error("[VideoEditor] split: %s", e, exc_info=True)

    def _do_delete(self, clip_id: str) -> None:
        """Delete a video clip from the project."""
        try:
            ps = self._ps
            proj = getattr(ps, 'project', None)
            if proj is None:
                ctx = getattr(ps, 'ctx', None)
                proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                return

            # Remove the clip
            proj.clips = [c for c in proj.clips
                          if str(getattr(c, 'id', '')) != str(clip_id)]

            # Emit changes → Arranger refreshes
            if hasattr(ps, '_emit_updated'):
                ps._emit_updated()
            elif hasattr(ps, '_emit_changed'):
                ps._emit_changed()

            # Try to select an adjacent clip
            remaining = [c for c in proj.clips
                         if str(getattr(c, 'kind', '')) == 'video']
            if remaining:
                self._canvas.set_clip(str(getattr(remaining[0], 'id', '')))
            else:
                self._canvas.set_clip(None)

            # v0.0.20.946: Send to collab
            self._send_video_clip_delete(str(clip_id))

        except Exception as e:
            log.error("[VideoEditor] delete: %s", e, exc_info=True)

    def _update_smpte(self) -> None:
        """VE8: Professional SMPTE display with DF/NDF support."""
        try:
            if not self._transport:
                return
            beat = float(getattr(self._transport, 'current_beat', 0.0))
            bpm = float(getattr(self._transport, 'bpm', 120.0) or 120.0)
            fps = self._canvas._timecode_fps
            df = self._canvas._timecode_drop_frame

            try:
                from pydaw.services.video_timecode import beats_to_timecode
                tc = beats_to_timecode(beat, bpm, fps=fps, drop_frame=df)
                self._lbl_smpte.setText(str(tc))
            except ImportError:
                secs = beat * 60.0 / max(1, bpm)
                h = int(secs) // 3600
                m = (int(secs) % 3600) // 60
                s = int(secs) % 60
                f = int((secs - int(secs)) * fps)
                sep = ";" if df else ":"
                self._lbl_smpte.setText(f"{h:02d}:{m:02d}:{s:02d}{sep}{f:02d}")
        except Exception:
            pass

    # ── VE8: Timecode Controls ──

    def _on_fps_changed(self, text: str) -> None:
        """VE8: Frame rate changed."""
        try:
            fps = float(text)
            self._canvas._timecode_fps = fps
            # Auto-enable DF for 29.97/59.94
            if fps in (29.97, 59.94):
                self._btn_df.setChecked(True)
                self._canvas._timecode_drop_frame = True
            self._canvas._request_paint()
        except ValueError:
            pass

    def _on_df_toggle(self, checked: bool) -> None:
        """VE8: Drop-Frame toggle."""
        self._canvas._timecode_drop_frame = checked
        self._canvas._request_paint()

    # ── VE9: Automation Controls ──

    def _on_auto_lane_changed(self, text: str) -> None:
        """VE9: Automation lane changed."""
        lane_map = {"Opacity": "opacity", "Speed": "speed", "Volume": "volume"}
        self._canvas._active_automation_lane = lane_map.get(text, "opacity")
        self._canvas._request_paint()

    def _on_auto_preset(self) -> None:
        """VE9: Show automation preset menu."""
        try:
            from PyQt6.QtWidgets import QMenu
            from PyQt6.QtGui import QAction

            menu = QMenu(self)
            menu.setStyleSheet(
                "QMenu { background: #2a2a3a; color: #ddd; border: 1px solid #555; }"
                "QMenu::item:selected { background: #3a5a7a; }"
            )

            for preset_name, label in [
                ("fade_in", "🔺 Fade In"),
                ("fade_out", "🔻 Fade Out"),
                ("s_curve", "〰 S-Curve"),
                ("bell", "🔔 Bell / Hump"),
            ]:
                action = menu.addAction(label)
                action.triggered.connect(
                    lambda checked, pn=preset_name: self._apply_auto_preset(pn))

            menu.addSeparator()
            action_clear = menu.addAction("🗑 Alle Punkte löschen")
            action_clear.triggered.connect(self._clear_automation)

            menu.exec(self._btn_auto_preset.mapToGlobal(
                self._btn_auto_preset.rect().bottomLeft()))
        except Exception as e:
            log.debug("[VideoEditor] auto preset menu: %s", e)

    def _apply_auto_preset(self, preset_name: str) -> None:
        """VE9: Apply automation preset to current clip."""
        store = self._canvas._get_automation_store()
        if not store or not self._canvas._clip_id:
            return
        cid = str(self._canvas._clip_id)
        cl = self._canvas._clip_length_beats
        auto = store.get_or_create(cid)
        auto.apply_preset(preset_name, cl)
        self._canvas._request_paint()
        # v0.0.20.948: Send automation to collab
        _video_collab_send_automation(self, cid, auto.to_dict())
        try:
            self._canvas.status_message.emit(f"📈 Preset: {preset_name}")
        except Exception:
            pass

    def _clear_automation(self) -> None:
        """VE9: Clear all automation for current clip."""
        store = self._canvas._get_automation_store()
        if not store or not self._canvas._clip_id:
            return
        cid = str(self._canvas._clip_id)
        auto = store.get(cid)
        if auto:
            lane_map = {"opacity": auto.opacity, "speed": auto.speed, "volume": auto.volume}
            curve = lane_map.get(self._canvas._active_automation_lane, auto.opacity)
            curve.clear()
            self._canvas._request_paint()
            try:
                self._canvas.status_message.emit("🗑 Automation gelöscht")
            except Exception:
                pass

    # ── v0.0.20.946: Video Collab Integration ──

    def _get_video_collab(self):
        """Get VideoCollabService from Collab panel (safe)."""
        try:
            main_win = self.window()
            if not main_win:
                return None
            cp = getattr(main_win, '_collab_panel', None)
            if cp is None:
                cp = getattr(main_win, 'collab_panel', None)
            if cp:
                return getattr(cp, '_video_collab', None)
        except Exception:
            pass
        return None

    def _send_video_clip_move(self, clip_id: str, start_beats: float,
                               track_id: str = "") -> None:
        """Send video clip move to collab."""
        vcs = self._get_video_collab()
        if vcs:
            vcs.send_clip_move(clip_id, start_beats, track_id)

    def _send_video_clip_split(self, clip_id: str, beat: float) -> None:
        """Send video clip split to collab."""
        vcs = self._get_video_collab()
        if vcs:
            vcs.send_clip_split(clip_id, beat)

    def _send_video_clip_delete(self, clip_id: str) -> None:
        """Send video clip delete to collab."""
        vcs = self._get_video_collab()
        if vcs:
            vcs.send_clip_delete(clip_id)

    def _send_video_clip_props(self, clip_id: str, props: dict) -> None:
        """Send video clip properties to collab."""
        vcs = self._get_video_collab()
        if vcs:
            vcs.send_clip_props(clip_id, props)

    def _send_video_filter(self, clip_id: str, chain: dict) -> None:
        """Send video filter chain to collab."""
        vcs = self._get_video_collab()
        if vcs:
            vcs.send_filter_sync(clip_id, chain)
