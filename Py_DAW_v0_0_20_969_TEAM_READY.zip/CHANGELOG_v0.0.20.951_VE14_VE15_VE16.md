# CHANGELOG v0.0.20.951 — VE14-VE18 GPU + Multi-Cam + Export + Immersive + Cloud

**Datum:** 2026-04-02
**Autor:** Claude Opus 4.6
**Arbeitspaket:** VIDEO_EDITOR_ROADMAP VE14, VE15, VE16, VE17, VE18

## Was wurde gemacht

### VE14: GPU Video Decode
- GPUDecodeService (Singleton): Auto-Detect VAAPI/NVDEC/Vulkan/CUDA/QSV
- Backend-Priorität: NVDEC (90) > VAAPI (80) > Vulkan (60)
- Hardware-beschleunigte Filter: blur, color_grade, tonemap, transpose, denoise, deinterlace
- GPU Scale-Filter pro Backend (scale_vaapi, scale_cuda, scale_vulkan)
- Preview-Pipeline Builder + Software-Fallback

### VE15: Multi-Cam Sync
- MultiCamService: Quellen-Management mit Sync-Offsets
- Audio-Waveform Cross-Correlation (8kHz Mono, coarse→refine Suche)
- Clap/Transient Detection mit Peak-Analyse
- Timecode-basierter Sync (SMPTE)
- Camera Switch Points + Edit-List Generator

### VE16: AAF/XML/OMF/EDL Export
- EDL Export: CMX 3600 mit Speed-Effekten und Transitions
- FCP XML: XMEML v5 mit Opacity, Speed, Transitions, Timecode
- AAF/OMF Manifest Export (JSON, für pyaaf2 Konvertierung)
- build_export_project(): Automatische Extraktion aus DAW-State

### VE17: Immersives Audio
- ImmersiveAudioService: Object-basiertes Spatial Audio
- 9 Spatial-Formate: Stereo bis 9.1.6, FOA/HOA, Binaural
- SpatialPosition (kartesisch + sphärisch) mit Automation
- FOA Ambisonics Encoder (ACN/SN3D Normalisierung)
- Binaural Rendering (HRTF-Panning Approximation)
- Dolby Atmos Metadata Generator

### VE18: Cloud-Collaboration (Video)
- VideoCloudService: Session + Participant Management
- ReviewComment: 4 Priority-Levels, Replies, Resolved-State
- Proxy-Video Generator: 360p/480p/720p/1080p
- ProjectVersion: Snapshot-basiertes Version Control
- CloudMessageType: 11 WebSocket Message-Typen

## 🎬 VIDEO_EDITOR_ROADMAP KOMPLETT — VE1–VE18 ✅

## Neue Dateien
| Datei | LOC | Inhalt |
|-------|-----|--------|
| pydaw/services/video_gpu_decode.py | 380 | GPU Decode + HW Filter |
| pydaw/services/video_multicam.py | 440 | Multi-Cam Sync + Switch |
| pydaw/services/video_interchange_export.py | 420 | EDL/XML/AAF/OMF Export |
| pydaw/services/video_immersive_audio.py | 370 | Dolby Atmos / Ambisonics |
| pydaw/services/video_cloud_collab.py | 380 | Cloud Collab + Review |

## Stats
444/444 kompilieren | 0 Fehler | Nichts kaputt
