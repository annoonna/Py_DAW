v0.0.20.96

- Hotfix: ArrangerCanvas startet wieder korrekt (Init-Regression behoben).
  - _gl_overlay wird wieder im __init__ gesetzt (Crash beim Start behoben: AttributeError '_gl_overlay').
  - Weitere Basis-States (playhead/loop/selection/peaks-cache) werden wieder korrekt initialisiert.
- Keine Engine-Änderungen (rein UI/Init-Fix).
