# -*- coding: utf-8 -*-
"""Audio FX Chain (serielle Effekte + Container mit Mix/WetGain).

Engine-first MVP:
- JSON-safe chain spec lives in Track.audio_fx_chain
- HybridAudioCallback applies per-track chain BEFORE volume/pan and BEFORE peaks.
- Also applies to Pull Sources (Sampler/Drum live audio).

Spec (Track.audio_fx_chain):
{
  "type": "chain",
  "mix": 1.0,          # 0..1
  "wet_gain": 1.0,     # linear
  "devices": [
     {"plugin_id":"chrono.fx.gain","id":"afx_xxx","enabled":true,"params":{"gain":1.0}},
     ...
  ]
}

Notes:
- Real-time safety: no allocations in the audio callback.
- All scratch buffers are preallocated.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

try:
    import numpy as np  # type: ignore
except Exception:  # pragma: no cover
    np = None  # type: ignore


def _clamp01(x: float) -> float:
    try:
        x = float(x)
    except Exception:
        return 0.0
    if x < 0.0:
        return 0.0
    if x > 1.0:
        return 1.0
    return x


def _rt_get_smooth(rt, key: str, default: float = 0.0) -> float:
    """Read a realtime parameter value in a version-tolerant way."""
    try:
        if rt is None:
            return float(default)
        if hasattr(rt, "get_smooth"):
            return float(rt.get_smooth(key, default))
        if hasattr(rt, "get_param"):
            return float(rt.get_param(key, default))
        if hasattr(rt, "get_target"):
            return float(rt.get_target(key, default))
    except Exception:
        pass
    return float(default)


def _gain_from_params(params: dict, default: float = 1.0) -> float:
    """Return linear gain from a device params dict (supports gain_db)."""
    try:
        if not isinstance(params, dict):
            return float(default)
        if "gain" in params:
            return float(params.get("gain", default) or default)
        if "gain_db" in params:
            db = float(params.get("gain_db", 0.0) or 0.0)
            db = max(-120.0, min(24.0, db))
            return float(10.0 ** (db / 20.0))
    except Exception:
        pass
    return float(default)


class AudioFxBase:

    """Base class for audio FX (in-place)."""

    def process_inplace(self, buf, frames: int, sr: int) -> None:  # noqa: ANN001
        raise NotImplementedError


@dataclass
class GainFx(AudioFxBase):
    """Simple linear gain effect (no dB conversion in RT)."""

    gain_key: str
    rt_params: Any

    def process_inplace(self, buf, frames: int, sr: int) -> None:  # noqa: ANN001
        if np is None:
            return
        try:
            g = float(_rt_get_smooth(self.rt_params, self.gain_key, 1.0))
        except Exception:
            g = 1.0
        if g == 1.0:
            return
        try:
            # buf shape: (frames, 2)
            np.multiply(buf[:frames, :], g, out=buf[:frames, :])
        except Exception:
            return




@dataclass
class DistortionFx(AudioFxBase):
    """Simple waveshaper distortion (tanh) with drive + mix.

    drive: 0..1  (0 = none)
    mix:   0..1
    """

    drive_key: str
    mix_key: str
    rt_params: Any

    def process_inplace(self, buf, frames: int, sr: int) -> None:  # noqa: ANN001
        if np is None:
            return
        try:
            drive = float(_rt_get_smooth(self.rt_params, self.drive_key, 0.25))
        except Exception:
            drive = 0.25
        try:
            mix = _clamp01(float(_rt_get_smooth(self.rt_params, self.mix_key, 1.0)))
        except Exception:
            mix = 1.0
        if drive <= 0.0001 or mix <= 0.0001:
            return
        try:
            # pre-emphasis gain
            k = 1.0 + 20.0 * max(0.0, min(1.0, drive))
            wet = np.tanh(buf[:frames, :] * k)
            if mix >= 0.999:
                np.copyto(buf[:frames, :], wet)
            else:
                dry_scale = (1.0 - mix)
                np.multiply(buf[:frames, :], dry_scale, out=buf[:frames, :])
                np.add(buf[:frames, :], wet * mix, out=buf[:frames, :])
        except Exception:
            return
class ChainFx:
    """Container that runs devices in series on wet buffer and blends with dry."""

    def __init__(self, track_id: str, chain_spec: Any, rt_params: Any, max_frames: int = 8192):
        self.track_id = str(track_id or "")
        self.rt_params = rt_params
        self.devices: List[AudioFxBase] = []
        self.enabled: bool = True

        # track-level container keys (optional live automation later)
        self.mix_key = f"afxchain:{self.track_id}:mix"
        self.wet_gain_key = f"afxchain:{self.track_id}:wet_gain"

        # defaults from spec
        mix = 1.0
        wet_gain = 1.0
        devices_spec = []
        if isinstance(chain_spec, dict):
            self.enabled = bool(chain_spec.get("enabled", True))
            mix = float(chain_spec.get("mix", 1.0) or 1.0)
            wet_gain = float(chain_spec.get("wet_gain", 1.0) or 1.0)
            devices_spec = chain_spec.get("devices", []) or []
        elif isinstance(chain_spec, list):
            devices_spec = chain_spec

        # ensure RT defaults exist
        try:
            if hasattr(rt_params, "ensure"):
                rt_params.ensure(self.mix_key, float(mix))
                rt_params.ensure(self.wet_gain_key, float(wet_gain))
        except Exception:
            pass

        # preallocate wet buffer
        self._wet = None
        if np is not None:
            try:
                self._wet = np.zeros((int(max_frames), 2), dtype=np.float32)
            except Exception:
                self._wet = None

        # compile devices
        self._compile_devices(devices_spec)

    def _compile_devices(self, devices_spec: Any) -> None:
        self.devices = []
        if not isinstance(devices_spec, list):
            return
        for dev in devices_spec:
            if not isinstance(dev, dict):
                continue
            if dev.get("enabled", True) is False:
                continue
            pid = str(dev.get("plugin_id") or dev.get("type") or "")
            did = str(dev.get("id") or dev.get("device_id") or "")
            params = dev.get("params", {}) if isinstance(dev.get("params", {}), dict) else {}
            if pid in ("chrono.fx.gain", "gain", "GainFx"):
                # store linear gain in RT store
                gain_key = f"afx:{self.track_id}:{did}:gain"
                default_gain = _gain_from_params(params, 1.0)
                try:
                    if hasattr(self.rt_params, "ensure"):
                        self.rt_params.ensure(gain_key, default_gain)
                except Exception:
                    pass
                self.devices.append(GainFx(gain_key=gain_key, rt_params=self.rt_params))
            elif pid in ("chrono.fx.distortion", "distortion", "DistortionFx"):
                drive_key = f"afx:{self.track_id}:{did}:drive"
                mix_key = f"afx:{self.track_id}:{did}:mix"
                # defaults from params
                drive = float(params.get("drive", 0.25) or 0.25)
                mix = float(params.get("mix", 1.0) or 1.0)
                try:
                    if hasattr(self.rt_params, "ensure"):
                        self.rt_params.ensure(drive_key, drive)
                        self.rt_params.ensure(mix_key, mix)
                except Exception:
                    pass
                self.devices.append(DistortionFx(drive_key=drive_key, mix_key=mix_key, rt_params=self.rt_params))
            else:
                continue

    def process_inplace(self, buf, frames: int, sr: int) -> None:  # noqa: ANN001
        if np is None:
            return
        if not self.enabled:
            return
        if not self.devices:
            return
        if self._wet is None:
            return

        frames = int(frames)
        if frames <= 0:
            return
        if frames > self._wet.shape[0]:
            frames = self._wet.shape[0]

        # Read container params
        try:
            mix = _clamp01(float(_rt_get_smooth(self.rt_params, self.mix_key, 1.0)))
        except Exception:
            mix = 1.0
        try:
            wet_gain = float(_rt_get_smooth(self.rt_params, self.wet_gain_key, 1.0))
        except Exception:
            wet_gain = 1.0

        # Wet path (process on copy)
        wet = self._wet
        try:
            np.copyto(wet[:frames, :], buf[:frames, :])
        except Exception:
            return
        for fx in self.devices:
            try:
                fx.process_inplace(wet, frames, sr)
            except Exception:
                continue
        if wet_gain != 1.0:
            try:
                np.multiply(wet[:frames, :], wet_gain, out=wet[:frames, :])
            except Exception:
                pass

        # Blend back to buf
        if mix >= 0.999:
            try:
                np.copyto(buf[:frames, :], wet[:frames, :])
            except Exception:
                pass
            return

        if mix <= 0.001:
            # keep dry (buf already dry)
            return

        try:
            # buf = dry*(1-mix) + wet*mix
            dry_scale = (1.0 - mix)
            np.multiply(buf[:frames, :], dry_scale, out=buf[:frames, :])
            np.add(buf[:frames, :], wet[:frames, :] * mix, out=buf[:frames, :])
        except Exception:
            return



def ensure_track_fx_params(project: Any, rt_params: Any) -> None:
    """Ensure RTParamStore keys exist for all Audio-FX chains.

    This is called from the GUI thread when a project snapshot changes,
    BEFORE compiled ChainFx objects are pushed to the audio thread.

    Keys (current MVP):
    - afxchain:{track_id}:mix
    - afxchain:{track_id}:wet_gain
    - afx:{track_id}:{device_id}:gain  (for chrono.fx.gain)
    """
    if rt_params is None:
        return
    try:
        tracks = getattr(project, "tracks", []) or []
    except Exception:
        tracks = []
    for t in tracks:
        try:
            tid = str(getattr(t, "id", ""))
        except Exception:
            tid = ""
        if not tid:
            continue
        chain = getattr(t, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            continue
        mix = float(chain.get("mix", 1.0) or 1.0)
        wet_gain = float(chain.get("wet_gain", 1.0) or 1.0)
        try:
            if hasattr(rt_params, "ensure"):
                rt_params.ensure(f"afxchain:{tid}:mix", mix)
                rt_params.ensure(f"afxchain:{tid}:wet_gain", wet_gain)
        except Exception:
            pass

        devices = chain.get("devices", []) or []
        if not isinstance(devices, list):
            continue
        for dev in devices:
            if not isinstance(dev, dict):
                continue
            pid = str(dev.get("plugin_id") or dev.get("type") or "")
            did = str(dev.get("id") or dev.get("device_id") or "")
            params = dev.get("params", {}) if isinstance(dev.get("params", {}), dict) else {}
            if not did:
                continue
            if pid in ("chrono.fx.gain", "gain", "GainFx"):
                default_gain = _gain_from_params(params, 1.0)
                try:
                    if hasattr(rt_params, "ensure"):
                        rt_params.ensure(f"afx:{tid}:{did}:gain", default_gain)
                except Exception:
                    pass


def build_track_fx_map(project: Any, rt_params: Any, max_frames: int = 8192) -> Dict[str, Optional[ChainFx]]:
    """Compile per-track ChainFx objects from a Project snapshot."""
    fx_map: Dict[str, Optional[ChainFx]] = {}
    try:
        tracks = getattr(project, "tracks", []) or []
    except Exception:
        tracks = []
    for t in tracks:
        try:
            tid = str(getattr(t, "id", ""))
        except Exception:
            tid = ""
        if not tid:
            continue
        chain = getattr(t, "audio_fx_chain", None)
        try:
            fx_map[tid] = ChainFx(track_id=tid, chain_spec=chain, rt_params=rt_params, max_frames=int(max_frames))
        except Exception:
            fx_map[tid] = None
    return fx_map