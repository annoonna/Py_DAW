# Audio Plugins auf macOS (LV2, LADSPA, DSSI, VST)

Diese Anleitung beschreibt **Pfade**, **Installationsmethoden** und eine **Homebrew-Einrichtung** für Plugin-Formate auf macOS.

> Hinweis: macOS kennt systemseitig vor allem **AU/VST/VST3**. Formate wie **LV2/LADSPA/DSSI** sind „Linux-native“ und werden auf macOS meist über Homebrew + kompatible Hosts genutzt.

## 1) Standard-Verzeichnisse (manuelle Installation)

Kopiere Plugin-Ordner oder Dateien in die folgenden Verzeichnisse. Falls ein Ordner nicht existiert, erstelle ihn manuell.

| Format | Endung | Systemweiter Pfad (für alle Nutzer) | Benutzer-Pfad (nur für dich) |
| :--- | :--- | :--- | :--- |
| **LV2** | `.lv2` | `/Library/Audio/Plug-Ins/LV2` | `~/Library/Audio/Plug-Ins/LV2` |
| **VST3** | `.vst3` | `/Library/Audio/Plug-Ins/VST3` | `~/Library/Audio/Plug-Ins/VST3` |
| **VST2** | `.vst` | `/Library/Audio/Plug-Ins/VST` | `~/Library/Audio/Plug-Ins/VST` |
| **LADSPA** | `.so`/`.dylib` | `/Library/Audio/Plug-Ins/LADSPA` | `~/.ladspa` |
| **DSSI** | `.so` | `/Library/Audio/Plug-Ins/DSSI` | `~/.dssi` |

---

## 2) Installation via Homebrew (`brew`)

### Homebrew installieren

Falls noch nicht vorhanden:

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

### Basis-SDKs & Support

```bash
brew install portaudio
brew install libsndfile
brew install fluidsynth

# LV2/LADSPA Tooling (optional, für LV2 Hosting/GUI):
brew install lv2
brew install lilv
brew install suil
brew install ladspa-sdk

# Plugin-Beispiele:
brew install mda-lv2
```

> Tipp: Auf Apple Silicon liegen Brew-Pfade unter `/opt/homebrew`, auf Intel-Macs unter `/usr/local`.

---

## 3) Umgebungsvariablen setzen (wichtig für Hosts/Scanner)

Damit Hosts die Plugins zuverlässig finden, kannst du in `~/.zshrc` ergänzen:

```bash
# LV2 Pfade
export LV2_PATH="$LV2_PATH:/usr/local/lib/lv2:/opt/homebrew/lib/lv2:$HOME/Library/Audio/Plug-Ins/LV2"

# LADSPA Pfade
export LADSPA_PATH="$LADSPA_PATH:/usr/local/lib/ladspa:/opt/homebrew/lib/ladspa:/Library/Audio/Plug-Ins/LADSPA:$HOME/.ladspa"
```

Aktivieren:

```bash
source ~/.zshrc
```

---

## 4) Problembehandlung (Gatekeeper)

macOS blockiert häufig Plugins, die nicht notarisiert sind.

1. Plugin kopieren/installieren
2. Host/DAW starten (Plugin-Scan kann fehlschlagen)
3. **Systemeinstellungen → Datenschutz & Sicherheit** öffnen
4. Unten bei „Sicherheit“ **„Dennoch öffnen“** für das Plugin/den Host bestätigen
5. Host neu starten / Plugin-Scan wiederholen

---

## 5) Nützliche Befehle (Terminal)

### ChronoScaleStudio Cache löschen (LV2 Probe Cache)

```bash
rm -f ~/.cache/ChronoScaleStudio/lv2_probe_cache.json
```

### Homebrew-LV2 Plugins in den User-Ordner symlinken

```bash
mkdir -p ~/Library/Audio/Plug-Ins/LV2
ln -s "$(brew --prefix)/lib/lv2"/* ~/Library/Audio/Plug-Ins/LV2/ 2>/dev/null || true
```

---

## 6) Optional: Wrapper / Adapter (VST↔AU)

Wenn du mir sagst, welches Ziel du hast (z. B. **VST2/VST3 → AU** oder **LV2 → AU/VST Host**), kann ich dir die passenden, möglichst stabilen Optionen zusammenstellen.
