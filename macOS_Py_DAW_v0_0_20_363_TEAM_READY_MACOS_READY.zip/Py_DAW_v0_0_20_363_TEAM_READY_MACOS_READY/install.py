"""Installer helper for Py_DAW.

Usage:
    python3 install.py

It will:
- warn if you're not inside a virtual environment
- install/upgrade pip
- install requirements.txt

Note:
- JACK/PipeWire system components are not installed here (distro packages).
"""

from __future__ import annotations

import os
import sys
import subprocess
from pathlib import Path


def _which(cmd: str) -> str | None:
    """Return full path if a command exists on PATH."""
    for p in os.environ.get("PATH", "").split(os.pathsep):
        cand = Path(p) / cmd
        if cand.exists() and os.access(cand, os.X_OK):
            return str(cand)
    return None


def _is_debian_like() -> bool:
    """Best-effort detection for Debian/Ubuntu/Kali family."""
    if sys.platform != "linux":
        return False
    try:
        txt = Path("/etc/os-release").read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return False
    low = txt.lower()
    return ("id_like=" in low and "debian" in low) or ("id=" in low and any(k in low for k in ("kali", "debian", "ubuntu", "linuxmint")))


def _dpkg_installed(pkg: str) -> bool:
    try:
        out = subprocess.check_output(["dpkg-query", "-W", "-f=${Status}", pkg], stderr=subprocess.DEVNULL)
        return b"install ok installed" in out
    except Exception:
        return False


def _maybe_install_lv2_deps() -> None:
    """Optional system deps for LV2 hosting (safe/best-effort).

    On Debian/Kali, the LV2 python binding + utilities are typically provided
    by distro packages:
        - python3-lilv
        - lilv-utils

    This step must NEVER abort the installer.
    """

    if not _is_debian_like():
        return
    if not _which("apt-get"):
        return

    pkgs = ["python3-lilv", "lilv-utils"]
    missing = [p for p in pkgs if not _dpkg_installed(p)]
    if not missing:
        return

    print("\n[LV2] Systempakete fehlen:", ", ".join(missing))
    print("[LV2] Versuche diese automatisch zu installieren (best-effort)…")
    print("      Falls das fehlschlägt, führe manuell aus:")
    print("      sudo apt update && sudo apt install python3-lilv lilv-utils\n")

    # Try root first.
    try:
        if hasattr(os, "geteuid") and os.geteuid() == 0:
            _run(["apt-get", "update"])
            _run(["apt-get", "install", "-y", *missing])
            return
    except Exception as exc:
        print("WARN: apt-get (root) failed:", exc)

    sudo = _which("sudo")
    if not sudo:
        return
    try:
        _run([sudo, "apt-get", "update"])
        _run([sudo, "apt-get", "install", "-y", *missing])
    except Exception as exc:
        print("WARN: sudo apt-get failed:", exc)


def _is_macos() -> bool:
    return sys.platform == "darwin"


def _brew_has(pkg: str) -> bool:
    brew = _which("brew")
    if not brew:
        return False
    try:
        subprocess.check_output([brew, "list", "--versions", pkg], stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def _maybe_install_brew_deps() -> None:
    """Optional Homebrew deps for macOS (best-effort, never abort).

    - CoreAudio comes via PortAudio (sounddevice).
    - We only install common libs + optional LV2 tooling.
    """
    if not _is_macos():
        return
    brew = _which("brew")
    if not brew:
        print("\n[macOS] Homebrew nicht gefunden. Optional installieren: https://brew.sh")
        print("       Danach (empfohlen): brew install portaudio libsndfile fluidsynth")
        print("       Für LV2 Hosting/GUI optional: brew install lv2 lilv suil ladspa-sdk mda-lv2\n")
        return

    pkgs_core = ["portaudio", "libsndfile", "fluidsynth"]
    pkgs_plugins = ["lv2", "lilv", "suil", "ladspa-sdk", "mda-lv2"]

    def _install_one(p: str) -> None:
        if _brew_has(p):
            return
        try:
            print(f"\n[macOS] brew install {p} (best-effort)…")
            _run([brew, "install", p])
        except Exception as exc:
            print(f"WARN: brew install {p} fehlgeschlagen: {exc}")

    print("\n[macOS] Prüfe/Installiere Homebrew Dependencies (best-effort)…")
    for p in pkgs_core:
        _install_one(p)

    # Plugins optional – niemals blockieren
    for p in pkgs_plugins:
        _install_one(p)


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def main() -> int:
    here = Path(__file__).resolve().parent
    req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))

    # Always run installs inside a local venv to avoid PEP 668 ("externally-managed-environment")
    # on Kali/Debian. This is SAFE: it does not modify system site-packages.
    py = sys.executable
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        print("      Empfehlung: python3 -m venv myenv && source myenv/bin/activate")
        venv_dir = here / "myenv"
        if os.name == "nt":
            vpy = venv_dir / "Scripts" / "python.exe"
        else:
            vpy = venv_dir / "bin" / "python3"
            if not vpy.exists():
                vpy = venv_dir / "bin" / "python"
        if vpy.exists():
            print(f"INFO: Verwende vorhandenes venv: {venv_dir}")
            py = str(vpy)
        else:
            print("INFO: Erstelle lokales venv ./myenv (safe, keine System-Änderung) ...")
            try:
                subprocess.check_call([sys.executable, "-m", "venv", "--system-site-packages", str(venv_dir)])
            except Exception:
                subprocess.check_call([sys.executable, "-m", "venv", str(venv_dir)])
            if not vpy.exists():
                # Refresh python path after creation
                if os.name == "nt":
                    vpy = venv_dir / "Scripts" / "python.exe"
                else:
                    vpy = venv_dir / "bin" / "python3"
                    if not vpy.exists():
                        vpy = venv_dir / "bin" / "python"
            py = str(vpy)
        print("INFO: Installer nutzt Python:", py)


    # Optional: system packages for LV2 hosting (Debian/Kali)
    # Best-effort only: never abort the installer.
    try:
        _maybe_install_lv2_deps()
    except Exception as exc:
        print("WARN: LV2 deps check/install failed:", exc)

    # Optional: Homebrew deps for macOS (best-effort)
    try:
        _maybe_install_brew_deps()
    except Exception as exc:
        print("WARN: macOS brew deps check/install failed:", exc)

    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    _run([py, "-m", "pip", "install", "-r", str(req)])

    print("\nOK. Starte danach mit: python3 main.py")
    print("Optional: Audio/MIDI Abhängigkeiten können Systempakete erfordern (PipeWire-JACK/JACK/qpwgraph).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
