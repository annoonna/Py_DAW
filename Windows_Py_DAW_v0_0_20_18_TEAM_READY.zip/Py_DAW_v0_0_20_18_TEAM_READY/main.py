"""Entry point for Py DAW.

Windows:
- Force Qt to prefer Direct3D (ANGLE -> D3D11) before importing PyQt6.
- Prefer Windows audio host API (WASAPI) via sounddevice/PortAudio.
"""
import faulthandler
import signal
import os
import sys

faulthandler.enable(all_threads=True)
try:
    faulthandler.register(signal.SIGABRT, all_threads=True)
except Exception:
    pass

# Must run BEFORE importing PyQt6 (which happens inside pydaw.app).
if sys.platform.startswith("win"):
    try:
        from pydaw.platform.windows_qt_init import init_windows_rendering

        init_windows_rendering(prefer=os.getenv("CHRONOSCALE_D3D", "d3d11"))
    except Exception:
        pass

    # Default to WASAPI on Windows unless user overrides.
    os.environ.setdefault("PYDAW_SD_HOSTAPI", os.getenv("PYDAW_SD_HOSTAPI", "wasapi"))

from pydaw.app import run

if __name__ == "__main__":
    run()
