# -*- coding: utf-8 -*-
"""Plugin Safety Probe — Fork-based crash isolation.

v0.0.20.723: Prevents SEGFAULT-prone plugins from crashing the DAW.

Before loading any external plugin in the main process, we fork a child
process that attempts the load. If the child crashes (SEGFAULT, SIGABRT),
the plugin is blacklisted and skipped — the DAW stays alive.

Usage:
    from pydaw.services.plugin_probe import is_plugin_safe

    if is_plugin_safe("/usr/lib/vst3/CardinalFX.vst3", "vst3"):
        # safe to load in main process
        engine = Vst3InstrumentEngine(...)
    else:
        print("Plugin blacklisted — skipping")

Architecture:
    Main Process ──fork()──► Child Process
                              │ try: load plugin
                              │ exit(0) if OK
                              │ SEGFAULT → exit code != 0
                   waitpid() ◄─┘
                   exit_code == 0 → safe
                   exit_code != 0 → blacklisted
"""
from __future__ import annotations

import logging
import os
import signal
import sys
import time
from typing import Dict, Optional, Set

_log = logging.getLogger(__name__)

# Persistent blacklist for this session (path → reason)
_blacklist: Dict[str, str] = {}

# Known-safe cache (avoid re-probing)
_safelist: Set[str] = set()

# Timeout for probe subprocess (seconds)
PROBE_TIMEOUT = 10.0


def is_plugin_safe(plugin_path: str, plugin_type: str = "vst3",
                    plugin_name: str = "", plugin_id: str = "") -> bool:
    """Check if a plugin can be safely loaded without crashing.

    Returns True if safe, False if blacklisted or probe crashed.
    Uses fork() on Linux to isolate the load attempt.
    """
    cache_key = f"{plugin_type}:{plugin_path}:{plugin_name}:{plugin_id}"

    # Already tested?
    if cache_key in _safelist:
        return True
    if cache_key in _blacklist:
        _log.info("[PROBE] Skipping blacklisted plugin: %s (%s)",
                  plugin_path, _blacklist[cache_key])
        return False

    # On non-Unix systems, skip probing (can't fork)
    if not hasattr(os, 'fork'):
        _safelist.add(cache_key)
        return True

    _log.info("[PROBE] Testing plugin: %s (%s)", plugin_path, plugin_type)

    try:
        pid = os.fork()
    except OSError as e:
        _log.warning("[PROBE] fork() failed: %s — allowing plugin", e)
        _safelist.add(cache_key)
        return True

    if pid == 0:
        # ── CHILD PROCESS ──
        # Suppress all output from plugin loading
        try:
            devnull = os.open(os.devnull, os.O_WRONLY)
            os.dup2(devnull, 2)  # redirect stderr
            os.close(devnull)
        except Exception:
            pass

        try:
            _do_probe(plugin_path, plugin_type, plugin_name, plugin_id)
            os._exit(0)  # Success
        except SystemExit:
            os._exit(0)
        except Exception:
            os._exit(1)  # Load error (not crash)
        finally:
            os._exit(2)  # Should not reach here
    else:
        # ── PARENT PROCESS ──
        # Wait for child with timeout
        start = time.monotonic()
        while True:
            try:
                rpid, status = os.waitpid(pid, os.WNOHANG)
            except ChildProcessError:
                # Child already reaped
                _safelist.add(cache_key)
                return True

            if rpid != 0:
                # Child finished
                if os.WIFEXITED(status):
                    exit_code = os.WEXITSTATUS(status)
                    if exit_code == 0:
                        _safelist.add(cache_key)
                        _log.info("[PROBE] ✅ Plugin safe: %s", plugin_path)
                        return True
                    else:
                        # exit code 1 = normal Python exception (e.g. "main thread" error)
                        # This is NOT a crash — the plugin might work on the main thread.
                        # Only real crashes (signals) should blacklist.
                        _safelist.add(cache_key)
                        _log.info("[PROBE] ✅ Plugin raised exception (exit %d) but no crash: %s",
                                  exit_code, plugin_path)
                        return True
                elif os.WIFSIGNALED(status):
                    sig = os.WTERMSIG(status)
                    sig_name = signal.Signals(sig).name if sig in signal.Signals._value2member_map_ else str(sig)
                    reason = f"crashed with signal {sig_name}"
                    _blacklist[cache_key] = reason
                    _log.warning(
                        "[PROBE] 💀 Plugin CRASHED: %s (%s) — BLACKLISTED",
                        plugin_path, reason)
                    print(
                        f"[PROBE] 💀 Plugin CRASHED: {plugin_path} "
                        f"(Signal {sig_name}) — blacklisted for this session",
                        file=sys.stderr, flush=True)
                    return False
                else:
                    _safelist.add(cache_key)
                    return True

            # Check timeout
            elapsed = time.monotonic() - start
            if elapsed > PROBE_TIMEOUT:
                # Kill hung child
                try:
                    os.kill(pid, signal.SIGKILL)
                    os.waitpid(pid, 0)
                except Exception:
                    pass
                reason = f"probe timed out after {PROBE_TIMEOUT}s"
                _blacklist[cache_key] = reason
                _log.warning("[PROBE] ⏰ Plugin probe timed out: %s — BLACKLISTED",
                             plugin_path)
                return False

            time.sleep(0.05)  # 50ms poll


def _do_probe(plugin_path: str, plugin_type: str,
               plugin_name: str, plugin_id: str) -> None:
    """Attempt to load the plugin (runs in child process).

    Any crash here kills only the child process.
    """
    if plugin_type in ("vst3", "vst2"):
        try:
            import pedalboard
            # Try loading — this is where SEGFAULT would happen
            if plugin_type == "vst3":
                p = pedalboard.VST3Plugin(plugin_path, plugin_name=plugin_name or None)
            else:
                p = pedalboard.VST3Plugin(plugin_path)  # VST2 also via pedalboard
            del p
        except Exception:
            raise

    elif plugin_type == "clap":
        # CLAP plugins are loaded via ctypes — generally safe
        # But still probe to catch dlopen crashes
        import ctypes
        try:
            path = plugin_path
            if "::" in path:
                path = path.split("::")[0]
            lib = ctypes.CDLL(path)
            del lib
        except Exception:
            raise

    elif plugin_type == "lv2":
        # LV2 via lilv — generally safe
        pass

    elif plugin_type == "ladspa":
        import ctypes
        try:
            lib = ctypes.CDLL(plugin_path)
            del lib
        except Exception:
            raise


def get_blacklist() -> Dict[str, str]:
    """Return the current session blacklist (path → reason)."""
    return dict(_blacklist)


def clear_blacklist() -> None:
    """Clear the blacklist (for re-probing)."""
    _blacklist.clear()
    _safelist.clear()
