"""Entry point for Py DAW."""

import faulthandler
import os
import signal
import sys

faulthandler.enable(all_threads=True)
try:
    faulthandler.register(signal.SIGABRT, all_threads=True)
except Exception:
    pass

# --- Windows: initialize Qt rendering backend EARLY (before any Qt import)
# This avoids common OpenGL/ANGLE/driver pitfalls on Windows.
if sys.platform.startswith("win"):
    try:
        from pydaw.platform.windows_qt_init import init_windows_rendering

        init_windows_rendering()
    except Exception:
        # Never block startup.
        pass

    # Prefer WASAPI for PortAudio via sounddevice (lower latency than MME).
    os.environ.setdefault("PYDAW_SD_HOSTAPI", "wasapi")

# --- Graphics backend selection (must happen BEFORE importing PyQt6)
# Linux default: Vulkan (when available). Override via:
#   PYDAW_GFX_BACKEND=opengl python3 main.py
try:
    from pydaw.utils.gfx_backend import configure_graphics_backend

    configure_graphics_backend()
except Exception:
    # Never block startup.
    pass

from pydaw.app import run

if __name__ == "__main__":
    run()
