v0.0.20.76 (Windows Build)

- Windows: Qt Rendering Bootstrap (ANGLE→D3D11) via `pydaw/platform/windows_qt_init.py` (vor PyQt6 Import).
- Windows: sounddevice bevorzugt WASAPI (Auto-Device-Pick) + optional Exclusive Mode (`PYDAW_WASAPI_EXCLUSIVE=1`).
- Windows: FluidSynth CLI Auto-Detection + optional pyfluidsynth Fallback.
- requirements: `JACK-Client` Linux-only + `requirements_windows.txt` ergänzt.
- Doku: `WINDOWS_INSTALLATION.md` aktualisiert.
