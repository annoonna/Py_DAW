"""DAWproject Importer — Import .dawproject files (Bitwig/Studio One/Cubase).

DAWproject is an open exchange format for DAWs (https://github.com/bitwig/dawproject).
A .dawproject file is a ZIP archive containing:
  - project.xml  (track structure, clips, notes, automation, transport)
  - metadata.xml (title, artist, comments)
  - audio/       (referenced WAV/FLAC files)
  - plugins/     (plugin state files — CLAP/VST presets)

This importer maps DAWproject structures into PyDAW's internal model:
  - DAWproject Track → PyDAW Track (audio / instrument)
  - DAWproject Clip + Notes → PyDAW Clip + MidiNotes
  - DAWproject Audio references → imported into project media/
  - DAWproject Transport (BPM, time signature) → project settings

v0.0.20.88 — Initial implementation (Claude Opus 4.6, 2026-02-16)
"""

from __future__ import annotations

import logging
import shutil
import tempfile
import zipfile
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from pydaw.model.project import (
    Clip,
    MediaItem,
    Track,
    new_id,
)
from pydaw.model.midi import MidiNote

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data classes for intermediate DAWproject representation
# ---------------------------------------------------------------------------

@dataclass
class DawProjectMetadata:
    title: str = ""
    artist: str = ""
    comment: str = ""
    application: str = ""
    app_version: str = ""


@dataclass
class DawProjectNote:
    """A single note from a DAWproject Notes lane."""
    time: float = 0.0       # beats
    duration: float = 1.0   # beats
    channel: int = 0
    key: int = 60           # MIDI pitch
    velocity: float = 0.8   # 0..1 normalized
    release_velocity: float = 0.0


@dataclass
class DawProjectClip:
    """A clip inside a DAWproject Arrangement lane."""
    time: float = 0.0          # beats (position on timeline)
    duration: float = 4.0      # beats
    content_time_offset: float = 0.0
    name: str = ""
    color: str = ""
    # For audio clips
    audio_file: str = ""       # relative path inside the archive
    # For note clips
    notes: List[DawProjectNote] = field(default_factory=list)


@dataclass
class DawProjectTrack:
    """Parsed track from DAWproject Structure."""
    id: str = ""
    name: str = ""
    color: str = ""
    content_type: str = ""     # "notes", "audio", "automationLanes", ...
    volume: float = 0.8        # linear 0..2
    pan: float = 0.5           # normalized 0..1 (0.5 = center)
    mute: bool = False
    solo: bool = False
    # Clips from the Arrangement that belong to this track
    clips: List[DawProjectClip] = field(default_factory=list)
    # Plugin info (informational — we can't load foreign plugins)
    plugin_name: str = ""
    plugin_id: str = ""


@dataclass
class DawProjectData:
    """Complete parsed DAWproject."""
    metadata: DawProjectMetadata = field(default_factory=DawProjectMetadata)
    bpm: float = 120.0
    time_sig_num: int = 4
    time_sig_den: int = 4
    tracks: List[DawProjectTrack] = field(default_factory=list)
    # All audio file paths found inside the archive
    audio_files: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# XML Parsing helpers
# ---------------------------------------------------------------------------

def _attr_float(elem: ET.Element, name: str, default: float = 0.0) -> float:
    try:
        return float(elem.get(name, default))
    except (ValueError, TypeError):
        return default


def _attr_int(elem: ET.Element, name: str, default: int = 0) -> int:
    try:
        return int(elem.get(name, default))
    except (ValueError, TypeError):
        return default


def _attr_bool(elem: ET.Element, name: str, default: bool = False) -> bool:
    val = elem.get(name, "")
    if val.lower() in ("true", "1", "yes"):
        return True
    if val.lower() in ("false", "0", "no"):
        return False
    return default


# ---------------------------------------------------------------------------
# Core parser
# ---------------------------------------------------------------------------

class DawProjectParser:
    """Parse a .dawproject ZIP archive into DawProjectData."""

    def __init__(self, path: Path):
        self.path = path
        self._track_map: Dict[str, DawProjectTrack] = {}  # id -> track

    def parse(self) -> DawProjectData:
        """Parse the .dawproject file and return structured data."""
        data = DawProjectData()

        if not self.path.exists():
            raise FileNotFoundError(f"File not found: {self.path}")

        if not zipfile.is_zipfile(self.path):
            raise ValueError(f"Not a valid ZIP archive: {self.path}")

        with zipfile.ZipFile(self.path, 'r') as zf:
            names = zf.namelist()

            # Parse metadata.xml (optional)
            meta_name = self._find_file(names, "metadata.xml")
            if meta_name:
                try:
                    with zf.open(meta_name) as f:
                        data.metadata = self._parse_metadata(ET.parse(f).getroot())
                except Exception as e:
                    log.warning("Failed to parse metadata.xml: %s", e)

            # Parse project.xml (required)
            proj_name = self._find_file(names, "project.xml")
            if not proj_name:
                raise ValueError("project.xml not found in .dawproject archive")

            with zf.open(proj_name) as f:
                root = ET.parse(f).getroot()

            self._parse_project(root, data)

            # Collect audio file paths
            for name in names:
                lower = name.lower()
                if any(lower.endswith(ext) for ext in ('.wav', '.flac', '.ogg', '.mp3', '.aiff', '.aif')):
                    data.audio_files.append(name)

        return data

    @staticmethod
    def _find_file(names: List[str], filename: str) -> Optional[str]:
        """Find a file in ZIP, accounting for possible subdirectory prefix."""
        for n in names:
            if n.endswith(filename) and (n == filename or n.endswith('/' + filename)):
                return n
        return None

    def _parse_metadata(self, root: ET.Element) -> DawProjectMetadata:
        meta = DawProjectMetadata()
        meta.title = root.findtext("Title", "")
        meta.artist = root.findtext("Artist", "")
        meta.comment = root.findtext("Comment", "")
        return meta

    def _parse_project(self, root: ET.Element, data: DawProjectData) -> None:
        """Parse the <Project> root element."""
        # Application info
        app = root.find("Application")
        if app is not None:
            data.metadata.application = app.get("name", "")
            data.metadata.app_version = app.get("version", "")

        # Transport: BPM + TimeSignature
        transport = root.find("Transport")
        if transport is not None:
            tempo = transport.find("Tempo")
            if tempo is not None:
                data.bpm = _attr_float(tempo, "value", 120.0)

            ts = transport.find("TimeSignature")
            if ts is not None:
                data.time_sig_num = _attr_int(ts, "numerator", 4)
                data.time_sig_den = _attr_int(ts, "denominator", 4)

        # Structure: Tracks
        structure = root.find("Structure")
        if structure is not None:
            self._parse_structure(structure, data)

        # Arrangement: Clips mapped to tracks
        arrangement = root.find("Arrangement")
        if arrangement is not None:
            self._parse_arrangement(arrangement, data)

    def _parse_structure(self, structure: ET.Element, data: DawProjectData) -> None:
        """Parse <Structure> containing <Track> elements."""
        for track_elem in structure.iter("Track"):
            trk = DawProjectTrack()
            trk.id = track_elem.get("id", "")
            trk.name = track_elem.get("name", "Track")
            trk.color = track_elem.get("color", "")
            trk.content_type = track_elem.get("contentType", "")

            # Channel info (Volume, Pan, Mute, Solo)
            channel = track_elem.find("Channel")
            if channel is not None:
                vol = channel.find("Volume")
                if vol is not None:
                    trk.volume = _attr_float(vol, "value", 0.8)

                pan = channel.find("Pan")
                if pan is not None:
                    trk.pan = _attr_float(pan, "value", 0.5)

                mute = channel.find("Mute")
                if mute is not None:
                    trk.mute = _attr_bool(mute, "value", False)

                # Devices / Plugins (informational)
                devices = channel.find("Devices")
                if devices is not None:
                    for dev in devices:
                        tag = dev.tag
                        if "Plugin" in tag:
                            trk.plugin_name = dev.get("deviceName", dev.get("name", ""))
                            trk.plugin_id = dev.get("deviceID", "")
                            break

            data.tracks.append(trk)
            self._track_map[trk.id] = trk

    def _parse_arrangement(self, arrangement: ET.Element, data: DawProjectData) -> None:
        """Parse <Arrangement> → <Lanes> → <Lanes track='id'> → <Clips> → <Clip>."""
        # The arrangement has nested <Lanes> elements.
        # Top-level <Lanes> may contain per-track <Lanes track="id"> elements,
        # which then contain <Clips> with <Clip> children.
        self._walk_lanes(arrangement, track_id=None)

    def _walk_lanes(self, parent: ET.Element, track_id: Optional[str]) -> None:
        """Recursively walk <Lanes> elements to find clips."""
        for child in parent:
            tag = child.tag

            if tag == "Lanes":
                # May have a track attribute
                tid = child.get("track", track_id)
                self._walk_lanes(child, tid)

            elif tag == "Clips":
                self._parse_clips(child, track_id)

            elif tag == "Clip":
                self._parse_single_clip(child, track_id)

    def _parse_clips(self, clips_elem: ET.Element, track_id: Optional[str]) -> None:
        """Parse a <Clips> container."""
        for clip_elem in clips_elem:
            if clip_elem.tag == "Clip":
                self._parse_single_clip(clip_elem, track_id)

    def _parse_single_clip(self, clip_elem: ET.Element, track_id: Optional[str]) -> None:
        """Parse a single <Clip> element."""
        clip = DawProjectClip()
        clip.time = _attr_float(clip_elem, "time", 0.0)
        clip.duration = _attr_float(clip_elem, "duration", 4.0)
        clip.content_time_offset = _attr_float(clip_elem, "contentTimeOffset", 0.0)
        clip.name = clip_elem.get("name", "")
        clip.color = clip_elem.get("color", "")

        # Check for <Notes> content
        notes_elem = clip_elem.find("Notes")
        if notes_elem is not None:
            for note_elem in notes_elem.iter("Note"):
                note = DawProjectNote(
                    time=_attr_float(note_elem, "time", 0.0),
                    duration=_attr_float(note_elem, "duration", 1.0),
                    channel=_attr_int(note_elem, "channel", 0),
                    key=_attr_int(note_elem, "key", 60),
                    velocity=_attr_float(note_elem, "vel", 0.8),
                    release_velocity=_attr_float(note_elem, "rel", 0.0),
                )
                clip.notes.append(note)

        # Check for <Audio> content (file reference)
        audio_elem = clip_elem.find("Audio")
        if audio_elem is not None:
            file_elem = audio_elem.find("File")
            if file_elem is not None:
                clip.audio_file = file_elem.get("path", "")

        # Also check for direct <File> reference (some exporters)
        if not clip.audio_file:
            file_direct = clip_elem.find("File")
            if file_direct is not None:
                clip.audio_file = file_direct.get("path", "")

        # Assign to track
        if track_id and track_id in self._track_map:
            self._track_map[track_id].clips.append(clip)
        else:
            # If no track mapping, try to find a matching track or create orphan
            log.debug("Clip '%s' has no track mapping (track_id=%s)", clip.name, track_id)


# ---------------------------------------------------------------------------
# Importer: Maps DawProjectData → PyDAW Project modifications
# ---------------------------------------------------------------------------

@dataclass
class ImportResult:
    """Summary of what was imported."""
    tracks_created: int = 0
    clips_created: int = 0
    notes_imported: int = 0
    audio_files_copied: int = 0
    warnings: List[str] = field(default_factory=list)
    source_app: str = ""
    project_name: str = ""


class DawProjectImporter:
    """Import a parsed DawProjectData into an existing PyDAW project.

    This is designed to be non-destructive:
    - New tracks and clips are ADDED (existing content is untouched)
    - BPM/time signature are only updated if the project is empty or the user opts in
    """

    def __init__(
        self,
        dawproject_path: Path,
        project,   # pydaw.model.project.Project
        media_dir: Path,
        update_transport: bool = True,
        progress_cb: Optional[Callable[[int, str], None]] = None,
    ):
        self.dawproject_path = dawproject_path
        self.project = project
        self.media_dir = media_dir
        self.update_transport = update_transport
        self.progress_cb = progress_cb or (lambda pct, msg: None)

    def run(self) -> ImportResult:
        """Execute the full import pipeline. Returns ImportResult."""
        result = ImportResult()

        # Step 1: Parse .dawproject
        self.progress_cb(5, "Parsing .dawproject …")
        parser = DawProjectParser(self.dawproject_path)
        data = parser.parse()

        result.source_app = f"{data.metadata.application} {data.metadata.app_version}".strip()
        result.project_name = data.metadata.title or self.dawproject_path.stem

        # Step 2: Update transport (BPM, time signature)
        if self.update_transport:
            self.progress_cb(10, "Transport-Einstellungen übernehmen …")
            self._apply_transport(data)

        # Step 3: Extract audio files
        self.progress_cb(15, "Audio-Dateien extrahieren …")
        audio_map = self._extract_audio_files(data, result)

        # Step 4: Create tracks + clips + notes
        self.progress_cb(30, "Spuren und Clips erstellen …")
        self._create_tracks_and_clips(data, audio_map, result)

        self.progress_cb(100, "Import abgeschlossen!")
        return result

    def _apply_transport(self, data: DawProjectData) -> None:
        """Apply BPM and time signature from the dawproject."""
        if data.bpm > 0:
            self.project.bpm = data.bpm

        if data.time_sig_num > 0 and data.time_sig_den > 0:
            self.project.time_signature = f"{data.time_sig_num}/{data.time_sig_den}"

    def _extract_audio_files(
        self, data: DawProjectData, result: ImportResult
    ) -> Dict[str, Path]:
        """Extract audio files from the archive into the project's media dir.

        Returns a mapping: archive_path → local_path
        """
        audio_map: Dict[str, Path] = {}

        if not data.audio_files:
            return audio_map

        self.media_dir.mkdir(parents=True, exist_ok=True)

        try:
            with zipfile.ZipFile(self.dawproject_path, 'r') as zf:
                total = len(data.audio_files)
                for i, arc_path in enumerate(data.audio_files):
                    try:
                        pct = 15 + int(15 * (i / max(total, 1)))
                        fname = Path(arc_path).name
                        self.progress_cb(pct, f"Audio: {fname}")

                        dest = self.media_dir / fname
                        # Avoid overwriting existing files
                        if dest.exists():
                            stem, suffix = dest.stem, dest.suffix
                            counter = 1
                            while dest.exists():
                                dest = self.media_dir / f"{stem}_{counter}{suffix}"
                                counter += 1

                        # Extract single file
                        with zf.open(arc_path) as src, open(dest, 'wb') as dst:
                            shutil.copyfileobj(src, dst)

                        audio_map[arc_path] = dest
                        result.audio_files_copied += 1
                    except Exception as e:
                        msg = f"Audio-Extraktion fehlgeschlagen: {arc_path}: {e}"
                        log.warning(msg)
                        result.warnings.append(msg)
        except Exception as e:
            log.error("Failed to open ZIP for audio extraction: %s", e)

        return audio_map

    def _create_tracks_and_clips(
        self, data: DawProjectData, audio_map: Dict[str, Path], result: ImportResult
    ) -> None:
        """Create PyDAW tracks and clips from parsed DAWproject data."""
        total = len(data.tracks)

        for i, daw_track in enumerate(data.tracks):
            pct = 30 + int(65 * (i / max(total, 1)))
            self.progress_cb(pct, f"Track: {daw_track.name}")

            # Determine track kind
            has_notes = any(c.notes for c in daw_track.clips)
            has_audio = any(c.audio_file for c in daw_track.clips)
            content_type = daw_track.content_type.lower()

            if content_type == "notes" or has_notes:
                kind = "instrument"
            elif content_type == "audio" or has_audio:
                kind = "audio"
            else:
                kind = "audio"  # default

            # Create PyDAW track
            trk = Track(
                kind=kind,
                name=daw_track.name or f"Imported Track {i + 1}",
                volume=self._convert_volume(daw_track.volume),
                pan=self._convert_pan(daw_track.pan),
                muted=daw_track.mute,
                solo=daw_track.solo,
            )

            # Insert before master track
            tracks = [t for t in self.project.tracks if t.kind != "master"]
            master = next((t for t in self.project.tracks if t.kind == "master"), None)
            tracks.append(trk)
            if master:
                tracks.append(master)
            self.project.tracks = tracks
            result.tracks_created += 1

            # Create clips
            for clip_data in daw_track.clips:
                if clip_data.notes:
                    self._create_midi_clip(trk, clip_data, result)
                elif clip_data.audio_file:
                    self._create_audio_clip(trk, clip_data, audio_map, result)
                else:
                    # Empty clip — skip or create placeholder
                    pass

    def _create_midi_clip(
        self, trk: Track, clip_data: DawProjectClip, result: ImportResult
    ) -> None:
        """Create a MIDI clip with notes."""
        clip = Clip(
            kind="midi",
            track_id=trk.id,
            start_beats=clip_data.time,
            length_beats=max(clip_data.duration, 1.0),
            label=clip_data.name or "Imported Clip",
        )
        self.project.clips.append(clip)
        result.clips_created += 1

        # Convert notes
        notes = []
        for dn in clip_data.notes:
            vel = max(1, min(127, int(dn.velocity * 127)))
            note = MidiNote(
                pitch=max(0, min(127, dn.key)),
                start_beats=max(0.0, dn.time - clip_data.content_time_offset),
                length_beats=max(0.0625, dn.duration),
                velocity=vel,
            ).clamp()
            notes.append(note)
            result.notes_imported += 1

        if notes:
            self.project.midi_notes[clip.id] = notes

    def _create_audio_clip(
        self,
        trk: Track,
        clip_data: DawProjectClip,
        audio_map: Dict[str, Path],
        result: ImportResult,
    ) -> None:
        """Create an audio clip referencing an extracted audio file."""
        # Resolve the audio file path
        local_path: Optional[Path] = None

        # Try exact match
        if clip_data.audio_file in audio_map:
            local_path = audio_map[clip_data.audio_file]
        else:
            # Try matching by filename only (paths may differ)
            target_name = Path(clip_data.audio_file).name.lower()
            for arc_path, loc_path in audio_map.items():
                if Path(arc_path).name.lower() == target_name:
                    local_path = loc_path
                    break

        source_path = str(local_path) if local_path else ""

        # Register as media item
        media_id = ""
        if local_path and local_path.exists():
            mi = MediaItem(
                kind="audio",
                path=str(local_path),
                label=local_path.name,
            )
            self.project.media.append(mi)
            media_id = mi.id

        clip = Clip(
            kind="audio",
            track_id=trk.id,
            start_beats=clip_data.time,
            length_beats=max(clip_data.duration, 1.0),
            offset_beats=clip_data.content_time_offset,
            label=clip_data.name or (Path(clip_data.audio_file).stem if clip_data.audio_file else "Audio Clip"),
            source_path=source_path,
            media_id=media_id,
        )
        self.project.clips.append(clip)
        result.clips_created += 1

    # --- Conversion helpers ---

    @staticmethod
    def _convert_volume(dawproject_volume: float) -> float:
        """Convert DAWproject volume (linear 0..2) to PyDAW volume (0..1).

        DAWproject uses 0..2 linear where 1.0 = 0dB.
        PyDAW uses 0..1 where 0.8 is roughly 0dB.
        """
        # Simple mapping: clamp and scale
        return max(0.0, min(1.0, dawproject_volume * 0.8))

    @staticmethod
    def _convert_pan(dawproject_pan: float) -> float:
        """Convert DAWproject pan (0..1, 0.5=center) to PyDAW pan (-1..+1, 0=center)."""
        return max(-1.0, min(1.0, (dawproject_pan - 0.5) * 2.0))


# ---------------------------------------------------------------------------
# Convenience function for UI integration
# ---------------------------------------------------------------------------

def import_dawproject(
    dawproject_path: Path,
    project,
    media_dir: Path,
    update_transport: bool = True,
    progress_cb: Optional[Callable[[int, str], None]] = None,
) -> ImportResult:
    """High-level entry point for importing a .dawproject file.

    Args:
        dawproject_path: Path to the .dawproject file
        project: PyDAW Project instance to import into
        media_dir: Directory where audio files should be extracted
        update_transport: Whether to update BPM/time signature
        progress_cb: Optional callback (percent: int, message: str)

    Returns:
        ImportResult with summary statistics
    """
    importer = DawProjectImporter(
        dawproject_path=dawproject_path,
        project=project,
        media_dir=media_dir,
        update_transport=update_transport,
        progress_cb=progress_cb,
    )
    return importer.run()
