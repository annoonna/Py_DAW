# -*- coding: utf-8 -*-
"""Bach Orgel instrument plugin (PyQt6 + simple additive organ engine)."""

from .bach_orgel_widget import BachOrgelWidget

__all__ = ["BachOrgelWidget"]
