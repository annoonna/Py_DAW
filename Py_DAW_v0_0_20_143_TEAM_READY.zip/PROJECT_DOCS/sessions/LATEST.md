v0.0.20.143
- Arranger: Playhead (rote Linie) ist jetzt seek/drag-bar (Lineal unten + direkt am Playhead)
- Arranger: Ctrl+Drag = DAW-Style Copy-Preview (Original bleibt; Ghost folgt; Drop erzeugt Kopien) inkl. Multi-Clip/Lasso
- Arranger: Massive Performance-Fix bei langen Projekten (Paint nur im sichtbaren Bereich + Playhead-Partial-Update)
