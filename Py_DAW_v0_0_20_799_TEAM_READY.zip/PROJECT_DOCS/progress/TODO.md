# TODO.md — Offene Aufgaben

## v0.0.20.798 — Phase 5A Wiring + Phase 6A Python Scripting

- [x] (Claude Opus 4.6, 2026-03-24): **CollabPanel in MainWindow** — Dock-Widget, Ctrl+Alt+C
- [x] (Claude Opus 4.6, 2026-03-24): **Services verdrahtet** — Git/Review/Scripting im ServiceContainer
- [x] (Claude Opus 4.6, 2026-03-24): **websockets Dependency** — requirements.txt + install.py
- [x] (Claude Opus 4.6, 2026-03-24): **ScriptingService** — Sandboxed Python, Proxy-API, Built-in Scripts
- [x] (Claude Opus 4.6, 2026-03-24): **ScriptingPanel** — Console + Library UI, Ctrl+Alt+P
- [x] (Claude Opus 4.6, 2026-03-24): **Menü-Einträge** — Kollaboration + Python Console im Projekt-Menü

- [ ] AVAILABLE: **Hardware-Test Console** — Ctrl+Alt+P → project.bpm = 140 → BPM ändert sich
- [ ] AVAILABLE: **Hardware-Test Collab** — Ctrl+Alt+C → Git Init → Commit → Branch
- [ ] AVAILABLE: **P6A Macro-System** — UI-Aktionen aufzeichnen → Script exportieren
- [ ] AVAILABLE: **P5B Cloud-Projekt-Management** — Preset-Cloud, Sample-Cloud

## v0.0.20.797 — Phase 5A: Kollaboration & Git-Integration

- [x] (Claude Opus 4.6, 2026-03-24): **Git Integration Service** — init, commit, branch, merge, push/pull, stash, tags
- [x] (Claude Opus 4.6, 2026-03-24): **Collab Server** — WebSocket, Track-Locking, Chat, Presence, Full Sync
- [x] (Claude Opus 4.6, 2026-03-24): **Collab Client** — Connect, Callbacks, send_op/cursor/chat/lock
- [x] (Claude Opus 4.6, 2026-03-24): **Review Service** — Comments, Markers, Tasks, Markdown Export
- [x] (Claude Opus 4.6, 2026-03-24): **Collab Panel UI** — 3-Tab Dock-Widget (Git/Collab/Review)
- [x] (Claude Opus 4.6, 2026-03-24): **Project.review_data** — Persistenz-Feld im Model

- [ ] AVAILABLE: **CollabPanel in MainWindow einbinden** — als Dock-Widget registrieren
- [ ] AVAILABLE: **Services verdrahten** — Git/Collab/Review im ServiceContainer
- [ ] AVAILABLE: **websockets Dependency** — pip install websockets, requirements.txt
- [ ] AVAILABLE: **P5B Cloud-Projekt-Management** — Preset-Cloud, Sample-Cloud
- [ ] AVAILABLE: **Git Workflow testen** — Init → Commit → Branch → Merge auf Hardware

## v0.0.20.796 — CLAP Segfault Fix + Comping Workflow

- [x] (Claude Opus 4.6, 2026-03-24): **CLAP Segfault Root Cause** — Race: process() auf destroyed plugin_ptr
- [x] (Claude Opus 4.6, 2026-03-24): **Fix _ClapPlugin.close()** — _ok=False first, 20ms sleep, local refs
- [x] (Claude Opus 4.6, 2026-03-24): **Fix ClapFx/ClapInstrumentEngine.shutdown()** — _ok=False first
- [x] (Claude Opus 4.6, 2026-03-24): **Fix ClapInstrumentEngine.pull()** — local ref caching
- [x] (Claude Opus 4.6, 2026-03-24): **Fix Vst3InstrumentEngine** — shutdown _ok first + pull local ref
- [x] (Claude Opus 4.6, 2026-03-24): **Fix audio_engine Phase 4** — unregister→sleep→shutdown
- [x] (Claude Opus 4.6, 2026-03-24): **Drag-Comp-Tool** — Region-Auswahl per Drag in Take-Lanes
- [x] (Claude Opus 4.6, 2026-03-24): **Take-Lane Farben** — 8-Farben-Palette + Nummerierung
- [x] (Claude Opus 4.6, 2026-03-24): **flatten_comp()** — Audio-Merge mit Crossfades
- [x] (Claude Opus 4.6, 2026-03-24): **Flatten Comp Menü** — Kontextmenü-Aktion im Arranger

- [ ] AVAILABLE: **Hardware-Test CLAP Segfault** — Surge XT laden, Tracks wechseln, kein Crash
- [ ] AVAILABLE: **Comping-Test** — Loop-Recording → Take-Lanes → Drag → Flatten
- [ ] AVAILABLE: **P1B Pitch-Correction** — Melodyne-ähnlich
- [ ] AVAILABLE: **P1C Audio-Quantisierung** — Transientenbasiert

## v0.0.20.792 — Rust-Engine Disconnect-Loop Fix

- [x] (Claude Opus 4.6, 2026-03-24): **Root Cause** — start_engine() löschte Socket der externen Engine
- [x] (Claude Opus 4.6, 2026-03-24): **Fix start_engine()** — Try existing socket first, nur Subprocess wenn nötig
- [x] (Claude Opus 4.6, 2026-03-24): **Fix reconnect** — Socket-first auch ohne self._process

- [ ] AVAILABLE: **Zielrechner-Test** — Disconnect-Loop sollte weg sein

## v0.0.20.790 — C-Speed ALL FX Complete

- [x] (Claude Opus 4.6, 2026-03-24): **Gate C-Extension** — 1275x RT, SC-Fallback
- [x] (Claude Opus 4.6, 2026-03-24): **DeEsser C-Extension** — 528x RT, Listen-Fallback
- [x] (Claude Opus 4.6, 2026-03-24): **10 C-Funktionen total** — Alle per-sample FX auf C portiert

- [ ] AVAILABLE: **Hardware-Test** — Alle C-Extensions auf Zielrechner
- [ ] AVAILABLE: **should_use_rust() aktivieren** — Hybrid-Mode freischalten

## v0.0.20.789 — C-Speed Creative FX (Chorus/Phaser/Flanger)

- [x] (Claude Opus 4.6, 2026-03-24): **Chorus C-Extension** — Multi-Voice Delay + LUT, 37x RT
- [x] (Claude Opus 4.6, 2026-03-24): **Phaser C-Extension** — N-Stage Allpass + Sweep, 41x RT
- [x] (Claude Opus 4.6, 2026-03-24): **Flanger C-Extension** — Modulated Comb + Feedback, 38x RT

- [x] (Claude Opus 4.6, 2026-03-24): **Utility FX C portiert** — Gate/DeEsser/StereoWidener
- [ ] AVAILABLE: **Hardware-Test** — Alle C-Extensions auf Zielrechner testen

## v0.0.20.788 — C-Speed Reverb + Delay

- [x] (Claude Opus 4.6, 2026-03-24): **Reverb C-Extension** — Schroeder 4C+4AP, 201x RT
- [x] (Claude Opus 4.6, 2026-03-24): **Delay C-Extension** — Stereo+LP+PingPong, 610x RT
- [x] (Claude Opus 4.6, 2026-03-24): **Auto-Compile Loader** — _load_builtin_fx_lib() mit gcc Fallback

- [x] (Claude Opus 4.6, 2026-03-24): **Creative FX C portiert** — Chorus/Phaser/Flanger/Distortion/Tremolo
- [x] (Claude Opus 4.6, 2026-03-24): **Utility FX C portiert** — Gate/DeEsser/StereoWidener

## v0.0.20.787 — Comb C-Extension + Export Verification + Beta Changelog

- [x] (Claude Opus 4.6, 2026-03-24): **Comb Filter C anbinden** — 1630x RT via fast_filters.so
- [x] (Claude Opus 4.6, 2026-03-24): **Export + Audio verifiziert** — 6 OSC-Typen, WAV, Dither OK
- [x] (Claude Opus 4.6, 2026-03-24): **Beta-Changelog v0.1.0 aktualisiert** — Performance-Sektion, Fusion erweitert

- [ ] AVAILABLE: **Hardware-Test auf Zielrechner** — FusionEngine + C-Filter auf Linux/Debian testen
- [ ] AVAILABLE: **should_use_rust() aktivieren** — Hybrid-Mode für Built-in FX freischalten
- [ ] AVAILABLE: **cargo build --release** — Rust-Engine kompilieren + testen
- [ ] AVAILABLE: **Recording-Workflow** — Input-Monitoring < 10ms, Waveform-Preview

## v0.0.20.786 — C-Speed Filters (SVF/Ladder/Comb)

## v0.0.20.785 — Vectorized Bite/Union/Swarm Oscillators

- [x] (Claude Opus 4.6, 2026-03-24): **Union vektorisiert** — 3 Phasen numpy, 178x RT
- [x] (Claude Opus 4.6, 2026-03-24): **Bite RING+PWM vektorisiert** — _vec_wave Helpers, 410x RT (RING)
- [x] (Claude Opus 4.6, 2026-03-24): **Swarm Saw vektorisiert** — _vec_saw_polyblep, 107x RT (8 Voices)
- [x] (Claude Opus 4.6, 2026-03-24): **Shared Helpers** — _vec_saw_polyblep, _vec_pulse_polyblep, _vec_wave

- [x] (Claude Opus 4.6, 2026-03-24): **SVF/Ladder C-Extension** — Erledigt in v0.0.20.786
- [ ] N/A: **Phase1 vektorisieren** — Feedback-Loop macht Vektorisierung unmöglich, bleibt per-sample (~51x RT, ausreichend)

## v0.0.20.784 — Vectorized Fusion Synth DSP

- [x] (Claude Opus 4.6, 2026-03-24): **Fusion Synth vektorisieren** — Saw/Pulse/Sine-Fold/Triangle-Fold Oscillatoren, ADSR/AR/AD/Pluck Envelopes, Highpass, Brown Noise
- [x] (Claude Opus 4.6, 2026-03-24): **ADSR Hybrid Render** — 37x schneller, numpy für Sustain/OFF, per-sample für Transitionen
- [x] (Claude Opus 4.6, 2026-03-24): **PluckEnvelope scipy.lfilter** — LP-Filter vektorisiert mit Fallback
- [x] (Claude Opus 4.6, 2026-03-24): **Brown Noise np.cumsum** — Ersetzt per-sample Loop

- [x] (Claude Opus 4.6, 2026-03-24): **SVF/Ladder C-Extension** — Erledigt in v0.0.20.786
- [x] (Claude Opus 4.6, 2026-03-24): **Bite/Union/Swarm vektorisiert** — Siehe v0.0.20.785
- [ ] AVAILABLE: **Fusion Hardware-Test** — A/B Vergleich Oszillator-Output vor/nach Vektorisierung

## v0.0.20.783 — Export Fix (Offline-Rendering + Dateiname)

- [x] (Claude Opus 4.6, 2026-03-23): **render_offline() umgeschrieben** — Echtes Offline-Rendering statt kaputtem Realtime-Capture
- [x] (Claude Opus 4.6, 2026-03-23): **Export-Dialog Save-Dialog** — User wählt Dateiname + Ordner statt nur Ordner
- [x] (Claude Opus 4.6, 2026-03-23): **Export-Service Dateiname** — User-Input direkt nutzen, kein BPM-Suffix
- [x] (Claude Opus 4.6, 2026-03-23): **Stem-Export track_ids Filter** — Einzelne Spuren exportierbar

- [x] (Claude Opus 4.6, 2026-03-24): **Export getestet** — Datei → Exportieren → Dateiname → Datei im Ordner prüfen
- [x] (Claude Opus 4.6, 2026-03-24): **Audio-Inhalt verifiziert** — Nicht nur Stille, sondern echte Instrument-Audio

## v0.0.20.782 — IPC-Only Engine (cpal entfernt, Listener-Loop)

- [x] (Claude Opus 4.6, 2026-03-23): **cpal Audio-Output entfernt** — Engine produziert keinen eigenen PipeWire-Node mehr
- [x] (Claude Opus 4.6, 2026-03-23): **Listener-Loop** — Engine überlebt Client-Disconnects, wartet auf Reconnect
- [x] (Claude Opus 4.6, 2026-03-23): **Command-Drain-Ticker** — 100Hz Thread ersetzt cpal-Callback
- [x] (Claude Opus 4.6, 2026-03-23): **Rust Engine Disconnect** — Root Cause war Buffer-Size-Mismatch (cpal 1024 vs Graph 512)

- [ ] AVAILABLE: **cargo build --release testen** — Build ohne cpal sollte schneller sein + keine ALSA-Dev nötig
- [ ] AVAILABLE: **PipeWire Graph verifizieren** — Nur noch 1 Audio-Node (Python), nicht 2
- [x] (Claude Opus 4.6, 2026-03-23): **Export testen** — Offline-Rendering implementiert in v0.0.20.783
- [ ] AVAILABLE: **Phase R12: IPC Audio-Buffer Bridge** — Rust rendert Tracks → Python holt Buffers via IPC

## v0.0.20.777 — C-Speed Built-in FX

- [x] (Claude Opus 4.6, 2026-03-23): **Compressor** — numpy peaks + tight envelope + numpy gain
- [x] (Claude Opus 4.6, 2026-03-23): **Limiter** — numpy abs/max + envelope + numpy multiply
- [x] (Claude Opus 4.6, 2026-03-23): **Distortion** — numpy LUT indexing + scipy tone
- [x] (Claude Opus 4.6, 2026-03-23): **Tremolo** — numpy phase + LUT + gain
- [x] (Claude Opus 4.6, 2026-03-23): **StereoWidener** — pure numpy M/S (kein Loop)
- [x] (Claude Opus 4.6, 2026-03-23): **Utility** — numpy gain/pan/phase + scipy DC blocker

## v0.0.20.776 — Vectorized Sampler DSP

- [x] (Claude Opus 4.6, 2026-03-23): **ProSampler Fast-Path** — Vektorisierter pull_fast(), ~24x schneller
- [x] (Claude Opus 4.6, 2026-03-23): **MultiSample Fast-Path** — Vektorisierter render_voice_fast(), ~20x schneller
- [x] (Claude Opus 4.6, 2026-03-23): **Block-ADSR** — generate_envelope_block() numpy statt per-sample
- [x] (Claude Opus 4.6, 2026-03-23): **EQ C-Level** — scipy.signal.lfilter statt Python Biquad Loop, ~50x schneller

## v0.0.20.775 — Realtime Audio Performance Fix

- [x] (Claude Opus 4.6, 2026-03-23): **RT-Thread-Priority** — SCHED_FIFO + GC disable + mlockall
- [x] (Claude Opus 4.6, 2026-03-23): **Hot-Swap ArrangementState** — Eliminiert 3s Aussetzer bei MIDI-Edits
- [x] (Claude Opus 4.6, 2026-03-23): **Lock-Free Audio Callback** — VST2 host + pull_sources ohne Locks
- [x] (Claude Opus 4.6, 2026-03-23): **MIDI Debounce 200ms** — Weniger Hot-Swaps bei schnellem Editieren

- [x] (Claude Opus 4.6, 2026-03-24): **Fusion Synth vektorisiert** — Saw/Pulse/Sine/Triangle/ADSR/AR/AD/Pluck/HP/Noise
- [ ] AVAILABLE: **RT-Permissions testen** — ulimit -r prüfen, limits.conf @audio Gruppe
- [ ] AVAILABLE: **Rust Engine aktivieren** — should_use_rust() → True für Built-in FX
- [ ] AVAILABLE: **Hardware-Test BRRR PADsynth** — A/B-Vergleich mit ZynAdd, alle Tonlagen
- [ ] AVAILABLE: **Rust bauen + P0A testen** — `cd pydaw_engine && cargo build --release`
- [x] (Claude Opus 4.6, 2026-03-24): **Beta-Changelog geschrieben** — CHANGELOG v0.1.0-beta schreiben
- [ ] AVAILABLE: **P1A Recording-Workflow** — Input-Monitoring < 10ms, Waveform-Preview während Recording

