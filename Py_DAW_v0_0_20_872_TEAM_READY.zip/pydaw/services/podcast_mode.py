"""Podcast & Broadcast Mode (P7B) — Simplified workflow for spoken content.

Features:
- Podcast Mode UI: simplified, decluttered interface for speech editing
- Auto-EQ for speech: High-pass, presence boost, de-essing presets
- Silence detection: auto-detect and mark/trim silent sections
- Chapter markers: attach timestamps + titles for podcast chapters
- Streaming output: RTMP/Icecast stub for live broadcasting
- Spotify chapter export: JSON chapter format

v0.0.20.812 — Phase P7B
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Tuple

from PyQt6.QtCore import QObject, pyqtSignal

log = logging.getLogger(__name__)

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    np = None  # type: ignore
    _HAS_NUMPY = False


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class PodcastChapter:
    """A chapter marker for podcast export."""
    title: str = ""
    start_ms: int = 0
    end_ms: int = 0
    url: str = ""            # optional link
    image_url: str = ""      # optional chapter art

    def to_dict(self) -> dict:
        d: Dict[str, Any] = {
            "title": self.title,
            "start_ms": self.start_ms,
        }
        if self.end_ms > 0:
            d["end_ms"] = self.end_ms
        if self.url:
            d["url"] = self.url
        if self.image_url:
            d["image_url"] = self.image_url
        return d

    def to_spotify_format(self) -> dict:
        """Export in Spotify podcast chapter format."""
        d: Dict[str, Any] = {
            "title": self.title,
            "startTime": self.start_ms,
        }
        if self.url:
            d["url"] = self.url
        return d

    @property
    def start_seconds(self) -> float:
        return self.start_ms / 1000.0

    @property
    def timecode(self) -> str:
        """Format as HH:MM:SS."""
        total_s = self.start_ms // 1000
        h = total_s // 3600
        m = (total_s % 3600) // 60
        s = total_s % 60
        if h > 0:
            return f"{h:02d}:{m:02d}:{s:02d}"
        return f"{m:02d}:{s:02d}"


@dataclass
class SilenceRegion:
    """A detected silence region in audio."""
    start_seconds: float = 0.0
    end_seconds: float = 0.0
    duration_seconds: float = 0.0
    level_db: float = -96.0

    def to_dict(self) -> dict:
        return {
            "start": round(self.start_seconds, 3),
            "end": round(self.end_seconds, 3),
            "duration": round(self.duration_seconds, 3),
            "level_db": round(self.level_db, 1),
        }


@dataclass
class SpeechEqPreset:
    """EQ preset optimized for speech."""
    name: str = ""
    high_pass_freq: float = 80.0     # Hz
    high_pass_q: float = 0.707
    presence_freq: float = 3000.0    # Hz
    presence_gain_db: float = 2.0
    presence_q: float = 1.0
    de_ess_freq: float = 6000.0      # Hz
    de_ess_reduction_db: float = -3.0
    low_shelf_freq: float = 200.0
    low_shelf_gain_db: float = -2.0
    air_freq: float = 12000.0
    air_gain_db: float = 1.5
    description: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "high_pass_freq": self.high_pass_freq,
            "presence_freq": self.presence_freq,
            "presence_gain_db": self.presence_gain_db,
            "de_ess_freq": self.de_ess_freq,
            "description": self.description,
        }


# ---------------------------------------------------------------------------
# Speech EQ Presets
# ---------------------------------------------------------------------------

SPEECH_EQ_PRESETS: Dict[str, SpeechEqPreset] = {
    "podcast_standard": SpeechEqPreset(
        name="Podcast Standard",
        high_pass_freq=80.0, presence_freq=3000.0, presence_gain_db=2.0,
        de_ess_freq=6000.0, de_ess_reduction_db=-3.0,
        low_shelf_gain_db=-1.5, air_gain_db=1.0,
        description="Universeller Podcast-EQ: Klarheit + Wärme",
    ),
    "podcast_warm": SpeechEqPreset(
        name="Podcast Warm",
        high_pass_freq=60.0, presence_freq=2500.0, presence_gain_db=1.5,
        de_ess_freq=5500.0, de_ess_reduction_db=-2.0,
        low_shelf_freq=250.0, low_shelf_gain_db=1.0,
        air_gain_db=0.5,
        description="Warmer, voller Sound — ideal für tiefe Stimmen",
    ),
    "podcast_bright": SpeechEqPreset(
        name="Podcast Bright",
        high_pass_freq=100.0, presence_freq=3500.0, presence_gain_db=3.0,
        de_ess_freq=7000.0, de_ess_reduction_db=-4.0,
        low_shelf_gain_db=-3.0, air_gain_db=2.5,
        description="Heller, durchsetzungsfähiger Sound — ideal für helle Stimmen",
    ),
    "broadcast_radio": SpeechEqPreset(
        name="Broadcast / Radio",
        high_pass_freq=120.0, presence_freq=2800.0, presence_gain_db=2.5,
        de_ess_freq=6500.0, de_ess_reduction_db=-4.0,
        low_shelf_gain_db=-2.0, air_gain_db=1.5,
        description="Radio-typischer Sound: aggressivere Bearbeitung",
    ),
    "interview": SpeechEqPreset(
        name="Interview",
        high_pass_freq=90.0, presence_freq=3200.0, presence_gain_db=1.5,
        de_ess_freq=6000.0, de_ess_reduction_db=-2.0,
        low_shelf_gain_db=-1.0, air_gain_db=1.0,
        description="Natürlicher Sound für Gespräche, weniger Bearbeitung",
    ),
    "voice_over": SpeechEqPreset(
        name="Voice Over",
        high_pass_freq=70.0, presence_freq=4000.0, presence_gain_db=3.0,
        de_ess_freq=7500.0, de_ess_reduction_db=-5.0,
        low_shelf_gain_db=-2.0, air_gain_db=2.0,
        description="Maximale Klarheit und Durchsetzung für Narration",
    ),
}


# ---------------------------------------------------------------------------
# Silence Detection
# ---------------------------------------------------------------------------

def detect_silence(
    audio: Any,
    sample_rate: float = 44100.0,
    threshold_db: float = -40.0,
    min_duration_ms: float = 500.0,
    pre_padding_ms: float = 100.0,
    post_padding_ms: float = 100.0,
) -> List[SilenceRegion]:
    """Detect silent regions in an audio buffer.

    Args:
        audio: numpy array (mono or stereo)
        sample_rate: sample rate in Hz
        threshold_db: silence threshold in dB
        min_duration_ms: minimum silence duration to report
        pre_padding_ms: keep this much audio before silence
        post_padding_ms: keep this much audio after silence

    Returns:
        List of SilenceRegion objects.
    """
    if not _HAS_NUMPY or audio is None:
        return []

    audio = np.asarray(audio, dtype=np.float64)
    if audio.ndim == 2:
        audio = np.mean(audio, axis=1)  # to mono

    if len(audio) == 0:
        return []

    threshold_linear = 10.0 ** (threshold_db / 20.0)
    min_samples = int(min_duration_ms * sample_rate / 1000.0)
    pre_pad = int(pre_padding_ms * sample_rate / 1000.0)
    post_pad = int(post_padding_ms * sample_rate / 1000.0)

    # Calculate RMS in short windows (~10ms)
    window_size = int(0.01 * sample_rate)
    if window_size < 1:
        window_size = 1

    regions: List[SilenceRegion] = []
    silence_start: Optional[int] = None

    for i in range(0, len(audio) - window_size, window_size):
        chunk = audio[i:i + window_size]
        rms = float(np.sqrt(np.mean(chunk ** 2)))

        if rms < threshold_linear:
            if silence_start is None:
                silence_start = i
        else:
            if silence_start is not None:
                silence_end = i
                duration_samples = silence_end - silence_start
                if duration_samples >= min_samples:
                    # Apply padding
                    padded_start = max(0, silence_start + pre_pad)
                    padded_end = max(padded_start, silence_end - post_pad)
                    if padded_end > padded_start:
                        regions.append(SilenceRegion(
                            start_seconds=padded_start / sample_rate,
                            end_seconds=padded_end / sample_rate,
                            duration_seconds=(padded_end - padded_start) / sample_rate,
                            level_db=threshold_db,
                        ))
                silence_start = None

    # Handle silence at end
    if silence_start is not None:
        silence_end = len(audio)
        duration_samples = silence_end - silence_start
        if duration_samples >= min_samples:
            padded_start = max(0, silence_start + pre_pad)
            padded_end = max(padded_start, silence_end - post_pad)
            if padded_end > padded_start:
                regions.append(SilenceRegion(
                    start_seconds=padded_start / sample_rate,
                    end_seconds=padded_end / sample_rate,
                    duration_seconds=(padded_end - padded_start) / sample_rate,
                    level_db=threshold_db,
                ))

    return regions


# ---------------------------------------------------------------------------
# Chapter Export
# ---------------------------------------------------------------------------

def export_chapters_spotify(
    chapters: List[PodcastChapter],
) -> Dict[str, Any]:
    """Export chapters in Spotify podcast format (JSON).

    Returns dict suitable for Spotify's chapter API.
    """
    return {
        "chapters": [ch.to_spotify_format() for ch in chapters],
    }


def export_chapters_mp4(
    chapters: List[PodcastChapter],
) -> str:
    """Export chapters in FFMETADATA format for MP4 embedding.

    Returns string to write to a .txt file for ffmpeg -i input -f ffmetadata.
    """
    lines = [";FFMETADATA1"]
    for ch in chapters:
        start_ms = ch.start_ms
        end_ms = ch.end_ms if ch.end_ms > 0 else start_ms + 60000
        lines.append("[CHAPTER]")
        lines.append("TIMEBASE=1/1000")
        lines.append(f"START={start_ms}")
        lines.append(f"END={end_ms}")
        lines.append(f"title={ch.title}")
    return "\n".join(lines)


def export_chapters_podlove(
    chapters: List[PodcastChapter],
) -> str:
    """Export chapters in Podlove Simple Chapters format (PSC).

    Returns XML string.
    """
    lines = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<psc:chapters version="1.2" xmlns:psc="http://podlove.org/simple-chapters">']
    for ch in chapters:
        tc = ch.timecode
        attrs = f'start="{tc}" title="{ch.title}"'
        if ch.url:
            attrs += f' href="{ch.url}"'
        if ch.image_url:
            attrs += f' image="{ch.image_url}"'
        lines.append(f'  <psc:chapter {attrs}/>')
    lines.append('</psc:chapters>')
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Streaming Output (Stub)
# ---------------------------------------------------------------------------

class StreamingService(QObject):
    """Live streaming output via RTMP or Icecast.

    This is a structural stub — actual streaming requires ffmpeg
    or libshout for the actual network stream.
    """

    status = pyqtSignal(str)
    error = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._streaming = False
        self._url = ""
        self._format = "mp3"  # "mp3"|"ogg"|"aac"

    @property
    def is_streaming(self) -> bool:
        return self._streaming

    def start_stream(
        self,
        url: str,
        stream_format: str = "mp3",
        bitrate: int = 128,
    ) -> bool:
        """Start streaming to an RTMP or Icecast server.

        Args:
            url: Stream URL (rtmp://... or http://...)
            stream_format: "mp3"|"ogg"|"aac"
            bitrate: kbps

        Returns True on success.
        """
        self._url = url
        self._format = stream_format
        self._streaming = True

        log.info("Streaming started to %s (%s @ %dkbps)", url, stream_format, bitrate)
        try:
            self.status.emit(f"🔴 Streaming: {url} ({stream_format} @ {bitrate}kbps)")
        except Exception:
            pass

        # NOTE: Actual implementation would use:
        # - ffmpeg subprocess piping audio to RTMP
        # - or libshout for Icecast
        # The audio callback would write to a pipe/buffer that feeds the stream.

        return True

    def stop_stream(self) -> None:
        """Stop the live stream."""
        self._streaming = False
        log.info("Streaming stopped")
        try:
            self.status.emit("⏹ Streaming gestoppt")
        except Exception:
            pass

    def shutdown(self) -> None:
        self.stop_stream()


# ---------------------------------------------------------------------------
# Podcast Mode Service
# ---------------------------------------------------------------------------

class PodcastModeService(QObject):
    """High-level service for podcast production workflow.

    Coordinates speech EQ, silence detection, chapter management,
    and streaming.
    """

    chapters_updated = pyqtSignal(list)   # List[PodcastChapter]
    silence_detected = pyqtSignal(list)   # List[SilenceRegion]
    status = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._chapters: List[PodcastChapter] = []
        self._eq_preset: str = "podcast_standard"
        self._streaming = StreamingService(self)

    @property
    def chapters(self) -> List[PodcastChapter]:
        return list(self._chapters)

    @property
    def streaming(self) -> StreamingService:
        return self._streaming

    def set_eq_preset(self, preset_key: str) -> Optional[SpeechEqPreset]:
        """Set the active speech EQ preset."""
        preset = SPEECH_EQ_PRESETS.get(preset_key)
        if preset:
            self._eq_preset = preset_key
            try:
                self.status.emit(f"🎙 Speech-EQ: {preset.name}")
            except Exception:
                pass
        return preset

    def get_eq_preset(self) -> Optional[SpeechEqPreset]:
        return SPEECH_EQ_PRESETS.get(self._eq_preset)

    def add_chapter(self, title: str, start_ms: int, end_ms: int = 0,
                    url: str = "") -> PodcastChapter:
        ch = PodcastChapter(title=title, start_ms=start_ms, end_ms=end_ms, url=url)
        self._chapters.append(ch)
        self._chapters.sort(key=lambda c: c.start_ms)
        try:
            self.chapters_updated.emit(list(self._chapters))
        except Exception:
            pass
        return ch

    def remove_chapter(self, index: int) -> None:
        if 0 <= index < len(self._chapters):
            self._chapters.pop(index)
            try:
                self.chapters_updated.emit(list(self._chapters))
            except Exception:
                pass

    def detect_silence_in_audio(
        self,
        audio: Any,
        sample_rate: float = 44100.0,
        threshold_db: float = -40.0,
    ) -> List[SilenceRegion]:
        regions = detect_silence(audio, sample_rate, threshold_db)
        try:
            self.silence_detected.emit(regions)
            self.status.emit(f"🔇 {len(regions)} stille Regionen erkannt")
        except Exception:
            pass
        return regions

    def export_chapters(self, format: str = "spotify") -> str:
        """Export chapters in the specified format."""
        if format == "spotify":
            import json
            return json.dumps(export_chapters_spotify(self._chapters), indent=2)
        elif format == "mp4":
            return export_chapters_mp4(self._chapters)
        elif format == "podlove":
            return export_chapters_podlove(self._chapters)
        return ""

    def get_eq_presets(self) -> Dict[str, SpeechEqPreset]:
        return dict(SPEECH_EQ_PRESETS)

    def shutdown(self) -> None:
        self._streaming.shutdown()
