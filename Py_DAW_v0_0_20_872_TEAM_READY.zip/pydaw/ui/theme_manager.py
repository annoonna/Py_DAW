"""Theme Manager (Tech Debt) — Hell/Dunkel/Custom YAML Farbschemata.

Provides a centralized theming system for Py_DAW.
Themes can be loaded from YAML files or built-in presets.

Features:
- Built-in themes: Dark (default), Light, Midnight, Solarized
- Custom themes via YAML files in ~/.pydaw/themes/
- Live theme switching without restart
- CSS variable generation for Qt stylesheets
- Color palette with semantic names (background, foreground, accent, etc.)

v0.0.20.813 — Tech Debt: Theming
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional, List, Any

from PyQt6.QtCore import QObject, pyqtSignal, QSettings
from PyQt6.QtGui import QColor, QPalette
from PyQt6.QtWidgets import QApplication

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Color Palette
# ---------------------------------------------------------------------------

@dataclass
class ThemePalette:
    """Complete color palette for a theme."""
    # Backgrounds
    bg_primary: str = "#1e1e1e"          # Main window background
    bg_secondary: str = "#252525"        # Panels, docks
    bg_tertiary: str = "#2d2d2d"         # Inputs, list items
    bg_hover: str = "#3a3a3a"            # Hover state
    bg_selected: str = "#37474f"         # Selected state
    bg_header: str = "#1a1a1a"           # Headers, toolbars

    # Foregrounds
    fg_primary: str = "#eeeeee"          # Main text
    fg_secondary: str = "#b0b0b0"        # Secondary text
    fg_muted: str = "#666666"            # Disabled/muted text
    fg_accent: str = "#4fc3f7"           # Links, active items

    # Accent colors
    accent_primary: str = "#4fc3f7"      # Primary accent (blue)
    accent_secondary: str = "#81c784"    # Secondary accent (green)
    accent_warning: str = "#ff9800"      # Warning (orange)
    accent_error: str = "#f44336"        # Error (red)
    accent_success: str = "#4caf50"      # Success (green)

    # DAW-specific
    track_bg: str = "#2a2a2a"            # Track background
    clip_bg: str = "#3a5f3a"             # Clip body
    clip_selected: str = "#4a7f4a"       # Selected clip
    playhead: str = "#ffffff"            # Playhead line
    grid_line: str = "#333333"           # Grid lines
    grid_bar: str = "#444444"            # Bar grid lines
    waveform: str = "#81c784"            # Waveform color
    midi_note: str = "#66bb6a"           # MIDI note fill
    automation: str = "#ff9800"          # Automation curve
    meter_green: str = "#4caf50"         # VU meter green
    meter_yellow: str = "#ff9800"        # VU meter yellow
    meter_red: str = "#f44336"           # VU meter red

    # Borders
    border: str = "#444444"              # Standard border
    border_focus: str = "#4fc3f7"        # Focus ring
    border_subtle: str = "#333333"       # Subtle separator

    # Scrollbar
    scrollbar_bg: str = "#1a1a1a"
    scrollbar_handle: str = "#555555"
    scrollbar_hover: str = "#777777"

    def to_dict(self) -> Dict[str, str]:
        """Export all colors as dict."""
        return {k: v for k, v in self.__dict__.items() if isinstance(v, str)}

    @staticmethod
    def from_dict(data: Dict[str, str]) -> ThemePalette:
        """Create palette from dict (partial override allowed)."""
        palette = ThemePalette()
        for key, val in data.items():
            if hasattr(palette, key) and isinstance(val, str):
                setattr(palette, key, val)
        return palette


# ---------------------------------------------------------------------------
# Theme definition
# ---------------------------------------------------------------------------

@dataclass
class Theme:
    """Complete theme definition."""
    name: str = "Dark"
    author: str = "Py_DAW"
    description: str = ""
    version: str = "1.0"
    palette: ThemePalette = field(default_factory=ThemePalette)
    font_family: str = "Segoe UI, Roboto, sans-serif"
    font_size: int = 12
    font_size_small: int = 10
    font_size_large: int = 14
    border_radius: int = 4
    is_dark: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name, "author": self.author,
            "description": self.description, "version": self.version,
            "is_dark": self.is_dark,
            "font_family": self.font_family,
            "font_size": self.font_size,
            "border_radius": self.border_radius,
            "palette": self.palette.to_dict(),
        }

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> Theme:
        theme = Theme()
        for key in ("name", "author", "description", "version",
                     "font_family", "is_dark"):
            if key in data:
                setattr(theme, key, data[key])
        for key in ("font_size", "font_size_small", "font_size_large",
                     "border_radius"):
            if key in data:
                setattr(theme, key, int(data[key]))
        if "palette" in data and isinstance(data["palette"], dict):
            theme.palette = ThemePalette.from_dict(data["palette"])
        return theme


# ---------------------------------------------------------------------------
# Built-in themes
# ---------------------------------------------------------------------------

def _theme_dark() -> Theme:
    return Theme(
        name="Dark", author="Py_DAW",
        description="Standard-Dunkelthema (Default)",
        is_dark=True,
        palette=ThemePalette(),  # defaults are dark
    )


def _theme_light() -> Theme:
    return Theme(
        name="Light", author="Py_DAW",
        description="Helles Thema für Tageslicht-Arbeitsplätze",
        is_dark=False,
        palette=ThemePalette(
            bg_primary="#f5f5f5", bg_secondary="#e8e8e8",
            bg_tertiary="#ffffff", bg_hover="#d0d0d0",
            bg_selected="#bbdefb", bg_header="#e0e0e0",
            fg_primary="#212121", fg_secondary="#616161",
            fg_muted="#9e9e9e", fg_accent="#1976d2",
            accent_primary="#1976d2", accent_secondary="#388e3c",
            accent_warning="#f57c00", accent_error="#d32f2f",
            accent_success="#388e3c",
            track_bg="#e0e0e0", clip_bg="#c8e6c9",
            clip_selected="#a5d6a7", playhead="#000000",
            grid_line="#d0d0d0", grid_bar="#bdbdbd",
            waveform="#2e7d32", midi_note="#43a047",
            automation="#ef6c00",
            meter_green="#43a047", meter_yellow="#f57c00",
            meter_red="#d32f2f",
            border="#bdbdbd", border_focus="#1976d2",
            border_subtle="#e0e0e0",
            scrollbar_bg="#e0e0e0", scrollbar_handle="#9e9e9e",
            scrollbar_hover="#757575",
        ),
    )


def _theme_midnight() -> Theme:
    return Theme(
        name="Midnight", author="Py_DAW",
        description="Tiefes Blau-Schwarz — ideal für Studio-Umgebungen",
        is_dark=True,
        palette=ThemePalette(
            bg_primary="#0d1117", bg_secondary="#161b22",
            bg_tertiary="#21262d", bg_hover="#30363d",
            bg_selected="#1f3a5f", bg_header="#010409",
            fg_primary="#e6edf3", fg_secondary="#8b949e",
            fg_muted="#484f58", fg_accent="#58a6ff",
            accent_primary="#58a6ff", accent_secondary="#3fb950",
            accent_warning="#d29922", accent_error="#f85149",
            accent_success="#3fb950",
            track_bg="#161b22", clip_bg="#1f3a2f",
            clip_selected="#2d5f3f", playhead="#f0f6fc",
            grid_line="#21262d", grid_bar="#30363d",
            waveform="#3fb950", midi_note="#56d364",
            automation="#d29922",
            border="#30363d", border_focus="#58a6ff",
            border_subtle="#21262d",
            scrollbar_bg="#0d1117", scrollbar_handle="#30363d",
            scrollbar_hover="#484f58",
        ),
    )


def _theme_solarized_dark() -> Theme:
    return Theme(
        name="Solarized Dark", author="Ethan Schoonover (adaptiert)",
        description="Solarized-Farbschema — augenschonend",
        is_dark=True,
        palette=ThemePalette(
            bg_primary="#002b36", bg_secondary="#073642",
            bg_tertiary="#0a3f4e", bg_hover="#1a5060",
            bg_selected="#1a4a5a", bg_header="#001e26",
            fg_primary="#fdf6e3", fg_secondary="#93a1a1",
            fg_muted="#586e75", fg_accent="#268bd2",
            accent_primary="#268bd2", accent_secondary="#859900",
            accent_warning="#cb4b16", accent_error="#dc322f",
            accent_success="#859900",
            track_bg="#073642", clip_bg="#2a5a3a",
            clip_selected="#3a7a4a", playhead="#fdf6e3",
            grid_line="#0a3f4e", grid_bar="#1a5060",
            waveform="#859900", midi_note="#b58900",
            automation="#cb4b16",
            border="#586e75", border_focus="#268bd2",
            border_subtle="#073642",
            scrollbar_bg="#002b36", scrollbar_handle="#586e75",
            scrollbar_hover="#657b83",
        ),
    )


def _theme_high_contrast() -> Theme:
    return Theme(
        name="High Contrast", author="Py_DAW",
        description="Maximaler Kontrast — Barrierefreiheit",
        is_dark=True,
        palette=ThemePalette(
            bg_primary="#000000", bg_secondary="#1a1a1a",
            bg_tertiary="#2a2a2a", bg_hover="#444444",
            bg_selected="#004488", bg_header="#000000",
            fg_primary="#ffffff", fg_secondary="#dddddd",
            fg_muted="#888888", fg_accent="#00ccff",
            accent_primary="#00ccff", accent_secondary="#00ff88",
            accent_warning="#ffcc00", accent_error="#ff3333",
            accent_success="#00ff88",
            track_bg="#1a1a1a", clip_bg="#003300",
            clip_selected="#005500", playhead="#ffffff",
            grid_line="#333333", grid_bar="#555555",
            waveform="#00ff88", midi_note="#00ffaa",
            automation="#ffcc00",
            border="#666666", border_focus="#00ccff",
            border_subtle="#333333",
            scrollbar_bg="#000000", scrollbar_handle="#666666",
            scrollbar_hover="#999999",
        ),
    )


BUILTIN_THEMES: Dict[str, Theme] = {
    "dark": _theme_dark(),
    "light": _theme_light(),
    "midnight": _theme_midnight(),
    "solarized_dark": _theme_solarized_dark(),
    "high_contrast": _theme_high_contrast(),
}


# ---------------------------------------------------------------------------
# Stylesheet generator
# ---------------------------------------------------------------------------

def generate_stylesheet(theme: Theme) -> str:
    """Generate a complete Qt stylesheet from a Theme."""
    p = theme.palette
    r = theme.border_radius
    fs = theme.font_size
    ff = theme.font_family

    return f"""
/* Py_DAW Theme: {theme.name} — Auto-generated */

* {{
    font-family: {ff};
    font-size: {fs}px;
}}

QMainWindow, QWidget {{
    background-color: {p.bg_primary};
    color: {p.fg_primary};
}}

QDockWidget {{
    background-color: {p.bg_secondary};
    titlebar-close-icon: none;
    titlebar-normal-icon: none;
}}

QDockWidget::title {{
    background: {p.bg_header};
    padding: 4px 8px;
    font-weight: bold;
}}

QMenuBar {{
    background: {p.bg_header};
    color: {p.fg_primary};
    border-bottom: 1px solid {p.border};
}}

QMenuBar::item:selected {{
    background: {p.bg_hover};
}}

QMenu {{
    background: {p.bg_secondary};
    color: {p.fg_primary};
    border: 1px solid {p.border};
    border-radius: {r}px;
}}

QMenu::item:selected {{
    background: {p.bg_selected};
}}

QToolBar {{
    background: {p.bg_header};
    border: none;
    spacing: 2px;
}}

QPushButton {{
    background: {p.bg_tertiary};
    color: {p.fg_primary};
    border: 1px solid {p.border};
    border-radius: {r}px;
    padding: 4px 12px;
    min-height: 20px;
}}

QPushButton:hover {{
    background: {p.bg_hover};
    border-color: {p.border_focus};
}}

QPushButton:pressed {{
    background: {p.bg_selected};
}}

QPushButton:disabled {{
    color: {p.fg_muted};
    background: {p.bg_primary};
}}

QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
    background: {p.bg_tertiary};
    color: {p.fg_primary};
    border: 1px solid {p.border};
    border-radius: {r}px;
    padding: 3px 6px;
}}

QLineEdit:focus, QSpinBox:focus, QComboBox:focus {{
    border-color: {p.border_focus};
}}

QComboBox::drop-down {{
    border: none;
    width: 20px;
}}

QListWidget, QTreeWidget, QTableWidget {{
    background: {p.bg_tertiary};
    color: {p.fg_primary};
    border: 1px solid {p.border};
    alternate-background-color: {p.bg_secondary};
}}

QListWidget::item:selected, QTreeWidget::item:selected {{
    background: {p.bg_selected};
}}

QListWidget::item:hover, QTreeWidget::item:hover {{
    background: {p.bg_hover};
}}

QTabWidget::pane {{
    border: 1px solid {p.border};
    background: {p.bg_secondary};
}}

QTabBar::tab {{
    background: {p.bg_tertiary};
    color: {p.fg_secondary};
    border: 1px solid {p.border};
    padding: 4px 12px;
    border-top-left-radius: {r}px;
    border-top-right-radius: {r}px;
}}

QTabBar::tab:selected {{
    background: {p.bg_secondary};
    color: {p.fg_primary};
    border-bottom: 2px solid {p.accent_primary};
}}

QScrollBar:vertical {{
    background: {p.scrollbar_bg};
    width: 10px;
    margin: 0;
}}

QScrollBar::handle:vertical {{
    background: {p.scrollbar_handle};
    min-height: 30px;
    border-radius: 5px;
}}

QScrollBar::handle:vertical:hover {{
    background: {p.scrollbar_hover};
}}

QScrollBar:horizontal {{
    background: {p.scrollbar_bg};
    height: 10px;
}}

QScrollBar::handle:horizontal {{
    background: {p.scrollbar_handle};
    min-width: 30px;
    border-radius: 5px;
}}

QScrollBar::add-line, QScrollBar::sub-line {{
    height: 0; width: 0;
}}

QSlider::groove:horizontal {{
    background: {p.bg_tertiary};
    height: 4px;
    border-radius: 2px;
}}

QSlider::handle:horizontal {{
    background: {p.accent_primary};
    width: 14px;
    height: 14px;
    margin: -5px 0;
    border-radius: 7px;
}}

QProgressBar {{
    background: {p.bg_tertiary};
    border: 1px solid {p.border};
    border-radius: {r}px;
    text-align: center;
    color: {p.fg_primary};
}}

QProgressBar::chunk {{
    background: {p.accent_primary};
    border-radius: {r}px;
}}

QToolTip {{
    background: {p.bg_header};
    color: {p.fg_primary};
    border: 1px solid {p.border};
    padding: 4px;
}}

QStatusBar {{
    background: {p.bg_header};
    color: {p.fg_secondary};
    border-top: 1px solid {p.border};
}}

QLabel {{
    color: {p.fg_primary};
}}

QGroupBox {{
    border: 1px solid {p.border};
    border-radius: {r}px;
    margin-top: 12px;
    padding-top: 16px;
    font-weight: bold;
}}

QGroupBox::title {{
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
    color: {p.fg_accent};
}}

QTextEdit, QPlainTextEdit {{
    background: {p.bg_tertiary};
    color: {p.fg_primary};
    border: 1px solid {p.border};
    border-radius: {r}px;
    selection-background-color: {p.bg_selected};
}}

QCheckBox::indicator, QRadioButton::indicator {{
    width: 16px;
    height: 16px;
}}

QSplitter::handle {{
    background: {p.border_subtle};
}}

QSplitter::handle:hover {{
    background: {p.accent_primary};
}}
"""


# ---------------------------------------------------------------------------
# Theme Manager Service
# ---------------------------------------------------------------------------

class ThemeManager(QObject):
    """Manages theme loading, switching, and custom themes.

    Usage:
        mgr = ThemeManager()
        mgr.set_theme("midnight")  # built-in
        mgr.load_custom_theme("/path/to/my_theme.yaml")
    """

    theme_changed = pyqtSignal(str)  # theme name

    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_theme: Theme = _theme_dark()
        self._custom_themes: Dict[str, Theme] = {}
        self._theme_dirs: List[str] = [
            str(Path.home() / ".pydaw" / "themes"),
        ]
        self._settings = QSettings("ChronoScaleStudio", "PyDAW")

    @property
    def current_theme(self) -> Theme:
        return self._current_theme

    def get_available_themes(self) -> Dict[str, str]:
        """Return dict of theme_key → display_name."""
        result = {k: t.name for k, t in BUILTIN_THEMES.items()}
        for k, t in self._custom_themes.items():
            result[k] = f"{t.name} (Custom)"
        return result

    def set_theme(self, theme_key: str) -> bool:
        """Switch to a theme by key. Returns True on success."""
        theme = BUILTIN_THEMES.get(theme_key) or self._custom_themes.get(theme_key)
        if theme is None:
            log.warning("Theme nicht gefunden: %s", theme_key)
            return False

        self._current_theme = theme
        self._apply_theme(theme)
        self._settings.setValue("theme", theme_key)

        try:
            self.theme_changed.emit(theme_key)
        except Exception:
            pass

        log.info("Theme gewechselt: %s", theme.name)
        return True

    def load_custom_theme(self, file_path: str) -> Optional[Theme]:
        """Load a custom theme from a YAML file."""
        try:
            text = Path(file_path).read_text(encoding="utf-8")

            # Try YAML first, then JSON
            data = None
            try:
                import yaml  # type: ignore
                data = yaml.safe_load(text)
            except ImportError:
                pass

            if data is None:
                import json
                data = json.loads(text)

            if not isinstance(data, dict):
                return None

            theme = Theme.from_dict(data)
            key = Path(file_path).stem.lower().replace(" ", "_")
            self._custom_themes[key] = theme
            log.info("Custom Theme geladen: %s von %s", theme.name, file_path)
            return theme

        except Exception as exc:
            log.error("Theme laden fehlgeschlagen: %s — %s", file_path, exc)
            return None

    def scan_theme_dirs(self) -> int:
        """Scan theme directories for .yaml/.json theme files."""
        count = 0
        for theme_dir in self._theme_dirs:
            if not os.path.isdir(theme_dir):
                continue
            for fname in os.listdir(theme_dir):
                if fname.endswith((".yaml", ".yml", ".json")):
                    fpath = os.path.join(theme_dir, fname)
                    if self.load_custom_theme(fpath):
                        count += 1
        return count

    def save_theme(self, theme: Theme, file_path: str) -> bool:
        """Save a theme to a YAML file."""
        try:
            data = theme.to_dict()
            Path(file_path).parent.mkdir(parents=True, exist_ok=True)

            try:
                import yaml  # type: ignore
                text = yaml.dump(data, default_flow_style=False, allow_unicode=True)
            except ImportError:
                import json
                text = json.dumps(data, indent=2, ensure_ascii=False)

            Path(file_path).write_text(text, encoding="utf-8")
            return True
        except Exception as exc:
            log.error("Theme speichern fehlgeschlagen: %s", exc)
            return False

    def restore_saved_theme(self) -> None:
        """Restore the previously saved theme from QSettings."""
        key = self._settings.value("theme", "dark")
        if isinstance(key, str):
            self.set_theme(key)

    def get_palette(self) -> ThemePalette:
        """Return current theme's palette for direct access."""
        return self._current_theme.palette

    def _apply_theme(self, theme: Theme) -> None:
        """Apply theme stylesheet to the application."""
        app = QApplication.instance()
        if app is None:
            return

        stylesheet = generate_stylesheet(theme)
        try:
            app.setStyleSheet(stylesheet)
        except Exception as exc:
            log.error("Stylesheet anwenden fehlgeschlagen: %s", exc)
