# Session Log — v0.0.20.842

**Datum:** 2026-03-27
**Kollege:** Claude Opus 4.6
**Basis:** v0.0.20.841
**Aufgabe:** Surge XT Aenderungen v839-841 rollback — nichts kaputt machen

## Was passiert ist

Seit v0.0.20.831 (3 Tage) haben mehrere Kollegen versucht den Surge XT
CLAP Editor auf Linux/X11 zu fixen:

- v831-837 (GPT-5.4): VST3-Surrogate-Shell, Overlay, Size-Stabilisierung
- v839 (Claude): Frameless Shell → doppelter Rahmen weg, aber Editor sitzt falsch
- v840 (Claude): VST3-Blob skip → Parameter-Snapshot, aber VST3 Names != CLAP Names
- v841 (Claude): VST3-Surrogate komplett deaktiviert → CLAP-Helper, aber GUI erscheint nicht

Keiner dieser Ansaetze hat das Grundproblem geloest:
**Surge XT CLAP GUI auf Linux/X11 blockiert oder zeigt nicht richtig an.**

## Entscheidung

**Rollback auf v837-Stand fuer fx_device_widgets.py.**
Die Ghost Notes Logger Fixes (v838) bleiben erhalten.
Surge XT Editor funktioniert wie in v837 — nicht perfekt, aber stabil.

## Geaenderte Dateien

- pydaw/ui/fx_device_widgets.py → v837 wiederhergestellt
- VERSION → 0.0.20.842
- pydaw/version.py → 0.0.20.842

## Was funktioniert in v842

- Ghost Notes Dialog: Clips laden korrekt (v838 Fix)
- Nekobi CLAP Editor: inline, funktioniert
- Dexed VST2 Editor: funktioniert mit Ton
- Surge XT CLAP: Audio/DSP funktioniert, VST3-Surrogate-Shell oeffnet sich
- Surge XT Preset-Wechsel: aendern NICHT den Ton (bekanntes Problem seit v831)

## Naechste Schritte (fuer kuenftigen Kollegen)

Das Surge XT Problem braucht einen fundamentalen neuen Ansatz:
1. Direkte CLAP GUI in-process (show_detached_gui) zum Laufen bringen
2. Oder: Carla-Bridge als externen Editor-Host nutzen
3. Oder: Surge XT Preset-Wechsel rein ueber CLAP-State-API (ohne GUI)
