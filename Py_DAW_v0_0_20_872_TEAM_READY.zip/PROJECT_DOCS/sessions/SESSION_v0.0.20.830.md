# Session Log — v0.0.20.830

**Datum:** 2026-03-26
**Kollege:** OpenAI GPT-5.4 Thinking
**Basis:** v0.0.20.829
**Aufgabe:** Surge XT CLAP Editor oeffnet nicht unter Linux/X11

## Beobachtung in v0.0.20.829

1. **CLAP-Synth selbst lief** — `Loaded Instrument ... params=775`, `Created NEW engine`, `Pull source ...` bestaetigten funktionierendes CLAP-Audio.
2. **GUI-Erkennung war positiv** — `Plugin found, has_gui=True`.
3. **Der externe CLAP-GUI-Helper war der Engpass** — nach `Using detached helper process for Surge XT on Linux/X11` kam kein erfolgreicher Ready/Open-Handshake.
4. **Widget-Rebuilds zerstoerten den laufenden Helper** — `QProcess: Destroyed while process ... is still running` plus `QLabel/QPushButton has been deleted`.

## Fix in v0.0.20.830

### 1. Surge XT CLAP nutzt jetzt einen VST3-Surrogate-Editor ✅

- Fuer `org.surge-synth-team.surge-xt` unter Linux/X11 wird jetzt bevorzugt
  `pydaw/audio/vst_gui_process.py` mit `/usr/lib/vst3/Surge XT.vst3` gestartet.
- Der Audio/DSP-Pfad bleibt **weiter CLAP**. Es wird nur der Editor ersetzt.
- Wenn kein passender VST3-Bundle gefunden wird, bleibt der bisherige CLAP-Helper der Fallback.

### 2. Initial-Sync per Parameterwerten statt CLAP-State ✅

- Nach dem `ready`-Event schickt die DAW nur die aktuell vom Live-CLAP abweichenden Parameter an den Surrogate-Editor.
- Rueckrichtung bleibt ueber `param`-Events aktiv, sodass Editor-Aenderungen den live laufenden CLAP-Synth aktualisieren.
- VST3-State-Blobs des Surrogate-Editors werden absichtlich **nicht** in CLAP geladen; es wird bewusst nur ueber Parameter synchronisiert.

### 3. QProcess-/Widget-Haertung ✅

- Externe Editor-Prozesse werden jetzt **parent-los** gestartet und in `_active_editor_threads` registriert.
- Button-/Status-Updates sind gegen geloeschte Qt-Objekte abgesichert.
- Beim Close/Finish wird der Registry-Eintrag wieder aufgeraeumt.

## Geaenderte Dateien

- `pydaw/ui/fx_device_widgets.py` — Surge-XT-CLAP startet VST3-Surrogate-Editor, Initial-Parameter-Sync, parent-loser QProcess, sichere UI-Callbacks
- `VERSION` → `0.0.20.830`
- `pydaw/version.py` → `0.0.20.830`
- `CHANGELOG.md`, `PROJECT_DOCS/progress/TODO.md`, `PROJECT_DOCS/progress/DONE.md`, `PROJECT_DOCS/sessions/LATEST.md`

## Verifikation

- `python3 -m py_compile pydaw/ui/fx_device_widgets.py` ✅
- kompletter `py_compile`-Lauf ueber `pydaw/` → **360 Dateien OK** ✅

## Erwartetes Ergebnis

- **Surge XT CLAP**: spielt wie bisher, Editor oeffnet ueber den VST3-Surrogate-Pfad stabiler
- **Andere CLAP-Plugins**: bleiben auf ihrem bisherigen nativen CLAP-Editorpfad
- **Keine DSP-Mehrkosten**: nur die Editor-GUI laeuft extern, Audio bleibt im CLAP-Host
