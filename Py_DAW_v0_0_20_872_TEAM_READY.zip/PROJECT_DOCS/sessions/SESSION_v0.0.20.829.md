# Session Log — v0.0.20.829

**Datum:** 2026-03-26
**Kollege:** Claude Opus 4.6
**Basis:** v0.0.20.828
**Aufgabe:** VST3 Instrument-Erkennung + Ton-Regression Fix

## Probleme in v0.0.20.828

1. **Blanket VST3 Deferral** — v0.0.20.828 schob ALLE VST3-Instrumente
   zum Main-Thread (preemptive defer). Aber nur Surge XT braucht das.
   Nekobi, LSP etc. laden normal auf jedem Thread.

2. **Nekobi kein Instrument-Symbol** — `is_vst_instrument()` lud das Plugin
   via pedalboard um `is_instrument` zu prüfen. Wenn das fehlschlägt
   (z.B. "main thread" Error), wurde False zurückgegeben → kein Symbol.

3. **Kein Ton bei VST3** — Weil alle VST3 deferred wurden UND der
   Main-Thread-Load für Surge XT fehlschlug, gab es keine funktionierenden
   VST3-Instrument-Engines.

## Fixes

### 1. Blanket VST3 Deferral entfernt ✅

Die pauschale Zeile `if (not _is_clap) and (not _is_vst2): defer` wurde
entfernt. VST3-Plugins laden jetzt wieder normal auf dem Worker-Thread.
Nur bei tatsächlichem "main thread" Fehler wird zum Main-Thread deferred
(v0.0.20.820 Logik bleibt erhalten).

### 2. is_vst_instrument() verbessert ✅

- **Known-Instruments-Liste**: Surge XT, Nekobi, Dexed, Vital, Helm,
  ZynAddSubFX, Yoshimi, amsynth etc. werden sofort als Instrument erkannt
  ohne pedalboard laden zu müssen.
- **Main-Thread-Fehler = Instrument**: Wenn `load_plugin()` mit
  "main thread" Error fehlschlägt, wird `True` zurückgegeben (cached).
  Plugins die Main-Thread brauchen sind fast immer Instrumente.

### 3. Debug-Logging in _finalize_rebuild ✅

Thread-Identity wird geloggt (`is_main=True/False`) um zu verifizieren
dass der deferred Load tatsächlich auf dem Main-Thread läuft.

## Geänderte Dateien

- pydaw/audio/audio_engine.py — Blanket defer entfernt, Thread-Logging
- pydaw/audio/vst3_host.py — Known-instruments, main-thread=instrument
- VERSION → 0.0.20.829, pydaw/version.py → 0.0.20.829

## Erwartetes Ergebnis

- Nekobi: Instrument-Symbol ✓, Ton ✓ (lädt normal auf Worker)
- Surge XT VST3: Deferred auf Main-Thread (nur bei Fehler), Ton ✓
- LSP/andere VST3 FX: Laden normal, nicht betroffen
- Dexed VST2: Wie bisher, Ton ✓
- Surge XT CLAP: Wie bisher (eigener Pfad)
