# Session v0.0.20.827 — Surge XT CLAP Helper Path Fix

## Ausgangslage

Der neue Out-of-Process-Editorpfad für Surge XT aus `v0.0.20.826` startete, der Helper-Prozess
konnte das Plugin aber nicht laden. Im Log stand:

- `CLAP load failed: dlopen failed: /usr/lib/clap/Surge XT.clap::org.surge-synth-team.surge-xt`

Damit war klar, dass nicht Surge XT selbst fehlte, sondern dass der Helper einen kombinierten
Referenzstring statt eines echten Dateipfads an `dlopen()` weitergereicht bekam.

## Was wurde erledigt

- Übergabe an den Surge-XT-Helper korrigiert: `path::plugin_id` wird vor dem Start sauber getrennt
- Helper zusätzlich gehärtet: kombiniert übergebene Referenzen werden intern ebenfalls getrennt
- Versionsnummer auf `0.0.20.827` erhöht

## Geänderte Dateien

- `pydaw/ui/fx_device_widgets.py`
- `pydaw/audio/clap_gui_process.py`
- `pydaw/version.py`
- `VERSION`
- `CHANGELOG_v0.0.20.827_SURGE_XT_CLAP_OOP_PATH_FIX.md`
- `PROJECT_DOCS/sessions/SESSION_v0.0.20.827.md`
- `PROJECT_DOCS/sessions/LATEST.md`

## Tests

- `python3 -m py_compile pydaw/ui/fx_device_widgets.py pydaw/audio/clap_gui_process.py`
- kompletter `py_compile`-Lauf über `pydaw/`

## Nächste Schritte

- Surge XT CLAP erneut öffnen
- prüfen, ob jetzt das externe Surge-Fenster wirklich erscheint
- danach Parameter-Sync und Close/Reopen verifizieren
