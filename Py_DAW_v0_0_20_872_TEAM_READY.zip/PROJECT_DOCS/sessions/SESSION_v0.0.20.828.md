# Session v0.0.20.828 — VST3 Instrument Main-Thread Deferral

## Ausgangslage

Nach `v0.0.20.827` liess sich der **Surge XT CLAP**-Helper zwar sauber starten, aber bei
**VST3-Instrumenten** blieb das Kernproblem bestehen:

- `Surge XT.vst3` und `Nekobi.vst3` meldeten wiederholt
  `must be reloaded on the main thread`
- die Rebuild-Logik startete daraufhin Retry-Versuche aus dem Worker-Kontext
- dadurch entstanden `QBasicTimer::start`-Warnungen, spuerbare Ladeverzoegerungen und
  am Ende oft **stille VST3-Instrumente**, obwohl der Editor bereits sichtbar war

## Was wurde erledigt

- VST3-Instrumente werden jetzt **vor dem ersten Load** direkt fuer den Qt-Main-Thread markiert
- der Rebuild-Worker fasst diese Plugins nicht mehr zuerst an
- worker-seitige Retry-Timer fuer diese Kandidaten wurden entfernt
- `_finalize_rebuild()` uebernimmt den Main-Thread-Load, registriert SamplerRegistry + Pull-Source
  und fordert danach den benoetigten Stream-Update an
- Versionsnummer auf `0.0.20.828` erhoeht

## Geaenderte Dateien

- `pydaw/audio/audio_engine.py`
- `pydaw/version.py`
- `VERSION`
- `CHANGELOG.md`
- `CHANGELOG_v0.0.20.828_VST3_MAINTHREAD_PREEMPTIVE_DEFER.md`
- `PROJECT_DOCS/progress/TODO.md`
- `PROJECT_DOCS/progress/DONE.md`
- `PROJECT_DOCS/sessions/SESSION_v0.0.20.828.md`
- `PROJECT_DOCS/sessions/LATEST.md`

## Tests

- `python3 -m py_compile pydaw/audio/audio_engine.py`
- kompletter `py_compile`-Lauf ueber `pydaw/`

## Naechste Schritte

- Surge XT.vst3 und Nekobi.vst3 erneut als Instrument laden
- pruefen: Sound da, Editor oeffnet, Reopen sauber, keine Main-Thread-Retry-Stuerm mehr
- danach erst kosmetische Punkte wie Symbol-/Badge-Darstellung nachziehen
