# Session Log — v0.0.20.822

**Datum:** 2026-03-26
**Kollege:** Claude Opus 4.6
**Basis:** v0.0.20.821
**Aufgabe:** CLAP Editor Auto-Fix (WAYLAND_DISPLAY), Takte 1–999

## Was wurde erledigt

### CLAP Editor Wayland Auto-Fix ✅

**Root Cause:** `main.py` setzte `QT_QPA_PLATFORM=xcb` (Qt über XWayland),
ließ aber `WAYLAND_DISPLAY` stehen. JUCE in Surge XT CLAP sah `WAYLAND_DISPLAY`,
versuchte eine direkte Wayland-Verbindung → Deadlock in `gui_ext.create()`.

**Fix:** `main.py` löscht jetzt auch `WAYLAND_DISPLAY` bevor Qt/Plugins laden.
- Qt nutzt X11 über XWayland (via `DISPLAY` Variable) 
- JUCE-Plugins sehen kein Wayland mehr → nutzen X11 → kein Deadlock
- Audio/RT/Rust arbeiten display-unabhängig → nicht betroffen
- Alles passiert automatisch, kein manueller Eingriff nötig

**Log-Ausgabe jetzt:**
```
[PyDAW] Wayland detected — forcing X11 mode 
(QT_QPA_PLATFORM=xcb, WAYLAND_DISPLAY cleared) 
for native plugin editor compatibility
```

**Zusätzliche Sicherheitsnetze (bleiben erhalten):**
- Staged GUI Creation (3-Stufen QTimer) in fx_device_widgets.py
- XWayland QMessageBox Fallback (falls WAYLAND_DISPLAY irgendwie gesetzt bleibt)

### Takte-Limit auf 999 erweitert ✅

Drei SpinBoxes von `setRange(1, 64)` auf `setRange(1, 999)`:
- KI-Assistent, Device-Editor, Orchestrator

## Geänderte Dateien

- main.py — WAYLAND_DISPLAY auto-clear bei Wayland-Erkennung
- pydaw/ui/fx_device_widgets.py — XWayland Fallback + Bars 999
- pydaw/ui/ki_assistant_panel.py — Bars 999
- pydaw/ui/orchestrator_dialog.py — Bars 999
- pydaw/audio/clap_host.py — Staged GUI + process_events
- VERSION → 0.0.20.822
