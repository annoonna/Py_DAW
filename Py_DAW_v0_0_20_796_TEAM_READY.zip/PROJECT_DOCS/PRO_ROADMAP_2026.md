# 🎵 Py_DAW PRO ROADMAP 2026–2027
## Weg zur Open-Source-Referenz-DAW mit KI-Superpowers

**Projekt:** Py_DAW (ChronoScaleStudio)
**Vision:** Professionelle DAW auf Ableton/Bitwig/Cubase-Niveau — Open Source, Linux-first,
Python-scriptbar, mit KI-Features die andere DAWs nicht haben.
**Erstellt:** 2026-03-23 (v0.0.20.744)
**Autor:** Anno (Lead Developer) + Claude Sonnet 4.6

---

## ⚠️ OBERSTE DIREKTIVE — FÜR ALLE KOLLEGEN

```
🔴 DU DARFST NICHTS KAPUTT MACHEN. DAS IST DIE OBERSTE DIREKTIVE.
🔴 Alle bestehenden Features müssen nach deiner Arbeit funktionieren.
🔴 Teste IMMER mit: python3 -c "import py_compile; ..."
🔴 Im Zweifel: NICHT ändern. Dokumentieren und zurückgeben.
🔴 Jede Session: LATEST.md + CHANGELOG + TODO/DONE + ZIP
```

---

## 📊 AKTUELLER STAND (v0.0.20.744)

### Was funktioniert (produktionsreif)
- ✅ Arranger, Piano Roll, Notation Editor
- ✅ Mixer mit Send/Return, Sidechain, Routing-Matrix
- ✅ AETERNA Synth (Wavetable, FM, Unison, Mod-Matrix)
- ✅ Fusion Synth (Modularer Ansatz, Scrawl-Oszillator)
- ✅ Drum Machine (64 Pads, Choke Groups, Multi-Output)
- ✅ Advanced Sampler (Multi-Zone, Round-Robin, Filter+ADSR) — neu gefixt
- ✅ Built-in FX: EQ, Compressor, Reverb, Delay, Limiter, Chorus, Gate, etc.
- ✅ Automation (Breakpoint-Kurven, Write/Touch/Latch, Lanes)
- ✅ MIDI FX Chain (Arp, Chord, Scale, Echo, Velocity)
- ✅ Export: WAV/FLAC/MP3, Stems, DAWproject, Cloud-Backup
- ✅ Rust Audio-Engine (332 Tests, IPC-Bridge)
- ✅ VST3/CLAP/LV2 Plugin-Hosting
- ✅ GitHub CI/CD für Linux/macOS/Windows

### Was noch instabil ist (Late Alpha)
- ⚠️ Rust-Engine trennt sich bei jedem Start (EOF-Bug)
- ⚠️ Advanced Sampler Persistenz noch nicht vollständig getestet
- ⚠️ CLAP/LV2 Live-Noten noch nicht auf echter Hardware validiert
- ⚠️ A/B Test Python vs Rust Engine ausstehend

---

## 🗺️ ROADMAP-STRUKTUR

```
PHASE 0: Stabilisierung (Alpha → Beta)          ← JETZT DRINGEND
PHASE 1: Audio Recording Professional           ← Core DAW Feature
PHASE 2: KI-Komposition & Analyse              ← Alleinstellungsmerkmal
PHASE 3: KI-Mixing & Mastering                 ← Professionell + KI
PHASE 4: Performance & Live-Features           ← Ableton-Niveau
PHASE 5: Kollaboration & Cloud                 ← Zukunft
PHASE 6: Plugin-Ökosystem & Scripting         ← Open-Source-Power
PHASE 7: Video & Multimedia                    ← Über DAW hinaus
```

---

## 🔧 PHASE 0: Stabilisierung — Alpha → Beta
### Priorität: 🔴 KRITISCH — Vor allem anderen

**P0A — Rust-Engine-Disconnect fixen**
- [x] Root Cause: Warum trennt sich der Rust-Engine-Prozess nach ~1s?
      **GEFUNDEN: ScanPlugins blockiert synchron im Audio-RT-Callback!** *(v0.0.20.746)*
- [x] Fix: ScanPlugins asynchron, kein Blocking im IPC-Reader-Loop  *(v0.0.20.746 — pydaw_engine/src/engine.rs: Background-Thread)*
- [x] Fix: Auto-Reconnect mit Exponential Backoff (3 Versuche, dann Fallback auf Python)  *(v0.0.20.746 — rust_engine_bridge.py: _do_reconnect_with_backoff)*
- [ ] Test: `./start_daw.sh` → Engine bleibt verbunden → Ton nach 5 Minuten Play
      *(Rust-Quellcode gefixt, aber cargo build --release auf echter Hardware nötig)*

**P0B — Advanced Sampler Stabilisierung**
- [ ] Persistenz-Test: Zone laden → Projekt speichern → DAW neu starten → Zone noch da?
- [ ] Chromatic-Map-Test: 12 Samples laden → 12 Noten in Piano Roll → alle 12 klingen?
- [ ] Drum-Map-Test: GM-Drum-Samples → korrekte Note-Zuordnung C1/D1/E1 etc.
- [x] Scrawl-Envelope → tatsächlich auf Amp-Hüllkurve anwenden (Engine-Anbindung)  *(v0.0.20.746 — multisample_engine.py: _activate_voice + EnvState.step Scrawl-Pfad)*
- [x] Fix Persistenz-Flush: Piano-Roll Ctrl+S < 500ms → Zones auf Disk gerettet  *(v0.0.20.746 — project_service._flush_advanced_sampler_states)*
- [x] Fix Velocity-Empfang: Piano-Roll-Noten mit unterschiedlicher Velocity → Volume-Unterschied hörbar?  *(v0.0.20.752)*

**P0C — Rust Engine Live-Validierung**
- [ ] CLAP-Plugin (Surge XT): Laden → NoteOn → Ton → State speichern/laden
- [ ] LV2-Plugin (Calf Mono Synth): Laden → NoteOn → Ton
- [ ] A/B Vergleich: 8-Track-Projekt Python vs Rust → CPU%, Latenz, XRuns
- [ ] Performance: 20 Tracks simultan → kein XRun unter normaler Last

**P0D — Beta-Qualitätssicherung**
- [x] Smoke Test Suite: `python3 smoke_test.py` deckt P0A/P0B/P0D ab (6/6 Checks)  *(v0.0.20.746)*
- [x] Crash-Reporter: Unbehandelte Exceptions → benutzerfreundliche Fehlermeldung + Log  *(v0.0.20.746 — pydaw/app.py: _install_crash_reporter + sys.excepthook)*
- [x] First-Run-Experience: Leeres Projekt → Instrument hinzufügen → Note spielen → Ton (< 30 Sekunden)  *(v0.0.20.747 — first_run_dialog.py: 5-seitiger QWizard)*
- [x] CHANGELOG für v0.1.0-beta schreiben  *(v0.0.20.754)*

---

## 🎙️ PHASE 1: Audio Recording — Professionell
### Priorität: 🔴 HOCH — Jede DAW muss das können

**P1A — Recording-Workflow polieren**
- [x] Input-Monitoring: Echtzeit-Latenz < 10ms spürbar (ASIO-ähnlich via PipeWire)  *(v0.0.20.757)*
- [x] Waveform-Preview während Recording (live render während Aufnahme)  *(v0.0.20.751)*
- [x] Auto-Punch: Recording startet/stoppt automatisch an gesetzten Markern  *(v0.0.20.754)*
- [ ] Comping-Workflow: Loop-Recording → Take-Lanes → Bereiche auswählen → Flatten
      *(v0.0.20.796: Drag-Comp-Tool + flatten_comp() implementiert, Hardware-Test ausstehend)*
- [x] Clip-Gain Envelope: Lautstärke direkt auf Audio-Clip zeichnen (Pre-Fader)  *(v0.0.20.751)*

**P1B — Audio-Editing Professional**
- [ ] Pitch-Correction (Melodyne-ähnlich): Einzelne Noten in Audio korrigieren
      → Aubio/Essentia für Pitch-Detection + Rubberband für Correction
- [ ] Spectral Repair: FFT-Ansicht → manuelle Auswahl von Störgeräuschen → Remove
- [x] Fade-Kurven: Logarithmisch, Exponentiell, S-Kurve pro Clip-Kante  *(v0.0.20.751)*
- [x] Crossfade-Editor: Überlappende Clips → Crossfade-Typ wählen  *(v0.0.20.751)*

**P1C — Quantisierung & Timing**
- [ ] Audio-Quantisierung: Transientenbasiert → auf Grid snappen
- [ ] Swing-Quantisierung: Timing aus einer Groove-Datei anwenden
- [ ] Elastic Audio: Einzelne Transientenmarker ziehen → Sample-genaues Timing

---

## 🤖 PHASE 2: KI-Komposition & Analyse
### Priorität: 🟠 HOCH — Das Alleinstellungsmerkmal

**Diese Features hat keine andere Open-Source-DAW. Hier wird Py_DAW einzigartig.**

**P2A — KI-Kompositions-Assistent (Claude API Integration)**
- [x] `KI-Komponist` Panel: Natürliche Sprache → MIDI-Pattern  *(v0.0.20.747 — ki_assistant_panel.py: Dock-Widget, Quick Prompts, freier Prompt)*
      Beispiel: "Schreibe einen 8-Takt-Drum-Groove im 80er Synthpop-Stil, Swing 15%"
      → direkt in Piano Roll oder Drum Machine einfügen
- [x] Kontext-aware: KI "sieht" aktuelle Key, BPM, vorhandene Clips → passende Antwort  *(v0.0.20.747 — refresh_context() + set_selected_track_name() bei Track-Wechsel)*
- [x] MIDI-zu-Beschreibung: Existierendes Pattern → KI erklärt es ("Das ist ein Bossa Nova...")  *(v0.0.20.747 — Quick Prompt "🤔 Erkläre")*
- [ ] Variations-Generator: Clip auswählen → "Generiere 4 Variationen" → wählen
- [ ] Chord-Progression-AI: "Progressionen wie Radiohead" → Akkordfolge vorschlagen

**P2B — KI-Analyse & Empfehlungen**
- [ ] Mix-Analyse: "Was fehlt in diesem Mix?" → KI hört sich Audio an → konkrete Tipps
      ("Bässe kollidieren bei 80Hz, EQ-Empfehlung: Bass -3dB bei 80Hz")
- [ ] Genre-Detektion: Projekt analysieren → "Klingt nach Techno, Ähnlichkeit 78%"
- [ ] Reference Track Analyse: Referenz-WAV importieren → "Mein Mix klingt anders weil..."
- [ ] Harmonie-Analyse: Piano Roll → Akkorde erkennen → Tonart bestimmen → anzeigen
- [ ] Rhythmus-Analyse: Drum-Pattern → Groove-Charakteristika extrahieren → als Template

**P2C — KI-Melodie & Harmonik**
- [ ] Scale-Lock mit KI: Noten einzeichnen → KI schlägt nächste harmonisch sinnvolle Note vor
- [ ] Kontrapunkt-Assistent: Melodie eingeben → KI schreibt passendes Gegenstimme
- [ ] Bass-Line-Generator: Chord-Progression → Bassline-Vorschlag
- [ ] Lead-Synth-Generator: Akkorde + Rhythmus → Melodie-Vorschlag
- [ ] Motiv-Entwicklung: 2-Takt-Idee → KI entwickelt zu 8 Takten weiter

**P2D — KI-Preset & Sound-Design**
- [ ] Synth-Beschreibung → Preset: "Warmer 80er Pad mit langem Attack" → AETERNA-Preset
- [ ] Sound-Matching: Sample hochladen → "Finde ähnliche Einstellungen in AETERNA"
- [ ] Smart-Randomize: KI-gesteuerte Variation (nicht rein zufällig, musikalisch sinnvoll)
- [ ] Preset-Beschreibungs-Generator: Preset auswählen → KI beschreibt es in Worten

**P2E — Offline KI (kein API-Key nötig)**
- [ ] Kleines lokales Modell (Whisper-ähnlich für Musik) für Basis-Features
- [ ] Beat-Detection: Exakte Transientenanalyse ohne Cloud
- [ ] Chord-Recognition: Offline, <100ms Latenz
- [ ] Key-Detection: Automatisch beim Sample-Import

---

## 🎚️ PHASE 3: KI-Mixing & Mastering
### Priorität: 🟠 HOCH — Professionell + zukunftssicher

**P3A — Smart Mixer**
- [ ] Auto-Gain-Staging: Alle Tracks analysieren → Pegel auf -18 LUFS normalisieren
- [ ] Frequenz-Konflikt-Erkennung: Mixer zeigt welche Tracks bei welchen Frequenzen kollidieren
      → visuell in einer Heatmap, klickbar → EQ öffnet sich an der richtigen Frequenz
- [ ] Stereo-Bild-Analyse: "Track 3 und 5 kämpfen im mittleren Stereofeld" → Empfehlung
- [ ] Dynamik-Budget: Zeigt wie viel Headroom für Mastering bleibt

**P3B — KI-gestütztes Auto-Mixing**
- [ ] One-Click-Mix: "Misch dieses Projekt auf Podcast-Niveau" → automatisch
- [ ] Reference-Matching: Referenz-Track → Mix angleichen (LUFS, Frequenzspektrum, Stereo)
- [ ] Genre-Mix-Presets: "Mix wie Hip-Hop" → typische EQ/Comp-Einstellungen für Genre
- [ ] Stem-Separation (Demucs): Audio → Drums/Bass/Vocals/Other trennen → in Arranger

**P3C — Mastering Chain**
- [ ] Mastering-Wizard: Finale Stems → Integrated LUFS messen → Empfehlung anzeigen
- [ ] LUFS-Target: "Für Spotify -14 LUFS" → automatisch anpassen
- [ ] True-Peak-Limiter mit KI-gestütztem Release: kein Pumpen, kein Clippen
- [ ] Mastering-Vergleich: A/B zwischen Original und gemastertem Audio

---

## 🎭 PHASE 4: Performance & Live-Features
### Priorität: 🟡 MITTEL — Ableton-Niveau

**P4A — Clip Launcher Professional (Ableton Session View)**
- [ ] Scene-Launch: Ganze Reihen gleichzeitig launchen
- [ ] Follow Actions: Clip X → nach N Takten → automatisch Clip Y
- [ ] MIDI-Mapping für Launchpad/APC40: direktes Hardware-Mapping
- [ ] Capture MIDI: Was ich gerade gespielt habe → in Clip umwandeln
- [ ] Live-Performance-Modus: Vollbild, große Buttons, Touch-optimiert

**P4B — Hardware-Integration**
- [ ] MIDI-Controller Auto-Configuration: Akai APC, Novation Launchpad, Push erkannt → sofort spielbar
- [ ] CV/Gate Unterstützung (über MIDI-to-CV): Modularsystem anbinden
- [ ] OSC-Protokoll: TouchOSC, Lemur → Py_DAW steuern
- [ ] Gamepad-Support: Xbox/PS-Controller als Instrument

**P4C — Live-Audio-Manipulation**
- [ ] Stutter-Effekt: Live-Buffer → choppable, reversierbar, pitch-shiftbar in Echtzeit
- [ ] Live-Looper: Like Ableton Looper — Record → Overdub → Play → Stop
- [ ] Beat-Repeat: Automatische rhythmische Wiederholungen (wie Ableton Beat Repeat)

---

## 🤝 PHASE 5: Kollaboration & Cloud
### Priorität: 🟡 MITTEL — Zukunft

**P5A — Echtzeit-Kollaboration (einzigartig in Open Source)**
- [ ] WebSocket-basiertes Collaborative Editing: 2 User → selbes Projekt → live sync
- [ ] Git-Integration: Projekt-Versionen wie Code → Branch, Merge, Diff
- [ ] Session-Share: Link generieren → Freund kann Projekt in Browser ansehen/kommentieren
- [ ] Review-Mode: Mixer-Einstellungen kommentieren, Marker setzen, Aufgaben zuweisen

**P5B — Cloud-Projekt-Management**
- [ ] Py_DAW Cloud (optional, self-hostbar): Projekte speichern, teilen, backup
- [ ] Sample-Cloud: Eigene Samples hochladen → von anderen Computern zugreifbar
- [ ] Preset-Cloud: Community-Presets für AETERNA, Fusion, Sampler
- [ ] Kollektions-Browser: "Zeig mir alle Community-Presets für Funk-Bass"

---

## 🔌 PHASE 6: Plugin-Ökosystem & Scripting
### Priorität: 🟡 MITTEL — Open-Source-Power

**P6A — Python-Scripting API (Einzigartig!)**
- [ ] Live-Scripting Console: Python-Code direkt in der DAW ausführen
      `project.tracks[0].volume = 0.8` → sofort wirksam
- [ ] Macro-System: Aktionen aufzeichnen → als Script exportieren → wiederverwenden
- [ ] Custom-Plugin API: Eigene Instrumente/FX in Python schreiben → in DAW laden
- [ ] Batch-Processing API: `pydaw process --input project.pydaw --script mastering.py`
- [ ] Dokumentation + Tutorials: "Schreibe deinen ersten Py_DAW Plugin in 10 Minuten"

**P6B — JSFX / Faust Integration**
- [ ] JSFX-Support (Reaper-kompatibel): Einfache DSP-Plugins direkt in Python implementiert
- [ ] Faust-DSP: `.dsp` Dateien als FX laden (Faust → C++ → Python-Binding)
- [ ] LV2-Builder: Aus Python-DSP-Code LV2-Plugin generieren

**P6C — Preset-Ökosystem**
- [ ] Preset-Format standardisieren: `.pydaw-preset` → machine-readable + human-readable YAML
- [ ] Preset-Importer: Serum-Presets → AETERNA konvertieren (so weit möglich)
- [ ] Community-Preset-Browser: direkt aus der DAW durchsuchen/installieren

---

## 🎬 PHASE 7: Video & Multimedia
### Priorität: 🟢 NIEDRIG — Langfristig

**P7A — Video-Synchronisation**
- [ ] Video-Spur im Arranger: MP4/MKV laden → Video läuft synchron mit Audio
- [ ] SMPTE Timecode: Synchronisation mit externen Video-Tools
- [ ] Kapitel-Marker → Video-Export mit Chapters

**P7B — Podcast & Broadcast**
- [ ] Podcast-Mode: Vereinfachtes UI, Auto-EQ für Sprache, automatische Stille-Erkennung
- [ ] Streaming-Output: Direkt auf RTMP/Icecast streamen (Live-Radio/Podcast)
- [ ] Chapter-Marker → Spotify-Chapters für Podcasts

---

## 📐 TECHNISCHE SCHULDEN (parallel abzuarbeiten)

Diese müssen nicht sofort, aber irgendwann gelöst werden:

- [ ] **Rust-Engine als Default**: `should_use_rust()` → `True` wenn alle Tests grüne
- [ ] **main_window.py aufteilen**: 7961 Zeilen → zu groß → aufteilen in Module
- [ ] **Kein `print()` in Production**: Alle `print(..., file=sys.stderr)` → `logging.getLogger()`
- [ ] **Unit-Tests für Python-Code**: Analog zu 332 Rust-Tests → PyTest für kritische Module
- [ ] **Dokumentation**: User-Manual + API-Referenz + Video-Tutorials
- [ ] **Accessibility**: Screen-Reader-Support, Keyboard-Navigation vollständig
- [ ] **Theming-System**: Hell/Dunkel + benutzerdefinierte Farbschemata per YAML

---

## 🎯 MEILENSTEINE

| Meilenstein | Was | Wann (Schätzung) |
|------------|-----|-----------------|
| **v0.1.0 Beta** | Phase 0 komplett + stabiler Ton aus Advanced Sampler | 2–3 Sessions |
| **v0.2.0** | Phase 1 (Recording Professional) | 5–8 Sessions |
| **v0.3.0** | Phase 2A+2B (KI-Kompositions-Assistent Basic) | 8–12 Sessions |
| **v0.4.0** | Phase 3 (KI-Mixing) + Phase 4 (Live) | 10–15 Sessions |
| **v0.5.0** | Phase 2 komplett (alle KI-Features) | 5–8 Sessions |
| **v0.6.0** | Phase 5+6 (Kollaboration + Scripting) | 10–15 Sessions |
| **v1.0.0** | Alle Phasen + stabil + dokumentiert | ~60 Sessions total |

---

## 🤖 KI-INTEGRATION ARCHITEKTUR (Technisch)

```
┌─────────────────────────────────────────┐
│  Py_DAW GUI (PyQt6)                     │
│  - KI-Panel (neues Dock-Widget)         │
│  - Inline-Vorschläge im Piano Roll      │
│  - Mix-Analyse-Overlay im Mixer         │
└──────────────┬──────────────────────────┘
               │
       ┌───────▼────────┐
       │  KI-Service     │  pydaw/services/ai_service.py
       │  (Singleton)    │
       └───┬─────────┬───┘
           │         │
   ┌───────▼──┐  ┌───▼──────────────┐
   │ Claude   │  │ Lokale Modelle   │
   │ API      │  │ (Essentia, Aubio,│
   │ (online) │  │  Demucs, etc.)   │
   └──────────┘  └──────────────────┘

Datenfluss:
  User-Anfrage → ai_service.py → API/Lokal → strukturierte Antwort
  → Piano Roll einfügen / Mixer anpassen / Preset laden
```

---

## 📋 FÜR DEN NÄCHSTEN KOLLEGEN

### So startest du

```bash
# 1. ZIP entpacken, orientieren
ls pydaw/  # muss existieren
cat VERSION  # aktueller Stand
cat PROJECT_DOCS/PRO_ROADMAP_2026.md  # dieser Plan
cat PROJECT_DOCS/sessions/LATEST.md   # letzte Session

# 2. Nächste offene Aufgabe finden
# → Erste [ ] Checkbox in PHASE 0 (immer zuerst!)
# → Dann PHASE 1, PHASE 2 etc.

# 3. Arbeiten, testen, dokumentieren
python3 -c "import py_compile; py_compile.compile('pydaw/DATEI.py', doraise=True)"

# 4. ZIP bauen
echo -n "0.0.20.XXX" > VERSION
zip -r Output.zip pydaw pydaw_engine PROJECT_DOCS docs *.py *.md *.txt VERSION *.sh \
  -x "*.pyc" "*__pycache__*" "*.egg-info*" "*/.git/*" "*/node_modules/*" "*/target/*"
```

### Prioritätsregel

```
IMMER zuerst PHASE 0 (Stabilisierung) vollständig abschließen
DANN PHASE 1 (Recording)
DANN PHASE 2 (KI) — hier liegt die Zukunft
DANN PHASE 3–7
```

### Was du zurückgibst

1. Neue ZIP mit aktualisierten Checkboxen
2. CHANGELOG_vX.X.X.md
3. PROJECT_DOCS/sessions/LATEST.md (was gemacht, was als nächstes)
4. Kurze Übergabe-Nachricht

---

## 💡 WARUM PY_DAW EINZIGARTIG WERDEN KANN

**Was Ableton/Bitwig/Cubase haben:** Professionelle Audio-Engine, VST-Support, Arranger, Mixer.
→ Das haben wir jetzt auch.

**Was die anderen NICHT haben:**
1. **Python-Scripting direkt in der DAW** — Ableton hat Max for Live, aber Python ist mächtiger
2. **KI-Kompositions-Assistent integriert** — kein anderer DAW-Hersteller hat das nativ
3. **Open Source + Community-Presets** — keine Lizenzkosten, keine Vendor-Lock-ins
4. **Rust-Performance + Python-Flexibilität** — beste beider Welten
5. **KI-Mix-Analyse in Echtzeit** — "dein Mix klingt so weil..." als Lernwerkzeug
6. **Offline-KI für Datenschutz** — Musik-Projekte bleiben lokal, KI läuft lokal
7. **DAWproject-Interoperabilität** — Projekte zwischen DAWs austauschen
8. **Self-hosted Kollaboration** — kein Cloud-Abo nötig

**Das macht Py_DAW zur ersten DAW die gleichzeitig:**
- Professional genug für Studioproduktionen
- Transparent genug für Lernende ("zeig mir warum dieser Mix funktioniert")
- Skriptierbar genug für Automatisierung
- KI-unterstützt genug für kreative Arbeit
- Open Source genug für Community-Beiträge

---

*Dieser Plan wird mit jeder Phase aktualisiert.*
*Stand: v0.0.20.744 — 2026-03-23*
*Nächste offene Aufgabe: PHASE 0 → P0A (Rust-Engine-Disconnect)*
