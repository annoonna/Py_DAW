"""Python Scripting Service — Live-Scripting API for Py_DAW.

v0.0.20.798 — Phase 6A: Python-Scripting API

Provides a safe, sandboxed Python scripting environment that runs
inside the DAW with full access to the project model and services.

Features:
  - Live console: Type Python → immediate effect on project
  - Pre-built API objects: project, tracks, clips, transport, mixer
  - Macro recording: record UI actions → export as script
  - Script library: save/load reusable scripts
  - Safety: restricted builtins (no os.system, no file deletion)
  - Undo integration: scripts run inside undo groups

Example usage in the console:
    >>> project.bpm = 140
    >>> tracks[0].volume = 0.6
    >>> tracks[0].name = "Bass"
    >>> for t in tracks:
    ...     t.muted = False
    >>> add_track("Synth Lead", kind="instrument")
    >>> clips[0].start_beats = 8.0
    >>> transport.play()
    >>> transport.stop()
    >>> export("my_song.wav", format="wav", bit_depth=24)

Architecture:
    ScriptingService creates a restricted globals dict with proxy
    objects that safely delegate to ProjectService/TransportService.
    All mutations trigger project_changed signals so the GUI updates.
"""

from __future__ import annotations

import io
import logging
import sys
import textwrap
import traceback
import time
from contextlib import redirect_stdout, redirect_stderr
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Script result
# ---------------------------------------------------------------------------

@dataclass
class ScriptResult:
    """Result of executing a script."""
    success: bool = True
    output: str = ""
    error: str = ""
    duration_ms: float = 0.0


@dataclass
class SavedScript:
    """A saved script in the library."""
    name: str = ""
    code: str = ""
    description: str = ""
    author: str = ""
    created_at: str = ""
    category: str = "general"  # general, mixing, midi, export, utility


# ---------------------------------------------------------------------------
# Proxy objects — safe wrappers around DAW internals
# ---------------------------------------------------------------------------

class _TrackProxy:
    """Proxy for a single Track — attribute access triggers project update.

    v0.0.20.799: Also triggers UI sync callback so mixer faders, mute/solo
    buttons and arranger update immediately.
    """

    # Attributes that need GUI refresh when changed
    _UI_SYNC_ATTRS = {'volume', 'pan', 'muted', 'solo', 'name', 'record_arm', 'monitor'}

    def __init__(self, track, project_service, on_ui_sync=None):
        object.__setattr__(self, '_track', track)
        object.__setattr__(self, '_ps', project_service)
        object.__setattr__(self, '_on_ui_sync', on_ui_sync)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, '_track'), name)

    def __setattr__(self, name, value):
        track = object.__getattribute__(self, '_track')
        ps = object.__getattribute__(self, '_ps')
        on_sync = object.__getattribute__(self, '_on_ui_sync')
        if hasattr(track, name):
            setattr(track, name, value)
            try:
                ps.project_changed.emit()
            except Exception:
                pass
            # Trigger UI refresh for visual attributes
            if on_sync and name in _TrackProxy._UI_SYNC_ATTRS:
                try:
                    on_sync("track_" + name, value)
                except Exception:
                    pass
        else:
            raise AttributeError(f"Track has no attribute '{name}'")

    def __repr__(self):
        t = object.__getattribute__(self, '_track')
        return f"<Track '{getattr(t, 'name', '?')}' id={getattr(t, 'id', '?')} kind={getattr(t, 'kind', '?')}>"


class _TrackListProxy:
    """Proxy for the tracks list — indexable, iterable."""

    def __init__(self, project_service, on_ui_sync=None):
        self._ps = project_service
        self._on_ui_sync = on_ui_sync

    def _tracks(self):
        try:
            return list(self._ps.ctx.project.tracks or [])
        except Exception:
            return []

    def __getitem__(self, idx):
        tracks = self._tracks()
        if isinstance(idx, str):
            # Access by name
            for t in tracks:
                if getattr(t, 'name', '') == idx:
                    return _TrackProxy(t, self._ps, self._on_ui_sync)
            raise KeyError(f"No track named '{idx}'")
        return _TrackProxy(tracks[idx], self._ps, self._on_ui_sync)

    def __len__(self):
        return len(self._tracks())

    def __iter__(self):
        for t in self._tracks():
            yield _TrackProxy(t, self._ps, self._on_ui_sync)

    def __repr__(self):
        tracks = self._tracks()
        lines = [f"TrackList ({len(tracks)} tracks):"]
        for i, t in enumerate(tracks):
            lines.append(f"  [{i}] {getattr(t, 'name', '?')} ({getattr(t, 'kind', '?')})")
        return "\n".join(lines)

    def by_name(self, name: str) -> Optional[_TrackProxy]:
        """Find track by name (case-insensitive)."""
        name_lower = name.lower()
        for t in self._tracks():
            if getattr(t, 'name', '').lower() == name_lower:
                return _TrackProxy(t, self._ps, self._on_ui_sync)
        return None

    def by_kind(self, kind: str) -> List[_TrackProxy]:
        """Get all tracks of a specific kind."""
        return [_TrackProxy(t, self._ps, self._on_ui_sync) for t in self._tracks()
                if getattr(t, 'kind', '') == kind]


class _ClipProxy:
    """Proxy for a single Clip."""

    def __init__(self, clip, project_service):
        object.__setattr__(self, '_clip', clip)
        object.__setattr__(self, '_ps', project_service)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, '_clip'), name)

    def __setattr__(self, name, value):
        clip = object.__getattribute__(self, '_clip')
        ps = object.__getattribute__(self, '_ps')
        if hasattr(clip, name):
            setattr(clip, name, value)
            try:
                ps.project_changed.emit()
            except Exception:
                pass
        else:
            raise AttributeError(f"Clip has no attribute '{name}'")

    def __repr__(self):
        c = object.__getattribute__(self, '_clip')
        return (f"<Clip '{getattr(c, 'label', '?')}' "
                f"kind={getattr(c, 'kind', '?')} "
                f"start={getattr(c, 'start_beats', 0):.1f}>")


class _ClipListProxy:
    """Proxy for the clips list."""

    def __init__(self, project_service):
        self._ps = project_service

    def _clips(self):
        try:
            return list(self._ps.ctx.project.clips or [])
        except Exception:
            return []

    def __getitem__(self, idx):
        return _ClipProxy(self._clips()[idx], self._ps)

    def __len__(self):
        return len(self._clips())

    def __iter__(self):
        for c in self._clips():
            yield _ClipProxy(c, self._ps)

    def __repr__(self):
        clips = self._clips()
        return f"ClipList ({len(clips)} clips)"

    def on_track(self, track_name: str) -> List[_ClipProxy]:
        """Get all clips on a track (by name)."""
        tracks = list(self._ps.ctx.project.tracks or [])
        tid = ""
        for t in tracks:
            if getattr(t, 'name', '').lower() == track_name.lower():
                tid = str(getattr(t, 'id', ''))
                break
        if not tid:
            return []
        return [_ClipProxy(c, self._ps) for c in self._clips()
                if str(getattr(c, 'track_id', '')) == tid]


class _ProjectProxy:
    """Proxy for the Project object — top-level access.

    v0.0.20.799: Enhanced to also update TransportService and trigger
    UI callbacks when BPM/time_signature change, so the transport panel
    display stays in sync.
    """

    def __init__(self, project_service, transport_service=None, on_ui_sync=None):
        self._ps = project_service
        self._ts = transport_service
        self._on_ui_sync = on_ui_sync  # callback(param_name, value)

    def _project(self):
        return self._ps.ctx.project

    def _notify(self, param_name, value):
        """Notify UI and transport of a parameter change."""
        try:
            self._ps.project_changed.emit()
        except Exception:
            pass
        if self._on_ui_sync:
            try:
                self._on_ui_sync(param_name, value)
            except Exception:
                pass

    @property
    def bpm(self):
        return float(getattr(self._project(), 'bpm', 120.0))

    @bpm.setter
    def bpm(self, value):
        value = max(20.0, min(999.0, float(value)))
        self._project().bpm = value
        # Also update TransportService so playback uses new BPM
        if self._ts and hasattr(self._ts, 'set_bpm'):
            try:
                self._ts.set_bpm(value)
            except Exception:
                pass
        self._notify("bpm", value)

    @property
    def name(self):
        return str(getattr(self._project(), 'name', ''))

    @name.setter
    def name(self, value):
        self._project().name = str(value)
        self._notify("name", value)

    @property
    def sample_rate(self):
        return int(getattr(self._project(), 'sample_rate', 48000))

    @property
    def time_signature(self):
        return str(getattr(self._project(), 'time_signature', '4/4'))

    @time_signature.setter
    def time_signature(self, value):
        self._project().time_signature = str(value)
        # Update TransportService
        if self._ts and hasattr(self._ts, 'set_time_signature'):
            try:
                self._ts.set_time_signature(str(value))
            except Exception:
                pass
        self._notify("time_signature", value)

    @property
    def track_count(self):
        return len(self._project().tracks or [])

    @property
    def clip_count(self):
        return len(self._project().clips or [])

    def __repr__(self):
        p = self._project()
        return (f"<Project '{getattr(p, 'name', '?')}' "
                f"bpm={getattr(p, 'bpm', 120)} "
                f"tracks={len(p.tracks or [])} "
                f"clips={len(p.clips or [])}>")

    def save(self):
        """Save the project."""
        try:
            self._ps.save_project()
            return "Project saved."
        except Exception as e:
            return f"Save failed: {e}"


class _TransportProxy:
    """Proxy for transport controls."""

    def __init__(self, transport_service):
        self._ts = transport_service

    def play(self):
        """Start playback."""
        if self._ts:
            self._ts.play()
            return "▶ Playing"
        return "Transport not available"

    def stop(self):
        """Stop playback."""
        if self._ts:
            self._ts.stop()
            return "⏹ Stopped"
        return "Transport not available"

    def pause(self):
        """Pause playback."""
        if self._ts:
            self._ts.pause()
            return "⏸ Paused"
        return "Transport not available"

    @property
    def position(self):
        """Current playhead position in beats."""
        if self._ts:
            return float(getattr(self._ts, 'position_beats', 0.0))
        return 0.0

    @position.setter
    def position(self, beat):
        if self._ts:
            self._ts.seek(float(beat))

    @property
    def is_playing(self):
        if self._ts:
            return bool(getattr(self._ts, 'playing', False))
        return False

    def __repr__(self):
        pos = self.position
        state = "▶ Playing" if self.is_playing else "⏹ Stopped"
        return f"<Transport {state} at beat {pos:.1f}>"


class _MixerProxy:
    """Convenience shortcuts for mixer operations."""

    def __init__(self, project_service):
        self._ps = project_service

    def _tracks(self):
        return list(self._ps.ctx.project.tracks or [])

    def solo(self, track_name: str):
        """Solo a track by name."""
        for t in self._tracks():
            if getattr(t, 'name', '').lower() == track_name.lower():
                t.solo = True
            else:
                t.solo = False
        try:
            self._ps.project_changed.emit()
        except Exception:
            pass
        return f"Solo: {track_name}"

    def unsolo_all(self):
        """Remove solo from all tracks."""
        for t in self._tracks():
            t.solo = False
        try:
            self._ps.project_changed.emit()
        except Exception:
            pass
        return "All tracks unsoloed"

    def mute(self, track_name: str):
        """Mute a track by name."""
        for t in self._tracks():
            if getattr(t, 'name', '').lower() == track_name.lower():
                t.muted = True
                break
        try:
            self._ps.project_changed.emit()
        except Exception:
            pass
        return f"Muted: {track_name}"

    def unmute_all(self):
        """Unmute all tracks."""
        for t in self._tracks():
            t.muted = False
        try:
            self._ps.project_changed.emit()
        except Exception:
            pass
        return "All tracks unmuted"

    def set_all_volume(self, volume: float):
        """Set all tracks to the same volume."""
        vol = max(0.0, min(1.0, float(volume)))
        for t in self._tracks():
            t.volume = vol
        try:
            self._ps.project_changed.emit()
        except Exception:
            pass
        return f"All tracks volume → {vol:.2f}"

    def __repr__(self):
        tracks = self._tracks()
        lines = ["Mixer:"]
        for t in tracks:
            name = getattr(t, 'name', '?')
            vol = getattr(t, 'volume', 0.8)
            pan = getattr(t, 'pan', 0.0)
            m = "M" if getattr(t, 'muted', False) else " "
            s = "S" if getattr(t, 'solo', False) else " "
            lines.append(f"  {m}{s} {name:20s} vol={vol:.2f} pan={pan:+.2f}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Core Scripting Service
# ---------------------------------------------------------------------------

# ═══════════════════════════════════════════════════════════════
# v0.0.20.946: Video Editor API for Python Console
# ═══════════════════════════════════════════════════════════════

class _VideoAPI:
    """Video editor API accessible from Python console.

    Usage in console:
        video.clips                     # list all video clips
        video.filters("clip_id")        # get filter chain
        video.set_opacity("clip_id", 0.5)
        video.set_speed("clip_id", 2.0)
        video.add_filter("clip_id", "bw")
        video.automation("clip_id")     # get automation data
        video.add_fade_in("clip_id", 4) # 4-beat fade in
        video.transitions              # list transitions
        video.timecode                  # current TC settings
        video.set_fps(29.97)
    """

    def __init__(self, project_service):
        self._ps = project_service

    def __repr__(self):
        n = len(self.clips)
        return f"<VideoAPI: {n} video clip(s)>"

    @property
    def clips(self) -> list:
        """List all video clips."""
        try:
            proj = getattr(getattr(self._ps, 'ctx', None), 'project', None)
            if not proj:
                return []
            return [
                {"id": str(getattr(c, 'id', '')),
                 "label": str(getattr(c, 'label', '')),
                 "start": float(getattr(c, 'start_beats', 0)),
                 "length": float(getattr(c, 'length_beats', 0)),
                 "source": str(getattr(c, 'source_path', ''))}
                for c in (proj.clips or [])
                if str(getattr(c, 'kind', '')) == 'video'
            ]
        except Exception:
            return []

    def filters(self, clip_id: str) -> dict:
        """Get filter chain for a clip."""
        try:
            from pydaw.services.video_filter_service import VideoFilterService
            vfs = VideoFilterService.instance()
            return vfs.get_chain_dict(clip_id) if vfs else {}
        except Exception:
            return {}

    def add_filter(self, clip_id: str, preset: str) -> str:
        """Apply a filter preset to a clip (warm, cold, bw, vintage, cinema, etc.)."""
        try:
            from pydaw.services.video_filter_service import VideoFilterService
            vfs = VideoFilterService.instance()
            if vfs and hasattr(vfs, 'apply_preset'):
                vfs.apply_preset(clip_id, preset)
                return f"Filter '{preset}' applied to {clip_id[:8]}"
        except Exception as e:
            return f"Error: {e}"
        return "VideoFilterService not available"

    def set_opacity(self, clip_id: str, opacity: float) -> str:
        """Set clip opacity (0.0–1.0)."""
        try:
            from pydaw.services.video_state_db import VideoStateDB
            db = VideoStateDB.instance()
            db.save_clip_props(clip_id, {"opacity": max(0, min(1, opacity))})
            return f"Opacity = {opacity:.2f}"
        except Exception as e:
            return f"Error: {e}"

    def set_speed(self, clip_id: str, speed: float) -> str:
        """Set clip speed (0.1–10.0)."""
        try:
            from pydaw.services.video_state_db import VideoStateDB
            db = VideoStateDB.instance()
            db.save_clip_props(clip_id, {"speed": max(0.1, min(10, speed))})
            return f"Speed = {speed:.2f}x"
        except Exception as e:
            return f"Error: {e}"

    def automation(self, clip_id: str) -> dict:
        """Get automation data for a clip."""
        try:
            from pydaw.services.video_state_db import VideoStateDB
            db = VideoStateDB.instance()
            return db.load_all_automation(clip_id)
        except Exception:
            return {}

    def add_fade_in(self, clip_id: str, duration: float = 4.0) -> str:
        """Add fade-in automation to a clip."""
        try:
            from pydaw.services.video_automation import AutomationPresets, AutomationLane
            curve = AutomationPresets.fade_in(duration, AutomationLane.OPACITY)
            from pydaw.services.video_state_db import VideoStateDB
            db = VideoStateDB.instance()
            db.save_automation(clip_id, "opacity", curve.to_dict())
            return f"Fade In ({duration} beats) added"
        except Exception as e:
            return f"Error: {e}"

    def add_fade_out(self, clip_id: str, clip_length: float = 16.0,
                     duration: float = 4.0) -> str:
        """Add fade-out automation to a clip."""
        try:
            from pydaw.services.video_automation import AutomationPresets, AutomationLane
            curve = AutomationPresets.fade_out(clip_length, duration, AutomationLane.OPACITY)
            from pydaw.services.video_state_db import VideoStateDB
            db = VideoStateDB.instance()
            db.save_automation(clip_id, "opacity", curve.to_dict())
            return f"Fade Out ({duration} beats) added"
        except Exception as e:
            return f"Error: {e}"

    @property
    def transitions(self) -> list:
        """List all transitions."""
        try:
            from pydaw.services.video_state_db import VideoStateDB
            db = VideoStateDB.instance()
            return db.load_all_transitions()
        except Exception:
            return []

    @property
    def timecode(self) -> dict:
        """Get timecode settings."""
        try:
            from pydaw.services.video_state_db import VideoStateDB
            db = VideoStateDB.instance()
            return db.load_timecode()
        except Exception:
            return {"fps": 24.0, "drop_frame": False}

    def set_fps(self, fps: float, drop_frame: bool = False) -> str:
        """Set timecode FPS and drop-frame mode."""
        try:
            from pydaw.services.video_state_db import VideoStateDB
            db = VideoStateDB.instance()
            db.save_timecode(fps, drop_frame)
            return f"FPS = {fps}, DF = {drop_frame}"
        except Exception as e:
            return f"Error: {e}"


class ScriptingService:
    """Live Python scripting engine for Py_DAW.

    Creates a sandboxed execution environment with proxy objects
    that safely access DAW internals.
    """

    def __init__(self, project_service=None, transport_service=None):
        self._project_service = project_service
        self._transport_service = transport_service
        self._history: List[str] = []
        self._output_history: List[str] = []
        self._scripts: List[SavedScript] = []
        self._globals: Dict[str, Any] = {}
        self._on_output: Optional[Callable] = None
        self._on_project_changed: Optional[Callable] = None
        # v0.0.20.799: UI sync callback — called when scripts change
        # project parameters that need GUI updates (BPM, name, etc.)
        # Signature: callback(param_name: str, value: Any)
        self._on_ui_sync: Optional[Callable] = None

        self._build_globals()

    def set_services(self, project_service=None, transport_service=None) -> None:
        self._project_service = project_service or self._project_service
        self._transport_service = transport_service or self._transport_service
        self._build_globals()

    def set_on_output(self, callback: Callable) -> None:
        """Set callback for script output (print statements)."""
        self._on_output = callback

    def set_on_ui_sync(self, callback: Callable) -> None:
        """Set callback for UI sync when scripts change project parameters.

        v0.0.20.799: Called with (param_name, value) so the main window
        can update transport display, mixer faders, etc.
        """
        self._on_ui_sync = callback
        # Rebuild globals to pass the new callback to proxies
        self._build_globals()

    def _build_globals(self) -> None:
        """Build the restricted globals dict for script execution."""
        ps = self._project_service
        ts = self._transport_service

        # Safe builtins (no file I/O, no exec, no eval of arbitrary code)
        safe_builtins = {
            'abs': abs, 'all': all, 'any': any, 'bool': bool,
            'dict': dict, 'enumerate': enumerate, 'filter': filter,
            'float': float, 'format': format, 'frozenset': frozenset,
            'getattr': getattr, 'hasattr': hasattr, 'hash': hash,
            'hex': hex, 'id': id, 'int': int, 'isinstance': isinstance,
            'issubclass': issubclass, 'iter': iter, 'len': len,
            'list': list, 'map': map, 'max': max, 'min': min,
            'next': next, 'oct': oct, 'ord': ord, 'pow': pow,
            'print': self._safe_print, 'range': range, 'repr': repr,
            'reversed': reversed, 'round': round, 'set': set,
            'slice': slice, 'sorted': sorted, 'str': str, 'sum': sum,
            'tuple': tuple, 'type': type, 'zip': zip,
            'True': True, 'False': False, 'None': None,
        }

        self._globals = {
            '__builtins__': safe_builtins,
            '__name__': '__pydaw_script__',
        }

        # DAW proxy objects
        if ps:
            self._globals['project'] = _ProjectProxy(
                ps,
                transport_service=ts,
                on_ui_sync=self._on_ui_sync,
            )
            self._globals['tracks'] = _TrackListProxy(ps, on_ui_sync=self._on_ui_sync)
            self._globals['clips'] = _ClipListProxy(ps)
            self._globals['mixer'] = _MixerProxy(ps)

            # Convenience functions
            def add_track(name: str = "New Track", kind: str = "audio"):
                """Add a new track to the project."""
                try:
                    from pydaw.model.project import Track, new_id
                    t = Track(id=new_id("trk"), kind=kind, name=name)
                    ps.ctx.project.tracks.append(t)
                    ps.project_changed.emit()
                    return f"Track '{name}' ({kind}) added"
                except Exception as e:
                    return f"Failed: {e}"

            def remove_track(name: str):
                """Remove a track by name."""
                try:
                    tracks = ps.ctx.project.tracks
                    for i, t in enumerate(tracks):
                        if getattr(t, 'name', '') == name:
                            tracks.pop(i)
                            ps.project_changed.emit()
                            return f"Track '{name}' removed"
                    return f"Track '{name}' not found"
                except Exception as e:
                    return f"Failed: {e}"

            def add_clip(track_name: str, start: float = 0.0,
                         length: float = 4.0, kind: str = "midi",
                         label: str = ""):
                """Add a clip to a track."""
                try:
                    from pydaw.model.project import Clip, new_id
                    tid = ""
                    for t in ps.ctx.project.tracks:
                        if getattr(t, 'name', '') == track_name:
                            tid = str(getattr(t, 'id', ''))
                            break
                    if not tid:
                        return f"Track '{track_name}' not found"
                    c = Clip(
                        id=new_id("clip"),
                        track_id=tid,
                        kind=kind,
                        start_beats=start,
                        length_beats=length,
                        label=label or f"Clip at {start}",
                    )
                    ps.ctx.project.clips.append(c)
                    ps.project_changed.emit()
                    return f"Clip added on '{track_name}' at beat {start}"
                except Exception as e:
                    return f"Failed: {e}"

            self._globals['add_track'] = add_track
            self._globals['remove_track'] = remove_track
            self._globals['add_clip'] = add_clip

        if ts:
            self._globals['transport'] = _TransportProxy(ts)

        # Utility functions
        def sleep(seconds: float):
            """Wait (max 10 seconds for safety)."""
            time.sleep(min(float(seconds), 10.0))

        def help_api():
            """Show available scripting API."""
            return textwrap.dedent("""
            🎵 Py_DAW Scripting API
            ═══════════════════════

            Objects:
              project       — Project properties (bpm, name, sample_rate)
              tracks        — Track list (indexable, iterable)
              tracks[0]     — First track (volume, pan, muted, solo, name)
              tracks["Bass"]— Track by name
              clips         — Clip list
              transport     — Play/Stop/Pause/Seek
              mixer         — Solo/Mute/Volume shortcuts

            Functions:
              add_track(name, kind)      — Add a track ("audio"/"instrument")
              remove_track(name)         — Remove a track by name
              add_clip(track, start, len)— Add a clip
              sleep(seconds)             — Wait (max 10s)
              help_api()                 — This help text

            Examples:
              project.bpm = 140
              tracks[0].volume = 0.6
              tracks["Bass"].muted = True
              mixer.solo("Drums")
              mixer.unmute_all()
              transport.play()
              add_track("Synth", kind="instrument")
            """)

        self._globals['sleep'] = sleep
        self._globals['help'] = help_api
        self._globals['help_api'] = help_api

        # Math module (useful for DSP scripting)
        import math
        self._globals['math'] = math

        # v0.0.20.946: Video Editor API for Python Console
        if ps:
            self._globals['video'] = _VideoAPI(ps)

    def _safe_print(self, *args, **kwargs):
        """Redirect print() to the script output."""
        output = " ".join(str(a) for a in args)
        self._output_history.append(output)
        if self._on_output:
            try:
                self._on_output(output)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def execute(self, code: str) -> ScriptResult:
        """Execute a Python script in the sandboxed environment.

        Returns ScriptResult with output, errors, and timing.
        """
        if not code.strip():
            return ScriptResult(output="")

        self._history.append(code)
        result = self._execute_impl(code)
        # v0.0.20.893 P18: Persist to SQLite
        try:
            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            edb.add_script_history(
                code=code,
                result=str(getattr(result, 'output', '') or getattr(result, 'error', '')),
                success=getattr(result, 'success', True),
            )
        except Exception:
            pass
        return result

    def _execute_impl(self, code: str) -> ScriptResult:
        """Internal execute implementation."""
        start = time.time()

        stdout_buf = io.StringIO()
        stderr_buf = io.StringIO()

        try:
            # Try as expression first (to show return value)
            try:
                compiled = compile(code.strip(), "<script>", "eval")
                with redirect_stdout(stdout_buf), redirect_stderr(stderr_buf):
                    result = eval(compiled, self._globals)
                output = stdout_buf.getvalue()
                if result is not None:
                    result_str = repr(result)
                    output = (output + "\n" + result_str).strip()
                elapsed = (time.time() - start) * 1000
                return ScriptResult(
                    success=True,
                    output=output,
                    duration_ms=elapsed,
                )
            except SyntaxError:
                pass  # Not an expression, try as statements

            # Execute as statements
            compiled = compile(code, "<script>", "exec")
            with redirect_stdout(stdout_buf), redirect_stderr(stderr_buf):
                exec(compiled, self._globals)

            output = stdout_buf.getvalue().strip()
            elapsed = (time.time() - start) * 1000
            return ScriptResult(
                success=True,
                output=output,
                duration_ms=elapsed,
            )

        except Exception as exc:
            elapsed = (time.time() - start) * 1000
            tb = traceback.format_exc()
            # Clean up traceback (remove internal frames)
            lines = tb.strip().splitlines()
            clean_lines = []
            skip = False
            for line in lines:
                if '<script>' in line or 'in <module>' in line:
                    skip = False
                if not skip:
                    clean_lines.append(line)
            error_msg = "\n".join(clean_lines[-3:]) if len(clean_lines) > 3 else "\n".join(clean_lines)
            return ScriptResult(
                success=False,
                output=stdout_buf.getvalue().strip(),
                error=error_msg,
                duration_ms=elapsed,
            )

    def execute_file(self, path: str) -> ScriptResult:
        """Execute a Python script file."""
        try:
            from pathlib import Path
            code = Path(path).read_text(encoding="utf-8")
            return self.execute(code)
        except Exception as e:
            return ScriptResult(success=False, error=str(e))

    # ------------------------------------------------------------------
    # History
    # ------------------------------------------------------------------

    def get_history(self) -> List[str]:
        """Get command history. v0.0.20.896: DB-first with in-memory fallback."""
        # Try loading from DB if local history is empty
        if not self._history:
            try:
                from pydaw.services.extended_state_db import ExtendedStateDB
                edb = ExtendedStateDB.get()
                edb.ensure_loaded()
                rows = edb.get_script_history(limit=100)
                if rows:
                    self._history = [str(r.get("code", "")) for r in reversed(rows) if r.get("code")]
            except Exception:
                pass
        return list(self._history)

    def clear_history(self) -> None:
        self._history.clear()
        self._output_history.clear()

    # ------------------------------------------------------------------
    # Script Library
    # ------------------------------------------------------------------

    def save_script(self, name: str, code: str,
                    description: str = "", category: str = "general") -> None:
        """Save a script to the library."""
        from datetime import datetime
        script = SavedScript(
            name=name, code=code, description=description,
            category=category,
            created_at=datetime.utcnow().isoformat(),
        )
        # Replace if exists
        self._scripts = [s for s in self._scripts if s.name != name]
        self._scripts.append(script)

    def get_scripts(self, category: str = "") -> List[SavedScript]:
        """Get saved scripts, optionally filtered by category."""
        if category:
            return [s for s in self._scripts if s.category == category]
        return list(self._scripts)

    def delete_script(self, name: str) -> bool:
        before = len(self._scripts)
        self._scripts = [s for s in self._scripts if s.name != name]
        return len(self._scripts) < before

    def get_builtin_scripts(self) -> List[SavedScript]:
        """Get built-in example scripts."""
        return [
            SavedScript(
                name="Gain Staging",
                code="for t in tracks:\n    if t.kind != 'master':\n        t.volume = 0.75\nprint(f'{len(tracks)} tracks set to 0.75')",
                description="Set all non-master tracks to 0.75 volume",
                category="mixing",
            ),
            SavedScript(
                name="Mute Empty Tracks",
                code="muted = 0\nfor t in tracks:\n    track_clips = clips.on_track(t.name)\n    if not track_clips:\n        t.muted = True\n        muted += 1\nprint(f'{muted} empty tracks muted')",
                description="Mute all tracks that have no clips",
                category="utility",
            ),
            SavedScript(
                name="Project Info",
                code="print(project)\nprint(f'BPM: {project.bpm}')\nprint(f'Tracks: {project.track_count}')\nprint(f'Clips: {project.clip_count}')\nprint(f'Sample Rate: {project.sample_rate}')\nprint(mixer)",
                description="Show project information and mixer state",
                category="utility",
            ),
            SavedScript(
                name="Double BPM",
                code="old = project.bpm\nproject.bpm = old * 2\nprint(f'BPM: {old} → {project.bpm}')",
                description="Double the project tempo",
                category="utility",
            ),
            SavedScript(
                name="Create 8-Track Template",
                code="names = ['Drums', 'Bass', 'Keys', 'Guitar', 'Vocals', 'Pad', 'FX', 'Lead']\nfor n in names:\n    add_track(n, kind='instrument')\nprint(f'{len(names)} tracks created')",
                description="Create a standard 8-track template",
                category="utility",
            ),
        ]
