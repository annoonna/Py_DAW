"""video_state_db.py — SQLite Persistence for Video Features (v0.0.20.946).

Stores:
  - VE9 Automation curves (opacity/speed/volume per clip)
  - VE10 Transitions (type, duration, position between clips)
  - VE8 Timecode settings (FPS, drop-frame per project)
  - Video clip properties (opacity, speed, label overrides)
  - Video filter chains (per clip)

Tables:
  video_automation    — breakpoint data per clip per lane
  video_transitions   — transition data between clip pairs
  video_timecode      — project-wide timecode settings
  video_clip_props    — per-clip properties
  video_filter_chains — per-clip filter chains (JSON)

Thread-safe: all DB writes use a single connection with WAL mode.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

_CREATE_TABLES = """
CREATE TABLE IF NOT EXISTS video_automation (
    clip_id    TEXT NOT NULL,
    lane       TEXT NOT NULL,
    data_json  TEXT NOT NULL,
    PRIMARY KEY (clip_id, lane)
);

CREATE TABLE IF NOT EXISTS video_transitions (
    transition_id  TEXT PRIMARY KEY,
    data_json      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS video_timecode (
    key    TEXT PRIMARY KEY,
    value  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS video_clip_props (
    clip_id    TEXT PRIMARY KEY,
    data_json  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS video_filter_chains (
    clip_id    TEXT PRIMARY KEY,
    chain_json TEXT NOT NULL
);
"""


class VideoStateDB:
    """SQLite storage for all video editor state.

    Usage:
        db = VideoStateDB("/path/to/project.db")
        db.save_automation("clip_123", "opacity", curve.to_dict())
        curve_data = db.load_automation("clip_123", "opacity")
    """

    _instance: Optional["VideoStateDB"] = None
    _lock = threading.Lock()

    def __init__(self, db_path: str = ""):
        self._db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None
        if db_path:
            self._connect(db_path)

    @classmethod
    def instance(cls, db_path: str = "") -> "VideoStateDB":
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls(db_path)
            elif db_path and cls._instance._db_path != db_path:
                cls._instance._close()
                cls._instance = cls(db_path)
            return cls._instance

    def _connect(self, path: str) -> None:
        try:
            self._conn = sqlite3.connect(path, check_same_thread=False)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.executescript(_CREATE_TABLES)
            self._conn.commit()
            log.info("[VideoStateDB] Tables ready: %s", path)
        except Exception as e:
            log.warning("[VideoStateDB] connect error: %s", e)
            self._conn = None

    def _close(self) -> None:
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None

    def is_ready(self) -> bool:
        return self._conn is not None

    # ═══════════════════════════════════════════════════════════════
    # Automation (VE9)
    # ═══════════════════════════════════════════════════════════════

    def save_automation(self, clip_id: str, lane: str, data: dict) -> None:
        if not self._conn:
            return
        try:
            self._conn.execute(
                "INSERT OR REPLACE INTO video_automation (clip_id, lane, data_json) "
                "VALUES (?, ?, ?)",
                (clip_id, lane, json.dumps(data, default=str)))
            self._conn.commit()
        except Exception as e:
            log.debug("[VideoStateDB] save_automation: %s", e)

    def load_automation(self, clip_id: str, lane: str) -> Optional[dict]:
        if not self._conn:
            return None
        try:
            row = self._conn.execute(
                "SELECT data_json FROM video_automation WHERE clip_id=? AND lane=?",
                (clip_id, lane)).fetchone()
            return json.loads(row[0]) if row else None
        except Exception as e:
            log.debug("[VideoStateDB] load_automation: %s", e)
            return None

    def load_all_automation(self, clip_id: str) -> Dict[str, dict]:
        if not self._conn:
            return {}
        try:
            rows = self._conn.execute(
                "SELECT lane, data_json FROM video_automation WHERE clip_id=?",
                (clip_id,)).fetchall()
            return {lane: json.loads(data) for lane, data in rows}
        except Exception:
            return {}

    def delete_automation(self, clip_id: str) -> None:
        if not self._conn:
            return
        try:
            self._conn.execute(
                "DELETE FROM video_automation WHERE clip_id=?", (clip_id,))
            self._conn.commit()
        except Exception:
            pass

    def save_automation_store(self, store_data: dict) -> None:
        """Save entire VideoAutomationStore."""
        if not self._conn:
            return
        try:
            self._conn.execute("DELETE FROM video_automation")
            for clip_id, auto_data in store_data.items():
                for lane_key in ("opacity", "speed", "volume"):
                    lane_data = auto_data.get(lane_key)
                    if lane_data and lane_data.get("points"):
                        self._conn.execute(
                            "INSERT INTO video_automation (clip_id, lane, data_json) "
                            "VALUES (?, ?, ?)",
                            (clip_id, lane_key, json.dumps(lane_data, default=str)))
            self._conn.commit()
        except Exception as e:
            log.debug("[VideoStateDB] save_automation_store: %s", e)

    # ═══════════════════════════════════════════════════════════════
    # Transitions (VE10)
    # ═══════════════════════════════════════════════════════════════

    def save_transition(self, transition_id: str, data: dict) -> None:
        if not self._conn:
            return
        try:
            self._conn.execute(
                "INSERT OR REPLACE INTO video_transitions (transition_id, data_json) "
                "VALUES (?, ?)",
                (transition_id, json.dumps(data, default=str)))
            self._conn.commit()
        except Exception as e:
            log.debug("[VideoStateDB] save_transition: %s", e)

    def load_all_transitions(self) -> List[dict]:
        if not self._conn:
            return []
        try:
            rows = self._conn.execute(
                "SELECT data_json FROM video_transitions").fetchall()
            return [json.loads(r[0]) for r in rows]
        except Exception:
            return []

    def delete_transition(self, transition_id: str) -> None:
        if not self._conn:
            return
        try:
            self._conn.execute(
                "DELETE FROM video_transitions WHERE transition_id=?",
                (transition_id,))
            self._conn.commit()
        except Exception:
            pass

    def save_transition_store(self, store_data: dict) -> None:
        """Save entire VideoTransitionStore."""
        if not self._conn:
            return
        try:
            self._conn.execute("DELETE FROM video_transitions")
            for tr_data in store_data.get("transitions", []):
                tid = tr_data.get("transition_id", "")
                if tid:
                    self._conn.execute(
                        "INSERT INTO video_transitions (transition_id, data_json) "
                        "VALUES (?, ?)",
                        (tid, json.dumps(tr_data, default=str)))
            self._conn.commit()
        except Exception as e:
            log.debug("[VideoStateDB] save_transition_store: %s", e)

    # ═══════════════════════════════════════════════════════════════
    # Timecode Settings (VE8)
    # ═══════════════════════════════════════════════════════════════

    def save_timecode(self, fps: float, drop_frame: bool) -> None:
        if not self._conn:
            return
        try:
            self._conn.execute(
                "INSERT OR REPLACE INTO video_timecode (key, value) VALUES (?, ?)",
                ("fps", str(fps)))
            self._conn.execute(
                "INSERT OR REPLACE INTO video_timecode (key, value) VALUES (?, ?)",
                ("drop_frame", "1" if drop_frame else "0"))
            self._conn.commit()
        except Exception:
            pass

    def load_timecode(self) -> Dict[str, Any]:
        if not self._conn:
            return {"fps": 24.0, "drop_frame": False}
        try:
            rows = self._conn.execute(
                "SELECT key, value FROM video_timecode").fetchall()
            d = dict(rows)
            return {
                "fps": float(d.get("fps", "24.0")),
                "drop_frame": d.get("drop_frame", "0") == "1",
            }
        except Exception:
            return {"fps": 24.0, "drop_frame": False}

    # ═══════════════════════════════════════════════════════════════
    # Clip Properties
    # ═══════════════════════════════════════════════════════════════

    def save_clip_props(self, clip_id: str, props: dict) -> None:
        if not self._conn:
            return
        try:
            self._conn.execute(
                "INSERT OR REPLACE INTO video_clip_props (clip_id, data_json) "
                "VALUES (?, ?)",
                (clip_id, json.dumps(props, default=str)))
            self._conn.commit()
        except Exception:
            pass

    def load_clip_props(self, clip_id: str) -> Optional[dict]:
        if not self._conn:
            return None
        try:
            row = self._conn.execute(
                "SELECT data_json FROM video_clip_props WHERE clip_id=?",
                (clip_id,)).fetchone()
            return json.loads(row[0]) if row else None
        except Exception:
            return None

    # ═══════════════════════════════════════════════════════════════
    # Filter Chains
    # ═══════════════════════════════════════════════════════════════

    def save_filter_chain(self, clip_id: str, chain: dict) -> None:
        if not self._conn:
            return
        try:
            self._conn.execute(
                "INSERT OR REPLACE INTO video_filter_chains (clip_id, chain_json) "
                "VALUES (?, ?)",
                (clip_id, json.dumps(chain, default=str)))
            self._conn.commit()
        except Exception:
            pass

    def load_filter_chain(self, clip_id: str) -> Optional[dict]:
        if not self._conn:
            return None
        try:
            row = self._conn.execute(
                "SELECT chain_json FROM video_filter_chains WHERE clip_id=?",
                (clip_id,)).fetchone()
            return json.loads(row[0]) if row else None
        except Exception:
            return None

    def load_all_filter_chains(self) -> Dict[str, dict]:
        if not self._conn:
            return {}
        try:
            rows = self._conn.execute(
                "SELECT clip_id, chain_json FROM video_filter_chains").fetchall()
            return {cid: json.loads(chain) for cid, chain in rows}
        except Exception:
            return {}
