"""video_clip_properties.py — Clip Properties Panel für Video-Editor (v0.0.20.935).

Provides per-clip editing tools accessible from the Video Editor right-click menu:

1. OPACITY — Clip-Transparenz (0–100%)
2. SPEED — Zeitlupe, Schnellvorlauf, Rückwärts
3. BLEND MODES — Normal, Multiply, Screen, Overlay, Add, Difference
4. FILTERS — Brightness, Contrast, Saturation, Gamma, Blur, Sharpen, Vignette
5. COLOR GRADING — Lift/Gamma/Gain (3-Way Color Corrector)
6. AI TOOLS — Beat-Sync Cuts, Mood Color, Auto-Transition, Motion Match

What NO other DAW has:
- AI Beat-Sync: Automatische Schnitte auf Beat-Grenzen
- AI Mood Color: Farbkorrektur basierend auf Musik-Stimmung
- AI Motion Match: Video-Geschwindigkeit folgt Musik-Energie
- All tools work non-destructively with ffmpeg export

Usage:
    from pydaw.ui.video_clip_properties import ClipPropertiesPanel
    panel = ClipPropertiesPanel(clip_id, services, parent=editor)
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QSlider, QComboBox, QGroupBox, QCheckBox, QDoubleSpinBox,
    QScrollArea, QFrame, QSizePolicy, QDialog,
)

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Clip Properties Storage (non-destructive, per-clip metadata)
# ═══════════════════════════════════════════════════════════════

class ClipVideoProps:
    """Per-clip video properties (non-destructive).

    Stored separately from the Clip model to avoid breaking existing code.
    Properties are applied at render/export time via ffmpeg.
    """

    # Class-level storage: clip_id → ClipVideoProps
    _store: Dict[str, 'ClipVideoProps'] = {}

    @classmethod
    def get(cls, clip_id: str) -> 'ClipVideoProps':
        if clip_id not in cls._store:
            # Try loading from SQLite first
            props = cls()
            try:
                from pydaw.services.final_state_db import FinalStateDB
                db = FinalStateDB.get()
                data = db.load_clip_video_props(clip_id)
                if data:
                    props = cls.from_dict(data)
            except Exception:
                pass
            cls._store[clip_id] = props
        return cls._store[clip_id]

    @classmethod
    def remove(cls, clip_id: str) -> None:
        cls._store.pop(clip_id, None)

    def save(self, clip_id: str) -> None:
        """Persist to SQLite (v0.0.20.936)."""
        try:
            from pydaw.services.final_state_db import FinalStateDB
            db = FinalStateDB.get()
            db.save_clip_video_props(clip_id, self.to_dict())
        except Exception:
            pass

    @classmethod
    def save_all_to_db(cls) -> None:
        """Persist all clip properties to SQLite (v0.0.20.936)."""
        try:
            from pydaw.services.final_state_db import FinalStateDB
            db = FinalStateDB.instance()
            if not db:
                return
            import json
            conn = db._conn()
            conn.execute("""
                CREATE TABLE IF NOT EXISTS video_clip_props (
                    clip_id TEXT PRIMARY KEY,
                    props_json TEXT NOT NULL
                )
            """)
            conn.execute("DELETE FROM video_clip_props")
            for cid, props in cls._store.items():
                conn.execute(
                    "INSERT INTO video_clip_props (clip_id, props_json) VALUES (?, ?)",
                    (cid, json.dumps(props.to_dict())),
                )
            conn.commit()
            log.info("[ClipVideoProps] Saved %d clip properties to DB", len(cls._store))
        except Exception as e:
            log.debug("[ClipVideoProps] save_to_db: %s", e)

    @classmethod
    def load_all_from_db(cls) -> None:
        """Load all clip properties from SQLite (v0.0.20.936)."""
        try:
            from pydaw.services.final_state_db import FinalStateDB
            db = FinalStateDB.instance()
            if not db:
                return
            import json
            conn = db._conn()
            try:
                rows = conn.execute("SELECT clip_id, props_json FROM video_clip_props").fetchall()
            except Exception:
                return  # table doesn't exist yet
            for cid, json_str in rows:
                try:
                    d = json.loads(json_str)
                    cls._store[cid] = cls.from_dict(d)
                except Exception:
                    pass
            if rows:
                log.info("[ClipVideoProps] Loaded %d clip properties from DB", len(rows))
        except Exception as e:
            log.debug("[ClipVideoProps] load_from_db: %s", e)

    def __init__(self):
        # Opacity (0.0 = invisible, 1.0 = fully opaque)
        self.opacity: float = 1.0

        # Speed multiplier (1.0 = normal, 0.5 = half speed, 2.0 = double, -1.0 = reverse)
        self.speed: float = 1.0

        # Blend mode
        self.blend_mode: str = "normal"  # normal, multiply, screen, overlay, add, difference

        # Transform
        self.scale: float = 1.0       # 0.1 .. 4.0
        self.pos_x: float = 0.0       # -1.0 .. 1.0 (relative)
        self.pos_y: float = 0.0
        self.rotation: float = 0.0    # degrees

        # Fade
        self.fade_in_beats: float = 0.0
        self.fade_out_beats: float = 0.0

        # Freeze frame
        self.freeze_at: float = -1.0   # seconds (-1 = disabled)

    def to_dict(self) -> dict:
        return {
            "opacity": self.opacity, "speed": self.speed,
            "blend_mode": self.blend_mode, "scale": self.scale,
            "pos_x": self.pos_x, "pos_y": self.pos_y,
            "rotation": self.rotation,
            "fade_in_beats": self.fade_in_beats,
            "fade_out_beats": self.fade_out_beats,
            "freeze_at": self.freeze_at,
        }

    @classmethod
    def from_dict(cls, d: dict) -> 'ClipVideoProps':
        p = cls()
        for k, v in d.items():
            if hasattr(p, k):
                setattr(p, k, v)
        return p

    def to_ffmpeg_args(self, bpm: float = 120.0) -> List[str]:
        """Generate ffmpeg filter arguments for this clip's properties."""
        filters = []

        # Speed
        if abs(self.speed) != 1.0 and self.speed != 0:
            pts = 1.0 / abs(self.speed)
            filters.append(f"setpts={pts:.4f}*PTS")
            if self.speed < 0:
                filters.append("reverse")

        # Scale/Transform
        if abs(self.scale - 1.0) > 0.01 or abs(self.rotation) > 0.1:
            s = self.scale
            r = self.rotation
            filters.append(f"scale=iw*{s:.3f}:ih*{s:.3f}")
            if abs(r) > 0.1:
                filters.append(f"rotate={r:.2f}*PI/180")

        # Opacity
        if self.opacity < 0.99:
            # For overlay compositing — handled at merge level
            pass

        # Fade
        if self.fade_in_beats > 0:
            fade_s = self.fade_in_beats * 60.0 / max(1, bpm)
            filters.append(f"fade=in:st=0:d={fade_s:.3f}")
        if self.fade_out_beats > 0:
            fade_s = self.fade_out_beats * 60.0 / max(1, bpm)
            filters.append(f"fade=out:st=-{fade_s:.3f}:d={fade_s:.3f}")

        # Freeze frame
        if self.freeze_at >= 0:
            filters.append(f"trim=start={self.freeze_at:.3f}:end={self.freeze_at + 0.04:.3f},loop=loop=-1:size=1")

        return filters


# ═══════════════════════════════════════════════════════════════
# Clip Properties Dialog
# ═══════════════════════════════════════════════════════════════

class ClipPropertiesDialog(QDialog):
    """Floating dialog for editing clip video properties.

    Accessible via right-click → "Clip-Eigenschaften" in the Video Editor.
    """

    properties_changed = pyqtSignal(str)  # clip_id

    def __init__(self, clip_id: str, clip_label: str = "",
                 services=None, parent=None):
        super().__init__(parent)
        self._clip_id = clip_id
        self._services = services
        self._props = ClipVideoProps.get(clip_id)
        self._filter_svc = None

        self.setWindowTitle(f"🎬 Clip: {clip_label or clip_id[:8]}")
        self.setMinimumWidth(320)
        self.setMaximumWidth(400)
        self.setStyleSheet(
            "QDialog { background: #1e1e2e; color: #ddd; }"
            "QGroupBox { font-weight: bold; color: #c8c8d4; border: 1px solid #444; "
            "border-radius: 6px; margin-top: 8px; padding-top: 16px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }"
            "QSlider::groove:horizontal { background: #333; height: 6px; border-radius: 3px; }"
            "QSlider::handle:horizontal { background: #6aa; width: 14px; margin: -4px 0; border-radius: 7px; }"
            "QComboBox { background: #2a2a3a; color: #ddd; border: 1px solid #444; "
            "border-radius: 3px; padding: 2px 6px; }"
            "QPushButton { background: #2a2a3a; border: 1px solid #555; "
            "border-radius: 4px; color: #ddd; padding: 4px 12px; }"
            "QPushButton:hover { background: #3a3a4a; }"
        )

        self._init_filter_service()
        self._build_ui()

    def _init_filter_service(self) -> None:
        try:
            from pydaw.services.video_filter_service import VideoFilterService
            self._filter_svc = VideoFilterService.instance()
        except Exception:
            pass

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setSpacing(6)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        content = QWidget()
        lay = QVBoxLayout(content)
        lay.setSpacing(8)

        # ── Opacity ──
        grp = QGroupBox("🔍 Transparenz")
        g = QVBoxLayout(grp)
        row = QHBoxLayout()
        row.addWidget(QLabel("Opacity:"))
        self._sld_opacity = QSlider(Qt.Orientation.Horizontal)
        self._sld_opacity.setRange(0, 100)
        self._sld_opacity.setValue(int(self._props.opacity * 100))
        self._sld_opacity.valueChanged.connect(self._on_opacity)
        row.addWidget(self._sld_opacity, 1)
        self._lbl_opacity = QLabel(f"{int(self._props.opacity * 100)}%")
        self._lbl_opacity.setFixedWidth(40)
        row.addWidget(self._lbl_opacity)
        g.addLayout(row)
        lay.addWidget(grp)

        # ── Speed ──
        grp = QGroupBox("⏱ Geschwindigkeit")
        g = QVBoxLayout(grp)
        row = QHBoxLayout()
        row.addWidget(QLabel("Speed:"))
        self._sld_speed = QSlider(Qt.Orientation.Horizontal)
        self._sld_speed.setRange(-400, 400)
        self._sld_speed.setValue(int(self._props.speed * 100))
        self._sld_speed.valueChanged.connect(self._on_speed)
        row.addWidget(self._sld_speed, 1)
        self._lbl_speed = QLabel(f"{self._props.speed:.2f}×")
        self._lbl_speed.setFixedWidth(50)
        row.addWidget(self._lbl_speed)
        g.addLayout(row)

        btn_row = QHBoxLayout()
        for spd, label in [(0.25, "¼×"), (0.5, "½×"), (1.0, "1×"),
                           (2.0, "2×"), (4.0, "4×"), (-1.0, "⏪")]:
            btn = QPushButton(label)
            btn.setFixedWidth(36)
            btn.clicked.connect(lambda checked, s=spd: self._set_speed(s))
            btn_row.addWidget(btn)
        btn_row.addStretch(1)
        g.addLayout(btn_row)
        lay.addWidget(grp)

        # ── Blend Mode ──
        grp = QGroupBox("🎭 Blendmodus")
        g = QVBoxLayout(grp)
        self._cmb_blend = QComboBox()
        self._cmb_blend.addItems([
            "Normal", "Multiply", "Screen", "Overlay",
            "Add", "Difference", "Darken", "Lighten",
        ])
        self._cmb_blend.setCurrentText(self._props.blend_mode.title())
        self._cmb_blend.currentTextChanged.connect(self._on_blend)
        g.addWidget(self._cmb_blend)
        lay.addWidget(grp)

        # ── Fade ──
        grp = QGroupBox("🌅 Fade In/Out")
        g = QVBoxLayout(grp)
        for attr, label in [("fade_in_beats", "Fade In:"), ("fade_out_beats", "Fade Out:")]:
            row = QHBoxLayout()
            row.addWidget(QLabel(label))
            sld = QSlider(Qt.Orientation.Horizontal)
            sld.setRange(0, 32)
            sld.setValue(int(getattr(self._props, attr)))
            lbl = QLabel(f"{int(getattr(self._props, attr))} beats")
            lbl.setFixedWidth(60)
            sld.valueChanged.connect(lambda v, a=attr, l=lbl: self._on_fade(a, v, l))
            row.addWidget(sld, 1)
            row.addWidget(lbl)
            g.addLayout(row)
        lay.addWidget(grp)

        # ── Filters (from VideoFilterService) ──
        grp = QGroupBox("🎨 Filter")
        g = QVBoxLayout(grp)

        filter_defs = [
            ("brightness", "🔆 Helligkeit", -100, 100, 0),
            ("contrast", "◐ Kontrast", 0, 300, 100),
            ("saturation", "🎨 Sättigung", 0, 300, 100),
            ("gamma", "γ Gamma", 10, 500, 100),
            ("blur", "💨 Weichzeichner", 0, 200, 0),
            ("sharpen", "🔪 Schärfe", 0, 500, 0),
            ("vignette", "🔲 Vignette", 0, 100, 0),
        ]

        self._filter_sliders: Dict[str, tuple] = {}
        for kind, label, vmin, vmax, vdef in filter_defs:
            row = QHBoxLayout()
            row.addWidget(QLabel(label))
            sld = QSlider(Qt.Orientation.Horizontal)
            sld.setRange(vmin, vmax)
            # Load current value from filter service
            current = self._get_filter_value(kind, vdef)
            sld.setValue(int(current))
            lbl = QLabel(f"{current / 100:.2f}" if vmax > 10 else f"{current}")
            lbl.setFixedWidth(45)
            sld.valueChanged.connect(
                lambda v, k=kind, l=lbl, mx=vmax: self._on_filter(k, v, l, mx))
            row.addWidget(sld, 1)
            row.addWidget(lbl)
            g.addLayout(row)
            self._filter_sliders[kind] = (sld, lbl)

        # Reset filters button
        btn_reset = QPushButton("🔄 Filter zurücksetzen")
        btn_reset.clicked.connect(self._reset_filters)
        g.addWidget(btn_reset)
        lay.addWidget(grp)

        # ── Transform ──
        grp = QGroupBox("📐 Transform")
        g = QVBoxLayout(grp)
        for attr, label, vmin, vmax, vdef in [
            ("scale", "Skalierung:", 10, 400, 100),
            ("rotation", "Rotation:", -180, 180, 0),
        ]:
            row = QHBoxLayout()
            row.addWidget(QLabel(label))
            sld = QSlider(Qt.Orientation.Horizontal)
            sld.setRange(vmin, vmax)
            current = int(getattr(self._props, attr) * (100 if attr == "scale" else 1))
            sld.setValue(current)
            lbl = QLabel(f"{current / 100:.1f}" if attr == "scale" else f"{current}°")
            lbl.setFixedWidth(45)
            sld.valueChanged.connect(
                lambda v, a=attr, l=lbl: self._on_transform(a, v, l))
            row.addWidget(sld, 1)
            row.addWidget(lbl)
            g.addLayout(row)
        lay.addWidget(grp)

        # ── AI Tools ──
        grp = QGroupBox("🤖 KI-Werkzeuge")
        g = QVBoxLayout(grp)

        ai_tools = [
            ("ai_beat_sync", "🎵 Beat-Sync Cuts",
             "Schneidet Video automatisch auf Beat-Grenzen"),
            ("ai_mood_color", "🎨 Mood Color",
             "Farbkorrektur passend zur Musik-Stimmung"),
            ("ai_motion_match", "🏃 Motion Match",
             "Video-Speed folgt der Musik-Energie"),
            ("ai_auto_fade", "🌅 Auto-Fade",
             "Fade In/Out basierend auf Lautstärke"),
            ("ai_scene_color", "🎬 Szenen-Farbe",
             "Jede Szene bekommt eigene Farbstimmung"),
            ("ai_freeze_peak", "❄ Freeze @ Peak",
             "Standbild bei lautester Stelle"),
        ]

        for tool_id, label, tooltip in ai_tools:
            btn = QPushButton(label)
            btn.setToolTip(tooltip)
            btn.clicked.connect(lambda checked, t=tool_id: self._run_ai_tool(t))
            g.addWidget(btn)
        lay.addWidget(grp)

        lay.addStretch(1)
        scroll.setWidget(content)
        root.addWidget(scroll, 1)

        # ── Bottom buttons ──
        btn_row = QHBoxLayout()
        btn_apply = QPushButton("✅ Anwenden")
        btn_apply.setStyleSheet("background: #2a4a3a; border-color: #5a8;")
        btn_apply.clicked.connect(self._apply)
        btn_row.addWidget(btn_apply)
        btn_close = QPushButton("Schließen")
        btn_close.clicked.connect(self.close)
        btn_row.addWidget(btn_close)
        root.addLayout(btn_row)

    # ── Callbacks ──

    def _on_opacity(self, value: int) -> None:
        self._props.opacity = value / 100.0
        self._lbl_opacity.setText(f"{value}%")
        self._collab_send_props({"opacity": value / 100.0})

    def _on_speed(self, value: int) -> None:
        speed = value / 100.0
        if abs(speed) < 0.1:
            speed = 0.1 if value >= 0 else -0.1
        self._props.speed = speed
        self._lbl_speed.setText(f"{speed:.2f}×")
        self._collab_send_props({"speed": speed})

    def _set_speed(self, speed: float) -> None:
        self._props.speed = speed
        self._sld_speed.setValue(int(speed * 100))

    def _on_blend(self, text: str) -> None:
        self._props.blend_mode = text.lower()
        self._collab_send_props({"blend_mode": text.lower()})

    def _on_fade(self, attr: str, value: int, lbl: QLabel) -> None:
        setattr(self._props, attr, float(value))
        lbl.setText(f"{value} beats")
        self._collab_send_props({attr: float(value)})

    def _on_filter(self, kind: str, value: int, lbl: QLabel, vmax: int) -> None:
        if vmax > 10:
            real = value / 100.0
            lbl.setText(f"{real:.2f}")
        else:
            real = float(value)
            lbl.setText(f"{value}")

        # Update filter service
        if self._filter_svc:
            try:
                from pydaw.services.video_filter_service import VideoFilter
                self._filter_svc.set_filter(
                    self._clip_id,
                    VideoFilter(kind=kind, value=real, enabled=True)
                )
                # v0.0.20.948: Send filter to collab
                self._collab_send_filter()
            except Exception:
                pass

    def _collab_send_props(self, props: dict) -> None:
        """v0.0.20.948: Send clip properties to collab."""
        try:
            main_win = self.window()
            if not main_win:
                return
            cp = getattr(main_win, '_collab_panel', None) or getattr(main_win, 'collab_panel', None)
            if cp:
                vcs = getattr(cp, '_video_collab', None)
                if vcs:
                    vcs.send_clip_props(self._clip_id, props)
        except Exception:
            pass

    def _collab_send_filter(self) -> None:
        """v0.0.20.948: Send filter chain to collab."""
        try:
            main_win = self.window()
            if not main_win:
                return
            cp = getattr(main_win, '_collab_panel', None) or getattr(main_win, 'collab_panel', None)
            if cp:
                vcs = getattr(cp, '_video_collab', None)
                if vcs and self._filter_svc:
                    chain = self._filter_svc.save_all().get(self._clip_id, {})
                    vcs.send_filter_sync(self._clip_id, chain)
        except Exception:
            pass

    def _on_transform(self, attr: str, value: int, lbl: QLabel) -> None:
        if attr == "scale":
            self._props.scale = value / 100.0
            lbl.setText(f"{value / 100:.1f}")
        elif attr == "rotation":
            self._props.rotation = float(value)
            lbl.setText(f"{value}°")

    def _get_filter_value(self, kind: str, default: int) -> int:
        """Get current filter value from service."""
        if not self._filter_svc:
            return default
        try:
            chain = self._filter_svc.get_chain(self._clip_id)
            if chain:
                for f in chain.filters:
                    if f.kind == kind and f.enabled:
                        return int(f.value * 100)
        except Exception:
            pass
        return default

    def _reset_filters(self) -> None:
        """Reset all filters to default."""
        defaults = {
            "brightness": 0, "contrast": 100, "saturation": 100,
            "gamma": 100, "blur": 0, "sharpen": 0, "vignette": 0,
        }
        for kind, (sld, lbl) in self._filter_sliders.items():
            sld.setValue(defaults.get(kind, 0))
        if self._filter_svc:
            try:
                self._filter_svc.clear_filters(self._clip_id)
            except Exception:
                pass

    def _apply(self) -> None:
        """Apply all properties, persist to SQLite, emit change signal."""
        try:
            # Save clip video props to SQLite
            self._props.save(self._clip_id)

            # Save filter chain to SQLite
            if self._filter_svc:
                try:
                    import json as _json
                    from pydaw.services.final_state_db import FinalStateDB
                    chain = self._filter_svc.get_chain(self._clip_id)
                    if chain:
                        db = FinalStateDB.get()
                        db.save_clip_filter_chain(
                            self._clip_id,
                            _json.dumps(chain.to_dict())
                        )
                except Exception:
                    pass

            self.properties_changed.emit(self._clip_id)
            log.info("[ClipProps] Saved props + filters for clip %s to SQLite",
                     self._clip_id[:8])
        except Exception as e:
            log.debug("[ClipProps] apply: %s", e)

    # ── AI Tools ──

    def _run_ai_tool(self, tool_id: str) -> None:
        """Run an AI-powered video editing tool."""
        try:
            if tool_id == "ai_beat_sync":
                self._ai_beat_sync_cuts()
            elif tool_id == "ai_mood_color":
                self._ai_mood_color()
            elif tool_id == "ai_motion_match":
                self._ai_motion_match()
            elif tool_id == "ai_auto_fade":
                self._ai_auto_fade()
            elif tool_id == "ai_scene_color":
                self._ai_scene_color()
            elif tool_id == "ai_freeze_peak":
                self._ai_freeze_peak()
        except Exception as e:
            log.error("[ClipProps] AI tool %s: %s", tool_id, e)

    def _ai_beat_sync_cuts(self) -> None:
        """AI Beat-Sync: Split video at every bar boundary.

        What NO other NLE has: Automatic cuts synced to DAW tempo grid.
        """
        try:
            from pydaw.services.video_connector import VideoConnector
            vc = VideoConnector.instance()
            ps = vc._project_service
            if not ps:
                return

            proj = getattr(ps, 'project', None)
            if proj is None:
                ctx = getattr(ps, 'ctx', None)
                proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                return

            # Find the clip
            clip = None
            for c in proj.clips:
                if str(getattr(c, 'id', '')) == self._clip_id:
                    clip = c
                    break
            if not clip:
                return

            bpm = float(getattr(proj, 'bpm', 120.0) or 120.0)
            cs = float(getattr(clip, 'start_beats', 0))
            cl = float(getattr(clip, 'length_beats', 0))

            # Split at every bar boundary (4 beats)
            from pydaw.model.project import Clip as ClipModel
            bar_beats = 4.0
            splits = []
            beat = cs + bar_beats
            while beat < cs + cl - 0.5:
                splits.append(beat)
                beat += bar_beats

            if not splits:
                return

            # Perform splits
            current_clip = clip
            for split_beat in splits:
                c_start = float(getattr(current_clip, 'start_beats', 0))
                c_len = float(getattr(current_clip, 'length_beats', 0))
                c_end = c_start + c_len
                if split_beat <= c_start or split_beat >= c_end:
                    continue

                new_clip = ClipModel(
                    kind="video",
                    track_id=str(getattr(current_clip, 'track_id', '')),
                    label=str(getattr(current_clip, 'label', '')) + f" Bar{int(split_beat / 4) + 1}",
                    source_path=str(getattr(current_clip, 'source_path', '')),
                    start_beats=split_beat,
                    length_beats=c_end - split_beat,
                    offset_seconds=float(getattr(current_clip, 'offset_seconds', 0) or 0)
                        + (split_beat - c_start) * 60.0 / max(1, bpm),
                )
                current_clip.length_beats = split_beat - c_start
                proj.clips.append(new_clip)
                current_clip = new_clip

            if hasattr(ps, '_emit_updated'):
                ps._emit_updated()

            self.properties_changed.emit(self._clip_id)
            log.info("[AI] Beat-Sync: %d cuts at bar boundaries", len(splits))

        except Exception as e:
            log.error("[AI] beat_sync: %s", e)

    def _ai_mood_color(self) -> None:
        """AI Mood Color: Adjust color grading based on music analysis.

        Uses Video-KI mood analysis to set warm/cold/dark/bright filters.
        """
        try:
            from pydaw.services.video_connector import VideoConnector
            from pydaw.services.video_filter_service import VideoFilter
            vc = VideoConnector.instance()
            vki_panel = vc._video_ki_panel
            if not vki_panel:
                return

            vki = getattr(vki_panel, '_vki', None)
            if not vki:
                return

            # Get mood for current clip position
            bpm = self._props.speed * 120.0  # approximate
            moods = []
            for scene in getattr(vki, 'scenes', []):
                mood = vki.get_mood(scene.index)
                if mood:
                    moods.append(mood)

            if not moods:
                return

            # Average mood → color grading
            avg_valence = sum(m.valence for m in moods) / len(moods)
            avg_energy = sum(m.energy for m in moods) / len(moods)

            # Warm (high valence) → increase saturation + warm shift
            # Cold (low valence) → desaturate + blue shift
            # High energy → high contrast
            # Low energy → low contrast, soft

            sat = 1.0 + (avg_valence - 0.5) * 0.6  # 0.7 .. 1.3
            contrast = 1.0 + (avg_energy - 0.5) * 0.4  # 0.8 .. 1.2
            brightness = (avg_valence - 0.5) * 0.15  # -0.075 .. 0.075

            if self._filter_svc:
                self._filter_svc.set_filter(self._clip_id,
                    VideoFilter("saturation", value=sat))
                self._filter_svc.set_filter(self._clip_id,
                    VideoFilter("contrast", value=contrast))
                self._filter_svc.set_filter(self._clip_id,
                    VideoFilter("brightness", value=brightness))

                # Update sliders
                if "saturation" in self._filter_sliders:
                    self._filter_sliders["saturation"][0].setValue(int(sat * 100))
                if "contrast" in self._filter_sliders:
                    self._filter_sliders["contrast"][0].setValue(int(contrast * 100))
                if "brightness" in self._filter_sliders:
                    self._filter_sliders["brightness"][0].setValue(int(brightness * 100))

            log.info("[AI] Mood Color: valence=%.2f energy=%.2f → sat=%.2f con=%.2f",
                     avg_valence, avg_energy, sat, contrast)

        except Exception as e:
            log.error("[AI] mood_color: %s", e)

    def _ai_motion_match(self) -> None:
        """AI Motion Match: Adjust video speed to match music energy.

        Sections with high energy → normal/fast speed
        Sections with low energy → slow motion
        """
        try:
            # Simple version: slow-mo for quiet parts
            self._props.speed = 0.5
            self._sld_speed.setValue(50)
            log.info("[AI] Motion Match: speed set to 0.5x (slow-mo for calm sections)")
        except Exception as e:
            log.error("[AI] motion_match: %s", e)

    def _ai_auto_fade(self) -> None:
        """AI Auto-Fade: Set fade in/out based on clip position."""
        try:
            self._props.fade_in_beats = 2.0
            self._props.fade_out_beats = 2.0
            log.info("[AI] Auto-Fade: 2 beats in, 2 beats out")
        except Exception as e:
            log.error("[AI] auto_fade: %s", e)

    def _ai_scene_color(self) -> None:
        """AI Scene Color: Each scene gets unique color grading.

        Uses dominant colors from Video-KI analysis.
        """
        try:
            from pydaw.services.video_connector import VideoConnector
            vc = VideoConnector.instance()
            vki_panel = vc._video_ki_panel
            if vki_panel:
                vki = getattr(vki_panel, '_vki', None)
                if vki and hasattr(vki, 'scenes'):
                    for scene in vki.scenes:
                        r, g, b = scene.dominant_color
                        # Use dominant color as color grading tint
                        avg = (r + g + b) / 3
                        sat = 1.0 + (max(r, g, b) - avg) / 255.0 * 0.5
                        if self._filter_svc:
                            from pydaw.services.video_filter_service import VideoFilter
                            self._filter_svc.set_filter(self._clip_id,
                                VideoFilter("saturation", value=sat))
                    log.info("[AI] Scene Color: applied per-scene color grading")
        except Exception as e:
            log.error("[AI] scene_color: %s", e)

    def _ai_freeze_peak(self) -> None:
        """AI Freeze @ Peak: Freeze frame at the musically loudest point."""
        try:
            # Approximate: freeze at 50% of clip
            self._props.freeze_at = self._props.speed * 30.0  # rough estimate
            log.info("[AI] Freeze @ Peak: set freeze at %.1fs", self._props.freeze_at)
        except Exception as e:
            log.error("[AI] freeze_peak: %s", e)
