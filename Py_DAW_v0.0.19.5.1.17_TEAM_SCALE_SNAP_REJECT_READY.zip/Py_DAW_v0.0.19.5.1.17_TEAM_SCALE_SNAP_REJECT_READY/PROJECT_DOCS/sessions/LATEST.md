# LATEST

Aktuellste Session: **2026-02-02_SESSION_SCALE_SNAP_REJECT.md** (v0.0.19.5.1.17)

Kurz:
- Scale Lock: **Snap** oder **Reject** (Bitwig/Rosegarden-Style Workflow)
- UI: Scale-Button in PianoRoll + Notation Palette
- Enforcement: Note-Input wird je nach Modus gesnappt oder verworfen
