"""Settings keys and persistence hooks (placeholders).

In later versions, this module will manage:
- audio backend selection (PipeWire/JACK, device routing)
- last opened project
- UI layout persistence
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SettingsKeys:
    organization: str = "PyDAW"
    application: str = "Py DAW"

    # Future keys (v0.0.2+)
    last_project: str = "ui/last_project"
    audio_backend: str = "audio/backend"
    audio_input: str = "audio/input"
    audio_output: str = "audio/output"
    sample_rate: str = "audio/sample_rate"
    buffer_size: str = "audio/buffer_size"
    jack_enable: str = "audio/jack_enable"
    jack_in_ports: str = "audio/jack_in_ports"
    jack_out_ports: str = "audio/jack_out_ports"
    jack_input_monitor: str = "audio/jack_input_monitor"  # global passthrough monitoring

    # Performance (MIDI pre-render)
    prerender_auto_on_load: str = "audio/prerender_auto_on_load"
    prerender_show_progress_on_load: str = "audio/prerender_show_progress_on_load"
    prerender_wait_before_play: str = "audio/prerender_wait_before_play"
    prerender_show_progress_on_play: str = "audio/prerender_show_progress_on_play"

    # UI
    ui_enable_notation_tab: str = "ui/enable_notation_tab"  # show Notation tab entry (WIP)

    # Scale constraint (Piano Roll + Notation)
    # When enabled, note input is restricted to the selected scale.
    # Mode:
    #   - "snap": out-of-scale pitches are snapped to the nearest in-scale pitch
    #   - "reject": out-of-scale pitches are rejected (nothing is created)
    scale_enabled: str = "music/scale_enabled"
    scale_root_pc: str = "music/scale_root_pc"  # 0..11 (C..B)
    scale_category: str = "music/scale_category"  # e.g. "Kirchentonarten"
    scale_name: str = "music/scale_name"  # e.g. "Dorian"
    scale_mode: str = "music/scale_mode"  # "snap" | "reject"
