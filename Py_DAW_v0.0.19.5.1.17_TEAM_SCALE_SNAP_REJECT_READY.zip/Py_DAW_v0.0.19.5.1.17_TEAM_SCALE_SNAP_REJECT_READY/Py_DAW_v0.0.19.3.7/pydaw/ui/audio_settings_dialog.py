"""Audio settings dialog (v0.0.2).

This dialog is intentionally pragmatic:
- It detects the best backend (prefer JACK / PipeWire-JACK).
- It lists available input/output endpoints.
- It persists selections via QSettings wrapper.
- It can start/stop a minimal 'audio thread' as a non-blocking proof-of-structure.
"""

from __future__ import annotations

import os
import shutil

from PyQt6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QComboBox,
    QPushButton,
    QGroupBox,
    QFormLayout,
    QMessageBox,
    QSpinBox,
    QDialogButtonBox,
    QCheckBox,
)
from PyQt6.QtCore import Qt

from pydaw.audio.audio_engine import AudioEngine, Backend
from pydaw.services.jack_client_service import JackClientService

from pydaw.core.settings import SettingsKeys
from pydaw.core.settings_store import get_value, set_value


class AudioSettingsDialog(QDialog):
    def __init__(self, engine: AudioEngine, jack: JackClientService | None = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Audio-Einstellungen")
        self.setModal(True)

        # Wird vom MainWindow ausgewertet: nach "OK" die App automatisch neu starten
        # (z. B. für PipeWire-JACK via pw-jack oder nach Port-Änderungen)
        self.restart_requested: bool = False
        self.restart_via_pw_jack: bool = False

        self.engine = engine
        self.jack = jack
        self.keys = SettingsKeys()

        self._build_ui()
        self._load()

        # Wenn JACK als Backend gespeichert ist, aber aktuell kein Server erreichbar ist,
        # darf der Dialog nicht "leer" wirken (Inputs/Outputs = keine). Wir fallen
        # in der UI automatisch auf sounddevice zurück und zeigen einen Hinweis.
        try:
            if self.cmb_backend.currentData() == "jack" and not JackClientService.probe_available():
                idx = self.cmb_backend.findData("sounddevice")
                if idx >= 0:
                    self.cmb_backend.setCurrentIndex(idx)
                self._set_status(
                    "JACK ist aktuell nicht erreichbar (Server/Bridge läuft nicht). "
                    "Fallback: sounddevice. Tipp: mit 'pw-jack python3 main.py' starten "
                    "oder pipewire-jack/jackd prüfen."
                )
        except Exception:
            pass

        # Snapshot für Restart-Entscheidung
        self._orig_backend = self.cmb_backend.currentText()
        self._orig_jack_enable = self.chk_jack_enable.isChecked()
        self._orig_in_pairs = int(self.spin_jack_in.value())
        self._orig_out_pairs = int(self.spin_jack_out.value())
        self._orig_monitor = self.chk_jack_monitor.isChecked()
        self._refresh_lists()

        # Engine feedback -> UI
        self.engine.status.connect(self._set_status)
        self.engine.error.connect(self._on_error)

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        self.lbl_status = QLabel("Erkennung läuft…")
        self.lbl_status.setWordWrap(True)
        layout.addWidget(self.lbl_status)

        box = QGroupBox("Backend & Routing")
        form = QFormLayout(box)

        self.cmb_backend = QComboBox()
        self.cmb_backend.addItem("JACK (PipeWire bevorzugt)", "jack")
        self.cmb_backend.addItem("sounddevice (PortAudio)", "sounddevice")
        self.cmb_backend.addItem("Keins", "none")
        self.cmb_backend.currentIndexChanged.connect(self._on_backend_changed)

        self.cmb_input = QComboBox()
        self.cmb_output = QComboBox()

        form.addRow("Backend", self.cmb_backend)
        form.addRow("Input", self.cmb_input)
        form.addRow("Output", self.cmb_output)

        layout.addWidget(box)


        jack_box = QGroupBox("JACK / PipeWire-JACK (Ports)")
        jack_form = QFormLayout(jack_box)

        self.chk_jack_enable = QCheckBox("JACK Client aktivieren (PyDAW in qpwgraph sichtbar)")
        # UI: Stereo-Paare (Bitwig-Style). Intern werden Kanäle gespeichert.
        self.spin_jack_in = QSpinBox()
        self.spin_jack_in.setRange(1, 32)   # 1..32 Stereo Inputs = 2..64 Kanäle
        self.spin_jack_in.setValue(1)
        self.spin_jack_out = QSpinBox()
        self.spin_jack_out.setRange(1, 32)  # 1..32 Stereo Outputs = 2..64 Kanäle
        self.spin_jack_out.setValue(1)

        # Global input monitoring (passthrough). Default OFF to avoid feedback loops.
        self.chk_jack_monitor = QCheckBox("Input Monitoring (Inputs → Outputs)")

        jack_form.addRow(self.chk_jack_enable)
        jack_form.addRow("Stereo-Inputs (Paare)", self.spin_jack_in)
        jack_form.addRow("Stereo-Outputs (Paare)", self.spin_jack_out)
        jack_form.addRow(self.chk_jack_monitor)

        layout.addWidget(jack_box)

        perf = QGroupBox("Audio-Parameter (Platzhalter)")
        perf_form = QFormLayout(perf)

        self.spin_sr = QSpinBox()
        self.spin_sr.setRange(8000, 384000)
        self.spin_sr.setSingleStep(1000)

        self.spin_buf = QSpinBox()
        self.spin_buf.setRange(16, 8192)
        self.spin_buf.setSingleStep(16)

        perf_form.addRow("Samplerate", self.spin_sr)
        perf_form.addRow("Buffer Size", self.spin_buf)

        layout.addWidget(perf)

        # Minimal controls for demonstration (non-blocking)
        row = QHBoxLayout()
        self.btn_start = QPushButton("Test: Start (Silence)")
        self.btn_stop = QPushButton("Stop")
        self.btn_stop.setEnabled(True)

        self.btn_start.clicked.connect(self._start_audio)
        self.btn_stop.clicked.connect(self.engine.stop)

        row.addWidget(self.btn_start)
        row.addWidget(self.btn_stop)
        row.addStretch(1)
        layout.addLayout(row)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        self._buttons = buttons
        self._btn_ok = buttons.button(QDialogButtonBox.StandardButton.Ok)
        layout.addWidget(buttons)

    def _set_status(self, msg: str) -> None:
        self.lbl_status.setText(msg)

    def _on_error(self, msg: str) -> None:
        QMessageBox.warning(self, "Audio-Fehler", msg)

    def _on_backend_changed(self) -> None:
        self._refresh_lists()

    def _refresh_lists(self) -> None:
        backend: Backend = self.cmb_backend.currentData()

        # Für JACK nur dann enumerieren, wenn ein Server erreichbar ist.
        # Sonst: kein Terminal-Spam + keine leeren Dropdowns.
        jack_ok = True
        if backend == "jack":
            jack_ok = JackClientService.probe_available()
            if not jack_ok:
                self._set_status(
                    "JACK nicht erreichbar. "
                    "Start ggf. mit 'pw-jack python3 main.py' oder stelle sicher, "
                    "dass PipeWire-JACK/JACK läuft."
                )
        elif backend == "sounddevice":
            self._set_status("sounddevice: Geräte werden aufgelistet.")
        else:
            self._set_status("Kein Backend ausgewählt.")

        self.cmb_input.clear()
        self.cmb_output.clear()

        # JACK: Routing läuft über Ports in qpwgraph. Die "Input/Output"-Dropdowns
        # sind hier nur als Status/Info gedacht. Wenn kein Server: nur Hinweis.
        if backend == "jack" and not jack_ok:
            self.cmb_input.addItem("(JACK Ports: über qpwgraph routen)", "")
            self.cmb_output.addItem("(JACK Ports: über qpwgraph routen)", "")
            self.cmb_input.setEnabled(False)
            self.cmb_output.setEnabled(False)
            if self._btn_ok is not None:
                # OK bleibt möglich (Settings speichern), aber wir verhindern später,
                # dass leere I/O IDs persistiert werden.
                self._btn_ok.setEnabled(True)
            return

        self.cmb_input.setEnabled(True)
        self.cmb_output.setEnabled(True)

        inputs = self.engine.list_inputs(backend)
        outputs = self.engine.list_outputs(backend)

        for ep in inputs:
            self.cmb_input.addItem(ep.label, ep.id)
        for ep in outputs:
            self.cmb_output.addItem(ep.label, ep.id)

        if self.cmb_input.count() == 0:
            self.cmb_input.addItem("(keine Inputs gefunden)", "")
        if self.cmb_output.count() == 0:
            self.cmb_output.addItem("(keine Outputs gefunden)", "")

        # Restore selection if possible (nur relevant für sounddevice)
        if backend == "sounddevice":
            saved_in = str(get_value(self.keys.audio_input, ""))
            saved_out = str(get_value(self.keys.audio_output, ""))
            self._select_if_present(self.cmb_input, saved_in)
            self._select_if_present(self.cmb_output, saved_out)

    @staticmethod
    def _select_if_present(cmb: QComboBox, data: str) -> None:
        if not data:
            return
        for i in range(cmb.count()):
            if str(cmb.itemData(i)) == data:
                cmb.setCurrentIndex(i)
                return

    def _load(self) -> None:
        saved_backend = str(get_value(self.keys.audio_backend, self.engine.backend))
        self._select_if_present(self.cmb_backend, saved_backend)

        # JACK client preferences
        en = str(get_value(self.keys.jack_enable, "0"))
        self.chk_jack_enable.setChecked(en.lower() in ("1","true","yes","on"))
        # Persistenz bleibt als Kanalzahl (abwärtskompatibel). GUI zeigt Stereo-Paare.
        in_ch = int(get_value(self.keys.jack_in_ports, 2))
        out_ch = int(get_value(self.keys.jack_out_ports, 2))
        in_pairs = max(1, (in_ch + 1) // 2)
        out_pairs = max(1, (out_ch + 1) // 2)
        self.spin_jack_in.setValue(min(in_pairs, self.spin_jack_in.maximum()))
        self.spin_jack_out.setValue(min(out_pairs, self.spin_jack_out.maximum()))

        mon = str(get_value(self.keys.jack_input_monitor, "0"))
        self.chk_jack_monitor.setChecked(mon.lower() in ("1","true","yes","on"))

        sr = int(get_value(self.keys.sample_rate, 48000))
        buf = int(get_value(self.keys.buffer_size, 256))
        self.spin_sr.setValue(sr)
        self.spin_buf.setValue(buf)

    def accept(self) -> None:
        # sounddevice: Device-IDs persistieren.
        # JACK: nicht überschreiben (sonst landet "" im Store und der Dialog wirkt leer).
        if self.cmb_backend.currentData() == "sounddevice":
            set_value(self.keys.audio_input, self.cmb_input.currentData())
            set_value(self.keys.audio_output, self.cmb_output.currentData())
        set_value(self.keys.sample_rate, self.spin_sr.value())
        set_value(self.keys.buffer_size, self.spin_buf.value())

        # Persist JACK config and apply immediately (without restarting GUI)
        jack_enabled = self.chk_jack_enable.isChecked()
        # If JACK is enabled, we run the engine in JACK mode to guarantee that
        # a "PyDAW" node appears in QPWGraph and routing behaves like Bitwig.
        if jack_enabled:
            idx = self.cmb_backend.findData("jack")
            if idx >= 0:
                self.cmb_backend.setCurrentIndex(idx)

        set_value(self.keys.audio_backend, self.cmb_backend.currentData())
        jack_in_pairs = self.spin_jack_in.value()
        jack_out_pairs = self.spin_jack_out.value()
        jack_in = int(jack_in_pairs) * 2
        jack_out = int(jack_out_pairs) * 2
        jack_monitor = self.chk_jack_monitor.isChecked()
        set_value(self.keys.jack_enable, "1" if jack_enabled else "0")
        set_value(self.keys.jack_in_ports, jack_in)
        set_value(self.keys.jack_out_ports, jack_out)
        set_value(self.keys.jack_input_monitor, "1" if jack_monitor else "0")
        try:
            os.environ["PYDAW_ENABLE_JACK"] = "1" if jack_enabled else "0"
            os.environ["PYDAW_JACK_IN"] = str(jack_in)
            os.environ["PYDAW_JACK_OUT"] = str(jack_out)
            os.environ["PYDAW_JACK_MONITOR"] = "1" if jack_monitor else "0"
        except Exception:
            pass
        if self.jack is not None:
            try:
                self.jack.apply_config(
                    enabled=jack_enabled,
                    in_ch=jack_in,
                    out_ch=jack_out,
                    monitor=jack_monitor,
                )
            except Exception:
                pass

        # Auto-Restart-Logik:
        # - Backend/JACK-Config ändern sollte die Audio-Initialisierung neu starten
        # - Wenn JACK unter PipeWire läuft, ist oft `pw-jack` erforderlich.
        backend_changed = (self.cmb_backend.currentText() != self._orig_backend)
        jack_changed = (
            (jack_enabled != self._orig_jack_enable)
            or (int(jack_in_pairs) != self._orig_in_pairs)
            or (int(jack_out_pairs) != self._orig_out_pairs)
            or (jack_monitor != self._orig_monitor)
        )

        # If we're already in JACK mode, changing only the port layout should not restart the whole GUI.
        only_jack_layout_change = (
            (not backend_changed)
            and jack_changed
            and jack_enabled
            and (self._orig_jack_enable is True)
        )

        if only_jack_layout_change and self.jack is not None and getattr(self.jack, "is_active", lambda: False)():
            try:
                # Recreate ports in-process (QPWGraph node refreshes) without re-exec.
                self.jack.reconfigure_ports(in_ch=jack_in, out_ch=jack_out, passthrough=jack_monitor)
                self.restart_requested = False
            except Exception:
                self.restart_requested = True

        # Default: wenn sich Backend/JACK-Config ändert, ist ein Restart sinnvoll.
        # (MainWindow entscheidet, ob wirklich re-exec gemacht wird.)
        if backend_changed or jack_changed:
            self.restart_requested = True
            if jack_enabled and self.cmb_backend.currentData() == "jack":
                # Wenn JACK nicht erreichbar ist, optional Relaunch via pw-jack.
                if not JackClientService.probe_available():
                    if shutil.which("pw-jack") and os.environ.get("PYDAW_PWJACK", "0") != "1":
                        self.restart_via_pw_jack = True

        super().accept()

    def _start_audio(self) -> None:
        backend: Backend = self.cmb_backend.currentData()
        cfg = {
            "sample_rate": self.spin_sr.value(),
            "buffer_size": self.spin_buf.value(),
            "input_device": self.cmb_input.currentData(),
            "output_device": self.cmb_output.currentData(),
        }
        self.engine.set_backend(backend)
        self.engine.start(backend=backend, config=cfg)
