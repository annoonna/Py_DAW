"""Notation editing tools (WIP).

Implements **Task 4 (Draw-Tool)** from ``PROJECT_DOCS/progress/TODO.md``.

Scope / Philosophy
------------------
This is intentionally minimal and pragmatic:

- We only implement the first editable action: **Draw a note** by click.
- Undo integration is supported via :meth:`pydaw.services.project_service.ProjectService.commit_midi_notes_edit`.
- The conversion from mouse position to musical data is kept simple:
  - X axis -> beat (snapped to project grid)
  - Y axis -> staff line/space -> diatonic pitch (natural notes for now)

Future tasks (TODO.md): Erase-Tool, Select-Tool, shortcuts, bidirectional sync.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from PyQt6.QtCore import QPointF, Qt

from pydaw.model.midi import MidiNote


def snap_beats_from_div(division: str) -> float:
    """Return beat grid size for a division string like "1/16"."""

    mapping = {
        "1/4": 1.0,
        "1/8": 0.5,
        "1/16": 0.25,
        "1/32": 0.125,
        "1/64": 0.0625,
    }
    return float(mapping.get(str(division), 0.25))


def snap_to_grid(value: float, step: float) -> float:
    """Snap a float value to a grid step."""

    s = float(step) if float(step) > 1e-9 else 0.25
    return round(float(value) / s) * s


@dataclass
class ToolResult:
    """Optional feedback from tool actions."""

    status: str = ""
    changed: bool = False


class NotationTool:
    """Base class for notation interaction tools."""

    name: str = "Tool"

    def handle_mouse_press(self, view, scene_pos: QPointF, button: Qt.MouseButton, modifiers: Qt.KeyboardModifier) -> ToolResult:
        return ToolResult("", False)


class DrawTool(NotationTool):
    """Draw notes by clicking on the staff."""

    name = "Draw"

    def handle_mouse_press(self, view, scene_pos: QPointF, button: Qt.MouseButton, modifiers: Qt.KeyboardModifier) -> ToolResult:
        # Only left click draws
        if button != Qt.MouseButton.LeftButton:
            return ToolResult("", False)

        clip_id = getattr(view, "clip_id", None)
        if not clip_id:
            return ToolResult("Kein MIDI-Clip ausgewählt.", False)

        ps = getattr(view, "project_service", None)
        if ps is None:
            return ToolResult("ProjectService fehlt.", False)

        # X -> beat
        beat = view.scene_x_to_beat(float(scene_pos.x()))
        snap_div = str(getattr(ps.ctx.project, "snap_division", "1/16") or "1/16")
        snap = snap_beats_from_div(snap_div)
        beat = max(0.0, snap_to_grid(beat, snap))

        # Y -> staff_line -> pitch
        staff_line = view.scene_y_to_staff_line(float(scene_pos.y()))
        pitch = view.staff_line_to_pitch(int(staff_line), accidental=0)

        # Length: 1 grid step (MVP)
        length = float(snap)

        # Undo snapshot
        before = ps.snapshot_midi_notes(str(clip_id))

        ps.add_midi_note(str(clip_id), pitch=int(pitch), start_beats=float(beat), length_beats=float(length), velocity=100)
        ps.commit_midi_notes_edit(str(clip_id), before, "Draw Note (Notation)")

        return ToolResult(f"Note hinzugefügt: pitch={pitch}, beat={beat:.3f} (Grid {snap_div})", True)


def _nearest_note_index(
    view,
    notes: list[MidiNote],
    *,
    target_beat: float,
    target_staff_line: int,
    snap_step: float,
) -> Optional[int]:
    """Pick the most likely note under the cursor.

    We keep this deliberately simple for MVP:
    - Prefer notes whose *staff line* matches (±1).
    - Prefer notes whose start beat is close to the click (within ~0.75 grid).

    Returns:
        Index into ``notes`` or ``None`` if nothing is close enough.
    """

    if not notes:
        return None

    try:
        snap = float(snap_step) if float(snap_step) > 1e-9 else 0.25
    except Exception:
        snap = 0.25

    pitch_to_staff = getattr(view, "_pitch_to_staff_line", None)
    best_idx: Optional[int] = None
    best_score = 1e9

    for i, n in enumerate(list(notes)):
        try:
            sb = float(getattr(n, "start_beats", 0.0))
            p = int(getattr(n, "pitch", 60))
        except Exception:
            continue

        # Prefer view's internal mapping (keeps behavior identical to rendering).
        if callable(pitch_to_staff):
            try:
                sl = int(pitch_to_staff(p))
            except Exception:
                sl = 0
        else:
            # Fallback: use diatonic staff position.
            try:
                tmp = MidiNote(pitch=p, start_beats=0.0, length_beats=1.0, velocity=100)
                line, octv = tmp.to_staff_position()
                # Convert to the same half-step index that NotationView uses.
                diat = int(octv) * 7 + int(line)
                e4_ref = int(4) * 7 + int(2)  # E4 bottom line
                sl = int(diat - e4_ref)
            except Exception:
                continue

        d_beat = abs(sb - float(target_beat))
        d_line = abs(int(sl) - int(target_staff_line))

        # Hard gate so we don't delete the wrong note.
        if d_beat > snap * 0.75:
            continue
        if d_line > 1:
            continue

        # Weighted score: time distance dominates, line distance breaks ties.
        score = (d_beat / max(1e-9, snap)) + (d_line * 0.35)
        if score < best_score:
            best_score = score
            best_idx = int(i)

    return best_idx


class EraseTool(NotationTool):
    """Erase notes by clicking on them.

    MVP behavior:
    - Deletes the closest note at the clicked *beat* (within the current snap grid)
      and *staff line* (±1).
    - Uses the ProjectService undo stack via ``commit_midi_notes_edit``.
    """

    name = "Erase"

    def handle_mouse_press(self, view, scene_pos: QPointF, button: Qt.MouseButton, modifiers: Qt.KeyboardModifier) -> ToolResult:
        # Erase expects either left click (if the tool is active) or right click (view routes it).
        if button not in (Qt.MouseButton.LeftButton, Qt.MouseButton.RightButton):
            return ToolResult("", False)

        clip_id = getattr(view, "clip_id", None)
        if not clip_id:
            return ToolResult("Kein MIDI-Clip ausgewählt.", False)

        ps = getattr(view, "project_service", None)
        if ps is None:
            return ToolResult("ProjectService fehlt.", False)

        try:
            notes = list(ps.get_midi_notes(str(clip_id)))
        except Exception:
            notes = []
        if not notes:
            return ToolResult("Keine Noten zum Löschen.", False)

        # Beat and grid
        beat = view.scene_x_to_beat(float(scene_pos.x()))
        snap_div = str(getattr(ps.ctx.project, "snap_division", "1/16") or "1/16")
        snap = snap_beats_from_div(snap_div)
        beat = max(0.0, snap_to_grid(float(beat), float(snap)))

        # Staff line
        staff_line = int(view.scene_y_to_staff_line(float(scene_pos.y())))

        idx = _nearest_note_index(view, notes, target_beat=float(beat), target_staff_line=int(staff_line), snap_step=float(snap))
        if idx is None:
            return ToolResult("Keine Note an dieser Position gefunden.", False)

        before = ps.snapshot_midi_notes(str(clip_id))
        ps.delete_midi_note_at(str(clip_id), int(idx))
        ps.commit_midi_notes_edit(str(clip_id), before, "Erase Note (Notation)")
        return ToolResult(f"Note gelöscht (Index {idx}, Grid {snap_div}).", True)


class SelectTool(NotationTool):
    """Select notes by clicking on them.

    MVP behavior:
    - **Left click** selects the closest note near the clicked beat+staff line.
    - Clicking empty space clears the selection.
    - Clicking the already-selected note toggles selection off.

    The view is responsible for rendering the selection state.
    """

    name = "Select"

    def handle_mouse_press(self, view, scene_pos: QPointF, button: Qt.MouseButton, modifiers: Qt.KeyboardModifier) -> ToolResult:
        if button != Qt.MouseButton.LeftButton:
            return ToolResult("", False)

        clip_id = getattr(view, "clip_id", None)
        if not clip_id:
            return ToolResult("Kein MIDI-Clip ausgewählt.", False)

        ps = getattr(view, "project_service", None)
        if ps is None:
            return ToolResult("ProjectService fehlt.", False)

        try:
            notes = list(ps.get_midi_notes(str(clip_id)))
        except Exception:
            notes = []

        if not notes:
            # Clear selection if the clip is empty.
            try:
                view.clear_selection()
            except Exception:
                pass
            return ToolResult("Keine Noten im Clip.", False)

        # Beat and grid (reuse the same heuristic as EraseTool so selection feels consistent)
        beat = view.scene_x_to_beat(float(scene_pos.x()))
        snap_div = str(getattr(ps.ctx.project, "snap_division", "1/16") or "1/16")
        snap = snap_beats_from_div(snap_div)
        beat = max(0.0, snap_to_grid(float(beat), float(snap)))

        staff_line = int(view.scene_y_to_staff_line(float(scene_pos.y())))
        idx = _nearest_note_index(view, notes, target_beat=float(beat), target_staff_line=int(staff_line), snap_step=float(snap))

        if idx is None:
            try:
                view.clear_selection()
            except Exception:
                pass
            return ToolResult("Auswahl gelöscht.", False)

        # Toggle selection if the same note is clicked again.
        try:
            if view.is_selected_note(notes[idx]):
                view.clear_selection()
                return ToolResult("Auswahl gelöscht.", False)
        except Exception:
            pass

        try:
            view.select_note(notes[idx])
        except Exception:
            pass

        try:
            n = notes[idx]
            return ToolResult(f"Note ausgewählt: pitch={int(getattr(n, 'pitch', 0))}, beat={float(getattr(n, 'start_beats', 0.0)):.3f}", False)
        except Exception:
            return ToolResult("Note ausgewählt.", False)
