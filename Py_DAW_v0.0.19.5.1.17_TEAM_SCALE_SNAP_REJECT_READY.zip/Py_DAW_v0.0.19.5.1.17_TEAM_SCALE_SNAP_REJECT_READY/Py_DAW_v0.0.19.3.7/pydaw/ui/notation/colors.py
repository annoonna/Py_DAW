"""Color helpers for notation.

Implements Task 10 (Velocity → Color Mapping) from PROJECT_DOCS/progress/TODO.md.

Goal
----
Give notes in the NotationView a velocity-dependent color, matching the
overall style used in the PianoRoll (blue notes, orange when selected).

We intentionally keep this as a tiny pure-Qt helper module so it can be
reused later (e.g. for chord symbols, selection/highlight, ghost notes).
"""

from __future__ import annotations

from functools import lru_cache

from PyQt6.QtGui import QColor


# Keep the base palette consistent with the PianoRoll.
BASE_NOTE_COLOR = QColor(120, 190, 255)  # blue-ish
SELECT_NOTE_COLOR = QColor(255, 185, 110)  # warm/orange


def _clamp_velocity(v: int | float | None) -> int:
    try:
        vv = int(v) if v is not None else 100
    except Exception:
        vv = 100
    return max(1, min(127, vv))


@lru_cache(maxsize=256)
def velocity_to_color(velocity: int, *, selected: bool = False) -> QColor:
    """Map MIDI velocity (1..127) to a QColor.

    Strategy:
    - Use the PianoRoll base hue.
    - Adjust saturation and value (HSV) with velocity.
    - If selected: use the selection base color but still keep subtle
      velocity variation so soft notes don't look identical.
    """

    vel = _clamp_velocity(velocity)
    t = float(vel) / 127.0

    base = QColor(SELECT_NOTE_COLOR if selected else BASE_NOTE_COLOR)
    h, _s, _v, _a = base.getHsv()

    # Velocity modulation: low velocity -> darker/desaturated,
    # high velocity -> saturated/bright.
    # Values tuned to still read well on a white background.
    new_s = int(60 + t * 195)  # 60..255
    new_v = int(90 + t * 165)  # 90..255

    out = QColor(base)
    out.setHsv(h, max(0, min(255, new_s)), max(0, min(255, new_v)), 255)
    return out


@lru_cache(maxsize=256)
def velocity_to_outline(velocity: int, *, selected: bool = False) -> QColor:
    """Outline color for a note head.

    Slightly darker than the fill. Selection uses a stronger outline.
    """

    fill = velocity_to_color(velocity, selected=selected)
    if selected:
        return QColor(0, 0, 0)
    return QColor(fill).darker(160)
