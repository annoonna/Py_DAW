"""MIDI Mapping dialog (v0.0.15)."""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QComboBox,
    QMessageBox,
)
from PyQt6.QtCore import Qt

from pydaw.services.project_service import ProjectService
from pydaw.services.midi_mapping_service import MidiMappingService, MappingTarget


class MidiMappingDialog(QDialog):
    def __init__(self, project: ProjectService, mapping: MidiMappingService, parent=None):
        super().__init__(parent)
        self.setWindowTitle("MIDI Mapping")
        self.setModal(True)

        self.project = project
        self.mapping = mapping

        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("Mappings:"))
        self.lst = QListWidget()
        layout.addWidget(self.lst, 1)

        row = QHBoxLayout()
        row.addWidget(QLabel("Target Track:"))
        self.cmb_track = QComboBox()
        self.cmb_track.setMinimumWidth(260)
        row.addWidget(self.cmb_track)

        row.addWidget(QLabel("Param:"))
        self.cmb_param = QComboBox()
        self.cmb_param.addItems(["volume", "pan"])
        row.addWidget(self.cmb_param)

        self.btn_learn = QPushButton("Learn")
        self.btn_cancel_learn = QPushButton("Cancel Learn")
        self.btn_remove = QPushButton("Remove Selected")
        row.addWidget(self.btn_learn)
        row.addWidget(self.btn_cancel_learn)
        row.addWidget(self.btn_remove)
        layout.addLayout(row)

        btns = QHBoxLayout()
        btns.addStretch(1)
        self.btn_ok = QPushButton("OK")
        btns.addWidget(self.btn_ok)
        layout.addLayout(btns)

        self.btn_ok.clicked.connect(self.accept)
        self.btn_learn.clicked.connect(self._learn)
        self.btn_cancel_learn.clicked.connect(self._cancel_learn)
        self.btn_remove.clicked.connect(self._remove)

        self.project.project_updated.connect(self.refresh)
        self.refresh()

    def refresh(self) -> None:
        # tracks
        self.cmb_track.blockSignals(True)
        self.cmb_track.clear()
        tracks = [t for t in self.project.ctx.project.tracks if t.kind in ("audio", "instrument", "bus")]
        for t in tracks:
            self.cmb_track.addItem(f"{t.name} [{t.kind}]", t.id)
        self.cmb_track.blockSignals(False)

        # mappings list
        self.lst.clear()
        for m in self.mapping.mappings():
            if m.get("type") == "cc":
                item = QListWidgetItem(
                    f"CC{m.get('control')} ch{m.get('channel')} -> {m.get('param')} ({m.get('track_id')})"
                )
            else:
                item = QListWidgetItem(str(m))
            self.lst.addItem(item)

        learning = self.mapping.is_learning()
        self.btn_learn.setEnabled(not learning)
        self.btn_cancel_learn.setEnabled(learning)

    def _learn(self) -> None:
        if self.cmb_track.count() == 0:
            QMessageBox.warning(self, "MIDI Mapping", "Keine geeigneten Tracks vorhanden.")
            return
        tid = str(self.cmb_track.currentData() or "")
        param = str(self.cmb_param.currentText())
        self.mapping.start_learn(MappingTarget(track_id=tid, param=param))
        QMessageBox.information(self, "MIDI Mapping", "MIDI Learn aktiv: bewege jetzt einen CC-Regler.")
        self.refresh()

    def _cancel_learn(self) -> None:
        self.mapping.cancel_learn()
        self.refresh()

    def _remove(self) -> None:
        idx = self.lst.currentRow()
        if idx < 0:
            return
        self.mapping.remove_mapping(idx)
        self.refresh()
