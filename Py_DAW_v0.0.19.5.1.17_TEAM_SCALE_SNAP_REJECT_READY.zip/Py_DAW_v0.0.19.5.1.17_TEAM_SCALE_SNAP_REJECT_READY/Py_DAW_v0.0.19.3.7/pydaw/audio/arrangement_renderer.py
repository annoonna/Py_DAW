"""Arrangement renderer for JACK/sounddevice.

Pure-numpy renderer that mixes prepared audio (and rendered MIDI->WAV) clips
into an output buffer for a given playhead position.

Design goals:
- No Qt usage here (service-layer friendly)
- Preparation (file IO / FluidSynth renders) happens *outside* realtime callbacks
- Rendering is a tight function operating on numpy arrays
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
import math

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None

try:
    import soundfile as sf
except Exception:  # pragma: no cover
    sf = None

from .midi_render import RenderKey, ensure_rendered_wav


def _midi_notes_content_hash(notes) -> str:  # noqa: ANN001
    import hashlib

    h = hashlib.sha1()
    for n in (notes or []):
        try:
            pitch = int(getattr(n, "pitch", 0))
            sb = float(getattr(n, "start_beats", 0.0))
            lb = float(getattr(n, "length_beats", 0.0))
            vel = int(getattr(n, "velocity", 0))
        except Exception:
            continue
        h.update(f"{pitch}:{sb:.6f}:{lb:.6f}:{vel};".encode("utf-8"))
    return h.hexdigest()[:16]


@dataclass
class PreparedClip:
    start_sample: int
    end_sample: int
    offset_sample: int
    data: "np.ndarray"  # (n, 2)
    gain_l: float
    gain_r: float


def _pan_gains(vol: float, pan: float) -> Tuple[float, float]:
    pan = max(-1.0, min(1.0, float(pan)))
    angle = (pan + 1.0) * (math.pi / 4.0)
    return float(vol) * math.cos(angle), float(vol) * math.sin(angle)


def prepare_clips(project: Any, sr: int) -> Tuple[List[PreparedClip], float]:
    """Prepare all playable clips for rendering.

    Returns (prepared_clips, bpm).
    """
    if np is None or sf is None:
        return ([], float(getattr(project, "bpm", 120.0) or 120.0))

    bpm = float(getattr(project, "bpm", getattr(project, "tempo_bpm", 120.0)) or 120.0)
    beats_per_second = bpm / 60.0
    samples_per_beat = sr / max(1e-9, beats_per_second)

    def beats_to_samples(beats: float) -> int:
        return int(round(float(beats) * samples_per_beat))

    tracks_by_id = {t.id: t for t in getattr(project, "tracks", []) or []}
    solos = [t for t in tracks_by_id.values() if bool(getattr(t, "solo", False))]
    solo_ids = {t.id for t in solos}
    use_solo = len(solo_ids) > 0

    prepared: List[PreparedClip] = []

    for clip in getattr(project, "clips", []) or []:
        kind = str(getattr(clip, "kind", "") or "")
        track = tracks_by_id.get(getattr(clip, "track_id", ""))
        if not track:
            continue

        muted = bool(getattr(track, "muted", getattr(track, "mute", False)))
        if muted:
            continue
        if use_solo and track.id not in solo_ids:
            continue

        data = None

        if kind == "audio":
            path = getattr(clip, "source_path", None)
            if not path:
                continue
            try:
                data, file_sr = sf.read(path, dtype="float32", always_2d=True)
            except Exception:
                continue
            if data.shape[1] == 1:
                data = np.repeat(data, 2, axis=1)
            elif data.shape[1] >= 2:
                data = data[:, :2]
            if int(file_sr or sr) != int(sr) and data.shape[0] > 1:
                # naive resample
                ratio = float(sr) / float(file_sr)
                n_out = max(1, int(round(data.shape[0] * ratio)))
                x_old = np.linspace(0.0, 1.0, num=data.shape[0], endpoint=False)
                x_new = np.linspace(0.0, 1.0, num=n_out, endpoint=False)
                data = np.vstack([
                    np.interp(x_new, x_old, data[:, 0]),
                    np.interp(x_new, x_old, data[:, 1]),
                ]).T.astype(np.float32, copy=False)

        elif kind == "midi":
            # Render MIDI -> WAV using track SF2
            sf2 = getattr(track, "sf2_path", None)
            if not sf2:
                sf2 = getattr(project, "default_sf2", None)
            if not sf2:
                continue

            notes_map: Dict[str, Any] = getattr(project, "midi_notes", {}) or {}
            notes = notes_map.get(getattr(clip, "id", ""), [])
            if not notes:
                continue

            # RenderKey muss zu midi_render.RenderKey passen (wird als stabiler Cache-Key genutzt).
            sf2_bank = int(getattr(track, "sf2_bank", 0) or 0)
            sf2_preset = int(getattr(track, "sf2_preset", 0) or 0)
            clip_length_beats = float(getattr(clip, "length_beats", 0.0) or 0.0)
            if clip_length_beats <= 0.0:
                # Fallback: Länge aus Notes ableiten (max (start+length))
                try:
                    def _get(n: Any, key: str, default: Any = 0.0) -> Any:
                        if isinstance(n, dict):
                            return n.get(key, default)
                        return getattr(n, key, default)

                    def _note_end(n: Any) -> float:
                        # Support both dict-formats and MidiNote objects.
                        start = float(_get(n, "start_beats", _get(n, "start", 0.0)))
                        length = float(_get(n, "length_beats", _get(n, "length", 0.0)))
                        return max(0.0, start + max(0.0, length))

                    clip_length_beats = max(_note_end(n) for n in (notes or []))
                except Exception:
                    clip_length_beats = 0.0

            # Guarantee a non-zero clip length (older projects may not store it).
            if clip_length_beats <= 0.0:
                clip_length_beats = 4.0

            # Content hash: supports MidiNote objects (start_beats/length_beats)
            content_hash = _midi_notes_content_hash(notes)
            key = RenderKey(
                clip_id=str(getattr(clip, "id", "")),
                sf2_path=str(sf2),
                sf2_bank=int(sf2_bank),
                sf2_preset=int(sf2_preset),
                bpm=float(bpm),
                samplerate=int(sr),
                clip_length_beats=float(clip_length_beats),
                content_hash=str(content_hash),
            )
            try:
                wav_path = ensure_rendered_wav(
                    key=key,
                    midi_notes=list(notes or []),
                    clip_start_beats=float(getattr(clip, "start_beats", 0.0) or 0.0),
                    clip_length_beats=float(clip_length_beats),
                )
                if not wav_path:
                    continue
                data, file_sr = sf.read(wav_path.as_posix(), dtype="float32", always_2d=True)
            except Exception:
                continue

            if data.shape[1] == 1:
                data = np.repeat(data, 2, axis=1)
            else:
                data = data[:, :2]
            if int(file_sr or sr) != int(sr) and data.shape[0] > 1:
                ratio = float(sr) / float(file_sr)
                n_out = max(1, int(round(data.shape[0] * ratio)))
                x_old = np.linspace(0.0, 1.0, num=data.shape[0], endpoint=False)
                x_new = np.linspace(0.0, 1.0, num=n_out, endpoint=False)
                data = np.vstack([
                    np.interp(x_new, x_old, data[:, 0]),
                    np.interp(x_new, x_old, data[:, 1]),
                ]).T.astype(np.float32, copy=False)
        else:
            continue

        if data is None:
            continue

        # Offsets/length
        offset_s = float(getattr(clip, "offset_seconds", 0.0) or 0.0)
        offset_sample = max(0, int(round(offset_s * sr)))

        start_sample = beats_to_samples(float(getattr(clip, "start_beats", 0.0) or 0.0))
        clip_len_beats = float(getattr(clip, "length_beats", 0.0) or 0.0)
        if clip_len_beats <= 0:
            clip_len_samples = max(0, int(data.shape[0] - offset_sample))
        else:
            clip_len_samples = beats_to_samples(clip_len_beats)

        end_sample = start_sample + max(0, int(clip_len_samples))

        gain_l, gain_r = _pan_gains(float(getattr(track, "volume", 1.0) or 1.0), float(getattr(track, "pan", 0.0) or 0.0))

        prepared.append(
            PreparedClip(
                start_sample=int(start_sample),
                end_sample=int(end_sample),
                offset_sample=int(offset_sample),
                data=data,
                gain_l=float(gain_l),
                gain_r=float(gain_r),
            )
        )

    prepared.sort(key=lambda c: c.start_sample)
    return prepared, bpm


class ArrangementState:
    """Realtime-safe-ish state holder for rendering."""

    def __init__(self, prepared: List[PreparedClip], sr: int, start_beat: float, bpm: float,
                 loop_enabled: bool, loop_start_beat: float, loop_end_beat: float):
        self.prepared = prepared
        self.sr = int(sr)
        self.bpm = float(bpm)
        self.beats_per_second = self.bpm / 60.0
        self.samples_per_beat = self.sr / max(1e-9, self.beats_per_second)
        self.playhead = int(round(float(start_beat) * self.samples_per_beat))

        self.loop_enabled = bool(loop_enabled)
        self.loop_start = int(round(float(loop_start_beat) * self.samples_per_beat))
        self.loop_end = int(round(float(loop_end_beat) * self.samples_per_beat))
        if self.loop_enabled:
            if self.loop_end <= self.loop_start:
                self.loop_enabled = False
            elif self.playhead < self.loop_start or self.playhead >= self.loop_end:
                self.playhead = self.loop_start

    def render(self, frames: int) -> "np.ndarray":
        if np is None:
            raise RuntimeError("numpy fehlt")
        frames = int(frames)
        out = np.zeros((frames, 2), dtype=np.float32)
        start = int(self.playhead)
        end = int(self.playhead + frames)

        for c in self.prepared:
            if c.end_sample <= start:
                continue
            if c.start_sample >= end:
                break
            o_start = max(start, c.start_sample)
            o_end = min(end, c.end_sample)
            n = int(o_end - o_start)
            if n <= 0:
                continue
            out_off = int(o_start - start)
            rel = int(o_start - c.start_sample)
            src_start = int(c.offset_sample + rel)
            src_end = int(src_start + n)
            if src_start >= int(c.data.shape[0]):
                continue
            if src_end > int(c.data.shape[0]):
                src_end = int(c.data.shape[0])
                n = int(src_end - src_start)
            if n <= 0:
                continue
            chunk = c.data[src_start:src_end]
            out[out_off:out_off + n, 0] += chunk[:, 0] * float(c.gain_l)
            out[out_off:out_off + n, 1] += chunk[:, 1] * float(c.gain_r)

        out = np.clip(out, -1.0, 1.0)

        # Advance playhead
        next_ph = int(self.playhead + frames)
        if self.loop_enabled and next_ph >= self.loop_end:
            overflow = int(next_ph - self.loop_end)
            span = max(1, int(self.loop_end - self.loop_start))
            overflow = int(overflow % span)
            self.playhead = int(self.loop_start + overflow)
        else:
            self.playhead = next_ph

        return out
