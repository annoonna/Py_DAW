# v0.0.20.193 — Aktueller Stand

## Hotfix / Stabilität
- **Qt/PyQt6 Hardening:** verhindert harte SIGABRT-Abstürze ("Unhandled Python exception") auf manchen Wayland/Qt6 Setups.
  - wrappt Qt-virtual Methods (paintEvent/eventFilter/…) für pydaw.ui Klassen und schluckt Exceptions (mit Log-Output).
- **PyQt6 Slot-Safety:** signal.connect wrappt Python-Slots defensiv (try/except), um qFatal("Unhandled Python exception") zu verhindern.
- TrackList startDrag Override defensiv (kein Start-Crash durch fehlende Methode).

## UI (Pro-Workflow)
- Track-Header ▾ (Routing/Arm/Monitor/Add Device) + Favorites/Recents + Search.
- Browser Tabs ⭐ Favorites / 🕘 Recents + Stern-Toggle direkt in Listen.
- Clip Micro-Controls: ▾ Menü + Fade-Handles + Gain/Pan Mini-Handles (Arranger + Audio Editor).


## v0.0.20.189 Hotfix — Regression-Fix (Nichts kaputt machen)
- Fix: QAction/QPushButton Signal-Signaturen wieder kompatibel (lambda _=False), damit Menüs/Buttons wie in v0.0.20.176 funktionieren.
- Fix: ProjectService.get_clip() (UI-Kompatibilität für Clip Launcher + Audio Editor).
- Fix: AudioEventEditor robustes Clip-Lookup (kein UI-Blocker bei fehlenden Helpern).
- Fix: Qt-Hardening Slot-Wrapper loggt nur noch 1× pro Fehler + ignoriert zusätzliche Signal-Args (verhindert Log-Spam/SIGKILL).


## v0.0.20.193 — Pro Drum Machine: AI‑Drum‑Generator + Smart‑Assign
- Drum‑Generator im Pro Drum Machine Instrument erweitert (Genre A/B + Mix, Kontext, Grid, Swing, Density, Intensity, Bars bis 64).
- Generierung ist deterministic/seeded (reine Mathematik/Stochastik) in `pydaw/music/ai_drummer.py`.
- Kanonisches Drum‑Mapping bleibt stabil (C2 Kick, C#2 Snare, …) → PianoRoll/Notation konsistent.
- Smart‑Assign beim Sample‑Load verhindert „HiHat spielt Kick“ (Keywords im Dateinamen → korrektes Slot).
