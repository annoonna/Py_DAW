"""Entry point for Py DAW."""
import faulthandler
import signal
faulthandler.enable(all_threads=True)
try:
    faulthandler.register(signal.SIGABRT, all_threads=True)
except Exception:
    pass

from pydaw.app import run

if __name__ == "__main__":
    run()
