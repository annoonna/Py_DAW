"""NotationView (Task 3).

This module provides a lightweight, DAW-integrated notation view that can
display MIDI notes from :class:`pydaw.services.project_service.ProjectService`.

It intentionally stays *minimal*: the goal is to **show** notes reliably (MVP)
and keep the code easy to evolve into an editor (Draw/Erase/Select tools are
planned in TODO.md).

Key points
----------
- Uses :class:`pydaw.ui.notation.staff_renderer.StaffRenderer` for drawing.
- Uses a small QGraphicsScene so the UI remains responsive.
- Listens to ``project_updated`` and repaints when the active clip changes.

Run a visual demo:

.. code-block:: bash

    python3 -m pydaw.ui.notation.notation_view
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import logging
from typing import Optional

from PyQt6.QtCore import QPoint, QRect, QRectF, Qt, QTimer, pyqtSignal

from PyQt6.QtGui import QCursor, QPainter, QColor, QPen, QTransform
from PyQt6.QtWidgets import (
    QApplication,
    QGraphicsItem,
    QGraphicsScene,
    QGraphicsView,
    QHBoxLayout,
    QLabel,
    QMenu,
    QRubberBand,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from pydaw.model.midi import MidiNote
from pydaw.core.settings import SettingsKeys
from pydaw.core.settings_store import get_value
from pydaw.music.scales import allowed_pitch_classes
from pydaw.ui.notation.staff_renderer import StaffRenderer, StaffStyle
from pydaw.ui.notation.colors import velocity_to_color, velocity_to_outline
from pydaw.ui.notation.tools import (
    DrawTool,
    EraseTool,
    NotationTool,
    SelectTool,
    TieTool,
    SlurTool,
    _nearest_note_index,
    snap_beats_from_div,
    snap_to_grid,
)

from pydaw.ui.notation.notation_palette import NotationPalette, NotationInputState

# Ghost Notes / Layered Editing Support
from pydaw.model.ghost_notes import LayerManager
from pydaw.ui.notation.notation_ghost_notes import NotationGhostRenderer


logger = logging.getLogger(__name__)


logger = logging.getLogger(__name__)


# --- duration formatting helpers (Notation UI) ---

_BEATS_TO_FRAC = {
    4.0: "1/1",
    2.0: "1/2",
    1.0: "1/4",
    0.5: "1/8",
    0.25: "1/16",
    0.125: "1/32",
    0.0625: "1/64",
}


def _format_duration_fraction(beats: float) -> str:
    """Return a stable fraction string (e.g. 1/16 or 1/8.) for a beat duration."""
    try:
        b = float(beats)
    except Exception:
        return "?"

    # dotted detection: beats ~= base * 1.5
    for base, frac in sorted(_BEATS_TO_FRAC.items(), key=lambda x: -x[0]):
        if abs(b - base) < 1e-6:
            return frac
        if abs(b - base * 1.5) < 1e-6:
            return f"{frac}."
    # fallback: show numeric
    return f"{b:g} beat"


def _format_rest_label(beats: float) -> str:
    frac = _format_duration_fraction(beats)
    # Keep it font-safe: use ASCII label, but include a subtle unicode rest if available
    # (If the system font lacks it, it will just render as a tofu box.)
    return f"Rest {frac}"



# Public helpers used in render code

def format_rest_label(beats: float) -> str:
    return _format_rest_label(beats)


def format_ornament_label(orn: str) -> str:
    o = str(orn or "").strip()
    if o == "trill":
        return "tr"
    return o if o else "orn"



@dataclass
class NotationLayout:
    """Layout constants for the view."""

    y_offset: int = 70
    left_margin: int = 40
    right_margin: int = 40
    top_margin: int = 30
    bottom_margin: int = 40
    pixels_per_beat: float = 120.0
    # Maximum width in beats we pre-allocate for a stable scene (prevents heavy resizes)
    max_beats: float = 64.0


@dataclass
class _LiveGhostState:
    """State for a currently held (live) MIDI note, shown as a ghost notehead."""

    pitch: int
    velocity: int
    channel: int
    start_beats: float  # clip-relative beat position
    accidental: int = 0



class _StaffBackgroundItem(QGraphicsItem):
    """Draws the staff and simple beat grid."""

    def __init__(self, width_px: float, style: StaffStyle, y_offset: int):
        super().__init__()
        self._width_px = float(width_px)
        self._style = style
        self._y_offset = int(y_offset)

    def boundingRect(self) -> QRectF:  # noqa: N802 (Qt API)
        h = StaffRenderer.staff_height(self._style) + 120
        return QRectF(0, 0, self._width_px, float(h))

    def paint(self, painter: QPainter, _opt, _widget=None):  # noqa: N802 (Qt API)
        # IMPORTANT: Never let exceptions escape paint(); PyQt6 can abort the
        # whole process on unhandled exceptions during painting.
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            StaffRenderer.render_staff(painter, int(self._width_px), self._y_offset, self._style)
        except Exception:
            logger.exception("Staff background paint failed")


class _NoteItem(QGraphicsItem):
    """A single note rendered via StaffRenderer."""

    def __init__(
        self,
        note: MidiNote,
        *,
        x_center: float,
        staff_line: int,
        y_offset: int,
        style: StaffStyle,
        selected: bool = False,
    ):
        super().__init__()
        self.note = note
        self._x = float(x_center)
        self._line = int(staff_line)
        self._y_offset = int(y_offset)
        self._style = style
        self._selected = bool(selected)
        self._key = (
            int(getattr(note, "pitch", 0)),
            round(float(getattr(note, "start_beats", 0.0)), 6),
            round(float(getattr(note, "length_beats", 0.0)), 6),
        )
        self.setAcceptedMouseButtons(Qt.MouseButton.NoButton)

    @property
    def key(self) -> tuple[int, float, float]:
        return self._key

    def set_selected(self, on: bool) -> None:
        on = bool(on)
        if on == self._selected:
            return
        self._selected = on
        # Slightly lift selected notes above others.
        try:
            self.setZValue(10.0 if on else 0.0)
        except Exception:
            pass
        self.update()
    def boundingRect(self) -> QRectF:  # noqa: N802 (Qt API)
        """Conservative bounding rect around note head + stems/accidentals.

        Notes can be outside the staff (ledger lines). If the bounding rect is
        anchored incorrectly, Qt may clip items and they can appear to
        'disappear' when you scroll/zoom.
        """
        w = float(self._style.note_head_w * 4)
        h = float(self._style.stem_len + self._style.note_head_h * 6)

        bottom_line_y = StaffRenderer.line_y(self._y_offset, self._style.lines - 1, self._style)
        half_step = float(self._style.line_distance) / 2.0
        y = float(bottom_line_y) - (float(self._line) * half_step)

        return QRectF(float(self._x) - w, y - h, w * 2.0, h * 2.0)

    def paint(self, painter: QPainter, _opt, _widget=None):  # noqa: N802 (Qt API)
        # IMPORTANT: Never let exceptions escape paint(); PyQt6 can abort the
        # whole process on unhandled exceptions during painting.
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

            # Determine accidental from note spelling
            # Ensure accidental is populated (MidiNote.to_staff_position updates it)
            try:
                _ = self.note.to_staff_position()
            except Exception:
                pass
            acc = int(getattr(self.note, "accidental", 0))

            # Stem direction: middle line (B4) is staff_line=4 when bottom line is E4.
            stem_up = self._line < 4

            # Velocity-based note color (Task 10)
            vel = int(getattr(self.note, "velocity", 100))
            fill = velocity_to_color(vel, selected=self._selected)
            outline = velocity_to_outline(vel, selected=self._selected)

            StaffRenderer.render_accidental(painter, self._x, self._line, self._y_offset, acc, self._style)

            # Glow effect for selected notes (like Piano Roll)
            if self._selected:
                try:
                    from PyQt6.QtCore import QRectF
                    from PyQt6.QtGui import QBrush, QPainterPath

                    # Calculate note head position for glow
                    note_head_w = self._style.note_head_w
                    note_head_h = self._style.note_head_h
                    center_y = self._y_offset + (4 - self._line) * (self._style.line_distance / 2)

                    # Glow layers (similar to Piano Roll)
                    glow_alpha = 80
                    glow_layers = (6.0, 4.0, 2.0)

                    for j, expand in enumerate(glow_layers):
                        alpha = max(0, glow_alpha - j * 18)
                        glow_color = QColor(fill)
                        glow_color.setAlpha(alpha)

                        # Draw expanded ellipse for glow
                        glow_rect = QRectF(
                            self._x - note_head_w / 2 - expand,
                            center_y - note_head_h / 2 - expand,
                            note_head_w + 2 * expand,
                            note_head_h + 2 * expand,
                        )

                        path = QPainterPath()
                        path.addEllipse(glow_rect)
                        painter.fillPath(path, QBrush(glow_color))
                except Exception:
                    pass

            StaffRenderer.render_note_head(
                painter,
                self._x,
                self._line,
                self._y_offset,
                self._style,
                filled=True,
                fill_color=fill,
                outline_color=outline,
            )
            StaffRenderer.render_stem(painter, self._x, self._line, self._y_offset, stem_up, self._style)

            # Selection outline (softer, matches glow effect)
            if self._selected:
                try:
                    # Subtle outline (not too harsh)
                    pen = QPen(QColor(100, 150, 255, 180))  # Soft blue with transparency
                    pen.setWidth(2)
                    painter.setPen(pen)
                    painter.setBrush(Qt.BrushStyle.NoBrush)
                    r = self.boundingRect()
                    painter.drawRoundedRect(r.adjusted(4, 4, -4, -4), 6, 6)
                except Exception:
                    pass

        except Exception:
            logger.exception("Note item paint failed")



class _LiveGhostNoteItem(QGraphicsItem):
    """Transient live notehead (ghost) for real-time input monitoring."""

    def __init__(
        self,
        *,
        x_center: float,
        line: int,
        accidental: int,
        velocity: int,
        y_offset: int,
        style: StaffStyle,
    ):
        super().__init__()
        self._x = float(x_center)
        self._line = int(line)
        self._acc = int(accidental)
        self._vel = int(velocity)
        self._y_offset = int(y_offset)
        self._style = style

        # Draw above normal notes
        try:
            self.setZValue(8.0)
        except Exception:
            pass

    def boundingRect(self) -> QRectF:  # noqa: N802
        # Similar to _NoteItem but tighter (notehead + accidental)
        w = float(self._style.note_head_w * 2.8)
        h = float(self._style.note_head_h * 2.8)

        bottom_line_y = StaffRenderer.line_y(self._y_offset, self._style.lines - 1, self._style)
        half_step = float(self._style.line_distance) / 2.0
        y = float(bottom_line_y) - (float(self._line) * half_step)

        # accidental sits left of notehead
        return QRectF(self._x - w - 16.0, y - h, (w * 2.0) + 28.0, h * 2.0)

    def paint(self, painter: QPainter, _opt, _widget=None):  # noqa: N802
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

            # Bitwig-like cyan ghost noteheads
            color = QColor(0, 220, 200, 165)
            outline = QColor(0, 220, 200, 210)
            pen = QPen(outline)
            pen.setWidth(2)
            pen.setStyle(Qt.PenStyle.DashLine)
            painter.setPen(pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)

            StaffRenderer.render_accidental(painter, self._x, self._line, self._y_offset, self._acc, self._style)

            # Hollow notehead (ghost)
            StaffRenderer.render_note_head(
                painter,
                self._x,
                self._line,
                self._y_offset,
                self._style,
                filled=False,
                fill_color=color,
                outline_color=outline,
            )
        except Exception:
            logger.exception("Live ghost note paint failed")


class _MarkItem(QGraphicsItem):
    """Small on-score marker for comments/rests/ornaments (MVP)."""

    def __init__(self, *, kind: str, x: float, y: float, text: str, mark_id: str = ""):
        super().__init__()
        self.kind = str(kind)
        self.text = str(text or "")
        self.mark_id = str(mark_id or "")
        self._rect = QRectF(float(x), float(y), 80.0 if self.kind == "comment" else 60.0, 18.0)

        # Make it easy to hover + selectable for editing (Delete / context menu).
        self.setAcceptHoverEvents(True)
        try:
            self.setAcceptedMouseButtons(Qt.MouseButton.LeftButton | Qt.MouseButton.RightButton)
            self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
        except Exception:
            pass
        self.setToolTip(self.text if self.text else self.kind)

    def boundingRect(self) -> QRectF:  # noqa: N802
        return self._rect

    def paint(self, painter: QPainter, option, widget=None):  # noqa: N802
        # IMPORTANT: never let exceptions escape paint() (Qt would abort).
        try:
            painter.save()
            pen = QPen(Qt.GlobalColor.black)
            try:
                if self.isSelected():
                    pen = QPen(QColor(90, 40, 200))
                    pen.setWidth(2)
            except Exception:
                pass
            painter.setPen(pen)

            if self.kind == "comment":
                painter.setBrush(QColor(255, 255, 160))
            elif self.kind == "rest":
                painter.setBrush(QColor(230, 230, 230))
            else:
                painter.setBrush(QColor(210, 240, 255))

            painter.drawRoundedRect(self._rect, 3.0, 3.0)

            # Text
            painter.drawText(self._rect.adjusted(4, 0, -4, 0), int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft), self.text[:32])
        except Exception:
            pass
        finally:
            try:
                painter.restore()
            except Exception:
                pass




class _ConnectionItem(QGraphicsItem):
    """Tie/Slur connection between two notes (MVP marker).

    Stored as a notation_mark with data: {"from": {"beat":..,"pitch":..}, "to": {...}}.
    """

    def __init__(self, *, kind: str, x1: float, y1: float, x2: float, y2: float, mark_id: str = ""):
        super().__init__()
        self.kind = str(kind or "slur")
        self.mark_id = str(mark_id or "")
        self._x1 = float(x1); self._y1 = float(y1)
        self._x2 = float(x2); self._y2 = float(y2)
        # Selectable for editing (Delete / context menu)
        try:
            self.setAcceptedMouseButtons(Qt.MouseButton.LeftButton | Qt.MouseButton.RightButton)
            self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
        except Exception:
            pass
        self.setAcceptHoverEvents(True)
        self.setToolTip(self.kind)

    def boundingRect(self) -> QRectF:  # noqa: N802
        x1, x2 = sorted([self._x1, self._x2])
        y1, y2 = sorted([self._y1, self._y2])
        pad = 40.0
        return QRectF(x1 - pad, y1 - pad, (x2 - x1) + 2 * pad, (y2 - y1) + 2 * pad)

    def paint(self, painter: QPainter, option, widget=None):  # noqa: N802
        # IMPORTANT: never let exceptions escape paint() (Qt would abort).
        try:
            painter.save()
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

            # Curve height: slur higher than tie
            dx = abs(self._x2 - self._x1)
            base = 10.0 if self.kind == "tie" else 18.0
            h = base + min(22.0, dx * 0.08)

            # Prefer drawing above the notes by default
            y_up = min(self._y1, self._y2) - h
            ctrl_x = (self._x1 + self._x2) * 0.5
            ctrl_y = y_up

            from PyQt6.QtGui import QPainterPath

            path = QPainterPath()
            path.moveTo(self._x1, self._y1)
            path.quadTo(ctrl_x, ctrl_y, self._x2, self._y2)

            pen = QPen(QColor(40, 40, 40, 160))
            try:
                if self.isSelected():
                    pen = QPen(QColor(90, 40, 200, 220))
                    pen.setWidth(3)
            except Exception:
                pass
            pen.setWidth(2 if self.kind == "slur" else 2)
            painter.setPen(pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawPath(path)
        except Exception:
            pass
        finally:
            try:
                painter.restore()
            except Exception:
                pass

class NotationView(QGraphicsView):
    """Notation view that renders notes from the current clip."""

    notes_changed = pyqtSignal()

    def __init__(self, project_service, *, parent: Optional[QWidget] = None):
        scene = QGraphicsScene()
        super().__init__(scene, parent)

        self._project_service = project_service
        self._clip_id: str | None = None
        self._layout = NotationLayout()
        self._style = StaffStyle()
        self._keys = SettingsKeys()

        # Live MIDI ghost notes (noteheads while key is held)
        self._live_ghost: dict[str, list[_LiveGhostState]] = {}
        self._live_ghost_items: list[_LiveGhostNoteItem] = []
        self._default_ppb = float(self._layout.pixels_per_beat)
        self._y_zoom = 1.0

        # Notation input state (Rosegarden-like palette)
        self.input_state = NotationInputState()
        self._last_mouse_scene_pos = None  # updated by mouseMoveEvent

        self.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        self.setViewportUpdateMode(QGraphicsView.ViewportUpdateMode.MinimalViewportUpdate)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self._apply_view_transform()
        # Keep colors predictable across themes.
        try:
            from PyQt6.QtGui import QBrush

            self.setBackgroundBrush(QBrush(Qt.GlobalColor.white))
        except Exception:
            pass

        self._staff_item: _StaffBackgroundItem | None = None
        self._note_items: list[_NoteItem] = []

        # --- Task 7: Bidirektionale MIDI-Sync (MVP-Infra) ---
        # The project emits a global `project_updated` signal for many changes.
        # For the notation view we keep refreshes cheap and avoid feedback loops
        # when we ourselves update MIDI notes.
        self._suppress_project_updates: int = 0
        self._last_notes_sig: tuple | None = None

        # Selection (Task 6 - Select-Tool)
        self._selected_key: tuple[int, float, float] | None = None
        # Multi-Select Support (Phase 1 - SAFE)
        self._selected_keys: set[tuple[int, float, float]] = set()
        # Lasso Selection (Phase 2 - MEDIUM)
        self._lasso_start_pos: QPoint | None = None
        self._lasso_rubber_band: QRubberBand | None = None

        # Clipboard (Task 8 - Keyboard Shortcuts)
        # Stores notes for copy/paste (supports multi-note)
        self._clipboard_note: MidiNote | None = None  # Legacy single-note
        self._clipboard_notes: list[MidiNote] = []  # Multi-note support
        self._clipboard_last_paste_start: float | None = None

        # Editing tools
        self._draw_tool: NotationTool = DrawTool()
        self._select_tool: NotationTool = SelectTool()
        self._tie_tool: NotationTool = TieTool()
        self._slur_tool: NotationTool = SlurTool()
        # pending tie/slur multi-click state
        self._pending_connection: dict | None = None
        # Connection overlay mode (allows Tie/Slur while Draw tool stays active)
        self._connection_mode: str | None = None
        # Active tool defaults to Draw (MVP)
        self._tool: NotationTool = self._draw_tool
        # Task 5 (Erase-Tool): routed via right-click for now (keeps MVP UI simple)
        self._erase_tool: NotationTool = EraseTool()

        # Ghost Notes / Layered Editing Support
        self.layer_manager = LayerManager()
        self.ghost_renderer = NotationGhostRenderer(self)

        # Restore persisted ghost layers (Project.ghost_layers)
        # IMPORTANT: Project loading is async (threadpool). The view is created
        # before `open_project()` finishes, so we also reload when the project
        # context changes.
        self._load_ghost_layers_from_project(emit=False)

        try:
            self._project_service.project_changed.connect(self._on_project_changed)
        except Exception:
            pass

        # Connect layer changes to refresh + persist
        self.layer_manager.layers_changed.connect(self._refresh_ghost_notes)
        self.layer_manager.layers_changed.connect(self._persist_ghost_layers_to_project)

        # auto-refresh when project changes (throttled + recursion-safe)
        try:
            self._project_service.project_updated.connect(self._on_project_updated)
        except Exception:
            pass

        self._rebuild_scene_base()


    # ------------------------------------------------------------------
    # View transforms / scrolling / zooming
    # ------------------------------------------------------------------
    def _apply_view_transform(self) -> None:
        """Apply current Y zoom to the view transform (scene coords stay stable)."""
        try:
            t = QTransform()
            t.scale(1.0, float(self._y_zoom))
            self.setTransform(t)
        except Exception:
            pass

    def _clamp(self, v: float, lo: float, hi: float) -> float:
        try:
            return max(float(lo), min(float(hi), float(v)))
        except Exception:
            return float(lo)

    def _set_x_zoom(self, factor: float) -> None:
        ppb = float(self._layout.pixels_per_beat)
        ppb = self._clamp(ppb * float(factor), 30.0, 600.0)
        self._layout.pixels_per_beat = ppb
        self.refresh()

    def _set_y_zoom(self, factor: float) -> None:
        self._y_zoom = self._clamp(float(self._y_zoom) * float(factor), 0.6, 3.5)
        self._apply_view_transform()
        try:
            self.viewport().update()
        except Exception:
            pass

    def _reset_zoom(self) -> None:
        self._layout.pixels_per_beat = float(self._default_ppb)
        self._y_zoom = 1.0
        self._apply_view_transform()
        self.refresh()

    def wheelEvent(self, ev):  # noqa: N802 (Qt API)
        """DAW-style scroll/zoom.
        
        FIXED v0.0.19.7.20: Intuitiveres Mousewheel-Verhalten!
        
        - Plain Wheel: VERTIKAL scrollen (hoch/runter) ← HAUPTFUNKTION!
        - Shift + Wheel: HORIZONTAL scrollen (links/rechts)
        - Ctrl + Wheel: X zoom (pixels/beat, Zeit-Achse)
        - Ctrl + Shift + Wheel: Y zoom (staff spacing, Notenzeilen-Höhe)
        """
        try:
            delta = ev.angleDelta().y()
        except Exception:
            return super().wheelEvent(ev)

        mods = ev.modifiers()
        steps = float(delta) / 120.0  # typical wheel step
        if steps == 0.0:
            return

        # Ctrl + Shift + Wheel: Y zoom (staff spacing)
        if (mods & Qt.KeyboardModifier.ControlModifier) and (mods & Qt.KeyboardModifier.ShiftModifier):
            self._set_y_zoom(1.12 if steps > 0 else 1.0 / 1.12)
            ev.accept()
            return

        # Ctrl + Wheel: X zoom (time axis)
        if mods & Qt.KeyboardModifier.ControlModifier:
            self._set_x_zoom(1.12 if steps > 0 else 1.0 / 1.12)
            ev.accept()
            return

        # Shift + Wheel: HORIZONTAL scroll (timeline)
        if mods & Qt.KeyboardModifier.ShiftModifier:
            sb = self.horizontalScrollBar()
            sb.setValue(int(sb.value() - steps * 80))
            ev.accept()
            return

        # Plain Wheel: VERTIKAL scroll (up/down) ← HAUPTFUNKTION!
        sb = self.verticalScrollBar()
        sb.setValue(int(sb.value() - steps * 60))
        ev.accept()

    def keyPressEvent(self, ev):  # noqa: N802 (Qt API)
        try:
            if ev.modifiers() & Qt.KeyboardModifier.ControlModifier:
                if ev.key() == Qt.Key.Key_0:
                    self._reset_zoom()
                    ev.accept()
                    return
                if ev.key() in (Qt.Key.Key_Plus, Qt.Key.Key_Equal):
                    self._set_x_zoom(1.12)
                    ev.accept()
                    return
                if ev.key() == Qt.Key.Key_Minus:
                    self._set_x_zoom(1.0 / 1.12)
                    ev.accept()
                    return
        except Exception:
            pass
        return super().keyPressEvent(ev)

    def drawBackground(self, painter: QPainter, rect: QRectF):  # noqa: N802 (Qt API)
        """Draw beat/bar grid + optional scale hints behind the staff."""
        try:
            painter.save()
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, False)

            # Base background (keep staff readable)
            painter.fillRect(rect, QColor("#ffffff"))

            left = float(self._layout.left_margin)
            ppb = float(self._layout.pixels_per_beat)

            # Visible beat range
            beat0 = max(0.0, (rect.left() - left) / ppb)
            beat1 = max(0.0, (rect.right() - left) / ppb)

            # Time signature MVP: 4/4 -> bar each 4 beats
            bar = 4.0

            # Pens: subbeat (very light), beat, bar (strong)
            pen_sub = QPen(QColor(220, 224, 228), 1)
            pen_beat = QPen(QColor(190, 196, 202), 1)
            pen_bar = QPen(QColor(120, 128, 136), 2)

            # Subbeat grid: 1/4 beat (16th) – readable, not too dense
            sub = 0.25
            start = int(beat0 / sub) - 1
            end = int(beat1 / sub) + 2
            for i in range(start, end + 1):
                b = float(i) * sub
                x = left + b * ppb
                if x < rect.left() - 2 or x > rect.right() + 2:
                    continue
                is_beat = abs((b % 1.0)) < 1e-9
                is_bar = abs((b % bar)) < 1e-9
                painter.setPen(pen_bar if is_bar else (pen_beat if is_beat else pen_sub))
                painter.drawLine(int(x), int(rect.top()), int(x), int(rect.bottom()))

            # Optional scale hints: subtle cyan row tint so in-scale notes are easier to spot
            try:
                if bool(get_value(self._keys.scale_visualize, True)) and bool(get_value(self._keys.scale_enabled, False)):
                    cat = str(get_value(self._keys.scale_category, "Keine Einschränkung"))
                    name = str(get_value(self._keys.scale_name, "Alle Noten"))
                    root = int(get_value(self._keys.scale_root_pc, 0) or 0) % 12
                    if cat != "Keine Einschränkung":
                        pcs = set(allowed_pitch_classes(category=cat, name=name, root_pc=root))
                        # Tint the staff band slightly; true per-pitch tint is hard in classical staff,
                        # but this gives a Bitwig-ish "scale mode is active" feel without clutter.
                        if pcs:
                            painter.fillRect(rect, QColor(0, 229, 255, 10))
            except Exception:
                pass

            painter.restore()
        except Exception:
            # Never crash paint pipeline
            try:
                painter.restore()
            except Exception:
                pass
            return super().drawBackground(painter, rect)

    # ------------------------------------------------------------------
    # Tool-facing helpers / properties
    # ------------------------------------------------------------------
    @property
    def project_service(self):
        return self._project_service

    @property
    def clip_id(self) -> str | None:
        return self._clip_id


    def set_input_state(self, state: object) -> None:
        """Update the current notation input state (from NotationPalette)."""
        try:
            if isinstance(state, NotationInputState):
                self.input_state = state
            else:
                self.input_state = getattr(self, "input_state", NotationInputState())
        except Exception:
            self.input_state = NotationInputState()
        try:
            self.viewport().update()
        except Exception:
            pass


    def _load_ghost_layers_from_project(self, *, emit: bool = True) -> None:
        """Load ghost layer state from the current project (if present).

        Args:
            emit: If True, emit LayerManager change signals after loading.
                  For init, use emit=False. For project open/new/load, emit=True.
        """
        try:
            proj = getattr(self._project_service, 'ctx', None)
            proj = getattr(proj, 'project', None)
            state = getattr(proj, 'ghost_layers', {}) or {}
            if isinstance(state, dict):
                self.layer_manager.load_state(state, emit=emit)
        except Exception:
            pass

    def _on_project_changed(self) -> None:
        """Reload persisted ghost layers after project open/new/load."""
        self._load_ghost_layers_from_project(emit=True)
        try:
            self.refresh()
        except Exception:
            pass

    def _persist_ghost_layers_to_project(self) -> None:
        """Persist current layer manager state into the project model."""
        try:
            proj = getattr(self._project_service, 'ctx', None)
            proj = getattr(proj, 'project', None)
            if proj is None:
                return
            setattr(proj, 'ghost_layers', self.layer_manager.to_dict())
            try:
                proj.modified_utc = datetime.utcnow().isoformat(timespec='seconds')
            except Exception:
                pass
        except Exception:
            pass



    def connection_mode(self) -> str | None:
        return self._connection_mode

    def set_connection_mode(self, mode: str | None) -> None:
        """Enable/disable Tie/Slur overlay mode.

        This is intentionally independent from the primary tool (Draw/Select),
        so users can keep the pencil active and still place ties/slurs,
        Rosegarden-style.
        """
        m = (str(mode).strip().lower() if mode is not None else "")
        if m in ("tie", "haltebogen"):
            self._connection_mode = "tie"
        elif m in ("slur", "bindebogen"):
            self._connection_mode = "slur"
        else:
            self._connection_mode = None
            # Cancel pending 2-click connection if any.
            try:
                self._pending_connection = None
            except Exception:
                pass

        try:
            lab = self._connection_mode or "off"
            self._project_service.status.emit(f"Notation Connection: {lab}")
        except Exception:
            pass

    def set_active_tool(self, name: str) -> None:
        """Switch the active left-click tool.

        Supported: "draw", "select", "tie", "slur".
        """

        n = str(name or "").strip().lower()
        if n in ("draw", "pencil"):
            self._tool = self._draw_tool
        elif n in ("select", "arrow"):
            self._tool = self._select_tool
        elif n in ("tie", "haltebogen"):
            # Overlay mode (can be used while Draw stays active)
            self.set_connection_mode("tie")
            return
        elif n in ("slur", "bindebogen"):
            self.set_connection_mode("slur")
            return
        else:
            self._tool = self._draw_tool


        # Provide UI feedback via status signal.
        try:
            self._project_service.status.emit(f"Notation Tool: {self._tool.name}")
        except Exception:
            pass

    # ---- selection helpers (used by SelectTool) ----
    @staticmethod
    def _note_key(note: MidiNote) -> tuple[int, float, float]:
        return (
            int(getattr(note, "pitch", 0)),
            round(float(getattr(note, "start_beats", 0.0)), 6),
            round(float(getattr(note, "length_beats", 0.0)), 6),
        )

    def is_selected_note(self, note: MidiNote) -> bool:
        key = self._note_key(note)
        # Check both single and multi-select
        return (key == self._selected_key) or (key in self._selected_keys)

    def clear_selection(self) -> None:
        self._selected_key = None
        self._selected_keys.clear()
        self._apply_selection_to_items()

    def select_note(self, note: MidiNote, *, multi: bool = False, toggle: bool = False) -> None:
        """Select a note.
        
        Args:
            note: Note to select
            multi: If True, add to multi-selection. If False, clear previous selection.
            toggle: If True, toggle selection state (only with multi=True)
        """
        key = self._note_key(note)
        
        if multi:
            if toggle and key in self._selected_keys:
                # Toggle off
                self._selected_keys.discard(key)
                if self._selected_key == key:
                    self._selected_key = None
            else:
                # Add to multi-selection
                self._selected_keys.add(key)
                self._selected_key = key  # Keep for single-select compatibility
        else:
            # Single selection (clear previous)
            self._selected_keys.clear()
            self._selected_key = key
            self._selected_keys.add(key)
        
        self._apply_selection_to_items()
    
    def get_selected_notes(self) -> list[MidiNote]:
        """Get all currently selected notes."""
        if not self._clip_id:
            return []
        
        try:
            ps = self._project_service
            all_notes = list(ps.get_midi_notes(str(self._clip_id)))
        except Exception:
            return []
        
        # Combine single and multi-select
        selected_keys = self._selected_keys.copy()
        if self._selected_key is not None:
            selected_keys.add(self._selected_key)
        
        return [n for n in all_notes if self._note_key(n) in selected_keys]

    def _apply_selection_to_items(self) -> None:
        # Combine single and multi-select keys
        selected_keys = self._selected_keys.copy()
        if self._selected_key is not None:
            selected_keys.add(self._selected_key)
        
        for it in list(self._note_items):
            try:
                it.set_selected(it.key in selected_keys)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Lasso Selection (Phase 2 - MEDIUM)
    # ------------------------------------------------------------------
    def _start_lasso_selection(self, view_pos: QPoint, modifiers: Qt.KeyboardModifier) -> None:
        """Start lasso selection (rubber band rectangle)."""
        self._lasso_start_pos = view_pos
        
        # Create rubber band if not exists
        if self._lasso_rubber_band is None:
            self._lasso_rubber_band = QRubberBand(QRubberBand.Shape.Rectangle, self)
        
        # Position rubber band at start point
        try:
            self._lasso_rubber_band.setGeometry(view_pos.x(), view_pos.y(), 1, 1)
            self._lasso_rubber_band.show()
        except Exception:
            pass
        
        # Clear selection if not Ctrl (additive mode)
        if not (modifiers & Qt.KeyboardModifier.ControlModifier):
            self.clear_selection()

    def _update_lasso_rubber_band(self, current_pos: QPoint) -> None:
        """Update rubber band geometry during drag."""
        if self._lasso_start_pos is None or self._lasso_rubber_band is None:
            return
        
        try:
            # Calculate rectangle from start to current
            x1 = min(self._lasso_start_pos.x(), current_pos.x())
            y1 = min(self._lasso_start_pos.y(), current_pos.y())
            x2 = max(self._lasso_start_pos.x(), current_pos.x())
            y2 = max(self._lasso_start_pos.y(), current_pos.y())
            
            rect = QRect(x1, y1, x2 - x1, y2 - y1)
            self._lasso_rubber_band.setGeometry(rect)
        except Exception:
            pass

    def _finish_lasso_selection(self, button: Qt.MouseButton, modifiers: Qt.KeyboardModifier) -> None:
        """Complete lasso selection - select all notes in rectangle."""
        if self._lasso_start_pos is None or self._lasso_rubber_band is None:
            return
        
        try:
            # Get lasso rectangle in scene coordinates
            lasso_rect_view = self._lasso_rubber_band.geometry()
            lasso_rect_scene = QRectF(
                self.mapToScene(lasso_rect_view.topLeft()),
                self.mapToScene(lasso_rect_view.bottomRight())
            )
            
            # Find all notes that intersect with lasso rectangle
            if not self._clip_id:
                return
            
            ps = self._project_service
            try:
                all_notes = list(ps.get_midi_notes(str(self._clip_id)))
            except Exception:
                all_notes = []
            
            # Helper: staff_line to scene_y (inverse of scene_y_to_staff_line)
            def staff_line_to_scene_y(staff_line: int) -> float:
                bottom_line_y = float(self._layout.y_offset) + float((self._style.lines - 1) * self._style.line_distance)
                half_step = float(self._style.line_distance) / 2.0
                return bottom_line_y - (staff_line * half_step)
            
            # Check each note for intersection with lasso
            selected_count = 0
            for note in all_notes:
                try:
                    # Get note bounding box in scene coordinates
                    note_start_x = float(self._layout.left_margin) + float(note.start_beats) * float(self._layout.pixels_per_beat)
                    note_end_x = note_start_x + float(note.length_beats) * float(self._layout.pixels_per_beat)
                    
                    # Get note Y position from pitch
                    staff_line = self._pitch_to_staff_line(int(note.pitch))
                    note_y = staff_line_to_scene_y(staff_line)
                    
                    # Note bounding box (with some height for visibility)
                    note_height = 20.0  # Approximate note head height
                    note_rect = QRectF(note_start_x, note_y - note_height/2, note_end_x - note_start_x, note_height)
                    
                    # Check intersection
                    if lasso_rect_scene.intersects(note_rect):
                        self.select_note(note, multi=True, toggle=False)
                        selected_count += 1
                except Exception:
                    continue
            
            # Show status
            if selected_count > 0:
                try:
                    msg = f"{selected_count} Noten ausgewählt (Lasso)" if selected_count > 1 else "Note ausgewählt (Lasso)"
                    ps.status.emit(msg)
                except Exception:
                    pass
            else:
                # No notes selected - clear selection if not Ctrl
                if not (modifiers & Qt.KeyboardModifier.ControlModifier):
                    self.clear_selection()
            
        except Exception:
            pass
        finally:
            # Always cleanup
            self._cancel_lasso_selection()

    def _cancel_lasso_selection(self) -> None:
        """Cancel/cleanup lasso selection."""
        self._lasso_start_pos = None
        if self._lasso_rubber_band is not None:
            try:
                self._lasso_rubber_band.hide()
            except Exception:
                pass



    def pick_note_at(self, scene_pos) -> MidiNote | None:
        """Return the nearest note under the cursor (used by tie/slur tools).

        This is intentionally conservative to avoid picking the wrong note.
        """
        if not self._clip_id:
            return None
        try:
            ps = self._project_service
            notes = list(ps.get_midi_notes(str(self._clip_id)))
        except Exception:
            return None
        if not notes:
            return None

        try:
            beat = float(self.scene_x_to_beat(float(scene_pos.x())))
            staff_line = int(self.scene_y_to_staff_line(float(scene_pos.y())))
        except Exception:
            return None

        try:
            snap_div = str(getattr(self._project_service.ctx.project, "snap_division", "1/16") or "1/16")
            snap = float(snap_beats_from_div(snap_div))
        except Exception:
            snap = 0.25

        idx = None
        try:
            idx = _nearest_note_index(self, notes, target_beat=float(beat), target_staff_line=int(staff_line), snap_step=float(snap))
        except Exception:
            idx = None
        if idx is None:
            return None
        try:
            return notes[int(idx)]
        except Exception:
            return None

    def _get_selected_note(self) -> MidiNote | None:
        """Return the currently selected note (single selection MVP)."""
        if not self._clip_id or self._selected_key is None:
            return None
        ps = self._project_service
        try:
            notes = list(ps.get_midi_notes(str(self._clip_id)))
        except Exception:
            return None

        for n in notes:
            try:
                if self._note_key(n) == self._selected_key:
                    return n
            except Exception:
                continue
        return None

    def _delete_selected_note(self) -> bool:
        """Delete all currently selected notes, committed as a single Undo step."""
        if not self._clip_id:
            return False
        
        # Get all selected notes (supports multi-select)
        selected_notes = self.get_selected_notes()
        if not selected_notes:
            return False

        ps = self._project_service
        try:
            all_notes = list(ps.get_midi_notes(str(self._clip_id)))
        except Exception:
            all_notes = []

        # Create set of keys to delete for fast lookup
        keys_to_delete = {self._note_key(n) for n in selected_notes}
        
        # Filter out selected notes
        new_notes = [n for n in all_notes if self._note_key(n) not in keys_to_delete]
        
        if len(new_notes) == len(all_notes):
            # Nothing was deleted
            return False

        deleted_count = len(all_notes) - len(new_notes)
        self.commit_notes_to_project(new_notes, label=f"Delete {deleted_count} Note(s) (Notation)")
        self.clear_selection()
        self.refresh()
        try:
            msg = f"Notation: {deleted_count} Note(n) gelöscht." if deleted_count > 1 else "Notation: Note gelöscht."
            ps.status.emit(msg)
        except Exception:
            pass
        return True

    def _delete_selected_marks(self) -> bool:
        """Delete selected notation marks (ties/slurs/comments/rests/ornaments)."""
        try:
            items = list(self.scene().selectedItems())
        except Exception:
            items = []
        mark_ids: list[str] = []
        for it in items:
            try:
                mid = getattr(it, "mark_id", "") or ""
                if mid:
                    mark_ids.append(str(mid))
            except Exception:
                pass
        if not mark_ids:
            return False

        # Remove marks via ProjectService (persists in project json on save)
        try:
            for mid in mark_ids:
                self._project_service.remove_notation_mark(str(mid))
        except Exception:
            pass

        try:
            self.scene().clearSelection()
        except Exception:
            pass
        try:
            self._project_service.status.emit("Notation: Mark gelöscht.")
        except Exception:
            pass
        self.refresh()
        return True


    def _copy_selected_note(self) -> bool:
        """Copy all selected notes into internal clipboard."""
        selected_notes = self.get_selected_notes()
        if not selected_notes:
            return False
        
        try:
            # Sort by start time for predictable paste
            selected_notes.sort(key=lambda n: n.start_beats)
            
            # Find earliest start time for relative positioning
            min_start = min(n.start_beats for n in selected_notes)
            
            # Copy notes with relative positioning
            self._clipboard_notes = []
            for sel in selected_notes:
                copied = MidiNote(
                    pitch=int(getattr(sel, "pitch", 60)),
                    start_beats=float(getattr(sel, "start_beats", 0.0)) - min_start,  # Relative!
                    length_beats=float(getattr(sel, "length_beats", 1.0)),
                    velocity=int(getattr(sel, "velocity", 100)),
                    accidental=int(getattr(sel, "accidental", 0)),
                    tie_to_next=bool(getattr(sel, "tie_to_next", False)),
                ).clamp()
                self._clipboard_notes.append(copied)
            
            # Keep first note in legacy clipboard for compatibility
            if self._clipboard_notes:
                self._clipboard_note = self._clipboard_notes[0]
            
        except Exception:
            return False

        self._clipboard_last_paste_start = None
        try:
            count = len(self._clipboard_notes)
            msg = f"Notation: {count} Note(n) kopiert." if count > 1 else "Notation: Note kopiert."
            self._project_service.status.emit(msg)
        except Exception:
            pass
        return True

    def _cut_selected_note(self) -> bool:
        """Cut = copy + delete."""
        if not self._copy_selected_note():
            return False
        return self._delete_selected_note()

    def _paste_clipboard_note(self) -> bool:
        """Paste clipboard notes (supports multi-note).

        Placement logic:
        - If a note is selected: paste right after it (start = selected.end).
        - Else: paste at the last paste position + total length (stepwise).
        - Else: paste at beat 0.
        The start is snapped to the current project snap grid when available.
        """
        # Check if we have multi-note clipboard or single-note
        if not self._clip_id:
            return False
        
        clipboard = self._clipboard_notes if self._clipboard_notes else (
            [self._clipboard_note] if self._clipboard_note else []
        )
        
        if not clipboard:
            return False

        ps = self._project_service
        try:
            notes = list(ps.get_midi_notes(str(self._clip_id)))
        except Exception:
            notes = []

        # Determine paste position
        selected = self.get_selected_notes()
        if selected:
            # Paste after last selected note
            selected.sort(key=lambda n: n.start_beats)
            last = selected[-1]
            start = float(getattr(last, "start_beats", 0.0)) + float(getattr(last, "length_beats", 1.0))
        elif self._clipboard_last_paste_start is not None:
            # Paste after last paste (stepwise)
            # Calculate total length of clipboard notes
            total_length = max((n.start_beats + n.length_beats) for n in clipboard)
            start = float(self._clipboard_last_paste_start) + total_length
        else:
            start = 0.0

        # Snap to project grid
        try:
            snap_div = str(getattr(ps.ctx.project, "snap_division", "1/16") or "1/16")
            step = snap_beats_from_div(snap_div)
            start = snap_to_grid(float(start), float(step))
        except Exception:
            pass

        # Paste all notes with relative positioning
        pasted_notes = []
        for clip_note in clipboard:
            new_note = MidiNote(
                pitch=int(getattr(clip_note, "pitch", 60)),
                start_beats=float(start) + float(getattr(clip_note, "start_beats", 0.0)),
                length_beats=float(getattr(clip_note, "length_beats", 1.0)),
                velocity=int(getattr(clip_note, "velocity", 100)),
                accidental=int(getattr(clip_note, "accidental", 0)),
                tie_to_next=bool(getattr(clip_note, "tie_to_next", False)),
            ).clamp()
            pasted_notes.append(new_note)
            notes.append(new_note)

        # Keep stable ordering
        try:
            notes.sort(key=lambda n: (float(getattr(n, "start_beats", 0.0)), int(getattr(n, "pitch", 0))))
        except Exception:
            pass

        count = len(pasted_notes)
        label = f"Paste {count} Note(s) (Notation)" if count > 1 else "Paste Note (Notation)"
        self.commit_notes_to_project(notes, label=label)
        
        # Remember last paste position for stepwise pasting
        if pasted_notes:
            self._clipboard_last_paste_start = float(getattr(pasted_notes[0], "start_beats", 0.0))
        
        # Select pasted notes
        self.clear_selection()
        for n in pasted_notes:
            self.select_note(n, multi=True)
        
        self.refresh()
        try:
            msg = f"Notation: {count} Note(n) eingefügt." if count > 1 else "Notation: Note eingefügt."
            ps.status.emit(msg)
        except Exception:
            pass
        return True

    def scene_x_to_beat(self, scene_x: float) -> float:
        """Convert a scene X coordinate to beats (unsnapped)."""
        return (float(scene_x) - float(self._layout.left_margin)) / float(self._layout.pixels_per_beat)

    def scene_y_to_staff_line(self, scene_y: float) -> int:
        """Convert a scene Y coordinate to a staff line/space index.

        Our staff model (as used by StaffRenderer):
        - bottom staff line == 0
        - each step (1) == one *half step* in pixel space (line or space)
        """
        bottom_line_y = float(self._layout.y_offset) + float((self._style.lines - 1) * self._style.line_distance)
        half_step = float(self._style.line_distance) / 2.0
        return int(round((bottom_line_y - float(scene_y)) / max(1e-9, half_step)))

    def staff_line_to_pitch(self, staff_line: int, *, accidental: int = 0) -> int:
        """Convert a staff line/space index to a MIDI pitch (natural notes MVP)."""
        e4_ref = self._diatonic_index(2, 4)  # E4 (bottom line)
        diat = int(e4_ref) + int(staff_line)
        octave = diat // 7
        line = diat % 7
        return int(MidiNote.from_staff_position(int(line), int(octave), int(accidental)))

    # ------------------------------------------------------------------
    # Qt events
    # ------------------------------------------------------------------
    def mouseMoveEvent(self, event):  # noqa: N802 (Qt API)
        try:
            self._last_mouse_scene_pos = self.mapToScene(event.pos())
        except Exception:
            self._last_mouse_scene_pos = None
        
        # Phase 2: Update lasso rubber band during drag
        if self._lasso_start_pos is not None and self._lasso_rubber_band is not None:
            try:
                self._update_lasso_rubber_band(event.pos())
                return  # Don't propagate to super during lasso
            except Exception:
                pass
        
        try:
            super().mouseMoveEvent(event)
        except Exception:
            pass

    def mouseReleaseEvent(self, event):  # noqa: N802 (Qt API)
        """Handle mouse release - complete lasso selection if active."""
        # Phase 2: Complete lasso selection on release
        if self._lasso_start_pos is not None:
            try:
                self._finish_lasso_selection(event.button(), event.modifiers())
                return
            except Exception:
                # Cleanup on error
                self._cancel_lasso_selection()
        
        try:
            super().mouseReleaseEvent(event)
        except Exception:
            pass

    def mousePressEvent(self, event):  # noqa: N802 (Qt API)
        try:
            scene_pos = self.mapToScene(event.pos())
            btn = event.button()
            mods = event.modifiers()

            # Hit-test items for editing (ties/slurs/marks)
            hit = None
            try:
                hit = self.scene().itemAt(scene_pos, self.transform())
            except Exception:
                hit = None

            # Right-click: prefer context actions on marks over erase.
            if btn == Qt.MouseButton.RightButton and hit is not None:
                if isinstance(hit, (_ConnectionItem, _MarkItem)):
                    try:
                        # Select the item so Delete works immediately.
                        self.scene().clearSelection()
                        hit.setSelected(True)
                    except Exception:
                        pass
                    # Show a tiny context menu (Delete)
                    try:
                        from PyQt6.QtWidgets import QMenu
                        menu = QMenu(self)
                        act_del = menu.addAction("Löschen")
                        act = menu.exec(event.globalPosition().toPoint())
                        if act == act_del:
                            self._delete_selected_marks()
                            return
                    except Exception:
                        # If menu fails, do not erase.
                        return

            # Left-click selection on marks (so Draw tool won't create notes by accident)
            if btn == Qt.MouseButton.LeftButton and hit is not None:
                if isinstance(hit, (_ConnectionItem, _MarkItem)):
                    try:
                        self.scene().clearSelection()
                        hit.setSelected(True)
                        return
                    except Exception:
                        pass

            # Phase 2: Lasso Selection (only for Select Tool)
            # Start lasso on left-click in empty space when Select Tool is active
            if btn == Qt.MouseButton.LeftButton and hit is None:
                # Check if Select Tool is active (not Draw/Erase/Tie/Slur)
                if self._tool is self._select_tool:
                    # No Shift/Alt modifiers (those are for range select)
                    if not (mods & Qt.KeyboardModifier.ShiftModifier) and not (mods & Qt.KeyboardModifier.AltModifier):
                        # Start lasso selection
                        try:
                            self._start_lasso_selection(event.pos(), mods)
                            return
                        except Exception:
                            pass

            # Route click to tools:
            # - Right-click defaults to erase tool
            # - Left-click supports a Rosegarden-like "armed" connection overlay
            #   (Tie/Slur can be active while Pencil stays active)
            tool = None
            if btn == Qt.MouseButton.RightButton:
                tool = self._erase_tool
            else:
                # Quick modifiers (momentary): allow tie/slur while Draw tool is active
                # Shift+Click = Tie, Alt+Click = Slur (Rosegarden-like workflow)
                if mods & Qt.KeyboardModifier.ShiftModifier:
                    tool = self._tie_tool
                elif mods & Qt.KeyboardModifier.AltModifier:
                    tool = self._slur_tool
                else:
                    # If a 2-click connection is already pending, keep routing
                    # clicks to the corresponding tool so users can complete
                    # or cancel the action without creating accidental notes.
                    pend = getattr(self, "_pending_connection", None)
                    if pend:
                        try:
                            kind = str(pend.get("kind", ""))
                        except Exception:
                            kind = ""
                        tool = self._tie_tool if kind == "tie" else self._slur_tool
                    else:
                        # Armed overlay mode: only engage on clicks near an
                        # existing note. This way Pencil can remain active and
                        # still draw notes in empty space.
                        # Ctrl+Click forces the primary tool even near notes.
                        force_primary = bool(mods & Qt.KeyboardModifier.ControlModifier)
                        if (not force_primary) and self._connection_mode in ("tie", "slur"):
                            near_note = False
                            try:
                                near_note = self.pick_note_at(scene_pos) is not None
                            except Exception:
                                near_note = False
                            if near_note:
                                tool = self._tie_tool if self._connection_mode == "tie" else self._slur_tool
                            else:
                                tool = self._tool
                        else:
                            tool = self._tool
            res = tool.handle_mouse_press(self, scene_pos, btn, mods)
            if getattr(res, "status", ""):
                try:
                    self._project_service.status.emit(str(res.status))
                except Exception:
                    pass
            if getattr(res, "changed", False):
                self.refresh()
                return
        except Exception:
            # Never break mouse input on errors.
            pass

        super().mousePressEvent(event)



    def keyPressEvent(self, event):  # noqa: N802 (Qt API)
        """Keyboard shortcuts.

        Implements DAW-friendly shortcuts for Notation:
        - D / S / E: Draw / Select / Erase tool
        - Ctrl+C / Ctrl+V / Ctrl+X: Copy / Paste / Cut (supports multi-note selection)
        - Ctrl+Z: Undo (ProjectService)
        - Del / Backspace: Delete selected note(s)
        
        Selection (with S tool or Select mode):
        - Click: Select single note (clears previous)
        - Ctrl+Click: Toggle note in multi-selection
        - Shift+Click: Range select (from last selected to clicked)
        """
        try:
            key = event.key()
            mods = event.modifiers()
        except Exception:
            return super().keyPressEvent(event)

        ctrl = bool(mods & Qt.KeyboardModifier.ControlModifier)

        # Tool switches (no Ctrl)
        if not ctrl:
            if key == Qt.Key.Key_D:
                self.set_active_tool("draw")
                return
            if key == Qt.Key.Key_S:
                self.set_active_tool("select")
                return
            if key == Qt.Key.Key_E:
                # Enable Erase as left-click tool (right-click erase stays available)
                self._tool = self._erase_tool
                try:
                    self._project_service.status.emit("Notation Tool: Erase")
                except Exception:
                    pass
                return

            if key in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
                if self._delete_selected_marks() or self._delete_selected_note():
                    return

        # Ctrl shortcuts
        if ctrl:
            if key == Qt.Key.Key_Z:
                try:
                    self._project_service.undo()
                    self.refresh()
                except Exception:
                    pass
                return

            if key == Qt.Key.Key_C:
                if self._copy_selected_note():
                    return

            if key == Qt.Key.Key_X:
                if self._cut_selected_note():
                    return

            if key == Qt.Key.Key_V:
                if self._paste_clipboard_note():
                    return

        return super().keyPressEvent(event)


    # ------------------------------------------------------------------
    # Context Menu (Task 11)
    # ------------------------------------------------------------------
    def contextMenuEvent(self, event):  # noqa: N802 (Qt API)
        """Open a safe context menu (Ctrl+RightClick).

        We keep the MVP ergonomics:
        - **Right click** still erases a note (Task 5).
        - **Ctrl + Right click** opens a context menu.

        Rationale: some Qt/graphics-view setups may crash when opening a menu
        synchronously inside the event handler. We therefore defer the `exec()`
        via ``QTimer.singleShot(0, ...)``.
        """
        try:
            mods = event.modifiers()
        except Exception:
            mods = Qt.KeyboardModifier.NoModifier

        # Keep default right-click erase behavior unless the user explicitly asks for a menu.
        if not (mods & Qt.KeyboardModifier.ControlModifier):
            try:
                event.ignore()
            except Exception:
                pass
            return

        try:
            scene_pos = self.mapToScene(event.pos())
        except Exception:
            scene_pos = None

        try:
            global_pos = event.globalPos()
        except Exception:
            try:
                global_pos = event.globalPosition().toPoint()
            except Exception:
                global_pos = QCursor.pos()

        def _open() -> None:
            try:
                self._open_context_menu(scene_pos, global_pos)
            except Exception:
                pass

        try:
            QTimer.singleShot(0, _open)
            event.accept()
        except Exception:
            pass

    def _open_context_menu(self, scene_pos, global_pos) -> None:
        """Build and show the context menu."""
        try:
            menu = QMenu(self)
            act_erase = menu.addAction("✖ Löschen (Erase)")
            act_clear = menu.addAction("⨯ Auswahl löschen")
            menu.addSeparator()
            act_draw = menu.addAction("✎ Tool: Draw")
            act_select = menu.addAction("⬚ Tool: Select")
            menu.addSeparator()
            act_refresh = menu.addAction("⟳ Neu rendern")
            menu.addSeparator()
            act_add_note = menu.addAction("🗒 Editor-Notiz hinzufügen")
            act_add_rest = menu.addAction("⏸ Pause setzen (MVP)")
            act_remove_marks = menu.addAction("🗑 Markierungen an dieser Position löschen")

            act_clear.setEnabled(self._selected_key is not None)

            def _emit_status(msg: str) -> None:
                try:
                    self._project_service.status.emit(str(msg))
                except Exception:
                    pass

            def _do_erase() -> None:
                if scene_pos is None:
                    _emit_status("Kein Cursor-Punkt für Erase.")
                    return
                res = self._erase_tool.handle_mouse_press(
                    self,
                    scene_pos,
                    Qt.MouseButton.RightButton,
                    Qt.KeyboardModifier.NoModifier,
                )
                if getattr(res, "status", ""):
                    _emit_status(str(res.status))
                if getattr(res, "changed", False):
                    self.refresh()

            def _do_clear() -> None:
                self.clear_selection()
                self.refresh()

            def _do_draw() -> None:
                self.set_active_tool("draw")
                _emit_status("Notation Tool: Draw")

            def _do_select() -> None:
                self.set_active_tool("select")
                _emit_status("Notation Tool: Select")


            def _beat_from_scene() -> float:
                if scene_pos is None:
                    return 0.0
                try:
                    b = self.scene_x_to_beat(float(scene_pos.x()))
                except Exception:
                    b = 0.0
                # snap to current grid
                try:
                    snap_div = str(getattr(self._project_service.ctx.project, "snap_division", "1/16") or "1/16")
                    snap = snap_beats_from_div(snap_div)
                    return max(0.0, snap_to_grid(float(b), float(snap)))
                except Exception:
                    return max(0.0, float(b))

            def _do_add_editor_note() -> None:
                if not self._clip_id:
                    _emit_status("Kein MIDI-Clip ausgewählt.")
                    return
                try:
                    from PyQt6.QtWidgets import QInputDialog
                    text, ok = QInputDialog.getMultiLineText(self, "Editor-Notiz", "Notiztext:", "")
                    if not ok:
                        return
                    txt = str(text or "").strip()
                    if not txt:
                        return
                except Exception:
                    return
                beat = _beat_from_scene()
                try:
                    if hasattr(self._project_service, "add_notation_mark"):
                        self._project_service.add_notation_mark(str(self._clip_id), beat=float(beat), mark_type="comment", data={"text": txt})
                        self.refresh()
                        _emit_status("Editor-Notiz hinzugefügt.")
                except Exception:
                    pass

            def _do_add_rest() -> None:
                if not self._clip_id:
                    _emit_status("Kein MIDI-Clip ausgewählt.")
                    return
                beat = _beat_from_scene()
                st = getattr(self, "input_state", None)
                try:
                    dur = float(st.duration_beats()) if st is not None else 0.25
                except Exception:
                    dur = 0.25
                try:
                    if hasattr(self._project_service, "add_notation_mark"):
                        self._project_service.add_notation_mark(str(self._clip_id), beat=float(beat), mark_type="rest", data={"duration_beats": float(dur)})
                        self.refresh()
                        _emit_status("Pause gesetzt.")
                except Exception:
                    pass

            def _do_remove_marks_here() -> None:
                if not self._clip_id:
                    return
                beat = _beat_from_scene()
                try:
                    proj = getattr(getattr(self._project_service, "ctx", None), "project", None)
                    marks = getattr(proj, "notation_marks", []) or []
                except Exception:
                    marks = []
                if not isinstance(marks, list):
                    return
                # Remove marks close to this beat (within half snap).
                try:
                    snap_div = str(getattr(self._project_service.ctx.project, "snap_division", "1/16") or "1/16")
                    snap = float(snap_beats_from_div(snap_div))
                except Exception:
                    snap = 0.25
                keep = []
                for m in marks:
                    try:
                        if str(m.get("clip_id","")) != str(self._clip_id):
                            keep.append(m); continue
                        if abs(float(m.get("beat",0.0)) - float(beat)) <= (0.5 * snap):
                            continue
                        keep.append(m)
                    except Exception:
                        keep.append(m)
                try:
                    proj.notation_marks = keep
                    self.refresh()
                    _emit_status("Markierungen entfernt.")
                except Exception:
                    pass


            act_erase.triggered.connect(_do_erase)
            act_clear.triggered.connect(_do_clear)
            act_draw.triggered.connect(_do_draw)
            act_select.triggered.connect(_do_select)
            act_refresh.triggered.connect(self.refresh)
            act_add_note.triggered.connect(_do_add_editor_note)
            act_add_rest.triggered.connect(_do_add_rest)
            act_remove_marks.triggered.connect(_do_remove_marks_here)

            try:
                menu.exec(global_pos)
            except Exception:
                menu.exec(QCursor.pos())
        except Exception:
            # Context menus must never crash the editor.
            return


    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def set_clip(self, clip_id: str | None):
        """Set the active clip id whose notes should be rendered."""
        self._clip_id = str(clip_id) if clip_id else None
        # Reset selection when switching clips (prevents confusing highlight).
        self._selected_key = None
        self.refresh()


    # --- Live MIDI Ghost Noteheads (Input Monitoring) ------------------------

    def handle_live_note_on(self, clip_id: str, track_id: str, pitch: int,
                            velocity: int, channel: int, start_beats: float) -> None:
        """Show a transient ghost notehead for a live key press.

        This does NOT commit anything to the clip (commit happens on note-off
        in MidiManager). Ghost notes are kept per clip and re-rendered on refresh.
        """
        cid = str(clip_id or "")
        if not cid:
            return
        # store state
        try:
            tmp = MidiNote(pitch=int(pitch), start_beats=0.0, length_beats=1.0, velocity=int(velocity))
            _ = tmp.to_staff_position()
            acc = int(getattr(tmp, "accidental", 0))
        except Exception:
            acc = 0
        st = _LiveGhostState(
            pitch=int(pitch),
            velocity=int(velocity),
            channel=int(channel),
            start_beats=float(start_beats),
            accidental=int(acc),
        )
        self._live_ghost.setdefault(cid, []).append(st)

        # If this is the currently visible clip, draw it immediately.
        if self._clip_id and str(self._clip_id) == cid:
            try:
                self._add_live_ghost_item(st)
            except Exception:
                # fallback: next refresh will draw
                pass

    def handle_live_note_off(self, clip_id: str, track_id: str, pitch: int, channel: int) -> None:
        """Remove the transient ghost notehead for a released key."""
        cid = str(clip_id or "")
        if not cid:
            return
        lst = self._live_ghost.get(cid, [])
        # remove one matching entry (supports repeated notes)
        removed = False
        for i, st in enumerate(list(lst)):
            if int(getattr(st, "pitch", -1)) == int(pitch) and int(getattr(st, "channel", -1)) == int(channel):
                try:
                    lst.pop(i)
                except Exception:
                    pass
                removed = True
                break
        if not lst and cid in self._live_ghost:
            self._live_ghost.pop(cid, None)

        if self._clip_id and str(self._clip_id) == cid:
            if removed:
                self._remove_live_ghost_item(int(pitch), int(channel))
            else:
                # if we couldn't match, just clear & re-render
                self._render_live_ghost_notes()

    def handle_midi_panic(self, _reason: str = "") -> None:
        """Clear all live ghost notes (e.g. on transport stop / panic)."""
        self._live_ghost.clear()
        self._render_live_ghost_notes()

    def _remove_live_ghost_item(self, pitch: int, channel: int) -> None:
        sc = self.scene()
        remaining: list[_LiveGhostNoteItem] = []
        for it in list(self._live_ghost_items):
            try:
                # We encode pitch/channel into tooltip to avoid storing extra fields on the item.
                tip = str(it.toolTip() or "")
                if tip == f"live:{pitch}:{channel}":
                    sc.removeItem(it)
                    continue
            except Exception:
                pass
            remaining.append(it)
        self._live_ghost_items = remaining

    def _add_live_ghost_item(self, st: _LiveGhostState) -> None:
        x = self._beat_to_x(float(st.start_beats))
        line = self._pitch_to_staff_line(int(st.pitch))
        item = _LiveGhostNoteItem(
            x_center=float(x),
            line=int(line),
            accidental=int(getattr(st, "accidental", 0)),
            velocity=int(getattr(st, "velocity", 100)),
            y_offset=int(self._layout.y_offset),
            style=self._style,
        )
        try:
            item.setToolTip(f"live:{int(st.pitch)}:{int(st.channel)}")
        except Exception:
            pass
        self.scene().addItem(item)
        self._live_ghost_items.append(item)

    def _render_live_ghost_notes(self) -> None:
        """Render (or re-render) all live ghost noteheads for the current clip."""
        # remove current live items
        sc = self.scene()
        try:
            for it in list(self._live_ghost_items):
                try:
                    sc.removeItem(it)
                except Exception:
                    pass
        except Exception:
            pass
        self._live_ghost_items = []

        if not self._clip_id:
            return
        cid = str(self._clip_id)
        for st in list(self._live_ghost.get(cid, []) or []):
            try:
                self._add_live_ghost_item(st)
            except Exception:
                continue

    def refresh(self):
        """Re-render staff + notes for the current clip."""
        notes: list[MidiNote] = []
        if self._clip_id:
            try:
                notes = list(self._project_service.get_midi_notes(self._clip_id))
            except Exception:
                notes = []

        # Cache a lightweight signature so we can skip redundant refreshes.
        self._last_notes_sig = self._notes_signature(notes)

        # Update the scene width based on clip content (keep it stable and only grow).
        if notes:
            max_end = 0.0
            for n in notes:
                try:
                    max_end = max(max_end, float(n.start_beats) + float(n.length_beats))
                except Exception:
                    continue
            max_end = max(8.0, min(256.0, max_end))
            self._layout.max_beats = max(self._layout.max_beats, float(max_end) + 4.0)

        self._rebuild_scene_base()
        self._render_notes(notes)
        self._render_live_ghost_notes()
        self._render_notation_marks()
        self._update_scene_rect_from_content()
        # re-apply selection after rebuild (if we could match it)
        self._apply_selection_to_items()
        self.notes_changed.emit()

    # ------------------------------------------------------------------
    # Task 7: Bidirektionale MIDI-Sync helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _notes_signature(notes: list[MidiNote]) -> tuple:
        """Create a stable signature for MIDI notes.

        We avoid hashing whole dataclasses; instead we use the most relevant
        numeric fields with rounding. Order is preserved as stored.
        """

        sig = []
        for n in list(notes or []):
            try:
                sig.append(
                    (
                        int(getattr(n, "pitch", 0)),
                        round(float(getattr(n, "start_beats", 0.0)), 6),
                        round(float(getattr(n, "length_beats", 0.0)), 6),
                        int(getattr(n, "velocity", 100)),
                    )
                )
            except Exception:
                continue
        return tuple(sig)

    def _on_project_updated(self) -> None:
        """React to global project updates.

        - Avoid infinite refresh loops by allowing callers to suppress the next
          few updates (e.g. when the notation view writes MIDI notes).
        - Skip redundant refreshes if the active clip's notes are unchanged.
        """

        if self._suppress_project_updates > 0:
            self._suppress_project_updates = max(0, int(self._suppress_project_updates) - 1)
            return

        if not self._clip_id:
            # No active clip -> nothing meaningful to refresh.
            return

        try:
            notes = list(self._project_service.get_midi_notes(self._clip_id))
        except Exception:
            notes = []

        sig = self._notes_signature(notes)
        if sig == self._last_notes_sig:
            return

        self.refresh()

    def commit_notes_to_project(self, notes: list[MidiNote], *, label: str = "Edit MIDI (Notation)") -> None:
        """Commit a full notes list back to the ProjectService.

        This is the preferred way for future notation edit actions (drag/resize)
        because it creates a single Undo step and keeps UI sync predictable.

        Notes:
        - For MVP tools (Draw/Erase) we may still call ProjectService helpers
          directly. This method mainly provides the bidirectional sync
          infrastructure and recursion prevention requested in Task 7.
        """

        if not self._clip_id:
            return
        ps = self._project_service
        try:
            before = ps.snapshot_midi_notes(str(self._clip_id))
        except Exception:
            before = []

        # set_midi_notes() emits project_updated, commit_midi_notes_edit() emits
        # again; allow a small suppression budget.
        self._suppress_project_updates += 3

        try:
            ps.set_midi_notes(str(self._clip_id), list(notes or []))
        except Exception:
            return

        try:
            ps.commit_midi_notes_edit(str(self._clip_id), before, str(label or "Edit MIDI (Notation)"))
        except Exception:
            # Even if undo commit fails, keep UI consistent.
            try:
                ps._emit_updated()  # type: ignore[attr-defined]
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------
    @staticmethod
    def _diatonic_index(line: int, octave: int) -> int:
        # line: C=0..B=6
        return int(octave) * 7 + int(line)

    def _pitch_to_staff_line(self, pitch: int) -> int:
        """Map MIDI pitch to staff half-step index relative to treble bottom line E4."""
        tmp = MidiNote(pitch=int(pitch), start_beats=0.0, length_beats=1.0, velocity=100)
        line, octv = tmp.to_staff_position()  # sets accidental on tmp
        diat = self._diatonic_index(line, octv)
        e4_ref = self._diatonic_index(2, 4)  # E4 (bottom line)
        return int(diat - e4_ref)

    def _beat_to_x(self, beat: float) -> float:
        return float(self._layout.left_margin) + float(beat) * float(self._layout.pixels_per_beat)



    def _update_scene_rect_from_content(self) -> None:
        """Grow the scene rect to include all items (notes, marks, ghost layers)."""
        try:
            sc = self.scene()
            br = sc.itemsBoundingRect()
            # Add padding so selection/glow isn't clipped.
            pad_x = 80.0
            pad_y = 120.0
            x0 = max(0.0, float(br.left()) - pad_x)
            # CRITICAL FIX: Allow negative Y for high notes (C8, C9) above staff!
            # Don't clamp to 0 - let scene rect include notes with negative Y coords
            y0 = float(br.top()) - pad_y
            w = float(br.width()) + pad_x * 2.0
            h = float(br.height()) + pad_y * 2.0
            # Ensure a minimum height for comfortable Y scrolling
            h = max(h, float(StaffRenderer.staff_height(self._style) + 260))
            sc.setSceneRect(QRectF(x0, y0, w, h))
        except Exception:
            pass

    def _rebuild_scene_base(self) -> None:
        sc = self.scene()
        sc.clear()
        self._note_items.clear()

        width_px = (
            float(self._layout.left_margin)
            + float(self._layout.right_margin)
            + float(self._layout.max_beats) * float(self._layout.pixels_per_beat)
        )

        self._staff_item = _StaffBackgroundItem(width_px, self._style, self._layout.y_offset)
        sc.addItem(self._staff_item)

        # stable scene rect; keeps scrolling consistent
        h = StaffRenderer.staff_height(self._style) + 180
        sc.setSceneRect(QRectF(0, 0, width_px, float(h)))

        # small hint if no clip selected
        if not self._clip_id:
            hint = sc.addText("Kein MIDI-Clip ausgewählt.\nWähle im Arranger einen MIDI-Clip.")
            hint.setDefaultTextColor(Qt.GlobalColor.black)
            hint.setPos(20, self._layout.y_offset + StaffRenderer.staff_height(self._style) + 40)

    def _render_notes(self, notes: list[MidiNote]) -> None:
        """Render notes to the scene.
        
        Note: Ghost layers are rendered even if main clip is empty!
        """
        if not self._clip_id:
            return

        # Ghost Notes / Layered Editing: Render ghost layers BEFORE main notes
        # IMPORTANT: Render ghost layers even if main clip is empty!
        try:
            if hasattr(self, 'ghost_renderer') and hasattr(self, 'layer_manager'):
                self.ghost_renderer.render_ghost_layers(
                    self.scene(),
                    self.layer_manager,
                    self._layout,
                    self._style,
                )
        except Exception:
            pass

        # Early return if no main notes (after ghost rendering!)
        if not notes:
            return

        # Add main notes
        for n in notes:
            try:
                x = self._beat_to_x(float(n.start_beats))
                staff_line = self._pitch_to_staff_line(int(n.pitch))
            except Exception:
                continue

            selected = False
            try:
                selected = self._selected_key == self._note_key(n)
            except Exception:
                selected = False

            item = _NoteItem(
                n,
                x_center=float(x),
                staff_line=int(staff_line),
                y_offset=int(self._layout.y_offset),
                style=self._style,
                selected=bool(selected),
            )
            self.scene().addItem(item)
            self._note_items.append(item)


    def _render_notation_marks(self) -> None:
        """Render notation marks (sticky notes, rests, ornaments) for the active clip."""
        if not self._clip_id:
            return

        try:
            proj = getattr(getattr(self._project_service, "ctx", None), "project", None)
            marks = getattr(proj, "notation_marks", []) or []
        except Exception:
            marks = []

        if not isinstance(marks, list):
            return

        # Render marks for this clip only.
        for m in list(marks):
            try:
                if str(m.get("clip_id", "")) != str(self._clip_id):
                    continue
                beat = float(m.get("beat", 0.0))
                mtype = str(m.get("type", ""))
                data = dict(m.get("data", {}) or {})
                x = self._beat_to_x(beat)

                if mtype == "comment":
                    txt = str(data.get("text", "") or "")
                    it = _MarkItem(kind="comment", x=float(x), y=float(self._layout.y_offset) - 46, text=txt, mark_id=str(m.get("id","")))
                    self.scene().addItem(it)
                elif mtype == "rest":
                    dur = float(data.get("duration_beats", 0.25))
                    lab = format_rest_label(dur)
                    it = _MarkItem(kind="rest", x=float(x), y=float(self._layout.y_offset) + 12, text=lab, mark_id=str(m.get("id","")))
                    self.scene().addItem(it)
                elif mtype == "ornament":
                    orn = str(data.get("ornament","") or "")
                    pitch = int(data.get("pitch", 0) or 0)
                    staff_line = self._pitch_to_staff_line(pitch) if pitch else 0
                    y = float(self._layout.y_offset) + StaffRenderer.staff_y_from_halfsteps(staff_line, self._style)
                    lab = format_ornament_label(orn)
                    it = _MarkItem(kind="ornament", x=float(x)+10, y=float(y)-22, text=lab, mark_id=str(m.get("id","")))
                    self.scene().addItem(it)
                elif mtype in ("tie", "slur"):
                    try:
                        a = dict(data.get("from", {}) or {})
                        b = dict(data.get("to", {}) or {})
                        b1 = float(a.get("beat", 0.0))
                        p1 = int(a.get("pitch", 0) or 0)
                        b2 = float(b.get("beat", 0.0))
                        p2 = int(b.get("pitch", 0) or 0)
                        x1 = self._beat_to_x(b1)
                        x2 = self._beat_to_x(b2)
                        sl1 = self._pitch_to_staff_line(p1) if p1 else 0
                        sl2 = self._pitch_to_staff_line(p2) if p2 else 0
                        y1 = float(self._layout.y_offset) + StaffRenderer.staff_y_from_halfsteps(sl1, self._style)
                        y2 = float(self._layout.y_offset) + StaffRenderer.staff_y_from_halfsteps(sl2, self._style)
                        conn = _ConnectionItem(kind=str(mtype), x1=float(x1), y1=float(y1), x2=float(x2), y2=float(y2), mark_id=str(m.get("id","")))
                        # Keep connections behind selected notes but above staff.
                        try:
                            conn.setZValue(2.0)
                        except Exception:
                            pass
                        self.scene().addItem(conn)
                    except Exception:
                        pass
            except Exception:
                continue


    def _refresh_ghost_notes(self) -> None:
        """Refresh ghost notes when layer configuration changes."""
        try:
            if hasattr(self, 'ghost_renderer') and hasattr(self, 'layer_manager'):
                self.ghost_renderer.render_ghost_layers(
                    self.scene(),
                    self.layer_manager,
                    self._layout,
                    self._style,
                )
        except Exception:
            pass


class NotationWidget(QWidget):
    """A small tab-friendly wrapper around :class:`NotationView`."""

    status_message = pyqtSignal(str)

    def __init__(self, project_service, *, transport=None, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._project_service = project_service
        self._transport = transport
        self._clip_id: str | None = None

        self._view = NotationView(project_service, parent=self)

        top = QHBoxLayout()
        top.setContentsMargins(6, 6, 6, 0)
        top.setSpacing(8)

        self._lbl = QLabel("Notation (MVP)")
        top.addWidget(self._lbl)
        top.addStretch(1)

        # Minimal tool switcher (keeps the MVP usable without shortcuts).
        btn_draw = QToolButton()
        btn_draw.setText("✎")
        btn_draw.setToolTip("Tool: Draw (Note zeichnen)")
        btn_draw.setCheckable(True)
        btn_draw.setChecked(True)
        top.addWidget(btn_draw)

        btn_select = QToolButton()
        btn_select.setText("⬚")
        btn_select.setToolTip("Tool: Select (Note auswählen)")
        btn_select.setCheckable(True)
        top.addWidget(btn_select)

        btn_tie = QToolButton()
        btn_tie.setText("⌒")
        btn_tie.setToolTip("Tool: Tie / Haltebogen (2 Klicks: Startnote → Endnote, gleiche Tonhöhe)")
        btn_tie.setCheckable(True)
        top.addWidget(btn_tie)

        btn_slur = QToolButton()
        btn_slur.setText("∿")
        btn_slur.setToolTip("Tool: Slur / Bindebogen (2 Klicks: Startnote → Endnote)")
        btn_slur.setCheckable(True)
        top.addWidget(btn_slur)

        # Clear visual indicator for the Rosegarden-like "armed" overlay.
        # This is important because connection mode does NOT replace the
        # primary tool (pencil can stay active).
        self._conn_indicator = QLabel("")
        try:
            self._conn_indicator.setMinimumWidth(120)
        except Exception:
            pass
        top.addWidget(self._conn_indicator)

        def _set_primary(name: str) -> None:
            # Primary tools are exclusive: Draw / Select.
            self._view.set_active_tool(name)
            btn_draw.setChecked(name == "draw")
            btn_select.setChecked(name == "select")

        def _set_connection(mode: str | None) -> None:
            # Connection mode is an overlay: can be enabled while Draw stays active.
            self._view.set_connection_mode(mode)
            btn_tie.setChecked(mode == "tie")
            btn_slur.setChecked(mode == "slur")
            # Update UI indicator text.
            try:
                if mode == "tie":
                    self._conn_indicator.setText("Tie armed")
                elif mode == "slur":
                    self._conn_indicator.setText("Slur armed")
                else:
                    self._conn_indicator.setText("")
            except Exception:
                pass

        btn_draw.clicked.connect(lambda: _set_primary("draw"))
        btn_select.clicked.connect(lambda: _set_primary("select"))

        def _toggle_tie() -> None:
            if btn_tie.isChecked():
                btn_slur.setChecked(False)
                _set_connection("tie")
            else:
                _set_connection(None)

        def _toggle_slur() -> None:
            if btn_slur.isChecked():
                btn_tie.setChecked(False)
                _set_connection("slur")
            else:
                _set_connection(None)

        # Extra guidance for the modifier workflow.
        try:
            btn_tie.setToolTip(
                "Tie / Haltebogen (2 Klicks: Startnote → Endnote, gleiche Tonhöhe)\n"
                "Overlay/Armed: bleibt aktiv, während der Stift aktiv bleibt.\n"
                "Momentary: Shift+Klick = Tie. Ctrl+Klick erzwingt Stift/Select."
            )
            btn_slur.setToolTip(
                "Slur / Bindebogen (2 Klicks: Startnote → Endnote)\n"
                "Overlay/Armed: bleibt aktiv, während der Stift aktiv bleibt.\n"
                "Momentary: Alt+Klick = Slur. Ctrl+Klick erzwingt Stift/Select."
            )
        except Exception:
            pass

        btn_tie.clicked.connect(_toggle_tie)
        btn_slur.clicked.connect(_toggle_slur)

        btn_refresh = QToolButton()
        btn_refresh.setText("⟳")
        btn_refresh.setToolTip("Neu rendern")
        btn_refresh.clicked.connect(self._view.refresh)
        top.addWidget(btn_refresh)


        # Rosegarden-like notation input palette (note values, dotted, rests, accidentals, ornaments, editor-notes)
        self._palette = NotationPalette(self)
        self._palette.state_changed.connect(self._view.set_input_state)
        # push initial state
        try:
            self._view.set_input_state(self._palette.state())
        except Exception:
            pass

        # Optional: editor notes quick button -> anchors at last mouse position (or beat 0)
        self._palette.enable_editor_notes_button(True)

        def _add_editor_note_from_palette() -> None:
            try:
                from PyQt6.QtWidgets import QInputDialog
                txt, ok = QInputDialog.getMultiLineText(self, "Editor-Notiz", "Notiztext:", "")
                if not ok:
                    return
                msg = str(txt or "").strip()
                if not msg:
                    return
            except Exception:
                return
            # anchor at last hover position
            try:
                scene_pos = getattr(self._view, "_last_mouse_scene_pos", None)
                if scene_pos is None:
                    beat = 0.0
                else:
                    beat = float(self._view.scene_x_to_beat(float(scene_pos.x())))
                # snap to grid
                snap_div = str(getattr(self._project_service.ctx.project, "snap_division", "1/16") or "1/16")
                snap = float(snap_beats_from_div(snap_div))
                beat = max(0.0, snap_to_grid(float(beat), float(snap)))
            except Exception:
                beat = 0.0
            try:
                if getattr(self._view, "clip_id", None) and hasattr(self._project_service, "add_notation_mark"):
                    self._project_service.add_notation_mark(str(self._view.clip_id), beat=float(beat), mark_type="comment", data={"text": msg})
                    self._view.refresh()
            except Exception:
                pass

        try:
            self._palette.editor_notes_button().clicked.connect(_add_editor_note_from_palette)
        except Exception:
            pass

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(6)
        root.addLayout(top)
        root.addWidget(self._palette)
        root.addWidget(self._view, 1)

        # Ghost Notes / Layered Editing: Layer Panel
        from pydaw.ui.layer_panel import LayerPanel
        self.layer_panel = LayerPanel(self._view.layer_manager)
        self.layer_panel.setMaximumHeight(200)  # Collapsible panel height
        self.layer_panel.layer_added.connect(self._on_add_ghost_layer)  # Connect signal
        root.addWidget(self.layer_panel)

        # Keep label in sync
        self._view.notes_changed.connect(self._update_label)

        # --- Task 7: Bidirektionale MIDI-Sync (Clip-Selection) ---
        # If the host DAW selects a clip (Arranger/PianoRoll), follow it automatically.
        # Only MIDI clips are shown; selecting an audio clip clears the notation view.
        try:
            self._project_service.active_clip_changed.connect(self._on_active_clip_changed)
        except Exception:
            pass
        try:
            self._project_service.clip_selected.connect(self._on_active_clip_changed)
        except Exception:
            pass

        # Initial sync (if the project already has a selected clip)
        try:
            cid = str(getattr(self._project_service, "active_clip_id", "") or "")
            if cid:
                self._on_active_clip_changed(cid)
        except Exception:
            pass

    def _on_active_clip_changed(self, clip_id: str) -> None:
        cid = str(clip_id or "").strip()
        if not cid:
            self.set_clip(None)
            return

        # Only show MIDI clips.
        try:
            clip = next((c for c in self._project_service.ctx.project.clips if str(getattr(c, "id", "")) == cid), None)
        except Exception:
            clip = None

        if not clip or str(getattr(clip, "kind", "")) != "midi":
            self.set_clip(None)
            return

        self.set_clip(cid)

    def set_clip(self, clip_id: str | None) -> None:
        self._clip_id = str(clip_id) if clip_id else None
        self._view.set_clip(self._clip_id)
        self._update_label()


    # --- Live MIDI Ghost Noteheads (forward to view) -------------------------

    def handle_live_note_on(self, clip_id: str, track_id: str, pitch: int,
                            velocity: int, channel: int, start_beats: float) -> None:
        try:
            self._view.handle_live_note_on(str(clip_id), str(track_id), int(pitch),
                                           int(velocity), int(channel), float(start_beats))
        except Exception:
            pass

    def handle_live_note_off(self, clip_id: str, track_id: str, pitch: int, channel: int) -> None:
        try:
            self._view.handle_live_note_off(str(clip_id), str(track_id), int(pitch), int(channel))
        except Exception:
            pass

    def handle_midi_panic(self, reason: str = "") -> None:
        try:
            self._view.handle_midi_panic(str(reason))
        except Exception:
            pass

    def _update_label(self) -> None:
        if self._clip_id:
            self._lbl.setText(f"Notation (MVP) – Clip: {self._clip_id}")
        else:
            self._lbl.setText("Notation (MVP)")

    def _on_add_ghost_layer(self) -> None:
        """Handle add ghost layer request from Layer Panel."""
        from PyQt6.QtWidgets import QDialog
        from pydaw.ui.clip_selection_dialog import ClipSelectionDialog
        from pydaw.model.ghost_notes import LayerState
        
        # Open clip selection dialog
        dialog = ClipSelectionDialog(
            self._project_service,
            current_clip_id=self._clip_id,
            parent=self
        )
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            clip_id = dialog.get_selected_clip_id()
            if not clip_id:
                return
            
            # Get clip info for display name
            try:
                project = self._project_service.ctx.project
                clip = next((c for c in project.clips if c.id == clip_id), None)
                track = next((t for t in project.tracks if clip and t.id == clip.track_id), None)
                
                if clip and track:
                    track_name = str(track.name)
                    
                    # Add as ghost layer
                    self._view.layer_manager.add_layer(
                        clip_id=clip_id,
                        track_name=track_name,
                        state=LayerState.LOCKED,
                        opacity=0.3,
                    )
                    
                    # Show status message
                    try:
                        self.status_message.emit(f"Ghost Layer hinzugefügt: {track_name}")
                    except Exception:
                        pass
            except Exception as e:
                print(f"Error adding ghost layer: {e}")


def _run_demo() -> None:
    """Standalone visual demo (does not require the full DAW)."""

    from PyQt6.QtCore import QObject

    class _Stub(QObject):
        project_updated = pyqtSignal()

        def __init__(self):
            super().__init__()
            self._notes = {
                "clip1": [
                    MidiNote(pitch=64, start_beats=0.0, length_beats=1.0, velocity=100),  # E4
                    MidiNote(pitch=66, start_beats=1.0, length_beats=1.0, velocity=100),  # F#4
                    MidiNote(pitch=67, start_beats=2.0, length_beats=2.0, velocity=100),  # G4
                    MidiNote(pitch=72, start_beats=4.0, length_beats=1.0, velocity=100),  # C5
                ]
            }

        def get_midi_notes(self, clip_id: str):
            return list(self._notes.get(clip_id, []))

    app = QApplication.instance() or QApplication([])
    stub = _Stub()
    w = NotationWidget(stub)
    w.resize(1000, 380)
    w.set_clip("clip1")
    w.show()
    app.exec()


if __name__ == "__main__":
    _run_demo()
