# 📦 ChronoScaleStudio (Py_DAW) – Installation

## System Requirements
- **OS:** Linux **oder** macOS
- **Python:** 3.10+ (empfohlen: venv)
- **GUI:** PyQt6
- **Audio:**
  - **Linux:** PipeWire-JACK/JACK *oder* sounddevice (PortAudio)
  - **macOS:** **CoreAudio** via sounddevice (PortAudio)
- **Optional Tools (Linux):** qpwgraph (Audio-Routing)

---

## Quick Install (alle OS)

```bash
# 1) Unzip
unzip Py_DAW_v0_0_20_XXX_TEAM_READY*.zip
cd Py_DAW_v0_0_20_XXX_TEAM_READY*

# 2) Virtual Env
python3 -m venv myenv
source myenv/bin/activate

# 3) Install (empfohlen: nutzt install.py)
python3 install.py

# 4) Start
python3 main.py
```

---

## macOS (Metal + CoreAudio)

### System Dependencies (Homebrew)
`install.py` versucht das automatisch. Manuell geht’s so:

```bash
brew install portaudio libsndfile fluidsynth
```

### Metal Render Backend
Default ist `auto` → **Metal** auf macOS. Override:

```bash
PYDAW_GFX_BACKEND=metal python3 main.py
# Fallback:
PYDAW_GFX_BACKEND=opengl python3 main.py
```

---

## Linux Audio Backend Setup (optional)

### PipeWire-JACK (empfohlen)
```bash
sudo apt install pipewire-jack qpwgraph
qpwgraph &
```

### JACK (klassisch)
```bash
sudo apt install jackd2
jack_control start
```

---

## Troubleshooting

### Vulkan (Linux) – System packages (optional)
Wenn du unter Linux Vulkan als Default-Backend nutzen willst:

```bash
sudo apt update
sudo apt install libvulkan1 mesa-vulkan-drivers vulkan-tools
vulkaninfo | head
```

Override (z. B. wenn dein Treiber kein Vulkan kann):

```bash
PYDAW_GFX_BACKEND=opengl python3 main.py
```

### "ModuleNotFoundError"
```bash
python3 -m pip install --upgrade -r requirements.txt
```

### "No audio devices found"
- **macOS:** Audio-Einstellungen öffnen und Output neu wählen (CoreAudio)
- **Linux:** PipeWire/JACK prüfen:
```bash
pw-cli ls || true
jack_lsp || true
```

---

✅ Danach: `python3 main.py`
