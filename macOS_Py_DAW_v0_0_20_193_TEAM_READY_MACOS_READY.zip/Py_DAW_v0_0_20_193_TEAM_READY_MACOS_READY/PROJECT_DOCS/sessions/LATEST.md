# Session: v0.0.20.193 — macOS: Metal + CoreAudio (Packaging)

Siehe:
- `PROJECT_DOCS/sessions/SESSION_v0.0.20.193_MACOS_METAL_COREAUDIO_INSTALL.md`
