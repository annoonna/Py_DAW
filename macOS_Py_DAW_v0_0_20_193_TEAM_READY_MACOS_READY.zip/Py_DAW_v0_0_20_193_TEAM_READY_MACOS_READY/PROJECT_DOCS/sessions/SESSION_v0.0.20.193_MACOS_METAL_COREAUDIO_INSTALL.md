# SESSION v0.0.20.193 — macOS: Metal + CoreAudio Packaging

**Datum:** 2026-03-02  
**Assignee:** GPT-5.2 Thinking (ChatGPT)  
**Ziel:** macOS lauffähig machen (Metal Rendering Default + CoreAudio Playback) ohne Linux zu zerstören.

---

## Änderungen

### 1) requirements.txt
- `JACK-Client` auf **Linux-only** gesetzt:
  - `JACK-Client>=...; platform_system=="Linux"`
- Begründung: macOS soll standardmäßig über **CoreAudio** (sounddevice/PortAudio) laufen.

### 2) install.py
- macOS erkennt Homebrew (best effort) und installiert:
  - `portaudio` (sounddevice)
  - `libsndfile` (soundfile)
  - `fluidsynth` (SF2/MIDI Pre-Render)
- Kein Hard-Fail, wenn brew fehlt (nur Hinweis + Anleitung).

### 3) Graphics Backend (Metal)
- `pydaw/utils/gfx_backend.py` erweitert:
  - `PYDAW_GFX_BACKEND=auto` → **metal** auf macOS
  - Linux bleibt: Vulkan (wenn verfügbar) sonst OpenGL.

### 4) Audio Backend (CoreAudio)
- `pydaw/audio/audio_engine.py`:
  - macOS bevorzugt **sounddevice** gegenüber JACK (JACK optional).
  - Device-IDs werden validiert (ungültige Indizes → fallback auf Default Output).

### 5) INSTALL.md
- macOS Abschnitt ergänzt: Brew + Metal overrides.

---

## Test-Checkliste (macOS)

```bash
python3 -m venv myenv
source myenv/bin/activate
python3 install.py
PYDAW_GFX_BACKEND=metal python3 main.py
```

- Audio-Einstellungen öffnen → Output (CoreAudio) wählen
- Transport Play/Stop testen
- SF2/MIDI Clip Playback testen (fluidsynth verfügbar?)

---

## Dateien geändert
- `requirements.txt`
- `install.py`
- `INSTALL.md`
- `pydaw/utils/gfx_backend.py`
- `pydaw/audio/audio_engine.py`
- `VERSION`, `pydaw/version.py`
