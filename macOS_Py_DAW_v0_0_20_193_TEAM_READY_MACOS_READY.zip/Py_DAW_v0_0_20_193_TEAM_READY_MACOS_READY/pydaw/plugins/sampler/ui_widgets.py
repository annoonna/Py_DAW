# -*- coding: utf-8 -*-
"""Compact UI widgets for the Sampler device (Pro-DAW-Style Device Panel).

Knob: small QPainter-drawn rotary knob with label + value.
WaveformDisplay: thin waveform strip with loop markers.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Optional

import numpy as np

from PyQt6.QtCore import Qt, QTimer, QRectF, pyqtSignal
from PyQt6.QtGui import QPainter, QColor, QPen, QFont
from PyQt6.QtWidgets import QWidget, QSizePolicy, QFrame, QMenu


class CompactKnob(QWidget):
    """Compact QPainter-drawn knob (~52x64 px).

    v0.0.20.90:
    - Optional AutomationManager binding (register_parameter)
    - Right-click context menu: "Show Automation in Arranger" + reset
    - External updates (automation playback) move the knob without feedback loops

    Notes:
    - The AutomationManager emits parameter_changed(parameter_id, value) (2 args).
    - We block signals on external updates so legacy engine wiring does not fire.
    """

    valueChanged = pyqtSignal(int)

    def __init__(self, title: str = "", init: int = 0, parent=None):
        super().__init__(parent)
        self._title = title
        self._value = int(max(0, min(100, init)))
        self._dragging = False
        self._drag_y = 0

        # --- automation binding (optional)
        self._automation_manager = None
        self._automation_param = None
        self._parameter_id: str = ""
        self._track_id: str = ""
        self._default_value: float = float(self._value)
        self._external_update: bool = False
        self._mgr_connected: bool = False

        self.setFixedSize(52, 64)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(f"{title}: {self._value}%")

    # ---------------- basic API
    def value(self) -> int:
        return self._value

    def setValueExternal(self, v: int) -> None:
        """Set value from automation/playback without emitting valueChanged."""
        try:
            self._external_update = True
            self.blockSignals(True)
            self.setValue(int(v))
        finally:
            try:
                self.blockSignals(False)
            except Exception:
                pass
            self._external_update = False

    # ---------------- automation
    def bind_automation(
        self,
        automation_manager,
        parameter_id: str,
        *,
        name: str | None = None,
        track_id: str = "",
        minimum: float = 0.0,
        maximum: float = 100.0,
        default: float | None = None,
    ) -> None:
        """Bind this knob to an AutomatableParameter in the global AutomationManager."""
        self._automation_manager = automation_manager
        self._parameter_id = str(parameter_id or "")
        self._track_id = str(track_id or "")

        if default is None:
            default = float(self._value)
        self._default_value = float(default)

        # Create / fetch parameter
        try:
            if self._automation_manager is not None and self._parameter_id:
                self._automation_param = self._automation_manager.register_parameter(
                    self._parameter_id,
                    str(name or self._title or self._parameter_id),
                    float(minimum),
                    float(maximum),
                    float(default),
                    track_id=self._track_id,
                )
        except Exception:
            self._automation_param = None

        # Listen to global changes once (knob updates itself on playback)
        if (not self._mgr_connected) and (self._automation_manager is not None):
            try:
                self._automation_manager.parameter_changed.connect(self._on_mgr_parameter_changed)
                self._mgr_connected = True
            except Exception:
                self._mgr_connected = False

        # Right-click context menu (Bitwig/Ableton style)
        try:
            self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            try:
                self.customContextMenuRequested.disconnect(self._show_context_menu)
            except Exception:
                pass
            self.customContextMenuRequested.connect(self._show_context_menu)
        except Exception:
            pass

        # Seed base value into the parameter
        try:
            if self._automation_param is not None:
                self._automation_param.set_value(float(self._value))
        except Exception:
            pass

    def set_automation_target(self, parameter_id: str, *, default: float | None = None) -> None:
        """Switch this knob to control another parameter_id (e.g. Drum slot selection)."""
        self._parameter_id = str(parameter_id or "")
        if default is not None:
            self._default_value = float(default)
        try:
            if self._automation_manager is not None and self._parameter_id:
                self._automation_param = self._automation_manager.get_parameter(self._parameter_id)
        except Exception:
            self._automation_param = None

    # ---------------- value changes
    def setValue(self, v: int) -> None:
        v = int(max(0, min(100, v)))
        if v != self._value:
            self._value = v
            self.setToolTip(f"{self._title}: {v}%")
            self.update()

            if not self.signalsBlocked():
                self.valueChanged.emit(v)

            # Push base value into automation system ONLY for interactive changes
            if (not self._external_update) and (self._automation_param is not None):
                try:
                    self._automation_param.set_value(float(v))
                except Exception:
                    pass

    def _on_mgr_parameter_changed(self, parameter_id: str, value: float) -> None:
        """Automation playback / lane edits → GUI."""
        try:
            if str(parameter_id) != str(self._parameter_id):
                return
            self.setValueExternal(int(round(float(value))))
        except Exception:
            pass

    def _show_context_menu(self, pos) -> None:
        try:
            if self._automation_manager is None or not self._parameter_id:
                return
            menu = QMenu(self)
            act_show = menu.addAction("Show Automation in Arranger")
            act_mod = menu.addAction("Add Modulator (LFO/ENV) — coming soon")
            try:
                act_mod.setEnabled(False)
            except Exception:
                pass
            menu.addSeparator()
            act_reset = menu.addAction("Reset to Default")

            chosen = menu.exec(self.mapToGlobal(pos))
            if chosen == act_show:
                try:
                    self._automation_manager.request_show_automation.emit(str(self._parameter_id))
                except Exception:
                    pass
            elif chosen == act_reset:
                try:
                    if self._automation_param is not None:
                        self._automation_param.set_value(float(self._default_value))
                        self._automation_param.set_automation_value(None)
                except Exception:
                    pass
                self.setValueExternal(int(round(self._default_value)))
        except Exception:
            pass

    # ---------------- drawing + interaction
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()

        # Title (top)
        p.setPen(QColor("#aaaaaa"))
        p.setFont(QFont("Sans", 7))
        p.drawText(0, 0, w, 12, Qt.AlignmentFlag.AlignHCenter, self._title)

        cx, cy = w // 2, 12 + 20
        r = 14

        # Background arc
        p.setPen(QPen(QColor("#333333"), 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        arc = QRectF(cx - r, cy - r, 2 * r, 2 * r)
        p.drawArc(arc, 225 * 16, -270 * 16)

        # Value arc
        if self._value > 0:
            p.setPen(QPen(QColor("#e060e0"), 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            span = int(-270 * (self._value / 100.0))
            p.drawArc(arc, 225 * 16, span * 16)

        # Pointer
        angle = math.radians(225.0 - (self._value / 100.0) * 270.0)
        px = cx + (r - 4) * math.cos(angle)
        py = cy - (r - 4) * math.sin(angle)
        p.setPen(QPen(QColor("#ffffff"), 2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawLine(int(cx), int(cy), int(px), int(py))

        # Center dot
        p.setBrush(QColor("#666666"))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(cx - 3, cy - 3, 6, 6)

        # Value (bottom)
        p.setPen(QColor("#cccccc"))
        p.setFont(QFont("Sans", 7))
        p.drawText(0, h - 12, w, 12, Qt.AlignmentFlag.AlignHCenter, f"{self._value}%")

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._dragging = True
            self._drag_y = int(e.position().y())

    def mouseMoveEvent(self, e):
        if self._dragging:
            dy = self._drag_y - int(e.position().y())
            self._drag_y = int(e.position().y())
            self.setValue(self._value + dy)

    def mouseReleaseEvent(self, _):
        self._dragging = False

    def wheelEvent(self, e):
        delta = 1 if e.angleDelta().y() > 0 else -1
        self.setValue(self._value + delta)


class WaveformStrip(QFrame):
    """Thin waveform strip for Pro-DAW device panel."""
    def __init__(self, engine, parent=None):
        super().__init__(parent)
        self.engine = engine
        self.setMinimumHeight(40)
        self.setMaximumHeight(60)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setStyleSheet("background:#0d0d0d;border:1px solid #222;border-radius:3px;")
        self.samples: Optional[np.ndarray] = None
        self.info = "No audio loaded"
        self.position = 0.0
        self.loop_start = 0.0
        self.loop_end = 1.0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._poll)
        self.timer.start(40)

    def _poll(self):
        try:
            if getattr(self.engine, "samples", None) is not None:
                self.samples = self.engine.samples
            if self.samples is not None:
                n = max(1, len(self.samples))
                self.position = float(getattr(self.engine.state, "position", 0.0)) / n
                self.loop_start = float(getattr(self.engine.state, "loop_start", 0.0))
                self.loop_end = float(getattr(self.engine.state, "loop_end", 1.0))
        except Exception:
            pass
        self.update()

    def set_info(self, text: str):
        self.info = text
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect().adjusted(2, 2, -2, -2)
        p.fillRect(rect, QColor("#0d0d0d"))

        if self.samples is None or len(self.samples) < 2:
            p.setPen(QColor("#666"))
            p.setFont(QFont("Sans", 8))
            p.drawText(rect, Qt.AlignmentFlag.AlignCenter, self.info)
            return

        W = max(1, rect.width())
        n = len(self.samples)
        step = max(1, n // W)
        usable = self.samples[:n - (n % step)]
        if usable.size < step:
            return

        chunk = usable.reshape(-1, step)
        mins, maxs = chunk.min(axis=1), chunk.max(axis=1)
        mid = rect.center().y()
        amp = rect.height() / 2.2

        p.setPen(QPen(QColor("#1bd760"), 1))
        for i in range(min(len(mins), W)):
            x = rect.left() + i
            y1, y2 = int(mid - float(mins[i]) * amp), int(mid - float(maxs[i]) * amp)
            if y1 > y2: y1, y2 = y2, y1
            p.drawLine(x, y1, x, y2)

        p.setPen(QPen(QColor("#d64d2a"), 1))
        xs = rect.left() + int(self.loop_start * rect.width())
        xe = rect.left() + int(self.loop_end * rect.width())
        p.drawLine(xs, rect.top(), xs, rect.bottom())
        p.drawLine(xe, rect.top(), xe, rect.bottom())

        p.setPen(QPen(QColor("#ffaa00"), 1))
        xp = rect.left() + int(self.position * rect.width())
        p.drawLine(xp, rect.top(), xp, rect.bottom())


# Legacy compat
Knob = CompactKnob


class WaveformDisplay(WaveformStrip):
    """Backward-compat wrapper with load_wav_file."""
    
    def __init__(self, engine=None, parent=None):
        super().__init__(engine, parent)
        self.path: str = ""  # v0.0.20.75: Store path for persistence
    
    def load_wav_file(self, path: str, *, engine=None) -> bool:
        """Load audio file and display waveform.
        
        Args:
            path: Path to audio file
            engine: Optional ProSamplerEngine to load samples into.
                    If None, uses self.engine (from WaveformStrip).
        """
        try:
            from .audio_io import load_audio
            target_engine = engine if engine is not None else self.engine
            # Get target sample rate from engine
            target_sr = 48000
            if target_engine is not None:
                try:
                    target_sr = int(target_engine.target_sr)
                except Exception:
                    pass
            
            data, sr = load_audio(path, target_sr=target_sr)
            mono = data.mean(axis=1).astype(np.float32, copy=False)
            self.samples = mono
            self.info = f"{Path(path).name} | {len(mono)/sr:.2f}s | {sr}Hz"
            self.path = str(path)  # v0.0.20.75: Store path for persistence
            
            if target_engine is not None:
                ok = bool(target_engine.load_wav(path))
            else:
                ok = True
            return ok
        except Exception as e:
            self.info = f"Load error: {e}"
            return False
