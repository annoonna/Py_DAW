# -*- coding: utf-8 -*-
"""DrumMachineWidget (Pro-DAW-Style Device Panel).

Phase 1 focus:
- Visible, testable skeleton (UI + basic audio wiring)
- 16 pad grid (drag&drop samples onto pads)
- Per-slot local sampler params (Gain/Pan/Tune + basic filter)
- Pattern Generator (rule-based placeholder; later AI/Magenta)

Integration:
- When inserted into a track's device chain, this widget registers a pull-source
  in AudioEngine and tags it with _pydaw_track_id so track faders + VU meters work.
- Note preview from PianoRoll/Notation is routed via existing SamplerRegistry
  by exposing engine.trigger_note().
"""

from __future__ import annotations

import logging
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QPushButton,
    QLabel,
    QFrame,
    QFileDialog,
    QComboBox,
    QSpinBox,
    QSlider,
)

from pydaw.plugins.sampler.ui_widgets import CompactKnob, WaveformDisplay
from .drum_engine import DrumMachineEngine


log = logging.getLogger(__name__)

AUDIO_EXTS = "Audio Files (*.wav *.flac *.ogg *.mp3 *.aif *.aiff);;All Files (*)"


def _note_name(midi: int) -> str:
    names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
    m = int(midi)
    n = names[m % 12]
    o = (m // 12) - 1  # MIDI standard: C4=60 -> 4
    return f"{n}{o}"


class DrumPadButton(QPushButton):
    """Pad button with drag&drop sample loading."""

    sample_dropped = pyqtSignal(int, str)  # slot_idx, path

    def __init__(self, slot_idx: int, text: str, parent=None):
        super().__init__(text, parent)
        self.slot_idx = int(slot_idx)
        self.setAcceptDrops(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumSize(72, 44)
        self.setMaximumWidth(120)

    def dragEnterEvent(self, e):
        try:
            if e.mimeData().hasUrls():
                e.acceptProposedAction()
                return
        except Exception:
            pass
        e.ignore()

    def dropEvent(self, e):
        try:
            urls = e.mimeData().urls()
            if not urls:
                e.ignore()
                return
            p = Path(urls[0].toLocalFile())
            if not p.exists():
                e.ignore()
                return
            self.sample_dropped.emit(self.slot_idx, str(p))
            e.acceptProposedAction()
        except Exception:
            e.ignore()


@dataclass
class StyleMix:
    style: str
    weight: float


class DrumMachineWidget(QWidget):
    """Drum Machine device widget."""

    def __init__(self, project_service=None, audio_engine=None, automation_manager=None, parent=None):
        super().__init__(parent)
        self.project_service = project_service
        self.audio_engine = audio_engine
        self.automation_manager = automation_manager
        self._automation_setup_done: bool = False
        self._automation_mgr_connected: bool = False
        self._automation_pid_to_engine: dict[str, callable] = {}
        self._slot_param_ids: dict[int, dict[str, str]] = {}


        self.track_id: Optional[str] = None
        self._slot_media_ids: dict[int, str] = {}
        self._restoring_state: bool = False

        # IMPORTANT: do NOT hard-code 48k. If the user's audio settings run at
        # 44.1k, the drum engine would output silence because pull() checked
        # sr==target_sr.
        sr = 48000
        try:
            if self.audio_engine is not None:
                sr = int(self.audio_engine.get_effective_sample_rate())
        except Exception:
            sr = 48000

        self.engine = DrumMachineEngine(slots=16, base_note=36, target_sr=sr)

        # Pull-source wiring
        self._pull_name: Optional[str] = None
        # Wrap pull so we can attach metadata (bound methods can't reliably hold attrs)
        def _pull(frames: int, sr: int, _eng=self.engine):
            return _eng.pull(frames, sr)

        # Tag for track faders/VU (AudioEngine reads this dynamically)
        _pull._pydaw_track_id = lambda: (self.track_id or "")  # type: ignore[attr-defined]
        self._pull_fn = _pull

        self._selected_slot: int = 0

        self._build_ui()
        self._apply_styles()

    # ---------------- Device lifecycle
    def set_track_context(self, track_id: str) -> None:
        self.track_id = str(track_id)
        # Register this engine as the instrument preview backend for this track
        # (PianoRoll/Notation note preview routes through SamplerRegistry).
        try:
            if self.track_id:
                from pydaw.plugins.sampler.sampler_registry import get_sampler_registry
                reg = get_sampler_registry()
                if not reg.has_sampler(self.track_id):
                    reg.register(self.track_id, self.engine, self)
        except Exception:
            pass
        # Register pull source once we know the track binding
        try:
            if self.audio_engine is not None and self._pull_name is None:
                self._pull_name = f"drum:{self.track_id}:{id(self) & 0xFFFF:04x}"
                self.audio_engine.register_pull_source(self._pull_name, self._pull_fn)
                self.audio_engine.ensure_preview_output()
        except Exception:
            pass

        # Restore persisted drum state (samples + params)
        self._restore_instrument_state()

        self._setup_automation()


    def shutdown(self) -> None:
        try:
            if self.audio_engine is not None and self._pull_name is not None:
                self.audio_engine.unregister_pull_source(self._pull_name)
        except Exception:
            pass
        self._pull_name = None
        try:
            if self.track_id:
                from pydaw.plugins.sampler.sampler_registry import get_sampler_registry
                reg = get_sampler_registry()
                reg.unregister(self.track_id)
        except Exception:
            pass
        try:
            self.engine.stop_all()
        except Exception:
            pass


    # ---------------- Persist/Restore (Projekt-State)
    def _get_track_obj(self):
        try:
            ctx = getattr(self.project_service, 'ctx', None)
            if ctx is None or getattr(ctx, 'project', None) is None:
                return None
            for t in ctx.project.tracks:
                if getattr(t, 'id', '') == str(self.track_id):
                    return t
        except Exception:
            return None
        return None

    def _find_media_path(self, media_id: str) -> str:
        try:
            ctx = getattr(self.project_service, 'ctx', None)
            if ctx is None or getattr(ctx, 'project', None) is None:
                return ''
            for m in ctx.project.media:
                if getattr(m, 'id', '') == str(media_id):
                    return str(getattr(m, 'path', ''))
        except Exception:
            return ''
        return ''

    def _persist_instrument_state(self) -> None:
        if self._restoring_state:
            return
        trk = self._get_track_obj()
        if trk is None:
            if self.track_id:
                log.warning("DrumMachine._persist: no track object for %s", self.track_id)
            return
        try:
            st = self.engine.export_state()
            for slot in st.get('slots', []):
                idx = slot.get('index')
                if idx in self._slot_media_ids:
                    slot['sample_media_id'] = self._slot_media_ids.get(idx, '')
            if getattr(trk, 'instrument_state', None) is None:
                trk.instrument_state = {}
            trk.instrument_state['drum_machine'] = st
            # Invalidate restore guard so next restore sees the new state
            self._last_restored_hash = None
            # Log what we saved
            saved_samples = [(s.get('index'), s.get('sample_path', '')) for s in st.get('slots', []) if s.get('sample_path')]
            log.info("DrumMachine._persist: track=%s, saved %d slots with samples: %s",
                     self.track_id, len(saved_samples), saved_samples)
        except Exception as exc:
            log.error("DrumMachine._persist failed: %s", exc)

    def _restore_instrument_state(self) -> None:
        trk = self._get_track_obj()
        if trk is None:
            if self.track_id:
                log.warning("DrumMachine._restore: no track object for %s", self.track_id)
            return
        ist = getattr(trk, 'instrument_state', {}) or {}
        st = ist.get('drum_machine')
        if not isinstance(st, dict):
            log.debug("DrumMachine._restore: no drum_machine state found for track %s (ist keys: %s)",
                     self.track_id, list(ist.keys()) if ist else '(empty)')
            return

        # Guard: skip if we already restored this exact state
        import json
        try:
            state_hash = hash(json.dumps(st, sort_keys=True, default=str))
        except Exception:
            state_hash = id(st)
        if getattr(self, '_last_restored_hash', None) == state_hash:
            return
        self._last_restored_hash = state_hash

        log.info("DrumMachine._restore: restoring state for track %s, %d slots",
                 self.track_id, len(st.get('slots', [])))
        self._restoring_state = True
        try:
            st2 = {k: v for k, v in st.items()}
            slots = []
            for slot in st.get('slots', []):
                sd = dict(slot)
                
                # v0.0.20.76: Try multiple path sources (like Sampler fix)
                sample_path = ""
                
                # 1. Try media_id first (project-relative, most reliable)
                mid = str(sd.get('sample_media_id') or '')
                if mid:
                    p = self._find_media_path(mid)
                    if p and Path(p).exists():
                        sample_path = p
                        idx = sd.get('index')
                        if isinstance(idx, int):
                            self._slot_media_ids[idx] = mid
                
                # 2. Try sample_path from state
                if not sample_path:
                    sp = str(sd.get('sample_path') or '')
                    if sp and Path(sp).exists():
                        sample_path = sp
                    elif sp:
                        log.warning("DrumMachine._restore: slot %s sample_path does not exist: %s",
                                    sd.get('index'), sp)
                
                # 3. Try sample_name from nested sampler engine state (fallback)
                if not sample_path:
                    sampler_state = sd.get('sampler')
                    if isinstance(sampler_state, dict):
                        sn = str(sampler_state.get('sample_name') or '')
                        if sn and Path(sn).exists():
                            sample_path = sn
                        elif sn:
                            log.warning("DrumMachine._restore: slot %s sampler.sample_name does not exist: %s",
                                        sd.get('index'), sn)
                
                # Update sd with resolved path
                if sample_path:
                    sd['sample_path'] = sample_path
                    log.info("DrumMachine._restore: slot %s -> %s", sd.get('index'), sample_path)
                else:
                    has_any = bool(sd.get('sample_path') or (sd.get('sampler') or {}).get('sample_name'))
                    if has_any:
                        log.warning("DrumMachine._restore: slot %s has paths but none exist!", sd.get('index'))
                
                slots.append(sd)
            st2['slots'] = slots
            try:
                self.engine.import_state(st2)
            except Exception as exc:
                log.error("DrumMachine._restore: engine.import_state failed: %s", exc)
            self._refresh_pad_labels()
            self._refresh_slot_editor()
        finally:
            self._restoring_state = False

    def _import_and_load_sample(self, idx: int, path: str) -> bool:
        """Importiert Sample nach media/ (falls möglich) und lädt es in Slot."""
        slot = self.engine.slots[idx]
        load_path = path
        media_id = ''
        if (self.project_service is not None) and self.track_id:
            try:
                load_path, media_id = self.project_service.import_audio_to_project(
                    str(self.track_id), Path(path), label=Path(path).stem
                )
                log.info("DrumMachine._import: slot %d imported to media: %s (media_id=%s)", idx, load_path, media_id)
            except Exception as exc:
                log.warning("DrumMachine._import: slot %d import_audio_to_project failed: %s, using original: %s", idx, exc, path)
                load_path = path
                media_id = ''
        else:
            log.warning("DrumMachine._import: no project_service or track_id, loading directly: %s", path)
        ok = slot.load_sample(str(load_path))
        if ok and media_id:
            self._slot_media_ids[idx] = str(media_id)
        log.info("DrumMachine._import: slot %d load_sample=%s, path=%s", idx, ok, load_path)
        return ok
    # ---------------- UI
    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)

        top = QHBoxLayout()
        top.setSpacing(10)

        # Pads
        pad_frame = QFrame()
        pad_frame.setObjectName("padFrame")
        pad_layout = QGridLayout(pad_frame)
        pad_layout.setContentsMargins(4, 4, 4, 4)
        pad_layout.setHorizontalSpacing(4)
        pad_layout.setVerticalSpacing(4)

        self.pads: list[DrumPadButton] = []
        for i, slot in enumerate(self.engine.slots):
            note = self.engine.base_note + i
            label = f"{i+1}\n{slot.state.name}\n{_note_name(note)}"
            b = DrumPadButton(i, label)
            b.clicked.connect(lambda _=False, idx=i: self._select_slot(idx))
            b.sample_dropped.connect(self._on_pad_sample_dropped)
            b.pressed.connect(lambda idx=i: self._preview_slot(idx))
            self.pads.append(b)
            r, c = divmod(i, 4)
            pad_layout.addWidget(b, r, c)

        top.addWidget(pad_frame, 0)

        # Editor + AI
        right = QVBoxLayout()
        right.setSpacing(6)

        # --- AI / Pattern generator (skeleton)
        ai_box = QFrame()
        ai_box.setObjectName("aiBox")
        ai_l = QHBoxLayout(ai_box)
        ai_l.setContentsMargins(6, 6, 6, 6)
        ai_l.setSpacing(8)

        self.cmb_style = QComboBox()
        self.cmb_style.addItems([
            "Classic", "80s Pop", "Punk", "Electro", "Electro-Punk",
            "HipHop/R&B", "Gabba", "Speedcore", "Country", "Gottesdienst",
        ])
        self.sld_intensity = QSlider(Qt.Orientation.Horizontal)
        self.sld_intensity.setRange(0, 100)
        self.sld_intensity.setValue(55)
        self.spn_bars = QSpinBox()
        self.spn_bars.setRange(1, 16)
        self.spn_bars.setValue(1)
        self.btn_random = QPushButton("Random")
        self.btn_generate = QPushButton("Generate → Clip")

        self.btn_random.clicked.connect(self._randomize_style)
        self.btn_generate.clicked.connect(self._generate_to_clip)

        ai_l.addWidget(QLabel("Style"))
        ai_l.addWidget(self.cmb_style, 1)
        ai_l.addWidget(QLabel("Intensity"))
        ai_l.addWidget(self.sld_intensity, 1)
        ai_l.addWidget(QLabel("Bars"))
        ai_l.addWidget(self.spn_bars)
        ai_l.addWidget(self.btn_random)
        ai_l.addWidget(self.btn_generate)

        right.addWidget(ai_box)

        # --- Slot editor
        edit_box = QFrame()
        edit_box.setObjectName("editBox")
        edit_l = QVBoxLayout(edit_box)
        edit_l.setContentsMargins(6, 6, 6, 6)
        edit_l.setSpacing(6)

        self.lbl_slot = QLabel("Slot 1")
        self.lbl_file = QLabel("No sample")
        self.lbl_file.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        file_row = QHBoxLayout()
        self.btn_load = QPushButton("Load")
        self.btn_clear = QPushButton("Clear")
        self.btn_load.clicked.connect(self._load_sample_dialog)
        self.btn_clear.clicked.connect(self._clear_sample)
        file_row.addWidget(self.lbl_slot)
        file_row.addSpacing(8)
        file_row.addWidget(self.lbl_file, 1)
        file_row.addWidget(self.btn_load)
        file_row.addWidget(self.btn_clear)

        edit_l.addLayout(file_row)

        self.wave = WaveformDisplay(self.engine.slots[0].engine)
        edit_l.addWidget(self.wave)

        knobs = QHBoxLayout()
        knobs.setSpacing(6)
        self.kn_gain = CompactKnob("Gain", 80)
        self.kn_pan = CompactKnob("Pan", 50)
        self.kn_tune = CompactKnob("Tune", 50)
        self.kn_cut = CompactKnob("Cut", 100)
        self.kn_res = CompactKnob("Res", 20)

        self.cmb_filter = QComboBox()
        self.cmb_filter.addItems(["off", "lowpass", "highpass", "bandpass"])

        knobs.addWidget(self.kn_gain)
        knobs.addWidget(self.kn_pan)
        knobs.addWidget(self.kn_tune)
        knobs.addWidget(self.cmb_filter)
        knobs.addWidget(self.kn_cut)
        knobs.addWidget(self.kn_res)
        knobs.addStretch(1)

        edit_l.addLayout(knobs)

        # Connect knobs
        self.kn_gain.valueChanged.connect(lambda v: self._slot_set_gain(v))
        self.kn_pan.valueChanged.connect(lambda v: self._slot_set_pan(v))
        self.kn_tune.valueChanged.connect(lambda v: self._slot_set_tune(v))
        self.kn_cut.valueChanged.connect(lambda v: self._slot_set_cut(v))
        self.kn_res.valueChanged.connect(lambda v: self._slot_set_res(v))
        self.cmb_filter.currentTextChanged.connect(lambda t: self._slot_set_filter(t))

        right.addWidget(edit_box, 1)

        top.addLayout(right, 1)
        root.addLayout(top)

        self._select_slot(0)

    def _apply_styles(self) -> None:
        self.setStyleSheet(
            """
            #padFrame {background:#141414;border:1px solid #232323;border-radius:6px;}
            #aiBox {background:#101010;border:1px solid #232323;border-radius:6px;}
            #editBox {background:#101010;border:1px solid #232323;border-radius:6px;}
            QPushButton {background:#1a1a1a;border:1px solid #2a2a2a;border-radius:6px;padding:6px;color:#ddd;}
            QPushButton:hover {border:1px solid #3a3a3a;}
            QPushButton:pressed {background:#151515;}
            QLabel {color:#cfcfcf;}
            QComboBox {background:#151515;border:1px solid #2a2a2a;border-radius:4px;padding:2px;color:#ddd;}
            QSpinBox {background:#151515;border:1px solid #2a2a2a;border-radius:4px;padding:2px;color:#ddd;}
            """
        )

    # ---------------- Pad actions
    def _select_slot(self, idx: int) -> None:
        idx = int(max(0, min(15, idx)))
        self._selected_slot = idx
        for i, b in enumerate(self.pads):
            if i == idx:
                b.setStyleSheet("border:2px solid #e060e0;")
            else:
                b.setStyleSheet("")
        self._refresh_slot_editor()

    def _preview_slot(self, idx: int) -> None:
        try:
            pitch = self.engine.base_note + int(idx)
            self.engine.trigger_note(pitch, velocity=110, duration_ms=160)
            if self.audio_engine is not None:
                self.audio_engine.ensure_preview_output()
        except Exception:
            pass

    def _on_pad_sample_dropped(self, idx: int, path: str) -> None:
        idx = int(idx)
        log.info("DrumMachine: sample dropped on pad %d: %s", idx, path)
        ok = False
        try:
            ok = self._import_and_load_sample(idx, path)
        except Exception as exc:
            log.error("DrumMachine: _import_and_load_sample failed for pad %d: %s", idx, exc)
            ok = False
        if ok:
            self._update_pad_text(idx)
            if idx == self._selected_slot:
                self._refresh_slot_editor()
            self._persist_instrument_state()
        else:
            self._status(f"Sample konnte nicht geladen werden: {Path(path).name}")

    def _update_pad_text(self, idx: int) -> None:
        slot = self.engine.slots[int(idx)]
        note = self.engine.base_note + int(idx)
        base = f"{idx+1}\n{slot.state.name}\n{_note_name(note)}"
        if slot.state.sample_path:
            base += f"\n{Path(slot.state.sample_path).stem[:10]}"
        self.pads[int(idx)].setText(base)

    # ---------------- Slot editor
    def _current_slot(self):
        return self.engine.slots[int(self._selected_slot)]

    def _refresh_slot_editor(self) -> None:
        slot = self._current_slot()
        self.lbl_slot.setText(f"Slot {slot.state.index+1} — {slot.state.name}  ({_note_name(self.engine.base_note + slot.state.index)})")
        self.lbl_file.setText(Path(slot.state.sample_path).name if slot.state.sample_path else "No sample")

        # Rebind waveform display to selected slot engine
        try:
            self.wave.engine = slot.engine
            # v0.0.20.90: keep automation target in sync with selected slot
            try:
                self._bind_editor_knobs_to_selected_slot()
            except Exception:
                pass
        except Exception:
            pass
        try:
            if slot.engine.samples is not None:
                self.wave.samples = slot.engine.samples
        except Exception:
            pass

        # Update knobs from engine state
        try:
            st = slot.engine.state
            self.kn_gain.setValue(int(float(getattr(st, "gain", 0.8)) * 100))
            pan = float(getattr(st, "pan", 0.0))
            self.kn_pan.setValue(int((pan + 1.0) * 50))

            # tune knob is semitone offset mapped around 50
            # we store tune in root_note offset concept: compute current ratio -> semitones
            root = int(getattr(slot.engine, "root_note", self.engine.base_note + slot.state.index))
            # ratio is derived at trigger time; here we keep as knob state only.
            self.kn_tune.setValue(int(getattr(self, "_tune_knob_cache", {}).get(slot.state.index, 50)))

            ftype = str(getattr(st, "filter_type", "off"))
            if ftype not in ("off", "lowpass", "highpass", "bandpass"):
                ftype = "off"
            self.cmb_filter.setCurrentText(ftype)

            cutoff = float(getattr(st, "cutoff_hz", 8000.0))
            # map 20..20000 -> 0..100 (log-ish)
            cut01 = (max(20.0, min(20000.0, cutoff)) - 20.0) / (20000.0 - 20.0)
            self.kn_cut.setValue(int(cut01 * 100))

            q = float(getattr(st, "q", 0.707))
            q01 = (max(0.25, min(12.0, q)) - 0.25) / (12.0 - 0.25)
            self.kn_res.setValue(int(q01 * 100))
        except Exception:
            pass

    def _load_sample_dialog(self) -> None:
        slot = self._current_slot()
        path, _ = QFileDialog.getOpenFileName(self, "Load sample", "", AUDIO_EXTS)
        if not path:
            return
        ok = self._import_and_load_sample(slot.state.index, path)
        if ok:
            self._update_pad_text(slot.state.index)
            # Refresh waveform from engine
            try:
                self.wave.samples = slot.engine.samples
            except Exception:
                pass
            self.lbl_file.setText(Path(path).name)
            self._persist_instrument_state()
        else:
            self._status("Sample load failed")

    def _clear_sample(self) -> None:
        slot = self._current_slot()
        slot.clear_sample()
        self._update_pad_text(slot.state.index)
        self._refresh_slot_editor()
        self._persist_instrument_state()



    # ---------------- Automation (v0.0.20.90)
    def _setup_automation(self) -> None:
        """Register per-slot drum parameters + enable right-click automation on editor knobs."""
        try:
            if self._automation_setup_done:
                return
            mgr = getattr(self, 'automation_manager', None)
            tid = str(getattr(self, 'track_id', '') or '')
            if mgr is None or not tid:
                return

            self._automation_setup_done = True
            self._automation_pid_to_engine = {}
            self._slot_param_ids = {}

            def _pid(slot_idx: int, key: str) -> str:
                return f"trk:{tid}:drum:{int(slot_idx)}:{key}"

            # Build ids + engine mapping for all slots
            for i, slot in enumerate(getattr(self.engine, 'slots', []) or []):
                i = int(i)
                self._slot_param_ids[i] = {
                    'gain': _pid(i, 'gain'),
                    'pan': _pid(i, 'pan'),
                    'tune': _pid(i, 'tune'),
                    'cut': _pid(i, 'cut'),
                    'res': _pid(i, 'res'),
                }

                # apply functions (value is in UI-space 0..100)
                self._automation_pid_to_engine[self._slot_param_ids[i]['gain']] = (lambda v, ii=i: self._apply_slot_gain(ii, v))
                self._automation_pid_to_engine[self._slot_param_ids[i]['pan']] = (lambda v, ii=i: self._apply_slot_pan(ii, v))
                self._automation_pid_to_engine[self._slot_param_ids[i]['tune']] = (lambda v, ii=i: self._apply_slot_tune(ii, v))
                self._automation_pid_to_engine[self._slot_param_ids[i]['cut']] = (lambda v, ii=i: self._apply_slot_cut(ii, v))
                self._automation_pid_to_engine[self._slot_param_ids[i]['res']] = (lambda v, ii=i: self._apply_slot_res(ii, v))

                # Register parameters so they appear in the Arranger automation combobox
                try:
                    # defaults derived from current engine state
                    # gain/pan are accessible via ProSamplerEngine.state
                    st = getattr(slot.engine, 'state', None)
                    gain = float(getattr(st, 'master_gain', 1.0)) if st is not None else 1.0
                    pan = float(getattr(st, 'master_pan', 0.0)) if st is not None else 0.0
                    default_gain = max(0.0, min(100.0, gain * 100.0))
                    default_pan = max(0.0, min(100.0, (pan + 1.0) * 50.0))
                except Exception:
                    default_gain, default_pan = 80.0, 50.0

                # Tune defaults: use cached knob value if present
                cache = getattr(self, '_tune_knob_cache', {}) or {}
                default_tune = float(cache.get(i, 50))

                # Cut/Res defaults from engine filter state
                try:
                    st = getattr(slot.engine, 'state', None)
                    cutoff = float(getattr(st, 'cutoff_hz', 8000.0)) if st is not None else 8000.0
                    cut01 = (max(20.0, min(20000.0, cutoff)) - 20.0) / (20000.0 - 20.0)
                    default_cut = cut01 * 100.0
                    q = float(getattr(st, 'q', 0.707)) if st is not None else 0.707
                    q01 = (max(0.25, min(12.0, q)) - 0.25) / (12.0 - 0.25)
                    default_res = q01 * 100.0
                except Exception:
                    default_cut, default_res = 100.0, 20.0

                # Register with readable names
                mgr.register_parameter(self._slot_param_ids[i]['gain'], f"Drum S{i+1} Gain", 0.0, 100.0, float(default_gain), track_id=tid)
                mgr.register_parameter(self._slot_param_ids[i]['pan'], f"Drum S{i+1} Pan", 0.0, 100.0, float(default_pan), track_id=tid)
                mgr.register_parameter(self._slot_param_ids[i]['tune'], f"Drum S{i+1} Tune", 0.0, 100.0, float(default_tune), track_id=tid)
                mgr.register_parameter(self._slot_param_ids[i]['cut'], f"Drum S{i+1} Cutoff", 0.0, 100.0, float(default_cut), track_id=tid)
                mgr.register_parameter(self._slot_param_ids[i]['res'], f"Drum S{i+1} Resonance", 0.0, 100.0, float(default_res), track_id=tid)

            # Disconnect legacy engine wiring from editor knobs (we apply via AutomationManager)
            for k in [getattr(self, 'kn_gain', None), getattr(self, 'kn_pan', None), getattr(self, 'kn_tune', None), getattr(self, 'kn_cut', None), getattr(self, 'kn_res', None)]:
                if k is None:
                    continue
                try:
                    k.valueChanged.disconnect()
                except Exception:
                    pass
                try:
                    k.valueChanged.connect(lambda _v=0: self._persist_instrument_state())
                except Exception:
                    pass

            # Bind editor knobs to the currently selected slot ids (right-click targets)
            self._bind_editor_knobs_to_selected_slot()

            if not self._automation_mgr_connected:
                try:
                    mgr.parameter_changed.connect(self._on_automation_parameter_changed)
                    self._automation_mgr_connected = True
                except Exception:
                    self._automation_mgr_connected = False

        except Exception:
            pass

    def _bind_editor_knobs_to_selected_slot(self) -> None:
        """Rebind editor knobs to the selected slot so right-click automation maps correctly."""
        try:
            mgr = getattr(self, 'automation_manager', None)
            tid = str(getattr(self, 'track_id', '') or '')
            if mgr is None or not tid:
                return
            slot_idx = int(getattr(self, '_selected_slot', 0) or 0)
            ids = (self._slot_param_ids or {}).get(slot_idx)
            if not ids:
                return

            # Defaults from current UI (they are already set in _refresh_slot_editor)
            try:
                self.kn_gain.bind_automation(mgr, ids['gain'], name=f"Drum S{slot_idx+1} Gain", track_id=tid, default=float(self.kn_gain.value()))
                self.kn_pan.bind_automation(mgr, ids['pan'], name=f"Drum S{slot_idx+1} Pan", track_id=tid, default=float(self.kn_pan.value()))
                self.kn_tune.bind_automation(mgr, ids['tune'], name=f"Drum S{slot_idx+1} Tune", track_id=tid, default=float(self.kn_tune.value()))
                self.kn_cut.bind_automation(mgr, ids['cut'], name=f"Drum S{slot_idx+1} Cutoff", track_id=tid, default=float(self.kn_cut.value()))
                self.kn_res.bind_automation(mgr, ids['res'], name=f"Drum S{slot_idx+1} Resonance", track_id=tid, default=float(self.kn_res.value()))
            except Exception:
                pass
        except Exception:
            pass

    # Engine apply helpers (no persistence; used by automation playback)
    def _apply_slot_gain(self, slot_idx: int, v: float) -> None:
        try:
            slot = self.engine.slots[int(slot_idx)]
            slot.engine.set_master(gain=float(v) / 100.0)
        except Exception:
            pass

    def _apply_slot_pan(self, slot_idx: int, v: float) -> None:
        try:
            slot = self.engine.slots[int(slot_idx)]
            pan = (float(v) / 50.0) - 1.0
            slot.engine.set_master(pan=pan)
        except Exception:
            pass

    def _apply_slot_tune(self, slot_idx: int, v: float) -> None:
        try:
            i = int(slot_idx)
            slot = self.engine.slots[i]
            semis = int(round(((int(v) - 50) / 50.0) * 12.0))
            base_pitch = int(self.engine.base_note) + i
            slot.engine.set_root(int(base_pitch - semis))
            cache = getattr(self, '_tune_knob_cache', None)
            if cache is None:
                cache = {}
                setattr(self, '_tune_knob_cache', cache)
            cache[i] = int(round(v))
        except Exception:
            pass

    def _apply_slot_cut(self, slot_idx: int, v: float) -> None:
        try:
            slot = self.engine.slots[int(slot_idx)]
            cut = 20.0 + (float(v) / 100.0) * (20000.0 - 20.0)
            slot.engine.set_filter(cutoff_hz=cut)
        except Exception:
            pass

    def _apply_slot_res(self, slot_idx: int, v: float) -> None:
        try:
            slot = self.engine.slots[int(slot_idx)]
            q = 0.25 + (float(v) / 100.0) * (12.0 - 0.25)
            slot.engine.set_filter(q=q)
        except Exception:
            pass

    def _on_automation_parameter_changed(self, parameter_id: str, value: float) -> None:
        try:
            fn = (self._automation_pid_to_engine or {}).get(str(parameter_id))
            if fn is None:
                return
            fn(float(value))
        except Exception:
            pass
    # ---------------- Param setters (selected slot)
    def _slot_set_gain(self, v: int) -> None:
        slot = self._current_slot()
        try:
            slot.engine.set_master(gain=float(v) / 100.0)
        except Exception:
            pass
        self._persist_instrument_state()

    def _slot_set_pan(self, v: int) -> None:
        slot = self._current_slot()
        try:
            pan = (float(v) / 50.0) - 1.0
            slot.engine.set_master(pan=pan)
        except Exception:
            pass
        self._persist_instrument_state()

    def _slot_set_tune(self, v: int) -> None:
        # Store as semitone offset in [-12..+12]
        slot = self._current_slot()
        semis = int(round(((int(v) - 50) / 50.0) * 12.0))
        base_pitch = self.engine.base_note + slot.state.index
        # For stable mapping, keep root note shifted so pitch-base yields ratio
        try:
            slot.engine.set_root(int(base_pitch - semis))
        except Exception:
            pass
        # Cache for refresh
        cache = getattr(self, "_tune_knob_cache", None)
        if cache is None:
            cache = {}
            setattr(self, "_tune_knob_cache", cache)
        cache[slot.state.index] = int(v)
        self._persist_instrument_state()

    def _slot_set_filter(self, ftype: str) -> None:
        slot = self._current_slot()
        try:
            slot.engine.set_filter(ftype=str(ftype))
        except Exception:
            pass
        self._persist_instrument_state()

    def _slot_set_cut(self, v: int) -> None:
        slot = self._current_slot()
        try:
            cut = 20.0 + (float(v) / 100.0) * (20000.0 - 20.0)
            slot.engine.set_filter(cutoff_hz=cut)
        except Exception:
            pass
        self._persist_instrument_state()

    def _slot_set_res(self, v: int) -> None:
        slot = self._current_slot()
        try:
            q = 0.25 + (float(v) / 100.0) * (12.0 - 0.25)
            slot.engine.set_filter(q=q)
        except Exception:
            pass
        self._persist_instrument_state()

    # ---------------- AI Pattern (placeholder)        self._persist_instrument_state()

    def _randomize_style(self) -> None:
        try:
            self.cmb_style.setCurrentIndex(random.randint(0, self.cmb_style.count() - 1))
            self.sld_intensity.setValue(random.randint(25, 95))
            self.spn_bars.setValue(random.choice([1, 1, 2, 4]))
        except Exception:
            pass

    def _generate_to_clip(self) -> None:
        if self.project_service is None:
            self._status("ProjectService fehlt – Pattern nicht möglich.")
            return
        try:
            clip_id = str(self.project_service.active_clip_id() or "")
        except Exception:
            clip_id = ""
        if not clip_id:
            self._status("Kein aktiver MIDI-Clip (Tip: Clip auswählen oder im Launcher doppelklicken).")
            return

        clip = None
        try:
            clip = self.project_service.get_clip(clip_id)
        except Exception:
            clip = None
        if clip is None or str(getattr(clip, "kind", "")) != "midi":
            self._status("Aktiver Clip ist kein MIDI-Clip.")
            return

        bars = int(self.spn_bars.value())
        style = str(self.cmb_style.currentText())
        intensity = float(self.sld_intensity.value()) / 100.0

        notes = self._make_pattern(style=style, intensity=intensity, bars=bars)
        try:
            before = self.project_service.snapshot_midi_notes(clip_id)
        except Exception:
            before = []

        try:
            self.project_service.set_midi_notes(clip_id, notes)
            self.project_service.commit_midi_notes_edit(clip_id, before, f"Drum Pattern: {style}")
            self._status(f"Pattern geschrieben: {style} ({bars} bar)")
        except Exception as e:
            self._status(f"Pattern schreiben fehlgeschlagen: {e}")

    def _make_pattern(self, style: str, intensity: float, bars: int = 1):
        """Return list[MidiNote] for a simple style-driven 16th grid."""
        from pydaw.model.midi import MidiNote

        # Slot mapping (default): 0 Kick, 1 Snare, 2 CHat, 3 OHat, 4 Clap, 5 Tom, 6 Perc
        kick = self.engine.base_note + 0
        snare = self.engine.base_note + 1
        chat = self.engine.base_note + 2
        ohat = self.engine.base_note + 3
        clap = self.engine.base_note + 4
        tom = self.engine.base_note + 5
        perc = self.engine.base_note + 6

        # probabilities & densities
        style_l = style.lower()
        four_floor = 0.6
        offbeat_hats = 0.6
        double_kick = 0.1
        snare_backbeat = 0.9
        hat_density = 0.7
        ghost = 0.2

        if "hip" in style_l:
            four_floor = 0.25
            offbeat_hats = 0.35
            snare_backbeat = 0.75
            hat_density = 0.55
            ghost = 0.35
        if "punk" in style_l:
            four_floor = 0.35
            offbeat_hats = 0.2
            snare_backbeat = 0.95
            hat_density = 0.8
            ghost = 0.15
        if "electro" in style_l:
            four_floor = 0.85
            offbeat_hats = 0.75
            hat_density = 0.9
            ghost = 0.2
        if "gabba" in style_l or "speedcore" in style_l:
            four_floor = 0.95
            offbeat_hats = 0.9
            hat_density = 1.0
            double_kick = 0.65
            snare_backbeat = 0.55
            ghost = 0.45
        if "country" in style_l:
            four_floor = 0.45
            offbeat_hats = 0.35
            snare_backbeat = 0.85
            hat_density = 0.55
            ghost = 0.2
        if "gottesdienst" in style_l:
            four_floor = 0.4
            offbeat_hats = 0.3
            snare_backbeat = 0.9
            hat_density = 0.45
            ghost = 0.1

        # intensity scales
        four_floor = min(1.0, max(0.0, four_floor * (0.5 + intensity)))
        hat_density = min(1.0, max(0.0, hat_density * (0.5 + intensity)))
        double_kick = min(1.0, max(0.0, double_kick * (0.25 + intensity)))
        ghost = min(1.0, max(0.0, ghost * (0.35 + intensity)))

        steps_per_bar = 16
        beat_per_step = 4.0 / steps_per_bar
        notes = []

        rng = random.Random()
        rng.seed(int(random.random() * 1e9))

        for bar in range(int(bars)):
            bar_off = float(bar) * 4.0
            for s in range(steps_per_bar):
                t = bar_off + s * beat_per_step
                # Kick
                if s in (0, 4, 8, 12):
                    if rng.random() < four_floor:
                        notes.append(MidiNote(pitch=kick, start_beats=t, length_beats=0.25, velocity=int(105 + 20 * intensity)).clamp())
                else:
                    if rng.random() < (0.10 + 0.25 * intensity):
                        if rng.random() < 0.35:
                            notes.append(MidiNote(pitch=kick, start_beats=t, length_beats=0.25, velocity=int(75 + 25 * intensity)).clamp())

                # Double kick for extreme styles
                if rng.random() < double_kick and s % 2 == 0:
                    if rng.random() < 0.28:
                        notes.append(MidiNote(pitch=kick, start_beats=t + beat_per_step * 0.5, length_beats=0.25, velocity=int(85 + 30 * intensity)).clamp())

                # Snare / Clap
                if s in (4, 12):
                    if rng.random() < snare_backbeat:
                        notes.append(MidiNote(pitch=snare, start_beats=t, length_beats=0.25, velocity=int(95 + 25 * intensity)).clamp())
                    if rng.random() < (0.25 + 0.30 * intensity):
                        notes.append(MidiNote(pitch=clap, start_beats=t, length_beats=0.25, velocity=int(70 + 40 * intensity)).clamp())
                else:
                    if rng.random() < ghost * 0.10:
                        notes.append(MidiNote(pitch=snare, start_beats=t, length_beats=0.25, velocity=int(35 + 30 * intensity)).clamp())

                # Hats
                if rng.random() < hat_density:
                    if offbeat_hats > 0.5 and s % 2 == 1:
                        notes.append(MidiNote(pitch=ohat, start_beats=t, length_beats=0.25, velocity=int(50 + 35 * intensity)).clamp())
                    else:
                        notes.append(MidiNote(pitch=chat, start_beats=t, length_beats=0.25, velocity=int(45 + 30 * intensity)).clamp())

                # Perc / Tom fills
                if rng.random() < (0.05 + 0.12 * intensity) and s in (14, 15):
                    notes.append(MidiNote(pitch=tom, start_beats=t, length_beats=0.25, velocity=int(60 + 35 * intensity)).clamp())
                if rng.random() < (0.04 + 0.10 * intensity) and s in (6, 10):
                    notes.append(MidiNote(pitch=perc, start_beats=t, length_beats=0.25, velocity=int(55 + 30 * intensity)).clamp())

        return notes

    # ---------------- helpers
    def _status(self, msg: str) -> None:
        # Best-effort: route to ProjectService.status (shows in statusbar)
        try:
            if self.project_service is not None and hasattr(self.project_service, "status"):
                self.project_service.status.emit(str(msg))
                return
        except Exception:
            pass

