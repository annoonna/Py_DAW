# -*- coding: utf-8 -*-
"""Device-Rack widgets for Note-FX + Audio-FX (Bitwig/Ableton style).

Goal:
- FX are visible as modules in the bottom Device panel.
- Each module owns a tiny MVP parameter UI (no right-browser editor needed).

This file intentionally stays lightweight — no heavy dependencies.
"""
from __future__ import annotations

from typing import Any, Optional

from PyQt6.QtCore import Qt, QTimer, QSignalBlocker
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QDial, QSlider, QDoubleSpinBox, QSpinBox, QComboBox,
    QPushButton, QLineEdit, QGroupBox, QFormLayout, QFileDialog, QMessageBox
)

try:
    # Optional widgets used by some devices (keep imports resilient).
    from PyQt6.QtWidgets import QScrollArea
except Exception:  # pragma: no cover
    QScrollArea = None


def _find_track(project: Any, track_id: str):
    try:
        for t in getattr(project, "tracks", []) or []:
            if getattr(t, "id", "") == track_id:
                return t
    except Exception:
        pass
    return None


class AudioChainContainerWidget(QWidget):
    """CHAIN container device: Wet Gain + Mix (per track)."""

    def __init__(self, services: Any, track_id: str, parent=None):
        super().__init__(parent)
        self._services = services
        self._track_id = str(track_id or "")
        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(120)
        self._debounce.timeout.connect(self._flush_to_project)
        self._build()

    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(4)

        row = QHBoxLayout()
        row.setSpacing(12)

        # Wet Gain (0..200%)
        self.dial_wet = QDial()
        self.dial_wet.setNotchesVisible(True)
        self.dial_wet.setRange(0, 200)
        self.dial_wet.setValue(100)

        col_w = QVBoxLayout()
        col_w.addWidget(QLabel("Wet Gain"), 0, Qt.AlignmentFlag.AlignHCenter)
        col_w.addWidget(self.dial_wet, 1)
        self.lbl_wet = QLabel("100%")
        self.lbl_wet.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        col_w.addWidget(self.lbl_wet)

        # Mix (0..100%)
        self.dial_mix = QDial()
        self.dial_mix.setNotchesVisible(True)
        self.dial_mix.setRange(0, 100)
        self.dial_mix.setValue(100)

        col_m = QVBoxLayout()
        col_m.addWidget(QLabel("Mix"), 0, Qt.AlignmentFlag.AlignHCenter)
        col_m.addWidget(self.dial_mix, 1)
        self.lbl_mix = QLabel("100%")
        self.lbl_mix.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        col_m.addWidget(self.lbl_mix)

        row.addLayout(col_w, 1)
        row.addLayout(col_m, 1)

        root.addLayout(row)

        self.dial_wet.valueChanged.connect(self._on_change)
        self.dial_mix.valueChanged.connect(self._on_change)

        self.refresh_from_project()

    def refresh_from_project(self) -> None:
        project = getattr(self._services, "project", None)
        proj = getattr(project, "ctx", None)
        p = getattr(proj, "project", None) if proj is not None else getattr(project, "project", None)
        t = _find_track(p, self._track_id) if p is not None else None
        if t is None:
            return
        chain = getattr(t, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        wet = float(chain.get("wet_gain", 1.0) or 1.0)
        mix = float(chain.get("mix", 1.0) or 1.0)
        self.dial_wet.blockSignals(True)
        self.dial_mix.blockSignals(True)
        try:
            self.dial_wet.setValue(int(max(0, min(200, round(wet * 100.0)))))
            self.dial_mix.setValue(int(max(0, min(100, round(mix * 100.0)))))
        finally:
            self.dial_wet.blockSignals(False)
            self.dial_mix.blockSignals(False)
        self.lbl_wet.setText(f"{self.dial_wet.value()}%")
        self.lbl_mix.setText(f"{self.dial_mix.value()}%")

    def _on_change(self) -> None:
        self.lbl_wet.setText(f"{self.dial_wet.value()}%")
        self.lbl_mix.setText(f"{self.dial_mix.value()}%")
        # realtime params
        ae = getattr(self._services, "audio_engine", None)
        rt = getattr(ae, "rt_params", None) if ae is not None else None
        tid = self._track_id
        wet = float(self.dial_wet.value()) / 100.0
        mix = float(self.dial_mix.value()) / 100.0
        try:
            if rt is not None:
                rt.set_param(f"afxchain:{tid}:wet_gain", wet)
                rt.set_param(f"afxchain:{tid}:mix", mix)
        except Exception:
            pass
        # persist (debounced)
        self._debounce.start()

    def _flush_to_project(self) -> None:
        project_service = getattr(self._services, "project", None)
        if project_service is None:
            return
        ctx = getattr(project_service, "ctx", None)
        p = getattr(ctx, "project", None) if ctx is not None else getattr(project_service, "project", None)
        t = _find_track(p, self._track_id) if p is not None else None
        if t is None:
            return
        chain = getattr(t, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        chain["wet_gain"] = float(self.dial_wet.value()) / 100.0
        chain["mix"] = float(self.dial_mix.value()) / 100.0
        try:
            # notify UI; avoid "changed" spam
            if hasattr(project_service, "project_updated"):
                project_service.project_updated.emit()
        except Exception:
            pass


class GainFxWidget(QWidget):
    """Gain audio FX module: Gain (dB) -> RTParam gain linear."""

    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(parent)
        self._services = services
        self._track_id = str(track_id or "")
        self._device_id = str(device_id or "")
        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(120)
        self._debounce.timeout.connect(self._flush_to_project)
        self._build()

    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(4)

        row = QHBoxLayout()
        row.setSpacing(6)

        self.sld = QSlider(Qt.Orientation.Horizontal)
        self.sld.setRange(-600, 240)  # -60..+24 dB * 10
        self.spn = QDoubleSpinBox()
        self.spn.setRange(-60.0, 24.0)
        self.spn.setSingleStep(0.1)
        self.spn.setDecimals(1)
        self.spn.setSuffix(" dB")
        self.spn.setMaximumWidth(110)

        row.addWidget(QLabel("Gain"), 0)
        row.addWidget(self.sld, 1)
        row.addWidget(self.spn, 0)
        root.addLayout(row)

        self.sld.valueChanged.connect(self._on_slider)
        self.spn.valueChanged.connect(self._on_spin)

        self.refresh_from_project()

    def _key(self) -> str:
        return f"afx:{self._track_id}:{self._device_id}:gain"

    def refresh_from_project(self) -> None:
        project_service = getattr(self._services, "project", None)
        ctx = getattr(project_service, "ctx", None) if project_service is not None else None
        p = getattr(ctx, "project", None) if ctx is not None else None
        t = _find_track(p, self._track_id) if p is not None else None
        if t is None:
            return
        chain = getattr(t, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        dev = next((d for d in devs if isinstance(d, dict) and str(d.get("id","")) == self._device_id), None)
        if dev is None:
            return
        params = dev.get("params", {}) if isinstance(dev.get("params"), dict) else {}
        db = float(params.get("gain_db", 0.0) or 0.0)
        self.sld.blockSignals(True)
        self.spn.blockSignals(True)
        try:
            self.sld.setValue(int(round(db * 10.0)))
            self.spn.setValue(db)
        finally:
            self.sld.blockSignals(False)
            self.spn.blockSignals(False)

    def _apply_rt(self, db: float) -> None:
        ae = getattr(self._services, "audio_engine", None)
        rt = getattr(ae, "rt_params", None) if ae is not None else None
        if rt is None:
            return
        # linear
        g = float(10.0 ** (max(-120.0, min(24.0, float(db))) / 20.0))
        try:
            rt.set_param(self._key(), g)
        except Exception:
            pass

    def _on_slider(self, v: int) -> None:
        db = float(v) / 10.0
        self.spn.blockSignals(True)
        try:
            self.spn.setValue(db)
        finally:
            self.spn.blockSignals(False)
        self._apply_rt(db)
        self._debounce.start()

    def _on_spin(self, db: float) -> None:
        self.sld.blockSignals(True)
        try:
            self.sld.setValue(int(round(float(db) * 10.0)))
        finally:
            self.sld.blockSignals(False)
        self._apply_rt(float(db))
        self._debounce.start()

    def _flush_to_project(self) -> None:
        project_service = getattr(self._services, "project", None)
        ctx = getattr(project_service, "ctx", None) if project_service is not None else None
        p = getattr(ctx, "project", None) if ctx is not None else None
        t = _find_track(p, self._track_id) if p is not None else None
        if t is None:
            return
        chain = getattr(t, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        dev = next((d for d in devs if isinstance(d, dict) and str(d.get("id","")) == self._device_id), None)
        if dev is None:
            return
        params = dev.get("params", {})
        if not isinstance(params, dict):
            params = {}
            dev["params"] = params
        db = float(self.spn.value())
        params["gain_db"] = db
        params["gain"] = float(10.0 ** (db / 20.0))
        try:
            if hasattr(project_service, "project_updated"):
                project_service.project_updated.emit()
        except Exception:
            pass


class DistortionFxWidget(QWidget):
    """Simple distortion module (drive + mix)."""

    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(parent)
        self._services = services
        self._track_id = str(track_id or "")
        self._device_id = str(device_id or "")
        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(120)
        self._debounce.timeout.connect(self._flush_to_project)
        self._build()

    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(4)

        # Drive
        row1 = QHBoxLayout()
        self.sld_drive = QSlider(Qt.Orientation.Horizontal)
        self.sld_drive.setRange(0, 100)
        self.spn_drive = QDoubleSpinBox()
        self.spn_drive.setRange(0.0, 1.0)
        self.spn_drive.setSingleStep(0.01)
        self.spn_drive.setDecimals(2)
        self.spn_drive.setMaximumWidth(90)
        row1.addWidget(QLabel("Drive"), 0)
        row1.addWidget(self.sld_drive, 1)
        row1.addWidget(self.spn_drive, 0)
        root.addLayout(row1)

        # Mix
        row2 = QHBoxLayout()
        self.sld_mix = QSlider(Qt.Orientation.Horizontal)
        self.sld_mix.setRange(0, 100)
        self.spn_mix = QDoubleSpinBox()
        self.spn_mix.setRange(0.0, 1.0)
        self.spn_mix.setSingleStep(0.01)
        self.spn_mix.setDecimals(2)
        self.spn_mix.setMaximumWidth(90)
        row2.addWidget(QLabel("Mix"), 0)
        row2.addWidget(self.sld_mix, 1)
        row2.addWidget(self.spn_mix, 0)
        root.addLayout(row2)

        self.sld_drive.valueChanged.connect(self._on_drive_slider)
        self.spn_drive.valueChanged.connect(self._on_drive_spin)
        self.sld_mix.valueChanged.connect(self._on_mix_slider)
        self.spn_mix.valueChanged.connect(self._on_mix_spin)

        self.refresh_from_project()

    def _key_drive(self) -> str:
        return f"afx:{self._track_id}:{self._device_id}:drive"

    def _key_mix(self) -> str:
        return f"afx:{self._track_id}:{self._device_id}:mix"

    def refresh_from_project(self) -> None:
        project_service = getattr(self._services, "project", None)
        ctx = getattr(project_service, "ctx", None) if project_service is not None else None
        p = getattr(ctx, "project", None) if ctx is not None else None
        t = _find_track(p, self._track_id) if p is not None else None
        if t is None:
            return
        chain = getattr(t, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        dev = next((d for d in devs if isinstance(d, dict) and str(d.get("id","")) == self._device_id), None)
        if dev is None:
            return
        params = dev.get("params", {}) if isinstance(dev.get("params"), dict) else {}
        drive = float(params.get("drive", 0.25) or 0.25)
        mix = float(params.get("mix", 1.0) or 1.0)

        self.sld_drive.blockSignals(True); self.spn_drive.blockSignals(True)
        self.sld_mix.blockSignals(True); self.spn_mix.blockSignals(True)
        try:
            self.sld_drive.setValue(int(round(max(0.0, min(1.0, drive)) * 100.0)))
            self.spn_drive.setValue(max(0.0, min(1.0, drive)))
            self.sld_mix.setValue(int(round(max(0.0, min(1.0, mix)) * 100.0)))
            self.spn_mix.setValue(max(0.0, min(1.0, mix)))
        finally:
            self.sld_drive.blockSignals(False); self.spn_drive.blockSignals(False)
            self.sld_mix.blockSignals(False); self.spn_mix.blockSignals(False)

        # ensure RT keys exist
        ae = getattr(self._services, "audio_engine", None)
        rt = getattr(ae, "rt_params", None) if ae is not None else None
        try:
            if rt is not None:
                rt.ensure(self._key_drive(), drive)
                rt.ensure(self._key_mix(), mix)
        except Exception:
            pass

    def _apply_rt(self) -> None:
        ae = getattr(self._services, "audio_engine", None)
        rt = getattr(ae, "rt_params", None) if ae is not None else None
        if rt is None:
            return
        try:
            rt.set_param(self._key_drive(), float(self.spn_drive.value()))
            rt.set_param(self._key_mix(), float(self.spn_mix.value()))
        except Exception:
            pass

    def _on_drive_slider(self, v: int) -> None:
        x = float(v) / 100.0
        self.spn_drive.blockSignals(True)
        try:
            self.spn_drive.setValue(x)
        finally:
            self.spn_drive.blockSignals(False)
        self._apply_rt()
        self._debounce.start()

    def _on_drive_spin(self, x: float) -> None:
        self.sld_drive.blockSignals(True)
        try:
            self.sld_drive.setValue(int(round(max(0.0, min(1.0, float(x))) * 100.0)))
        finally:
            self.sld_drive.blockSignals(False)
        self._apply_rt()
        self._debounce.start()

    def _on_mix_slider(self, v: int) -> None:
        x = float(v) / 100.0
        self.spn_mix.blockSignals(True)
        try:
            self.spn_mix.setValue(x)
        finally:
            self.spn_mix.blockSignals(False)
        self._apply_rt()
        self._debounce.start()

    def _on_mix_spin(self, x: float) -> None:
        self.sld_mix.blockSignals(True)
        try:
            self.sld_mix.setValue(int(round(max(0.0, min(1.0, float(x))) * 100.0)))
        finally:
            self.sld_mix.blockSignals(False)
        self._apply_rt()
        self._debounce.start()

    def _flush_to_project(self) -> None:
        project_service = getattr(self._services, "project", None)
        ctx = getattr(project_service, "ctx", None) if project_service is not None else None
        p = getattr(ctx, "project", None) if ctx is not None else None
        t = _find_track(p, self._track_id) if p is not None else None
        if t is None:
            return
        chain = getattr(t, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        dev = next((d for d in devs if isinstance(d, dict) and str(d.get("id","")) == self._device_id), None)
        if dev is None:
            return
        params = dev.get("params", {})
        if not isinstance(params, dict):
            params = {}
            dev["params"] = params
        params["drive"] = float(self.spn_drive.value())
        params["mix"] = float(self.spn_mix.value())
        try:
            if hasattr(project_service, "project_updated"):
                project_service.project_updated.emit()
        except Exception:
            pass


# --- NOTE-FX: small module UIs (MVP)

def _get_project_and_track(services: Any, track_id: str):
    ps = getattr(services, "project", None) if services is not None else None
    ctx = getattr(ps, "ctx", None) if ps is not None else None
    p = getattr(ctx, "project", None) if ctx is not None else None
    t = _find_track(p, track_id) if p is not None else None
    return ps, p, t


def _find_note_fx_dev(services: Any, track_id: str, device_id: str):
    ps, p, t = _get_project_and_track(services, track_id)
    if t is None:
        return None, None
    chain = getattr(t, "note_fx_chain", None)
    if not isinstance(chain, dict):
        return None, None
    devs = chain.get("devices", []) or []
    dev = next((d for d in devs if isinstance(d, dict) and str(d.get("id","")) == str(device_id)), None)
    if dev is None:
        return None, None
    params = dev.get("params", {})
    if not isinstance(params, dict):
        params = {}
        dev["params"] = params
    return dev, params


class _NoteFxBase(QWidget):
    """Small helper base with debounced project writes."""
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(parent)
        self._services = services
        self._track_id = str(track_id or "")
        self._device_id = str(device_id or "")
        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(120)
        self._debounce.timeout.connect(self._flush)

    def _emit_updated(self) -> None:
        ps = getattr(self._services, "project", None) if self._services is not None else None
        try:
            if ps is not None and hasattr(ps, "project_updated"):
                ps.project_updated.emit()
        except Exception:
            pass

    def _flush(self) -> None:
        # implemented by subclasses
        self._emit_updated()


class TransposeNoteFxWidget(_NoteFxBase):
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)
        root = QVBoxLayout(self); root.setContentsMargins(6,6,6,6); root.setSpacing(4)
        row = QHBoxLayout()
        row.addWidget(QLabel("Semitones"), 0)
        self.spn = QSpinBox(); self.spn.setRange(-24, 24); self.spn.setValue(0)
        row.addWidget(self.spn, 0)
        row.addStretch(1)
        root.addLayout(row)
        self.spn.valueChanged.connect(lambda _: self._debounce.start())
        self.refresh_from_project()

    def refresh_from_project(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        val = int(params.get("semitones", 0) or 0)
        self.spn.blockSignals(True)
        try:
            self.spn.setValue(val)
        finally:
            self.spn.blockSignals(False)

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        params["semitones"] = int(self.spn.value())
        self._emit_updated()


class VelocityScaleNoteFxWidget(_NoteFxBase):
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)
        root = QVBoxLayout(self); root.setContentsMargins(6,6,6,6); root.setSpacing(4)
        row = QHBoxLayout(); row.setSpacing(6)
        row.addWidget(QLabel("Vel Scale"), 0)
        self.sld = QSlider(Qt.Orientation.Horizontal)
        self.sld.setRange(0, 200)  # 0..2.0
        self.spn = QDoubleSpinBox()
        self.spn.setRange(0.0, 2.0)
        self.spn.setSingleStep(0.01)
        self.spn.setDecimals(2)
        self.spn.setMaximumWidth(90)
        row.addWidget(self.sld, 1)
        row.addWidget(self.spn, 0)
        root.addLayout(row)

        self.sld.valueChanged.connect(self._on_sld)
        self.spn.valueChanged.connect(self._on_spn)
        self.refresh_from_project()

    def refresh_from_project(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        x = float(params.get("scale", 1.0) or 1.0)
        x = max(0.0, min(2.0, x))
        self.sld.blockSignals(True); self.spn.blockSignals(True)
        try:
            self.sld.setValue(int(round(x * 100.0)))
            self.spn.setValue(x)
        finally:
            self.sld.blockSignals(False); self.spn.blockSignals(False)

    def _on_sld(self, v: int) -> None:
        x = float(v) / 100.0
        self.spn.blockSignals(True)
        try:
            self.spn.setValue(x)
        finally:
            self.spn.blockSignals(False)
        self._debounce.start()

    def _on_spn(self, x: float) -> None:
        x = max(0.0, min(2.0, float(x)))
        self.sld.blockSignals(True)
        try:
            self.sld.setValue(int(round(x * 100.0)))
        finally:
            self.sld.blockSignals(False)
        self._debounce.start()

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        params["scale"] = float(self.spn.value())
        self._emit_updated()


class ScaleSnapNoteFxWidget(_NoteFxBase):
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)
        root = QVBoxLayout(self); root.setContentsMargins(6,6,6,6); root.setSpacing(4)

        r1 = QHBoxLayout(); r1.setSpacing(6)
        r1.addWidget(QLabel("Root"), 0)
        self.cmb_root = QComboBox()
        self._roots = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]
        self.cmb_root.addItems(self._roots)
        r1.addWidget(self.cmb_root, 0)
        r1.addWidget(QLabel("Scale"), 0)
        self.cmb_scale = QComboBox()
        self.cmb_scale.addItems(["major","minor","dorian","phrygian","lydian","mixolydian","locrian","pentatonic","chromatic"])
        r1.addWidget(self.cmb_scale, 1)
        root.addLayout(r1)

        r2 = QHBoxLayout(); r2.setSpacing(6)
        r2.addWidget(QLabel("Mode"), 0)
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["nearest","down","up"])
        r2.addWidget(self.cmb_mode, 0)
        r2.addStretch(1)
        root.addLayout(r2)

        self.cmb_root.currentIndexChanged.connect(lambda _: self._debounce.start())
        self.cmb_scale.currentIndexChanged.connect(lambda _: self._debounce.start())
        self.cmb_mode.currentIndexChanged.connect(lambda _: self._debounce.start())

        self.refresh_from_project()

    def refresh_from_project(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        root_pc = int(params.get("root", 0) or 0) % 12
        scale = str(params.get("scale", "major") or "major")
        mode = str(params.get("mode", "nearest") or "nearest")
        self.cmb_root.blockSignals(True); self.cmb_scale.blockSignals(True); self.cmb_mode.blockSignals(True)
        try:
            self.cmb_root.setCurrentIndex(max(0, min(11, root_pc)))
            self.cmb_scale.setCurrentText(scale if scale in [self.cmb_scale.itemText(i) for i in range(self.cmb_scale.count())] else "major")
            self.cmb_mode.setCurrentText(mode if mode in [self.cmb_mode.itemText(i) for i in range(self.cmb_mode.count())] else "nearest")
        finally:
            self.cmb_root.blockSignals(False); self.cmb_scale.blockSignals(False); self.cmb_mode.blockSignals(False)

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        params["root"] = int(self.cmb_root.currentIndex()) % 12
        params["scale"] = str(self.cmb_scale.currentText() or "major")
        params["mode"] = str(self.cmb_mode.currentText() or "nearest")
        self._emit_updated()


class ChordNoteFxWidget(_NoteFxBase):
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)
        root = QVBoxLayout(self); root.setContentsMargins(6,6,6,6); root.setSpacing(4)

        row = QHBoxLayout(); row.setSpacing(6)
        row.addWidget(QLabel("Chord"), 0)
        self.cmb = QComboBox()
        self.cmb.addItems(["maj","min","power","maj7","min7","dim","aug"])
        row.addWidget(self.cmb, 1)
        root.addLayout(row)

        self.cmb.currentIndexChanged.connect(lambda _: self._debounce.start())
        self.refresh_from_project()

    def refresh_from_project(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        ch = str(params.get("chord", "maj") or "maj")
        self.cmb.blockSignals(True)
        try:
            self.cmb.setCurrentText(ch if ch in [self.cmb.itemText(i) for i in range(self.cmb.count())] else "maj")
        finally:
            self.cmb.blockSignals(False)

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        params["chord"] = str(self.cmb.currentText() or "maj")
        self._emit_updated()


class ArpNoteFxWidget(_NoteFxBase):
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)
        root = QVBoxLayout(self); root.setContentsMargins(6,6,6,6); root.setSpacing(4)

        r1 = QHBoxLayout(); r1.setSpacing(6)
        r1.addWidget(QLabel("Step"), 0)
        self.cmb_step = QComboBox()
        self._steps = [0.125, 0.25, 0.5, 1.0]
        self.cmb_step.addItems([f"{s:g}" for s in self._steps])
        r1.addWidget(self.cmb_step, 0)
        r1.addWidget(QLabel("Mode"), 0)
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["up","down","updown","random"])
        r1.addWidget(self.cmb_mode, 1)
        root.addLayout(r1)

        r2 = QHBoxLayout(); r2.setSpacing(6)
        r2.addWidget(QLabel("Oct"), 0)
        self.spn_oct = QSpinBox(); self.spn_oct.setRange(1, 4); self.spn_oct.setValue(1)
        r2.addWidget(self.spn_oct, 0)
        r2.addWidget(QLabel("Gate"), 0)
        self.sld_gate = QSlider(Qt.Orientation.Horizontal); self.sld_gate.setRange(10, 100); self.sld_gate.setValue(90)
        self.spn_gate = QDoubleSpinBox(); self.spn_gate.setRange(0.10, 1.00); self.spn_gate.setSingleStep(0.01); self.spn_gate.setDecimals(2); self.spn_gate.setMaximumWidth(80)
        r2.addWidget(self.sld_gate, 1)
        r2.addWidget(self.spn_gate, 0)
        root.addLayout(r2)

        self.cmb_step.currentIndexChanged.connect(lambda _: self._debounce.start())
        self.cmb_mode.currentIndexChanged.connect(lambda _: self._debounce.start())
        self.spn_oct.valueChanged.connect(lambda _: self._debounce.start())
        self.sld_gate.valueChanged.connect(self._on_gate_sld)
        self.spn_gate.valueChanged.connect(self._on_gate_spn)

        self.refresh_from_project()

    def refresh_from_project(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        step = float(params.get("step_beats", 0.5) or 0.5)
        mode = str(params.get("mode", "up") or "up")
        octv = int(params.get("octaves", 1) or 1)
        gate = float(params.get("gate", 0.9) or 0.9)
        # normalize
        try:
            idx = min(range(len(self._steps)), key=lambda i: abs(self._steps[i] - step))
        except Exception:
            idx = 2
        gate = max(0.10, min(1.00, gate))
        self.cmb_step.blockSignals(True); self.cmb_mode.blockSignals(True)
        self.spn_oct.blockSignals(True); self.sld_gate.blockSignals(True); self.spn_gate.blockSignals(True)
        try:
            self.cmb_step.setCurrentIndex(int(idx))
            self.cmb_mode.setCurrentText(mode if mode in [self.cmb_mode.itemText(i) for i in range(self.cmb_mode.count())] else "up")
            self.spn_oct.setValue(max(1, min(4, octv)))
            self.sld_gate.setValue(int(round(gate * 100.0)))
            self.spn_gate.setValue(gate)
        finally:
            self.cmb_step.blockSignals(False); self.cmb_mode.blockSignals(False)
            self.spn_oct.blockSignals(False); self.sld_gate.blockSignals(False); self.spn_gate.blockSignals(False)

    def _on_gate_sld(self, v: int) -> None:
        x = max(0.10, min(1.00, float(v) / 100.0))
        self.spn_gate.blockSignals(True)
        try:
            self.spn_gate.setValue(x)
        finally:
            self.spn_gate.blockSignals(False)
        self._debounce.start()

    def _on_gate_spn(self, x: float) -> None:
        x = max(0.10, min(1.00, float(x)))
        self.sld_gate.blockSignals(True)
        try:
            self.sld_gate.setValue(int(round(x * 100.0)))
        finally:
            self.sld_gate.blockSignals(False)
        self._debounce.start()

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        params["step_beats"] = float(self._steps[int(self.cmb_step.currentIndex())]) if self.cmb_step.currentIndex() >= 0 else 0.5
        params["mode"] = str(self.cmb_mode.currentText() or "up")
        params["octaves"] = int(self.spn_oct.value())
        params["gate"] = float(self.spn_gate.value())
        self._emit_updated()


class RandomNoteFxWidget(_NoteFxBase):
    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)
        root = QVBoxLayout(self); root.setContentsMargins(6,6,6,6); root.setSpacing(4)

        r1 = QHBoxLayout(); r1.setSpacing(6)
        r1.addWidget(QLabel("Pitch ±"), 0)
        self.spn_pr = QSpinBox(); self.spn_pr.setRange(0, 24); self.spn_pr.setValue(0)
        r1.addWidget(self.spn_pr, 0)
        r1.addWidget(QLabel("Vel ±"), 0)
        self.spn_vr = QSpinBox(); self.spn_vr.setRange(0, 127); self.spn_vr.setValue(0)
        r1.addWidget(self.spn_vr, 0)
        r1.addStretch(1)
        root.addLayout(r1)

        r2 = QHBoxLayout(); r2.setSpacing(6)
        r2.addWidget(QLabel("Prob"), 0)
        self.sld_pb = QSlider(Qt.Orientation.Horizontal); self.sld_pb.setRange(0, 100); self.sld_pb.setValue(100)
        self.spn_pb = QDoubleSpinBox(); self.spn_pb.setRange(0.0, 1.0); self.spn_pb.setSingleStep(0.01); self.spn_pb.setDecimals(2); self.spn_pb.setMaximumWidth(80)
        r2.addWidget(self.sld_pb, 1)
        r2.addWidget(self.spn_pb, 0)
        root.addLayout(r2)

        self.spn_pr.valueChanged.connect(lambda _: self._debounce.start())
        self.spn_vr.valueChanged.connect(lambda _: self._debounce.start())
        self.sld_pb.valueChanged.connect(self._on_pb_sld)
        self.spn_pb.valueChanged.connect(self._on_pb_spn)

        self.refresh_from_project()

    def refresh_from_project(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        pr = int(params.get("pitch_range", 0) or 0)
        vr = int(params.get("vel_range", 0) or 0)
        pb = float(params.get("prob", 1.0) or 1.0)
        pr = max(0, min(24, pr))
        vr = max(0, min(127, vr))
        pb = max(0.0, min(1.0, pb))
        self.spn_pr.blockSignals(True); self.spn_vr.blockSignals(True)
        self.sld_pb.blockSignals(True); self.spn_pb.blockSignals(True)
        try:
            self.spn_pr.setValue(pr)
            self.spn_vr.setValue(vr)
            self.sld_pb.setValue(int(round(pb * 100.0)))
            self.spn_pb.setValue(pb)
        finally:
            self.spn_pr.blockSignals(False); self.spn_vr.blockSignals(False)
            self.sld_pb.blockSignals(False); self.spn_pb.blockSignals(False)

    def _on_pb_sld(self, v: int) -> None:
        x = max(0.0, min(1.0, float(v) / 100.0))
        self.spn_pb.blockSignals(True)
        try:
            self.spn_pb.setValue(x)
        finally:
            self.spn_pb.blockSignals(False)
        self._debounce.start()

    def _on_pb_spn(self, x: float) -> None:
        x = max(0.0, min(1.0, float(x)))
        self.sld_pb.blockSignals(True)
        try:
            self.sld_pb.setValue(int(round(x * 100.0)))
        finally:
            self.sld_pb.blockSignals(False)
        self._debounce.start()

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        params["pitch_range"] = int(self.spn_pr.value())
        params["vel_range"] = int(self.spn_vr.value())
        params["prob"] = float(self.spn_pb.value())
        self._emit_updated()


class AiComposerNoteFxWidget(_NoteFxBase):
    """Algorithmic MIDI composition engine (as Note-FX tool).

    Important UX constraints:
    - must never freeze the UI on load/refresh
    - must be fully visible / scrollable inside the device card

    This device does not apply processing in the audio engine yet. It is a
    *generator* UI: it writes MIDI notes into the selected clip or creates a new
    clip on the track.
    """

    def __init__(self, services: Any, track_id: str, device_id: str, parent=None):
        super().__init__(services, track_id, device_id, parent)

        from pydaw.music.ai_composer import GENRES, CONTEXTS, FORMS, INSTRUMENT_SETUPS

        outer = QVBoxLayout(self)
        outer.setContentsMargins(6, 6, 6, 6)
        outer.setSpacing(6)

        # Inside the DevicePanel chain, cards don't have vertical scroll.
        # Therefore, this widget must be self-scrollable to avoid clipped UI.
        content_parent = self
        if QScrollArea is not None:
            self._scroll = QScrollArea(self)
            self._scroll.setWidgetResizable(True)
            self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            self._scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            try:
                self._scroll.verticalScrollBar().setSingleStep(18)
            except Exception:
                pass
            content = QWidget(self._scroll)
            self._scroll.setWidget(content)
            outer.addWidget(self._scroll, 1)
            content_parent = content
        else:
            self._scroll = None

        root = QVBoxLayout(content_parent)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(6)

        # --- Controls
        box = QGroupBox("AI Composer — MIDI Generation")
        form = QFormLayout(box)
        form.setContentsMargins(8, 8, 8, 8)
        form.setSpacing(6)
        try:
            form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        except Exception:
            pass

        # Genres: use editable comboboxes so *any* genre can be typed.
        self.cmb_genre_a = QComboBox()
        self.cmb_genre_a.setEditable(True)
        try:
            self.cmb_genre_a.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        except Exception:
            pass
        self.cmb_genre_a.addItems(list(GENRES) + ["Custom"])

        self.txt_genre_a = QLineEdit()
        self.txt_genre_a.setPlaceholderText("Custom Genre A …")
        self._lab_custom_a = QLabel("Custom A")

        self.cmb_genre_b = QComboBox()
        self.cmb_genre_b.setEditable(True)
        try:
            self.cmb_genre_b.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        except Exception:
            pass
        self.cmb_genre_b.addItems(list(GENRES) + ["Custom"])

        self.txt_genre_b = QLineEdit()
        self.txt_genre_b.setPlaceholderText("Custom Genre B …")
        self._lab_custom_b = QLabel("Custom B")

        self.cmb_context = QComboBox(); self.cmb_context.addItems(list(CONTEXTS))
        self.cmb_form = QComboBox(); self.cmb_form.addItems(list(FORMS))
        self.cmb_instr = QComboBox(); self.cmb_instr.addItems(list(INSTRUMENT_SETUPS))

        self.spn_bars = QSpinBox(); self.spn_bars.setRange(1, 64); self.spn_bars.setValue(8)

        # Grid in beats: 1/16=0.25, 1/8=0.5, 1/4=1.0
        self.cmb_grid = QComboBox()
        self._grid_map = {
            "1/16": 0.25,
            "1/8": 0.5,
            "1/4": 1.0,
            "1/32": 0.125,
        }
        self.cmb_grid.addItems(list(self._grid_map.keys()))

        self.spn_swing = QDoubleSpinBox(); self.spn_swing.setRange(0.0, 1.0); self.spn_swing.setDecimals(2); self.spn_swing.setSingleStep(0.01)
        self.spn_density = QDoubleSpinBox(); self.spn_density.setRange(0.0, 1.0); self.spn_density.setDecimals(2); self.spn_density.setSingleStep(0.01)
        self.spn_hybrid = QDoubleSpinBox(); self.spn_hybrid.setRange(0.0, 1.0); self.spn_hybrid.setDecimals(2); self.spn_hybrid.setSingleStep(0.01)
        self.spn_seed = QSpinBox(); self.spn_seed.setRange(0, 2_000_000_000); self.spn_seed.setValue(1)

        form.addRow("Genre A (Struktur)", self.cmb_genre_a)
        form.addRow(self._lab_custom_a, self.txt_genre_a)
        form.addRow("Genre B (Rhythm)", self.cmb_genre_b)
        form.addRow(self._lab_custom_b, self.txt_genre_b)
        form.addRow("Kontext", self.cmb_context)
        form.addRow("Form", self.cmb_form)
        form.addRow("Instrument-Setup", self.cmb_instr)
        form.addRow("Länge (Bars)", self.spn_bars)
        form.addRow("Grid", self.cmb_grid)
        form.addRow("Swing", self.spn_swing)
        form.addRow("Density", self.spn_density)
        form.addRow("Hybrid (A↔B)", self.spn_hybrid)
        form.addRow("Seed", self.spn_seed)

        root.addWidget(box)

        # --- Hint
        self.lab_hint = QLabel(
            "Tipp: Genre A steuert Harmonik/Struktur (z.B. Barock/Fuge),\n"
            "Genre B steuert Rhythmus/Energie (z.B. Hardcore/Industrial).\n"
            "\nOutput: schreibt Noten in den ausgewählten MIDI-Clip oder erstellt einen neuen Clip auf der Spur."
        )
        self.lab_hint.setWordWrap(True)
        self.lab_hint.setStyleSheet("color:#7f7f7f; font-size:11px;")
        root.addWidget(self.lab_hint)

        # --- Actions (pinned below scroll)
        row = QHBoxLayout(); row.setSpacing(6)
        self.btn_generate = QPushButton("Generate → Clip")
        self.btn_overwrite = QPushButton("Overwrite Selected Clip")
        self.btn_snapshot_save = QPushButton("Save Snapshot…")
        self.btn_snapshot_load = QPushButton("Load Snapshot…")
        row.addWidget(self.btn_generate, 0)
        row.addWidget(self.btn_overwrite, 0)
        row.addStretch(1)
        row.addWidget(self.btn_snapshot_save, 0)
        row.addWidget(self.btn_snapshot_load, 0)
        outer.addLayout(row)

        # Wire changes → params (debounced)
        self.cmb_genre_a.currentTextChanged.connect(self._on_any_change)
        self.cmb_genre_b.currentTextChanged.connect(self._on_any_change)
        self.cmb_context.currentIndexChanged.connect(lambda _=0: self._on_any_change())
        self.cmb_form.currentIndexChanged.connect(lambda _=0: self._on_any_change())
        self.cmb_instr.currentIndexChanged.connect(lambda _=0: self._on_any_change())
        self.spn_bars.valueChanged.connect(lambda _=0: self._on_any_change())
        self.cmb_grid.currentIndexChanged.connect(lambda _=0: self._on_any_change())
        self.spn_swing.valueChanged.connect(lambda _=0: self._on_any_change())
        self.spn_density.valueChanged.connect(lambda _=0: self._on_any_change())
        self.spn_hybrid.valueChanged.connect(lambda _=0: self._on_any_change())
        self.spn_seed.valueChanged.connect(lambda _=0: self._on_any_change())
        self.txt_genre_a.textChanged.connect(lambda _="": self._on_any_change())
        self.txt_genre_b.textChanged.connect(lambda _="": self._on_any_change())

        # Actions
        self.btn_generate.clicked.connect(self._on_generate_new_clip)
        self.btn_overwrite.clicked.connect(self._on_overwrite_selected)
        self.btn_snapshot_save.clicked.connect(self._on_snapshot_save)
        self.btn_snapshot_load.clicked.connect(self._on_snapshot_load)

        self.refresh_from_project()
        self._update_custom_rows()

    def _on_any_change(self) -> None:
        # Keep UI responsive: update visibility without triggering loops.
        try:
            self._update_custom_rows()
        except Exception:
            pass
        self._debounce.start()

    def _update_custom_rows(self) -> None:
        """Show custom text fields only when explicitly requested.

        This keeps the card compact (often no vertical scroll needed) while still
        supporting arbitrary genres via editable comboboxes.
        """
        try:
            a_is_custom = str(self.cmb_genre_a.currentText() or "") == "Custom"
            b_is_custom = str(self.cmb_genre_b.currentText() or "") == "Custom"
            for w in (getattr(self, '_lab_custom_a', None), getattr(self, 'txt_genre_a', None)):
                if w is not None:
                    w.setVisible(bool(a_is_custom))
            for w in (getattr(self, '_lab_custom_b', None), getattr(self, 'txt_genre_b', None)):
                if w is not None:
                    w.setVisible(bool(b_is_custom))
        except Exception:
            pass

    def _params_from_ui(self) -> dict:
        return {
            "genre_a": str(self.cmb_genre_a.currentText()),
            "genre_b": str(self.cmb_genre_b.currentText()),
            "custom_genre_a": str(self.txt_genre_a.text() or ""),
            "custom_genre_b": str(self.txt_genre_b.text() or ""),
            "context": str(self.cmb_context.currentText()),
            "form": str(self.cmb_form.currentText()),
            "instrument_setup": str(self.cmb_instr.currentText()),
            "bars": int(self.spn_bars.value()),
            "grid": float(self._grid_map.get(str(self.cmb_grid.currentText()), 0.25)),
            "swing": float(self.spn_swing.value()),
            "density": float(self.spn_density.value()),
            "hybrid": float(self.spn_hybrid.value()),
            "seed": int(self.spn_seed.value()),
        }

    def refresh_from_project(self) -> None:
        """Refresh without re-entrancy loops.

        IMPORTANT: do *not* rely on self.blockSignals(True) because it does not
        block child widget signals. Use QSignalBlocker per widget.
        """
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return

        def _set_combo_text(cmb: QComboBox, value: str) -> None:
            try:
                ix = cmb.findText(str(value))
                if ix >= 0:
                    cmb.setCurrentIndex(ix)
                else:
                    # editable combobox: allow arbitrary text
                    cmb.setCurrentText(str(value))
            except Exception:
                try:
                    cmb.setCurrentText(str(value))
                except Exception:
                    pass

        blockers = []
        try:
            blockers = [
                QSignalBlocker(self.cmb_genre_a),
                QSignalBlocker(self.txt_genre_a),
                QSignalBlocker(self.cmb_genre_b),
                QSignalBlocker(self.txt_genre_b),
                QSignalBlocker(self.cmb_context),
                QSignalBlocker(self.cmb_form),
                QSignalBlocker(self.cmb_instr),
                QSignalBlocker(self.spn_bars),
                QSignalBlocker(self.cmb_grid),
                QSignalBlocker(self.spn_swing),
                QSignalBlocker(self.spn_density),
                QSignalBlocker(self.spn_hybrid),
                QSignalBlocker(self.spn_seed),
            ]
        except Exception:
            blockers = []

        try:
            _set_combo_text(self.cmb_genre_a, str(params.get("genre_a", "Barock (Bach/Fuge)")))
            _set_combo_text(self.cmb_genre_b, str(params.get("genre_b", "Electro")))
            self.txt_genre_a.setText(str(params.get("custom_genre_a", "") or ""))
            self.txt_genre_b.setText(str(params.get("custom_genre_b", "") or ""))
            _set_combo_text(self.cmb_context, str(params.get("context", "Neutral")))
            _set_combo_text(self.cmb_form, str(params.get("form", "Mini-Fuge (Subject/Answer)")))
            _set_combo_text(self.cmb_instr, str(params.get("instrument_setup", "Kammermusik-Setup")))
            self.spn_bars.setValue(int(params.get("bars", 8) or 8))

            grid_val = float(params.get("grid", 0.25) or 0.25)
            best_k = "1/16"; best_d = 999.0
            for k, v in self._grid_map.items():
                d = abs(float(v) - grid_val)
                if d < best_d:
                    best_k, best_d = k, d
            _set_combo_text(self.cmb_grid, best_k)

            self.spn_swing.setValue(float(params.get("swing", 0.0) or 0.0))
            self.spn_density.setValue(float(params.get("density", 0.65) or 0.65))
            self.spn_hybrid.setValue(float(params.get("hybrid", 0.55) or 0.55))
            self.spn_seed.setValue(int(params.get("seed", 1) or 1))
        finally:
            blockers = []

        self._update_custom_rows()

    def _flush(self) -> None:
        dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
        if dev is None:
            return
        newp = self._params_from_ui()
        # Only emit project_updated if something actually changed.
        changed = False
        try:
            for k, v in newp.items():
                if params.get(k) != v:
                    changed = True
                    break
        except Exception:
            changed = True
        if not changed:
            return
        params.update(newp)
        self._emit_updated()

    # --- actions

    def _get_time_signature(self) -> str:
        ps = getattr(self._services, "project", None) if self._services is not None else None
        try:
            return str(getattr(ps.ctx.project, "time_signature", "4/4") or "4/4")
        except Exception:
            return "4/4"

    def _on_generate_new_clip(self) -> None:
        """Create a new MIDI clip on this track and fill it."""
        ps = getattr(self._services, "project", None) if self._services is not None else None
        if ps is None:
            return

        try:
            # Place at playhead if available, else bar 1
            transport = getattr(self._services, "transport", None) if self._services is not None else None
            start = float(getattr(transport, "current_beat", 0.0) if transport is not None else 0.0)
        except Exception:
            start = 0.0

        try:
            clip_id = ps.add_midi_clip_at(str(self._track_id), start_beats=float(start), length_beats=4.0, label="AI Clip")
        except Exception as e:
            try:
                QMessageBox.warning(self, "AI Composer", f"Konnte Clip nicht erstellen: {e}")
            except Exception:
                pass
            return

        self._render_into_clip(str(clip_id), overwrite=True)

    def _on_overwrite_selected(self) -> None:
        ps = getattr(self._services, "project", None) if self._services is not None else None
        if ps is None:
            return
        clip_id = ""
        try:
            clip_id = str(ps.active_clip_id() or "")
        except Exception:
            clip_id = str(getattr(ps, "_active_clip_id", "") or "")
        if not clip_id:
            try:
                QMessageBox.information(self, "AI Composer", "Kein Clip ausgewählt. Nutze 'Generate → Clip' oder wähle einen MIDI-Clip.")
            except Exception:
                pass
            return
        self._render_into_clip(str(clip_id), overwrite=True)

    def _render_into_clip(self, clip_id: str, *, overwrite: bool = True) -> None:
        ps = getattr(self._services, "project", None) if self._services is not None else None
        if ps is None:
            return
        try:
            from pydaw.music.ai_composer import ComposerParams, generate_clip_notes
            p = self._params_from_ui()
            params = ComposerParams(
                genre_a=str(p.get("genre_a", "Barock (Bach/Fuge)")),
                genre_b=str(p.get("genre_b", "Electro")),
                custom_genre_a=str(p.get("custom_genre_a", "")),
                custom_genre_b=str(p.get("custom_genre_b", "")),
                context=str(p.get("context", "Neutral")),
                form=str(p.get("form", "Mini-Fuge (Subject/Answer)")),
                instrument_setup=str(p.get("instrument_setup", "Kammermusik-Setup")),
                bars=int(p.get("bars", 8) or 8),
                grid=float(p.get("grid", 0.25) or 0.25),
                swing=float(p.get("swing", 0.0) or 0.0),
                density=float(p.get("density", 0.65) or 0.65),
                hybrid=float(p.get("hybrid", 0.55) or 0.55),
                seed=int(p.get("seed", 1) or 1),
            )

            ts = self._get_time_signature()
            start = 0.0
            new_notes = generate_clip_notes(start_beats=float(start), time_signature=ts, params=params)
        except Exception as e:
            try:
                QMessageBox.warning(self, "AI Composer", f"Komposition fehlgeschlagen: {e}")
            except Exception:
                pass
            return

        try:
            before = ps.snapshot_midi_notes(str(clip_id))
        except Exception:
            before = []

        try:
            if overwrite:
                ps.set_midi_notes(str(clip_id), list(new_notes))
            else:
                cur = list(ps.get_midi_notes(str(clip_id)) or [])
                cur.extend(list(new_notes))
                ps.set_midi_notes(str(clip_id), cur)
        except Exception as e:
            try:
                QMessageBox.warning(self, "AI Composer", f"Konnte Noten nicht schreiben: {e}")
            except Exception:
                pass
            return

        # register undo step for the MIDI note edit
        try:
            ps.commit_midi_notes_edit(str(clip_id), before=before, label="AI Composer")
        except Exception:
            # fallback: emit update
            try:
                ps.project_updated.emit()
            except Exception:
                pass

    def _on_snapshot_save(self) -> None:
        try:
            path, _ = QFileDialog.getSaveFileName(self, "AI Composer Snapshot speichern", "ai_composer_snapshot.json", "JSON (*.json)")
            if not path:
                return
            import json
            with open(str(path), "w", encoding="utf-8") as f:
                json.dump(self._params_from_ui(), f, indent=2, ensure_ascii=False)
        except Exception as e:
            try:
                QMessageBox.warning(self, "AI Composer", f"Snapshot speichern fehlgeschlagen: {e}")
            except Exception:
                pass

    def _on_snapshot_load(self) -> None:
        try:
            path, _ = QFileDialog.getOpenFileName(self, "AI Composer Snapshot laden", "", "JSON (*.json)")
            if not path:
                return
            import json
            with open(str(path), "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                return

            # write into device params (single source of truth)
            dev, params = _find_note_fx_dev(self._services, self._track_id, self._device_id)
            if dev is None:
                return
            params.update({k: data.get(k) for k in data.keys()})
            self.refresh_from_project()
            self._emit_updated()
        except Exception as e:
            try:
                QMessageBox.warning(self, "AI Composer", f"Snapshot laden fehlgeschlagen: {e}")
            except Exception:
                pass

def make_audio_fx_widget(services: Any, track_id: str, device: dict) -> Optional[QWidget]:
    pid = str(device.get("plugin_id") or device.get("type") or "")
    did = str(device.get("id") or "")
    if not did:
        return None
    if pid == "chrono.fx.gain":
        return GainFxWidget(services, track_id, did)
    if pid == "chrono.fx.distortion":
        return DistortionFxWidget(services, track_id, did)
    # ── v105: Bitwig-Style Audio-FX ──────────────────────────────
    try:
        from pydaw.ui.fx_audio_widgets import (
            EQ5FxWidget, Delay2FxWidget, ReverbFxWidget, CombFxWidget,
            CompressorFxWidget, FilterPlusFxWidget, DistortionPlusFxWidget,
            DynamicsFxWidget, FlangerFxWidget, PitchShifterFxWidget,
            TremoloFxWidget, PeakLimiterFxWidget, ChorusFxWidget,
            XYFxWidget, DeEsserFxWidget,
        )
        _NEW_FX = {
            "chrono.fx.eq5": EQ5FxWidget,
            "chrono.fx.delay2": Delay2FxWidget,
            "chrono.fx.reverb": ReverbFxWidget,
            "chrono.fx.comb": CombFxWidget,
            "chrono.fx.compressor": CompressorFxWidget,
            "chrono.fx.filter_plus": FilterPlusFxWidget,
            "chrono.fx.distortion_plus": DistortionPlusFxWidget,
            "chrono.fx.dynamics": DynamicsFxWidget,
            "chrono.fx.flanger": FlangerFxWidget,
            "chrono.fx.pitch_shifter": PitchShifterFxWidget,
            "chrono.fx.tremolo": TremoloFxWidget,
            "chrono.fx.peak_limiter": PeakLimiterFxWidget,
            "chrono.fx.chorus": ChorusFxWidget,
            "chrono.fx.xy_fx": XYFxWidget,
            "chrono.fx.de_esser": DeEsserFxWidget,
        }
        cls = _NEW_FX.get(pid)
        if cls is not None:
            return cls(services, track_id, did)
    except Exception:
        pass
    # unknown FX: show placeholder label
    lab = QLabel(f"{pid}\n(no UI yet)")
    lab.setWordWrap(True)
    return lab


def make_note_fx_widget(services: Any, track_id: str, device: dict) -> Optional[QWidget]:
    pid = str(device.get("plugin_id") or device.get("type") or "")
    did = str(device.get("id") or "")
    if not did:
        return None
    if pid == "chrono.note_fx.transpose":
        return TransposeNoteFxWidget(services, track_id, did)
    if pid == "chrono.note_fx.velocity_scale":
        return VelocityScaleNoteFxWidget(services, track_id, did)
    if pid == "chrono.note_fx.scale_snap":
        return ScaleSnapNoteFxWidget(services, track_id, did)
    if pid == "chrono.note_fx.chord":
        return ChordNoteFxWidget(services, track_id, did)
    if pid == "chrono.note_fx.arp":
        return ArpNoteFxWidget(services, track_id, did)
    if pid == "chrono.note_fx.random":
        return RandomNoteFxWidget(services, track_id, did)
    if pid == "chrono.note_fx.ai_composer":
        return AiComposerNoteFxWidget(services, track_id, did)
    # Others: show placeholder for forward compatibility
    lab = QLabel(f"{pid}\n(MVP UI missing)")
    lab.setWordWrap(True)
    return lab
