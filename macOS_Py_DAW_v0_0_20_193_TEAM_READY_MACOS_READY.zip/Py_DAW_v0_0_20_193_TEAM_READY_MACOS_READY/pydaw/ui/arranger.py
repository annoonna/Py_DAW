"""Arranger view: track list + scrollable canvas + automation panel.

v0.0.19.7.39:
- Drag&Drop Overlay Clip-Launcher Grid (from Browser Sample drag)
- Overlay accepts drops ONLY while active to avoid collisions with Arranger logic

v0.0.20.86:
- TrackList: Drag&Drop support for cross-project track transfer
  Drag a track from one project tab's TrackList to another tab's ArrangerCanvas.
"""

from __future__ import annotations

import logging

from PyQt6.QtWidgets import (
    QWidget,
    QHBoxLayout,
    QVBoxLayout,
    QListWidget,
    QListWidgetItem,
    QScrollArea,
    QSplitter,
    QLabel,
    QToolButton,
    QComboBox,
    QAbstractItemView,
    QMenu,
    QWidgetAction,
    QLineEdit,
)
from PyQt6.QtCore import Qt, pyqtSignal, QEvent, QMimeData
from PyQt6.QtGui import QDrag

from pydaw.ui.cross_project_drag import create_track_drag_data

from pydaw.services.project_service import ProjectService
from .arranger_canvas import ArrangerCanvas
from .automation_lanes import AutomationLanePanel
# v0.0.20.89: Enhanced Automation Editor (Bezier + FX params)
try:
    from .automation_editor import EnhancedAutomationLanePanel
    _HAS_ENHANCED_AUTOMATION = True
except ImportError:
    _HAS_ENHANCED_AUTOMATION = False
from .clip_launcher_overlay import ClipLauncherOverlay

log = logging.getLogger(__name__)


class TrackList(QWidget):
    track_selected = pyqtSignal(str)
    selected_track_changed = pyqtSignal(str)  # compatibility alias

    # Phase 2 (Track-Header ▾): request helpers (handled by MainWindow)
    request_open_browser_tab = pyqtSignal(str, str)  # track_id, tab_key ('instruments'|'effects'|'samples')
    request_show_device_panel = pyqtSignal(str)      # track_id
    # Phase 3: Track-Header ▾ → 1-click insert into device chains
    request_add_device = pyqtSignal(str, str, str)   # track_id, kind ('instrument'|'note_fx'|'audio_fx'), plugin_id

    def __init__(self, project: ProjectService, parent=None):
        super().__init__(parent)
        self.project = project
        self._tab_service = None  # v0.0.20.86: for cross-project drag
        self._device_prefs = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.list = QListWidget()
        # v0.0.20.86: Enable drag for cross-project track transfer
        self.list.setDragEnabled(True)
        self.list.setDefaultDropAction(Qt.DropAction.CopyAction)
        self.list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.list.setDragDropMode(QAbstractItemView.DragDropMode.DragOnly)
        # Override startDrag to provide custom MIME data
        # (defensive: never crash startup if method is missing due to stale caches or edits)
        try:
            fn = getattr(self, "_start_drag", None)
            if callable(fn):
                self.list.startDrag = fn
        except Exception:
            pass
        layout.addWidget(self.list, 1)
        # Safety: PyQt6 may abort the whole process (SIGABRT) if a slot raises.
        # Always route through _safe_ui_call.
        try:
            self.list.currentItemChanged.connect(lambda cur, prev: self._safe_ui_call(self._on_sel, cur, prev))
        except Exception:
            self.list.currentItemChanged.connect(self._on_sel)

        try:
            self.project.project_updated.connect(lambda: self._safe_ui_call(self.refresh))
        except Exception:
            self.project.project_updated.connect(self.refresh)
        self.refresh()

    # --- safety: PyQt6 may abort on uncaught slot exceptions (SIGABRT) ---
    def _safe_ui_call(self, fn, *args, **kwargs):  # noqa: ANN001
        try:
            return fn(*args, **kwargs)
        except Exception:
            return None

    # --- Phase 3: Favorites/Recents (UI-only; per-user cache) ---
    def _prefs(self):  # noqa: ANN001
        if self._device_prefs is None:
            try:
                from .device_prefs import DevicePrefs
                self._device_prefs = DevicePrefs.load()
            except Exception:
                self._device_prefs = None
        return self._device_prefs

    def _prefs_add_recent(self, kind: str, plugin_id: str, name: str) -> None:
        p = self._prefs()
        if p is None:
            return
        try:
            p.add_recent(kind, plugin_id, name)
            p.save()
        except Exception:
            pass

    def _prefs_toggle_favorite(self, kind: str, plugin_id: str, name: str) -> bool:
        p = self._prefs()
        if p is None:
            return False
        try:
            now = bool(p.toggle_favorite(kind, plugin_id, name))
            p.save()
            return now
        except Exception:
            return False

    def _prefs_get(self, bucket: str, kind: str):  # noqa: ANN001
        p = self._prefs()
        if p is None:
            return []
        try:
            b = getattr(p, bucket, {}) or {}
            return list(b.get(kind, []) or [])
        except Exception:
            return []

    def _prefs_clear_recents(self, kinds: list[str]) -> None:
        p = self._prefs()
        if p is None:
            return
        try:
            for k in kinds:
                p.clear_recents(k)
            p.save()
        except Exception:
            pass

    def _emit_add_device(self, track_id: str, kind: str, plugin_id: str, name: str) -> None:
        self._prefs_add_recent(kind, plugin_id, name)
        try:
            self.request_add_device.emit(str(track_id), str(kind), str(plugin_id))
        except Exception:
            pass

    def _attach_searchable_device_menu(self, menu: QMenu, *, track_id: str, title: str, kind: str, items: list[tuple[str, str]]) -> None:
        """Attach a submenu with search + filtered device list.

        Wayland safety:
        - Embedding a QLineEdit into a QMenu (QWidgetAction) can be flaky on some Wayland/Qt combos.
          If we detect Wayland, we use a tiny input dialog instead.

        IMPORTANT: This function must never raise (PyQt6 can SIGABRT on uncaught slot exceptions).
        """
        import os

        sub = menu.addMenu(title)
        state = {"acts": [], "q": ""}

        def _clear_actions() -> None:
            for a in list(state["acts"]):
                try:
                    sub.removeAction(a)
                except Exception:
                    pass
            state["acts"] = []

        def repop() -> None:
            try:
                _clear_actions()
                q = str(state.get("q") or "").strip().lower()
                shown = 0
                for it in list(items or []):
                    try:
                        name, pid = it
                    except Exception:
                        continue
                    hay = f"{name} {pid}".lower()
                    if q and q not in hay:
                        continue
                    act = sub.addAction(str(name))
                    act.triggered.connect(
                        lambda _=False, _tid=str(track_id), _pid=str(pid), _name=str(name): self._safe_ui_call(
                            self._emit_add_device, _tid, kind, _pid, _name
                        )
                    )
                    state["acts"].append(act)
                    shown += 1
                    if shown >= 30:
                        break

                if shown == 0:
                    act = sub.addAction("(keine Treffer)")
                    act.setEnabled(False)
                    state["acts"].append(act)
            except Exception:
                try:
                    _clear_actions()
                    act = sub.addAction("(Fehler beim Laden)")
                    act.setEnabled(False)
                    state["acts"].append(act)
                except Exception:
                    pass

        def _safe_repop(*_a) -> None:
            try:
                repop()
            except Exception:
                pass

        # Detect Wayland
        qpa = (os.environ.get("QT_QPA_PLATFORM", "") or "").lower()
        sess = (os.environ.get("XDG_SESSION_TYPE", "") or "").lower()
        is_wayland = (sess == "wayland") or ("WAYLAND_DISPLAY" in os.environ) or qpa.startswith("wayland")

        if is_wayland:
            # No embedded text input; use Search… dialog.
            act_search = sub.addAction("Search…")
            act_clear = sub.addAction("Clear Search")
            sub.addSeparator()

            def ask_search() -> None:
                try:
                    from PyQt6.QtWidgets import QInputDialog
                    txt, ok = QInputDialog.getText(self, "Search", "Filter:", text=str(state.get("q") or ""))
                    if ok:
                        state["q"] = str(txt or "")
                        repop()
                except Exception:
                    pass

            def clear_search() -> None:
                try:
                    state["q"] = ""
                    repop()
                except Exception:
                    pass

            try:
                act_search.triggered.connect(lambda _=False: self._safe_ui_call(ask_search))
                act_clear.triggered.connect(lambda _=False: self._safe_ui_call(clear_search))
                sub.aboutToShow.connect(_safe_repop)
            except Exception:
                pass

            _safe_repop()
            return

        # Non-Wayland: embed QLineEdit into menu
        try:
            w = QWidget(sub)
            lay = QHBoxLayout(w)
            lay.setContentsMargins(8, 6, 8, 6)
            edt = QLineEdit(w)
            edt.setPlaceholderText("Suchen…")
            lay.addWidget(edt, 1)
            wa = QWidgetAction(sub)
            wa.setDefaultWidget(w)
            sub.addAction(wa)
            sub.addSeparator()

            def _set_q_from_edt() -> None:
                state["q"] = (edt.text() or "")

            def _safe_repop_from_edt(*_a) -> None:
                try:
                    _set_q_from_edt()
                    repop()
                except Exception:
                    pass

            sub.aboutToShow.connect(_safe_repop_from_edt)
            edt.textChanged.connect(_safe_repop_from_edt)
            _safe_repop_from_edt()
        except Exception:
            # Fallback: no search box
            try:
                sub.aboutToShow.connect(_safe_repop)
            except Exception:
                pass
            _safe_repop()

    # --- v0.0.20.86: Cross-Project Drag Support ---

    def set_tab_service(self, tab_service) -> None:
        """Wire the ProjectTabService for cross-project drag data."""
        self._tab_service = tab_service

    def _start_drag(self, supported_actions) -> None:
        """Custom startDrag: creates cross-project MIME data for selected tracks."""
        try:
            selected_items = self.list.selectedItems()
            if not selected_items:
                return

            track_ids = []
            for item in selected_items:
                tid = str(item.data(Qt.ItemDataRole.UserRole) or "")
                if tid:
                    track_ids.append(tid)

            if not track_ids:
                return

            # Determine source tab index (default 0 if no tab service)
            src_idx = 0
            if self._tab_service:
                src_idx = getattr(self._tab_service, "active_index", 0)

            mime = create_track_drag_data(
                source_tab_index=src_idx,
                track_ids=track_ids,
                include_clips=True,
                include_device_chains=True,
            )

            drag = QDrag(self.list)
            drag.setMimeData(mime)

            log.info("TrackList: starting cross-project drag with %d track(s)", len(track_ids))
            drag.exec(Qt.DropAction.CopyAction)
        except Exception:
            log.exception("TrackList._start_drag failed")

    def refresh(self) -> None:
        cur_id = self.selected_track_id()
        self.list.clear()
        for t in self.project.ctx.project.tracks:
            it = QListWidgetItem()
            it.setData(Qt.ItemDataRole.UserRole, t.id)

            # custom row widget with M/S/R controls
            row = QWidget()
            lay = QHBoxLayout(row)
            lay.setContentsMargins(6, 2, 6, 2)
            lay.setSpacing(6)

            lbl = QLabel(t.name)
            lbl.setMinimumWidth(90)
            lbl.setStyleSheet("color: #e6e6e6;")
            lay.addWidget(lbl, 1)

            # Input/Monitoring controls (JACK-first): show for audio/bus tracks.
            if t.kind in ("audio", "bus"):
                try:
                    import os
                    in_ch = int(os.environ.get("PYDAW_JACK_IN", "2"))
                    out_ch = int(os.environ.get("PYDAW_JACK_OUT", "2"))
                except Exception:
                    in_ch, out_ch = 2, 2

                in_pairs = max(1, in_ch // 2)
                out_pairs = max(1, out_ch // 2)

                cb_in = QComboBox()
                for i in range(1, in_pairs + 1):
                    cb_in.addItem(f"Stereo {i}")
                try:
                    cur_in = max(1, int(getattr(t, "input_pair", 1) or 1))
                except Exception:
                    cur_in = 1
                cb_in.setCurrentIndex(max(0, min(in_pairs - 1, cur_in - 1)))
                cb_in.setToolTip("Input (Stereo-Paar) für Monitoring/Recording")
                cb_in.currentIndexChanged.connect(lambda idx, tid=t.id: self._safe_ui_call(self.project.set_track_input_pair, tid, int(idx) + 1))
                cb_in.setFixedWidth(90)

                cb_out = QComboBox()
                for i in range(1, out_pairs + 1):
                    cb_out.addItem(f"Out {i}")
                try:
                    cur_out = max(1, int(getattr(t, "output_pair", 1) or 1))
                except Exception:
                    cur_out = 1
                cb_out.setCurrentIndex(max(0, min(out_pairs - 1, cur_out - 1)))
                cb_out.setToolTip("Output (Stereo-Paar) – vorbereitet für Submix/Click")
                cb_out.currentIndexChanged.connect(lambda idx, tid=t.id: self._safe_ui_call(self.project.set_track_output_pair, tid, int(idx) + 1))
                cb_out.setFixedWidth(76)

                btn_i = QToolButton()
                btn_i.setText("I")
                btn_i.setCheckable(True)
                btn_i.setChecked(bool(getattr(t, "monitor", False)))
                btn_i.setToolTip("Input Monitoring")
                btn_i.clicked.connect(lambda _=False, tid=t.id: self._safe_ui_call(self.project.set_track_monitor, tid, not self._track_mon(tid)))
                btn_i.setFixedWidth(26)
                btn_i.setAutoRaise(True)

                # Phase 3: icon for Monitoring button (safe fallback)
                try:
                    from .chrono_icons import icon as _ic
                    btn_i.setIcon(_ic("monitor", 14))
                    btn_i.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonIconOnly)
                    btn_i.setText("")
                    btn_i.setAccessibleName("I")
                except Exception:
                    pass

                lay.addWidget(cb_in)
                lay.addWidget(cb_out)
                lay.addWidget(btn_i)

            btn_m = QToolButton()
            btn_m.setText("M")
            btn_m.setCheckable(True)
            btn_m.setChecked(bool(getattr(t, "muted", False)))
            btn_m.setToolTip("Mute")
            btn_m.clicked.connect(lambda _=False, tid=t.id: self._safe_ui_call(self.project.set_track_muted, tid, not self._track_muted(tid)))

            btn_s = QToolButton()
            btn_s.setText("S")
            btn_s.setCheckable(True)
            btn_s.setChecked(bool(getattr(t, "solo", False)))
            btn_s.setToolTip("Solo")
            btn_s.clicked.connect(lambda _=False, tid=t.id: self._safe_ui_call(self.project.set_track_solo, tid, not self._track_solo(tid)))

            btn_r = QToolButton()
            btn_r.setText("R")
            btn_r.setCheckable(True)
            btn_r.setChecked(bool(getattr(t, "record_arm", False)))
            btn_r.setToolTip("Record Arm")
            btn_r.clicked.connect(lambda _=False, tid=t.id: self._safe_ui_call(self.project.set_track_record_arm, tid, not self._track_arm(tid)))

            # Phase 3: Mini-Header Icons (Arm/Mon/IO) — replace text with tiny icons (safe fallback)
            try:
                from .chrono_icons import icon as _ic
                for btn, name, txt in (
                    (btn_m, "mute", "M"),
                    (btn_s, "solo", "S"),
                    (btn_r, "rec", "R"),
                ):
                    try:
                        btn.setIcon(_ic(name, 14))
                        btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonIconOnly)
                        btn.setText("")
                        btn.setAccessibleName(txt)
                    except Exception:
                        pass
            except Exception:
                pass

            for b in (btn_m, btn_s, btn_r):
                b.setFixedWidth(26)
                b.setAutoRaise(True)

            lay.addWidget(btn_m)
            lay.addWidget(btn_s)
            lay.addWidget(btn_r)

            # Phase 2: Track-Header ▾ (Routing/Arm/Monitor/Add Device) — UI-only, additiv
            btn_menu = QToolButton()
            btn_menu.setText("▾")
            btn_menu.setToolTip("Track-Menü (Routing / Arm / Monitor / Devices)")
            btn_menu.setAutoRaise(True)
            btn_menu.setFixedWidth(24)

            # Ensure the correct track becomes selected even when clicking on the ▾ button.
            btn_menu.pressed.connect(lambda _it=it: self._safe_ui_call(self._select_item_safe, _it))

            menu = QMenu(btn_menu)
            try:
                menu.addSection(f"Track: {t.name}")
            except Exception:
                pass

            # --- Routing (audio/bus) ---
            if t.kind in ("audio", "bus"):
                m_route = menu.addMenu("Routing")

                # Input Pair
                m_in = m_route.addMenu("Input Pair")
                try:
                    cur_in_menu = max(1, int(getattr(t, "input_pair", 1) or 1))
                except Exception:
                    cur_in_menu = 1
                for pair in range(1, in_pairs + 1):
                    act = m_in.addAction(f"Stereo {pair}")
                    act.setCheckable(True)
                    act.setChecked(pair == cur_in_menu)
                    act.triggered.connect(lambda _=False, tid=t.id, _pair=pair: self._safe_ui_call(self.project.set_track_input_pair, tid, _pair))

                # Output Pair
                m_out = m_route.addMenu("Output Pair")
                try:
                    cur_out_menu = max(1, int(getattr(t, "output_pair", 1) or 1))
                except Exception:
                    cur_out_menu = 1
                for pair in range(1, out_pairs + 1):
                    act = m_out.addAction(f"Out {pair}")
                    act.setCheckable(True)
                    act.setChecked(pair == cur_out_menu)
                    act.triggered.connect(lambda _=False, tid=t.id, _pair=pair: self._safe_ui_call(self.project.set_track_output_pair, tid, _pair))

                m_route.addSeparator()
                a_mon = m_route.addAction("Monitoring (I)")
                a_mon.setCheckable(True)
                a_mon.setChecked(bool(getattr(t, "monitor", False)))
                a_mon.triggered.connect(lambda checked, tid=t.id: self._safe_ui_call(self.project.set_track_monitor, tid, bool(checked)))

            # --- Record / Mix ---
            menu.addSeparator()
            a_arm = menu.addAction("Record Arm (R)")
            a_arm.setCheckable(True)
            a_arm.setChecked(bool(getattr(t, "record_arm", False)))
            a_arm.triggered.connect(lambda checked, tid=t.id: self._safe_ui_call(self.project.set_track_record_arm, tid, bool(checked)))

            a_mute = menu.addAction("Mute (M)")
            a_mute.setCheckable(True)
            a_mute.setChecked(bool(getattr(t, "muted", False)))
            a_mute.triggered.connect(lambda checked, tid=t.id: self._safe_ui_call(self.project.set_track_muted, tid, bool(checked)))

            a_solo = menu.addAction("Solo (S)")
            a_solo.setCheckable(True)
            a_solo.setChecked(bool(getattr(t, "solo", False)))
            a_solo.triggered.connect(lambda checked, tid=t.id: self._safe_ui_call(self.project.set_track_solo, tid, bool(checked)))

            # --- Devices / Browser ---
            menu.addSeparator()
            m_dev = menu.addMenu("Devices")
            try:
                # Phase 3: Favorites/Recents (1-click insert) + searchable quick lists
                try:
                    m_dev.addSection("Quick Insert")
                except Exception:
                    pass

                relevant_kinds = []
                if t.kind == "instrument":
                    relevant_kinds = ["instrument", "note_fx", "audio_fx"]
                else:
                    relevant_kinds = ["audio_fx"]

                # --- Favorites ---
                m_fav = m_dev.addMenu("⭐ Favorites")
                fav_any = False
                for k in relevant_kinds:
                    favs = self._prefs_get("favorites", k)
                    if not favs:
                        continue
                    fav_any = True
                    try:
                        m_fav.addSection({"instrument": "Instruments", "note_fx": "Note-FX", "audio_fx": "Audio-FX"}.get(k, k))
                    except Exception:
                        pass
                    for e in favs:
                        name = getattr(e, "name", "") or getattr(e, "plugin_id", "")
                        pid = getattr(e, "plugin_id", "")
                        act = m_fav.addAction(name)
                        act.triggered.connect(
                            lambda _=False, _k=k, _pid=pid, _name=name, _tid=t.id: self._emit_add_device(str(_tid), _k, _pid, _name)
                        )
                if not fav_any:
                    a = m_fav.addAction("(keine Favorites)")
                    a.setEnabled(False)

                # Manage favorites: toggle from recents
                m_fav.addSeparator()
                m_add_from_rec = m_fav.addMenu("⭐ Add/Remove from Recents")
                for k in relevant_kinds:
                    subk = m_add_from_rec.addMenu({"instrument": "Instruments", "note_fx": "Note-FX", "audio_fx": "Audio-FX"}.get(k, k))
                    recs = self._prefs_get("recents", k)
                    if not recs:
                        a = subk.addAction("(keine Recents)")
                        a.setEnabled(False)
                        continue
                    for e in recs:
                        name = getattr(e, "name", "") or getattr(e, "plugin_id", "")
                        pid = getattr(e, "plugin_id", "")
                        act = subk.addAction(name)
                        act.setCheckable(True)
                        try:
                            p = self._prefs()
                            act.setChecked(bool(p and p.is_favorite(k, pid)))
                        except Exception:
                            pass
                        act.triggered.connect(lambda _checked=False, _k=k, _pid=pid, _name=name: self._prefs_toggle_favorite(_k, _pid, _name))

                # --- Recents ---
                m_rec = m_dev.addMenu("🕘 Recents")
                rec_any = False
                for k in relevant_kinds:
                    recs = self._prefs_get("recents", k)
                    if not recs:
                        continue
                    rec_any = True
                    try:
                        m_rec.addSection({"instrument": "Instruments", "note_fx": "Note-FX", "audio_fx": "Audio-FX"}.get(k, k))
                    except Exception:
                        pass
                    for e in recs:
                        name = getattr(e, "name", "") or getattr(e, "plugin_id", "")
                        pid = getattr(e, "plugin_id", "")
                        act = m_rec.addAction(name)
                        act.triggered.connect(
                            lambda _=False, _k=k, _pid=pid, _name=name, _tid=t.id: self._emit_add_device(str(_tid), _k, _pid, _name)
                        )
                if not rec_any:
                    a = m_rec.addAction("(keine Recents)")
                    a.setEnabled(False)
                else:
                    m_rec.addSeparator()
                    a_clear = m_rec.addAction("Clear Recents")
                    a_clear.triggered.connect(lambda _=False, _kinds=list(relevant_kinds): self._prefs_clear_recents(_kinds))

                # --- Searchable quick lists ---
                try:
                    m_dev.addSeparator()
                except Exception:
                    pass

                if "instrument" in relevant_kinds:
                    try:
                        from pydaw.plugins.registry import get_instruments
                        inst_items = []
                        for spec in get_instruments():
                            nm = f"{spec.name} — {getattr(spec, 'category', '')}".strip(" —")
                            inst_items.append((nm, str(spec.plugin_id)))
                    except Exception:
                        inst_items = []
                    self._attach_searchable_device_menu(m_dev, track_id=str(t.id), title="Add Instrument…", kind="instrument", items=inst_items)

                if "note_fx" in relevant_kinds:
                    try:
                        from .fx_specs import get_note_fx
                        nf_items = [(f"{s.name} — {s.plugin_id}", str(s.plugin_id)) for s in get_note_fx()]
                    except Exception:
                        nf_items = []
                    self._attach_searchable_device_menu(m_dev, track_id=str(t.id), title="Add Note-FX…", kind="note_fx", items=nf_items)

                if "audio_fx" in relevant_kinds:
                    try:
                        from .fx_specs import get_audio_fx
                        af_items = [(f"{s.name} — {s.plugin_id}", str(s.plugin_id)) for s in get_audio_fx()]
                    except Exception:
                        af_items = []
                    self._attach_searchable_device_menu(m_dev, track_id=str(t.id), title="Add Audio-FX…", kind="audio_fx", items=af_items)

                # --- Browser / Panels ---
                try:
                    m_dev.addSection("Browser")
                except Exception:
                    m_dev.addSeparator()
                a_add_instr = m_dev.addAction("Open Instruments (Browser)")
                a_add_fx = m_dev.addAction("Open Effects (Browser)")
                a_show_dev = m_dev.addAction("Device Panel zeigen")

                a_add_instr.triggered.connect(lambda _=False, tid=t.id: self.request_open_browser_tab.emit(str(tid), "instruments"))
                a_add_fx.triggered.connect(lambda _=False, tid=t.id: self.request_open_browser_tab.emit(str(tid), "effects"))
                a_show_dev.triggered.connect(lambda _=False, tid=t.id: self.request_show_device_panel.emit(str(tid)))

            except Exception:
                # If anything goes wrong, keep the original minimal menu (no crash).
                a_add_instr = m_dev.addAction("Add Instrument… (Browser)")
                a_add_fx = m_dev.addAction("Add FX… (Browser)")
                a_show_dev = m_dev.addAction("Device Panel zeigen")
                a_add_instr.triggered.connect(lambda _=False, tid=t.id: self.request_open_browser_tab.emit(str(tid), "instruments"))
                a_add_fx.triggered.connect(lambda _=False, tid=t.id: self.request_open_browser_tab.emit(str(tid), "effects"))
                a_show_dev.triggered.connect(lambda _=False, tid=t.id: self.request_show_device_panel.emit(str(tid)))

            # --- Track ops ---
            menu.addSeparator()
            a_rename = menu.addAction("Umbenennen…")
            a_delete = None
            if t.kind != "master":
                a_delete = menu.addAction("Track löschen")

            a_rename.triggered.connect(lambda _=False, _it=it: self._safe_ui_call(self._begin_rename_item, _it))
            if a_delete is not None:
                a_delete.triggered.connect(lambda _=False, tid=t.id: self._safe_ui_call(self.project.delete_track, str(tid)))

            btn_menu.setMenu(menu)
            btn_menu.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
            lay.addWidget(btn_menu)

            it.setSizeHint(row.sizeHint())
            self.list.addItem(it)
            self.list.setItemWidget(it, row)
            if cur_id and t.id == cur_id:
                self.list.setCurrentItem(it)

    def _track_muted(self, track_id: str) -> bool:
        trk = next((t for t in self.project.ctx.project.tracks if t.id == track_id), None)
        return bool(getattr(trk, "muted", False))

    def _track_solo(self, track_id: str) -> bool:
        trk = next((t for t in self.project.ctx.project.tracks if t.id == track_id), None)
        return bool(getattr(trk, "solo", False))

    def _track_arm(self, track_id: str) -> bool:
        trk = next((t for t in self.project.ctx.project.tracks if t.id == track_id), None)
        return bool(getattr(trk, "record_arm", False))

    def _track_mon(self, track_id: str) -> bool:
        trk = next((t for t in self.project.ctx.project.tracks if t.id == track_id), None)
        return bool(getattr(trk, "monitor", False))

    def _on_sel(self, cur, prev):  # noqa: ANN001
        if not cur:
            self.track_selected.emit("")
            return
        tid = str(cur.data(Qt.ItemDataRole.UserRole) or "")
        self.track_selected.emit(tid)
        self.selected_track_changed.emit(tid)

    def selected_track_id(self) -> str:
        it = self.list.currentItem()
        if not it:
            return ""
        return str(it.data(Qt.ItemDataRole.UserRole) or "")

    def _select_item_safe(self, item) -> None:  # noqa: ANN001
        try:
            if item is None:
                return
            self.list.setCurrentItem(item)
        except Exception:
            pass

    def _begin_rename_item(self, item) -> None:  # noqa: ANN001
        try:
            if item is None:
                return
            self.list.editItem(item)
        except Exception:
            pass


class ArrangerView(QWidget):
    clip_activated = pyqtSignal(str)
    clip_selected = pyqtSignal(str)
    request_rename_clip = pyqtSignal(str)
    request_duplicate_clip = pyqtSignal(str)
    request_delete_clip = pyqtSignal(str)
    status_message = pyqtSignal(str, int)  # (message, timeout_ms) - v0.0.19.7.0
    view_range_changed = pyqtSignal(float, float)  # start_beat, end_beat

    # Drag&Drop Overlay import: (file_path, track_id, start_beats, slot_key)
    request_import_audio_file = pyqtSignal(str, str, float, str)

    def __init__(self, project: ProjectService, parent=None):
        super().__init__(parent)
        self.project = project
        self._transport = None

        # Outer layout hosts a *horizontal splitter* so the user can resize/collapse
        # the TrackList and the Arranger view (Pro-DAW-like). This fixes the UX issue
        # where the left track area was not resizable at all.
        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        hsplit = QSplitter(Qt.Orientation.Horizontal)
        hsplit.setChildrenCollapsible(True)
        try:
            hsplit.setHandleWidth(6)
        except Exception:
            pass

        # Left side: Tracklist (collapsible)
        left_panel = QVBoxLayout()
        left_panel.setContentsMargins(0, 0, 0, 0)
        left_panel.setSpacing(4)

        self.tracks = TrackList(project)
        # Allow shrinking almost to zero (user requested)
        try:
            self.tracks.setMinimumWidth(0)
        except Exception:
            pass
        left_panel.addWidget(self.tracks, 1)

        left_container = QWidget()
        left_container.setLayout(left_panel)
        try:
            left_container.setMinimumWidth(0)
        except Exception:
            pass

        # Right side: canvas (scrollable) + automation panel in a vertical splitter
        right = QSplitter(Qt.Orientation.Vertical)

        self.canvas = ArrangerCanvas(project)
        self.canvas.clip_activated.connect(self.clip_activated.emit)
        self.canvas.clip_selected.connect(self.clip_selected.emit)
        self.canvas.request_rename_clip.connect(self.request_rename_clip.emit)
        self.canvas.request_duplicate_clip.connect(self.request_duplicate_clip.emit)
        self.canvas.request_delete_clip.connect(self.request_delete_clip.emit)
        self.canvas.status_message.connect(self.status_message.emit)  # Keyboard shortcuts (v0.0.19.7.0)

        self.scroll = QScrollArea()
        # Canvas liefert eine dynamische Mindestgröße; dadurch können
        # horizontale/vertikale Scrollbars zuverlässig erscheinen.
        self.scroll.setWidgetResizable(False)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll.setWidget(self.canvas)
        # v0.0.20.98: Enable mouse tracking on viewport so hover events
        # reach the canvas for ruler magnifier cursor (Bitwig-style zoom).
        try:
            self.scroll.setMouseTracking(True)
            self.scroll.viewport().setMouseTracking(True)
        except Exception:
            pass

        # Clip-Launcher Overlay (shown during Browser drag)
        self.clip_overlay = ClipLauncherOverlay(self.project, transport=None, parent=self.scroll.viewport())
        self.clip_overlay.setGeometry(self.scroll.viewport().rect())
        self.clip_overlay.request_import_audio.connect(self.request_import_audio_file.emit)
        self.scroll.viewport().installEventFilter(self)

        right.addWidget(self.scroll)

        # sync view range (scroll/zoom) to downstream editors (automation, etc.)
        try:
            self.scroll.horizontalScrollBar().valueChanged.connect(lambda _v: self._emit_view_range())
            self.canvas.zoom_changed.connect(lambda _ppb: self._emit_view_range())
        except Exception:
            pass

        self.automation = AutomationLanePanel(project)
        # v0.0.20.89: Enhanced Automation Editor (Bezier + FX params + AutomationManager)
        self._enhanced_automation = None
        self._automation_manager = None
        right.addWidget(self.automation)
        right.setStretchFactor(0, 4)
        right.setStretchFactor(1, 1)

        # Assemble horizontal splitter
        hsplit.addWidget(left_container)
        hsplit.addWidget(right)
        hsplit.setStretchFactor(0, 0)
        hsplit.setStretchFactor(1, 1)
        try:
            hsplit.setCollapsible(0, True)
            hsplit.setCollapsible(1, False)
        except Exception:
            pass
        try:
            # Default: readable TrackList, big arranger
            hsplit.setSizes([240, 1200])
        except Exception:
            pass

        outer.addWidget(hsplit, 1)
        self._emit_view_range()

    # ---- overlay helpers

    def set_transport(self, transport) -> None:
        self._transport = transport
        try:
            self.clip_overlay.set_transport(transport)
        except Exception:
            pass

    def set_tab_service(self, tab_service) -> None:
        """Wire ProjectTabService to canvas + track list for cross-project D&D."""
        try:
            self.canvas.set_tab_service(tab_service)
        except Exception:
            pass
        try:
            self.tracks.set_tab_service(tab_service)
        except Exception:
            pass

    def set_automation_manager(self, automation_manager) -> None:
        """Wire AutomationManager for enhanced Bezier automation editor (v0.0.20.89)."""
        self._automation_manager = automation_manager
        if _HAS_ENHANCED_AUTOMATION and automation_manager is not None:
            try:
                self._enhanced_automation = EnhancedAutomationLanePanel(
                    automation_manager, self.project, parent=self
                )
                # Find the right splitter and replace the old panel
                # The old panel's parent is a vertical QSplitter
                splitter = self.automation.parentWidget()
                if splitter is not None and hasattr(splitter, 'replaceWidget'):
                    idx = splitter.indexOf(self.automation)
                    if idx >= 0:
                        splitter.replaceWidget(idx, self._enhanced_automation)
                        self.automation.hide()
                        self._enhanced_automation.setVisible(self.automation.isVisible())
                else:
                    # Fallback: just add alongside
                    self._enhanced_automation.hide()
            except Exception:
                self._enhanced_automation = None

    def activate_clip_overlay(self, drag_label: str = "") -> None:
        try:
            self.clip_overlay.setGeometry(self.scroll.viewport().rect())
            self.clip_overlay.activate(str(drag_label or ""))
        except Exception:
            pass

    def deactivate_clip_overlay(self) -> None:
        try:
            self.clip_overlay.deactivate()
        except Exception:
            pass

    def eventFilter(self, obj, event):  # noqa: ANN001
        if obj is self.scroll.viewport() and event.type() == QEvent.Type.Resize:
            try:
                self.clip_overlay.setGeometry(self.scroll.viewport().rect())
            except Exception:
                pass
        return super().eventFilter(obj, event)

    # ---- view range

    def visible_range_beats(self) -> tuple[float, float]:
        try:
            ppb = float(getattr(self.canvas, "pixels_per_beat", 80.0)) or 80.0
            x0 = float(self.scroll.horizontalScrollBar().value())
            w = float(self.scroll.viewport().width())
            start = max(0.0, x0 / ppb)
            end = max(start + 0.25, (x0 + w) / ppb)
            return (start, end)
        except Exception:
            return (0.0, 0.0)

    def _emit_view_range(self) -> None:
        """Emit currently visible beat range based on scroll position + zoom."""
        try:
            a, b = self.visible_range_beats()
            self.view_range_changed.emit(a, b)
        except Exception:
            pass

    def resizeEvent(self, event):  # noqa: ANN001
        super().resizeEvent(event)
        self._emit_view_range()

    def set_automation_visible(self, visible: bool) -> None:
        if self._enhanced_automation is not None:
            self._enhanced_automation.setVisible(bool(visible))
        else:
            self.automation.setVisible(bool(visible))

    def set_snap_division(self, division: str) -> None:
        # map division string to beats (quarter-beat unit)
        div = str(division)
        mapping = {
            "1/4": 1.0,
            "1/8": 0.5,
            "1/16": 0.25,
            "1/32": 0.125,
            "1/64": 0.0625,
        }
        self.canvas.snap_beats = mapping.get(div, 0.25)
        self.canvas.update()
