"""Track list panel (v0.0.4).

Left side of the Arranger: track selection + quick add/remove buttons.
This is still placeholder UI; real track controls come later.
"""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QLabel,
    QMenu,
    QAbstractItemView,
)
from PyQt6.QtCore import Qt, pyqtSignal

from pydaw.services.project_service import ProjectService


class TrackListWidget(QWidget):
    selected_track_changed = pyqtSignal(str)  # track_id (empty if none)

    def __init__(self, project: ProjectService, parent=None):
        super().__init__(parent)
        self.project = project

        self._build_ui()
        self._wire()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        header = QHBoxLayout()
        header.addWidget(QLabel("Spuren"))

        self.btn_add = QPushButton("+")
        self.btn_add.setToolTip("Spur hinzufügen")
        self.btn_remove = QPushButton("–")
        self.btn_remove.setToolTip("Ausgewählte Spur entfernen")
        header.addWidget(self.btn_add)
        header.addWidget(self.btn_remove)

        layout.addLayout(header)

        self.list = QListWidget()
        self.list.setEditTriggers(QAbstractItemView.EditTrigger.DoubleClicked | QAbstractItemView.EditTrigger.EditKeyPressed)
        self.list.itemChanged.connect(self._on_item_changed)
        self.list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.list.customContextMenuRequested.connect(self._on_context_menu)
        self.list.setSelectionMode(QListWidget.SelectionMode.SingleSelection)
        
        # FIXED v0.0.19.7.9: Expliziter DoubleClick Handler für Umbenennen!
        self.list.itemDoubleClicked.connect(self._on_item_double_clicked)
        
        # FIXED v0.0.19.7.4: DEL/Entf löscht Track!
        self.list.keyPressEvent = self._on_list_key_press
        
        # Tooltip: Wie man Tracks umbenennt
        self.list.setToolTip(
            "Tracks umbenennen:\n"
            "• Doppelklick auf Track-Name\n"
            "• Rechtsklick → 'Umbenennen...'\n"
            "\n"
            "Tracks auswählen: Einfach klicken"
        )
        
        layout.addWidget(self.list, 1)
    
    def _on_item_double_clicked(self, item: QListWidgetItem) -> None:
        """FIXED v0.0.19.7.9: Expliziter DoubleClick Handler!"""
        track_id = item.data(Qt.ItemDataRole.UserRole)
        if not track_id:
            return
        
        # Find track
        trk = next((t for t in self.project.ctx.project.tracks if t.id == str(track_id)), None)
        if not trk:
            return
        
        # Don't rename master
        if getattr(trk, "kind", "") == "master":
            return
        
        # Show input dialog
        from PyQt6.QtWidgets import QInputDialog
        new_name, ok = QInputDialog.getText(
            self,
            "Track umbenennen",
            f"Neuer Name für '{trk.name}':",
            text=trk.name
        )
        
        if ok and new_name.strip():
            try:
                self.project.rename_track(str(track_id), new_name.strip())
            except Exception as e:
                print(f"[TrackList] Rename failed: {e}")

    def _wire(self) -> None:
        self.project.project_updated.connect(self.refresh)
        self.list.currentItemChanged.connect(self._on_selection_changed)
        self.btn_add.clicked.connect(self._open_add_menu)
        self.btn_remove.clicked.connect(self._remove_selected)

    def refresh(self) -> None:
        self.list.clear()
        for trk in self.project.ctx.project.tracks:
            item = QListWidgetItem(f"{trk.name}  [{trk.kind}]")
            item.setData(Qt.ItemDataRole.UserRole, trk.id)
            
            # IMPORTANT: Master track is NOT editable, all others ARE editable!
            if trk.kind == "master":
                # Remove ItemIsEditable flag from master
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            else:
                # EXPLICITLY ADD ItemIsEditable flag for all other tracks!
                # This is REQUIRED - QListWidgetItem doesn't have it by default!
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsEditable)
            
            self.list.addItem(item)

        # Keep selection if possible
        if self.list.count() > 0 and self.list.currentRow() < 0:
            self.list.setCurrentRow(0)

    def selected_track_id(self) -> str:
        item = self.list.currentItem()
        if not item:
            return ""
        return str(item.data(Qt.ItemDataRole.UserRole) or "")

    def _on_selection_changed(self) -> None:
        self.selected_track_changed.emit(self.selected_track_id())

    def _open_add_menu(self) -> None:
        menu = QMenu(self)
        a_audio = menu.addAction("Audio-Spur hinzufügen")
        a_inst = menu.addAction("Instrumenten-Spur hinzufügen")
        a_bus = menu.addAction("FX/Bus-Spur hinzufügen")
        action = menu.exec(self.btn_add.mapToGlobal(self.btn_add.rect().bottomLeft()))
        if action == a_audio:
            self.project.add_track("audio")
        elif action == a_inst:
            self.project.add_track("instrument")
        elif action == a_bus:
            self.project.add_track("bus")

    def _remove_selected(self) -> None:
        tid = self.selected_track_id()
        if not tid:
            return
        self.project.remove_track(tid)

    def _on_item_changed(self, item: QListWidgetItem) -> None:
        """Handle track name change (edit in list)."""
        track_id = item.data(Qt.ItemDataRole.UserRole)
        if not track_id:
            return
        
        # IMPORTANT: item.text() contains "Track Name  [kind]"
        # We need to extract just the track name part!
        full_text = str(item.text() or "").strip()
        if not full_text:
            return
        
        # Remove the "[kind]" suffix if present
        # Format: "Track Name  [kind]"
        if "  [" in full_text:
            name = full_text.split("  [")[0].strip()
        else:
            name = full_text.strip()
        
        if not name:
            return
        
        try:
            self.project.rename_track(str(track_id), name)
        except Exception as e:
            print(f"[TrackList] Rename failed: {e}")
            pass
    
    def _on_list_key_press(self, event) -> None:
        """Handle keyboard shortcuts in track list.
        
        FIXED v0.0.19.7.4: DEL/Entf löscht ausgewählten Track!
        """
        from PyQt6.QtGui import QKeyEvent
        
        # DEL or Backspace: Delete selected track
        if event.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            tid = self.selected_track_id()
            if tid:
                # Check if it's not master track
                trk = next((t for t in self.project.ctx.project.tracks if t.id == tid), None)
                if trk and getattr(trk, "kind", "") != "master":
                    try:
                        self.project.delete_track(tid)
                        event.accept()
                        return
                    except Exception as e:
                        print(f"[TrackList] Delete track failed: {e}")
        
        # F2: Rename (edit mode)
        elif event.key() == Qt.Key.Key_F2:
            item = self.list.currentItem()
            if item:
                self.list.editItem(item)
                event.accept()
                return
        
        # Pass to parent for default behavior
        QListWidget.keyPressEvent(self.list, event)

    def _on_context_menu(self, pos):  # noqa: ANN001
        """Handle right-click context menu on track."""
        item = self.list.itemAt(pos)
        if item is None:
            return
        track_id = item.data(Qt.ItemDataRole.UserRole)
        if not track_id:
            return
        # find kind
        trk = next((t for t in self.project.ctx.project.tracks if t.id == str(track_id)), None)
        if trk is None:
            return

        menu = QMenu(self)
        a_rename = menu.addAction("Umbenennen…")
        a_del = None
        if trk.kind != "master":
            a_del = menu.addAction("Track löschen")

        act = menu.exec(self.list.mapToGlobal(pos))
        if act == a_rename:
            self.list.editItem(item)
            return
        if a_del is not None and act == a_del:
            try:
                self.project.delete_track(str(track_id))
            except Exception:
                pass
            return
