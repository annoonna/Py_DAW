"""Installer helper for ChronoScaleStudio (Py_DAW).

Usage:
    python3 install.py

What it does:
- Warn if you're not inside a virtual environment
- Upgrade pip/setuptools/wheel
- Install requirements.txt
- On macOS: best-effort install of required system libraries via Homebrew
  (PortAudio, libsndfile, FluidSynth) for CoreAudio playback + SF2 rendering.

Notes:
- Linux JACK/PipeWire system components are not installed here (distro packages).
- This script is defensive: it tries not to fail hard if Homebrew is missing.
"""

from __future__ import annotations

import os
import sys
import subprocess
import shutil
import platform
from pathlib import Path


def _run(cmd: list[str], *, check: bool = True, env: dict | None = None) -> int:
    print(">>", " ".join(cmd))
    p = subprocess.run(cmd, check=False, env=env)
    if check and p.returncode != 0:
        raise subprocess.CalledProcessError(p.returncode, cmd)
    return int(p.returncode)


def _is_macos() -> bool:
    try:
        return (platform.system() or "").lower() == "darwin"
    except Exception:
        return False


def _brew_env() -> dict:
    env = os.environ.copy()
    # Avoid slow auto-update in scripted runs.
    env.setdefault("HOMEBREW_NO_AUTO_UPDATE", "1")
    env.setdefault("HOMEBREW_NO_INSTALL_CLEANUP", "1")
    return env


def _brew_is_installed(pkg: str) -> bool:
    brew = shutil.which("brew")
    if not brew:
        return False
    try:
        rc = _run([brew, "list", "--versions", pkg], check=False, env=_brew_env())
        return rc == 0
    except Exception:
        return False


def _brew_install(pkg: str) -> None:
    brew = shutil.which("brew")
    if not brew:
        return
    try:
        _run([brew, "install", pkg], check=False, env=_brew_env())
    except Exception as exc:
        print(f"WARN: brew install {pkg} fehlgeschlagen: {exc}")


def _ensure_macos_system_libs() -> None:
    """Best-effort install of macOS system libs needed by audio stack."""
    brew = shutil.which("brew")
    if not brew:
        print("HINWEIS (macOS): Homebrew ist nicht installiert.")
        print("  Install: https://brew.sh/  (danach erneut: python3 install.py)")
        return

    needed = [
        ("portaudio", "sounddevice (CoreAudio/PortAudio)"),
        ("libsndfile", "soundfile (WAV/FLAC decoding)"),
        ("fluidsynth", "SF2/MIDI pre-render (midi_render.py)"),
    ]

    for pkg, reason in needed:
        if _brew_is_installed(pkg):
            print(f"OK: brew {pkg} bereits installiert ({reason})")
        else:
            print(f"INFO: installiere brew {pkg} ({reason}) …")
            _brew_install(pkg)


def main() -> int:
    here = Path(__file__).resolve().parent
    req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        print("      Empfehlung: python3 -m venv myenv && source myenv/bin/activate")

    # macOS: install system deps first (best effort)
    if _is_macos():
        _ensure_macos_system_libs()

    py = sys.executable
    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"], check=False)
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    # Install Python deps
    rc = _run([py, "-m", "pip", "install", "-r", str(req)], check=False)
    if rc != 0:
        print("\nWARN: pip install -r requirements.txt ist fehlgeschlagen.")
        print("Tipp: Auf macOS können einzelne Pakete (z.B. numba/llvmlite) je nach Python-Version fehlen.")
        print("      In dem Fall: requirements.txt öffnen und problematische Zeilen temporär auskommentieren.")
        return rc

    print("\nOK. Start danach mit: python3 main.py")
    if _is_macos():
        print("macOS Tipps:")
        print("  - Metal erzwingen: PYDAW_GFX_BACKEND=metal python3 main.py")
        print("  - Fallback OpenGL: PYDAW_GFX_BACKEND=opengl python3 main.py")
        print("  - Falls Audio zickt: Audio-Einstellungen öffnen und Output neu wählen (CoreAudio).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
