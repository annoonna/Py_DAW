# Session: v0.0.20.187 — Regression-Fix: v0.0.20.176 Verhalten wiederherstellen

Siehe:
- `PROJECT_DOCS/sessions/SESSION_v0.0.20.187_REGRESSION_FIX.md`
