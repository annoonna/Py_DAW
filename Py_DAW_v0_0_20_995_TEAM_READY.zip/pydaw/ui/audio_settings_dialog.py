"""Audio settings dialog.

Goals
-----
- Let the user choose the *engine* backend (sounddevice / jack / none).
- Let the user optionally enable a *JACK client* for port visibility & routing in qpwgraph.
  This is independent from the engine backend, because many workflows want:
    - Playback via sounddevice (PortAudio)
    - Routing/recording visibility via JACK/PipeWire-JACK ports

Hard rules
----------
- Never force-switch the engine backend just because the JACK client is enabled.
- Never overwrite sounddevice device ids with empty values when backend=jack.
- Keep the dialog startable even when JACK isn't reachable.
"""

from __future__ import annotations

import os
import shutil

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from pydaw.audio.audio_engine import AudioEngine, Backend
from pydaw.core.settings import SettingsKeys
from pydaw.core.settings_store import get_value, set_value
from pydaw.services.jack_client_service import JackClientService


class AudioSettingsDialog(QDialog):
    def __init__(self, engine: AudioEngine, jack: JackClientService | None = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Audio-Einstellungen")
        self.setModal(True)

        # Wird vom MainWindow ausgewertet: nach "OK" die App automatisch neu starten
        self.restart_requested: bool = False
        self.restart_via_pw_jack: bool = False

        self.engine = engine
        self.jack = jack
        self.keys = SettingsKeys()

        self._build_ui()
        self._load()

        # Snapshot für Restart-Entscheidung
        self._orig_backend = self.cmb_backend.currentData()
        self._orig_jack_enable = bool(self.chk_jack_enable.isChecked())
        self._orig_in_pairs = int(self.spin_jack_in.value())
        self._orig_out_pairs = int(self.spin_jack_out.value())
        self._orig_monitor = bool(self.chk_jack_monitor.isChecked())

        self._refresh_lists()

        # Engine feedback -> UI
        try:
            self.engine.status.connect(self._set_status)
            self.engine.error.connect(self._on_error)
        except Exception:
            pass

    # ---------------- UI ----------------
    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        self.lbl_status = QLabel("Erkennung läuft…")
        self.lbl_status.setWordWrap(True)
        layout.addWidget(self.lbl_status)

        box = QGroupBox("Backend & Routing")
        form = QFormLayout(box)

        self.cmb_backend = QComboBox()
        self.cmb_backend.addItem("🦀 Rust (cpal — Echtzeit, kein GIL!)", "rust")
        self.cmb_backend.addItem("JACK (PipeWire bevorzugt)", "jack")
        self.cmb_backend.addItem("sounddevice (PortAudio)", "sounddevice")
        self.cmb_backend.addItem("Keins", "none")
        self.cmb_backend.currentIndexChanged.connect(self._on_backend_changed)

        self.cmb_input = QComboBox()
        self.cmb_output = QComboBox()

        form.addRow("Backend", self.cmb_backend)
        form.addRow("Input", self.cmb_input)
        form.addRow("Output", self.cmb_output)

        layout.addWidget(box)

        jack_box = QGroupBox("JACK / PipeWire-JACK (Ports)")
        jack_form = QFormLayout(jack_box)

        self.chk_jack_enable = QCheckBox("JACK Client aktivieren (PyDAW in qpwgraph sichtbar)")

        self.spin_jack_in = QSpinBox()
        self.spin_jack_in.setRange(1, 32)  # Stereo pairs
        self.spin_jack_in.setValue(1)

        self.spin_jack_out = QSpinBox()
        self.spin_jack_out.setRange(1, 32)
        self.spin_jack_out.setValue(1)

        self.chk_jack_monitor = QCheckBox("Input Monitoring (Inputs → Outputs)")

        jack_form.addRow(self.chk_jack_enable)
        jack_form.addRow("Stereo-Inputs (Paare)", self.spin_jack_in)
        jack_form.addRow("Stereo-Outputs (Paare)", self.spin_jack_out)
        jack_form.addRow(self.chk_jack_monitor)

        layout.addWidget(jack_box)

        perf = QGroupBox("Audio-Parameter (Platzhalter)")
        perf_form = QFormLayout(perf)

        # v0.0.20.68: Provide common sample-rate presets (44100/48000/…)
        # Users can still type any custom value into the spin box.
        self._sr_updating = False
        self.cmb_sr_preset = QComboBox()
        for _sr in (44100, 48000, 88200, 96000, 192000):
            self.cmb_sr_preset.addItem(f"{_sr} Hz", int(_sr))
        self.cmb_sr_preset.addItem("Custom", "custom")

        self.spin_sr = QSpinBox()
        self.spin_sr.setRange(8000, 384000)
        self.spin_sr.setSingleStep(1000)

        # v0.0.20.636: Buffer size ComboBox with standard DAW sizes (AP2 Phase 2B)
        self.cmb_buf = QComboBox()
        for bs in (64, 128, 256, 512, 1024, 2048, 4096):
            latency_ms = (bs / 48000.0) * 1000.0
            self.cmb_buf.addItem(f"{bs} ({latency_ms:.1f} ms @ 48kHz)", bs)

        sr_row = QWidget()
        sr_row_l = QHBoxLayout(sr_row)
        sr_row_l.setContentsMargins(0, 0, 0, 0)
        sr_row_l.addWidget(self.cmb_sr_preset)
        sr_row_l.addWidget(self.spin_sr)
        perf_form.addRow("Samplerate", sr_row)
        perf_form.addRow("Buffer Size", self.cmb_buf)

        try:
            self.cmb_sr_preset.currentIndexChanged.connect(self._on_sr_preset_changed)
            self.spin_sr.valueChanged.connect(self._on_sr_spin_changed)
        except Exception:
            pass

        layout.addWidget(perf)

        # --------------------------------------------------------------
        # Performance: MIDI Pre-Render options
        # --------------------------------------------------------------
        pr = QGroupBox("Performance: MIDI Pre-Render")
        pr_form = QFormLayout(pr)

        self.chk_pr_autoload = QCheckBox("Automatisch nach Projekt/Stand laden pre-rendern")
        self.chk_pr_autoload.setToolTip(
            "Rendert MIDI-Clips im Hintergrund, damit Playback nicht stottert."
        )

        self.chk_pr_show_load = QCheckBox("Fortschritt beim Auto-Pre-Render anzeigen")
        self.chk_pr_show_load.setToolTip("Zeigt einen kleinen Fortschrittsdialog beim Laden.")

        self.chk_pr_wait_play = QCheckBox("Vor Play warten, bis Pre-Render fertig ist")
        self.chk_pr_wait_play.setToolTip(
            "Wenn aktiv, startet Play erst wenn alle relevanten MIDI-Clips gerendert wurden."
        )

        self.chk_pr_show_play = QCheckBox("Fortschritt vor Play anzeigen")
        self.chk_pr_show_play.setToolTip("Zeigt einen Fortschrittsdialog, während vorgerendert wird.")

        pr_form.addRow(self.chk_pr_autoload)
        pr_form.addRow(self.chk_pr_show_load)
        pr_form.addRow(self.chk_pr_wait_play)
        pr_form.addRow(self.chk_pr_show_play)
        layout.addWidget(pr)

        # v0.0.20.704: Plugin Sandbox section (P1C + P6C)
        sbx = QGroupBox("🛡️ Plugin Sandbox (Crash-Schutz)")
        sbx_form = QFormLayout(sbx)

        self.chk_sandbox_enabled = QCheckBox(
            "Plugin Sandbox aktivieren (jedes Plugin in eigenem Prozess)")
        self.chk_sandbox_enabled.setToolTip(
            "Wenn aktiv, laufen externe Plugins (VST3/VST2/LV2/LADSPA/CLAP) "
            "in separaten Subprozessen.\n"
            "Crasht ein Plugin → nur der Worker-Prozess stirbt, "
            "die DAW läuft weiter.\n"
            "Bitwig-Style Crash-Recovery mit Auto-Restart."
        )
        sbx_form.addRow(self.chk_sandbox_enabled)

        layout.addWidget(sbx)

        # v0.0.20.983: NS5.4 — PipeWire Buffer-Size Sync
        pw_box = QGroupBox("🔧 PipeWire Synchronisation")
        pw_form = QFormLayout(pw_box)

        self.lbl_pw_status = QLabel("Wird erkannt…")
        self.lbl_pw_status.setWordWrap(True)
        pw_form.addRow("PipeWire:", self.lbl_pw_status)

        self.lbl_pw_quantum = QLabel("—")
        pw_form.addRow("Aktueller Quantum:", self.lbl_pw_quantum)

        self.lbl_pw_rate = QLabel("—")
        pw_form.addRow("Aktuelle Rate:", self.lbl_pw_rate)

        self.btn_pw_sync = QPushButton("Buffer an PipeWire anpassen")
        self.btn_pw_sync.setToolTip(
            "Setzt den PipeWire Quantum auf den gewählten Buffer-Size.\n"
            "Verhindert Buffer-Mismatch und reduziert Latenz."
        )
        self.btn_pw_sync.clicked.connect(self._on_pw_sync_clicked)
        self.btn_pw_sync.setEnabled(False)
        pw_form.addRow(self.btn_pw_sync)

        layout.addWidget(pw_box)

        # Query PipeWire status in background
        self._query_pipewire_status()

        # v0.0.20.968: Rust status label (shown in Backend section)
        self.lbl_rust_status = QLabel("Nicht verbunden")
        self.lbl_rust_status.setStyleSheet("font-weight: bold;")
        form.addRow("Rust:", self.lbl_rust_status)

        # Test-Sine button (added to test row below)
        self.btn_rust_test_sine = QPushButton("▶ Test: Sine 440Hz")
        self.btn_rust_test_sine.setToolTip(
            "Spielt einen 440Hz Sinuston über die Rust Audio Engine.\n"
            "Damit kannst du prüfen, ob Audio über Rust funktioniert."
        )
        self.btn_rust_test_sine.setCheckable(True)
        self.btn_rust_test_sine.toggled.connect(self._rust_test_sine_toggled)

        # Wire Rust bridge events
        self._rust_bridge = None
        self._rust_cpal_devices = []  # cached device list from cpal
        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            bridge = RustEngineBridge.instance()
            if bridge is not None:
                self._rust_bridge = bridge
                bridge.audio_started.connect(self._on_rust_audio_started)
                bridge.audio_stopped.connect(self._on_rust_audio_stopped)
                bridge.audio_error.connect(self._on_rust_audio_error)
                bridge.audio_device_list.connect(self._on_rust_device_list)
                bridge.audio_status_report.connect(self._on_rust_status_report)
                # Show initial connection status
                if bridge.is_connected:
                    self.lbl_rust_status.setText("✅ Rust-Engine verbunden")
                    self.lbl_rust_status.setStyleSheet("font-weight: bold; color: green;")
                    # Query current audio status
                    bridge.audio_status()
                else:
                    # v0.0.20.979: Auto-start Rust engine when Rust backend is selected
                    if self.cmb_backend.currentData() == "rust":
                        self.lbl_rust_status.setText("⏳ Verbinde Rust-Engine...")
                        self.lbl_rust_status.setStyleSheet("font-weight: bold; color: orange;")
                        from PyQt6.QtCore import QTimer
                        QTimer.singleShot(100, self._ensure_rust_engine_running)
                    else:
                        self.lbl_rust_status.setText(
                            "Nicht verbunden — wähle 'Rust' als Backend"
                        )
        except Exception:
            pass

        row = QHBoxLayout()
        self.btn_start = QPushButton("Test: Start (Silence)")
        self.btn_stop = QPushButton("Stop")
        self.btn_stop.setEnabled(True)

        self.btn_start.clicked.connect(self._start_audio)
        self.btn_stop.clicked.connect(self.engine.stop)

        row.addWidget(self.btn_rust_test_sine)
        row.addWidget(self.btn_start)
        row.addWidget(self.btn_stop)
        row.addStretch(1)
        layout.addLayout(row)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        self._buttons = buttons
        self._btn_ok = buttons.button(QDialogButtonBox.StandardButton.Ok)
        layout.addWidget(buttons)

    # v0.0.20.983: NS5.4 — PipeWire Buffer-Size Sync methods

    def _query_pipewire_status(self) -> None:
        """Query PipeWire quantum/rate in background thread."""
        import threading

        def _run():
            try:
                from pydaw.services.pipewire_monitor import PipeWireMonitor
                pw = PipeWireMonitor.instance()
                info = pw.query()
                # Schedule UI update on main thread
                try:
                    from PyQt6.QtCore import QTimer
                    QTimer.singleShot(0, lambda: self._update_pw_ui(info))
                except Exception:
                    pass
            except Exception:
                pass

        threading.Thread(target=_run, daemon=True, name="pw-query-dialog").start()

    def _update_pw_ui(self, info) -> None:
        """Update PipeWire UI elements with query results."""
        try:
            if not info.available:
                self.lbl_pw_status.setText("❌ PipeWire nicht erkannt")
                self.lbl_pw_quantum.setText("—")
                self.lbl_pw_rate.setText("—")
                self.btn_pw_sync.setEnabled(False)
                return

            self.lbl_pw_status.setText("✅ PipeWire aktiv")
            self.lbl_pw_quantum.setText(f"{info.quantum} Samples")
            self.lbl_pw_rate.setText(f"{info.rate} Hz")
            self.btn_pw_sync.setEnabled(True)

            # Check mismatch
            try:
                requested_buf = self.cmb_buf.currentData()
                if requested_buf and info.quantum != requested_buf:
                    ratio = info.quantum / requested_buf if requested_buf else 1
                    if ratio > 4 or ratio < 0.25:
                        self.lbl_pw_quantum.setText(
                            f"⚠️ {info.quantum} Samples (MISMATCH! "
                            f"DAW: {requested_buf})"
                        )
                        self.lbl_pw_quantum.setStyleSheet(
                            "color: #ff6e40; font-weight: bold;"
                        )
                    else:
                        self.lbl_pw_quantum.setText(
                            f"{info.quantum} Samples (DAW: {requested_buf})"
                        )
            except Exception:
                pass
        except Exception:
            pass

    def _on_pw_sync_clicked(self) -> None:
        """Sync PipeWire quantum to match DAW buffer size."""
        try:
            from pydaw.services.pipewire_monitor import PipeWireMonitor
            pw = PipeWireMonitor.instance()

            buf = self.cmb_buf.currentData()
            sr = self.spin_sr.value()

            if buf:
                ok = pw.set_quantum(int(buf))
                if ok:
                    self.lbl_pw_status.setText(
                        f"✅ PipeWire Quantum → {buf} gesetzt"
                    )
                    self.lbl_pw_quantum.setText(f"{buf} Samples ✅")
                    self.lbl_pw_quantum.setStyleSheet("")
                else:
                    self.lbl_pw_status.setText(
                        "⚠️ Konnte PipeWire Quantum nicht setzen"
                    )
        except Exception as e:
            self.lbl_pw_status.setText(f"Fehler: {e}")

    def _on_sr_preset_changed(self) -> None:
        if getattr(self, "_sr_updating", False):
            return
        try:
            data = self.cmb_sr_preset.currentData()
            if isinstance(data, int):
                self._sr_updating = True
                self.spin_sr.setValue(int(data))
        finally:
            self._sr_updating = False

    def _on_sr_spin_changed(self) -> None:
        if getattr(self, "_sr_updating", False):
            return
        try:
            sr = int(self.spin_sr.value())
            # Select matching preset, otherwise fall back to "Custom".
            idx_custom = self.cmb_sr_preset.findData("custom")
            idx_match = self.cmb_sr_preset.findData(sr)
            self._sr_updating = True
            if idx_match >= 0:
                self.cmb_sr_preset.setCurrentIndex(idx_match)
            elif idx_custom >= 0:
                self.cmb_sr_preset.setCurrentIndex(idx_custom)
        finally:
            self._sr_updating = False

    def _set_status(self, msg: str) -> None:
        try:
            self.lbl_status.setText(str(msg))
        except Exception:
            pass

    def _on_error(self, msg: str) -> None:
        try:
            QMessageBox.warning(self, "Audio-Fehler", str(msg))
        except Exception:
            pass

    # ---------------- Logic ----------------
    def _on_backend_changed(self) -> None:
        """Backend dropdown changed.

        UX:
        - JACK port controls remain usable independent of the engine backend.
        - We do not force backend changes.
        """
        backend: Backend = self.cmb_backend.currentData()

        # JACK controls always usable (for routing/recording visibility)
        for w in (self.chk_jack_enable, self.spin_jack_in, self.spin_jack_out, self.chk_jack_monitor):
            try:
                w.setEnabled(True)
            except Exception:
                pass

        if backend == "rust":
            self._set_status(
                "🦀 Rust Audio (cpal) — Audio läuft direkt in Rust, kein GIL-Problem. "
                "Python macht nur noch GUI."
            )
            # Auto-start Rust engine to enumerate devices
            if self._rust_bridge and not self._rust_bridge.is_connected:
                self._ensure_rust_engine_running()
        elif backend == "sounddevice":
            self._set_status(
                "sounddevice aktiv. JACK/PipeWire-JACK Ports sind optional (Recording/Routing) "
                "und ändern das Backend NICHT."
            )
        elif backend == "jack":
            if not JackClientService.probe_available():
                self._set_status(
                    "JACK nicht erreichbar. Start ggf. mit 'pw-jack python3 main.py' "
                    "oder stelle sicher, dass PipeWire-JACK/JACK läuft."
                )
        else:
            self._set_status("Kein Backend ausgewählt.")

        self._refresh_lists()

    def _refresh_lists(self) -> None:
        backend: Backend = self.cmb_backend.currentData()

        jack_ok = True
        if backend == "jack":
            jack_ok = JackClientService.probe_available()

        self.cmb_input.clear()
        self.cmb_output.clear()

        # Rust: devices come from cpal via the Rust engine
        if backend == "rust":
            self.cmb_input.addItem("(Rust: kein separater Input nötig)", "")
            self.cmb_input.setEnabled(False)
            self.cmb_output.setEnabled(True)
            # Populate with cached cpal devices if available
            if self._rust_cpal_devices:
                for d in self._rust_cpal_devices:
                    name = d.get("name", "Unknown")
                    is_default = d.get("is_default", False)
                    rates = d.get("sample_rates", [])
                    suffix = " ⭐" if is_default else ""
                    rate_info = "/".join(str(r // 1000) + "k" for r in rates[:3])
                    label = f"{name}{suffix} ({rate_info})" if rate_info else f"{name}{suffix}"
                    self.cmb_output.addItem(label, name)
            else:
                self.cmb_output.addItem("(Standard-Gerät)", "")
                # Request device list ONCE (not on every callback!)
                if self._rust_bridge and self._rust_bridge.is_connected:
                    self._rust_bridge.enumerate_audio_devices()
            return

        # JACK: routing via ports; device ids are not meaningful.
        if backend == "jack" and not jack_ok:
            self.cmb_input.addItem("(JACK Ports: über qpwgraph routen)", "")
            self.cmb_output.addItem("(JACK Ports: über qpwgraph routen)", "")
            self.cmb_input.setEnabled(False)
            self.cmb_output.setEnabled(False)
            return

        self.cmb_input.setEnabled(True)
        self.cmb_output.setEnabled(True)

        inputs = self.engine.list_inputs(backend)
        outputs = self.engine.list_outputs(backend)

        for ep in inputs:
            self.cmb_input.addItem(ep.label, ep.id)
        for ep in outputs:
            self.cmb_output.addItem(ep.label, ep.id)

        if self.cmb_input.count() == 0:
            self.cmb_input.addItem("(keine Inputs gefunden)", "")
        if self.cmb_output.count() == 0:
            self.cmb_output.addItem("(keine Outputs gefunden)", "")

        # Restore selection
        if backend in ("sounddevice", "rust"):
            saved_out = str(get_value(self.keys.audio_output, ""))
            self._select_if_present(self.cmb_output, saved_out)
        if backend == "sounddevice":
            saved_in = str(get_value(self.keys.audio_input, ""))
            self._select_if_present(self.cmb_input, saved_in)

    @staticmethod
    def _select_if_present(cmb: QComboBox, data: str) -> None:
        if not data:
            return
        for i in range(cmb.count()):
            if str(cmb.itemData(i)) == str(data):
                cmb.setCurrentIndex(i)
                return

    def _load(self) -> None:
        saved_backend = str(get_value(self.keys.audio_backend, getattr(self.engine, "backend", "sounddevice")))
        self._select_if_present(self.cmb_backend, saved_backend)

        # JACK client preferences
        en = str(get_value(self.keys.jack_enable, "0"))
        self.chk_jack_enable.setChecked(en.lower() in ("1", "true", "yes", "on"))

        in_ch = int(get_value(self.keys.jack_in_ports, 2))
        out_ch = int(get_value(self.keys.jack_out_ports, 2))
        self.spin_jack_in.setValue(max(1, (in_ch + 1) // 2))
        self.spin_jack_out.setValue(max(1, (out_ch + 1) // 2))

        mon = str(get_value(self.keys.jack_input_monitor, "0"))
        self.chk_jack_monitor.setChecked(mon.lower() in ("1", "true", "yes", "on"))

        sr = int(get_value(self.keys.sample_rate, 48000))
        buf = int(get_value(self.keys.buffer_size, 256))
        self.spin_sr.setValue(sr)
        # v0.0.20.636: Buffer size ComboBox
        for i in range(self.cmb_buf.count()):
            if self.cmb_buf.itemData(i) == buf:
                self.cmb_buf.setCurrentIndex(i)
                break

        # Pre-render defaults: enabled (autoload + wait + progress) for smoother UX
        def _b(key: str, default: bool) -> bool:
            v = str(get_value(key, "1" if default else "0")).strip().lower()
            return v in ("1", "true", "yes", "on")

        self.chk_pr_autoload.setChecked(_b(self.keys.prerender_auto_on_load, True))
        self.chk_pr_show_load.setChecked(_b(self.keys.prerender_show_progress_on_load, False))
        self.chk_pr_wait_play.setChecked(_b(self.keys.prerender_wait_before_play, False))  # FIXED: Default FALSE!
        self.chk_pr_show_play.setChecked(_b(self.keys.prerender_show_progress_on_play, True))

        # v0.0.20.704: Plugin Sandbox (P1C)
        self.chk_sandbox_enabled.setChecked(
            _b(self.keys.audio_plugin_sandbox_enabled, False))

    # ---------------- Actions ----------------
    def accept(self) -> None:
        backend: Backend = self.cmb_backend.currentData()

        # Persist device ids
        if backend == "sounddevice":
            set_value(self.keys.audio_input, self.cmb_input.currentData())
            set_value(self.keys.audio_output, self.cmb_output.currentData())
        elif backend == "rust":
            # Save selected Rust output device
            set_value(self.keys.audio_output, self.cmb_output.currentData() or "")

        set_value(self.keys.sample_rate, int(self.spin_sr.value()))
        set_value(self.keys.buffer_size, int(self.cmb_buf.currentData() or 256))
        set_value(self.keys.audio_backend, backend)

        # v0.0.20.979: Sync backend to AudioEngine so Play uses the right backend
        try:
            self.engine.set_backend(backend)
        except Exception:
            pass

        # MIDI Pre-Render preferences
        set_value(self.keys.prerender_auto_on_load, "1" if self.chk_pr_autoload.isChecked() else "0")
        set_value(self.keys.prerender_show_progress_on_load, "1" if self.chk_pr_show_load.isChecked() else "0")
        set_value(self.keys.prerender_wait_before_play, "1" if self.chk_pr_wait_play.isChecked() else "0")
        set_value(self.keys.prerender_show_progress_on_play, "1" if self.chk_pr_show_play.isChecked() else "0")

        # JACK client preferences (independent of backend)
        jack_enabled = bool(self.chk_jack_enable.isChecked())
        jack_in_pairs = int(self.spin_jack_in.value())
        jack_out_pairs = int(self.spin_jack_out.value())
        jack_in = jack_in_pairs * 2
        jack_out = jack_out_pairs * 2
        jack_monitor = bool(self.chk_jack_monitor.isChecked())

        set_value(self.keys.jack_enable, "1" if jack_enabled else "0")
        set_value(self.keys.jack_in_ports, jack_in)
        set_value(self.keys.jack_out_ports, jack_out)
        set_value(self.keys.jack_input_monitor, "1" if jack_monitor else "0")

        # v0.0.20.704: Plugin Sandbox (P1C)
        set_value(self.keys.audio_plugin_sandbox_enabled,
                  "1" if self.chk_sandbox_enabled.isChecked() else "0")

        # For services created in this process
        try:
            os.environ["PYDAW_ENABLE_JACK"] = "1" if jack_enabled else "0"
            os.environ["PYDAW_JACK_IN"] = str(jack_in)
            os.environ["PYDAW_JACK_OUT"] = str(jack_out)
            os.environ["PYDAW_JACK_MONITOR"] = "1" if jack_monitor else "0"
            # Do NOT touch PYDAW_AUDIO_BACKEND here.
        except Exception:
            pass

        # Apply JACK client config in-process when possible
        if self.jack is not None:
            try:
                self.jack.apply_config(enabled=jack_enabled, in_ch=jack_in, out_ch=jack_out, monitor=jack_monitor)
            except Exception:
                pass

        backend_changed = (backend != self._orig_backend)
        jack_changed = (
            (jack_enabled != self._orig_jack_enable)
            or (jack_in_pairs != self._orig_in_pairs)
            or (jack_out_pairs != self._orig_out_pairs)
            or (jack_monitor != self._orig_monitor)
        )

        # Backend change -> restart recommended
        if backend_changed:
            self.restart_requested = True

        # v0.0.20.721: Notify Rust Engine of new audio settings (live reconfigure)
        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            if RustEngineBridge.is_enabled():
                bridge = RustEngineBridge.instance()
                if bridge.is_connected:
                    new_sr = int(self.spin_sr.value())
                    new_buf = int(self.cmb_buf.currentData() or 1024)
                    bridge.send_command({
                        "cmd": "Configure",
                        "sample_rate": new_sr,
                        "buffer_size": new_buf,
                        "device": "",
                    })
        except Exception:
            pass  # Rust not available — no problem

        # If JACK enabled changed and JACK isn't reachable: offer pw-jack relaunch
        if jack_changed and jack_enabled and (not JackClientService.probe_available()):
            if shutil.which("pw-jack") and os.environ.get("PYDAW_PWJACK", "0") != "1":
                self.restart_via_pw_jack = True
                self.restart_requested = True

        # v0.0.20.964: Rust backend — stop Python audio, start Rust cpal
        if backend == "rust":
            # Stop the Python audio engine (sounddevice/JACK)
            try:
                self.engine.stop()
            except Exception:
                pass
            # Start Rust audio with device from the MAIN Output dropdown
            self._ensure_rust_engine_running()
            if self._rust_bridge and self._rust_bridge.is_connected:
                sr = int(self.spin_sr.value())
                buf = int(self.cmb_buf.currentData() or 256)
                device = self.cmb_output.currentData() or ""
                self._rust_bridge.audio_start(
                    device=device, sample_rate=sr, buffer_size=buf,
                )
            self.restart_requested = False  # No restart needed — we're already live
        elif self._orig_backend == "rust" and backend != "rust":
            # Switching away from Rust — stop Rust audio
            if self._rust_bridge and self._rust_bridge.is_connected:
                self._rust_bridge.audio_stop()

        super().accept()

    # -------------- Rust Audio Output (v0.0.20.959) ---------------

    def _rust_enumerate_devices(self) -> None:
        """Request device list from Rust/cpal."""
        if self._rust_bridge is not None:
            if not self._rust_bridge.is_connected:
                self._ensure_rust_engine_running()
            self._rust_bridge.enumerate_audio_devices()

    def _rust_test_sine_toggled(self, checked: bool) -> None:
        """Start/stop 440Hz test sine through Rust audio."""
        if self._rust_bridge is not None:
            if checked and not self._rust_bridge.is_connected:
                self._ensure_rust_engine_running()
            self._rust_bridge.audio_test_sine(enabled=checked)
            if checked:
                self.btn_rust_test_sine.setText("■ Test stoppen")
            else:
                self.btn_rust_test_sine.setText("▶ Test: Sine 440Hz")

    def _rust_audio_start(self) -> None:
        """Start Rust audio output with current settings."""
        if self._rust_bridge is None:
            return
        if not self._rust_bridge.is_connected:
            self._ensure_rust_engine_running()
        sr = int(self.spin_sr.value())
        buf = int(self.cmb_buf.currentData() or 256)
        device = self.cmb_output.currentData() or ""
        self._rust_bridge.audio_start(
            device=device,
            sample_rate=sr,
            buffer_size=buf,
        )

    def _ensure_rust_engine_running(self) -> None:
        """Start the Rust engine subprocess if not already running."""
        bridge = self._rust_bridge
        if bridge is None:
            return
        if bridge.is_connected:
            return

        self.lbl_rust_status.setText("⏳ Starte Rust-Engine...")
        self.lbl_rust_status.setStyleSheet("font-weight: bold; color: orange;")

        # Force Qt to repaint before blocking
        from PyQt6.QtWidgets import QApplication
        QApplication.processEvents()

        try:
            sr = int(self.spin_sr.value())
            buf = int(self.cmb_buf.currentData() or 256)
            ok = bridge.start_engine(sample_rate=sr, buffer_size=buf)
            if ok:
                self.lbl_rust_status.setText("✅ Rust-Engine verbunden")
                self.lbl_rust_status.setStyleSheet("font-weight: bold; color: green;")
            else:
                self.lbl_rust_status.setText("❌ Rust-Engine konnte nicht gestartet werden")
                self.lbl_rust_status.setStyleSheet("font-weight: bold; color: red;")
        except Exception as e:
            self.lbl_rust_status.setText(f"❌ Fehler: {e}")
            self.lbl_rust_status.setStyleSheet("font-weight: bold; color: red;")

    def _rust_audio_stop(self) -> None:
        """Stop Rust audio output."""
        if self._rust_bridge is not None:
            self._rust_bridge.audio_stop()
            self.btn_rust_test_sine.setChecked(False)

    def _on_rust_audio_started(self, device_name: str, sr: int,
                                buf: int, latency_ms: float) -> None:
        """Handle AudioStarted event from Rust."""
        self.lbl_rust_status.setText(
            f"✅ Aktiv — {device_name} | {sr}Hz | {buf} Samples | "
            f"{latency_ms:.1f}ms Latenz"
        )
        self.lbl_rust_status.setStyleSheet("font-weight: bold; color: green;")

    def _on_rust_audio_stopped(self) -> None:
        """Handle AudioStopped event from Rust."""
        self.lbl_rust_status.setText("Gestoppt")
        self.lbl_rust_status.setStyleSheet("font-weight: bold; color: gray;")
        self.btn_rust_test_sine.setChecked(False)

    def _on_rust_audio_error(self, message: str) -> None:
        """Handle AudioError event from Rust."""
        self.lbl_rust_status.setText(f"❌ Fehler: {message}")
        self.lbl_rust_status.setStyleSheet("font-weight: bold; color: red;")

    def _on_rust_device_list(self, devices: list) -> None:
        """Handle AudioDeviceList event from Rust."""
        self._rust_cpal_devices = devices
        # Update main Output dropdown if Rust backend is active
        # (directly, NOT via _refresh_lists to avoid infinite loop)
        backend = self.cmb_backend.currentData()
        if backend == "rust":
            self.cmb_output.clear()
            for d in devices:
                name = d.get("name", "Unknown")
                is_default = d.get("is_default", False)
                rates = d.get("sample_rates", [])
                suffix = " ⭐" if is_default else ""
                rate_info = "/".join(str(r // 1000) + "k" for r in rates[:3])
                label = f"{name}{suffix} ({rate_info})" if rate_info else f"{name}{suffix}"
                self.cmb_output.addItem(label, name)

    def _on_rust_status_report(self, status: dict) -> None:
        """Handle AudioStatusReport event from Rust."""
        if status.get("is_active", False):
            dev = status.get("device_name", "?")
            sr = status.get("sample_rate", 0)
            buf = status.get("buffer_size", 0)
            xruns = status.get("xrun_count", 0)
            cpu = status.get("cpu_load", 0.0)
            lat_ms = (buf / sr * 1000) if sr > 0 else 0
            # v0.0.20.979: Show actual hardware buffer (cpal may choose differently)
            requested_buf = int(self.cmb_buf.currentData() or 0)
            buf_info = f"{buf}buf"
            if requested_buf > 0 and requested_buf != buf:
                buf_info = f"{buf}buf (HW, angefordert: {requested_buf})"
            self.lbl_rust_status.setText(
                f"✅ {dev} | {sr}Hz | {buf_info} | {lat_ms:.1f}ms | "
                f"CPU: {cpu * 100:.0f}% | XRuns: {xruns}"
            )
            self.lbl_rust_status.setStyleSheet("font-weight: bold; color: green;")
        else:
            self.lbl_rust_status.setText("Nicht aktiv")
            self.lbl_rust_status.setStyleSheet("font-weight: bold; color: gray;")

    # -------------- Python Audio Test ---------------

    def _start_audio(self) -> None:
        backend: Backend = self.cmb_backend.currentData()
        cfg = {
            "sample_rate": int(self.spin_sr.value()),
            "buffer_size": int(self.cmb_buf.currentData() or 256),
            "input_device": self.cmb_input.currentData(),
            "output_device": self.cmb_output.currentData(),
        }
        try:
            self.engine.set_backend(backend)
        except Exception:
            pass
        self.engine.start(backend=backend, config=cfg)
