-- Py_DAW Schema Migration v1: Initial Schema (25 tables, 12 indexes)

CREATE TABLE IF NOT EXISTS project (
    id TEXT PRIMARY KEY, name TEXT NOT NULL,
    bpm REAL NOT NULL DEFAULT 120.0,
    time_sig_num INTEGER NOT NULL DEFAULT 4, time_sig_den INTEGER NOT NULL DEFAULT 4,
    sample_rate INTEGER NOT NULL DEFAULT 44100,
    created TEXT NOT NULL, modified TEXT NOT NULL, version TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tracks (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL,
    track_index INTEGER NOT NULL,
    color TEXT NOT NULL DEFAULT '#6496C8FF',
    volume REAL NOT NULL DEFAULT 1.0, pan REAL NOT NULL DEFAULT 0.0,
    mute INTEGER NOT NULL DEFAULT 0, solo INTEGER NOT NULL DEFAULT 0,
    armed INTEGER NOT NULL DEFAULT 0, visible INTEGER NOT NULL DEFAULT 1,
    height INTEGER NOT NULL DEFAULT 80, group_id TEXT,
    FOREIGN KEY (group_id) REFERENCES tracks(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS clips (
    id TEXT PRIMARY KEY, track_id TEXT NOT NULL, kind TEXT NOT NULL,
    name TEXT NOT NULL, color TEXT NOT NULL DEFAULT '#6496C8FF',
    start_beat REAL NOT NULL, length_beats REAL NOT NULL,
    offset_beats REAL NOT NULL DEFAULT 0.0,
    gain REAL NOT NULL DEFAULT 1.0,
    fade_in_beats REAL NOT NULL DEFAULT 0.0, fade_out_beats REAL NOT NULL DEFAULT 0.0,
    fade_in_curve TEXT NOT NULL DEFAULT 'linear', fade_out_curve TEXT NOT NULL DEFAULT 'linear',
    muted INTEGER NOT NULL DEFAULT 0, locked INTEGER NOT NULL DEFAULT 0, group_id TEXT,
    audio_file TEXT, audio_channels INTEGER, audio_sample_rate INTEGER,
    warp_enabled INTEGER NOT NULL DEFAULT 0,
    video_file TEXT, video_in_point REAL, video_out_point REAL,
    video_speed REAL DEFAULT 1.0, video_opacity REAL DEFAULT 1.0,
    video_blend_mode TEXT DEFAULT 'normal',
    FOREIGN KEY (track_id) REFERENCES tracks(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS midi_notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    clip_id TEXT NOT NULL, pitch INTEGER NOT NULL, velocity INTEGER NOT NULL,
    start_beat REAL NOT NULL, length_beats REAL NOT NULL,
    channel INTEGER NOT NULL DEFAULT 0,
    pressure REAL, slide REAL, pitch_bend REAL,
    FOREIGN KEY (clip_id) REFERENCES clips(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS midi_ccs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    clip_id TEXT NOT NULL, cc INTEGER NOT NULL, value INTEGER NOT NULL,
    beat REAL NOT NULL, channel INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (clip_id) REFERENCES clips(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS automation_lanes (
    id TEXT PRIMARY KEY, track_id TEXT NOT NULL,
    param_id TEXT NOT NULL, param_name TEXT NOT NULL,
    default_value REAL NOT NULL DEFAULT 0.5,
    min_value REAL NOT NULL DEFAULT 0.0, max_value REAL NOT NULL DEFAULT 1.0,
    visible INTEGER NOT NULL DEFAULT 1, height INTEGER NOT NULL DEFAULT 60,
    FOREIGN KEY (track_id) REFERENCES tracks(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS automation_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lane_id TEXT NOT NULL, beat REAL NOT NULL, value REAL NOT NULL,
    curve_type TEXT NOT NULL DEFAULT 'linear',
    cp1_x REAL NOT NULL DEFAULT 0.0, cp1_y REAL NOT NULL DEFAULT 0.0,
    cp2_x REAL NOT NULL DEFAULT 0.0, cp2_y REAL NOT NULL DEFAULT 0.0,
    FOREIGN KEY (lane_id) REFERENCES automation_lanes(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS fx_slots (
    id TEXT PRIMARY KEY, track_id TEXT NOT NULL, slot_index INTEGER NOT NULL,
    plugin_id TEXT NOT NULL, plugin_name TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1, wet_dry REAL NOT NULL DEFAULT 1.0,
    preset_name TEXT,
    FOREIGN KEY (track_id) REFERENCES tracks(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS fx_params (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slot_id TEXT NOT NULL, param_key TEXT NOT NULL, param_value REAL NOT NULL,
    FOREIGN KEY (slot_id) REFERENCES fx_slots(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS sends (
    id TEXT PRIMARY KEY, source_track_id TEXT NOT NULL, target_track_id TEXT NOT NULL,
    gain REAL NOT NULL DEFAULT 1.0, pan REAL NOT NULL DEFAULT 0.0,
    pre_fader INTEGER NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 1,
    FOREIGN KEY (source_track_id) REFERENCES tracks(id) ON DELETE CASCADE,
    FOREIGN KEY (target_track_id) REFERENCES tracks(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS tempo_changes (
    id INTEGER PRIMARY KEY AUTOINCREMENT, beat REAL NOT NULL, bpm REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS time_sig_changes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    beat REAL NOT NULL, numerator INTEGER NOT NULL, denominator INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS warp_markers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    clip_id TEXT NOT NULL, beat REAL NOT NULL, sample_pos INTEGER NOT NULL,
    FOREIGN KEY (clip_id) REFERENCES clips(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS video_filters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    clip_id TEXT NOT NULL, filter_index INTEGER NOT NULL,
    filter_type TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1,
    FOREIGN KEY (clip_id) REFERENCES clips(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS video_filter_params (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filter_id INTEGER NOT NULL, param_key TEXT NOT NULL, param_value REAL NOT NULL,
    FOREIGN KEY (filter_id) REFERENCES video_filters(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS video_transitions (
    id TEXT PRIMARY KEY, track_id TEXT NOT NULL,
    position_beat REAL NOT NULL, duration_beats REAL NOT NULL,
    transition_type TEXT NOT NULL, params TEXT,
    FOREIGN KEY (track_id) REFERENCES tracks(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS plugin_cache (
    plugin_path TEXT PRIMARY KEY, plugin_id TEXT NOT NULL, plugin_name TEXT NOT NULL,
    vendor TEXT, category TEXT, format TEXT NOT NULL,
    num_inputs INTEGER NOT NULL DEFAULT 0, num_outputs INTEGER NOT NULL DEFAULT 0,
    has_gui INTEGER NOT NULL DEFAULT 0, scan_time TEXT NOT NULL, file_hash TEXT
);
CREATE TABLE IF NOT EXISTS presets (
    id TEXT PRIMARY KEY, plugin_id TEXT NOT NULL, name TEXT NOT NULL,
    category TEXT, tags TEXT, is_factory INTEGER NOT NULL DEFAULT 0,
    data BLOB, created TEXT NOT NULL, modified TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS midi_mappings (
    id TEXT PRIMARY KEY, device_name TEXT NOT NULL,
    cc_number INTEGER NOT NULL, channel INTEGER NOT NULL DEFAULT 0,
    target_param TEXT NOT NULL, target_track TEXT,
    min_value REAL NOT NULL DEFAULT 0.0, max_value REAL NOT NULL DEFAULT 1.0
);
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY, value TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'general'
);
CREATE TABLE IF NOT EXISTS time_travel_journal (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL, action_type TEXT NOT NULL,
    description TEXT, snapshot BLOB, tags TEXT
);
CREATE TABLE IF NOT EXISTS sentinel_anomalies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL, severity TEXT NOT NULL,
    category TEXT NOT NULL, message TEXT NOT NULL, metrics TEXT
);
CREATE INDEX IF NOT EXISTS idx_clips_track ON clips(track_id);
CREATE INDEX IF NOT EXISTS idx_clips_start ON clips(start_beat);
CREATE INDEX IF NOT EXISTS idx_midi_notes_clip ON midi_notes(clip_id);
CREATE INDEX IF NOT EXISTS idx_automation_points_lane ON automation_points(lane_id);
CREATE INDEX IF NOT EXISTS idx_fx_params_slot ON fx_params(slot_id);
CREATE INDEX IF NOT EXISTS idx_video_filters_clip ON video_filters(clip_id);
CREATE INDEX IF NOT EXISTS idx_presets_plugin ON presets(plugin_id);
CREATE INDEX IF NOT EXISTS idx_sentinel_ts ON sentinel_anomalies(timestamp);
CREATE INDEX IF NOT EXISTS idx_journal_ts ON time_travel_journal(timestamp);
