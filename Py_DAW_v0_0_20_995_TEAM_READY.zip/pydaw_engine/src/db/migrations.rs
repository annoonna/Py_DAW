// ============================================================================
// Database Schema Migrations — v0.0.20.971 (RM1.2)
// ============================================================================

use rusqlite::{Connection, params};
use log::info;
use super::DbResult;
use super::DbError;

/// Run all pending migrations
pub fn run_migrations(conn: &Connection) -> DbResult<()> {
    conn.execute_batch(
        "CREATE TABLE IF NOT EXISTS schema_info (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );"
    )?;

    let current = get_schema_version(conn)?;
    let target = MIGRATIONS.len() as u32;

    if current >= target {
        return Ok(());
    }

    for version in current..target {
        info!("Applying migration v{} → v{}...", version, version + 1);
        conn.execute_batch(MIGRATIONS[version as usize])?;
        set_schema_version(conn, version + 1)?;
    }

    info!("Migrations complete. Schema version: {}", target);
    Ok(())
}

fn get_schema_version(conn: &Connection) -> DbResult<u32> {
    match conn.query_row(
        "SELECT value FROM schema_info WHERE key = 'schema_version'",
        [], |row| { let v: String = row.get(0)?; Ok(v.parse::<u32>().unwrap_or(0)) },
    ) {
        Ok(v) => Ok(v),
        Err(rusqlite::Error::QueryReturnedNoRows) => Ok(0),
        Err(e) => Err(DbError::Sqlite(e)),
    }
}

fn set_schema_version(conn: &Connection, version: u32) -> DbResult<()> {
    conn.execute(
        "INSERT OR REPLACE INTO schema_info (key, value) VALUES ('schema_version', ?1)",
        params![version.to_string()],
    )?;
    Ok(())
}

const MIGRATIONS: &[&str] = &[
    // v0 → v1: Full initial schema
    include_str!("migration_v1.sql"),
];
