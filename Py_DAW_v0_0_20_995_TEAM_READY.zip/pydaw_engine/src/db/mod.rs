// ============================================================================
// Py_DAW Database Layer — v0.0.20.971 (RM1.2 + RM1.3)
// ============================================================================
//
// Unified SQLite database using rusqlite. Replaces all 19 Python DB files.
//
// Architecture:
//   - Single DB file per project (project.db)
//   - WAL mode for concurrent reads + single writer
//   - Versioned schema migrations
//   - Thread-safe via Mutex (NOT used in audio thread!)
// ============================================================================

pub mod project_db;
pub mod migrations;

use log::{info, warn, error};
use rusqlite::{Connection, params};
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};

/// Database manager — owns the connection and handles migrations
pub struct DatabaseManager {
    db_path: PathBuf,
    conn: Option<Arc<Mutex<Connection>>>,
}

/// Result type for database operations
pub type DbResult<T> = Result<T, DbError>;

/// Database error types
#[derive(Debug)]
pub enum DbError {
    ConnectionFailed(String),
    QueryFailed(String),
    MigrationFailed(String),
    SerializationError(String),
    NotConnected,
    InvalidData(String),
    Sqlite(rusqlite::Error),
}

impl std::fmt::Display for DbError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::ConnectionFailed(msg) => write!(f, "DB connection failed: {}", msg),
            Self::QueryFailed(msg) => write!(f, "DB query failed: {}", msg),
            Self::MigrationFailed(msg) => write!(f, "DB migration failed: {}", msg),
            Self::SerializationError(msg) => write!(f, "DB serialization error: {}", msg),
            Self::NotConnected => write!(f, "DB not connected"),
            Self::InvalidData(msg) => write!(f, "DB invalid data: {}", msg),
            Self::Sqlite(e) => write!(f, "SQLite error: {}", e),
        }
    }
}

impl std::error::Error for DbError {}

impl From<rusqlite::Error> for DbError {
    fn from(e: rusqlite::Error) -> Self {
        DbError::Sqlite(e)
    }
}

impl DatabaseManager {
    /// Create a new database manager for a file path
    pub fn new(db_path: impl AsRef<Path>) -> Self {
        Self {
            db_path: db_path.as_ref().to_path_buf(),
            conn: None,
        }
    }

    /// Create an in-memory database (for tests)
    pub fn in_memory() -> DbResult<Self> {
        let conn = Connection::open_in_memory()?;
        Self::configure_connection(&conn)?;
        let mut mgr = Self {
            db_path: PathBuf::from(":memory:"),
            conn: Some(Arc::new(Mutex::new(conn))),
        };
        mgr.migrate()?;
        Ok(mgr)
    }

    /// Open the database connection
    pub fn open(&mut self) -> DbResult<()> {
        info!("Opening database: {:?}", self.db_path);

        // Create parent directory if needed
        if let Some(parent) = self.db_path.parent() {
            std::fs::create_dir_all(parent).map_err(|e|
                DbError::ConnectionFailed(format!("Cannot create dir: {}", e)))?;
        }

        let conn = Connection::open(&self.db_path)?;
        Self::configure_connection(&conn)?;

        self.conn = Some(Arc::new(Mutex::new(conn)));
        self.migrate()?;

        info!("Database opened successfully");
        Ok(())
    }

    /// Configure connection pragmas for performance
    fn configure_connection(conn: &Connection) -> DbResult<()> {
        conn.execute_batch("
            PRAGMA journal_mode=WAL;
            PRAGMA synchronous=NORMAL;
            PRAGMA foreign_keys=ON;
            PRAGMA cache_size=-32000;
            PRAGMA temp_store=MEMORY;
            PRAGMA mmap_size=268435456;
        ")?;
        Ok(())
    }

    /// Close the database
    pub fn close(&mut self) {
        self.conn.take();
        info!("Database closed");
    }

    /// Run schema migrations
    pub fn migrate(&mut self) -> DbResult<()> {
        let conn = self.connection()?;
        let conn = conn.lock().map_err(|e| DbError::QueryFailed(e.to_string()))?;
        migrations::run_migrations(&conn)
    }

    /// Get a reference to the connection
    pub fn connection(&self) -> DbResult<Arc<Mutex<Connection>>> {
        self.conn.clone().ok_or(DbError::NotConnected)
    }

    pub fn is_connected(&self) -> bool {
        self.conn.is_some()
    }

    pub fn path(&self) -> &Path {
        &self.db_path
    }

    // ========================================================================
    // Project Save/Load (RM1.3)
    // ========================================================================

    /// Save entire project to database
    pub fn save_project(&self, project: &crate::model::Project) -> DbResult<()> {
        let conn = self.connection()?;
        let conn = conn.lock().map_err(|e| DbError::QueryFailed(e.to_string()))?;

        // Use a transaction for atomicity
        conn.execute("BEGIN IMMEDIATE", [])?;

        // Upsert project metadata
        conn.execute(
            "INSERT OR REPLACE INTO project (id, name, bpm, time_sig_num, time_sig_den,
             sample_rate, created, modified, version)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)",
            params![
                project.id, project.name, project.bpm,
                project.time_signature.numerator as i32,
                project.time_signature.denominator as i32,
                project.sample_rate as i32,
                project.created, project.modified, project.version,
            ],
        )?;

        // Clear and re-insert tracks
        conn.execute("DELETE FROM tracks", [])?;
        for track in &project.tracks {
            conn.execute(
                "INSERT INTO tracks (id, name, kind, track_index, color, volume, pan,
                 mute, solo, armed, visible, height, group_id)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13)",
                params![
                    track.id, track.name,
                    format!("{:?}", track.kind).to_lowercase(),
                    track.index as i32,
                    format!("#{:02X}{:02X}{:02X}{:02X}",
                        track.color.r, track.color.g, track.color.b, track.color.a),
                    track.volume, track.pan,
                    track.mute as i32, track.solo as i32,
                    track.armed as i32, track.visible as i32,
                    track.height as i32, track.group_id,
                ],
            )?;

            // Save clips for this track
            for clip in &track.clips {
                conn.execute(
                    "INSERT INTO clips (id, track_id, kind, name, color,
                     start_beat, length_beats, offset_beats, gain,
                     fade_in_beats, fade_out_beats, fade_in_curve, fade_out_curve,
                     muted, locked, group_id, audio_file, audio_channels,
                     audio_sample_rate, warp_enabled, video_file,
                     video_in_point, video_out_point, video_speed,
                     video_opacity, video_blend_mode)
                     VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,
                             ?14,?15,?16,?17,?18,?19,?20,?21,?22,?23,?24,?25,?26)",
                    params![
                        clip.id, clip.track_id,
                        format!("{:?}", clip.kind).to_lowercase(),
                        clip.name,
                        format!("#{:02X}{:02X}{:02X}{:02X}",
                            clip.color.r, clip.color.g, clip.color.b, clip.color.a),
                        clip.start_beat, clip.length_beats, clip.offset_beats,
                        clip.gain, clip.fade_in_beats, clip.fade_out_beats,
                        format!("{:?}", clip.fade_in_curve).to_lowercase(),
                        format!("{:?}", clip.fade_out_curve).to_lowercase(),
                        clip.muted as i32, clip.locked as i32,
                        clip.group_id, clip.audio_file,
                        clip.audio_channels.map(|c| c as i32),
                        clip.audio_sample_rate.map(|s| s as i32),
                        clip.warp_enabled as i32,
                        clip.video_file, clip.video_in_point,
                        clip.video_out_point, clip.video_speed,
                        clip.video_opacity,
                        clip.video_blend_mode.as_ref().map(|m| format!("{:?}", m).to_lowercase()),
                    ],
                )?;

                // Save MIDI notes
                if let Some(ref notes) = clip.midi_notes {
                    for note in notes {
                        conn.execute(
                            "INSERT INTO midi_notes (clip_id, pitch, velocity,
                             start_beat, length_beats, channel, pressure, slide, pitch_bend)
                             VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9)",
                            params![
                                clip.id, note.pitch as i32, note.velocity as i32,
                                note.start_beat, note.length_beats,
                                note.channel as i32,
                                note.pressure, note.slide, note.pitch_bend,
                            ],
                        )?;
                    }
                }
            }

            // Save automation lanes
            for lane in &track.automation_lanes {
                conn.execute(
                    "INSERT INTO automation_lanes (id, track_id, param_id, param_name,
                     default_value, min_value, max_value, visible, height)
                     VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9)",
                    params![
                        lane.id, lane.track_id, lane.param_id, lane.param_name,
                        lane.default_value, lane.min_value, lane.max_value,
                        lane.visible as i32, lane.height as i32,
                    ],
                )?;
                for pt in &lane.points {
                    conn.execute(
                        "INSERT INTO automation_points (lane_id, beat, value,
                         curve_type, cp1_x, cp1_y, cp2_x, cp2_y)
                         VALUES (?1,?2,?3,?4,?5,?6,?7,?8)",
                        params![
                            lane.id, pt.beat, pt.value,
                            format!("{:?}", pt.curve_type).to_lowercase(),
                            pt.cp1_x, pt.cp1_y, pt.cp2_x, pt.cp2_y,
                        ],
                    )?;
                }
            }

            // Save FX chain
            for (idx, slot) in track.fx_chain.iter().enumerate() {
                conn.execute(
                    "INSERT INTO fx_slots (id, track_id, slot_index, plugin_id,
                     plugin_name, enabled, wet_dry, preset_name)
                     VALUES (?1,?2,?3,?4,?5,?6,?7,?8)",
                    params![
                        slot.id, track.id, idx as i32,
                        slot.plugin_id, slot.plugin_name,
                        slot.enabled as i32, slot.wet_dry, slot.preset_name,
                    ],
                )?;
                for (key, val) in &slot.params {
                    conn.execute(
                        "INSERT INTO fx_params (slot_id, param_key, param_value)
                         VALUES (?1,?2,?3)",
                        params![slot.id, key, val],
                    )?;
                }
            }

            // Save sends
            for send in &track.sends {
                conn.execute(
                    "INSERT INTO sends (id, source_track_id, target_track_id,
                     gain, pan, pre_fader, enabled)
                     VALUES (?1,?2,?3,?4,?5,?6,?7)",
                    params![
                        send.id, track.id, send.target_track_id,
                        send.gain, send.pan,
                        send.pre_fader as i32, send.enabled as i32,
                    ],
                )?;
            }
        }

        // Save tempo map
        conn.execute("DELETE FROM tempo_changes", [])?;
        for tc in &project.tempo_map.tempo_changes {
            conn.execute(
                "INSERT INTO tempo_changes (beat, bpm) VALUES (?1, ?2)",
                params![tc.beat, tc.bpm],
            )?;
        }
        conn.execute("DELETE FROM time_sig_changes", [])?;
        for tsc in &project.tempo_map.time_sig_changes {
            conn.execute(
                "INSERT INTO time_sig_changes (beat, numerator, denominator)
                 VALUES (?1, ?2, ?3)",
                params![tsc.beat, tsc.time_signature.numerator as i32,
                        tsc.time_signature.denominator as i32],
            )?;
        }

        conn.execute("COMMIT", [])?;
        info!("Project '{}' saved ({} tracks)", project.name, project.tracks.len());
        Ok(())
    }

    /// Load project from database
    pub fn load_project(&self) -> DbResult<crate::model::Project> {
        let conn = self.connection()?;
        let conn = conn.lock().map_err(|e| DbError::QueryFailed(e.to_string()))?;

        // Load project metadata
        let mut stmt = conn.prepare(
            "SELECT id, name, bpm, time_sig_num, time_sig_den,
             sample_rate, created, modified, version FROM project LIMIT 1")?;
        let mut project = stmt.query_row([], |row| {
            Ok(crate::model::Project {
                id: row.get(0)?,
                name: row.get(1)?,
                bpm: row.get(2)?,
                time_signature: crate::model::TimeSignature {
                    numerator: row.get::<_, i32>(3)? as u8,
                    denominator: row.get::<_, i32>(4)? as u8,
                },
                sample_rate: row.get::<_, i32>(5)? as u32,
                created: row.get(6)?,
                modified: row.get(7)?,
                version: row.get(8)?,
                tracks: Vec::new(),
                master_track: crate::model::Track::new_master(),
                tempo_map: crate::model::TempoMap::default(),
                loop_region: None,
                project_path: None,
            })
        }).map_err(|e| DbError::QueryFailed(format!("No project found: {}", e)))?;

        // Load tracks
        let mut track_stmt = conn.prepare(
            "SELECT id, name, kind, track_index, color, volume, pan,
             mute, solo, armed, visible, height, group_id
             FROM tracks ORDER BY track_index")?;
        let tracks: Vec<crate::model::Track> = track_stmt.query_map([], |row| {
            let kind_str: String = row.get(2)?;
            let kind = match kind_str.as_str() {
                "audio" => crate::model::TrackKind::Audio,
                "instrument" => crate::model::TrackKind::Instrument,
                "group" => crate::model::TrackKind::Group,
                "master" => crate::model::TrackKind::Master,
                "fxreturn" | "fx_return" => crate::model::TrackKind::FxReturn,
                "video" => crate::model::TrackKind::Video,
                _ => crate::model::TrackKind::Audio,
            };
            Ok(crate::model::Track {
                id: row.get(0)?,
                name: row.get(1)?,
                kind,
                index: row.get::<_, i32>(3)? as u16,
                color: crate::model::Color::default(), // simplified
                volume: row.get(5)?,
                pan: row.get(6)?,
                mute: row.get::<_, i32>(7)? != 0,
                solo: row.get::<_, i32>(8)? != 0,
                armed: row.get::<_, i32>(9)? != 0,
                visible: row.get::<_, i32>(10)? != 0,
                height: row.get::<_, i32>(11)? as u32,
                group_id: row.get(12)?,
                clips: Vec::new(),
                automation_lanes: Vec::new(),
                fx_chain: Vec::new(),
                sends: Vec::new(),
                input_config: crate::model::InputConfig::default(),
                output_config: crate::model::OutputConfig::default(),
            })
        })?.filter_map(|r| r.ok()).collect();

        project.tracks = tracks;

        // Load clips per track
        let mut clip_stmt = conn.prepare(
            "SELECT id, track_id, kind, name, start_beat, length_beats,
             offset_beats, gain, fade_in_beats, fade_out_beats,
             muted, locked, audio_file, video_file,
             video_speed, video_opacity
             FROM clips WHERE track_id = ?1 ORDER BY start_beat")?;

        for track in &mut project.tracks {
            let clips: Vec<crate::model::Clip> = clip_stmt.query_map(
                params![track.id], |row| {
                let kind_str: String = row.get(2)?;
                let kind = match kind_str.as_str() {
                    "midi" => crate::model::ClipKind::Midi,
                    "video" => crate::model::ClipKind::Video,
                    _ => crate::model::ClipKind::Audio,
                };
                let mut clip = crate::model::Clip::new_audio(&row.get::<_, String>(1)?,
                    &row.get::<_, String>(3)?, row.get(4)?, row.get(5)?, "");
                clip.id = row.get(0)?;
                clip.kind = kind;
                clip.offset_beats = row.get(6)?;
                clip.gain = row.get(7)?;
                clip.fade_in_beats = row.get(8)?;
                clip.fade_out_beats = row.get(9)?;
                clip.muted = row.get::<_, i32>(10)? != 0;
                clip.locked = row.get::<_, i32>(11)? != 0;
                clip.audio_file = row.get(12)?;
                clip.video_file = row.get(13)?;
                clip.video_speed = row.get(14)?;
                clip.video_opacity = row.get(15)?;
                if kind == crate::model::ClipKind::Midi {
                    clip.midi_notes = Some(Vec::new());
                    clip.midi_ccs = Some(Vec::new());
                }
                Ok(clip)
            })?.filter_map(|r| r.ok()).collect();
            track.clips = clips;
        }

        // Load MIDI notes per clip
        let mut note_stmt = conn.prepare(
            "SELECT pitch, velocity, start_beat, length_beats, channel,
             pressure, slide, pitch_bend
             FROM midi_notes WHERE clip_id = ?1 ORDER BY start_beat")?;

        for track in &mut project.tracks {
            for clip in &mut track.clips {
                if clip.kind == crate::model::ClipKind::Midi {
                    let notes: Vec<crate::model::MidiNote> = note_stmt.query_map(
                        params![clip.id], |row| {
                        Ok(crate::model::MidiNote {
                            pitch: row.get::<_, i32>(0)? as u8,
                            velocity: row.get::<_, i32>(1)? as u8,
                            start_beat: row.get(2)?,
                            length_beats: row.get(3)?,
                            channel: row.get::<_, i32>(4)? as u8,
                            pressure: row.get(5)?,
                            slide: row.get(6)?,
                            pitch_bend: row.get(7)?,
                        })
                    })?.filter_map(|r| r.ok()).collect();
                    clip.midi_notes = Some(notes);
                }
            }
        }

        // Load tempo map
        let mut tempo_stmt = conn.prepare(
            "SELECT beat, bpm FROM tempo_changes ORDER BY beat")?;
        project.tempo_map.tempo_changes = tempo_stmt.query_map([], |row| {
            Ok(crate::model::TempoChange { beat: row.get(0)?, bpm: row.get(1)? })
        })?.filter_map(|r| r.ok()).collect();

        if project.tempo_map.tempo_changes.is_empty() {
            project.tempo_map.tempo_changes.push(
                crate::model::TempoChange { beat: 0.0, bpm: project.bpm });
        }

        info!("Project '{}' loaded ({} tracks)", project.name, project.tracks.len());
        Ok(project)
    }

    /// Store a single setting key/value
    pub fn set_setting(&self, key: &str, value: &str, category: &str) -> DbResult<()> {
        let conn = self.connection()?;
        let conn = conn.lock().map_err(|e| DbError::QueryFailed(e.to_string()))?;
        conn.execute(
            "INSERT OR REPLACE INTO settings (key, value, category) VALUES (?1, ?2, ?3)",
            params![key, value, category],
        )?;
        Ok(())
    }

    /// Get a setting value
    pub fn get_setting(&self, key: &str) -> DbResult<Option<String>> {
        let conn = self.connection()?;
        let conn = conn.lock().map_err(|e| DbError::QueryFailed(e.to_string()))?;
        let result = conn.query_row(
            "SELECT value FROM settings WHERE key = ?1",
            params![key],
            |row| row.get(0),
        );
        match result {
            Ok(v) => Ok(Some(v)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(DbError::Sqlite(e)),
        }
    }
}
