// ============================================================================
// Project Database Operations — v0.0.20.970 (RM1.2)
// ============================================================================
//
// High-level operations for project data: tracks, clips, automation, etc.
// Provides the API that IPC commands will call.
// ============================================================================

use crate::model::*;
use super::{DbResult, DbError};
use log::info;

/// Project database operations (stateless — operates on Project in memory)
pub struct ProjectDb;

impl ProjectDb {
    // ========================================================================
    // Track Operations
    // ========================================================================

    /// Add a new track to the project
    pub fn add_track(project: &mut Project, name: &str, kind: TrackKind) -> DbResult<Id> {
        let index = project.tracks.len() as u16;
        let track = Track::new(name, kind, index);
        let id = track.id.clone();
        project.tracks.push(track);
        project.modified = now_iso();
        info!("Added track '{}' ({})", name, id);
        Ok(id)
    }

    /// Remove a track by ID
    pub fn remove_track(project: &mut Project, track_id: &str) -> DbResult<()> {
        let before = project.tracks.len();
        project.tracks.retain(|t| t.id != track_id);
        if project.tracks.len() == before {
            return Err(DbError::InvalidData(format!("Track not found: {}", track_id)));
        }
        // Re-index
        for (i, track) in project.tracks.iter_mut().enumerate() {
            track.index = i as u16;
        }
        project.modified = now_iso();
        info!("Removed track {}", track_id);
        Ok(())
    }

    /// Move a track to a new index
    pub fn move_track(project: &mut Project, track_id: &str, new_index: u16) -> DbResult<()> {
        let pos = project.tracks.iter().position(|t| t.id == track_id)
            .ok_or(DbError::InvalidData(format!("Track not found: {}", track_id)))?;
        let new_idx = (new_index as usize).min(project.tracks.len() - 1);
        let track = project.tracks.remove(pos);
        project.tracks.insert(new_idx, track);
        for (i, t) in project.tracks.iter_mut().enumerate() {
            t.index = i as u16;
        }
        project.modified = now_iso();
        Ok(())
    }

    /// Set track parameter
    pub fn set_track_param(project: &mut Project, track_id: &str, param: &str, value: f64) -> DbResult<()> {
        let track = project.tracks.iter_mut().find(|t| t.id == track_id)
            .ok_or(DbError::InvalidData(format!("Track not found: {}", track_id)))?;
        match param {
            "volume" => track.volume = value.clamp(0.0, 2.0),
            "pan" => track.pan = value.clamp(-1.0, 1.0),
            "mute" => track.mute = value > 0.5,
            "solo" => track.solo = value > 0.5,
            "armed" => track.armed = value > 0.5,
            "height" => track.height = value as u32,
            _ => return Err(DbError::InvalidData(format!("Unknown param: {}", param))),
        }
        project.modified = now_iso();
        Ok(())
    }

    // ========================================================================
    // Clip Operations
    // ========================================================================

    /// Add an audio clip
    pub fn add_audio_clip(
        project: &mut Project,
        track_id: &str,
        name: &str,
        start_beat: f64,
        length_beats: f64,
        audio_file: &str,
    ) -> DbResult<Id> {
        let track = project.tracks.iter_mut().find(|t| t.id == track_id)
            .ok_or(DbError::InvalidData(format!("Track not found: {}", track_id)))?;
        let clip = Clip::new_audio(track_id, name, start_beat, length_beats, audio_file);
        let id = clip.id.clone();
        track.clips.push(clip);
        project.modified = now_iso();
        info!("Added audio clip '{}' to track {}", name, track_id);
        Ok(id)
    }

    /// Add a MIDI clip
    pub fn add_midi_clip(
        project: &mut Project,
        track_id: &str,
        name: &str,
        start_beat: f64,
        length_beats: f64,
    ) -> DbResult<Id> {
        let track = project.tracks.iter_mut().find(|t| t.id == track_id)
            .ok_or(DbError::InvalidData(format!("Track not found: {}", track_id)))?;
        let clip = Clip::new_midi(track_id, name, start_beat, length_beats);
        let id = clip.id.clone();
        track.clips.push(clip);
        project.modified = now_iso();
        info!("Added MIDI clip '{}' to track {}", name, track_id);
        Ok(id)
    }

    /// Add a video clip
    pub fn add_video_clip(
        project: &mut Project,
        track_id: &str,
        name: &str,
        start_beat: f64,
        length_beats: f64,
        video_file: &str,
    ) -> DbResult<Id> {
        let track = project.tracks.iter_mut().find(|t| t.id == track_id)
            .ok_or(DbError::InvalidData(format!("Track not found: {}", track_id)))?;
        let clip = Clip::new_video(track_id, name, start_beat, length_beats, video_file);
        let id = clip.id.clone();
        track.clips.push(clip);
        project.modified = now_iso();
        info!("Added video clip '{}' to track {}", name, track_id);
        Ok(id)
    }

    /// Remove a clip
    pub fn remove_clip(project: &mut Project, clip_id: &str) -> DbResult<()> {
        for track in &mut project.tracks {
            let before = track.clips.len();
            track.clips.retain(|c| c.id != clip_id);
            if track.clips.len() < before {
                project.modified = now_iso();
                info!("Removed clip {}", clip_id);
                return Ok(());
            }
        }
        Err(DbError::InvalidData(format!("Clip not found: {}", clip_id)))
    }

    /// Move a clip to a new position
    pub fn move_clip(project: &mut Project, clip_id: &str, new_start: f64, new_track_id: Option<&str>) -> DbResult<()> {
        // Find and remove clip from current track
        let mut clip = None;
        for track in &mut project.tracks {
            if let Some(pos) = track.clips.iter().position(|c| c.id == clip_id) {
                clip = Some(track.clips.remove(pos));
                break;
            }
        }
        let mut clip = clip.ok_or(DbError::InvalidData(format!("Clip not found: {}", clip_id)))?;
        clip.start_beat = new_start;

        // Place in target track
        let target_id = new_track_id.unwrap_or(&clip.track_id);
        let track = project.tracks.iter_mut().find(|t| t.id == target_id)
            .ok_or(DbError::InvalidData(format!("Target track not found: {}", target_id)))?;
        clip.track_id = track.id.clone();
        track.clips.push(clip);
        project.modified = now_iso();
        Ok(())
    }

    /// Set clip parameter
    pub fn set_clip_param(project: &mut Project, clip_id: &str, param: &str, value: f64) -> DbResult<()> {
        for track in &mut project.tracks {
            if let Some(clip) = track.clips.iter_mut().find(|c| c.id == clip_id) {
                match param {
                    "gain" => clip.gain = value.clamp(0.0, 4.0),
                    "start_beat" => clip.start_beat = value.max(0.0),
                    "length_beats" => clip.length_beats = value.max(0.001),
                    "offset_beats" => clip.offset_beats = value,
                    "fade_in" => clip.fade_in_beats = value.max(0.0),
                    "fade_out" => clip.fade_out_beats = value.max(0.0),
                    "muted" => clip.muted = value > 0.5,
                    "locked" => clip.locked = value > 0.5,
                    "video_opacity" => clip.video_opacity = Some(value.clamp(0.0, 1.0)),
                    "video_speed" => clip.video_speed = Some(value.clamp(0.01, 100.0)),
                    _ => return Err(DbError::InvalidData(format!("Unknown clip param: {}", param))),
                }
                project.modified = now_iso();
                return Ok(());
            }
        }
        Err(DbError::InvalidData(format!("Clip not found: {}", clip_id)))
    }

    /// Ripple delete: remove clip and shift all later clips left
    pub fn ripple_delete(project: &mut Project, clip_id: &str) -> DbResult<()> {
        for track in &mut project.tracks {
            if let Some(pos) = track.clips.iter().position(|c| c.id == clip_id) {
                let removed = track.clips.remove(pos);
                let gap = removed.length_beats;
                let threshold = removed.start_beat;
                // Shift all clips after the deleted one
                for clip in &mut track.clips {
                    if clip.start_beat > threshold {
                        clip.start_beat -= gap;
                    }
                }
                project.modified = now_iso();
                info!("Ripple deleted clip {}, shifted {} beats", clip_id, gap);
                return Ok(());
            }
        }
        Err(DbError::InvalidData(format!("Clip not found: {}", clip_id)))
    }

    // ========================================================================
    // MIDI Note Operations
    // ========================================================================

    /// Add a MIDI note to a clip
    pub fn add_midi_note(project: &mut Project, clip_id: &str, note: MidiNote) -> DbResult<()> {
        for track in &mut project.tracks {
            if let Some(clip) = track.clips.iter_mut().find(|c| c.id == clip_id) {
                if let Some(ref mut notes) = clip.midi_notes {
                    notes.push(note);
                    project.modified = now_iso();
                    return Ok(());
                }
                return Err(DbError::InvalidData("Clip is not a MIDI clip".into()));
            }
        }
        Err(DbError::InvalidData(format!("Clip not found: {}", clip_id)))
    }

    /// Remove MIDI notes in a beat range
    pub fn remove_midi_notes_in_range(
        project: &mut Project,
        clip_id: &str,
        start_beat: f64,
        end_beat: f64,
    ) -> DbResult<usize> {
        for track in &mut project.tracks {
            if let Some(clip) = track.clips.iter_mut().find(|c| c.id == clip_id) {
                if let Some(ref mut notes) = clip.midi_notes {
                    let before = notes.len();
                    notes.retain(|n| n.start_beat < start_beat || n.start_beat >= end_beat);
                    let removed = before - notes.len();
                    project.modified = now_iso();
                    return Ok(removed);
                }
            }
        }
        Err(DbError::InvalidData(format!("Clip not found: {}", clip_id)))
    }

    /// Quantize MIDI notes to grid
    pub fn quantize_midi(project: &mut Project, clip_id: &str, grid_beats: f64, strength: f64) -> DbResult<usize> {
        let strength = strength.clamp(0.0, 1.0);
        let mut count = 0;
        for track in &mut project.tracks {
            if let Some(clip) = track.clips.iter_mut().find(|c| c.id == clip_id) {
                if let Some(ref mut notes) = clip.midi_notes {
                    for note in notes.iter_mut() {
                        let nearest = (note.start_beat / grid_beats).round() * grid_beats;
                        let diff = nearest - note.start_beat;
                        note.start_beat += diff * strength;
                        count += 1;
                    }
                    project.modified = now_iso();
                    return Ok(count);
                }
            }
        }
        Err(DbError::InvalidData(format!("Clip not found: {}", clip_id)))
    }

    // ========================================================================
    // Automation Operations
    // ========================================================================

    /// Add or update an automation lane
    pub fn add_automation_lane(
        project: &mut Project,
        track_id: &str,
        param_id: &str,
        param_name: &str,
    ) -> DbResult<Id> {
        let track = project.tracks.iter_mut().find(|t| t.id == track_id)
            .ok_or(DbError::InvalidData(format!("Track not found: {}", track_id)))?;

        // Check if lane already exists
        if let Some(existing) = track.automation_lanes.iter().find(|l| l.param_id == param_id) {
            return Ok(existing.id.clone());
        }

        let lane = AutomationLane {
            id: uuid_v4(),
            track_id: track_id.into(),
            param_id: param_id.into(),
            param_name: param_name.into(),
            points: Vec::new(),
            default_value: 0.5,
            min_value: 0.0,
            max_value: 1.0,
            visible: true,
            height: 60,
        };
        let id = lane.id.clone();
        track.automation_lanes.push(lane);
        project.modified = now_iso();
        Ok(id)
    }

    /// Add an automation point
    pub fn add_automation_point(
        project: &mut Project,
        lane_id: &str,
        point: AutomationPoint,
    ) -> DbResult<()> {
        for track in &mut project.tracks {
            if let Some(lane) = track.automation_lanes.iter_mut().find(|l| l.id == lane_id) {
                // Insert sorted by beat
                let pos = lane.points.iter()
                    .position(|p| p.beat > point.beat)
                    .unwrap_or(lane.points.len());
                lane.points.insert(pos, point);
                project.modified = now_iso();
                return Ok(());
            }
        }
        Err(DbError::InvalidData(format!("Lane not found: {}", lane_id)))
    }

    /// Get automation value at a beat position
    pub fn get_automation_value(project: &Project, lane_id: &str, beat: f64) -> DbResult<f64> {
        for track in &project.tracks {
            if let Some(lane) = track.automation_lanes.iter().find(|l| l.id == lane_id) {
                return Ok(lane.value_at(beat));
            }
        }
        Err(DbError::InvalidData(format!("Lane not found: {}", lane_id)))
    }

    // ========================================================================
    // FX Operations
    // ========================================================================

    /// Add an FX slot to a track
    pub fn add_fx_slot(
        project: &mut Project,
        track_id: &str,
        plugin_id: &str,
        plugin_name: &str,
    ) -> DbResult<Id> {
        let track = project.tracks.iter_mut().find(|t| t.id == track_id)
            .ok_or(DbError::InvalidData(format!("Track not found: {}", track_id)))?;
        let slot = FxSlot {
            id: uuid_v4(),
            plugin_id: plugin_id.into(),
            plugin_name: plugin_name.into(),
            enabled: true,
            wet_dry: 1.0,
            params: std::collections::HashMap::new(),
            preset_name: None,
        };
        let id = slot.id.clone();
        track.fx_chain.push(slot);
        project.modified = now_iso();
        Ok(id)
    }

    // ========================================================================
    // Query Operations
    // ========================================================================

    /// Get all clips in a beat range across all tracks
    pub fn clips_in_range(project: &Project, start: f64, end: f64) -> Vec<&Clip> {
        let mut result = Vec::new();
        for track in &project.tracks {
            for clip in &track.clips {
                if clip.overlaps(start, end) {
                    result.push(clip);
                }
            }
        }
        result
    }

    /// Get all video clips sorted by start position
    pub fn video_clips_sorted(project: &Project) -> Vec<&Clip> {
        let mut result: Vec<&Clip> = project.tracks.iter()
            .flat_map(|t| t.clips.iter())
            .filter(|c| c.kind == ClipKind::Video)
            .collect();
        result.sort_by(|a, b| a.start_beat.partial_cmp(&b.start_beat).unwrap());
        result
    }

    /// Find track by ID
    pub fn find_track<'a>(project: &'a Project, track_id: &str) -> Option<&'a Track> {
        project.tracks.iter().find(|t| t.id == track_id)
    }

    /// Find clip by ID
    pub fn find_clip<'a>(project: &'a Project, clip_id: &str) -> Option<&'a Clip> {
        project.tracks.iter()
            .flat_map(|t| t.clips.iter())
            .find(|c| c.id == clip_id)
    }

    /// Project statistics
    pub fn statistics(project: &Project) -> ProjectStats {
        let total_clips: usize = project.tracks.iter().map(|t| t.clips.len()).sum();
        let audio_clips = project.tracks.iter()
            .flat_map(|t| t.clips.iter())
            .filter(|c| c.kind == ClipKind::Audio)
            .count();
        let midi_clips = project.tracks.iter()
            .flat_map(|t| t.clips.iter())
            .filter(|c| c.kind == ClipKind::Midi)
            .count();
        let video_clips = project.tracks.iter()
            .flat_map(|t| t.clips.iter())
            .filter(|c| c.kind == ClipKind::Video)
            .count();
        let total_notes: usize = project.tracks.iter()
            .flat_map(|t| t.clips.iter())
            .filter_map(|c| c.midi_notes.as_ref())
            .map(|n| n.len())
            .sum();
        let total_automation: usize = project.tracks.iter()
            .map(|t| t.automation_lanes.len())
            .sum();

        ProjectStats {
            num_tracks: project.tracks.len(),
            num_clips: total_clips,
            num_audio_clips: audio_clips,
            num_midi_clips: midi_clips,
            num_video_clips: video_clips,
            num_midi_notes: total_notes,
            num_automation_lanes: total_automation,
        }
    }
}

/// Project statistics summary
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct ProjectStats {
    pub num_tracks: usize,
    pub num_clips: usize,
    pub num_audio_clips: usize,
    pub num_midi_clips: usize,
    pub num_video_clips: usize,
    pub num_midi_notes: usize,
    pub num_automation_lanes: usize,
}
