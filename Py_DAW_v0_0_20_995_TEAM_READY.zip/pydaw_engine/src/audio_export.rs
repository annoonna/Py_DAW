// ============================================================================
// Audio Export / Offline Render — v0.0.20.972 (RM3.5)
// ============================================================================
//
// Renders the entire arrangement to an audio file.
// Faster-than-realtime, supports multiple formats.
// ============================================================================

use crossbeam_channel::{bounded, Sender, Receiver};
use log::{info, error};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU32, Ordering};
use std::sync::Arc;

/// Export format
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum AudioFormat {
    Wav16,
    Wav24,
    Wav32Float,
    Flac16,
    Flac24,
}

/// Dithering algorithm
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum DitherType {
    None,
    Tpdf,          // Triangular Probability Density Function
    NoiseShaping,  // Noise shaping (better perceived SNR)
}

/// Normalization mode
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum NormalizeMode {
    None,
    Peak { target_db: f64 },
    Rms { target_db: f64 },
    Lufs { target_lufs: f64 },
}

/// Export configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExportConfig {
    pub output_path: String,
    pub format: AudioFormat,
    pub sample_rate: u32,
    pub channels: u16,
    pub dither: DitherType,
    pub normalize: NormalizeMode,
    /// Export range in beats (None = entire arrangement)
    pub range: Option<(f64, f64)>,
    /// Export stems (one file per track)
    pub stems: bool,
    /// Tail in seconds (for reverb tails)
    pub tail_seconds: f64,
}

impl Default for ExportConfig {
    fn default() -> Self {
        Self {
            output_path: "export.wav".into(),
            format: AudioFormat::Wav24,
            sample_rate: 44100,
            channels: 2,
            dither: DitherType::Tpdf,
            normalize: NormalizeMode::None,
            range: None,
            stems: false,
            tail_seconds: 2.0,
        }
    }
}

/// Export progress info
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExportProgress {
    pub percent: f32,          // 0..100
    pub current_sample: u64,
    pub total_samples: u64,
    pub elapsed_secs: f64,
    pub estimated_remaining: f64,
    pub phase: String,        // "rendering", "normalizing", "writing", "done"
}

/// Offline renderer
pub struct OfflineRenderer {
    config: ExportConfig,
    cancelled: Arc<AtomicBool>,
    progress_percent: Arc<AtomicU32>,
}

impl OfflineRenderer {
    pub fn new(config: ExportConfig) -> Self {
        Self {
            config,
            cancelled: Arc::new(AtomicBool::new(false)),
            progress_percent: Arc::new(AtomicU32::new(0)),
        }
    }

    /// Cancel the current render
    pub fn cancel(&self) {
        self.cancelled.store(true, Ordering::Relaxed);
    }

    /// Get current progress (0..100)
    pub fn progress(&self) -> u32 {
        self.progress_percent.load(Ordering::Relaxed)
    }

    /// Render the arrangement to a buffer
    /// `render_fn` is called for each buffer block: (output_buffer, position_samples) → bool
    /// Returns the complete rendered audio as f32 interleaved samples.
    pub fn render_to_buffer<F>(&self, total_samples: u64, block_size: usize, mut render_fn: F)
        -> Result<Vec<f32>, String>
    where F: FnMut(&mut [f32], u64) -> bool
    {
        let channels = self.config.channels as usize;
        let total_frames = total_samples;
        let mut output = Vec::with_capacity((total_frames as usize) * channels);
        let mut block = vec![0.0f32; block_size * channels];
        let mut pos: u64 = 0;

        info!("Offline render: {} samples, {} channels, block_size={}",
            total_frames, channels, block_size);

        let start = std::time::Instant::now();

        while pos < total_frames {
            if self.cancelled.load(Ordering::Relaxed) {
                return Err("Render cancelled".into());
            }

            // Clear block
            block.fill(0.0);

            let remaining = (total_frames - pos) as usize;
            let this_block = remaining.min(block_size);

            // Call the render function
            if !render_fn(&mut block[..this_block * channels], pos) {
                break;
            }

            output.extend_from_slice(&block[..this_block * channels]);
            pos += this_block as u64;

            // Update progress
            let pct = (pos as f64 / total_frames as f64 * 100.0) as u32;
            self.progress_percent.store(pct.min(100), Ordering::Relaxed);
        }

        let elapsed = start.elapsed().as_secs_f64();
        let audio_duration = total_frames as f64 / self.config.sample_rate as f64;
        info!("Offline render complete: {:.1}s audio in {:.2}s ({:.1}x realtime)",
            audio_duration, elapsed, audio_duration / elapsed);

        Ok(output)
    }

    /// Apply normalization to a buffer
    pub fn normalize(&self, buffer: &mut [f32]) {
        match self.config.normalize {
            NormalizeMode::None => {}
            NormalizeMode::Peak { target_db } => {
                let peak = buffer.iter().map(|s| s.abs()).fold(0.0f32, f32::max);
                if peak > 0.0 {
                    let target = 10.0_f32.powf(target_db as f32 / 20.0);
                    let gain = target / peak;
                    for s in buffer.iter_mut() { *s *= gain; }
                    info!("Peak normalized: gain={:.3} ({:.1}dB)", gain, 20.0 * gain.log10());
                }
            }
            NormalizeMode::Rms { target_db } => {
                let rms = (buffer.iter().map(|s| s * s).sum::<f32>()
                    / buffer.len() as f32).sqrt();
                if rms > 0.0 {
                    let target = 10.0_f32.powf(target_db as f32 / 20.0);
                    let gain = target / rms;
                    for s in buffer.iter_mut() { *s *= gain; }
                    info!("RMS normalized: gain={:.3}", gain);
                }
            }
            NormalizeMode::Lufs { target_lufs } => {
                // Simplified LUFS normalization (use LufsMeter for accurate version)
                let rms = (buffer.iter().map(|s| s * s).sum::<f32>()
                    / buffer.len() as f32).sqrt();
                if rms > 0.0 {
                    let current_lufs = -0.691 + 10.0 * (rms as f64).log10();
                    let diff = target_lufs - current_lufs;
                    let gain = 10.0_f64.powf(diff / 20.0) as f32;
                    for s in buffer.iter_mut() { *s *= gain; }
                    info!("LUFS normalized: {:.1} → {:.1} LUFS", current_lufs, target_lufs);
                }
            }
        }
    }

    /// Apply dithering when reducing bit depth
    pub fn dither(&self, buffer: &mut [f32], target_bits: u32) {
        match self.config.dither {
            DitherType::None => {}
            DitherType::Tpdf => {
                // TPDF dithering: add triangular-distributed noise at ±1 LSB
                let lsb = 1.0 / (1u64 << (target_bits - 1)) as f32;
                let mut rng_state: u32 = 0x12345678;
                for s in buffer.iter_mut() {
                    // Simple LCG for fast random
                    rng_state = rng_state.wrapping_mul(1103515245).wrapping_add(12345);
                    let r1 = (rng_state >> 16) as f32 / 32768.0 - 1.0;
                    rng_state = rng_state.wrapping_mul(1103515245).wrapping_add(12345);
                    let r2 = (rng_state >> 16) as f32 / 32768.0 - 1.0;
                    *s += (r1 + r2) * lsb * 0.5;
                }
            }
            DitherType::NoiseShaping => {
                // First-order noise shaping
                let lsb = 1.0 / (1u64 << (target_bits - 1)) as f32;
                let mut error: f32 = 0.0;
                let mut rng_state: u32 = 0xDEADBEEF;
                for s in buffer.iter_mut() {
                    rng_state = rng_state.wrapping_mul(1103515245).wrapping_add(12345);
                    let noise = (rng_state >> 16) as f32 / 32768.0 - 1.0;
                    let dithered = *s - error + noise * lsb;
                    let quantized = (dithered / lsb).round() * lsb;
                    error = quantized - *s;
                    *s = quantized;
                }
            }
        }
    }

    /// Write buffer to WAV file
    pub fn write_wav(&self, buffer: &[f32], path: &Path) -> Result<(), String> {
        let (bits, sample_fmt) = match self.config.format {
            AudioFormat::Wav16 => (16, hound::SampleFormat::Int),
            AudioFormat::Wav24 => (24, hound::SampleFormat::Int),
            AudioFormat::Wav32Float => (32, hound::SampleFormat::Float),
            _ => (24, hound::SampleFormat::Int),
        };

        let spec = hound::WavSpec {
            channels: self.config.channels,
            sample_rate: self.config.sample_rate,
            bits_per_sample: bits,
            sample_format: sample_fmt,
        };

        let mut writer = hound::WavWriter::create(path, spec)
            .map_err(|e| format!("Cannot create WAV: {}", e))?;

        match (bits, sample_fmt) {
            (32, hound::SampleFormat::Float) => {
                for &s in buffer {
                    writer.write_sample(s).map_err(|e| format!("Write error: {}", e))?;
                }
            }
            (16, _) => {
                for &s in buffer {
                    let i = (s.clamp(-1.0, 1.0) * 32767.0) as i16;
                    writer.write_sample(i).map_err(|e| format!("Write error: {}", e))?;
                }
            }
            (24, _) => {
                for &s in buffer {
                    let i = (s.clamp(-1.0, 1.0) * 8388607.0) as i32;
                    writer.write_sample(i).map_err(|e| format!("Write error: {}", e))?;
                }
            }
            _ => {}
        }

        writer.finalize().map_err(|e| format!("Finalize error: {}", e))?;
        info!("WAV written: {:?} ({} samples, {}bit)", path, buffer.len(), bits);
        Ok(())
    }

    /// Full export pipeline: render → normalize → dither → write
    pub fn export<F>(&self, total_samples: u64, block_size: usize, render_fn: F)
        -> Result<String, String>
    where F: FnMut(&mut [f32], u64) -> bool
    {
        // 1. Render
        let mut buffer = self.render_to_buffer(total_samples, block_size, render_fn)?;

        // 2. Normalize
        self.normalize(&mut buffer);

        // 3. Dither (if reducing bit depth)
        let target_bits = match self.config.format {
            AudioFormat::Wav16 | AudioFormat::Flac16 => 16,
            AudioFormat::Wav24 | AudioFormat::Flac24 => 24,
            AudioFormat::Wav32Float => 32,
        };
        if target_bits < 32 {
            self.dither(&mut buffer, target_bits);
        }

        // 4. Write
        let path = PathBuf::from(&self.config.output_path);
        self.write_wav(&buffer, &path)?;

        self.progress_percent.store(100, Ordering::Relaxed);
        Ok(self.config.output_path.clone())
    }
}
