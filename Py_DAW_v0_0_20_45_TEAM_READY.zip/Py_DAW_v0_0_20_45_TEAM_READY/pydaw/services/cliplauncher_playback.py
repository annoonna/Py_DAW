"""ClipLauncherPlaybackService (v0.0.19.7.57)

Bitwig-Style Clip Launcher Playback Grundgerüst:

- Event-Timeline: AudioClip.audio_events (Start/Offset/Duration in Beats)
- Sample-Accurate Looping: Clip-Loop in Samples (über globalen Transport-Playhead)
- Gapless Playback: Mixing erfolgt im Audio-Callback über Pull-Source (AudioEngine.register_pull_source)
- Quantized Start: LauncherService armt Clips für den nächsten Quantize-Punkt und gibt die Start-Beat-Position mit.

Hinweis:
Dieses Playback nutzt das bestehende AudioEngine-Backend (JACK via PipeWire oder sounddevice).
Für ein reines QtMultimedia/QAudioSink-Backend existiert ein separates Skeleton in
`pydaw/audio/qt_audio_sink_backend.py`.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
import threading
from typing import Any, Dict, List, Optional, Tuple

from PyQt6.QtCore import QObject

try:
    import numpy as np  # type: ignore
except Exception:  # pragma: no cover
    np = None  # type: ignore


@dataclass
class _Voice:
    slot_key: str
    clip_id: str
    start_beat: float
    # Cached model refs (best-effort)
    kind: str
    track_id: str
    file_path: str
    # Clip-local looping (beats)
    loop_start_beats: float
    loop_end_beats: float
    # Event timeline in beats
    events: List[Any]
    # Gains
    gain: float
    pan: float
    pitch: float
    formant: float
    stretch: float
    track_gain: float
    track_pan: float


class ClipLauncherPlaybackService(QObject):
    """Realtime ClipLauncher playback through AudioEngine pull-sources.

    The engine calls `pull(frames, sr)` inside the audio callback.
    We output a stereo float32 buffer. No allocations on the hot path beyond
    a small output buffer.
    """

    def __init__(self, project: Any, transport: Any, audio_engine: Any):
        super().__init__()
        self.project = project
        self.transport = transport
        self.audio_engine = audio_engine

        self._pull_name = "cliplauncher"
        self._registered = False

        # Active voices per slot
        self._voices: Dict[str, _Voice] = {}

        # Thread-safety: UI thread updates vs audio callback
        self._lock = threading.RLock()

        # Pending map for block-boundary swap (updated after edits)
        self._pending_voice_map: Optional[Dict[str, _Voice]] = None

        # Short crossfade at swap to avoid clicks
        self._swap_xfade_frames = 96

        # Cache decoded/resampled audio: (path, sr) -> np.ndarray (n,2) float32
        self._audio_cache: Dict[Tuple[str, int], Any] = {}

        # Fallback playhead counter when no external clock is available
        self._fallback_playhead_samples = 0
        self._fallback_sr = 48000


        # Live-edit support: rebuild active voices on model changes (applied block-boundary)
        try:
            self.project.project_updated.connect(self._on_project_updated)
        except Exception:
            pass

    # ---------------- public API used by ProjectService ----------------

    def stop_all(self) -> None:
        with self._lock:
            self._voices.clear()
            self._pending_voice_map = None

    def stop_slot(self, slot_key: str) -> None:
        with self._lock:
            self._voices.pop(str(slot_key), None)

    def launch_slot(self, slot_key: str, *, at_beat: Optional[float] = None) -> None:
        """Start (or restart) the clip assigned to slot_key.

        at_beat: global transport beat where the clip should start.
        """
        key = str(slot_key)
        clip_id = str(getattr(self.project.ctx.project, "clip_launcher", {}).get(key, "") or "")
        if not clip_id:
            return
        self._ensure_registered()
        self._start_voice(key, clip_id, at_beat=at_beat)

    def launch_scene(self, scene_index: int, *, at_beat: Optional[float] = None) -> None:
        """Launch all slots in a scene row (scene_index is 1-based)."""
        try:
            tracks = list(getattr(self.project.ctx.project, "tracks", []) or [])
        except Exception:
            tracks = []
        row = int(scene_index)
        for trk in tracks:
            try:
                slot_key = f"{row}:{trk.id}"
            except Exception:
                continue
            cid = str(getattr(self.project.ctx.project, "clip_launcher", {}).get(slot_key, "") or "")
            if cid:
                self._ensure_registered()
                self._start_voice(slot_key, cid, at_beat=at_beat)

    # ---------------- internal ----------------

    def _ensure_registered(self) -> None:
        if self._registered:
            return
        try:
            # Make sure the engine has an output stream so our pull-source is audible.
            self.audio_engine.ensure_preview_output()
        except Exception:
            pass
        try:
            self.audio_engine.register_pull_source(self._pull_name, self.pull)
            self._registered = True
        except Exception:
            self._registered = False

    def _make_voice(self, slot_key: str, clip_id: str, *, at_beat: Optional[float]) -> Optional[_Voice]:
        """Build a voice snapshot from the current project model.

        This is used for live-edit block swaps (project_updated) and for starting voices.
        """
        # Resolve clip + track
        proj = self.project.ctx.project
        clip = next((c for c in (getattr(proj, 'clips', []) or []) if str(getattr(c, 'id', '')) == str(clip_id)), None)
        if clip is None:
            return None
        trk = next((t for t in (getattr(proj, 'tracks', []) or []) if str(getattr(t, 'id', '')) == str(getattr(clip, 'track_id', ''))), None)

        kind = str(getattr(clip, 'kind', 'audio') or 'audio')

        file_path = str(getattr(clip, 'source_path', '') or '')
        if kind == 'midi':
            file_path = self._render_midi_clip_to_wav(clip, trk)
        if not file_path:
            return None

        loop_start = float(getattr(clip, 'loop_start_beats', 0.0) or 0.0)
        loop_end = float(getattr(clip, 'loop_end_beats', 0.0) or 0.0)
        if loop_end <= loop_start + 1e-6:
            length = float(getattr(clip, 'length_beats', 4.0) or 4.0)
            loop_start = 0.0
            loop_end = max(0.25, length)

        events = list(getattr(clip, 'audio_events', []) or [])
        if not events:
            class _E:
                start_beats = 0.0
                length_beats = float(loop_end - loop_start)
                source_offset_beats = float(getattr(clip, 'offset_beats', 0.0) or 0.0)
            events = [_E()]
        try:
            events.sort(key=lambda e: float(getattr(e, 'start_beats', 0.0) or 0.0))
        except Exception:
            pass

        clip_gain = float(getattr(clip, 'gain', 1.0) or 1.0)
        clip_pan = float(getattr(clip, 'pan', 0.0) or 0.0)
        clip_pitch = float(getattr(clip, 'pitch', 0.0) or 0.0)
        clip_formant = float(getattr(clip, 'formant', 0.0) or 0.0)
        clip_stretch = float(getattr(clip, 'stretch', 1.0) or 1.0)
        tr_gain = float(getattr(trk, 'volume', 1.0) or 1.0) if trk is not None else 1.0
        tr_pan = float(getattr(trk, 'pan', 0.0) or 0.0) if trk is not None else 0.0

        start_beat = float(at_beat) if at_beat is not None else float(getattr(self.transport, 'current_beat', 0.0) or 0.0)

        return _Voice(
            slot_key=str(slot_key),
            clip_id=str(clip_id),
            start_beat=float(start_beat),
            kind=kind,
            track_id=str(getattr(clip, 'track_id', '') or ''),
            file_path=str(file_path),
            loop_start_beats=float(loop_start),
            loop_end_beats=float(loop_end),
            events=events,
            gain=float(clip_gain),
            pan=float(clip_pan),
            pitch=float(clip_pitch),
            formant=float(clip_formant),
            stretch=float(clip_stretch),
            track_gain=float(tr_gain),
            track_pan=float(tr_pan),
        )


    def _start_voice(self, slot_key: str, clip_id: str, *, at_beat: Optional[float]) -> None:
        voice = self._make_voice(str(slot_key), str(clip_id), at_beat=at_beat)
        if voice is None:
            return
        with self._lock:
            self._voices[str(slot_key)] = voice


    def _render_midi_clip_to_wav(self, clip: Any, track: Any) -> str:
        """Best-effort MIDI->WAV render to make ClipLauncher playable for MIDI."""
        try:
            from pydaw.audio.midi_render import RenderKey, ensure_rendered_wav
            from pydaw.audio.arrangement_renderer import _midi_notes_content_hash
        except Exception:
            return ""
        try:
            sf2_path = str(getattr(track, "sf2_path", "") or "") if track is not None else ""
            if not sf2_path:
                return ""
            proj = self.project.ctx.project
            bpm = float(getattr(proj, "bpm", getattr(proj, "tempo_bpm", 120.0)) or 120.0)
            notes_map = getattr(proj, "midi_notes", {}) or {}
            notes = list(notes_map.get(str(getattr(clip, "id", "")), []) or [])
            clip_len_beats = float(getattr(clip, "length_beats", 4.0) or 4.0)
            try:
                if notes:
                    note_end = max(float(getattr(n, "start_beats", 0.0)) + float(getattr(n, "length_beats", 0.0)) for n in notes)
                    clip_len_beats = max(clip_len_beats, float(note_end))
            except Exception:
                pass
            content_hash = _midi_notes_content_hash(notes)
            key = RenderKey(
                clip_id=str(getattr(clip, "id", "")),
                sf2_path=str(sf2_path),
                sf2_bank=int(getattr(track, "sf2_bank", 0) or 0),
                sf2_preset=int(getattr(track, "sf2_preset", 0) or 0),
                bpm=float(bpm),
                samplerate=int(48000),
                clip_length_beats=float(clip_len_beats),
                content_hash=str(content_hash),
            )
            wav_path = ensure_rendered_wav(
                key=key,
                midi_notes=notes,
                clip_start_beats=float(getattr(clip, "start_beats", 0.0) or 0.0),
                clip_length_beats=float(clip_len_beats),
            )
            return wav_path.as_posix() if wav_path else ""
        except Exception:
            return ""


    def _on_project_updated(self) -> None:
        """Schedule a block-boundary voice rebuild for live edits.

        We keep slot start times, but refresh loop bounds, events and gains/pan.
        The actual swap happens in the audio callback with a tiny crossfade.
        """
        try:
            with self._lock:
                if not self._voices:
                    return
                current = dict(self._voices)
        except Exception:
            return

        rebuilt: Dict[str, _Voice] = {}
        for slot_key, v in current.items():
            # Preserve the existing start_beat so timing stays stable
            voice = self._make_voice(slot_key, v.clip_id, at_beat=v.start_beat)
            if voice is not None:
                rebuilt[slot_key] = voice

        with self._lock:
            self._pending_voice_map = rebuilt

    # ---------------- realtime pull source ----------------

    def pull(self, frames: int, sr: int):  # noqa: ANN001
        if np is None:
            return None

        frames_i = int(frames)
        sr_i = int(sr)

        # Snapshot voices + pending swap (very short lock).
        with self._lock:
            if not self._voices and not self._pending_voice_map:
                return None
            old_map = None
            if self._pending_voice_map is not None:
                old_map = dict(self._voices)
                self._voices = dict(self._pending_voice_map)
                self._pending_voice_map = None
            voices_map = dict(self._voices)

        if not voices_map:
            return None

        # Determine global playhead samples.
        g_samp = self._get_global_playhead_samples(sr_i)

        try:
            bpm = float(getattr(self.project.ctx.project, 'bpm', getattr(self.project.ctx.project, 'tempo_bpm', 120.0)) or 120.0)
        except Exception:
            bpm = 120.0
        bps = bpm / 60.0
        sppb = float(sr_i) / float(bps) if bps > 1e-9 else float(sr_i)

        # RT params (live track faders/mute/solo without project_updated)
        rt = getattr(self.audio_engine, "rt_params", None)
        try:
            any_solo = bool(rt.any_solo()) if rt is not None else False
        except Exception:
            any_solo = False
        try:
            bridge = getattr(self.audio_engine, "hybrid_bridge", None) or getattr(self.audio_engine, "_hybrid_bridge", None)
        except Exception:
            bridge = None

        # Normal path: just mix current map
        if old_map is None:
            out = np.zeros((frames_i, 2), dtype=np.float32)
            self._mix_voice_map(out, voices_map, g_samp, frames_i, sr_i, sppb, rt=rt, any_solo=any_solo, bridge=bridge)
            return out

        # Swap path: tiny crossfade to avoid clicks
        out_new = np.zeros((frames_i, 2), dtype=np.float32)
        self._mix_voice_map(out_new, voices_map, g_samp, frames_i, sr_i, sppb, rt=rt, any_solo=any_solo, bridge=bridge)

        fade_n = int(min(frames_i, int(self._swap_xfade_frames)))
        if not old_map or fade_n <= 0:
            return out_new

        out_old = np.zeros((fade_n, 2), dtype=np.float32)
        self._mix_voice_map(out_old, old_map, g_samp, fade_n, sr_i, sppb, rt=rt, any_solo=any_solo, bridge=bridge)

        ramp = np.linspace(0.0, 1.0, num=fade_n, endpoint=False, dtype=np.float32).reshape((fade_n, 1))
        out_new[:fade_n, :] = (out_old * (1.0 - ramp)) + (out_new[:fade_n, :] * ramp)
        return out_new

    def _mix_voice_map(self, out, voices_map: Dict[str, _Voice], g_samp: int, frames: int, sr: int, sppb: float, *, rt=None, any_solo: bool = False, bridge=None) -> None:  # noqa: ANN001
        for v in list(voices_map.values()):
            try:
                self._mix_voice(out, v, g_samp, frames, sr, sppb, rt=rt, any_solo=any_solo, bridge=bridge)
            except Exception:
                continue

    def _get_global_playhead_samples(self, sr: int) -> int:
        # Prefer external audio-thread clock
        try:
            if bool(getattr(self.transport, "playing", False)):
                ext = getattr(self.transport, "_external_playhead_samples", None)
                ext_sr = float(getattr(self.transport, "_external_sample_rate", 0.0) or 0.0)
                if ext is not None and ext_sr > 1.0:
                    # Convert if needed (rare)
                    if abs(ext_sr - float(sr)) < 1e-3:
                        return int(ext)
                    # scale samples from ext_sr to sr
                    return int(round((float(ext) / ext_sr) * float(sr)))
        except Exception:
            pass

        # Fallback: derive from beat (lower precision)
        try:
            beat = float(getattr(self.transport, "current_beat", 0.0) or 0.0)
            bpm = float(getattr(self.project.ctx.project, "bpm", getattr(self.project.ctx.project, "tempo_bpm", 120.0)) or 120.0)
            bps = bpm / 60.0
            sppb = float(sr) / float(bps) if bps > 1e-9 else float(sr)
            return int(round(beat * sppb))
        except Exception:
            # Last-resort monotonic counter
            if sr != int(self._fallback_sr):
                self._fallback_sr = int(sr)
                self._fallback_playhead_samples = 0
            cur = int(self._fallback_playhead_samples)
            self._fallback_playhead_samples += 0  # will be advanced by engine, not here
            return cur

    def _mix_voice(self, out, v: _Voice, g_samp: int, frames: int, sr: int, sppb: float, *, rt=None, any_solo: bool = False, bridge=None) -> None:  # noqa: ANN001
        # Live track params (volume/pan/mute/solo) — applied in realtime
        tid = str(getattr(v, "track_id", "") or "")
        tr_gain = float(getattr(v, "track_gain", 1.0) or 1.0)
        tr_pan = float(getattr(v, "track_pan", 0.0) or 0.0)
        try:
            if rt is not None and tid:
                if bool(getattr(rt, "is_track_muted")(tid)):
                    return
                if bool(any_solo) and not bool(getattr(rt, "is_track_solo")(tid)):
                    return
                tr_gain = float(getattr(rt, "get_track_vol")(tid))
                tr_pan = float(getattr(rt, "get_track_pan")(tid))
        except Exception:
            pass

        # Decode audio
        data = self._load_audio(v.file_path, sr)
        if data is None:
            return

        # Compute gains (clip * track) + equal-power pan (clip + track pan)
        gl, gr = self._pan_gains(float(v.gain) * float(tr_gain), float(v.pan) + float(tr_pan))

        # Meter hook (optional): update TrackMeterRing backed by HybridAudioCallback
        meter = None
        try:
            if bridge is not None and tid:
                idx = None
                if hasattr(bridge, "try_get_track_idx"):
                    idx = bridge.try_get_track_idx(tid)
                else:
                    idx = getattr(bridge, "_track_id_to_idx", {}).get(tid)
                if idx is not None:
                    cb = getattr(bridge, "callback", None)
                    if cb is not None:
                        meter = cb.get_track_meter(int(idx))
        except Exception:
            meter = None

        # Clip-local loop in samples
        loop_s = int(round(float(v.loop_start_beats) * sppb))
        loop_e = int(round(float(v.loop_end_beats) * sppb))
        if loop_e <= loop_s:
            return
        loop_span = max(1, loop_e - loop_s)

        # Global start sample of this voice
        start_samp = int(round(float(v.start_beat) * sppb))

        # This pull call corresponds to [g_samp, g_samp+frames)
        rel0 = g_samp - start_samp
        if rel0 + frames <= 0:
            # not started yet
            return

        # Determine segment inside the current buffer that overlaps the active region
        buf_off = 0
        if rel0 < 0:
            buf_off = int(-rel0)
            rel0 = 0
        n_remain = frames - buf_off
        if n_remain <= 0:
            return

        # Clip-local sample at buffer start (wrapped into loop)
        local0 = loop_s + (rel0 % loop_span)

        # Process possibly multiple wraps inside this block
        write_pos = buf_off
        while n_remain > 0:
            seg_local = local0
            seg_avail = min(n_remain, (loop_e - seg_local))
            if seg_avail <= 0:
                # wrap
                local0 = loop_s
                continue

            # Map [seg_local, seg_local+seg_avail) -> events
            self._mix_events_segment(out, data, v, v.events, seg_local, seg_avail, sr, sppb, write_pos, gl, gr, meter=meter)

            write_pos += int(seg_avail)
            n_remain -= int(seg_avail)
            local0 = loop_s  # next segment starts at loop start

    def _mix_events_segment(self, out, data, v: _Voice, events, seg_local_samp: int, seg_len: int, sr: int, sppb: float, write_pos: int, gl: float, gr: float, *, meter=None) -> None:  # noqa: ANN001
        # Convert segment to beats in clip timeline
        seg_start_beat = float(seg_local_samp) / float(sppb)
        seg_end_beat = float(seg_local_samp + seg_len) / float(sppb)

        # Tape-style rate (preview): pitch + stretch.
        try:
            pitch_st = float(getattr(v, 'pitch', 0.0) or 0.0)
        except Exception:
            pitch_st = 0.0
        try:
            stretch = float(getattr(v, 'stretch', 1.0) or 1.0)
        except Exception:
            stretch = 1.0
        if stretch <= 1e-6:
            stretch = 1.0
        try:
            _rate = (2.0 ** (pitch_st / 12.0)) / float(stretch)
        except Exception:
            _rate = 1.0

        # Iterate events overlapping this segment
        for e in events:
            try:
                e_start = float(getattr(e, "start_beats", 0.0) or 0.0)
                e_len = float(getattr(e, "length_beats", 0.0) or 0.0)
                e_end = e_start + max(0.0, e_len)
                if e_end <= seg_start_beat or e_start >= seg_end_beat:
                    continue
                ov_start_beat = max(seg_start_beat, e_start)
                ov_end_beat = min(seg_end_beat, e_end)
                if ov_end_beat <= ov_start_beat:
                    continue

                # Destination slice in output
                dst_off = int(round((ov_start_beat - seg_start_beat) * sppb))
                n = int(round((ov_end_beat - ov_start_beat) * sppb))
                if n <= 0:
                    continue

                # Source slice in file
                src_off_beats = float(getattr(e, "source_offset_beats", 0.0) or 0.0)
                src_beat = src_off_beats + (ov_start_beat - e_start)
                src_off = int(round(src_beat * sppb))
                src_end = src_off + n
                if src_off >= int(data.shape[0]):
                    continue
                if src_end > int(data.shape[0]):
                    src_end = int(data.shape[0])
                    n = int(src_end - src_off)
                if n <= 0:
                    continue

                if np is None:
                    continue
                if abs(float(_rate) - 1.0) < 1e-6:
                    chunk = data[src_off:src_off + n]
                else:
                    # Linear interpolation resample (preview quality)
                    idx = float(src_off) + (np.arange(int(n), dtype=np.float32) * float(_rate))
                    i0 = np.floor(idx).astype(np.int64)
                    i1 = i0 + 1
                    max_i = int(data.shape[0]) - 1
                    i0 = np.clip(i0, 0, max_i)
                    i1 = np.clip(i1, 0, max_i)
                    frac = (idx - i0.astype(np.float32)).reshape((-1, 1))
                    s0 = data[i0]
                    s1 = data[i1]
                    chunk = (s0 * (1.0 - frac) + s1 * frac).astype(np.float32)
                try:
                    if meter is not None:
                        meter.update_from_block(chunk, gl, gr)
                except Exception:
                    pass
                out[write_pos + dst_off:write_pos + dst_off + n, 0] += chunk[:n, 0] * gl
                out[write_pos + dst_off:write_pos + dst_off + n, 1] += chunk[:n, 1] * gr
            except Exception:
                continue

    def _load_audio(self, path: str, sr: int):  # noqa: ANN001
        if np is None:
            return None
        key = (str(path), int(sr))
        cached = self._audio_cache.get(key)
        if cached is not None:
            return cached
        try:
            import soundfile as sf  # type: ignore
        except Exception:
            return None
        try:
            data, file_sr = sf.read(str(path), dtype="float32", always_2d=True)
        except Exception:
            return None
        if data.shape[1] == 1:
            data = np.repeat(data, 2, axis=1)
        elif data.shape[1] >= 2:
            data = data[:, :2]
        file_sr_i = int(file_sr)
        if file_sr_i != int(sr) and int(data.shape[0]) > 1:
            ratio = float(sr) / float(file_sr_i)
            n_out = max(1, int(round(int(data.shape[0]) * ratio)))
            x_old = np.linspace(0.0, 1.0, num=int(data.shape[0]), endpoint=False)
            x_new = np.linspace(0.0, 1.0, num=n_out, endpoint=False)
            data = np.vstack([
                np.interp(x_new, x_old, data[:, 0]),
                np.interp(x_new, x_old, data[:, 1]),
            ]).T.astype(np.float32, copy=False)
        self._audio_cache[key] = data
        # basic cache trimming
        if len(self._audio_cache) > 32:
            try:
                for k in list(self._audio_cache.keys())[:8]:
                    self._audio_cache.pop(k, None)
            except Exception:
                pass
        return data

    @staticmethod
    def _pan_gains(gain: float, pan: float) -> Tuple[float, float]:
        pan = max(-1.0, min(1.0, float(pan)))
        angle = (pan + 1.0) * (math.pi / 4.0)
        return float(gain) * math.cos(angle), float(gain) * math.sin(angle)
