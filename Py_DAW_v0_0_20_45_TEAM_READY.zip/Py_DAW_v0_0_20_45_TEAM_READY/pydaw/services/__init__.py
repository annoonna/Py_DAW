"""Service layer (shared application services)."""
