# Session Log — v0.0.20.45 Drum Machine Hotfix (Pull Wrapper)

**Date:** 2026-02-09  
**Developer:** GPT-5.2 Thinking  
**Duration:** ~10 min  

## Task

Hotfix: Pro Drum Machine zeigte beim Einfügen ein Fehler-Overlay, weil `_pydaw_track_id` an einem bound-method (`self.engine.pull`) gesetzt wurde.

## Ergebnis

- Pull-Source wird jetzt über eine Wrapper-Funktion registriert (wie im Sampler)
- `_pydaw_track_id` ist wieder setzbar (dynamischer Getter)
- Device lädt ohne Fehler-Overlay; Track-Fader/VU-Meter bleiben kompatibel

## Details

Siehe: `PROJECT_DOCS/sessions/2026-02-09_SESSION_DRUM_MACHINE_HOTFIX_PULL_WRAPPER_v0.0.20.45.md`
