#!/bin/bash
# Helper: Find remaining 2 Rust compile errors
# Run this in the project directory after applying the v0.0.20.996 fixes

echo "=== Building Rust Engine ==="
cd pydaw_engine

echo ""
echo "=== ERRORS ONLY ==="
cargo build --release 2>&1 | grep "^error"

echo ""
echo "=== FULL ERROR CONTEXT ==="
cargo build --release 2>&1 | grep -B5 "^error\[" | head -60

echo ""
echo "If 0 errors: 🎉 Rust Build OK! Run ./start_daw.sh"
echo "If errors remain: the 'error[EXXXX]' lines show exactly what to fix"
