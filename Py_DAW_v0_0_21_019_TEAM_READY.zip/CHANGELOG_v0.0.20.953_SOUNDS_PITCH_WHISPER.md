# CHANGELOG v0.0.20.953 — Sounds-Tab Info + Pitch C0–C9 + Whisper Deps

**Datum:** 2026-04-03
**Autor:** Claude Opus 4.6

## Änderungen

### Sounds-Tab: Szenen-Position
- Beat-Position, Bar-Nummer, Länge in Beats/Sekunden anzeigen
- "Track wird an Beat X erstellt, Länge Y Beats" Info
- Preset-Liste: Key/Mode in Klammern

### Pitch-Range C0–C9
- Pad/Arp: 12–120 (vorher 24–108)
- Bass: 12–84 deep bass (vorher 24–72)
- Lead: 36–120 (vorher 48–108)
- Scale-Generator: 5 Oktaven

### Whisper Dependencies
- requirements.txt: openai-whisper
- install.py: Auto-Install mit Fallback
- start_daw.sh: Auto-Detect + Install

### VIDEO_HANDBUCH.md
- 20 Kapitel Benutzerhandbuch (Video + Video-KI)

## Stats
445/445 | 0 Fehler | Nichts kaputt
