# CHANGELOG v0.0.20.996 — Rust Build Fix + Dashboard + PipeWire

**Datum:** 2026-04-04
**Autor:** Claude Opus 4.6
**Arbeitspaket:** Bugfixes aus Betriebstest

## Problembeschreibung (aus Anno's Screenshots + Logs)

1. **Rust Engine kompiliert nicht** — `cargo build` scheitert mit 5 Errors (E0062)
2. **CPU/Latenz/XRun im Dashboard immer 0** — kein AudioStatusReport von Rust
3. **PipeWire Panel "Wird erkannt..."** — QTimer.singleShot aus Thread = broken in PyQt6
4. **AudioStatus Spam** — 100+ WARN-Zeilen/Sekunde im Log
5. **"main.py antwortet nicht"** — Startup-Block durch viele IPC-Fehlversuche

## Fixes

### 1. Rust Build Error — `audio_output.rs` (3 von 5 E0062 Errors behoben)

**Problem:** `AudioOutputShared::new()` hatte 3 duplizierte Felder:
```rust
Self {
    running: AtomicBool::new(false),
    xrun_count: AtomicU32::new(0),         // ← OK
    actual_buffer_size: AtomicU32::new(0),  // ← OK
    actual_sample_rate: AtomicU32::new(0),  // ← OK
    render_time_us: AtomicU32::new(0),      // ← OK
    xrun_count: AtomicU32::new(0),          // ← DUPLIKAT entfernt
    actual_buffer_size: AtomicU32::new(0),  // ← DUPLIKAT entfernt
    actual_sample_rate: AtomicU32::new(0),  // ← DUPLIKAT entfernt
}
```

**Fix:** Zeilen 112–114 entfernt.

**Hinweis:** 2 weitere Compile-Errors bleiben. Diese sind NICHT E0062 (keine weiteren
Duplikate gefunden). Nach `cargo build --release` werden die restlichen Errors sichtbar.

### 2. PipeWire Sync Panel — Thread-Safe Fix

**Problem:** `_query_pipewire_status()` in `audio_settings_dialog.py` rief
`QTimer.singleShot(0, lambda)` aus einem `threading.Thread` — in PyQt6 kommt
das Event nie im Main-Thread an → Labels bleiben auf "Wird erkannt…".

**Fix:** Thread speichert Ergebnis in `self._pw_query_result`, Main-Thread pollt
mit `QTimer.singleShot(100, _check)` bis Ergebnis da (max 2s Timeout).

### 3. AudioStatus Spam reduziert

**Problem:** `RustDashboardWidget._poll_engine()` feuerte `bridge.audio_status()`
alle 500ms, auch wenn die Rust-Engine den Command nicht kennt → hunderte
`[WARN] Failed to decode command: unknown variant AudioStatus` pro Minute.

**Fix:** Polling nur wenn `self._engine_active == True` (wird via `set_connected()`
gesetzt wenn AudioStarted empfangen wird).

### 4. Analyse: Warum CPU 0% zeigt

Die Handler `_on_rust_dashboard_status()`, `_on_rust_dashboard_started()`,
`_on_rust_dashboard_stopped()` existieren korrekt in `main_window_engine.py`
(EngineRustMixin). Der Grund für CPU=0% ist die Fehler-Kette:

1. Rust Build scheitert → alte Binary läuft (ohne AudioStatus-Support)
2. `AudioStatus` Command wird nicht erkannt → kein `AudioStatusReport` Event
3. `_on_rust_dashboard_status()` wird nie aufgerufen → CPU/Latenz = 0

**Lösung:** Rust Build fixen (Schritt 1 hier getan, restliche 2 Errors offen).

## Geänderte Dateien

| Datei | Änderung |
|-------|----------|
| `pydaw_engine/src/audio_output.rs` | 3 duplizierte Felder entfernt (E0062 Fix) |
| `pydaw/ui/audio_settings_dialog.py` | PipeWire-Query: Thread-safe Polling statt QTimer-aus-Thread |
| `pydaw/ui/rust_dashboard_widget.py` | AudioStatus-Polling nur bei aktiver Engine |
| `VERSION` | 0.0.20.995 → 0.0.20.996 |

## Nächste Schritte

1. `cargo build --release` — restliche 2 Compile-Errors sichtbar machen + fixen
2. Rust Audio testen (Instrument über Rust-Output statt sounddevice)
3. VIDEO_EDITOR_ROADMAP ab VE8 weiter
