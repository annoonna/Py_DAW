# CHANGELOG v0.0.20.950 — VE11-VE13 KI Text-Editing + Smart Cut + Mood Matcher

**Datum:** 2026-04-02
**Autor:** Claude Opus 4.6
**Arbeitspaket:** VIDEO_EDITOR_ROADMAP VE11, VE12, VE13

## Was wurde gemacht

### VE11: KI Text-Editing (Whisper Integration)
- WhisperService: Lokale Whisper-Transkription (faster-whisper / openai-whisper / Stub-Fallback)
- VideoTextEditorPanel: Interaktiver Text-Editor neben der Timeline
- Wort-Klick → Playhead springt zum Zeitpunkt
- Wort löschen → Video wird dort geschnitten (Jump Cut)
- Strikethrough-Highlighting für gelöschte Wörter
- Word-Boundary-Marker auf der Timeline (blau = aktiv, rot = gelöscht)
- SRT/VTT/Text-Export via VideoSubtitleExport
- TranscriptHighlighter mit Echtzeit-Playhead-Tracking
- SQLite-Persistenz für Transkripte (video_transcripts Tabelle)
- Python Console API: video.transcribe(), video.transcript(), video.words(), video.export_srt/vtt()

### VE12: KI Smart Cut
- SmartCutService mit 4 Analyse-Modulen
- Filler-Erkennung: "ähm/uhh" in 5 Sprachen + universal
- Pausen-Erkennung: Stille >0.8s / >1.5s automatisch
- Wiederholungs-Erkennung: Stotterer und Neuanfänge
- Low-Confidence-Erkennung: unsichere Whisper-Stellen
- Highlight Reel: Beste Segmente nach Score auswählen
- Compress-to-Duration: Automatisch auf Zieldauer kürzen
- SmartCutPanel mit One-Click Buttons für jede Kategorie
- Auto-Clean: Nur sichere Vorschläge anwenden

### VE13: KI Mood Matcher
- MoodMatcherService: Referenz-basiertes Color Grading
- 15 Film-Look Presets (Cinematic, Noir, Teal/Orange, Vintage, etc.)
- Referenz-Clip Analyse via ffprobe signalstats
- ffmpeg eq/colorbalance Filter-Generierung
- Audio-EQ Matching: Loudness + Frequenzbalance übertragen
- MoodMatcherPanel: Preset-Gallery + Referenz-Loader
- Integration mit VideoFilterService (non-destructive chain)

## Neue Dateien
| Datei | LOC | Inhalt |
|-------|-----|--------|
| pydaw/services/video_whisper_service.py | 480 | Whisper Transkription |
| pydaw/services/video_subtitle_export.py | 210 | SRT/VTT/Text Export |
| pydaw/services/video_smart_cut.py | 415 | KI Smart Cut Engine |
| pydaw/services/video_mood_matcher.py | 430 | Mood Matcher + Presets |
| pydaw/ui/video_text_editor.py | 470 | Text-Editor Panel |
| pydaw/ui/video_smart_cut_panel.py | 310 | Smart Cut Panel |
| pydaw/ui/video_mood_panel.py | 260 | Mood Matcher Panel |

## Geänderte Dateien
| Datei | Änderung |
|-------|----------|
| pydaw/ui/video_editor.py | VE11 Text-Editor Splitter + Word-Marker Drawing |
| pydaw/services/video_state_db.py | video_transcripts Tabelle |
| pydaw/services/scripting_service.py | transcript/subtitle API |

## Stats
439/439 kompilieren | 0 Fehler | Nichts kaputt
