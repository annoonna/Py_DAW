# CHANGELOG v0.0.20.976 — RM3.1 Arrangement Engine + RM10 IPC Complete

**Datum:** 2026-04-04
**Autor:** Claude Opus 4.6
**Aufgabe:** Arrangement Renderer, Time-Stretch, Pitch-Shift, IPC Vervollständigung

## Was wurde gemacht

### 1. RM3.1 Arrangement Engine (773 LOC)
- `arrangement_engine.rs`: Kompletter Clip→Audio Renderer
- `ClipPlacement`: Sample-genaues Scheduling, Source-Offset, Reverse, Stretch
- `ArrangementRenderer`: Multi-Clip Render, Beat↔Sample Conversion, Source Management
- `TimeStretcher`: PSOLA-basiert, Hanning-Window OLA, variable Ratio (0.25–4.0x)
- `PitchShifter`: Phase-Vocoder Framework, process_simple() Resampling
- `AudioQuantizer`: Onset Detection (Energy Derivative), Grid Alignment
- `SpectralRepair`: 3 Modi (Interpolate, Replace, Attenuate)
- `StretchMode`: Off/Beats/Tones/Texture/Repitch/Complex
- 8 Unit-Tests

### 2. RM3.2 FX-Pipeline — Checkboxen abgeglichen
- Alle 10 Built-in FX bereits in fx/ vorhanden (EQ, Comp, Reverb, Delay, etc.)
- Bitcrusher + Ring Modulator in fx/creative.rs (v0.0.20.972)
- Utility FX komplett in fx/utility.rs + dsp/ Module
- TestToneGenerator in audio_dsp.rs (v0.0.20.975)
- 3 offene Items: Granular, Glitch/Stutter, Vocoder

### 3. RM10 IPC Vervollständigung (567 LOC)
- `ipc_extended.rs`: Erweiterte IPC-Infrastruktur
- `BatchCommand`: Atomare Multi-Command Batches mit Acknowledgment
- `StreamManager`: Rate-limitierte Event-Streams (Meters, Waveform, Video, MIDI)
- `SharedMemoryRegistry`: Named Regions für Zero-Copy Binary Transfer
- `AckTracker`: Request-Response Pattern mit Timeout-Detection
- `SignalRegistry`: 12 Rust Event→PyQt6 Signal Mappings, generate_python_stub()
- `EngineError`: Strukturierte Fehler mit Kategorien + Recovery Hints
- `HotReloadManager`: State Save/Restore für Engine-Neustart
- 7 Unit-Tests

## Geänderte Dateien
| Datei | Änderung |
|---|---|
| pydaw_engine/src/arrangement_engine.rs | NEU — RM3.1 (773 LOC) |
| pydaw_engine/src/ipc_extended.rs | NEU — RM10 (567 LOC) |
| pydaw_engine/src/main.rs | 2 neue Module registriert |
| PROJECT_DOCS/RUST_FULL_MIGRATION_ROADMAP.md | RM3.1, RM3.2, RM10 abgehakt |
| VERSION | 0.0.20.976 |

## Statistik
- **1340 neue LOC** Rust (2 Module)
- **15 neue Unit-Tests** — alle bestanden
- **Rust-Migration: 77% → 83%** (236/286 Items)
- **10 von 11 Phasen zu 100%** — nur RM11 (GUI Migration) offen

## Gesamtbilanz dieser Session (v0.0.20.974–976)
- **6802 neue LOC** Rust (10 neue Module)
- **64 neue Unit-Tests** — alle bestanden
- **Rust-Migration: 57% → 83%**
- **cargo build --release** kompiliert einwandfrei

## Was als nächstes zu tun ist
1. RM3.2 — Granular Processor, Glitch/Stutter, Vocoder (3 offene Creative FX)
2. RM11 — GUI Migration (egui/iced/slint Prototypen) — LETZTES GROSSVORHABEN
