# CHANGELOG v0.0.21.012 — SC1+SC2 Scripting Console Instrument-Proxys

**Datum:** 2026-04-08
**Kollege:** Claude Opus 4.6

## Neue Dateien
- `pydaw/services/scripting_proxies.py` (520 LOC) — Proxy-Framework + 6 Instrument-Proxys

## Geänderte Dateien (3)
- `pydaw/services/scripting_service.py` — `_device_panel`, `set_device_panel()`, `instruments` global
- `pydaw/ui/main_window.py` — DevicePanel→ScriptingService wire
- `PROJECT_DOCS/SCRIPTING_CONSOLE_ROADMAP.md` — SC1/SC2 Checkboxen

## Features
- **instruments["Track"]** → Typisierter Proxy für das Instrument auf dem Track
- **Pro Drum Machine**: 16 Properties pro Slot, load/clear/trigger
- **Pro Sampler**: gain/pan/root/loop/filter/cutoff/ADSR/fx/region
- **AETERNA**: params/set/get/wavetable/preset
- **Fusion**: params/set/get
- **BRRR**: params/trigger
- **Bach Orgel**: params/set/get
- Automatische Erkennung des Instrument-Typs via plugin_id
- help() auf jedem Proxy
