"""Installer helper for Py_DAW.

Usage:
    python3 install.py

It will:
- warn if you're not inside a virtual environment
- install/upgrade pip
- install requirements.txt

Note:
- JACK/PipeWire system components are not installed here (distro packages).
"""

from __future__ import annotations

import os
import sys
import subprocess
from pathlib import Path


def _which(cmd: str) -> str | None:
    """Return full path if a command exists on PATH."""
    for p in os.environ.get("PATH", "").split(os.pathsep):
        cand = Path(p) / cmd
        if cand.exists() and os.access(cand, os.X_OK):
            return str(cand)
    return None


def _is_debian_like() -> bool:
    """Best-effort detection for Debian/Ubuntu/Kali family."""
    if sys.platform != "linux":
        return False
    try:
        txt = Path("/etc/os-release").read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return False
    low = txt.lower()
    return ("id_like=" in low and "debian" in low) or ("id=" in low and any(k in low for k in ("kali", "debian", "ubuntu", "linuxmint")))


def _is_arch_like() -> bool:
    """Best-effort detection for Arch Linux / SteamOS / Manjaro family."""
    if sys.platform != "linux":
        return False
    try:
        txt = Path("/etc/os-release").read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return False
    low = txt.lower()
    if any(k in low for k in ("id=arch", "id=steamos", "id=manjaro", "id=endeavouros", "id=garuda", "id=cachyos")):
        return True
    if "id_like=" in low and "arch" in low:
        return True
    # Fallback: check for pacman
    return _which("pacman") is not None and not _is_debian_like()


def _dpkg_installed(pkg: str) -> bool:
    try:
        out = subprocess.check_output(["dpkg-query", "-W", "-f=${Status}", pkg], stderr=subprocess.DEVNULL)
        return b"install ok installed" in out
    except Exception:
        return False


def _maybe_install_lv2_deps() -> None:
    """Optional system deps for LV2 hosting (safe/best-effort).

    On Debian/Kali, the LV2 python binding + utilities are typically provided
    by distro packages:
        - python3-lilv
        - lilv-utils

    This step must NEVER abort the installer.
    """

    if not _is_debian_like():
        return
    if not _which("apt-get"):
        return

    pkgs = ["python3-lilv", "lilv-utils"]
    missing = [p for p in pkgs if not _dpkg_installed(p)]
    if not missing:
        return

    print("\n[LV2] Systempakete fehlen:", ", ".join(missing))
    print("[LV2] Versuche diese automatisch zu installieren (best-effort)…")
    print("      Falls das fehlschlägt, führe manuell aus:")
    print("      sudo apt update && sudo apt install python3-lilv lilv-utils\n")

    # Try root first.
    try:
        if hasattr(os, "geteuid") and os.geteuid() == 0:
            _run(["apt-get", "update"])
            _run(["apt-get", "install", "-y", *missing])
            return
    except Exception as exc:
        print("WARN: apt-get (root) failed:", exc)

    sudo = _which("sudo")
    if not sudo:
        return
    try:
        _run([sudo, "apt-get", "update"])
        _run([sudo, "apt-get", "install", "-y", *missing])
    except Exception as exc:
        print("WARN: sudo apt-get failed:", exc)


def _maybe_install_vst2_plugins() -> None:
    """Optional: check for common VST2 plugin packages (Debian/Kali).

    VST2 hosting uses pure ctypes — no Python packages needed.
    This just checks if common VST2 .so plugins are installed.
    v0.0.20.395
    """
    if not _is_debian_like():
        return

    vst2_dir = Path("/usr/lib/vst")
    if vst2_dir.exists():
        so_count = len(list(vst2_dir.glob("*.so")))
        if so_count > 0:
            print(f"\n[VST2] {so_count} VST2 Plugins gefunden in {vst2_dir}")
            return

    # Suggest common packages
    print("\n[VST2] Keine VST2 Plugins gefunden in /usr/lib/vst/")
    print("[VST2] Empfohlene Pakete (optional):")

    suggestions = [
        ("helm", "Helm Wavetable Synthesizer"),
        ("zam-plugins", "Zam Audio Plugins (Compressor, EQ, etc.)"),
        ("tal-plugins", "TAL Audio Plugins (Reverb, Filter, etc.)"),
        ("zynaddsubfx-vst", "ZynAddSubFX Synthesizer"),
    ]
    for pkg, desc in suggestions:
        installed = _dpkg_installed(pkg)
        status = "✓" if installed else "✗"
        print(f"  {status} {pkg} — {desc}")

    print("  Installieren mit: sudo apt install helm zam-plugins")
    print("  VST2 Hosting benötigt KEINE Python-Pakete (reines ctypes).\n")


def _pacman_installed(pkg: str) -> bool:
    """Check if a pacman package is installed (Arch/SteamOS)."""
    try:
        subprocess.check_call(
            ["pacman", "-Qi", pkg],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def _maybe_install_arch_deps() -> None:
    """Install system dependencies on Arch Linux / SteamOS.

    These are packages that cannot be installed via pip and must come
    from pacman. Without them, audio output, JACK bridge, and plugin
    hosting will not work.
    """
    if not _is_arch_like():
        return
    if not _which("pacman"):
        return

    # Essential audio packages for Py_DAW on Arch/SteamOS
    pkgs = [
        "pipewire-jack",     # JACK compatibility layer (PipeWire)
        "pipewire-alsa",     # ALSA → PipeWire bridge (for sounddevice)
        "portaudio",         # C library for python-sounddevice
        "lilv",              # LV2 plugin hosting
        "fluidsynth",        # SF2 soundfont support
    ]
    missing = [p for p in pkgs if not _pacman_installed(p)]
    if not missing:
        print("\n[ARCH] ✅ Alle System-Abhängigkeiten installiert.")
        return

    print("\n[ARCH] System-Pakete fehlen:", ", ".join(missing))
    print("[ARCH] Versuche automatische Installation (best-effort)…")
    print("       Falls das fehlschlägt, führe manuell aus:")
    print(f"       sudo pacman -S --needed {' '.join(missing)}\n")

    sudo = _which("sudo")
    if not sudo:
        return
    try:
        _run([sudo, "pacman", "-S", "--needed", "--noconfirm", *missing])
    except Exception as exc:
        print("WARN: pacman install failed:", exc)


def _maybe_install_arch_plugins() -> None:
    """Check for common plugin packages on Arch (optional)."""
    if not _is_arch_like():
        return

    vst3_dir = Path("/usr/lib/vst3")
    vst2_dir = Path("/usr/lib/vst")
    clap_dir = Path("/usr/lib/clap")

    has_plugins = False
    for d in (vst3_dir, vst2_dir, clap_dir):
        if d.exists() and any(d.iterdir()):
            has_plugins = True
            break

    if has_plugins:
        count = 0
        for d in (vst3_dir, vst2_dir, clap_dir):
            if d.exists():
                count += sum(1 for _ in d.iterdir())
        print(f"\n[ARCH] {count} externe Plugins gefunden (VST2/VST3/CLAP)")
        return

    print("\n[ARCH] Keine externen Plugins gefunden.")
    print("[ARCH] Empfohlene Pakete (AUR oder Community):")
    suggestions = [
        ("surge-xt", "Surge XT Synthesizer (VST3 + CLAP)"),
        ("lsp-plugins", "LSP Audio Plugins (VST3 + CLAP)"),
        ("zynaddsubfx", "ZynAddSubFX Synthesizer (VST2)"),
    ]
    for pkg, desc in suggestions:
        installed = _pacman_installed(pkg)
        status = "✓" if installed else "✗"
        print(f"  {status} {pkg} — {desc}")
    print("  Installieren mit: sudo pacman -S lsp-plugins surge-xt")
    print("  Oder via AUR: yay -S surge-xt-bin\n")


def _check_ffmpeg() -> None:
    """v0.0.20.925: Check for ffmpeg/ffprobe system binaries.

    Required for Video-Integration Pro (VP2–VP10):
    - Thumbnails, Video-Track duration probe, Filter export,
      Multi-video compositing, audio format conversion.

    Attempts auto-install on Debian/Arch if missing.
    """
    ffmpeg_ok = _which("ffmpeg") is not None
    ffprobe_ok = _which("ffprobe") is not None

    if ffmpeg_ok and ffprobe_ok:
        print("\n[VIDEO] ✅ ffmpeg + ffprobe gefunden")
        return

    missing = []
    if not ffmpeg_ok:
        missing.append("ffmpeg")
    if not ffprobe_ok:
        missing.append("ffprobe")

    print(f"\n[VIDEO] ⚠️  Fehlend: {', '.join(missing)}")
    print("[VIDEO] Video-Features (Thumbnails, Filter, Export) benötigen ffmpeg.")

    # Try auto-install
    if _is_debian_like() and _which("apt-get"):
        print("[VIDEO] Versuche automatische Installation (Debian/Ubuntu/Kali)...")
        try:
            sudo = _which("sudo")
            if hasattr(os, "geteuid") and os.geteuid() == 0:
                _run(["apt-get", "update"])
                _run(["apt-get", "install", "-y", "ffmpeg"])
            elif sudo:
                _run([sudo, "apt-get", "update"])
                _run([sudo, "apt-get", "install", "-y", "ffmpeg"])
        except Exception as exc:
            print(f"WARN: ffmpeg auto-install failed: {exc}")
            print("  Manuell: sudo apt install ffmpeg")

    elif _is_arch_like() and _which("pacman"):
        print("[VIDEO] Versuche automatische Installation (Arch/SteamOS)...")
        try:
            sudo = _which("sudo")
            if sudo:
                _run([sudo, "pacman", "-S", "--needed", "--noconfirm", "ffmpeg"])
        except Exception as exc:
            print(f"WARN: ffmpeg auto-install failed: {exc}")
            print("  Manuell: sudo pacman -S ffmpeg")

    else:
        print("[VIDEO] Bitte manuell installieren:")
        print("  Debian/Ubuntu/Kali:  sudo apt install ffmpeg")
        print("  Arch/SteamOS:        sudo pacman -S ffmpeg")
        print("  Fedora:              sudo dnf install ffmpeg-free")
        print("  macOS:               brew install ffmpeg")


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def main() -> int:
    here = Path(__file__).resolve().parent
    req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))

    # Always run installs inside a local venv to avoid PEP 668 ("externally-managed-environment")
    # on Kali/Debian. This is SAFE: it does not modify system site-packages.
    py = sys.executable
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        print("      Empfehlung: python3 -m venv myenv && source myenv/bin/activate")
        venv_dir = here / "myenv"
        if os.name == "nt":
            vpy = venv_dir / "Scripts" / "python.exe"
        else:
            vpy = venv_dir / "bin" / "python3"
            if not vpy.exists():
                vpy = venv_dir / "bin" / "python"
        if vpy.exists():
            print(f"INFO: Verwende vorhandenes venv: {venv_dir}")
            py = str(vpy)
        else:
            print("INFO: Erstelle lokales venv ./myenv (safe, keine System-Änderung) ...")
            try:
                subprocess.check_call([sys.executable, "-m", "venv", "--system-site-packages", str(venv_dir)])
            except Exception:
                subprocess.check_call([sys.executable, "-m", "venv", str(venv_dir)])
            if not vpy.exists():
                # Refresh python path after creation
                if os.name == "nt":
                    vpy = venv_dir / "Scripts" / "python.exe"
                else:
                    vpy = venv_dir / "bin" / "python3"
                    if not vpy.exists():
                        vpy = venv_dir / "bin" / "python"
            py = str(vpy)
        print("INFO: Installer nutzt Python:", py)


    # Optional: system packages for LV2 hosting (Debian/Kali)
    # Best-effort only: never abort the installer.
    try:
        _maybe_install_lv2_deps()
    except Exception as exc:
        print("WARN: LV2 deps check/install failed:", exc)

    # Optional: VST2 plugin packages (Debian/Kali)
    try:
        _maybe_install_vst2_plugins()
    except Exception as exc:
        print("WARN: VST2 plugin check failed:", exc)

    # Arch Linux / SteamOS: system packages (pipewire-jack, portaudio, etc.)
    try:
        _maybe_install_arch_deps()
    except Exception as exc:
        print("WARN: Arch deps check/install failed:", exc)

    # Arch Linux / SteamOS: plugin packages
    try:
        _maybe_install_arch_plugins()
    except Exception as exc:
        print("WARN: Arch plugin check failed:", exc)

    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    try:
        _run([py, "-m", "pip", "install", "pedalboard"])
    except Exception as exc:
        print("WARN: pedalboard install failed:", exc)

    try:
        _run([py, "-m", "pip", "install", "maturin"])
    except Exception as exc:
        print("WARN: maturin install failed:", exc)

    try:
        _run([py, "-m", "pip", "install", "patchelf"])
    except Exception as exc:
        print("WARN: patchelf install failed:", exc)

    # v0.0.20.798: Collaboration WebSocket support
    try:
        _run([py, "-m", "pip", "install", "websockets"])
    except Exception as exc:
        print("WARN: websockets install failed (Collab-Feature optional):", exc)

    # v0.0.20.862: mDNS/Zeroconf for LAN session discovery
    try:
        _run([py, "-m", "pip", "install", "zeroconf"])
    except Exception as exc:
        print("WARN: zeroconf install failed (LAN-Discovery optional):", exc)

    # v0.0.20.805: SF2 Soundfont realtime engine (Bach Orgel etc.)
    try:
        _run([py, "-m", "pip", "install", "pyfluidsynth"])
    except Exception as exc:
        print("WARN: pyfluidsynth install failed (SF2-Feature optional):", exc)

    # v0.0.20.810: OSC controller support (TouchOSC, Lemur)
    try:
        _run([py, "-m", "pip", "install", "python-osc"])
    except Exception as exc:
        print("WARN: python-osc install failed (OSC-Feature optional):", exc)

    # v0.0.20.810: Gamepad support (Xbox/PS controller as instrument)
    try:
        _run([py, "-m", "pip", "install", "pygame"])
    except Exception as exc:
        print("WARN: pygame install failed (Gamepad-Feature optional):", exc)

    # v0.0.20.925: VP9 advanced video KI (face detection, motion analysis)
    try:
        _run([py, "-m", "pip", "install", "opencv-python-headless"])
    except Exception as exc:
        print("WARN: opencv-python-headless install failed (VP9-Feature optional):", exc)

    # v0.0.20.925: Rust Engine IPC serialization
    try:
        _run([py, "-m", "pip", "install", "msgpack"])
    except Exception as exc:
        print("WARN: msgpack install failed (Rust-Engine-IPC optional):", exc)

    # v0.0.20.952: Whisper für Video Text-Editing (VE11)
    try:
        _run([py, "-m", "pip", "install", "openai-whisper"])
        print("  ✅ openai-whisper installiert (Video-Transkription)")
    except Exception as exc:
        print("WARN: openai-whisper install failed (Video-Transkription optional):", exc)
        print("  Alternative: pip install faster-whisper (schneller, weniger RAM)")

    # v0.0.20.989: KI-Komposition Dokument-Import (KK6)
    try:
        _run([py, "-m", "pip", "install", "pymupdf"])
        print("  ✅ PyMuPDF installiert (PDF-Import für KI-Komposition)")
    except Exception as exc:
        print("WARN: pymupdf install failed (PDF-Import optional):", exc)

    try:
        _run([py, "-m", "pip", "install", "python-docx"])
        print("  ✅ python-docx installiert (Word-Import für KI-Komposition)")
    except Exception as exc:
        print("WARN: python-docx install failed (DOCX-Import optional):", exc)

    # v0.0.20.925: Check for ffmpeg/ffprobe (system binary, needed for video features)
    _check_ffmpeg()

    _run([py, "-m", "pip", "install", "-r", str(req)])

    print("\nOK. Starte danach mit: python3 main.py")
    print("     oder besser:     ./start_daw.sh")
    print()
    print("Optional: Audio/MIDI Abhängigkeiten können Systempakete erfordern (PipeWire-JACK/JACK/ALSA).")
    print("VST2 Plugins: /usr/lib/vst/*.so (ctypes-basiert, keine extra Python-Pakete nötig)")
    print("VST3 Plugins: /usr/lib/vst3/*.vst3 (via pedalboard)")
    print()
    print("Für Rust Audio-Engine (empfohlen für beste Performance):")
    print("    python3 setup_all.py --with-rust")
    print("  Das installiert Rust automatisch und baut die Engine.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
