# CHANGELOG v0.0.20.977 — Creative FX + GUI Framework

**Datum:** 2026-04-04
**Autor:** Claude Opus 4.6
**Aufgabe:** RM3.2 Creative FX komplett, RM11.1-11.5 GUI-Framework

## Was wurde gemacht

### 1. RM3.2 Creative FX komplett (666 LOC neu in creative.rs)
- **Granular Processor**: 64-Grain Pool, Hanning Window, Position Jitter, Scatter, Reverse, Feedback
- **Glitch/Stutter**: 6 Modi (Stutter, Reverse, HalfSpeed, TapeStop, Gate, Shuffle), Beat-synced
- **Vocoder**: 4-32 Band Channel Vocoder, BPF Analyse/Synthese, 5 Carrier-Typen (Noise/Saw/Square/Pulse/Pink)
- 6 Unit-Tests (alle bestanden)
- → **RM3 ist jetzt 100% komplett!**

### 2. RM11.1-11.5 GUI-Framework (8 Dateien, ~1600 LOC)
Framework-unabhängige GUI-Abstraktionsschicht in `gui/` Modul:

- `app_state.rs` — AppState, TransportState, SelectionState, Tool, SnapSettings, Rect
- `theme.rs` — Theme (Dark/Light), Color mit lerp/alpha, 35+ Farbwerte, 16 Track-Farben
- `layout.rs` — LayoutManager, DockPanel, 5 Positionen, Presets, Resize
- `input.rs` — ShortcutManager (35+ Defaults), Action enum, Modifiers, MouseState
- `widgets.rs` — FaderState, KnobState, MeterState (Peak Hold, Clip), ToggleState, DropdownState
- `arranger.rs` — ArrangerState, beat↔pixel, zoom/scroll, ClipVisual, hit-testing, TrackHeaderState
- `pianoroll.rs` — PianoRollState, note↔pixel, NoteVisual, ghost notes, velocity editor
- `mixer.rs` — MixerState, ChannelStrip, FxSlotState, SendState, meter update
- 27 Unit-Tests (alle bestanden)

## Geänderte Dateien
| Datei | Änderung |
|---|---|
| pydaw_engine/src/fx/creative.rs | +666 LOC: Granular, Glitch, Vocoder |
| pydaw_engine/src/gui/mod.rs | NEU — 8 Submodule |
| pydaw_engine/src/gui/app_state.rs | NEU — 250 LOC |
| pydaw_engine/src/gui/theme.rs | NEU — 190 LOC |
| pydaw_engine/src/gui/layout.rs | NEU — 160 LOC |
| pydaw_engine/src/gui/input.rs | NEU — 170 LOC |
| pydaw_engine/src/gui/widgets.rs | NEU — 200 LOC |
| pydaw_engine/src/gui/arranger.rs | NEU — 300 LOC |
| pydaw_engine/src/gui/pianoroll.rs | NEU — 200 LOC |
| pydaw_engine/src/gui/mixer.rs | NEU — 140 LOC |
| pydaw_engine/src/main.rs | gui Modul registriert |
| PROJECT_DOCS/RUST_FULL_MIGRATION_ROADMAP.md | RM3.2+RM11.1-11.5 abgehakt |
| VERSION | 0.0.20.977 |

## Statistik
- **~2260 neue LOC** Rust
- **33 neue Unit-Tests** — alle bestanden
- **Rust-Migration: 84% → 94%** (270/286 Items)
- **11 von 11 Phasen haben Fortschritt!** Davon 10 Phasen ≥92%

## Was als nächstes zu tun ist
1. RM11.6 — Video Editor GUI (6 Items)
2. RM11.7 — Weitere GUI Panels (10 Items)
3. RM11.8 — Plugin-GUI Hosting (3 Items)
4. egui/iced/slint Crate integrieren + thin adapters bauen
