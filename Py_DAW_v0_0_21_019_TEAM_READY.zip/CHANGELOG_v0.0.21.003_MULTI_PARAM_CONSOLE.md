# CHANGELOG v0.0.21.003 — Multi-Param Overlay + Python Console API

**Datum:** 2026-04-06
**Kollege:** Claude Opus 4.6

## Implementierte Features

### AE2.5 ✅ Multi-Param Automation Overlay
**Datei:** `pydaw/ui/audio_editor/audio_event_editor.py`
- Automation ComboBox: neuer Eintrag "All" zeigt alle 4 Envelopes gleichzeitig
- Aktiver Parameter: volle Opazität (1.0) + Punkte sichtbar + Linienstärke 2px
- Hintergrund-Parameter: 35% Opazität + keine Punkte + Linienstärke 1.2px
- Farbcodierung: Gain=Grün, Pan=Gelb, Pitch=Blau, Formant=Magenta
- Refactoring: `_render_clip_automation()` → `_render_single_auto_param()` Extraktion

### AE14.1 ✅ Clip Automation Scripting API
**Datei:** `pydaw/services/scripting_service.py`
- `clip.add_automation("gain", beat=4.0, value=0.8, curve="scurve")` — Punkt hinzufügen
- `clip.get_automation("gain")` → Liste der Breakpoints
- `clip.set_automation("gain", [(0, 0.5), (4, 0.8, "scurve"), (8, 0.3)])` — Bulk-Set
- `clip.clear_automation("pitch")` oder `clip.clear_automation()` — Löschen
- `clip.normalize()` — Gain normalisieren
- `clip.split_at(beat=4.0)` — Audio-Event splitten
- Alle Methoden triggern `_emit_updated()` für UI-Sync

## Gesamtfortschritt
- **AE1:** 5/5 ✅ KOMPLETT
- **AE2:** 4/6 ✅ (Kurven, Snap, Value-Display, Multi-Param)
- **AE4:** 4/6 ✅
- **AE14:** 1/5 ✅
- **Gesamt:** 14/67 Items (21%)

## Geänderte Dateien
1. `pydaw/ui/audio_editor/audio_event_editor.py` — Multi-Param Overlay
2. `pydaw/services/scripting_service.py` — Automation API (+75 Zeilen)
3. `PROJECT_DOCS/AUDIO_EDITOR_ROADMAP.md` — AE2.5, AE14.1 abgehakt
4. `VERSION` — 0.0.21.003

## Nichts kaputt gemacht ✅
