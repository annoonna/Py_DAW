# CHANGELOG v0.0.21.001 — AE1 Complete + AE4.3 Launcher Automation

**Datum:** 2026-04-06
**Kollege:** Claude Opus 4.6

## Implementierte Features

### AE1.4 ✅ Crossfade-Editing
**Datei:** `pydaw/ui/audio_editor/audio_event_editor.py`
- Context Menu → "Crossfade" Submenu: 1/16, 1/8, 1/4, 1/2, 1 Beat, 1 Bar
- Crossfade Curve Selection: Linear, Equal Power, S-Curve (mit Checkmarks)
- "Clear Crossfade" Aktion
- Handler verdrahtet mit `update_audio_clip_params(crossfade_beats=..., crossfade_curve=...)`
- Renderer war bereits implementiert (v0.0.20.751)

### AE1.5 ✅ Snap-to-Zero-Crossing bei Split
**Datei:** `pydaw/ui/audio_editor/audio_event_editor.py`
- `_on_slice_requested()` snappt jetzt automatisch zum nächsten Zero-Crossing
- Radius: ±0.05 beats (nutzt `find_zero_crossings()` aus ProjectService)
- Klickfreie Schnitte bei allen Knife/Split Operationen
- Fallback: Original-Position falls kein Zero-Crossing gefunden

### AE4.3 ✅ Launcher Audio-Clip Automation Rendering
**Datei:** `pydaw/services/cliplauncher_playback.py`
- `_Voice` Dataclass erweitert: `clip_automation: dict`, `clip_length_beats: float`
- Voice-Erstellung: `clip.clip_automation` wird beim Launch übergeben
- `_mix_events_segment()`: Gain + Pan Automation-Envelopes werden angewendet
  - Per-Sample Gain-Kurve aus Breakpoints (np.interp)
  - Per-Sample Pan-Kurve mit Equal-Power Pan Law
- **Ergebnis:** Automation im Audio-Editor zeichnen → im Clip-Launcher hörbar!

## AE1 Phase — VOLLSTÄNDIG ERLEDIGT ✅
Alle 5 Items von AE1 sind jetzt abgehakt:
- AE1.1 ✅ Formant-Automation (v0.0.20.999)
- AE1.2 ✅ Clip-Level Formant-Shift (v0.0.20.999)
- AE1.3 ✅ Fade-Kurven UI (v0.0.20.999)
- AE1.4 ✅ Crossfade-Editing (v0.0.21.001)
- AE1.5 ✅ Zero-Crossing Snap (v0.0.21.001)

## Geänderte Dateien
1. `pydaw/ui/audio_editor/audio_event_editor.py` — Crossfade Menu + Zero-Crossing Snap
2. `pydaw/services/cliplauncher_playback.py` — Clip Automation in Launcher
3. `PROJECT_DOCS/AUDIO_EDITOR_ROADMAP.md` — AE1.4, AE1.5, AE4.3 abgehakt
4. `VERSION` — 0.0.21.001

## Nichts kaputt gemacht ✅
- Alle 4 geänderte Python-Dateien kompilieren fehlerfrei
- Backward-compatible: Voices ohne clip_automation funktionieren (default=None)
- Zero-Crossing Snap: Fallback auf Original-Position wenn nichts gefunden
