# CHANGELOG v0.0.21.013 — SC3+SC4+SC5 FX-Proxys

**Datum:** 2026-04-08

## SC3: Audio-FX Proxys (20 Effekte)
- `_AudioFxDeviceProxy` — Parameter lesen/schreiben, enabled, reset
- Alle 20 Built-in FX steuerbar (EQ-5, Compressor, Reverb, Delay, etc.)
- Auch externe Plugins (VST2/VST3/CLAP/LV2) per params-Dict

## SC4: Note-FX Proxys (9 Note-FX)
- `_NoteFxDeviceProxy` — Parameter lesen/schreiben, enabled
- Transpose, VelScale, ScaleSnap, Chord, Arp, Note Echo, etc.

## SC5: Track-Device-Chain
- `_TrackDevicesProxy` — add/remove/iterate/index/search
- `_ExtendedTrackProxy` — .devices, .note_fx, .instrument Properties
- `_ExtendedTrackListProxy` — Wraps tracks[] für automatische Extension

## Dateien
- `pydaw/services/scripting_proxies.py` — 1311 LOC (von 520)
- `pydaw/services/scripting_service.py` — Extended tracks wiring
