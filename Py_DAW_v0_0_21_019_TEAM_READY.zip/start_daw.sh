#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════
#  🎵 Py_DAW — ChronoScaleStudio
#  Ein Befehl. Alles automatisch.
#
#  Nutzung:  ./start_daw.sh
#
#  Was passiert automatisch:
#  1. Python venv erstellen (falls nötig)
#  2. Python-Pakete installieren (falls nötig)
#  3. C-Extensions kompilieren (falls gcc vorhanden)
#  4. Rust-Engine starten (falls gebaut)
#  5. DAW starten
#
#  Optionen:
#    USE_RUST_ENGINE=0 ./start_daw.sh   # Ohne Rust-Engine
#    ./start_daw.sh --rebuild           # Alles neu bauen
#
#  v0.0.20.790
# ═══════════════════════════════════════════════════════════

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

REBUILD=0
for arg in "$@"; do
    case "$arg" in
        --rebuild) REBUILD=1 ;;
    esac
done

echo ""
echo "════════════════════════════════════════"
echo "  🎵 Py_DAW — ChronoScaleStudio"
echo "  Version: $(cat VERSION 2>/dev/null || echo '?')"
echo "════════════════════════════════════════"
echo ""

# ═══════════════════════════════════════════════════════════
#  0. Distro-Erkennung + System-Abhängigkeiten
# ═══════════════════════════════════════════════════════════

_detect_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        case "$ID" in
            arch|manjaro|endeavouros|garuda|cachyos)
                echo "arch"
                return ;;
            steamos)
                echo "steamos"
                return ;;
        esac
        case "$ID_LIKE" in
            *arch*)
                echo "arch"
                return ;;
            *debian*)
                echo "debian"
                return ;;
        esac
    fi
    if command -v pacman &>/dev/null; then
        echo "arch"
    elif command -v apt-get &>/dev/null; then
        echo "debian"
    else
        echo "unknown"
    fi
}

DISTRO="$(_detect_distro)"

_install_arch_deps() {
    # System-Pakete für Arch Linux / SteamOS
    # pipewire-jack: JACK-Kompatibilitätsschicht (PipeWire)
    # pipewire-alsa: ALSA → PipeWire Bridge (für sounddevice/PortAudio)
    # portaudio: C-Bibliothek für sounddevice Python-Paket
    # python-pyqt6: Qt6 Bindings
    # lilv: LV2 Plugin-Hosting
    # fluidsynth: SF2 Soundfont Support
    # base-devel: gcc für C-Extensions
    local NEEDED_PKGS=""
    local CHECK_PKGS=(
        "pipewire-jack"
        "pipewire-alsa"
        "portaudio"
        "lilv"
        "fluidsynth"
        "ffmpeg"
    )

    for pkg in "${CHECK_PKGS[@]}"; do
        if ! pacman -Qi "$pkg" &>/dev/null; then
            NEEDED_PKGS="$NEEDED_PKGS $pkg"
        fi
    done

    # base-devel für gcc (C-Extensions)
    if ! command -v gcc &>/dev/null; then
        NEEDED_PKGS="$NEEDED_PKGS base-devel"
    fi

    if [ -n "$NEEDED_PKGS" ]; then
        echo "📦 Arch/SteamOS: Installiere System-Abhängigkeiten..."
        echo "   Pakete:$NEEDED_PKGS"
        if command -v sudo &>/dev/null; then
            sudo pacman -S --needed --noconfirm $NEEDED_PKGS 2>&1 | tail -5 || {
                echo "  ⚠️  Einige Pakete konnten nicht installiert werden."
                echo "  Manuell: sudo pacman -S$NEEDED_PKGS"
            }
        else
            echo "  ⚠️  sudo nicht gefunden. Bitte manuell installieren:"
            echo "  pacman -S$NEEDED_PKGS"
        fi
    else
        echo "  ✅ System-Abhängigkeiten OK (Arch)"
    fi
}

_install_debian_deps() {
    # Bestehende Debian-Logik
    local NEEDED_PKGS=""
    local CHECK_PKGS=(
        "python3-venv"
        "python3-pip"
        "python3-dev"
        "libjack-jackd2-dev"
        "libportaudio2"
        "python3-lilv"
        "lilv-utils"
        "libfluidsynth3"
        "ffmpeg"
    )

    for pkg in "${CHECK_PKGS[@]}"; do
        if ! dpkg -s "$pkg" &>/dev/null 2>&1; then
            NEEDED_PKGS="$NEEDED_PKGS $pkg"
        fi
    done

    if [ -n "$NEEDED_PKGS" ]; then
        echo "📦 Debian/Ubuntu: Installiere System-Abhängigkeiten..."
        echo "   Pakete:$NEEDED_PKGS"
        if command -v sudo &>/dev/null; then
            sudo apt-get update -qq 2>/dev/null
            sudo apt-get install -y $NEEDED_PKGS 2>&1 | tail -5 || {
                echo "  ⚠️  Einige Pakete konnten nicht installiert werden."
                echo "  Manuell: sudo apt install$NEEDED_PKGS"
            }
        fi
    else
        echo "  ✅ System-Abhängigkeiten OK (Debian)"
    fi
}

case "$DISTRO" in
    arch|steamos)
        echo "🐧 Erkannt: Arch Linux / SteamOS ($DISTRO)"
        _install_arch_deps
        ;;
    debian)
        echo "🐧 Erkannt: Debian / Ubuntu / Kali"
        _install_debian_deps
        ;;
    *)
        echo "🐧 Distro: unbekannt (Abhängigkeiten manuell installieren)"
        ;;
esac

# ═══════════════════════════════════════════════════════════
#  1. Python venv — automatisch erstellen wenn nötig
# ═══════════════════════════════════════════════════════════

VENV_DIR="$DIR/myenv"

activate_venv() {
    if [ -n "$VIRTUAL_ENV" ]; then
        return 0
    fi
    if [ -f "$VENV_DIR/bin/activate" ]; then
        . "$VENV_DIR/bin/activate"
        return 0
    fi
    if [ -f "$HOME/myenv/bin/activate" ]; then
        . "$HOME/myenv/bin/activate"
        return 0
    fi
    return 1
}

if ! activate_venv; then
    echo "📦 Erstelle Python Virtual Environment..."
    PYTHON_CMD=""
    for p in python3.13 python3.12 python3.11 python3; do
        if command -v "$p" &>/dev/null; then
            PYTHON_CMD="$p"
            break
        fi
    done

    if [ -z "$PYTHON_CMD" ]; then
        echo "❌ Python3 nicht gefunden. Bitte installieren:"
        echo "   sudo apt install python3 python3-venv python3-pip"
        exit 1
    fi

    $PYTHON_CMD -m venv "$VENV_DIR" 2>/dev/null || {
        echo "⚠️  python3-venv fehlt. Versuche Installation..."
        if [ "$DISTRO" = "arch" ] || [ "$DISTRO" = "steamos" ]; then
            sudo pacman -S --needed --noconfirm python 2>/dev/null || true
        else
            sudo apt-get install -y python3-venv 2>/dev/null || true
        fi
        $PYTHON_CMD -m venv "$VENV_DIR" || {
            echo "❌ Konnte kein venv erstellen."
            if [ "$DISTRO" = "arch" ] || [ "$DISTRO" = "steamos" ]; then
                echo "   sudo pacman -S python"
            else
                echo "   sudo apt install python3-venv"
            fi
            exit 1
        }
    }
    . "$VENV_DIR/bin/activate"
    echo "  ✅ venv erstellt"
    REBUILD=1  # Erstmalig → alles installieren
fi

echo "🐍 Python: $(python3 --version 2>&1)"

# ═══════════════════════════════════════════════════════════
#  2. Python-Pakete — nur installieren wenn nötig
# ═══════════════════════════════════════════════════════════

_check_packages() {
    python3 -c "
import sys
try:
    import PyQt6.QtWidgets
    import numpy
    import sounddevice
    import fluidsynth
    sys.exit(0)
except ImportError:
    sys.exit(1)
" 2>/dev/null
}

if [ "$REBUILD" = "1" ] || ! _check_packages; then
    echo "📦 Installiere Python-Pakete..."
    pip install --quiet --upgrade pip 2>/dev/null || true
    if [ -f "$DIR/requirements.txt" ]; then
        pip install --quiet -r "$DIR/requirements.txt" 2>&1 | tail -2 && \
            echo "  ✅ Pakete installiert" || \
            echo "  ⚠️  Einige Pakete fehlgeschlagen (DAW startet trotzdem)"
    fi
else
    echo "  ✅ Python-Pakete OK"
fi

# v0.0.20.862: Auto-install optional packages if missing (won't trigger full reinstall)
_install_if_missing() {
    python3 -c "import $1" 2>/dev/null || {
        pip install --quiet "$2" 2>/dev/null && echo "  ✅ $2 nachinstalliert" || true
    }
}
_install_if_missing websockets websockets
_install_if_missing zeroconf zeroconf

# v0.0.20.952: Whisper für Video Text-Editing (VE11)
python3 -c "
try:
    import faster_whisper
except ImportError:
    try:
        import whisper
    except ImportError:
        import sys; sys.exit(1)
" 2>/dev/null || {
    echo "  🎤 Installiere openai-whisper (Video-Transkription)..."
    pip install --quiet openai-whisper 2>/dev/null && echo "  ✅ openai-whisper installiert" || {
        echo "  ℹ️  Whisper nicht installiert (optional — Video-Transkription deaktiviert)"
        echo "     Manuell: pip install openai-whisper  ODER  pip install faster-whisper"
    }
}

# v0.0.20.925: Video-Integration Pro dependencies
_install_if_missing cv2 opencv-python-headless
_install_if_missing msgpack msgpack

# v0.0.20.989: KI-Komposition Dokument-Import (KK6)
_install_if_missing fitz pymupdf
_install_if_missing docx python-docx

# v0.0.20.925: Check ffmpeg system binary (needed for video features)
if ! command -v ffmpeg &>/dev/null; then
    echo "  ⚠️  ffmpeg nicht gefunden — Video-Features eingeschränkt"
    echo "     Installieren: sudo apt install ffmpeg  (oder: sudo pacman -S ffmpeg)"
fi

# ═══════════════════════════════════════════════════════════
#  3. C-Extensions — automatisch kompilieren (silent)
# ═══════════════════════════════════════════════════════════

AUDIO_DIR="$DIR/pydaw/audio"
C_BUILT=0

_build_c_ext() {
    local name="$1"
    local c_file="$AUDIO_DIR/$name.c"
    local so_file="$AUDIO_DIR/$name.so"

    [ -f "$c_file" ] || return 0

    # Nur neu bauen wenn .c neuer als .so oder .so fehlt oder --rebuild
    if [ "$REBUILD" = "1" ] || [ ! -f "$so_file" ] || [ "$c_file" -nt "$so_file" ]; then
        if gcc -O3 -march=native -ffast-math -shared -fPIC -o "$so_file" "$c_file" -lm 2>/dev/null; then
            C_BUILT=$((C_BUILT + 1))
        fi
    fi
}

if command -v gcc &>/dev/null; then
    _build_c_ext "fast_filters"
    _build_c_ext "fast_builtin_fx"
    if [ "$C_BUILT" -gt 0 ]; then
        echo "  ⚡ $C_BUILT C-Extension(s) kompiliert (DSP-Turbo aktiv)"
    else
        echo "  ⚡ C-Extensions aktuell"
    fi
else
    if [ -f "$AUDIO_DIR/fast_filters.so" ] && [ -f "$AUDIO_DIR/fast_builtin_fx.so" ]; then
        echo "  ⚡ C-Extensions vorhanden (vorkompiliert)"
    else
        echo "  ℹ️  Optionaler Turbo: sudo apt install build-essential"
    fi
fi

# ═══════════════════════════════════════════════════════════
#  4. Rust-Toolchain + Engine (optional, automatisch)
# ═══════════════════════════════════════════════════════════

[ -f "$HOME/.cargo/env" ] && . "$HOME/.cargo/env"
[ -d "$HOME/.cargo/bin" ] && export PATH="$HOME/.cargo/bin:$PATH"

RUST_ENGINE="$DIR/pydaw_engine/target/release/pydaw_engine"
CARGO_TOML="$DIR/pydaw_engine/Cargo.toml"
RUST_OK=0

if [ -f "$RUST_ENGINE" ]; then
    echo "  🦀 Rust-Engine: bereit"
    RUST_OK=1
elif command -v cargo &>/dev/null && [ -f "$CARGO_TOML" ]; then
    echo "  🦀 Baue Rust Audio-Engine (einmalig, 1-3 Min.)..."
    if cargo build --release --manifest-path "$CARGO_TOML" 2>&1 | tail -3; then
        [ -f "$RUST_ENGINE" ] && RUST_OK=1 && echo "  🦀 Rust-Engine: ✅ gebaut"
    else
        echo "  🦀 ⚠️  Build fehlgeschlagen (Python-Fallback aktiv)"
    fi
else
    echo "  🐍 Audio: Python-Engine (Rust optional)"
fi

# ═══════════════════════════════════════════════════════════
#  4b. PyO3 Native DSP Module (pydaw_native) — NS1
# ═══════════════════════════════════════════════════════════

NATIVE_TOML="$SCRIPT_DIR/pydaw_native/Cargo.toml"
if [ -f "$NATIVE_TOML" ]; then
    if command -v maturin &>/dev/null; then
        echo "  🔧 Baue pydaw_native (PyO3 DSP-Modul)..."
        if (cd "$SCRIPT_DIR/pydaw_native" && maturin develop --release 2>&1 | tail -3); then
            echo "  🔧 pydaw_native: ✅ gebaut"
        else
            echo "  🔧 ⚠️  pydaw_native Build fehlgeschlagen (Python-Fallback aktiv)"
        fi
    else
        echo "  🔧 pydaw_native: maturin nicht installiert (pip install maturin)"
        echo "      Python-Fallback für Waveform/FFT/Metering aktiv"
    fi
fi

# ═══════════════════════════════════════════════════════════
#  5. Starten!
# ═══════════════════════════════════════════════════════════

echo ""
echo "════════════════════════════════════════"
echo "  🚀 Starte Py_DAW..."
if [ "$RUST_OK" = "1" ]; then
    echo "  🦀 Rust-Engine wird von der DAW automatisch gestartet"
fi
echo "════════════════════════════════════════"
echo ""

# v0.0.20.793: Engine wird NICHT mehr hier gestartet.
# Die Python-Bridge (RustEngineBridge) startet die Engine selbst als
# Subprocess. Das verhindert den Disconnect-Loop der entsteht wenn
# ZWEI Prozesse sich um denselben Socket streiten.
#
# Alt (kaputt):  start_daw.sh startet Engine → Python verbindet sich
#                → Socket-Konflik → Disconnect → Reconnect-Loop
#
# Neu (stabil):  start_daw.sh baut nur die Engine
#                Python startet + verbindet sich selbst → stabile Verbindung

# Stale socket aufräumen (falls vorhanden von vorherigem Absturz)
rm -f /tmp/pydaw_engine.sock

# DAW starten
python3 main.py
EXIT_CODE=$?

# ═══════════════════════════════════════════════════════════
#  6. Aufräumen
# ═══════════════════════════════════════════════════════════

# Socket aufräumen falls übrig
rm -f /tmp/pydaw_engine.sock

echo "👋 Py_DAW beendet."
exit $EXIT_CODE
