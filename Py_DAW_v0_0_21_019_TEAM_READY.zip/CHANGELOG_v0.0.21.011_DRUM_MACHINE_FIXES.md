# CHANGELOG v0.0.21.011 — Pro Drum Machine Fixes + DSP

**Datum:** 2026-04-08
**Kollege:** Claude Opus 4.6
**Schwerpunkt:** Pro Drum Machine Tiefenanalyse + 3 Bug-Fixes + DSP-Verbesserungen

---

## 🐛 Bug-Fixes

### BUG 1: MIDI CC-Mapping nicht Slot-spezifisch (🔴 KRITISCH)
**Datei:** `pydaw/plugins/sampler/ui_widgets.py`
**Problem:** Beim Pad-Wechsel blieb die MIDI CC-Zuordnung auf dem Knob-Widget stehen.
Alle Slots zeigten dasselbe CC-Mapping (z.B. "CC18 ch0").
**Fix:** `set_automation_target()` lädt jetzt die CC-Zuordnung aus dem `_persistent_cc_map`
für die neue `_parameter_id` und registriert den Listener um.
Ohne Mapping → `_midi_cc_mapping = None`.

### BUG 2: Start/End-Knobs ohne Automation/MIDI-Binding (🔴 KRITISCH)
**Datei:** `pydaw/plugins/drum_machine/drum_widget.py`
**Problem:** Start/End-Regler hatten kein `bind_automation()` und kein `set_automation_target()`.
Dadurch: kein MIDI Learn, kein Kontextmenü, keine Automation-Lanes.
**Fix:**
- `_slot_param_ids` um `'start'` und `'end'` erweitert
- Im AutomationManager registriert (mit korrekten Defaults aus engine state)
- In `_bind_editor_knobs_to_selected_slot()` gebunden + retarget
- `_apply_slot_start()` / `_apply_slot_end()` als Automation-Apply-Funktionen
- Knob-Sync bei Automation-Playback

### BUG 3: Kein Per-Slot MIDI Channel (🟡 FEATURE-FIX)
**Dateien:** `drum_engine.py`, `drum_widget.py`
**Problem:** Alle Slots reagierten auf jeden MIDI-Kanal. Keine Möglichkeit,
verschiedene Controller/Kanäle auf spezifische Pads zu routen.
**Fix:**
- `DrumSlotState.midi_channel` Feld (-1=Omni, 0-15=Kanal)
- `trigger_note()` filtert nach Slot-MIDI-Kanal
- UI: SpinBox "Ch:" im Editor (mit "Omni" als Spezialwert)
- Sync bei Pad-Wechsel
- Export/Import State Persistenz

---

## 🔧 DSP-Verbesserungen

### Anti-Click Choke (Klick-freie Hi-Hat-Gruppen)
**Datei:** `drum_engine.py`
**Vorher:** `engine.state.playing = False` → harter Abbruch = Klick-Artefakte
**Nachher:** `set_env(r=0.002)` + `all_notes_off()` → 2ms Envelope-Release = sauber

---

## Dateien geändert (3)
- `pydaw/plugins/sampler/ui_widgets.py` — CompactKnob.set_automation_target() CC-Swap
- `pydaw/plugins/drum_machine/drum_engine.py` — midi_channel, choke fade, export/import
- `pydaw/plugins/drum_machine/drum_widget.py` — Start/End binding, MIDI Ch UI, apply funcs
