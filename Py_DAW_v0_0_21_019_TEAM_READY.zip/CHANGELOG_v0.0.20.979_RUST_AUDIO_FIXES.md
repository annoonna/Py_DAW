# CHANGELOG v0.0.20.979 — Rust Audio Fixes (Doppel-Stream, Auto-Connect, Buffer)

**Datum:** 2026-04-04
**Autor:** Claude Opus 4.6
**Aufgabe:** 3 kritische Audio-Bugs fixen

## Fixes

| # | Problem | Fix | Datei |
|---|---|---|---|
| 1 | Engine.set_backend() nicht aufgerufen | Dialog ruft set_backend(backend) | audio_settings_dialog.py |
| 2 | Play öffnet sounddevice trotz Rust-Backend | _backend=="rust" → Rust-Delegation | audio_engine.py |
| 3 | Backend "rust" überlebt Neustart nicht | QSettings beim Start laden | audio_engine.py |
| 4 | "Nicht verbunden" im Dialog | Auto-Connect per QTimer(100ms) | audio_settings_dialog.py |
| 5 | "256buf" ohne Erklärung | "256buf (HW, angefordert: 1024)" | audio_settings_dialog.py |
| 6 | Rust startet nicht beim DAW-Start | _auto_start_rust_engine() nach 2s | main_window*.py |

## Geänderte Dateien
| Datei | Änderung |
|---|---|
| pydaw/ui/audio_settings_dialog.py | Fix 1+4+5: set_backend, auto-connect, buffer-info |
| pydaw/audio/audio_engine.py | Fix 2+3: Rust-Delegation bei Play, QSettings-Backend |
| pydaw/ui/main_window.py | Fix 6: QTimer auto-start Aufruf |
| pydaw/ui/main_window_engine.py | Fix 6: _auto_start_rust_engine() Methode |
