# CHANGELOG v0.0.20.952 — VK1-VK9 Video-KI Arranger Integration

**Datum:** 2026-04-02
**Autor:** Claude Opus 4.6

## Was wurde gemacht

### VK1-VK6 + VK9: Video-KI Arranger Integration
- VideoKIArrangerService: Zentraler Service für alle VK-Features
- VK1: Scene markers mit Beat-Position, SMPTE TC, Mood-Tags
- VK2: Dialog markers + Auto-Duck automation (beat, gain_linear)
- VK3: 12 Mood→AETERNA Preset mappings + Scene Color Bar
- VK4: Subtitle blocks + transcript search + chapter titles
- VK5: Beat-to-Cut suggestions + BPM per scene
- VK6: ADR/Foley cue sheet (CSV + PDF/TXT export)
- VK9: AnnotationManager (sticky notes, farbkodiert, suchbar)

### P7 Korrektur
- VST3 IBStream, CLAP MIDI Events, LV2 State/Atom — bereits implementiert, abgehakt

## Neue Dateien
| Datei | LOC | Inhalt |
|-------|-----|--------|
| pydaw/services/video_ki_arranger.py | 580 | VK1-VK6 + VK9 |

## Roadmap-Status
- VIDEO_EDITOR_ROADMAP: ✅ VE1-VE18 KOMPLETT
- VIDEO_KI_ROADMAP: ✅ VK1-VK9 KOMPLETT (26/26)
- PLUGIN_SANDBOX_ROADMAP: ✅ P1-P7 KOMPLETT
- Verbleibend: Nur Hardware-Tests (H1, Anno only)

## Stats
445/445 kompilieren | 0 Fehler | Nichts kaputt
