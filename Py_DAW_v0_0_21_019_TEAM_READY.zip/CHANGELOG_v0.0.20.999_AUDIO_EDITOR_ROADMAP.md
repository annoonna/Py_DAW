# CHANGELOG v0.0.20.999 — Audio Editor Roadmap + AE1 Fundament

**Datum:** 2026-04-06
**Kollege:** Claude Opus 4.6

## Neue Dateien

### `PROJECT_DOCS/AUDIO_EDITOR_ROADMAP.md`
Vollständige Analyse + 56-Item Roadmap für den Audio-Editor:
- **Lagebild:** 25+ funktionierende Features dokumentiert, 15+ Lücken identifiziert
- **Feature-Matrix:** Bitwig 6 vs Ableton 12 vs Py_DAW (jetzt vs nach Roadmap)
- **12 Phasen (AE1–AE12):** Fundament → Automation → Comping → Launcher-Integration → Scrub → Spectral → Advanced → KI Level 1 → KI Level 2 → Warp Pro → UX → Rust
- **9 KI-Alleinstellungsmerkmale:** Vocal-Isolation, Auto-Harmonize, Smart-Fade, Beat-Match, Noise-Classify, Audio-Inpainting, Style-Transfer, Text-to-Edit, Audio-Continuation
- **Empfohlene Reihenfolge:** AE1 → AE4 → AE2 → AE5 → AE3 → AE10 → AE6 → AE7 → AE8 → AE11 → AE9 → AE12

## Implementierte Features (AE1 — Fundament-Reparatur)

### AE1.1 ✅ Formant-Automation im Renderer
**Datei:** `pydaw/audio/arrangement_renderer.py`
- Formant-Automation-Envelope wird jetzt im Audio-Renderer ausgewertet
- Overlap-Add Spectral Formant-Shift (block_size=2048, hop=512)
- Mapping: 0.0 → -12 Semitones, 0.5 → 0 (kein Shift), 1.0 → +12 Semitones
- Per-Block Resampling: verschiebt Spektral-Envelope ohne Pitch zu ändern
- **Ergebnis:** Formant mit Pencil-Tool einzeichnen → hörbar beim Playback

### AE1.2 ✅ Clip-Level Formant-Shift
**Datei:** `pydaw/audio/arrangement_renderer.py`
- Formant-SpinBox im Audio-Editor → Clip-Parameter `formant` → Renderer
- Resampling-basierter globaler Formant-Shift pro Clip
- Unabhängig von Pitch steuerbar (Formant ≠ Pitch)

### AE1.3 ✅ Fade-Kurven UI
**Datei:** `pydaw/ui/audio_editor/audio_event_editor.py`
- Context Menu → Fades → "Fade In Curve" / "Fade Out Curve" Submenüs hinzugefügt
- 4 Kurventypen: Linear, Logarithmic, Exponential, S-Curve
- Checkmark zeigt aktiven Kurventyp an
- Handler: `update_audio_clip_params(fade_in_curve=..., fade_out_curve=...)` verdrahtet
- Renderer `_fade_ramp()` unterstützte die 4 Kurven bereits (v0.0.20.751)

## Geänderte Dateien
1. `pydaw/audio/arrangement_renderer.py` — Formant-Automation + Clip-Level Formant-Shift
2. `pydaw/ui/audio_editor/audio_event_editor.py` — Fade-Kurven Context Menu + Handler
3. `PROJECT_DOCS/AUDIO_EDITOR_ROADMAP.md` — NEU: 56-Item Roadmap
4. `VERSION` — 0.0.20.999

## Nichts kaputt gemacht ✅
- Beide geänderte Python-Dateien kompilieren fehlerfrei
- Keine bestehenden Methoden gelöscht oder Signaturen geändert
- Nur additive Änderungen (neue Code-Blöcke, neue Menüeinträge)
