# CHANGELOG v0.0.20.984 — NS2 + NS6.2 + Dashboard Fix (Symphonia, Hybrid Audio, CPU Fix)

**Datum:** 2026-04-04
**Autor:** Claude Opus 4.6
**Arbeitspaket:** NEXT_STEPS_ROADMAP — NS2, NS6.2 + Dashboard Bugfix

## Was wurde gemacht

### Dashboard CPU-Anzeige Bugfix (aus Screenshot-Report)
- **Bug: CPU Flip-Flop** — `_on_rust_dashboard_status` setzte `set_disconnected()` wenn
  `is_active=False`, obwohl die Engine verbunden war. Dashboard flippte permanent
  zwischen connected/disconnected → CPU wurde nie angezeigt.
- **Fix:** StatusReport = immer verbunden. Bei `is_active=False` → connected-idle (0% CPU)
- **Bug: CPU-Text unsichtbar** — 7pt Font *innerhalb* 8px-Bar war nicht lesbar
- **Fix:** CPU-Prozent jetzt RECHTS NEBEN dem Balken, 8pt Font, Farbkodierung

### NS2: Symphonia Audio-Decode (10/10 Items ✅)

**Rust-Seite:**
- `pydaw_engine/src/audio_decode.rs` — **278 Zeilen** Symphonia-basierter Decoder
  - MP3, OGG Vorbis, AAC/M4A, FLAC, WAV, AIFF
  - Automatische Codec-Erkennung via Symphonia Probe
  - Streaming Decode (nicht ganzes File in RAM)
  - Resampling auf Ziel-Sample-Rate (linear interpolation)
  - Mono/Stereo/Multi-Channel Support
  - f32/f64/s16/s32/u8 Sample-Format Konvertierung
- `Cargo.toml` — `symphonia = "0.5"` mit allen Codec-Features
- `ipc.rs` — `DecodeAudio` Command + `AudioDecoded` / `AudioDecodeError` Events
- `engine.rs` — Background-Thread Handler (blockiert nicht den Audio-Thread)

**Python-Seite:**
- `rust_engine_bridge.py`:
  - `decode_audio(path, target_sr, callback)` — async decode
  - `decode_audio_sync(path, target_sr, timeout)` — blocking decode → numpy array
  - `_decode_callbacks` dict für Request/Response Matching
  - Event-Dispatch für `AudioDecoded` / `AudioDecodeError`

### NS6.2: should_use_rust() aktivieren (4/4 Items ✅)
- `engine_migration.py` — Hybrid Audio Mode:
  - `should_use_rust("audio_output")` → True wenn Backend=rust + Bridge connected
  - `should_use_rust("audio_playback")` → False (Python rendert, Rust gibt aus)
  - `USE_RUST_ENGINE=force_rust_dsp` → Experimentell: volles Rust-Rendering
  - `_is_rust_output_active()` — prüft Bridge-Verbindung
  - `get_active_subsystems()` — Status aller Subsysteme als dict

## Geänderte Dateien

| Datei | Änderung |
|---|---|
| pydaw_engine/Cargo.toml | symphonia dependency |
| pydaw_engine/src/audio_decode.rs | **NEU** — 278 Zeilen Symphonia Decoder |
| pydaw_engine/src/main.rs | audio_decode Modul registriert |
| pydaw_engine/src/ipc.rs | DecodeAudio Command + AudioDecoded/Error Events |
| pydaw_engine/src/engine.rs | DecodeAudio Handler (Background-Thread) |
| pydaw/services/rust_engine_bridge.py | decode_audio(), AudioDecoded dispatch |
| pydaw/services/engine_migration.py | Hybrid Audio Mode, audio_output subsystem |
| pydaw/ui/rust_dashboard_widget.py | CPU-Text neben Bar, Connecting-State |
| pydaw/ui/main_window_engine.py | StatusReport: connected-idle statt disconnected |
| VERSION | 0.0.20.983 → 0.0.20.984 |
| pydaw/version.py | aktualisiert |

## Architektur: Hybrid Audio Mode (NS6.2)

```
Play drücken
  ┌────────────────────────────┐
  │ Python (audio_engine.py)   │
  │  rendert Instrumente/FX    │  ← should_use_rust("audio_playback") = False
  │  in float32 Buffers        │
  └──────────┬─────────────────┘
             │ SharedAudioRing (lock-free SPSC)
  ┌──────────▼─────────────────┐
  │ Rust (cpal audio output)   │  ← should_use_rust("audio_output") = True
  │  liest Ring → PipeWire     │
  │  kein GIL, kein Python     │
  └────────────────────────────┘
```

## Zum Testen

### Symphonia Decode:
```python
from pydaw.services.rust_engine_bridge import RustEngineBridge
bridge = RustEngineBridge.instance()
result = bridge.decode_audio_sync("/path/to/file.mp3")
if result:
    samples, sr, channels, duration = result
    print(f"Decoded: {sr}Hz, {channels}ch, {duration:.1f}s")
```

### Hybrid Audio Status:
```python
from pydaw.services.engine_migration import EngineMigrationController
ctrl = EngineMigrationController.instance()
print(ctrl.get_active_subsystems())
# {'audio_output': 'rust', 'audio_playback': 'python', ...}
```

## Was als nächstes zu tun ist
- **NS3: FFmpeg Video-Decode** — echtes Video statt Stubs
- **NS4: WGPU GPU-Rendering** — GPU-beschleunigte Video-Filter
- **NS6.1: A/B Benchmark** — Rust vs Python bei 10/20/50 Tracks
- **NS6.3: Lock-Free Optimierungen** — SPSC für alle Track-Outputs

## Bekannte Probleme
- Symphonia AAC Support ist experimental (nicht alle M4A Container)
- Resampling ist lineare Interpolation (für Produktion besser libsamplerate)
- GIL-Starvation bei 5+ Tracks weiterhin ein Problem (braucht volles Rust-Rendering)
- SharedAudioRing wird bei jedem Play/Stop neu erstellt → Memory Leak
