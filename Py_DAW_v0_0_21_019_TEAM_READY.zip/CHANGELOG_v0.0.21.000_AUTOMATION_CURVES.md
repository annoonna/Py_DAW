# CHANGELOG v0.0.21.000 — Audio Editor AE2.1 Automation Curves

**Datum:** 2026-04-06
**Kollege:** Claude Opus 4.6

## Implementierte Features

### AE2.1 ✅ Automation-Kurventypen (S-Curve/Log/Exp)

**Renderer** (`pydaw/audio/arrangement_renderer.py`):
- Neue Helper-Funktion `_interp_auto_curve()` — per-Segment Kurven-Interpolation
  - Unterstützt: Linear (default), S-Curve (Hermite 3t²-2t³), Log (schneller Start), Exp (langsamer Start)
  - Backward-compatible: fehlende `curve` Felder → Linear (np.interp Fast-Path)
- Gain-Automation → `_interp_auto_curve()` (vorher `np.interp`)
- Pan-Automation → `_interp_auto_curve()` (vorher `np.interp`)
- Pitch-Automation (beide Sektionen) → `_interp_auto_curve()`
- Formant-Automation → `_interp_auto_curve()`

**Editor UI** (`pydaw/ui/audio_editor/audio_event_editor.py`):
- Toolbar: "Curve Type" ComboBox (Linear/S-Curve/Log/Exp) neben Automation-Param-Selector
- Pencil-Tool: neue Automation-Punkte erhalten den gewählten Kurventyp
- Visuelle Darstellung: QPainterPath mit ~20 Segmenten pro Kurve statt gerader Linien
- Status-Message zeigt Kurventyp an: "Automation: gain @ 2.50 = 0.75 [scurve]"

**Service** (`pydaw/services/project_service.py`):
- `add_clip_automation_point()` um `curve` Parameter erweitert (default="linear")
- Nur nicht-lineare Kurventypen werden im Breakpoint gespeichert (spart Platz)

### Breakpoint-Format (erweitert, backward-compatible)
```json
{"beat": 2.0, "value": 0.75, "curve": "scurve"}
```
- `curve` ist optional, default = "linear"
- Gültige Werte: "linear", "scurve", "log", "exp"

## Geänderte Dateien
1. `pydaw/audio/arrangement_renderer.py` — +95 Zeilen (_interp_auto_curve + Umstellung aller Automation)
2. `pydaw/ui/audio_editor/audio_event_editor.py` — +40 Zeilen (Toolbar ComboBox + Curve Rendering)
3. `pydaw/services/project_service.py` — +5 Zeilen (curve Parameter)
4. `PROJECT_DOCS/AUDIO_EDITOR_ROADMAP.md` — AE2.1 abgehakt
5. `VERSION` — 0.0.21.000

## Nichts kaputt gemacht ✅
- Alle 3 geänderte Python-Dateien kompilieren fehlerfrei
- Backward-compatible: bestehende Projekte ohne `curve` Felder funktionieren (default=linear)
- Keine bestehenden Methoden gelöscht, nur erweitert (optionaler Parameter)
