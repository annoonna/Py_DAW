# CHANGELOG v0.0.20.983 — NS5.3 + NS5.4 + NS1 (Auto-Connect, PipeWire Sync, PyO3 Native)

**Datum:** 2026-04-04
**Autor:** Claude Opus 4.6
**Arbeitspaket:** NEXT_STEPS_ROADMAP — NS5.3, NS5.4, NS1

## Was wurde gemacht

### NS5.3: Auto-Connect Verbesserung (4 Items ✅)
- **Startup-Delay 2000ms → 500ms** — Rust Engine verbindet sofort nach UI-Init
- **Connecting-State im Dashboard** — gelb pulsierende Anzeige + "Verbinde…" Text
- **Reconnect-Versuche 3 → 5** — mehr Resilienz bei instabiler Verbindung
- **Status-Feedback** — Statusbar zeigt Erfolg/Fehler ohne Audio-Dialog zu öffnen
- Dashboard zeigt 3 Zustände: 🟢 Verbunden | 🟡 Verbindet | ⚪ Offline

### NS5.4: Buffer-Size Synchronisation (4 Items ✅)
- **PipeWireMonitor Service** — `pydaw/services/pipewire_monitor.py`
  - Fragt `pw-metadata` ab: Quantum, Rate, Min/Max Quantum, Driver
  - `query()` / `query_async()` / `set_quantum()` / `set_rate()` / `sync_to_daw()`
  - Hintergrund-Thread, kein UI-Blocking
- **Dashboard Tooltip** — zeigt PipeWire Quantum + Rate + Mismatch-Warnung
- **Audio Settings Dialog** — neue "PipeWire Synchronisation" GroupBox
  - Zeigt aktuellen Quantum vs. angeforderten Buffer
  - "Buffer an PipeWire anpassen" Button
  - ⚠️ MISMATCH-Warnung wenn Ratio > 4x
- **Automatische Query** bei Engine-Connect und Dialog-Öffnung

### NS1: PyO3 UI-Hilfsfunktionen (12 Items ✅)
- **Neues Rust-Crate `pydaw_native/`** (PyO3 + maturin)
  - Cargo.toml mit pyo3, numpy, rustfft, pitch-detection
  - pyproject.toml für `maturin develop --release`

- **NS1.1 Waveform** (4 Items)
  - `waveform_peaks(samples, num_peaks)` — min/max Peaks, GIL-frei
  - `waveform_rms(samples, num_points)` — RMS-Waveform
  - Zero-Copy numpy Arrays, Thread-safe

- **NS1.2 FFT / Spectrum** (4 Items)
  - `fft_magnitude(samples, fft_size)` — Hanning-Window FFT → dB
  - `fft_magnitude_blackman(samples, fft_size)` — Blackman-Harris
  - `mel_scale(magnitudes, num_mel_bins, sr)` — Mel-Skalierung für Spektrogramm
  - 30fps-fähig für Echtzeit-Analyzer

- **NS1.3 Metering** (3 Items)
  - `rms_peak(left, right)` → (rms_l, rms_r, peak_l, peak_r) in dBFS
  - `lufs_momentary(left, right, sr)` → LUFS (EBU R128 Approximation)
  - `true_peak(left, right)` → dBTP mit 4x Oversampling

- **NS1.4 Audio-Utilities** (4 Items)
  - `normalize(samples, target_db)` — Peak-Normalisierung
  - `resample(samples, from_sr, to_sr)` — Lineare Interpolation
  - `detect_bpm(samples, sr)` — Autocorrelation-basiert (60-200 BPM)
  - `detect_key(samples, sr)` — Chroma + Krumhansl-Kessler Profiles

- **Python Fallback Bridge** — `pydaw/services/native_bridge.py`
  - Importiert `pydaw_native` wenn verfügbar, sonst numpy-Fallback
  - Identische API für beide Backends
  - `from pydaw.services.native_bridge import native`

- **Build-Integration** — `start_daw.sh` baut pydaw_native automatisch

## Geänderte Dateien

| Datei | Änderung |
|---|---|
| pydaw/ui/main_window.py | Auto-Start Delay 2000→500ms |
| pydaw/ui/main_window_engine.py | Connecting-State in Dashboard, besseres Feedback |
| pydaw/ui/rust_dashboard_widget.py | 🟡 Connecting-State, PipeWire Quantum Query/Tooltip |
| pydaw/ui/audio_settings_dialog.py | PipeWire Sync GroupBox, Query + Set Quantum |
| pydaw/services/rust_engine_bridge.py | Reconnect 3→5 Versuche |
| pydaw/services/pipewire_monitor.py | **NEU** — PipeWire Quantum/Rate Monitor |
| pydaw/services/native_bridge.py | **NEU** — Python↔Rust Native DSP Bridge |
| pydaw_native/Cargo.toml | **NEU** — PyO3 Crate Config |
| pydaw_native/pyproject.toml | **NEU** — Maturin Build Config |
| pydaw_native/src/lib.rs | **NEU** — 12 native DSP Funktionen |
| start_daw.sh | pydaw_native Build-Step |
| VERSION | 0.0.20.982 → 0.0.20.983 |
| pydaw/version.py | 0.0.20.945 → 0.0.20.983 |
| PROJECT_DOCS/NEXT_STEPS_ROADMAP.md | NS1+NS5 abgehakt (26/76 = 34%) |

## Was als nächstes zu tun ist

### SOFORT (nächste Session):
- **NS2: Symphonia Audio-Decode** — MP3/OGG/AAC Decode in Rust Engine
- **NS6.2: should_use_rust()** — Rust-Rendering live aktivieren

### MITTELFRISTIG:
- **NS3: FFmpeg Video-Decode** — echtes Video statt Stubs
- **NS4: WGPU GPU-Rendering** — GPU-beschleunigte Video-Filter
- **NS6: Performance-Tuning** — A/B Vergleich, Lock-Free Optimierungen

### HARDWARE-TESTS (Anno):
- `cd pydaw_native && maturin develop --release` → pydaw_native bauen
- Python: `from pydaw.services.native_bridge import native; print(native.backend_name)`
- PipeWire: Klick auf 🦀 Dashboard → Tooltip zeigt PipeWire Quantum

## Bekannte Probleme / Offene Fragen
- pydaw_native braucht `maturin` (`pip install maturin`) — Fallback auf Python wenn nicht vorhanden
- LUFS ist eine Approximation (vereinfachtes K-Weighting statt voller ITU-R BS.1770 Biquad-Chain)
- True Peak nutzt lineare Interpolation statt 48-Tap FIR (pragmatische Näherung)
- PipeWire Quantum-Query funktioniert nur mit PipeWire (nicht mit purem ALSA/JACK)
