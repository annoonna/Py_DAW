# CHANGELOG v0.0.20.971 — RUST MIGRATION: Cargo.toml + RM1.3 + RM3.3/3.4 + RM4.1

**Datum:** 2026-04-04
**Autor:** Claude Opus 4.6
**Arbeitspaket:** RUST_FULL_MIGRATION_ROADMAP — RM1.3, RM3.3, RM3.4, RM4.1

## Was wurde gemacht

### 1. Cargo.toml — Neue Dependencies
- `rusqlite = "0.31"` (bundled SQLite)
- `uuid = "1"` (v4 generation)
- `chrono = "0.4"` (timestamps)
- `midir = "0.10"` (MIDI input)
- `rayon = "1.10"` (parallel processing)
- `sha2 = "0.10"` (file hashing)
- `claxon = "0.4"` (FLAC reading)

### 2. RM1.3: Projekt-Service mit echtem rusqlite
- `DatabaseManager` mit `open()`, `close()`, `migrate()`
- WAL-Modus, PRAGMAs für Performance
- `save_project()` — Vollständiger Projekt-Export nach SQLite (Tracks, Clips, MIDI, Automation, FX, Sends, Tempo)
- `load_project()` — Vollständiger Projekt-Import aus SQLite
- `set_setting()` / `get_setting()` — Key-Value Settings
- Versioniertes Migration-System mit `migration_v1.sql`
- model.rs: echte `uuid::Uuid::new_v4()` + `chrono::Utc::now()`

### 3. RM3.3: LUFS/EBU R128 Metering (lufs_meter.rs — 283 LOC)
- K-Weighting Filter (2-stage biquad per ITU-R BS.1770-4)
- Momentary Loudness (400ms window)
- Short-Term Loudness (3s window)
- Integrated Loudness (full program, absolute + relative gating)
- Loudness Range (LRA — 10th/95th percentile)
- True Peak detection (per channel, dBTP)
- Surround channel weights (5.1 layout)

### 4. RM3.4: Audio Recording in Rust (audio_recording.rs — 400 LOC)
- `TrackRecorder` — Arm/Start/Stop/Process per track
- Pre-Record Buffer (configurable, default 5s ring buffer)
- Lock-free audio thread → writer thread via crossbeam channel
- WAV 32-bit float writing via hound (background thread)
- Multi-track recording via `RecordingEngine`
- Punch In/Out support
- Take management with UUID + file path

### 5. RM4.1: MIDI Input Engine (midi_input.rs — 291 LOC)
- `midir` crate integration for direct hardware access
- `MidiMessage` parser (NoteOn/Off, CC, PitchBend, MPE, Clock, SysEx)
- Lock-free event queue (crossbeam, 1024 buffer)
- `MidiInputEngine` — port enumerate/open/close
- MIDI Learn (CC → parameter mapping)
- CC value → parameter range mapping
- Hot-plug device support

### 6. IPC Erweiterung (+21 Commands, +13 Events)
- Recording: Arm/Disarm/Start/Stop/Configure
- MIDI: ListPorts/OpenPort/ClosePort/LearnStart/Cancel/AddMapping/RemoveMapping
- Database: SaveProject/LoadProject/SetSetting/GetSetting
- Python Bridge: +15 neue Methoden, +13 Event-Handler

## Geänderte Dateien

| Datei | Änderung |
|---|---|
| pydaw_engine/Cargo.toml | +7 Dependencies (rusqlite, uuid, chrono, midir, rayon, sha2, claxon) |
| pydaw_engine/src/main.rs | +2 Module (audio_recording, midi_input) |
| pydaw_engine/src/model.rs | uuid::Uuid + chrono statt eigene Impl |
| pydaw_engine/src/db/mod.rs | REWRITE — echtes rusqlite, save/load_project() |
| pydaw_engine/src/db/migrations.rs | REWRITE — versioniertes System |
| pydaw_engine/src/db/migration_v1.sql | NEU (153 LOC) — SQL Schema v1 |
| pydaw_engine/src/fx/lufs_meter.rs | NEU (283 LOC) — LUFS/EBU R128 |
| pydaw_engine/src/fx/mod.rs | +lufs_meter Modul |
| pydaw_engine/src/audio_recording.rs | NEU (400 LOC) — Recording Engine |
| pydaw_engine/src/midi_input.rs | NEU (291 LOC) — MIDI Input |
| pydaw_engine/src/ipc.rs | +21 Commands, +13 Events (+206 LOC) |
| pydaw/services/rust_engine_bridge.py | +15 Methoden, +13 Event-Handler |
| VERSION | 0.0.20.971 |

## Stats
- 448/448 Python-Dateien kompilieren | 0 Fehler
- 79 Rust-Dateien | 33.811 LOC (+5.286 seit v0.0.20.969)
- Roadmap: 97/285 Items (34%)

## Nächste Schritte
1. `cargo build --release` testen
2. RM2.8: Video Decode (ffmpeg-next)
3. RM3.1/3.2: Audio DSP + FX Vervollständigung
4. RM4.2/4.3: MIDI Processing + Export
5. RM5: Plugin-Hosting Vervollständigung
