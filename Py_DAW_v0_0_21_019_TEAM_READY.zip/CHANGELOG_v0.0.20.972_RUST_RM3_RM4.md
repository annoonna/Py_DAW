# CHANGELOG v0.0.20.972 — RUST MIGRATION: RM3.5 + RM4.2/4.3 + Creative FX

**Datum:** 2026-04-04
**Autor:** Claude Opus 4.6
**Arbeitspaket:** RUST_FULL_MIGRATION_ROADMAP — RM3.2, RM3.5, RM4.2, RM4.3

## Was wurde gemacht

### RM3.5: Audio Export/Offline Render (audio_export.rs — 258 LOC)
- `OfflineRenderer` — Faster-than-realtime render pipeline
- WAV export: 16bit, 24bit, 32bit float
- TPDF dithering + first-order noise shaping
- Normalization: Peak, RMS, LUFS
- Progress tracking mit cancel support
- Tail rendering (für Reverb-Ausklingen)
- Full pipeline: render → normalize → dither → write

### RM4.2: MIDI Processing (midi_processing.rs — 395 LOC, Teil 1)
- `MidiProcessor::quantize()` — 10 Grid-Größen (Bar bis 32nd, Triplets, Dotted)
- `quantize_lengths()` — Notenlängen quantisieren
- `transpose()` — Transponieren in Halbtönen
- `scale_velocity()` / `compress_velocity()` — Velocity-Bearbeitung
- `humanize()` — Zufällige Timing/Velocity-Variation
- `legato()` / `staccato()` — Artikulation
- `reverse()` — Noten-Reihenfolge umkehren
- `arpeggiate()` — Akkorde in Arpeggios (5 Patterns: Up/Down/UpDown/DownUp/Random)

### RM4.3: Standard MIDI File I/O (midi_processing.rs — Teil 2)
- `read_smf()` — SMF Typ 0 + Typ 1 lesen
- Variable-length quantity (VLQ) decoder
- Track-Parser mit running status, Note On/Off Matching
- `write_smf()` — SMF Export mit korrektem Header + Track-Chunks
- VLQ encoder

### RM3.2: Creative FX (fx/creative.rs — 153 LOC)
- `Bitcrusher` — Bit-Depth Reduction + Sample-Rate Decimation
- `RingModulator` — 4 Wellenformen (Sine/Square/Triangle/Saw)

## Geänderte Dateien

| Datei | Änderung |
|---|---|
| pydaw_engine/src/main.rs | +3 Module (audio_export, midi_processing, creative) |
| pydaw_engine/src/audio_export.rs | NEU (258 LOC) — Offline Render + Export |
| pydaw_engine/src/midi_processing.rs | NEU (395 LOC) — MIDI Processing + SMF I/O |
| pydaw_engine/src/fx/creative.rs | NEU (153 LOC) — Bitcrusher + Ring Modulator |
| pydaw_engine/src/fx/mod.rs | +creative Modul |
| VERSION | 0.0.20.972 |

## Stats
- 448/448 Python OK | 82 Rust-Dateien | 34.708 LOC Rust (+6.183 seit v0.0.20.969)
- Roadmap: 116/285 Items (41%)
- RM1 ✅ 100% | RM4 ✅ 100% | RM2 85% | RM3 55%

## Nächste Schritte
1. **RM2.8** Video Decode (ffmpeg-next)
2. **RM3.1** Arrangement Renderer vollständig in Rust
3. **RM3.2** Restliche FX: Granular, Vocoder
4. **RM5** Plugin-Hosting Vervollständigung
5. **RM6** Services (Time Travel, SENTINEL, Hardware Controller)
