# CHANGELOG v0.0.20.974 — Rust Build Fix + RM5/RM6/RM9

**Datum:** 2026-04-04
**Autor:** Claude Opus 4.6
**Aufgabe:** cargo build --release fix, RM5.4 Plugin Sandbox, RM6.3-6.5 Services, RM9 Collaboration

## Was wurde gemacht

### 1. cargo build --release — KOMPILIERT ✅
- Rust 1.75 Kompatibilität: `uuid` auf 1.7.0 gepinnt, `rayon-core` auf 1.12.1
- System-Dependencies: `libasound2-dev`, `libudev-dev`, `pkg-config` installiert
- Syntaxfehler in `main.rs` behoben (doppelte mod-Deklarationen, Textmüll in Zeile 34)
- `Copy` derive aus `MidiMessage` entfernt (Vec<u8> in SysEx nicht Copy)
- Catch-all arm in engine.rs `handle_command()` für neue IPC-Kommandos

### 2. RM5.4 — Plugin Sandbox (526 LOC)
- `plugin_sandbox.rs`: Prozess-Isolation Framework
- `SharedPluginMemory`: mmap-basierter Audio-Buffer (Header + Input + Output)
- `SharedAudioHeader`: Atomare Synchronisation (write_seq, read_seq, heartbeat, health)
- `SandboxedPlugin`: Crash-Handling, Watchdog, Passthrough bei Ausfall
- `PluginSandboxManager`: Multi-Plugin Verwaltung, Status-Reports
- `SandboxCommand`/`SandboxResponse`: IPC-Protokoll für Parameter/State
- 5 Unit-Tests

### 3. RM9 — Collaboration (639 LOC)
- `collaboration.rs`: WebSocket-Collaboration System
- `CollabSession`: Peer Management, Track Locking, Edit History, Chat
- `CollabServer`: Message Handling, Join/Leave, Edit Broadcast, Stale Cleanup
- `CollabOperation`: 23 Edit-Typen (Track/Clip/Note/Automation/Transport/Mixer)
- `CollabMessage`: 18 Message-Typen (Join/Edit/Lock/Chat/Sync/Media/Ping)
- `DeltaSync`: Inkrementelle Synchronisation ab beliebiger Revision
- `LanAnnouncement`: mDNS-kompatible Service-Entdeckung (UDP broadcast)
- 7 Unit-Tests

### 4. RM6.3 — Hardware Controller (469 LOC)
- `hardware_controller.rs`: OSC Server/Client + Controller Profiles
- `OscMessage`: Vollständiger OSC encode/decode (Int, Float, String, Blob)
- `OscServer`: Non-blocking UDP Bind, Poll, Send
- `ControllerProfile`: 3 Built-in Profile (APC40, nanoKONTROL2, Launchpad)
- `ControllerManager`: Auto-Detect, MIDI→DAW Action Routing, Bank Navigation
- `LedMapping`/`LedState`: LED Feedback Framework
- 4 Unit-Tests

### 5. RM6.4 — Preset System (489 LOC)
- `preset_system.rs`: SQLite-basierte Preset-Datenbank
- `PresetDatabase`: CRUD, FTS5 Volltextsuche, Kategorien, Favoriten, Ratings
- `PresetFilter`: Multi-Kriterien Suche (Plugin, Kategorie, Tags, Rating, Sort)
- Factory Presets: AETERNA (5), Fusion (2), BachOrgel (1)
- Export/Import (JSON), Usage Tracking
- 5 Unit-Tests

### 6. RM6.5 — Scripting Engine (327 LOC)
- `scripting.rs`: Eingebettete Scripting-Engine
- `ScriptAction`: 25+ atomare DAW-Operationen
- `MacroRecorder`: Action-Aufzeichnung, Kategorie-Filter, Auto-Wait
- `ScriptLibrary`: Speichern, Suchen, Export/Import
- JSON-Serialisierung für Scripts
- 5 Unit-Tests

## Geänderte Dateien
| Datei | Änderung |
|---|---|
| pydaw_engine/Cargo.toml | uuid=1.7.0, rayon=1.8.1 Pins für Rust 1.75 |
| pydaw_engine/src/main.rs | Doppelte mods entfernt, 5 neue Module registriert |
| pydaw_engine/src/engine.rs | Catch-all arm für neue Commands |
| pydaw_engine/src/midi_input.rs | Copy derive entfernt (SysEx Vec<u8>) |
| pydaw_engine/src/plugin_sandbox.rs | NEU — RM5.4 (526 LOC) |
| pydaw_engine/src/collaboration.rs | NEU — RM9 (639 LOC) |
| pydaw_engine/src/hardware_controller.rs | NEU — RM6.3 (469 LOC) |
| pydaw_engine/src/preset_system.rs | NEU — RM6.4 (489 LOC) |
| pydaw_engine/src/scripting.rs | NEU — RM6.5 (327 LOC) |
| PROJECT_DOCS/RUST_FULL_MIGRATION_ROADMAP.md | RM5.4, RM6.3-6.5, RM9 abgehakt |
| VERSION | 0.0.20.974 |

## Statistik
- **2450 neue LOC** Rust (5 Module)
- **26 neue Unit-Tests** — alle bestanden
- **cargo build --release** → Erfolg (42 Warnings, 0 Errors)
- **Rust-Migration Fortschritt:** 57% → 67% (192/285 Items)

## Was als nächstes zu tun ist
1. RM5.1-5.3 — VST3/CLAP/LV2 Plugin-Hosting Vervollständigung (Parameter, GUI, State)
2. RM2.8 — Video Decode (FFmpeg, Thumbnails, Proxy)
3. RM3.1-3.3 — Audio DSP Vervollständigung (Arrangement Renderer, Time-Stretch)
4. RM10 — IPC Vervollständigung
5. RM11 — GUI Migration (egui/iced/slint Prototypen)
