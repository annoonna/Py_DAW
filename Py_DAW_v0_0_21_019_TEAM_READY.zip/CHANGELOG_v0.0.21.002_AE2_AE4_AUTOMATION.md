# CHANGELOG v0.0.21.002 — AE2/AE4 Automation + Launcher Sync

**Datum:** 2026-04-06
**Kollege:** Claude Opus 4.6

## Implementierte Features

### AE2.2 ✅ Automation Snap-to-Grid
- `_snap_auto_beat()` Helper snaps Pencil-Punkte zum Beat-Raster
- Pencil-Add und Pencil-Drag beide snap-aware
- Nutzt globale Snap-Quantisierung (1/16, 1/8, 1/4 etc.)

### AE2.3 ✅ Automation Value-Display
- `_auto_value_display()` konvertiert Normalized → echte Einheiten
- Gain: dB (-∞ bis +12 dB), Pan: L/R% (L50%, C, R75%), Pitch/Formant: Semitones
- Status-Message zeigt beim Zeichnen: "Auto: gain @ 4.00 = +3.2 dB [scurve]"

### AE4.1 ✅ Launcher → Editor Sync (verifiziert)
- War bereits korrekt verdrahtet: `set_active_clip()` → `active_clip_changed` → `editor_tabs.set_clip()`

### AE4.2 ✅ Editor → Launcher Live-Update (verifiziert)
- War bereits korrekt verdrahtet: `_emit_updated()` → `project_updated` → Launcher `refresh()`

### AE4.4 ✅ Loop-Region Sync (verifiziert)
- Launcher nutzt `clip.loop_start_beats`/`loop_end_beats` bei Voice-Erstellung

## Gesamtfortschritt
- **AE1:** 5/5 ✅ KOMPLETT
- **AE2:** 3/6 ✅ (AE2.1 Kurven, AE2.2 Snap, AE2.3 Value-Display)
- **AE4:** 4/6 ✅ (AE4.1 Sync, AE4.2 Update, AE4.3 Automation, AE4.4 Loop)
- **Gesamt:** 12/67 Items

## Geänderte Dateien
1. `pydaw/ui/audio_editor/audio_event_editor.py` — Snap + Value Display + Crossfade Menu
2. `PROJECT_DOCS/AUDIO_EDITOR_ROADMAP.md` — 5 Items abgehakt
3. `VERSION` — 0.0.21.002

## Nichts kaputt gemacht ✅
