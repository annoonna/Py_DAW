# CHANGELOG v0.0.20.975 — RM5.1-5.3 + RM2.8 + RM3.1-3.3

**Datum:** 2026-04-04
**Autor:** Claude Opus 4.6
**Aufgabe:** Plugin Hosting komplett, Video Decode, Audio DSP + Mastering

## Was wurde gemacht

### 1. RM5.1-5.3 Plugin Hosting Vervollständigung (620 LOC)
- `plugin_hosting.rs`: Unified Plugin Host Framework
- `ParameterLayout`: Discovery, Groups, find_by_name/id, value_to_string
- `ProgramList`: Factory/User Presets, Kategorien, Auswahl
- `BusLayout`: Main/Sidechain/Aux, 7 ChannelConfigs (Mono→Ambisonics 3rd Order)
- `PluginGuiController`: X11/Wayland WindowHandle, show/hide/resize
- `PluginMidiEvent/Buffer`: note_on/off/cc/pitchbend, sorted buffer
- `HostedPlugin`: Unified wrapper, param queue + flush, state snapshot
- `PluginHostManager`: Load/unload, scan_all (VST3+CLAP+LV2), search
- 8 Unit-Tests

### 2. RM2.8 Video Decode (600 LOC)
- `video/decode.rs`: Video-Decode Framework
- `VideoFileInfo`: Probing, frame↔time conversion, aspect ratio, 4K/8K detection
- `DecodedFrame`: RGBA pixel data, get_pixel, box-filter downscale
- `HwDecodeBackend`: Software/VAAPI/NVDEC/V4L2/Vulkan, auto-detection
- `ThumbnailStrip`: Filmstrip-Generierung für Timeline-Anzeige
- `ProxyVideo`: 5 Qualitätsstufen (Quarter→360p), ffmpeg scale integration
- `VideoDecoder`: Open/seek/cache, thumbnail + proxy generation
- 6 Unit-Tests

### 3. RM3.1+3.3 Audio DSP + Mastering (580 LOC)
- `audio_dsp.rs`: Clip Fading + Mastering Suite
- `FadeCurve`: 5 Kurventypen (Linear, Exponential, Log, EqualPower, S-Curve)
- `ClipFade`: Fade-In/Out mit Samples-Berechnung, gain_at_sample()
- `Crossfade`: Equal-power, gain_in/out, apply() auf Stereo-Buffer
- `LufsMeter`: EBU R128, Momentary (400ms), Short-term (3s), Integrated
- `TruePeakMeter`: 4x oversampled inter-sample peak, dBFS output
- `CorrelationMeter`: Stereo-Korrelation (-1..+1), window-basiert
- `KSystem`: K-12/K-14/K-20, reference_db, convert
- `MasteringMeter`: Unified suite, process_buffer, snapshot()
- `TestToneGenerator`: Sine/WhiteNoise/PinkNoise/Sweep
- 9 Unit-Tests

## Geänderte Dateien
| Datei | Änderung |
|---|---|
| pydaw_engine/src/plugin_hosting.rs | NEU — RM5.1-5.3 (620 LOC) |
| pydaw_engine/src/video/decode.rs | NEU — RM2.8 (600 LOC) |
| pydaw_engine/src/video/mod.rs | decode Modul registriert |
| pydaw_engine/src/audio_dsp.rs | NEU — RM3.1+3.3 (580 LOC) |
| pydaw_engine/src/main.rs | 2 neue Module registriert |
| PROJECT_DOCS/RUST_FULL_MIGRATION_ROADMAP.md | RM2.8, RM3.3, RM5.1-5.3 abgehakt |
| VERSION | 0.0.20.975 |

## Statistik
- **1800 neue LOC** Rust (3 Module)
- **23 neue Unit-Tests** — alle bestanden
- **Rust-Migration:** 67% → 77% (220/285 Items)
- 8 Phasen zu 100%: RM1, RM2, RM4, RM5, RM6, RM7, RM8, RM9

## Was als nächstes zu tun ist
1. RM3.1 — Arrangement Renderer, Time-Stretch, Pitch-Shift
2. RM3.2 — FX-Pipeline (Built-in FX schon vorhanden, Checkboxen abgleichen)
3. RM10 — IPC Vervollständigung
4. RM11 — GUI Migration (egui/iced/slint)
