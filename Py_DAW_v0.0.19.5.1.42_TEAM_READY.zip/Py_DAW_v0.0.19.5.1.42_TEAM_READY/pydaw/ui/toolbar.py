"""Toolbar panel (tools + grid)."""

from __future__ import annotations

from PyQt6.QtWidgets import QWidget, QHBoxLayout, QPushButton, QLabel, QComboBox, QToolButton
from PyQt6.QtCore import pyqtSignal


class ToolBarPanel(QWidget):
    tool_changed = pyqtSignal(str)
    grid_changed = pyqtSignal(str)
    automation_toggled = pyqtSignal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(8)

        # Tool ComboBox (STATT 5 Buttons!)
        layout.addWidget(QLabel("Werkzeug:"))
        self.cmb_tool = QComboBox()
        self.cmb_tool.addItem("⬚ Zeiger (V)", "select")
        self.cmb_tool.addItem("✂ Messer (K)", "knife")
        self.cmb_tool.addItem("⎅ Zeitauswahl", "time_select")
        self.cmb_tool.addItem("✎ Stift (D)", "draw")
        self.cmb_tool.addItem("⌫ Radiergummi (E)", "erase")
        self.cmb_tool.setCurrentIndex(0)
        
        def _on_tool_changed(index):
            tool_data = self.cmb_tool.itemData(index)
            if tool_data:
                self.tool_changed.emit(str(tool_data))
        
        self.cmb_tool.currentIndexChanged.connect(_on_tool_changed)
        layout.addWidget(self.cmb_tool)

        layout.addSpacing(12)
        layout.addWidget(QLabel("Grid/Snap:"))
        self.cmb_grid = QComboBox()
        self.cmb_grid.addItems(["1/4", "1/8", "1/16", "1/32", "1/64"])
        self.cmb_grid.setCurrentText("1/16")
        self.cmb_grid.currentTextChanged.connect(lambda t: self.grid_changed.emit(str(t)))
        layout.addWidget(self.cmb_grid)

        layout.addSpacing(12)
        self.btn_auto = QToolButton()
        self.btn_auto.setText("Automation")
        self.btn_auto.setCheckable(True)
        self.btn_auto.toggled.connect(self.automation_toggled.emit)
        layout.addWidget(self.btn_auto)

        layout.addStretch(1)
