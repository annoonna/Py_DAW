# Session Log — v0.0.20.742

**Datum:** 2026-03-23
**Kollege:** Claude Sonnet 4.6
**Aufgabe:** Advanced Sampler Kein-Ton: Zwei-Engine-Problem

## Root Cause (v0.0.20.742)

`_create_advanced_sampler_engines()` erstellt Engine A → in SamplerRegistry → bekommt MIDI.
`_ensure_engine()` im Widget erstellt Engine B → hat die geladenen Zones.

Engine A hat leere Map → `note_on()` findet keine Zones → `pull()` → None → Stille.

## Fixes (multisample_widget.py + audio_engine.py)

### _do_persist_now():
- Holt `_advanced_sampler_engines[track_id]` direkt aus audio_engine
- Ruft `live_eng.set_map(self._map)` auf → Engine A bekommt sofort die Zones
- Fallback: rebuild_fx_maps() falls noch keine Live-Engine existiert

### _restore_instrument_state():
- Gleicher Direct-Push nach import_state()

### _sync_engine_map() (map_changed Signal):
- Pushed zuerst in Live-Engine (_advanced_sampler_engines[track_id])
- Dann in Widget-eigene Engine (_engine)

### _create_advanced_sampler_engines():
- Nach Engine-Erstellung: kopiert Map vom alten SamplerRegistry-Eintrag
  falls dieser bereits Zones hatte
