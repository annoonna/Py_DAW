"""EnginePerformanceBenchmark — Python vs Rust Engine Vergleich.

v0.0.20.662 — Phase 1D

Provides A/B performance comparison between the Python and Rust audio engines.
Measures render time, latency, CPU load, and throughput for each subsystem.

Usage:
    bench = EnginePerformanceBenchmark()
    results = bench.run_benchmark(num_tracks=16, duration_sec=10.0)
    print(bench.format_report(results))

The benchmark is non-destructive — it does NOT modify any existing audio
engine state or project data.
"""

from __future__ import annotations

import logging
import math
import os
import statistics
import time
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

try:
    import numpy as np
    _NP_AVAILABLE = True
except ImportError:
    _NP_AVAILABLE = False

try:
    from PyQt6.QtCore import QObject, pyqtSignal
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class SubsystemBenchResult:
    """Benchmark result for a single subsystem on a single backend."""
    subsystem: str = ""
    backend: str = ""           # "python" or "rust"
    num_tracks: int = 0
    buffer_size: int = 512
    sample_rate: int = 44100
    duration_sec: float = 0.0

    # Timing (microseconds)
    render_times_us: List[float] = field(default_factory=list)
    avg_render_us: float = 0.0
    median_render_us: float = 0.0
    p95_render_us: float = 0.0
    p99_render_us: float = 0.0
    max_render_us: float = 0.0
    min_render_us: float = 0.0
    stddev_render_us: float = 0.0

    # Budget
    budget_us: float = 0.0     # Available time per buffer (sample_rate/buffer_size based)
    cpu_load_pct: float = 0.0  # avg_render_us / budget_us * 100
    headroom_pct: float = 0.0  # 100 - cpu_load_pct
    xruns: int = 0             # Buffers that exceeded budget

    # Throughput
    buffers_processed: int = 0
    total_samples: int = 0
    realtime_ratio: float = 0.0  # >1.0 means faster than realtime

    # IPC (Rust only)
    ipc_roundtrip_us: float = 0.0

    error: str = ""


@dataclass
class BenchmarkReport:
    """Complete benchmark report comparing Python and Rust."""
    timestamp: float = 0.0
    num_tracks: int = 0
    buffer_size: int = 512
    sample_rate: int = 44100
    duration_sec: float = 0.0
    python_results: Dict[str, SubsystemBenchResult] = field(default_factory=dict)
    rust_results: Dict[str, SubsystemBenchResult] = field(default_factory=dict)
    rust_available: bool = False
    winner: str = ""          # "python", "rust", or "tie"
    speedup_factor: float = 1.0


# ---------------------------------------------------------------------------
# EnginePerformanceBenchmark
# ---------------------------------------------------------------------------

if _QT_AVAILABLE:
    _BASE = QObject
else:
    _BASE = object


class EnginePerformanceBenchmark(_BASE):
    """Benchmarks the Python and (optionally) Rust audio engine.

    Non-destructive: uses synthetic audio data, does not touch project state.
    """

    if _QT_AVAILABLE:
        progress = pyqtSignal(int, int, str)   # current, total, message
        finished = pyqtSignal(object)           # BenchmarkReport

    def __init__(self):
        if _QT_AVAILABLE:
            super().__init__()
        self._cancel = False

    def cancel(self):
        """Cancel a running benchmark."""
        self._cancel = True

    # --- Public API ----------------------------------------------------------

    def run_benchmark(
        self,
        num_tracks: int = 8,
        buffer_size: int = 512,
        sample_rate: int = 44100,
        duration_sec: float = 5.0,
    ) -> BenchmarkReport:
        """Run a complete benchmark comparing Python and Rust engines.

        Args:
            num_tracks: Number of simulated tracks.
            buffer_size: Audio buffer size in samples.
            sample_rate: Sample rate in Hz.
            duration_sec: Duration of the benchmark in seconds.

        Returns:
            BenchmarkReport with results for both engines.
        """
        self._cancel = False
        report = BenchmarkReport(
            timestamp=time.time(),
            num_tracks=num_tracks,
            buffer_size=buffer_size,
            sample_rate=sample_rate,
            duration_sec=duration_sec,
        )

        # Budget per buffer in microseconds
        budget_us = (buffer_size / sample_rate) * 1_000_000

        # --- Python benchmark ---
        self._emit_progress(0, 4, "Benchmarking Python audio playback...")
        report.python_results["audio_playback"] = self._bench_python_audio(
            num_tracks, buffer_size, sample_rate, duration_sec, budget_us,
        )

        if self._cancel:
            return report

        self._emit_progress(1, 4, "Benchmarking Python MIDI dispatch...")
        report.python_results["midi_dispatch"] = self._bench_python_midi(
            num_tracks, buffer_size, sample_rate, duration_sec, budget_us,
        )

        if self._cancel:
            return report

        # --- Rust benchmark (if available) ---
        rust_avail = self._is_rust_available()
        report.rust_available = rust_avail

        if rust_avail:
            self._emit_progress(2, 4, "Benchmarking Rust audio playback...")
            report.rust_results["audio_playback"] = self._bench_rust_audio(
                num_tracks, buffer_size, sample_rate, duration_sec, budget_us,
            )

            if self._cancel:
                return report

            self._emit_progress(3, 4, "Benchmarking Rust MIDI dispatch...")
            report.rust_results["midi_dispatch"] = self._bench_rust_midi(
                num_tracks, buffer_size, sample_rate, duration_sec, budget_us,
            )
        else:
            log.info("Rust engine not available — skipping Rust benchmarks")

        # --- Compute comparison ---
        self._compute_comparison(report)

        # Update migration controller metrics
        self._update_migration_metrics(report)

        self._emit_progress(4, 4, "Benchmark complete")
        if _QT_AVAILABLE:
            try:
                self.finished.emit(report)
            except Exception:
                pass

        return report

    def run_benchmark_async(self, **kwargs):
        """Run benchmark in a background thread."""
        t = threading.Thread(
            target=self._run_async_wrapper,
            args=(kwargs,),
            name="pydaw-benchmark",
            daemon=True,
        )
        t.start()
        return t

    def _run_async_wrapper(self, kwargs):
        try:
            self.run_benchmark(**kwargs)
        except Exception as e:
            log.error("Benchmark thread error: %s", e)

    # --- Python benchmarks ---------------------------------------------------

    def _bench_python_audio(
        self,
        num_tracks: int,
        buffer_size: int,
        sample_rate: int,
        duration_sec: float,
        budget_us: float,
    ) -> SubsystemBenchResult:
        """Benchmark Python audio rendering (mix N tracks of sine waves)."""
        result = SubsystemBenchResult(
            subsystem="audio_playback",
            backend="python",
            num_tracks=num_tracks,
            buffer_size=buffer_size,
            sample_rate=sample_rate,
            duration_sec=duration_sec,
            budget_us=budget_us,
        )

        if not _NP_AVAILABLE:
            result.error = "numpy not available"
            return result

        # Generate synthetic per-track audio (sine waves at different frequencies)
        track_buffers = []
        for i in range(num_tracks):
            freq = 220.0 * (1.0 + i * 0.5)
            t = np.arange(buffer_size, dtype=np.float32) / sample_rate
            mono = (np.sin(2.0 * np.pi * freq * t) * 0.3).astype(np.float32)
            stereo = np.column_stack([mono, mono])  # (frames, 2)
            track_buffers.append(stereo)

        # Simulate mixing: sum all tracks, apply volume/pan, master limiter
        num_buffers = int((duration_sec * sample_rate) / buffer_size)
        render_times = []
        xruns = 0

        master_buf = np.zeros((buffer_size, 2), dtype=np.float32)

        for _ in range(num_buffers):
            if self._cancel:
                break

            t0 = time.perf_counter_ns()

            # Zero master
            master_buf[:] = 0.0

            # Mix tracks
            for i, tb in enumerate(track_buffers):
                vol = 0.7
                pan = (i - num_tracks / 2) / max(num_tracks, 1)
                pan_l = math.cos(max(0.0, min(1.0, (pan + 1.0) / 2.0)) * (math.pi / 2.0))
                pan_r = math.sin(max(0.0, min(1.0, (pan + 1.0) / 2.0)) * (math.pi / 2.0))
                master_buf[:, 0] += tb[:, 0] * vol * pan_l
                master_buf[:, 1] += tb[:, 1] * vol * pan_r

            # Simple limiter
            peak = np.max(np.abs(master_buf))
            if peak > 1.0:
                master_buf /= peak

            t1 = time.perf_counter_ns()
            elapsed_us = (t1 - t0) / 1000.0
            render_times.append(elapsed_us)
            if elapsed_us > budget_us:
                xruns += 1

        self._fill_stats(result, render_times, xruns, num_buffers, buffer_size, sample_rate)
        return result

    def _bench_python_midi(
        self,
        num_tracks: int,
        buffer_size: int,
        sample_rate: int,
        duration_sec: float,
        budget_us: float,
    ) -> SubsystemBenchResult:
        """Benchmark Python MIDI dispatch (process N notes across tracks)."""
        result = SubsystemBenchResult(
            subsystem="midi_dispatch",
            backend="python",
            num_tracks=num_tracks,
            buffer_size=buffer_size,
            sample_rate=sample_rate,
            duration_sec=duration_sec,
            budget_us=budget_us,
        )

        # Simulate MIDI event processing: schedule notes, dispatch to tracks
        num_buffers = int((duration_sec * sample_rate) / buffer_size)
        notes_per_track = 4  # simultaneous notes per track
        render_times = []
        xruns = 0

        # Pre-build event lists
        events = []
        for t in range(num_tracks):
            for n in range(notes_per_track):
                events.append({
                    "track": t,
                    "type": "note_on",
                    "note": 60 + n,
                    "velocity": 0.8,
                    "channel": 0,
                    "sample_offset": 0,
                })

        for _ in range(num_buffers):
            if self._cancel:
                break

            t0 = time.perf_counter_ns()

            # Simulate dispatch: iterate events, route to tracks, process
            dispatched = [[] for _ in range(num_tracks)]
            for ev in events:
                ti = ev["track"]
                dispatched[ti].append(ev)

            # Simulate per-track MIDI→audio conversion (trivial)
            for ti, track_events in enumerate(dispatched):
                for _ev in track_events:
                    # Would call instrument.process_note() here
                    pass

            t1 = time.perf_counter_ns()
            elapsed_us = (t1 - t0) / 1000.0
            render_times.append(elapsed_us)
            if elapsed_us > budget_us:
                xruns += 1

        self._fill_stats(result, render_times, xruns, num_buffers, buffer_size, sample_rate)
        return result

    # --- Rust benchmarks -----------------------------------------------------

    def _bench_rust_audio(
        self,
        num_tracks: int,
        buffer_size: int,
        sample_rate: int,
        duration_sec: float,
        budget_us: float,
    ) -> SubsystemBenchResult:
        """Benchmark Rust audio rendering via IPC."""
        result = SubsystemBenchResult(
            subsystem="audio_playback",
            backend="rust",
            num_tracks=num_tracks,
            buffer_size=buffer_size,
            sample_rate=sample_rate,
            duration_sec=duration_sec,
            budget_us=budget_us,
        )

        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            bridge = RustEngineBridge.instance()

            if not bridge.is_connected:
                started = bridge.start_engine(
                    sample_rate=sample_rate,
                    buffer_size=buffer_size,
                )
                if not started:
                    result.error = "Could not start Rust engine"
                    return result

            # Configure tracks
            for i in range(num_tracks):
                bridge.add_track(f"bench_track_{i}", i, "audio")

            # Measure IPC roundtrip (ping/pong)
            ipc_times = []
            for _ in range(20):
                t0 = time.perf_counter_ns()
                bridge.ping()
                # Wait briefly for pong (non-blocking, approximate)
                time.sleep(0.001)
                t1 = time.perf_counter_ns()
                ipc_times.append((t1 - t0) / 1000.0)

            result.ipc_roundtrip_us = statistics.mean(ipc_times) if ipc_times else 0.0

            # Measure playback render by requesting engine stats
            # The actual render happens in Rust — we measure via Pong cpu_load
            bridge.set_tempo(120.0)
            bridge.play()

            render_times = []
            num_samples = int(duration_sec * sample_rate)
            num_buffers = num_samples // buffer_size

            # Poll engine performance via ping/pong
            t_start = time.monotonic()
            xruns = 0
            while time.monotonic() - t_start < duration_sec:
                if self._cancel:
                    break
                t0 = time.perf_counter_ns()
                bridge.ping()
                time.sleep(buffer_size / sample_rate)
                t1 = time.perf_counter_ns()
                elapsed_us = (t1 - t0) / 1000.0
                render_times.append(elapsed_us)
                if elapsed_us > budget_us * 1.5:
                    xruns += 1

            bridge.stop()

            # Cleanup benchmark tracks
            for i in range(num_tracks):
                bridge.remove_track(f"bench_track_{i}")

            self._fill_stats(result, render_times, xruns, len(render_times), buffer_size, sample_rate)

        except Exception as e:
            result.error = str(e)
            log.error("Rust audio benchmark error: %s", e)

        return result

    def _bench_rust_midi(
        self,
        num_tracks: int,
        buffer_size: int,
        sample_rate: int,
        duration_sec: float,
        budget_us: float,
    ) -> SubsystemBenchResult:
        """Benchmark Rust MIDI dispatch via IPC."""
        result = SubsystemBenchResult(
            subsystem="midi_dispatch",
            backend="rust",
            num_tracks=num_tracks,
            buffer_size=buffer_size,
            sample_rate=sample_rate,
            duration_sec=duration_sec,
            budget_us=budget_us,
        )

        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            bridge = RustEngineBridge.instance()

            if not bridge.is_connected:
                result.error = "Rust engine not connected"
                return result

            notes_per_track = 4
            render_times = []
            xruns = 0
            num_buffers = int((duration_sec * sample_rate) / buffer_size)

            for buf_idx in range(min(num_buffers, 5000)):
                if self._cancel:
                    break

                t0 = time.perf_counter_ns()

                # Send MIDI events via IPC
                for t in range(num_tracks):
                    for n in range(notes_per_track):
                        bridge.midi_note_on(f"bench_track_{t}", 0, 60 + n, 0.8)

                t1 = time.perf_counter_ns()
                elapsed_us = (t1 - t0) / 1000.0
                render_times.append(elapsed_us)
                if elapsed_us > budget_us:
                    xruns += 1

            self._fill_stats(result, render_times, xruns, len(render_times), buffer_size, sample_rate)

        except Exception as e:
            result.error = str(e)
            log.error("Rust MIDI benchmark error: %s", e)

        return result

    # --- Statistics helpers ---------------------------------------------------

    def _fill_stats(
        self,
        result: SubsystemBenchResult,
        render_times: List[float],
        xruns: int,
        num_buffers: int,
        buffer_size: int,
        sample_rate: int,
    ):
        """Fill statistics into a SubsystemBenchResult."""
        if not render_times:
            return

        result.render_times_us = render_times
        result.avg_render_us = statistics.mean(render_times)
        result.median_render_us = statistics.median(render_times)
        result.max_render_us = max(render_times)
        result.min_render_us = min(render_times)

        if len(render_times) >= 2:
            result.stddev_render_us = statistics.stdev(render_times)
            sorted_times = sorted(render_times)
            idx95 = int(len(sorted_times) * 0.95)
            idx99 = int(len(sorted_times) * 0.99)
            result.p95_render_us = sorted_times[min(idx95, len(sorted_times) - 1)]
            result.p99_render_us = sorted_times[min(idx99, len(sorted_times) - 1)]
        else:
            result.stddev_render_us = 0.0
            result.p95_render_us = render_times[0]
            result.p99_render_us = render_times[0]

        result.xruns = xruns
        result.buffers_processed = num_buffers
        result.total_samples = num_buffers * buffer_size

        if result.budget_us > 0 and result.avg_render_us > 0:
            result.cpu_load_pct = (result.avg_render_us / result.budget_us) * 100.0
            result.headroom_pct = 100.0 - result.cpu_load_pct
            result.realtime_ratio = result.budget_us / result.avg_render_us

    def _compute_comparison(self, report: BenchmarkReport):
        """Compute overall winner and speedup factor."""
        py_audio = report.python_results.get("audio_playback")
        rs_audio = report.rust_results.get("audio_playback")

        if py_audio and rs_audio and py_audio.avg_render_us > 0 and rs_audio.avg_render_us > 0:
            report.speedup_factor = py_audio.avg_render_us / rs_audio.avg_render_us
            if report.speedup_factor > 1.1:
                report.winner = "rust"
            elif report.speedup_factor < 0.9:
                report.winner = "python"
            else:
                report.winner = "tie"
        elif py_audio and not rs_audio:
            report.winner = "python"
            report.speedup_factor = 1.0
        else:
            report.winner = "unknown"
            report.speedup_factor = 1.0

    def _update_migration_metrics(self, report: BenchmarkReport):
        """Push benchmark results to the migration controller."""
        try:
            from pydaw.services.engine_migration import EngineMigrationController
            ctrl = EngineMigrationController.instance()

            for subsystem in ["audio_playback", "midi_dispatch"]:
                py_res = report.python_results.get(subsystem)
                rs_res = report.rust_results.get(subsystem)
                ctrl.update_performance_metrics(
                    subsystem,
                    python_avg_us=py_res.avg_render_us if py_res else 0.0,
                    rust_avg_us=rs_res.avg_render_us if rs_res else 0.0,
                )
        except Exception as e:
            log.debug("Could not update migration metrics: %s", e)

    # --- Helpers -------------------------------------------------------------

    @staticmethod
    def _is_rust_available() -> bool:
        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            return RustEngineBridge.is_available()
        except Exception:
            return False

    def _emit_progress(self, current: int, total: int, message: str):
        if _QT_AVAILABLE:
            try:
                self.progress.emit(current, total, message)
            except Exception:
                pass

    # --- Report formatting ---------------------------------------------------

    @staticmethod
    def format_report(report: BenchmarkReport) -> str:
        """Format a BenchmarkReport as a human-readable string."""
        lines = []
        lines.append("=" * 70)
        lines.append("  Py_DAW Engine Performance Benchmark")
        lines.append("=" * 70)
        lines.append(f"  Tracks: {report.num_tracks}  |  Buffer: {report.buffer_size}"
                      f"  |  SR: {report.sample_rate} Hz  |  Duration: {report.duration_sec}s")
        budget_us = (report.buffer_size / report.sample_rate) * 1_000_000
        lines.append(f"  Budget per buffer: {budget_us:.0f} µs")
        lines.append("")

        def _fmt_result(r: SubsystemBenchResult) -> List[str]:
            if r.error:
                return [f"    ERROR: {r.error}"]
            return [
                f"    Avg: {r.avg_render_us:>8.1f} µs  |  Median: {r.median_render_us:>8.1f} µs",
                f"    P95: {r.p95_render_us:>8.1f} µs  |  P99:    {r.p99_render_us:>8.1f} µs",
                f"    Max: {r.max_render_us:>8.1f} µs  |  StdDev: {r.stddev_render_us:>8.1f} µs",
                f"    CPU Load: {r.cpu_load_pct:>5.1f}%  |  Headroom: {r.headroom_pct:>5.1f}%"
                f"  |  XRuns: {r.xruns}",
                f"    Realtime ratio: {r.realtime_ratio:.2f}x",
            ]

        for subsystem in ["audio_playback", "midi_dispatch"]:
            lines.append(f"  --- {subsystem.replace('_', ' ').title()} ---")
            py_res = report.python_results.get(subsystem)
            rs_res = report.rust_results.get(subsystem)

            if py_res:
                lines.append("  [Python]")
                lines.extend(_fmt_result(py_res))

            if rs_res:
                lines.append("  [Rust]")
                lines.extend(_fmt_result(rs_res))
                if rs_res.ipc_roundtrip_us > 0:
                    lines.append(f"    IPC roundtrip: {rs_res.ipc_roundtrip_us:.1f} µs")

            lines.append("")

        lines.append("  --- Summary ---")
        lines.append(f"  Rust available: {report.rust_available}")
        lines.append(f"  Winner: {report.winner.upper()}")
        if report.speedup_factor != 1.0:
            lines.append(f"  Speedup factor: {report.speedup_factor:.2f}x")
        lines.append("=" * 70)

        return "\n".join(lines)
