"""EngineMigrationController — Schrittweise Migration Python→Rust.

v0.0.20.662 — Phase 1D

Manages the gradual migration from the Python audio engine to the Rust engine.
Each subsystem (audio playback, MIDI dispatch, plugin hosting) can be toggled
independently, allowing a safe step-by-step transition.

Migration order (as designed in ROADMAP):
    1. Audio Playback  — Rust renders arrangement audio, Python still handles MIDI + plugins
    2. MIDI Dispatch    — Rust handles MIDI routing to instruments
    3. Plugin Hosting   — Rust hosts VST3/CLAP/LV2 plugins natively

Architecture:
    ┌──────────────────────────────────────────────────────┐
    │  EngineMigrationController (singleton)               │
    │                                                      │
    │  ┌─────────────┐  ┌─────────────┐  ┌──────────────┐ │
    │  │ audio_play   │  │ midi_dispatch│  │ plugin_host  │ │
    │  │ ☑ Python     │  │ ☑ Python     │  │ ☑ Python     │ │
    │  │ ☐ Rust       │  │ ☐ Rust       │  │ ☐ Rust       │ │
    │  └─────────────┘  └─────────────┘  └──────────────┘ │
    │                                                      │
    │  State saved to QSettings → survives restarts        │
    │  Hot-swap: switch subsystems without restarting DAW  │
    └──────────────────────────────────────────────────────┘

Usage:
    ctrl = EngineMigrationController.instance()
    ctrl.set_subsystem("audio_playback", "rust")
    ctrl.set_subsystem("midi_dispatch", "python")
    if ctrl.should_use_rust("audio_playback"):
        # delegate to RustEngineBridge
    else:
        # use Python engine
"""

from __future__ import annotations

import logging
import time
import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

try:
    from PyQt6.QtCore import QObject, pyqtSignal, QSettings
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

class EngineBackend(str, Enum):
    """Which engine handles a given subsystem."""
    PYTHON = "python"
    RUST = "rust"


class MigrationSubsystem(str, Enum):
    """The three migrateable subsystems."""
    AUDIO_PLAYBACK = "audio_playback"
    MIDI_DISPATCH = "midi_dispatch"
    PLUGIN_HOSTING = "plugin_hosting"


class MigrationStatus(str, Enum):
    """Status of a subsystem migration."""
    IDLE = "idle"              # Not started
    SWITCHING = "switching"    # In progress (brief transition)
    ACTIVE = "active"          # Running on target backend
    FAILED = "failed"          # Switch failed, rolled back
    ROLLBACK = "rollback"      # Rolling back to previous backend


@dataclass
class SubsystemState:
    """State of a single migrateable subsystem."""
    subsystem: MigrationSubsystem
    backend: EngineBackend = EngineBackend.PYTHON
    status: MigrationStatus = MigrationStatus.ACTIVE
    last_switch_time: float = 0.0
    error_message: str = ""
    switch_count: int = 0
    # Performance metrics (filled by benchmark)
    python_avg_render_us: float = 0.0
    rust_avg_render_us: float = 0.0


@dataclass
class MigrationSnapshot:
    """Complete migration state for serialization."""
    subsystems: Dict[str, str] = field(default_factory=dict)
    rust_as_default: bool = False
    timestamp: float = 0.0


# ---------------------------------------------------------------------------
# Settings keys
# ---------------------------------------------------------------------------

_SETTINGS_PREFIX = "engine_migration/"
_KEY_AUDIO = _SETTINGS_PREFIX + "audio_playback"
_KEY_MIDI = _SETTINGS_PREFIX + "midi_dispatch"
_KEY_PLUGIN = _SETTINGS_PREFIX + "plugin_hosting"
_KEY_RUST_DEFAULT = _SETTINGS_PREFIX + "rust_as_default"


# ---------------------------------------------------------------------------
# EngineMigrationController
# ---------------------------------------------------------------------------

if _QT_AVAILABLE:
    _BASE = QObject
else:
    _BASE = object


class EngineMigrationController(_BASE):
    """Singleton controller for step-by-step Python→Rust engine migration.

    Thread safety:
        All public methods are thread-safe (protected by _lock).
        Signal emissions happen on the calling thread — connect with Qt::QueuedConnection
        if calling from non-GUI threads.
    """

    # Qt signals
    if _QT_AVAILABLE:
        subsystem_changed = pyqtSignal(str, str, str)   # subsystem, new_backend, status
        migration_error = pyqtSignal(str, str)           # subsystem, error_message
        rust_default_changed = pyqtSignal(bool)          # is_default

    # Singleton
    _instance: Optional[EngineMigrationController] = None
    _instance_lock = threading.Lock()

    @classmethod
    def instance(cls) -> EngineMigrationController:
        """Get or create the singleton instance."""
        if cls._instance is None:
            with cls._instance_lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def __init__(self):
        if _QT_AVAILABLE:
            super().__init__()

        self._lock = threading.RLock()

        # Per-subsystem state
        self._states: Dict[MigrationSubsystem, SubsystemState] = {
            MigrationSubsystem.AUDIO_PLAYBACK: SubsystemState(
                subsystem=MigrationSubsystem.AUDIO_PLAYBACK,
            ),
            MigrationSubsystem.MIDI_DISPATCH: SubsystemState(
                subsystem=MigrationSubsystem.MIDI_DISPATCH,
            ),
            MigrationSubsystem.PLUGIN_HOSTING: SubsystemState(
                subsystem=MigrationSubsystem.PLUGIN_HOSTING,
            ),
        }

        # Whether Rust is the default for new projects
        self._rust_as_default = False

        # Callbacks for pre/post switch hooks
        self._pre_switch_hooks: Dict[MigrationSubsystem, List[Callable]] = {
            s: [] for s in MigrationSubsystem
        }
        self._post_switch_hooks: Dict[MigrationSubsystem, List[Callable]] = {
            s: [] for s in MigrationSubsystem
        }

        # Validation callbacks: return True if Rust subsystem is functional
        self._validators: Dict[MigrationSubsystem, Optional[Callable]] = {
            s: None for s in MigrationSubsystem
        }

        # Load saved state
        self._load_settings()

    # --- Public API: Query ---------------------------------------------------

    def should_use_rust(self, subsystem: str) -> bool:
        """Check if a subsystem should use the Rust engine.

        Args:
            subsystem: One of 'audio_playback', 'midi_dispatch', 'plugin_hosting'

        Returns:
            True if the subsystem is configured to use Rust AND the Rust engine
            is available AND the subsystem is actually implemented in Rust.

        v0.0.20.666 SAFETY: The Rust engine is currently Phase 1A/1B (sine PoC +
        audio graph). It does NOT render Python instruments (Sampler, AETERNA,
        DrumMachine, SF2, etc). Audio playback delegation is therefore DISABLED
        until the Rust engine gains full instrument rendering support.
        Returning True here when Rust can't render instruments causes:
        - Silent playback (no sound)
        - ALSA underrun floods
        - GUI freezes from error flooding
        """
        # SAFETY GATE: Rust audio rendering not ready for production use
        # All Python-based instruments need the Python engine to produce sound.
        # Remove this gate once Rust engine supports full clip/instrument rendering.
        return False

    def get_backend(self, subsystem: str) -> str:
        """Get the configured backend for a subsystem.

        Returns 'python' or 'rust'.
        """
        with self._lock:
            try:
                sub = MigrationSubsystem(subsystem)
            except ValueError:
                return "python"
            return self._states[sub].backend.value

    def get_state(self, subsystem: str) -> Optional[SubsystemState]:
        """Get the full state of a subsystem."""
        with self._lock:
            try:
                sub = MigrationSubsystem(subsystem)
            except ValueError:
                return None
            # Return a copy to prevent external mutation
            import copy
            return copy.copy(self._states[sub])

    def get_all_states(self) -> Dict[str, SubsystemState]:
        """Get states of all subsystems."""
        with self._lock:
            import copy
            return {s.value: copy.copy(self._states[s]) for s in MigrationSubsystem}

    @property
    def rust_as_default(self) -> bool:
        """Whether Rust is the default engine for new projects."""
        with self._lock:
            return self._rust_as_default

    def get_migration_summary(self) -> Dict[str, Any]:
        """Get a summary suitable for display in UI / settings dialog."""
        with self._lock:
            rust_avail = self._is_rust_available()
            return {
                "rust_available": rust_avail,
                "rust_as_default": self._rust_as_default,
                "subsystems": {
                    s.value: {
                        "backend": self._states[s].backend.value,
                        "status": self._states[s].status.value,
                        "error": self._states[s].error_message,
                        "switch_count": self._states[s].switch_count,
                        "python_avg_us": self._states[s].python_avg_render_us,
                        "rust_avg_us": self._states[s].rust_avg_render_us,
                    }
                    for s in MigrationSubsystem
                },
            }

    # --- Public API: Mutation ------------------------------------------------

    def set_subsystem(self, subsystem: str, backend: str) -> bool:
        """Switch a subsystem to a different backend.

        Args:
            subsystem: 'audio_playback', 'midi_dispatch', or 'plugin_hosting'
            backend: 'python' or 'rust'

        Returns:
            True if the switch was successful.
        """
        with self._lock:
            try:
                sub = MigrationSubsystem(subsystem)
                be = EngineBackend(backend)
            except ValueError as e:
                log.error("Invalid subsystem or backend: %s", e)
                return False

            state = self._states[sub]

            # Already on this backend?
            if state.backend == be:
                log.debug("Subsystem %s already on %s", subsystem, backend)
                return True

            # Switching to Rust requires the engine to be available
            if be == EngineBackend.RUST and not self._is_rust_available():
                msg = (
                    "Rust engine binary not found. "
                    "Build with: cd pydaw_engine && cargo build --release"
                )
                log.warning(msg)
                state.error_message = msg
                state.status = MigrationStatus.FAILED
                self._emit_error(subsystem, msg)
                return False

            # Dependency check: MIDI needs audio, plugins need MIDI
            if be == EngineBackend.RUST:
                if sub == MigrationSubsystem.MIDI_DISPATCH:
                    if self._states[MigrationSubsystem.AUDIO_PLAYBACK].backend != EngineBackend.RUST:
                        msg = "MIDI dispatch requires audio_playback to be on Rust first"
                        log.warning(msg)
                        state.error_message = msg
                        self._emit_error(subsystem, msg)
                        return False
                elif sub == MigrationSubsystem.PLUGIN_HOSTING:
                    if self._states[MigrationSubsystem.MIDI_DISPATCH].backend != EngineBackend.RUST:
                        msg = "Plugin hosting requires midi_dispatch to be on Rust first"
                        log.warning(msg)
                        state.error_message = msg
                        self._emit_error(subsystem, msg)
                        return False

            # Reverse dependency: switching back to Python cascades
            if be == EngineBackend.PYTHON:
                if sub == MigrationSubsystem.AUDIO_PLAYBACK:
                    # Must also switch MIDI and plugins back
                    self._force_subsystem(MigrationSubsystem.PLUGIN_HOSTING, EngineBackend.PYTHON)
                    self._force_subsystem(MigrationSubsystem.MIDI_DISPATCH, EngineBackend.PYTHON)
                elif sub == MigrationSubsystem.MIDI_DISPATCH:
                    self._force_subsystem(MigrationSubsystem.PLUGIN_HOSTING, EngineBackend.PYTHON)

            # Execute switch
            return self._do_switch(sub, be)

    def set_rust_as_default(self, enabled: bool):
        """Set whether Rust should be the default engine.

        Only takes effect if all three subsystems are stable on Rust.
        """
        with self._lock:
            if enabled:
                # All subsystems must be on Rust and active
                for sub in MigrationSubsystem:
                    st = self._states[sub]
                    if st.backend != EngineBackend.RUST or st.status != MigrationStatus.ACTIVE:
                        log.warning(
                            "Cannot set Rust as default: %s is %s/%s",
                            sub.value, st.backend.value, st.status.value,
                        )
                        return
            self._rust_as_default = enabled
            self._save_settings()
            if _QT_AVAILABLE:
                try:
                    self.rust_default_changed.emit(enabled)
                except Exception:
                    pass
            log.info("Rust as default: %s", enabled)

    def migrate_all_to_rust(self) -> bool:
        """Migrate all subsystems to Rust in the correct order.

        Returns True if all subsystems switched successfully.
        """
        order = [
            MigrationSubsystem.AUDIO_PLAYBACK,
            MigrationSubsystem.MIDI_DISPATCH,
            MigrationSubsystem.PLUGIN_HOSTING,
        ]
        for sub in order:
            if not self.set_subsystem(sub.value, EngineBackend.RUST.value):
                log.error("Migration stopped at %s", sub.value)
                return False
        return True

    def rollback_all_to_python(self) -> bool:
        """Roll back all subsystems to Python (safe fallback)."""
        order = [
            MigrationSubsystem.PLUGIN_HOSTING,
            MigrationSubsystem.MIDI_DISPATCH,
            MigrationSubsystem.AUDIO_PLAYBACK,
        ]
        success = True
        for sub in order:
            if not self.set_subsystem(sub.value, EngineBackend.PYTHON.value):
                log.error("Rollback failed at %s", sub.value)
                success = False
        return success

    # --- Hooks ---------------------------------------------------------------

    def register_pre_switch_hook(self, subsystem: str, callback: Callable):
        """Register a callback to be called before a subsystem switch.

        Callback signature: callback(subsystem: str, new_backend: str) -> None
        """
        with self._lock:
            try:
                sub = MigrationSubsystem(subsystem)
            except ValueError:
                return
            self._pre_switch_hooks[sub].append(callback)

    def register_post_switch_hook(self, subsystem: str, callback: Callable):
        """Register a callback after a successful subsystem switch.

        Callback signature: callback(subsystem: str, new_backend: str) -> None
        """
        with self._lock:
            try:
                sub = MigrationSubsystem(subsystem)
            except ValueError:
                return
            self._post_switch_hooks[sub].append(callback)

    def register_validator(self, subsystem: str, callback: Callable):
        """Register a validation callback for a subsystem.

        Called during switch-to-Rust to verify the engine is functional.
        Callback signature: callback() -> bool  (True = OK)
        """
        with self._lock:
            try:
                sub = MigrationSubsystem(subsystem)
            except ValueError:
                return
            self._validators[sub] = callback

    def update_performance_metrics(
        self,
        subsystem: str,
        python_avg_us: float = 0.0,
        rust_avg_us: float = 0.0,
    ):
        """Update performance metrics for a subsystem (called by benchmark)."""
        with self._lock:
            try:
                sub = MigrationSubsystem(subsystem)
            except ValueError:
                return
            if python_avg_us > 0:
                self._states[sub].python_avg_render_us = python_avg_us
            if rust_avg_us > 0:
                self._states[sub].rust_avg_render_us = rust_avg_us

    # --- Internal: Switch Execution ------------------------------------------

    def _do_switch(self, sub: MigrationSubsystem, new_be: EngineBackend) -> bool:
        """Execute the actual backend switch for a subsystem."""
        state = self._states[sub]
        old_be = state.backend

        log.info("Switching %s: %s → %s", sub.value, old_be.value, new_be.value)
        state.status = MigrationStatus.SWITCHING

        # Pre-switch hooks
        for hook in self._pre_switch_hooks[sub]:
            try:
                hook(sub.value, new_be.value)
            except Exception as e:
                log.error("Pre-switch hook error for %s: %s", sub.value, e)

        # Validate if switching to Rust
        if new_be == EngineBackend.RUST:
            validator = self._validators[sub]
            if validator is not None:
                try:
                    ok = validator()
                    if not ok:
                        msg = f"Validation failed for {sub.value} on Rust"
                        log.warning(msg)
                        state.backend = old_be
                        state.status = MigrationStatus.FAILED
                        state.error_message = msg
                        self._emit_error(sub.value, msg)
                        return False
                except Exception as e:
                    msg = f"Validation error for {sub.value}: {e}"
                    log.error(msg)
                    state.backend = old_be
                    state.status = MigrationStatus.FAILED
                    state.error_message = msg
                    self._emit_error(sub.value, msg)
                    return False

        # Apply
        state.backend = new_be
        state.status = MigrationStatus.ACTIVE
        state.error_message = ""
        state.last_switch_time = time.monotonic()
        state.switch_count += 1

        # Post-switch hooks
        for hook in self._post_switch_hooks[sub]:
            try:
                hook(sub.value, new_be.value)
            except Exception as e:
                log.error("Post-switch hook error for %s: %s", sub.value, e)

        # Save and emit
        self._save_settings()
        self._emit_changed(sub.value, new_be.value, "active")

        log.info("Switched %s to %s (count: %d)", sub.value, new_be.value, state.switch_count)
        return True

    def _force_subsystem(self, sub: MigrationSubsystem, be: EngineBackend):
        """Force a subsystem to a backend without dependency checks (cascade)."""
        state = self._states[sub]
        if state.backend == be:
            return
        old = state.backend
        state.backend = be
        state.status = MigrationStatus.ACTIVE
        state.error_message = ""
        state.last_switch_time = time.monotonic()
        state.switch_count += 1
        self._emit_changed(sub.value, be.value, "active")
        log.info("Force-switched %s: %s → %s (cascade)", sub.value, old.value, be.value)

    # --- Internal: Rust availability -----------------------------------------

    @staticmethod
    def _is_rust_available() -> bool:
        """Check if the Rust engine binary is available."""
        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            return RustEngineBridge.is_available()
        except Exception:
            return False

    # --- Internal: Settings persistence --------------------------------------

    def _load_settings(self):
        """Load migration state from QSettings."""
        if not _QT_AVAILABLE:
            return
        try:
            s = QSettings()
            audio_be = s.value(_KEY_AUDIO, "python")
            midi_be = s.value(_KEY_MIDI, "python")
            plugin_be = s.value(_KEY_PLUGIN, "python")
            rust_default = s.value(_KEY_RUST_DEFAULT, False)
            if isinstance(rust_default, str):
                rust_default = rust_default.lower() in ("true", "1", "yes")

            # Only load Rust if the binary is actually available
            if self._is_rust_available():
                try:
                    self._states[MigrationSubsystem.AUDIO_PLAYBACK].backend = EngineBackend(audio_be)
                except ValueError:
                    pass
                try:
                    self._states[MigrationSubsystem.MIDI_DISPATCH].backend = EngineBackend(midi_be)
                except ValueError:
                    pass
                try:
                    self._states[MigrationSubsystem.PLUGIN_HOSTING].backend = EngineBackend(plugin_be)
                except ValueError:
                    pass
                self._rust_as_default = bool(rust_default)
            else:
                # Rust not available — force everything to Python
                for sub in MigrationSubsystem:
                    self._states[sub].backend = EngineBackend.PYTHON
                self._rust_as_default = False
        except Exception as e:
            log.debug("Could not load migration settings: %s", e)

    def _save_settings(self):
        """Save migration state to QSettings."""
        if not _QT_AVAILABLE:
            return
        try:
            s = QSettings()
            s.setValue(_KEY_AUDIO, self._states[MigrationSubsystem.AUDIO_PLAYBACK].backend.value)
            s.setValue(_KEY_MIDI, self._states[MigrationSubsystem.MIDI_DISPATCH].backend.value)
            s.setValue(_KEY_PLUGIN, self._states[MigrationSubsystem.PLUGIN_HOSTING].backend.value)
            s.setValue(_KEY_RUST_DEFAULT, self._rust_as_default)
        except Exception as e:
            log.debug("Could not save migration settings: %s", e)

    # --- Internal: Signal emission -------------------------------------------

    def _emit_changed(self, subsystem: str, backend: str, status: str):
        """Emit subsystem_changed signal."""
        if _QT_AVAILABLE:
            try:
                self.subsystem_changed.emit(subsystem, backend, status)
            except Exception:
                pass

    def _emit_error(self, subsystem: str, message: str):
        """Emit migration_error signal."""
        if _QT_AVAILABLE:
            try:
                self.migration_error.emit(subsystem, message)
            except Exception:
                pass
