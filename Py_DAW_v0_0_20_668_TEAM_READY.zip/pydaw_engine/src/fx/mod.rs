// ==========================================================================
// FX Module — Built-in audio effects for the Rust engine
// ==========================================================================
// v0.0.20.667 — Phase R2
//
// All effects process AudioBuffer in-place. Zero allocations in process().
// ==========================================================================

pub mod parametric_eq;
pub mod compressor;
pub mod limiter;
pub mod reverb;
pub mod delay;

#[allow(unused_imports)]
pub use parametric_eq::{ParametricEq, EqBandParams};
#[allow(unused_imports)]
pub use compressor::{Compressor, CompressorParams};
#[allow(unused_imports)]
pub use limiter::Limiter;
#[allow(unused_imports)]
pub use reverb::Reverb;
#[allow(unused_imports)]
pub use delay::Delay;
