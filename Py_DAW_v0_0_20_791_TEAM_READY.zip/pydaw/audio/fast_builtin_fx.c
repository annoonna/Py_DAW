/*
 * Py_DAW — Fast Built-in FX (C Extension)
 * v0.0.20.788
 *
 * Schroeder Reverb (4 Comb + 4 Allpass) and Stereo Delay.
 * Called via ctypes from Python. Zero-allocation in process loops.
 *
 * Build: gcc -O3 -march=native -ffast-math -shared -fPIC -o fast_builtin_fx.so fast_builtin_fx.c -lm
 */

#include <math.h>
#include <string.h>

/* ═══════════════════════════════════════════════════════════
 *  Schroeder Reverb (4 Comb + 4 Allpass, Stereo)
 * ═══════════════════════════════════════════════════════════ */

/*
 * reverb_process: In-place stereo Schroeder reverb.
 *
 * buf:          interleaved stereo buffer [frames * 2] (float64, in-place)
 * frames:       number of sample frames
 * feedback:     comb feedback amount (0..1)
 * damping:      comb LP damping (0..1)
 * mix:          dry/wet mix (0..1)
 * pd_samps:     pre-delay in samples
 *
 * Comb state arrays (4 combs, L+R):
 * comb_bufs_l/r:  4 delay buffers concatenated [comb_lens[0] + comb_lens[1] + ...]
 * comb_offsets:   start offset of each comb in the concatenated buffer [4]
 * comb_lens:      length of each comb delay line [4]
 * comb_pos:       current write position for each comb [4] (read/write)
 * comb_filt_l/r:  LP filter state per comb [4] (read/write)
 *
 * Allpass state arrays (4 allpasses, L+R):
 * ap_bufs_l/r:    4 delay buffers concatenated
 * ap_offsets:     start offset of each allpass [4]
 * ap_lens:        length of each allpass [4]
 * ap_pos:         current write position [4] (read/write)
 *
 * Pre-delay:
 * pd_buf_l/r:     pre-delay buffer [pd_max]
 * pd_max:         pre-delay buffer length
 * pd_pos:         current position (int*, read/write)
 */
void reverb_process(double *buf, int frames,
                    double feedback, double damping, double mix, int pd_samps,
                    /* comb state */
                    double *comb_bufs_l, double *comb_bufs_r,
                    const int *comb_offsets, const int *comb_lens,
                    int *comb_pos, double *comb_filt_l, double *comb_filt_r,
                    /* allpass state */
                    double *ap_bufs_l, double *ap_bufs_r,
                    const int *ap_offsets, const int *ap_lens, int *ap_pos,
                    /* pre-delay */
                    double *pd_buf_l, double *pd_buf_r,
                    int pd_max, int *pd_pos_ptr)
{
    int pdp = *pd_pos_ptr;
    double one_minus_damp = 1.0 - damping;

    for (int n = 0; n < frames; n++) {
        double dry_l = buf[n * 2];
        double dry_r = buf[n * 2 + 1];

        /* Pre-delay */
        pd_buf_l[pdp] = dry_l;
        pd_buf_r[pdp] = dry_r;
        int rd = (pdp - pd_samps + pd_max) % pd_max;
        double inp_l = pd_buf_l[rd];
        double inp_r = pd_buf_r[rd];
        pdp = (pdp + 1) % pd_max;

        /* 4 Comb filters (parallel) */
        double wet_l = 0.0, wet_r = 0.0;
        for (int i = 0; i < 4; i++) {
            int off = comb_offsets[i];
            int L   = comb_lens[i];
            int pos = comb_pos[i];

            double out_l = comb_bufs_l[off + pos];
            double out_r = comb_bufs_r[off + pos];

            /* LP damping */
            comb_filt_l[i] = out_l * one_minus_damp + comb_filt_l[i] * damping;
            comb_filt_r[i] = out_r * one_minus_damp + comb_filt_r[i] * damping;

            /* Write back with feedback */
            comb_bufs_l[off + pos] = inp_l + comb_filt_l[i] * feedback;
            comb_bufs_r[off + pos] = inp_r + comb_filt_r[i] * feedback;

            comb_pos[i] = (pos + 1) % L;
            wet_l += out_l;
            wet_r += out_r;
        }
        wet_l *= 0.25;
        wet_r *= 0.25;

        /* 4 Allpass filters (series) */
        for (int i = 0; i < 4; i++) {
            int off = ap_offsets[i];
            int L   = ap_lens[i];
            int pos = ap_pos[i];

            double bl = ap_bufs_l[off + pos];
            double br = ap_bufs_r[off + pos];
            ap_bufs_l[off + pos] = wet_l + bl * 0.5;
            ap_bufs_r[off + pos] = wet_r + br * 0.5;
            wet_l = bl - wet_l * 0.5;
            wet_r = br - wet_r * 0.5;
            ap_pos[i] = (pos + 1) % L;
        }

        /* Mix */
        double one_minus_mix = 1.0 - mix;
        buf[n * 2]     = dry_l * one_minus_mix + wet_l * mix;
        buf[n * 2 + 1] = dry_r * one_minus_mix + wet_r * mix;
    }

    *pd_pos_ptr = pdp;
}


/* ═══════════════════════════════════════════════════════════
 *  LUT Interpolation Helper (shared by Chorus/Phaser/Flanger)
 * ═══════════════════════════════════════════════════════════ */

static inline double lut_interp(const double *lut, int lut_size, double phase)
{
    double pos = phase * lut_size;
    int idx = (int)pos;
    if (idx < 0) idx = 0;
    if (idx >= lut_size - 1) return lut[lut_size - 1];
    double frac = pos - idx;
    return lut[idx] * (1.0 - frac) + lut[idx + 1] * frac;
}


/* ═══════════════════════════════════════════════════════════
 *  Chorus (multi-voice modulated delay)
 * ═══════════════════════════════════════════════════════════ */

void chorus_process(double *buf, int frames,
                    double depth_samps, double phase_inc, double mix,
                    int voices,
                    const double *mod_lut, int lut_size,
                    double *delay_buf_l, double *delay_buf_r,
                    int max_delay, int *pos_ptr, double *phase_ptr)
{
    int p = *pos_ptr;
    double ph = *phase_ptr;
    double one_minus_mix = 1.0 - mix;
    double inv_voices = 1.0 / (double)voices;

    for (int n = 0; n < frames; n++) {
        double dry_l = buf[n * 2];
        double dry_r = buf[n * 2 + 1];

        delay_buf_l[p] = dry_l;
        delay_buf_r[p] = dry_r;

        double wet_l = 0.0, wet_r = 0.0;
        for (int v = 0; v < voices; v++) {
            double vph = fmod(ph + (double)v / (double)voices, 1.0);
            double mod = lut_interp(mod_lut, lut_size, vph);
            double delay = (1.0 + mod) * 0.5 * depth_samps;
            if (delay < 1.0) delay = 1.0;
            if (delay > max_delay - 2) delay = max_delay - 2;
            int rd = (p - (int)delay + max_delay) % max_delay;
            wet_l += delay_buf_l[rd];
            wet_r += delay_buf_r[rd];
        }
        wet_l *= inv_voices;
        wet_r *= inv_voices;

        ph = fmod(ph + phase_inc, 1.0);
        p = (p + 1) % max_delay;

        buf[n * 2]     = dry_l * one_minus_mix + wet_l * mix;
        buf[n * 2 + 1] = dry_r * one_minus_mix + wet_r * mix;
    }
    *pos_ptr = p;
    *phase_ptr = ph;
}


/* ═══════════════════════════════════════════════════════════
 *  Phaser (N-stage allpass cascade with sweep)
 * ═══════════════════════════════════════════════════════════ */

void phaser_process(double *buf, int frames,
                    double depth, double feedback, double mix,
                    double phase_inc, int num_stages,
                    const double *mod_lut, int lut_size,
                    double *ap_l, double *ap_r,
                    double *fb_l_ptr, double *fb_r_ptr,
                    double *phase_ptr)
{
    double ph = *phase_ptr;
    double fb_l = *fb_l_ptr;
    double fb_r = *fb_r_ptr;
    double one_minus_mix = 1.0 - mix;

    for (int n = 0; n < frames; n++) {
        double mod = lut_interp(mod_lut, lut_size, ph);
        double coeff = 0.1 + depth * 0.8 * (mod + 1.0) * 0.5;
        if (coeff < 0.01) coeff = 0.01;
        if (coeff > 0.99) coeff = 0.99;

        double in_l = buf[n * 2]     + fb_l * feedback;
        double in_r = buf[n * 2 + 1] + fb_r * feedback;

        double out_l = in_l, out_r = in_r;
        for (int s = 0; s < num_stages; s++) {
            double new_l = -coeff * out_l + ap_l[s];
            ap_l[s] = coeff * new_l + out_l;
            out_l = new_l;

            double new_r = -coeff * out_r + ap_r[s];
            ap_r[s] = coeff * new_r + out_r;
            out_r = new_r;
        }

        fb_l = out_l;
        fb_r = out_r;
        ph = fmod(ph + phase_inc, 1.0);

        buf[n * 2]     = buf[n * 2]     * one_minus_mix + out_l * mix;
        buf[n * 2 + 1] = buf[n * 2 + 1] * one_minus_mix + out_r * mix;
    }
    *fb_l_ptr = fb_l;
    *fb_r_ptr = fb_r;
    *phase_ptr = ph;
}


/* ═══════════════════════════════════════════════════════════
 *  Flanger (modulated comb with feedback)
 * ═══════════════════════════════════════════════════════════ */

void flanger_process(double *buf, int frames,
                     double depth_samps, double feedback, double mix,
                     double phase_inc,
                     const double *mod_lut, int lut_size,
                     double *delay_buf_l, double *delay_buf_r,
                     int max_delay, int *pos_ptr, double *phase_ptr)
{
    int p = *pos_ptr;
    double ph = *phase_ptr;
    double one_minus_mix = 1.0 - mix;

    for (int n = 0; n < frames; n++) {
        double mod = lut_interp(mod_lut, lut_size, ph);
        double delay = (1.0 + mod) * 0.5 * depth_samps;
        if (delay < 1.0) delay = 1.0;
        if (delay > max_delay - 2) delay = max_delay - 2;

        int rd = (p - (int)delay + max_delay) % max_delay;
        double del_l = delay_buf_l[rd];
        double del_r = delay_buf_r[rd];

        double in_l = buf[n * 2]     + del_l * feedback;
        double in_r = buf[n * 2 + 1] + del_r * feedback;

        delay_buf_l[p] = in_l;
        delay_buf_r[p] = in_r;
        p = (p + 1) % max_delay;

        ph = fmod(ph + phase_inc, 1.0);

        buf[n * 2]     = buf[n * 2]     * one_minus_mix + del_l * mix;
        buf[n * 2 + 1] = buf[n * 2 + 1] * one_minus_mix + del_r * mix;
    }
    *pos_ptr = p;
    *phase_ptr = ph;
}

/*
 * delay_process: In-place stereo delay.
 *
 * buf:          interleaved stereo [frames * 2]
 * frames:       number of sample frames
 * delay_samps:  delay in samples
 * feedback:     0..0.95
 * mix:          0..1
 * ping_pong:    0 or 1
 * lp_alpha:     LP filter coefficient
 * delay_buf_l/r: delay line buffer [max_samps]
 * max_samps:    buffer length
 * pos:          current position (int*, read/write)
 * lp_l/r:       LP filter state (double*, read/write)
 */
void delay_process(double *buf, int frames,
                   int delay_samps, double feedback, double mix,
                   int ping_pong, double lp_alpha,
                   double *delay_buf_l, double *delay_buf_r,
                   int max_samps, int *pos_ptr,
                   double *lp_l_ptr, double *lp_r_ptr)
{
    int p = *pos_ptr;
    double lp_l = *lp_l_ptr;
    double lp_r = *lp_r_ptr;
    double one_minus_mix = 1.0 - mix;

    for (int n = 0; n < frames; n++) {
        double dry_l = buf[n * 2];
        double dry_r = buf[n * 2 + 1];

        /* Read from delay line */
        int rd = (p - delay_samps + max_samps) % max_samps;
        double del_l = delay_buf_l[rd];
        double del_r = delay_buf_r[rd];

        /* LP filter on feedback */
        lp_l += lp_alpha * (del_l - lp_l);
        lp_r += lp_alpha * (del_r - lp_r);

        /* Write to delay line */
        if (ping_pong) {
            delay_buf_l[p] = dry_l + lp_r * feedback;
            delay_buf_r[p] = dry_r + lp_l * feedback;
        } else {
            delay_buf_l[p] = dry_l + lp_l * feedback;
            delay_buf_r[p] = dry_r + lp_r * feedback;
        }

        p = (p + 1) % max_samps;

        buf[n * 2]     = dry_l * one_minus_mix + del_l * mix;
        buf[n * 2 + 1] = dry_r * one_minus_mix + del_r * mix;
    }

    *pos_ptr = p;
    *lp_l_ptr = lp_l;
    *lp_r_ptr = lp_r;
}


/* ═══════════════════════════════════════════════════════════
 *  Gate (Noise Gate with Hold)
 * ═══════════════════════════════════════════════════════════ */

void gate_process(double *buf, int frames,
                  double threshold_lin, double range_lin, double mix,
                  double attack_coeff, double release_coeff, int hold_samps,
                  double *env_ptr, double *gate_gain_ptr, int *hold_counter_ptr)
{
    double env = *env_ptr;
    double gate_gain = *gate_gain_ptr;
    int hold_counter = *hold_counter_ptr;
    double one_minus_mix = 1.0 - mix;

    for (int n = 0; n < frames; n++) {
        double in_l = buf[n * 2];
        double in_r = buf[n * 2 + 1];

        /* Peak detection */
        double level = fabs(in_l);
        double ar = fabs(in_r);
        if (ar > level) level = ar;

        /* Envelope follower */
        if (level > env) {
            env = level;
        } else {
            env = release_coeff * env + (1.0 - release_coeff) * level;
        }

        /* Gate logic */
        double target;
        if (env >= threshold_lin) {
            hold_counter = hold_samps;
            target = 1.0;
        } else if (hold_counter > 0) {
            hold_counter--;
            target = 1.0;
        } else {
            target = range_lin;
        }

        /* Smooth gain transitions */
        if (target > gate_gain) {
            gate_gain = (1.0 - attack_coeff) * target + attack_coeff * gate_gain;
        } else {
            gate_gain = (1.0 - release_coeff) * target + release_coeff * gate_gain;
        }

        /* Apply */
        buf[n * 2]     = in_l * one_minus_mix + in_l * gate_gain * mix;
        buf[n * 2 + 1] = in_r * one_minus_mix + in_r * gate_gain * mix;
    }

    *env_ptr = env;
    *gate_gain_ptr = gate_gain;
    *hold_counter_ptr = hold_counter;
}


/* ═══════════════════════════════════════════════════════════
 *  DeEsser (frequency-selective dynamics)
 * ═══════════════════════════════════════════════════════════ */

void deesser_process(double *buf, int frames,
                     double threshold_lin, double max_reduction,
                     double attack_coeff, double release_coeff,
                     double range_db,
                     /* biquad coefficients (bandpass detection) */
                     double b0, double b1, double b2, double a1, double a2,
                     /* biquad state L+R */
                     double *z1_l_ptr, double *z2_l_ptr,
                     double *z1_r_ptr, double *z2_r_ptr,
                     double *env_ptr)
{
    double z1_l = *z1_l_ptr, z2_l = *z2_l_ptr;
    double z1_r = *z1_r_ptr, z2_r = *z2_r_ptr;
    double env = *env_ptr;

    for (int n = 0; n < frames; n++) {
        double in_l = buf[n * 2];
        double in_r = buf[n * 2 + 1];

        /* Biquad bandpass L (DF2T) */
        double bp_l = b0 * in_l + z1_l;
        z1_l = b1 * in_l - a1 * bp_l + z2_l;
        z2_l = b2 * in_l - a2 * bp_l;

        /* Biquad bandpass R (DF2T) */
        double bp_r = b0 * in_r + z1_r;
        z1_r = b1 * in_r - a1 * bp_r + z2_r;
        z2_r = b2 * in_r - a2 * bp_r;

        /* Envelope follower */
        double det = fabs(bp_l);
        double det_r = fabs(bp_r);
        if (det_r > det) det = det_r;

        if (det > env) {
            env = (1.0 - attack_coeff) * det + attack_coeff * env;
        } else {
            env = (1.0 - release_coeff) * det + release_coeff * env;
        }

        /* Gain reduction */
        double gain = 1.0;
        if (env > threshold_lin && threshold_lin > 1e-12) {
            double over_db = 20.0 * log10(env / threshold_lin);
            double reduce_db = over_db < range_db ? over_db : range_db;
            gain = pow(10.0, -reduce_db / 20.0);
        }

        buf[n * 2]     = in_l * gain;
        buf[n * 2 + 1] = in_r * gain;
    }

    *z1_l_ptr = z1_l; *z2_l_ptr = z2_l;
    *z1_r_ptr = z1_r; *z2_r_ptr = z2_r;
    *env_ptr = env;
}
