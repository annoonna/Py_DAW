"""
Time-stretch utilities (pitch-preserving) for PyDAW.

Design goals:
- Robust: never crash playback if stretching fails.
- Optional Essentia integration (if available).
- Pure-numpy fallback (phase vocoder) so the DAW still works without Essentia.

Convention:
- `rate` is a *play-rate* multiplier:
    rate > 1.0  -> faster / shorter
    rate < 1.0  -> slower / longer
So the stretched output length is approximately len(input) / rate.
"""

from __future__ import annotations

from typing import Optional

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None


def _clamp_rate(rate: float) -> float:
    try:
        r = float(rate)
    except Exception:
        r = 1.0
    if not (0.01 < r < 100.0):
        return 1.0
    return r


def _pv_time_stretch_mono(x, rate: float, n_fft: int = 2048, hop: int = 512):
    """
    Simple phase-vocoder time-stretch (mono), pitch-preserving.

    This is a pragmatic implementation meant for preview/arranger sync.
    Quality is acceptable for loops; can be replaced by higher-quality engines later.
    """
    if np is None:
        return x
    x = np.asarray(x, dtype=np.float32)
    if x.ndim != 1 or x.size < 8:
        return x

    rate = _clamp_rate(rate)
    if abs(rate - 1.0) < 1e-3:
        return x

    n_fft = int(n_fft)
    hop = int(hop)
    n_fft = max(256, n_fft)
    hop = max(64, min(hop, n_fft // 2))

    # Pad so we can frame safely
    pad = n_fft
    x_pad = np.pad(x, (pad, pad), mode="constant")
    win = np.hanning(n_fft).astype(np.float32)

    # Frame count
    n_frames = 1 + (len(x_pad) - n_fft) // hop
    if n_frames <= 2:
        return x

    # STFT
    frames = np.lib.stride_tricks.as_strided(
        x_pad,
        shape=(n_frames, n_fft),
        strides=(x_pad.strides[0] * hop, x_pad.strides[0]),
        writeable=False,
    )
    frames_win = frames * win[None, :]
    spec = np.fft.rfft(frames_win, axis=1).astype(np.complex64)  # (frames, bins)
    spec = spec.T  # (bins, frames)

    # Time steps in analysis frames
    time_steps = np.arange(0, spec.shape[1], rate, dtype=np.float32)
    n_out_frames = int(len(time_steps))
    if n_out_frames <= 1:
        return x

    # Expected phase advance per bin
    omega = (2.0 * np.pi * np.arange(spec.shape[0], dtype=np.float32) * hop) / float(n_fft)

    phase_acc = np.angle(spec[:, 0]).astype(np.float32)
    last_phase = phase_acc.copy()

    out_spec = np.empty((spec.shape[0], n_out_frames), dtype=np.complex64)

    for t, step in enumerate(time_steps):
        i = int(step)
        if i >= spec.shape[1] - 1:
            i = spec.shape[1] - 2
        frac = float(step - i)

        s0 = spec[:, i]
        s1 = spec[:, i + 1]

        # Linear interp magnitudes
        mag = (1.0 - frac) * np.abs(s0) + frac * np.abs(s1)

        phase = np.angle(s0).astype(np.float32)
        delta = phase - last_phase - omega
        delta -= 2.0 * np.pi * np.round(delta / (2.0 * np.pi)).astype(np.float32)

        phase_acc += omega + delta
        last_phase = phase

        out_spec[:, t] = mag.astype(np.float32) * np.exp(1.0j * phase_acc.astype(np.float32))

    # ISTFT (overlap-add)
    out_frames = np.fft.irfft(out_spec.T, n=n_fft, axis=1).astype(np.float32)
    out_len = n_out_frames * hop + n_fft
    y = np.zeros(out_len, dtype=np.float32)
    win_sum = np.zeros(out_len, dtype=np.float32)

    for i in range(n_out_frames):
        start = i * hop
        y[start:start + n_fft] += out_frames[i] * win
        win_sum[start:start + n_fft] += win * win

    # Normalize windowing
    nz = win_sum > 1e-8
    y[nz] /= win_sum[nz]

    # Remove initial padding
    y = y[pad:-pad]

    # Ensure approximate target length
    target_len = max(1, int(round(len(x) / rate)))
    if len(y) > target_len + hop:
        y = y[:target_len]
    elif len(y) < target_len:
        y = np.pad(y, (0, target_len - len(y)), mode="constant")

    return y.astype(np.float32, copy=False)


def _try_essentia_stretch_mono(x, rate: float) -> Optional["np.ndarray"]:
    """Best-effort Essentia stretch (mono). Returns None if unavailable."""
    if np is None:
        return None
    try:
        import essentia.standard as es  # type: ignore
    except Exception:
        return None

    x = np.asarray(x, dtype=np.float32).reshape(-1)

    # Try a few algorithm names/signatures defensively.
    # We keep this very safe: any failure => None => fallback to numpy PV.
    for ctor_name in ("TimeStretch", "FStretch"):
        try:
            ctor = getattr(es, ctor_name, None)
            if ctor is None:
                continue
            try:
                alg = ctor(rate=float(rate))
                y = alg(x)
                if y is not None and len(y) > 8:
                    return np.asarray(y, dtype=np.float32)
            except TypeError:
                # Some builds may require different args; skip.
                continue
        except Exception:
            continue
    return None


def time_stretch_mono(x, rate: float, *, prefer_essentia: bool = True):
    """Public mono stretch helper."""
    if np is None:
        return x
    rate = _clamp_rate(rate)
    if abs(rate - 1.0) < 1e-3:
        return np.asarray(x, dtype=np.float32)

    if prefer_essentia:
        y = _try_essentia_stretch_mono(x, rate)
        if y is not None:
            return y

    return _pv_time_stretch_mono(x, rate)


def time_stretch_stereo(data, rate: float, sr: int, *, prefer_essentia: bool = True):
    """
    Pitch-preserving time-stretch for stereo float32 arrays.

    `data`: shape (n, 2) or (n,1). Returns shape (m,2).
    """
    if np is None:
        return data
    rate = _clamp_rate(rate)
    d = np.asarray(data, dtype=np.float32)
    if d.ndim != 2:
        d = np.atleast_2d(d).astype(np.float32)
    if d.shape[1] == 1:
        d = np.repeat(d, 2, axis=1)
    elif d.shape[1] > 2:
        d = d[:, :2]

    if d.shape[0] < 8 or abs(rate - 1.0) < 1e-3:
        return d.astype(np.float32, copy=False)

    l = time_stretch_mono(d[:, 0], rate, prefer_essentia=prefer_essentia)
    r = time_stretch_mono(d[:, 1], rate, prefer_essentia=prefer_essentia)

    n = min(len(l), len(r))
    out = np.stack([l[:n], r[:n]], axis=1).astype(np.float32, copy=False)
    return out
