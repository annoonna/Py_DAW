"""Clip Launcher (v0.0.11).

v0.0.10:
- Quantized launch via LauncherService

v0.0.11:
- Quantize also applies to Slot DnD ("arm + launch"):
  drop a clip onto a slot -> assign + (quantized) launch
- Stop All optional playhead reset (checkbox)
"""

from __future__ import annotations

from dataclasses import dataclass
import os

try:
    import numpy as np  # type: ignore
except Exception:  # pragma: no cover
    np = None  # type: ignore

try:
    import soundfile as sf  # type: ignore
except Exception:  # pragma: no cover
    sf = None  # type: ignore

from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QSpinBox,
    QScrollArea,
    QGridLayout,
    QPushButton,
    QMenu,
    QComboBox,
    QToolButton,
    QCheckBox,
    QStyle,
    QStyleOptionButton,
)
from PyQt6.QtCore import Qt, pyqtSignal, QPoint, QRectF
from PyQt6.QtGui import QDrag, QPainter, QPen
from PyQt6.QtCore import QMimeData

from pydaw.services.project_service import ProjectService
from pydaw.services.launcher_service import LauncherService


@dataclass
class _PeaksData:
    mtime_ns: int
    block_size: int
    samplerate: int
    peaks: 'np.ndarray'  # type: ignore

    @property
    def peaks_per_second(self) -> float:
        return float(self.samplerate) / float(max(1, self.block_size))

class SlotButton(QPushButton):
    """A slot button that supports drop + (Alt) drag + double-click for loop editor."""

    double_clicked = pyqtSignal()  # NEU: Doppelklick Signal

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self._drag_start: QPoint | None = None

    def mouseDoubleClickEvent(self, event):  # noqa: ANN001
        """Handle Doppelklick -> Loop-Editor öffnen."""
        if event.button() == Qt.MouseButton.LeftButton:
            self.double_clicked.emit()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def dragEnterEvent(self, event):  # noqa: ANN001
        # IMPORTANT: Never let exceptions escape from Qt virtual overrides.
        # PyQt6 + SIP can turn this into a Qt fatal (SIGABRT).
        try:
            if event.mimeData().hasFormat("application/x-pydaw-clipid"):
                event.acceptProposedAction()
                return
        except Exception:
            pass
        try:
            super().dragEnterEvent(event)
        except Exception:
            pass

    def dropEvent(self, event):  # noqa: ANN001
        # IMPORTANT: Never let exceptions escape from Qt virtual overrides.
        # PyQt6 + SIP can turn this into a Qt fatal (SIGABRT).
        try:
            if event.mimeData().hasFormat("application/x-pydaw-clipid"):
                try:
                    self.parent().slot_drop_requested.emit(self, event)  # type: ignore[attr-defined]
                    event.acceptProposedAction()
                except Exception:
                    try:
                        event.ignore()
                    except Exception:
                        pass
                return
        except Exception:
            try:
                event.ignore()
            except Exception:
                pass
            return
        try:
            super().dropEvent(event)
        except Exception:
            pass

    def mousePressEvent(self, event):  # noqa: ANN001
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_start = event.pos()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):  # noqa: ANN001
        if (
            self._drag_start is not None
            and (event.buttons() & Qt.MouseButton.LeftButton)
            and (event.modifiers() & Qt.KeyboardModifier.AltModifier)
        ):
            if (event.pos() - self._drag_start).manhattanLength() >= 8:
                clip_id = str(self.property("clip_id") or "")
                if clip_id:
                    drag = QDrag(self)
                    md = QMimeData()
                    md.setData("application/x-pydaw-clipid", clip_id.encode("utf-8"))
                    drag.setMimeData(md)
                    drag.exec(Qt.DropAction.CopyAction)
                self._drag_start = None
                return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):  # noqa: ANN001
        self._drag_start = None
        super().mouseReleaseEvent(event)


class SlotWaveButton(SlotButton):
    """Slot button with in-slot audio waveform preview (Arranger-like)."""

    def __init__(self, panel: 'ClipLauncherPanel', parent: QWidget | None = None):
        super().__init__(parent or panel)
        self._panel = panel



    def mouseDoubleClickEvent(self, event):  # noqa: ANN001
        # Dedicated editor open on double click (Pro-DAW-like).
        if event.button() == Qt.MouseButton.LeftButton:
            cid = str(self.property("clip_id") or "")
            if cid:
                try:
                    self._panel.clip_edit_requested.emit(cid)
                except Exception:
                    pass
                event.accept()
                return
        super().mouseDoubleClickEvent(event)
    def paintEvent(self, event):  # noqa: ANN001
        # Draw normal button chrome but render our own contents (text + waveform).
        opt = QStyleOptionButton()
        self.initStyleOption(opt)
        opt.text = ''

        p = QPainter(self)
        try:
            self.style().drawControl(QStyle.ControlElement.CE_PushButton, opt, p, self)
            content = self.style().subElementRect(QStyle.SubElement.SE_PushButtonContents, opt, self)

            cid = str(self.property('clip_id') or '')
            if not cid:
                p.setPen(self.palette().mid().color())
                p.drawText(content, Qt.AlignmentFlag.AlignCenter, 'Empty')
                return

            clip = self._panel._get_clip(cid)
            if clip is None:
                p.setPen(self.palette().mid().color())
                p.drawText(content, Qt.AlignmentFlag.AlignCenter, 'Missing')
                return

            label = str(getattr(clip, 'label', '') or 'Clip')

            # Layout: small label row + waveform area
            label_rect = QRectF(content.left() + 4, content.top() + 2, content.width() - 8, 12)
            wave_rect = QRectF(content.left() + 4, content.top() + 16, content.width() - 8, content.height() - 20)

            # Waveform (audio only)
            if float(wave_rect.height()) >= 8.0 and str(getattr(clip, 'kind', '')) == 'audio' and getattr(clip, 'source_path', None):
                track_vol = self._panel._get_track_volume(str(getattr(clip, 'track_id', '') or ''))
                p.save()
                p.setClipRect(wave_rect)
                self._panel._draw_audio_waveform(p, wave_rect, clip, track_vol)
                p.restore()

            # Label on top
            p.setPen(self.palette().text().color())
            p.drawText(label_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, label)
        finally:
            p.end()

class ClipLauncherPanel(QWidget):
    clip_activated = pyqtSignal(str)  # clip_id
    clip_edit_requested = pyqtSignal(str)  # clip_id (double click)
    slot_drop_requested = pyqtSignal(object, object)  # (SlotButton, QDropEvent)

    def __init__(
        self,
        project: ProjectService,
        launcher: LauncherService,
        clip_context: 'ClipContextService | None' = None,
        parent=None
    ):
        super().__init__(parent)
        self.project = project
        self.launcher = launcher
        self.clip_context = clip_context  # NEU: ClipContextService
        self.scene_count = 8

        # Allow the right dock group (Browser/Clip Launcher) to be shrunk
        # "almost closed" without being blocked by minimum-size hints.
        try:
            from PyQt6.QtWidgets import QSizePolicy
            self.setMinimumSize(0, 0)
            self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        except Exception:
            pass

        # waveform cache (shared across slot widgets)
        self._peaks_cache: dict[str, _PeaksData] = {}
        self._peaks_pending: set[str] = set()
        self._clip_index: dict[str, object] = {}
        self._track_index: dict[str, object] = {}

        self._build_ui()
        self._wire()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        header = QHBoxLayout()
        header.addWidget(QLabel("Clip Launcher (Scenes)"))

        header.addWidget(QLabel("Scenes:"))
        self.spin_scenes = QSpinBox()
        self.spin_scenes.setRange(1, 64)
        self.spin_scenes.setValue(self.scene_count)
        header.addWidget(self.spin_scenes)

        header.addSpacing(12)
        header.addWidget(QLabel("Quantize:"))
        self.cmb_quant = QComboBox()
        self.cmb_quant.addItems(["Off", "1 Beat", "1 Bar"])
        header.addWidget(self.cmb_quant)

        header.addSpacing(6)
        header.addWidget(QLabel("Mode:"))
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["Trigger", "Toggle", "Gate"])
        header.addWidget(self.cmb_mode)

        header.addSpacing(12)
        self.chk_reset = QCheckBox("Reset Playhead")
        self.chk_reset.setToolTip("Beim Stop All wird der Playhead auf 0 gesetzt.")
        header.addWidget(self.chk_reset)

        self.btn_stop_all = QPushButton("Stop All")
        header.addWidget(self.btn_stop_all)

        header.addStretch(1)

        self.lbl_sel = QLabel("Ausgewählter Clip: —")
        header.addWidget(self.lbl_sel)

        layout.addLayout(header)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        try:
            from PyQt6.QtWidgets import QSizePolicy
            self.scroll.setMinimumSize(0, 0)
            self.scroll.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Expanding)
        except Exception:
            pass
        layout.addWidget(self.scroll, 1)

        self.inner = QWidget()
        self.grid = QGridLayout(self.inner)
        self.grid.setContentsMargins(6, 6, 6, 6)
        self.grid.setHorizontalSpacing(6)
        self.grid.setVerticalSpacing(6)

        self.scroll.setWidget(self.inner)

    def _wire(self) -> None:
        self.spin_scenes.valueChanged.connect(self._scenes_changed)
        self.project.project_updated.connect(self.refresh)
        self.project.active_clip_changed.connect(self._active_clip_changed)
        self.slot_drop_requested.connect(self._handle_slot_drop)

        self.cmb_quant.currentTextChanged.connect(self._launcher_settings_changed)
        self.cmb_mode.currentTextChanged.connect(self._launcher_settings_changed)

        self.btn_stop_all.clicked.connect(lambda: self.launcher.stop_all(reset_playhead=self.chk_reset.isChecked()))

    def _launcher_settings_changed(self) -> None:
        fn = getattr(self.project, 'set_launcher_settings', None)
        if callable(fn):
            fn(self.cmb_quant.currentText(), self.cmb_mode.currentText())
        else:
            # Fallback: persist directly on project model
            try:
                setattr(self.project.ctx.project, 'launcher_quantize', self.cmb_quant.currentText())
                setattr(self.project.ctx.project, 'launcher_mode', self.cmb_mode.currentText())
                self.project.project_updated.emit()
            except Exception:
                pass

    def _active_clip_changed(self, clip_id: str) -> None:
        if not clip_id:
            self.lbl_sel.setText("Ausgewählter Clip: —")
            return
        clip = next((c for c in self.project.ctx.project.clips if c.id == clip_id), None)
        self.lbl_sel.setText(f"Ausgewählter Clip: {clip.label}" if clip else "Ausgewählter Clip: —")

    def _scenes_changed(self, v: int) -> None:
        self.scene_count = int(v)
        self.refresh()

    def _slot_key(self, scene_index: int, track_id: str) -> str:
        return f"scene:{scene_index}:track:{track_id}"

    def _tracks(self):
        return [t for t in self.project.ctx.project.tracks if t.kind != 'master']

    def _beats_to_seconds(self, beats: float) -> float:
        bpm = float(getattr(self.project.ctx.project, 'bpm', 120.0) or 120.0)
        return (float(beats) * 60.0) / max(1e-6, bpm)

    def _volume_to_db(self, vol: float) -> float:
        v = float(vol)
        if v <= 0.0:
            return -120.0
        if v <= 1.0:
            return -60.0 + (60.0 * v)
        v = min(v, 2.0)
        return 6.0 * (v - 1.0)

    def _db_to_gain(self, db: float) -> float:
        if db <= -120.0:
            return 0.0
        return float(10.0 ** (float(db) / 20.0))

    def _display_gain_for_volume(self, vol: float) -> tuple[float, float]:
        db = self._volume_to_db(float(vol))
        return (self._db_to_gain(db), db)

    def _get_clip(self, clip_id: str):
        return self._clip_index.get(str(clip_id))

    def _get_track_volume(self, track_id: str) -> float:
        trk = self._track_index.get(str(track_id))
        try:
            return float(getattr(trk, 'volume', 0.8) or 0.8)
        except Exception:
            return 0.8

    # --- waveform cache (ported from ArrangerCanvas)

    def _get_peaks_for_path(self, path_str: str) -> _PeaksData | None:
        if sf is None or np is None:
            return None
        if not path_str:
            return None
        try:
            p = os.path.abspath(path_str)
            st = os.stat(p)
            mtime = int(st.st_mtime_ns)
        except Exception:
            return None

        cached = self._peaks_cache.get(p)
        if cached and int(cached.mtime_ns) == mtime:
            return cached

        if p not in self._peaks_pending:
            self._peaks_pending.add(p)
            self._submit_peaks_compute(p, mtime)
        return None

    def _submit_peaks_compute(self, abs_path: str, mtime_ns: int) -> None:
        def fn():
            return self._compute_peaks(abs_path)

        def ok(res):
            try:
                if res is None:
                    return
                peaks_arr, sr, bs = res
                self._peaks_cache[str(abs_path)] = _PeaksData(
                    mtime_ns=int(mtime_ns),
                    block_size=int(bs),
                    samplerate=int(sr),
                    peaks=peaks_arr,
                )
            finally:
                self._peaks_pending.discard(str(abs_path))
                try:
                    self.inner.update()
                except Exception:
                    pass
                self.update()

        def err(_msg: str):
            self._peaks_pending.discard(str(abs_path))

        try:
            self.project._submit(fn, ok, err)  # type: ignore[attr-defined]
        except Exception:
            try:
                res = self._compute_peaks(abs_path)
                if res is not None:
                    peaks_arr, sr, bs = res
                    self._peaks_cache[str(abs_path)] = _PeaksData(
                        mtime_ns=int(mtime_ns),
                        block_size=int(bs),
                        samplerate=int(sr),
                        peaks=peaks_arr,
                    )
            finally:
                self._peaks_pending.discard(str(abs_path))
                try:
                    self.inner.update()
                except Exception:
                    pass
                self.update()

    def _compute_peaks(self, abs_path: str):
        if sf is None or np is None:
            return None
        try:
            f = sf.SoundFile(abs_path)
        except Exception:
            return None

        block_size = 2048
        sr = int(getattr(f, 'samplerate', 48000) or 48000)
        peaks_list = []
        try:
            for block in f.blocks(blocksize=block_size, dtype='float32', always_2d=True):
                if block is None or block.shape[0] == 0:
                    continue
                a = np.max(np.abs(block), axis=1)
                peaks_list.append(float(np.max(a)))
        except Exception:
            try:
                data = f.read(dtype='float32', always_2d=True)
                if data is None or data.shape[0] == 0:
                    return None
                a = np.max(np.abs(data), axis=1)
                n = int(a.shape[0])
                n_chunks = (n + block_size - 1) // block_size
                for i in range(n_chunks):
                    s = i * block_size
                    e = min(n, (i + 1) * block_size)
                    peaks_list.append(float(np.max(a[s:e])))
            except Exception:
                return None
        finally:
            try:
                f.close()
            except Exception:
                pass

        if not peaks_list:
            return None
        arr = np.asarray(peaks_list, dtype='float32')
        arr = np.clip(arr, 0.0, 1.0)
        return arr, sr, block_size

    def _draw_audio_waveform(self, p: QPainter, rect: QRectF, clip, track_volume: float) -> None:
        peaks = self._get_peaks_for_path(str(getattr(clip, 'source_path', '') or ''))
        if peaks is None or np is None:
            p.setPen(QPen(self.palette().mid().color()))
            p.drawText(rect.adjusted(4, 0, -4, 0), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, 'Waveform…')
            return

        beats_to_sec = self._beats_to_seconds(1.0)
        offset_sec = float(getattr(clip, 'offset_seconds', 0.0) or 0.0)
        length_sec = float(getattr(clip, 'length_beats', 0.0) or 0.0) * beats_to_sec
        if length_sec <= 0.0:
            return

        start_i = int(max(0.0, offset_sec * peaks.peaks_per_second))
        end_i = int(max(start_i + 1, (offset_sec + length_sec) * peaks.peaks_per_second))
        seg = peaks.peaks[start_i:min(end_i, len(peaks.peaks))]
        if seg.size == 0:
            return

        n = max(8, int(rect.width()))
        if seg.size != n:
            x_old = np.linspace(0.0, 1.0, num=int(seg.size), dtype=np.float32)
            x_new = np.linspace(0.0, 1.0, num=int(n), dtype=np.float32)
            seg = np.interp(x_new, x_old, seg).astype(np.float32)

        gain, _db = self._display_gain_for_volume(track_volume)
        seg = np.clip(seg * float(gain), 0.0, 1.0)

        mid_y = rect.center().y()
        amp_h = rect.height() * 0.45

        p.setPen(QPen(self.palette().text().color()))
        x0 = int(rect.left())
        top = rect.top()
        bottom = rect.bottom()
        for i, a in enumerate(seg):
            if float(a) <= 0.0005:
                continue
            x = x0 + i
            dy = float(a) * amp_h
            y1 = max(top, mid_y - dy)
            y2 = min(bottom, mid_y + dy)
            p.drawLine(int(x), int(y1), int(x), int(y2))


    def _clear_grid(self) -> None:
        while self.grid.count():
            it = self.grid.takeAt(0)
            w = it.widget()
            if w:
                w.deleteLater()

    def refresh(self) -> None:
        self._clear_grid()

        q = getattr(self.project.ctx.project, "launcher_quantize", "1 Bar")
        m = getattr(self.project.ctx.project, "launcher_mode", "Trigger")
        self.cmb_quant.setCurrentText(q if q in ["Off", "1 Beat", "1 Bar"] else "1 Bar")
        self.cmb_mode.setCurrentText(m if m in ["Trigger", "Toggle", "Gate"] else "Trigger")

        tracks = self._tracks()

        # index for fast lookup in slot paintEvent
        try:
            self._clip_index = {str(c.id): c for c in (self.project.ctx.project.clips or [])}
        except Exception:
            self._clip_index = {}
        try:
            self._track_index = {str(t.id): t for t in (self.project.ctx.project.tracks or [])}
        except Exception:
            self._track_index = {}

        self.grid.addWidget(QLabel("Scene"), 0, 0)
        for col, trk in enumerate(tracks, start=1):
            lbl = QLabel(trk.name)
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.grid.addWidget(lbl, 0, col)

        for row in range(1, self.scene_count + 1):
            scene_btn = QToolButton()
            scene_btn.setText(f"▶ {row}")
            scene_btn.setToolTip("Scene starten (Quantize via Transport)")
            scene_btn.clicked.connect(lambda _=False, r=row: self.launcher.launch_scene(r))
            self.grid.addWidget(scene_btn, row, 0)

            for col, trk in enumerate(tracks, start=1):
                key = self._slot_key(row, trk.id)
                btn = SlotWaveButton(self)
                btn.setMinimumHeight(44)
                btn.setProperty("slot_key", key)

                cid = self.project.ctx.project.clip_launcher.get(key, "")
                btn.setProperty("clip_id", cid)

                if cid:
                    clip = next((c for c in self.project.ctx.project.clips if c.id == cid), None)
                    btn.setText(clip.label if clip else "Missing")
                else:
                    btn.setText("Empty")

                btn.clicked.connect(lambda _=False, k=key: self._launch(k))
                btn.double_clicked.connect(lambda k=key: self._slot_double_click(k))  # NEU: Doppelklick
                btn.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
                btn.customContextMenuRequested.connect(lambda _pos, b=btn: self._slot_menu(b))

                self.grid.addWidget(btn, row, col)

        self.grid.setRowStretch(self.scene_count + 1, 1)

    def _handle_slot_drop(self, btn: SlotButton, event) -> None:  # noqa: ANN001
        key = str(btn.property("slot_key") or "")
        if not key:
            return
        clip_id = bytes(event.mimeData().data("application/x-pydaw-clipid")).decode("utf-8")
        if clip_id:
            # v0.0.11: arm + launch
            self.project.cliplauncher_assign(key, clip_id)
            self.launcher.launch_slot(key)

    def _launch(self, slot_key: str) -> None:
        """Slot launchen und ClipContextService benachrichtigen."""
        self.launcher.launch_slot(slot_key)
        cid = self.project.ctx.project.clip_launcher.get(slot_key, "")
        if cid:
            self.clip_activated.emit(cid)
            
            # ClipContextService benachrichtigen (Pro-DAW-Style)
            if self.clip_context:
                # slot_key Format: "scene:X:track:Y"
                parts = slot_key.split(":")
                if len(parts) == 4 and parts[0] == "scene" and parts[2] == "track":
                    try:
                        scene_idx = int(parts[1])
                        track_id = parts[3]
                        self.clip_context.set_active_slot(scene_idx, track_id, cid)
                    except Exception:
                        pass

    def _slot_double_click(self, slot_key: str) -> None:
        """Doppelklick auf Slot -> Loop-Editor oder Audio Event Editor öffnen."""
        cid = self.project.ctx.project.clip_launcher.get(slot_key, "")
        if not cid or not self.clip_context:
            return
            
        clip = self.project.get_clip(cid)
        if not clip:
            return
            
        # Audio Clip -> Audio Event Editor (wie in v0.0.19.7.49 implementiert)
        if str(getattr(clip, 'kind', '')) == 'audio':
            try:
                from pydaw.ui.audio_event_editor import AudioEventEditor
                dialog = AudioEventEditor(clip, self.project, parent=self)
                dialog.exec()
            except Exception as e:
                self.project.error.emit(f"Fehler beim Öffnen des Event Editors: {e}")
        else:
            # MIDI/andere -> Loop-Editor
            self.clip_context.open_loop_editor(cid)

    def _slot_menu(self, btn: SlotButton) -> None:
        key = str(btn.property("slot_key") or "")
        if not key:
            return

        cid = self.project.ctx.project.clip_launcher.get(key, "")
        
        menu = QMenu(self)
        a_assign = menu.addAction("Ausgewählten Clip zuweisen")
        a_select = menu.addAction("Clip auswählen")
        
        # NEU: Loop-Editor nur wenn Clip zugewiesen ist
        a_loop_editor = None
        if cid and self.clip_context:
            menu.addSeparator()
            a_loop_editor = menu.addAction("Loop-Editor öffnen...")
        
        menu.addSeparator()
        a_clear = menu.addAction("Slot leeren")

        act = menu.exec(btn.mapToGlobal(btn.rect().center()))
        if act == a_assign:
            active_cid = self.project.active_clip_id
            if active_cid:
                self.project.cliplauncher_assign(key, active_cid)
        elif act == a_clear:
            self.project.cliplauncher_clear(key)
        elif act == a_select:
            if cid:
                self.project.select_clip(cid)
                self.clip_activated.emit(cid)
        elif a_loop_editor and act == a_loop_editor:
            # Loop-Editor öffnen
            if self.clip_context:
                self.clip_context.open_loop_editor(cid)