from __future__ import annotations

from dataclasses import dataclass

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QAction, QKeySequence
from PyQt6.QtWidgets import (
    QComboBox,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QScrollArea,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from pydaw.services.project_service import ProjectService
from pydaw.services.transport_service import TransportService

from pydaw.core.settings import SettingsKeys
from pydaw.core.settings_store import get_value
from pydaw.music.scales import allowed_pitch_classes
from pydaw.ui.pianoroll_canvas import PianoRollCanvas

# Ghost Notes / Layered Editing Support
from pydaw.ui.layer_panel import LayerPanel

# Scale Lock / Scale Menu (shared with Notation)
from pydaw.ui.scale_menu_button import ScaleMenuButton


@dataclass
class _PianoRollUiConstants:
    ruler_h: int = 22
    keyboard_w: int = 66


class _PianoRollRuler(QWidget):
    """Top ruler that follows the canvas horizontal scroll."""

    def __init__(self, canvas: PianoRollCanvas, scroll_area: QScrollArea, parent=None):
        super().__init__(parent)
        self.canvas = canvas
        self.scroll_area = scroll_area
        self.setFixedHeight(_PianoRollUiConstants().ruler_h)
        self.setAutoFillBackground(True)

        # update when scroll changes
        self.scroll_area.horizontalScrollBar().valueChanged.connect(self.update)
        self.scroll_area.verticalScrollBar().valueChanged.connect(self.update)

    def paintEvent(self, event):  # noqa: N802
        # Keep it simple: tick marks at bars/beats based on current zoom
        from PyQt6.QtGui import QPainter, QPen

        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        p.fillRect(self.rect(), self.palette().window())

        scroll_x = self.scroll_area.horizontalScrollBar().value()
        ppb = float(self.canvas.pixels_per_beat)

        w = self.width()
        start_beat = max(0, int(scroll_x / ppb) - 1)
        end_beat = int((scroll_x + w) / ppb) + 2

        pen_major = QPen(Qt.GlobalColor.lightGray)
        pen_minor = QPen(Qt.GlobalColor.darkGray)

        for beat in range(start_beat, end_beat + 1):
            x = int(beat * ppb) - scroll_x
            if x < 0 or x > w:
                continue
            is_bar = (beat % 4 == 0)
            p.setPen(pen_major if is_bar else pen_minor)
            p.drawLine(x, 0, x, self.height())
            if is_bar:
                bar_idx = beat // 4
                p.drawText(x + 4, self.height() - 6, f"Bar {bar_idx+1}")


class _PianoRollKeyboard(QWidget):
    """Left keyboard that follows the canvas vertical scroll."""

    def __init__(self, canvas: PianoRollCanvas, scroll_area: QScrollArea, parent=None):
        super().__init__(parent)
        self.canvas = canvas
        self.scroll_area = scroll_area
        self.setFixedWidth(_PianoRollUiConstants().keyboard_w)
        self.setAutoFillBackground(True)

        self.scroll_area.verticalScrollBar().valueChanged.connect(self.update)

    @staticmethod
    def _is_black(midi_pitch: int) -> bool:
        return (midi_pitch % 12) in {1, 3, 6, 8, 10}

    def paintEvent(self, event):  # noqa: N802
        from PyQt6.QtGui import QPainter

        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        p.fillRect(self.rect(), self.palette().window())

        scroll_y = self.scroll_area.verticalScrollBar().value()
        pps = float(self.canvas.pixels_per_semitone)
        lo, hi = self.canvas.visible_pitches

        viewport_h = self.height()
        start_y = scroll_y
        end_y = scroll_y + viewport_h

        pitch_top = hi - int(start_y / pps) - 1
        pitch_bottom = hi - int(end_y / pps) + 1
        pitch_top = min(hi, max(lo, pitch_top))
        pitch_bottom = min(hi, max(lo, pitch_bottom))

        # Scale hints (Pro-DAW-like cyan dots) on the keyboard
        allowed_pcs = None
        try:
            keys = SettingsKeys()
            if bool(get_value(keys.scale_visualize, True)) and bool(get_value(keys.scale_enabled, False)):
                cat = str(get_value(keys.scale_category, "Keine Einschränkung"))
                name = str(get_value(keys.scale_name, "Alle Noten"))
                if cat != "Keine Einschränkung":
                    root = int(get_value(keys.scale_root_pc, 0) or 0)
                    allowed_pcs = set(int(x) % 12 for x in allowed_pitch_classes(category=cat, name=name, root_pc=root))
        except Exception:
            allowed_pcs = None

        if allowed_pcs:
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        for pitch in range(pitch_top, pitch_bottom - 1, -1):
            y = int((hi - pitch) * pps) - scroll_y
            r_h = int(pps)

            if self._is_black(pitch):
                p.fillRect(0, y, self.width(), r_h, Qt.GlobalColor.black)
                p.setPen(Qt.GlobalColor.darkGray)
            else:
                p.fillRect(0, y, self.width(), r_h, Qt.GlobalColor.white)
                p.setPen(Qt.GlobalColor.gray)

            p.drawRect(0, y, self.width() - 1, r_h)

            if pitch % 12 == 0:
                octave = pitch // 12 - 1
                p.setPen(Qt.GlobalColor.darkBlue)
                p.drawText(6, y + r_h - 4, f"C{octave}")

            # Scale hint dot (cyan)
            if allowed_pcs and (int(pitch) % 12) in allowed_pcs:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(Qt.GlobalColor.cyan)
                cx = int(self.width() - 12)
                cy = int(y + (r_h / 2))
                p.drawEllipse(cx - 3, cy - 3, 6, 6)


class PianoRollEditor(QWidget):
    """Piano roll editor with BachOrgelForge-like tool strip (UI-first)."""

    status_message = pyqtSignal(str, int)
    # MIDI live-record toggle (writes notes into clip)
    record_toggled = pyqtSignal(bool)

    def __init__(self, project: ProjectService, transport: TransportService | None = None, parent=None):
        super().__init__(parent)
        self.project = project
        self.transport = transport

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(4)

        # --- Header + local tool strip
        header_row = QHBoxLayout()
        header_row.setContentsMargins(6, 0, 6, 0)
        header_row.setSpacing(6)

        self.header = QLabel("Piano Roll")
        self.header.setObjectName("PianoRollHeader")
        header_row.addWidget(self.header, 1)

        # Tool group (exclusive)
        self._btn_select = self._mk_tool("Select", "select", shortcut="1")
        self._btn_time = self._mk_tool("Time", "time", shortcut="2")
        self._btn_pen = self._mk_tool("Pencil", "pen", shortcut="3")
        self._btn_erase = self._mk_tool("Erase", "erase", shortcut="4")
        self._btn_knife = self._mk_tool("Knife", "knife", shortcut="5")

        for b in (self._btn_select, self._btn_time, self._btn_pen, self._btn_erase, self._btn_knife):
            header_row.addWidget(b)

        # Grid controls
        header_row.addSpacing(8)
        header_row.addWidget(QLabel("Grid:"))

        self._cmb_grid_mode = QComboBox()
        self._cmb_grid_mode.addItems(["fixed", "adaptive"])
        self._cmb_grid_mode.setToolTip("fixed = konstant; adaptive = gröber beim Herauszoomen")
        self._cmb_grid_mode.currentTextChanged.connect(self._on_grid_mode)
        header_row.addWidget(self._cmb_grid_mode)

        self._cmb_grid_div = QComboBox()
        self._grid_denoms = [1, 2, 4, 8, 16, 32, 64]
        for d in self._grid_denoms:
            self._cmb_grid_div.addItem(f"1/{d}", d)
        self._cmb_grid_div.setCurrentIndex(self._grid_denoms.index(16))
        self._cmb_grid_div.currentIndexChanged.connect(self._on_grid_div)
        header_row.addWidget(self._cmb_grid_div)

        # Toggles
        self._btn_snap = self._mk_toggle("Snap", checked=True)
        self._btn_automation = self._mk_toggle("Automation", checked=False)
        self._btn_record = self._mk_toggle("Record", checked=False)
        self._btn_looprec = self._mk_toggle("Loop", checked=False)

        self._btn_snap.clicked.connect(self._on_snap)
        # Record -> drives MidiManager.set_record_enabled (live monitoring stays on)
        try:
            self._btn_record.toggled.connect(self.record_toggled.emit)
        except Exception:
            pass
        # Automation/LoopRec are still UI-only placeholders for now

        for b in (self._btn_snap, self._btn_automation, self._btn_record, self._btn_looprec):
            header_row.addWidget(b)

        # Scale Lock (Snap/Reject)
        header_row.addSpacing(8)
        self._scale_btn = ScaleMenuButton(self)
        self._scale_btn.changed.connect(self._on_scale_changed)
        header_row.addWidget(self._scale_btn)

        # Undo (UI placeholder) + Zoom
        header_row.addSpacing(8)
        self._btn_undo = QToolButton()
        self._btn_undo.setText("Undo")
        self._btn_undo.setToolTip("Undo (Ctrl+Z)")
        self._btn_undo.clicked.connect(lambda: getattr(project, 'undo', lambda: None)())
        header_row.addWidget(self._btn_undo)

        self._btn_redo = QToolButton()
        self._btn_redo.setText("Redo")
        self._btn_redo.setToolTip("Redo (Ctrl+Shift+Z / Ctrl+Y)")
        self._btn_redo.clicked.connect(lambda: getattr(project, 'redo', lambda: None)())
        header_row.addWidget(self._btn_redo)

        self._btn_zoom_out = QToolButton()
        self._btn_zoom_out.setText("-")
        self._btn_zoom_out.setToolTip("Zoom out")

        self._btn_zoom_in = QToolButton()
        self._btn_zoom_in.setText("+")
        self._btn_zoom_in.setToolTip("Zoom in")

        self._btn_zoom_out.clicked.connect(lambda: self.canvas.zoom_out())
        self._btn_zoom_in.clicked.connect(lambda: self.canvas.zoom_in())

        header_row.addWidget(self._btn_zoom_out)
        header_row.addWidget(self._btn_zoom_in)

        outer.addLayout(header_row)

        # --- Main grid layout: corner + ruler + keyboard + scrollable canvas
        grid = QGridLayout()
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(0)
        grid.setVerticalSpacing(0)

        self.canvas = PianoRollCanvas(project, transport=self.transport)
        self.canvas.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.canvas.status_message.connect(lambda t, ms=1500: self.status_message.emit(str(t), int(ms)))

        # DAW-style shortcuts (work while focus is anywhere inside the PianoRoll)
        self._install_shortcuts()

        # Loop helpers from the right-click context menu
        if self.transport is not None:
            self.canvas.loop_start_requested.connect(self._set_loop_start)
            self.canvas.loop_end_requested.connect(self._set_loop_end)
            self.canvas.playhead_requested.connect(self._set_playhead)
            # Transport playhead -> PianoRoll playline (local to current clip)
            try:
                self.transport.playhead_changed.connect(self.canvas.set_transport_playhead)
            except Exception:
                pass

        self.scroll = QScrollArea()
        self.scroll.setWidget(self.canvas)
        self.scroll.setWidgetResizable(False)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)

        corner = QWidget()
        corner.setFixedSize(_PianoRollUiConstants().keyboard_w, _PianoRollUiConstants().ruler_h)

        self.ruler = _PianoRollRuler(self.canvas, self.scroll)
        self.keyboard = _PianoRollKeyboard(self.canvas, self.scroll)

        grid.addWidget(corner, 0, 0)
        grid.addWidget(self.ruler, 0, 1)
        grid.addWidget(self.keyboard, 1, 0)
        grid.addWidget(self.scroll, 1, 1)

        grid.setRowStretch(1, 1)
        grid.setColumnStretch(1, 1)

        outer.addLayout(grid)

        # Ghost Notes / Layered Editing: Layer Panel
        self.layer_panel = LayerPanel(self.canvas.layer_manager)
        self.layer_panel.setMaximumHeight(200)  # Collapsible panel height
        self.layer_panel.layer_added.connect(self._on_add_ghost_layer)  # Connect signal
        outer.addWidget(self.layer_panel)

        # defaults
        self._btn_pen.setChecked(True)
        self.canvas.set_tool_mode("pen")
        self._on_grid_div(self._cmb_grid_div.currentIndex())
        self._on_grid_mode(self._cmb_grid_mode.currentText())
        self._on_snap()

        self.set_clip(None)

    def _install_shortcuts(self) -> None:
        """Install core editing shortcuts for the PianoRoll.

        Paste behavior: anchored at last mouse position in the grid.
        """

        def add_act(seq, fn, text: str = ""):
            a = QAction(self)
            a.setShortcut(seq)
            a.setShortcutContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
            if text:
                a.setText(text)
            a.triggered.connect(fn)
            self.addAction(a)
        # NOTE: Copy/Cut/Paste/SelectAll are handled by MainWindow global actions
        # to avoid shortcut ambiguity across panels.

        # Delete
        add_act(QKeySequence(Qt.Key.Key_Delete), self.canvas.delete_selected, "Delete")
        add_act(QKeySequence(Qt.Key.Key_Backspace), self.canvas.delete_selected, "Delete")

        # Duplicate (Ctrl+D)
        add_act(QKeySequence("Ctrl+D"), self.canvas.duplicate_selected, "Duplicate")

    # ---- UI helpers
    def _mk_tool(self, label: str, mode: str, shortcut: str = "") -> QToolButton:
        b = QToolButton()
        b.setText(label)
        b.setCheckable(True)
        if shortcut:
            b.setToolTip(f"{label} [{shortcut}]")
        b.clicked.connect(lambda: self._set_tool(mode, b))
        return b

    def _mk_toggle(self, label: str, checked: bool = False) -> QToolButton:
        b = QToolButton()
        b.setText(label)
        b.setCheckable(True)
        b.setChecked(bool(checked))
        return b

    def _set_tool(self, mode: str, clicked: QToolButton) -> None:
        for b in (self._btn_select, self._btn_time, self._btn_pen, self._btn_erase, self._btn_knife):
            if b is not clicked:
                b.blockSignals(True)
                b.setChecked(False)
                b.blockSignals(False)
        clicked.setChecked(True)
        self.canvas.set_tool_mode(mode)
        try:
            self.status_message.emit(f"Tool: {mode}", 900)
        except Exception:
            pass

    # ---- hooks
    def _on_grid_mode(self, text: str) -> None:
        self.canvas.set_grid_mode(str(text or "fixed"))

    def _on_grid_div(self, idx: int) -> None:
        denom = int(self._cmb_grid_div.itemData(idx) or 16)
        self.canvas.set_grid_division(denom)

    def _on_snap(self) -> None:
        self.canvas.set_snap_enabled(bool(self._btn_snap.isChecked()))

    def _on_scale_changed(self) -> None:
        """Scale selector changed.

        The canvas reads the persistent settings when creating notes.
        We only refresh small UI hints / repaint.
        """
        try:
            self._scale_btn.refresh()
        except Exception:
            pass
        try:
            self.canvas.update()
            self.keyboard.update()
        except Exception:
            pass

    # ---- transport interactions
    def _set_loop_start(self, beat: float) -> None:
        if self.transport is None:
            return
        _start, end = self.transport.get_loop_region()
        self.transport.set_loop_region(float(beat), float(max(beat + 0.25, end)))
        self.transport.set_loop(True)

    def _set_loop_end(self, beat: float) -> None:
        if self.transport is None:
            return
        start, _end = self.transport.get_loop_region()
        self.transport.set_loop_region(float(min(start, beat - 0.25)), float(beat))
        self.transport.set_loop(True)

    def _set_playhead(self, beat: float) -> None:
        if self.transport is None:
            return
        try:
            self.transport.set_position_beats(float(beat))
        except Exception:
            # keep it non-fatal
            pass

    # ---- Ghost Notes / Layered Editing
    def _on_add_ghost_layer(self) -> None:
        """Handle add ghost layer request from Layer Panel."""
        from PyQt6.QtWidgets import QDialog
        from pydaw.ui.clip_selection_dialog import ClipSelectionDialog
        from pydaw.model.ghost_notes import LayerState
        
        # Open clip selection dialog
        dialog = ClipSelectionDialog(
            self.project,
            current_clip_id=self.canvas.clip_id,
            parent=self
        )
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            clip_id = dialog.get_selected_clip_id()
            if not clip_id:
                return
            
            # Get clip info for display name
            try:
                project = self.project.ctx.project
                clip = next((c for c in project.clips if c.id == clip_id), None)
                track = next((t for t in project.tracks if clip and t.id == clip.track_id), None)
                
                if clip and track:
                    track_name = str(track.name)
                    
                    # Add as ghost layer
                    self.canvas.layer_manager.add_layer(
                        clip_id=clip_id,
                        track_name=track_name,
                        state=LayerState.LOCKED,
                        opacity=0.3,
                    )
                    
                    # Show status message
                    try:
                        self.status_message.emit(f"Ghost Layer hinzugefügt: {track_name}", 2000)
                    except Exception:
                        pass
            except Exception as e:
                print(f"Error adding ghost layer: {e}")

    # ---- public API
    def set_clip(self, clip_id: str | None) -> None:
        self.canvas.set_clip(clip_id)
        if clip_id:
            self.header.setText(f"Piano Roll: {clip_id}")
        else:
            self.header.setText("Piano Roll")
        self.ruler.update()
        self.keyboard.update()
