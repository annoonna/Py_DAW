#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Standalone VST3/VST2 native editor subprocess helper.

Launched by Vst3AudioFxWidget via QProcess.  Loads one VST plugin, shows
its native editor window, and maintains bidirectional parameter sync with
the parent DAW process via JSON-Lines over stdout/stdin.

Usage (internal, called by Vst3AudioFxWidget):
    python3 vst_gui_process.py <plugin_path> [plugin_name]
                               [--title WINDOW_TITLE] [--track TRACK_NAME]

Exit codes:
    0  — editor closed normally
    1  — plugin could not be loaded
    2  — show_editor() not available / not supported on this platform
    3  — pedalboard not installed

Protocol — stdout (subprocess → parent), one JSON line per event:
    {"event": "ready",   "plugin": "<n>", "params": [{"name":..,"value":..}, ...]}
    {"event": "param",   "name": "<param>",  "value": <float>}
    {"event": "closed"}
    {"event": "error",   "msg": "<reason>"}

Protocol — stdin (parent → subprocess), one JSON line per command:
    {"cmd": "set_param", "name": "<param>", "value": <float>}
    {"cmd": "quit"}

v0.0.20.377 — Korrekte pedalboard Parameter-API (plugin.parameters dict +
               param.raw_value); robuste Snapshot-Logik; QPushButton-
               deleted-Guard im Parent via Widget-weak-ref.
"""

from __future__ import annotations

import json
import os
import sys
import threading
import time
from typing import Any, Dict, List, Optional


# ── Helpers ──────────────────────────────────────────────────────────────────

_stdout_lock = threading.Lock()


def _emit(obj: dict) -> None:
    """Write one JSON event line to stdout — thread-safe."""
    try:
        line = json.dumps(obj, ensure_ascii=False)
        with _stdout_lock:
            print(line, flush=True)
    except Exception:
        pass


def _parse_args() -> tuple[str, str, str, str]:
    """Return (plugin_path, plugin_name, window_title, track_name)."""
    args = sys.argv[1:]
    positional: List[str] = []
    window_title = ""
    track_name = ""
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--title" and i + 1 < len(args):
            window_title = args[i + 1]
            i += 2
        elif a == "--track" and i + 1 < len(args):
            track_name = args[i + 1]
            i += 2
        else:
            positional.append(a)
            i += 1
    plugin_path = positional[0] if positional else ""
    plugin_name = positional[1] if len(positional) > 1 else ""
    return plugin_path, plugin_name, window_title, track_name


def _load_plugin(path: str, plugin_name: str) -> Any:
    """Load a VST plugin via pedalboard."""
    import pedalboard
    if plugin_name:
        try:
            return pedalboard.load_plugin(path, plugin_name=plugin_name)
        except TypeError:
            return pedalboard.load_plugin(path, plugin_name)
    return pedalboard.load_plugin(path)


def _snapshot_params(plugin: Any) -> Dict[str, float]:
    """Snapshot all current parameter values using pedalboard's official API.

    pedalboard exposes a `.parameters` dict:  name (str) → AudioProcessorParameter
    Each AudioProcessorParameter has `.raw_value` (float) for the current value.

    v0.0.20.377 — replaced broken dir()-based fallback with proper API.
    """
    out: Dict[str, float] = {}
    try:
        params = plugin.parameters  # dict: name → AudioProcessorParameter
        for name, param in params.items():
            try:
                out[str(name)] = float(param.raw_value)
            except Exception:
                # Fallback: some pedalboard builds expose value directly as attr
                try:
                    v = getattr(plugin, name, None)
                    if isinstance(v, (int, float, bool)):
                        out[str(name)] = float(v)
                except Exception:
                    pass
    except Exception:
        pass
    return out


# ── Background threads ────────────────────────────────────────────────────────

class _StdinReader(threading.Thread):
    """Reads JSON commands from stdin and applies them to the plugin."""

    def __init__(self, plugin: Any, stop_event: threading.Event) -> None:
        super().__init__(daemon=True, name="vst-stdin-reader")
        self._plugin = plugin
        self._stop = stop_event

    def run(self) -> None:
        try:
            for raw in sys.stdin:
                if self._stop.is_set():
                    break
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    cmd = json.loads(raw)
                except Exception:
                    continue
                action = cmd.get("cmd", "")
                if action == "set_param":
                    name = str(cmd.get("name", ""))
                    value = cmd.get("value")
                    if name and value is not None:
                        try:
                            # Use raw_value setter (normalized 0-1) via parameters dict
                            params = self._plugin.parameters
                            if name in params:
                                param = params[name]
                                if getattr(param, "is_boolean", False):
                                    setattr(self._plugin, name, bool(float(value) >= 0.5))
                                else:
                                    param.raw_value = float(value)
                            else:
                                setattr(self._plugin, name, float(value))
                        except Exception:
                            try:
                                setattr(self._plugin, name, float(value))
                            except Exception:
                                pass
                elif action == "quit":
                    self._stop.set()
                    break
        except Exception:
            pass


class _ParamPoller(threading.Thread):
    """Polls plugin params every INTERVAL_S and emits changes via stdout."""

    INTERVAL_S = 0.08  # 80 ms

    def __init__(self, plugin: Any, stop_event: threading.Event,
                 initial_params: Dict[str, float]) -> None:
        super().__init__(daemon=True, name="vst-param-poller")
        self._plugin = plugin
        self._stop = stop_event
        self._last: Dict[str, float] = dict(initial_params)

    def run(self) -> None:
        while not self._stop.is_set():
            try:
                current = _snapshot_params(self._plugin)
                for name, val in current.items():
                    prev = self._last.get(name)
                    if prev is None or abs(val - prev) > 1e-7:
                        self._last[name] = val
                        _emit({"event": "param", "name": name, "value": val})
            except Exception:
                pass
            time.sleep(self.INTERVAL_S)


# ── Main ─────────────────────────────────────────────────────────────────────

def _ensure_x11_platform() -> None:
    """Auto-detect Wayland and force XCB/X11 for native VST editor windows.

    VST2/VST3 native editors use X11 embedding (winId). On Wayland sessions,
    Qt must run under XWayland via QT_QPA_PLATFORM=xcb, otherwise the editor
    window will not appear or crash.

    v0.0.20.397 — Wayland Editor Auto-Fix
    """
    try:
        sess = (os.environ.get("XDG_SESSION_TYPE", "") or "").lower()
        qpa = (os.environ.get("QT_QPA_PLATFORM", "") or "").lower()
        has_wayland_display = bool(os.environ.get("WAYLAND_DISPLAY", ""))
        is_wayland = (sess == "wayland") or has_wayland_display or qpa.startswith("wayland")

        if is_wayland:
            # Force XWayland for native plugin editors
            os.environ["QT_QPA_PLATFORM"] = "xcb"
            _emit({"event": "info", "msg": "Wayland detected — forcing QT_QPA_PLATFORM=xcb for VST editor"})
    except Exception:
        pass


def main() -> int:
    # ── Wayland Auto-Fix (before any Qt/plugin imports) ─────────────────────
    _ensure_x11_platform()

    plugin_path, plugin_name, window_title, track_name = _parse_args()

    if not plugin_path:
        _emit({"event": "error", "msg": "No plugin path supplied"})
        return 1

    # ── pedalboard check ────────────────────────────────────────────────────
    try:
        import pedalboard  # noqa: F401
    except ImportError:
        _emit({"event": "error", "msg": "pedalboard not installed (pip install pedalboard)"})
        return 3

    # ── load plugin ─────────────────────────────────────────────────────────
    try:
        plugin = _load_plugin(plugin_path, plugin_name)
    except Exception as exc:
        _emit({"event": "error", "msg": f"Load failed: {exc}"})
        return 1

    # ── initial param snapshot ──────────────────────────────────────────────
    initial_params = _snapshot_params(plugin)
    params_list = [{"name": k, "value": v} for k, v in sorted(initial_params.items())]

    disp_name = plugin_name or os.path.basename(plugin_path)
    _emit({"event": "ready", "plugin": disp_name, "params": params_list})

    # ── show_editor() check ─────────────────────────────────────────────────
    show_fn = getattr(plugin, "show_editor", None)
    if not callable(show_fn):
        _emit({"event": "error", "msg": "show_editor() not available for this plugin"})
        return 2

    # ── build window title ──────────────────────────────────────────────────
    if not window_title:
        parts = [disp_name]
        if track_name:
            parts.append(f"[{track_name}]")
        parts.append("— Py_DAW")
        window_title = "  ".join(parts)

    # ── start background threads ────────────────────────────────────────────
    stop_event = threading.Event()
    stdin_reader = _StdinReader(plugin, stop_event)
    param_poller = _ParamPoller(plugin, stop_event, initial_params)
    stdin_reader.start()
    param_poller.start()

    # ── show editor (blocks until window closed) ────────────────────────────
    try:
        try:
            show_fn(window_title=window_title)
        except TypeError:
            try:
                show_fn(window_title)
            except TypeError:
                show_fn()
        _emit({"event": "closed"})
        return 0
    except KeyboardInterrupt:
        _emit({"event": "closed"})
        return 0
    except Exception as exc:
        _emit({"event": "error", "msg": f"show_editor() failed: {exc}"})
        return 2
    finally:
        stop_event.set()


if __name__ == "__main__":
    sys.exit(main())
