"""Mixer Panel — Pro-DAW-Style vertical fader strips (v0.0.20.14).

Features:
- Vertical fader strips (90px wide) with VU meters
- Mute / Solo buttons per track
- Pan knob (horizontal slider)
- Volume fader (vertical, 0-127 → 0.0-1.0, logarithmic dB display)
- Automation mode selector
- All parameters routed through RTParamStore + HybridRingBuffer for click-free real-time audio
- Per-track params via lock-free ParamRingBuffer (v0.0.20.14)
- Track rename via double-click
- Add/Remove track buttons
"""
from __future__ import annotations

import math
from typing import Optional

from PyQt6.QtCore import Qt, QTimer, QRectF
from PyQt6.QtGui import QPainter, QColor, QLinearGradient, QPen
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea, QFrame,
    QSlider, QComboBox, QPushButton, QSizePolicy, QMenu, QInputDialog,
)

from pydaw.services.project_service import ProjectService

# v0.0.20.21: Professional VU Meter
try:
    from pydaw.ui.widgets.vu_meter import VUMeterWidget
    VU_METER_AVAILABLE = True
except ImportError:
    VU_METER_AVAILABLE = False


# ---- VU Meter Widget (Legacy - kept for backward compatibility)

class _VUMeter(QWidget):
    """Stereo VU meter — 8px wide, gradient fill, peak hold."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(10)
        self.setMinimumHeight(60)
        self._peak_l = 0.0
        self._peak_r = 0.0
        self._hold_l = 0.0
        self._hold_r = 0.0

    def set_levels(self, left: float, right: float) -> None:
        self._peak_l = max(0.0, min(1.0, left))
        self._peak_r = max(0.0, min(1.0, right))
        self._hold_l = max(self._hold_l * 0.92, self._peak_l)
        self._hold_r = max(self._hold_r * 0.92, self._peak_r)
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        w = self.width()
        h = self.height()
        half = w // 2

        # Background
        p.fillRect(0, 0, w, h, QColor(30, 30, 30))

        for i, (peak, hold) in enumerate(
            [(self._peak_l, self._hold_l), (self._peak_r, self._hold_r)]
        ):
            x = 0 if i == 0 else half
            bar_h = int(peak * h)
            if bar_h > 0:
                grad = QLinearGradient(0, h, 0, 0)
                grad.setColorAt(0.0, QColor(0, 200, 80))
                grad.setColorAt(0.65, QColor(220, 220, 0))
                grad.setColorAt(1.0, QColor(255, 40, 40))
                p.fillRect(x, h - bar_h, half, bar_h, grad)

            # Peak hold line
            hold_y = h - int(hold * h)
            p.setPen(QPen(QColor(255, 255, 255, 180), 1))
            p.drawLine(x, hold_y, x + half - 1, hold_y)

        p.end()


# ---- Mixer Strip

class _MixerStrip(QFrame):
    """Single vertical mixer strip (90px wide)."""

    def __init__(self, project: ProjectService, track_id: str,
                 audio_engine=None, rt_params=None, hybrid_bridge=None, parent=None):
        super().__init__(parent)
        self.project = project
        self.track_id = track_id
        self.audio_engine = audio_engine
        self.rt_params = rt_params
        self.hybrid_bridge = hybrid_bridge  # v0.0.20.14: lock-free per-track ring

        # v0.0.20.28: Fallback to AudioEngine's HybridEngineBridge when not passed in.
        if self.hybrid_bridge is None and self.audio_engine is not None:
            try:
                hb = getattr(self.audio_engine, "_hybrid_bridge", None)
                if hb is None:
                    hb = getattr(self.audio_engine, "hybrid_bridge", None)
                if hb is not None:
                    self.hybrid_bridge = hb
            except Exception:
                pass

        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setFixedWidth(92)
        self.setSizePolicy(QSizePolicy.Policy.Fixed,
                           QSizePolicy.Policy.Expanding)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(3)

        # Track name (click to rename)
        self.lbl_name = QLabel("")
        self.lbl_name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_name.setWordWrap(True)
        self.lbl_name.setMaximumHeight(32)
        self.lbl_name.setStyleSheet(
            "QLabel { font-size: 10px; padding: 2px; }"
            "QLabel:hover { background: #444; border-radius: 3px; }"
        )
        self.lbl_name.setCursor(Qt.CursorShape.PointingHandCursor)
        self.lbl_name.mouseDoubleClickEvent = lambda ev: self._rename_track()
        lay.addWidget(self.lbl_name)

        # Automation mode
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["off", "read", "write"])
        self.cmb_mode.setFixedHeight(22)
        self.cmb_mode.setStyleSheet("font-size: 9px;")
        self.cmb_mode.currentTextChanged.connect(self._on_mode)
        lay.addWidget(self.cmb_mode)

        # Pan slider (horizontal)
        self.sld_pan = QSlider(Qt.Orientation.Horizontal)
        self.sld_pan.setRange(-100, 100)
        self.sld_pan.setValue(0)
        self.sld_pan.setFixedHeight(18)
        self.sld_pan.setToolTip("Pan: L ← → R")
        self.sld_pan.valueChanged.connect(self._on_pan)
        lay.addWidget(self.sld_pan)

        # Fader + VU area
        fader_row = QHBoxLayout()
        fader_row.setSpacing(2)

        self.sld_vol = QSlider(Qt.Orientation.Vertical)
        self.sld_vol.setRange(0, 127)
        self.sld_vol.setValue(100)
        self.sld_vol.setMinimumHeight(80)
        self.sld_vol.setToolTip("Volume fader")
        self.sld_vol.valueChanged.connect(self._on_vol)
        fader_row.addWidget(self.sld_vol, 1)

        # VU Meter (v0.0.20.21: New professional widget if available)
        if VU_METER_AVAILABLE:
            self.vu = VUMeterWidget()
        else:
            self.vu = _VUMeter()
        fader_row.addWidget(self.vu, 0)

        lay.addLayout(fader_row, 1)

        # dB label
        self.lbl_db = QLabel("0.0 dB")
        self.lbl_db.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_db.setStyleSheet("font-size: 9px; color: #aaa;")
        lay.addWidget(self.lbl_db)

        # Mute / Solo buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(2)

        self.btn_mute = QPushButton("M")
        self.btn_mute.setCheckable(True)
        self.btn_mute.setFixedSize(34, 22)
        self.btn_mute.setStyleSheet(
            "QPushButton { font-size: 10px; font-weight: bold; }"
            "QPushButton:checked { background: #c44; color: white; }"
        )
        self.btn_mute.toggled.connect(self._on_mute)
        btn_row.addWidget(self.btn_mute)

        self.btn_solo = QPushButton("S")
        self.btn_solo.setCheckable(True)
        self.btn_solo.setFixedSize(34, 22)
        self.btn_solo.setStyleSheet(
            "QPushButton { font-size: 10px; font-weight: bold; }"
            "QPushButton:checked { background: #cc4; color: black; }"
        )
        self.btn_solo.toggled.connect(self._on_solo)
        btn_row.addWidget(self.btn_solo)

        # v0.0.20.397 — MIDI Learn context menus for all mixer controls
        self._midi_mapping_service = None  # injected later
        for widget in (self.sld_vol, self.sld_pan, self.btn_mute, self.btn_solo):
            widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.sld_vol.customContextMenuRequested.connect(lambda pos: self._midi_learn_menu(pos, "volume", self.sld_vol))
        self.sld_pan.customContextMenuRequested.connect(lambda pos: self._midi_learn_menu(pos, "pan", self.sld_pan))
        self.btn_mute.customContextMenuRequested.connect(lambda pos: self._midi_learn_menu(pos, "mute", self.btn_mute))
        self.btn_solo.customContextMenuRequested.connect(lambda pos: self._midi_learn_menu(pos, "solo", self.btn_solo))

        lay.addLayout(btn_row)

        self.refresh_from_model()
        
        # v0.0.20.40: VU Meter Updates (30 FPS — Pro-DAW-quality refresh)
        self._track_idx = None  # Will be set by MixerPanel
        self._meter_timer = QTimer(self)
        self._meter_timer.timeout.connect(self._update_vu_meter)
        self._meter_timer.start(33)  # 33ms ≈ 30 FPS

    # ---- Model sync

    def _track(self):
        return next(
            (t for t in self.project.ctx.project.tracks
             if t.id == self.track_id), None)

    def refresh_from_model(self) -> None:
        t = self._track()
        if not t:
            return

        self.lbl_name.setText(f"{t.name}")
        self.lbl_name.setToolTip(f"{t.name} [{t.kind}]")

        self.cmb_mode.blockSignals(True)
        self.cmb_mode.setCurrentText(getattr(t, "automation_mode", "off"))
        self.cmb_mode.blockSignals(False)

        # Volume: 0.0-1.0 → 0-127
        vol = float(getattr(t, "volume", 0.8))
        self.sld_vol.blockSignals(True)
        self.sld_vol.setValue(int(round(vol * 127.0)))
        self.sld_vol.blockSignals(False)

        # Pan: -1.0..+1.0 → -100..+100
        pan = float(getattr(t, "pan", 0.0))
        self.sld_pan.blockSignals(True)
        self.sld_pan.setValue(int(round(pan * 100.0)))
        self.sld_pan.blockSignals(False)

        # Mute / Solo
        self.btn_mute.blockSignals(True)
        self.btn_mute.setChecked(bool(getattr(t, "muted", False)))
        self.btn_mute.blockSignals(False)

        self.btn_solo.blockSignals(True)
        self.btn_solo.setChecked(bool(getattr(t, "solo", False)))
        self.btn_solo.blockSignals(False)

        self._update_db_label(vol)
        self._sync_rt_params()

    # ---- RT param sync

    def _sync_rt_params(self) -> None:
        """Push current values into RTParamStore + HybridBridge for real-time audio."""
        t = self._track()
        if not t:
            return
        vol = float(getattr(t, "volume", 0.8))
        pan = float(getattr(t, "pan", 0.0))

        # Master track → master params
        if getattr(t, "kind", "") == "master":
            if self.audio_engine:
                self.audio_engine.set_master_volume(vol)
                self.audio_engine.set_master_pan(pan)
            if self.rt_params:
                self.rt_params.set_param("master:vol", vol)
                self.rt_params.set_param("master:pan", pan)
        else:
            # NEW v0.0.20.37: Write to atomic dicts (LIKE MASTER!)
            if self.audio_engine and hasattr(self.audio_engine, 'set_track_volume'):
                try:
                    self.audio_engine.set_track_volume(self.track_id, vol)
                    self.audio_engine.set_track_pan(self.track_id, pan)
                    self.audio_engine.set_track_mute(self.track_id, bool(getattr(t, "muted", False)))
                    self.audio_engine.set_track_solo(self.track_id, bool(getattr(t, "solo", False)))
                except Exception:
                    pass
            # Legacy: Per-track RT params
            if self.rt_params:
                self.rt_params.set_track_vol(self.track_id, vol)
                self.rt_params.set_track_pan(self.track_id, pan)
                self.rt_params.set_track_mute(
                    self.track_id, bool(getattr(t, "muted", False)))
                self.rt_params.set_track_solo(
                    self.track_id, bool(getattr(t, "solo", False)))
            # v0.0.20.14: Per-track via lock-free ring buffer
            if self.hybrid_bridge:
                try:
                    self.hybrid_bridge.set_track_volume(self.track_id, vol)
                    self.hybrid_bridge.set_track_pan(self.track_id, pan)
                    self.hybrid_bridge.set_track_mute(
                        self.track_id, bool(getattr(t, "muted", False)))
                    self.hybrid_bridge.set_track_solo(
                        self.track_id, bool(getattr(t, "solo", False)))
                except Exception:
                    pass

    # ---- UI callbacks

    def _on_vol(self, v: int) -> None:
        t = self._track()
        if not t:
            return
        vol = max(0.0, min(1.0, float(v) / 127.0))
        t.volume = vol
        self._update_db_label(vol)

        # Live RT param update
        if getattr(t, "kind", "") == "master":
            if self.audio_engine:
                self.audio_engine.set_master_volume(vol)
            if self.rt_params:
                self.rt_params.set_param("master:vol", vol)
        else:
            # NEW v0.0.20.33: Write to atomic dict (additional channel, SAFE!)
            if self.audio_engine and hasattr(self.audio_engine, 'set_track_volume'):
                try:
                    self.audio_engine.set_track_volume(self.track_id, vol)
                except Exception:
                    pass
            # Legacy channels (keep for compatibility)
            if self.rt_params:
                self.rt_params.set_track_vol(self.track_id, vol)
            # v0.0.20.14: lock-free ring
            if self.hybrid_bridge:
                try:
                    self.hybrid_bridge.set_track_volume(self.track_id, vol)
                except Exception:
                    pass
        # No project_updated during drag (performance)

    def _on_pan(self, v: int) -> None:
        t = self._track()
        if not t:
            return
        pan = max(-1.0, min(1.0, float(v) / 100.0))
        t.pan = pan

        if getattr(t, "kind", "") == "master":
            if self.audio_engine:
                self.audio_engine.set_master_pan(pan)
            if self.rt_params:
                self.rt_params.set_param("master:pan", pan)
        else:
            # NEW v0.0.20.33: Write to atomic dict (SAFE!)
            if self.audio_engine and hasattr(self.audio_engine, 'set_track_pan'):
                try:
                    self.audio_engine.set_track_pan(self.track_id, pan)
                except Exception:
                    pass
            # Legacy channels
            if self.rt_params:
                self.rt_params.set_track_pan(self.track_id, pan)
            # v0.0.20.14: lock-free ring
            if self.hybrid_bridge:
                try:
                    self.hybrid_bridge.set_track_pan(self.track_id, pan)
                except Exception:
                    pass

    def _on_mute(self, checked: bool) -> None:
        t = self._track()
        if not t:
            return
        t.muted = bool(checked)
        # NEW v0.0.20.33: Write to atomic dict (SAFE!)
        if self.audio_engine and hasattr(self.audio_engine, 'set_track_mute'):
            try:
                self.audio_engine.set_track_mute(self.track_id, checked)
            except Exception:
                pass
        # Legacy channels
        if self.rt_params:
            self.rt_params.set_track_mute(self.track_id, checked)
        # v0.0.20.14: lock-free ring
        if self.hybrid_bridge:
            try:
                self.hybrid_bridge.set_track_mute(self.track_id, checked)
            except Exception:
                pass

    def _on_solo(self, checked: bool) -> None:
        t = self._track()
        if not t:
            return
        t.solo = bool(checked)
        # NEW v0.0.20.33: Write to atomic dict (SAFE!)
        if self.audio_engine and hasattr(self.audio_engine, 'set_track_solo'):
            try:
                self.audio_engine.set_track_solo(self.track_id, checked)
            except Exception:
                pass
        # Legacy channels
        if self.rt_params:
            self.rt_params.set_track_solo(self.track_id, checked)
        # v0.0.20.14: lock-free ring
        if self.hybrid_bridge:
            try:
                self.hybrid_bridge.set_track_solo(self.track_id, checked)
            except Exception:
                pass

    def _on_mode(self, mode: str) -> None:
        t = self._track()
        if not t:
            return
        t.automation_mode = str(mode)
        self.project.project_updated.emit()

    # v0.0.20.397 — MIDI Learn context menu for mixer controls
    def set_midi_mapping_service(self, svc) -> None:
        """Inject MidiMappingService reference."""
        self._midi_mapping_service = svc

    def _midi_learn_menu(self, pos, param_name: str, widget) -> None:
        """Show MIDI Learn context menu for a mixer control."""
        try:
            from PyQt6.QtWidgets import QMenu
            menu = QMenu(self)
            svc = self._midi_mapping_service

            if svc is not None:
                existing = svc.get_mapping_for_param(self.track_id, param_name)
                if existing:
                    cc_info = f"CC{existing.get('control', '?')} ch{existing.get('channel', 0)}"
                    a_info = menu.addAction(f"🎹 Mapped: {cc_info}")
                    a_info.setEnabled(False)
                    a_remove = menu.addAction("🎹 MIDI Mapping entfernen")
                    a_remove.triggered.connect(
                        lambda _=False, _tid=self.track_id, _p=param_name: svc.remove_mappings_for_param(_tid, _p)
                    )
                else:
                    a_learn = menu.addAction(f"🎹 MIDI Learn ({param_name.capitalize()})")
                    is_toggle = param_name in ("mute", "solo")
                    min_val = -1.0 if param_name == "pan" else 0.0
                    max_val = 1.0
                    a_learn.triggered.connect(
                        lambda _=False, _tid=self.track_id, _p=param_name, _mn=min_val, _mx=max_val, _t=is_toggle:
                            self._start_midi_learn(_tid, _p, _mn, _mx, _t)
                    )
            else:
                a_na = menu.addAction(f"🎹 MIDI Learn ({param_name.capitalize()})")
                a_na.setEnabled(False)
                a_na.setToolTip("MIDI-Service nicht verfügbar")

            menu.addSeparator()
            a_mapping = menu.addAction("🎛️ MIDI Mapping Dialog öffnen…")
            a_mapping.triggered.connect(self._open_midi_mapping_dialog)

            menu.exec(widget.mapToGlobal(pos))
        except Exception:
            pass

    def _open_midi_mapping_dialog(self) -> None:
        """Open the MIDI Mapping dialog from the menu bar."""
        try:
            mw = self.window()
            if mw and hasattr(mw, "_show_midi_mapping"):
                mw._show_midi_mapping()
        except Exception:
            pass

    def _start_midi_learn(self, track_id: str, param: str, min_val: float, max_val: float, is_toggle: bool) -> None:
        try:
            svc = self._midi_mapping_service
            if svc is None:
                return
            from pydaw.services.midi_mapping_service import MappingTarget
            target = MappingTarget(
                track_id=track_id,
                param=param,
                min_val=min_val,
                max_val=max_val,
                is_toggle=is_toggle,
            )
            svc.start_learn(target)
        except Exception:
            pass

    def _rename_track(self) -> None:
        t = self._track()
        if not t or t.kind == "master":
            return
        new_name, ok = QInputDialog.getText(
            self, "Track umbenennen",
            f"Neuer Name für '{t.name}':", text=t.name)
        if ok and new_name.strip():
            try:
                self.project.rename_track(t.id, new_name.strip())
            except Exception:
                pass

    def _update_db_label(self, vol: float) -> None:
        if vol <= 0.001:
            self.lbl_db.setText("-∞ dB")
        else:
            db = 20.0 * math.log10(max(1e-10, vol))
            self.lbl_db.setText(f"{db:+.1f} dB")
    
    def _update_vu_meter(self) -> None:
        """Update VU meter (30 FPS, GUI thread).

        v0.0.20.41: Direct peak path (most reliable) + fallback chain.
        Sources (in priority order):
        1. AudioEngine._direct_peaks (written directly from audio callback)
        2. HybridEngineBridge → TrackMeterRing
        3. HybridEngineBridge → read_track_peak() / read_master_peak()
        4. AudioEngine.read_track_peak() / read_master_peak()
        """
        try:
            t = self._track()
            if t is None:
                return

            is_master = str(getattr(t, "kind", "")) == "master"
            l, r = 0.0, 0.0
            got_data = False

            # --- Source 1: Direct peaks (v0.0.20.41 — most reliable)
            ae = self.audio_engine
            if ae is not None and hasattr(ae, "read_direct_track_peak"):
                try:
                    if is_master:
                        l, r = ae.read_master_peak()
                        got_data = (l > 0.0001 or r > 0.0001)
                    else:
                        l, r = ae.read_direct_track_peak(self.track_id)
                        got_data = (l > 0.0001 or r > 0.0001)
                except Exception:
                    pass

            # --- Source 2: Hybrid bridge (fallback)
            if not got_data:
                hb = self.hybrid_bridge
                if hb is not None:
                    try:
                        if is_master:
                            l, r = hb.read_master_peak()
                            got_data = True
                        elif self._track_idx is not None:
                            cb = getattr(hb, "callback", None)
                            if cb is not None:
                                meter = cb.get_track_meter(int(self._track_idx))
                                l, r = meter.read_and_decay()
                                got_data = True
                    except Exception:
                        pass

                    # Source 3: Bridge-level read_track_peak
                    if not got_data and not is_master:
                        try:
                            l, r = hb.read_track_peak(self.track_id)
                            got_data = True
                        except Exception:
                            pass

            # --- Source 4: AudioEngine helper (legacy / non-hybrid)
            if not got_data:
                if ae is not None:
                    try:
                        if is_master and hasattr(ae, "read_master_peak"):
                            l, r = ae.read_master_peak()
                            got_data = True
                        elif hasattr(ae, "read_track_peak"):
                            l, r = ae.read_track_peak(self.track_id)
                            got_data = True
                    except Exception:
                        pass

            if got_data:
                self.vu.set_levels(float(l), float(r))

        except Exception:
            # Fail silently - never break UI update loop
            pass


# ---- Mixer Panel

class MixerPanel(QWidget):
    """Pro-DAW-Style horizontal scrolling mixer with vertical fader strips."""

    def __init__(self, project: ProjectService, audio_engine=None,
                 rt_params=None, hybrid_bridge=None, parent=None):
        super().__init__(parent)
        self.project = project
        self.audio_engine = audio_engine
        self.rt_params = rt_params
        self.hybrid_bridge = hybrid_bridge  # v0.0.20.14

        # v0.0.20.28: Auto-wire HybridEngineBridge from AudioEngine when not explicitly provided.
        if self.hybrid_bridge is None and self.audio_engine is not None:
            try:
                hb = getattr(self.audio_engine, "_hybrid_bridge", None)
                if hb is None:
                    hb = getattr(self.audio_engine, "hybrid_bridge", None)
                if hb is not None:
                    self.hybrid_bridge = hb
            except Exception:
                pass
        self._strips: dict[str, _MixerStrip] = {}
        self._midi_mapping_service = None  # v0.0.20.397

        self._build_ui()
        self.project.project_updated.connect(self.refresh)
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 4, 6, 4)
        layout.setSpacing(4)

        # Header
        header = QHBoxLayout()
        header.setSpacing(6)
        lbl = QLabel("MIXER")
        lbl.setStyleSheet("font-weight: bold; font-size: 11px;")
        header.addWidget(lbl)

        self.btn_add = QPushButton("+ Add")
        self.btn_add.setFixedWidth(70)
        self.btn_add.clicked.connect(self._show_add_menu)
        header.addWidget(self.btn_add)

        self.btn_remove = QPushButton("− Remove")
        self.btn_remove.setFixedWidth(80)
        self.btn_remove.clicked.connect(self._remove_selected_track)
        header.addWidget(self.btn_remove)

        header.addStretch(1)
        layout.addLayout(header)

        # Scroll area with horizontal strip layout
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        layout.addWidget(self.scroll, 1)

        self.inner = QWidget()
        self.inner_layout = QHBoxLayout(self.inner)
        self.inner_layout.setContentsMargins(0, 0, 0, 0)
        self.inner_layout.setSpacing(2)
        self.inner_layout.addStretch(1)
        self.scroll.setWidget(self.inner)

        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    # v0.0.20.397 — MIDI Learn integration
    def set_midi_mapping_service(self, svc) -> None:
        """Inject MidiMappingService into mixer and all strips."""
        self._midi_mapping_service = svc
        for strip in self._strips.values():
            try:
                strip.set_midi_mapping_service(svc)
            except Exception:
                pass

    def _show_add_menu(self) -> None:
        menu = QMenu(self)
        a_audio = menu.addAction("Audio-Spur")
        a_inst = menu.addAction("Instrumenten-Spur")
        a_bus = menu.addAction("FX/Bus-Spur")
        action = menu.exec(
            self.btn_add.mapToGlobal(self.btn_add.rect().bottomLeft()))
        if action == a_audio:
            self.project.add_track("audio")
        elif action == a_inst:
            self.project.add_track("instrument")
        elif action == a_bus:
            self.project.add_track("bus")

    def _remove_selected_track(self) -> None:
        tid = getattr(self.project, "selected_track_id", "") or ""
        if not tid:
            return
        trk = next(
            (t for t in self.project.ctx.project.tracks
             if t.id == tid), None)
        if trk and getattr(trk, "kind", "") == "master":
            return
        try:
            self.project.delete_track(tid)
        except Exception:
            pass

    def keyPressEvent(self, event) -> None:
        if event.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            self._remove_selected_track()
            event.accept()
            return
        super().keyPressEvent(event)

    def refresh(self) -> None:
        existing_ids = {t.id for t in self.project.ctx.project.tracks}

        # v0.0.20.25: Keep HybridEngineBridge track indices aligned with project order
        if self.hybrid_bridge is not None and hasattr(self.hybrid_bridge, "set_track_index_map"):
            try:
                mapping = {t.id: int(i) for i, t in enumerate(self.project.ctx.project.tracks)}
                self.hybrid_bridge.set_track_index_map(mapping)
            except Exception:
                pass

        # Remove strips for deleted tracks
        for tid in list(self._strips.keys()):
            if tid not in existing_ids:
                w = self._strips.pop(tid)
                w.deleteLater()

        # Clear layout (except stretch)
        while self.inner_layout.count() > 1:
            item = self.inner_layout.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None)

        # Rebuild strips
        for track_idx, trk in enumerate(self.project.ctx.project.tracks):
            strip = self._strips.get(trk.id)
            if strip is None:
                strip = _MixerStrip(
                    self.project, trk.id, self.audio_engine,
                    self.rt_params, self.hybrid_bridge)
                # v0.0.20.397 — Inject MIDI Mapping Service for MIDI Learn
                if hasattr(self, "_midi_mapping_service") and self._midi_mapping_service is not None:
                    strip.set_midi_mapping_service(self._midi_mapping_service)
                self._strips[trk.id] = strip
            
            # v0.0.20.25: Deterministic track index mapping (matches HybridEngineBridge/ArrangementState)
            if self.hybrid_bridge is not None and hasattr(self.hybrid_bridge, "get_track_idx"):
                try:
                    strip._track_idx = int(self.hybrid_bridge.get_track_idx(trk.id))
                except Exception:
                    strip._track_idx = track_idx
            else:
                strip._track_idx = track_idx
            
            strip.refresh_from_model()
            self.inner_layout.insertWidget(
                self.inner_layout.count() - 1, strip)


# ---- Library Panel (placeholder — kept for compatibility)

class LibraryPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)
        layout.addWidget(QLabel("Bibliothek/Browser (Platzhalter)"))
        layout.addWidget(QLabel(
            "Hier kommen später: Samples, Plugins, Presets, Medienpool…"))
        layout.addStretch(1)
