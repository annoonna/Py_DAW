"""Bitwig-Style Browser with Tabs for PyDAW.

Professional browser system with tabs for:
- Samples (external audio files)
- Instruments (user-developed instruments)
- Effects (user-developed effects)
- Plugins (VST/LV2 plugins)
- Presets (sound presets)
"""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QTabWidget,
    QLabel,
)

from .sample_browser import SampleBrowserWidget


class BitwigStyleBrowser(QWidget):
    """Professional browser with tabs like Bitwig Studio.
    
    Tabs:
    - Samples: Browse external audio files
    - Instruments: User-developed instruments (placeholder)
    - Effects: User-developed effects (placeholder)
    - Plugins: VST/LV2 plugins (placeholder)
    - Presets: Sound presets (placeholder)
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()
    
    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Tab Widget (Bitwig-Style!)
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.TabPosition.North)
        
        # Tab 1: Samples (Functional!)
        self.samples_tab = SampleBrowserWidget()
        self.tabs.addTab(self.samples_tab, "🎵 Samples")
        
        # Tab 2: Instruments (Placeholder für User)
        self.instruments_tab = self._create_placeholder_tab(
            "Instruments",
            "🎹 Eigene entwickelte Instrumente\n\n"
            "Hier kommen später:\n"
            "• Python-basierte Synths\n"
            "• MIDI → Audio Processing\n"
            "• Modulare Instrumente\n"
            "• Parameter UI\n\n"
            "Status: PLACEHOLDER - Bereit für Entwicklung! 🚀"
        )
        self.tabs.addTab(self.instruments_tab, "🎹 Instruments")
        
        # Tab 3: Effects (Placeholder für User)
        self.effects_tab = self._create_placeholder_tab(
            "Effects",
            "🎚️ Eigene entwickelte Effects\n\n"
            "Hier kommen später:\n"
            "• Audio → Audio DSP\n"
            "• Real-time Processing\n"
            "• Modulare Effects\n"
            "• Parameter UI\n\n"
            "Status: PLACEHOLDER - Bereit für Entwicklung! 🚀"
        )
        self.tabs.addTab(self.effects_tab, "🎚️ Effects")
        
        # Tab 4: Plugins (Placeholder)
        self.plugins_tab = self._create_placeholder_tab(
            "Plugins",
            "🔌 VST/LV2 Plugins\n\n"
            "Hier kommen später:\n"
            "• VST3 Scanner\n"
            "• LV2 Scanner\n"
            "• Plugin Validation\n"
            "• Preset Management\n\n"
            "Status: PLACEHOLDER - In Entwicklung! ⏳"
        )
        self.tabs.addTab(self.plugins_tab, "🔌 Plugins")
        
        # Tab 5: Presets (Placeholder)
        self.presets_tab = self._create_placeholder_tab(
            "Presets",
            "💾 Sound Presets\n\n"
            "Hier kommen später:\n"
            "• Preset Browser\n"
            "• Kategorie-System\n"
            "• Favoriten\n"
            "• User Presets\n\n"
            "Status: PLACEHOLDER - In Entwicklung! ⏳"
        )
        self.tabs.addTab(self.presets_tab, "💾 Presets")
        
        layout.addWidget(self.tabs)
    
    def _create_placeholder_tab(self, title: str, info_text: str) -> QWidget:
        """Create a placeholder tab with info text."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Title
        title_label = QLabel(title)
        title_label.setStyleSheet("QLabel { font-size: 18px; font-weight: bold; }")
        layout.addWidget(title_label)
        
        # Info
        info_label = QLabel(info_text)
        info_label.setStyleSheet("QLabel { color: #888; font-size: 12px; }")
        info_label.setWordWrap(True)
        layout.addWidget(info_label)
        
        layout.addStretch(1)
        return widget
