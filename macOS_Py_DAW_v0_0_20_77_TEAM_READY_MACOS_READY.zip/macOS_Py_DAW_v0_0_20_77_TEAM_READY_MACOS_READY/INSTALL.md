# 📦 ChronoScaleStudio (Py_DAW) Installation

## System Requirements
- **OS:** Linux **oder** macOS
- **Python:** 3.10+ (getestet mit Python 3.13)
- **Audio:**
  - Linux: PipeWire-JACK/JACK (Routing via qpwgraph möglich)
  - macOS: CoreAudio via `sounddevice` (Default)

## Quick Install (Linux/macOS)

```bash
# 1) Unzip
unzip Py_DAW_v0_0_20_XX_TEAM_READY.zip
cd Py_DAW_v0_0_20_XX_TEAM_READY

# 2) Virtual Environment
python3 -m venv myenv
source myenv/bin/activate

# 3) Install Dependencies
python3 install.py

# 4) Start
python3 main.py
```

> Hinweis: `install.py` installiert nur Python-Pakete. System-Libraries (PortAudio, libsndfile, fluidsynth, JACK/PipeWire) müssen über das OS installiert werden.

## macOS (CoreAudio + Metal Default)

### System Dependencies (Homebrew)
```bash
brew install portaudio libsndfile fluidsynth
```

Optional (nur wenn du JACK auf macOS nutzen willst):
```bash
brew install jack
```

### Audio Backend
- Standard: **sounddevice** → CoreAudio (keine extra Konfiguration nötig)
- Im Programm: **Menü → Einstellungen → Audio** (Backend/Device/SR/Buffer)

### Graphics Backend
- Default auf macOS: **Metal** (Qt RHI) — kann per Env überschrieben werden:
```bash
PYDAW_GFX_BACKEND=opengl python3 main.py
PYDAW_GFX_BACKEND=software python3 main.py
```

## Linux (PipeWire-JACK / JACK)

### PipeWire-JACK
```bash
sudo apt update
sudo apt install pipewire-jack
```

### qpwgraph (Optional)
```bash
sudo apt install qpwgraph
qpwgraph &
```

## Troubleshooting

### Vulkan (Linux) - System packages

Wenn du unter Linux Vulkan als Default-Backend nutzen willst (v0.0.20.18),
installiere die System-Pakete:

```bash
sudo apt update
sudo apt install libvulkan1 mesa-vulkan-drivers vulkan-tools
```

Test:

```bash
vulkaninfo | head
```

Override (z. B. wenn dein Treiber kein Vulkan kann):

```bash
PYDAW_GFX_BACKEND=opengl python3 main.py
```

### "No audio devices found"
```bash
# Check JACK
jack_lsp

# Or PipeWire
pw-cli ls
```

### "ModuleNotFoundError"
```bash
pip install --upgrade -r requirements.txt
```

## Done!
Run: `python3 main.py`
