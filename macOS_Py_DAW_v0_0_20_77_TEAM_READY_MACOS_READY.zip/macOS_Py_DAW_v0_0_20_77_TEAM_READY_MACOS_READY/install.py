"""Installer helper for Py_DAW.

Usage:
    python3 install.py

It will:
- warn if you're not inside a virtual environment
- install/upgrade pip
- install requirements.txt

Note:
- JACK/PipeWire system components are not installed here (distro packages).
"""

from __future__ import annotations

import os
import sys
import subprocess
import platform
import shutil
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def main() -> int:
    here = Path(__file__).resolve().parent
    req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        print("      Empfehlung: python3 -m venv myenv && source myenv/bin/activate")

    py = sys.executable

    # --- OS prerequisites hinting (best effort, no auto-install of system packages)
    sys_name = platform.system().lower()
    if sys_name == "darwin":
        print("\nmacOS detected: Default Audio backend ist CoreAudio via sounddevice (PortAudio).")
        brew = shutil.which("brew")
        if not brew:
            print("WARN: Homebrew (brew) nicht gefunden.")
            print("      Für Audio/SF2 brauchst du System-Libs, z.B. portaudio/libsndfile/fluidsynth.")
        else:
            print("Hinweis: Stelle sicher, dass folgende Pakete installiert sind:")
            print("  brew install portaudio libsndfile fluidsynth")
        if not shutil.which("fluidsynth"):
            print("WARN: 'fluidsynth' nicht gefunden → SF2 Offline-Render wird fehlschlagen.")
            print("      (macOS) brew install fluidsynth")
        print("Graphics: Default ist Metal (Qt RHI). Override: PYDAW_GFX_BACKEND=opengl|software")
    elif sys_name == "linux":
        print("\nLinux detected: Default Audio backend bevorzugt JACK (PipeWire-JACK), Fallback sounddevice.")
        print("Hinweis: PipeWire-JACK/JACK sind Systempakete (apt/dnf/pacman), nicht pip.")

    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    _run([py, "-m", "pip", "install", "-r", str(req)])

    print("\nOK. Starte danach mit: python3 main.py")
    print("Optional: Audio/MIDI Abhängigkeiten können Systempakete erfordern (PipeWire-JACK/JACK/qpwgraph).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
