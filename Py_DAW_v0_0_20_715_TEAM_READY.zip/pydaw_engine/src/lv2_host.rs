// ============================================================================
// LV2 Plugin Host — Phase P7C
// ============================================================================
//
// Hosts LV2 plugins using lilv (C library) via FFI.
//
// Architecture:
//   1. Scanner: lilv_world_load_all() → iterate plugins
//   2. Instance: lilv_plugin_instantiate() → connect ports → activate
//   3. Process: lilv_instance_run(frames) — real-time, zero-alloc
//   4. State: LV2_State_Interface save/restore
//
// LV2 is a Linux-native plugin format:
//   - Turtle/RDF metadata → rich discovery without loading .so
//   - Port-based: audio, control, MIDI (atom), CV
//   - Extensions via URIs: state, worker, options, resize-port
//
// Dependencies:
//   - lilv-0 (C library): `apt install liblilv-dev`
//   - Link: -llilv-0 (via pkg-config or manual link)
//
// v0.0.20.713 — Phase P7C (Claude Opus 4.6, 2026-03-21)
// ============================================================================

use std::collections::HashMap;
use std::path::PathBuf;

use log::{debug, info};
use serde::{Deserialize, Serialize};

use crate::audio_graph::AudioBuffer;
use crate::plugin_host::AudioPlugin;

// ---------------------------------------------------------------------------
// Lilv FFI Type Stubs
// ---------------------------------------------------------------------------
//
// When `liblilv-dev` is available and linked, replace these with
// actual C struct pointers from lilv/lilv.h.
//
// The real lilv API uses opaque pointers:
//   LilvWorld*, LilvPlugin*, LilvInstance*, LilvNode*, etc.

// Opaque pointer types (replace with real FFI when linking lilv)
#[allow(non_camel_case_types)]
type LilvWorld = std::ffi::c_void;
#[allow(non_camel_case_types)]
type LilvPlugin = std::ffi::c_void;
#[allow(non_camel_case_types)]
type LilvInstance = std::ffi::c_void;
#[allow(non_camel_case_types)]
type LilvNode = std::ffi::c_void;
#[allow(non_camel_case_types)]
type LilvPlugins = std::ffi::c_void;

// LV2 Feature array (NULL-terminated array of LV2_Feature*)
#[repr(C)]
#[allow(non_camel_case_types)]
struct LV2_Feature {
    uri: *const std::ffi::c_char,
    data: *mut std::ffi::c_void,
}

// ---------------------------------------------------------------------------
// LV2 Port Types
// ---------------------------------------------------------------------------

/// LV2 port direction and type.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Lv2PortKind {
    AudioInput,
    AudioOutput,
    ControlInput,
    ControlOutput,
    AtomInput,   // MIDI + other events
    AtomOutput,
    CvInput,     // Control Voltage (audio-rate control)
    CvOutput,
    Unknown,
}

/// Metadata for a single LV2 port.
#[derive(Debug, Clone)]
pub struct Lv2PortInfo {
    pub index: u32,
    pub symbol: String,
    pub name: String,
    pub kind: Lv2PortKind,
    pub default_value: f32,
    pub min_value: f32,
    pub max_value: f32,
    pub is_logarithmic: bool,
    pub is_integer: bool,
    pub is_toggled: bool,
}

// ---------------------------------------------------------------------------
// LV2 Plugin Info (from scanner)
// ---------------------------------------------------------------------------

/// Metadata for a scanned LV2 plugin.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Lv2PluginInfo {
    /// LV2 URI (unique identifier, e.g. "http://calf.sourceforge.net/plugins/Compressor")
    pub uri: String,
    /// Human-readable name
    pub name: String,
    /// Author/Vendor
    pub author: String,
    /// Plugin class (e.g. "CompressorPlugin", "ReverbPlugin")
    pub class_label: String,
    /// Bundle path on disk
    pub bundle_path: PathBuf,
    /// Number of audio input ports
    pub audio_inputs: u32,
    /// Number of audio output ports
    pub audio_outputs: u32,
    /// Number of control ports
    pub control_ports: u32,
    /// Has MIDI input (atom port)
    pub has_midi_input: bool,
    /// Required features (URIs)
    pub required_features: Vec<String>,
    /// Optional features (URIs)
    pub optional_features: Vec<String>,
}

/// LV2 scan result.
#[derive(Debug, Default)]
pub struct Lv2ScanResult {
    pub plugins: Vec<Lv2PluginInfo>,
    pub errors: Vec<String>,
    pub scan_time_ms: u64,
}

// ---------------------------------------------------------------------------
// LV2 Plugin Scanner
// ---------------------------------------------------------------------------

/// Scan all installed LV2 plugins using lilv.
///
/// Requires liblilv-0 to be installed:
///   apt install liblilv-dev lilv-utils
///
/// Without lilv: returns an empty scan result.
pub fn scan_lv2_plugins() -> Lv2ScanResult {
    let start = std::time::Instant::now();
    let mut result = Lv2ScanResult::default();

    // TODO (P7C FFI): Real implementation:
    //
    // unsafe {
    //     let world = lilv_world_new();
    //     if world.is_null() { return result; }
    //     lilv_world_load_all(world);
    //
    //     let plugins = lilv_world_get_all_plugins(world);
    //     let iter = lilv_plugins_begin(plugins);
    //     while !lilv_plugins_is_end(plugins, iter) {
    //         let plugin = lilv_plugins_get(plugins, iter);
    //         // Extract: URI, name, class, ports, features
    //         // ...
    //         iter = lilv_plugins_next(plugins, iter);
    //     }
    //
    //     lilv_world_free(world);
    // }

    // Stub: scan common LV2 directories and list bundles
    for search_dir in lv2_search_paths() {
        if !search_dir.exists() {
            continue;
        }
        debug!("Scanning LV2 directory: {}", search_dir.display());
        scan_lv2_directory(&search_dir, &mut result);
    }

    result.scan_time_ms = start.elapsed().as_millis() as u64;
    info!(
        "LV2 scan complete: {} plugins found in {}ms",
        result.plugins.len(),
        result.scan_time_ms
    );
    result
}

/// Standard LV2 search paths (Linux).
pub fn lv2_search_paths() -> Vec<PathBuf> {
    let mut paths = Vec::new();

    if let Some(home) = std::env::var_os("HOME") {
        let home = PathBuf::from(home);
        paths.push(home.join(".lv2"));
    }

    paths.push(PathBuf::from("/usr/lib/lv2"));
    paths.push(PathBuf::from("/usr/local/lib/lv2"));
    paths.push(PathBuf::from("/usr/lib/x86_64-linux-gnu/lv2"));

    if let Some(extra) = std::env::var_os("LV2_PATH") {
        for p in std::env::split_paths(&extra) {
            paths.push(p);
        }
    }

    paths
}

fn scan_lv2_directory(dir: &std::path::Path, result: &mut Lv2ScanResult) {
    let entries = match std::fs::read_dir(dir) {
        Ok(e) => e,
        Err(e) => {
            result.errors.push(format!("Cannot read {}: {}", dir.display(), e));
            return;
        }
    };

    for entry in entries.flatten() {
        let path = entry.path();
        // LV2 bundles are directories ending with .lv2
        if path.is_dir() {
            if let Some(ext) = path.extension() {
                if ext.to_ascii_lowercase() == "lv2" {
                    match probe_lv2_bundle(&path) {
                        Ok(info) => result.plugins.push(info),
                        Err(e) => result.errors.push(
                            format!("Failed to probe {}: {}", path.display(), e)),
                    }
                }
            }
        }
    }
}

/// Probe an LV2 bundle directory for plugin metadata.
///
/// A proper implementation would parse the Turtle (.ttl) manifest.
/// This stub extracts the name from the directory name.
fn probe_lv2_bundle(bundle_path: &std::path::Path) -> Result<Lv2PluginInfo, String> {
    let name = bundle_path
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("Unknown")
        .to_string();

    // Check for manifest.ttl (required in every LV2 bundle)
    let manifest = bundle_path.join("manifest.ttl");
    if !manifest.exists() {
        return Err(format!("No manifest.ttl in {}", bundle_path.display()));
    }

    // TODO (P7C): Parse manifest.ttl for plugin URI + class
    // The manifest contains lines like:
    //   <http://example.org/myPlugin> a lv2:Plugin ;
    //       lv2:binary <myPlugin.so> ;
    //       rdfs:seeAlso <myPlugin.ttl> .

    Ok(Lv2PluginInfo {
        uri: format!("urn:lv2:{}", name.to_lowercase()),
        name: name.clone(),
        author: String::new(),
        class_label: "Plugin".to_string(),
        bundle_path: bundle_path.to_path_buf(),
        audio_inputs: 2,
        audio_outputs: 2,
        control_ports: 0,
        has_midi_input: false,
        required_features: Vec::new(),
        optional_features: Vec::new(),
    })
}

// ---------------------------------------------------------------------------
// LV2 Plugin Instance
// ---------------------------------------------------------------------------

/// A loaded LV2 plugin instance.
///
/// In the full FFI implementation, this wraps:
///   - LilvInstance* (from lilv_plugin_instantiate)
///   - Port connections (audio in/out, control, atom)
///   - Feature array (URID map, options, worker)
///
/// Real-time processing goes through lilv_instance_run(frames).
pub struct Lv2Instance {
    info: Lv2PluginInfo,
    sample_rate: f64,
    max_block_size: u32,
    is_active: bool,
    is_processing: bool,

    /// Port metadata.
    ports: Vec<Lv2PortInfo>,

    /// Control port values (index → current value).
    control_values: HashMap<u32, f32>,

    /// Saved state (binary blob from LV2_State_Interface).
    saved_state: Vec<u8>,

    /// Plugin-reported latency in samples.
    latency: u32,

    // TODO (P7C FFI): Add these fields when linking lilv:
    // _lilv_instance: *mut LilvInstance,
    // _audio_in_bufs: Vec<*mut f32>,
    // _audio_out_bufs: Vec<*mut f32>,
    // _features: Vec<LV2_Feature>,
    // _urid_map: UridMap,
}

impl Lv2Instance {
    pub fn new(info: Lv2PluginInfo) -> Self {
        Self {
            info,
            sample_rate: 48000.0,
            max_block_size: 1024,
            is_active: false,
            is_processing: false,
            ports: Vec::new(),
            control_values: HashMap::new(),
            saved_state: Vec::new(),
            latency: 0,
        }
    }

    /// Initialize the plugin.
    ///
    /// Real implementation:
    /// 1. Build feature array (URID map, options, etc.)
    /// 2. lilv_plugin_instantiate(plugin, sample_rate, features)
    /// 3. Connect audio ports to pre-allocated buffers
    /// 4. Connect control ports to control_values
    /// 5. lilv_instance_activate()
    pub fn initialize(
        &mut self,
        sample_rate: f64,
        max_block_size: u32,
    ) -> Result<(), String> {
        self.sample_rate = sample_rate;
        self.max_block_size = max_block_size;

        // TODO (P7C FFI):
        // let features = build_features(&self.urid_map);
        // let instance = lilv_plugin_instantiate(
        //     self._lilv_plugin, sample_rate, features.as_ptr());
        // if instance.is_null() { return Err("instantiate failed"); }
        // connect_ports(instance, &self.ports, ...);
        // lilv_instance_activate(instance);

        self.is_active = true;
        info!(
            "LV2 initialized: {} @ {}Hz, block={}",
            self.info.name, sample_rate, max_block_size
        );
        Ok(())
    }

    /// Start processing.
    pub fn start_processing(&mut self) -> Result<(), String> {
        if !self.is_active {
            return Err("Plugin not active".to_string());
        }
        self.is_processing = true;
        Ok(())
    }

    /// Stop processing.
    pub fn stop_processing(&mut self) {
        self.is_processing = false;
    }

    /// Deactivate and release.
    pub fn terminate(&mut self) {
        self.is_processing = false;
        self.is_active = false;
        // TODO (P7C FFI):
        // lilv_instance_deactivate(self._lilv_instance);
        // lilv_instance_free(self._lilv_instance);
    }

    /// Set a control port value by symbol name.
    pub fn set_control(&mut self, symbol: &str, value: f32) {
        // Find port by symbol
        for port in &self.ports {
            if port.symbol == symbol && port.kind == Lv2PortKind::ControlInput {
                let clamped = value.clamp(port.min_value, port.max_value);
                self.control_values.insert(port.index, clamped);
                return;
            }
        }
    }

    /// Get a control port value by symbol name.
    pub fn get_control(&self, symbol: &str) -> Option<f32> {
        for port in &self.ports {
            if port.symbol == symbol {
                return self.control_values.get(&port.index).copied();
            }
        }
        None
    }
}

impl AudioPlugin for Lv2Instance {
    fn process(&mut self, _buffer: &mut AudioBuffer, sample_rate: u32) {
        if !self.is_processing {
            return;
        }
        let _ = sample_rate;

        // TODO (P7C FFI): Real implementation:
        //
        // 1. Copy input audio from buffer → _audio_in_bufs
        // 2. Update control port pointers from control_values
        // 3. lilv_instance_run(self._lilv_instance, buffer.frames)
        // 4. Copy output audio from _audio_out_bufs → buffer
        //
        // For now: passthrough (no modification to buffer)
    }

    fn id(&self) -> &str {
        &self.info.uri
    }

    fn name(&self) -> &str {
        &self.info.name
    }

    fn set_parameter(&mut self, index: u32, value: f64) {
        self.control_values.insert(index, value as f32);
    }

    fn get_parameter(&self, index: u32) -> f64 {
        self.control_values.get(&index).copied().unwrap_or(0.0) as f64
    }

    fn parameter_count(&self) -> u32 {
        self.ports
            .iter()
            .filter(|p| p.kind == Lv2PortKind::ControlInput)
            .count() as u32
    }

    fn parameter_name(&self, index: u32) -> String {
        self.ports
            .iter()
            .filter(|p| p.kind == Lv2PortKind::ControlInput)
            .nth(index as usize)
            .map(|p| p.name.clone())
            .unwrap_or_default()
    }

    fn save_state(&self) -> Vec<u8> {
        // TODO (P7C FFI): Use LV2_State_Interface.save()
        self.saved_state.clone()
    }

    fn load_state(&mut self, data: &[u8]) -> Result<(), String> {
        // TODO (P7C FFI): Use LV2_State_Interface.restore()
        self.saved_state = data.to_vec();
        Ok(())
    }

    fn latency_samples(&self) -> u32 {
        self.latency
    }
}

impl Drop for Lv2Instance {
    fn drop(&mut self) {
        self.terminate();
    }
}

// ---------------------------------------------------------------------------
// URID Map (needed by almost all LV2 plugins)
// ---------------------------------------------------------------------------

/// URID (URI-to-integer) map for LV2 plugins.
///
/// LV2 plugins communicate using URI strings mapped to integer IDs.
/// This map is shared between host and plugin instances.
///
/// Thread-safe: reads happen on audio thread, writes on main thread.
pub struct UridMap {
    uri_to_id: parking_lot::RwLock<HashMap<String, u32>>,
    id_to_uri: parking_lot::RwLock<Vec<String>>,
}

impl UridMap {
    pub fn new() -> Self {
        let mut map = Self {
            uri_to_id: parking_lot::RwLock::new(HashMap::new()),
            id_to_uri: parking_lot::RwLock::new(Vec::new()),
        };
        // Pre-register common LV2 URIs
        map.map_uri("http://lv2plug.in/ns/ext/atom#Blank");
        map.map_uri("http://lv2plug.in/ns/ext/atom#Bool");
        map.map_uri("http://lv2plug.in/ns/ext/atom#Float");
        map.map_uri("http://lv2plug.in/ns/ext/atom#Int");
        map.map_uri("http://lv2plug.in/ns/ext/atom#Long");
        map.map_uri("http://lv2plug.in/ns/ext/atom#String");
        map.map_uri("http://lv2plug.in/ns/ext/atom#Chunk");
        map.map_uri("http://lv2plug.in/ns/ext/atom#Sequence");
        map.map_uri("http://lv2plug.in/ns/ext/midi#MidiEvent");
        map.map_uri("http://lv2plug.in/ns/ext/patch#Set");
        map.map_uri("http://lv2plug.in/ns/ext/patch#Get");
        map.map_uri("http://lv2plug.in/ns/ext/state#StateChanged");
        map
    }

    /// Map a URI to a URID. Returns existing ID if already mapped.
    pub fn map_uri(&mut self, uri: &str) -> u32 {
        {
            let map = self.uri_to_id.read();
            if let Some(&id) = map.get(uri) {
                return id;
            }
        }
        // New URI — assign next ID
        let mut map = self.uri_to_id.write();
        let mut ids = self.id_to_uri.write();
        let id = ids.len() as u32 + 1; // URIDs start at 1 (0 = invalid)
        map.insert(uri.to_string(), id);
        ids.push(uri.to_string());
        id
    }

    /// Look up a URID → URI string.
    pub fn unmap_uri(&self, urid: u32) -> Option<String> {
        let ids = self.id_to_uri.read();
        if urid == 0 || urid as usize > ids.len() {
            return None;
        }
        Some(ids[(urid - 1) as usize].clone())
    }

    /// Look up URI → URID (read-only, audio-thread safe).
    pub fn get_urid(&self, uri: &str) -> Option<u32> {
        self.uri_to_id.read().get(uri).copied()
    }
}
