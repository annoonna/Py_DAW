"""Clip Launcher (v0.0.11).

v0.0.10:
- Quantized launch via LauncherService

v0.0.11:
- Quantize also applies to Slot DnD ("arm + launch"):
  drop a clip onto a slot -> assign + (quantized) launch
- Stop All optional playhead reset (checkbox)
"""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QSpinBox,
    QScrollArea,
    QGridLayout,
    QPushButton,
    QMenu,
    QComboBox,
    QToolButton,
    QCheckBox,
)
from PyQt6.QtCore import Qt, pyqtSignal, QPoint
from PyQt6.QtGui import QDrag
from PyQt6.QtCore import QMimeData

from pydaw.services.project_service import ProjectService
from pydaw.services.launcher_service import LauncherService


class SlotButton(QPushButton):
    """A slot button that supports drop + (Alt) drag."""

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self._drag_start: QPoint | None = None

    def dragEnterEvent(self, event):  # noqa: ANN001
        if event.mimeData().hasFormat("application/x-pydaw-clipid"):
            event.acceptProposedAction()
            return
        super().dragEnterEvent(event)

    def dropEvent(self, event):  # noqa: ANN001
        if event.mimeData().hasFormat("application/x-pydaw-clipid"):
            self.parent().slot_drop_requested.emit(self, event)  # type: ignore[attr-defined]
            event.acceptProposedAction()
            return
        super().dropEvent(event)

    def mousePressEvent(self, event):  # noqa: ANN001
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_start = event.pos()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):  # noqa: ANN001
        if (
            self._drag_start is not None
            and (event.buttons() & Qt.MouseButton.LeftButton)
            and (event.modifiers() & Qt.KeyboardModifier.AltModifier)
        ):
            if (event.pos() - self._drag_start).manhattanLength() >= 8:
                clip_id = str(self.property("clip_id") or "")
                if clip_id:
                    drag = QDrag(self)
                    md = QMimeData()
                    md.setData("application/x-pydaw-clipid", clip_id.encode("utf-8"))
                    drag.setMimeData(md)
                    drag.exec(Qt.DropAction.CopyAction)
                self._drag_start = None
                return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):  # noqa: ANN001
        self._drag_start = None
        super().mouseReleaseEvent(event)


class ClipLauncherPanel(QWidget):
    clip_activated = pyqtSignal(str)  # clip_id
    slot_drop_requested = pyqtSignal(object, object)  # (SlotButton, QDropEvent)

    def __init__(self, project: ProjectService, launcher: LauncherService, parent=None):
        super().__init__(parent)
        self.project = project
        self.launcher = launcher
        self.scene_count = 8

        self._build_ui()
        self._wire()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        header = QHBoxLayout()
        header.addWidget(QLabel("Clip Launcher (Scenes)"))

        header.addWidget(QLabel("Scenes:"))
        self.spin_scenes = QSpinBox()
        self.spin_scenes.setRange(1, 64)
        self.spin_scenes.setValue(self.scene_count)
        header.addWidget(self.spin_scenes)

        header.addSpacing(12)
        header.addWidget(QLabel("Quantize:"))
        self.cmb_quant = QComboBox()
        self.cmb_quant.addItems(["Off", "1 Beat", "1 Bar"])
        header.addWidget(self.cmb_quant)

        header.addSpacing(6)
        header.addWidget(QLabel("Mode:"))
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["Trigger", "Toggle", "Gate"])
        header.addWidget(self.cmb_mode)

        header.addSpacing(12)
        self.chk_reset = QCheckBox("Reset Playhead")
        self.chk_reset.setToolTip("Beim Stop All wird der Playhead auf 0 gesetzt.")
        header.addWidget(self.chk_reset)

        self.btn_stop_all = QPushButton("Stop All")
        header.addWidget(self.btn_stop_all)

        header.addStretch(1)

        self.lbl_sel = QLabel("Ausgewählter Clip: —")
        header.addWidget(self.lbl_sel)

        layout.addLayout(header)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        layout.addWidget(self.scroll, 1)

        self.inner = QWidget()
        self.grid = QGridLayout(self.inner)
        self.grid.setContentsMargins(6, 6, 6, 6)
        self.grid.setHorizontalSpacing(6)
        self.grid.setVerticalSpacing(6)

        self.scroll.setWidget(self.inner)

    def _wire(self) -> None:
        self.spin_scenes.valueChanged.connect(self._scenes_changed)
        self.project.project_updated.connect(self.refresh)
        self.project.active_clip_changed.connect(self._active_clip_changed)
        self.slot_drop_requested.connect(self._handle_slot_drop)

        self.cmb_quant.currentTextChanged.connect(self._launcher_settings_changed)
        self.cmb_mode.currentTextChanged.connect(self._launcher_settings_changed)

        self.btn_stop_all.clicked.connect(lambda: self.launcher.stop_all(reset_playhead=self.chk_reset.isChecked()))

    def _launcher_settings_changed(self) -> None:
        fn = getattr(self.project, 'set_launcher_settings', None)
        if callable(fn):
            fn(self.cmb_quant.currentText(), self.cmb_mode.currentText())
        else:
            # Fallback: persist directly on project model
            try:
                setattr(self.project.ctx.project, 'launcher_quantize', self.cmb_quant.currentText())
                setattr(self.project.ctx.project, 'launcher_mode', self.cmb_mode.currentText())
                self.project.project_updated.emit()
            except Exception:
                pass

    def _active_clip_changed(self, clip_id: str) -> None:
        if not clip_id:
            self.lbl_sel.setText("Ausgewählter Clip: —")
            return
        clip = next((c for c in self.project.ctx.project.clips if c.id == clip_id), None)
        self.lbl_sel.setText(f"Ausgewählter Clip: {clip.label}" if clip else "Ausgewählter Clip: —")

    def _scenes_changed(self, v: int) -> None:
        self.scene_count = int(v)
        self.refresh()

    def _slot_key(self, scene_index: int, track_id: str) -> str:
        return f"scene:{scene_index}:track:{track_id}"

    def _tracks(self):
        return [t for t in self.project.ctx.project.tracks if t.kind != "master"]

    def _clear_grid(self) -> None:
        while self.grid.count():
            it = self.grid.takeAt(0)
            w = it.widget()
            if w:
                w.deleteLater()

    def refresh(self) -> None:
        self._clear_grid()

        q = getattr(self.project.ctx.project, "launcher_quantize", "1 Bar")
        m = getattr(self.project.ctx.project, "launcher_mode", "Trigger")
        self.cmb_quant.setCurrentText(q if q in ["Off", "1 Beat", "1 Bar"] else "1 Bar")
        self.cmb_mode.setCurrentText(m if m in ["Trigger", "Toggle", "Gate"] else "Trigger")

        tracks = self._tracks()

        self.grid.addWidget(QLabel("Scene"), 0, 0)
        for col, trk in enumerate(tracks, start=1):
            lbl = QLabel(trk.name)
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.grid.addWidget(lbl, 0, col)

        for row in range(1, self.scene_count + 1):
            scene_btn = QToolButton()
            scene_btn.setText(f"▶ {row}")
            scene_btn.setToolTip("Scene starten (Quantize via Transport)")
            scene_btn.clicked.connect(lambda _=False, r=row: self.launcher.launch_scene(r))
            self.grid.addWidget(scene_btn, row, 0)

            for col, trk in enumerate(tracks, start=1):
                key = self._slot_key(row, trk.id)
                btn = SlotButton(self)
                btn.setMinimumHeight(30)
                btn.setProperty("slot_key", key)

                cid = self.project.ctx.project.clip_launcher.get(key, "")
                btn.setProperty("clip_id", cid)

                if cid:
                    clip = next((c for c in self.project.ctx.project.clips if c.id == cid), None)
                    btn.setText(clip.label if clip else "Missing")
                else:
                    btn.setText("Empty")

                btn.clicked.connect(lambda _=False, k=key: self._launch(k))
                btn.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
                btn.customContextMenuRequested.connect(lambda _pos, b=btn: self._slot_menu(b))

                self.grid.addWidget(btn, row, col)

        self.grid.setRowStretch(self.scene_count + 1, 1)

    def _handle_slot_drop(self, btn: SlotButton, event) -> None:  # noqa: ANN001
        key = str(btn.property("slot_key") or "")
        if not key:
            return
        clip_id = bytes(event.mimeData().data("application/x-pydaw-clipid")).decode("utf-8")
        if clip_id:
            # v0.0.11: arm + launch
            self.project.cliplauncher_assign(key, clip_id)
            self.launcher.launch_slot(key)

    def _launch(self, slot_key: str) -> None:
        self.launcher.launch_slot(slot_key)
        cid = self.project.ctx.project.clip_launcher.get(slot_key, "")
        if cid:
            self.clip_activated.emit(cid)

    def _slot_menu(self, btn: SlotButton) -> None:
        key = str(btn.property("slot_key") or "")
        if not key:
            return

        menu = QMenu(self)
        a_assign = menu.addAction("Ausgewählten Clip zuweisen")
        a_select = menu.addAction("Clip auswählen")
        menu.addSeparator()
        a_clear = menu.addAction("Slot leeren")

        act = menu.exec(btn.mapToGlobal(btn.rect().center()))
        if act == a_assign:
            cid = self.project.active_clip_id
            if cid:
                self.project.cliplauncher_assign(key, cid)
        elif act == a_clear:
            self.project.cliplauncher_clear(key)
        elif act == a_select:
            cid = self.project.ctx.project.clip_launcher.get(key, "")
            if cid:
                self.project.select_clip(cid)
                self.clip_activated.emit(cid)