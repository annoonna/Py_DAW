"""NotationView (Task 3).

This module provides a lightweight, DAW-integrated notation view that can
display MIDI notes from :class:`pydaw.services.project_service.ProjectService`.

It intentionally stays *minimal*: the goal is to **show** notes reliably (MVP)
and keep the code easy to evolve into an editor (Draw/Erase/Select tools are
planned in TODO.md).

Key points
----------
- Uses :class:`pydaw.ui.notation.staff_renderer.StaffRenderer` for drawing.
- Uses a small QGraphicsScene so the UI remains responsive.
- Listens to ``project_updated`` and repaints when the active clip changes.

Run a visual demo:

.. code-block:: bash

    python3 -m pydaw.ui.notation.notation_view
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from PyQt6.QtCore import QRectF, Qt, QTimer, pyqtSignal

from PyQt6.QtGui import QCursor, QPainter
from PyQt6.QtWidgets import (
    QApplication,
    QGraphicsItem,
    QGraphicsScene,
    QGraphicsView,
    QHBoxLayout,
    QLabel,
    QMenu,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from pydaw.model.midi import MidiNote
from pydaw.ui.notation.staff_renderer import StaffRenderer, StaffStyle
from pydaw.ui.notation.colors import velocity_to_color, velocity_to_outline
from pydaw.ui.notation.tools import DrawTool, EraseTool, NotationTool, SelectTool


@dataclass
class NotationLayout:
    """Layout constants for the view."""

    y_offset: int = 70
    left_margin: int = 40
    right_margin: int = 40
    top_margin: int = 30
    bottom_margin: int = 40
    pixels_per_beat: float = 120.0
    # Maximum width in beats we pre-allocate for a stable scene (prevents heavy resizes)
    max_beats: float = 64.0


class _StaffBackgroundItem(QGraphicsItem):
    """Draws the staff and simple beat grid."""

    def __init__(self, width_px: float, style: StaffStyle, y_offset: int):
        super().__init__()
        self._width_px = float(width_px)
        self._style = style
        self._y_offset = int(y_offset)

    def boundingRect(self) -> QRectF:  # noqa: N802 (Qt API)
        h = StaffRenderer.staff_height(self._style) + 120
        return QRectF(0, 0, self._width_px, float(h))

    def paint(self, painter: QPainter, _opt, _widget=None):  # noqa: N802 (Qt API)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        StaffRenderer.render_staff(painter, int(self._width_px), self._y_offset, self._style)


class _NoteItem(QGraphicsItem):
    """A single note rendered via StaffRenderer."""

    def __init__(
        self,
        note: MidiNote,
        *,
        x_center: float,
        staff_line: int,
        y_offset: int,
        style: StaffStyle,
        selected: bool = False,
    ):
        super().__init__()
        self.note = note
        self._x = float(x_center)
        self._line = int(staff_line)
        self._y_offset = int(y_offset)
        self._style = style
        self._selected = bool(selected)
        self._key = (
            int(getattr(note, "pitch", 0)),
            round(float(getattr(note, "start_beats", 0.0)), 6),
            round(float(getattr(note, "length_beats", 0.0)), 6),
        )
        self.setAcceptedMouseButtons(Qt.MouseButton.NoButton)

    @property
    def key(self) -> tuple[int, float, float]:
        return self._key

    def set_selected(self, on: bool) -> None:
        on = bool(on)
        if on == self._selected:
            return
        self._selected = on
        # Slightly lift selected notes above others.
        try:
            self.setZValue(10.0 if on else 0.0)
        except Exception:
            pass
        self.update()

    def boundingRect(self) -> QRectF:  # noqa: N802 (Qt API)
        # generous rect to include accidentals and stems
        w = self._style.note_head_w * 4
        h = self._style.stem_len + self._style.note_head_h * 4
        # vertical center is around y computed in renderer; approximate
        return QRectF(self._x - w, self._y_offset - h, w * 2, h * 2)

    def paint(self, painter: QPainter, _opt, _widget=None):  # noqa: N802 (Qt API)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        # Determine accidental from note spelling
        # Ensure accidental is populated (MidiNote.to_staff_position updates it)
        try:
            _ = self.note.to_staff_position()
        except Exception:
            pass
        acc = int(getattr(self.note, "accidental", 0))

        # Stem direction: middle line (B4) is staff_line=4 when bottom line is E4.
        stem_up = self._line < 4

        # Velocity-based note color (Task 10)
        vel = int(getattr(self.note, "velocity", 100))
        fill = velocity_to_color(vel, selected=self._selected)
        outline = velocity_to_outline(vel, selected=self._selected)

        StaffRenderer.render_accidental(painter, self._x, self._line, self._y_offset, acc, self._style)
        StaffRenderer.render_note_head(
            painter,
            self._x,
            self._line,
            self._y_offset,
            self._style,
            filled=True,
            fill_color=fill,
            outline_color=outline,
        )
        StaffRenderer.render_stem(painter, self._x, self._line, self._y_offset, stem_up, self._style)

        # Selection outline (MVP)
        if self._selected:
            try:
                from PyQt6.QtGui import QPen

                pen = QPen(Qt.GlobalColor.blue)
                pen.setWidth(2)
                painter.setPen(pen)
                painter.setBrush(Qt.BrushStyle.NoBrush)
                r = self.boundingRect()
                painter.drawRoundedRect(r.adjusted(6, 6, -6, -6), 4, 4)
            except Exception:
                pass


class NotationView(QGraphicsView):
    """Notation view that renders notes from the current clip."""

    notes_changed = pyqtSignal()

    def __init__(self, project_service, *, parent: Optional[QWidget] = None):
        scene = QGraphicsScene()
        super().__init__(scene, parent)

        self._project_service = project_service
        self._clip_id: str | None = None
        self._layout = NotationLayout()
        self._style = StaffStyle()

        # --- UX: Scroll/Zoom (Notation Timeline) ---
        # Many users expect DAW-like behavior:
        #   - Mouse wheel scrolls the timeline horizontally
        #   - Ctrl + wheel zooms the timeline (time-axis)
        # This is essential once notes extend far to the right.
        self._ppb_default: float = float(self._layout.pixels_per_beat)
        self._ppb_min: float = 20.0
        self._ppb_max: float = 640.0
        self._zoom_step: float = 1.12
        # Hard cap for scene beat allocation to prevent accidental runaway values.
        # (Still very large; allows practical "infinite" scrolling.)
        self._max_beats_hard: float = 131072.0

        self.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        self.setViewportUpdateMode(QGraphicsView.ViewportUpdateMode.MinimalViewportUpdate)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        # Ensure the view can reliably receive wheel/key events.
        try:
            self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        except Exception:
            pass
        # Keep colors predictable across themes.
        try:
            from PyQt6.QtGui import QBrush

            self.setBackgroundBrush(QBrush(Qt.GlobalColor.white))
        except Exception:
            pass

        self._staff_item: _StaffBackgroundItem | None = None
        self._note_items: list[_NoteItem] = []

        # --- Task 7: Bidirektionale MIDI-Sync (MVP-Infra) ---
        # The project emits a global `project_updated` signal for many changes.
        # For the notation view we keep refreshes cheap and avoid feedback loops
        # when we ourselves update MIDI notes.
        self._suppress_project_updates: int = 0
        self._last_notes_sig: tuple | None = None

        # Selection (Task 6 - Select-Tool)
        self._selected_key: tuple[int, float, float] | None = None

        # Editing tools
        self._draw_tool: NotationTool = DrawTool()
        self._select_tool: NotationTool = SelectTool()
        # Active tool defaults to Draw (MVP)
        self._tool: NotationTool = self._draw_tool
        # Task 5 (Erase-Tool): routed via right-click for now (keeps MVP UI simple)
        self._erase_tool: NotationTool = EraseTool()

        # auto-refresh when project changes (throttled + recursion-safe)
        try:
            self._project_service.project_updated.connect(self._on_project_updated)
        except Exception:
            pass

        self._rebuild_scene_base()

    # ------------------------------------------------------------------
    # Tool-facing helpers / properties
    # ------------------------------------------------------------------
    @property
    def project_service(self):
        return self._project_service

    @property
    def clip_id(self) -> str | None:
        return self._clip_id

    def set_active_tool(self, name: str) -> None:
        """Switch the active left-click tool.

        Supported: "draw", "select".
        """

        n = str(name or "").strip().lower()
        if n in ("draw", "pencil"):
            self._tool = self._draw_tool
        elif n in ("select", "arrow"):
            self._tool = self._select_tool
        else:
            self._tool = self._draw_tool

        # Provide UI feedback via status signal.
        try:
            self._project_service.status.emit(f"Notation Tool: {self._tool.name}")
        except Exception:
            pass

    # ---- selection helpers (used by SelectTool) ----
    @staticmethod
    def _note_key(note: MidiNote) -> tuple[int, float, float]:
        return (
            int(getattr(note, "pitch", 0)),
            round(float(getattr(note, "start_beats", 0.0)), 6),
            round(float(getattr(note, "length_beats", 0.0)), 6),
        )

    def is_selected_note(self, note: MidiNote) -> bool:
        return self._selected_key == self._note_key(note)

    def clear_selection(self) -> None:
        self._selected_key = None
        self._apply_selection_to_items()

    def select_note(self, note: MidiNote) -> None:
        self._selected_key = self._note_key(note)
        self._apply_selection_to_items()

    def _apply_selection_to_items(self) -> None:
        key = self._selected_key
        for it in list(self._note_items):
            try:
                it.set_selected(bool(key is not None and it.key == key))
            except Exception:
                pass

    def scene_x_to_beat(self, scene_x: float) -> float:
        """Convert a scene X coordinate to beats (unsnapped)."""
        return (float(scene_x) - float(self._layout.left_margin)) / float(self._layout.pixels_per_beat)

    def scene_y_to_staff_line(self, scene_y: float) -> int:
        """Convert a scene Y coordinate to a staff line/space index.

        Our staff model (as used by StaffRenderer):
        - bottom staff line == 0
        - each step (1) == one *half step* in pixel space (line or space)
        """
        bottom_line_y = float(self._layout.y_offset) + float((self._style.lines - 1) * self._style.line_distance)
        half_step = float(self._style.line_distance) / 2.0
        return int(round((bottom_line_y - float(scene_y)) / max(1e-9, half_step)))

    def staff_line_to_pitch(self, staff_line: int, *, accidental: int = 0) -> int:
        """Convert a staff line/space index to a MIDI pitch (natural notes MVP)."""
        e4_ref = self._diatonic_index(2, 4)  # E4 (bottom line)
        diat = int(e4_ref) + int(staff_line)
        octave = diat // 7
        line = diat % 7
        return int(MidiNote.from_staff_position(int(line), int(octave), int(accidental)))

    # ------------------------------------------------------------------
    # Qt events
    # ------------------------------------------------------------------
    def mousePressEvent(self, event):  # noqa: N802 (Qt API)
        try:
            scene_pos = self.mapToScene(event.pos())
            tool = self._erase_tool if event.button() == Qt.MouseButton.RightButton else self._tool
            res = tool.handle_mouse_press(self, scene_pos, event.button(), event.modifiers())
            if getattr(res, "status", ""):
                # Route status to the global status bar if possible.
                try:
                    self._project_service.status.emit(str(res.status))
                except Exception:
                    pass
            if getattr(res, "changed", False):
                # The ProjectService already emits project_updated, but a direct refresh
                # makes the editor feel snappy.
                self.refresh()
                return
        except Exception:
            # Never break mouse input on errors.
            pass

        super().mousePressEvent(event)


    def wheelEvent(self, event):  # noqa: N802 (Qt API)
        """DAW-like wheel behavior.

        - Ctrl + Wheel: zoom time-axis (pixels-per-beat)
        - Wheel: horizontal scroll (timeline)

        Notes:
        - We keep vertical scrolling available via scrollbars if needed,
          but default wheel interaction is timeline-centric.
        """

        try:
            mods = event.modifiers()
        except Exception:
            mods = Qt.KeyboardModifier.NoModifier

        # Zoom: Ctrl+Wheel
        if mods & Qt.KeyboardModifier.ControlModifier:
            try:
                delta = event.angleDelta().y()
            except Exception:
                delta = 0

            if delta == 0:
                try:
                    event.ignore()
                except Exception:
                    pass
                return

            # Keep beat under cursor stable.
            try:
                pos = event.position().toPoint()
            except Exception:
                pos = event.pos()

            try:
                scene_pos = self.mapToScene(pos)
                beat = self.scene_x_to_beat(float(scene_pos.x()))
                anchor_y = float(scene_pos.y())
            except Exception:
                beat = None
                anchor_y = None

            factor = self._zoom_step if delta > 0 else (1.0 / self._zoom_step)
            new_ppb = float(self._layout.pixels_per_beat) * float(factor)
            self._set_pixels_per_beat(new_ppb)

            # After rebuild, move viewport so the same beat stays near cursor.
            if beat is not None and anchor_y is not None:
                try:
                    self.centerOn(self._beat_to_x(float(beat)), float(anchor_y))
                except Exception:
                    pass

            try:
                event.accept()
            except Exception:
                pass
            return

        # Horizontal scroll (timeline)
        try:
            dx = int(event.angleDelta().x())
            dy = int(event.angleDelta().y())
        except Exception:
            dx = 0
            dy = 0

        # Prefer explicit horizontal delta (trackpad), otherwise map vertical wheel to horizontal.
        delta = dx if dx != 0 else dy
        if delta != 0:
            try:
                sb = self.horizontalScrollBar()
                sb.setValue(int(sb.value()) - int(delta))
                event.accept()
                return
            except Exception:
                pass

        super().wheelEvent(event)


    def keyPressEvent(self, event):  # noqa: N802 (Qt API)
        """Keyboard zoom shortcuts.

        - Ctrl + '+' / Ctrl + '-' : zoom
        - Ctrl + '0' : reset zoom
        """
        try:
            key = event.key()
            mods = event.modifiers()
        except Exception:
            return super().keyPressEvent(event)

        if mods & Qt.KeyboardModifier.ControlModifier:
            if key in (Qt.Key.Key_Plus, Qt.Key.Key_Equal):
                self._set_pixels_per_beat(float(self._layout.pixels_per_beat) * float(self._zoom_step))
                event.accept()
                return
            if key in (Qt.Key.Key_Minus, Qt.Key.Key_Underscore):
                self._set_pixels_per_beat(float(self._layout.pixels_per_beat) / float(self._zoom_step))
                event.accept()
                return
            if key == Qt.Key.Key_0:
                self._set_pixels_per_beat(self._ppb_default)
                event.accept()
                return

        super().keyPressEvent(event)


    # ------------------------------------------------------------------
    # Context Menu (Task 11)
    # ------------------------------------------------------------------
    def contextMenuEvent(self, event):  # noqa: N802 (Qt API)
        """Open a safe context menu (Ctrl+RightClick).

        We keep the MVP ergonomics:
        - **Right click** still erases a note (Task 5).
        - **Ctrl + Right click** opens a context menu.

        Rationale: some Qt/graphics-view setups may crash when opening a menu
        synchronously inside the event handler. We therefore defer the `exec()`
        via ``QTimer.singleShot(0, ...)``.
        """
        try:
            mods = event.modifiers()
        except Exception:
            mods = Qt.KeyboardModifier.NoModifier

        # Keep default right-click erase behavior unless the user explicitly asks for a menu.
        if not (mods & Qt.KeyboardModifier.ControlModifier):
            try:
                event.ignore()
            except Exception:
                pass
            return

        try:
            scene_pos = self.mapToScene(event.pos())
        except Exception:
            scene_pos = None

        try:
            global_pos = event.globalPos()
        except Exception:
            try:
                global_pos = event.globalPosition().toPoint()
            except Exception:
                global_pos = QCursor.pos()

        def _open() -> None:
            try:
                self._open_context_menu(scene_pos, global_pos)
            except Exception:
                pass

        try:
            QTimer.singleShot(0, _open)
            event.accept()
        except Exception:
            pass

    def _open_context_menu(self, scene_pos, global_pos) -> None:
        """Build and show the context menu."""
        try:
            menu = QMenu(self)
            act_erase = menu.addAction("✖ Löschen (Erase)")
            act_clear = menu.addAction("⨯ Auswahl löschen")
            menu.addSeparator()
            act_draw = menu.addAction("✎ Tool: Draw")
            act_select = menu.addAction("⬚ Tool: Select")
            menu.addSeparator()
            act_refresh = menu.addAction("⟳ Neu rendern")

            act_clear.setEnabled(self._selected_key is not None)

            def _emit_status(msg: str) -> None:
                try:
                    self._project_service.status.emit(str(msg))
                except Exception:
                    pass

            def _do_erase() -> None:
                if scene_pos is None:
                    _emit_status("Kein Cursor-Punkt für Erase.")
                    return
                res = self._erase_tool.handle_mouse_press(
                    self,
                    scene_pos,
                    Qt.MouseButton.RightButton,
                    Qt.KeyboardModifier.NoModifier,
                )
                if getattr(res, "status", ""):
                    _emit_status(str(res.status))
                if getattr(res, "changed", False):
                    self.refresh()

            def _do_clear() -> None:
                self.clear_selection()
                self.refresh()

            def _do_draw() -> None:
                self.set_active_tool("draw")
                _emit_status("Notation Tool: Draw")

            def _do_select() -> None:
                self.set_active_tool("select")
                _emit_status("Notation Tool: Select")

            act_erase.triggered.connect(_do_erase)
            act_clear.triggered.connect(_do_clear)
            act_draw.triggered.connect(_do_draw)
            act_select.triggered.connect(_do_select)
            act_refresh.triggered.connect(self.refresh)

            try:
                menu.exec(global_pos)
            except Exception:
                menu.exec(QCursor.pos())
        except Exception:
            # Context menus must never crash the editor.
            return


    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def set_clip(self, clip_id: str | None):
        """Set the active clip id whose notes should be rendered."""
        self._clip_id = str(clip_id) if clip_id else None
        # Reset selection when switching clips (prevents confusing highlight).
        self._selected_key = None
        self.refresh()

    def refresh(self):
        """Re-render staff + notes for the current clip."""
        notes: list[MidiNote] = []
        if self._clip_id:
            try:
                notes = list(self._project_service.get_midi_notes(self._clip_id))
            except Exception:
                notes = []

        # Cache a lightweight signature so we can skip redundant refreshes.
        self._last_notes_sig = self._notes_signature(notes)

        # Update the scene width based on clip content (keep it stable and only grow).
        # IMPORTANT: Do NOT clamp too aggressively.
        # Users may create / import very long clips or notes far to the right.
        # If we clamp to a low value, the notes exist but cannot be reached via scrolling.
        if notes:
            max_end = 0.0
            for n in notes:
                try:
                    max_end = max(max_end, float(n.start_beats) + float(n.length_beats))
                except Exception:
                    continue
            max_end = max(8.0, float(max_end))

            # Hard cap to prevent accidental runaway values (still huge).
            if max_end > float(self._max_beats_hard):
                max_end = float(self._max_beats_hard)
                try:
                    self._project_service.status.emit(
                        f"Notation: Clip sehr lang – Timeline auf {int(self._max_beats_hard)} Beats begrenzt (Performance)."
                    )
                except Exception:
                    pass

            self._layout.max_beats = max(self._layout.max_beats, float(max_end) + 4.0)

        self._rebuild_scene_base()
        self._render_notes(notes)
        # re-apply selection after rebuild (if we could match it)
        self._apply_selection_to_items()
        self.notes_changed.emit()

    # ------------------------------------------------------------------
    # Task 7: Bidirektionale MIDI-Sync helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _notes_signature(notes: list[MidiNote]) -> tuple:
        """Create a stable signature for MIDI notes.

        We avoid hashing whole dataclasses; instead we use the most relevant
        numeric fields with rounding. Order is preserved as stored.
        """

        sig = []
        for n in list(notes or []):
            try:
                sig.append(
                    (
                        int(getattr(n, "pitch", 0)),
                        round(float(getattr(n, "start_beats", 0.0)), 6),
                        round(float(getattr(n, "length_beats", 0.0)), 6),
                        int(getattr(n, "velocity", 100)),
                    )
                )
            except Exception:
                continue
        return tuple(sig)

    def _on_project_updated(self) -> None:
        """React to global project updates.

        - Avoid infinite refresh loops by allowing callers to suppress the next
          few updates (e.g. when the notation view writes MIDI notes).
        - Skip redundant refreshes if the active clip's notes are unchanged.
        """

        if self._suppress_project_updates > 0:
            self._suppress_project_updates = max(0, int(self._suppress_project_updates) - 1)
            return

        if not self._clip_id:
            # No active clip -> nothing meaningful to refresh.
            return

        try:
            notes = list(self._project_service.get_midi_notes(self._clip_id))
        except Exception:
            notes = []

        sig = self._notes_signature(notes)
        if sig == self._last_notes_sig:
            return

        self.refresh()

    def commit_notes_to_project(self, notes: list[MidiNote], *, label: str = "Edit MIDI (Notation)") -> None:
        """Commit a full notes list back to the ProjectService.

        This is the preferred way for future notation edit actions (drag/resize)
        because it creates a single Undo step and keeps UI sync predictable.

        Notes:
        - For MVP tools (Draw/Erase) we may still call ProjectService helpers
          directly. This method mainly provides the bidirectional sync
          infrastructure and recursion prevention requested in Task 7.
        """

        if not self._clip_id:
            return
        ps = self._project_service
        try:
            before = ps.snapshot_midi_notes(str(self._clip_id))
        except Exception:
            before = []

        # set_midi_notes() emits project_updated, commit_midi_notes_edit() emits
        # again; allow a small suppression budget.
        self._suppress_project_updates += 3

        try:
            ps.set_midi_notes(str(self._clip_id), list(notes or []))
        except Exception:
            return

        try:
            ps.commit_midi_notes_edit(str(self._clip_id), before, str(label or "Edit MIDI (Notation)"))
        except Exception:
            # Even if undo commit fails, keep UI consistent.
            try:
                ps._emit_updated()  # type: ignore[attr-defined]
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------
    @staticmethod
    def _diatonic_index(line: int, octave: int) -> int:
        # line: C=0..B=6
        return int(octave) * 7 + int(line)

    def _pitch_to_staff_line(self, pitch: int) -> int:
        """Map MIDI pitch to staff half-step index relative to treble bottom line E4."""
        tmp = MidiNote(pitch=int(pitch), start_beats=0.0, length_beats=1.0, velocity=100)
        line, octv = tmp.to_staff_position()  # sets accidental on tmp
        diat = self._diatonic_index(line, octv)
        e4_ref = self._diatonic_index(2, 4)  # E4 (bottom line)
        return int(diat - e4_ref)

    def _beat_to_x(self, beat: float) -> float:
        return float(self._layout.left_margin) + float(beat) * float(self._layout.pixels_per_beat)

    def _set_pixels_per_beat(self, ppb: float) -> None:
        """Set timeline scale (pixels-per-beat) and rebuild the view.

        We rebuild (instead of QGraphicsView scaling) so note heads and
        staff geometry keep their intended proportions while only the
        time-axis spacing changes.
        """

        try:
            ppb_f = float(ppb)
        except Exception:
            return

        # Clamp for usability.
        ppb_f = max(float(self._ppb_min), min(float(self._ppb_max), ppb_f))

        if abs(ppb_f - float(self._layout.pixels_per_beat)) < 1e-6:
            return

        self._layout.pixels_per_beat = float(ppb_f)

        # Provide user feedback in the DAW status bar if available.
        try:
            self._project_service.status.emit(f"Notation Zoom: {int(self._layout.pixels_per_beat)} px/beat")
        except Exception:
            pass

        # Re-render with the new scale.
        self.refresh()

    def _rebuild_scene_base(self) -> None:
        sc = self.scene()
        sc.clear()
        self._note_items.clear()

        width_px = (
            float(self._layout.left_margin)
            + float(self._layout.right_margin)
            + float(self._layout.max_beats) * float(self._layout.pixels_per_beat)
        )

        self._staff_item = _StaffBackgroundItem(width_px, self._style, self._layout.y_offset)
        sc.addItem(self._staff_item)

        # stable scene rect; keeps scrolling consistent
        h = StaffRenderer.staff_height(self._style) + 180
        sc.setSceneRect(QRectF(0, 0, width_px, float(h)))

        # small hint if no clip selected
        if not self._clip_id:
            hint = sc.addText("Kein MIDI-Clip ausgewählt.\nWähle im Arranger einen MIDI-Clip.")
            hint.setDefaultTextColor(Qt.GlobalColor.black)
            hint.setPos(20, self._layout.y_offset + StaffRenderer.staff_height(self._style) + 40)

    def _render_notes(self, notes: list[MidiNote]) -> None:
        if not self._clip_id or not notes:
            return

        # Add notes
        for n in notes:
            try:
                x = self._beat_to_x(float(n.start_beats))
                staff_line = self._pitch_to_staff_line(int(n.pitch))
            except Exception:
                continue

            selected = False
            try:
                selected = self._selected_key == self._note_key(n)
            except Exception:
                selected = False

            item = _NoteItem(
                n,
                x_center=float(x),
                staff_line=int(staff_line),
                y_offset=int(self._layout.y_offset),
                style=self._style,
                selected=bool(selected),
            )
            self.scene().addItem(item)
            self._note_items.append(item)




def _on_scale_state_changed(self, root: str, scale_id: str, lock_enabled: bool) -> None:
    self._scale_root = str(root or "C")
    self._scale_id = str(scale_id or "major")
    self._scale_lock = bool(lock_enabled)
    self.viewport().update()

def apply_scale_lock(self, pitch: int) -> int:
    """Apply scale lock to a MIDI pitch (12-TET)."""
    if not self._scale_lock or not self._scale_id or self._scale_id == "__off__":
        return int(pitch)
    db = get_scale_db()
    sc = db.get(self._scale_id)
    if not sc:
        return int(pitch)
    allowed = sc.pitch_classes(note_to_pc(self._scale_root))
    return int(nearest_allowed_pitch(int(pitch), allowed))

class NotationWidget(QWidget):
    """A small tab-friendly wrapper around :class:`NotationView`."""

    status_message = pyqtSignal(str)

    def __init__(self, project_service, *, transport=None, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._project_service = project_service
        self._transport = transport
        self._clip_id: str | None = None

        self._view = NotationView(project_service, parent=self)

        top = QHBoxLayout()
        top.setContentsMargins(6, 6, 6, 0)
        top.setSpacing(8)

        self._lbl = QLabel("Notation (MVP)")
        top.addWidget(self._lbl)
        top.addStretch(1)

        # Scale selector (shared with Piano Roll)
        self._scale_btn = ScaleSelectorButton()
        self._scale_btn.setToolTip("Scale Menü. Wenn Scale Lock aktiv ist, werden Noten auf Skalentöne eingeschränkt.")
        top.addWidget(self._scale_btn)
        top.addSpacing(8)

        # Minimal tool switcher (keeps the MVP usable without shortcuts).
        btn_draw = QToolButton()
        btn_draw.setText("✎")
        btn_draw.setToolTip("Tool: Draw (Note zeichnen)")
        btn_draw.setCheckable(True)
        btn_draw.setChecked(True)
        top.addWidget(btn_draw)

        btn_select = QToolButton()
        btn_select.setText("⬚")
        btn_select.setToolTip("Tool: Select (Note auswählen)")
        btn_select.setCheckable(True)
        top.addWidget(btn_select)

        def _set_tool(name: str) -> None:
            self._view.set_active_tool(name)
            btn_draw.setChecked(name == "draw")
            btn_select.setChecked(name == "select")

        btn_draw.clicked.connect(lambda: _set_tool("draw"))
        btn_select.clicked.connect(lambda: _set_tool("select"))

        btn_refresh = QToolButton()
        btn_refresh.setText("⟳")
        btn_refresh.setToolTip("Neu rendern")
        btn_refresh.clicked.connect(self._view.refresh)
        top.addWidget(btn_refresh)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(6)
        root.addLayout(top)
        root.addWidget(self._view, 1)

        # Keep label in sync
        self._view.notes_changed.connect(self._update_label)

        # --- Task 7: Bidirektionale MIDI-Sync (Clip-Selection) ---
        # If the host DAW selects a clip (Arranger/PianoRoll), follow it automatically.
        # Only MIDI clips are shown; selecting an audio clip clears the notation view.
        try:
            self._project_service.active_clip_changed.connect(self._on_active_clip_changed)
        except Exception:
            pass
        try:
            self._project_service.clip_selected.connect(self._on_active_clip_changed)
        except Exception:
            pass

        # Initial sync (if the project already has a selected clip)
        try:
            cid = str(getattr(self._project_service, "active_clip_id", "") or "")
            if cid:
                self._on_active_clip_changed(cid)
        except Exception:
            pass

    def _on_active_clip_changed(self, clip_id: str) -> None:
        cid = str(clip_id or "").strip()
        if not cid:
            self.set_clip(None)
            return

        # Only show MIDI clips.
        try:
            clip = next((c for c in self._project_service.ctx.project.clips if str(getattr(c, "id", "")) == cid), None)
        except Exception:
            clip = None

        if not clip or str(getattr(clip, "kind", "")) != "midi":
            self.set_clip(None)
            return

        self.set_clip(cid)

    def set_clip(self, clip_id: str | None) -> None:
        self._clip_id = str(clip_id) if clip_id else None
        self._view.set_clip(self._clip_id)
        self._update_label()

    def _update_label(self) -> None:
        if self._clip_id:
            self._lbl.setText(f"Notation (MVP) – Clip: {self._clip_id}")
        else:
            self._lbl.setText("Notation (MVP)")


def _run_demo() -> None:
    """Standalone visual demo (does not require the full DAW)."""

    from PyQt6.QtCore import QObject

    class _Stub(QObject):
        project_updated = pyqtSignal()

        def __init__(self):
            super().__init__()
            self._notes = {
                "clip1": [
                    MidiNote(pitch=64, start_beats=0.0, length_beats=1.0, velocity=100),  # E4
                    MidiNote(pitch=66, start_beats=1.0, length_beats=1.0, velocity=100),  # F#4
                    MidiNote(pitch=67, start_beats=2.0, length_beats=2.0, velocity=100),  # G4
                    MidiNote(pitch=72, start_beats=4.0, length_beats=1.0, velocity=100),  # C5
                ]
            }

        def get_midi_notes(self, clip_id: str):
            return list(self._notes.get(clip_id, []))

    app = QApplication.instance() or QApplication([])
    stub = _Stub()
    w = NotationWidget(stub)
    w.resize(1000, 380)
    w.set_clip("clip1")
    w.show()
    app.exec()


if __name__ == "__main__":
    _run_demo()
