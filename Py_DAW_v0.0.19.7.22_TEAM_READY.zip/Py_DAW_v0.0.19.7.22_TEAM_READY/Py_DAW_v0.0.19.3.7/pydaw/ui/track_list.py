"""Track list panel (v0.0.4).

Left side of the Arranger: track selection + quick add/remove buttons.
This is still placeholder UI; real track controls come later.
"""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QLabel,
    QMenu,
)
from PyQt6.QtCore import Qt, pyqtSignal

from pydaw.services.project_service import ProjectService


class TrackListWidget(QWidget):
    selected_track_changed = pyqtSignal(str)  # track_id (empty if none)

    def __init__(self, project: ProjectService, parent=None):
        super().__init__(parent)
        self.project = project

        self._build_ui()
        self._wire()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        header = QHBoxLayout()
        header.addWidget(QLabel("Spuren"))

        self.btn_add = QPushButton("+")
        self.btn_add.setToolTip("Spur hinzufügen")
        self.btn_remove = QPushButton("–")
        self.btn_remove.setToolTip("Ausgewählte Spur entfernen")
        header.addWidget(self.btn_add)
        header.addWidget(self.btn_remove)

        layout.addLayout(header)

        self.list = QListWidget()
        self.list.setEditTriggers(QAbstractItemView.EditTrigger.DoubleClicked | QAbstractItemView.EditTrigger.EditKeyPressed)
        self.list.itemChanged.connect(self._on_item_changed)
        self.list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.list.customContextMenuRequested.connect(self._on_context_menu)
        self.list.setSelectionMode(QListWidget.SelectionMode.SingleSelection)
        layout.addWidget(self.list, 1)

    def _wire(self) -> None:
        self.project.project_updated.connect(self.refresh)
        self.list.currentItemChanged.connect(self._on_selection_changed)
        self.btn_add.clicked.connect(self._open_add_menu)
        self.btn_remove.clicked.connect(self._remove_selected)

    def refresh(self) -> None:
        self.list.clear()
        for trk in self.project.ctx.project.tracks:
            item = QListWidgetItem(f"{trk.name}  [{trk.kind}]")
            item.setData(Qt.ItemDataRole.UserRole, trk.id)
            if trk.kind == "master":
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.list.addItem(item)

        # Keep selection if possible
        if self.list.count() > 0 and self.list.currentRow() < 0:
            self.list.setCurrentRow(0)

    def selected_track_id(self) -> str:
        item = self.list.currentItem()
        if not item:
            return ""
        return str(item.data(Qt.ItemDataRole.UserRole) or "")

    def _on_selection_changed(self) -> None:
        self.selected_track_changed.emit(self.selected_track_id())

    def _open_add_menu(self) -> None:
        menu = QMenu(self)
        a_audio = menu.addAction("Audio-Spur hinzufügen")
        a_inst = menu.addAction("Instrumenten-Spur hinzufügen")
        a_bus = menu.addAction("FX/Bus-Spur hinzufügen")
        action = menu.exec(self.btn_add.mapToGlobal(self.btn_add.rect().bottomLeft()))
        if action == a_audio:
            self.project.add_track("audio")
        elif action == a_inst:
            self.project.add_track("instrument")
        elif action == a_bus:
            self.project.add_track("bus")

    def _remove_selected(self) -> None:
        tid = self.selected_track_id()
        if not tid:
            return
        self.project.remove_track(tid)


def _on_item_changed(self, item: QListWidgetItem) -> None:
    track_id = item.data(Qt.ItemDataRole.UserRole)
    if not track_id:
        return
    name = str(item.text() or "").strip()
    if not name:
        return
    try:
        self.project.rename_track(str(track_id), name)
    except Exception:
        pass

def _on_context_menu(self, pos):  # noqa: ANN001
    item = self.list.itemAt(pos)
    if item is None:
        return
    track_id = item.data(Qt.ItemDataRole.UserRole)
    if not track_id:
        return
    # find kind
    trk = next((t for t in self.project.ctx.project.tracks if t.id == str(track_id)), None)
    if trk is None:
        return

    menu = QMenu(self)
    a_rename = menu.addAction("Umbenennen…")
    a_del = None
    if trk.kind != "master":
        a_del = menu.addAction("Track löschen")

    act = menu.exec(self.list.mapToGlobal(pos))
    if act == a_rename:
        self.list.editItem(item)
        return
    if a_del is not None and act == a_del:
        try:
            self.project.delete_track(str(track_id))
        except Exception:
            pass
        return
