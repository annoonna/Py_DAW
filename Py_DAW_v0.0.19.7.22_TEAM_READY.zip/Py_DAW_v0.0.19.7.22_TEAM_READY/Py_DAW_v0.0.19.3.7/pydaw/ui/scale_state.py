from __future__ import annotations

from PyQt6.QtCore import QObject, pyqtSignal

from pydaw.core.settings import SettingsKeys
from pydaw.core.settings_store import get_value as get_setting, set_value as set_setting

# Settings keys
_KEYS = SettingsKeys()
KEY_SCALE_ROOT = "ui/scale_root"
KEY_SCALE_ID = "ui/scale_id"
KEY_SCALE_LOCK = "ui/scale_lock"

class ScaleState(QObject):
    """
    Global, lightweight state holder for scale selection.
    Used by Piano Roll + Notation editor to keep a single truth.
    """
    changed = pyqtSignal(str, str, bool)  # root, scale_id, lock

    def __init__(self):
        super().__init__()
        self.root: str = str(get_setting(KEY_SCALE_ROOT, "C") or "C")
        self.scale_id: str = str(get_setting(KEY_SCALE_ID, "major") or "major")
        self.lock_enabled: bool = str(get_setting(KEY_SCALE_LOCK, "false")).lower() in ("1","true","yes","on")

    def set(self, *, root: str | None = None, scale_id: str | None = None, lock_enabled: bool | None = None) -> None:
        changed = False
        if root is not None and str(root) != self.root:
            self.root = str(root)
            set_setting(KEY_SCALE_ROOT, self.root)
            changed = True
        if scale_id is not None and str(scale_id) != self.scale_id:
            self.scale_id = str(scale_id)
            set_setting(KEY_SCALE_ID, self.scale_id)
            changed = True
        if lock_enabled is not None and bool(lock_enabled) != bool(self.lock_enabled):
            self.lock_enabled = bool(lock_enabled)
            set_setting(KEY_SCALE_LOCK, "true" if self.lock_enabled else "false")
            changed = True

        if changed:
            self.changed.emit(self.root, self.scale_id, self.lock_enabled)

# module-level singleton
scale_state = ScaleState()
