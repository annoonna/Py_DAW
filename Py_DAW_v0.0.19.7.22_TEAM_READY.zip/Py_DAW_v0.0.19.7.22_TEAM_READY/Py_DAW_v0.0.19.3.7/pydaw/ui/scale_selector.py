from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import (
    QAbstractItemView,
    QFrame,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QToolButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
    QWidgetAction,
)

from pydaw.music.scales import NOTE_NAMES, get_scale_db, note_to_pc
from pydaw.ui.scale_state import scale_state


@dataclass
class ScaleSelection:
    root: str
    scale_id: str
    lock_enabled: bool


class _ScalePopup(QWidget):
    """Bitwig-like popup: left root list, right scale tree (categories)."""

    def __init__(self, parent_menu: QMenu, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._menu = parent_menu

        self.setObjectName("ScalePopup")
        self.setMinimumWidth(520)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(10)

        # Left: root notes
        self.roots = QListWidget()
        self.roots.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.roots.setFixedWidth(110)
        for n in NOTE_NAMES:
            it = QListWidgetItem(n)
            it.setData(Qt.ItemDataRole.UserRole, n)
            self.roots.addItem(it)
        lay.addWidget(self.roots)

        # Right: categories/scales
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setIndentation(14)
        self.tree.setUniformRowHeights(True)
        lay.addWidget(self.tree, 1)

        self._populate_tree()

        # Init selection from state
        self._sync_from_state()

        self.roots.itemClicked.connect(self._on_root_clicked)
        self.tree.itemClicked.connect(self._on_tree_clicked)

    def _populate_tree(self) -> None:
        db = get_scale_db()
        self.tree.clear()

        # Special "Off" at top (disables lock)
        off = QTreeWidgetItem(["(Off) – frei zeichnen"])
        off.setData(0, Qt.ItemDataRole.UserRole, ("scale", "__off__"))
        self.tree.addTopLevelItem(off)

        for cid, cname, scales in db.categories():
            cat = QTreeWidgetItem([cname])
            cat.setData(0, Qt.ItemDataRole.UserRole, ("cat", cid))
            cat.setExpanded(True)
            self.tree.addTopLevelItem(cat)
            for sc in scales:
                child = QTreeWidgetItem([sc.name])
                child.setData(0, Qt.ItemDataRole.UserRole, ("scale", sc.id))
                cat.addChild(child)

        self.tree.expandAll()

    def _sync_from_state(self) -> None:
        # root
        for i in range(self.roots.count()):
            it = self.roots.item(i)
            if it.data(Qt.ItemDataRole.UserRole) == scale_state.root:
                self.roots.setCurrentRow(i)
                break

        # scale
        def select_scale(target_id: str) -> None:
            root = self.tree.invisibleRootItem()
            for i in range(root.childCount()):
                top = root.child(i)
                typ, val = top.data(0, Qt.ItemDataRole.UserRole) or (None, None)
                if typ == "scale" and val == target_id:
                    self.tree.setCurrentItem(top)
                    return
                for j in range(top.childCount()):
                    ch = top.child(j)
                    typ2, val2 = ch.data(0, Qt.ItemDataRole.UserRole) or (None, None)
                    if typ2 == "scale" and val2 == target_id:
                        self.tree.setCurrentItem(ch)
                        return

        if scale_state.lock_enabled and scale_state.scale_id and scale_state.scale_id != "__off__":
            select_scale(scale_state.scale_id)
        else:
            select_scale("__off__")

    def _on_root_clicked(self, item: QListWidgetItem) -> None:
        root = str(item.data(Qt.ItemDataRole.UserRole))
        scale_state.set(root=root)
        self._menu.close()

    def _on_tree_clicked(self, item: QTreeWidgetItem, col: int) -> None:
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data:
            return
        typ, val = data
        if typ != "scale":
            return
        scale_id = str(val)
        if scale_id == "__off__":
            # Off => unlock
            scale_state.set(lock_enabled=False)
        else:
            # Selecting a scale enables lock automatically
            scale_state.set(scale_id=scale_id, lock_enabled=True)
        self._menu.close()


class ScaleSelectorButton(QToolButton):
    """Toolbar button showing current scale (cyan). Click opens selector popup."""

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        self.setObjectName("ScaleSelectorButton")

        self._menu = QMenu(self)
        self._menu.setObjectName("ScaleSelectorMenu")

        popup = _ScalePopup(self._menu, parent=self)
        wa = QWidgetAction(self._menu)
        wa.setDefaultWidget(popup)
        self._menu.addAction(wa)

        self._menu.addSeparator()

        act_lock = QAction("Scale Lock (nur Skalentöne setzen)", self._menu)
        act_lock.setCheckable(True)
        act_lock.setChecked(bool(scale_state.lock_enabled))
        act_lock.triggered.connect(lambda checked: scale_state.set(lock_enabled=bool(checked)))
        self._menu.addAction(act_lock)

        self.setMenu(self._menu)

        scale_state.changed.connect(self._on_state_changed)
        self._on_state_changed(scale_state.root, scale_state.scale_id, scale_state.lock_enabled)

    def _on_state_changed(self, root: str, scale_id: str, lock_enabled: bool) -> None:
        # Update lock action check
        for a in self._menu.actions():
            if a.text().startswith("Scale Lock"):
                a.setChecked(bool(lock_enabled))
                break

        label = "Scale: Off"
        if lock_enabled and scale_id and scale_id != "__off__":
            db = get_scale_db()
            sc = db.get(scale_id)
            if sc:
                label = f"{root} {sc.name}"
            else:
                label = f"{root} {scale_id}"
        else:
            label = f"{root} (free)"

        self.setText(label)

        # Cyan-ish badge styling
        self.setStyleSheet("""
            QToolButton#ScaleSelectorButton {
                padding: 3px 8px;
                border-radius: 6px;
                border: 1px solid rgba(0, 255, 255, 90);
                color: rgb(170, 255, 255);
                background: rgba(0, 255, 255, 18);
            }
            QToolButton#ScaleSelectorButton:hover {
                background: rgba(0, 255, 255, 28);
            }
        """)
