"""Toolbar panel (tools + grid)."""

from __future__ import annotations

from PyQt6.QtWidgets import QWidget, QHBoxLayout, QPushButton, QLabel, QComboBox, QToolButton
from PyQt6.QtCore import pyqtSignal


class ToolBarPanel(QWidget):
    tool_changed = pyqtSignal(str)
    grid_changed = pyqtSignal(str)
    automation_toggled = pyqtSignal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(8)

        self.btn_pointer = QPushButton("Zeiger")
        self.btn_knife = QPushButton("Messer")
        self.btn_time = QPushButton("Zeitauswahl")
        self.btn_pen = QPushButton("Stift")
        self.btn_eraser = QPushButton("Radiergummi")

        for b in (self.btn_pointer, self.btn_knife, self.btn_time, self.btn_pen, self.btn_eraser):
            b.clicked.connect(lambda _=False, name=b.text(): self.tool_changed.emit(name))
            layout.addWidget(b)

        layout.addSpacing(12)
        layout.addWidget(QLabel("Grid/Snap:"))
        self.cmb_grid = QComboBox()
        self.cmb_grid.addItems(["1/4", "1/8", "1/16", "1/32", "1/64"])
        self.cmb_grid.setCurrentText("1/16")
        self.cmb_grid.currentTextChanged.connect(lambda t: self.grid_changed.emit(str(t)))
        layout.addWidget(self.cmb_grid)

        layout.addSpacing(12)
        self.btn_auto = QToolButton()
        self.btn_auto.setText("Automation")
        self.btn_auto.setCheckable(True)
        self.btn_auto.toggled.connect(self.automation_toggled.emit)
        layout.addWidget(self.btn_auto)

        layout.addStretch(1)
