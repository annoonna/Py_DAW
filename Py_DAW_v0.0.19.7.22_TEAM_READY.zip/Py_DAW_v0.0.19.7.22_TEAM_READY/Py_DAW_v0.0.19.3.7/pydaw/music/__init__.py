"""Music utilities (scales, theory helpers)."""
