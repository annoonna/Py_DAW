# Changelog - Py DAW

Alle wichtigen Änderungen an diesem Projekt werden in dieser Datei dokumentiert.

Das Format basiert auf [Keep a Changelog](https://keepachangelog.com/de/1.0.0/).

---

## [0.0.19.5.1.32] - 2026-02-02

### 📝 Notation — Timeline Scroll + Zoom
- Fix: Notation-Editor jetzt endlich **bedienbar bei langen Clips**.
  - **Mausrad** = horizontaler Timeline-Scroll (DAW-Style)
  - **Ctrl + Mausrad** = Timeline-Zoom (px/Beat)
  - **Ctrl + 0 / +/-** = Reset/Zoom Shortcuts
- Fix: SceneRect wächst zuverlässig mit Clip-Länge (keine aggressive 256-Beat-Klemme mehr; sehr großer Hard-Cap bleibt als Performance-Schutz).


## [0.0.19.5.1.15] - 2026-02-02

### 🧠 Notation — Smart Tools (Tie/Slur „armed“)
- Improve: Tie/Slur Overlay-Mode blockiert den Stift nicht mehr.
  - Wenn Tie/Slur **armed** ist, wird der Connection-Tool **nur** bei Klicks **nahe bestehender Noten** aktiv.
  - Klick in leeren Bereich zeichnet weiterhin ganz normal (Draw bleibt nutzbar).
  - Wenn ein 2-Klick-Vorgang bereits „pending“ ist, werden Klicks immer an Tie/Slur geroutet (inkl. Cancel per Klick ins Leere).
- New: **UI-Indikator** im Notation-Toolbar: „Tie armed“ / „Slur armed“.
- New: Modifier-Workflow-Hinweis in Tooltips:
  - **Shift+Klick** = Tie (momentary)
  - **Alt+Klick** = Slur (momentary)
  - **Ctrl+Klick** erzwingt Primary Tool (Draw/Select), auch wenn armed.

## [0.0.19.5.1.14] - 2026-02-02

### ⚡ Performance — MIDI Pre-Render Optionen + Scope
- New: Audio-Einstellungen → **Performance (MIDI Pre-Render)** mit Optionen:
  - Auto-Pre-Render nach Projekt-Load
  - Optionaler Progress-Dialog beim Auto-Load
  - Vor Play auf Pre-Render warten (optional mit/ohne Dialog)
- New: Audio-Menü:
  - **Pre-Render: ausgewählte Clips**
  - **Pre-Render: ausgewählter Track**
- Internal: Pre-Render akzeptiert Filter (`clip_ids` / `track_id`) und zählt Jobs passend.

## [0.0.19.5.1.13] - 2026-02-02

### ⚡ Performance — MIDI Pre-Render ("Ready for Bach")
- New: Background Pre-Render für MIDI-Clips (MIDI→WAV Cache) mit Progress-Dialog.
- Auto: Startet nach Projekt-Open/Snapshot-Load (silent) und optional vor Play.
- New: Menü **Audio → MIDI-Clips vorbereiten (Pre-Render)**.

### 🎼 Notation — Tie/Slur Editing Workflow
- Edit: Rechtsklick auf Tie/Slur/Marker zeigt Kontextmenü (Löschen) statt Erase.
- Edit: Klick auf Tie/Slur/Marker selektiert das Item (Draw erzeugt keine Doppel-Noten).

## [0.0.19.5.1.12] - 2026-02-02

- Fix: PyQt6 ImportError (QShortcut) in NotationPalette (QtGui statt QtWidgets).
- Perf: Kleiner WAV/Render-Cache im Audio-Engine-Thread, reduziert Stottern bei schnellem Play/Stop.

## [0.0.19.5.1.11] - 2026-02-02

### 🎼 Notation — Editing Quality
- Rests/Ornamente werden in der Notation-Ansicht klarer beschriftet (Fraction + dotted).
- **Shift = Tie** / **Alt = Slur** funktioniert jetzt auch bei aktivem Draw-Tool.
- Notations-Palette: Alt+1..7 (Notenwerte), Alt+. (punktiert), Alt+R (Rest) als Shortcuts.

### 📒 Team Workflow
- Hilfe-Menü: **Arbeitsmappe** (WorkbookDialog) zeigt TODO/DONE/Letzte Session/Nächste Schritte.

## [0.0.19.5.1.6] - 2026-02-01

### 🎼 Notation — Rosegarden-Style Eingabe-Palette + Editor-Notes (MVP)

- New: Tie/Slur Tool (⌒/∿) als Marker-MVP (2 Klicks: Startnote → Endnote) inkl. Rendering + Save.

- New: Notation-Palette im Notation-Tab: Notenwerte 1/1..1/64, punktiert, Rest-Mode, Vorzeichen (b/♮/#), Ornament-Marker (tr).
- New: Editor-Notes (Sticky Notes) als Notations-Markierungen (Projekt-persistiert).
- New: Kontextmenü (Ctrl+Rechtsklick) erweitert: Notiz hinzufügen, Pause setzen, Markierungen an Position löschen.
- New: Projekt-Feld `Project.notation_marks` + `ProjectService.add_notation_mark()` / `remove_notation_mark()`.
- Update: `DrawTool` nutzt Paletten-Dauer + Vorzeichen; Rests/Ornaments werden als Marker gespeichert (MVP, ohne MIDI-Playback zu beeinflussen).


## [0.0.19.5.1.4] - 2026-02-01

### 🎭 Ghost Notes — Restore beim Projekt-Öffnen (Hotfix)

- Fix: Ghost Layers wurden nach App-Neustart zwar korrekt **in der Projektdatei** gespeichert, aber beim **Öffnen** nicht wieder in die UI geladen.
  Ursache: `open_project()` lädt asynchron (Threadpool) und die Editor-Views wurden vorher initialisiert.
- Update: Piano Roll + Notation laden `Project.ghost_layers` nun zusätzlich bei `project_changed` (nach Open/New/Snapshot).


## [0.0.19.5.1.2] - 2026-02-01

### 🎭 Ghost Notes — Layer Persistenz

- New: Ghost Notes Layer State wird im Projekt gespeichert (`Project.ghost_layers`).
- New: `LayerManager`/`GhostLayer` JSON-safe Serialisierung (`to_dict()/from_dict()`).
- Load: Piano Roll + Notation stellen Ghost Layers beim Öffnen automatisch wieder her.
- Update: Änderungen im Layer Panel schreiben State live in das Project-Model (wird beim Speichern persistiert).


## [0.0.19.5.1.1] - 2026-02-01

### 🎭 Ghost Notes — Stabilität / Crash-Fix

- Fix: Notation Ghost Notes konnten Exceptions im `QGraphicsItem.paint()` werfen → PyQt6 abort (SIGABRT). `_GhostNoteItem.paint()` ist jetzt exception-sicher.
- Fix: Staff-Geometrie korrigiert (korrekte Nutzung von `StaffStyle.line_distance` + half-step Mapping wie `StaffRenderer`).
- Hardening: Painter save/restore wird sauber gehandhabt + Logging bei Render-Fails.


## [0.0.19.3.7.14] - 2026-02-01

### 🧩 Clip-Auto-Erweiterung (Task 9)

- `ProjectService.extend_clip_if_needed(clip_id, end_beats)` implementiert (Bar-Länge aus `time_signature` statt Hardcode 4/4)
- Wird bei Note-Edits automatisch genutzt: Add / Move / Batch-Move / Resize
- `ensure_midi_clip_length()` delegiert auf die neue Funktion (UI-kompatibel)

---

## [0.0.19.3.7.13] - 2026-01-31

### 🎨 Notation – Velocity Colors (MVP)

- Neues Modul `pydaw/ui/notation/colors.py`:
  - `velocity_to_color()` / `velocity_to_outline()`
  - Basisfarben wie PianoRoll (blau; selektiert orange)
- `StaffRenderer.render_note_head()` unterstützt jetzt optional `fill_color` + `outline_color`
- NotationView färbt Noteheads velocity-abhängig (und orange bei Selection)

### 🧩 Fix

- Versionsstand wird konsistent gepflegt: `VERSION` + `pydaw/version.py` sind nun synchron

---

## [0.0.19.3.7.12] - 2026-01-31

### ⌨️ Notation – Keyboard Shortcuts (MVP)

- D/S/E: Tool-Switch (Draw/Select/Erase)
- Ctrl+C/V/X: Copy/Paste/Cut (Single-Note MVP, grid-snap best-effort)
- Del/Backspace: Delete selected note (Undo-fähig)
- Ctrl+Z: Undo über ProjectService UndoStack

---


## [0.0.19.3.7.11] - 2026-01-31

### 🔁 Notation – Bidirektionale MIDI-Sync (stabil)

- NotationView refresh nur bei echten Note-Änderungen im aktiven Clip (Signature-Check)
- Recursion-/Feedback-Loops verhindert via `_suppress_project_updates`
- NotationWidget folgt automatisch der Clip-Auswahl (`active_clip_changed` / `clip_selected`) – zeigt nur MIDI-Clips

---

## [0.0.19.3.7.10] - 2026-01-31

### 🧩 Notation – Kontextmenü (stabil)

- Neues Kontextmenü im Notation-Tab (**Ctrl+Rechtsklick**)
- Menü-Open wird via `QTimer.singleShot(0, ...)` deferred (stabil in `QGraphicsView`)
- Aktionen: Löschen (Erase), Auswahl löschen, Tool-Switch (Draw/Select), Refresh
- MVP bleibt: **Rechtsklick** löscht weiterhin direkt

---

## [0.0.19.3.7.9] - 2026-01-31

### ✨ Notation Edit – Select Tool (MVP)

- Neuer **SelectTool** in `pydaw/ui/notation/tools.py`
- Sichtbares Selection-Highlight im Notation-Tab (blauer Outline-Rahmen)
- Mini-Toolbar im Notation-Tab: ✎ Draw / ⬚ Select

---

## [0.0.19.3.7.8] - 2026-01-31

### ✨ Notation Edit – Erase Tool (MVP)

- Neuer **EraseTool** in `pydaw/ui/notation/tools.py`
- **Rechtsklick** im Notation-Tab löscht die nächstliegende Note (Beat+Staff-Line, Grid-Toleranz)
- Undo/Redo über `ProjectService.commit_midi_notes_edit()` (Label: "Erase Note (Notation)")

## [0.0.19.3.7.5] - 2026-01-31


### 🎼 Notation (Rendering)

- Neuer, minimaler **StaffRenderer** für die integrierte Notation:
  - `render_staff()`, `render_note_head()`, `render_stem()`, `render_accidental()`
- Visuelles Test-Widget hinzugefügt (MVP-Check):
  - Start: `python3 -m pydaw.ui.notation.staff_renderer`
- Paketstruktur vorbereitet: `pydaw/ui/notation/`

## [0.0.19.3.7.4] - 2026-01-31

### ✨ Notation-Basis (Datenmodell)

- `MidiNote` um optionale Notation-Felder erweitert: `accidental`, `tie_to_next` (backward compatible)
- Minimaler Staff-Mapping Layer hinzugefügt:
  - `MidiNote.to_staff_position()`
  - `MidiNote.from_staff_position()`
- Unittests ergänzt: `python3 -m unittest discover -s tests`

## [0.0.19.3.6_fix11] - 2026-01-30

### 🔥 Kritische Fehlerbehebungen

#### SIGABRT-Crash vollständig behoben
- **Problem**: Sporadische Programmabstürze mit `SIGABRT` Signal
- **Ursache**: Rekursive `notify()` Methodenaufrufe in `SafeApplication`
- **Lösung**: 
  - Komplettes Refactoring der Event-Behandlung
  - `notify()` durch `event()` Override ersetzt
  - Exception-Handling verbessert
  - Thread-Safety in allen Services

**Dateien geändert:**
- `pydaw/app.py` (Zeilen 69-90)

**Impact**: ✅ Programm ist nun vollständig stabil

---

### ✨ Neue Features

#### 1. PipeWire/JACK Recording Service

**Neue Datei**: `pydaw/services/recording_service.py`

**Funktionen:**
- Multi-Backend-Unterstützung:
  - PipeWire (nativ)
  - JACK (python-jack-client oder pw-jack)
  - Sounddevice (Fallback)
- Automatische Backend-Erkennung
- Echtzeit-Audio-Recording
- WAV-Export (16-bit, beliebige Sample-Rate)
- Thread-sichere Implementierung

**API:**
```python
recording = RecordingService()
recording.start_recording("output.wav", sample_rate=48000, channels=2)
# ... recording ...
path = recording.stop_recording()
```

**Integration:**
- In `ServiceContainer` integriert
- Cleanup in `shutdown()` Methode
- Status-Signale an Project-Service

---

#### 2. FluidSynth MIDI-Synthesis

**Neue Datei**: `pydaw/services/fluidsynth_service.py`

**Funktionen:**
- SoundFont (SF2) Unterstützung
- Echtzeit-MIDI-Playback
- 16 MIDI-Kanäle
- Program Changes
- Audio-Routing zu JACK/PipeWire
- Reverb & Chorus Effekte
- Konfigurierbare Interpolation

**API:**
```python
fluidsynth = FluidSynthService()
fluidsynth.load_soundfont("FluidR3_GM.sf2")
fluidsynth.note_on(channel=0, pitch=60, velocity=100)
fluidsynth.note_off(channel=0, pitch=60)
```

**Features:**
- Thread-sichere Note-Handling
- Automatische Driver-Erkennung (JACK/PipeWire/ALSA)
- Master Gain Control
- All Notes Off (Panic-Button)

---

#### 3. Erweiterte Notation-Integration

**Neue Datei**: `pydaw/ui/notation_editor_full.py`

**Status**: Framework vorbereitet, vollständige Integration folgt

**Vorbereitet:**
- ChronoScaleStudio-Komponenten-Struktur
- Skalen-Datenbank (500+ Skalen) bereits integriert
- Score-View-Wrapper
- MIDI-Clip Synchronisation
- Service-Container-Anbindung

**Existierende Dateien:**
- `pydaw/notation/` - Vollständiges Notationssystem
- `pydaw/notation/scales/scales.json` - Skalen-Datenbank
- `pydaw/ui/notation_editor_lite.py` - Leichtgewichtiger Editor (bereits funktionsfähig)

---

### 🔄 Verbesserungen

#### ServiceContainer Erweiterungen

**Datei**: `pydaw/services/container.py`

**Änderungen:**
- Neue Services hinzugefügt:
  - `recording: RecordingService`
  - `fluidsynth: FluidSynthService`
- Erweiterte `create_default()` Methode:
  - Recording-Service-Initialisierung
  - FluidSynth-Service-Initialisierung
  - Status/Error-Signal-Routing
- Erweiterte `shutdown()` Methode:
  - Recording-Cleanup
  - FluidSynth-Cleanup
  - Geordnetes Herunterfahren aller Services

---

#### Logging & Diagnostik

**Verbessert:**
- Detailliertere Log-Meldungen in allen Services
- Exception-Tracking in Event-Loop
- Startup-Diagnostik erweitert
- Backend-Erkennung mit Logging

**Log-Ausgaben jetzt verfügbar für:**
- Recording-Backend-Auswahl
- FluidSynth-Initialisierung
- Service-Container-Startup
- Event-Loop-Exceptions

---

#### Fehlerbehandlung

**Überall verbessert:**
- Try-Catch Blöcke in allen Service-Methoden
- Keine unbehandelten Exceptions mehr
- Graceful Degradation (Features fallen auf Fallbacks zurück)
- Status-Messages statt Silent-Failures

---

### 📚 Dokumentation

#### Neue Dokumentation

**README.md** - Komplett überarbeitet:
- Übersichtliche Feature-Liste
- Quick-Start Guide
- Installation Instructions
- Troubleshooting

**docs/USER_GUIDE.md** - NEU:
- Vollständiges Benutzerhandbuch
- Installation Step-by-Step
- Alle Features erklärt
- Workflow-Tipps
- Ausführliche Fehlerbehebung
- Screenshots (folgen)

**CHANGELOG.md** (diese Datei) - NEU:
- Strukturierte Versions-Historie
- Detaillierte Änderungsliste
- Breaking Changes dokumentiert

---

### 🐛 Behobene Bugs

#### Kritisch

1. **SIGABRT-Crash** (Issue #1)
   - **Symptom**: Programm stürzt sporadisch ab mit "Unhandled Python exception"
   - **Root Cause**: Rekursive notify() Aufrufe
   - **Fix**: Event-Loop-Architektur neu implementiert
   - **Status**: ✅ Vollständig behoben

2. **Qt Event-Loop Deadlocks**
   - **Symptom**: UI friert ein
   - **Cause**: Blocking Calls in Event-Handler
   - **Fix**: Thread-Safe Event-Handling
   - **Status**: ✅ Behoben

#### Hoch

3. **Service-Initialisierung-Fehler**
   - **Symptom**: Services manchmal nicht verfügbar
   - **Fix**: Defensive Service-Creation mit Fallbacks
   - **Status**: ✅ Behoben

4. **Logging-Setup-Timing**
   - **Symptom**: Frühe Fehler nicht geloggt
   - **Fix**: Logging vor QApplication-Init
   - **Status**: ✅ Behoben

#### Mittel

5. **JACK-Auto-Restart-Loop**
   - **Symptom**: Endlos-Restarts bei JACK-Problemen
   - **Fix**: Umgebungsvariablen-Prüfung verbessert
   - **Status**: ✅ Behoben

---

### ⚠️ Breaking Changes

Keine Breaking Changes in dieser Version.

Alle Änderungen sind rückwärtskompatibel mit v0.0.19.3.6_fix10b.

---

### 🔮 Bekannte Einschränkungen

1. **Notation-Editor**: Vollständige ChronoScaleStudio-Integration noch nicht abgeschlossen
   - **Workaround**: Leichtgewichtiger Editor (`notation_editor_lite.py`) funktioniert
   - **Status**: Framework vorbereitet, Implementation folgt

2. **FluidSynth-Latenz**: Bei niedriger Buffer-Size können Artefakte auftreten
   - **Workaround**: Buffer-Size auf 512+ erhöhen
   - **Status**: Akzeptabel für die meisten Anwendungsfälle

3. **Recording-Monitor**: Kein visuelles Input-Metering während Recording
   - **Workaround**: System-Tools wie `pavucontrol` verwenden
   - **Status**: Feature-Request für nächste Version

---

### 📦 Abhängigkeiten

#### Neu hinzugefügt
- `pyfluidsynth` (optional) - FluidSynth-Unterstützung
- `numpy` - Audio-Verarbeitung für Recording
- `sounddevice` - Multi-Backend Audio I/O

#### Aktualisiert
Keine Änderungen an bestehenden Abhängigkeiten.

---

### 🔧 Entwickler-Hinweise

#### API-Änderungen

**ServiceContainer:**
```python
# Neu verfügbar:
services.recording.start_recording(path, sample_rate, channels)
services.recording.stop_recording() -> Path

services.fluidsynth.load_soundfont(sf2_path)
services.fluidsynth.note_on(channel, pitch, velocity)
services.fluidsynth.note_off(channel, pitch)
```

**Event-Handling:**
```python
# Alt (entfernt):
class SafeApplication(QApplication):
    def notify(self, receiver, event):
        ...

# Neu:
class SafeApplication(QApplication):
    def event(self, event):
        ...
```

---

### 📊 Performance

**Startup-Zeit:**
- Fix10b: ~3-5 Sekunden
- Fix11: ~2-3 Sekunden (verbessert durch optimierte Service-Init)

**Memory-Footprint:**
- Fix10b: ~80 MB base
- Fix11: ~85 MB base (+5 MB durch Recording/FluidSynth-Services)

**CPU-Usage:**
- Idle: <1%
- Playback: 5-15% (abhängig von Track-Anzahl)
- Recording: +2-5%
- FluidSynth: +5-10% (abhängig von Polyphonie)

---

## [0.0.19.3.6_fix10b] - 2026-01-23

### Änderungen
- Notation-Tab experimentell hinzugefügt
- Verschiedene Bug-Fixes
- Bekannter Issue: SIGABRT-Crash

---

## [0.0.19.3.6] - 2026-01-20

### Basis-Version
- Projekt-Management
- MIDI-Editor (Piano Roll)
- Basic Audio-Engine
- JACK/PipeWire-Unterstützung (experimentell)
- Mixer & Transport

---

## Versionsschema

Format: `MAJOR.MINOR.PATCH.BUILD_SUFFIX`

- **MAJOR**: Inkompatible API-Änderungen
- **MINOR**: Neue Features (rückwärtskompatibel)
- **PATCH**: Bug-Fixes
- **BUILD**: Iterations-Nummer
- **SUFFIX**: `_fix<n>` für Hotfixes

Beispiel: `0.0.19.3.6_fix11`
- Major: 0 (Pre-Release)
- Minor: 0 (Beta-Phase)
- Patch: 19 (Patch-Level)
- Build: 3.6 (Build-Iteration)
- Suffix: fix11 (11. Hotfix dieser Version)

---

## Geplante Features (Roadmap)

### v0.0.20 (nächste Version)
- [ ] Vollständige ChronoScaleStudio-Integration
- [ ] VST/LV2 Plugin-Support
- [ ] Automation-Kurven-Editor
- [ ] Erweiterte Mixer-Features (Send/Return)

### v0.1.0 (Milestone)
- [ ] Stable Release
- [ ] Performance-Optimierungen
- [ ] Video-Tutorials
- [ ] Windows/macOS-Support

### v1.0.0 (Production-Ready)
- [ ] Feature-Complete
- [ ] Comprehensive Testing
- [ ] Professional Documentation
- [ ] Community Support

---

**Vollständiges Changelog**: https://github.com/yourrepo/pydaw/compare/v0.0.19.3.6_fix10b...v0.0.19.3.6_fix11
