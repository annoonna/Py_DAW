"""Mixer + Library panels (v0.0.15).

v0.0.15:
- Mixer strips show editable placeholder controls for Volume/Pan.
- Values are stored in Track.volume / Track.pan (project model) and refreshed live.
"""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QScrollArea,
    QFrame,
    QHBoxLayout,
    QSlider,
    QComboBox,
)
from PyQt6.QtCore import Qt

from pydaw.services.project_service import ProjectService


class _MixerStrip(QFrame):
    def __init__(self, project: ProjectService, track_id: str, audio_engine=None, parent=None):
        super().__init__(parent)
        self.project = project
        self.track_id = track_id
        self.audio_engine = audio_engine  # FIXED v0.0.19.7.14: For LIVE master volume! ✅
        self.setFrameShape(QFrame.Shape.StyledPanel)

        row = QHBoxLayout(self)
        row.setContentsMargins(8, 6, 8, 6)
        row.setSpacing(8)

        self.lbl = QLabel("")
        # FIXED v0.0.19.7.8: Master Track kann auch umbenannt werden!
        self.lbl.setToolTip("Doppelklick um Track umzubenennen")
        self.lbl.setCursor(Qt.CursorShape.PointingHandCursor)
        self.lbl.setStyleSheet("QLabel { padding: 4px; } QLabel:hover { background: #444; }")
        self.lbl.mouseDoubleClickEvent = lambda ev: self._rename_track()
        row.addWidget(self.lbl)

        self.lbl_mode = QLabel("Auto:")
        row.addWidget(self.lbl_mode)
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["off", "read", "write"])
        row.addWidget(self.cmb_mode)

        row.addStretch(1)

        row.addWidget(QLabel("Vol"))
        self.sld_vol = QSlider(Qt.Orientation.Horizontal)
        self.sld_vol.setRange(0, 100)
        self.sld_vol.setFixedWidth(140)
        # FIXED v0.0.19.7.8: Master Volume funktioniert jetzt! ✅
        self.sld_vol.valueChanged.connect(self._on_vol)
        row.addWidget(self.sld_vol)

        row.addWidget(QLabel("Pan"))
        self.sld_pan = QSlider(Qt.Orientation.Horizontal)
        self.sld_pan.setRange(-100, 100)
        self.sld_pan.setFixedWidth(140)
        # FIXED v0.0.19.7.8: Master Pan funktioniert jetzt! ✅
        self.sld_pan.valueChanged.connect(self._on_pan)
        row.addWidget(self.sld_pan)

        self.lbl_vals = QLabel("")
        row.addWidget(self.lbl_vals)

        self.cmb_mode.currentTextChanged.connect(self._on_mode)

        self.refresh_from_model()

    def _track(self):
        return next((t for t in self.project.ctx.project.tracks if t.id == self.track_id), None)

    def refresh_from_model(self) -> None:
        t = self._track()
        if not t:
            return
        self.lbl.setText(f"{t.name} [{t.kind}]")
        self.cmb_mode.blockSignals(True)
        self.cmb_mode.setCurrentText(getattr(t, "automation_mode", "off"))
        self.cmb_mode.blockSignals(False)

        self.sld_vol.blockSignals(True)
        self.sld_pan.blockSignals(True)
        self.sld_vol.setValue(int(round(float(getattr(t, "volume", 0.8)) * 100.0)))
        self.sld_pan.setValue(int(round(float(getattr(t, "pan", 0.0)) * 100.0)))
        self.sld_vol.blockSignals(False)
        self.sld_pan.blockSignals(False)

        self.lbl_vals.setText(f"{float(getattr(t,'volume',0.0)):.2f} / {float(getattr(t,'pan',0.0)):.2f}")
        
        # FIXED v0.0.19.7.14: Set initial master volume/pan in audio engine! ✅
        if getattr(t, "kind", "") == "master" and self.audio_engine:
            self.audio_engine.set_master_volume(float(getattr(t, "volume", 0.8)))
            self.audio_engine.set_master_pan(float(getattr(t, "pan", 0.0)))

    def _on_mode(self, mode: str) -> None:
        t = self._track()
        if not t:
            return
        t.automation_mode = str(mode)
        self.project.project_updated.emit()
        self.project.status.emit(f"Automation Mode: {t.name} = {mode}")

    def _rename_track(self) -> None:
        """Open rename dialog when user double-clicks track name in mixer."""
        t = self._track()
        if not t:
            return
        
        # Don't allow renaming master track
        if t.kind == "master":
            return
        
        # Show input dialog
        from PyQt6.QtWidgets import QInputDialog
        new_name, ok = QInputDialog.getText(
            self,
            "Track umbenennen",
            f"Neuer Name für '{t.name}':",
            text=t.name
        )
        
        if ok and new_name.strip():
            try:
                self.project.rename_track(t.id, new_name.strip())
            except Exception:
                pass

    def _on_vol(self, v: int) -> None:
        """FIXED v0.0.19.7.14: Update UI Label + LIVE master volume! ✅"""
        t = self._track()
        if not t:
            return
        t.volume = max(0.0, min(1.0, float(v) / 100.0))
        self.lbl_vals.setText(f"{t.volume:.2f} / {t.pan:.2f}")
        
        # FIXED v0.0.19.7.14: LIVE Master Volume Update! ✅
        if getattr(t, "kind", "") == "master" and self.audio_engine:
            self.audio_engine.set_master_volume(t.volume)
        
        # PERFORMANCE FIX: Kein project_updated während Drag! ✅

    def _on_pan(self, v: int) -> None:
        """FIXED v0.0.19.7.14: Update UI Label + LIVE master pan! ✅"""
        t = self._track()
        if not t:
            return
        t.pan = max(-1.0, min(1.0, float(v) / 100.0))
        self.lbl_vals.setText(f"{t.volume:.2f} / {t.pan:.2f}")
        
        # FIXED v0.0.19.7.14: LIVE Master Pan Update! ✅
        if getattr(t, "kind", "") == "master" and self.audio_engine:
            self.audio_engine.set_master_pan(t.pan)
        
        # PERFORMANCE FIX: Kein project_updated während Drag! ✅


class MixerPanel(QWidget):
    def __init__(self, project: ProjectService, audio_engine=None, parent=None):
        super().__init__(parent)
        self.project = project
        self.audio_engine = audio_engine  # FIXED v0.0.19.7.14: For LIVE master volume! ✅
        self._strips: dict[str, _MixerStrip] = {}
        self._build_ui()
        self.project.project_updated.connect(self.refresh)
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        # FIXED v0.0.19.7.7: Header with + Add and − Remove buttons
        header = QHBoxLayout()
        header.addWidget(QLabel("Mixer"))
        
        from PyQt6.QtWidgets import QPushButton, QMenu
        
        # + Add Button
        self.btn_add = QPushButton("+ Add")
        self.btn_add.setToolTip("Track hinzufügen")
        self.btn_add.setFixedWidth(80)
        self.btn_add.clicked.connect(self._show_add_menu)
        header.addWidget(self.btn_add)
        
        # − Remove Button  
        self.btn_remove = QPushButton("− Remove")
        self.btn_remove.setToolTip("Ausgewählten Track entfernen")
        self.btn_remove.setFixedWidth(80)
        self.btn_remove.clicked.connect(self._remove_selected_track)
        header.addWidget(self.btn_remove)
        
        header.addStretch(1)
        layout.addLayout(header)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        layout.addWidget(self.scroll, 1)

        self.inner = QWidget()
        self.inner_layout = QVBoxLayout(self.inner)
        self.inner_layout.setContentsMargins(0, 0, 0, 0)
        self.inner_layout.setSpacing(6)
        self.inner_layout.addStretch(1)

        self.scroll.setWidget(self.inner)
        
        # FIXED v0.0.19.7.7: DEL Key support
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
    
    def _show_add_menu(self) -> None:
        """Show menu to add different track types."""
        from PyQt6.QtWidgets import QMenu
        menu = QMenu(self)
        a_audio = menu.addAction("Audio-Spur")
        a_inst = menu.addAction("Instrumenten-Spur")
        a_bus = menu.addAction("FX/Bus-Spur")
        
        action = menu.exec(self.btn_add.mapToGlobal(self.btn_add.rect().bottomLeft()))
        
        if action == a_audio:
            self.project.add_track("audio")
        elif action == a_inst:
            self.project.add_track("instrument")
        elif action == a_bus:
            self.project.add_track("bus")
    
    def _remove_selected_track(self) -> None:
        """Remove currently selected track."""
        # Get selected track from project service
        tid = getattr(self.project, "selected_track_id", "") or ""
        if not tid:
            return
        
        # Don't remove master track
        trk = next((t for t in self.project.ctx.project.tracks if t.id == tid), None)
        if trk and getattr(trk, "kind", "") == "master":
            return
        
        try:
            self.project.delete_track(tid)
        except Exception:
            pass
    
    def keyPressEvent(self, event) -> None:
        """FIXED v0.0.19.7.7: DEL Key removes selected track."""
        from PyQt6.QtGui import QKeyEvent
        
        if event.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            self._remove_selected_track()
            event.accept()
            return
        
        super().keyPressEvent(event)


    def refresh(self) -> None:
        # remove missing strips
        existing_ids = {t.id for t in self.project.ctx.project.tracks}
        for tid in list(self._strips.keys()):
            if tid not in existing_ids:
                w = self._strips.pop(tid)
                w.deleteLater()

        # ensure strips
        # clear layout widgets (except stretch) and rebuild
        while self.inner_layout.count() > 1:
            item = self.inner_layout.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None)

        for trk in self.project.ctx.project.tracks:
            strip = self._strips.get(trk.id)
            if strip is None:
                # FIXED v0.0.19.7.14: Pass audio_engine für LIVE master volume! ✅
                strip = _MixerStrip(self.project, trk.id, self.audio_engine)
                self._strips[trk.id] = strip
            strip.refresh_from_model()
            self.inner_layout.insertWidget(self.inner_layout.count() - 1, strip)


class LibraryPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)
        layout.addWidget(QLabel("Bibliothek/Browser (Platzhalter)"))
        layout.addWidget(QLabel("Hier kommen später: Samples, Plugins, Presets, Medienpool…"))
        layout.addStretch(1)
