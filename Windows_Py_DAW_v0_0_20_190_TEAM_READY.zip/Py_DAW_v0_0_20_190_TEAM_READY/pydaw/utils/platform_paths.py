"""Platform-aware path helpers (cache/config/log).

We keep the app's files in user-writable locations:
- Windows:
    cache: %LOCALAPPDATA%\ChronoScaleStudio\Cache
    config: %APPDATA%\ChronoScaleStudio\Config
- Linux:
    cache: $XDG_CACHE_HOME/ChronoScaleStudio or ~/.cache/ChronoScaleStudio
    config: $XDG_CONFIG_HOME/ChronoScaleStudio or ~/.config/ChronoScaleStudio
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


APP_NAME = "ChronoScaleStudio"


def is_windows() -> bool:
    return sys.platform.startswith("win")


def cache_root(app_name: str = APP_NAME) -> Path:
    if is_windows():
        base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home())
        p = Path(base) / app_name / "Cache"
        p.mkdir(parents=True, exist_ok=True)
        return p
    # Linux/macOS fallback (keeps previous behavior)
    base = os.environ.get("XDG_CACHE_HOME") or str(Path.home() / ".cache")
    p = Path(base) / app_name
    p.mkdir(parents=True, exist_ok=True)
    return p


def config_root(app_name: str = APP_NAME) -> Path:
    if is_windows():
        base = os.environ.get("APPDATA") or os.environ.get("LOCALAPPDATA") or str(Path.home())
        p = Path(base) / app_name / "Config"
        p.mkdir(parents=True, exist_ok=True)
        return p
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    p = Path(base) / app_name
    p.mkdir(parents=True, exist_ok=True)
    return p


def log_root(app_name: str = APP_NAME) -> Path:
    # Keep logs in cache by default
    p = cache_root(app_name) / "logs"
    p.mkdir(parents=True, exist_ok=True)
    return p
