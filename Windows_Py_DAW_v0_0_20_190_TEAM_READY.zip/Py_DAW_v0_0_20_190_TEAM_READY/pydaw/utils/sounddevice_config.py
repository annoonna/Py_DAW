"""sounddevice (PortAudio) configuration helpers.

Windows focus:
- Prefer WASAPI when available (more stable/low-latency than MME in many setups).
- Optional WASAPI Exclusive Mode via env var.

Env:
- PYDAW_SD_HOSTAPI: "wasapi" (default on Windows), "asio", "directsound", "mme", "auto"
- PYDAW_WASAPI_EXCLUSIVE: "1" to request exclusive mode (best effort)
"""

from __future__ import annotations

import os
import sys
from typing import Optional, Tuple


def _is_windows() -> bool:
    return sys.platform.startswith("win")


def _env_truthy(name: str) -> bool:
    return str(os.environ.get(name, "")).strip().lower() in ("1", "true", "yes", "y", "on")


def preferred_hostapi() -> str:
    if not _is_windows():
        return "auto"
    return (os.environ.get("PYDAW_SD_HOSTAPI") or "wasapi").strip().lower()


def pick_device(kind: str = "output") -> Optional[int]:
    """Pick a reasonable default device index for the preferred host API.

    Returns a *global* device index (sounddevice/PortAudio style), or None.
    """
    try:
        import sounddevice as sd  # type: ignore
    except Exception:
        return None

    try:
        hostpref = preferred_hostapi()
        if hostpref in ("auto", "", None):
            return None

        hostapis = sd.query_hostapis()
        # Find hostapi by name
        target_id = None
        for i, ha in enumerate(hostapis):
            name = str(ha.get("name", "")).lower()
            if hostpref in name:
                target_id = i
                break
        if target_id is None:
            return None

        ha = hostapis[target_id]
        if kind == "input":
            d = int(ha.get("default_input_device", -1))
            if d >= 0:
                return d
        else:
            d = int(ha.get("default_output_device", -1))
            if d >= 0:
                return d

        # Fallback: pick first device from hostapi with channels
        devs = sd.query_devices()
        dev_ids = ha.get("devices") or []
        for di in dev_ids:
            try:
                dev = devs[int(di)]
                if kind == "input" and int(dev.get("max_input_channels", 0)) > 0:
                    return int(di)
                if kind != "input" and int(dev.get("max_output_channels", 0)) > 0:
                    return int(di)
            except Exception:
                continue
    except Exception:
        return None

    return None


def wasapi_extra_settings():
    """Return a PortAudio WASAPI settings object if requested (best effort)."""
    if not _is_windows():
        return None
    if not _env_truthy("PYDAW_WASAPI_EXCLUSIVE"):
        return None
    try:
        import sounddevice as sd  # type: ignore
        WasapiSettings = getattr(sd, "WasapiSettings", None)
        if WasapiSettings is None:
            return None
        return WasapiSettings(exclusive=True)
    except Exception:
        return None
