"""Installer helper for Py_DAW / ChronoScaleStudio.

Usage:
    python install.py

It will:
- warn if you're not inside a virtual environment
- install/upgrade pip tooling
- install requirements (Windows uses requirements_windows.txt when present)

Notes:
- On Linux, JACK/PipeWire system components are NOT installed here (distro packages).
- On Windows, WASAPI is used via sounddevice/PortAudio (no extra system packages required).
- Optional SF2/MIDI rendering uses FluidSynth. Install it separately and ensure `fluidsynth.exe`
  is in PATH, or set `FLUIDSYNTH_PATH` to the full path of fluidsynth.exe.
"""

from __future__ import annotations

import os
import sys
import subprocess
from pathlib import Path


def _is_windows() -> bool:
    return sys.platform.startswith("win")


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def _venv_hint() -> str:
    if _is_windows():
        return (
            "Empfehlung (Windows):\n"
            "  py -m venv myenv\n"
            "  myenv\\Scripts\\activate  (CMD)\n"
            "  myenv\\Scripts\\Activate.ps1  (PowerShell)\n"
        )
    return "Empfehlung (Linux/macOS):\n  python3 -m venv myenv && source myenv/bin/activate\n"


def main() -> int:
    here = Path(__file__).resolve().parent

    # Prefer Windows-specific requirements when available.
    req = here / "requirements.txt"
    req_win = here / "requirements_windows.txt"
    if _is_windows() and req_win.exists():
        req = req_win

    if not req.exists():
        print("Requirements file not found:", req)
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        print(_venv_hint())

    py = sys.executable

    # Upgrade tooling (best effort)
    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    # Install deps
    _run([py, "-m", "pip", "install", "-r", str(req)])

    print("\nOK. Starte danach mit: python main.py")
    if _is_windows():
        print("Windows Audio: Standard ist WASAPI. Optional kannst du setzen:")
        print("  set PYDAW_SD_HOSTAPI=wasapi")
        print("  set PYDAW_WASAPI_EXCLUSIVE=1   (nur wenn du Exclusive Mode willst)")
        print("Qt/Rendering: falls schwarzes Fenster/crash, setze:")
        print("  set PYDAW_QT_OPENGL=angle")
    else:
        print("Optional: Audio/MIDI Abhängigkeiten können Systempakete erfordern (PipeWire-JACK/JACK/qpwgraph).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
