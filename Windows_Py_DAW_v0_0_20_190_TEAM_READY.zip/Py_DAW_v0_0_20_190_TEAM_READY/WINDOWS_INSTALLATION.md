# Windows Installation (TEAM_READY)

## 1) Virtualenv (empfohlen)
CMD:
```
py -m venv myenv
myenv\Scripts\activate
```

PowerShell:
```
py -m venv myenv
myenv\Scripts\Activate.ps1
```

## 2) Dependencies installieren
```
python install.py
```

## 3) Start
```
python main.py
```

## Audio Hinweise (Windows)
- Standard ist WASAPI via `sounddevice`.
- Optional:
  - `PYDAW_SD_HOSTAPI=wasapi`
  - `PYDAW_WASAPI_EXCLUSIVE=1` (Exclusive Mode – best effort)

## Wenn Qt/Rendering Probleme macht (schwarzes Fenster / Crash)
Setze (CMD):
```
set PYDAW_QT_OPENGL=angle
```

## Optional: FluidSynth (SF2/MIDI Render)
Installiere FluidSynth und stelle sicher, dass `fluidsynth.exe` in PATH ist,
oder setze:
- `FLUIDSYNTH_PATH=C:\\Path\\To\\fluidsynth.exe`
