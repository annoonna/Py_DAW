"""Platform helpers (Windows/Linux/macOS)."""
