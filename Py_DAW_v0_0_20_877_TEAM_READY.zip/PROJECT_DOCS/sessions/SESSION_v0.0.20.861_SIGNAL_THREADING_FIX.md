# Session Log — v0.0.20.861

**Datum:** 2026-03-28
**Kollege:** Claude Opus 4.6
**Basis:** v0.0.20.860

## Erledigt

### v0.0.20.861 — Thread-Safe Signal Fix
- **ROOT CAUSE:** QTimer.singleShot(0, lambda) aus asyncio-Thread ist nicht
  thread-safe in PyQt6 — Chat/Cursor/Ops kamen nicht im GUI-Thread an
- **FIX:** 8 pyqtSignals ersetzen alle QTimer.singleShot Cross-Thread-Calls
- **ENTFERNT:** 6 _safe Wrapper-Methoden (_append_chat_safe, _on_remote_cursor_safe,
  _on_remote_operation_safe, _on_remote_presence_safe, _refresh_users_safe,
  _on_remote_presence_safe_host_leave)
- **GETESTET:** LAN-Test von Anno bestätigt User-Liste funktioniert,
  Chat-Nachrichten fehlten → nach Fix sollten sie ankommen

## Geaenderte Dateien
- pydaw/ui/collab_panel.py

## Zusammenfassung Gesamtsession (v0.0.20.856 → v0.0.20.861)
- .856: Collab repariert (websockets v16)
- .857: Thread-Leak gefixt
- .858: Cursor Sharing + 5 Ops
- .859: Transport Sync + Mixer Live Sync
- .860: mDNS + Conflict Detection + Undo/Redo
- .861: Thread-Safe Signal Fix (Chat/Ops tatsächlich sichtbar)
