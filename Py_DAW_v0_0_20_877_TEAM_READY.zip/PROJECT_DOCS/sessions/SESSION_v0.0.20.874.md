# Session Log — v0.0.20.874

**Datum:** 2026-03-28
**Kollege:** Claude Opus 4.6

## Erledigt

### CRITICAL: Instrument-Instanziierung auf Remote
- **Root Cause:** `track_add` Handler setzte Model-Felder (plugin_type etc.) aber rief NIE `set_instrument_on_track()` auf → Spuren ohne Instrument
- **Fix in track_add:** Nach Model-Update jetzt `dp.set_instrument_on_track(tid, plugin_type)` + Engine-Fingerprint invalidieren + `rebuild_fx_maps()`
- **Fix in full_sync (Late-Joiner):** Loop über ALLE Tracks mit plugin_type → `set_instrument_on_track()` für jeden

### Collab Arranger Ops
- **7 Collab-Hooks in project_service.py:** move_clip, resize_clip, scale_clip_content, trim_clip_left, move_clip_track, rename_track, rename_clip
- **Ctrl+Drag Batch Copy:** arranger_canvas.py sendet `clip_copy_batch` mit MIDI-Notes
- **3 Remote-Handler:** clip_trim, clip_rename, clip_copy_batch in collab_panel.py
- **3 Server-Passthroughs:** clip_trim, clip_rename, clip_copy_batch in collab_service.py

### Spam Fixes
- **VST3 Nekobi Spam Fix:** Max 5 process errors pro Plugin, dann suppress
- **MediaSync Hash-Dedup:** `_offered_hashes` Set verhindert Re-Offer gleicher Dateien

## Nächste Schritte
- Live-Test: Instrument-Sync bei Track-Add + Late-Join
- Live-Test: Arranger Ops + Ctrl+Drag + Rename im Collab
- Segfault beim Beenden nach Collab-Session
- Built-in Instrumente Sample-Pfade auf Remote
