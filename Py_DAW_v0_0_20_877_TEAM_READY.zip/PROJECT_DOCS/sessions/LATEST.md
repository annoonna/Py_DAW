# Session Log — v0.0.20.877

**Datum:** 2026-03-29
**Kollege:** Claude Opus 4.6

## Erledigt

### CRITICAL FIX: Instrumente bei Kollaboration — ROOT CAUSE GEFUNDEN

**Das echte Problem (bewiesen durch Logs):**
1. Onna weist Bachs Orgel zu → `add_instrument_to_track()` wird aufgerufen
2. `_emit_project_updated()` feuert, aber nutzt `_current_track` um den Track zu identifizieren
3. `_current_track` zeigt noch auf den ALTEN Track (Master) → device_sync wird entweder mit falschem Track oder gar nicht gesendet
4. Anno empfängt nur `track_add` (ohne plugin_type, weil Track erst erstellt, dann Instrument zugewiesen wird)

**Fix:** Direkter Collab-Hook in `add_instrument_to_track()` mit dem KORREKTEN `track_id` Parameter statt `_current_track`.

### Geänderte Dateien
- `pydaw/ui/device_panel.py` — Direkter Collab-Hook in add_instrument_to_track()
- `pydaw/ui/collab_panel.py` — _device_panel Fix + add_instrument_to_track + INFO Logging
