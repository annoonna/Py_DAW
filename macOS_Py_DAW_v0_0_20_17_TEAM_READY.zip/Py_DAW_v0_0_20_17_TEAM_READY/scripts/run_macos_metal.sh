#!/usr/bin/env bash
set -euo pipefail

# macOS launcher: CoreAudio + (optional) Metal flags for Qt
#
# Usage:
#   source myenv/bin/activate
#   bash scripts/run_macos_metal.sh

export QT_MAC_WANTS_LAYER=${QT_MAC_WANTS_LAYER:-1}
export QSG_RHI_BACKEND=${QSG_RHI_BACKEND:-metal}

# Optional: if your Qt build ships ANGLE, this can map OpenGL -> Metal.
# If you see GL context creation errors, comment this out.
# export QT_OPENGL=angle

python3 main.py
