# 🍎 macOS Setup (CoreAudio + optional Metal)

Ziel: PyDAW/ChronoScaleStudio unter macOS mit **CoreAudio** betreiben.
Das Projekt nutzt dafür **sounddevice (PortAudio)** – JACK ist auf macOS **nicht nötig**.

> Hinweis: Für Audio-Input (Recording) kann macOS eine **Mikrofon-Berechtigung** verlangen.

---

## 1) System-Abhängigkeiten (Homebrew)

```bash
brew update

# PortAudio + libsndfile (sounddevice + soundfile)
brew install portaudio libsndfile

# Optional: FluidSynth (für SF2/SoundFonts)
brew install fluidsynth
```

Wenn du **FluidSynth** nutzen willst:

```bash
pip install pyfluidsynth
```

---

## 2) Python Setup

```bash
python3 -m venv myenv
source myenv/bin/activate

pip install --upgrade pip setuptools wheel
pip install -r requirements.txt

python3 main.py
```

---

## 3) Audio: CoreAudio (Standard)

Unter macOS nutzt `sounddevice` automatisch **CoreAudio**.
Du musst nichts mit JACK konfigurieren.

Wenn du Probleme mit Devices hast:

```python
import sounddevice as sd
print(sd.query_devices())
```

---

## 4) Metal (Rendering) – pragmatischer Start

Qt6 nutzt unter macOS für Qt Quick typischerweise RHI/Metal.
Unsere GUI ist überwiegend Qt Widgets/QPainter; das ist zuverlässig und benötigt kein GPU-Setup.

Für Experimente/Performance (v.a. wenn Qt Quick später dazukommt) kannst du das mit Env-Flags testen:

```bash
export QT_MAC_WANTS_LAYER=1
export QSG_RHI_BACKEND=metal

# Optional (nur wenn du das OpenGL-Overlay nutzt):
# Manche Qt-Builds unterstützen ANGLE (OpenGL ES → Metal). Falls es nicht klappt, weglassen.
# export QT_OPENGL=angle

python3 main.py
```

**GPU Waveforms** (Arranger Overlay) ist aktuell ein **OpenGL/QOpenGLWidget**-Pfad.
Auf macOS ist OpenGL zwar noch verfügbar, aber deprecated – deshalb ist das Feature **standardmäßig OFF**.

---

## 5) Bekannte Stolpersteine

- **Mikrofon-Rechte:** Recording kann sonst „stumm“ sein → Systemeinstellungen → Datenschutz → Mikrofon.
- **Puffer/Knackser:** Buffer Size erhöhen (z. B. 256/512), SampleRate 48k.
- **GPU Overlay:** Bei Problemen einfach aus lassen (Ansicht → GPU Waveforms OFF).
