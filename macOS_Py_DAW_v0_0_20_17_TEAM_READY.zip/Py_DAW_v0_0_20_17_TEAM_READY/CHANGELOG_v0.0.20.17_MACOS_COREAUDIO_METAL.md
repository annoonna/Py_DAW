# CHANGELOG v0.0.20.17 — macOS: CoreAudio + Metal-Flags

**Datum:** 2026-02-08  
**Basis:** v0.0.20.16

---

## ✅ macOS Port – erste saubere Grundlage

### Audio: CoreAudio statt JACK
- macOS: Audio läuft über **sounddevice** (PortAudio → **CoreAudio**).
- Linux: JACK bleibt **optional** (Routing/qpwgraph) – aber **nur** als Linux-Dependency.

### Rendering: Metal (best-effort)
- Für macOS setzen wir früh (vor Qt-Init) Defaults:
  - `QT_MAC_WANTS_LAYER=1`
  - `QSG_RHI_BACKEND=metal`
- Zusätzlich gibt es ein Startskript `scripts/run_macos_metal.sh`.

> Hinweis: Die aktuelle GPU-Waveforms-Overlay-Implementierung ist **QOpenGLWidget/OpenGL**.  
> Unter macOS ist OpenGL deprecated → Feature bleibt **opt-in** (Ansicht → GPU Waveforms).

---

## Dateien

### Geändert
- `requirements.txt` — Linux-only JACK Dependency via environment marker
- `pydaw/app.py` — macOS Metal-Flags (best-effort Defaults)
- `INSTALL.md`, `README_TEAM.md`, `BRIEF_AN_KOLLEGEN.md` — cross-platform Hinweise

### Neu
- `docs/MACOS.md` — Homebrew + CoreAudio Setup + Metal Flags
- `scripts/run_macos_metal.sh` — macOS Launcher

---

## Test-Checkliste (macOS)

1. `pip install -r requirements.txt` läuft ohne JACK.
2. `python3 main.py` startet, Audio (CoreAudio) funktioniert.
3. (Optional) `bash scripts/run_macos_metal.sh` startet ebenfalls.
4. Ansicht → GPU Waveforms AN/AUS verursacht keinen UI-„Arranger kaputt“ Effekt.
