"""Hybrid Audio Engine (v0.0.20.14) — C-Speed Audio, Python GUI.

v0.0.20.14 Changes:
- Per-track volume/pan/mute/solo via ParamRingBuffer + TrackParamState
- render_for_jack() fully integrated into JACK process callback
- HybridSounddeviceCallback: drop-in replacement for arrangement playback
- Track index registry for mapping track_id → track_idx

Architecture:
    ┌──────────────────────────────────────────────────────────┐
    │                      GUI THREAD (PyQt6)                  │
    │  ┌────────────┐  ┌─────────┐  ┌──────────┐  ┌────────┐ │
    │  │ Arranger   │  │ Mixer   │  │Transport │  │Sampler │ │
    │  └─────┬──────┘  └────┬────┘  └────┬─────┘  └───┬────┘ │
    │        │              │            │             │       │
    │        ▼              ▼            ▼             ▼       │
    │  ┌─────────────────────────────────────────────────────┐ │
    │  │    ParamRingBuffer (lock-free, per-track + master)   │ │
    │  └─────────────────────────┬───────────────────────────┘ │
    └────────────────────────────┼─────────────────────────────┘
                                 │ (zero-lock boundary)
    ┌────────────────────────────┼─────────────────────────────┐
    │                    AUDIO THREAD                          │
    │  ┌─────────────────────────▼───────────────────────────┐ │
    │  │          HybridAudioCallback                         │ │
    │  │  • drain_into(TrackParamState) → per-track mix       │ │
    │  │  • per-track vol/pan/mute/solo with IIR smoothing    │ │
    │  │  • render arrangement (numpy C-speed)                │ │
    │  │  • mix pull sources (Sampler, FluidSynth)            │ │
    │  │  • master vol/pan (smoothed, click-free)             │ │
    │  │  • soft limiter + metering ring                      │ │
    │  └──────────────────────────────────────────────────────┘ │
    └──────────────────────────────────────────────────────────┘
"""
from __future__ import annotations

import math
import threading
from typing import Any, Callable, Dict, List, Optional, Tuple

try:
    import numpy as np
except Exception:
    np = None

from .ring_buffer import (
    ParamRingBuffer, AudioRingBuffer, TrackMeterRing, TrackParamState,
    PARAM_MASTER_VOL, PARAM_MASTER_PAN,
    PARAM_TRACK_BASE, PARAM_TRACK_STRIDE,
    TRACK_VOL, TRACK_PAN, TRACK_MUTE, TRACK_SOLO,
    track_param_id, decode_track_param, MAX_TRACKS,
)
from .rt_params import RTParamStore

from pydaw.utils.logging_setup import get_logger

log = get_logger(__name__)

_HALF_PI = 1.5707963267948966


def _pan_gains(gain: float, pan: float) -> Tuple[float, float]:
    """Equal-power pan law."""
    pan = max(-1.0, min(1.0, float(pan)))
    x = (pan + 1.0) * 0.5
    return (math.cos(x * _HALF_PI) * gain,
            math.sin(x * _HALF_PI) * gain)


class HybridAudioCallback:
    """Zero-lock audio callback for sounddevice/JACK.

    All state is read from pre-cached local variables or lock-free rings.
    No Python locks, no allocations, no exceptions in the hot path.

    v0.0.20.14: Per-track volume/pan/mute/solo via TrackParamState.
    """

    __slots__ = (
        # Pre-allocated buffers
        "_mix_buf", "_block_buf",
        # Parameters (local copies, updated from ring)
        "_master_vol", "_master_pan",
        "_master_vol_smooth", "_master_pan_smooth",
        "_smooth_coeff",
        # Per-track state (v0.0.20.14)
        "_track_state",
        # Track index registry: track_id -> track_idx
        "_track_index_map",
        # Ring buffers
        "_param_ring", "_meter_ring",
        # Per-track meter rings
        "_track_meters",
        # Arrangement state (atomic reference swap)
        "_arrangement_state",
        # Pull sources (atomic list swap)
        "_pull_sources",
        # Transport ref
        "_transport_ref",
        # Playhead for silence mode
        "_silence_playhead",
        # RT params ref (optional, for backward compat)
        "_rt_params",
        # Config
        "_sr",
    )

    def __init__(self, param_ring: ParamRingBuffer,
                 meter_ring: Optional[AudioRingBuffer] = None,
                 rt_params: Optional[RTParamStore] = None,
                 sr: int = 48000):
        if np is not None:
            self._mix_buf = np.zeros((8192, 2), dtype=np.float32)
            self._block_buf = np.zeros((8192, 2), dtype=np.float32)
        else:
            self._mix_buf = None
            self._block_buf = None

        self._param_ring = param_ring
        self._meter_ring = meter_ring
        self._rt_params = rt_params
        self._sr = int(sr)

        # Master parameters
        self._master_vol = 0.8
        self._master_pan = 0.0
        self._master_vol_smooth = 0.8
        self._master_pan_smooth = 0.0
        self._smooth_coeff = 0.0

        # v0.0.20.14: Per-track parameter state
        self._track_state = TrackParamState()
        self._track_index_map: Dict[str, int] = {}
        self._track_meters: Dict[int, TrackMeterRing] = {}

        # Atomic references (swapped from main thread)
        self._arrangement_state = None
        self._pull_sources: List[Any] = []
        self._transport_ref = None
        self._silence_playhead = 0

    def set_arrangement_state(self, state: Any) -> None:
        """Set arrangement state (main thread). Atomic reference swap."""
        self._arrangement_state = state

    def set_pull_sources(self, sources: List[Any]) -> None:
        """Set pull source list (main thread). Atomic reference swap."""
        self._pull_sources = list(sources) if sources else []

    def set_transport_ref(self, transport: Any) -> None:
        self._transport_ref = transport

    def set_track_index_map(self, mapping: Dict[str, int]) -> None:
        """Set track_id → track_idx mapping (main thread)."""
        self._track_index_map = dict(mapping)

    def get_track_meter(self, track_idx: int) -> TrackMeterRing:
        """Get or create per-track meter ring."""
        if track_idx not in self._track_meters:
            self._track_meters[track_idx] = TrackMeterRing()
        return self._track_meters[track_idx]

    def __call__(self, outdata, frames: int, time_info, status) -> None:
        """The actual audio callback. Called by sounddevice.

        ZERO LOCKS. ZERO ALLOCATIONS. ZERO EXCEPTIONS (caught).
        """
        try:
            self._process(outdata, int(frames))
        except Exception:
            try:
                outdata.fill(0)
            except Exception:
                pass

    def _process(self, outdata, frames: int) -> None:
        """Inner processing — separated for profiling."""
        if np is None or self._mix_buf is None:
            outdata.fill(0)
            return

        # 0. Compute smoothing coefficient if needed
        if self._smooth_coeff == 0.0:
            tau = 5.0 * float(self._sr) / 1000.0  # 5ms
            self._smooth_coeff = 1.0 - math.exp(-float(frames) / max(1.0, tau))

        # 1. Drain parameter ring (lock-free) — track params go to TrackParamState
        ring = self._param_ring
        ts = self._track_state
        if ring is not None:
            for pid, val in ring.drain_into(ts):
                if pid == PARAM_MASTER_VOL:
                    self._master_vol = val
                elif pid == PARAM_MASTER_PAN:
                    self._master_pan = val

        # 2. Smooth master + track parameters (single-pole IIR)
        coeff = self._smooth_coeff
        self._master_vol_smooth += coeff * (self._master_vol - self._master_vol_smooth)
        self._master_pan_smooth += coeff * (self._master_pan - self._master_pan_smooth)
        ts.advance_smoothing(coeff)

        # 3. Advance RT params if present (backward compat)
        rt = self._rt_params
        if rt is not None:
            try:
                rt.advance(frames, self._sr)
            except Exception:
                pass

        # 4. Zero the mix buffer slice
        mix = self._mix_buf[:frames]
        mix.fill(0.0)

        # 5. Transport playhead sync (start of block)
        st = self._arrangement_state
        transport = self._transport_ref
        if transport is not None:
            try:
                ph = int(st.playhead) if st is not None else int(self._silence_playhead)
                transport._set_external_playhead_samples(ph, float(self._sr))
            except Exception:
                pass

        # 6. Arrangement render (numpy C-speed operations)
        if st is not None:
            try:
                buf = st.render(frames)
                if buf is not None:
                    mix[:buf.shape[0]] += buf[:frames]
            except Exception:
                pass
        else:
            try:
                if transport is not None and bool(getattr(transport, "playing", False)):
                    self._silence_playhead += frames
            except Exception:
                pass

        # 7. Pull sources (Sampler, FluidSynth, etc.)
        for fn in self._pull_sources:
            try:
                b = fn(frames, self._sr)
                if b is not None:
                    mix[:frames, :2] += b[:frames, :2]
            except Exception:
                pass

        # 8. Master Volume & Pan (smoothed — no clicks!)
        vol = self._master_vol_smooth
        if vol != 1.0:
            mix *= vol

        pan = self._master_pan_smooth
        if abs(pan) > 0.005:
            gl, gr = _pan_gains(1.0, pan)
            mix[:, 0] *= gl
            mix[:, 1] *= gr

        # 9. Soft limiter (numpy C-speed)
        np.clip(mix, -1.0, 1.0, out=mix)

        # 10. Copy to output
        outdata[:frames, :2] = mix[:frames]
        if outdata.shape[1] > 2:
            outdata[:frames, 2:] = 0

        # 11. Write metering ring (lock-free)
        meter = self._meter_ring
        if meter is not None:
            try:
                meter.write(mix[:frames])
            except Exception:
                pass

        # 12. Transport playhead sync (end of block)
        if transport is not None and st is not None:
            try:
                transport._set_external_playhead_samples(
                    int(st.playhead), float(self._sr))
            except Exception:
                pass

    def render_for_jack(self, frames: int, in_bufs, out_bufs,
                        sr: int) -> bool:
        """JACK render callback variant (v0.0.20.14: fully integrated).

        Called directly from JACK process callback. Uses same zero-lock pipeline
        as sounddevice callback but writes to JACK buffer format.
        """
        try:
            self._sr = int(sr)
            if np is None or self._mix_buf is None:
                return False

            # Smoothing coefficient
            if self._smooth_coeff == 0.0:
                tau = 5.0 * float(sr) / 1000.0
                self._smooth_coeff = 1.0 - math.exp(-float(frames) / max(1.0, tau))

            # Drain params (with per-track handling)
            ring = self._param_ring
            ts = self._track_state
            if ring is not None:
                for pid, val in ring.drain_into(ts):
                    if pid == PARAM_MASTER_VOL:
                        self._master_vol = val
                    elif pid == PARAM_MASTER_PAN:
                        self._master_pan = val

            coeff = self._smooth_coeff
            self._master_vol_smooth += coeff * (self._master_vol - self._master_vol_smooth)
            self._master_pan_smooth += coeff * (self._master_pan - self._master_pan_smooth)
            ts.advance_smoothing(coeff)

            # RT params backward compat
            rt = self._rt_params
            if rt is not None:
                try:
                    rt.advance(frames, sr)
                except Exception:
                    pass

            mix = self._mix_buf[:frames]
            mix.fill(0.0)

            # Transport sync (start)
            st = self._arrangement_state
            transport = self._transport_ref
            if transport is not None:
                try:
                    ph = int(st.playhead) if st is not None else 0
                    transport._set_external_playhead_samples(ph, float(sr))
                except Exception:
                    pass

            # Arrangement render
            if st is not None:
                try:
                    buf = st.render(frames)
                    if buf is not None:
                        mix[:buf.shape[0]] += buf[:frames]
                except Exception:
                    pass

            # Pull sources
            for fn in self._pull_sources:
                try:
                    b = fn(frames, sr)
                    if b is not None:
                        mix[:frames, :2] += b[:frames, :2]
                except Exception:
                    pass

            # Master vol/pan
            vol = self._master_vol_smooth
            if vol != 1.0:
                mix *= vol
            pan = self._master_pan_smooth
            if abs(pan) > 0.005:
                gl, gr = _pan_gains(1.0, pan)
                mix[:, 0] *= gl
                mix[:, 1] *= gr

            # Soft limiter
            np.clip(mix, -1.0, 1.0, out=mix)

            # JACK output (de-interleaved)
            if out_bufs:
                if len(out_bufs) >= 1:
                    out_bufs[0][:frames] = mix[:frames, 0]
                if len(out_bufs) >= 2:
                    out_bufs[1][:frames] = mix[:frames, 1]

            # Metering
            meter = self._meter_ring
            if meter is not None:
                try:
                    meter.write(mix[:frames])
                except Exception:
                    pass

            # Transport sync (end)
            if transport is not None and st is not None:
                try:
                    transport._set_external_playhead_samples(
                        int(st.playhead), float(sr))
                except Exception:
                    pass

            return True
        except Exception:
            return False


# ---------------------------------------------------------------------------
# Hybrid Engine Bridge (connects GUI thread to audio callback)
# ---------------------------------------------------------------------------

class HybridEngineBridge:
    """Bridge between GUI thread and HybridAudioCallback.

    All methods on this class are GUI-thread safe.

    v0.0.20.14: Per-track parameter control + track index registry.
    """

    def __init__(self, rt_params: Optional[RTParamStore] = None):
        self._param_ring = ParamRingBuffer(capacity=512)
        self._meter_ring = AudioRingBuffer(capacity=16384, channels=2)

        self._callback = HybridAudioCallback(
            param_ring=self._param_ring,
            meter_ring=self._meter_ring,
            rt_params=rt_params,
        )

        self._track_meters: Dict[str, TrackMeterRing] = {}
        # Track ID → index mapping (GUI thread writes, audio thread reads atomically)
        self._track_id_to_idx: Dict[str, int] = {}
        self._next_track_idx: int = 0

    @property
    def callback(self) -> HybridAudioCallback:
        return self._callback

    @property
    def param_ring(self) -> ParamRingBuffer:
        return self._param_ring

    @property
    def meter_ring(self) -> AudioRingBuffer:
        return self._meter_ring

    # ---- Track index registry (GUI thread)

    def register_track(self, track_id: str) -> int:
        """Register a track and get its ring buffer index."""
        if track_id in self._track_id_to_idx:
            return self._track_id_to_idx[track_id]
        idx = self._next_track_idx
        self._next_track_idx += 1
        self._track_id_to_idx[track_id] = idx
        # Update callback's mapping (atomic swap)
        self._callback.set_track_index_map(dict(self._track_id_to_idx))
        return idx

    def get_track_idx(self, track_id: str) -> int:
        """Get track index, registering if needed."""
        return self.register_track(track_id)

    # ---- Master parameter updates (GUI thread, lock-free via ring)

    def set_master_volume(self, vol: float) -> None:
        self._param_ring.push(PARAM_MASTER_VOL, max(0.0, min(1.0, float(vol))))

    def set_master_pan(self, pan: float) -> None:
        self._param_ring.push(PARAM_MASTER_PAN, max(-1.0, min(1.0, float(pan))))

    # ---- Per-track parameter updates (GUI thread, lock-free via ring)

    def set_track_volume(self, track_id: str, vol: float) -> None:
        """Set track volume from GUI thread (0.0-1.0)."""
        idx = self.get_track_idx(track_id)
        self._param_ring.push_track_param(idx, TRACK_VOL,
                                          max(0.0, min(1.0, float(vol))))

    def set_track_pan(self, track_id: str, pan: float) -> None:
        """Set track pan from GUI thread (-1.0 to 1.0)."""
        idx = self.get_track_idx(track_id)
        self._param_ring.push_track_param(idx, TRACK_PAN,
                                          max(-1.0, min(1.0, float(pan))))

    def set_track_mute(self, track_id: str, muted: bool) -> None:
        """Set track mute from GUI thread."""
        idx = self.get_track_idx(track_id)
        self._param_ring.push_track_param(idx, TRACK_MUTE,
                                          1.0 if muted else 0.0)

    def set_track_solo(self, track_id: str, solo: bool) -> None:
        """Set track solo from GUI thread."""
        idx = self.get_track_idx(track_id)
        self._param_ring.push_track_param(idx, TRACK_SOLO,
                                          1.0 if solo else 0.0)

    # ---- Arrangement state (atomic reference swap)

    def set_arrangement_state(self, state: Any) -> None:
        self._callback.set_arrangement_state(state)

    def set_pull_sources(self, sources: List[Any]) -> None:
        self._callback.set_pull_sources(sources)

    def set_transport_ref(self, transport: Any) -> None:
        self._callback.set_transport_ref(transport)

    def set_sample_rate(self, sr: int) -> None:
        self._callback._sr = int(sr)

    # ---- Metering (GUI reads lock-free from audio ring)

    def read_master_peak(self) -> Tuple[float, float]:
        return self._meter_ring.read_peak(frames=512)

    def get_track_meter(self, track_id: str) -> TrackMeterRing:
        if track_id not in self._track_meters:
            self._track_meters[track_id] = TrackMeterRing()
        return self._track_meters[track_id]

    def read_track_peak(self, track_id: str) -> Tuple[float, float]:
        """Read per-track peak levels (GUI thread, lock-free)."""
        meter = self._track_meters.get(track_id)
        if meter is not None:
            return meter.read_and_decay()
        return (0.0, 0.0)

    # ---- JACK integration (v0.0.20.14)

    def jack_render_callback(self, frames: int, in_bufs, out_bufs,
                             sr: int) -> bool:
        """Direct JACK process callback using HybridAudioCallback.

        Drop-in replacement for DSPJackEngine.render_callback.
        Uses zero-lock ring buffer pipeline instead of RTParamStore.
        """
        return self._callback.render_for_jack(frames, in_bufs, out_bufs, sr)


# ---------------------------------------------------------------------------
# Module singleton
# ---------------------------------------------------------------------------

_global_bridge: Optional[HybridEngineBridge] = None


def get_hybrid_bridge(rt_params: Optional[RTParamStore] = None) -> HybridEngineBridge:
    """Get or create the global hybrid engine bridge."""
    global _global_bridge
    if _global_bridge is None:
        _global_bridge = HybridEngineBridge(rt_params=rt_params)
    return _global_bridge
