# 📦 PyDAW / ChronoScaleStudio Installation

Dieses Repo ist inzwischen **cross-platform** angelegt:
- **Linux:** PipeWire-JACK/JACK optional (Routing, qpwgraph)
- **macOS:** **CoreAudio** via `sounddevice` (PortAudio) – kein JACK nötig

> Hinweis: Die App heißt in Logs/Cache bereits **ChronoScaleStudio**.

## System Requirements
- **Python:** 3.10+ (getestet: 3.13)
- **GUI:** PyQt6 (Qt6)
- **Audio:**
  - Linux: PipeWire (empfohlen) / optional JACK
  - macOS: CoreAudio (automatisch)

## Quick Install

```bash
# 1) Unzip
unzip Py_DAW_v0_0_20_17_TEAM_READY.zip
cd Py_DAW_v0_0_20_17_TEAM_READY

# 2) Virtualenv
python3 -m venv myenv
source myenv/bin/activate

# 3) Dependencies
pip install -r requirements.txt

# 4) Start
python3 main.py
```

## Audio Backend Setup (Linux)

### JACK
```bash
sudo apt install jackd2
jack_control start
```

### PipeWire-JACK
```bash
sudo apt install pipewire-jack
# Already running on most modern Linux
```

### qpwgraph (Optional)
```bash
sudo apt install qpwgraph
qpwgraph &
```

## Troubleshooting

### "No audio devices found"
```bash
# Check JACK
jack_lsp

# Or PipeWire
pw-cli ls
```

### "ModuleNotFoundError"
```bash
pip install --upgrade -r requirements.txt
```

## Done!
Run: `python3 main.py`

---

## macOS Setup (CoreAudio + optional Metal)

Siehe: `docs/MACOS.md` (Homebrew Abhängigkeiten + Start-Skripte)
