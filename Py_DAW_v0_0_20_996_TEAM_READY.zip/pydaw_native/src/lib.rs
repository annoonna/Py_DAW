//! pydaw_native — PyO3 native DSP functions for Py_DAW UI (v0.0.20.983)
//!
//! NS1: PyO3 UI-Hilfsfunktionen
//!
//! Provides zero-copy numpy integration for:
//!   - Waveform peak calculation (NS1.1)
//!   - FFT / Spectrum Analysis (NS1.2)
//!   - RMS/Peak/LUFS Metering (NS1.3)
//!   - Audio utilities: resample, normalize, BPM/key detection (NS1.4)
//!
//! Build: cd pydaw_native && maturin develop --release
//! Usage: import pydaw_native

use numpy::{PyArray1, PyReadonlyArray1};
use pyo3::prelude::*;
use pyo3::exceptions::PyValueError;
use rustfft::{FftPlanner, num_complex::Complex};
use std::f32::consts::PI;

// ═══════════════════════════════════════════════════════════════════════════
// NS1.1: Waveform Peak Calculation
// ═══════════════════════════════════════════════════════════════════════════

/// Calculate min/max waveform peaks for overview display.
///
/// Args:
///     samples: numpy float32 array of audio samples
///     num_peaks: number of peak pairs to return
///
/// Returns:
///     (min_peaks, max_peaks) — two numpy float32 arrays
///
/// 10-100x faster than Python loop. GIL released during computation.
#[pyfunction]
fn waveform_peaks<'py>(
    py: Python<'py>,
    samples: PyReadonlyArray1<'py, f32>,
    num_peaks: usize,
) -> PyResult<(Bound<'py, PyArray1<f32>>, Bound<'py, PyArray1<f32>>)> {
    if num_peaks == 0 {
        return Err(PyValueError::new_err("num_peaks must be > 0"));
    }

    let data = samples.as_slice()?;
    let len = data.len();

    if len == 0 {
        let empty_min = PyArray1::from_vec(py, vec![]);
        let empty_max = PyArray1::from_vec(py, vec![]);
        return Ok((empty_min, empty_max));
    }

    let mut mins = vec![0.0f32; num_peaks];
    let mut maxs = vec![0.0f32; num_peaks];

    // Release GIL for computation
    py.allow_threads(|| {
        let chunk_size = (len as f64 / num_peaks as f64).ceil() as usize;
        let chunk_size = chunk_size.max(1);

        for i in 0..num_peaks {
            let start = i * chunk_size;
            let end = ((i + 1) * chunk_size).min(len);
            if start >= len {
                break;
            }

            let mut min_val = f32::MAX;
            let mut max_val = f32::MIN;

            for &s in &data[start..end] {
                if s < min_val { min_val = s; }
                if s > max_val { max_val = s; }
            }

            mins[i] = min_val;
            maxs[i] = max_val;
        }
    });

    Ok((PyArray1::from_vec(py, mins), PyArray1::from_vec(py, maxs)))
}

/// Calculate RMS waveform for smooth display.
///
/// Returns numpy float32 array of RMS values per chunk.
#[pyfunction]
fn waveform_rms<'py>(
    py: Python<'py>,
    samples: PyReadonlyArray1<'py, f32>,
    num_points: usize,
) -> PyResult<Bound<'py, PyArray1<f32>>> {
    if num_points == 0 {
        return Err(PyValueError::new_err("num_points must be > 0"));
    }

    let data = samples.as_slice()?;
    let len = data.len();
    let mut rms = vec![0.0f32; num_points];

    if len == 0 {
        return Ok(PyArray1::from_vec(py, rms));
    }

    py.allow_threads(|| {
        let chunk_size = (len as f64 / num_points as f64).ceil() as usize;
        let chunk_size = chunk_size.max(1);

        for i in 0..num_points {
            let start = i * chunk_size;
            let end = ((i + 1) * chunk_size).min(len);
            if start >= len { break; }

            let sum_sq: f64 = data[start..end]
                .iter()
                .map(|&s| (s as f64) * (s as f64))
                .sum();
            let count = (end - start) as f64;
            rms[i] = (sum_sq / count).sqrt() as f32;
        }
    });

    Ok(PyArray1::from_vec(py, rms))
}

// ═══════════════════════════════════════════════════════════════════════════
// NS1.2: FFT / Spectrum Analyzer
// ═══════════════════════════════════════════════════════════════════════════

/// Compute FFT magnitude spectrum.
///
/// Args:
///     samples: numpy float32 array (mono)
///     fft_size: FFT size (power of 2, e.g. 2048, 4096)
///
/// Returns:
///     numpy float32 array of magnitude values (fft_size/2 + 1 bins)
///     in dB scale (0 dB = full scale)
#[pyfunction]
fn fft_magnitude<'py>(
    py: Python<'py>,
    samples: PyReadonlyArray1<'py, f32>,
    fft_size: usize,
) -> PyResult<Bound<'py, PyArray1<f32>>> {
    if fft_size == 0 || (fft_size & (fft_size - 1)) != 0 {
        return Err(PyValueError::new_err("fft_size must be a power of 2"));
    }

    let data = samples.as_slice()?;
    let num_bins = fft_size / 2 + 1;
    let mut magnitudes = vec![0.0f32; num_bins];

    py.allow_threads(|| {
        // Prepare input with Hanning window
        let mut input: Vec<Complex<f32>> = vec![Complex::new(0.0, 0.0); fft_size];
        let copy_len = data.len().min(fft_size);

        for i in 0..copy_len {
            let window = 0.5 * (1.0 - (2.0 * PI * i as f32 / (fft_size as f32 - 1.0)).cos());
            input[i] = Complex::new(data[i] * window, 0.0);
        }

        // FFT
        let mut planner = FftPlanner::new();
        let fft = planner.plan_fft_forward(fft_size);
        fft.process(&mut input);

        // Magnitude in dB
        let scale = 2.0 / fft_size as f32;
        for i in 0..num_bins {
            let mag = input[i].norm() * scale;
            magnitudes[i] = if mag > 1e-10 {
                20.0 * mag.log10()
            } else {
                -200.0
            };
        }
    });

    Ok(PyArray1::from_vec(py, magnitudes))
}

/// Compute FFT with Blackman-Harris window (better sidelobe rejection).
#[pyfunction]
fn fft_magnitude_blackman<'py>(
    py: Python<'py>,
    samples: PyReadonlyArray1<'py, f32>,
    fft_size: usize,
) -> PyResult<Bound<'py, PyArray1<f32>>> {
    if fft_size == 0 || (fft_size & (fft_size - 1)) != 0 {
        return Err(PyValueError::new_err("fft_size must be a power of 2"));
    }

    let data = samples.as_slice()?;
    let num_bins = fft_size / 2 + 1;
    let mut magnitudes = vec![0.0f32; num_bins];

    py.allow_threads(|| {
        let mut input: Vec<Complex<f32>> = vec![Complex::new(0.0, 0.0); fft_size];
        let copy_len = data.len().min(fft_size);
        let n = fft_size as f32;

        for i in 0..copy_len {
            // Blackman-Harris 4-term
            let x = 2.0 * PI * i as f32 / (n - 1.0);
            let window = 0.35875 - 0.48829 * x.cos()
                + 0.14128 * (2.0 * x).cos()
                - 0.01168 * (3.0 * x).cos();
            input[i] = Complex::new(data[i] * window, 0.0);
        }

        let mut planner = FftPlanner::new();
        let fft = planner.plan_fft_forward(fft_size);
        fft.process(&mut input);

        let scale = 2.0 / fft_size as f32;
        for i in 0..num_bins {
            let mag = input[i].norm() * scale;
            magnitudes[i] = if mag > 1e-10 {
                20.0 * mag.log10()
            } else {
                -200.0
            };
        }
    });

    Ok(PyArray1::from_vec(py, magnitudes))
}

/// Convert linear frequency bins to Mel scale for spectrogram display.
///
/// Args:
///     magnitudes: linear FFT magnitude array (from fft_magnitude)
///     num_mel_bins: number of Mel bands (e.g. 128)
///     sample_rate: sample rate in Hz
///
/// Returns:
///     numpy float32 array of Mel-scale magnitudes
#[pyfunction]
fn mel_scale<'py>(
    py: Python<'py>,
    magnitudes: PyReadonlyArray1<'py, f32>,
    num_mel_bins: usize,
    sample_rate: f32,
) -> PyResult<Bound<'py, PyArray1<f32>>> {
    let mags = magnitudes.as_slice()?;
    let num_fft_bins = mags.len();
    let mut mel_out = vec![-200.0f32; num_mel_bins];

    py.allow_threads(|| {
        let freq_max = sample_rate / 2.0;
        let mel_max = 2595.0 * (1.0 + freq_max / 700.0).log10();

        for m in 0..num_mel_bins {
            let mel_lo = mel_max * m as f32 / num_mel_bins as f32;
            let mel_hi = mel_max * (m + 1) as f32 / num_mel_bins as f32;

            let freq_lo = 700.0 * (10.0f32.powf(mel_lo / 2595.0) - 1.0);
            let freq_hi = 700.0 * (10.0f32.powf(mel_hi / 2595.0) - 1.0);

            let bin_lo = (freq_lo / freq_max * (num_fft_bins - 1) as f32) as usize;
            let bin_hi = ((freq_hi / freq_max * (num_fft_bins - 1) as f32) as usize)
                .min(num_fft_bins - 1);

            if bin_lo <= bin_hi && bin_lo < num_fft_bins {
                let mut max_val = -200.0f32;
                for b in bin_lo..=bin_hi {
                    if mags[b] > max_val {
                        max_val = mags[b];
                    }
                }
                mel_out[m] = max_val;
            }
        }
    });

    Ok(PyArray1::from_vec(py, mel_out))
}

// ═══════════════════════════════════════════════════════════════════════════
// NS1.3: Metering
// ═══════════════════════════════════════════════════════════════════════════

/// Calculate RMS and peak levels for stereo audio.
///
/// Args:
///     samples_l: left channel numpy float32 array
///     samples_r: right channel numpy float32 array
///
/// Returns:
///     (rms_l, rms_r, peak_l, peak_r) in dBFS
#[pyfunction]
fn rms_peak<'py>(
    py: Python<'py>,
    samples_l: PyReadonlyArray1<'py, f32>,
    samples_r: PyReadonlyArray1<'py, f32>,
) -> PyResult<(f32, f32, f32, f32)> {
    let left = samples_l.as_slice()?;
    let right = samples_r.as_slice()?;

    let result = py.allow_threads(|| {
        let (rms_l, peak_l) = calc_rms_peak(left);
        let (rms_r, peak_r) = calc_rms_peak(right);
        (to_dbfs(rms_l), to_dbfs(rms_r), to_dbfs(peak_l), to_dbfs(peak_r))
    });

    Ok(result)
}

/// Calculate RMS and peak for mono audio.
fn calc_rms_peak(samples: &[f32]) -> (f32, f32) {
    if samples.is_empty() {
        return (0.0, 0.0);
    }

    let mut sum_sq: f64 = 0.0;
    let mut peak: f32 = 0.0;

    for &s in samples {
        let abs = s.abs();
        sum_sq += (s as f64) * (s as f64);
        if abs > peak { peak = abs; }
    }

    let rms = (sum_sq / samples.len() as f64).sqrt() as f32;
    (rms, peak)
}

fn to_dbfs(linear: f32) -> f32 {
    if linear > 1e-10 {
        20.0 * linear.log10()
    } else {
        -200.0
    }
}

/// LUFS measurement (simplified EBU R128 momentary loudness).
///
/// Applies K-weighting filter approximation and measures
/// integrated loudness over the provided samples.
///
/// Args:
///     samples_l: left channel
///     samples_r: right channel
///     sample_rate: sample rate in Hz
///
/// Returns:
///     LUFS value (float)
#[pyfunction]
fn lufs_momentary<'py>(
    py: Python<'py>,
    samples_l: PyReadonlyArray1<'py, f32>,
    samples_r: PyReadonlyArray1<'py, f32>,
    sample_rate: f32,
) -> PyResult<f32> {
    let left = samples_l.as_slice()?;
    let right = samples_r.as_slice()?;

    let result = py.allow_threads(|| {
        // K-weighting: simplified high-shelf + high-pass
        // Full R128 uses a 2-stage biquad. Here we approximate with a
        // simple pre-emphasis filter for the high-shelf stage.
        let k_weight = |samples: &[f32], _sr: f32| -> f64 {
            // Pre-emphasis: y[n] = x[n] - 0.95 * x[n-1] (approximate +4dB @ 2kHz)
            let mut prev = 0.0f32;
            let mut sum_sq: f64 = 0.0;
            for &s in samples {
                let filtered = s - 0.95 * prev;
                sum_sq += (filtered as f64) * (filtered as f64);
                prev = s;
            }
            sum_sq / samples.len().max(1) as f64
        };

        let mean_sq_l = k_weight(left, sample_rate);
        let mean_sq_r = k_weight(right, sample_rate);

        // Loudness = -0.691 + 10 * log10(sum of channel mean squares)
        let sum = mean_sq_l + mean_sq_r;
        if sum > 1e-20 {
            -0.691 + 10.0 * (sum as f32).log10()
        } else {
            -200.0
        }
    });

    Ok(result)
}

/// True Peak detection with 4x oversampling.
///
/// Returns the true peak in dBTP for each channel.
#[pyfunction]
fn true_peak<'py>(
    py: Python<'py>,
    samples_l: PyReadonlyArray1<'py, f32>,
    samples_r: PyReadonlyArray1<'py, f32>,
) -> PyResult<(f32, f32)> {
    let left = samples_l.as_slice()?;
    let right = samples_r.as_slice()?;

    let result = py.allow_threads(|| {
        let tp_l = true_peak_channel(left);
        let tp_r = true_peak_channel(right);
        (to_dbfs(tp_l), to_dbfs(tp_r))
    });

    Ok(result)
}

/// 4x oversampling true peak for one channel.
fn true_peak_channel(samples: &[f32]) -> f32 {
    if samples.is_empty() {
        return 0.0;
    }

    let mut peak: f32 = 0.0;

    // Simple 4x linear interpolation (full ITU-R BS.1770 uses
    // a 48-tap FIR at 192kHz — this is a pragmatic approximation)
    for i in 0..samples.len() {
        let s0 = samples[i];
        let s1 = if i + 1 < samples.len() { samples[i + 1] } else { s0 };

        // 4 interpolated points between s0 and s1
        for k in 0..4 {
            let t = k as f32 / 4.0;
            let interp = s0 + (s1 - s0) * t;
            let abs = interp.abs();
            if abs > peak { peak = abs; }
        }
    }

    peak
}

// ═══════════════════════════════════════════════════════════════════════════
// NS1.4: Audio Utilities
// ═══════════════════════════════════════════════════════════════════════════

/// Normalize audio to target dB level.
///
/// Args:
///     samples: numpy float32 array
///     target_db: target peak level in dBFS (e.g. -1.0)
///
/// Returns:
///     normalized numpy float32 array
#[pyfunction]
fn normalize<'py>(
    py: Python<'py>,
    samples: PyReadonlyArray1<'py, f32>,
    target_db: f32,
) -> PyResult<Bound<'py, PyArray1<f32>>> {
    let data = samples.as_slice()?;
    let mut output = data.to_vec();

    py.allow_threads(|| {
        // Find peak
        let mut peak: f32 = 0.0;
        for &s in &output {
            let abs = s.abs();
            if abs > peak { peak = abs; }
        }

        if peak > 1e-10 {
            let target_linear = 10.0f32.powf(target_db / 20.0);
            let gain = target_linear / peak;
            for s in output.iter_mut() {
                *s *= gain;
            }
        }
    });

    Ok(PyArray1::from_vec(py, output))
}

/// Simple linear resampling.
///
/// For production use, consider libsamplerate. This is a fast
/// approximation suitable for preview/display purposes.
///
/// Args:
///     samples: input numpy float32 array
///     from_sr: source sample rate
///     to_sr: target sample rate
///
/// Returns:
///     resampled numpy float32 array
#[pyfunction]
fn resample<'py>(
    py: Python<'py>,
    samples: PyReadonlyArray1<'py, f32>,
    from_sr: u32,
    to_sr: u32,
) -> PyResult<Bound<'py, PyArray1<f32>>> {
    if from_sr == 0 || to_sr == 0 {
        return Err(PyValueError::new_err("sample rates must be > 0"));
    }
    if from_sr == to_sr {
        return Ok(PyArray1::from_vec(py, samples.as_slice()?.to_vec()));
    }

    let data = samples.as_slice()?;
    let ratio = to_sr as f64 / from_sr as f64;
    let new_len = (data.len() as f64 * ratio) as usize;
    let mut output = vec![0.0f32; new_len];

    py.allow_threads(|| {
        for i in 0..new_len {
            let src_pos = i as f64 / ratio;
            let idx = src_pos as usize;
            let frac = (src_pos - idx as f64) as f32;

            let s0 = data[idx.min(data.len() - 1)];
            let s1 = data[(idx + 1).min(data.len() - 1)];
            output[i] = s0 + (s1 - s0) * frac;
        }
    });

    Ok(PyArray1::from_vec(py, output))
}

/// Detect BPM using autocorrelation method.
///
/// Args:
///     samples: numpy float32 array (mono, ideally 10+ seconds)
///     sample_rate: sample rate in Hz
///
/// Returns:
///     estimated BPM (float), 0.0 if detection fails
#[pyfunction]
fn detect_bpm<'py>(
    py: Python<'py>,
    samples: PyReadonlyArray1<'py, f32>,
    sample_rate: u32,
) -> PyResult<f32> {
    let data = samples.as_slice()?;
    let sr = sample_rate as f32;

    let result = py.allow_threads(|| {
        if data.len() < (sr * 2.0) as usize {
            return 0.0;  // Need at least 2 seconds
        }

        // Step 1: Onset detection via energy derivative
        let hop = 512;
        let frame_size = 1024;
        let num_frames = (data.len() - frame_size) / hop;

        if num_frames < 4 {
            return 0.0;
        }

        let mut energies = vec![0.0f32; num_frames];
        for i in 0..num_frames {
            let start = i * hop;
            let end = start + frame_size;
            let e: f32 = data[start..end].iter().map(|s| s * s).sum();
            energies[i] = e;
        }

        // Onset strength = positive first derivative of energy
        let mut onset = vec![0.0f32; num_frames.saturating_sub(1)];
        for i in 1..energies.len() {
            let diff = energies[i] - energies[i - 1];
            onset[i - 1] = diff.max(0.0);
        }

        if onset.is_empty() {
            return 0.0;
        }

        // Step 2: Autocorrelation of onset function
        // Search range: 60-200 BPM
        let min_bpm = 60.0;
        let max_bpm = 200.0;
        let frames_per_sec = sr / hop as f32;
        let min_lag = (frames_per_sec * 60.0 / max_bpm) as usize;
        let max_lag = (frames_per_sec * 60.0 / min_bpm) as usize;
        let max_lag = max_lag.min(onset.len() / 2);

        if min_lag >= max_lag || max_lag >= onset.len() {
            return 0.0;
        }

        let mut best_lag = min_lag;
        let mut best_corr = 0.0f32;

        for lag in min_lag..=max_lag {
            let mut corr = 0.0f32;
            let count = onset.len() - lag;
            for i in 0..count {
                corr += onset[i] * onset[i + lag];
            }
            corr /= count as f32;

            if corr > best_corr {
                best_corr = corr;
                best_lag = lag;
            }
        }

        if best_corr < 1e-10 {
            return 0.0;
        }

        // Convert lag to BPM
        let bpm = 60.0 * frames_per_sec / best_lag as f32;
        bpm
    });

    Ok(result)
}

/// Detect musical key using chroma analysis.
///
/// Args:
///     samples: numpy float32 array (mono)
///     sample_rate: sample rate in Hz
///
/// Returns:
///     key name as string (e.g. "C major", "A minor")
#[pyfunction]
fn detect_key<'py>(
    py: Python<'py>,
    samples: PyReadonlyArray1<'py, f32>,
    sample_rate: u32,
) -> PyResult<String> {
    let data = samples.as_slice()?;
    let sr = sample_rate as f32;

    let result = py.allow_threads(|| {
        if data.len() < 4096 {
            return "Unknown".to_string();
        }

        // Compute chroma features using FFT
        let fft_size = 4096;
        let mut planner = FftPlanner::new();
        let fft = planner.plan_fft_forward(fft_size);

        let mut chroma = [0.0f64; 12]; // C, C#, D, ..., B
        let num_frames = data.len() / fft_size;

        for frame_idx in 0..num_frames {
            let start = frame_idx * fft_size;
            let mut input: Vec<Complex<f32>> = Vec::with_capacity(fft_size);

            for i in 0..fft_size {
                let window = 0.5 * (1.0 - (2.0 * PI * i as f32 / (fft_size as f32 - 1.0)).cos());
                input.push(Complex::new(data[start + i] * window, 0.0));
            }

            fft.process(&mut input);

            // Map FFT bins to chroma
            for bin in 1..fft_size / 2 {
                let freq = bin as f32 * sr / fft_size as f32;
                if freq < 60.0 || freq > 5000.0 { continue; }

                let mag = input[bin].norm();
                // MIDI note number: 69 + 12 * log2(freq / 440)
                let midi = 69.0 + 12.0 * (freq / 440.0).log2();
                let chroma_idx = ((midi.round() as i32) % 12 + 12) % 12;
                chroma[chroma_idx as usize] += (mag * mag) as f64;
            }
        }

        // Normalize
        let max_c = chroma.iter().cloned().fold(0.0f64, f64::max);
        if max_c > 0.0 {
            for c in chroma.iter_mut() {
                *c /= max_c;
            }
        }

        // Krumhansl-Kessler key profiles
        let major_profile: [f64; 12] = [
            6.35, 2.23, 3.48, 2.33, 4.38, 4.09,
            2.52, 5.19, 2.39, 3.66, 2.29, 2.88,
        ];
        let minor_profile: [f64; 12] = [
            6.33, 2.68, 3.52, 5.38, 2.60, 3.53,
            2.54, 4.75, 3.98, 2.69, 3.34, 3.17,
        ];

        let note_names = ["C", "C#", "D", "D#", "E", "F",
                          "F#", "G", "G#", "A", "A#", "B"];

        let mut best_key = "C major".to_string();
        let mut best_corr = -1.0f64;

        for root in 0..12 {
            // Rotate chroma to start at root
            let mut rotated = [0.0f64; 12];
            for i in 0..12 {
                rotated[i] = chroma[(i + root) % 12];
            }

            // Pearson correlation with major profile
            let corr_maj = pearson_correlation(&rotated, &major_profile);
            if corr_maj > best_corr {
                best_corr = corr_maj;
                best_key = format!("{} major", note_names[root]);
            }

            // Pearson correlation with minor profile
            let corr_min = pearson_correlation(&rotated, &minor_profile);
            if corr_min > best_corr {
                best_corr = corr_min;
                best_key = format!("{} minor", note_names[root]);
            }
        }

        best_key
    });

    Ok(result)
}

fn pearson_correlation(a: &[f64; 12], b: &[f64; 12]) -> f64 {
    let mean_a: f64 = a.iter().sum::<f64>() / 12.0;
    let mean_b: f64 = b.iter().sum::<f64>() / 12.0;

    let mut cov = 0.0;
    let mut var_a = 0.0;
    let mut var_b = 0.0;

    for i in 0..12 {
        let da = a[i] - mean_a;
        let db = b[i] - mean_b;
        cov += da * db;
        var_a += da * da;
        var_b += db * db;
    }

    let denom = (var_a * var_b).sqrt();
    if denom < 1e-20 { 0.0 } else { cov / denom }
}

// ═══════════════════════════════════════════════════════════════════════════
// Module registration
// ═══════════════════════════════════════════════════════════════════════════

#[pymodule]
fn pydaw_native(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // NS1.1: Waveform
    m.add_function(wrap_pyfunction!(waveform_peaks, m)?)?;
    m.add_function(wrap_pyfunction!(waveform_rms, m)?)?;

    // NS1.2: FFT / Spectrum
    m.add_function(wrap_pyfunction!(fft_magnitude, m)?)?;
    m.add_function(wrap_pyfunction!(fft_magnitude_blackman, m)?)?;
    m.add_function(wrap_pyfunction!(mel_scale, m)?)?;

    // NS1.3: Metering
    m.add_function(wrap_pyfunction!(rms_peak, m)?)?;
    m.add_function(wrap_pyfunction!(lufs_momentary, m)?)?;
    m.add_function(wrap_pyfunction!(true_peak, m)?)?;

    // NS1.4: Audio Utilities
    m.add_function(wrap_pyfunction!(normalize, m)?)?;
    m.add_function(wrap_pyfunction!(resample, m)?)?;
    m.add_function(wrap_pyfunction!(detect_bpm, m)?)?;
    m.add_function(wrap_pyfunction!(detect_key, m)?)?;

    Ok(())
}
