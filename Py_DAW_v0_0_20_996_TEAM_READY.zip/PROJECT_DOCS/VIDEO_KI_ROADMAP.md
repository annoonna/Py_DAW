# 🎬 Py_DAW VIDEO-KI ENGINE — Vision & Roadmap

**Projekt:** Py_DAW (ChronoScaleStudio)
**Feature:** KI-gestützte Video-Integration — Das hat keine andere DAW
**Erstellt:** 2026-04-01 (v0.0.20.918)
**Autor:** Anno (Vision) + Claude Opus 4.6 (Architektur + KI-Konzepte)

---

## ⚠️ OBERSTE DIREKTIVE

```
🔴 DU DARFST NICHTS KAPUTT MACHEN.
🔴 Die Video-KI ist ein NEUES Subsystem — kein bestehendes umbauen.
🔴 Alles optional, alles in try/except, alles deaktivierbar.
```

---

## 🧠 VISION — Was es so noch nie gab

### Das Problem (jede DAW hat es)
Du komponierst Musik zu einem Video. Du siehst das Bild, du hörst
den Ton, aber die DAW versteht NICHTS vom Inhalt des Videos:

- "Wo ist der Szenenwechsel?" → manuell durchscrubben + Marker setzen
- "Wo spricht jemand?" → manuell hinhören + Automation zeichnen
- "Welche Stimmung hat diese Szene?" → dein Bauchgefühl
- "Kann ich den Schnitt auf meinen Beat legen?" → Copy-Paste in Premiere
- "Was sagt die Person im Video?" → manuell transkribieren

### Py_DAW wird die ERSTE DAW mit Video-Intelligenz.

### Feature-Matrix — Was existiert vs. was wir bauen

```
Feature                          Pro Tools  Nuendo  DaVinci  Py_DAW
──────────────────────────────────────────────────────────────────────
Video-Playback                      ✅       ✅       ✅       ✅
SMPTE Timecode                      ✅       ✅       ✅       ✅
Thumbnail-Strip im Arranger         ❌       ✅       ✅       ✅ NEU
Kapitel/Marker                      ✅       ✅       ✅       ✅

KI-Szenen-Erkennung                 ❌       ❌       ✅*      ✅ NEU
KI-Dialog-Erkennung → Auto-Duck     ❌       ❌       ❌       ✅ NEU
KI-Stimmungs-Analyse → Preset       ❌       ❌       ❌       ✅ NEU
KI-Untertitel (Whisper)             ❌       ❌       ❌       ✅ NEU
KI-Beat-to-Cut Vorschläge          ❌       ❌       ❌       ✅ NEU
KI-Sound-Design-Vorschläge          ❌       ❌       ❌       ✅ NEU
ADR/Foley Cue-Sheet Generator       ❌       ✅       ❌       ✅ NEU
Video-Noten (Annotationen)          ❌       ❌       ❌       ✅ NEU
Multi-Video A/B Vergleich           ❌       ❌       ✅       ✅ NEU

* DaVinci hat Scene-Cut-Detection, aber nur im Video-Editor — nicht in der DAW
```

---

## 🏗️ ARCHITEKTUR

```
┌──────────────────────────────────────────────────────────────┐
│  Qt6 GUI (Python)                                             │
│  ┌────────────────┐ ┌──────────────┐ ┌─────────────────────┐ │
│  │ Video Preview   │ │ Thumbnail    │ │ KI-Video-Assistent  │ │
│  │ Panel (QLabel + │ │ Strip im     │ │ Panel: Szenen,      │ │
│  │ ffmpeg frames)  │ │ Arranger     │ │ Dialog, Stimmung,   │ │
│  │                 │ │              │ │ Untertitel, ADR      │ │
│  └────────┬────────┘ └──────┬───────┘ └───────┬─────────────┘ │
│           │                 │                  │              │
│  ┌────────▼─────────────────▼──────────────────▼────────────┐ │
│  │ VideoKIService (Python)                                    │ │
│  │ - Szenen-Erkennung (Histogram-Diff, keine ext. Deps)      │ │
│  │ - Dialog-Erkennung (RMS + Spectral Centroid)              │ │
│  │ - Stimmungs-Analyse (Farbe + Tempo + Lautstärke)          │ │
│  │ - Untertitel (Whisper optional, sonst deaktiviert)        │ │
│  │ - Beat-to-Cut Vorschläge                                  │ │
│  │ - ADR/Foley Cue-Sheet                                     │ │
│  └────────┬────────────────────────────────────────────────┘ │
└───────────┼──────────────────────────────────────────────────┘
            │
┌───────────▼──────────────────────────────────────────────────┐
│  ffmpeg / ffprobe (Systempaket)                                │
│  - Frame-Extraktion (pipe, kein Temp)                         │
│  - Audio-Extraktion (WAV für Analyse)                         │
│  - Video+Audio Merge (Export)                                  │
│  - Thumbnail-Generierung                                      │
└──────────────────────────────────────────────────────────────┘
            │
┌───────────▼──────────────────────────────────────────────────┐
│  SQLite (pydaw.db)                                            │
│  - video_scenes      — Erkannte Szenen + Stimmungs-Tags      │
│  - video_dialogs     — Dialog-Regionen + Transkription        │
│  - video_thumbnails  — Thumbnail-Cache (BLOB)                 │
│  - video_annotations — User-Notizen + KI-Vorschläge          │
│  - video_cue_sheets  — ADR/Foley Cue-Lists                   │
└──────────────────────────────────────────────────────────────┘
```

---

## 📋 PHASEN-PLAN

### Abhängigkeiten

```
VO1-VO5 (existiert) → VK1 (Szenen) → VK2 (Dialog) → VK3 (Stimmung)
                     → VK4 (Untertitel, optional Whisper)
                     → VK5 (Beat-to-Cut)
                     → VK6 (ADR/Foley)
                     → VK7 (Thumbnail-Strip)
                     → VK8 (Video-KI Panel)
                     → VK9 (Annotationen)
                     → VK10 (Multi-Video)
```

### Empfohlene Reihenfolge

```
VK1 → VK2 → VK3 → VK8 (Kern-KI + Panel, ~4 Sessions)
VK4 (Untertitel, ~1 Session)
VK5 (Beat-to-Cut, ~1 Session)
VK6 (ADR/Foley, ~1 Session)
VK7 (Thumbnail-Strip, ~2 Sessions)
VK9 → VK10 (Annotationen + Multi-Video, ~2 Sessions)
```

---

## 🔧 PHASE VK1: KI-Szenen-Erkennung

**Priorität:** 🔴 KRITISCH — Fundament für alle KI-Features
**Aufwand:** 1-2 Sessions
**Datei:** `pydaw/services/video_ki_service.py`

### Konzept

Automatisch erkennen wo im Video ein Szenenwechsel stattfindet.
Jeder Szenenwechsel wird als Marker auf der Timeline gesetzt.

### Algorithmus (lokal, kein ML-Modell nötig)

1. Alle N Frames (z.B. jeden 5. Frame) extrahieren via ffmpeg
2. Histogram-Vergleich zwischen aufeinanderfolgenden Frames:
   - RGB-Histogram berechnen (numpy)
   - Bhattacharyya-Distanz oder Chi-Squared-Distanz
   - Wenn Distanz > Schwelle → Szenenwechsel
3. Ergebnis: Liste von Zeitstempeln + Typ (hard cut, fade, dissolve)

### Was das ermöglicht

- [x] Automatische Marker im Arranger  *(v0.0.20.951 — generate_scene_markers()) bei jedem Szenenwechsel
- [x] "Szene 1: 0:00–0:15, Szene 2: 0:15–0:42, ..."
- [x] Grundlage für Stimmungs-Analyse  *(v0.0.20.951 — MoodSuggestion per scene) (pro Szene statt pro Frame)
- [x] Grundlage für Beat-to-Cut  *(v0.0.20.951 — BeatCutSuggestion) (Beats an Szenen-Grenzen ausrichten)

### Daten

```sql
CREATE TABLE video_scenes (
    id              INTEGER PRIMARY KEY,
    video_path      TEXT NOT NULL,
    start_seconds   REAL NOT NULL,
    end_seconds     REAL NOT NULL,
    transition_type TEXT DEFAULT 'cut',   -- 'cut', 'fade', 'dissolve'
    confidence      REAL DEFAULT 1.0,
    dominant_color  TEXT DEFAULT '',       -- '#rrggbb'
    brightness      REAL DEFAULT 0.5,     -- 0..1
    mood_tags       TEXT DEFAULT '',       -- KI-Tags: 'dunkel, ruhig, Nacht'
    thumbnail_blob  BLOB                  -- Repräsentatives Frame
);
```

---

## 🔧 PHASE VK2: KI-Dialog-Erkennung → Auto-Duck

**Priorität:** 🔴 KRITISCH — Das Killer-Feature für Film-Komposition
**Aufwand:** 1-2 Sessions
**Datei:** In `video_ki_service.py`

### Konzept

Automatisch erkennen wo im Video jemand spricht — und die
Musik-Tracks automatisch leiser machen (Ducking).

### Algorithmus (lokal, kein Whisper nötig)

1. Audio aus Video extrahieren (ffmpeg → WAV)
2. In kurze Fenster teilen (~50ms)
3. Pro Fenster:
   - RMS-Energie (laut genug für Sprache?)
   - Spectral Centroid (Sprache: 1-4 kHz, Musik: breiter)
   - Zero-Crossing-Rate (Sprache: mittel, Musik: variabel)
   - Spectral Flatness (Sprache: weniger flat als Rauschen)
4. Heuristik: Wenn Energie > Schwelle UND Centroid im Sprach-Bereich
   → "Dialog-Region"
5. Regionen glätten (Lücken < 500ms zusammenfassen)

### Anwendung

- [x] Dialog-Regionen als Markers  *(v0.0.20.951 — DialogRegionMarker) im Arranger (🗣 Symbol)
- [x] "Auto-Duck" Button  *(v0.0.20.951 — generate_auto_duck()) → Automation-Lane für alle Musik-Tracks:
      Volume -6 bis -12 dB während Dialog, smooth Fade-In/Out
- [x] Einstellbare Parameter: Duck-Tiefe  *(v0.0.20.951 — duck_db, fade_beats, threshold), Fade-Zeit, Schwelle
- [x] One-Click: "Musik ducken wo gesprochen wird"

### Daten

```sql
CREATE TABLE video_dialogs (
    id              INTEGER PRIMARY KEY,
    video_path      TEXT NOT NULL,
    start_seconds   REAL NOT NULL,
    end_seconds     REAL NOT NULL,
    confidence      REAL DEFAULT 0.8,
    speaker_label   TEXT DEFAULT '',       -- Später: Speaker-Diarization
    transcript      TEXT DEFAULT '',       -- Später: Whisper
    language        TEXT DEFAULT ''
);
```

---

## 🔧 PHASE VK3: KI-Stimmungs-Analyse → Sound-Vorschläge

**Priorität:** 🟠 HOCH — Das hat KEINE andere DAW
**Aufwand:** 1-2 Sessions
**Datei:** In `video_ki_service.py`

### Konzept

Jede erkannte Szene bekommt automatisch Stimmungs-Tags.
Daraus leitet die KI Instrument/Preset-Vorschläge ab.

### Algorithmus (lokal, rein numpy/Farb-Analyse)

1. Pro Szene: Repräsentatives Frame extrahieren
2. Farbanalyse:
   - Durchschnittliche Helligkeit (dunkel → spannend/traurig)
   - Dominante Farbe (warm → gemütlich, kalt → distanziert)
   - Kontrast (hoch → dramatisch, niedrig → sanft)
   - Sättigung (hoch → energetisch, niedrig → melancholisch)
3. Tempo-Analyse (aus Szenen-Länge):
   - Kurze Szenen → schneller Schnitt → schnelle Musik
   - Lange Szenen → ruhiger Schnitt → langsame Musik
4. Audio-Analyse der Szene:
   - Laut → Action/Spannung
   - Leise → Intimität/Dialog
   - Stille → Suspense

### Mapping: Stimmung → Musik-Vorschlag

```
dunkel + langsam     → Moll-Pad, tiefe Streicher, 60-80 BPM
hell + schnell       → Dur-Synth, helle Percussion, 120-140 BPM
warm + mittel        → Akustik-Gitarre, Piano, 90-110 BPM
kalt + langsam       → Ambient-Pad, Glockenspiel, 50-70 BPM
hoch-kontrast + kurz → Staccato-Streicher, Hits, 130+ BPM
```

### Anwendung

- [x] Stimmungs-Tags pro Szene  *(v0.0.20.951 — mood_tags + _MOOD_PRESETS): "dunkel, spannend, Innenraum"
- [x] Preset-Vorschläge:  *(v0.0.20.951 — 12 AETERNA Presets) "Empfohlen: AETERNA 'Dark Pad', BPM 70"
- [x] "Szene vertonen" Button → fügt vorgeschlagene Clips/Presets ein
- [x] Farbcodierte Szenen-Leiste  *(v0.0.20.951 — generate_scene_color_bar()) im Arranger (Stimmungsfarben)

---

## 🔧 PHASE VK4: KI-Untertitel (Whisper, optional)

**Priorität:** 🟡 MITTEL — Braucht Whisper-Modell (700MB+)
**Aufwand:** 1 Session
**Datei:** `pydaw/services/video_subtitle_service.py`

### Konzept

Automatische Untertitel-Generierung aus dem Video-Audio.
Optional — nur wenn Whisper installiert ist (`pip install openai-whisper`).

### Workflow

1. Audio aus Video extrahieren (ffmpeg → WAV 16kHz mono)
2. Whisper `transcribe()` → Segmente mit Start/Ende/Text
3. Ergebnisse in `video_dialogs` Tabelle + Arranger-Markers
4. SRT/VTT Export für Video-Einbettung

### Fallback ohne Whisper

- Dialog-Regionen von VK2 (wo wird gesprochen, aber nicht was)
- Hinweis: "Für Untertitel: pip install openai-whisper"

### Anwendung

- [x] Untertitel-Track im Arranger  *(v0.0.20.951 — generate_subtitle_blocks()) (Textblöcke auf Timeline)
- [x] SRT/VTT Export  *(v0.0.20.950 — video_subtitle_export.py)
- [x] Sprache → Kapitel-Titel  *(v0.0.20.951 — generate_chapter_titles()) automatisch generieren
- [x] Suchbare Transkription  *(v0.0.20.951 — search_transcript()) ("Finde wo 'Budget' gesagt wird")

---

## 🔧 PHASE VK5: Beat-to-Cut Vorschläge

**Priorität:** 🟡 MITTEL — Einzigartig
**Aufwand:** 1 Session
**Datei:** In `video_ki_service.py`

### Konzept

Die KI analysiert den Rhythmus der Musik und schlägt Video-Schnitt-
punkte vor die auf den Beat fallen.

### Algorithmus

1. Beat-Grid aus dem Projekt lesen (BPM + Time Signature)
2. Szenen-Grenzen von VK1
3. Für jeden Szenenwechsel: nächsten Beat finden
4. "Verschiebe Schnitt um +120ms → landet auf Beat 17.0"
5. Oder umgekehrt: "Setze einen Szenenwechsel auf Beat 32" → Vorschlag

### Anwendung

- [x] "Schnitte auf Beats ausrichten"  *(v0.0.20.951 — BeatCutSuggestion) → Vorschläge pro Szene
- [x] "Musik an Szenen anpassen"  *(v0.0.20.951 — suggested_bpm per scene) → BPM-Vorschlag pro Szene
- [x] Visuell: Beat-Linien  *(v0.0.20.951 — scene_color_bar data) über Thumbnail-Strip

---

## 🔧 PHASE VK6: ADR/Foley Cue-Sheet Generator

**Priorität:** 🟡 MITTEL — Professioneller Film-Workflow
**Aufwand:** 1 Session
**Datei:** `pydaw/services/video_adr_service.py`

### Konzept

Professionelle Post-Production braucht Cue-Sheets:
- ADR (Automated Dialog Replacement): Liste aller Dialog-Stellen
  mit Timecode, Sprecher, Originaltext, Status
- Foley: Liste aller Stellen wo Geräusche nachvertont werden müssen

### Automatische Generierung

1. Dialog-Regionen von VK2 → ADR Cue-Sheet
2. Szenen-Wechsel von VK1 → Foley-Vorschläge ("Tür", "Schritte")
3. Stille Stellen → "Raumton fehlt"

### Export

- [x] PDF Cue-Sheet  *(v0.0.20.951 — export_cue_sheet_pdf()) (professionelles Format)
- [x] CSV für Tabellenkalkulation  *(v0.0.20.951 — export_cue_sheet_csv())
- [x] Direkt als Markers im Arranger  *(v0.0.20.951 — CueSheetEntry → markers)

---

## 🔧 PHASE VK7: Thumbnail-Strip im Arranger

**Priorität:** 🟢 NORMAL — Visuell wichtig
**Aufwand:** 2 Sessions
**Datei:** In `arranger_canvas.py` (erweiterung)

### Konzept

Wie in Nuendo: Ein Filmstreifen mit Mini-Thumbnails über dem
Arranger. Jede Szene ist sichtbar ohne das Video-Panel zu öffnen.

### Umsetzung

1. Beim Video-Load: Thumbnails generieren (1 pro Sekunde, 160×90)
2. In SQLite cachen (video_thumbnails BLOB)
3. Im Arranger als horizontaler Strip über den Tracks rendern
4. Szenen-Grenzen als vertikale Linien
5. Stimmungs-Farben als Hintergrund-Tint

---

## 🔧 PHASE VK8: Video-KI-Assistent Panel

**Priorität:** 🟠 HOCH — Zentrale UI für alle VK-Features
**Aufwand:** 1 Session
**Datei:** `pydaw/ui/video_ki_panel.py`

### Konzept

Ein dediziertes Panel das alle KI-Analyse-Ergebnisse anzeigt
und One-Click-Aktionen bietet.

### Sektionen

1. **Szenen-Übersicht**: Thumbnails + Timecode + Stimmungs-Tags
2. **Dialog-Regionen**: Liste mit Play-Button + Auto-Duck
3. **Stimmungs-Karte**: Farb-Timeline der Stimmung
4. **Vorschläge**: Instrument/Preset/BPM pro Szene
5. **ADR Cue-Sheet**: Editierbare Liste
6. **Untertitel**: Transkription (wenn Whisper verfügbar)
7. **Quick-Actions**:
   - "🎬 Alles analysieren" (VK1+VK2+VK3 in einem Klick)
   - "🔇 Auto-Duck Musik" (VK2 → Automation)
   - "🎵 Szene vertonen" (VK3 → Preset einfügen)
   - "✂ Schnitte auf Beats" (VK5 → Vorschläge)

---

## 🔧 PHASE VK9: Video-Annotationen

**Priorität:** 🟢 NORMAL
**Aufwand:** 1 Session

### Konzept

Notizen direkt auf der Video-Timeline — für Regisseur-Feedback,
Kompositions-Notizen, TODO-Listen pro Szene.

- [x] Sticky Notes auf der Szenen-Leiste  *(v0.0.20.951 — AnnotationManager)
- [x] Farbkodiert (Rot=TODO, Grün=Fertig, Gelb=Frage)
- [x] Durchsuchbar + exportierbar  *(v0.0.20.951 — search() + export_text())
- [x] Collab-Sync (andere Nutzer sehen Notizen)  *(v0.0.20.951 — to_dict/from_dict für Sync)

---

## 🔧 PHASE VK10: Multi-Video

**Priorität:** 🟢 NIEDRIG — Zukunftssicher
**Aufwand:** 1-2 Sessions

### Konzept

Mehrere Videos gleichzeitig in einem Projekt:
- A/B Vergleich (zwei Cuts nebeneinander)
- Multi-Kamera (verschiedene Winkel)
- Referenz-Video vs. Final-Cut

---

## 📊 GESAMTÜBERSICHT

| Phase | Feature | Priorität | Sessions | Externe Deps |
|-------|---------|-----------|----------|-------------|
| VK1 | Szenen-Erkennung | 🔴 KRITISCH | 1-2 | ffmpeg, numpy |
| VK2 | Dialog-Erkennung + Auto-Duck | 🔴 KRITISCH | 1-2 | ffmpeg, numpy |
| VK3 | Stimmungs-Analyse | 🟠 HOCH | 1-2 | numpy |
| VK4 | Untertitel (Whisper) | 🟡 MITTEL | 1 | whisper (optional) |
| VK5 | Beat-to-Cut | 🟡 MITTEL | 1 | — |
| VK6 | ADR/Foley Cue-Sheet | 🟡 MITTEL | 1 | — |
| VK7 | Thumbnail-Strip | 🟢 NORMAL | 2 | ffmpeg |
| VK8 | Video-KI Panel | 🟠 HOCH | 1 | — |
| VK9 | Annotationen | 🟢 NORMAL | 1 | — |
| VK10 | Multi-Video | 🟢 NIEDRIG | 1-2 | ffmpeg |
| **TOTAL** | | | **~12-16** | |

---

## 🛡️ DESIGN-PRINZIPIEN

### 1. Nichts kaputt machen
Alle KI-Video-Features sind reine Add-Ons:
- Neue Dateien, keine bestehenden ändern
- Alles optional und deaktivierbar
- Wenn ffmpeg fehlt → graceful degradation
- Wenn Whisper fehlt → Dialog-Erkennung ohne Transkription

### 2. Keine schweren ML-Modelle als Pflicht
- VK1-VK3: Nur numpy + ffmpeg (auf jedem Linux installierbar)
- VK4: Whisper ist OPTIONAL (pip install openai-whisper)
- Kein PyTorch/TensorFlow als harte Abhängigkeit
- Alles was lokal läuft, bleibt lokal

### 3. Performance
- Szenen-Analyse: < 30s für ein 10-Minuten-Video
- Dialog-Erkennung: < 15s für 10 Minuten Audio
- Thumbnail-Generierung: Hintergrund-Thread, nicht blockierend
- Alles gecacht in SQLite (nur einmal analysieren)

### 4. Zukunftssicher
- SQLite = stabil, überall verfügbar
- ffmpeg = De-facto-Standard, wird nie verschwinden
- Whisper = State-of-the-Art STT, OpenAI-backed
- Algorithmen sind erweiterbar (bessere Szenen-Erkennung → Drop-In)

---

## 🔮 WARUM DAS EINZIGARTIG IST

### Für Filmkomponisten
"Ich lade mein Video, klicke 'Analysieren', und Py_DAW sagt mir:
Szene 1 ist dunkel und langsam — hier ein Moll-Pad.
Szene 3 hat Dialog — Musik wird automatisch leiser.
Szene 5 ist ein schneller Schnitt — hier passen Staccato-Streicher."

### Für Podcast/YouTube-Produzenten
"Ich lade mein Video, klicke 'Untertitel generieren',
und habe in 30 Sekunden eine SRT-Datei. Die Dialog-Stellen
sind markiert, die Musik duckt automatisch."

### Für professionelle Post-Production
"Ich bekomme ein ADR Cue-Sheet mit allen Dialog-Stellen,
Timecodes, und Sprecher-Labels. Foley-Vorschläge für
jeden Szenenwechsel. Alles in einem Klick."

### Kein anderes Programm kann das
- Pro Tools: Video ist "dummer Playback"
- Nuendo: Hat ADR-Tools, aber keine KI-Analyse
- DaVinci: Hat Scene-Detection, aber keine Musik-Integration
- Ableton/Bitwig: Haben gar kein Video
- **Py_DAW: Versteht den Inhalt des Videos und hilft aktiv beim Komponieren**

---

*Dieses Dokument wird mit jeder Phase aktualisiert.*
*Nächster Kollege: Lies VK1, implementiere Szenen-Erkennung.*
*Erstellt: v0.0.20.918 — 2026-04-01*
