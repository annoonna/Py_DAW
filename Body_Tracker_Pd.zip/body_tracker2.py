#!/usr/bin/env python3
"""
body_tracker.py - VOLLSTÄNDIG mit GEM-OSC-Erweiterung
Kamera -> MediaPipe Pose -> OSC nach Pure Data + GEM
"""

import cv2
import sys
import signal
import math
import time
import os
import urllib.request
import numpy as np
import mediapipe as mp
from pythonosc import udp_client

# ═══════════════════════════════════════════════════════
#  Konfiguration
# ═══════════════════════════════════════════════════════

OSC_HOST           = "127.0.0.1"
OSC_PORT           = 9002
CAMERA             = "/dev/video1"
CAMERA_WIDTH       = 1280
CAMERA_HEIGHT      = 720
CAMERA_FPS         = 30
MIRROR             = True
SHOW_WINDOW        = True
MIN_DETECTION_CONF = 0.5
MIN_TRACKING_CONF  = 0.5
MIN_PRESENCE_CONF  = 0.5
VELOCITY_SMOOTHING = 0.6
SEND_VELOCITY      = True
SEND_ANGLES        = True
SEND_DISTANCES     = True
SEND_GESTURES      = True
SEND_RAW_LANDMARKS = True
SEND_GEM_LINES     = True

MODEL_PATH = os.path.expanduser(
    "~/Pd/Body Tracker Pure Data Vollständiges System/"
    "pose_landmarker_full.task"
)
MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/"
    "pose_landmarker/pose_landmarker_full/float16/1/"
    "pose_landmarker_full.task"
)

# ═══════════════════════════════════════════════════════
#  Landmark-Namen (MediaPipe Pose 33)
# ═══════════════════════════════════════════════════════

LANDMARK_NAMES = [
    "nose",           "left_eye_inner",  "left_eye",
    "left_eye_outer", "right_eye_inner", "right_eye",
    "right_eye_outer","left_ear",        "right_ear",
    "mouth_left",     "mouth_right",     "left_shoulder",
    "right_shoulder", "left_elbow",      "right_elbow",
    "left_wrist",     "right_wrist",     "left_pinky",
    "right_pinky",    "left_index",      "right_index",
    "left_thumb",     "right_thumb",     "left_hip",
    "right_hip",      "left_knee",       "right_knee",
    "left_ankle",     "right_ankle",     "left_heel",
    "right_heel",     "left_foot_index", "right_foot_index",
]

# ═══════════════════════════════════════════════════════
#  Skelett-Verbindungen
# ═══════════════════════════════════════════════════════

SKELETON_CONNECTIONS = [
    # Gesicht
    (0,1),(1,2),(2,3),(0,4),(4,5),(5,6),(3,7),(6,8),(9,10),
    # Torso
    (11,12),(11,23),(12,24),(23,24),
    # Linker Arm
    (11,13),(13,15),(15,17),(15,19),(15,21),
    # Rechter Arm
    (12,14),(14,16),(16,18),(16,20),(16,22),
    # Linkes Bein
    (23,25),(25,27),(27,29),(27,31),(29,31),
    # Rechtes Bein
    (24,26),(26,28),(28,30),(28,32),(30,32),
]

# Farb-Gruppen pro Verbindung (für GEM OSC)
# 0=Gesicht 1=Torso 2=LinkerArm 3=RechterArm 4=LinkesBein 5=RechtesBein
BONE_GROUPS = (
    [0]*9 + [1]*4 + [2]*5 + [3]*5 + [4]*5 + [5]*5
)

# Körperteil-Farben BGR (Python Fenster)
PART_COLORS = {
    "face":      (255,200,100),
    "torso":     (0,255,255),
    "left_arm":  (0,255,0),
    "right_arm": (255,50,50),
    "left_leg":  (0,200,0),
    "right_leg": (200,0,0),
    "default":   (255,255,255),
}

def connection_color(i, j):
    face  = {0,1,2,3,4,5,6,7,8,9,10}
    torso = {11,12,23,24}
    la    = {11,13,15,17,19,21}
    ra    = {12,14,16,18,20,22}
    ll    = {23,25,27,29,31}
    rl    = {24,26,28,30,32}
    pair  = {i,j}
    if pair <= face:  return PART_COLORS["face"]
    if pair <= la:    return PART_COLORS["left_arm"]
    if pair <= ra:    return PART_COLORS["right_arm"]
    if pair <= ll:    return PART_COLORS["left_leg"]
    if pair <= rl:    return PART_COLORS["right_leg"]
    if pair <= torso: return PART_COLORS["torso"]
    return PART_COLORS["default"]

# ═══════════════════════════════════════════════════════
#  GEM-Farben pro Knochen-Gruppe (R G B 0..1)
# ═══════════════════════════════════════════════════════

GEM_BONE_COLORS = {
    0: [1.0, 0.8, 0.4],   # Gesicht    gelb-orange
    1: [0.0, 1.0, 1.0],   # Torso      cyan
    2: [0.0, 1.0, 0.0],   # LinkerArm  grün
    3: [1.0, 0.2, 0.2],   # RechterArm rot
    4: [0.0, 0.8, 0.0],   # LinkesBein dunkelgrün
    5: [0.8, 0.0, 0.0],   # RechtesBein dunkelrot
}

# ═══════════════════════════════════════════════════════
#  Gelenkwinkel-Definitionen
# ═══════════════════════════════════════════════════════

ANGLE_DEFS = [
    ("left_elbow",     11,13,15),
    ("right_elbow",    12,14,16),
    ("left_shoulder",  13,11,23),
    ("right_shoulder", 14,12,24),
    ("left_knee",      23,25,27),
    ("right_knee",     24,26,28),
    ("left_hip",       11,23,25),
    ("right_hip",      12,24,26),
    ("left_wrist",     13,15,19),
    ("right_wrist",    14,16,20),
    ("left_ankle",     25,27,31),
    ("right_ankle",    26,28,32),
]

# ═══════════════════════════════════════════════════════
#  Abstands-Definitionen
# ═══════════════════════════════════════════════════════

DISTANCE_DEFS = [
    ("hands",       15,16),
    ("feet",        27,28),
    ("shoulders",   11,12),
    ("hips",        23,24),
    ("left_arm",    11,15),
    ("right_arm",   12,16),
    ("left_leg",    23,27),
    ("right_leg",   24,28),
    ("head_hip",     0,23),
    ("wrist_hip_l", 15,23),
    ("wrist_hip_r", 16,24),
]

# ═══════════════════════════════════════════════════════
#  Mathematik
# ═══════════════════════════════════════════════════════

def calc_angle(a, b, c):
    ba = np.array([a[0]-b[0], a[1]-b[1], a[2]-b[2]])
    bc = np.array([c[0]-b[0], c[1]-b[1], c[2]-b[2]])
    cos_a = np.dot(ba,bc) / (
        np.linalg.norm(ba) * np.linalg.norm(bc) + 1e-8
    )
    return float(np.degrees(np.arccos(np.clip(cos_a,-1.0,1.0))))

def calc_dist(a, b):
    return math.sqrt(
        (a[0]-b[0])**2 + (a[1]-b[1])**2 + (a[2]-b[2])**2
    )

def lm_to_xyz(lm):
    x =  (lm.x - 0.5) * 2.0
    y = -(lm.y - 0.5) * 2.0
    z =  lm.z * -1.0
    return (x, y, z)

# ═══════════════════════════════════════════════════════
#  Signal Handler
# ═══════════════════════════════════════════════════════

running = True
def shutdown(*_):
    global running
    running = False

signal.signal(signal.SIGINT,  shutdown)
signal.signal(signal.SIGTERM, shutdown)

# ═══════════════════════════════════════════════════════
#  OSC Client
# ═══════════════════════════════════════════════════════

osc = udp_client.SimpleUDPClient(OSC_HOST, OSC_PORT)

# ═══════════════════════════════════════════════════════
#  Banner
# ═══════════════════════════════════════════════════════

print("═" * 60)
print("  Body Tracker -> Pure Data + GEM")
print("═" * 60)
print(f"  MediaPipe : {mp.__version__}")
print(f"  Kamera    : {CAMERA}")
print(f"  OSC       : {OSC_HOST}:{OSC_PORT}")
print(f"  GEM-Lines : {SEND_GEM_LINES}")
print("═" * 60)

# ═══════════════════════════════════════════════════════
#  Model herunterladen
# ═══════════════════════════════════════════════════════

os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)

if not os.path.exists(MODEL_PATH):
    print("Lade Pose-Model herunter (~30 MB)...")
    def progress(count, block, total):
        pct = min(count * block / total * 100, 100)
        print(f"\r   {pct:.1f}%", end="", flush=True)
    urllib.request.urlretrieve(MODEL_URL, MODEL_PATH, reporthook=progress)
    print("\nModel gespeichert:", MODEL_PATH)
else:
    print(f"Model vorhanden: {os.path.basename(MODEL_PATH)}")

# ═══════════════════════════════════════════════════════
#  Kamera
# ═══════════════════════════════════════════════════════

cap = cv2.VideoCapture(CAMERA, cv2.CAP_V4L2)
if not cap.isOpened():
    print(f"{CAMERA} nicht gefunden -> versuche Index 0")
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Keine Kamera!")
        sys.exit(1)

cap.set(cv2.CAP_PROP_FRAME_WIDTH,  CAMERA_WIDTH)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAMERA_HEIGHT)
cap.set(cv2.CAP_PROP_FPS,          CAMERA_FPS)

aw = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
ah = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
print(f"  Kamera: {aw}x{ah}")

# ═══════════════════════════════════════════════════════
#  MediaPipe Tasks API
# ═══════════════════════════════════════════════════════

from mediapipe.tasks        import python as mp_tasks
from mediapipe.tasks.python import vision as mp_vision
from mediapipe.tasks.python.vision import (
    PoseLandmarkerOptions, RunningMode
)

base_opts = mp_tasks.BaseOptions(model_asset_path=MODEL_PATH)
pose_opts = PoseLandmarkerOptions(
    base_options=base_opts,
    running_mode=RunningMode.VIDEO,
    num_poses=1,
    min_pose_detection_confidence=MIN_DETECTION_CONF,
    min_pose_presence_confidence =MIN_PRESENCE_CONF,
    min_tracking_confidence      =MIN_TRACKING_CONF,
    output_segmentation_masks    =False,
)
landmarker = mp_vision.PoseLandmarker.create_from_options(pose_opts)
print("PoseLandmarker bereit")

# ═══════════════════════════════════════════════════════
#  Velocity-Tracking
# ═══════════════════════════════════════════════════════

prev_lm  = {}
smooth_v = {}
VELOCITY_LM_IDX = [0,11,12,13,14,15,16,23,24,25,26,27,28]

def compute_velocity(name, x, y, z, t):
    global prev_lm, smooth_v
    if name in prev_lm:
        px,py,pz,pt = prev_lm[name]
        dt = t - pt
        if dt > 0.001:
            vx = (x-px)/dt
            vy = (y-py)/dt
            vz = (z-pz)/dt
            if name in smooth_v:
                svx,svy,svz = smooth_v[name]
                s  = VELOCITY_SMOOTHING
                vx = s*svx + (1-s)*vx
                vy = s*svy + (1-s)*vy
                vz = s*svz + (1-s)*vz
            smooth_v[name] = (vx,vy,vz)
            prev_lm[name]  = (x,y,z,t)
            spd = math.sqrt(vx*vx + vy*vy + vz*vz)
            return (vx,vy,vz,spd)
    prev_lm[name]  = (x,y,z,t)
    smooth_v[name] = (0.0,0.0,0.0)
    return (0.0,0.0,0.0,0.0)

# ═══════════════════════════════════════════════════════
#  Gesten
# ═══════════════════════════════════════════════════════

gesture_state   = {}
hip_baseline_y  = None
hip_samples     = []
BASELINE_FRAMES = 60

def detect_gestures(lms):
    global hip_baseline_y, hip_samples

    def p(i): return lm_to_xyz(lms[i])

    nose  = p(0)
    l_sh  = p(11); r_sh  = p(12)
    l_elb = p(13); r_elb = p(14)
    l_wr  = p(15); r_wr  = p(16)
    l_hip = p(23); r_hip = p(24)
    l_kn  = p(25); r_kn  = p(26)
    l_ank = p(27); r_ank = p(28)

    mid_hip_y = (l_hip[1] + r_hip[1]) / 2.0
    mid_sh_y  = (l_sh[1]  + r_sh[1])  / 2.0
    mid_sh_x  = (l_sh[0]  + r_sh[0])  / 2.0
    mid_hip_x = (l_hip[0] + r_hip[0]) / 2.0
    sh_width  = abs(l_sh[0] - r_sh[0])

    if len(hip_samples) < BASELINE_FRAMES:
        hip_samples.append(mid_hip_y)
        if len(hip_samples) == BASELINE_FRAMES:
            hip_baseline_y = float(np.mean(hip_samples))
            print(f"  Huefte-Baseline: {hip_baseline_y:.3f}")

    g = {}

    if hip_baseline_y is not None:
        g["jump"]   = 1 if (mid_hip_y - hip_baseline_y) >  0.15 else 0
        g["crouch"] = 1 if (hip_baseline_y - mid_hip_y) >  0.15 else 0
    else:
        g["jump"] = g["crouch"] = 0

    g["arms_up"]      = 1 if (
        l_wr[1] > l_sh[1]+0.1 and r_wr[1] > r_sh[1]+0.1
    ) else 0
    g["left_arm_up"]  = 1 if l_wr[1] > l_sh[1]+0.15 else 0
    g["right_arm_up"] = 1 if r_wr[1] > r_sh[1]+0.15 else 0

    arms_wide  = (abs(l_wr[0]-l_sh[0]) > sh_width*0.8 and
                  abs(r_wr[0]-r_sh[0]) > sh_width*0.8)
    arms_level = (abs(l_wr[1]-l_sh[1]) < 0.15 and
                  abs(r_wr[1]-r_sh[1]) < 0.15)
    g["t_pose"] = 1 if (arms_wide and arms_level) else 0

    g["hands_together"] = 1 if calc_dist(l_wr, r_wr) < 0.15 else 0

    g["arms_crossed"] = 1 if (
        l_wr[0] < r_sh[0] and r_wr[0] > l_sh[0] and
        abs(l_wr[1]-mid_sh_y) < 0.3 and
        abs(r_wr[1]-mid_sh_y) < 0.3
    ) else 0

    torso_lean      = mid_sh_x - mid_hip_x
    g["lean_left"]  = 1 if torso_lean < -0.1 else 0
    g["lean_right"] = 1 if torso_lean >  0.1 else 0

    return g

# ═══════════════════════════════════════════════════════
#  Label-Map für Anzeige
# ═══════════════════════════════════════════════════════

LABEL_MAP = {
    0:"NOSE",  11:"L_SH",  12:"R_SH",
    13:"L_ELB",14:"R_ELB", 15:"L_WR",
    16:"R_WR", 23:"L_HIP", 24:"R_HIP",
    25:"L_KN", 26:"R_KN",  27:"L_ANK",
    28:"R_ANK",
}

# ═══════════════════════════════════════════════════════
#  FPS
# ═══════════════════════════════════════════════════════

fps_counter = 0
fps_time    = time.time()
current_fps = 0
frame_ts_ms = 0
frame_count = 0

print("\nStarte Tracking... (q=quit  r=reset  m=mirror)\n")

# ═══════════════════════════════════════════════════════
#  Hauptschleife
# ═══════════════════════════════════════════════════════

while running:
    ret, frame = cap.read()
    if not ret:
        print("Kein Frame")
        time.sleep(0.05)
        continue

    frame_count += 1
    now = time.time()

    fps_counter += 1
    if now - fps_time >= 1.0:
        current_fps = fps_counter
        fps_counter = 0
        fps_time    = now

    if MIRROR:
        frame = cv2.flip(frame, 1)

    h, w = frame.shape[:2]

    rgb      = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)

    frame_ts_ms += 33
    result = landmarker.detect_for_video(mp_image, frame_ts_ms)

    body_detected = False
    num_visible   = 0
    cx = cy = cz = 0.0

    if result.pose_landmarks and len(result.pose_landmarks) > 0:
        body_detected = True
        lms = result.pose_landmarks[0]

        num_visible = sum(
            1 for lm in lms
            if hasattr(lm,'visibility') and lm.visibility > 0.5
        )

        # ── RAW LANDMARKS ──────────────────────────────
        if SEND_RAW_LANDMARKS:
            for idx, name in enumerate(LANDMARK_NAMES):
                if idx >= len(lms): break
                lm  = lms[idx]
                x   = round((lm.x - 0.5) * 2.0,  4)
                y   = round(-(lm.y - 0.5) * 2.0, 4)
                z   = round(lm.z * -1.0,           4)
                vis = round(getattr(lm,'visibility',1.0), 4)
                osc.send_message(f"/body/{name}", [x,y,z,vis])

        # ── GELENKWINKEL ──────────────────────────────
        if SEND_ANGLES:
            for aname, ai, bi, ci in ANGLE_DEFS:
                if max(ai,bi,ci) < len(lms):
                    a   = lm_to_xyz(lms[ai])
                    b   = lm_to_xyz(lms[bi])
                    c   = lm_to_xyz(lms[ci])
                    ang = calc_angle(a, b, c)
                    osc.send_message(
                        f"/body/angle/{aname}", [round(ang,2)]
                    )

            if len(lms) > 24:
                l_sh  = lm_to_xyz(lms[11])
                r_sh  = lm_to_xyz(lms[12])
                l_hip = lm_to_xyz(lms[23])
                r_hip = lm_to_xyz(lms[24])
                mid_sh  = tuple(
                    (l_sh[i]+r_sh[i])/2 for i in range(3)
                )
                mid_hip = tuple(
                    (l_hip[i]+r_hip[i])/2 for i in range(3)
                )
                dx = mid_sh[0] - mid_hip[0]
                dy = mid_sh[1] - mid_hip[1]
                torso_lean = math.degrees(
                    math.atan2(dx, dy + 1e-8)
                )
                osc.send_message(
                    "/body/angle/torso_lean",
                    [round(torso_lean,2)]
                )
                nose  = lm_to_xyz(lms[0])
                spine = calc_angle(nose, mid_sh, mid_hip)
                osc.send_message(
                    "/body/angle/spine", [round(spine,2)]
                )

        # ── ABSTÄNDE ──────────────────────────────────
        if SEND_DISTANCES:
            for dname, ai, bi in DISTANCE_DEFS:
                if max(ai,bi) < len(lms):
                    a    = lm_to_xyz(lms[ai])
                    b    = lm_to_xyz(lms[bi])
                    dist = calc_dist(a, b)
                    osc.send_message(
                        f"/body/distance/{dname}",
                        [round(dist,4)]
                    )

        # ── CENTER OF MASS ─────────────────────────────
        com_idx = [0,11,12,23,24,25,26,27,28]
        com_wgt = [1, 3, 3, 5, 5, 2, 2, 1, 1]
        tw = 0
        for ci, cw in zip(com_idx, com_wgt):
            if ci < len(lms):
                p   = lm_to_xyz(lms[ci])
                cx += p[0]*cw
                cy += p[1]*cw
                cz += p[2]*cw
                tw += cw
        if tw:
            cx /= tw; cy /= tw; cz /= tw
        osc.send_message(
            "/body/center_of_mass",
            [round(cx,4), round(cy,4), round(cz,4)]
        )

        # ── VELOCITY ──────────────────────────────────
        if SEND_VELOCITY:
            for idx in VELOCITY_LM_IDX:
                if idx < len(lms) and idx < len(LANDMARK_NAMES):
                    name = LANDMARK_NAMES[idx]
                    p    = lm_to_xyz(lms[idx])
                    vx,vy,vz,spd = compute_velocity(
                        name, p[0], p[1], p[2], now
                    )
                    osc.send_message(
                        f"/body/velocity/{name}",
                        [round(vx,4), round(vy,4),
                         round(vz,4), round(spd,4)]
                    )

        # ── GESTEN ────────────────────────────────────
        if SEND_GESTURES and len(lms) >= 29:
            gestures = detect_gestures(lms)
            for gname, gval in gestures.items():
                if gesture_state.get(gname) != gval:
                    gesture_state[gname] = gval
                    osc.send_message(
                        f"/body/gesture/{gname}", [gval]
                    )

        # ── GEM SKELETT-LINIEN ─────────────────────────
        if SEND_GEM_LINES:
            for bone_idx, (i, j) in enumerate(
                SKELETON_CONNECTIONS
            ):
                if i < len(lms) and j < len(lms):
                    li = lms[i]
                    lj = lms[j]
                    vi = getattr(li,'visibility',1.0)
                    vj = getattr(lj,'visibility',1.0)
                    # Sichtbarkeit: 1 wenn sichtbar 0 wenn nicht
                    visible = 1 if (vi > 0.4 and vj > 0.4) else 0
                    x1 = round((li.x - 0.5) * 2.0,  4)
                    y1 = round(-(li.y - 0.5) * 2.0, 4)
                    x2 = round((lj.x - 0.5) * 2.0,  4)
                    y2 = round(-(lj.y - 0.5) * 2.0, 4)
                    grp = BONE_GROUPS[bone_idx]
                    osc.send_message(
                        f"/gem/bone/{bone_idx}",
                        [x1, y1, x2, y2, visible, grp]
                    )

            # Wichtige Punkte senden
            POINT_IDX = [
                0,
                11,12,13,14,
                15,16,
                23,24,25,26,
                27,28,31,32
            ]
            for idx in POINT_IDX:
                if idx < len(lms):
                    lm = lms[idx]
                    vis = getattr(lm,'visibility',1.0)
                    px = round((lm.x - 0.5) * 2.0,  4)
                    py = round(-(lm.y - 0.5) * 2.0, 4)
                    v  = 1 if vis > 0.4 else 0
                    osc.send_message(
                        f"/gem/point/{idx}", [px, py, v]
                    )

            # Frame-fertig Signal
            osc.send_message("/gem/frame", [frame_count])

        # ── ZEICHNEN Python-Fenster ────────────────────
        if SHOW_WINDOW:
            for (i,j) in SKELETON_CONNECTIONS:
                if i < len(lms) and j < len(lms):
                    li = lms[i]; lj = lms[j]
                    vi = getattr(li,'visibility',1.0)
                    vj = getattr(lj,'visibility',1.0)
                    if vi > 0.4 and vj > 0.4:
                        x1 = int(li.x*w); y1 = int(li.y*h)
                        x2 = int(lj.x*w); y2 = int(lj.y*h)
                        cv2.line(
                            frame,(x1,y1),(x2,y2),
                            connection_color(i,j),2
                        )

            for idx, lm in enumerate(lms):
                v = getattr(lm,'visibility',1.0)
                if v > 0.4:
                    px = int(lm.x * w)
                    py = int(lm.y * h)
                    r  = (8 if idx in (0,11,12,23,24) else
                          6 if idx in (15,16,27,28)   else 4)
                    cv2.circle(frame,(px,py),r,(0,255,255),-1)

            for idx, label in LABEL_MAP.items():
                if idx < len(lms):
                    lm = lms[idx]
                    if getattr(lm,'visibility',1.0) > 0.4:
                        cv2.putText(
                            frame, label,
                            (int(lm.x*w)+8, int(lm.y*h)-5),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.38,(200,200,200),1
                        )

            # Center of Mass
            com_px = int((cx/2.0+0.5)*w)
            com_py = int((-cy/2.0+0.5)*h)
            cv2.circle(frame,(com_px,com_py),10,(0,0,255),2)
            cv2.putText(
                frame,"COM",
                (com_px+12,com_py+5),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.45,(0,0,255),1
            )

    # ── Presence ──────────────────────────────────────
    osc.send_message(
        "/body/presence",      [1 if body_detected else 0]
    )
    osc.send_message(
        "/body/num_landmarks", [num_visible]
    )

    # ── Status Overlay ─────────────────────────────────
    if SHOW_WINDOW:
        col = (0,255,0) if body_detected else (0,0,255)
        cv2.putText(
            frame,
            f"{'BODY' if body_detected else 'NO BODY'} | "
            f"LM:{num_visible}/33 | FPS:{current_fps}",
            (20,35),
            cv2.FONT_HERSHEY_SIMPLEX,0.7,col,2
        )
        cv2.putText(
            frame,
            "q=quit  r=reset  m=mirror",
            (20,h-15),
            cv2.FONT_HERSHEY_SIMPLEX,0.5,(150,150,150),1
        )

        gy = 65
        for gname, gval in gesture_state.items():
            if gval:
                cv2.putText(
                    frame,
                    f"* {gname.upper()}",
                    (20,gy),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,(0,255,0),2
                )
                gy += 22

        cv2.line(frame,(w//2,0),(w//2,h),(60,60,60),1)
        cv2.imshow("Body Tracker", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
        elif key == ord("r"):
            hip_baseline_y = None
            hip_samples.clear()
            print("  Baseline zurueckgesetzt")
        elif key == ord("m"):
            MIRROR = not MIRROR
            print(f"  Spiegel: {'Ein' if MIRROR else 'Aus'}")

    if frame_count % 90 == 0:
        ag = [g for g,v in gesture_state.items() if v]
        print(
            f"  Frame={frame_count} | "
            f"Body={'OK' if body_detected else '--'} | "
            f"LM={num_visible}/33 | "
            f"FPS={current_fps} | "
            f"Gest={ag or 'none'}"
        )

# ═══════════════════════════════════════════════════════
#  Cleanup
# ═══════════════════════════════════════════════════════

print(f"\nBody Tracker beendet | {frame_count} Frames")
osc.send_message("/body/presence", [0])
osc.send_message("/gem/frame",     [0])
for gname in gesture_state:
    osc.send_message(f"/body/gesture/{gname}", [0])

cap.release()
cv2.destroyAllWindows()
landmarker.close()
print("Cleanup abgeschlossen")
