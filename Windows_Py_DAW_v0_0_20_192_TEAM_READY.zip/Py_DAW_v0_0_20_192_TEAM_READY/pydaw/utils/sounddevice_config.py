"""sounddevice (PortAudio) helper for consistent Windows defaults.

Ziel: Nichts an bestehender Audio-Logik ändern, nur Defaults setzen, wenn möglich.

Env Vars:
- PYDAW_SD_HOSTAPI: bevorzugte HostAPI (z.B. wasapi, asio, directsound, mme)
- PYDAW_SD_OUT: bevorzugtes Output-Device (Index oder Substring)
- PYDAW_SD_IN: bevorzugtes Input-Device (Index oder Substring)
- PYDAW_WASAPI_EXCLUSIVE: "1" aktiviert Exclusive Mode (wenn sounddevice es unterstützt)

Dieses Modul ist defensiv: es darf niemals den Start blockieren.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Optional, Tuple


@dataclass
class SdSelection:
    hostapi_index: Optional[int] = None
    out_device: Optional[int] = None
    in_device: Optional[int] = None
    extra_settings_out: Any = None
    extra_settings_in: Any = None


def _env_norm(key: str) -> str:
    return os.environ.get(key, "").strip()


def _try_int(s: str) -> Optional[int]:
    try:
        return int(s)
    except Exception:
        return None


def _match_device_index(devices: list[dict], needle: str, kind: str) -> Optional[int]:
    """needle may be an int index or substring match."""
    if not needle:
        return None
    idx = _try_int(needle)
    if idx is not None and 0 <= idx < len(devices):
        return idx
    n = needle.lower()
    for i, d in enumerate(devices):
        name = str(d.get("name", "")).lower()
        if n in name:
            # ensure device has channels for kind
            if kind == "out" and int(d.get("max_output_channels", 0)) > 0:
                return i
            if kind == "in" and int(d.get("max_input_channels", 0)) > 0:
                return i
    return None


def select(sd_module) -> SdSelection:
    """Return best-effort selection based on env + platform defaults."""
    sel = SdSelection()
    try:
        devices = list(sd_module.query_devices())
    except Exception:
        return sel

    # HostAPI preference (by name)
    host_pref = _env_norm("PYDAW_SD_HOSTAPI").lower()
    try:
        hostapis = list(sd_module.query_hostapis())
    except Exception:
        hostapis = []

    if host_pref and hostapis:
        for i, h in enumerate(hostapis):
            name = str(h.get("name", "")).lower()
            if host_pref in name:
                sel.hostapi_index = i
                break

    # Devices
    sel.out_device = _match_device_index(devices, _env_norm("PYDAW_SD_OUT"), "out")
    sel.in_device = _match_device_index(devices, _env_norm("PYDAW_SD_IN"), "in")

    # WASAPI Exclusive (if supported)
    want_excl = _env_norm("PYDAW_WASAPI_EXCLUSIVE").lower() in ("1", "true", "yes", "on")
    if want_excl:
        try:
            WasapiSettings = getattr(sd_module, "WasapiSettings", None)
            if WasapiSettings is not None:
                # If hostapi is WASAPI, we can set exclusive.
                sel.extra_settings_out = WasapiSettings(exclusive=True)
                sel.extra_settings_in = WasapiSettings(exclusive=True)
        except Exception:
            pass

    return sel


def apply_output_defaults(sd_module) -> Tuple[Optional[int], Any]:
    """Apply global defaults for output. Returns (device_index, extra_settings)."""
    sel = select(sd_module)
    try:
        if sel.hostapi_index is not None:
            sd_module.default.hostapi = sel.hostapi_index  # type: ignore[attr-defined]
    except Exception:
        pass
    try:
        if sel.out_device is not None:
            # sounddevice default.device is (in, out)
            cur = sd_module.default.device
            if isinstance(cur, (list, tuple)) and len(cur) == 2:
                sd_module.default.device = (cur[0], sel.out_device)
            else:
                sd_module.default.device = (None, sel.out_device)
    except Exception:
        pass
    return sel.out_device, sel.extra_settings_out


def apply_input_defaults(sd_module) -> Tuple[Optional[int], Any]:
    """Apply global defaults for input. Returns (device_index, extra_settings)."""
    sel = select(sd_module)
    try:
        if sel.hostapi_index is not None:
            sd_module.default.hostapi = sel.hostapi_index  # type: ignore[attr-defined]
    except Exception:
        pass
    try:
        if sel.in_device is not None:
            cur = sd_module.default.device
            if isinstance(cur, (list, tuple)) and len(cur) == 2:
                sd_module.default.device = (sel.in_device, cur[1])
            else:
                sd_module.default.device = (sel.in_device, None)
    except Exception:
        pass
    return sel.in_device, sel.extra_settings_in
