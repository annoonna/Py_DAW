"""Cross-platform user directories for ChronoScaleStudio.

Oberste Direktive: nichts kaputt machen.

Wir kapseln Pfade (Config/Cache/Logs) in eine kleine Utility, damit Windows/macOS
keine Linux-spezifischen ".config"/".cache"-Ordner brauchen.

- Windows: %APPDATA% / %LOCALAPPDATA%
- macOS:   ~/Library/Application Support / ~/Library/Caches
- Linux:   XDG_* oder ~/.config ~/.cache

Abhängigkeit: platformdirs (klein, robust).
"""

from __future__ import annotations

from pathlib import Path

try:
    from platformdirs import user_cache_dir, user_config_dir, user_data_dir, user_log_dir
except Exception:  # pragma: no cover
    user_cache_dir = user_config_dir = user_data_dir = user_log_dir = None  # type: ignore


APP_NAME = "ChronoScaleStudio"
APP_AUTHOR = "ChronoScaleStudio"


def config_dir() -> Path:
    if user_config_dir:
        return Path(user_config_dir(APP_NAME, APP_AUTHOR))
    return Path.home() / ".config" / APP_NAME


def cache_dir() -> Path:
    if user_cache_dir:
        return Path(user_cache_dir(APP_NAME, APP_AUTHOR))
    return Path.home() / ".cache" / APP_NAME


def data_dir() -> Path:
    if user_data_dir:
        return Path(user_data_dir(APP_NAME, APP_AUTHOR))
    # fallback: keep everything in config if platformdirs missing
    return config_dir() / "data"


def log_dir() -> Path:
    if user_log_dir:
        return Path(user_log_dir(APP_NAME, APP_AUTHOR))
    return cache_dir() / "logs"
