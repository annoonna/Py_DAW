"""Installer helper for Py_DAW.

Usage:
    python3 install.py

It will:
- warn if you're not inside a virtual environment
- install/upgrade pip
- install requirements.txt

Note:
- JACK/PipeWire system components are not installed here (distro packages).
"""

from __future__ import annotations

import os
import sys
import subprocess
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def main() -> int:
    here = Path(__file__).resolve().parent
    is_windows = sys.platform.startswith("win")

    # Windows: prefer a dedicated requirements file (prevents Linux-only deps from breaking pip).
    req = here / ("requirements_windows.txt" if is_windows else "requirements.txt")
    if not req.exists():
        # fallback (shouldn't happen, but keep installer robust)
        req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        if is_windows:
            print("      Empfehlung (PowerShell): python -m venv .venv ; .\\.venv\\Scripts\\Activate.ps1")
            print("      Empfehlung (CMD):       python -m venv .venv && .\\.venv\\Scripts\\activate.bat")
        else:
            print("      Empfehlung: python3 -m venv myenv && source myenv/bin/activate")

    py = sys.executable
    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    _run([py, "-m", "pip", "install", "-r", str(req)])

    print("\nOK. Starte danach mit: python main.py")
    if is_windows:
        print("Hinweis Windows: Audio läuft standardmäßig über PortAudio (sounddevice).")
        print("  - Empfohlen: PYDAW_SD_HOSTAPI=wasapi")
        print("  - Optional:  PYDAW_WASAPI_EXCLUSIVE=1 (Exclusive Mode, wenn verfügbar)")
        print("  - Optional:  PYDAW_QT_OPENGL=angle (wenn die UI schwarz bleibt)")
        print("FluidSynth (SF2 Render) optional: setze FLUIDSYNTH_PATH auf fluidsynth.exe oder füge es zum PATH hinzu.")
    else:
        print("Optional: Audio/MIDI Abhängigkeiten können Systempakete erfordern (PipeWire-JACK/JACK/qpwgraph).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
