# 📝 SESSION LOG: 2026-03-14 — FX Instance Reuse + Deferred Loading (v0.0.20.477)

**Entwickler:** Claude Opus 4.6
**Task:** Priorität 1 — `rebuild_fx_maps()` FX Instance Reuse Fix + Initial Load Performance
**Version:** v0.0.20.476 → v0.0.20.477

## ROOT CAUSE ANALYSE

### Bug 1: Instrument Engine Reuse ALWAYS Failed (Multi-Plugin Bundles)
**Datei:** `audio_engine.py`
**Root Cause:** Pfad-Vergleich `old_eng.path == vst_ref` verglich aufgelösten Basispfad
mit rohem Referenz-String inkl. `::pydaw_plugin::` Separator → IMMER Mismatch.

### Bug 2: FX Chain Rebuilt from Scratch on Every Play/Stop
**Datei:** `fx_chain.py`
**Root Cause:** Kein Mechanismus um unveränderte Chains zu erkennen.

### Bug 3: Initiales Laden 30s+ Freeze
**Datei:** `vst3_host.py`
**Root Cause:** Drei Bottlenecks:
1. `pedalboard.load_plugin()` blockiert Main-Thread (5-15s pro Plugin)
2. 2145 `getattr()` C++-Bridge-Calls nach State-Restore (Presswerk: ~3s)
3. Alles sequentiell auf Main-Thread

## ERLEDIGTE TASKS

- [x] **Chain Fingerprinting** — JSON-Fingerprint Vergleich, unveränderte Chains wiederverwendet
- [x] **Instrument Engine Pfad-Fix** — `resolve_plugin_reference()` + basename-Fallback
- [x] **VST3/VST2 FX Device Pfad-Fix** — Selbe Logik in `_compile_devices()`
- [x] **Deferred Background Loading (FX)** — `defer_load=True`, Hintergrund-Thread
- [x] **Deferred Background Loading (Instruments)** — Sofort registriert, Hintergrund-Thread
- [x] **Fast Param Setup** — 0 C++-Bridge-Calls nach raw_state Restore
- [x] **Timing-Diagnostik** — load/state/params/total Timing in Logs
- [x] **Reuse-Logging** — Diagnose auf stderr für alle Reuse-Entscheidungen

## CODE-ÄNDERUNGEN

**Geändert:**
- `pydaw/audio/fx_chain.py` — Chain Fingerprinting, deferred FX loads, robuste Pfad-Vergleiche
- `pydaw/audio/audio_engine.py` — Instrument Engine Pfad-Fix, deferred inst loads, bg threads
- `pydaw/audio/vst3_host.py` — Fast Param Setup, defer_load, Timing-Diagnostik
- `pydaw/audio/vst2_host.py` — defer_load Parameter

**Nicht angefasst:** Kein Audio-Callback, kein UI-Code, keine neuen Dependencies

## ERWARTETE VERBESSERUNG
- **Play/Stop:** <50ms (war ~10-30s)
- **Initiales Laden:** UI reagiert sofort (<1s), Plugins laden im Hintergrund
- **Param Setup:** <1ms nach State-Restore (war 2-8s für 2145 Params)
