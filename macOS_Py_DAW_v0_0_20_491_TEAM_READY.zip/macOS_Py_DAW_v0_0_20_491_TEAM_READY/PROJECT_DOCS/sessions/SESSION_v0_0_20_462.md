# Session Log — v0.0.20.462

**Datum:** 2026-03-14
**Kollege:** Claude Opus 4.6
**Task:** VST3 Preset-Corruption Fix (alle Presets klangen gleich)

## Problem

User: "alle presets klingen gleich — windig, luftig, rauschen"

Das bedeutet: Zebra2's interne Preset-Daten werden ZERSTÖRT beim Laden.
Egal welches Preset gewählt wird, es klingt immer wie ein korrumpiertes Init.

## Root Cause

In `Vst3InstrumentEngine._load()` und `Vst3Fx._load()`:

```python
# Zeile 1083 (vorher):
setattr(self._plugin, info.name, init_val)
```

Dieser Code liest den aktuellen Parameterwert vom Plugin (normalisiert 0-1),
und schreibt ihn SOFORT ZURÜCK. Das klingt harmlos, aber:

1. Pedalboard's `getattr()` gibt den **normalisierten** Wert (0.0-1.0)
2. Pedalboard's `setattr()` erwartet teilweise den **physischen** Wert (500ms, 2kHz etc.)
3. Selbst wenn beides normalisiert wäre — Float Round-Trip-Fehler bei 2378 Params
   korrumpieren Zebra2's internen State (Wavetable-Indices, Mod-Matrix-Routing etc.)

Und dann nochmal beim ersten Audio-Callback: `_apply_rt_params()` hatte einen
leeren `_last_param_vals` Cache → schrieb nochmal alle 2378 Params.

## Lösung

### Vst3InstrumentEngine._load():
- KEIN `setattr(plugin, name, val)` mehr für init-Params
- Nur `rt_params.ensure(key, init_val)` (RT-Store registrieren)
- `_last_param_vals[key] = init_val` (Delta-Cache pre-populieren)
- Plugin behält seinen EIGENEN Preset-State

### Vst3Fx._load():
- `setattr()` NUR für Params die in `_params_init` gespeichert waren
  (= User hat den Param mal bewusst geändert/gespeichert)
- Alle anderen Params: nur Cache pre-populieren

### Effekt:
- Plugin-Load: 0 unnötige setattr-Calls (vorher: 2378)
- Erster Callback: 0 Param-Writes (Cache ist vorbelegt)
- User dreht Knob: 1 Param-Write (nur der geänderte)

## Geänderte Dateien

- `pydaw/audio/vst3_host.py` — _load() in beiden Klassen

## Nichts kaputt gemacht

- ✅ RT-Store wird weiterhin korrekt initialisiert (für UI-Slider)
- ✅ Gespeicherte User-Params (aus Projekt-Datei) werden weiterhin angewendet
- ✅ raw_state blob (vollständiger Plugin-State) wird weiterhin restored wenn vorhanden
- ✅ Automation/MIDI-Learn funktioniert weiterhin (schreibt in RT-Store → Delta-Check erkennt Änderung)
