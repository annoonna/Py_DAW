# 📝 SESSION LOG: 2026-03-14 — macOS Main-Thread Fix + Plugin Instance Cache (v0.0.20.478)

**Entwickler:** Claude Opus 4.6
**Version:** v0.0.20.477 → v0.0.20.478

## ROOT CAUSE (aus User-Log)

### Problem 1: Background-Loading scheitert auf macOS
```
[VST3-INST] load failed for .../Zebra2.vst3::pydaw_plugin::Zebra2:
Plugin .../Zebra2.vst3 must be reloaded on the main thread.
```
macOS Cocoa-basierte VST3 Plugins MÜSSEN auf dem Main-Thread geladen werden.
`defer_load=True` im Background-Thread schlägt immer fehl.

### Problem 2: Zebra2.vst3 wird ~12× geladen
Im Log sieht man `INIT AudioProcessor` für Zebra2 ~12×. Jeder Aufruf von
`_load_pedalboard_plugin()` für das Multi-Plugin-Bundle probiert alle 4
Sub-Plugins (Zebra2, Zebralette, ZRev, Zebrify) durch. Das passiert bei:
1. `is_vst_instrument()` — prüft ob Instrument
2. `_create_vst_instrument_engines()` — erstellt Engine (lädt nochmal)
3. `describe_controls()` — UI Widget lädt nochmal
4. Carla/Editor-Pfade — nochmal

## FIXES

- [x] **macOS Platform Guard** — `defer_load` nur auf Linux (`sys.platform != "darwin"`)
- [x] **Plugin Instance Cache** — `_plugin_instance_cache` in vst3_host.py
      - `is_vst_instrument()` speichert geladene Instanz statt `del plugin`
      - `Vst3Fx._load()` prüft Cache zuerst → 0 Loads wenn gecacht
      - `Vst3InstrumentEngine._load()` prüft Cache zuerst → 0 Loads wenn gecacht

## CODE-ÄNDERUNGEN

- `pydaw/audio/audio_engine.py` — Platform-Guard für defer_load
- `pydaw/audio/fx_chain.py` — Platform-Guard für defer_load
- `pydaw/audio/vst3_host.py` — `_plugin_instance_cache`, Cache-Check in beiden `_load()`

## ERWARTETE VERBESSERUNG
- Zebra2 initial: von ~12 Loads auf ~2-3 (1× is_instrument + 1× Engine reuses cache)
- Kein "must be reloaded on main thread" Fehler mehr
- Play/Stop bleibt flüssig (<50ms, unverändert aus v477)
