# Session Log — v0.0.20.461

**Datum:** 2026-03-14
**Kollege:** Claude Opus 4.6
**Task:** VST3 Audio Performance Fix (gehackter Sound + GUI-Freeze)

## Problem

Zebra2 lud erfolgreich (v460 Fix wirkte!), aber:
- Gehackter/abgehackter Sound
- GUI/Playhead extrem langsam
- Auf einem Apple M4 mit 16GB RAM — sollte butterweich laufen

## Root Causes (zwei)

### 1. Buffer-Size 8192 = 170ms Latenz
8192 Samples bei 48kHz = 170ms pro Audio-Block. Das ist absurd groß für macOS CoreAudio.
Die sounddevice-Callback-Deadline wird zwar eingehalten, aber:
- 170ms Latenz → hörbare Verzögerung
- Große Blöcke → GUI friert ein während der Block verarbeitet wird

### 2. 2378 Parameter pro Audio-Callback
Zebra2 hat 2378 automatable Parameters. `_apply_rt_params()` hat bei JEDEM
Callback ALLE 2378 an das Plugin geschrieben — egal ob sich etwas geändert hat.
Jeder Schreibzugriff = ein Python→C++ Bridge-Call über pedalboard.
Bei 48kHz/1024 Samples = 47 Callbacks/Sekunde × 2378 Params = **111.766 Bridge-Calls/Sekunde**.
Das war die Hauptursache für den gehackten Sound.

## Lösung

### Fix 1: Platform-aware Buffer-Sizing
```
macOS (Apple Silicon): 1024 Samples = 21ms (mit VST Inst), 512 ohne
Linux:                 2048 Samples = 42ms (mit VST Inst), 1024 ohne
```

### Fix 2: Param Delta-Check (`_last_param_vals`)
```python
prev = last_vals.get(key)
if prev is not None and abs(val - prev) < 1e-7:
    continue  # Skip — nothing changed
last_vals[key] = val
```
Effekt: 2378 → ~0-5 Bridge-Calls pro Callback (nur aktiv automatisierte Params).
Implementiert in BEIDEN Klassen: `Vst3Fx` und `Vst3InstrumentEngine`.

## Geänderte Dateien

- `pydaw/audio/audio_engine.py` — Buffer 8192→1024/2048 (3 Stellen)
- `pydaw/audio/vst3_host.py` — `_last_param_vals` + Delta-Check in beiden _apply_rt_params()
- `pydaw/version.py` — 0.0.20.460 → 0.0.20.461

## Nichts kaputt gemacht

- ✅ Delta-Check ist rein additiv — wenn sich ein Param ändert, wird er sofort geschrieben
- ✅ Erster Callback nach Plugin-Load schreibt ALLE Params (Cache ist leer)
- ✅ Linux Buffer bleibt konservativ (2048) für Surge XT Kompatibilität
- ✅ Arrangement Playback + Preview Output beide aktualisiert
