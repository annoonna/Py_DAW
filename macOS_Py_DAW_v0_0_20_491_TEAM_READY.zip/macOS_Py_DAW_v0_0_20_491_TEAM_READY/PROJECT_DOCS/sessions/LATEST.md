# 📝 SESSION LOG: 2026-03-15 — FX Widget Diagnostik + macOS VST3 Param-Loader Fix (v0.0.20.491)

**Entwickler:** Claude Opus 4.6
**Version:** v0.0.20.490 → v0.0.20.491

## ROOT CAUSE (aus User-Screenshots + Logs)

### Problem 1: Interne Audio-FX zeigen "(no UI yet)" statt ihrer Widgets
`chrono.fx.delay2` etc. zeigen nur Placeholder. Ursache: `make_audio_fx_widget()`
hatte einen `try/except Exception: pass` der ALLE Fehler (Import + Constructor)
komplett verschluckte.

### Problem 2: VST3 Parameter-Widget zeigt "Keine Parameter gefunden" / "Warte auf laufende Plugin-Instanz"
Auf macOS: `_Vst3ParamLoader` (QThread) ruft `describe_controls()` →
`load_plugin()` auf einem **Background-Thread** auf. macOS Cocoa verweigert das:
*"must be reloaded on the main thread"*. Der Fallback-Pfad (Main-Thread-Retry)
funktionierte nur manchmal, weil zu viele native Plugin-Loads die Cocoa-Ressourcen
erschöpften.

### Problem 3 (vorbestehend): Zebra2 Instrument Engine scheitert auf macOS
Zebra2.vst3 ist ein Multi-Plugin-Bundle (Zebra2/Zebralette/ZRev/Zebrify).
Jeder `_load_pedalboard_plugin` Aufruf probt bis zu 4 Sub-Plugins.
Bei 3 Retry-Zyklen = 12+ native macOS Loads → Cocoa erschöpft.
**Dieses Problem bestand schon in v490** — dort war es nicht sichtbar weil
das Projekt bereits geladen war und die Runtime-Instanzen gecacht waren.

## FIXES

### 1. chrono.fx Import/Constructor Error-Logging (fx_device_widgets.py)
- **Lazy Module-Level Import Cache** `_ensure_chrono_fx_imports()` — importiert
  `fx_audio_widgets` genau EINMAL, cacht Erfolg/Fehler
- **Import-Fehler loggen** — `[FX-WIDGETS] IMPORT ERROR` auf stderr mit Traceback
- **Constructor-Fehler separat fangen** — `[FX-WIDGETS] CONSTRUCTOR ERROR`
- **`_make_error_widget()`** — zeigt tatsächlichen Fehler (orange/rot) im Device-Panel

### 2. macOS VST3 Param-Loader: Main-Thread-Direct (fx_device_widgets.py)
- **`_start_async_param_loader()`** prüft `sys.platform == "darwin"`
- Auf macOS: überspringt `_Vst3ParamLoader` QThread komplett
- Geht direkt zu `_load_params_on_main_thread()` via `QTimer.singleShot(0, ...)`
- Kein Background-Thread-Load auf macOS → kein "must be reloaded" Error
- Linux: weiterhin Background-Thread (schneller, keine Cocoa-Probleme)

### 3. LV2 Probe: Connect ALL Ports (lv2_probe.py + lv2_host.py)
- **`lv2_probe.py`**: Probe verband nur Audio + Control-Input-Ports, aber
  **nicht Output-Control-Ports** (Latency, Meter, etc.)
- LV2-Spec: ALLE Ports MÜSSEN verbunden sein → `run()` schrieb in NULL → Crash
- Plugin wurde als "BLOCKED" in Probe-Cache gespeichert → nie wieder geladen
- **Fix**: Probe verbindet jetzt ALLE verbleibenden Ports mit Dummy-Buffers
  (selbes Pattern wie Host-Code, Zeilen 1076–1140)
- **`lv2_host.py`**: `get_probe_status()` invalidiert automatisch alte
  "blocked" Cache-Einträge (`probe_ver < 2`) → Plugins werden neu geprobt
- **`_record_probe()`**: Schreibt `probe_ver: 2` in Cache-Einträge

## GEÄNDERTE DATEIEN

| Datei | Änderung |
|---|---|
| `pydaw/ui/fx_device_widgets.py` | chrono.fx Import-Cache + Error-Logging + macOS Main-Thread Param-Loader |
| `pydaw/tools/lv2_probe.py` | Probe verbindet ALLE Ports (nicht nur Audio+CtlIn) → kein NULL-Crash mehr |
| `pydaw/audio/lv2_host.py` | Probe-Cache auto-invalidiert alte "blocked" Einträge (probe_ver < 2) |
| `install-macos.py` | `_link_lilv_to_venv()` — kopiert lilv.py von Homebrew ins venv |
| `pydaw/version.py` | → 0.0.20.491 |

## NICHTS KAPUTT GEMACHT ✅

- ✅ VST3/VST2 Widget-Pfad (`ext.vst3:`, `ext.vst2:`) → unverändert
- ✅ LV2/LADSPA Widget-Pfad → unverändert
- ✅ `chrono.fx.gain` / `chrono.fx.distortion` → weiterhin direkt instantiiert
- ✅ Note-FX Widgets → unverändert
- ✅ fx_audio_widgets.py → NICHT angefasst
- ✅ vst3_host.py → NICHT angefasst
- ✅ audio_engine.py → NICHT angefasst
- ✅ Linux-Pfad: Background-Thread param loading bleibt aktiv
- ✅ Alle .py Dateien bestehen py_compile Syntax-Check
