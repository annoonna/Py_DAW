# Session Log — v0.0.20.459

**Datum:** 2026-03-14
**Kollege:** Claude Opus 4.6
**Task:** VST3 Deferred Retry Loop Breaker (macOS "main thread" Fix)

## Problem

v0.0.20.458 hat das Multi-Plugin-Bundle-Problem gelöst (Auto-Selecting 'Zebra2' funktioniert),
aber auf macOS kommt ein zweiter Fehler:

```
Plugin /Library/Audio/Plug-Ins/VST3/Zebra2.vst3 must be reloaded on the main thread.
```

Dieser Fehler entsteht weil pedalboard auf macOS (Apple M4/Cocoa) verlangt, dass bestimmte
Plugins auf dem Main Thread geladen werden. Die `_create_vst_instrument_engines()` wird
von `rebuild_fx_maps()` aufgerufen (UI-Thread-Zyklus), und jedes Mal wurde ein neuer
2-Sekunden-Timer für den fehlgeschlagenen Track gestartet → Endlosschleife.

Hinweis: Der Zebra2 Editor öffnet sich trotzdem (Screenshot zeigt Zebra2 UI mit
"HS Basedrop" Preset). Das FX-Laden funktioniert teilweise, nur der
Vst3InstrumentEngine-Pfad scheitert wiederholt.

## Lösung

`_vst_inst_retry_counts: Dict[str, int]` in AudioEngine.__init__():
- Zählt fehlgeschlagene Load-Versuche pro (track_id, vst_ref) Paar
- Nach 3 Fehlversuchen: Aufgeben + einmalige Log-Meldung "Giving up on track..."
- Bei erfolgreichem Load: Counter wird gelöscht (Retry wieder möglich nach z.B. Plugin-Wechsel)

## Geänderte Dateien

- `pydaw/audio/audio_engine.py` — _vst_inst_retry_counts + max-retry-Logik + success-reset
- `pydaw/version.py` — 0.0.20.458 → 0.0.20.459
- `PROJECT_DOCS/progress/TODO.md`, `DONE.md`, Session-Log

## Nichts kaputt gemacht

- ✅ Bestehende erfolgreiche Loads werden nicht beeinflusst (Counter wird nur bei Fehler erhöht)
- ✅ Counter wird bei Erfolg zurückgesetzt → spätere Reloads bleiben möglich
- ✅ Nur die Endlos-Retry-Schleife wird gestoppt, nicht das initiale Laden
