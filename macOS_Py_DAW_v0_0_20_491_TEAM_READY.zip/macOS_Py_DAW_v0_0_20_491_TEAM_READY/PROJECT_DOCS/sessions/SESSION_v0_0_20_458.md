# Session Log — v0.0.20.458

**Datum:** 2026-03-14
**Kollege:** Claude Opus 4.6
**Task:** Multi-Plugin VST3 Bundle Auto-Recovery (u-he Zebra2 Fix)

## Problem

Zebra2.vst3 (u-he) enthält 4 Plugins in einem Bundle: Zebra2, Zebralette, ZRev, Zebrify.
Pedalboard kann das Bundle nicht ohne expliziten `plugin_name` Parameter laden.

Der Plugin-Scanner hatte Zebra2.vst3 nicht in seiner Whitelist für Multi-Plugin-Probing,
daher wurde kein `__ext_plugin_name` gespeichert. Beim Laden kam dann:

```
Plugin file Zebra2.vst3 contains 4 plugins. To open a specific plugin within this file,
pass a "plugin_name" parameter with one of the following values:
    "Zebra2" "Zebralette" "ZRev" "Zebrify"
```

Dieser Fehler wiederholte sich endlos (initial load → deferred retry → describe_controls → etc.)
und produzierte massive Log-Spam.

## Lösung

### 1. Auto-Recovery in `_load_pedalboard_plugin()` (vst3_host.py)
Neue `_guess_best_sub_plugin()` Funktion: Wenn kein `plugin_name` gegeben und der
"contains N plugins"-Fehler kommt, wird automatisch der Sub-Plugin-Name gewählt,
der am besten zum Bundle-Stem passt (z.B. "Zebra2" für Zebra2.vst3).

### 2. Name-Persistence in Vst3Fx._load() und Vst3InstrumentEngine._load()
Nach erfolgreicher Auto-Recovery wird `self.plugin_name` aktualisiert,
damit der Name im Projekt persistiert wird.

### 3. Instrument-Aware Retry in Vst3InstrumentEngine._load()
Wenn der auto-gewählte Sub-Plugin kein Instrument ist (z.B. ZRev ist ein Effect),
werden alle anderen Sub-Plugins durchprobiert bis ein Instrument gefunden wird.

### 4. vst_gui_process.py
Standalone-Editor-Subprocess hat jetzt dieselbe Auto-Recovery-Logik.

### 5. Scanner Whitelist erweitert
`_should_try_multi_vst_probe()` enthält jetzt alle bekannten u-he Bundles
für korrekte Auflistung im Browser (Zebra2, Diva, Hive, Repro, Bazille, etc.).

## Geänderte Dateien

- `pydaw/audio/vst3_host.py` — _load_pedalboard_plugin(), _guess_best_sub_plugin(), Vst3Fx._load(), Vst3InstrumentEngine._load()
- `pydaw/audio/vst_gui_process.py` — _load_plugin()
- `pydaw/services/plugin_scanner.py` — _should_try_multi_vst_probe()
- `pydaw/version.py` — 0.0.20.456 → 0.0.20.458
- `PROJECT_DOCS/progress/TODO.md` — Neue Sektion
- `PROJECT_DOCS/progress/DONE.md` — Neue Sektion

## Nichts kaputt gemacht

- ✅ Bestehende Single-Plugin-Bundles funktionieren unverändert (kein plugin_name → kein Fehler → kein Recovery nötig)
- ✅ Bereits korrekt konfigurierte Multi-Plugin-Referenzen (mit __ext_plugin_name) werden weiterhin direkt geladen
- ✅ Auto-Recovery ist nur Fallback bei fehlendem plugin_name UND "contains N plugins"-Fehler
- ✅ Scanner-Whitelist ist additiv — bestehende Einträge bleiben
