# Session Log — v0.0.20.460

**Datum:** 2026-03-14
**Kollege:** Claude Opus 4.6
**Task:** VST3 Multi-Plugin Name Cache (macOS Audio Fix — KEIN TON GEFIXT)

## Problem

Zebra2 Editor öffnete sich (Screenshot: Zebra2 UI mit "HS Basedrop" Preset sichtbar),
aber es kam KEIN TON. Root Cause: macOS "must be reloaded on the main thread" Fehler.

### Warum kein Ton?

MIDI-Noten kamen an, aber der Audio-Prozessor (`Vst3InstrumentEngine`) konnte nie geladen
werden. Der Editor ist ein separater UI-Prozess — er zeigt die Oberfläche, aber ohne
funktionierenden Audio-Engine dahinter gibt es keinen Sound.

### Root Cause: Zu viele native Plugin-Instanziierungen

JEDER Aufruf von `_load_pedalboard_plugin(Zebra2.vst3, "")` (ohne plugin_name) tat folgendes:
1. `pedalboard.load_plugin("Zebra2.vst3")` → Pedalboard instantiiert intern ALLE 4 Sub-Plugins
   (Zebra2, Zebralette, ZRev, Zebrify) um sie aufzulisten → FEHLER "contains 4 plugins"
2. `parse_multi_plugin_names()` → extrahiert die 4 Namen
3. `pedalboard.load_plugin("Zebra2.vst3", plugin_name="Zebra2")` → Nochmal alle 4 + lädt Zebra2

Pro rebuild_fx_maps() Zyklus wurde das 4x aufgerufen (FX Chain + is_vst_instrument + 
Instrument Engine + describe_controls) = ~20 native Plugin-Instanziierungen.

macOS Cocoa/AppKit hat eine Thread-Affinität für bestimmte Operationen. Nach ~10-15
Instanziierungen werden Cocoa-Ressourcen erschöpft → "must be reloaded on the main thread".

## Lösung: Module-Level Name Cache

```python
_auto_resolved_names: Dict[str, str] = {}    # "Zebra2.vst3" → "Zebra2"
_known_multi_bundles: Dict[str, List[str]] = {}  # "Zebra2.vst3" → ["Zebra2", "Zebralette", "ZRev", "Zebrify"]
```

### Vorher (v458):
- Jeder Load-Aufruf: 5 native Instanziierungen (4 Probe + 1 Load)
- Pro Rebuild-Zyklus: ~20 native Instanziierungen
- Nach 2-3 Zyklen: macOS Cocoa erschöpft → "main thread" Fehler → kein Audio

### Nachher (v460):
- Erster Load: 5 native Instanziierungen (unvermeidbar, wird gecacht)
- Alle weiteren Loads: 1 native Instanziierung (direkt `load_plugin(path, "Zebra2")`)
- Pro Rebuild-Zyklus: ~4 native Instanziierungen
- Cocoa-Ressourcen werden nicht erschöpft → Audio funktioniert

## Geänderte Dateien

- `pydaw/audio/vst3_host.py` — _auto_resolved_names, _known_multi_bundles, Cache-Logik in
  _load_pedalboard_plugin() und probe_multi_plugin_names()
- `pydaw/audio/audio_engine.py` — (v459: Retry-Limiter bleibt als Safety Net)
- `pydaw/version.py` — 0.0.20.459 → 0.0.20.460

## Nichts kaputt gemacht

- ✅ Single-Plugin-Bundles (Presswerk, Surge XT etc.) werden nicht beeinflusst (kein Cache-Eintrag)
- ✅ Bereits korrekt konfigurierte Multi-Plugin-Referenzen (mit __ext_plugin_name) umgehen den Cache
- ✅ Cache ist nur ein Lookup-Beschleuniger — wenn gecachter Name fehlschlägt, wird der Fehler durchgereicht
- ✅ probe_multi_plugin_names() gibt bei bekannten Bundles sofort die gecachte Liste zurück
