# Carla Plugin Host Integration — Architektur-Plan

**Datum:** 2026-03-14
**Status:** Phase 0 (Planung + Installation)
**Ziel:** Carla als alternatives Plugin-Host-Backend neben pedalboard

## Warum Carla?

pedalboard (Spotify) hat auf macOS eine fundamentale Einschränkung:
- `show_editor()` muss auf dem Main Thread laufen (Cocoa-Pflicht)
- `show_editor()` blockiert bis das Fenster geschlossen wird
- → Entweder GUI tot ODER kein Plugin-Editor mit Live-Audio

Carla löst das weil:
- Plugins laufen in **eigenen Prozessen** (Plugin-Bridges)
- Editor-Fenster werden von Carla verwaltet (nicht von unserer Qt-App)
- Audio-Routing über JACK (PipeWire-JACK auf Linux, JACK auf macOS)
- Unterstützt LADSPA, DSSI, LV2, VST2, VST3, AU
- Cross-Platform: Linux, macOS, Windows
- Python-Steuerung über C-API (`libcarla_standalone2.dylib` / `.so`)

## Architektur-Übersicht

```
┌─────────────────────────────┐
│        Py_DAW (PyQt6)       │
│  ┌───────────────────────┐  │
│  │   CarlaHostBridge     │  │  ← Neues Modul: pydaw/audio/carla_host.py
│  │   (ctypes → libcarla) │  │
│  └───────┬───────────────┘  │
│          │ C-API calls      │
└──────────┼──────────────────┘
           │
    ┌──────▼──────────────────┐
    │   libcarla_standalone2  │  ← Carla shared library
    │   (eigener Audio-Thread)│
    │                         │
    │  ┌─────┐ ┌─────┐       │
    │  │VST3 │ │ LV2 │ ...   │  ← Plugins in Carla-Prozessen
    │  │Presswerk│ │   │      │
    │  └──┬──┘ └──┬──┘       │
    │     │       │           │
    │  ┌──▼───────▼──┐       │
    │  │ JACK Audio   │       │  ← Audio-Routing
    │  └──────────────┘       │
    └─────────────────────────┘
           │
    ┌──────▼──────────────────┐
    │  JACK / PipeWire-JACK   │  ← Audio-Server
    │  (CoreAudio auf macOS)  │
    └─────────────────────────┘
```

## Phasen

### Phase 0: Installation + Erkennung (DIESE SESSION)
- [ ] `brew install carla` in install-macos.py
- [ ] `apt install carla` in install.py (Linux)
- [ ] Erkennung ob Carla installiert ist (libcarla Pfad finden)
- [ ] requirements-macos.txt + requirements.txt aktualisieren
- [ ] `pydaw/audio/carla_host.py` — Minimales Modul mit `is_available()`

### Phase 1: Proof of Concept (nächste Session)
- [ ] `CarlaHostBridge` Klasse — ctypes Bindings für Carla C-API
- [ ] Engine initialisieren (JACK oder CoreAudio Backend)
- [ ] Ein Plugin laden (z.B. Presswerk)
- [ ] Plugin-Editor öffnen (non-blocking!)
- [ ] Parameter lesen/schreiben

### Phase 2: Audio-Integration
- [ ] JACK-Routing zwischen Py_DAW Audio-Engine und Carla
- [ ] Carla-Plugins in die FX-Chain einbinden
- [ ] MIDI-Events an Carla-Plugins weiterleiten
- [ ] VU-Meter-Daten aus Carla auslesen

### Phase 3: UI-Integration
- [ ] Plugin-Browser zeigt auch Carla-Plugins
- [ ] Device-Panel: Carla-Plugin-Widget mit Editor-Button
- [ ] Parameter-Sync (Carla ↔ Py_DAW RTParamStore)
- [ ] Preset-Management über Carla

### Phase 4: Migration + Fallback
- [ ] Umschalter in Settings: "Plugin Backend: pedalboard / Carla"
- [ ] Automatischer Fallback: Carla wenn verfügbar, sonst pedalboard
- [ ] Projekt-Kompatibilität (gleiche Plugin-Referenzen)
- [ ] pedalboard bleibt als Fallback für Offline-Rendering

## Carla C-API — Wichtigste Funktionen

```c
// Engine
CarlaHostHandle carla_standalone_host_init(void);
bool carla_engine_init(handle, "JACK", "Py_DAW");
bool carla_engine_close(handle);
void carla_engine_idle(handle);  // muss regelmäßig aufgerufen werden!

// Plugins
bool carla_add_plugin(handle, btype, ptype, filename, name, label, ...);
bool carla_remove_plugin(handle, pluginId);
uint32_t carla_get_current_plugin_count(handle);

// Plugin Info
const CarlaPluginInfo* carla_get_plugin_info(handle, pluginId);
uint32_t carla_get_parameter_count(handle, pluginId);
float carla_get_current_parameter_value(handle, pluginId, parameterId);
void carla_set_parameter_value(handle, pluginId, parameterId, value);

// Plugin UI
void carla_show_custom_ui(handle, pluginId, true/false);  // NON-BLOCKING!

// Audio Peaks (für VU-Meter!)
float[4] carla_get_peak_values(handle, pluginId);  // input L/R + output L/R

// State
char* carla_get_chunk_data(handle, pluginId);
void carla_set_chunk_data(handle, pluginId, chunkData);
```

## Wichtig: `carla_show_custom_ui()` ist NON-BLOCKING!

Das ist der entscheidende Unterschied zu pedalboard's `show_editor()`:
- Carla öffnet das Plugin-Fenster in einem eigenen Prozess
- Der Aufruf kehrt sofort zurück
- Die Qt Event-Loop läuft weiter
- VU-Meter funktionieren weil Audio durchs Plugin fließt

## Installation

### macOS
```bash
brew install carla
# Installiert: /opt/homebrew/lib/carla/libcarla_standalone2.dylib
# Plus: /opt/homebrew/bin/carla (GUI, optional)
```

### Linux
```bash
sudo apt install carla  # Ubuntu/Debian
# Installiert: /usr/lib/carla/libcarla_standalone2.so
```

## Risiken + Mitigierung

| Risiko | Mitigierung |
|--------|-------------|
| Carla nicht installiert | Fallback auf pedalboard (bestehendes System) |
| JACK nicht aktiv | Carla kann auch ohne JACK (Rack-Modus) |
| API-Änderungen | Carla ist ABI-stabil seit v2.0 |
| Latenz durch JACK | Minimal (~5ms), akzeptabel für Echtzeit |
| macOS Homebrew-Pfade | Automatische Erkennung `/opt/homebrew/lib/carla/` |

## Nichts kaputt machen!

- pedalboard bleibt als Default-Backend
- Carla ist optional und wird nur aktiviert wenn installiert
- Alle bestehenden Projekte funktionieren weiter
- Kein bestehendes Verhalten wird geändert
