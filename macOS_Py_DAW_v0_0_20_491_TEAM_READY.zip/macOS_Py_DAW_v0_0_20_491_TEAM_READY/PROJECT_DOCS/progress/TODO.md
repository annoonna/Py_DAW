## v0.0.20.491 — FX Widget Diagnostik + macOS VST3 Param-Loader Fix

- [x] DONE (Claude Opus 4.6, 2026-03-15): **Silent except→Error-Logging** — `make_audio_fx_widget()` hatte `try/except Exception: pass` der ALLE Fehler bei internen FX-Widgets verschluckte (Import + Constructor). Jetzt: Lazy Import-Cache (`_ensure_chrono_fx_imports()`), separate Constructor-Catches, volle Tracebacks auf stderr `[FX-WIDGETS]`.
- [x] DONE (Claude Opus 4.6, 2026-03-15): **Error-Widget statt Placeholder** — Statt `"(no UI yet)"` zeigt `_make_error_widget()` den tatsächlichen Fehler (orange/rot) im Device-Panel. Import-Fehler und Constructor-Fehler getrennt sichtbar.
- [x] DONE (Claude Opus 4.6, 2026-03-15): **macOS VST3 Param-Loader Main-Thread-Direct** — `_start_async_param_loader()` prüft `sys.platform == "darwin"` und überspringt den Background-QThread komplett. Stattdessen: direkter Main-Thread-Load via `QTimer.singleShot(0, _load_params_on_main_thread)`. Verhindert "must be reloaded on main thread" Fehler bei VST3 Parameter-Discovery auf macOS.
- [x] DONE (Claude Opus 4.6, 2026-03-15): **Stale .pyc Cleanup** — Alle `__pycache__` + `.pyc` aus ZIP entfernt.
- [ ] AVAILABLE: **Zebra2 Multi-Bundle Load-Reduktion** — Zebra2.vst3 erzeugt 12+ native macOS Plugin-Loads pro Startup (4 Sub-Plugins × 3 Zyklen: is_vst_instrument + Engine + Retry). Name-Cache hilft ab 2. Load, aber der 1. Load probt immer alle Sub-Plugins. Lösung: `_plugin_instance_cache` auch für Instrument-Engine nutzen, oder Multi-Bundle-Probing auf macOS beschränken.

## v0.0.20.481 — Carla Phase 2: Peak Metering + VU Display + Editor Fix

- [x] DONE (Claude Opus 4.6, 2026-03-14): **_toggle_native_editor TypeError Fix** — Methode akzeptiert jetzt optionalen `_checked: bool` Parameter vom `QPushButton.clicked` Signal. Vorher: `TypeError: takes 1 positional argument but 2 were given` → Editor-Button funktionierte nicht.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **Pedalboard-seitige Peak-Metering (Vst3Fx)** — `peak_l` / `peak_r` Float-Attribute werden nach jedem `_write_process_output()` aus dem numpy-Output-Buffer berechnet (`np.max(np.abs())`). L/R separat bei Stereo, mono dupliziert. Kein zusätzlicher Audio-Buffer, kein Performance-Impact.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **Pedalboard-seitige Peak-Metering (Vst3InstrumentEngine)** — Selbe `peak_l`/`peak_r` Logik in `pull()` nach Audio-Rendering. Instrument-Engines messen jetzt ebenfalls Peaks.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **_MiniVuMeter Widget** — 18×22px Stereo-VU-Meter-Widget mit grün→gelb→rot Farbverlauf. Exponentieller Decay (~300ms). `paintEvent()` mit QPainter, keine externen Dependencies.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **VU im Vst3AudioFxWidget Header** — Mini-VU-Meter neben Pin/Shade-Buttons. ~15Hz Update-Timer (`_update_vu`) liest `peak_l`/`peak_r` vom live Vst3Fx-Objekt. Decay auf 0 wenn kein FX-Objekt vorhanden.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **Carla→pedalboard State-Sync (v480)** — Bidirektionaler State-Sync mit 250ms Timer. Beim Öffnen: pedalboard→Carla push (`set_chunk`). Periodisch: Carla→pedalboard sync (`get_chunk` + hash-compare). Preset-Wechsel in Carla-GUI → Audio ändert sich sofort.
- [ ] AVAILABLE: **Carla Buffer-Mismatch** — `numSamples != bufferSize` Assertion-Spam von Carla's CoreAudio-Engine. Harmlos (Carla verarbeitet kein Audio für uns), aber spammt stderr. Lösung: Carla mit `JACK`-Driver statt CoreAudio (wenn verfügbar), oder stderr-Filter.
- [ ] AVAILABLE: **Carla Phase 2b: JACK Audio-Routing** — Echtes Audio durch Carla-Plugins routen (statt nur GUI). Erfordert JACK-Verbindung zwischen sounddevice und Carla.
- [ ] AVAILABLE: **Instrument VU-Widget** — Selbes _MiniVuMeter auch für Instrument-Tracks (Vst3InstrumentEngine hat jetzt peak_l/peak_r).
- [ ] AVAILABLE: **VU Peak-Hold** — Kurzes Peak-Hold (1-2s) mit dünner Linie am Maximum, wie professionelle DAW-Meter.

## v0.0.20.478 — macOS Main-Thread Fix + Plugin Instance Cache

- [x] DONE (Claude Opus 4.6, 2026-03-14): **macOS Main-Thread Fix** — `defer_load` ist jetzt auf macOS deaktiviert (`sys.platform == "darwin"`). macOS Cocoa-basierte VST3 Plugins (Zebra2, Presswerk etc.) MÜSSEN auf dem Main-Thread geladen werden. Background-Loading nur auf Linux. Fehlermeldung "must be reloaded on the main thread" behoben.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **Plugin Instance Cache** — `is_vst_instrument()` speichert jetzt die geladene Plugin-Instanz in `_plugin_instance_cache` statt sie zu zerstören. `Vst3Fx._load()` und `Vst3InstrumentEngine._load()` prüfen den Cache zuerst — spart einen kompletten `load_plugin()` Roundtrip pro Plugin (bei Zebra2.vst3 = 4 Sub-Plugin-Probes = ~5-10s gespart).
- [x] DONE (Claude Opus 4.6, 2026-03-14): **Logging** — `is_vst_instrument()` loggt Ergebnis + Cache-Hit. `_load()` loggt "Reused cached plugin instance" wenn Cache genutzt.

## v0.0.20.477 — FX Instance Reuse Fix + Deferred Background Loading

- [x] DONE (Claude Opus 4.6, 2026-03-14): **Chain Fingerprinting** — `build_track_fx_map()` vergleicht jetzt den JSON-Fingerprint der `audio_fx_chain` Spec. Unveränderte Chains werden komplett wiederverwendet (inkl. aller live VST-Plugin-Instanzen). Kein `load_plugin()` mehr bei jedem Play/Stop.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **Instrument Engine Pfad-Fix** — `_create_vst_instrument_engines()` löst `vst_ref` jetzt korrekt durch `resolve_plugin_reference()` auf bevor er mit `old_eng.path` verglichen wird. Multi-Plugin-Bundles (u-he Zebra2, Presswerk etc.) werden jetzt korrekt wiedererkannt. Vorher: `"/path/Zebra2.vst3::pydaw_plugin::Zebra2" != "/path/Zebra2.vst3"` → IMMER Neuladen.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **VST3/VST2 FX Device Pfad-Fix** — Selbe robuste Pfad-Auflösung + Basename-Fallback in `_compile_devices()` für Audio-FX-Plugins.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **Reuse Diagnostics** — Logging auf stderr: `[FX-MAP]` zeigt chains reused/new, `[VST3-FX]`/`[VST2-FX]`/`[VST3-INST]` zeigt pro-Device Reuse/Failure.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **Restructured Control Flow** — `_did_reuse` Flag statt if/else verhindert dass bei fehlgeschlagenem Path-Match gar keine Engine erstellt wird.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **Deferred Background Loading (FX)** — Neue VST3/VST2 Audio-FX Devices werden sofort mit `defer_load=True` erstellt (process_inplace ist safe no-op). Laden passiert in einem Hintergrund-Thread (`pydaw-vst-bgload`). UI friert nicht mehr ein.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **Deferred Background Loading (Instruments)** — VST Instrument-Engines werden sofort registriert (SamplerRegistry + Pull-Source, liefern Stille). Laden in Hintergrund-Thread (`pydaw-vstinst-bgload`). Plugins produzieren Audio sobald `_ok=True`.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **Fast Param Setup nach State-Restore** — Wenn `__ext_state_b64` erfolgreich restored wurde, werden 0 C++-Bridge-Calls (`getattr`/`setattr`) gemacht. Vorher: 2145 `getattr()` Calls für Presswerk, 777 für Zebra2 (je ~0.5-2ms = 2-8s). Jetzt: nur Python-Dict-Lookups (<1ms).
- [x] DONE (Claude Opus 4.6, 2026-03-14): **Timing-Diagnostik** — `[VST3] loaded: ... | timing: load=X.Xs state=X.Xs params=X.Xs total=X.Xs` für Performance-Analyse.

## v0.0.20.470 — Carla Phase 1: ctypes Bridge (CarlaBridge)

- [x] DONE (Claude Opus 4.6, 2026-03-14): **carla_bridge.py** — 772-Zeilen ctypes Bridge zu libcarla_standalone2. Vollständige Bindings für: Engine init/close/idle, Plugin add/remove (VST3/VST2/LV2/AU), show_custom_ui (NON-BLOCKING!), Parameter get/set, Audio Peaks (VU!), MIDI note_on/off, State chunk save/load, Transport play/pause/bpm. Engine Callback Handler.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **Self-Test** — `python3 -m pydaw.audio.carla_bridge /path/to/Presswerk.vst3 Presswerk` zeigt Version, Treiber, lädt Plugin, öffnet Editor (non-blocking), liest 10s Peaks, schließt.

## v0.0.20.469 — Carla Integration Phase 0 + Saubere v463-Basis

- [x] DONE (Claude Opus 4.6, 2026-03-14): **carla_host.py** — Neues Modul `pydaw/audio/carla_host.py` mit `is_available()`, `get_library_path()`, `availability_hint()`, `get_version()`. Sucht `libcarla_standalone2` auf macOS (Homebrew) und Linux. Cached nach erstem Aufruf.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **install-macos.py** — `_install_carla()` Funktion hinzugefügt. Installiert via `brew install carla`. Optional, Py_DAW funktioniert auch ohne.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **requirements-macos.txt** — Carla-Dokumentation hinzugefügt.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **CARLA_INTEGRATION_PLAN.md** — Vollständiger 4-Phasen Architektur-Plan für die Carla-Integration.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **FX Instance Reuse** (aus v464) — Sauber auf v463-Basis. Minimale Änderung in fx_chain.py + audio_engine.py. Kein Debug-Output.
- [x] DONE (Claude Opus 4.6, 2026-03-14): **macOS Editor → Subprocess** — 3-Zeilen Guard in fx_device_widgets.py. macOS nutzt Subprocess, Linux nutzt in-process QThread.
- [ ] AVAILABLE: **Carla Phase 1** — ctypes Bridge zu libcarla_standalone2, Engine init, Plugin laden, Editor öffnen (non-blocking!).
- [ ] AVAILABLE: **Carla Phase 2** — JACK Audio-Routing, FX-Chain Integration, MIDI, VU-Meter.
- [ ] AVAILABLE: **Carla Phase 3** — UI-Integration (Plugin-Browser, Device-Panel, Parameter-Sync).
- [ ] AVAILABLE: **Carla Phase 4** — Settings-Umschalter (pedalboard/Carla), Fallback, Projekt-Kompatibilität.

## v0.0.20.463 — requirements-macos.txt lilv Fix

- [x] FIXED (Claude Opus 4.6, 2026-03-14): **lilv ist kein pip-Paket** — `lilv; platform_system=="Darwin"` aus requirements-macos.txt entfernt. lilv wird über `brew install lilv` installiert (war schon korrekt in install-macos.py). pip install -r requirements-macos.txt läuft jetzt fehlerfrei.

## v0.0.20.462 — VST3 Preset-Corruption Fix (alle Presets klangen gleich)

- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Kein Param-Roundtrip mehr bei Instrument-Load** — `Vst3InstrumentEngine._load()` schreibt KEINE normalisierten Float-Werte mehr ans Plugin zurück. Zebra2 hat 2378 Params — der Round-Trip durch `setattr(plugin, name, normalized_float)` korrumpierte interne Wavetables/Mod-Routing. Plugin behält jetzt seinen eigenen Preset-State.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Delta-Cache Pre-Population** — `_last_param_vals` wird in `_load()` mit den Init-Werten gefüllt. Erster Audio-Callback schreibt KEINE Params (alles "unchanged"). Nur User-Änderungen (Knob drehen, Automation) lösen Writes aus.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Vst3Fx: Nur gespeicherte Params schreiben** — `Vst3Fx._load()` schreibt nur noch Params die explizit in `_params_init` gespeichert waren (User hat sie mal geändert). Standard-Params werden nicht round-tripped.

## v0.0.20.461 — VST3 Audio Performance Fix (Buffer + Param Delta-Check)

- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Buffer-Size 8192→1024 (macOS)** — Platform-aware Buffer-Sizing: macOS 1024 (21ms), Linux 2048 (42ms). Vorher 8192 (170ms) → GUI-Freeze + gehackter Sound. Apple M4 mit CoreAudio braucht keine 8192er Puffer.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Param Delta-Check** — `_apply_rt_params()` in BEIDEN Klassen (Vst3Fx + Vst3InstrumentEngine) prüft jetzt ob sich ein Parameter seit dem letzten Callback geändert hat. Unveränderte Params werden übersprungen. Zebra2 hat 2378 Params → vorher 2378 C++/Python Bridge-Calls pro Callback, jetzt ~0-5. Das war die Hauptursache für gehackten Sound.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Arrangement Playback Buffer** — Auch `start_arrangement_playback()` nutzt jetzt platform-aware Buffer statt hardcoded 8192.

## v0.0.20.460 — VST3 Multi-Plugin Name Cache (macOS Audio Fix)

- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Auto-Resolved Name Cache** — `_auto_resolved_names` Dict in `vst3_host.py` cached den auto-aufgelösten Sub-Plugin-Namen (z.B. "Zebra2" für Zebra2.vst3). Erste Probe: 5 native Plugin-Instanzen. Alle weiteren Loads: 1 Instanz. Reduziert native Loads pro Rebuild-Zyklus von ~20 auf ~4.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Multi-Bundle Cache** — `_known_multi_bundles` Dict cached die vollständige Sub-Plugin-Liste. `probe_multi_plugin_names()` gibt bei bekannten Bundles sofort die gecachte Liste zurück statt nochmal alle Sub-Plugins zu instanziieren.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Root Cause: macOS "main thread" Fehler** — Der Fehler entstand weil JEDER Load-Versuch für Zebra2.vst3 erst alle 4 Sub-Plugins instanziiert hat (Zebra2+Zebralette+ZRev+Zebrify), scheiterte, dann den richtigen Namen fand und nochmal lud. ~20 native Instanziierungen pro Rebuild-Zyklus erschöpften macOS Cocoa-Ressourcen → "must be reloaded on the main thread". Mit dem Cache: 1 Probe beim ersten Mal, danach nur noch 1 `load_plugin()` Aufruf.

## v0.0.20.459 — VST3 Deferred Retry Loop Breaker (macOS "main thread" Fix)

- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Retry Count Limiter** — `_vst_inst_retry_counts` Dict in AudioEngine verfolgt fehlgeschlagene Load-Versuche pro Track+Plugin. Nach 3 Fehlversuchen wird aufgegeben statt endlos weiterzuversuchen. Behebt die Endlosschleife bei Zebra2.vst3 "must be reloaded on the main thread" auf macOS.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Success Counter Reset** — Bei erfolgreichem Engine-Load (initial oder deferred) wird der Retry-Counter gelöscht, damit ein späterer Reload wieder möglich ist.

## v0.0.20.458 — Multi-Plugin VST3 Bundle Auto-Recovery (u-he Zebra2 Fix)

- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Multi-Plugin Auto-Recovery** — `_load_pedalboard_plugin()` in `vst3_host.py` erkennt jetzt automatisch Multi-Plugin-Bundles (z.B. Zebra2.vst3 mit Zebra2/Zebralette/ZRev/Zebrify). Wenn `plugin_name` leer ist und pedalboard den "contains N plugins"-Fehler wirft, wird der passendste Sub-Plugin-Name per Bundle-Stem-Matching ausgewählt und automatisch geladen.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Vst3Fx Name Persistence** — Nach Auto-Recovery wird der aufgelöste Plugin-Name in `self.plugin_name` gespeichert, damit er im Projekt persistiert.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Vst3InstrumentEngine Instrument-Aware Retry** — Wenn der automatisch gewählte Sub-Plugin kein Instrument ist, werden alle anderen Sub-Plugins im Bundle durchprobiert bis ein Instrument gefunden wird.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **vst_gui_process.py Auto-Recovery** — Standalone-Editor-Subprocess hat jetzt dieselbe Multi-Plugin-Auto-Recovery-Logik.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Scanner Whitelist erweitert** — `_should_try_multi_vst_probe()` enthält jetzt alle bekannten u-he Bundles (Zebra2, Diva, Hive, Repro, Bazille, ACE, etc.) für korrekte Sub-Plugin-Auflistung im Browser.
- [ ] AVAILABLE: **Scanner: Generischer Multi-Plugin-Probe** — Statt Whitelist könnte ein timeout-geschützter Probe für alle VST3-Bundles laufen (aktuell nur für bekannte Bundles).

## v0.0.20.457 — macOS Cross-Platform Port (ECHTE Code-Änderungen)

- [x] FIXED (Claude Opus 4.6, 2026-03-14): **main.py Platform Startup** — macOS: Cocoa QPA, Linux: Wayland→xcb wie bisher. `sys.platform` Guard.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Metal GPU Backend** — `gfx_backend.py` erkennt macOS und setzt `QSG_RHI_BACKEND=metal`. Vulkan auf Linux unverändert.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **VST2 macOS Bundle Support** — `_resolve_vst2_binary()` löst `.vst/Contents/MacOS/Plugin` auf. `is_vst2_path()` erkennt .vst Bundles, .so, .dll, .dylib.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Audio Engine VST2 Cross-Platform** — `.endswith(".so")` → `is_vst2_path()` an beiden Stellen (Arrangement-Build + Deferred-Retry).
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **LADSPA .dylib Support** — Regex `_(\d+)\.so$` → `_(\d+)\.(?:so|dylib)$`. ctypes.CDLL Docstring erweitert.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **LV2 macOS Homebrew lilv Import** — Fallback sucht `/opt/homebrew/lib/python3*/site-packages` (Apple Silicon) + Intel-Pfade. Platform-aware Fehlermeldungen.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **X11 Graceful No-Op** — `_IS_LINUX` Guard in `x11_window_ctl.py`. Alle Funktionen geben safe Defaults auf macOS zurück.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **VST Editor Pin macOS** — `_toggle_pin()` nutzt Qt `WindowStaysOnTopHint` auf macOS, X11 EWMH auf Linux. Betrifft `_Vst2EditorDialog` + `_VstEditorContainer`.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **SoundFont Cross-Platform** — `_find_default_sf2()` sucht Homebrew + Linux-Pfade. FluidSynth nutzt `coreaudio`/`coremidi` auf macOS.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Plugin Scanner Homebrew LV2** — `default_paths("darwin")` enthält `/opt/homebrew/lib/lv2` + `/usr/local/lib/lv2`.
- [ ] AVAILABLE: **VST2 Editor macOS Cocoa (NSView)** — winId() auf macOS liefert NSView*, VST2 effEditOpen sollte damit funktionieren. Noch ungetestet mit realen macOS VST2 Plugins.
- [ ] AVAILABLE: **Audio Unit (AU) Plugin Hosting** — macOS-natives Plugin-Format. Pfade: `~/Library/Audio/Plug-Ins/Components/`. Braucht eigenen Host (pyaudiounit o.ä.).
- [ ] AVAILABLE: **macOS CoreMIDI Integration** — rtmidi unterstützt CoreMIDI, aber MIDI-Geräteerkennung in UI sollte getestet werden.

## v0.0.20.451 — Klangfarben-Noten + Notennamen + Schlüssel-Dialog Fix

- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Pitch-Class Klangfarben** — Jede Note wird nach Tonhöhe farblich dargestellt: C=Rot, D=Orange, E=Gelb-Grün, F=Grün, G=Türkis, A=Indigo, H=Pink. Chromatische Farbrad-Zuordnung. Velocity moduliert Helligkeit dezent.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Notennamen im Notenkopf** — Jede Note zeigt ihren Namen (C, D, E, F, G, A, B, H) zentriert im Notenkopf. 6pt fett, hoher Kontrast. Deutsche Notation (H statt B).
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Dezenter Glow-Effekt** — Alle Noten haben sanften Glow in ihrer Klangfarbe. Selektierte Noten stärkeren Glow.
- [x] FIXED (Claude Opus 4.6, 2026-03-14): **Schlüssel-Dialog: QComboBox** — Signal-Problem endgültig gelöst durch QComboBox als Hauptnavigation mit Dropdown aller 12 Schlüssel.

## v0.0.20.449 — Notation Editor: Record Button (MIDI Live-Aufnahme)

- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Record Button** — Neuer Toggle-Button "Record" in der Notation-Toolbar. Rot hinterlegt wenn aktiv (`#cc3333`). Ausführlicher Tooltip erklärt die Funktion. Gleicher MIDI-Record-Pfad wie im Piano Roll.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **record_toggled Signal** — `NotationWidget.record_toggled(bool)` Signal wird in `main_window.py` an `MidiManager.set_record_enabled` angeschlossen. Beide Editoren (Piano Roll + Notation) teilen den selben Record-Pfad.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Status-Feedback** — "Notation Record: AN/AUS" wird in der Statusleiste angezeigt.

## v0.0.20.448 — Notenschlüssel-System (Clef Dialog + Rendering + Klick-Interaktion)

- [x] FIXED (Claude Opus 4.6, 2026-03-13): **ClefType Enum + ClefInfo Datenmodell** — Neues Modul `pydaw/ui/notation/clef_dialog.py` mit 12 Schlüssel-Typen: Violin (G), Bass (F), Alt (C3), Tenor (C4), Sopran (C1), Mezzosopran (C2), Bariton (C5/F3), plus 8va/8vb Varianten für Violin und Bass. Jeder Typ hat Unicode-Symbol, Referenz-Note (MIDI), Referenz-Linie, Oktav-Shift und ausführlichen deutschen Tooltip.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **ClefDialog** — Visueller Schlüssel-Picker mit ◀/▶ Pfeil-Buttons, Live-Vorschau (Staff + Schlüssel + Referenz-Note), Name + Info-Text, Transpositions-Option ("Tonhöhen beibehalten" / "In richtige Oktave transponieren"). Exakt wie im professionellen Vorbild.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **StaffRenderer.render_clef()** — Zeichnet Schlüssel-Symbol (Unicode) an der korrekten Referenz-Linie. Oktavierungs-Anzeige (8va/8vb) wird automatisch über/unter dem Schlüssel gerendert. Gibt Bounding-Rect zurück für Klick-Detection.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **StaffRenderer.render_time_signature()** — Zeichnet Taktangabe (z.B. 4/4) auf dem Staff, fett, zentriert.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **_StaffBackgroundItem erweitert** — Rendert jetzt Schlüssel + Taktangabe automatisch. Speichert clef_rect für Klick-Erkennung.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Klick auf Schlüssel → Dialog** — `NotationView.mousePressEvent()` prüft ob der Klick im Schlüssel-Bereich liegt und öffnet dann `ClefDialog`. Schlüssel-Wechsel → sofortiges Refresh.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **𝄞 Schlüssel-Button in Toolbar** — Mit vollständigem Tooltip aller 12 Schlüssel-Typen inkl. Referenz-Noten und Linien. "Tipp: Auch direkt auf den Schlüssel klicken!"
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Clef-aware Pitch Mapping** — `_pitch_to_staff_line()` nutzt jetzt `pitch_to_staff_line(pitch, clef_type)` aus clef_dialog.py. Diatonische Distanz relativ zur Schlüssel-Referenz. Fallback auf Treble wenn import fehlschlägt.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **NotationLayout erweitert** — Neue Felder `clef_type`, `time_sig_num`, `time_sig_denom`.
- [ ] AVAILABLE: **Schlüssel-Persistenz** — Gewählten Schlüssel im Projekt-Modell speichern (aktuell nur Laufzeit).
- [ ] AVAILABLE: **Transposition bei Schlüsselwechsel** — Noten tatsächlich transponieren (Dialog-Option ist UI-fertig, Logik folgt).
- [ ] AVAILABLE: **Schlüsselwechsel innerhalb eines Stücks** — Verschiedene Schlüssel an verschiedenen Beat-Positionen.

## v0.0.20.447 — "Rosegarden" Branding entfernt

- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Alle "Rosegarden" Referenzen entfernt** — 0 Referenzen im aktiven Python-Code. Ersetzt durch "professionell", "Pro-Style", "ChronoScaleStudio". Betrifft: notation_view.py, notation_palette.py, main_window.py, README_TEAM.md, BRIEF_AN_KOLLEGEN.md, VISION.md, TODO.md.

## v0.0.20.446 — Professionelles Notations-Kontextmenü (umfassend)

- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Professionelles Rechtsklick-Menü** — Umfassendes strukturiertes Kontextmenü mit 12 Kategorien, >80 Einträgen, vollständig deutsch beschriftet mit ausführlichen Tooltips. Organisiert nach professionellem Notations-Editor Paletten-Layout.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Intelligenter Rechtsklick-Trigger** — Rechtsklick auf leeren Bereich = Kontextmenü öffnen. Rechtsklick auf Note = Erase (bestehendes Verhalten). Ctrl+Rechtsklick = immer Menü. Nichts kaputt gemacht.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **🎵 Notenwerte** — Ganze bis 64tel mit Unicode-Symbolen, Punktiert, Doppelt punktiert. Jeder mit ausführlicher Beschreibung.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **⏸ Pausen** — Ganze Pause bis 32tel-Pause, Eingabemodus Pausen (Y) als Toggle.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **♯♭ Vorzeichen** — Kreuz, Be, Auflöser + NEU: Doppelkreuz (𝄪), Doppel-Be (𝄫) mit Erklärung.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **🎶 Tuplets** — NEU: Triole (3:2), Duole (2:3), Quintole (5:4), Sextole (6:4), Septole (7:4) als notation_marks.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **🎻 Artikulation** — NEU: Staccato, Akzent, Tenuto, Marcato, Fermata, Staccatissimo, Portato, Downbow, Upbow, Pizzicato (LH), Flageolett. Alle mit ausführlicher Erklärung.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **🎼 Dynamik** — NEU: ppp bis fff (8 Stufen mit MIDI-Velocity-Mapping), sf/sfz/fp/fz, Crescendo/Decrescendo Hairpins.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **🎵 Ornamente** — Triller + NEU: Mordent, Pralltriller, Doppelschlag, Gruppetto, Schleifer, Vorschlag, Tremolo, Vibrato, Glissando.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **🎹 Spielanweisungen** — NEU: 8va/8vb/15ma, Pedal/Pedal-Auf, Una Corda/Tre Corde, Atemzeichen, Cäsur, Arco, Pizzicato, Con/Senza Sordino.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **📐 Struktur/Navigation** — NEU: Segno, Coda, D.C., D.S., D.S. al Coda, D.C. al Fine, Fine, Wiederholungszeichen (Anfang/Ende), Volta 1/2.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **⌒∿ Bögen** — Haltebogen, Bindebogen (bestehend), NEU: Phrasierungsbogen.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **ℹ Über-Dialog** — Kompakte Kurzreferenz aller verfügbaren Symbole.
- [ ] AVAILABLE: **Rendering aller neuen Mark-Typen** — Aktuell werden die neuen Marks als notation_marks gespeichert (Datenmodell OK), aber noch nicht alle visuell gerendert. Nächster Schritt: `_render_notation_marks()` erweitern.
- [ ] AVAILABLE: **Professionelles Seitenpalette** — Vertikale Symbolpalette am rechten Rand als vertikale Symbolpalette zusätzlich zum Kontextmenü.

## v0.0.20.445 — Notation Editor: Playhead + Zeitlineal + Zoom Buttons (Arranger-Style)

- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Playhead (rote Linie)** — `NotationView.drawForeground()` zeichnet eine rote 2px Linie über die gesamte Szene-Höhe. Effizientes Stripe-Update wie im Arranger (nur alte/neue Position invalidiert, kein Full-Repaint).
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Playhead-Dreieck** — Kleines rotes Dreieck-Marker am oberen Lineal-Rand zeigt exakte Playhead-Position (wie Arranger/Bitwig).
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Zeitlineal mit Bar-Labels** — Halbtransparenter Ruler-Streifen (24px) am oberen Szenen-Rand. Zeigt "Bar 1", "Bar 2" usw. mit Trennlinien pro Takt (4/4 MVP). Zeichnet sich nur für sichtbare Bars (Performance).
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Zoom +/− Buttons** — Toolbar-Buttons "+" und "−" (28×28px) mit 1.25× Faktor, plus "⊙" Reset-Button und %-Label. Exakt wie im Arranger-Vorbild.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Zoom-Label** — Zeigt aktuelles Zoom-Level als Prozent an (z.B. "125%"), aktualisiert sich bei Button-Klick und Transport-Tick.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Transport → Notation Playhead Wiring** — `TransportService.playhead_changed` Signal wird in `NotationWidget._on_playhead_changed()` empfangen und an `NotationView.set_playhead_beat()` weitergeleitet.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Mouse-Lupe Zoom** — Ctrl+Mausrad zoomt X-Achse (bereits vorhanden, jetzt konsistent mit den Buttons). Ctrl+Shift+Wheel = Y-Zoom. Shift+Wheel = horizontaler Scroll.
- [ ] AVAILABLE: **Playhead Click-to-Seek** — Klick ins Lineal setzt Playhead (wie im Arranger).
- [ ] AVAILABLE: **Follow Playhead** — Automatischer Scroll wenn Playhead den sichtbaren Bereich verlässt.
- [ ] AVAILABLE: **Zeitlineal: Time-Sig Support** — Statt 4/4 fix die tatsächliche Taktart des Projekts verwenden.

## v0.0.20.444 — Detachable Panels + Bitwig-Style Multi-Monitor Layout System

- [x] FIXED (Claude Opus 4.6, 2026-03-13): **ScreenLayoutManager** — Neues Modul `pydaw/ui/screen_layout.py` mit vollständigem Multi-Monitor-Layout-System. `DetachablePanel` kapselt jedes Widget für Dock↔Float-Toggle. `ScreenLayoutManager` orchestriert alle Panels und wendet Layout-Presets an.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **8 Layout-Presets** — "Ein Bildschirm (Groß)", "Ein Bildschirm (Klein)", "Tablet", "Zwei Bildschirme (Studio)", "Zwei Bildschirme (Arranger/Mixer)", "Zwei Bildschirme (Hauptbildschirm/Detail)", "Zwei Bildschirme (Studio/Touch)", "Drei Bildschirme" — exakt wie im Bitwig-Style Screenshot-Menü.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Ansicht → Bildschirm-Layout Menü** — Neues Untermenü zeigt erkannte Bildschirme, alle Presets (deaktiviert wenn zu wenige Monitore), individuelles Panel-Abkoppeln, und "Alle andocken".
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **5 registrierte Panels** — Editor, Mixer, Device, Browser, Automation als DetachablePanel registriert. Jedes Panel kann einzeln abgekoppelt und frei auf dem Desktop platziert werden.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Persistenz** — Detach-Status und Fenster-Geometrie werden in SettingsStore gespeichert und beim nächsten Start wiederhergestellt. closeEvent speichert + dockt alles sauber an.
- [x] FIXED (Claude Opus 4.6, 2026-03-13): **Safety-First** — Alle Qt-Operationen in try/except. Re-Docking gibt Widgets immer an original Parent/Position zurück. Schließen eines Float-Fensters dockt automatisch an statt zu zerstören.
- [ ] AVAILABLE: **Keyboard Shortcuts für Layout-Presets** — z.B. Ctrl+Alt+1/2/3 für schnellen Layout-Wechsel.
- [ ] AVAILABLE: **Custom Layout speichern** — User-definierte Layouts als benannte Presets speichern.
- [ ] AVAILABLE: **Screen-Change Detection** — Automatische Layout-Anpassung wenn Monitor an-/abgesteckt wird (QScreen::screenAdded/Removed).
- [ ] AVAILABLE: **Arranger als DetachablePanel** — Aktuell bleibt der Arranger immer im Hauptfenster; könnte auch abkoppelbar sein.

## v0.0.20.441 — Auto-Thinning (Douglas-Peucker) + Lane Tools (Pointer/Pencil/Eraser)

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Douglas-Peucker Auto-Thinning** — `AutomationLane.thin(epsilon=0.015)` reduziert 500 raw CC-Punkte auf ~30-50 saubere Punkte bei 1.5% max Abweichung. Wird automatisch bei Transport-Stop, Touch-Timeout und Latch-Ende aufgerufen.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Lane-Werkzeuge: ↖ Pointer, ✏ Pencil, ⌫ Eraser** — Tool-Buttons im Lane-Header. Pointer = Standard (auswählen/verschieben). Pencil = Freihand-Zeichnen mit Auto-Thin bei Release. Eraser = Drag-Rechteck löscht alle Punkte darin.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Recorded Lane Tracking** — `_recorded_lane_pids` Set trackt welche Lanes beschrieben wurden. `thin_recorded_lanes()` thinnt nur diese bei Stop.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Visual Feedback** — Pencil: gelbe Preview-Linie während Zeichnen. Eraser: rotes gestricheltes Selektions-Rechteck.

## v0.0.20.439 — Follow Playhead (Bitwig-Style) + Loop Transport-Feld + Automation-Button entfernt

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **▶ Follow Button** — Neuer Toggle in der Toolbar. Arranger scrollt smooth mit dem Playhead. Wenn Playhead 80% des sichtbaren Bereichs erreicht, springt View so dass Playhead bei 20% steht (Bitwig-Stil).
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Loop Start/End Eingabefelder** — Numerische SpinBoxen (Bar-Einheit) + Loop-Checkbox direkt in der Toolbar. Bidirektional mit Transport + Arranger synchronisiert.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Toter Automation-Button entfernt** — Hatte keinen Click-Handler, war rein dekorativ. btn_auto ist jetzt ein Alias auf btn_follow für Backward-Compat.
- [ ] AVAILABLE: **Automation Thinning** — Reduktion der Breakpoint-Dichte nach Recording.

## v0.0.20.438 — Fix: Drum Machine Knobs + vollständige Analyse aller Plugins

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Pro Drum Machine Engine-Rewire** — Selbes disconnect-Problem wie Sampler. `kn_gain/pan/tune/cut/res` Engine-Connections werden nach `bind_automation` als Failsafe wieder angeschlossen.
- [x] VERIFIED (Claude Opus 4.6, 2026-03-12): **Vollständige Codebase-Analyse** — Nur Sampler + Drum Machine hatten `valueChanged.disconnect()`. AETERNA, VST2, VST3, LV2, LADSPA, DSSI, Bach Orgel haben das Problem NICHT.

## v0.0.20.437 — Fix: Pro Audio Sampler Knobs wieder funktionsfähig

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Direkte Engine-Connections als Failsafe** — `_setup_automation()` trennte die `valueChanged→engine` Verbindungen und ersetzte sie durch die AutomationManager-Kette. Wenn die Signal-Kette nicht durchkam (race condition, None-Param, signal coalescing), waren die Knobs tot. Fix: Engine-Connections werden nach `bind_automation` zusätzlich wieder angeschlossen.

## v0.0.20.436 — Performance Fix: Automation Recording Audio-Stutter beseitigt

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **`sort_points()` während Recording entfernt** — Beats sind monoton steigend während Playback, append ist already in-order. Sort passiert erst bei Project-Save. War O(n log n) pro CC-Message → jetzt O(1).
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **`lane_data_changed` throttled auf 8 Hz** — Statt emit bei jedem CC (30-120/s → 30-120 Repaints/s) jetzt max 8 Repaints/s über dirty-set + Timer. Vorher blockierte der GUI-Thread den Audio-Callback.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Legacy-Store-Write während Recording entfernt** — `project.automation_lanes` dict wurde auf jedem CC kopiert+sortiert. Deferred to save.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Selbe Fixes in `MidiMappingService._write_automation_point()`** — Beide Recording-Pfade sind jetzt O(1) pro CC.
- [ ] AVAILABLE: **Automation Thinning** — Reduktion der Breakpoint-Dichte nach Recording.

## v0.0.20.435 — Fix: Automation Playback dB→Linear RT-Store Overwrite Bug

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **`tick()` _mirror_to_rt_store überschrieb Gain-Werte** — `_mirror_to_rt_store()` schrieb den rohen dB-Wert (z.B. -18) in den RT-Store, aber der Audio-Thread erwartet LINEAR (z.B. 0.126). Die Widget-Signal-Kette konvertierte korrekt (dB→linear), wurde aber danach von `_mirror_to_rt_store` überschrieben. Fix: `if not param._listeners:` → Mirror nur für Params ohne aktive Widget-Listener.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **`clear_automation_values()` gleicher Guard** — Selbe Logik: keine RT-Mirror wenn Widget-Listener existieren.
- [ ] AVAILABLE: **Automation Thinning** — Reduktion der Breakpoint-Dichte nach Recording.

## v0.0.20.434 — Fix: CC→Automation Recording für ALLE Plugin-Typen (afx:/afxchain: Support)

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **`_write_cc_automation()` akzeptiert jetzt afx: und afxchain: Prefixe** — Vorher wurde nur `trk:` akzeptiert, wodurch Gain, LV2, LADSPA, DSSI, VST2, VST3 Parameter nie aufgezeichnet wurden. Jetzt: `prefix in ("trk", "afx", "afxchain")` → track_id immer an Position [1].
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Generic CC Re-Registration in `_install_automation_menu()`** — Wenn DevicePanel Widgets rebuildet (project_updated), gehen MIDI Learn Mappings verloren. Jetzt: neue Widgets re-registrieren sich aus `_persistent_cc_map` bei Erstellung.
- [ ] AVAILABLE: **Automation Thinning** — Reduktion der Breakpoint-Dichte nach Recording (Cubase-Style).
- [ ] AVAILABLE: **Global Automation Arm** — Ein globaler "Arm"-Button in der Toolbar + per-Track Arm/Disarm.

## v0.0.20.433 — CC→Automation Recording für MIDI Learn Fast Path + REC Button

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **MIDI Learn Fast Path schreibt jetzt Automation** — `AutomationManager.handle_midi_message()` ruft nach dem Widget-Dispatch `_write_cc_automation()` auf. Prüft `widget._pydaw_param_id` oder `widget._parameter_id`, liest `track.automation_mode`, schreibt BreakPoints bei write/touch/latch.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **`_write_cc_automation()` Methode** — Neue Methode in AutomationManager: schreibt in BEIDE Stores (AutomationManager._lanes + legacy project.automation_lanes). Emittiert `lane_data_changed` für Live-UI-Repaint.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Transport+Project Referenzen** — `set_transport()` + `set_project()` in AutomationManager; gewired in `container.py`.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **● REC Button** — Neuer Button im Automation-Panel. Toggle: Touch-Modus (Aufnahme) ↔ Read-Modus. Leuchtet rot bei aktiver Aufnahme. Synchronisiert mit Mode-Dropdown.
- [ ] AVAILABLE: **Automation Thinning** — Reduktion der Breakpoint-Dichte nach Recording (Cubase-Style). Aktuell werden bei 30-120 CC/Sek alle Punkte gespeichert.
- [ ] AVAILABLE: **Global Automation Arm** — Ein globaler "Arm"-Button in der Toolbar + per-Track Arm/Disarm.
- [ ] AVAILABLE: **Inline Automation im Arranger** — Automation-Lanes als erweiterte Track-Zeilen direkt im Arranger statt separatem Panel (wie Bitwig).

## v0.0.20.432 — Multi-Lane Stacking + Touch/Latch Automation Modi

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Multi-Lane Stacking (Bitwig-Style)** — `EnhancedAutomationLanePanel` zeigt jetzt beliebig viele Automation-Lanes gleichzeitig. Jede Lane hat eigenen Parameter-Selector + Curve-Selector + Close-Button. "+" Button zum Hinzufügen, "×" zum Entfernen. Bis zu 8 Lanes gleichzeitig.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **`_LaneStrip` Widget** — Neue Klasse: mini Header-Bar (Param-Combo + Curve-Combo + Clear + Close) + `EnhancedAutomationEditor`. Jede Strip ist unabhängig editierbar.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Touch Automation-Modus** — Aufzeichnung nur solange der MIDI-Controller bewegt wird. 500ms nach letztem CC-Wert stoppt die Aufzeichnung automatisch.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Latch Automation-Modus** — Aufzeichnung startet beim ersten CC-Wert und hält den letzten Wert bis Transport-Stop. Timer schreibt alle 100ms den gelatchten Wert.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **AutomationPlaybackService liest Touch/Latch** — Automation wird bei `mode in (read, touch, latch)` abgespielt, nicht nur bei "read".
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **"Show Automation" öffnet neue Lane** — Wenn ein Knob per Rechtsklick → "Show Automation in Arranger" angefragt wird und der Parameter noch nicht sichtbar ist, wird automatisch eine neue Lane hinzugefügt.
- [ ] AVAILABLE: **Inline Automation im Arranger** — Automation-Lanes als erweiterte Track-Zeilen direkt im Arranger statt separatem Panel (wie Bitwig).
- [ ] AVAILABLE: **Global Automation Arm** — Ein globaler "Arm"-Button in der Toolbar + per-Track Arm/Disarm.
- [ ] AVAILABLE: **Automation Thinning** — Reduktion der Breakpoint-Dichte nach Recording (Cubase-Style). Aktuell werden bei 30-120 CC/Sek alle Punkte gespeichert.

## v0.0.20.431 — Automation Bridge Fix (MIDI Record → Lane → Playback)

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Kritischer Dual-Store-Bug behoben** — MIDI-aufgezeichnete Automation landete im Legacy-Store (`project.automation_lanes`), aber die UI und der Playback lasen aus dem neuen Store (`AutomationManager._lanes`). Jetzt schreibt `_write_automation_point()` in BEIDE Stores.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Legacy-Format-Bug in AutomationPlaybackService** — `_on_playhead()` erwartete `dict` mit `"points"` Key, bekam aber eine flat `list`. Jetzt werden beide Formate unterstützt.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Write-Mode für Volume/Pan/Device-Params** — Bisher wurde Automation nur für generische Params aufgezeichnet. Jetzt zeichnen Volume, Pan und alle Device-Parameter Breakpoints auf wenn `automation_mode == "write"`.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **MIDI-recorded Lanes in UI sichtbar** — `lane_data_changed` Signal repainted den Editor live; MIDI-erzeugte Lanes erscheinen in der Parameter-Dropdown-Liste (📈 Icon).

## v0.0.20.430 — SF2 Realtime Engine (Live MIDI → SoundFont Audio)

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **SF2 SoundFont reagiert jetzt auf Live-MIDI-Keyboard** — Bisher wurde SF2 nur offline gerendert (FluidSynth CLI → WAV-Cache). Neue `FluidSynthRealtimeEngine` (Pull-Source) registriert sich in SamplerRegistry + AudioEngine wie alle anderen Instrumente.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **`_create_sf2_instrument_engines()` in AudioEngine** — Scannt Tracks nach `plugin_type=="sf2"`, erstellt/reused Engines, registriert Pull-Sources mit `_pydaw_track_id` Tag für Track-Mixer (Vol/Pan/Mute/Solo/VU).
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Polyphonic note_off für alle Live-MIDI-Instrumente** — `_on_live_note_off_route_to_sampler()` gibt jetzt `pitch` an `SamplerRegistry.note_off()` weiter. Vorher wurden alle Noten released, jetzt nur die losgelassene Taste.
- [ ] AVAILABLE: **SF2 Multi-Channel Support** — Aktuell nur Channel 0; könnte auf 16 Kanäle erweitert werden für GM/GS drum kits.
- [ ] AVAILABLE: **SF2 Preset-Browser** — Preset-Liste aus SoundFont anzeigen (Bank/Preset mit Namen).

## v0.0.20.429 — Bounce in Place: plugin_type Matching Fix (chrono-Prefix)

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **plugin_type `'chrono.pro_drum_machine'` wurde nicht erkannt** — Der Offline-Render-Code prüfte nur `'drum_machine'`, `'sampler'`, `'aeterna'`, aber die Plugin-Registry verwendet `'chrono.pro_drum_machine'`, `'chrono.pro_audio_sampler'`, `'chrono.aeterna'`. Alle Prüfungen erweitert auf `in ('drum_machine', 'chrono.pro_drum_machine')` etc.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Bach-Orgel Fallback** — `'chrono.bach_orgel'` wird jetzt ebenfalls als internes Instrument erkannt.

## v0.0.20.428 — Bounce in Place: Best-Practice Fix (Borrow Running Engine)

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Best-Practice Ansatz wie Bitwig/Ableton/Cubase** — Statt eine NEUE VST-Instanz für den Offline-Bounce zu erstellen (was bei vielen Plugins scheitert), wird jetzt die BEREITS LAUFENDE Engine-Instanz aus der Audio-Engine "geborgt". Das Plugin ist schon geladen, initialisiert und produziert garantiert Audio.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **`_audio_engine_ref` Brücke** — `ServiceContainer` setzt `project._audio_engine_ref = audio_engine`, damit ProjectService auf die laufenden VST-Engines zugreifen kann (`_vst_instrument_engines[track_id]`).
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **`_borrowed` Flag** — Geborgte Engines werden NICHT mit `shutdown()` beendet (gehören der Audio-Engine). Nach dem Bounce: `all_notes_off()` + Flush-Blocks zum Aufräumen.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Relaxierte `kind=='instrument'` Prüfung** — Die strenge Prüfung `kind == 'instrument'` hat Tracks mit VST-Devices ausgesperrt, wenn `kind` nicht korrekt gesetzt war. Jetzt: `_track_has_vst_device()` prüft sowohl `audio_fx_chain` als auch die laufende Audio-Engine.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Offline-Fallback beibehalten** — Falls keine laufende Engine verfügbar ist (z.B. frisch geladenes Projekt), wird weiterhin eine neue Instanz erstellt (mit Suspend/Resume + Warmup).

## v0.0.20.427 — Bounce in Place: VST Offline Fix #2 (Warmup + Suspend/Resume + Diagnostics)

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **VST2 Suspend/Resume nach State-Restore** — Nach `set_chunk()` brauchen viele VSTs (Dexed, Helm, etc.) einen `effMainsChanged(0)→effMainsChanged(1)→effStartProcess` Zyklus, damit der geladene State aktiv wird. Ohne diesen Schritt bleibt das Plugin im "Schlafmodus".
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **200ms Warmup-Phase** — VST-Plugins werden nach Engine-Erstellung mit ~200ms Leer-Audio "aufgewärmt", damit interne Oszillatoren, Filter und Buffer initialisiert sind bevor MIDI-Noten ankommen.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Relaxierte Instrument-Erkennung** — `__ext_is_instrument` ist oft nicht im gespeicherten Projekt-JSON vorhanden. Jetzt: wenn wir MIDI-Clips bouncen und kein internes Engine (Sampler/Drum/Aeterna) passt, wird jedes `ext.vst` Device als Instrument angenommen.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Umfangreiche Diagnose-Logs** — Jeder Schritt des Offline-Bounce-Prozesses wird nach stderr geloggt: Device-Scan, Engine-Erstellung, MIDI-Events, Peak-Level, WAV-Datei-Analyse. Zeigt `AUDIO OK` oder `SILENT!` an.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Exception-Logging statt stummes Verschlucken** — Alle `except: pass` Blöcke im Bounce-Pfad loggen jetzt Fehler + Traceback nach stderr.

## v0.0.20.426 — Bounce in Place: VST2/VST3 Instrument Offline Rendering Fix

- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Bounce in Place erzeugt jetzt Audio für VST2/VST3-Instrument-Tracks** — zuvor wurde eine stille WAV-Datei erstellt, weil `_render_track_subset_offline` nur interne Engines (Sampler, DrumMachine, Aeterna) kannte. Jetzt wird automatisch eine temporäre `Vst2InstrumentEngine` / `Vst3InstrumentEngine` aus dem `audio_fx_chain` des Tracks instanziiert und für Offline-Rendering genutzt.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **`_create_vst_instrument_engine_offline()`** — neue Methode: scannt `track.audio_fx_chain` nach `ext.vst2:`/`ext.vst3:` Instrument-Devices, erstellt temporäre Engine-Instanz mit restored Plugin-State (`__ext_state_b64`), nutzt Offline-RTParamStore.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **`_render_vst_notes_offline()`** — neue Methode: rendert MIDI-Noten durch VST-Engine mit korrektem note_on/note_off-Scheduling (statt `trigger_note()`). Inklusive 1-Sekunde Release-Tail für natürliche Ausklingphase.
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Bounce in Place + Quelle stummschalten** — funktioniert jetzt korrekt auch für VST2-Instrumente (Dexed, Helm, etc.).
- [x] FIXED (Claude Opus 4.6, 2026-03-12): **Bounce in Place (Dry)** — ebenfalls für VST-Instrumente unterstützt; FX-Chain-Processing wird korrekt angewendet (VST-Instrument wird von ChainFx übersprungen, nur Audio-FX werden verarbeitet).

## v0.0.20.380 — VST3 Instrument Engine (MIDI→Audio Host für Surge XT & Co.)

- [x] FIXED (Claude Opus 4.6, 2026-03-11): **Vst3InstrumentEngine** — neue Klasse in `vst3_host.py` für VST3/VST2-Instrument-Hosting via pedalboard. Empfängt MIDI über SamplerRegistry, rendert Audio via `plugin.process(midi_msgs, duration, sr)`, registriert sich als Pull-Source im Audio-Callback.
- [x] FIXED (Claude Opus 4.6, 2026-03-11): **Instrument-Erkennung in FX-Chain** — `is_vst_instrument()` prüft `plugin.is_instrument`; erkannte Instrumente werden aus der FX-Verarbeitung übersprungen und stattdessen als Pull-Source gehostet.
- [x] FIXED (Claude Opus 4.6, 2026-03-11): **Polyphonic note_off** — `SamplerRegistry.note_off(track_id, pitch)` unterstützt jetzt pitch-spezifisches Note-Off für polyphonische VST-Instrumente (Surge XT).
- [x] FIXED (Claude Opus 4.6, 2026-03-11): **MIDI-Routing in HybridAudioCallback** — beide Callbacks (Sounddevice + JACK) übergeben jetzt `pitch` an `note_off()`.
- [x] FIXED (Claude Opus 4.6, 2026-03-11): **AudioEngine._create_vst_instrument_engines()** — erstellt und registriert Instrument-Engines automatisch bei `rebuild_fx_maps()`.
- [ ] AVAILABLE: **VST3 Instrument Preset Browser** — Preset-Auswahl direkt im Device-Widget für Surge XT.
- [ ] AVAILABLE: **Multi-Instrument pro Track** — aktuell nur 1 VST-Instrument pro Track (wie Ableton); mehrere wäre Ableton-Live-Rack-Style.
- [ ] AVAILABLE: **MIDI CC/Pitchbend Forwarding** — CC-Events und Pitch Bend an VST-Instrumente weiterleiten.

## v0.0.20.375 — Bidirektionale VST Param-Sync + Editor-Fenstertitel

- [x] FIXED (Claude Sonnet 4.6, 2026-03-10): **Bidirektionale Param-Sync DAW ↔ Editor** — vollständiges JSON-Protokoll über QProcess stdout/stdin:
  - **Editor→DAW** (`vst_gui_process.py` Polling-Thread, 80 ms): Param-Änderungen im nativen Fenster werden via `{"event":"param","name":...,"value":...}` gesendet; `_apply_param_from_editor()` schreibt in RTParamStore + updated Slider mit QSignalBlocker (kein Echo-Loop).
  - **DAW→Editor** (`_send_to_editor()`): Slider/Spinbox/Checkbox-Änderungen senden `{"cmd":"set_param","name":...,"value":...}` zu subprocess stdin; `_StdinReader`-Thread setzt `setattr(plugin, name, value)`.
  - **Initialer Snapshot**: `ready`-Event trägt jetzt `params`-Liste mit allen Anfangswerten; Widget übernimmt sie sofort.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-10): **Editor-Fenster-Titel** `"PluginName  [TrackName]  — Py_DAW"` — `_get_track_name()` liest Track.name aus ProjectService; `--title`/`--track` Args übergeben; `show_editor(window_title=...)` mit graceful TypeError-Fallback für ältere pedalboard-Versionen.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-10): `QProcess.ProcessChannelMode.SeparateChannels` statt MergedChannels — ermöglicht stabiles stdin-Schreiben ohne stdout-Korruption.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-10): `_get_track_name()` + `_send_to_editor()` als wiederverwendbare Hilfsmethoden in `Vst3AudioFxWidget`.
- [ ] AVAILABLE: Bidirektionale Param-Sync auch für LADSPA- und LV2-Devices.
- [ ] AVAILABLE: Editor-Fenster-Position/Größe persistieren (pro Plugin-Pfad in Projekt-JSON).

## v0.0.20.374 — VST3 Native Editor Subprocess + Param-Source-Hint

- [x] FIXED (Claude Sonnet 4.6, 2026-03-10): **Nativer VST3/VST2-Editor als Subprocess** (`pydaw/audio/vst_gui_process.py` neu) — isolierter `QProcess` lädt Plugin + ruft `show_editor()` auf. Kein Block des Qt-Main-Thread, Audio-Engine komplett unbeeinflusst. Läuft auf Linux (X11/XWayland), macOS, Windows.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-10): **`🎛 Editor`-Button** im VST-Widget-Header — startet/stoppt den Subprocess. Visuelles Feedback: `⏳ Editor…` beim Starten, `✕ Editor schließen` (grün) wenn aktiv.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-10): **Param-Source-Hint** — `_lbl_param_source` zeigt kursiv ⚡ live / ⏳ async / 🔄 main-thread.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-10): **`closeEvent()`** im Widget killt Editor-Subprocess sauber beim Schließen.
- [ ] AVAILABLE: Bidirektionale Param-Sync zwischen Editor-Subprocess und Audio-Engine.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-10): **Editor-Fenster-Titel** — `"PluginName  [TrackName]  — Py_DAW"` via `--title` + `--track` Args; `show_editor(window_title=...)` mit graceful TypeError-Fallback.

## v0.0.20.373 — VST3 Widget Main-Thread Reload Hotfix

- [x] FIXED (GPT-5, 2026-03-10): **`QCheckBox`-Import im VST3-Widget ergänzt** — Bool-/Toggle-Parameter können wieder stabil als Checkbox-Zeilen aufgebaut werden.
- [x] FIXED (GPT-5, 2026-03-10): **Async-Fallback macht jetzt einen einmaligen Main-Thread-Retry**, wenn `pedalboard` explizit `must be reloaded on the main thread` meldet.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-10): **Parameter-Quell-Hint** — `_lbl_param_source` zeigt jetzt ⚡ live / ⏳ async / 🔄 main-thread je nach Ladepfad.

## v0.0.20.371 — VST3 Project-State Raw-Blob Save/Load

- [x] FIXED (GPT-5, 2026-03-10): **Projekt-Save bettet jetzt für externe VST2/VST3-Devices einen `raw_state`-Blob als Base64** (`__ext_state_b64`) ins Device-`params` ein — erzeugt aus den aktuell gespeicherten Plugin-Parametern, ohne die laufende DSP-Instanz anzufassen.
- [x] FIXED (GPT-5, 2026-03-10): **`Vst3Fx` stellt den gespeicherten Base64-Blob beim Laden zuerst wieder her** und übernimmt danach wie bisher die explizit gespeicherten Parameterwerte; dadurch bleiben Preset-/State-Daten projektseitig erhalten, ohne den Audio-Callback-Pfad umzubauen.
- [x] FIXED (GPT-5, 2026-03-10): **`Vst3AudioFxWidget` zeigt jetzt direkt im Header einen kleinen Preset-/State-Hinweis**, ob für dieses externe VST2/VST3-Device bereits ein eingebetteter `__ext_state_b64`-Blob im Projekt vorhanden ist, inklusive kompakter Größenanzeige – rein UI-seitig, ohne Audio-/Host-Eingriff.
- [ ] AVAILABLE: Optional später einen **expliziten „Preset/State aktualisieren“-Button** im VST3-Widget ergänzen, falls künftig auch native Plugin-Editoren internen State ändern dürfen.

## v0.0.20.370 — VST3 Widget Runtime-Param-Reuse Hotfix

- [x] FIXED (GPT-5, 2026-03-10): **`Vst3AudioFxWidget` bevorzugt jetzt die bereits laufende DSP-Instanz** — Parameter-Metadaten werden zuerst direkt aus dem kompilierten `Vst3Fx` im `audio_engine._track_audio_fx_map` gelesen, statt denselben Bundle-/Sub-Plugin-Pfad sofort erneut im Worker zu laden.
- [x] FIXED (GPT-5, 2026-03-10): **Kurzer Rebuild-Wartepfad vor Async-Fallback** ergänzt — frisch eingefügte VST3-Devices bekommen ein paar kurze Poll-Versuche auf die Live-Instanz; erst danach startet der bestehende Background-Loader.
- [x] FIXED (GPT-5, 2026-03-10): **`Vst3Fx._load()` extrahiert Parameter jetzt direkt aus der bereits geladenen Plugin-Instanz** — vermeidet unnötigen Doppel-Load desselben VSTs während des FX-Map-Builds.
- [ ] AVAILABLE: Optional im VST-Header einen kleinen Status wie **„Parameter: live“ / „Parameter: fallback“** anzeigen, weiterhin nur UI-seitig.

## v0.0.20.369 — VST3 Mono/Stereo Bus-Adapt Hotfix

- [x] FIXED (GPT-5, 2026-03-09): **`Vst3Fx` passt Hauptbus-Kanalzahlen jetzt sicher an** — Mono-VSTs wie **LSP Autogain Mono / Filter Mono** laufen im weiterhin stereo-internen Track-FX-Pfad, ohne pro Audio-Block denselben `does not support 2-channel output`-Fehler zu werfen.
- [x] FIXED (GPT-5, 2026-03-09): **Eingang/ Ausgang werden jetzt gebrückt statt starr 2→2 erzwungen** — Stereo→Mono wird sauber heruntergemischt, Mono→Stereo wieder dupliziert, 2→1 und 1→2 bleiben damit ebenfalls safe.
- [x] FIXED (GPT-5, 2026-03-09): **Fehlertext-Parser + Layout-Cache** ergänzt — wenn `pedalboard` die Busgröße erst beim `process()` verrät, merkt sich der Host die erkannte 1/1- bzw. 1/2-/2/1-Konfiguration und spammt nicht weiter jede Callback-Runde dieselbe Fehlermeldung.
- [ ] AVAILABLE: Optional im externen VST-Header die erkannte **Main-Bus-Zeile** (`1→1`, `1→2`, `2→2`) sichtbar machen, weiterhin nur UI.

## v0.0.20.368 — VST3 Widget Async-Param-Load Fix

- [x] FIXED (Claude Sonnet 4.6, 2026-03-09): **Vst3AudioFxWidget: describe_controls async** — Plugin-Parameter-Lade blockierte Qt-Main-Thread (10-60 s Freeze bei "Add to Device"). Neuer _Vst3ParamLoader(QThread) lädt Parameter im Hintergrund, UI zeigt sofort "Lade Plugin-Parameter…" Status.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-09): **_build_rows_from_infos()** — Row-Build-Code aus synchronem Pfad extrahiert, wird jetzt in _on_params_loaded() nach async-Load aufgerufen.

## v0.0.20.367 — VST3 Startup Cache-Guard + Probe-Timeout

- [x] FIXED (Claude Sonnet 4.6, 2026-03-09): **Warmer Start ohne Rescan** — `PluginsBrowserWidget.__init__()` ruft `rescan()` nur noch dann auf, wenn kein frischer Cache (< 4h) vorhanden ist. Sonst wird der Cache sofort angezeigt.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-09): **`cache_is_fresh(max_age_seconds)`** in `plugin_scanner.py` — prüft `ts`-Feld des Caches, gibt `True` zurück wenn frisch.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-09): **`probe_multi_plugin_names()` mit 15-Sekunden-Timeout** — hängendes VST3-Binary wird nach 15s abgebrochen; Warning auf stderr, Scan läuft weiter.
- [ ] AVAILABLE: Optional sichtbare Sub-Plugin-Zeile im Device-Header für externe VSTs.
- [ ] AVAILABLE: Insert-Selbsttest / Diagnose-Toast wenn externes VST nach Insert keine Parameter liefert.
- [ ] AVAILABLE: Lazy "Sub-Plugin wählen…" Dialog für unbekannte Multi-Plugin-Bundles (kein Eager-Scan).
- [ ] AVAILABLE: Scanner-Modus-Schalter (safe/deep) im Plugins-Browser als UI-Option.


## v0.0.20.366 — VST3 Device Exact-Reference Hotfix

- [x] FIXED (GPT-5, 2026-03-09): **Externe VST3/VST2-Devices speichern jetzt immer eine kanonische Komplett-Referenz** (`__ext_ref`) zusätzlich zu Basis-Pfad und optionalem `__ext_plugin_name`.
- [x] FIXED (GPT-5, 2026-03-09): **Browser → DevicePanel → FX-Widget → Live-Host** bevorzugt jetzt diese exakte Referenz; damit gehen Multi-Plugin-Sub-Plugins beim Insert/Rebuild nicht mehr still verloren.
- [x] FIXED (GPT-5, 2026-03-09): **DevicePanel normalisiert VST-Insert-Metadaten** beim Hinzufügen, damit auch gemischte alte/neue Payloads robust im Projekt landen.
- [ ] AVAILABLE: Optional den Device-Header bei externen VSTs zusätzlich um eine **sichtbare Sub-Plugin-Zeile** erweitern (Datei + Sub-Plugin getrennt lesbar).
- [ ] AVAILABLE: Optional einen kleinen **Insert-Selbsttest / Diagnose-Toast** ergänzen, wenn ein externes VST nach dem Insert keine Parameter liefert.

## v0.0.20.365 — VST3 Startup Scan Hang Hotfix

- [x] FIXED (GPT-5, 2026-03-09): **Automatischer VST3-Startscan instanziiert nicht mehr jedes Plugin** per `pedalboard.load_plugin()`; dadurch hängt der Programmstart nicht mehr an problematischen Plugins wie `ZamVerb.vst3`.
- [x] FIXED (GPT-5, 2026-03-09): **Eager Multi-Plugin-Probing** ist jetzt auf bekannte sichere Bundle-Sammlungen wie `lsp-plugins.vst3` begrenzt; normale VST3s werden beim Scan nur als Datei/Bundles gelistet.
- [x] FIXED (GPT-5, 2026-03-09): **Debug-Override** `PYDAW_VST_MULTI_PROBE=1` ergänzt, um das breite Probe-Verhalten bei Bedarf bewusst wieder einzuschalten.
- [ ] AVAILABLE: Optional einen **Lazy „Sub-Plugin wählen…“ Dialog** ergänzen, damit auch unbekannte Multi-Plugin-Bundles ohne Eager-Scan sauber auswählbar bleiben.
- [ ] AVAILABLE: Optional einen kleinen **Scanner-Modus-Schalter** (safe/deep) im Plugins-Browser ergänzen.

## v0.0.20.364 — VST3 Browser Multi-Plugin Bundle Fix

- [x] FIXED (GPT-5, 2026-03-09): **VST3-Browser scannt Multi-Plugin-Bundles** wie `lsp-plugins.vst3` jetzt in einzelne auswählbare Sub-Plugins auf, sobald `pedalboard` verfügbar ist.
- [x] FIXED (GPT-5, 2026-03-09): **Externe VST-Metadaten** tragen jetzt zusätzlich `__ext_plugin_name`, damit Browser, Device-Widget und Live-Host exakt dasselbe Sub-Plugin laden.
- [x] FIXED (GPT-5, 2026-03-09): **`install.py` + `requirements.txt`** ergänzen jetzt `pedalboard`, damit VST2/VST3-Hosting auf frischen Setups nicht nur zufällig lokal funktioniert.
- [x] FIXED (GPT-5, 2026-03-09): Veraltete **Placeholder-Texte** im Plugins-Browser bereinigt; Status/Hinweise sprechen jetzt von echtem Live-Hosting statt Dummy-Verhalten.
- [ ] AVAILABLE: Optional einen kleinen **„Sub-Plugin wählen…“ Fallback-Dialog** ergänzen, falls ein alter Cache-Eintrag noch als Bundle-Datei statt als einzelnes Sub-Plugin angeklickt wird.
- [ ] AVAILABLE: Optional einen kleinen **„Rescan empfohlen“ Hinweis** anzeigen, wenn der VST-Cache noch aus Vor-Multi-Plugin-Zeiten stammt.

## v0.0.20.363 — VST3/VST2 Live Hosting via pedalboard

- [x] FIXED (Claude Sonnet 4.6, 2026-03-09): **VST3/VST2 Plugins live gehostet** via `pedalboard` (Spotify). Plugins werden bei Audio-Rendering tatsächlich ausgeführt statt Placeholder.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-09): **`pydaw/audio/vst3_host.py`** neu erstellt — `Vst3Fx` mit `process_inplace(buf, frames, sr)` kompatibel zu FxChain. Parameter-Discovery via `describe_controls()`.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-09): **`pydaw/audio/fx_chain.py`** — `ext.vst3:` und `ext.vst2:` Branch hinzugefügt (analog zu LADSPA-Branch).
- [x] FIXED (Claude Sonnet 4.6, 2026-03-09): **`Vst3AudioFxWidget`** in `fx_device_widgets.py` — zeigt alle VST3-Parameter als Slider/Spinbox/Checkbox, mit RT-Sync, Persistenz und Automation-Menü.
- [x] FIXED (Claude Sonnet 4.6, 2026-03-09): **`plugins_browser.py`** — Status-Meldung zeigt jetzt "VST3 live OK (pedalboard X.Y.Z)" statt "Placeholder (Hosting noch nicht implementiert)".
- [x] FIXED (Claude Sonnet 4.6, 2026-03-10): **VST3 Native Editor** — `🎛 Editor`-Button in `Vst3AudioFxWidget`; startet `vst_gui_process.py` als isolierten `QProcess`-Subprocess.
- [ ] AVAILABLE: **VST3 Preset-Speicherung** — Plugin-State als Base64-Blob in project JSON sichern.

## v0.0.20.361 — MIDI Content Scaling + Instrument-Browser Doppelklick-Fix

- [x] FIXED (Claude Opus 4.6, 2026-03-09): **Alt + Drag am MIDI-Clip-Rand = Content Scaling** — alle MIDI-Noten proportional zur neuen Cliplänge skaliert (Bitwig-Style).
- [x] FIXED (Claude Opus 4.6, 2026-03-09): **Alt + Drag am Audio-Clip-Rand = Audio Stretch** — clip.stretch proportional angepasst.
- [x] FIXED (Claude Opus 4.6, 2026-03-09): **Lazy Update Pattern** + **Original-Snapshot** für Rundungssicherheit.
- [x] FIXED (Claude Opus 4.6, 2026-03-09): **Neon-Glow-Effekt** (Cyan/Teal) + Skalierungsfaktor-Overlay (🎵 MIDI / 🔊 Audio).
- [x] FIXED (Claude Opus 4.6, 2026-03-09): **Alt+Shift+Drag = Free Mode** (pixelgenau, kein Grid-Snap).
- [x] FIXED (Claude Opus 4.6, 2026-03-09): **Instrument-Browser Doppelklick** repariert — `_add_instrument_to_device()` war leer.
- [x] FIXED (Claude Opus 4.6, 2026-03-09): **Alt+Drag-auf-Body DnD-Copy entfernt** (kollidierte mit Content Scaling, Ctrl+Drag ist die richtige Copy-Methode).
- [ ] AVAILABLE: **Multi-Clip Content Scaling** — mehrere selektierte MIDI-Clips gleichzeitig skalieren.

## v0.0.20.360 — DAWproject Export Cross-Device Hotfix

- [x] FIXED (GPT-5, 2026-03-08): Kritischen Export-Fehler **`[Errno 18] Ungültiger Link über Gerätegrenzen hinweg`** behoben. Finale `.dawproject`-Datei wird jetzt als **temporäre Schwesterdatei im Zielordner** erzeugt und erst danach per `os.replace()` übernommen. Dadurch funktionieren Exporte auch dann, wenn `/tmp` und Benutzerordner auf unterschiedlichen Dateisystemen liegen.

## v0.0.20.359 — DAWproject Export UI Hook (sichtbar im Datei-Menü)

- [x] FIXED (GPT-5, 2026-03-08): Sicherer Menü-Hook **`Datei → DAWproject exportieren… (.dawproject)`** ergänzt, inklusive Hintergrund-Export via `DawProjectExportRunnable`, Progress-Dialog und Summary-Dialog — ohne Core-/Playback-Eingriff.
- [ ] AVAILABLE: Export-Dialog optional später um sehr kleine **Optionen** ergänzen (z. B. Audio einbetten an/aus, Validierung an/aus), weiterhin nur UI/FileIO.
- [ ] AVAILABLE: Ein kleiner **Roundtrip-Testpfad** `Export → neues leeres Projekt → Import` kann als separater sicherer QA-Schritt ergänzt werden.


## v0.0.20.358 — DAWproject Exporter Scaffold (snapshot-safe, ohne Core-Eingriff)

- [x] FIXED (GPT-5, 2026-03-08): Neuer entkoppelter **`DawProjectExporter`** als reiner **Data Mapper** ergänzt — arbeitet ausschließlich auf einer tief kopierten Snapshot-`Project`-Instanz.
- [x] FIXED (GPT-5, 2026-03-08): Sicherer **Temp-File-First Exportpfad** umgesetzt: Staging-Ordner → `project.xml` / `metadata.xml` / `audio/` → temporäre ZIP → XML/ZIP-Validierung → atomarer Move.
- [x] FIXED (GPT-5, 2026-03-08): **Automation-Lanes**, **Audio-Referenzen** und konservative **Base64-Plugin-State-Blobs** in ein erstes `.dawproject`-Export-Skelett gemappt, ohne Playback-/DSP-Core anzufassen.
- [x] FIXED (GPT-5, 2026-03-08): Optionalen **`DawProjectExportRunnable`** für non-blocking UI-Integration ergänzt, weiterhin ohne MainWindow-Hook.
- [ ] AVAILABLE: Sicheren **MainWindow-Menü-Hook** `Datei → DAWproject exportieren…` ergänzen, ausschließlich auf Basis des neuen Snapshot-Exporters.
- [ ] AVAILABLE: Kleinen **Export-ProgressDialog** mit `QThreadPool` / `DawProjectExportRunnable` ergänzen, ohne Audio-/Transport-Core anzufassen.
- [ ] AVAILABLE: **Roundtrip-Smoke-Test** (Export → Re-Import in leeres Projekt) ergänzen, weiterhin nur im FileIO-/Test-Bereich.

## v0.0.20.357 — Echter Group-Bus mit eigener Device-Chain (Bitwig-Style)

- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Echte Gruppenspur mit kind="group"** erstellt — Group-Track hat eigene `audio_fx_chain` durch die das summierte Audio aller Kindspuren fließt.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Group-Bus-Routing im Audio-Callback**: Kind-Audio → Kind-FX → Kind-Vol/Pan → Group-Buffer → Group-FX → Group-Vol/Pan → Master.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Pull-Sources (Sampler/Drum/SF2)** werden ebenfalls durch den Group-Bus geroutet.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Group-Header-Klick im Arranger** wählt den Group-Track aus → DevicePanel zeigt die Gruppen-Device-Chain.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Effects auf die Gruppe** landen jetzt auf der Gruppen-FX-Chain (nicht mehr auf kick).
- [ ] AVAILABLE: **Group-Fader im Mixer-View** als eigener Bus-Kanal anzeigen.
- [ ] AVAILABLE: **Group Mute/Solo Verhalten** (Bitwig: Group-Mute stummschaltet alle Kinder).
- [ ] AVAILABLE: **Sub-Lanes innerhalb einer eingeklappten Gruppe** statt Überlappung.

## v0.0.20.356 — Kritischer Bugfix: Collapsed-Group Clip-Track-Zuordnung

- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Clip-Track-Korruption bei Drag in eingeklappter Gruppe** behoben. Clips wurden beim horizontalen Drag stillschweigend auf `members[0]` (z.B. kick) umgehängt — damit spielten alle gruppierten Instrumente gleichzeitig.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Single-Clip, Multi-Clip und Copy-Drag** jeweils mit `_is_same_collapsed_group()` Guard geschützt.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Track-Lookup Fallback** für collapsed Groups: Volume-Anzeige für Non-First-Members korrigiert.
- [x] FIXED (Claude Opus 4.6, 2026-03-08): **Spur-Name-Prefix in Clip-Labels** bei eingeklappter Gruppe (🔹kick: ..., 🔹open hi: ...) zur besseren Unterscheidbarkeit.
- [ ] AVAILABLE: **Sub-Lanes innerhalb einer eingeklappten Gruppe** statt Überlappung aller Clips auf einer Zeile.
- [ ] AVAILABLE: **Echte Group-Track / Group-Bus Device-Chain wie in Bitwig** bleibt ein separater Routing-/Mixer-Schritt.

## v0.0.20.355 — Browser Scope-Badges + Distortion Automation Guard

- [x] FIXED (GPT-5, 2026-03-08): Kleine **Scope-Badges direkt im Browser/Add-Flow** ergänzt (Instruments / Effects / Favorites / Recents), damit vor dem Hinzufügen sichtbar ist, dass Browser-Add weiter nur auf die **aktive Spur** zielt.
- [x] FIXED (GPT-5, 2026-03-08): Die Scope-Badges werden jetzt **trackbezogen aktualisiert**, sobald die aktive Spur wechselt.
- [x] FIXED (GPT-5, 2026-03-08): Safe Guard gegen den gemeldeten **DistortionFxWidget Automation-Callback auf gelöschte Slider/Spinboxen** ergänzt.
- [ ] AVAILABLE: Optional die Scope-Badges zusätzlich in **Plugins** und ggf. weiteren Browser-Tabs spiegeln, weiterhin UI-only.
- [ ] AVAILABLE: **Echte Group-Track / Group-Bus Device-Chain wie in Bitwig** bleibt ein separater Routing-/Mixer-Schritt und ist in diesem Safe-Block bewusst noch nicht umgesetzt.

## v0.0.20.354 — DevicePanel Gruppen-/Spur-Zieltrennung klarer

- [x] FIXED (GPT-5, 2026-03-08): DevicePanel zeigt jetzt eine zusätzliche **Aktive Spur-Ziel**-Hinweisbox; sichtbare Device-Kette unten wird klar als **aktive Spur** ausgewiesen, Gruppen-Aktionen separat als **NOTE→Gruppe / AUDIO→Gruppe** erklärt.
- [ ] AVAILABLE: Kleine **Scope-Badge direkt im Browser/Add-Flow** ergänzen, damit schon vor dem Hinzufügen klar ist, ob das Ziel die **aktive Spur** oder die **ganze Gruppe** ist.

## v0.0.20.353 — TrackList Drop-Markierung beim Maus-Reorder

- [x] FIXED (GPT-5, 2026-03-08): **Sichtbare Drop-Markierung in der linken Arranger-TrackList** ergänzt, damit beim Maus-Verschieben klar erkennbar ist, an welcher Position Spur oder Block eingefügt wird.
- [x] FIXED (GPT-5, 2026-03-08): Die Markierung reagiert sicher auf **same-widget Reorder-Drags** und bleibt damit vom bestehenden **Cross-Project-Track-Drag** getrennt.
- [ ] AVAILABLE: Optional die **Drop-Markierung zusätzlich als kleine Ziel-Highlight-Zone** pro Zeile erweitern, weiterhin ohne Routing-/DSP-Eingriff.
- [ ] AVAILABLE: Die **Gruppen-/Track-FX-Zieltrennung** im DevicePanel optional noch deutlicher visualisieren; echter Gruppenbus bleibt weiterhin ein separater Core-Schritt.

## v0.0.20.352 — Gruppenkopf-Mausdrag + Doppelklick-Umbenennen

- [x] FIXED (GPT-5, 2026-03-08): **Gruppenkopf in der Arranger-TrackList per Maus als kompletter Block verschiebbar** gemacht, ohne den bestehenden Cross-Project-Track-Drag anzutasten.
- [x] FIXED (GPT-5, 2026-03-08): **Doppelklick auf Track-/Gruppennamen** öffnet jetzt sicher den bestehenden Umbenennen-Dialog.
- [x] FIXED (GPT-5, 2026-03-08): DevicePanel-Gruppenhinweis klarer gemacht: **normales Add-to-Device wirkt nur auf die aktive Spur**, **N→G / A→G** auf die ganze Gruppe.

## v0.0.20.351 — Arranger Maus-Reorder in TrackList

- [x] FIXED (GPT-5, 2026-03-08): **Maus-Drag-Reorder im linken Arranger-Bereich** ergänzt, inklusive sicherem **Mehrfachauswahl-Blockmove** und ohne den bestehenden **Cross-Project-Track-Drag** zu brechen.
- [ ] AVAILABLE: Optional **Gruppenkopf ebenfalls per Maus als kompletter Block** verschiebbar machen, weiterhin ohne Routing-/DSP-Eingriff.
- [ ] AVAILABLE: Optional eine kleine **Drop-Ziel-Markierung** in der TrackList ergänzen, damit die Einfügeposition beim Maus-Drag noch klarer wird.

## v0.0.20.350 — Arranger Gruppen-Alignment + sichtbare Verschiebe-Pfeile

- [x] FIXED (GPT-5, 2026-03-08): **Ausgeklappte Gruppen im Arranger-Canvas an die linke TrackList angeglichen**: Gruppenkopf und alle Mitgliedsspuren werden jetzt korrekt untereinander gezeigt, statt dass Spuren optisch verschwinden oder zusammenrutschen.
- [x] FIXED (GPT-5, 2026-03-08): Das Gruppen-Alignment gilt jetzt sicher auch für **Audio- und Busspuren** innerhalb derselben Gruppendarstellung.
- [x] FIXED (GPT-5, 2026-03-08): **Sichtbare ▲/▼-Buttons direkt in Track-/Gruppenzeilen** ergänzt, damit das Verschieben nicht nur über Kontextmenü, sondern direkt im Arranger-Header funktioniert.
- [x] FIXED (GPT-5, 2026-03-08): **Gruppenkopf als kompletter Block nach oben/unten verschiebbar** gemacht, ohne Audio-/Routing-Core anzufassen.
- [ ] AVAILABLE: **Track-Reorder per Drag & Drop** separat evaluieren; nur sinnvoll, wenn Cross-Project-Drag dabei sicher erhalten bleibt.
- [ ] AVAILABLE: **Gruppenkopf-Lane im Canvas** optional noch mit kompakterem Titel/Badge visuell verfeinern.
- [ ] AVAILABLE: **Echte Audio-Gruppenbusse** weiterhin strikt getrennt als späteren Routing-/Mixer-Schritt behandeln.

## v0.0.20.349 — Gruppen-Fold-State + Arranger-Gruppen-Lane + Track-Reorder

- [x] FIXED (GPT-5, 2026-03-08): **Gruppen-Einklappstatus projektseitig gespeichert** (`arranger_collapsed_group_ids`), damit Fold-State beim Speichern/Laden erhalten bleibt.
- [x] FIXED (GPT-5, 2026-03-08): **Gruppen im Arranger-Canvas als eine Lane im eingeklappten Zustand** sichtbar gemacht; Clips aller Mitglieder laufen dann sicher auf einer gemeinsamen Gruppen-Lane zusammen.
- [x] FIXED (GPT-5, 2026-03-08): **Spuren im Arranger-Kontextmenü nach oben/unten verschiebbar** gemacht, damit neu angelegte Instrument-/Audio-/Busspuren sauber umsortiert werden können.
- [x] FIXED (GPT-5, 2026-03-08): **Neue Spur direkt in eine bestehende Gruppe einfügen** ergänzt (Gruppenkopf-Menü + Track-Menü „In diese Gruppe hinzufügen“), damit neue Instrumente/Busse nicht mehr nur unterhalb der Gruppe landen.
- [ ] AVAILABLE: **Collapsed Group Lane** optional um kleine kompakte Summen-/Member-Hinweise direkt im Canvas ergänzen, rein visuell.
- [ ] AVAILABLE: **Gruppen-Spur verschieben** optional als kompletter Block (alle Mitglieder zusammen) ergänzen; separat planen, weil das Verhalten klar definiert werden sollte.
- [ ] AVAILABLE: **Echte Audio-Gruppenbusse** weiterhin getrennt als späteren Routing-/Mixer-Schritt behandeln, nicht in diesem UI-safe Block.

## v0.0.20.348 — Master-FX / Global Undo / Arranger-Menü-Hotfixes

- [x] FIXED (GPT-5, 2026-03-08): **Master-Audio-FX hörbar gemacht**: Summen-/Master-FX werden jetzt im Master-Mixpfad wirklich verarbeitet.
- [x] FIXED (GPT-5, 2026-03-08): **Globales Projekt-Undo/Redo** per sicherem Snapshot-Fallback ergänzt, damit viele bislang undo-lose Projektänderungen rückgängig gemacht werden können.
- [x] FIXED (GPT-5, 2026-03-08): **Ctrl+Z / Ctrl+Shift+Z / Ctrl+Y** zusätzlich als globale Application-Shortcuts verdrahtet.
- [x] FIXED (GPT-5, 2026-03-08): **Track-Kontextmenü repariert/erweitert**: **Umbenennen**, **Track löschen**, **Instrument-/Audio-/Bus-Spur hinzufügen**.
- [x] FIXED (GPT-5, 2026-03-08): **Gruppenkopf einklappbar** im Arranger umgesetzt.
- [ ] AVAILABLE: **Gruppen-Einklappstatus projektseitig speichern**, damit Fold-State beim erneuten Laden erhalten bleibt.
- [ ] AVAILABLE: **Undo-Labels** für größere UI-Aktionen gezielter benennen statt generischem Snapshot-Label.
- [ ] AVAILABLE: **Master-DeviceCard** optisch noch klarer als Summenkanal ausweisen (rein UI-seitig).

## v0.0.20.347 — Arranger Track-/Gruppen-Flow + Gruppen-Sektion im DevicePanel

- [x] FIXED (GPT-5, 2026-03-08): **Clip → Track-Auswahl synchronisiert**: wenn im Arranger ein MIDI-/Audio-Clip aktiv ausgewählt wird, wird jetzt auch seine zugehörige Spur im Track-Header mit ausgewählt.
- [x] FIXED (GPT-5, 2026-03-08): **Rechtsklick-Menü direkt auf Track-/Instrument-Zeilen** im Arranger ergänzt, inkl. **Umbenennen**, **Auswahl gruppieren**, **Gruppe umbenennen**, **Gruppe auflösen**, Devices/Browser sowie bestehende Track-Aktionen.
- [x] FIXED (GPT-5, 2026-03-08): **Spurgruppierung visuell als echte Sektion** im Arranger-Trackbereich dargestellt: Gruppenkopf + eingerückte Mitglieder untereinander, ohne Eingriff in Playback-/Mixer-Core.
- [x] FIXED (GPT-5, 2026-03-08): **Gruppen-Sektion im DevicePanel** ergänzt: sichtbare Mitgliederliste plus sichere Batch-Aktionen **N→G** / **A→G**, um NOTE-FX bzw. AUDIO-FX auf alle Tracks der aktuellen Gruppe anzuwenden.
- [ ] AVAILABLE: **Gruppen-Kopf einklappbar** machen (nur UI), damit große Orchester-/Chorgruppen im Arranger kompakter werden.
- [ ] AVAILABLE: **Gruppen-DevicePanel** optional um eine kleine **Bypass-/Mute-Übersicht pro Mitglied** erweitern, weiterhin ohne Engine-/Routing-Umbau.
- [ ] AVAILABLE: **Echte Gruppen-Bus-/Summen-Spur** als späteren Architektur-Schritt separat planen, erst nach expliziter Freigabe, weil das ein Core-/Routing-Thema wäre.

## v0.0.20.338 — AETERNA Live ARP / Readability / Safe Note-FX Bridge

- [x] FIXED (GPT-5, 2026-03-07): **AETERNA Arp A** kann jetzt sicher **Live an/aus** geschaltet werden, indem lokal ein vorhandenes **Track Note-FX Arp** für diese AETERNA-Spur gepflegt wird — ohne Playback-Core-Umbau.
- [x] FIXED (GPT-5, 2026-03-07): Die bereits vorhandenen **16 Step-Daten** von AETERNA Arp A werden jetzt auch für den sicheren **Track Note-FX Arp** genutzt (**Transpose / Skip / Velocity / Gate / Shuffle / Note Type**), damit Live-ARP und ARP→MIDI näher zusammenliegen.
- [x] FIXED (GPT-5, 2026-03-07): **AETERNA-Readability** lokal weiter angehoben: etwas größere Card-/Hint-Schriften sowie klarerer **ARP Live / ARP→MIDI**-Header.
- [ ] AVAILABLE: Lokale **AETERNA-Familienkarten** noch weiter verdichten (z. B. kompakte Mini-Meter oder aktive Mod-Ziel-Badges direkt im Card-Kopf), nur Widget/State.
- [ ] AVAILABLE: Lokale **Signalfluss-Ansicht** noch feiner staffeln (z. B. aktive Slot-Ziele farbig im passenden Ziel-Bucket hervorheben), nur im AETERNA-Widget.

## v0.0.20.335 — Nächster sichere AETERNA-Polish-Block

- [x] FIXED (GPT-5, 2026-03-07): Größeren lokalen **AETERNA-Polish-Block** umgesetzt: stärkere **Farbtrennung**, neue **Familien-Legende**, deutlichere **Familienkarten** und eine kleine **grafische Signalfluss-Ansicht** direkt im Instrument, weiterhin ohne Core-Umbau.
- [x] FIXED (GPT-5, 2026-03-07): Bisher intern schon vorgesehene **Pitch / Shape / Pulse Width**- sowie **Drive / Feedback**-Familien jetzt auch als echte sichtbare **Synth-Panel-Karten mit Knobs** im Widget ergänzt, weiterhin nur lokal in AETERNA.
- [ ] AVAILABLE: Lokale **AETERNA-Familienkarten** noch weiter verdichten (z. B. kompakte Mini-Meter oder aktive Mod-Ziel-Badges direkt im Card-Kopf), nur Widget/State.
- [ ] AVAILABLE: Lokale **Signalfluss-Ansicht** noch feiner staffeln (z. B. aktive Slot-Ziele farbig im passenden Ziel-Bucket hervorheben), nur im AETERNA-Widget.

## v0.0.20.329 — Nächste sichere AETERNA-Mod-Rack-/Synth-Schritte

- [ ] AVAILABLE: Lokale **AETERNA-Targets** optional noch kompakter nach **Klang / Raum / Bewegung** gliedern, weiterhin nur im Widget.
- [x] FIXED (GPT-5, 2026-03-07): Lokales **AETERNA-SYNTH PANEL Stage 1** mit bereits stabilen Parametern aufgebaut und lesbar gruppiert.
- [x] FIXED (GPT-5, 2026-03-07): Lokales **AETERNA-SYNTH PANEL Stage 2** mit echtem **Filter Cutoff / Resonance / Filter Type** ergänzt.
- [x] FIXED (GPT-5, 2026-03-07): Lokales **AETERNA-SYNTH PANEL Stage 3** in sicheren Familien gestartet: zuerst **Voice** (**Pan / Glide / Retrig / Stereo-Spread**) und **AEG/FEG ADSR**.
- [ ] AVAILABLE: Nächste Stage-3-Familien weiterführen: **Unison/Voices/Detune**, **Sub/Sub-Oktave**, **Shape/Pulse Width**, **Noise**, **Drive/Feedback** — nur schrittweise und nie alles auf einmal.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-SYNTH PANEL Stage 3** um die Familie **Unison / Sub / Noise** erweitert: echte Klangparameter, lokale Comboboxen für **Voices**/**Sub-Oktave** sowie stabile Automation-/Mod-Ziele für **Unison Mix / Unison Detune / Sub Level / Noise Level / Noise Color**.
- [ ] AVAILABLE: Nächste Stage-3-Familien weiterführen: **Pitch/Shape/Pulse Width** sowie **Drive/Feedback** — weiterhin nur schrittweise und nur lokal in AETERNA.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA-Mod-Rack zeigt jetzt lokale **Amount-/Polaritätsanzeigen** direkt an den realen Web-A/B-Slots.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA hat jetzt eine kleine lokale **Signalfluss-Linienansicht** für die aktiven Web-A/B-Wege.

## v0.0.20.326 — Nächste sichere Bounce/Freeze- und AETERNA-Schritte

- [ ] AVAILABLE: **Bounce in Place** optional um einen kleinen lokalen Dialog ergänzen (z. B. Quelle stummschalten / Dry / +FX), weiterhin ohne Playback-Core-Umbau.
- [ ] AVAILABLE: **Freeze Track / Group Freeze** optional um einen sichtbaren kleinen Statusmarker im Track-Namen oder Kontextmenü ergänzen, weiterhin projekt-/UI-seitig.
- [ ] AVAILABLE: Lokale **AETERNA Random-Math-/Formel-Familien** weiter ausbauen (z. B. mehr kohärente/noise-/chaos-inspirierte Startideen), weiterhin nur im Widget.
- [x] FIXED (GPT-5, 2026-03-07): Erste sichere **Bounce/Freeze-Workflows** ergänzt: **Bounce in Place → neue Audiospur**, **Spur einfrieren (+FX/Dry)**, **Gruppe einfrieren** bei vorhandener Track-Gruppe sowie **Freeze-Quellen wieder aktivieren** — ohne Playback-Core-Umbau.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA-Formelhilfen und Randomizer lokal um **breitere mathematische Familien** erweitert, damit nicht immer nur reine **phase**-Varianten im Vordergrund stehen.

## v0.0.20.324 — Nächste sichere AETERNA-Performance-Schritte

- [ ] AVAILABLE: Lokale **AETERNA-Ladeprofil-Hinweise** im Widget noch etwas sichtbarer machen (z. B. leichte Ready-/Staged-Init-Hinweise), weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Composer-Phrasenlängen/-Dichten** feiner staffeln, weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Snapshot-/Preset-Schnellaufrufe** optional noch um einen kleinen aktiven Fokusmarker ergänzen, weiterhin nur in AETERNA.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA lädt lokal spürbar sanfter: **Restore-Signale werden gebündelt**, **Komfort-Refreshes gestaffelt nachgezogen** und **Button-Rebinds ohne blindes disconnect()** aktualisiert — weiterhin nur im Widget.

## v0.0.20.321 — Nächste sichere AETERNA-Schritte

- [ ] AVAILABLE: Lokale **Automation-Hinweise** an den bereits sicheren AETERNA-Knobs noch klarer verdichten, weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Snapshot-Karte** optional noch um eine sehr kleine „zuletzt gespeichert/recallt“-Hinweiszeile ergänzen, weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Preset-/Snapshot-Schnellaufrufe** optional noch um kleine Statusfarben oder „aktiv“-Marker verfeinern, weiterhin nur im Widget.

- [x] FIXED (GPT-5, 2026-03-07): Lokale **Preset-/Snapshot-Kombis** sind jetzt als kleine **Schnellaufrufe** direkt im AETERNA-Widget sichtbar, inklusive kompakter Buttons und Tooltips für Recall/Load — ohne Core-Eingriff.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **Formel-/Web-Kombitipps** werden jetzt direkt an passenden AETERNA-Presets sichtbarer gezeigt, inklusive Preset-Fokus, Kurzlistenzeile und erweiterten Schnellpreset-Tooltips.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA-Preset-Kurzliste zeigt jetzt lokale **Direktmarker für Kategorie/Charakter** im Schnellbereich.

---

- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt einen lokalen **Automation-Schnellzugriff** für alle stabilen Knobs/Rates/Amounts, inklusive klarerer **musikalischer Tooltip-Hinweise** direkt an den Reglern.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-Snapshot-Slots** um kleine **Farbbadges/Statusmarker** erweitert, inklusive klarerem Slot-Tooltip und deaktiviertem Recall für leere Slots.
## v0.0.20.318 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Automation-Ziele** optional noch nach "Sweep / Bewegung / Raum" kompakter gruppieren, weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Preset-Kurzliste** optional um kleine Direktmarker für Kategorie/Charakter ergänzen, weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Snapshot-Karte** optional noch um eine sehr kleine „zuletzt gespeichert/recallt“-Hinweiszeile ergänzen, weiterhin nur im Widget.


- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-Presetbibliothek** kompakter nach **Kategorie/Charakter** zusammengefasst, inklusive aktivem Preset-Fokus und kompakter Bibliotheksübersicht direkt im Widget.

- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-Formel-/Preset-Empfehlungen** um kompakte **Hörhinweise** ergänzt.
## v0.0.20.315 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **AETERNA-Presetbibliothek** kompakter nach Charakter/Kategorie zusammenfassen, nur im Widget.
- [ ] AVAILABLE: Lokale **Snapshot-Slots** optional um kleine Farbbadges/kurze Statusmarker ergänzen, weiterhin nur im Widget.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **Automation-ready-Knob-Hinweise** in AETERNA kompakter gemacht, inklusive **Schnellzugriff** auf alle stabilen Automation-Lanes und klarerer Tooltip-Hinweise direkt an den Reglern.

- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-Snapshot-Karte** kompakter und musikalischer lesbar gemacht.
## v0.0.20.314 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Formel-/Preset-Empfehlungen** um kleine Hörhinweise ergänzen (z. B. sakral, klar, getragen), weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **AETERNA-Presetbibliothek** kompakter nach Charakter/Kategorie zusammenfassen, nur im Widget.
- [ ] AVAILABLE: Lokale **Snapshot-Slots** optional um kleine Farbbadges/kurze Statusmarker ergänzen, weiterhin nur im Widget.

- [x] 2026-03-07 AETERNA: Web-Vorlagen Basis-Reset lokal ergänzt, inkl. Save/Load von aktivem Web-Template.
## v0.0.20.311 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Formel-/Preset-Empfehlungen** um kleine Hörhinweise ergänzen (z. B. sakral, klar, getragen), weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **AETERNA-Presetbibliothek** kompakter nach Charakter/Kategorie zusammenfassen, nur im Widget.
- [ ] AVAILABLE: Lokale **Web-Vorlagen** optional um eine kleine klare **„Reset auf Basiswerte“**-Funktion ergänzen, weiterhin nur lokal in AETERNA.

- [x] FIXED (GPT-5, 2026-03-07): Lokale **Web-Intensitätsstufen** für AETERNA-Startvorlagen ergänzt (**Sanft / Mittel / Präsent**), inklusive sauberem Save/Load im Instrument-State.

## v0.0.20.309 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **AETERNA-Presetbibliothek** kompakter nach Charakter/Kategorie zusammenfassen, nur im Widget.
- [ ] AVAILABLE: Lokale **Formel-/Preset-Empfehlungen** optional um kleine Hörhinweise ergänzen (z. B. sakral, klar, getragen), weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Web-A/Web-B-Startvorlagen** ergänzen (z. B. langsam/lebendig/organisch), weiterhin nur in AETERNA.

- [x] FIXED (GPT-5, 2026-03-07): Lokale **Macro-A/B-Feinsteuerung** in AETERNA lesbarer gemacht, mit klarer Source→Target→Amount-Karte und kompakten Nutzungshinweisen.

## v0.0.20.308 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Macro-A/B-Feinsteuerung** lesbarer machen, weiterhin ohne DAW-Core-Eingriff.
- [ ] AVAILABLE: Lokale **AETERNA-Presetbibliothek** kompakter nach Charakter/Kategorie zusammenfassen, nur im Widget.
- [ ] AVAILABLE: Lokale **Formel-/Preset-Empfehlungen** optional um kleine Hörhinweise ergänzen (z. B. sakral, klar, getragen), weiterhin nur im Widget.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA zeigt jetzt lokal sichtbar, **welche Formelidee zum aktuellen Preset passt**, inklusive Lade-Button und Statuszeile.

## v0.0.20.307 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Formula-/Preset-Verknüpfung** sichtbarer machen (z. B. welches Preset nutzt aktuell welche Formelidee), nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **Macro-A/B-Feinsteuerung** lesbarer machen, weiterhin ohne DAW-Core-Eingriff.
- [ ] AVAILABLE: Lokale **Preset-Kurzliste** um kleine Herkunftshinweise ergänzen (z. B. sakral/kristall/drone), weiterhin nur im Widget.

- [x] FIXED (GPT-5, 2026-03-07): Lokale **Preset-Kurzliste** in AETERNA um einen sicheren **Filter** erweitert (Alle / Sakral / Kristall / Drone / Favoriten).

---

## v0.0.20.306 — Nächste sichere AETERNA-Phase-3b-Schritte

- lokale Preset-Kurzliste optional um intelligente Filter (z. B. sakral / kristall / drone) erweitern
- kuratierte Formel-Preset-Karte weiter ausbauen
- weitere vorsichtige Klangverfeinerung nur lokal in AETERNA
- weiterhin keine Core-Eingriffe

## v0.0.20.304 — Nächste sichere AETERNA-Schritte nach Kristall-/Formel-Upgrade
- [ ] AVAILABLE: Lokale **Formel-Preset-Karte** noch kompakter mit kleinen Stil-Hinweisen (z. B. ruhig / sakral / organisch / drone) ergänzen, weiterhin nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **AETERNA-Knob-Hinweise** für langsame Sweeps vs. lebendige Modulation noch klarer ausweisen, ohne Core-Eingriff.
- [ ] AVAILABLE: Optional ein lokales **"Klar/Weich"-Voicing-Preset** für AETERNA ergänzen, weiterhin nur innerhalb des Instruments.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt zusätzliche kuratierte **Formel-Startbeispiele** (**Organisch**, **Drone**), ein lokales **klareres/kristallineres Voicing** und den lokalen Bugfix **`get_formula_status()`** für die Formelstatus-Anzeige.

## v0.0.20.303 — Nächste sichere AETERNA-Schritte nach Formel-Infozeile
- [ ] AVAILABLE: Kuratierte lokale **Formel-Preset-Karte** um weitere musikalische Startbeispiele (z. B. Organisch / Drone) ergänzen, weiterhin nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **Automation-ready**-Hinweise direkt an ausgewählten AETERNA-Knobs kompakter machen, ohne Core-Eingriff.
- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt eine lokale **Formel-Infozeile**, die klar zwischen **Beispiel geladen**, **manuell geändert**, **angewendet** und **noch nicht angewendet** unterscheidet.

## v0.0.20.302 — Nächste sichere AETERNA-Schritte nach freigegebenen Automationszielen

- [ ] AVAILABLE: Kleine lokale **Formel-Infozeile** ergänzen, die zeigt, ob ein Startbeispiel nur im Feld steht oder bereits angewendet wurde.
- [ ] AVAILABLE: Lokale **AETERNA-Makros/Knobs** optional um eine noch kompaktere **"Automation-ready"-Kurzansicht** direkt an den Reglern ergänzen, weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Kuratierte lokale **Formel-Preset-Karte** erweitern (z. B. Organisch / Drone), weiterhin nur im AETERNA-Widget.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA zeigt jetzt klar die **bereits lokal freigegebenen stabilen Automationsziele** (Knobs, Rates, Amounts) und erklärt die sichere Nutzung per **Rechtsklick → Show Automation in Arranger**.

---

## v0.0.20.301 — Nächste sichere AETERNA-Schritte nach lokaler Automation-Zielkarte

- [ ] AVAILABLE: Kleine lokale **Formel-Infozeile** ergänzen, die erklärt, ob ein Startbeispiel erst im Feld steht oder schon angewendet wurde.
- [ ] AVAILABLE: Lokale **Formel-Preset-Hinweise** noch deutlicher mit Preset-Metadaten verknüpfen, weiterhin nur im Widget.
- [ ] AVAILABLE: Lokale **Automation-Ziele** optional um kurze Hinweise ergänzen, welche Ziele eher für langsame Sweeps und welche für lebendige Modulation sinnvoll sind.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt eine kompakte lokale **Automation-Zielkarte** mit klar benannten Gruppen und Sicherheits-Hinweis.

---

---

## v0.0.20.300 — Nächste sichere AETERNA-Schritte nach Phase 3a safe

- [ ] AVAILABLE: Lokale **Automation-Ziele** in AETERNA als kompakte, klar benannte Kurzliste/Karte sichtbar machen.
- [ ] AVAILABLE: Kleine lokale **Formel-Infozeile** ergänzen, die erklärt, ob ein Startbeispiel erst im Feld steht oder schon angewendet wurde.
- [ ] AVAILABLE: Lokale **Formel-Preset-Hinweise** noch deutlicher mit Preset-Metadaten verknüpfen, weiterhin nur im Widget.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt eine kompakte lokale **Badge-/Kurzansicht** für Preset-Metadaten direkt im Widget.

---

## v0.0.20.299 — Nächste sichere AETERNA-Phase-3a-Schritte

- [ ] AVAILABLE: Kleine lokale **Formel-Infozeile** ergänzen, die erklärt, ob ein Startbeispiel erst im Feld steht oder schon angewendet wurde.
- [ ] AVAILABLE: Lokale **Preset-Metadaten** in AETERNA noch klarer zusammenfassen (z. B. Badge-/Kurzansicht), weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Formel-Preset-Hinweise** noch deutlicher mit Preset-Metadaten verknüpfen, weiterhin nur im Widget.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt lokale **Preset-Metadaten mit Tags/Favorit**, weiterhin nur im Widget/State von AETERNA.


---

## v0.0.20.298 — Nächste sichere AETERNA-Phase-3a-Schritte

- [ ] AVAILABLE: Lokale **Formel-Makro-Slots** noch lesbarer gruppieren (z. B. Sound / Zeit / Chaos), weiterhin nur in AETERNA.
- [ ] AVAILABLE: Lokale **Preset-Metadaten** optional um Tags/Favorit erweitern, weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Kleine lokale **Formel-Infozeile** ergänzen, die erklärt, ob ein Startbeispiel erst im Feld steht oder schon angewendet wurde.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA erhielt eine lokale **Formel-Startkarte / Onboarding-Hilfe** mit sicheren Beispiel-Buttons direkt im Widget.

---

## v0.0.20.297 — Nächste sichere AETERNA-Phase-3a-Schritte

- [ ] AVAILABLE: Lokale **Formel-Startkarte / Onboarding-Hilfe** ergänzen, nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **Formel-Makro-Slots** noch lesbarer gruppieren (z. B. Sound / Zeit / Chaos), weiterhin nur in AETERNA.
- [ ] AVAILABLE: Lokale **Preset-Metadaten** optional um Tags/Favorit erweitern, weiterhin ohne Core-Eingriff.

- [x] FIXED (GPT-5, 2026-03-07): AETERNA Formel-Eingabe wieder nutzbar gemacht (**mehrzeiliges Edit-Feld**) und **lokale Preset-Metadaten** ergänzt.

---

## v0.0.20.295 — Nächste sichere AETERNA-Phase-3a-Schritte

- [ ] AVAILABLE: Lokale **Formel-Makro-Slots** noch lesbarer gruppieren (z. B. Sound / Zeit / Chaos), weiterhin nur in AETERNA.
- [ ] AVAILABLE: Lokale **Formel-Hilfe** um ein kleines Beispiel-Panel ergänzen, weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Preset-Metadaten** ergänzen (z. B. Snapshot-Info oder kleiner Kommentar), weiterhin ohne Core-Eingriff.

- [x] FIXED (GPT-5, 2026-03-06): AETERNA Phase 3a safe erweitert: **Formel-Aliase** plus **sichtbare Formel-Mod-Slots** im Widget.

---

## v0.0.20.294 — Nächste sichere AETERNA-Phase-3a-Schritte

- [ ] AVAILABLE: Lokale **Formel-Mod-Slots** lesbar ergänzen (z. B. kleine Liste der aktuell genutzten Formelquellen), weiterhin nur in AETERNA.
- [ ] AVAILABLE: Lokale **Formel-Hilfe** noch klarer machen (z. B. Wrapping-Buttons oder Makro-Snippets), weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Preset-Metadaten** ergänzen (z. B. Snapshot-Info oder kleiner Kommentar), weiterhin ohne Core-Eingriff.

- [x] FIXED (GPT-5, 2026-03-06): AETERNA Phase 3a safe erweitert: **LFO/MSEG/Chaos-Formelhilfen** per **Klick** und **Drag&Drop** direkt in die Formel.


## v0.0.20.293 — Nächste sichere AETERNA-Phase-3a-Schritte

- [ ] AVAILABLE: Lokale **Phase-3a-Ansicht** weiter vereinfachen (z. B. noch klarere Basic/Advanced-Trennung nur in AETERNA).
- [ ] AVAILABLE: Lokale **Preset-Metadaten** ergänzen (z. B. Snapshot-Info oder kleiner Kommentar), weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Automation-Listen** optional noch kompakter machen (z. B. nur lesbare Namen statt Keys), weiterhin nur im AETERNA-Widget.

- [x] FIXED (GPT-5, 2026-03-06): AETERNA Phase 3a safe erweitert: **Preset A/B** plus **klarere Automation-Zielsektionen** im Phase-3a-Bereich.


---

## v0.0.20.305 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Preset-Kurzliste/Favoritenansicht** in AETERNA ergänzen, damit sakrale/kristalline Presets schneller auffindbar sind.
- [ ] AVAILABLE: Lokale **Formula-/Preset-Verknüpfung** sichtbarer machen (z. B. welches Preset nutzt aktuell welche Formelidee), nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **Macro-A/B-Feinsteuerung** lesbarer machen, weiterhin ohne DAW-Core-Eingriff.

---

## v0.0.20.310 — Nächste sichere AETERNA-Phase-3b-Schritte

- [ ] AVAILABLE: Lokale **Web-A/Web-B-Feinmischung** um kleine Intensitätsstufen ergänzen (z. B. sanft / mittel / präsent), nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **Formel-/Web-Verknüpfung** sichtbarer machen (z. B. welche Web-Vorlage passt zu welcher Formelidee), ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Preset-/Web-Kombis** als kleine Kurztipps ergänzen, weiterhin nur in AETERNA.


## v0.0.20.313 — Nächste sichere AETERNA-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Lokale **Snapshot-Hinweise** in AETERNA weiter verdichtet: Badges, Tooltips, Recall-Status und neue **„Zuletzt: Store/Recall …“**-Hinweiszeile direkt an der Snapshot-Karte.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **Formel-/Web-Kombitipps** pro Preset ergänzt, damit der passende Startweg direkt sichtbar wird.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **Preset-/Snapshot-Kombis** als kleine Schnellaufrufe direkt im Widget sichtbar gemacht.
---

## v0.0.20.322 — Nächste sichere lokale AETERNA-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Lokale **Snapshot-Slot-Kurznamen** ergänzt (automatisch aus Preset/Hörbild abgeleitet), weiterhin nur im AETERNA-Widget.
- [ ] AVAILABLE: Lokale **Snapshot-Vergleichshinweise** kompakter machen (z. B. was sich zwischen aktivem Zustand und Recall-Slot grob ändert), ohne Engine-/Core-Eingriff.
- [ ] AVAILABLE: Lokale **Preset-/Snapshot-Schnellaufrufe** optisch feiner staffeln (z. B. aktiver Slot klarer markiert), nur im Widget.

## v0.0.20.323 — Nächste sichere lokale AETERNA-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Lokalen **AETERNA Composer** mit Dreiecks-Menü ergänzt: mathematischer Weltstil-Mix für **Bass / Melodie / Lead / Pad / Arp** direkt als MIDI-Clip auf der aktuellen AETERNA-Spur, ohne Drum-Logik und ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **AETERNA-Composer-Vergleichshinweise** ergänzen (z. B. aktuelle Stil-Mischung vs. letzter Seed), weiterhin nur im Widget/State.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-Composer-Phrasenlängen/-Dichten** feiner gestaffelt: neue lokale Phrasenprofile und Dichteprofile im Widget, weiterhin ohne Core-Eingriff.
- [ ] AVAILABLE: Lokale **Snapshot-Vergleichshinweise** mit Composer-Kontext verbinden (z. B. ob Recall eher Bass/Pad/Lead-lastig ist), weiterhin ohne Engine-/Core-Eingriff.



## v0.0.20.325 — Nächste sichere lokale AETERNA-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Lokale **AETERNA-Ladezeit sichtbar gemacht** (Build / Restore / staged Refresh) direkt im Widget, ohne globales Profiling.
- [ ] AVAILABLE: Lokale **AETERNA-Composer-Vergleichshinweise** ergänzen (z. B. aktueller Mix vs. letzter Seed), weiterhin nur im Widget/State.
- [ ] AVAILABLE: Lokale **Snapshot-Vergleichshinweise** mit Composer-Kontext verbinden (z. B. Recall eher Bass/Pad/Lead-lastig), weiterhin ohne Engine-/Core-Eingriff.
- [ ] AVAILABLE: Lokale **AETERNA-Ladeprofil-Historie** kompakt ergänzen (z. B. letzter Restore vs. aktueller Restore), weiterhin nur im Widget.


## v0.0.20.327 — Nächste sichere Bounce/Freeze- und AETERNA-Schritte

- [ ] AVAILABLE: Kleinen **Freeze-Status im Arranger-Header** sichtbar machen, weiterhin ohne Playback-Core-Umbau.
- [ ] AVAILABLE: **Bounce/Freeze-Dialog** optional um „Proxy sofort solo/selektieren“ ergänzen, nur UI-seitig.
- [ ] AVAILABLE: AETERNA lokal um noch klarere **Math-/Random-Familien-Kategorien** im Formelbereich ergänzen, weiterhin ohne Engine-Eingriff.

## v0.0.20.330 — Nächste sichere AETERNA-Synth-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Lokales **AETERNA Synth Panel Stage 1** ergänzt: vorhandene stabile Parameter lesbar gruppiert, Bereichs-Navigation hinzugefügt und sichere UI-Preview für spätere Familien reserviert.
- [x] FIXED (GPT-5, 2026-03-07): Ersten echten **Filter-Block** nur in AETERNA ergänzt (**Cutoff / Resonance / Type**) – mit lokalem UI, Save/Load, stabiler Automation sowie lokalen Mod-Rack-Zielen, weiterhin ohne DAW-Core-Umbau.
- [x] FIXED (GPT-5, 2026-03-07): Größeren **Voice-Block** in AETERNA als zusammenhängende Familie ergänzt (**Pan / Glide / Retrig / Stereo-Spread**), inklusive lokaler UI, Save/Load, stabiler Automation für die kontinuierlichen Parameter und echter Audio-Wirkung innerhalb von AETERNA.
- [x] FIXED (GPT-5, 2026-03-07): Nächste **Envelope-Familie** in AETERNA gebündelt (**AEG ADSR / FEG ADSR** als lokale UI + State + sichere Audio-Wirkung), inklusive Filter-Envelope-Amount.
- [ ] AVAILABLE: Nächsten **Unison/Sub/Noise-Block** als eigene sichere Ausbau-Familie ergänzen, lokal in AETERNA und mit klarer Einklapp-/Signalflussdarstellung.
- [ ] AVAILABLE: Danach einen **Pitch/Shape/Pulse-Width-Block** als eigene sichere Familie ergänzen, lokal in AETERNA und ohne Core-Umbau.
- [ ] AVAILABLE: Anschließend **Drive/Feedback** als separate sichere Klangfamilie ergänzen, lokal in AETERNA und mit klarer Warn-/Stabilitätstrennung.



## v0.0.20.334 — Nächste sichere AETERNA-Synth-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Gebündelten lokalen **Pitch / Shape / Pulse Width**-Block in AETERNA ergänzt — mit echter Klangwirkung, Save/Load, Randomize, stabilen Automation-Zielen und lokalen Mod-Rack-Zielen, ohne Core-Umbau.
- [x] FIXED (GPT-5, 2026-03-07): Gebündelten lokalen **Drive / Feedback**-Block in AETERNA ergänzt — mit echter Audio-Wirkung, Save/Load, Randomize, stabilen Automation-Zielen und lokalen Mod-Rack-Zielen, weiterhin nur in AETERNA.
- [ ] AVAILABLE: Lokale **AETERNA-Unison/Sub/Noise-UX** weiter verdichten (z. B. kleine Voices-/Oktav-Hinweise direkt an den Familienkarten), nur Widget/State.
- [ ] AVAILABLE: Lokale **AETERNA-Mod-Rack-Visualisierung** für die neuen Pitch/Timbre-/Drive-Ziele weiter ausbauen (z. B. stärkere Zielhervorhebung), ohne Core-Eingriff.
- [ ] AVAILABLE: Nächsten sicheren **Feinpolish-Block** für AETERNA angehen (z. B. kompaktere Familienkarten, stärkere Farbtrennung, klarere Signalfluss-Linien), weiterhin lokal im Instrument.


## v0.0.20.336 — Nächste sichere AETERNA-UX-Schritte

- [x] FIXED (GPT-5, 2026-03-07): **Layer-Schnellschalter** im AETERNA Synth Panel repariert: die bisher irreführenden Vorschau-Checkboxen für **Unison / Sub / Noise** schalten jetzt die realen Layer-Level direkt lokal an/aus.
- [x] FIXED (GPT-5, 2026-03-07): **Familienkarten** um lokale **aktive Mod-Ziel-Badges** und kompakte **Mini-Meter** ergänzt, weiterhin nur im AETERNA-Widget.
- [x] FIXED (GPT-5, 2026-03-07): Kleine **Mini-Meter direkt an einzelnen AETERNA-Synth-Knobs** ergänzt, weiterhin nur Widget/State.
- [ ] AVAILABLE: **Layer-Voices/Sub-Oktave** noch direkter in den Familienkarten hervorheben, ohne Engine-Eingriff.


## v0.0.20.337 — Nächste sichere AETERNA-ARP-/Mod-Schritte

- [x] FIXED (GPT-5, 2026-03-07): Lokalen **AETERNA Arp A (LOCAL SAFE)** ergänzt — als **Clip-Arpeggiator** nur für die aktuelle AETERNA-Spur, mit Pattern, Rate, Straight/Dotted/Triplets, 16 Steps sowie pro-Step **Transpose / Skip / Velocity / Gate**.
- [x] FIXED (GPT-5, 2026-03-07): **Per-Knob-Kontextmenü** in AETERNA erweitert: Rechtsklick bietet jetzt **Show Automation in Arranger** und **Add Modulator** (LFO1/LFO2/MSEG/Chaos/ENV/VEL) direkt für den angeklickten Ziel-Knob.
- [x] FIXED (GPT-5, 2026-03-07): Lokale **Knob-Mod-Profilzustände** pro AETERNA-Ziel ergänzt, damit jeder Knob seinen eigenen gespeicherten Mod-Zuweisungszustand behalten kann.
- [x] FIXED (GPT-5, 2026-03-07): **Readability-Polish** lokal in AETERNA verstärkt (größere Karten-/Hint-Schriften, lesbarere Signalfluss-Karte, höhere Controls).
- [ ] AVAILABLE: **Arp B** als zweite lokale AETERNA-Instanz ergänzen (erst nach Praxistest von Arp A).
- [ ] AVAILABLE: **Per-Knob-Mod-Profile** später um frei speicherbare Amount-/Polaritäts-Presets erweitern, weiterhin lokal im Widget/State.
- [x] FIXED (GPT-5, 2026-03-07): Kleine **Knob-Mini-Meter** direkt an wichtigen AETERNA-Synth-Zielen sichtbar gemacht; aktive Mod-Badges werden jetzt pro Knob kompakt angedeutet.


## v0.0.20.340 — Nächste sichere AETERNA-/Qt-Schritte

- [x] FIXED (GPT-5, 2026-03-07): **Layer-Voices/Sub-Oktave** in den AETERNA-Familienkarten deutlicher sichtbar gemacht, weiterhin nur Widget/State.
- [x] FIXED (GPT-5, 2026-03-07): Den **Qt-/Selection-Rekursionspfad** aus dem GDB-Log gezielt lokal entschärft: Refresh-/Signalguards für TrackList, Arranger-TrackList, Automation-Lanes sowie koaleszierter AETERNA-Refresh bei Live-ARP.
- [ ] AVAILABLE: Den **AETERNA-ARP-Live-Pfad** nach Praxistest weiter verhärten (z. B. noch gezieltere Diff-Erkennung der Note-FX-Params), weiterhin ohne Playback-Core-Umbau.
- [ ] AVAILABLE: Die **Layer-/Noise-Familienkarten** zusätzlich um kleine **Mode-/Voices-Badges** verdichten, weiterhin rein lokal im Widget.
