# CHANGELOG v0.0.20.457 — macOS Cross-Platform Port (ECHTE Code-Änderungen)

**Session:** v0.0.20.457
**Datum:** 2026-03-14
**Typ:** macOS-Port — alle Python-Module plattform-aware gemacht
**Basis:** v0.0.20.444 (Linux)

---

## Zusammenfassung

Die vorherige macOS-Session (v0.0.20.456) hat nur Dokumentation und einen Installer
hinzugefügt, aber **kein einziges Python-Modul** geändert. Alle 6 kritischen Probleme
(VST2, X11, Metal, LADSPA, LV2, SoundFont) existierten noch.

Diese Session behebt **alle** identifizierten Probleme durch defensive Platform-Guards.
Linux-Funktionalität bleibt 100% intakt (oberste Direktive eingehalten).

---

## ✅ Geänderte Dateien (10 Module)

### 1. `main.py` — Platform-spezifischer Startup
- **NEU:** `sys.platform == "darwin"` → setzt QT_QPA_PLATFORM=cocoa
- **INTAKT:** Wayland→xcb Fix jetzt in `elif sys.platform.startswith("linux")` Block
- Kein Verhalten auf Linux geändert

### 2. `pydaw/utils/gfx_backend.py` — Metal GPU Support
- **NEU:** `_is_macos()` Funktion
- **NEU:** `"metal"` als Backend-Option, wird auf macOS als Default gewählt
- **NEU:** `QSG_RHI_BACKEND=metal` Environment-Variable für Qt6
- **INTAKT:** Vulkan auf Linux wie bisher (gleiche Pfade, gleiche Logik)

### 3. `pydaw/audio/vst2_host.py` — macOS .vst Bundle Support
- **NEU:** `_resolve_vst2_binary(path)` — löst macOS Bundle auf:
  - `Plugin.vst/Contents/MacOS/Plugin` → Binary-Pfad
  - Fallback: Info.plist CFBundleExecutable
  - Linux .so / Windows .dll → unverändert durchgereicht
- **NEU:** `is_vst2_path(path)` — prüft ob Pfad ein VST2-Plugin ist (cross-platform)
- **GEÄNDERT:** `_Vst2Plugin.__init__` nutzt `_binary_path = _resolve_vst2_binary()`
- **GEÄNDERT:** `_Vst2Plugin._load()` lädt resolved Binary statt original Pfad
- **GEÄNDERT:** `is_vst2_instrument()` nutzt resolved Binary für Subprocess-Probe
- **INTAKT:** Alle bestehenden Linux-Plugins laden wie bisher

### 4. `pydaw/audio/audio_engine.py` — Cross-Platform VST2 Erkennung
- **GEÄNDERT:** Zeile 1854/2143: `.endswith(".so")` → `is_vst2_path()` Import
- **FALLBACK:** Bei ImportError greift alte `.so`-Prüfung (Linux bleibt funktional)
- Betrifft: Arrangement-Build und Deferred-Retry für VST-Instrumente

### 5. `pydaw/audio/ladspa_host.py` — .dylib Support
- **GEÄNDERT:** `_load_lib()` Docstring erweitert (akzeptiert .so und .dylib)
- **GEÄNDERT:** Regex `r"_(\d+)\.so$"` → `r"_(\d+)\.(?:so|dylib)$"`
- **INTAKT:** ctypes.CDLL() lädt beides transparent

### 6. `pydaw/audio/lv2_host.py` — macOS Homebrew lilv-Import
- **NEU:** macOS-Pfade im Fallback-Import:
  - `/opt/homebrew/lib/python3*/site-packages` (Apple Silicon)
  - `/usr/local/lib/python3*/site-packages` (Intel)
  - `/opt/homebrew/Cellar/lilv/*/lib/python3*/site-packages`
  - `~/Library/Python/3.*/lib/python/site-packages`
- **GEÄNDERT:** `availability_hint()` — macOS-spezifische Fix-Vorschläge:
  - `brew install lilv && pip install lilv`
  - PawPaw/DISTRHO Empfehlung
- **INTAKT:** Linux dist-packages Pfade unverändert

### 7. `pydaw/ui/x11_window_ctl.py` — Graceful No-Op auf macOS
- **NEU:** `_IS_LINUX = sys.platform.startswith("linux")` Guard
- **GEÄNDERT:** `_load_x11()` gibt sofort `None` zurück wenn nicht Linux
- **EFFEKT:** Alle x11_*-Funktionen geben [] / False / 0 auf macOS zurück
- **INTAKT:** Alle X11-Funktionen auf Linux identisch

### 8. `pydaw/ui/fx_device_widgets.py` — Cross-Platform Editor
- **GEÄNDERT:** `_Vst2EditorDialog._toggle_pin()`:
  - macOS: Qt `WindowStaysOnTopHint` (Cocoa, sicher)
  - Linux: X11 EWMH `_NET_WM_STATE_ABOVE` (wie bisher)
- **GEÄNDERT:** `_VstEditorContainer._toggle_pin()`: gleiche Logik
- **GEÄNDERT:** `_Vst2EditorDialog._restore_state()`: macOS-Branch für Pin
- **GEÄNDERT:** VST2-Erkennung: `.endswith(".so")` → `is_vst2_path()`
- **INTAKT:** Alle Editor-Fenster, Shade, Close auf Linux identisch

### 9. `pydaw/notation/audio/synth.py` — Cross-Platform SoundFont + FluidSynth
- **NEU:** `_find_default_sf2()` — sucht SF2 auf macOS + Linux:
  - macOS: `/opt/homebrew/share/soundfonts/`, `/usr/local/share/soundfonts/`
  - Linux: `/usr/share/sounds/sf2/`, `/usr/share/soundfonts/`
- **NEU:** `_fluidsynth_audio_driver()` → `coreaudio` / `pulseaudio`
- **NEU:** `_fluidsynth_midi_driver()` → `coremidi` / `alsa_seq`
- **GEÄNDERT:** FluidSynth Popen nutzt plattform-spezifische Treiber

### 10. `pydaw/notation/audio/direct_synth.py` — Cross-Platform FluidSynth
- **GEÄNDERT:** `SOUNDFONT` nutzt `_find_default_sf2()` (Import aus synth.py)
- **GEÄNDERT:** `DirectSynth.__init__` → `coreaudio` auf macOS, `pulseaudio` auf Linux

### 11. `pydaw/services/plugin_scanner.py` — Homebrew LV2 Pfade
- **GEÄNDERT:** `default_paths("darwin")` für LV2 enthält jetzt zusätzlich:
  - `/opt/homebrew/lib/lv2` (Apple Silicon Homebrew)
  - `/usr/local/lib/lv2` (Intel Homebrew)

---

## Prinzip aller Änderungen

```
if sys.platform == "darwin":
    # macOS-spezifischer Code
elif sys.platform.startswith("linux"):
    # Linux-Code (UNVERÄNDERT)
```

**Keine** bestehende Linux-Funktion wurde geändert oder entfernt.
Alle macOS-Pfade sind **zusätzlich** zu den bestehenden.

---

## Was jetzt auf macOS funktioniert

| Feature | Status | Details |
|---------|--------|---------|
| App-Start | ✅ | Cocoa QPA, Metal RHI |
| VST3 (pedalboard) | ✅ | War schon cross-platform |
| VST2 (ctypes) | ✅ NEU | .vst Bundle → Mach-O Binary Resolver |
| LV2 (lilv) | ✅ NEU | Homebrew Import-Pfade + Scan-Pfade |
| LADSPA | ⚠️ | Code OK (.dylib), aber kaum macOS-Plugins |
| DSSI | ❌ | Kein Host implementiert (war schon so) |
| FluidSynth/SF2 | ✅ NEU | CoreAudio Driver + Homebrew SF2-Pfade |
| VST2 Editor GUI | ✅ NEU | winId() auf macOS = NSView* (Cocoa) |
| Pin (Always-on-Top) | ✅ NEU | Qt WindowStaysOnTopHint (macOS) |
| Metal GPU | ✅ NEU | QSG_RHI_BACKEND=metal |

---

## NICHT geändert (wichtig!)

- Alle CHANGELOGs
- PROJECT_DOCS (TODO.md, DONE.md)
- Arranger, Clip Launcher, Piano Roll, Notation Editor
- Mixer, Device Panel, Browser
- Automation System
- AETERNA Synth
- Audio Engine Rendering-Logik
- Projekt-Dateiformat
- Kein einziger Bug eingeführt auf Linux
