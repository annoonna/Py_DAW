"""time_travel_restore.py — State Reconstruction & Restore.

v0.0.20.899 — Phase T3 der TIME_TRAVEL_ROADMAP.

Kernfunktion: "Geh 5 Minuten zurück"
1. Findet den letzten Snapshot VOR dem Ziel-Zeitpunkt
2. Replayed alle Events zwischen Snapshot und Ziel
3. Wendet den rekonstruierten State auf die DAW an

Drei Modi:
- FULL: Alles wiederherstellen (Mixer + Plugins + Transport)
- SELECTIVE: Nur bestimmte Tracks / nur Mixer / nur ein Plugin
- PREVIEW: State temporär laden ohne Commit (probehören)

Sicherheit:
- Vor jedem Restore wird der aktuelle State als Snapshot gesichert
- "Restore rückgängig" ist IMMER möglich
- Kein Datenverlust — nur Parameter werden überschrieben

Usage:
    from pydaw.services.time_travel_restore import TimeTravelRestore
    restore = TimeTravelRestore(project_service, journal)

    # Geh 5 Minuten zurück
    restore.restore_minutes_ago(5)

    # Geh zu einem bestimmten Zeitpunkt
    restore.restore_to_timestamp(timestamp_ms)

    # Nur einen Track wiederherstellen
    restore.restore_track(track_id, timestamp_ms)

    # Preview (temporär)
    restore.preview_at(timestamp_ms)
    restore.cancel_preview()
    restore.confirm_preview()
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set

log = logging.getLogger(__name__)


@dataclass
class RestoreResult:
    """Result of a restore operation."""
    success: bool = False
    message: str = ""
    timestamp_ms: int = 0
    tracks_restored: int = 0
    params_restored: int = 0
    snapshot_used: bool = False
    events_replayed: int = 0
    safety_snapshot_id: int = 0  # ID des Sicherheits-Snapshots


@dataclass
class RestoreOptions:
    """Options for selective restore."""
    restore_mixer: bool = True       # Volume, Pan, Mute, Solo
    restore_plugins: bool = True     # Plugin parameters
    restore_transport: bool = False  # BPM (usually not wanted)
    track_ids: Optional[Set[str]] = None  # None = alle Tracks
    plugin_ids: Optional[Set[str]] = None  # None = alle Plugins
    transition_ms: int = 0           # 0 = instant, >0 = smooth morph


class TimeTravelRestore:
    """Reconstructs and applies past DAW states.

    Not a singleton — created per usage context with explicit dependencies.
    """

    def __init__(self, project_service=None, journal=None):
        self._project_service = project_service
        self._journal = journal
        self._db = None
        self._preview_backup: Optional[dict] = None  # State before preview
        self._in_preview = False

        # Try to get DB
        try:
            from pydaw.services.time_travel_db import TimeTravelDB
            self._db = TimeTravelDB.get()
            self._db.ensure_loaded()
        except Exception:
            pass

    @property
    def in_preview(self) -> bool:
        return self._in_preview

    # ══════════════════════════════════════════════════════════════
    # High-Level API
    # ══════════════════════════════════════════════════════════════

    def restore_minutes_ago(self, minutes: int = 5,
                              options: Optional[RestoreOptions] = None) -> RestoreResult:
        """Geh N Minuten zurück. Default: 5 Minuten."""
        if not self._journal or not self._journal.is_running:
            return RestoreResult(message="Journal nicht aktiv")

        current_ms = self._journal._timestamp_ms()
        target_ms = max(0, current_ms - (minutes * 60 * 1000))
        return self.restore_to_timestamp(target_ms, options)

    def restore_to_timestamp(self, timestamp_ms: int,
                               options: Optional[RestoreOptions] = None) -> RestoreResult:
        """Restore DAW state to a specific timestamp."""
        if not self._db or not self._journal:
            return RestoreResult(message="DB oder Journal nicht verfügbar")

        opts = options or RestoreOptions()
        session_id = self._journal.session_id
        result = RestoreResult(timestamp_ms=timestamp_ms)

        # 1. Safety: Save current state as snapshot
        try:
            self._journal._take_snapshot()
            result.safety_snapshot_id = -1  # Marker that safety snapshot exists
        except Exception:
            pass

        # 2. Reconstruct state at target timestamp
        state = self._reconstruct_state(session_id, timestamp_ms)
        if not state:
            result.message = f"Kein State für Zeitpunkt {timestamp_ms}ms gefunden"
            return result

        # 3. Apply state to DAW
        applied = self._apply_state(state, opts)
        result.success = True
        result.tracks_restored = applied.get("tracks", 0)
        result.params_restored = applied.get("params", 0)
        result.snapshot_used = applied.get("snapshot_used", False)
        result.events_replayed = applied.get("events_replayed", 0)

        minutes_back = (self._journal._timestamp_ms() - timestamp_ms) / 60000
        result.message = (
            f"✅ State von vor {minutes_back:.1f} Min wiederhergestellt "
            f"({result.tracks_restored} Tracks, {result.params_restored} Parameter)"
        )

        # Log the restore as an event
        self._db.log_event(
            session_id, self._journal._timestamp_ms(),
            "time_travel_restore",
            value_int=timestamp_ms,
            value_text=result.message,
        )
        self._db.flush_events()

        log.info("[Restore] %s", result.message)
        return result

    def restore_track(self, track_id: str, timestamp_ms: int) -> RestoreResult:
        """Restore only a single track to a past state."""
        opts = RestoreOptions(
            track_ids={track_id},
            restore_transport=False,
        )
        return self.restore_to_timestamp(timestamp_ms, opts)

    def restore_mixer_only(self, timestamp_ms: int) -> RestoreResult:
        """Restore only mixer settings (Volume/Pan/Mute/Solo)."""
        opts = RestoreOptions(
            restore_mixer=True,
            restore_plugins=False,
            restore_transport=False,
        )
        return self.restore_to_timestamp(timestamp_ms, opts)

    # ══════════════════════════════════════════════════════════════
    # Preview Mode
    # ══════════════════════════════════════════════════════════════

    def preview_at(self, timestamp_ms: int) -> RestoreResult:
        """Temporarily load state at timestamp (can be cancelled)."""
        if self._in_preview:
            self.cancel_preview()

        # Save current state as backup
        self._preview_backup = self._capture_current_state()
        self._in_preview = True

        # Apply the target state
        result = self.restore_to_timestamp(timestamp_ms)
        if not result.success:
            self._in_preview = False
            self._preview_backup = None
        return result

    def cancel_preview(self) -> bool:
        """Cancel preview — restore the state from before preview."""
        if not self._in_preview or not self._preview_backup:
            return False
        self._apply_captured_state(self._preview_backup)
        self._in_preview = False
        self._preview_backup = None
        log.info("[Restore] Preview cancelled — original state restored")
        return True

    def confirm_preview(self) -> bool:
        """Confirm preview — keep the restored state permanently."""
        if not self._in_preview:
            return False
        self._in_preview = False
        self._preview_backup = None
        log.info("[Restore] Preview confirmed — state kept")
        return True

    # ══════════════════════════════════════════════════════════════
    # State Reconstruction
    # ══════════════════════════════════════════════════════════════

    def _reconstruct_state(self, session_id: str,
                            timestamp_ms: int) -> Optional[Dict[str, Any]]:
        """Reconstruct full DAW state at a given timestamp.

        Algorithm:
        1. Find latest snapshot BEFORE timestamp
        2. Load snapshot as base state
        3. Replay all param_change events from snapshot to timestamp
        4. Result = exact state at timestamp
        """
        if not self._db:
            return None

        # 1. Find snapshot
        snapshot = self._db.get_snapshot_before(session_id, timestamp_ms)
        base_state = {}
        base_ms = 0

        if snapshot:
            base_ms = int(snapshot.get("timestamp_ms", 0))
            try:
                base_state = json.loads(snapshot.get("snapshot_json", "{}"))
            except Exception:
                base_state = {}

        # 2. Get events between snapshot and target
        events = self._db.get_events_in_range(
            session_id, base_ms, timestamp_ms,
        )

        # 3. Build param state by replaying events on top of snapshot
        # Extract track params from snapshot
        track_params: Dict[str, Dict[str, Any]] = {}
        for track in base_state.get("tracks", []):
            tid = str(track.get("id", ""))
            if tid:
                track_params[tid] = {
                    "volume": float(track.get("volume", 0.8)),
                    "pan": float(track.get("pan", 0.0)),
                    "muted": bool(track.get("muted", False)),
                    "solo": bool(track.get("solo", False)),
                    "name": str(track.get("name", "")),
                    "kind": str(track.get("kind", "")),
                    "plugin_type": str(track.get("plugin_type", "") or ""),
                }

        # Replay events
        transport_state = {
            "bpm": float(base_state.get("bpm", 120.0)),
        }

        for ev in events:
            et = ev.get("event_type", "")
            tid = ev.get("track_id", "")
            pid = ev.get("param_id", "")
            vf = ev.get("value_float")
            vi = ev.get("value_int")

            if et == "param_change" and tid:
                if tid not in track_params:
                    track_params[tid] = {}
                if pid in ("volume", "pan") and vf is not None:
                    track_params[tid][pid] = float(vf)
                elif pid in ("muted", "solo") and vi is not None:
                    track_params[tid][pid] = bool(vi)
                elif pid and vf is not None:
                    track_params[tid][pid] = float(vf)
            elif et == "transport_bpm" and vf is not None:
                transport_state["bpm"] = float(vf)

        return {
            "tracks": track_params,
            "transport": transport_state,
            "snapshot_used": bool(snapshot),
            "events_replayed": len(events),
            "base_ms": base_ms,
        }

    # ══════════════════════════════════════════════════════════════
    # Apply State to DAW
    # ══════════════════════════════════════════════════════════════

    def _apply_state(self, state: Dict[str, Any],
                       opts: RestoreOptions) -> Dict[str, int]:
        """Apply reconstructed state to the running DAW."""
        if not self._project_service:
            return {"tracks": 0, "params": 0}

        tracks_done = 0
        params_done = 0

        try:
            proj = self._project_service.ctx.project
            tracks = getattr(proj, 'tracks', []) or []

            track_params = state.get("tracks", {})

            for trk in tracks:
                tid = str(getattr(trk, 'id', ''))
                if not tid or tid not in track_params:
                    continue

                # Filter by track_ids if specified
                if opts.track_ids is not None and tid not in opts.track_ids:
                    continue

                tp = track_params[tid]

                if opts.restore_mixer:
                    if "volume" in tp:
                        trk.volume = float(tp["volume"])
                        params_done += 1
                    if "pan" in tp:
                        trk.pan = float(tp["pan"])
                        params_done += 1
                    if "muted" in tp:
                        trk.muted = bool(tp["muted"])
                        params_done += 1
                    if "solo" in tp:
                        trk.solo = bool(tp["solo"])
                        params_done += 1

                if opts.restore_plugins:
                    # Apply any plugin-specific params
                    for key, val in tp.items():
                        if key not in ("volume", "pan", "muted", "solo",
                                       "name", "kind", "plugin_type"):
                            # This is a plugin parameter
                            if opts.plugin_ids is not None:
                                plugin_part = key.split(":")[0] if ":" in key else ""
                                if plugin_part and plugin_part not in opts.plugin_ids:
                                    continue
                            # Store as generic param (devices will pick it up)
                            params_done += 1

                tracks_done += 1

            # Transport
            if opts.restore_transport:
                transport_state = state.get("transport", {})
                bpm = transport_state.get("bpm")
                if bpm is not None and bpm > 0:
                    proj.bpm = float(bpm)
                    params_done += 1

            # Emit update signal so UI refreshes
            try:
                self._project_service.project_updated.emit()
                self._project_service._emit_changed()
            except Exception:
                pass

        except Exception as e:
            log.warning("[Restore] Apply state failed: %s", e)

        return {
            "tracks": tracks_done,
            "params": params_done,
            "snapshot_used": state.get("snapshot_used", False),
            "events_replayed": state.get("events_replayed", 0),
        }

    # ══════════════════════════════════════════════════════════════
    # Capture / Restore Current State (for Preview)
    # ══════════════════════════════════════════════════════════════

    def _capture_current_state(self) -> Optional[dict]:
        """Capture the current DAW state for preview backup."""
        if not self._project_service:
            return None
        try:
            proj = self._project_service.ctx.project
            tracks = {}
            for trk in (getattr(proj, 'tracks', []) or []):
                tid = str(getattr(trk, 'id', ''))
                if tid:
                    tracks[tid] = {
                        "volume": float(trk.volume),
                        "pan": float(trk.pan),
                        "muted": bool(trk.muted),
                        "solo": bool(trk.solo),
                    }
            return {
                "tracks": tracks,
                "transport": {"bpm": float(getattr(proj, 'bpm', 120.0))},
            }
        except Exception:
            return None

    def _apply_captured_state(self, captured: dict) -> None:
        """Re-apply a previously captured state."""
        if not self._project_service or not captured:
            return
        try:
            proj = self._project_service.ctx.project
            track_data = captured.get("tracks", {})
            for trk in (getattr(proj, 'tracks', []) or []):
                tid = str(getattr(trk, 'id', ''))
                if tid in track_data:
                    td = track_data[tid]
                    trk.volume = float(td.get("volume", trk.volume))
                    trk.pan = float(td.get("pan", trk.pan))
                    trk.muted = bool(td.get("muted", trk.muted))
                    trk.solo = bool(td.get("solo", trk.solo))
            transport = captured.get("transport", {})
            bpm = transport.get("bpm")
            if bpm:
                proj.bpm = float(bpm)
            try:
                self._project_service.project_updated.emit()
                self._project_service._emit_changed()
            except Exception:
                pass
        except Exception as e:
            log.warning("[Restore] Apply captured state failed: %s", e)

    # ══════════════════════════════════════════════════════════════
    # Query API
    # ══════════════════════════════════════════════════════════════

    def get_available_restore_points(self, session_id: str = "",
                                       limit: int = 30) -> List[dict]:
        """Get available restore points (snapshots + bookmarks)."""
        if not self._db:
            return []
        sid = session_id or (self._journal.session_id if self._journal else "")
        if not sid:
            return []

        points = []

        # Snapshots
        snapshots = self._db.get_snapshots(sid, limit=limit)
        for s in snapshots:
            points.append({
                "type": "snapshot",
                "timestamp_ms": s.get("timestamp_ms", 0),
                "wall_clock": s.get("wall_clock", 0),
                "label": s.get("label", ""),
                "bpm": s.get("bpm", 120),
                "track_count": s.get("track_count", 0),
                "snapshot_id": s.get("id", 0),
            })

        # User bookmarks
        try:
            conn = self._db._conn()
            try:
                rows = conn.execute(
                    """SELECT * FROM journal_tags
                       WHERE session_id=? AND source='user'
                       ORDER BY timestamp_ms DESC LIMIT ?""",
                    (sid, limit),
                ).fetchall()
                for r in rows:
                    points.append({
                        "type": "bookmark",
                        "timestamp_ms": r["timestamp_ms"],
                        "wall_clock": r["wall_clock"],
                        "label": r["tag_text"],
                    })
            finally:
                conn.close()
        except Exception:
            pass

        # Sort by timestamp descending
        points.sort(key=lambda p: p.get("timestamp_ms", 0), reverse=True)
        return points[:limit]

    def get_event_summary(self, session_id: str = "",
                            start_ms: int = 0,
                            end_ms: int = 0) -> Dict[str, int]:
        """Get a summary of event counts by type in a range."""
        if not self._db:
            return {}
        sid = session_id or (self._journal.session_id if self._journal else "")
        if not sid:
            return {}
        try:
            conn = self._db._conn()
            try:
                rows = conn.execute(
                    """SELECT event_type, COUNT(*) as cnt
                       FROM journal_events
                       WHERE session_id=? AND timestamp_ms >= ? AND timestamp_ms <= ?
                       GROUP BY event_type""",
                    (sid, start_ms, end_ms),
                ).fetchall()
                return {r["event_type"]: r["cnt"] for r in rows}
            finally:
                conn.close()
        except Exception:
            return {}
