"""time_travel_panel.py — Time-Travel UI Panel.

v0.0.20.899 — Phase T4 der TIME_TRAVEL_ROADMAP.

Dock-Panel mit:
- Horizontaler Timeline-Slider (letzte 5+ Minuten)
- Event-Markers (MIDI=blau, Params=orange, Plugins=grün, Bookmarks=gelb)
- "Geh 5 Min zurück" One-Click Button
- Restore-Punkte-Liste (Snapshots + Bookmarks)
- Preview Mode (probehören ohne commit)
- Bookmark-Button (Ctrl+B)

Erreichbar via:
- Menü: Projekt → 🕰️ Time Travel...
- Tastenkürzel: Ctrl+Shift+Z
"""

from __future__ import annotations

import logging
import time
from typing import List, Optional

try:
    from PyQt6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
        QSlider, QListWidget, QListWidgetItem, QGroupBox,
        QSplitter, QDockWidget, QToolButton, QSizePolicy,
    )
    from PyQt6.QtCore import Qt, QTimer, pyqtSignal
    from PyQt6.QtGui import QColor, QFont
    _QT = True
except ImportError:
    _QT = False

log = logging.getLogger(__name__)


if _QT:
    class TimeTravelPanel(QWidget):
        """Time-Travel Dock Panel — "Geh 5 Minuten zurück"."""

        status_message = pyqtSignal(str)
        restore_completed = pyqtSignal(str)  # result message

        def __init__(self, project_service=None, parent=None):
            super().__init__(parent)
            self.setObjectName("timeTravelPanel")
            self._project_service = project_service
            self._restore = None
            self._journal = None
            self._refresh_timer = QTimer(self)
            self._refresh_timer.setInterval(2000)
            self._refresh_timer.timeout.connect(self._refresh_status)
            self._build_ui()
            self._init_services()
            self._refresh_timer.start()

        def _init_services(self):
            """Lazy-init restore service and journal."""
            try:
                from pydaw.services.time_travel_journal import TimeTravelJournal
                self._journal = TimeTravelJournal.get()
            except Exception:
                pass
            try:
                from pydaw.services.time_travel_restore import TimeTravelRestore
                self._restore = TimeTravelRestore(self._project_service, self._journal)
            except Exception:
                pass

        def _build_ui(self):
            layout = QVBoxLayout(self)
            layout.setContentsMargins(6, 6, 6, 6)
            layout.setSpacing(6)

            # ── Header ──
            hdr = QHBoxLayout()
            title = QLabel("🕰️ Time Travel")
            title_font = QFont()
            title_font.setBold(True)
            title_font.setPointSize(12)
            title.setFont(title_font)
            hdr.addWidget(title)
            hdr.addStretch()

            self._lbl_status = QLabel("⏳ Initialisiere...")
            self._lbl_status.setStyleSheet("color: #888; font-size: 10px;")
            hdr.addWidget(self._lbl_status)
            layout.addLayout(hdr)

            # ── Big Action Buttons ──
            action_box = QGroupBox("Schnellaktionen")
            action_layout = QHBoxLayout(action_box)

            self._btn_5min = QPushButton("⏪ 5 Min zurück")
            self._btn_5min.setMinimumHeight(40)
            self._btn_5min.setStyleSheet(
                "QPushButton { background: #1E3A5F; color: white; font-size: 13px; "
                "font-weight: bold; border-radius: 6px; padding: 8px 16px; }"
                "QPushButton:hover { background: #2E5A8F; }"
                "QPushButton:pressed { background: #0E2A4F; }"
            )
            self._btn_5min.clicked.connect(self._on_restore_5min)
            action_layout.addWidget(self._btn_5min)

            self._btn_1min = QPushButton("⏪ 1 Min")
            self._btn_1min.setMinimumHeight(40)
            self._btn_1min.setStyleSheet(
                "QPushButton { background: #2A3A4A; color: #ccc; font-size: 11px; "
                "border-radius: 6px; padding: 8px 12px; }"
                "QPushButton:hover { background: #3A4A5A; }"
            )
            self._btn_1min.clicked.connect(lambda: self._on_restore_n_min(1))
            action_layout.addWidget(self._btn_1min)

            self._btn_3min = QPushButton("⏪ 3 Min")
            self._btn_3min.setMinimumHeight(40)
            self._btn_3min.setStyleSheet(self._btn_1min.styleSheet())
            self._btn_3min.clicked.connect(lambda: self._on_restore_n_min(3))
            action_layout.addWidget(self._btn_3min)

            self._btn_bookmark = QPushButton("⭐ Bookmark")
            self._btn_bookmark.setMinimumHeight(40)
            self._btn_bookmark.setStyleSheet(
                "QPushButton { background: #4A3A1A; color: #FFD700; font-size: 11px; "
                "border-radius: 6px; padding: 8px 12px; }"
                "QPushButton:hover { background: #5A4A2A; }"
            )
            self._btn_bookmark.clicked.connect(self._on_bookmark)
            action_layout.addWidget(self._btn_bookmark)

            layout.addWidget(action_box)

            # ── Timeline Slider ──
            slider_box = QGroupBox("Timeline (Session)")
            slider_layout = QVBoxLayout(slider_box)

            slider_row = QHBoxLayout()
            self._lbl_slider_left = QLabel("Start")
            self._lbl_slider_left.setStyleSheet("color: #666; font-size: 9px;")
            slider_row.addWidget(self._lbl_slider_left)

            self._slider = QSlider(Qt.Orientation.Horizontal)
            self._slider.setMinimum(0)
            self._slider.setMaximum(1000)
            self._slider.setValue(1000)
            self._slider.setTickPosition(QSlider.TickPosition.TicksBelow)
            self._slider.setTickInterval(100)
            self._slider.sliderReleased.connect(self._on_slider_released)
            self._slider.valueChanged.connect(self._on_slider_moved)
            slider_row.addWidget(self._slider, 1)

            self._lbl_slider_right = QLabel("Jetzt")
            self._lbl_slider_right.setStyleSheet("color: #666; font-size: 9px;")
            slider_row.addWidget(self._lbl_slider_right)
            slider_layout.addLayout(slider_row)

            self._lbl_slider_info = QLabel("")
            self._lbl_slider_info.setStyleSheet("color: #4690E6; font-size: 10px;")
            self._lbl_slider_info.setAlignment(Qt.AlignmentFlag.AlignCenter)
            slider_layout.addWidget(self._lbl_slider_info)

            layout.addWidget(slider_box)

            # ── Preview Controls ──
            preview_row = QHBoxLayout()
            self._btn_preview = QPushButton("👁️ Preview")
            self._btn_preview.setToolTip("State temporär laden (probehören)")
            self._btn_preview.clicked.connect(self._on_preview)
            preview_row.addWidget(self._btn_preview)

            self._btn_preview_ok = QPushButton("✅ Übernehmen")
            self._btn_preview_ok.setEnabled(False)
            self._btn_preview_ok.clicked.connect(self._on_preview_confirm)
            preview_row.addWidget(self._btn_preview_ok)

            self._btn_preview_cancel = QPushButton("❌ Abbrechen")
            self._btn_preview_cancel.setEnabled(False)
            self._btn_preview_cancel.clicked.connect(self._on_preview_cancel)
            preview_row.addWidget(self._btn_preview_cancel)

            layout.addLayout(preview_row)

            # ── Restore Points List ──
            list_box = QGroupBox("Wiederherstellungspunkte")
            list_layout = QVBoxLayout(list_box)

            self._restore_list = QListWidget()
            self._restore_list.setAlternatingRowColors(True)
            self._restore_list.setStyleSheet("font-size: 11px;")
            self._restore_list.itemDoubleClicked.connect(self._on_restore_point_clicked)
            list_layout.addWidget(self._restore_list)

            btn_refresh = QPushButton("🔄 Aktualisieren")
            btn_refresh.clicked.connect(self._refresh_restore_points)
            list_layout.addWidget(btn_refresh)

            layout.addWidget(list_box, 1)

            # ── Event Counter ──
            self._lbl_events = QLabel("")
            self._lbl_events.setStyleSheet("color: #555; font-size: 9px;")
            self._lbl_events.setAlignment(Qt.AlignmentFlag.AlignRight)
            layout.addWidget(self._lbl_events)

        # ══════════════════════════════════════════════════════════
        # Actions
        # ══════════════════════════════════════════════════════════

        def _on_restore_5min(self):
            self._do_restore(5)

        def _on_restore_n_min(self, n: int):
            self._do_restore(n)

        def _do_restore(self, minutes: int):
            if not self._restore:
                self._emit_status("⚠️ Restore-Service nicht verfügbar")
                return
            result = self._restore.restore_minutes_ago(minutes)
            if result.success:
                self._emit_status(result.message)
                self.restore_completed.emit(result.message)
            else:
                self._emit_status(f"⚠️ {result.message}")
            self._refresh_restore_points()

        def _on_bookmark(self):
            if self._journal and self._journal.is_running:
                self._journal.bookmark()
                self._emit_status("⭐ Bookmark gesetzt")
                self._refresh_restore_points()
            else:
                self._emit_status("⚠️ Journal nicht aktiv")

        def _on_slider_moved(self, value: int):
            """Show info while dragging the slider."""
            if not self._journal or not self._journal.is_running:
                return
            total_ms = self._journal._timestamp_ms()
            if total_ms <= 0:
                return
            target_ms = int(total_ms * value / 1000)
            secs_ago = (total_ms - target_ms) / 1000
            if secs_ago < 60:
                self._lbl_slider_info.setText(f"vor {secs_ago:.0f}s")
            else:
                self._lbl_slider_info.setText(f"vor {secs_ago / 60:.1f} min")

        def _on_slider_released(self):
            """Restore to slider position."""
            if not self._journal or not self._journal.is_running:
                return
            value = self._slider.value()
            total_ms = self._journal._timestamp_ms()
            target_ms = int(total_ms * value / 1000)
            if target_ms < total_ms - 5000:  # Only if > 5s back
                self._do_restore_to_ms(target_ms)

        def _do_restore_to_ms(self, timestamp_ms: int):
            if not self._restore:
                return
            result = self._restore.restore_to_timestamp(timestamp_ms)
            if result.success:
                self._emit_status(result.message)
                self.restore_completed.emit(result.message)
            else:
                self._emit_status(f"⚠️ {result.message}")

        # ── Preview ──

        def _on_preview(self):
            if not self._restore or not self._journal:
                return
            total_ms = self._journal._timestamp_ms()
            value = self._slider.value()
            target_ms = int(total_ms * value / 1000)
            result = self._restore.preview_at(target_ms)
            if result.success:
                self._btn_preview_ok.setEnabled(True)
                self._btn_preview_cancel.setEnabled(True)
                self._btn_preview.setEnabled(False)
                self._emit_status("👁️ Preview aktiv — probehören, dann ✅ oder ❌")
            else:
                self._emit_status(f"⚠️ {result.message}")

        def _on_preview_confirm(self):
            if self._restore:
                self._restore.confirm_preview()
                self._emit_status("✅ Preview übernommen")
            self._btn_preview_ok.setEnabled(False)
            self._btn_preview_cancel.setEnabled(False)
            self._btn_preview.setEnabled(True)

        def _on_preview_cancel(self):
            if self._restore:
                self._restore.cancel_preview()
                self._emit_status("❌ Preview abgebrochen — Originalzustand wiederhergestellt")
            self._btn_preview_ok.setEnabled(False)
            self._btn_preview_cancel.setEnabled(False)
            self._btn_preview.setEnabled(True)

        # ── Restore Points ──

        def _on_restore_point_clicked(self, item: QListWidgetItem):
            """Double-click on a restore point → restore to that time."""
            ts = item.data(Qt.ItemDataRole.UserRole)
            if ts is not None and ts > 0:
                self._do_restore_to_ms(int(ts))

        def _refresh_restore_points(self):
            self._restore_list.clear()
            if not self._restore:
                return
            points = self._restore.get_available_restore_points()
            for p in points:
                ts_ms = p.get("timestamp_ms", 0)
                label = p.get("label", "")
                ptype = p.get("type", "snapshot")
                bpm = p.get("bpm", "")

                secs = ts_ms / 1000
                mins = secs / 60

                if ptype == "bookmark":
                    icon = "⭐"
                else:
                    icon = "📸"

                text = f"{icon} {mins:.1f} min — {label}"
                if bpm:
                    text += f" ({bpm} BPM)"

                item = QListWidgetItem(text)
                item.setData(Qt.ItemDataRole.UserRole, ts_ms)
                if ptype == "bookmark":
                    item.setForeground(QColor("#FFD700"))
                else:
                    item.setForeground(QColor("#888"))
                self._restore_list.addItem(item)

        # ══════════════════════════════════════════════════════════
        # Status Updates
        # ══════════════════════════════════════════════════════════

        def _refresh_status(self):
            if not self._journal:
                self._lbl_status.setText("⚠️ Journal nicht geladen")
                return
            if not self._journal.is_running:
                self._lbl_status.setText("⏸️ Journal gestoppt")
                return

            ts_ms = self._journal._timestamp_ms()
            events = self._journal.event_count
            mins = ts_ms / 60000

            self._lbl_status.setText(f"🟢 Aktiv — {mins:.1f} min")
            self._lbl_events.setText(f"{events:,} Events geloggt")
            self._lbl_slider_left.setText("0:00")
            self._lbl_slider_right.setText(f"{mins:.1f} min")

        def _emit_status(self, text: str):
            try:
                self.status_message.emit(text)
            except Exception:
                pass
            self._lbl_slider_info.setText(text)

        def showEvent(self, event):
            super().showEvent(event)
            self._refresh_restore_points()
            self._refresh_status()

else:
    class TimeTravelPanel:  # type: ignore
        def __init__(self, *a, **kw): pass
