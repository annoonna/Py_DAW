# macOS Audio Plugins Setup (LV2 / LADSPA / VST / VST3)

Stand: 2026-03-10  
Getestet auf: Apple Silicon (M1/M2/M3/M4), macOS 13+  
Zielformat dieser Doku: Realistisch getestete Wege – keine theoretische Wunschliste.

---

## Kurzfazit

### Was auf macOS zuverlässig funktioniert

- **LV2-Basis** via Homebrew (`brew install lv2`)
- **mda-lv2** via Homebrew (`brew install mda-lv2`)
- Große Plugin-Sammlungen via **PawPaw / DISTRHO** als macOS-Paket
- **VST3 / VST2** via `pedalboard` (Spotify) – in Py_DAW integriert
- Standard LV2-Pfade: `~/Library/Audio/Plug-Ins/LV2` und `/Library/Audio/Plug-Ins/LV2`

### Was auf macOS problematisch ist

- `ladspa-sdk` via Homebrew → Linux-only, schlägt auf macOS fehl
- `swh-lv2` via david0/homebrew-audio → scheitert an Intel-Flags (`-msse`) auf Apple Silicon
- `calf` via Homebrew → Build-Fehler unter Clang/macOS
- `x42-plugins` via Homebrew → HEAD-only, instabil

---

## Begriffe kurz erklärt

| Format | Status auf macOS | Empfehlung |
|--------|-----------------|-----------|
| **LV2** | ✅ gut unterstützt via Homebrew + PawPaw | Hauptweg |
| **LADSPA** | ⚠️ kaum nutzbar (ladspa-sdk Linux-only) | Nicht empfohlen |
| **DSSI** | ⚠️ historisch, selten | Nicht empfohlen |
| **VST3** | ✅ via pedalboard (integriert in Py_DAW) | Vollständig unterstützt |
| **VST2** | ✅ via pedalboard (integriert in Py_DAW) | Vollständig unterstützt |
| **AU** | ❌ nicht geplant | - |

---

## LV2 Plugins installieren

### Schritt 1 – Zielordner anlegen

```bash
mkdir -p ~/Library/Audio/Plug-Ins/LV2
sudo mkdir -p /Library/Audio/Plug-Ins/LV2
```

### Schritt 2 – Homebrew-Basis

```bash
brew install lv2
brew install mda-lv2
```

Installation prüfen:

```bash
brew list lv2
brew list mda-lv2
brew --prefix mda-lv2
ls -l "$(brew --prefix mda-lv2)/lib/lv2"
```

### Schritt 3 – Bundles verlinken

Homebrew installiert nach `/opt/homebrew/lib/lv2/` (Apple Silicon) bzw. `/usr/local/lib/lv2/` (Intel).

```bash
# Benutzerordner
ln -snf /opt/homebrew/lib/lv2/* ~/Library/Audio/Plug-Ins/LV2/

# Systemordner (optional, für alle Benutzer)
sudo ln -snf /opt/homebrew/lib/lv2/* /Library/Audio/Plug-Ins/LV2/
```

Ergebnis prüfen:

```bash
ls -F ~/Library/Audio/Plug-Ins/LV2/
# Zeigt z.B.: mda.lv2@  core.lv2@  midi.lv2@  (@ = Symlink)
```

### Schritt 4 – Große Plugin-Sammlung via PawPaw / DISTRHO

Da viele ältere Linux-Audio-Ports auf Apple Silicon nicht kompilieren, ist dies der praktischste Weg für eine große LV2-Sammlung:

Release-Seite: https://github.com/DISTRHO/PawPaw/releases

**Bevorzugte Datei für Apple Silicon:**
```
PawPaw-macOS-universal-v1.1.0.pkg
```

Installation:
```bash
cd ~/Downloads
ls PawPaw*
sudo installer -pkg PawPaw-macOS-universal-v1.1.0.pkg -target /
```

Nach Installation prüfen:
```bash
ls /Library/Audio/Plug-Ins/LV2 | wc -l
# Typisch: 78+ Bundle-Ordner (ein Bundle kann mehrere Plugins enthalten)
```

Systemordner in Benutzerordner spiegeln (damit Hosts beide Pfade sehen):
```bash
ln -snf /Library/Audio/Plug-Ins/LV2/* ~/Library/Audio/Plug-Ins/LV2/
ls ~/Library/Audio/Plug-Ins/LV2/ | wc -l
```

---

## VST3 / VST2 Plugins

Py_DAW hostet VST3/VST2 Plugins direkt via **pedalboard** (Spotify).  
pedalboard wird via `install.py` automatisch installiert.

Standard VST3-Pfade auf macOS:
- `~/Library/Audio/Plug-Ins/VST3/` (Benutzer)
- `/Library/Audio/Plug-Ins/VST3/` (System)

Standard VST2-Pfade auf macOS:
- `~/Library/Audio/Plug-Ins/VST/`
- `/Library/Audio/Plug-Ins/VST/`

Nach Installation: **Py_DAW neu starten** und Plugin-Scan ausführen (Plugins Browser → Rescan).

---

## Gatekeeper / Sicherheitshinweise

Apple Silicon Macs blockieren ggf. Plugins ohne Apple-Signierung.

Wenn ein Plugin nicht geladen wird:

```bash
# Quarantäne-Flag entfernen (nur wenn du der Quelle vertraust)
xattr -rd com.apple.quarantine /Library/Audio/Plug-Ins/LV2/mda.lv2
```

Alternativ: Systemeinstellungen → Datenschutz & Sicherheit → App manuell erlauben.

**Wichtig:** PawPaw-Pakete sind in der Regel korrekt signiert und benötigen das meist nicht.

---

## Py_DAW Plugin-Scan-Pfade

Py_DAW scannt folgende Standard-Pfade (konfigurierbar):

**LV2:**
- `~/Library/Audio/Plug-Ins/LV2`
- `/Library/Audio/Plug-Ins/LV2`

**VST3:**
- `~/Library/Audio/Plug-Ins/VST3`
- `/Library/Audio/Plug-Ins/VST3`

**VST2:**
- `~/Library/Audio/Plug-Ins/VST`
- `/Library/Audio/Plug-Ins/VST`

Nach Änderungen an Plugin-Ordnern: DAW neu starten und Rescan.

---

## Komplette Installations-Checkliste

```bash
# 1. Ordner anlegen
mkdir -p ~/Library/Audio/Plug-Ins/LV2
sudo mkdir -p /Library/Audio/Plug-Ins/LV2

# 2. Homebrew-Basis
brew install lv2
brew install mda-lv2

# 3. Verlinken
ln -snf /opt/homebrew/lib/lv2/* ~/Library/Audio/Plug-Ins/LV2/
sudo ln -snf /opt/homebrew/lib/lv2/* /Library/Audio/Plug-Ins/LV2/

# 4. PawPaw herunterladen
# https://github.com/DISTRHO/PawPaw/releases
# → PawPaw-macOS-universal-v1.1.0.pkg

# 5. PawPaw installieren
cd ~/Downloads && ls PawPaw*
sudo installer -pkg PawPaw-macOS-universal-v1.1.0.pkg -target /

# 6. Systemordner spiegeln
ln -snf /Library/Audio/Plug-Ins/LV2/* ~/Library/Audio/Plug-Ins/LV2/

# 7. Ergebnis prüfen
ls /Library/Audio/Plug-Ins/LV2 | wc -l
ls ~/Library/Audio/Plug-Ins/LV2 | wc -l

# 8. Py_DAW neu starten + Rescan
```

---

## Was auf Apple Silicon NICHT verwenden

```bash
# Linux-only – schlägt auf macOS ab:
brew install ladspa-sdk  # NICHT verwenden

# Intel-Flags – schlägt auf ARM fehl:
brew install david0/audio/swh-lv2  # NICHT empfohlen
brew install david0/audio/calf     # NICHT empfohlen
brew install --HEAD david0/audio/x42-plugins  # NICHT empfohlen
```

---

## Nützliche Diagnosebefehle

```bash
# Homebrew-Status
brew info lv2
brew info mda-lv2

# LV2-Bundles anzeigen
ls -F ~/Library/Audio/Plug-Ins/LV2/
ls -F /Library/Audio/Plug-Ins/LV2/

# Bundle-Anzahl
ls /Library/Audio/Plug-Ins/LV2 | wc -l
ls ~/Library/Audio/Plug-Ins/LV2 | wc -l

# Plugin-Host Carla (zum Testen)
brew install carla
```

---

## Bekannte Fehlermeldungen und Bedeutung

| Fehler | Bedeutung |
|--------|-----------|
| `ladspa-sdk: Linux is required` | Korrekt – LADSPA-SDK ist Linux-only |
| `ln: No such file or directory` | Zielordner fehlt – erst `mkdir -p` ausführen |
| `unsupported option '-msse' for target 'arm64-apple-darwin'` | Intel-Only-Plugin auf Apple Silicon |
| `installer: Error - the package path specified was invalid` | Dateiname prüfen: `ls ~/Downloads/PawPaw*` |
| `Could not resolve host: github.com` | Temporärer DNS-Fehler – kurz warten, erneut versuchen |

---

*Diese Dokumentation basiert auf praktisch getesteten Verfahren aus dem Projektverlauf.*  
*Stand: v0.0.20.381*
