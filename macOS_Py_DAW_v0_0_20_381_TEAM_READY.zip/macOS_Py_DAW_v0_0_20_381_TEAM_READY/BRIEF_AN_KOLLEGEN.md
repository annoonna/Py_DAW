## Neu in v0.0.20.373
- Kleiner VST3-Widget-Hotfix: `QCheckBox`-Import ergänzt.
- Async-Fallback bleibt bestehen, macht bei `must be reloaded on the main thread` jetzt automatisch einen sicheren Main-Thread-Retry.
- Fokus blieb bewusst klein und UI-seitig.

## Update v0.0.20.370 — VST3 Widget Runtime-Param-Reuse Hotfix

- Externe **VST3/VST2-Widgets** lesen ihre Parameter jetzt bevorzugt direkt aus der **bereits laufenden DSP-Instanz**.
- Dadurch müssen Plugins wie **Autogain Mono** oder **GOTT Compressor LeftRight** im Device-Fall nicht sofort noch einmal in einem Worker-Thread geladen werden.
- Der **Async-Fallback** aus v0.0.20.368 bleibt erhalten, startet aber erst nach einem kurzen sicheren Warten auf den FX-Rebuild.

## Update v0.0.20.369 — VST3 Mono/Stereo Bus-Adapt Hotfix

- Externe **VST3/VST2 Audio-FX** passen den Main-Bus jetzt sicher zwischen internem Stereo-Host und tatsächlichem Plugin-Bus an.
- **Mono-Plugins** wie **Autogain Mono** oder **Filter Mono** laufen damit jetzt ohne wiederholten `2-channel output`-Fehler im Playback.
- Umsetzung blieb bewusst nur im **VST-Bridge-Pfad**; Mixer, Routing und DSP-Grundarchitektur wurden nicht angefasst.

## Update v0.0.20.359 — Sichtbarer DAWproject Export

- Datei-Menü zeigt jetzt **DAWproject exportieren… (.dawproject)** direkt neben dem Import.
- Export läuft weiter **snapshot-sicher im Hintergrund** und berührt die Live-Session nicht.
- Fortschritt + Summary sind bereits verdrahtet; nächster sicherer Schritt wäre nur noch QA/Optionen.

## Update v0.0.20.353 — TrackList Drop-Markierung

- Arranger-TrackList zeigt beim lokalen Maus-Reorder jetzt eine **sichtbare Drop-Markierung**.
- Nur UI-Feedback; kein Eingriff in Routing/Mixer/DSP.
- Cross-Project-Track-Drag bleibt unverändert.

# 💌 AN JEDEN KOLLEGEN - WICHTIG!

## 🎯 Was du bekommen hast:

**Eine ZIP-Datei:** `Py_DAW_v0_0_20_197_TEAM_READY.zip`

Diese enthält:
- ✅ Vollständiges DAW-Projekt
- ✅ Komplette Dokumentation
- ✅ Arbeitsplan mit TODO-Liste
- ✅ Session-Logs (was bisher gemacht wurde)
- ✅ Anleitung für dich

---

## ⚡ DEINE AUFGABE (5 Schritte):

### 1. ZIP entpacken
```bash
unzip Py_DAW_v0_0_20_196_TEAM_READY.zip
cd Py_DAW_v0_0_20_196_TEAM_READY
```

### 2. LIES DAS:
```bash
cat README_TEAM.md
# ← Hier steht ALLES was du wissen musst!
```

### 3. Analysiere Projekt
```bash
# Was wurde gemacht?
cat PROJECT_DOCS/progress/DONE.md

# Was ist zu tun?
cat PROJECT_DOCS/progress/TODO.md

# Letzter Stand?
ls -t PROJECT_DOCS/sessions/ | head -1
cat PROJECT_DOCS/sessions/2026-*_SESSION_*.md
```

### 4. Task nehmen
- Öffne `PROJECT_DOCS/progress/TODO.md`
- Suche Task mit `[ ] AVAILABLE`
- Markiere: `[x] (Dein Name, Datum)`

### 5. Arbeiten!
- Erstelle Session-Log
- Code schreiben
- Dokumentieren
- TODO/DONE updaten
- Version erhöhen
- Neue ZIP erstellen
- An nächsten Kollegen

---

## 📋 WICHTIGSTE REGELN:

1. ✅ **IMMER** in TODO.md Task markieren
2. ✅ **IMMER** Session-Log schreiben
3. ✅ **IMMER** TODO/DONE updaten
4. ✅ **IMMER** VERSION erhöhen
5. ✅ **IMMER** neue ZIP für nächsten

---

## 🎯 ZIEL:

Wir bauen eine **DAW** wie:
- Rosegarden Studio (Linux)
- Pro-DAW

**Gemeinsam, Schritt für Schritt!**

Jeder macht einen Task, dokumentiert, übergibt.

---

## 🆕 Neu in v0.0.20.198 (Kurz)

- Expression-Lane Edit Tools: **Draw / Select / Erase** (Header Buttons)
- Select: Punkt auswählen + Drag verschieben; **Del/Backspace** löscht Punkt
- Erase: Drag löscht Punkte nahe Cursor
- RMB Delete + DoubleClick Add/Delete

## 🆕 Neu in v0.0.20.197 (Kurz)

- **Note Expressions UI (opt‑in):** Expr Toggle + Param Combo im Piano‑Roll Header.
- **Triangle Interaction Model:** Hover‑Triangle, Klick‑Menu, **Alt+Drag Morph**, Doppelklick Focus (ESC exit).
- **Expression Lane (unter Piano‑Roll):** Anzeige + Draw‑Editing + Undo Snapshot.
- **Smooth Micropitch Rendering:** cubic Bezier (Bitwig‑ähnlich).

Details: `PROJECT_DOCS/plans/NOTE_EXPRESSIONS.md` und `PROJECT_DOCS/sessions/LATEST.md`.

---

## 💬 WENN DU NICHT WEITERKOMMST:

1. Siehe `README_TEAM.md` - Vollständige Anleitung
2. Siehe `PROJECT_DOCS/plans/MASTER_PLAN.md` - Übersicht
3. Siehe letzte Session-Logs - Was andere gemacht haben
4. Dokumentiere Problem in Session-Log
5. Markiere in TODO.md als "BLOCKED"
6. Übergib an nächsten Kollegen

---

**Viel Erfolg!** 🚀

**Du bist Teil eines Teams das eine echte DAW baut!**

- Neu in v0.0.19.5.1.6: Notation-Palette + Editor-Notes (Sticky Notes) (MVP).

- ✅ Notation: Tie/Slur Tool (⌒/∿) als Marker-MVP (2 Klicks) + Rendering + Save


## 🎛️ Neu in v0.0.19.7.39
- JACK-Playback nutzt jetzt eine neue `pydaw/audio/dsp_engine.py` (Mixing + Master Gain/Pan).
- Master-Volume/Pan wirkt jetzt auch im JACK/qpwgraph Pfad (wie im sounddevice-Fallback).
- UI: Drag & Drop Audio aus Browser → semitransparentes Clip-Launcher-Overlay über dem Arranger (Drop erzeugt AudioClip + Slot-Zuweisung).
