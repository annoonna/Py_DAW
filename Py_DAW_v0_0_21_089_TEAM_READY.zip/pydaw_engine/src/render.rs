use crate::audio_graph::AudioGraph;
use crate::ipc::{Event, TrackMeterLevel};
use crate::transport::Transport;

// ============================================================================
// Audio Render Loop (RA1.2) — v0.0.20.959
// ============================================================================
//
// Placeholder module for the full render pipeline.
// Currently, audio rendering is done via a simple closure in engine.rs.
// This module will be used when the full pipeline is wired up (RA2/RA3).
//
// The actual AudioGraph API:
//   graph.process()         → &AudioBuffer (master output)
//   graph.silence_all()     → silence all track buffers
//   graph.all_track_meters() → Vec<(u16, peak_l, peak_r, rms_l, rms_r)>
//   graph.master_peaks()    → (f32, f32)
//   graph.master_rms()      → (f32, f32)
//   graph.master_output     → AudioBuffer (field, not method)
// ============================================================================

/// Compute meter levels from the audio graph and send as IPC events.
///
/// Called periodically (~30Hz) from the audio callback to update
/// VU meters and playhead position in the Python GUI.
pub fn send_meter_events(
    graph: &AudioGraph,
    transport: &Transport,
    event_tx: &crossbeam_channel::Sender<Event>,
) {
    // Playhead position
    let _ = event_tx.try_send(Event::PlayheadPosition {
        beat: transport.position_beats(),
        sample_position: transport.position_samples(),
        is_playing: transport.playing.load(std::sync::atomic::Ordering::Relaxed),
    });

    // Per-track meter levels
    let meters = graph.all_track_meters();
    if !meters.is_empty() {
        let levels: Vec<TrackMeterLevel> = meters
            .iter()
            .map(|&(idx, pl, pr, rl, rr)| TrackMeterLevel {
                track_index: idx,
                peak_l: pl,
                peak_r: pr,
                rms_l: rl,
                rms_r: rr,
            })
            .collect();
        let _ = event_tx.try_send(Event::MeterLevels { levels });
    }

    // Master meter
    let (mp_l, mp_r) = graph.master_peaks();
    let (mr_l, mr_r) = graph.master_rms();
    let _ = event_tx.try_send(Event::MasterMeterLevel {
        peak_l: mp_l,
        peak_r: mp_r,
        rms_l: mr_l,
        rms_r: mr_r,
    });
}

/// Render the full audio pipeline and copy to output buffer.
///
/// This is the function that will be called from the cpal callback
/// when the full pipeline is wired up. Currently used as a reference
/// implementation.
///
/// Steps:
///   1. Silence all track buffers
///   2. Process the audio graph (FX chains, routing, mixing)
///   3. Copy master output to the cpal buffer
pub fn render_graph_to_output(
    graph: &mut AudioGraph,
    output: &mut [f32],
    channels: usize,
) {
    // Process the graph — this handles all track routing, FX, and mixing
    let master = graph.process();

    // Copy master output to cpal buffer
    let copy_len = output.len().min(master.data.len());
    output[..copy_len].copy_from_slice(&master.data[..copy_len]);

    // Zero any remaining samples
    if copy_len < output.len() {
        output[copy_len..].fill(0.0);
    }
}

/// Generate a 440Hz test sine wave.
///
/// Used by the AudioTestSine command to verify audio output works.
pub fn render_test_sine(
    output: &mut [f32],
    channels: usize,
    sample_rate: f64,
    phase: &mut f64,
) {
    let freq = 440.0_f64;
    let frames = output.len() / channels;

    for frame in 0..frames {
        let sample = (*phase * 2.0 * std::f64::consts::PI).sin() as f32 * 0.3;
        for c in 0..channels {
            output[frame * channels + c] = sample;
        }
        *phase += freq / sample_rate;
        if *phase >= 1.0 {
            *phase -= 1.0;
        }
    }
}
