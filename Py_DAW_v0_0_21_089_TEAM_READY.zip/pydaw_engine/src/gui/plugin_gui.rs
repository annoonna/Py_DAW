// ============================================================================
// Plugin GUI Hosting — RM11.8: X11/Wayland Window Embedding
// ============================================================================
//
// Manages embedding external plugin GUI windows into the DAW's UI.
//
// v0.0.20.978 — RM11.8 (Claude Opus 4.6, 2026-04-04)
// ============================================================================

use std::collections::HashMap;
use serde::{Deserialize, Serialize};
use super::app_state::Rect;

/// Platform-specific window system.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum WindowSystem {
    X11,
    Wayland,
    Unknown,
}

impl WindowSystem {
    /// Detect the current window system.
    pub fn detect() -> Self {
        // Check XDG_SESSION_TYPE or WAYLAND_DISPLAY
        if std::env::var("WAYLAND_DISPLAY").is_ok() {
            WindowSystem::Wayland
        } else if std::env::var("DISPLAY").is_ok() {
            WindowSystem::X11
        } else {
            WindowSystem::Unknown
        }
    }
}

/// DPI/scaling information.
#[derive(Debug, Clone, Copy)]
pub struct DpiInfo {
    /// Scale factor (1.0 = 96 DPI, 2.0 = 192 DPI / HiDPI)
    pub scale_factor: f64,
    /// Physical DPI
    pub dpi: f64,
    /// Whether we should use HiDPI rendering
    pub hidpi: bool,
}

impl Default for DpiInfo {
    fn default() -> Self {
        Self { scale_factor: 1.0, dpi: 96.0, hidpi: false }
    }
}

impl DpiInfo {
    /// Detect DPI from environment.
    pub fn detect() -> Self {
        // Check GDK_SCALE, QT_SCALE_FACTOR, or Xft.dpi
        let scale = std::env::var("GDK_SCALE")
            .or_else(|_| std::env::var("QT_SCALE_FACTOR"))
            .ok()
            .and_then(|s| s.parse::<f64>().ok())
            .unwrap_or(1.0);

        Self {
            scale_factor: scale,
            dpi: 96.0 * scale,
            hidpi: scale > 1.5,
        }
    }

    /// Scale a pixel value by the DPI factor.
    pub fn scale(&self, pixels: f32) -> f32 {
        pixels * self.scale_factor as f32
    }

    /// Unscale a physical pixel value.
    pub fn unscale(&self, physical_pixels: f32) -> f32 {
        physical_pixels / self.scale_factor as f32
    }
}

/// State of an embedded plugin GUI window.
#[derive(Debug, Clone)]
pub struct EmbeddedPluginWindow {
    /// Plugin instance ID
    pub instance_id: String,
    /// Plugin name (for title bar)
    pub plugin_name: String,
    /// Parent window ID (DAW's window)
    pub parent_window_id: u64,
    /// Plugin window ID (embedded child)
    pub plugin_window_id: u64,
    /// Current position and size
    pub rect: Rect,
    /// Preferred size (from plugin)
    pub preferred_width: u32,
    pub preferred_height: u32,
    /// Whether the plugin supports resizing
    pub resizable: bool,
    /// Whether the window is currently visible
    pub visible: bool,
    /// Whether the window is pinned (always on top)
    pub pinned: bool,
    /// Whether the window is collapsed (title bar only)
    pub collapsed: bool,
    /// Whether this window has keyboard focus
    pub has_focus: bool,
    /// Window system in use
    pub window_system: WindowSystem,
    /// DPI info
    pub dpi: DpiInfo,
    /// Whether embedding succeeded
    pub embedded: bool,
}

impl EmbeddedPluginWindow {
    pub fn new(instance_id: &str, plugin_name: &str) -> Self {
        let ws = WindowSystem::detect();
        let dpi = DpiInfo::detect();
        Self {
            instance_id: instance_id.to_string(),
            plugin_name: plugin_name.to_string(),
            parent_window_id: 0,
            plugin_window_id: 0,
            rect: Rect::new(100.0, 100.0, 800.0, 600.0),
            preferred_width: 800,
            preferred_height: 600,
            resizable: true,
            visible: false,
            pinned: false,
            collapsed: false,
            has_focus: false,
            window_system: ws,
            dpi,
            embedded: false,
        }
    }

    /// Set parent window for embedding.
    pub fn set_parent(&mut self, parent_id: u64) {
        self.parent_window_id = parent_id;
    }

    /// Set plugin window to embed.
    pub fn set_plugin_window(&mut self, window_id: u64) {
        self.plugin_window_id = window_id;
        self.embedded = window_id != 0;
    }

    /// Show the plugin window.
    pub fn show(&mut self) {
        self.visible = true;
    }

    /// Hide the plugin window.
    pub fn hide(&mut self) {
        self.visible = false;
        self.has_focus = false;
    }

    /// Toggle pin state.
    pub fn toggle_pin(&mut self) {
        self.pinned = !self.pinned;
    }

    /// Toggle collapsed state.
    pub fn toggle_collapse(&mut self) {
        self.collapsed = !self.collapsed;
    }

    /// Resize the window (respecting constraints).
    pub fn resize(&mut self, width: f32, height: f32) -> bool {
        if !self.resizable && self.embedded { return false; }
        self.rect.width = width.max(200.0);
        self.rect.height = height.max(100.0);
        true
    }

    /// Move the window.
    pub fn move_to(&mut self, x: f32, y: f32) {
        self.rect.x = x;
        self.rect.y = y;
    }

    /// Get the title bar height (for collapsed mode).
    pub fn title_bar_height(&self) -> f32 {
        self.dpi.scale(28.0)
    }

    /// Get actual display rect (accounting for collapse).
    pub fn display_rect(&self) -> Rect {
        if self.collapsed {
            Rect::new(self.rect.x, self.rect.y, self.rect.width, self.title_bar_height())
        } else {
            self.rect
        }
    }
}

/// Manages all embedded plugin GUI windows.
pub struct PluginWindowManager {
    /// Active plugin windows
    pub windows: HashMap<String, EmbeddedPluginWindow>,
    /// Window system
    pub window_system: WindowSystem,
    /// DPI info
    pub dpi: DpiInfo,
    /// Which window currently has focus
    pub focused_window: Option<String>,
    /// Z-order (front to back)
    pub z_order: Vec<String>,
}

impl PluginWindowManager {
    pub fn new() -> Self {
        Self {
            windows: HashMap::new(),
            window_system: WindowSystem::detect(),
            dpi: DpiInfo::detect(),
            focused_window: None,
            z_order: Vec::new(),
        }
    }

    /// Create a new plugin window.
    pub fn create_window(&mut self, instance_id: &str, plugin_name: &str) -> &mut EmbeddedPluginWindow {
        let window = EmbeddedPluginWindow::new(instance_id, plugin_name);
        self.windows.insert(instance_id.to_string(), window);
        self.z_order.push(instance_id.to_string());
        self.windows.get_mut(instance_id).unwrap()
    }

    /// Remove a plugin window.
    pub fn remove_window(&mut self, instance_id: &str) {
        self.windows.remove(instance_id);
        self.z_order.retain(|id| id != instance_id);
        if self.focused_window.as_deref() == Some(instance_id) {
            self.focused_window = None;
        }
    }

    /// Bring a window to front (focus).
    pub fn focus_window(&mut self, instance_id: &str) {
        // Remove old focus
        if let Some(ref old) = self.focused_window {
            if let Some(w) = self.windows.get_mut(old.as_str()) {
                w.has_focus = false;
            }
        }

        // Set new focus
        if let Some(w) = self.windows.get_mut(instance_id) {
            w.has_focus = true;
            self.focused_window = Some(instance_id.to_string());
        }

        // Move to front in z-order
        self.z_order.retain(|id| id != instance_id);
        self.z_order.push(instance_id.to_string());
    }

    /// Release focus from all plugin windows (return to DAW).
    pub fn release_focus(&mut self) {
        if let Some(ref id) = self.focused_window {
            if let Some(w) = self.windows.get_mut(id.as_str()) {
                w.has_focus = false;
            }
        }
        self.focused_window = None;
    }

    /// Get all visible windows in z-order (back to front).
    pub fn visible_windows(&self) -> Vec<&EmbeddedPluginWindow> {
        self.z_order.iter()
            .filter_map(|id| self.windows.get(id))
            .filter(|w| w.visible)
            .collect()
    }

    /// Hide all plugin windows.
    pub fn hide_all(&mut self) {
        for w in self.windows.values_mut() {
            w.hide();
        }
        self.focused_window = None;
    }

    /// Count visible windows.
    pub fn visible_count(&self) -> usize {
        self.windows.values().filter(|w| w.visible).count()
    }

    /// Cascade all windows (offset each by title bar height).
    pub fn cascade(&mut self) {
        let offset = 30.0;
        let mut x = 100.0;
        let mut y = 100.0;
        for id in &self.z_order.clone() {
            if let Some(w) = self.windows.get_mut(id) {
                w.move_to(x, y);
                x += offset;
                y += offset;
            }
        }
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_window_system_detect() {
        // Will return Unknown or X11 in test env
        let _ws = WindowSystem::detect();
    }

    #[test]
    fn test_dpi_scaling() {
        let dpi = DpiInfo { scale_factor: 2.0, dpi: 192.0, hidpi: true };
        assert_eq!(dpi.scale(100.0), 200.0);
        assert_eq!(dpi.unscale(200.0), 100.0);
    }

    #[test]
    fn test_embedded_window() {
        let mut win = EmbeddedPluginWindow::new("synth_1", "Super Synth");
        assert!(!win.visible);
        assert!(!win.embedded);

        win.set_plugin_window(12345);
        assert!(win.embedded);

        win.show();
        assert!(win.visible);

        win.toggle_pin();
        assert!(win.pinned);

        win.toggle_collapse();
        let dr = win.display_rect();
        assert!(dr.height < win.rect.height); // collapsed
    }

    #[test]
    fn test_window_manager() {
        let mut mgr = PluginWindowManager::new();

        mgr.create_window("p1", "Synth A");
        mgr.create_window("p2", "Reverb B");

        assert_eq!(mgr.windows.len(), 2);
        assert_eq!(mgr.visible_count(), 0);

        mgr.windows.get_mut("p1").unwrap().show();
        mgr.windows.get_mut("p2").unwrap().show();
        assert_eq!(mgr.visible_count(), 2);

        mgr.focus_window("p1");
        assert_eq!(mgr.focused_window.as_deref(), Some("p1"));
        assert!(mgr.windows["p1"].has_focus);

        mgr.focus_window("p2");
        assert!(!mgr.windows["p1"].has_focus);
        assert!(mgr.windows["p2"].has_focus);

        mgr.release_focus();
        assert!(mgr.focused_window.is_none());

        mgr.remove_window("p1");
        assert_eq!(mgr.windows.len(), 1);
    }

    #[test]
    fn test_z_order() {
        let mut mgr = PluginWindowManager::new();
        mgr.create_window("a", "A").show();
        mgr.create_window("b", "B").show();
        mgr.create_window("c", "C").show();

        // Initial order: a, b, c
        let vis = mgr.visible_windows();
        assert_eq!(vis.len(), 3);

        // Focus a → moves to front
        mgr.focus_window("a");
        assert_eq!(mgr.z_order.last().unwrap(), "a");
    }

    #[test]
    fn test_cascade() {
        let mut mgr = PluginWindowManager::new();
        mgr.create_window("a", "A");
        mgr.create_window("b", "B");
        mgr.cascade();

        let wa = &mgr.windows["a"];
        let wb = &mgr.windows["b"];
        assert!(wb.rect.x > wa.rect.x);
        assert!(wb.rect.y > wa.rect.y);
    }
}
