// ============================================================================
// Widget State — RM11.2: Framework-Independent Widget Abstractions
// ============================================================================

use serde::{Deserialize, Serialize};

/// Fader (vertical slider) state.
#[derive(Debug, Clone)]
pub struct FaderState {
    pub value: f32,      // 0.0–1.0 normalized
    pub db_value: f32,   // display in dB
    pub min_db: f32,
    pub max_db: f32,
    pub is_dragging: bool,
    pub label: String,
}

impl FaderState {
    pub fn new(label: &str, min_db: f32, max_db: f32) -> Self {
        Self { value: 0.75, db_value: 0.0, min_db, max_db, is_dragging: false, label: label.into() }
    }

    pub fn set_db(&mut self, db: f32) {
        self.db_value = db.clamp(self.min_db, self.max_db);
        self.value = (self.db_value - self.min_db) / (self.max_db - self.min_db);
    }

    pub fn set_normalized(&mut self, v: f32) {
        self.value = v.clamp(0.0, 1.0);
        self.db_value = self.min_db + self.value * (self.max_db - self.min_db);
    }

    pub fn db_display(&self) -> String {
        if self.db_value <= self.min_db + 0.5 { "-∞".into() }
        else { format!("{:.1}", self.db_value) }
    }
}

/// Knob (rotary) state.
#[derive(Debug, Clone)]
pub struct KnobState {
    pub value: f32,       // 0.0–1.0
    pub min: f32,
    pub max: f32,
    pub default: f32,
    pub is_dragging: bool,
    pub label: String,
    pub unit: String,
    pub bipolar: bool,    // center = 0
}

impl KnobState {
    pub fn new(label: &str, min: f32, max: f32, default: f32) -> Self {
        let value = (default - min) / (max - min);
        Self { value, min, max, default, is_dragging: false, label: label.into(), unit: String::new(), bipolar: false }
    }

    pub fn real_value(&self) -> f32 { self.min + self.value * (self.max - self.min) }

    pub fn set_real(&mut self, v: f32) {
        self.value = ((v - self.min) / (self.max - self.min)).clamp(0.0, 1.0);
    }

    pub fn reset(&mut self) {
        self.value = (self.default - self.min) / (self.max - self.min);
    }

    pub fn display(&self) -> String {
        if self.unit.is_empty() { format!("{:.1}", self.real_value()) }
        else { format!("{:.1} {}", self.real_value(), self.unit) }
    }
}

/// VU/Peak meter state.
#[derive(Debug, Clone, Default)]
pub struct MeterState {
    pub peak_left: f32,    // 0.0–1.0
    pub peak_right: f32,
    pub rms_left: f32,
    pub rms_right: f32,
    pub clip_left: bool,
    pub clip_right: bool,
    pub hold_left: f32,    // peak hold
    pub hold_right: f32,
}

impl MeterState {
    pub fn update(&mut self, peak_l: f32, peak_r: f32, rms_l: f32, rms_r: f32) {
        self.peak_left = peak_l;
        self.peak_right = peak_r;
        self.rms_left = rms_l;
        self.rms_right = rms_r;
        if peak_l > self.hold_left { self.hold_left = peak_l; }
        if peak_r > self.hold_right { self.hold_right = peak_r; }
        self.clip_left = self.clip_left || peak_l >= 1.0;
        self.clip_right = self.clip_right || peak_r >= 1.0;
    }

    /// Decay peak hold (call per frame).
    pub fn decay_hold(&mut self, rate: f32) {
        self.hold_left = (self.hold_left - rate).max(self.peak_left);
        self.hold_right = (self.hold_right - rate).max(self.peak_right);
    }

    pub fn clear_clip(&mut self) {
        self.clip_left = false;
        self.clip_right = false;
    }
}

/// Toggle button state.
#[derive(Debug, Clone)]
pub struct ToggleState {
    pub active: bool,
    pub label: String,
    pub tooltip: String,
}

impl ToggleState {
    pub fn new(label: &str, active: bool) -> Self {
        Self { active, label: label.into(), tooltip: String::new() }
    }
    pub fn toggle(&mut self) { self.active = !self.active; }
}

/// Dropdown/ComboBox state.
#[derive(Debug, Clone)]
pub struct DropdownState {
    pub selected: usize,
    pub items: Vec<String>,
    pub is_open: bool,
    pub label: String,
}

impl DropdownState {
    pub fn new(label: &str, items: Vec<String>) -> Self {
        Self { selected: 0, items, is_open: false, label: label.into() }
    }
    pub fn selected_text(&self) -> &str {
        self.items.get(self.selected).map(|s| s.as_str()).unwrap_or("")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_fader() {
        let mut f = FaderState::new("Volume", -60.0, 12.0);
        f.set_db(0.0);
        assert!((f.value - 0.833).abs() < 0.01);
        f.set_db(-60.0);
        assert_eq!(f.db_display(), "-∞");
        f.set_db(6.0);
        assert_eq!(f.db_display(), "6.0");
    }

    #[test]
    fn test_knob() {
        let mut k = KnobState::new("Pan", -1.0, 1.0, 0.0);
        assert!((k.real_value() - 0.0).abs() < 0.01);
        k.set_real(0.5);
        assert!((k.real_value() - 0.5).abs() < 0.01);
        k.reset();
        assert!((k.real_value() - 0.0).abs() < 0.01);
    }

    #[test]
    fn test_meter() {
        let mut m = MeterState::default();
        m.update(0.8, 0.6, 0.5, 0.4);
        assert_eq!(m.hold_left, 0.8);
        m.update(0.3, 0.2, 0.2, 0.1);
        assert_eq!(m.hold_left, 0.8); // hold stays
        m.update(1.0, 0.5, 0.5, 0.3);
        assert!(m.clip_left);
        m.clear_clip();
        assert!(!m.clip_left);
    }
}
