// ============================================================================
// Piano Roll State — RM11.4: Note Canvas Logic
// ============================================================================

use super::app_state::Rect;
use serde::{Deserialize, Serialize};

/// Visual state of the piano roll editor.
#[derive(Debug, Clone)]
pub struct PianoRollState {
    /// Horizontal zoom (pixels per beat)
    pub pixels_per_beat: f64,
    /// Vertical zoom (pixels per note row)
    pub note_height: f32,
    /// Scroll position (beats)
    pub scroll_x_beats: f64,
    /// Scroll position (MIDI note, 0=C-2, 127=G8)
    pub scroll_y_note: u8,
    /// Viewport rect
    pub viewport: Rect,
    /// Keyboard width in pixels
    pub keyboard_width: f32,
    /// Visible notes
    pub notes: Vec<NoteVisual>,
    /// Ghost notes (from other clips)
    pub ghost_notes: Vec<NoteVisual>,
    /// Currently editing clip ID
    pub clip_id: Option<String>,
    /// Velocity editor height (0 = hidden)
    pub velocity_height: f32,
    /// Note range (lowest visible)
    pub note_range_low: u8,
    /// Note range (highest visible)
    pub note_range_high: u8,
    /// Show velocity bars
    pub show_velocity: bool,
    /// Show expression lanes
    pub show_expression: bool,
}

impl Default for PianoRollState {
    fn default() -> Self {
        Self {
            pixels_per_beat: 80.0,
            note_height: 12.0,
            scroll_x_beats: 0.0,
            scroll_y_note: 36, // C2
            viewport: Rect::new(0.0, 0.0, 800.0, 500.0),
            keyboard_width: 60.0,
            notes: Vec::new(),
            ghost_notes: Vec::new(),
            clip_id: None,
            velocity_height: 60.0,
            note_range_low: 21,  // A0
            note_range_high: 108, // C8
            show_velocity: true,
            show_expression: false,
        }
    }
}

impl PianoRollState {
    /// Convert beat to pixel X.
    pub fn beat_to_x(&self, beat: f64) -> f32 {
        self.keyboard_width + ((beat - self.scroll_x_beats) * self.pixels_per_beat) as f32
    }

    /// Convert pixel X to beat.
    pub fn x_to_beat(&self, x: f32) -> f64 {
        (x - self.keyboard_width) as f64 / self.pixels_per_beat + self.scroll_x_beats
    }

    /// Convert MIDI note to pixel Y (higher notes = higher on screen).
    pub fn note_to_y(&self, note: u8) -> f32 {
        let rows_from_top = (self.note_range_high as f32 - note as f32);
        rows_from_top * self.note_height - self.scroll_y_note as f32 * self.note_height
    }

    /// Convert pixel Y to MIDI note.
    pub fn y_to_note(&self, y: f32) -> u8 {
        let adjusted = y + self.scroll_y_note as f32 * self.note_height;
        let note = self.note_range_high as f32 - adjusted / self.note_height;
        (note as u8).clamp(0, 127)
    }

    /// Get note rect for display.
    pub fn note_rect(&self, note: u8, start_beat: f64, length_beats: f64) -> Rect {
        let x = self.beat_to_x(start_beat);
        let y = self.note_to_y(note);
        let w = (length_beats * self.pixels_per_beat) as f32;
        Rect::new(x, y, w, self.note_height - 1.0)
    }

    /// Hit test: find note at pixel position.
    pub fn note_at(&self, x: f32, y: f32) -> Option<usize> {
        self.notes.iter().position(|n| n.rect.contains(x, y))
    }

    /// Is this a black key?
    pub fn is_black_key(note: u8) -> bool {
        matches!(note % 12, 1 | 3 | 6 | 8 | 10)
    }

    /// Note name string (e.g., "C4", "F#3").
    pub fn note_name(note: u8) -> String {
        let names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
        let octave = (note / 12) as i8 - 2;
        format!("{}{}", names[(note % 12) as usize], octave)
    }

    /// Update note visuals from note data.
    pub fn update_notes(&mut self, notes: &[NoteInfo]) {
        self.notes.clear();
        for note in notes {
            let rect = self.note_rect(note.pitch, note.start_beat, note.length_beats);
            self.notes.push(NoteVisual {
                rect,
                pitch: note.pitch,
                velocity: note.velocity,
                start_beat: note.start_beat,
                length_beats: note.length_beats,
                selected: note.selected,
                muted: note.muted,
            });
        }
    }

    /// Zoom in vertically.
    pub fn zoom_in_vertical(&mut self) {
        self.note_height = (self.note_height * 1.25).min(30.0);
    }

    /// Zoom out vertically.
    pub fn zoom_out_vertical(&mut self) {
        self.note_height = (self.note_height / 1.25).max(4.0);
    }
}

/// Visual representation of a MIDI note.
#[derive(Debug, Clone)]
pub struct NoteVisual {
    pub rect: Rect,
    pub pitch: u8,
    pub velocity: u8,
    pub start_beat: f64,
    pub length_beats: f64,
    pub selected: bool,
    pub muted: bool,
}

/// Input note data.
#[derive(Debug, Clone)]
pub struct NoteInfo {
    pub pitch: u8,
    pub velocity: u8,
    pub start_beat: f64,
    pub length_beats: f64,
    pub selected: bool,
    pub muted: bool,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_beat_pixel_conversion() {
        let state = PianoRollState::default();
        let x = state.beat_to_x(1.0);
        let beat = state.x_to_beat(x);
        assert!((beat - 1.0).abs() < 0.001);
    }

    #[test]
    fn test_note_name() {
        assert_eq!(PianoRollState::note_name(60), "C3");
        assert_eq!(PianoRollState::note_name(69), "A3");
        assert_eq!(PianoRollState::note_name(0), "C-2");
    }

    #[test]
    fn test_black_key() {
        assert!(!PianoRollState::is_black_key(60));  // C
        assert!(PianoRollState::is_black_key(61));   // C#
        assert!(!PianoRollState::is_black_key(64));   // E
        assert!(PianoRollState::is_black_key(66));   // F#
    }

    #[test]
    fn test_note_hit_test() {
        let mut state = PianoRollState::default();
        let notes = vec![NoteInfo {
            pitch: 60, velocity: 100, start_beat: 0.0, length_beats: 1.0, selected: false, muted: false,
        }];
        state.update_notes(&notes);
        assert_eq!(state.notes.len(), 1);

        let note_rect = &state.notes[0].rect;
        assert!(state.note_at(note_rect.center_x(), note_rect.center_y()).is_some());
    }

    #[test]
    fn test_zoom_vertical() {
        let mut state = PianoRollState::default();
        let h_before = state.note_height;
        state.zoom_in_vertical();
        assert!(state.note_height > h_before);
        state.zoom_out_vertical();
        assert!((state.note_height - h_before).abs() < 0.1);
    }
}
