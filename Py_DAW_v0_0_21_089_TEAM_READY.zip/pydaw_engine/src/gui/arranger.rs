// ============================================================================
// Arranger State — RM11.3: Timeline Canvas Logic
// ============================================================================

use std::collections::HashMap;
use serde::{Deserialize, Serialize};
use super::app_state::Rect;

/// Visual state of the arranger timeline.
#[derive(Debug, Clone)]
pub struct ArrangerState {
    /// Horizontal zoom (pixels per beat)
    pub pixels_per_beat: f64,
    /// Vertical zoom (pixels per track)
    pub track_height: f32,
    /// Scroll position (beats)
    pub scroll_x_beats: f64,
    /// Scroll position (pixels from top)
    pub scroll_y: f32,
    /// Visible area (set by layout)
    pub viewport: Rect,
    /// Track headers
    pub tracks: Vec<TrackHeaderState>,
    /// Visible clips (clip_id → visual rect)
    pub clip_rects: HashMap<String, ClipVisual>,
    /// Playhead position (beats)
    pub playhead_beat: f64,
    /// Loop region
    pub loop_start: f64,
    pub loop_end: f64,
    pub loop_active: bool,
    /// Cursor beat (mouse hover position)
    pub cursor_beat: f64,
    /// Cursor track index
    pub cursor_track: Option<usize>,
    /// Ruler height in pixels
    pub ruler_height: f32,
    /// Whether to show automation lanes
    pub show_automation: bool,
    /// Zoom range limits
    pub min_ppb: f64,
    pub max_ppb: f64,
}

impl Default for ArrangerState {
    fn default() -> Self {
        Self {
            pixels_per_beat: 40.0,
            track_height: 60.0,
            scroll_x_beats: 0.0,
            scroll_y: 0.0,
            viewport: Rect::new(0.0, 0.0, 1000.0, 600.0),
            tracks: Vec::new(),
            clip_rects: HashMap::new(),
            playhead_beat: 0.0,
            loop_start: 0.0,
            loop_end: 4.0,
            loop_active: false,
            cursor_beat: 0.0,
            cursor_track: None,
            ruler_height: 24.0,
            show_automation: false,
            min_ppb: 5.0,
            max_ppb: 400.0,
        }
    }
}

impl ArrangerState {
    /// Convert beat position to pixel X coordinate.
    pub fn beat_to_x(&self, beat: f64) -> f32 {
        ((beat - self.scroll_x_beats) * self.pixels_per_beat) as f32
    }

    /// Convert pixel X to beat position.
    pub fn x_to_beat(&self, x: f32) -> f64 {
        x as f64 / self.pixels_per_beat + self.scroll_x_beats
    }

    /// Convert track index to pixel Y coordinate.
    pub fn track_to_y(&self, track_index: usize) -> f32 {
        self.ruler_height + track_index as f32 * self.track_height - self.scroll_y
    }

    /// Find which track is at pixel Y.
    pub fn y_to_track(&self, y: f32) -> Option<usize> {
        if y < self.ruler_height { return None; }
        let adjusted = y - self.ruler_height + self.scroll_y;
        let idx = (adjusted / self.track_height) as usize;
        if idx < self.tracks.len() { Some(idx) } else { None }
    }

    /// Zoom in horizontally (centered on a beat position).
    pub fn zoom_in(&mut self, center_beat: f64) {
        let new_ppb = (self.pixels_per_beat * 1.25).min(self.max_ppb);
        self.zoom_to(new_ppb, center_beat);
    }

    /// Zoom out horizontally.
    pub fn zoom_out(&mut self, center_beat: f64) {
        let new_ppb = (self.pixels_per_beat / 1.25).max(self.min_ppb);
        self.zoom_to(new_ppb, center_beat);
    }

    fn zoom_to(&mut self, new_ppb: f64, center_beat: f64) {
        let center_x = (center_beat - self.scroll_x_beats) * self.pixels_per_beat;
        self.pixels_per_beat = new_ppb;
        self.scroll_x_beats = center_beat - center_x / new_ppb;
        if self.scroll_x_beats < 0.0 { self.scroll_x_beats = 0.0; }
    }

    /// Zoom to fit the entire project in the viewport.
    pub fn zoom_fit(&mut self, total_beats: f64) {
        if total_beats > 0.0 {
            self.pixels_per_beat = (self.viewport.width as f64 / total_beats).clamp(self.min_ppb, self.max_ppb);
            self.scroll_x_beats = 0.0;
        }
    }

    /// Scroll to make the playhead visible.
    pub fn ensure_playhead_visible(&mut self) {
        let px = self.beat_to_x(self.playhead_beat);
        let margin = self.viewport.width * 0.1;
        if px < margin {
            self.scroll_x_beats = self.playhead_beat - margin as f64 / self.pixels_per_beat;
        } else if px > self.viewport.width - margin {
            self.scroll_x_beats = self.playhead_beat - (self.viewport.width - margin) as f64 / self.pixels_per_beat;
        }
        if self.scroll_x_beats < 0.0 { self.scroll_x_beats = 0.0; }
    }

    /// Recalculate visible clip rectangles.
    pub fn update_clip_rects(&mut self, clips: &[ClipInfo]) {
        self.clip_rects.clear();
        let visible_start = self.scroll_x_beats;
        let visible_end = self.scroll_x_beats + self.viewport.width as f64 / self.pixels_per_beat;

        for clip in clips {
            if clip.end_beat < visible_start || clip.start_beat > visible_end { continue; }
            if clip.track_index >= self.tracks.len() { continue; }

            let x = self.beat_to_x(clip.start_beat);
            let w = ((clip.end_beat - clip.start_beat) * self.pixels_per_beat) as f32;
            let y = self.track_to_y(clip.track_index) + 2.0;
            let h = self.track_height - 4.0;

            self.clip_rects.insert(clip.clip_id.clone(), ClipVisual {
                rect: Rect::new(x, y, w, h),
                clip_id: clip.clip_id.clone(),
                track_index: clip.track_index,
                is_audio: clip.is_audio,
                color_index: clip.color_index,
                name: clip.name.clone(),
                selected: clip.selected,
            });
        }
    }

    /// Hit test: find clip at pixel position.
    pub fn clip_at(&self, x: f32, y: f32) -> Option<&ClipVisual> {
        self.clip_rects.values().find(|cv| cv.rect.contains(x, y))
    }

    /// Visible beat range.
    pub fn visible_beats(&self) -> (f64, f64) {
        let start = self.scroll_x_beats;
        let end = start + self.viewport.width as f64 / self.pixels_per_beat;
        (start, end)
    }

    /// Total content height.
    pub fn content_height(&self) -> f32 {
        self.ruler_height + self.tracks.len() as f32 * self.track_height
    }
}

/// Track header visual state.
#[derive(Debug, Clone)]
pub struct TrackHeaderState {
    pub track_id: String,
    pub name: String,
    pub color_index: u8,
    pub muted: bool,
    pub solo: bool,
    pub armed: bool,
    pub volume_db: f32,
    pub pan: f32,
    pub kind: String, // "audio", "instrument", "group", "master", "fx"
    pub collapsed: bool,
    pub height_override: Option<f32>,
}

/// Info about a clip (input for rect calculation).
#[derive(Debug, Clone)]
pub struct ClipInfo {
    pub clip_id: String,
    pub track_index: usize,
    pub start_beat: f64,
    pub end_beat: f64,
    pub name: String,
    pub is_audio: bool,
    pub color_index: u8,
    pub selected: bool,
}

/// Visual representation of a clip on the timeline.
#[derive(Debug, Clone)]
pub struct ClipVisual {
    pub rect: Rect,
    pub clip_id: String,
    pub track_index: usize,
    pub is_audio: bool,
    pub color_index: u8,
    pub name: String,
    pub selected: bool,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_beat_pixel_conversion() {
        let state = ArrangerState { pixels_per_beat: 40.0, scroll_x_beats: 0.0, ..Default::default() };
        assert_eq!(state.beat_to_x(1.0), 40.0);
        assert!((state.x_to_beat(40.0) - 1.0).abs() < 0.001);

        // With scroll
        let state2 = ArrangerState { pixels_per_beat: 40.0, scroll_x_beats: 4.0, ..Default::default() };
        assert_eq!(state2.beat_to_x(4.0), 0.0);
        assert_eq!(state2.beat_to_x(5.0), 40.0);
    }

    #[test]
    fn test_track_y_conversion() {
        let mut state = ArrangerState::default();
        state.tracks = vec![
            TrackHeaderState { track_id: "t1".into(), name: "Track 1".into(), color_index: 0, muted: false, solo: false, armed: false, volume_db: 0.0, pan: 0.0, kind: "audio".into(), collapsed: false, height_override: None },
            TrackHeaderState { track_id: "t2".into(), name: "Track 2".into(), color_index: 1, muted: false, solo: false, armed: false, volume_db: 0.0, pan: 0.0, kind: "instrument".into(), collapsed: false, height_override: None },
        ];
        let y0 = state.track_to_y(0);
        let y1 = state.track_to_y(1);
        assert!(y1 > y0);
        assert_eq!(state.y_to_track(y0 + 5.0), Some(0));
        assert_eq!(state.y_to_track(y1 + 5.0), Some(1));
    }

    #[test]
    fn test_zoom() {
        let mut state = ArrangerState::default();
        let ppb_before = state.pixels_per_beat;
        state.zoom_in(0.0);
        assert!(state.pixels_per_beat > ppb_before);
        state.zoom_out(0.0);
        assert!((state.pixels_per_beat - ppb_before).abs() < 0.1);
    }

    #[test]
    fn test_clip_hit_test() {
        let mut state = ArrangerState::default();
        state.tracks = vec![
            TrackHeaderState { track_id: "t1".into(), name: "T1".into(), color_index: 0, muted: false, solo: false, armed: false, volume_db: 0.0, pan: 0.0, kind: "audio".into(), collapsed: false, height_override: None },
        ];
        let clips = vec![ClipInfo {
            clip_id: "c1".into(), track_index: 0,
            start_beat: 0.0, end_beat: 4.0,
            name: "Clip 1".into(), is_audio: true, color_index: 0, selected: false,
        }];
        state.update_clip_rects(&clips);
        assert!(state.clip_at(20.0, state.track_to_y(0) + 10.0).is_some());
        assert!(state.clip_at(500.0, state.track_to_y(0) + 10.0).is_none()); // past clip
    }
}
