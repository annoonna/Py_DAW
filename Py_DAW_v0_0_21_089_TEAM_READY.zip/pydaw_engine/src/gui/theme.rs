// ============================================================================
// Theme System — RM11.2: Dark/Light/Custom Themes
// ============================================================================

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct Color {
    pub r: u8, pub g: u8, pub b: u8, pub a: u8,
}

impl Color {
    pub const fn rgb(r: u8, g: u8, b: u8) -> Self { Self { r, g, b, a: 255 } }
    pub const fn rgba(r: u8, g: u8, b: u8, a: u8) -> Self { Self { r, g, b, a } }
    pub fn to_f32(&self) -> [f32; 4] {
        [self.r as f32 / 255.0, self.g as f32 / 255.0, self.b as f32 / 255.0, self.a as f32 / 255.0]
    }
    pub fn with_alpha(&self, a: u8) -> Self { Self { a, ..*self } }
    pub fn lerp(&self, other: &Color, t: f32) -> Color {
        let t = t.clamp(0.0, 1.0);
        Color {
            r: (self.r as f32 + (other.r as f32 - self.r as f32) * t) as u8,
            g: (self.g as f32 + (other.g as f32 - self.g as f32) * t) as u8,
            b: (self.b as f32 + (other.b as f32 - self.b as f32) * t) as u8,
            a: (self.a as f32 + (other.a as f32 - self.a as f32) * t) as u8,
        }
    }
}

/// Track colors for visual identification.
pub const TRACK_COLORS: [Color; 16] = [
    Color::rgb(66, 133, 244),   // Blue
    Color::rgb(234, 67, 53),    // Red
    Color::rgb(52, 168, 83),    // Green
    Color::rgb(251, 188, 4),    // Yellow
    Color::rgb(171, 71, 188),   // Purple
    Color::rgb(0, 172, 193),    // Cyan
    Color::rgb(255, 112, 67),   // Orange
    Color::rgb(126, 87, 194),   // Deep Purple
    Color::rgb(38, 166, 154),   // Teal
    Color::rgb(236, 64, 122),   // Pink
    Color::rgb(121, 134, 203),  // Indigo
    Color::rgb(174, 213, 129),  // Light Green
    Color::rgb(255, 183, 77),   // Amber
    Color::rgb(77, 182, 172),   // Medium Teal
    Color::rgb(255, 138, 128),  // Salmon
    Color::rgb(149, 117, 205),  // Medium Purple
];

/// Complete theme definition.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Theme {
    pub name: String,
    // Window
    pub bg_primary: Color,
    pub bg_secondary: Color,
    pub bg_tertiary: Color,
    pub bg_hover: Color,
    pub bg_selected: Color,
    pub bg_header: Color,
    // Text
    pub text_primary: Color,
    pub text_secondary: Color,
    pub text_disabled: Color,
    pub text_accent: Color,
    // Borders
    pub border: Color,
    pub border_focus: Color,
    // Accent
    pub accent: Color,
    pub accent_hover: Color,
    pub accent_active: Color,
    // Transport
    pub play_green: Color,
    pub record_red: Color,
    pub stop_gray: Color,
    // Meters
    pub meter_green: Color,
    pub meter_yellow: Color,
    pub meter_red: Color,
    pub meter_bg: Color,
    // Arranger
    pub clip_audio: Color,
    pub clip_midi: Color,
    pub clip_automation: Color,
    pub playhead: Color,
    pub grid_line: Color,
    pub grid_bar: Color,
    // Piano Roll
    pub note_color: Color,
    pub note_selected: Color,
    pub black_key_bg: Color,
    pub white_key_bg: Color,
    // Scrollbar
    pub scrollbar_bg: Color,
    pub scrollbar_thumb: Color,
    // Typography
    pub font_size_small: f32,
    pub font_size_normal: f32,
    pub font_size_large: f32,
    pub font_size_header: f32,
}

impl Theme {
    pub fn dark() -> Self {
        Self {
            name: "Dark".into(),
            bg_primary: Color::rgb(30, 30, 30),
            bg_secondary: Color::rgb(42, 42, 42),
            bg_tertiary: Color::rgb(55, 55, 55),
            bg_hover: Color::rgb(65, 65, 65),
            bg_selected: Color::rgb(50, 80, 120),
            bg_header: Color::rgb(25, 25, 25),
            text_primary: Color::rgb(220, 220, 220),
            text_secondary: Color::rgb(160, 160, 160),
            text_disabled: Color::rgb(90, 90, 90),
            text_accent: Color::rgb(100, 180, 255),
            border: Color::rgb(60, 60, 60),
            border_focus: Color::rgb(100, 180, 255),
            accent: Color::rgb(66, 133, 244),
            accent_hover: Color::rgb(90, 155, 255),
            accent_active: Color::rgb(40, 110, 220),
            play_green: Color::rgb(76, 175, 80),
            record_red: Color::rgb(244, 67, 54),
            stop_gray: Color::rgb(158, 158, 158),
            meter_green: Color::rgb(76, 175, 80),
            meter_yellow: Color::rgb(255, 235, 59),
            meter_red: Color::rgb(244, 67, 54),
            meter_bg: Color::rgb(20, 20, 20),
            clip_audio: Color::rgb(76, 175, 80),
            clip_midi: Color::rgb(100, 150, 255),
            clip_automation: Color::rgb(255, 152, 0),
            playhead: Color::rgb(255, 255, 255),
            grid_line: Color::rgba(80, 80, 80, 100),
            grid_bar: Color::rgba(100, 100, 100, 150),
            note_color: Color::rgb(100, 180, 255),
            note_selected: Color::rgb(255, 200, 50),
            black_key_bg: Color::rgb(35, 35, 35),
            white_key_bg: Color::rgb(50, 50, 50),
            scrollbar_bg: Color::rgb(25, 25, 25),
            scrollbar_thumb: Color::rgb(80, 80, 80),
            font_size_small: 10.0,
            font_size_normal: 13.0,
            font_size_large: 16.0,
            font_size_header: 20.0,
        }
    }

    pub fn light() -> Self {
        Self {
            name: "Light".into(),
            bg_primary: Color::rgb(245, 245, 245),
            bg_secondary: Color::rgb(235, 235, 235),
            bg_tertiary: Color::rgb(225, 225, 225),
            bg_hover: Color::rgb(215, 215, 215),
            bg_selected: Color::rgb(180, 210, 255),
            bg_header: Color::rgb(250, 250, 250),
            text_primary: Color::rgb(30, 30, 30),
            text_secondary: Color::rgb(100, 100, 100),
            text_disabled: Color::rgb(180, 180, 180),
            text_accent: Color::rgb(30, 100, 200),
            border: Color::rgb(200, 200, 200),
            border_focus: Color::rgb(66, 133, 244),
            accent: Color::rgb(66, 133, 244),
            accent_hover: Color::rgb(50, 115, 220),
            accent_active: Color::rgb(30, 90, 200),
            play_green: Color::rgb(56, 142, 60),
            record_red: Color::rgb(211, 47, 47),
            stop_gray: Color::rgb(117, 117, 117),
            meter_green: Color::rgb(56, 142, 60),
            meter_yellow: Color::rgb(245, 127, 23),
            meter_red: Color::rgb(211, 47, 47),
            meter_bg: Color::rgb(210, 210, 210),
            clip_audio: Color::rgb(56, 142, 60),
            clip_midi: Color::rgb(66, 133, 244),
            clip_automation: Color::rgb(230, 126, 34),
            playhead: Color::rgb(30, 30, 30),
            grid_line: Color::rgba(180, 180, 180, 100),
            grid_bar: Color::rgba(150, 150, 150, 150),
            note_color: Color::rgb(66, 133, 244),
            note_selected: Color::rgb(255, 160, 0),
            black_key_bg: Color::rgb(235, 235, 235),
            white_key_bg: Color::rgb(250, 250, 250),
            scrollbar_bg: Color::rgb(230, 230, 230),
            scrollbar_thumb: Color::rgb(180, 180, 180),
            font_size_small: 10.0,
            font_size_normal: 13.0,
            font_size_large: 16.0,
            font_size_header: 20.0,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_color_ops() {
        let c = Color::rgb(255, 128, 0);
        let f = c.to_f32();
        assert!((f[0] - 1.0).abs() < 0.01);
        assert!((f[1] - 0.502).abs() < 0.01);

        let c2 = c.with_alpha(128);
        assert_eq!(c2.a, 128);

        let white = Color::rgb(255, 255, 255);
        let black = Color::rgb(0, 0, 0);
        let mid = white.lerp(&black, 0.5);
        assert!((mid.r as f32 - 127.5).abs() < 1.0);
    }

    #[test]
    fn test_themes() {
        let dark = Theme::dark();
        assert_eq!(dark.name, "Dark");
        assert!(dark.bg_primary.r < 50);

        let light = Theme::light();
        assert!(light.bg_primary.r > 200);
    }
}
