// ============================================================================
// Additional GUI Panels — RM11.7
// ============================================================================
//
// State management for all remaining GUI panels:
//   - Clip Launcher (Ableton-style grid)
//   - Sample/File Browser + Drag&Drop
//   - Preset Browser
//   - Audio Editor (Waveform + Warp)
//   - Notation Editor (stub)
//   - Plugin Browser
//   - Collaboration Panel
//   - KI-Assistent Panel
//   - Settings Dialog
//   - About Dialog
//
// v0.0.20.978 — RM11.7 (Claude Opus 4.6, 2026-04-04)
// ============================================================================

use std::collections::HashMap;
use serde::{Deserialize, Serialize};
use super::app_state::Rect;
use super::theme::Color;

// ============================================================================
// Clip Launcher (Ableton-Style Grid)
// ============================================================================

/// Clip launcher grid state.
#[derive(Debug, Clone)]
pub struct ClipLauncherState {
    /// Grid cells [col][row] (col = track, row = scene)
    pub cells: Vec<Vec<LauncherCell>>,
    /// Number of visible columns (tracks)
    pub num_cols: usize,
    /// Number of visible rows (scenes)
    pub num_rows: usize,
    /// Cell width
    pub cell_width: f32,
    /// Cell height
    pub cell_height: f32,
    /// Currently playing scene index
    pub playing_scene: Option<usize>,
    /// Scene names
    pub scene_names: Vec<String>,
    /// Scroll offset (column)
    pub scroll_col: usize,
    /// Scroll offset (row)
    pub scroll_row: usize,
}

#[derive(Debug, Clone, Default)]
pub struct LauncherCell {
    pub clip_id: Option<String>,
    pub name: String,
    pub color: u8,
    pub state: CellState,
    pub has_content: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Default, Serialize, Deserialize)]
pub enum CellState {
    #[default]
    Empty,
    Stopped,
    Playing,
    Recording,
    Queued,
}

impl Default for ClipLauncherState {
    fn default() -> Self {
        Self {
            cells: vec![vec![LauncherCell::default(); 8]; 8],
            num_cols: 8, num_rows: 8,
            cell_width: 100.0, cell_height: 40.0,
            playing_scene: None,
            scene_names: (1..=8).map(|i| format!("Scene {}", i)).collect(),
            scroll_col: 0, scroll_row: 0,
        }
    }
}

impl ClipLauncherState {
    pub fn get_cell(&self, col: usize, row: usize) -> Option<&LauncherCell> {
        self.cells.get(col).and_then(|c| c.get(row))
    }

    pub fn set_cell_state(&mut self, col: usize, row: usize, state: CellState) {
        if let Some(cell) = self.cells.get_mut(col).and_then(|c| c.get_mut(row)) {
            cell.state = state;
        }
    }

    pub fn launch_scene(&mut self, row: usize) {
        self.playing_scene = Some(row);
        for col in 0..self.num_cols {
            if let Some(cell) = self.cells.get_mut(col).and_then(|c| c.get_mut(row)) {
                if cell.has_content { cell.state = CellState::Playing; }
            }
        }
    }

    pub fn stop_all(&mut self) {
        self.playing_scene = None;
        for col in &mut self.cells {
            for cell in col {
                if cell.state == CellState::Playing { cell.state = CellState::Stopped; }
            }
        }
    }
}

// ============================================================================
// Sample/File Browser
// ============================================================================

#[derive(Debug, Clone)]
pub struct BrowserState {
    /// Current directory path
    pub current_path: String,
    /// Directory entries
    pub entries: Vec<BrowserEntry>,
    /// Selected entry index
    pub selected: Option<usize>,
    /// Search query
    pub search_query: String,
    /// Filter by file type
    pub file_filter: FileFilter,
    /// Favorites/bookmarks
    pub bookmarks: Vec<String>,
    /// Preview playing
    pub previewing: bool,
    /// Preview file path
    pub preview_path: Option<String>,
    /// Sort order
    pub sort_by: BrowserSort,
    /// Show hidden files
    pub show_hidden: bool,
}

#[derive(Debug, Clone)]
pub struct BrowserEntry {
    pub name: String,
    pub path: String,
    pub is_dir: bool,
    pub size_bytes: u64,
    pub file_type: FileType,
    pub is_favorite: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum FileType { Audio, Midi, Video, Project, Preset, Plugin, Image, Other }

#[derive(Debug, Clone, Copy, PartialEq, Default, Serialize, Deserialize)]
pub enum FileFilter { #[default] All, Audio, Midi, Video, Presets, Plugins }

#[derive(Debug, Clone, Copy, PartialEq, Default, Serialize, Deserialize)]
pub enum BrowserSort { #[default] NameAsc, NameDesc, SizeAsc, SizeDesc, TypeAsc }

impl Default for BrowserState {
    fn default() -> Self {
        Self {
            current_path: String::new(), entries: Vec::new(),
            selected: None, search_query: String::new(),
            file_filter: FileFilter::All, bookmarks: Vec::new(),
            previewing: false, preview_path: None,
            sort_by: BrowserSort::NameAsc, show_hidden: false,
        }
    }
}

// ============================================================================
// Preset Browser
// ============================================================================

#[derive(Debug, Clone)]
pub struct PresetBrowserState {
    /// Current plugin ID
    pub plugin_id: Option<String>,
    /// Categories
    pub categories: Vec<String>,
    /// Selected category
    pub selected_category: Option<String>,
    /// Presets in current view
    pub presets: Vec<PresetEntry>,
    /// Selected preset index
    pub selected_preset: Option<usize>,
    /// Search query
    pub search_query: String,
    /// Show favorites only
    pub favorites_only: bool,
    /// A/B comparison active
    pub ab_active: bool,
    /// Current A/B slot
    pub ab_slot: u8, // 0=A, 1=B
}

#[derive(Debug, Clone)]
pub struct PresetEntry {
    pub id: String,
    pub name: String,
    pub category: String,
    pub is_factory: bool,
    pub is_favorite: bool,
    pub rating: u8,
}

impl Default for PresetBrowserState {
    fn default() -> Self {
        Self {
            plugin_id: None, categories: Vec::new(),
            selected_category: None, presets: Vec::new(),
            selected_preset: None, search_query: String::new(),
            favorites_only: false, ab_active: false, ab_slot: 0,
        }
    }
}

// ============================================================================
// Audio Editor (Waveform + Warp)
// ============================================================================

#[derive(Debug, Clone)]
pub struct AudioEditorState {
    /// Pixels per second (horizontal zoom)
    pub pixels_per_second: f64,
    /// Scroll X (seconds)
    pub scroll_x: f64,
    /// Viewport
    pub viewport: Rect,
    /// Waveform data (downsampled peaks for display, L channel)
    pub waveform_peaks_l: Vec<f32>,
    /// Waveform data (R channel)
    pub waveform_peaks_r: Vec<f32>,
    /// Duration in seconds
    pub duration: f64,
    /// Sample rate
    pub sample_rate: u32,
    /// Selection range (start_sec, end_sec)
    pub selection: Option<(f64, f64)>,
    /// Warp markers
    pub warp_markers: Vec<WarpMarkerVisual>,
    /// Current stretch mode
    pub stretch_mode: String,
    /// Show spectral view
    pub show_spectrogram: bool,
}

#[derive(Debug, Clone)]
pub struct WarpMarkerVisual {
    pub beat_position: f64,
    pub sample_position: f64,
    pub is_anchor: bool,
    pub selected: bool,
}

impl Default for AudioEditorState {
    fn default() -> Self {
        Self {
            pixels_per_second: 100.0, scroll_x: 0.0,
            viewport: Rect::new(0.0, 0.0, 800.0, 200.0),
            waveform_peaks_l: Vec::new(), waveform_peaks_r: Vec::new(),
            duration: 0.0, sample_rate: 44100, selection: None,
            warp_markers: Vec::new(), stretch_mode: "Tones".into(),
            show_spectrogram: false,
        }
    }
}

// ============================================================================
// Plugin Browser
// ============================================================================

#[derive(Debug, Clone)]
pub struct PluginBrowserState {
    /// All scanned plugins
    pub plugins: Vec<PluginBrowserEntry>,
    /// Search query
    pub search_query: String,
    /// Filter by format
    pub format_filter: Option<String>, // "VST3", "CLAP", "LV2", None=All
    /// Filter by type
    pub type_filter: PluginTypeFilter,
    /// Selected plugin index
    pub selected: Option<usize>,
    /// Sort order
    pub sort_by: PluginSort,
    /// Show favorites only
    pub favorites_only: bool,
}

#[derive(Debug, Clone)]
pub struct PluginBrowserEntry {
    pub id: String,
    pub name: String,
    pub vendor: String,
    pub format: String,
    pub is_instrument: bool,
    pub is_effect: bool,
    pub is_favorite: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Default, Serialize, Deserialize)]
pub enum PluginTypeFilter { #[default] All, Instruments, Effects }

#[derive(Debug, Clone, Copy, PartialEq, Default, Serialize, Deserialize)]
pub enum PluginSort { #[default] NameAsc, VendorAsc, FormatAsc }

impl Default for PluginBrowserState {
    fn default() -> Self {
        Self {
            plugins: Vec::new(), search_query: String::new(),
            format_filter: None, type_filter: PluginTypeFilter::All,
            selected: None, sort_by: PluginSort::NameAsc, favorites_only: false,
        }
    }
}

// ============================================================================
// Collaboration Panel
// ============================================================================

#[derive(Debug, Clone)]
pub struct CollabPanelState {
    /// Is connected to a session
    pub connected: bool,
    /// Session ID
    pub session_id: Option<String>,
    /// Connected peers
    pub peers: Vec<CollabPeerVisual>,
    /// Chat messages
    pub chat_messages: Vec<ChatMessageVisual>,
    /// Chat input text
    pub chat_input: String,
    /// Server address
    pub server_address: String,
    /// Server port
    pub server_port: u16,
}

#[derive(Debug, Clone)]
pub struct CollabPeerVisual {
    pub name: String,
    pub color: Color,
    pub cursor_beat: f64,
    pub locked_tracks: Vec<String>,
    pub is_self: bool,
}

#[derive(Debug, Clone)]
pub struct ChatMessageVisual {
    pub sender: String,
    pub message: String,
    pub timestamp: String,
    pub is_self: bool,
}

impl Default for CollabPanelState {
    fn default() -> Self {
        Self {
            connected: false, session_id: None, peers: Vec::new(),
            chat_messages: Vec::new(), chat_input: String::new(),
            server_address: "localhost".into(), server_port: 9876,
        }
    }
}

// ============================================================================
// KI-Assistent Panel
// ============================================================================

#[derive(Debug, Clone)]
pub struct KiAssistantState {
    /// Chat history
    pub messages: Vec<KiMessage>,
    /// Current input
    pub input: String,
    /// Is KI processing
    pub processing: bool,
    /// Available KI tools
    pub tools: Vec<KiTool>,
    /// Selected tool
    pub active_tool: Option<String>,
}

#[derive(Debug, Clone)]
pub struct KiMessage {
    pub role: String, // "user" or "assistant"
    pub content: String,
    pub timestamp: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KiTool {
    pub id: String,
    pub name: String,
    pub description: String,
    pub icon: String,
}

impl Default for KiAssistantState {
    fn default() -> Self {
        Self {
            messages: Vec::new(), input: String::new(), processing: false,
            tools: vec![
                KiTool { id: "melody".into(), name: "Melody Generator".into(), description: "Generate melodies".into(), icon: "🎵".into() },
                KiTool { id: "chord".into(), name: "Chord Suggest".into(), description: "Suggest chord progressions".into(), icon: "🎹".into() },
                KiTool { id: "drum".into(), name: "Drum Pattern".into(), description: "Generate drum patterns".into(), icon: "🥁".into() },
                KiTool { id: "mix".into(), name: "Mix Assistant".into(), description: "Analyze and suggest mix improvements".into(), icon: "🎚️".into() },
                KiTool { id: "master".into(), name: "Master Check".into(), description: "Check mastering levels".into(), icon: "📊".into() },
            ],
            active_tool: None,
        }
    }
}

// ============================================================================
// Settings Dialog
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SettingsState {
    /// Audio settings
    pub audio_device: String,
    pub sample_rate: u32,
    pub buffer_size: u32,
    pub audio_backend: String,
    /// MIDI settings
    pub midi_input_devices: Vec<String>,
    pub midi_output_devices: Vec<String>,
    /// Paths
    pub project_default_path: String,
    pub plugin_paths: Vec<String>,
    pub sample_paths: Vec<String>,
    /// Appearance
    pub theme_name: String,
    pub ui_scale: f32,
    pub show_tooltips: bool,
    /// Engine
    pub use_rust_engine: bool,
    pub rust_engine_mode: String, // "off", "hybrid", "full"
    /// Recording
    pub record_format: String,
    pub record_bit_depth: u32,
    /// Current settings page
    pub active_page: SettingsPage,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum SettingsPage { Audio, Midi, Paths, Appearance, Engine, Recording, About }

impl Default for SettingsState {
    fn default() -> Self {
        Self {
            audio_device: "Default".into(), sample_rate: 44100, buffer_size: 512,
            audio_backend: "PipeWire".into(),
            midi_input_devices: Vec::new(), midi_output_devices: Vec::new(),
            project_default_path: "~/Music/Py_DAW".into(),
            plugin_paths: vec!["/usr/lib/vst3".into(), "/usr/lib/clap".into(), "/usr/lib/lv2".into()],
            sample_paths: Vec::new(),
            theme_name: "Dark".into(), ui_scale: 1.0, show_tooltips: true,
            use_rust_engine: true, rust_engine_mode: "hybrid".into(),
            record_format: "WAV".into(), record_bit_depth: 24,
            active_page: SettingsPage::Audio,
        }
    }
}

// ============================================================================
// About Dialog
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AboutState {
    pub app_name: String,
    pub version: String,
    pub build_date: String,
    pub rust_engine_version: String,
    pub license: String,
    pub website: String,
    pub credits: Vec<String>,
}

impl Default for AboutState {
    fn default() -> Self {
        Self {
            app_name: "Py_DAW (ChronoScaleStudio)".into(),
            version: "0.0.20.978".into(),
            build_date: "2026-04-04".into(),
            rust_engine_version: "0.1.0".into(),
            license: "GPL-3.0".into(),
            website: "https://github.com/annoonna/Py-DAW-Studio".into(),
            credits: vec![
                "Anno (Lead Developer)".into(),
                "Claude Opus 4.6 (AI Assistant)".into(),
                "UKNS UG, Leipzig".into(),
            ],
        }
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_clip_launcher() {
        let mut launcher = ClipLauncherState::default();
        launcher.cells[0][0].has_content = true;
        launcher.cells[0][0].name = "Drums A".into();
        launcher.cells[1][0].has_content = true;

        launcher.launch_scene(0);
        assert_eq!(launcher.playing_scene, Some(0));
        assert_eq!(launcher.cells[0][0].state, CellState::Playing);

        launcher.stop_all();
        assert_eq!(launcher.cells[0][0].state, CellState::Stopped);
        assert_eq!(launcher.playing_scene, None);
    }

    #[test]
    fn test_browser() {
        let browser = BrowserState::default();
        assert_eq!(browser.file_filter, FileFilter::All);
        assert!(!browser.previewing);
    }

    #[test]
    fn test_settings() {
        let settings = SettingsState::default();
        assert_eq!(settings.sample_rate, 44100);
        assert_eq!(settings.buffer_size, 512);
        assert_eq!(settings.theme_name, "Dark");
    }

    #[test]
    fn test_about() {
        let about = AboutState::default();
        assert!(about.app_name.contains("Py_DAW"));
        assert_eq!(about.license, "GPL-3.0");
    }

    #[test]
    fn test_ki_assistant() {
        let ki = KiAssistantState::default();
        assert_eq!(ki.tools.len(), 5);
        assert!(!ki.processing);
    }

    #[test]
    fn test_collab_panel() {
        let collab = CollabPanelState::default();
        assert!(!collab.connected);
        assert_eq!(collab.server_port, 9876);
    }
}
