// ============================================================================
// Layout Manager — RM11.2: Dock/Panel System
// ============================================================================

use serde::{Deserialize, Serialize};
use super::app_state::Rect;

/// Panel dock position.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum DockPosition { Left, Right, Top, Bottom, Center, Floating }

/// A dockable panel.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DockPanel {
    pub id: String,
    pub title: String,
    pub position: DockPosition,
    pub visible: bool,
    pub rect: Rect,
    pub min_width: f32,
    pub min_height: f32,
    pub closable: bool,
    pub detached: bool,
    /// For floating: which monitor (0-based)
    pub monitor: u32,
}

/// Layout preset (saveable arrangement of panels).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LayoutPreset {
    pub name: String,
    pub panels: Vec<DockPanel>,
}

/// Layout manager for the entire application window.
#[derive(Debug, Clone)]
pub struct LayoutManager {
    pub panels: Vec<DockPanel>,
    pub presets: Vec<LayoutPreset>,
    pub window_width: f32,
    pub window_height: f32,
    pub left_width: f32,
    pub right_width: f32,
    pub bottom_height: f32,
    pub header_height: f32,
}

impl LayoutManager {
    pub fn new(width: f32, height: f32) -> Self {
        Self {
            panels: Self::default_panels(),
            presets: vec![],
            window_width: width,
            window_height: height,
            left_width: 250.0,
            right_width: 300.0,
            bottom_height: 250.0,
            header_height: 80.0,
        }
    }

    fn default_panels() -> Vec<DockPanel> {
        vec![
            DockPanel { id: "browser".into(), title: "Browser".into(), position: DockPosition::Left, visible: true, rect: Rect::default(), min_width: 200.0, min_height: 100.0, closable: true, detached: false, monitor: 0 },
            DockPanel { id: "arranger".into(), title: "Arranger".into(), position: DockPosition::Center, visible: true, rect: Rect::default(), min_width: 400.0, min_height: 200.0, closable: false, detached: false, monitor: 0 },
            DockPanel { id: "mixer".into(), title: "Mixer".into(), position: DockPosition::Bottom, visible: true, rect: Rect::default(), min_width: 400.0, min_height: 150.0, closable: true, detached: false, monitor: 0 },
            DockPanel { id: "inspector".into(), title: "Inspector".into(), position: DockPosition::Right, visible: false, rect: Rect::default(), min_width: 200.0, min_height: 100.0, closable: true, detached: false, monitor: 0 },
            DockPanel { id: "pianoroll".into(), title: "Piano Roll".into(), position: DockPosition::Bottom, visible: false, rect: Rect::default(), min_width: 400.0, min_height: 200.0, closable: true, detached: false, monitor: 0 },
        ]
    }

    /// Recalculate all panel rectangles based on window size and dock positions.
    pub fn layout(&mut self) {
        let left_w = if self.panel_visible("browser") { self.left_width } else { 0.0 };
        let right_w = if self.panel_visible("inspector") { self.right_width } else { 0.0 };
        let bottom_h = if self.any_bottom_visible() { self.bottom_height } else { 0.0 };
        let center_x = left_w;
        let center_w = (self.window_width - left_w - right_w).max(100.0);
        let center_h = (self.window_height - self.header_height - bottom_h).max(100.0);

        for panel in &mut self.panels {
            if panel.detached { continue; }
            panel.rect = match panel.position {
                DockPosition::Left => Rect::new(0.0, self.header_height, left_w, center_h + bottom_h),
                DockPosition::Right => Rect::new(self.window_width - right_w, self.header_height, right_w, center_h + bottom_h),
                DockPosition::Top => Rect::new(0.0, 0.0, self.window_width, self.header_height),
                DockPosition::Bottom => Rect::new(center_x, self.header_height + center_h, center_w, bottom_h),
                DockPosition::Center => Rect::new(center_x, self.header_height, center_w, center_h),
                DockPosition::Floating => panel.rect, // keep current
            };
        }
    }

    pub fn panel_visible(&self, id: &str) -> bool {
        self.panels.iter().any(|p| p.id == id && p.visible)
    }

    fn any_bottom_visible(&self) -> bool {
        self.panels.iter().any(|p| p.position == DockPosition::Bottom && p.visible)
    }

    pub fn toggle_panel(&mut self, id: &str) {
        if let Some(p) = self.panels.iter_mut().find(|p| p.id == id) {
            p.visible = !p.visible;
        }
        self.layout();
    }

    pub fn resize(&mut self, width: f32, height: f32) {
        self.window_width = width;
        self.window_height = height;
        self.layout();
    }

    pub fn get_panel_rect(&self, id: &str) -> Option<Rect> {
        self.panels.iter().find(|p| p.id == id).map(|p| p.rect)
    }

    /// Save current layout as a preset.
    pub fn save_preset(&mut self, name: &str) {
        self.presets.push(LayoutPreset { name: name.into(), panels: self.panels.clone() });
    }

    /// Restore a layout preset.
    pub fn load_preset(&mut self, name: &str) -> bool {
        if let Some(preset) = self.presets.iter().find(|p| p.name == name) {
            self.panels = preset.panels.clone();
            self.layout();
            true
        } else { false }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_layout() {
        let mut lm = LayoutManager::new(1920.0, 1080.0);
        lm.layout();
        let arr = lm.get_panel_rect("arranger").unwrap();
        assert!(arr.width > 400.0);
        assert!(arr.height > 200.0);
    }

    #[test]
    fn test_toggle_panel() {
        let mut lm = LayoutManager::new(1920.0, 1080.0);
        assert!(lm.panel_visible("browser"));
        lm.toggle_panel("browser");
        assert!(!lm.panel_visible("browser"));
    }

    #[test]
    fn test_resize() {
        let mut lm = LayoutManager::new(1920.0, 1080.0);
        lm.layout();
        lm.resize(1280.0, 720.0);
        let arr = lm.get_panel_rect("arranger").unwrap();
        assert!(arr.width < 1920.0);
    }
}
