// ============================================================================
// Mixer State — RM11.5: Channel Strips & Routing
// ============================================================================

use super::widgets::{FaderState, KnobState, MeterState, ToggleState};
use serde::{Deserialize, Serialize};

/// A single mixer channel strip.
#[derive(Debug, Clone)]
pub struct ChannelStrip {
    pub track_id: String,
    pub name: String,
    pub kind: String,
    pub color_index: u8,
    pub fader: FaderState,
    pub pan: KnobState,
    pub meter: MeterState,
    pub mute: ToggleState,
    pub solo: ToggleState,
    pub arm: ToggleState,
    pub fx_slots: Vec<FxSlotState>,
    pub sends: Vec<SendState>,
    pub selected: bool,
    pub width: f32,
}

impl ChannelStrip {
    pub fn new(track_id: &str, name: &str, kind: &str, color_index: u8) -> Self {
        Self {
            track_id: track_id.into(),
            name: name.into(),
            kind: kind.into(),
            color_index,
            fader: FaderState::new("Vol", -60.0, 12.0),
            pan: KnobState::new("Pan", -1.0, 1.0, 0.0),
            meter: MeterState::default(),
            mute: ToggleState::new("M", false),
            solo: ToggleState::new("S", false),
            arm: ToggleState::new("R", false),
            fx_slots: Vec::new(),
            sends: Vec::new(),
            selected: false,
            width: 80.0,
        }
    }
}

/// FX slot in the mixer.
#[derive(Debug, Clone)]
pub struct FxSlotState {
    pub slot_index: u8,
    pub name: String,
    pub enabled: bool,
    pub bypassed: bool,
}

/// Send to an FX/group bus.
#[derive(Debug, Clone)]
pub struct SendState {
    pub target_id: String,
    pub target_name: String,
    pub amount: KnobState,
    pub pre_fader: bool,
}

/// Complete mixer state.
#[derive(Debug, Clone)]
pub struct MixerState {
    pub strips: Vec<ChannelStrip>,
    pub master: Option<ChannelStrip>,
    pub scroll_x: f32,
    pub narrow_mode: bool,
    pub show_sends: bool,
    pub show_fx: bool,
    pub selected_strip: Option<usize>,
}

impl MixerState {
    pub fn new() -> Self {
        Self {
            strips: Vec::new(),
            master: None,
            scroll_x: 0.0,
            narrow_mode: false,
            show_sends: true,
            show_fx: true,
            selected_strip: None,
        }
    }

    pub fn add_strip(&mut self, strip: ChannelStrip) {
        self.strips.push(strip);
    }

    pub fn strip_by_track(&self, track_id: &str) -> Option<&ChannelStrip> {
        self.strips.iter().find(|s| s.track_id == track_id)
    }

    pub fn strip_by_track_mut(&mut self, track_id: &str) -> Option<&mut ChannelStrip> {
        self.strips.iter_mut().find(|s| s.track_id == track_id)
    }

    /// Total width of all strips.
    pub fn total_width(&self) -> f32 {
        let w: f32 = self.strips.iter().map(|s| s.width).sum();
        w + if self.master.is_some() { 100.0 } else { 0.0 }
    }

    /// Update meters from engine data.
    pub fn update_meters(&mut self, track_id: &str, peak_l: f32, peak_r: f32, rms_l: f32, rms_r: f32) {
        if let Some(strip) = self.strip_by_track_mut(track_id) {
            strip.meter.update(peak_l, peak_r, rms_l, rms_r);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mixer_state() {
        let mut mixer = MixerState::new();
        mixer.add_strip(ChannelStrip::new("t1", "Drums", "audio", 0));
        mixer.add_strip(ChannelStrip::new("t2", "Bass", "instrument", 1));
        assert_eq!(mixer.strips.len(), 2);
        assert!(mixer.strip_by_track("t1").is_some());
    }

    #[test]
    fn test_meter_update() {
        let mut mixer = MixerState::new();
        mixer.add_strip(ChannelStrip::new("t1", "Track 1", "audio", 0));
        mixer.update_meters("t1", 0.8, 0.6, 0.5, 0.4);
        let strip = mixer.strip_by_track("t1").unwrap();
        assert_eq!(strip.meter.peak_left, 0.8);
    }
}
