// ============================================================================
// Py_DAW GUI Module — RM11: Framework-Independent GUI Layer
// ============================================================================
//
// This module provides a framework-independent GUI application layer.
// All state management, layout logic, and widget abstractions are pure Rust
// with no dependency on any specific GUI framework.
//
// The final GUI framework (egui/iced/slint) will implement thin adapters
// that render using these state structures.
//
// Modules:
//   app_state  — Central application state (project, transport, selection)
//   theme      — Theme system (Dark/Light/Custom, color palette)
//   layout     — Dock/panel layout manager (like Qt docking)
//   input      — Keyboard shortcuts, mouse state, gesture detection
//   widgets    — Widget state abstractions (faders, knobs, meters)
//   arranger   — Arranger/timeline canvas state and hit-testing
//   mixer      — Mixer channel strip state
//   pianoroll  — Piano roll editor state
//
// v0.0.20.977 — RM11.1-11.5 (Claude Opus 4.6, 2026-04-04)
// ============================================================================

pub mod app_state;
pub mod theme;
pub mod layout;
pub mod input;
pub mod widgets;
pub mod arranger;
pub mod mixer;
pub mod pianoroll;
pub mod video_editor;   // v0.0.20.978: RM11.6 — Video NLE GUI
pub mod panels;         // v0.0.20.978: RM11.7 — Clip Launcher, Browser, Settings, etc.
pub mod plugin_gui;     // v0.0.20.978: RM11.8 — Plugin GUI Hosting (X11/Wayland)
