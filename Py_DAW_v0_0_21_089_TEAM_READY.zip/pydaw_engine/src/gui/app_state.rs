// ============================================================================
// App State — RM11.2: Central GUI Application State
// ============================================================================

use std::collections::HashMap;
use serde::{Deserialize, Serialize};

/// Top-level application state — drives the entire GUI.
#[derive(Debug, Clone)]
pub struct AppState {
    /// Currently open projects (tabs)
    pub projects: Vec<ProjectTab>,
    /// Active project index
    pub active_project: usize,
    /// Transport state
    pub transport: TransportState,
    /// Global selection
    pub selection: SelectionState,
    /// Active panel/view
    pub active_panel: PanelType,
    /// Whether the app is in full-screen mode
    pub fullscreen: bool,
    /// Whether the left browser panel is visible
    pub browser_visible: bool,
    /// Whether the bottom panel (mixer/editor) is visible
    pub bottom_panel_visible: bool,
    /// Current tool
    pub current_tool: Tool,
    /// Snap settings
    pub snap: SnapSettings,
    /// Follow playhead
    pub follow_playhead: bool,
    /// CPU load (0.0–1.0)
    pub cpu_load: f32,
    /// Engine status
    pub engine_connected: bool,
    /// Undo/redo availability
    pub can_undo: bool,
    pub can_redo: bool,
    /// Status bar message
    pub status_message: String,
}

impl Default for AppState {
    fn default() -> Self {
        Self {
            projects: vec![ProjectTab::new("Untitled")],
            active_project: 0,
            transport: TransportState::default(),
            selection: SelectionState::default(),
            active_panel: PanelType::Arranger,
            fullscreen: false,
            browser_visible: true,
            bottom_panel_visible: true,
            current_tool: Tool::Select,
            snap: SnapSettings::default(),
            follow_playhead: true,
            cpu_load: 0.0,
            engine_connected: false,
            can_undo: false,
            can_redo: false,
            status_message: "Ready".to_string(),
        }
    }
}

/// A project tab.
#[derive(Debug, Clone)]
pub struct ProjectTab {
    pub name: String,
    pub file_path: Option<String>,
    pub modified: bool,
    pub bpm: f64,
    pub time_sig_num: u8,
    pub time_sig_den: u8,
    pub sample_rate: u32,
}

impl ProjectTab {
    pub fn new(name: &str) -> Self {
        Self {
            name: name.to_string(),
            file_path: None,
            modified: false,
            bpm: 120.0,
            time_sig_num: 4,
            time_sig_den: 4,
            sample_rate: 44100,
        }
    }
}

/// Transport state (play/stop/record/position).
#[derive(Debug, Clone, Default)]
pub struct TransportState {
    pub is_playing: bool,
    pub is_recording: bool,
    pub is_looping: bool,
    pub playhead_beat: f64,
    pub playhead_sample: u64,
    pub loop_start: f64,
    pub loop_end: f64,
    pub bpm: f64,
    pub time_sig_num: u8,
    pub time_sig_den: u8,
    /// Timecode display string (HH:MM:SS:FF)
    pub timecode: String,
    /// Bar:Beat:Tick display
    pub bar_beat_tick: String,
    /// Count-in bars
    pub count_in_bars: u8,
    /// Metronome on/off
    pub metronome: bool,
}

/// What's currently selected.
#[derive(Debug, Clone, Default)]
pub struct SelectionState {
    pub selected_track_ids: Vec<String>,
    pub selected_clip_ids: Vec<String>,
    pub selected_note_ids: Vec<u64>,
    pub selection_rect: Option<Rect>,
}

impl SelectionState {
    pub fn clear(&mut self) {
        self.selected_track_ids.clear();
        self.selected_clip_ids.clear();
        self.selected_note_ids.clear();
        self.selection_rect = None;
    }

    pub fn has_selection(&self) -> bool {
        !self.selected_track_ids.is_empty()
            || !self.selected_clip_ids.is_empty()
            || !self.selected_note_ids.is_empty()
    }
}

/// A rectangle (for selection, layout, etc.).
#[derive(Debug, Clone, Copy, Default, Serialize, Deserialize)]
pub struct Rect {
    pub x: f32,
    pub y: f32,
    pub width: f32,
    pub height: f32,
}

impl Rect {
    pub fn new(x: f32, y: f32, w: f32, h: f32) -> Self {
        Self { x, y, width: w, height: h }
    }

    pub fn contains(&self, px: f32, py: f32) -> bool {
        px >= self.x && px < self.x + self.width && py >= self.y && py < self.y + self.height
    }

    pub fn intersects(&self, other: &Rect) -> bool {
        self.x < other.x + other.width && self.x + self.width > other.x
            && self.y < other.y + other.height && self.y + self.height > other.y
    }

    pub fn right(&self) -> f32 { self.x + self.width }
    pub fn bottom(&self) -> f32 { self.y + self.height }
    pub fn center_x(&self) -> f32 { self.x + self.width * 0.5 }
    pub fn center_y(&self) -> f32 { self.y + self.height * 0.5 }
}

/// Which panel/view is active.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum PanelType {
    Arranger,
    Mixer,
    PianoRoll,
    AudioEditor,
    ClipLauncher,
    VideoEditor,
    Browser,
    Settings,
}

/// Current editing tool.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum Tool {
    Select,
    Pencil,
    Eraser,
    Knife,
    Glue,
    Mute,
    Zoom,
    Hand,
    Automation,
    Lasso,
}

/// Snap/grid settings.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SnapSettings {
    pub enabled: bool,
    pub grid_value: GridValue,
    pub triplet: bool,
    pub dotted: bool,
    pub swing_amount: f32,
}

impl Default for SnapSettings {
    fn default() -> Self {
        Self {
            enabled: true,
            grid_value: GridValue::SixteenthNote,
            triplet: false,
            dotted: false,
            swing_amount: 0.0,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum GridValue {
    WholeNote,
    HalfNote,
    QuarterNote,
    EighthNote,
    SixteenthNote,
    ThirtySecondNote,
    SixtyFourthNote,
    Bar,
}

impl GridValue {
    /// Grid value in beats (quarter note = 1.0).
    pub fn beats(&self) -> f64 {
        match self {
            GridValue::WholeNote => 4.0,
            GridValue::HalfNote => 2.0,
            GridValue::QuarterNote => 1.0,
            GridValue::EighthNote => 0.5,
            GridValue::SixteenthNote => 0.25,
            GridValue::ThirtySecondNote => 0.125,
            GridValue::SixtyFourthNote => 0.0625,
            GridValue::Bar => 4.0, // default 4/4
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_rect() {
        let r = Rect::new(10.0, 20.0, 100.0, 50.0);
        assert!(r.contains(50.0, 30.0));
        assert!(!r.contains(5.0, 30.0));
        assert_eq!(r.right(), 110.0);
        assert_eq!(r.bottom(), 70.0);
    }

    #[test]
    fn test_rect_intersect() {
        let a = Rect::new(0.0, 0.0, 100.0, 100.0);
        let b = Rect::new(50.0, 50.0, 100.0, 100.0);
        let c = Rect::new(200.0, 200.0, 10.0, 10.0);
        assert!(a.intersects(&b));
        assert!(!a.intersects(&c));
    }

    #[test]
    fn test_app_state_default() {
        let state = AppState::default();
        assert_eq!(state.projects.len(), 1);
        assert!(!state.transport.is_playing);
        assert_eq!(state.current_tool, Tool::Select);
    }

    #[test]
    fn test_selection() {
        let mut sel = SelectionState::default();
        assert!(!sel.has_selection());
        sel.selected_clip_ids.push("c1".into());
        assert!(sel.has_selection());
        sel.clear();
        assert!(!sel.has_selection());
    }

    #[test]
    fn test_grid_beats() {
        assert_eq!(GridValue::QuarterNote.beats(), 1.0);
        assert_eq!(GridValue::SixteenthNote.beats(), 0.25);
        assert_eq!(GridValue::WholeNote.beats(), 4.0);
    }
}
