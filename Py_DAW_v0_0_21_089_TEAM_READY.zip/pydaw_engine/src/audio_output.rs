use std::sync::atomic::{AtomicBool, AtomicU32, Ordering};
use std::sync::Arc;

use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};
use log::{error, info};

// ============================================================================
// Rust Audio Output — cpal backend (RA1.1)
// ============================================================================
//
// v0.0.20.959: cpal re-enabled with proper buffer size handling.
//
// Previous crash (v0.0.20.781) was caused by:
//   1. Python sent Configure(sr=44100, buf=512) → graph resized to 512
//   2. cpal callback requested 1024 frames → buffer overflow → crash
//
// FIX: The audio callback now uses the ACTUAL cpal buffer size (from the
// callback's `data.len()`), NOT the configured buffer size. The render
// function always produces exactly the number of frames requested.
//
// Architecture:
//   ┌─────────────────────────────────────────────────┐
//   │  cpal Stream (OS audio thread — RT priority)    │
//   │                                                  │
//   │  callback(data: &mut [f32]) {                   │
//   │      render_fn(data);  // fill buffer            │
//   │  }                                               │
//   └─────────────────────────────────────────────────┘
//
// The render_fn is provided by the caller (Engine) and runs on the
// OS audio thread. It MUST be real-time safe:
//   - No allocations
//   - No I/O
//   - No locks (except try_lock with immediate fallback)
//   - No syscalls
// ============================================================================

/// Information about an available audio output device.
#[derive(Debug, Clone)]
pub struct AudioDeviceInfo {
    /// Human-readable device name.
    pub name: String,
    /// Whether this is the default output device.
    pub is_default: bool,
    /// Supported sample rates (empty = unknown).
    pub sample_rates: Vec<u32>,
    /// Maximum output channels.
    pub max_channels: u16,
}

/// Audio output configuration.
#[derive(Debug, Clone)]
pub struct AudioOutputConfig {
    /// Desired sample rate (44100, 48000, 96000).
    pub sample_rate: u32,
    /// Desired buffer size in frames (64, 128, 256, 512, 1024).
    pub buffer_size: u32,
    /// Device name (empty = default device).
    pub device_name: String,
    /// Number of output channels (always 2 for stereo).
    pub channels: u16,
}

impl Default for AudioOutputConfig {
    fn default() -> Self {
        Self {
            sample_rate: 48000,
            buffer_size: 256,
            device_name: String::new(),
            channels: 2,
        }
    }
}

/// Statistics from the audio output.
#[derive(Debug, Clone, Default)]
pub struct AudioOutputStats {
    /// Number of buffer underruns (xruns).
    pub xrun_count: u32,
    /// Actual sample rate being used.
    pub actual_sample_rate: u32,
    /// Actual buffer size being used.
    pub actual_buffer_size: u32,
    /// Actual device name.
    pub device_name: String,
    /// Whether the stream is currently running.
    pub is_running: bool,
}

/// Shared state between the audio thread and the control thread.
pub struct AudioOutputShared {
    /// Whether the stream is active.
    pub running: AtomicBool,
    /// XRun counter (incremented by audio callback on underrun).
    pub xrun_count: AtomicU32,
    /// Actual buffer size used by cpal (may differ from requested).
    pub actual_buffer_size: AtomicU32,
    /// Actual sample rate.
    pub actual_sample_rate: AtomicU32,
    /// Last render callback time in microseconds (for CPU load reporting).
    pub render_time_us: AtomicU32,
}

impl AudioOutputShared {
    pub fn new() -> Self {
        Self {
            running: AtomicBool::new(false),
            xrun_count: AtomicU32::new(0),
            actual_buffer_size: AtomicU32::new(0),
            actual_sample_rate: AtomicU32::new(0),
            render_time_us: AtomicU32::new(0),
        }
    }
}

/// The audio output manager.
///
/// Owns the cpal stream and provides start/stop/enumerate controls.
/// The actual audio rendering is done by a callback function provided
/// by the caller (typically the Engine).
pub struct AudioOutput {
    /// The cpal stream (None when stopped).
    stream: Option<cpal::Stream>,
    /// Current configuration.
    config: AudioOutputConfig,
    /// Shared state for stats.
    shared: Arc<AudioOutputShared>,
    /// Device name actually in use.
    device_name: String,
}

// SAFETY: AudioOutput is always accessed through a Mutex (exclusive access).
// cpal::Stream may not be Send on some backends (ALSA), but since we only
// create/destroy it while holding the Mutex lock and never move it between
// threads without the lock, this is safe.
unsafe impl Send for AudioOutput {}

impl AudioOutput {
    /// Create a new AudioOutput (stream not yet started).
    pub fn new() -> Self {
        Self {
            stream: None,
            config: AudioOutputConfig::default(),
            shared: Arc::new(AudioOutputShared::new()),
            device_name: String::new(),
        }
    }

    /// Enumerate available output devices.
    pub fn enumerate_devices() -> Vec<AudioDeviceInfo> {
        let mut devices = Vec::new();

        let host = cpal::default_host();
        let default_name = host
            .default_output_device()
            .and_then(|d| d.name().ok())
            .unwrap_or_default();

        if let Ok(output_devices) = host.output_devices() {
            for device in output_devices {
                let name = device.name().unwrap_or_else(|_| "Unknown".into());
                let is_default = name == default_name;

                // Query supported configurations
                let mut sample_rates = Vec::new();
                let mut max_channels: u16 = 2;

                if let Ok(configs) = device.supported_output_configs() {
                    for cfg in configs {
                        max_channels = max_channels.max(cfg.channels());
                        // Check common sample rates
                        for &sr in &[44100u32, 48000, 88200, 96000, 176400, 192000] {
                            let sr_val = cpal::SampleRate(sr);
                            if sr_val >= cfg.min_sample_rate()
                                && sr_val <= cfg.max_sample_rate()
                                && !sample_rates.contains(&sr)
                            {
                                sample_rates.push(sr);
                            }
                        }
                    }
                }

                sample_rates.sort();

                devices.push(AudioDeviceInfo {
                    name,
                    is_default,
                    sample_rates,
                    max_channels,
                });
            }
        }

        devices
    }

    /// Get a reference to the shared state (for stats queries).
    pub fn shared(&self) -> &Arc<AudioOutputShared> {
        &self.shared
    }

    /// Start the audio output stream.
    ///
    /// `render_fn` is called on the OS audio thread to fill the output buffer.
    /// It receives a mutable slice of interleaved f32 samples (L, R, L, R, ...).
    /// The number of frames = data.len() / channels.
    ///
    /// IMPORTANT: `render_fn` MUST be real-time safe (no alloc, no I/O, no locks).
    pub fn start<F>(&mut self, config: AudioOutputConfig, render_fn: F) -> Result<(), String>
    where
        F: FnMut(&mut [f32]) + Send + 'static,
    {
        // Stop any existing stream
        self.stop();

        let host = cpal::default_host();
        info!(
            "cpal host: {} (available: {:?})",
            host.id().name(),
            cpal::available_hosts()
                .iter()
                .map(|h| h.name())
                .collect::<Vec<_>>()
        );

        // Find the requested device (or use default)
        let device = if config.device_name.is_empty() {
            host.default_output_device()
                .ok_or_else(|| "No default output device found".to_string())?
        } else {
            let target = config.device_name.clone();
            host.output_devices()
                .map_err(|e| format!("Failed to enumerate devices: {}", e))?
                .find(|d| d.name().map(|n| n == target).unwrap_or(false))
                .ok_or_else(|| format!("Device '{}' not found", target))?
        };

        self.device_name = device.name().unwrap_or_else(|_| "Unknown".into());
        info!("Using audio device: {}", self.device_name);

        // Find a matching output config
        let desired_sr = cpal::SampleRate(config.sample_rate);
        let desired_channels = config.channels;

        let _supported = device
            .supported_output_configs()
            .map_err(|e| format!("Failed to query device configs: {}", e))?
            .filter(|c| c.channels() >= desired_channels)
            .filter(|c| desired_sr >= c.min_sample_rate() && desired_sr <= c.max_sample_rate())
            .next()
            .ok_or_else(|| {
                format!(
                    "Device '{}' does not support {}Hz stereo output",
                    self.device_name, config.sample_rate
                )
            })?;

        let stream_config = cpal::StreamConfig {
            channels: desired_channels,
            sample_rate: desired_sr,
            buffer_size: cpal::BufferSize::Fixed(config.buffer_size),
        };

        info!(
            "Stream config: {}Hz, {} channels, buffer={}",
            config.sample_rate, desired_channels, config.buffer_size
        );

        // Shared state for the callback
        let shared = Arc::clone(&self.shared);
        shared.actual_sample_rate.store(config.sample_rate, Ordering::Release);
        shared.actual_buffer_size.store(config.buffer_size, Ordering::Release);

        // Move render_fn directly into the callback (no Mutex needed —
        // cpal guarantees the data callback is called from a single thread)
        let mut render_fn = render_fn;

        let shared_err = Arc::clone(&self.shared);

        let stream = device
            .build_output_stream(
                &stream_config,
                move |data: &mut [f32], _info: &cpal::OutputCallbackInfo| {
                    let t0 = std::time::Instant::now();

                    // Update actual buffer size (cpal may use a different size)
                    let frames = data.len() / desired_channels as usize;
                    shared.actual_buffer_size.store(frames as u32, Ordering::Relaxed);

                    // Call the render function directly
                    render_fn(data);

                    // Store render time for CPU load reporting
                    let elapsed_us = t0.elapsed().as_micros() as u32;
                    shared.render_time_us.store(elapsed_us, Ordering::Relaxed);
                },
                move |err| {
                    error!("cpal stream error: {}", err);
                    shared_err.xrun_count.fetch_add(1, Ordering::Relaxed);
                },
                None, // No timeout
            )
            .map_err(|e| format!("Failed to build output stream: {}", e))?;

        stream
            .play()
            .map_err(|e| format!("Failed to start playback: {}", e))?;

        self.shared.running.store(true, Ordering::Release);
        self.config = config;
        self.stream = Some(stream);

        info!(
            "Audio output started: {} @ {}Hz, buffer={}",
            self.device_name,
            self.config.sample_rate,
            self.config.buffer_size
        );

        Ok(())
    }

    /// Stop the audio output stream.
    pub fn stop(&mut self) {
        if let Some(stream) = self.stream.take() {
            // cpal::Stream::drop() stops the stream
            drop(stream);
            self.shared.running.store(false, Ordering::Release);
            info!("Audio output stopped");
        }
    }

    /// Check if the stream is currently running.
    pub fn is_running(&self) -> bool {
        self.shared.running.load(Ordering::Acquire)
    }

    /// Get current stats.
    pub fn stats(&self) -> AudioOutputStats {
        AudioOutputStats {
            xrun_count: self.shared.xrun_count.load(Ordering::Relaxed),
            actual_sample_rate: self.shared.actual_sample_rate.load(Ordering::Relaxed),
            actual_buffer_size: self.shared.actual_buffer_size.load(Ordering::Relaxed),
            device_name: self.device_name.clone(),
            is_running: self.is_running(),
        }
    }

    /// Generate a test sine wave (440Hz) for verification.
    ///
    /// Returns a render function that produces a sine tone.
    pub fn test_sine_render(sample_rate: u32, channels: u16) -> impl FnMut(&mut [f32]) + Send {
        let mut phase: f64 = 0.0;
        let freq = 440.0_f64;
        let sr = sample_rate as f64;
        let ch = channels as usize;

        move |data: &mut [f32]| {
            let frames = data.len() / ch;
            for frame in 0..frames {
                let sample = (phase * 2.0 * std::f64::consts::PI).sin() as f32 * 0.3;
                for c in 0..ch {
                    data[frame * ch + c] = sample;
                }
                phase += freq / sr;
                if phase >= 1.0 {
                    phase -= 1.0;
                }
            }
        }
    }
}

impl Drop for AudioOutput {
    fn drop(&mut self) {
        self.stop();
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_config() {
        let cfg = AudioOutputConfig::default();
        assert_eq!(cfg.sample_rate, 48000);
        assert_eq!(cfg.buffer_size, 256);
        assert_eq!(cfg.channels, 2);
        assert!(cfg.device_name.is_empty());
    }

    #[test]
    fn test_shared_state() {
        let shared = AudioOutputShared::new();
        assert!(!shared.running.load(Ordering::Relaxed));
        assert_eq!(shared.xrun_count.load(Ordering::Relaxed), 0);
    }

    #[test]
    fn test_enumerate_devices() {
        // Should not panic even on headless systems
        let devices = AudioOutput::enumerate_devices();
        // May be empty on CI, that's fine
        for d in &devices {
            assert!(!d.name.is_empty());
        }
    }

    #[test]
    fn test_sine_render_produces_audio() {
        let mut render = AudioOutput::test_sine_render(48000, 2);
        let mut buf = vec![0.0f32; 512]; // 256 stereo frames
        render(&mut buf);
        // Should have non-zero samples
        let has_nonzero = buf.iter().any(|&s| s.abs() > 0.001);
        assert!(has_nonzero, "Sine render should produce non-zero samples");
    }
}
