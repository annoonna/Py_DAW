// ============================================================================
// Py_DAW Core Data Model — v0.0.20.970 (RM1.1)
// ============================================================================
//
// All project data types in pure Rust. No Python dependency.
// Every struct is Serialize/Deserialize for IPC + SQLite persistence.
// ============================================================================

use serde::{Deserialize, Serialize};
use std::collections::HashMap;

// ============================================================================
// IDs — Type-safe identifiers
// ============================================================================

/// Unique identifier for tracks, clips, etc.
pub type Id = String; // UUID v4 string

// ============================================================================
// Project
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Project {
    pub id: Id,
    pub name: String,
    pub bpm: f64,
    pub time_signature: TimeSignature,
    pub sample_rate: u32,
    pub created: String,      // ISO 8601
    pub modified: String,     // ISO 8601
    pub version: String,      // e.g. "0.0.20.970"
    pub tracks: Vec<Track>,
    pub master_track: Track,
    pub tempo_map: TempoMap,
    pub loop_region: Option<LoopRegion>,
    pub project_path: Option<String>,
}

impl Default for Project {
    fn default() -> Self {
        Self {
            id: uuid_v4(),
            name: "Untitled".into(),
            bpm: 120.0,
            time_signature: TimeSignature { numerator: 4, denominator: 4 },
            sample_rate: 44100,
            created: now_iso(),
            modified: now_iso(),
            version: "0.0.20.970".into(),
            tracks: Vec::new(),
            master_track: Track::new_master(),
            tempo_map: TempoMap::default(),
            loop_region: None,
            project_path: None,
        }
    }
}

// ============================================================================
// Track
// ============================================================================

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TrackKind {
    Audio,
    Instrument,
    Group,
    Master,
    FxReturn,
    Video,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Track {
    pub id: Id,
    pub name: String,
    pub kind: TrackKind,
    pub index: u16,
    pub color: Color,
    pub volume: f64,       // 0.0 .. 2.0 (1.0 = unity)
    pub pan: f64,          // -1.0 (L) .. 1.0 (R)
    pub mute: bool,
    pub solo: bool,
    pub armed: bool,       // record-armed
    pub visible: bool,
    pub height: u32,       // pixels in arranger
    pub group_id: Option<Id>,  // parent group track
    pub clips: Vec<Clip>,
    pub automation_lanes: Vec<AutomationLane>,
    pub fx_chain: Vec<FxSlot>,
    pub sends: Vec<Send>,
    pub input_config: InputConfig,
    pub output_config: OutputConfig,
}

impl Track {
    pub fn new(name: &str, kind: TrackKind, index: u16) -> Self {
        Self {
            id: uuid_v4(),
            name: name.into(),
            kind,
            index,
            color: Color::default(),
            volume: 1.0,
            pan: 0.0,
            mute: false,
            solo: false,
            armed: false,
            visible: true,
            height: 80,
            group_id: None,
            clips: Vec::new(),
            automation_lanes: Vec::new(),
            fx_chain: Vec::new(),
            sends: Vec::new(),
            input_config: InputConfig::default(),
            output_config: OutputConfig::default(),
        }
    }

    pub fn new_master() -> Self {
        let mut t = Self::new("Master", TrackKind::Master, 0);
        t.color = Color { r: 200, g: 160, b: 80, a: 255 };
        t
    }
}

// ============================================================================
// Clip (Audio / MIDI / Video)
// ============================================================================

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ClipKind {
    Audio,
    Midi,
    Video,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Clip {
    pub id: Id,
    pub track_id: Id,
    pub kind: ClipKind,
    pub name: String,
    pub color: Color,
    pub start_beat: f64,
    pub length_beats: f64,
    pub offset_beats: f64,   // content offset within clip
    pub gain: f64,           // 0.0 .. 2.0
    pub fade_in_beats: f64,
    pub fade_out_beats: f64,
    pub fade_in_curve: FadeCurve,
    pub fade_out_curve: FadeCurve,
    pub muted: bool,
    pub locked: bool,
    pub group_id: Option<Id>,  // clip group

    // Audio-specific
    pub audio_file: Option<String>,    // path to audio file
    pub audio_channels: Option<u8>,
    pub audio_sample_rate: Option<u32>,
    pub warp_enabled: bool,
    pub warp_markers: Vec<WarpMarker>,

    // MIDI-specific
    pub midi_notes: Option<Vec<MidiNote>>,
    pub midi_ccs: Option<Vec<MidiCC>>,

    // Video-specific
    pub video_file: Option<String>,
    pub video_in_point: Option<f64>,   // in beats
    pub video_out_point: Option<f64>,  // in beats
    pub video_speed: Option<f64>,      // 1.0 = normal
    pub video_opacity: Option<f64>,    // 0.0 .. 1.0
    pub video_blend_mode: Option<BlendMode>,
    pub video_filters: Option<Vec<VideoFilterEntry>>,
}

impl Clip {
    pub fn new_audio(track_id: &str, name: &str, start: f64, length: f64, file: &str) -> Self {
        Self {
            id: uuid_v4(),
            track_id: track_id.into(),
            kind: ClipKind::Audio,
            name: name.into(),
            color: Color::default(),
            start_beat: start,
            length_beats: length,
            offset_beats: 0.0,
            gain: 1.0,
            fade_in_beats: 0.0,
            fade_out_beats: 0.0,
            fade_in_curve: FadeCurve::Linear,
            fade_out_curve: FadeCurve::Linear,
            muted: false,
            locked: false,
            group_id: None,
            audio_file: Some(file.into()),
            audio_channels: None,
            audio_sample_rate: None,
            warp_enabled: false,
            warp_markers: Vec::new(),
            midi_notes: None,
            midi_ccs: None,
            video_file: None,
            video_in_point: None,
            video_out_point: None,
            video_speed: None,
            video_opacity: None,
            video_blend_mode: None,
            video_filters: None,
        }
    }

    pub fn new_midi(track_id: &str, name: &str, start: f64, length: f64) -> Self {
        let mut clip = Self::new_audio(track_id, name, start, length, "");
        clip.kind = ClipKind::Midi;
        clip.audio_file = None;
        clip.midi_notes = Some(Vec::new());
        clip.midi_ccs = Some(Vec::new());
        clip
    }

    pub fn new_video(track_id: &str, name: &str, start: f64, length: f64, file: &str) -> Self {
        let mut clip = Self::new_audio(track_id, name, start, length, "");
        clip.kind = ClipKind::Video;
        clip.audio_file = None;
        clip.video_file = Some(file.into());
        clip.video_opacity = Some(1.0);
        clip.video_speed = Some(1.0);
        clip.video_blend_mode = Some(BlendMode::Normal);
        clip.video_filters = Some(Vec::new());
        clip
    }

    /// End beat position
    pub fn end_beat(&self) -> f64 {
        self.start_beat + self.length_beats
    }

    /// Check if this clip overlaps with a beat range
    pub fn overlaps(&self, start: f64, end: f64) -> bool {
        self.start_beat < end && self.end_beat() > start
    }
}

// ============================================================================
// MIDI
// ============================================================================

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct MidiNote {
    pub pitch: u8,          // 0-127
    pub velocity: u8,       // 0-127
    pub start_beat: f64,
    pub length_beats: f64,
    pub channel: u8,        // 0-15
    // MPE / Note Expression
    pub pressure: Option<f64>,   // 0.0 .. 1.0
    pub slide: Option<f64>,      // -1.0 .. 1.0
    pub pitch_bend: Option<f64>, // semitones
}

impl MidiNote {
    pub fn new(pitch: u8, velocity: u8, start: f64, length: f64) -> Self {
        Self {
            pitch,
            velocity,
            start_beat: start,
            length_beats: length,
            channel: 0,
            pressure: None,
            slide: None,
            pitch_bend: None,
        }
    }

    pub fn end_beat(&self) -> f64 {
        self.start_beat + self.length_beats
    }

    /// Note name (e.g. "C4", "F#5")
    pub fn name(&self) -> String {
        let names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
        let octave = (self.pitch / 12) as i8 - 1;
        let note = self.pitch % 12;
        format!("{}{}", names[note as usize], octave)
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct MidiCC {
    pub cc: u8,             // CC number 0-127
    pub value: u8,          // 0-127
    pub beat: f64,
    pub channel: u8,
}

// ============================================================================
// Automation
// ============================================================================

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum CurveType {
    Linear,
    Bezier,      // cubic bezier
    Step,        // instant jump
    SCurve,
    Logarithmic,
    Exponential,
    EaseIn,
    EaseOut,
    EaseInOut,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct AutomationPoint {
    pub beat: f64,
    pub value: f64,        // normalized 0.0 .. 1.0
    pub curve_type: CurveType,
    // Bezier control points (relative offsets)
    pub cp1_x: f64,        // control point 1 x offset
    pub cp1_y: f64,        // control point 1 y offset
    pub cp2_x: f64,        // control point 2 x offset
    pub cp2_y: f64,        // control point 2 y offset
}

impl AutomationPoint {
    pub fn new(beat: f64, value: f64) -> Self {
        Self {
            beat,
            value,
            curve_type: CurveType::Linear,
            cp1_x: 0.0,
            cp1_y: 0.0,
            cp2_x: 0.0,
            cp2_y: 0.0,
        }
    }

    pub fn with_curve(mut self, curve: CurveType) -> Self {
        self.curve_type = curve;
        self
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AutomationLane {
    pub id: Id,
    pub track_id: Id,
    pub param_id: String,       // e.g. "volume", "pan", "eq_freq_1"
    pub param_name: String,     // human readable
    pub points: Vec<AutomationPoint>,
    pub default_value: f64,
    pub min_value: f64,
    pub max_value: f64,
    pub visible: bool,
    pub height: u32,
}

impl AutomationLane {
    /// Evaluate automation value at a given beat position
    pub fn value_at(&self, beat: f64) -> f64 {
        if self.points.is_empty() {
            return self.default_value;
        }

        // Before first point
        if beat <= self.points[0].beat {
            return self.points[0].value;
        }

        // After last point
        let last = self.points.last().unwrap();
        if beat >= last.beat {
            return last.value;
        }

        // Find surrounding points
        for i in 0..self.points.len() - 1 {
            let p0 = &self.points[i];
            let p1 = &self.points[i + 1];

            if beat >= p0.beat && beat < p1.beat {
                let t = (beat - p0.beat) / (p1.beat - p0.beat);
                return interpolate(p0, p1, t);
            }
        }

        self.default_value
    }
}

/// Interpolate between two automation points
fn interpolate(p0: &AutomationPoint, p1: &AutomationPoint, t: f64) -> f64 {
    match p0.curve_type {
        CurveType::Linear => {
            p0.value + (p1.value - p0.value) * t
        }
        CurveType::Step => {
            p0.value
        }
        CurveType::Bezier => {
            // Cubic bezier interpolation
            let t2 = t * t;
            let t3 = t2 * t;
            let mt = 1.0 - t;
            let mt2 = mt * mt;
            let mt3 = mt2 * mt;

            let y0 = p0.value;
            let y1 = p0.value + p0.cp1_y;
            let y2 = p1.value + p1.cp2_y;
            let y3 = p1.value;

            mt3 * y0 + 3.0 * mt2 * t * y1 + 3.0 * mt * t2 * y2 + t3 * y3
        }
        CurveType::SCurve => {
            // Smoothstep S-curve
            let s = t * t * (3.0 - 2.0 * t);
            p0.value + (p1.value - p0.value) * s
        }
        CurveType::Logarithmic => {
            let log_t = (1.0 + t * 9.0).log10(); // log10(1..10) = 0..1
            p0.value + (p1.value - p0.value) * log_t
        }
        CurveType::Exponential => {
            let exp_t = (10.0_f64.powf(t) - 1.0) / 9.0;
            p0.value + (p1.value - p0.value) * exp_t
        }
        CurveType::EaseIn => {
            let ease = t * t;
            p0.value + (p1.value - p0.value) * ease
        }
        CurveType::EaseOut => {
            let ease = 1.0 - (1.0 - t) * (1.0 - t);
            p0.value + (p1.value - p0.value) * ease
        }
        CurveType::EaseInOut => {
            let ease = if t < 0.5 {
                2.0 * t * t
            } else {
                1.0 - (-2.0 * t + 2.0).powi(2) / 2.0
            };
            p0.value + (p1.value - p0.value) * ease
        }
    }
}

// ============================================================================
// Tempo Map
// ============================================================================

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct TimeSignature {
    pub numerator: u8,
    pub denominator: u8,
}

impl Default for TimeSignature {
    fn default() -> Self {
        Self { numerator: 4, denominator: 4 }
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct TempoChange {
    pub beat: f64,
    pub bpm: f64,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct TimeSignatureChange {
    pub beat: f64,
    pub time_signature: TimeSignature,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TempoMap {
    pub tempo_changes: Vec<TempoChange>,
    pub time_sig_changes: Vec<TimeSignatureChange>,
}

impl Default for TempoMap {
    fn default() -> Self {
        Self {
            tempo_changes: vec![TempoChange { beat: 0.0, bpm: 120.0 }],
            time_sig_changes: vec![TimeSignatureChange {
                beat: 0.0,
                time_signature: TimeSignature::default(),
            }],
        }
    }
}

impl TempoMap {
    /// Get BPM at a given beat position
    pub fn bpm_at(&self, beat: f64) -> f64 {
        let mut bpm = 120.0;
        for tc in &self.tempo_changes {
            if tc.beat <= beat {
                bpm = tc.bpm;
            } else {
                break;
            }
        }
        bpm
    }

    /// Convert beat position to seconds (handles tempo changes)
    pub fn beat_to_seconds(&self, target_beat: f64) -> f64 {
        let mut seconds = 0.0;
        let mut prev_beat = 0.0;
        let mut prev_bpm = self.tempo_changes.first().map(|t| t.bpm).unwrap_or(120.0);

        for tc in &self.tempo_changes {
            if tc.beat >= target_beat {
                break;
            }
            if tc.beat > prev_beat {
                let delta_beats = tc.beat - prev_beat;
                seconds += delta_beats * 60.0 / prev_bpm;
                prev_beat = tc.beat;
            }
            prev_bpm = tc.bpm;
        }

        let remaining = target_beat - prev_beat;
        seconds += remaining * 60.0 / prev_bpm;
        seconds
    }

    /// Convert seconds to beat position (handles tempo changes)
    pub fn seconds_to_beat(&self, target_seconds: f64) -> f64 {
        let mut seconds = 0.0;
        let mut beat = 0.0;
        let mut prev_bpm = self.tempo_changes.first().map(|t| t.bpm).unwrap_or(120.0);

        for i in 1..self.tempo_changes.len() {
            let tc = &self.tempo_changes[i];
            let delta_beats = tc.beat - beat;
            let delta_secs = delta_beats * 60.0 / prev_bpm;

            if seconds + delta_secs > target_seconds {
                let remaining_secs = target_seconds - seconds;
                return beat + remaining_secs * prev_bpm / 60.0;
            }

            seconds += delta_secs;
            beat = tc.beat;
            prev_bpm = tc.bpm;
        }

        let remaining_secs = target_seconds - seconds;
        beat + remaining_secs * prev_bpm / 60.0
    }

    /// Convert beat position to sample position
    pub fn beat_to_sample(&self, beat: f64, sample_rate: u32) -> i64 {
        let secs = self.beat_to_seconds(beat);
        (secs * sample_rate as f64).round() as i64
    }

    /// Get time signature at a given beat
    pub fn time_sig_at(&self, beat: f64) -> TimeSignature {
        let mut ts = TimeSignature::default();
        for tsc in &self.time_sig_changes {
            if tsc.beat <= beat {
                ts = tsc.time_signature;
            } else {
                break;
            }
        }
        ts
    }

    /// Get bar number at a given beat
    pub fn bar_at(&self, beat: f64) -> u32 {
        // Simplified: assumes constant time signature
        let ts = self.time_sig_at(0.0);
        let beats_per_bar = ts.numerator as f64 * 4.0 / ts.denominator as f64;
        (beat / beats_per_bar).floor() as u32 + 1
    }
}

// ============================================================================
// Supporting Types
// ============================================================================

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct Color {
    pub r: u8,
    pub g: u8,
    pub b: u8,
    pub a: u8,
}

impl Default for Color {
    fn default() -> Self {
        Self { r: 100, g: 150, b: 200, a: 255 }
    }
}

impl Color {
    pub fn from_hex(hex: &str) -> Self {
        let hex = hex.trim_start_matches('#');
        let r = u8::from_str_radix(&hex[0..2], 16).unwrap_or(100);
        let g = u8::from_str_radix(&hex[2..4], 16).unwrap_or(150);
        let b = u8::from_str_radix(&hex[4..6], 16).unwrap_or(200);
        let a = if hex.len() >= 8 {
            u8::from_str_radix(&hex[6..8], 16).unwrap_or(255)
        } else {
            255
        };
        Self { r, g, b, a }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum FadeCurve {
    Linear,
    Exponential,
    Logarithmic,
    SCurve,
    EqualPower,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct WarpMarker {
    pub beat: f64,        // position in clip (beats)
    pub sample: i64,      // original sample position
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum BlendMode {
    Normal,
    Multiply,
    Screen,
    Overlay,
    Add,
    Subtract,
    Difference,
    Darken,
    Lighten,
    SoftLight,
    HardLight,
    ColorDodge,
    ColorBurn,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VideoFilterEntry {
    pub filter_type: String,      // e.g. "brightness", "blur", "lut"
    pub params: HashMap<String, f64>,
    pub enabled: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoopRegion {
    pub enabled: bool,
    pub start_beat: f64,
    pub end_beat: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FxSlot {
    pub id: Id,
    pub plugin_id: String,        // plugin identifier
    pub plugin_name: String,
    pub enabled: bool,
    pub wet_dry: f64,             // 0.0 .. 1.0
    pub params: HashMap<String, f64>,
    pub preset_name: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Send {
    pub id: Id,
    pub target_track_id: Id,
    pub gain: f64,                // 0.0 .. 2.0
    pub pan: f64,                 // -1.0 .. 1.0
    pub pre_fader: bool,
    pub enabled: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InputConfig {
    pub device: Option<String>,
    pub channel_left: Option<u32>,
    pub channel_right: Option<u32>,
    pub monitoring: bool,
}

impl Default for InputConfig {
    fn default() -> Self {
        Self {
            device: None,
            channel_left: None,
            channel_right: None,
            monitoring: false,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OutputConfig {
    pub device: Option<String>,
    pub channel_left: u32,
    pub channel_right: u32,
}

impl Default for OutputConfig {
    fn default() -> Self {
        Self {
            device: None,
            channel_left: 0,
            channel_right: 1,
        }
    }
}

// ============================================================================
// Ghost Notes (transparent notes from other clips)
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GhostNote {
    pub pitch: u8,
    pub start_beat: f64,
    pub length_beats: f64,
    pub source_clip_id: Id,
    pub source_track_id: Id,
}

// ============================================================================
// Helper functions
// ============================================================================

/// Generate a UUID v4 string
pub fn uuid_v4() -> String {
    uuid::Uuid::new_v4().to_string()
}

/// Current timestamp as ISO 8601 string
pub fn now_iso() -> String {
    chrono::Utc::now().to_rfc3339_opts(chrono::SecondsFormat::Secs, true)
}
