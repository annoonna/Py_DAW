"""RustEngineBridge — Python ↔ Rust Audio-Engine IPC Bridge.

v0.0.20.630 — Phase 1A

This module provides the Python-side interface to the Rust audio engine.
Communication uses Unix Domain Sockets with MessagePack-encoded frames.

Frame format: [u32 LE length][msgpack payload]

Architecture:
    ┌─────────────────────────────────────────────┐
    │  Python GUI (PyQt6)                         │
    │                                             │
    │  RustEngineBridge                           │
    │  ├─ send_command(cmd)  → Unix Socket → Rust │
    │  ├─ _reader_thread     ← Unix Socket ← Rust│
    │  ├─ event signals (PyQt6)                   │
    │  └─ subprocess management                   │
    └─────────────────────────────────────────────┘

Usage:
    bridge = RustEngineBridge.instance()
    bridge.start_engine()
    bridge.play()
    bridge.set_tempo(140.0)
    bridge.stop()
    bridge.shutdown()

The bridge is a singleton — only one engine process per application.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import signal
import socket
import struct
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import msgpack
    _MSGPACK_AVAILABLE = True
except ImportError:
    _MSGPACK_AVAILABLE = False

try:
    from PyQt6.QtCore import QObject, pyqtSignal, QTimer
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# v0.0.20.728: Cross-platform socket/pipe path
if sys.platform == "win32":
    DEFAULT_SOCKET_PATH = r"\\.\pipe\pydaw_engine"
elif sys.platform == "darwin":
    DEFAULT_SOCKET_PATH = os.path.join(os.environ.get("TMPDIR", "/tmp"), "pydaw_engine.sock")
else:
    DEFAULT_SOCKET_PATH = "/tmp/pydaw_engine.sock"
DEFAULT_SAMPLE_RATE = 44100
DEFAULT_BUFFER_SIZE = 512
DEFAULT_BPM = 120.0

# Engine binary search paths (in priority order)
# v0.0.20.728: Extended for Nuitka standalone builds + cross-platform
_ENGINE_NAME = "pydaw_engine.exe" if sys.platform == "win32" else "pydaw_engine"
_ENGINE_SEARCH_PATHS = [
    # PRIORITY 1: Development build — freshly compiled from source
    Path(__file__).parent.parent.parent / "pydaw_engine" / "target" / "release" / _ENGINE_NAME,
    Path(__file__).parent.parent.parent / "pydaw_engine" / "target" / "debug" / _ENGINE_NAME,
    # PRIORITY 2: Same directory as project root
    Path(__file__).parent.parent.parent / _ENGINE_NAME,
    Path(os.path.dirname(os.path.abspath(sys.argv[0] if sys.argv else __file__))) / _ENGINE_NAME,
    # Nuitka standalone: binary sits NEXT TO the executable
    Path(getattr(sys, '_MEIPASS', '')) / _ENGINE_NAME if hasattr(sys, '_MEIPASS') else Path("."),
    # LOW PRIORITY: venv/system paths (may be stale!)
    Path(sys.executable).parent / _ENGINE_NAME,
    Path(sys.prefix) / "bin" / _ENGINE_NAME,
    # System-wide (Linux/macOS)
    Path("/usr/local/bin/pydaw_engine"),
    Path("/usr/bin/pydaw_engine"),
]


def _find_engine_binary() -> Optional[Path]:
    """Find the pydaw_engine binary.

    v0.0.20.963: Prioritizes the project's target/release/ build over
    PATH lookup to avoid using stale cached binaries from venvs.
    """
    # Check PYDAW_ENGINE_PATH env var first
    env_path = os.environ.get("PYDAW_ENGINE_PATH")
    if env_path:
        p = Path(env_path)
        if p.is_file() and os.access(str(p), os.X_OK):
            return p

    # Check known project locations FIRST (before PATH)
    for path in _ENGINE_SEARCH_PATHS:
        if path.is_file() and os.access(str(path), os.X_OK):
            return path

    # Fall back to PATH (may find old cached binary in venv)
    which_result = shutil.which("pydaw_engine")
    if which_result:
        return Path(which_result)

    return None


# ---------------------------------------------------------------------------
# Frame encoding/decoding
# ---------------------------------------------------------------------------

def _encode_frame(data: dict) -> bytes:
    """Encode a command dict to a length-prefixed MessagePack frame."""
    if _MSGPACK_AVAILABLE:
        payload = msgpack.packb(data, use_bin_type=True)
    else:
        # Fallback to JSON (slower but works without msgpack)
        payload = json.dumps(data).encode("utf-8")
    length = struct.pack("<I", len(payload))
    return length + payload


def _decode_frame(payload: bytes) -> dict:
    """Decode a MessagePack payload to a dict."""
    if _MSGPACK_AVAILABLE:
        return msgpack.unpackb(payload, raw=False)
    else:
        return json.loads(payload.decode("utf-8"))


def _recv_frame(sock: socket.socket) -> Optional[bytes]:
    """Read one length-prefixed frame from a socket. Returns None on EOF."""
    # Read 4-byte length prefix
    len_buf = b""
    while len(len_buf) < 4:
        chunk = sock.recv(4 - len(len_buf))
        if not chunk:
            return None
        len_buf += chunk

    length = struct.unpack("<I", len_buf)[0]
    if length > 16 * 1024 * 1024:
        raise ValueError(f"Frame too large: {length} bytes")

    # Read payload
    buf = b""
    while len(buf) < length:
        chunk = sock.recv(length - len(buf))
        if not chunk:
            return None
        buf += chunk

    return buf


# ---------------------------------------------------------------------------
# RustEngineBridge
# ---------------------------------------------------------------------------

if _QT_AVAILABLE:
    _BASE_CLASS = QObject
else:
    _BASE_CLASS = object


class RustEngineBridge(_BASE_CLASS):
    """Singleton bridge to the Rust audio engine process.

    Manages:
    - Engine subprocess lifecycle (start, monitor, restart, shutdown)
    - IPC via Unix Domain Socket (send commands, receive events)
    - PyQt6 signals for GUI integration (meter levels, playhead, etc.)

    Thread safety:
    - send_command() is thread-safe (uses a lock on the socket)
    - Events are received on a background thread and dispatched via Qt signals
    """

    # --- Qt Signals (only if Qt available) ---
    if _QT_AVAILABLE:
        # Transport
        playhead_changed = pyqtSignal(float, int, bool)  # beat, sample_pos, is_playing
        transport_state_changed = pyqtSignal(bool, float)  # is_playing, beat

        # Metering
        master_meter_changed = pyqtSignal(float, float, float, float)  # peak_l, peak_r, rms_l, rms_r
        track_meters_changed = pyqtSignal(list)  # list of (track_index, peak_l, peak_r, rms_l, rms_r)

        # Engine status
        engine_ready = pyqtSignal(int, int, str)  # sample_rate, buffer_size, device_name
        engine_error = pyqtSignal(int, str)  # code, message
        engine_pong = pyqtSignal(int, float, int)  # seq, cpu_load, xrun_count
        plugin_crashed = pyqtSignal(str, int, str)  # track_id, slot_index, message
        plugin_scan_result = pyqtSignal(list, int, list)  # plugins, scan_time_ms, errors
        plugin_loaded = pyqtSignal(str, int, str, str, int, int)  # track_id, slot, name, format, params, latency
        engine_shutdown = pyqtSignal()

        # v0.0.20.959: Rust Audio Output signals (Phase RA1.3)
        audio_started = pyqtSignal(str, int, int, float)  # device_name, sr, buf, latency_ms
        audio_stopped = pyqtSignal()
        audio_error = pyqtSignal(str)  # error message
        audio_device_list = pyqtSignal(list)  # list of device dicts
        audio_status_report = pyqtSignal(dict)  # full status dict
        # v0.0.20.970: Generic event signal for video engine + future events
        generic_event = pyqtSignal(dict)  # any event dict

    # Singleton
    _instance: Optional[RustEngineBridge] = None
    _lock = threading.Lock()

    @classmethod
    def instance(cls) -> RustEngineBridge:
        """Get or create the singleton bridge instance."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def __init__(self):
        if _QT_AVAILABLE:
            super().__init__()
        self._socket: Optional[socket.socket] = None
        self._socket_lock = threading.Lock()
        self._process: Optional[subprocess.Popen] = None
        self._reader_thread: Optional[threading.Thread] = None
        self._running = False
        self._connected = False
        self._shutting_down = False  # v0.0.20.666: prevents error flood on disconnect

        self._socket_path = DEFAULT_SOCKET_PATH
        self._bpm = DEFAULT_BPM

        # v0.0.20.794: Read actual audio settings from QSettings (not hardcoded!)
        # The user sets these in Audio-Einstellungen → must be respected.
        sr = DEFAULT_SAMPLE_RATE
        bs = DEFAULT_BUFFER_SIZE
        try:
            if _QT_AVAILABLE:
                from PyQt6.QtCore import QSettings
                s = QSettings()
                sr = int(s.value("audio/sample_rate", DEFAULT_SAMPLE_RATE))
                bs = int(s.value("audio/buffer_size", DEFAULT_BUFFER_SIZE))
        except Exception:
            pass
        self._sample_rate = sr
        self._buffer_size = bs

        # Ping tracking
        self._ping_seq = 0
        self._last_pong_time = 0.0
        self._last_cpu_load = 0.0
        self._last_render_time_us = 0.0
        self._last_xrun_count = 0

        # Health check timer (Qt)
        self._health_timer: Optional[QTimer] = None

        # v0.0.20.984: NS2 — Pending audio decode callbacks
        self._decode_callbacks: dict = {}

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def is_running(self) -> bool:
        return self._running and self._process is not None and self._process.poll() is None

    # --- Engine Lifecycle -------------------------------------------------

    def start_engine(
        self,
        socket_path: str = DEFAULT_SOCKET_PATH,
        sample_rate: int = DEFAULT_SAMPLE_RATE,
        buffer_size: int = DEFAULT_BUFFER_SIZE,
    ) -> bool:
        """Start the Rust engine subprocess and connect via IPC.

        v0.0.20.791: First tries to connect to an EXISTING engine (started
        by start_daw.sh or a previous session). Only starts a new subprocess
        if no engine is already listening on the socket.

        Returns True if successfully started and connected.
        """
        if self.is_running:
            log.warning("Engine already running")
            return True

        self._socket_path = socket_path
        self._sample_rate = sample_rate
        self._buffer_size = buffer_size

        # ── Step 1: Try connecting to existing engine (started by start_daw.sh) ──
        if os.path.exists(socket_path):
            log.info("Socket %s exists — trying to connect to existing engine...", socket_path)
            try:
                if self._connect():
                    log.info("Connected to existing engine (no subprocess needed)")
                    return True
            except Exception as e:
                log.debug("Could not connect to existing socket: %s", e)
            # Socket exists but can't connect → stale socket, remove it
            try:
                os.unlink(socket_path)
            except FileNotFoundError:
                pass

        # ── Step 2: Start new engine subprocess ──
        engine_bin = _find_engine_binary()
        if engine_bin is None:
            log.error(
                "Rust engine binary not found. Build with: "
                "cd pydaw_engine && cargo build --release"
            )
            return False

        log.info("Starting engine: %s", engine_bin)

        # Start subprocess
        # v0.0.20.793: CRITICAL FIX — NO PIPE for stdout/stderr!
        # With PIPE, nobody reads the buffers → 65KB pipe buffer fills up
        # → engine blocks on next log write → socket dies → EOF → disconnect loop.
        # stderr=None inherits parent's stderr → engine logs visible in terminal.
        try:
            self._process = subprocess.Popen(
                [
                    str(engine_bin),
                    "--socket", socket_path,
                    "--sr", str(sample_rate),
                    "--buf", str(buffer_size),
                ],
                stdout=subprocess.DEVNULL,
                stderr=None,  # inherit parent stderr → logs visible in terminal
            )
        except OSError as e:
            log.error("Failed to start engine: %s", e)
            return False

        log.info("Engine PID: %d", self._process.pid)

        # Wait for socket to appear (engine needs time to bind)
        for _ in range(50):  # max 5 seconds
            if os.path.exists(socket_path):
                break
            time.sleep(0.1)
        else:
            log.error("Engine socket did not appear within 5 seconds")
            self._kill_process()
            return False

        # Connect
        return self._connect()

    def _connect(self) -> bool:
        """Connect to the engine's Unix socket."""
        try:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.settimeout(5.0)
            sock.connect(self._socket_path)
            sock.settimeout(None)  # blocking mode for reader thread
            self._socket = sock
            self._connected = True
            self._running = True
            log.info("Connected to engine at %s", self._socket_path)
        except (socket.error, OSError) as e:
            log.error("Failed to connect to engine: %s", e)
            return False

        # Start reader thread
        self._reader_thread = threading.Thread(
            target=self._reader_loop,
            name="pydaw-ipc-reader",
            daemon=True,
        )
        self._reader_thread.start()

        # Start health check timer
        if _QT_AVAILABLE:
            self._health_timer = QTimer()
            self._health_timer.setInterval(5000)  # 5 seconds
            self._health_timer.timeout.connect(self._health_check)
            self._health_timer.start()

        # Send initial configuration
        self.send_command({
            "cmd": "Configure",
            "sample_rate": self._sample_rate,
            "buffer_size": self._buffer_size,
            "device": "",
        })

        return True

    def shutdown(self):
        """Gracefully shut down the engine."""
        log.info("Shutting down engine bridge")

        # v0.0.20.666: Stop event dispatch IMMEDIATELY to prevent error flood
        self._shutting_down = True

        if self._health_timer:
            self._health_timer.stop()
            self._health_timer = None

        # Send shutdown command
        if self._connected:
            try:
                self.send_command({"cmd": "Shutdown"})
                time.sleep(0.2)
            except Exception:
                pass

        self._running = False
        self._connected = False

        # Close socket
        if self._socket:
            try:
                self._socket.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                self._socket.close()
            except Exception:
                pass
            self._socket = None

        # Wait for reader thread
        if self._reader_thread and self._reader_thread.is_alive():
            self._reader_thread.join(timeout=2.0)

        # Terminate process
        self._kill_process()

        # Cleanup socket file
        try:
            os.unlink(self._socket_path)
        except FileNotFoundError:
            pass

        log.info("Engine bridge shut down")

    def _kill_process(self):
        """Force-kill the engine process."""
        if self._process:
            try:
                self._process.terminate()
                self._process.wait(timeout=3.0)
            except subprocess.TimeoutExpired:
                log.warning("Engine did not terminate, killing...")
                self._process.kill()
                self._process.wait(timeout=2.0)
            except Exception as e:
                log.error("Error killing engine: %s", e)
            self._process = None

    # --- IPC: Send Commands -----------------------------------------------

    def send_command(self, cmd: dict) -> bool:
        """Send a command to the engine. Thread-safe.

        Args:
            cmd: Command dict with "cmd" key matching ipc::Command variants.

        Returns:
            True if sent successfully.
        """
        if not self._connected or not self._socket:
            return False

        frame = _encode_frame(cmd)
        with self._socket_lock:
            try:
                self._socket.sendall(frame)
                return True
            except (socket.error, OSError) as e:
                log.error("Failed to send command: %s", e)
                self._connected = False
                return False

    # --- Convenience methods (typed command wrappers) ----------------------

    def play(self):
        """Start playback."""
        self.send_command({"cmd": "Play"})

    def stop(self):
        """Stop playback (reset to start)."""
        self.send_command({"cmd": "Stop"})

    def pause(self):
        """Pause playback (keep position)."""
        self.send_command({"cmd": "Pause"})

    def seek(self, beat: float):
        """Seek to a beat position."""
        self.send_command({"cmd": "Seek", "beat": float(beat)})

    def set_tempo(self, bpm: float):
        """Set tempo in BPM."""
        self.send_command({"cmd": "SetTempo", "bpm": float(bpm)})

    def set_time_signature(self, numerator: int, denominator: int):
        """Set time signature."""
        self.send_command({
            "cmd": "SetTimeSignature",
            "numerator": int(numerator),
            "denominator": int(denominator),
        })

    def set_loop(self, enabled: bool, start_beat: float, end_beat: float):
        """Set loop region."""
        self.send_command({
            "cmd": "SetLoop",
            "enabled": bool(enabled),
            "start_beat": float(start_beat),
            "end_beat": float(end_beat),
        })

    def add_track(self, track_id: str, track_index: int, kind: str = "audio"):
        """Add a track to the audio graph."""
        self.send_command({
            "cmd": "AddTrack",
            "track_id": str(track_id),
            "track_index": int(track_index),
            "kind": str(kind),
        })

    def remove_track(self, track_id: str):
        """Remove a track from the audio graph."""
        self.send_command({"cmd": "RemoveTrack", "track_id": str(track_id)})

    def set_track_param(self, track_index: int, param: str, value: float):
        """Set a track parameter (Volume, Pan, Mute, Solo)."""
        self.send_command({
            "cmd": "SetTrackParam",
            "track_index": int(track_index),
            "param": str(param),
            "value": float(value),
        })

    def set_instrument_param(self, track_id: str, param_name: str, value: float):
        """Set an instrument parameter on a track (R-I1.3).

        Dispatches to the Rust instrument's set_param() trait method.
        Works for ALL instruments (BachOrgel, Aeterna, Fusion, DrumMachine, etc.).

        Args:
            track_id: Track ID string (e.g. "trk_04e90a3071")
            param_name: Parameter name (e.g. "drawbar_0", "filter_cutoff", "gain")
            value: Parameter value (float, interpretation depends on instrument)
        """
        self.send_command({
            "cmd": "SetInstrumentParam",
            "track_id": str(track_id),
            "param_name": str(param_name),
            "value": float(value),
        })

    def get_instrument_param(self, track_id: str, param_name: str):
        """Request readback of a single instrument parameter (R-I1.5).

        Response arrives as InstrumentParamValue event.
        """
        self.send_command({
            "cmd": "GetInstrumentParam",
            "track_id": str(track_id),
            "param_name": str(param_name),
        })

    def get_instrument_param_dump(self, track_id: str):
        """Request all param names+values for an instrument (R-I1.5).

        Response arrives as InstrumentParamDump event with JSON map.
        """
        self.send_command({
            "cmd": "GetInstrumentParamDump",
            "track_id": str(track_id),
        })

    def set_group_routing(self, child_index: int, group_index: Optional[int]):
        """Set group bus routing."""
        self.send_command({
            "cmd": "SetGroupRouting",
            "child_track_index": int(child_index),
            "group_track_index": group_index,
        })

    def ping(self) -> int:
        """Send a ping, returns the sequence number."""
        self._ping_seq += 1
        self.send_command({"cmd": "Ping", "seq": self._ping_seq})
        return self._ping_seq

    def midi_note_on(self, track_id: str, channel: int, note: int, velocity: float):
        """Send MIDI note-on to a track."""
        self.send_command({
            "cmd": "MidiNoteOn",
            "track_id": str(track_id),
            "channel": int(channel),
            "note": int(note),
            "velocity": float(velocity),
        })

    def midi_note_off(self, track_id: str, channel: int, note: int):
        """Send MIDI note-off to a track."""
        self.send_command({
            "cmd": "MidiNoteOff",
            "track_id": str(track_id),
            "channel": int(channel),
            "note": int(note),
        })

    def midi_cc(self, track_id: str, channel: int, cc: int, value: float):
        """Send MIDI CC to a track."""
        self.send_command({
            "cmd": "MidiCC",
            "track_id": str(track_id),
            "channel": int(channel),
            "cc": int(cc),
            "value": float(value),
        })

    # --- Audio Data (Phase 1B) --------------------------------------------

    def load_audio_clip(
        self,
        clip_id: str,
        audio_data: bytes,
        channels: int = 2,
        sample_rate: int = 44100,
    ):
        """Load audio clip data into the Rust engine.

        Args:
            clip_id: Unique clip identifier.
            audio_data: Raw f32 LE interleaved PCM bytes.
            channels: Number of channels (1=mono, 2=stereo).
            sample_rate: Sample rate of the audio data.
        """
        import base64
        b64 = base64.b64encode(audio_data).decode("ascii")
        self.send_command({
            "cmd": "LoadAudioClip",
            "clip_id": str(clip_id),
            "channels": int(channels),
            "sample_rate": int(sample_rate),
            "audio_b64": b64,
        })

    def load_audio_clip_from_numpy(
        self,
        clip_id: str,
        samples: Any,
        channels: int = 2,
        sample_rate: int = 44100,
    ):
        """Load audio clip from a numpy array.

        Args:
            clip_id: Unique clip identifier.
            samples: numpy float32 array (interleaved if stereo).
            channels: Number of channels.
            sample_rate: Sample rate.
        """
        try:
            import numpy as np
            arr = np.asarray(samples, dtype=np.float32)
            self.load_audio_clip(clip_id, arr.tobytes(), channels, sample_rate)
        except ImportError:
            log.error("numpy required for load_audio_clip_from_numpy")

    def set_arrangement(self, clips: List[Dict[str, Any]]):
        """Set the arrangement (which clips play where).

        Args:
            clips: List of dicts with keys:
                clip_id (str), track_index (int), start_beat (float),
                end_beat (float), offset_samples (int), gain (float)
        """
        ipc_clips = []
        for c in clips:
            ipc_clips.append({
                "clip_id": str(c.get("clip_id", "")),
                "track_index": int(c.get("track_index", 0)),
                "start_beat": float(c.get("start_beat", 0.0)),
                "end_beat": float(c.get("end_beat", 0.0)),
                "offset_samples": int(c.get("offset_samples", 0)),
                "gain": float(c.get("gain", 1.0)),
            })
        self.send_command({
            "cmd": "SetArrangement",
            "clips": ipc_clips,
        })

    # --- R4: FX Chain Sync (v0.0.21.055) ---

    # Python plugin_id → Rust fx_type mapping
    _FX_TYPE_MAP = {
        "chrono.fx.gain": "gain", "gain": "gain", "GainFx": "gain",
        "chrono.fx.eq5": "parametric_eq", "chrono.fx.eq": "parametric_eq", "eq": "parametric_eq",
        "chrono.fx.compressor": "compressor", "compressor": "compressor",
        "chrono.fx.reverb": "reverb", "reverb": "reverb",
        "chrono.fx.delay2": "delay", "chrono.fx.delay": "delay", "delay": "delay",
        "chrono.fx.peak_limiter": "limiter", "chrono.fx.limiter": "limiter", "limiter": "limiter",
        "chrono.fx.distortion": "distortion", "distortion": "distortion",
        "chrono.fx.chorus": "chorus", "chorus": "chorus",
        "chrono.fx.flanger": "flanger", "flanger": "flanger",
        "chrono.fx.filter_plus": "phaser", "chrono.fx.phaser": "phaser", "phaser": "phaser",
        "chrono.fx.tremolo": "tremolo", "tremolo": "tremolo",
        "chrono.fx.gate": "gate", "gate": "gate",
        "chrono.fx.de_esser": "deesser", "chrono.fx.deesser": "deesser", "deesser": "deesser",
        "chrono.fx.stereo_widener": "stereo_widener", "stereo_widener": "stereo_widener",
        "chrono.fx.utility": "utility", "utility": "utility",
        "chrono.fx.spectrum_analyzer": "spectrum_analyzer", "spectrum_analyzer": "spectrum_analyzer",
        # v0.0.21.084: New FX
        "chrono.fx.comb": "comb", "comb": "comb",
        "chrono.fx.dynamics": "dynamics", "dynamics": "dynamics",
        "chrono.fx.pitch_shifter": "pitch_shifter", "pitch_shifter": "pitch_shifter",
        "chrono.fx.xy_fx": "xy_fx", "xy_fx": "xy_fx",
        "chrono.fx.distortion_plus": "distortion_plus", "distortion_plus": "distortion_plus",
    }

    def sync_fx_chains(self, fx_chains: List[Dict[str, Any]]):
        """Send FX chain configurations to Rust engine (R4.6).

        Uses individual AddFx + SetFxChainMix commands per track.
        First clears existing FX, then re-adds from Python spec.
        """
        for chain in fx_chains:
            track_id = str(chain.get("track_id", ""))
            if not track_id:
                continue
            # Clear existing FX (remove slots 15→0)
            for i in range(15, -1, -1):
                self.send_command({"cmd": "RemoveFx", "track_id": track_id, "slot_index": i})
            # Add devices
            devices = chain.get("devices", [])
            for i, dev in enumerate(devices):
                plugin_id = str(dev.get("plugin_id", ""))
                slot_id = str(dev.get("id", f"afx_{i}"))
                params = dev.get("params", {})

                # PH-1.1: External plugins → LoadPluginFx
                _ext_format = ""
                _ext_path = ""
                _ext_pid = ""
                if plugin_id.startswith("ext.vst3:"):
                    _ext_format = "vst3"
                    _raw = plugin_id.split(":", 1)[1] if ":" in plugin_id else ""
                    _ext_path = str(params.get("__ext_path") or _raw or "")
                    _ext_pid = str(params.get("__ext_plugin_name") or "")
                elif plugin_id.startswith("ext.vst2:"):
                    _ext_format = "vst2"  # Will fail in Rust (no VST2 host yet)
                    _ext_path = str(params.get("__ext_path") or plugin_id.split(":", 1)[1] or "")
                elif plugin_id.startswith("ext.clap:"):
                    _ext_format = "clap"
                    _raw = plugin_id.split(":", 1)[1] if ":" in plugin_id else ""
                    _ext_path = str(params.get("__ext_path") or _raw or "")
                    _ext_pid = str(params.get("__ext_plugin_name") or "")
                elif plugin_id.startswith("ext.lv2:"):
                    _ext_format = "lv2"
                    _ext_pid = plugin_id.split(":", 1)[1] if ":" in plugin_id else ""
                elif plugin_id.startswith("ext.ladspa:"):
                    _ext_format = "ladspa"
                    _ext_path = str(params.get("__ext_path") or plugin_id.split(":", 1)[1] or "")

                if _ext_format:
                    self.load_plugin_fx(track_id, slot_id, _ext_path, _ext_format, _ext_pid)
                else:
                    # Built-in FX
                    rust_type = self._FX_TYPE_MAP.get(plugin_id, "")
                    if not rust_type:
                        continue
                    self.send_command({
                        "cmd": "AddFx", "track_id": track_id,
                        "fx_type": rust_type, "slot_id": slot_id, "position": None,
                    })
                # RFX-2: Send initial params from widget state to Rust
                if isinstance(params, dict):
                    for pname, pval in params.items():
                        if pname.startswith("__"):
                            continue  # Skip internal meta-params
                        if isinstance(pval, (int, float)):
                            self.set_fx_param(track_id, i, str(pname), float(pval))
                if not bool(dev.get("enabled", True)):
                    self.send_command({
                        "cmd": "SetFxEnabled", "track_id": track_id,
                        "slot_index": i, "enabled": False,
                    })
            # Set chain mix
            mix = float(chain.get("mix", 1.0) or 1.0)
            self.send_command({"cmd": "SetFxChainMix", "track_id": track_id, "mix": mix})

    def set_fx_param(self, track_id: str, slot_index: int,
                     param_name: str, value: float):
        """v0.0.21.082 EFX-2: Live-update a single FX parameter on Rust engine."""
        self.send_command({
            "cmd": "SetFxParam", "track_id": str(track_id),
            "slot_index": int(slot_index), "param_name": str(param_name),
            "value": float(value),
        })

    def set_track_param_ring(self, track_index: int, param_type: int, value: float):
        """Send a parameter update via the lock-free ring buffer encoding.

        The param_id encodes track_index in the high 16 bits and
        param_type in the low 16 bits:
            0 = Volume, 1 = Pan, 2 = Mute, 3 = Solo

        This is sent as a regular SetTrackParam command; the Rust engine
        also supports the ring buffer for ultra-low-latency updates.
        """
        param_names = {0: "Volume", 1: "Pan", 2: "Mute", 3: "Solo"}
        param_name = param_names.get(param_type, "Volume")
        self.send_command({
            "cmd": "SetTrackParam",
            "track_index": int(track_index),
            "param": param_name,
            "value": float(value),
        })

    # --- IPC: MultiSample Instrument (Phase R6B) -------------------------

    def set_master_param(self, param_name: str, value: float):
        """v0.0.21.068 R-I9.4: Set master track parameter (Volume/Pan/Mute/Solo)."""
        self.send_command({
            "cmd": "SetMasterParam",
            "param": str(param_name),
            "value": float(value),
        })

    def load_instrument(self, track_id: str, instrument_type: str,
                        instrument_id: str = ""):
        """Load an instrument on a track.

        Args:
            track_id: Track identifier.
            instrument_type: One of 'pro_sampler', 'multi_sample',
                'drum_machine', 'aeterna', 'fusion', 'bach_orgel', 'sf2'.
            instrument_id: Optional unique ID (auto-generated if empty).
        """
        self.send_command({
            "cmd": "LoadInstrument",
            "track_id": str(track_id),
            "instrument_type": str(instrument_type),
            "instrument_id": str(instrument_id),
        })

    def unload_instrument(self, track_id: str):
        """Unload an instrument from a track."""
        self.send_command({
            "cmd": "UnloadInstrument",
            "track_id": str(track_id),
        })

    def load_sample(self, track_id: str, wav_path: str,
                    root_note: int = 60, fine_tune: int = 0):
        """Load a sample into a ProSampler instrument."""
        self.send_command({
            "cmd": "LoadSample",
            "track_id": str(track_id),
            "wav_path": str(wav_path),
            "root_note": int(root_note),
            "fine_tune": int(fine_tune),
        })

    def add_sample_zone(self, track_id: str, wav_path: str,
                        root_note: int = 60,
                        key_lo: int = 0, key_hi: int = 127,
                        vel_lo: int = 0, vel_hi: int = 127,
                        gain: float = 0.8, pan: float = 0.0,
                        tune_semitones: float = 0.0,
                        tune_cents: float = 0.0,
                        rr_group: int = 0):
        """Add a sample zone to a MultiSample instrument.

        Args:
            track_id: Track with a multi_sample instrument loaded.
            wav_path: Path to the WAV file.
            root_note: MIDI note that plays at original pitch.
            key_lo/key_hi: MIDI key range (0–127).
            vel_lo/vel_hi: Velocity range (0–127).
            gain: Zone gain (0.0–1.0).
            pan: Zone pan (-1.0..1.0).
            tune_semitones: Coarse tuning in semitones.
            tune_cents: Fine tuning in cents.
            rr_group: Round-robin group (0 = none, 1+ = group).
        """
        self.send_command({
            "cmd": "AddSampleZone",
            "track_id": str(track_id),
            "wav_path": str(wav_path),
            "root_note": int(root_note),
            "key_lo": int(key_lo),
            "key_hi": int(key_hi),
            "vel_lo": int(vel_lo),
            "vel_hi": int(vel_hi),
            "gain": float(gain),
            "pan": float(pan),
            "tune_semitones": float(tune_semitones),
            "tune_cents": float(tune_cents),
            "rr_group": int(rr_group),
        })

    def remove_sample_zone(self, track_id: str, zone_id: int):
        """Remove a zone from a MultiSample instrument."""
        self.send_command({
            "cmd": "RemoveSampleZone",
            "track_id": str(track_id),
            "zone_id": int(zone_id),
        })

    def clear_all_zones(self, track_id: str):
        """Clear all zones from a MultiSample instrument."""
        self.send_command({
            "cmd": "ClearAllZones",
            "track_id": str(track_id),
        })

    def set_zone_filter(self, track_id: str, zone_id: int,
                        filter_type: str = "off",
                        cutoff_hz: float = 8000.0,
                        resonance: float = 0.707,
                        env_amount: float = 0.0):
        """Set per-zone filter parameters.

        Args:
            filter_type: 'off', 'lp', 'hp', 'bp'
        """
        self.send_command({
            "cmd": "SetZoneFilter",
            "track_id": str(track_id),
            "zone_id": int(zone_id),
            "filter_type": str(filter_type),
            "cutoff_hz": float(cutoff_hz),
            "resonance": float(resonance),
            "env_amount": float(env_amount),
        })

    def set_zone_envelope(self, track_id: str, zone_id: int,
                          env_type: str = "amp",
                          attack: float = 0.005, decay: float = 0.15,
                          sustain: float = 1.0, release: float = 0.2):
        """Set per-zone envelope (amp or filter).

        Args:
            env_type: 'amp' or 'filter'
        """
        self.send_command({
            "cmd": "SetZoneEnvelope",
            "track_id": str(track_id),
            "zone_id": int(zone_id),
            "env_type": str(env_type),
            "attack": float(attack),
            "decay": float(decay),
            "sustain": float(sustain),
            "release": float(release),
        })

    def set_zone_lfo(self, track_id: str, zone_id: int,
                     lfo_index: int = 0,
                     rate_hz: float = 1.0,
                     shape: str = "sine"):
        """Set per-zone LFO parameters.

        Args:
            lfo_index: 0 or 1.
            shape: 'sine', 'triangle', 'square', 'saw', 'sample_hold'
        """
        self.send_command({
            "cmd": "SetZoneLfo",
            "track_id": str(track_id),
            "zone_id": int(zone_id),
            "lfo_index": int(lfo_index),
            "rate_hz": float(rate_hz),
            "shape": str(shape),
        })

    def set_zone_mod_slot(self, track_id: str, zone_id: int,
                          slot_index: int = 0,
                          source: str = "none",
                          destination: str = "none",
                          amount: float = 0.0):
        """Set per-zone modulation routing.

        Args:
            source: 'none', 'lfo1', 'lfo2', 'env_amp', 'env_filter',
                    'velocity', 'key_track'
            destination: 'none', 'pitch', 'filter_cutoff', 'amp', 'pan'
            amount: -1.0 .. 1.0
        """
        self.send_command({
            "cmd": "SetZoneModSlot",
            "track_id": str(track_id),
            "zone_id": int(zone_id),
            "slot_index": int(slot_index),
            "source": str(source),
            "destination": str(destination),
            "amount": float(amount),
        })

    def auto_map_zones(self, track_id: str, mode: str = "chromatic",
                       base_note: int = 60,
                       wav_paths: Optional[List[str]] = None):
        """Auto-map WAV files to zones on a MultiSample instrument.

        Args:
            mode: 'chromatic', 'drum', 'velocity_layer'
            base_note: Starting MIDI note.
            wav_paths: List of WAV file paths.
        """
        self.send_command({
            "cmd": "AutoMapZones",
            "track_id": str(track_id),
            "mode": str(mode),
            "base_note": int(base_note),
            "wav_paths": list(wav_paths or []),
        })

    # --- IPC: DrumMachine Instrument (Phase R7A) -------------------------

    def load_drum_pad_sample(self, track_id: str, pad_index: int,
                             wav_path: str):
        """Load a sample onto a drum pad.

        Args:
            track_id: Track with a drum_machine instrument loaded.
            pad_index: Pad slot (0–127).
            wav_path: Path to the WAV file.
        """
        self.send_command({
            "cmd": "LoadDrumPadSample",
            "track_id": str(track_id),
            "pad_index": int(pad_index),
            "wav_path": str(wav_path),
        })

    def clear_drum_pad(self, track_id: str, pad_index: int):
        """Clear a drum pad."""
        self.send_command({
            "cmd": "ClearDrumPad",
            "track_id": str(track_id),
            "pad_index": int(pad_index),
        })

    def set_drum_pad_param(self, track_id: str, pad_index: int,
                           param_name: str, value: float):
        """Set a drum pad parameter.

        Args:
            param_name: 'gain', 'pan', 'tune', 'choke', 'play_mode'
            value: Parameter value (play_mode: 0=one_shot, 1=gate).
        """
        self.send_command({
            "cmd": "SetDrumPadParam",
            "track_id": str(track_id),
            "pad_index": int(pad_index),
            "param_name": str(param_name),
            "value": float(value),
        })

    def clear_all_drum_pads(self, track_id: str):
        """Clear all drum pads."""
        self.send_command({
            "cmd": "ClearAllDrumPads",
            "track_id": str(track_id),
        })

    def set_drum_base_note(self, track_id: str, base_note: int = 36):
        """Set drum machine base MIDI note (default 36 = GM kick)."""
        self.send_command({
            "cmd": "SetDrumBaseNote",
            "track_id": str(track_id),
            "base_note": int(base_note),
        })

    def set_drum_pad_output(self, track_id: str, pad_index: int,
                            output_index: int = 0):
        """Set drum pad output routing (multi-output).

        Args:
            pad_index: Pad slot (0–127).
            output_index: Output bus (0=main, 1–15=aux).
        """
        self.send_command({
            "cmd": "SetDrumPadOutput",
            "track_id": str(track_id),
            "pad_index": int(pad_index),
            "output_index": int(output_index),
        })

    def set_drum_multi_output(self, track_id: str, enabled: bool = False,
                              output_count: int = 1):
        """Enable/disable drum machine multi-output.

        Args:
            enabled: Whether multi-output routing is active.
            output_count: Number of output buses (1–16).
        """
        self.send_command({
            "cmd": "SetDrumMultiOutput",
            "track_id": str(track_id),
            "enabled": bool(enabled),
            "output_count": int(output_count),
        })

    # --- LADSPA Plugin Hosting (Phase P3.3, v0.0.21.058) --------------------

    def load_ladspa_plugin(self, track_id: str, slot_index: int,
                           path: str, plugin_index: int = 0):
        """Load a LADSPA plugin (.so) into a track FX slot.

        Args:
            track_id: Target track.
            slot_index: FX slot index (0-based).
            path: Absolute path to the .so file.
            plugin_index: Plugin index within the library (usually 0).
        """
        log.info("LADSPA load: %s slot %d path=%s idx=%d",
                 track_id, slot_index, path, plugin_index)
        self.send_command({
            "cmd": "LoadLadspaPlugin",
            "track_id": str(track_id),
            "slot_index": int(slot_index),
            "path": str(path),
            "plugin_index": int(plugin_index),
        })

    def set_ladspa_param(self, track_id: str, slot_index: int,
                         port_index: int, value: float):
        """Set a LADSPA plugin control port value.

        Args:
            track_id: Target track.
            slot_index: FX slot index.
            port_index: LADSPA port index.
            value: New parameter value.
        """
        self.send_command({
            "cmd": "SetLadspaParam",
            "track_id": str(track_id),
            "slot_index": int(slot_index),
            "port_index": int(port_index),
            "value": float(value),
        })

    def unload_ladspa_plugin(self, track_id: str, slot_index: int):
        """Unload a LADSPA plugin from a track FX slot."""
        self.send_command({
            "cmd": "UnloadLadspaPlugin",
            "track_id": str(track_id),
            "slot_index": int(slot_index),
        })

    # --- External Plugin Hosting (Phase P7) --------------------------------

    def scan_plugins(self):
        """Request a full scan of all installed plugins (VST3 + CLAP + LV2).

        Results come back as a 'PluginScanResult' event.
        v0.0.20.718: Phase P7 Integration.
        """
        self.send_command({"cmd": "ScanPlugins"})

    def load_plugin(self, track_id: str, slot_index: int,
                    plugin_path: str, plugin_format: str,
                    plugin_id: str = ""):
        """Load an external plugin on a track.

        Args:
            track_id: Track ID string.
            slot_index: FX slot index (0-7).
            plugin_path: Path to .vst3 bundle, .clap file, or "" for LV2.
            plugin_format: "vst3", "clap", or "lv2".
            plugin_id: VST3 class_id, CLAP plugin_id, or LV2 URI.
                        Empty string = load first plugin in bundle.

        Results come back as 'PluginLoaded' event on success,
        or 'Error' event on failure.
        v0.0.20.718: Phase P7 Integration.
        """
        self.send_command({
            "cmd": "LoadPlugin",
            "track_id": str(track_id),
            "slot_index": int(slot_index),
            "plugin_path": str(plugin_path),
            "plugin_format": str(plugin_format),
            "plugin_id": str(plugin_id),
        })

    def unload_plugin(self, track_id: str, slot_index: int):
        """Unload a plugin from a track slot.

        v0.0.20.718: Phase P7 Integration.
        """
        self.send_command({
            "cmd": "UnloadPlugin",
            "track_id": str(track_id),
            "slot_index": int(slot_index),
        })

    def load_plugin_fx(self, track_id: str, slot_id: str,
                       plugin_path: str, plugin_format: str,
                       plugin_id: str = "", position: int = None):
        """v0.0.21.088 PH-1.9: Load external plugin into Rust FX chain.

        Args:
            track_id: Target track.
            slot_id: Unique FX slot identifier.
            plugin_path: Path to .vst3 bundle, .clap file, .so (LADSPA).
            plugin_format: "vst3", "clap", "lv2", "ladspa".
            plugin_id: VST3 class_id, CLAP plugin_id, LV2 URI.
            position: Insert position (None = append).
        """
        self.send_command({
            "cmd": "LoadPluginFx",
            "track_id": str(track_id),
            "slot_id": str(slot_id),
            "plugin_path": str(plugin_path),
            "plugin_format": str(plugin_format),
            "plugin_id": str(plugin_id or ""),
            "position": position,
        })

    def set_plugin_param(self, track_id: str, slot_index: int,
                         param_index: int, value: float):
        """Set an external plugin parameter.

        v0.0.20.718: Phase P7 Integration.
        """
        self.send_command({
            "cmd": "SetPluginParam",
            "track_id": str(track_id),
            "slot_index": int(slot_index),
            "param_index": int(param_index),
            "value": float(value),
        })

    def save_plugin_state(self, track_id: str, slot_index: int):
        """Request plugin state blob (comes back as PluginState event).

        v0.0.20.718: Phase P7 Integration.
        """
        self.send_command({
            "cmd": "SavePluginState",
            "track_id": str(track_id),
            "slot_index": int(slot_index),
        })

    def load_plugin_state(self, track_id: str, slot_index: int,
                          state_b64: str):
        """Load a plugin state from a base64-encoded blob.

        v0.0.20.718: Phase P7 Integration.
        """
        self.send_command({
            "cmd": "LoadPluginState",
            "track_id": str(track_id),
            "slot_index": int(slot_index),
            "state_b64": str(state_b64),
        })

    # --- Rust Audio Output (Phase RA1.3, v0.0.20.959) --------------------

    def audio_start(self, device: str = "", sample_rate: int = 48000,
                    buffer_size: int = 256):
        """Start Rust audio output via cpal.

        This tells the Rust engine to open an audio device and start
        outputting audio directly. Python's sounddevice engine should
        be stopped before calling this.

        Args:
            device: Audio device name (empty = default).
            sample_rate: Sample rate in Hz (44100, 48000, 96000).
            buffer_size: Buffer size in frames (64–1024).

        Response events:
            AudioStarted — on success
            AudioError — on failure
        """
        self.send_command({
            "cmd": "AudioStart",
            "device": str(device),
            "sample_rate": int(sample_rate),
            "buffer_size": int(buffer_size),
        })

    def audio_stop(self):
        """Stop Rust audio output (release audio device)."""
        self.send_command({"cmd": "AudioStop"})

    def audio_test_sine(self, enabled: bool = True):
        """Start/stop a 440Hz test sine through Rust audio.

        If audio is not running, it will be auto-started with defaults.
        Use this to verify Rust audio output is working.

        Args:
            enabled: True to start test tone, False to stop.
        """
        self.send_command({
            "cmd": "AudioTestSine",
            "enabled": bool(enabled),
        })

    def enumerate_audio_devices(self):
        """Query available audio output devices from cpal.

        Response event: AudioDeviceList
        """
        self.send_command({"cmd": "EnumerateAudioDevices"})

    def audio_status(self):
        """Query current Rust audio output status.

        Response event: AudioStatusReport
        """
        self.send_command({"cmd": "AudioStatus"})

    # --- v0.0.20.984: NS2 — Symphonia Audio Decode -------------------------

    def decode_audio(self, path: str, target_sr: int = 0, callback=None):
        """Decode an audio file via Rust/Symphonia.

        Supports: MP3, OGG, AAC/M4A, FLAC, WAV, AIFF

        Args:
            path: Path to audio file
            target_sr: Target sample rate (0 = keep original)
            callback: Optional callback(event_dict) or callback(None, error_str)

        The result comes asynchronously via AudioDecoded event.
        If callback is provided, it will be called with the result.
        """
        import uuid
        request_id = str(uuid.uuid4())[:8]

        if callback is not None:
            self._decode_callbacks[request_id] = callback

        self.send_command({
            "cmd": "DecodeAudio",
            "request_id": request_id,
            "path": str(path),
            "target_sr": int(target_sr),
        })
        return request_id

    def decode_audio_sync(self, path: str, target_sr: int = 0,
                          timeout: float = 30.0):
        """Synchronous audio decode — blocks until result is ready.

        Args:
            path: Path to audio file
            target_sr: Target sample rate (0 = keep original)
            timeout: Max wait time in seconds

        Returns:
            numpy array of interleaved f32 samples, or None on error.
            Also returns (samples, sample_rate, channels, duration).
        """
        import threading
        result_holder = [None, None]  # [event_dict, error_str]
        done = threading.Event()

        def _cb(*args):
            if len(args) == 1:
                result_holder[0] = args[0]
            elif len(args) == 2:
                result_holder[1] = args[1]
            done.set()

        self.decode_audio(path, target_sr, callback=_cb)

        if not done.wait(timeout):
            log.warning("decode_audio_sync timed out after %.0fs", timeout)
            return None

        if result_holder[1] is not None:
            log.warning("decode_audio_sync error: %s", result_holder[1])
            return None

        event = result_holder[0]
        if event is None:
            return None

        try:
            import base64
            import numpy as np
            b64 = event.get("audio_b64", "")
            raw = base64.b64decode(b64)
            samples = np.frombuffer(raw, dtype=np.float32)
            sr = event.get("sample_rate", 0)
            ch = event.get("channels", 2)
            dur = event.get("duration_secs", 0.0)
            return samples, sr, ch, dur
        except Exception as e:
            log.warning("decode_audio_sync parse error: %s", e)
            return None

    # --- v0.0.20.980: Python → Rust Audio Streaming (NS6.2) ---------------

    def audio_stream_mode(self, enabled: bool):
        """Enable/disable Python→Rust audio streaming.

        When enabled:
          - Python renders audio (instruments/FX/clips)
          - Sends rendered buffers via send_audio_data()
          - Rust outputs them through cpal

        When disabled:
          - Rust goes back to silence/test sine mode
          - Ring buffer is cleared
        """
        self.send_command({"cmd": "AudioStreamMode", "enabled": enabled})

    def send_audio_data(self, samples):
        """Send rendered audio samples to Rust for output via cpal.

        Args:
            samples: numpy float32 array, interleaved stereo (L,R,L,R,...)
                     or (frames, 2) shaped array.

        v0.0.20.981: Uses raw bytes (not JSON list) for zero-overhead transfer.
        msgpack binary type sends the raw f32 bytes directly — no float→string
        conversion, no Python list creation, ~100x faster than tolist().
        """
        try:
            import numpy as np
            if isinstance(samples, np.ndarray):
                if samples.ndim == 2:
                    # (frames, 2) → interleaved
                    samples = samples.flatten()
                raw = samples.astype(np.float32).tobytes()
            else:
                import struct
                raw = struct.pack(f'{len(samples)}f', *samples)
            self.send_command({"cmd": "AudioData", "raw": raw})
        except Exception:
            pass

    # --- IPC: Video Engine Commands (v0.0.20.970: RM2) --------------------

    def video_set_frame_rate(self, fps: str, drop_frame: bool = False):
        """Set video timeline frame rate."""
        self.send_command({"cmd": "VideoSetFrameRate", "fps": fps, "drop_frame": drop_frame})

    def video_add_clip(self, track_id: str, file_path: str, start_beat: float, length_beats: float):
        """Add a video clip to the timeline."""
        self.send_command({"cmd": "VideoAddClip", "track_id": track_id,
                           "file_path": file_path, "start_beat": start_beat,
                           "length_beats": length_beats})

    def video_remove_clip(self, clip_id: str):
        """Remove a video clip."""
        self.send_command({"cmd": "VideoRemoveClip", "clip_id": clip_id})

    def video_move_clip(self, clip_id: str, new_start: float, new_track: str = None):
        """Move a video clip."""
        self.send_command({"cmd": "VideoMoveClip", "clip_id": clip_id,
                           "new_start": new_start, "new_track": new_track})

    def video_split_clip(self, clip_id: str, split_beat: float):
        """Split a video clip at the given beat."""
        self.send_command({"cmd": "VideoSplitClip", "clip_id": clip_id,
                           "split_beat": split_beat})

    def video_set_clip_param(self, clip_id: str, param: str, value: float):
        """Set a video clip parameter (opacity, speed, blend_mode)."""
        self.send_command({"cmd": "VideoSetClipParam", "clip_id": clip_id,
                           "param": param, "value": value})

    def video_ripple_delete(self, clip_id: str):
        """Ripple delete a video clip (close the gap)."""
        self.send_command({"cmd": "VideoRippleDelete", "clip_id": clip_id})

    def video_add_filter(self, clip_id: str, filter_type: str):
        """Add a video filter to a clip."""
        self.send_command({"cmd": "VideoAddFilter", "clip_id": clip_id,
                           "filter_type": filter_type})

    def video_set_filter_param(self, clip_id: str, filter_index: int, param: str, value: float):
        """Set a video filter parameter."""
        self.send_command({"cmd": "VideoSetFilterParam", "clip_id": clip_id,
                           "filter_index": filter_index, "param": param, "value": value})

    def video_apply_preset(self, clip_id: str, preset: str):
        """Apply a film look preset (blade_runner, matrix, etc.)."""
        self.send_command({"cmd": "VideoApplyPreset", "clip_id": clip_id, "preset": preset})

    def video_add_transition(self, track_id: str, position_beat: float,
                             duration_beats: float, transition_type: str):
        """Add a transition between video clips."""
        self.send_command({"cmd": "VideoAddTransition", "track_id": track_id,
                           "position_beat": position_beat, "duration_beats": duration_beats,
                           "transition_type": transition_type})

    def video_set_automation(self, clip_id: str, target: str, beat: float,
                             value: float, curve: str = "linear"):
        """Set a video automation breakpoint."""
        self.send_command({"cmd": "VideoSetAutomation", "clip_id": clip_id,
                           "target": target, "beat": beat, "value": value, "curve": curve})

    def video_analyze(self, clip_id: str, analysis_type: str):
        """Analyze video clip (scenes, silence, fillers, highlights)."""
        self.send_command({"cmd": "VideoAnalyze", "clip_id": clip_id,
                           "analysis_type": analysis_type})

    def video_smart_cut(self, clip_id: str):
        """Smart cut: auto-remove silence and fillers."""
        self.send_command({"cmd": "VideoSmartCut", "clip_id": clip_id})

    def video_highlight_reel(self, target_duration_secs: float):
        """Generate highlight reel from timeline."""
        self.send_command({"cmd": "VideoHighlightReel",
                           "target_duration_secs": target_duration_secs})

    # --- R8: Audio Export (v0.0.21.055) ---

    def audio_export(self, output_path: str, format: str = "wav24",
                     start_beat: float = None, end_beat: float = None):
        """Start offline audio export (R8).

        Args:
            output_path: Output file path.
            format: wav16, wav24, wav32float, flac16, flac24.
            start_beat: Start position (None = beginning).
            end_beat: End position (None = end of arrangement).
        """
        self.send_command({
            "cmd": "AudioExport",
            "output_path": str(output_path),
            "format": str(format),
            "start_beat": float(start_beat) if start_beat is not None else None,
            "end_beat": float(end_beat) if end_beat is not None else None,
        })

    def audio_export_cancel(self):
        """Cancel a running audio export."""
        self.send_command({"cmd": "AudioExportCancel"})

    def video_export(self, fmt: str):
        """Export timeline (edl, xml, srt, vtt, aaf)."""
        self.send_command({"cmd": "VideoExport", "format": fmt})

    def multicam_add_camera(self, name: str, file_path: str):
        """Add a camera source for multi-cam editing."""
        self.send_command({"cmd": "MultiCamAddCamera", "name": name, "file_path": file_path})

    def multicam_sync(self):
        """Sync all multi-cam sources by audio correlation."""
        self.send_command({"cmd": "MultiCamSync"})

    def multicam_switch(self, beat: float, camera_id: str):
        """Switch camera at a beat position."""
        self.send_command({"cmd": "MultiCamSwitch", "beat": beat, "camera_id": camera_id})

    def video_get_timecode(self, beat: float):
        """Get formatted timecode at beat position."""
        self.send_command({"cmd": "VideoGetTimecode", "beat": beat})

    def sync_project_model(self, project_json: str):
        """Sync full project model to Rust engine."""
        self.send_command({"cmd": "SyncProjectModel", "project_json": project_json})

    # --- IPC: Recording Commands (v0.0.20.971: RM3.4) ---------------------

    def record_arm(self, track_id: str):
        """Arm a track for recording."""
        self.send_command({"cmd": "RecordArm", "track_id": track_id})

    def record_disarm(self, track_id: str):
        """Disarm a track."""
        self.send_command({"cmd": "RecordDisarm", "track_id": track_id})

    def record_start(self):
        """Start recording on all armed tracks."""
        self.send_command({"cmd": "RecordStart"})

    def record_stop(self):
        """Stop recording."""
        self.send_command({"cmd": "RecordStop"})

    def record_configure(self, track_id: str, channels: int = 2,
                         output_dir: str = "", input_device: int = None):
        """Configure recording for a track."""
        self.send_command({"cmd": "RecordConfigure", "track_id": track_id,
                           "channels": channels, "output_dir": output_dir,
                           "input_device": input_device})

    # --- IPC: MIDI Input Commands (v0.0.20.971: RM4.1) --------------------

    def midi_list_ports(self):
        """List available MIDI input ports."""
        self.send_command({"cmd": "MidiListPorts"})

    def midi_open_port(self, port_index: int):
        """Open a MIDI input port."""
        self.send_command({"cmd": "MidiOpenPort", "port_index": port_index})

    def midi_close_port(self, port_index: int):
        """Close a MIDI input port."""
        self.send_command({"cmd": "MidiClosePort", "port_index": port_index})

    def midi_learn_start(self, target_param: str):
        """Start MIDI Learn for a parameter."""
        self.send_command({"cmd": "MidiLearnStart", "target_param": target_param})

    def midi_learn_cancel(self):
        """Cancel MIDI Learn."""
        self.send_command({"cmd": "MidiLearnCancel"})

    def midi_add_mapping(self, cc: int, channel: int, target_param: str,
                         target_track: str = None, min_val: float = 0.0, max_val: float = 1.0):
        """Add a MIDI CC mapping."""
        self.send_command({"cmd": "MidiAddMapping", "cc": cc, "channel": channel,
                           "target_param": target_param, "target_track": target_track,
                           "min_value": min_val, "max_value": max_val})

    # --- IPC: Input Monitoring (v0.0.21.056: R7.3) ------------------------

    def set_input_monitoring(self, track_id: str, enabled: bool):
        """Enable/disable input monitoring for a track."""
        self.send_command({"cmd": "SetInputMonitoring", "track_id": track_id,
                           "enabled": enabled})

    # --- IPC: Waveform Peaks (v0.0.21.056: R6) ----------------------------

    def generate_waveform_peaks(self, clip_id: str, peaks_per_second: int = 200):
        """Request waveform peak data from Rust engine.

        Rust generates min/max peaks and sends WaveformPeaks event back.
        """
        self.send_command({"cmd": "GenerateWaveformPeaks", "clip_id": clip_id,
                           "peaks_per_second": peaks_per_second})

    # --- IPC: Plugin GUI (v0.0.21.056: R5.5) ------------------------------

    def plugin_open_gui(self, track_id: str, slot_index: int,
                        parent_window_id: int = 0):
        """Request plugin GUI window opening.

        Rust creates the editor and returns the X11 window ID
        for embedding into the Qt UI via PluginGuiOpened event.
        """
        self.send_command({"cmd": "PluginOpenGui", "track_id": track_id,
                           "slot_index": slot_index,
                           "parent_window_id": parent_window_id})

    def plugin_close_gui(self, track_id: str, slot_index: int):
        """Close plugin GUI window."""
        self.send_command({"cmd": "PluginCloseGui", "track_id": track_id,
                           "slot_index": slot_index})

    def plugin_resize_gui(self, track_id: str, slot_index: int,
                          width: int, height: int):
        """Resize plugin GUI window."""
        self.send_command({"cmd": "PluginResizeGui", "track_id": track_id,
                           "slot_index": slot_index,
                           "width": width, "height": height})

    # --- IPC: Performance Benchmark (v0.0.21.056: R9.3) -------------------

    def request_benchmark(self):
        """Request performance benchmark data from Rust engine.

        Engine responds with PerformanceBenchmark event.
        """
        self.send_command({"cmd": "RequestBenchmark"})

    # --- IPC: Database Commands (v0.0.20.971: RM1.3) ----------------------

    def db_save_project(self):
        """Save project to SQLite database."""
        self.send_command({"cmd": "DbSaveProject"})

    def db_load_project(self, db_path: str):
        """Load project from SQLite database."""
        self.send_command({"cmd": "DbLoadProject", "db_path": db_path})

    def db_set_setting(self, key: str, value: str, category: str = "general"):
        """Store a setting in the database."""
        self.send_command({"cmd": "DbSetSetting", "key": key,
                           "value": value, "category": category})

    def db_get_setting(self, key: str):
        """Get a setting from the database."""
        self.send_command({"cmd": "DbGetSetting", "key": key})

    # --- IPC: Receive Events (background thread) --------------------------

    def _reader_loop(self):
        """Background thread: read events from engine, dispatch via signals.

        v0.0.20.725: Better error categorization + graceful disconnect handling.
        v0.0.20.746: P0A — Auto-reconnect with exponential backoff on EOF.
        """
        log.info("IPC reader loop started")
        consecutive_errors = 0
        max_consecutive_errors = 5
        while self._running and self._socket:
            try:
                payload = _recv_frame(self._socket)
                if payload is None:
                    if not self._shutting_down:
                        log.info("Engine disconnected (EOF) — attempting reconnect")
                        # v0.0.20.746: trigger reconnect from the reader thread
                        self._connected = False
                        self._schedule_reconnect()
                    break
                event = _decode_frame(payload)
                self._dispatch_event(event)
                consecutive_errors = 0  # Reset on success
            except (socket.error, OSError) as e:
                if self._shutting_down or not self._running:
                    break
                consecutive_errors += 1
                if consecutive_errors >= max_consecutive_errors:
                    log.error("IPC reader: %d consecutive errors, giving up: %s",
                              consecutive_errors, e)
                    self._connected = False
                    self._schedule_reconnect()
                    break
                log.warning("IPC reader error (%d/%d): %s",
                            consecutive_errors, max_consecutive_errors, e)
                import time
                time.sleep(0.1)  # Brief pause before retry
            except Exception as e:
                if self._shutting_down or not self._running:
                    break
                log.error("Event dispatch error: %s", e)

        self._connected = False
        if not self._shutting_down:
            log.info("IPC reader loop ended (engine disconnected)")
        else:
            log.info("IPC reader loop ended (shutdown)")

    def _schedule_reconnect(self):
        """Schedule an exponential-backoff reconnect attempt on the Qt timer thread.

        v0.0.20.746: P0A Fix — called when reader thread detects EOF.
        Avoids attempting reconnect from the reader daemon thread directly
        (which would block the thread and create race conditions).
        """
        if self._shutting_down or not _QT_AVAILABLE:
            return
        # Use a one-shot QTimer to hop back to the Qt main thread safely.
        try:
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(500, self._do_reconnect_with_backoff)
        except Exception as e:
            log.warning("Could not schedule reconnect: %s", e)

    def _do_reconnect_with_backoff(self):
        """Attempt to reconnect to the engine with exponential backoff.

        v0.0.20.781: The Rust engine now has a listener loop — it stays alive
        across client disconnects. So we just reconnect to the existing socket
        instead of killing and restarting the engine process.

        v0.0.20.746: P0A Fix (original implementation killed/restarted).
        """
        MAX_RECONNECT_ATTEMPTS = 5

        reconnect_count = getattr(self, '_reconnect_count', 0)

        if reconnect_count >= MAX_RECONNECT_ATTEMPTS:
            log.error(
                "Auto-reconnect failed after %d attempts — falling back to Python engine",
                MAX_RECONNECT_ATTEMPTS,
            )
            self._reconnect_count = 0
            if _QT_AVAILABLE:
                self.engine_error.emit(
                    9998,
                    f"Rust engine could not reconnect after {MAX_RECONNECT_ATTEMPTS} "
                    "attempts. Falling back to Python engine.",
                )
            return

        if self._shutting_down:
            return

        delay_s = 2 ** reconnect_count  # 1s, 2s, 4s
        self._reconnect_count = reconnect_count + 1

        log.info(
            "Auto-reconnect attempt %d/%d (delay was %ds)...",
            self._reconnect_count, MAX_RECONNECT_ATTEMPTS, delay_s,
        )

        # Close stale socket
        if self._socket:
            try:
                self._socket.close()
            except Exception:
                pass
            self._socket = None

        # v0.0.20.791: Try to reconnect to the EXISTING engine first.
        # This works whether the engine was started by start_daw.sh (external)
        # or by the bridge (self._process). The engine's listener loop stays
        # alive across client disconnects.
        success = False

        # Always try socket reconnect first (cheapest option)
        if os.path.exists(self._socket_path):
            log.info("Socket exists — trying reconnect...")
            try:
                success = self._connect()
            except Exception as e:
                log.warning("Socket reconnect failed: %s", e)
                success = False

        if not success and self._process and self._process.poll() is None:
            # Engine process is ours and still running — wait a moment and retry
            log.info("Engine process alive (PID %d) — retrying socket...",
                     self._process.pid)
            import time as _time
            _time.sleep(0.5)
            try:
                success = self._connect()
            except Exception:
                success = False

        if not success:
            # Engine process is dead or external engine gone — full restart
            log.info("Engine not reachable — full restart")
            self._kill_process()
            try:
                success = self.start_engine(
                    self._socket_path,
                    self._sample_rate,
                    self._buffer_size,
                )
            except Exception as e:
                log.error("Reconnect attempt %d failed: %s", self._reconnect_count, e)
                success = False

        if success:
            log.info("Auto-reconnect succeeded on attempt %d!", self._reconnect_count)
            self._reconnect_count = 0
            if _QT_AVAILABLE:
                self.engine_error.emit(0, "Rust engine reconnected successfully")
        else:
            log.warning(
                "Reconnect attempt %d failed — retrying in %ds",
                self._reconnect_count, delay_s * 2,
            )
            if _QT_AVAILABLE:
                from PyQt6.QtCore import QTimer
                QTimer.singleShot(delay_s * 2000, self._do_reconnect_with_backoff)

    def _dispatch_event(self, event: dict):
        """Dispatch a decoded event to the appropriate Qt signal.

        v0.0.20.666: Guarded against deleted C++ objects and shutdown state
        to prevent error-flood that freezes the GUI.
        """
        # Safety: do not emit signals during/after shutdown
        if self._shutting_down or not self._running:
            return

        evt_type = event.get("evt", "")

        try:
            if evt_type == "PlayheadPosition":
                if _QT_AVAILABLE:
                    self.playhead_changed.emit(
                        event.get("beat", 0.0),
                        event.get("sample_position", 0),
                        event.get("is_playing", False),
                    )

            elif evt_type == "TransportState":
                if _QT_AVAILABLE:
                    self.transport_state_changed.emit(
                        event.get("is_playing", False),
                        event.get("beat", 0.0),
                    )

            elif evt_type == "MasterMeterLevel":
                if _QT_AVAILABLE:
                    self.master_meter_changed.emit(
                        event.get("peak_l", 0.0),
                        event.get("peak_r", 0.0),
                        event.get("rms_l", 0.0),
                        event.get("rms_r", 0.0),
                    )

            elif evt_type == "MeterLevels":
                levels = event.get("levels", [])
                if _QT_AVAILABLE and levels:
                    parsed = [
                        (
                            lv.get("track_index", 0),
                            lv.get("peak_l", 0.0),
                            lv.get("peak_r", 0.0),
                            lv.get("rms_l", 0.0),
                            lv.get("rms_r", 0.0),
                        )
                        for lv in levels
                    ]
                    self.track_meters_changed.emit(parsed)

            elif evt_type == "Ready":
                log.info(
                    "Engine ready: sr=%s, buf=%s, dev='%s'",
                    event.get("sample_rate"),
                    event.get("buffer_size"),
                    event.get("device_name"),
                )
                if _QT_AVAILABLE:
                    self.engine_ready.emit(
                        event.get("sample_rate", 44100),
                        event.get("buffer_size", 512),
                        event.get("device_name", ""),
                    )

            elif evt_type == "Pong":
                self._last_pong_time = time.monotonic()
                self._last_cpu_load = float(event.get("cpu_load", 0.0))
                self._last_render_time_us = float(event.get("render_time_us", 0.0))
                self._last_xrun_count = int(event.get("xrun_count", 0))
                if _QT_AVAILABLE:
                    self.engine_pong.emit(
                        event.get("seq", 0),
                        event.get("cpu_load", 0.0),
                        event.get("xrun_count", 0),
                    )

            elif evt_type == "Error":
                log.error("Engine error [%d]: %s", event.get("code", 0), event.get("message", ""))
                if _QT_AVAILABLE:
                    self.engine_error.emit(
                        event.get("code", 0),
                        event.get("message", ""),
                    )

            elif evt_type == "PluginCrash":
                log.error(
                    "Plugin crash: track=%s slot=%d: %s",
                    event.get("track_id"),
                    event.get("slot_index", 0),
                    event.get("message", ""),
                )
                if _QT_AVAILABLE:
                    self.plugin_crashed.emit(
                        event.get("track_id", ""),
                        event.get("slot_index", 0),
                        event.get("message", ""),
                    )

            elif evt_type == "PluginState":
                # Plugin state is handled by specific callbacks
                log.debug(
                    "Plugin state received: track=%s slot=%d",
                    event.get("track_id"),
                    event.get("slot_index", 0),
                )

            elif evt_type == "PluginScanResult":
                plugins = event.get("plugins", [])
                scan_ms = event.get("scan_time_ms", 0)
                errors = event.get("errors", [])
                log.info(
                    "Plugin scan complete: %d plugins in %dms (%d errors)",
                    len(plugins), scan_ms, len(errors),
                )
                if _QT_AVAILABLE:
                    self.plugin_scan_result.emit(plugins, scan_ms, errors)

            elif evt_type == "PluginLoaded":
                log.info(
                    "Plugin loaded: %s '%s' on track=%s slot=%d (%d params, %d lat)",
                    event.get("plugin_format", ""),
                    event.get("plugin_name", ""),
                    event.get("track_id", ""),
                    event.get("slot_index", 0),
                    event.get("param_count", 0),
                    event.get("latency_samples", 0),
                )
                if _QT_AVAILABLE:
                    self.plugin_loaded.emit(
                        event.get("track_id", ""),
                        event.get("slot_index", 0),
                        event.get("plugin_name", ""),
                        event.get("plugin_format", ""),
                        event.get("param_count", 0),
                        event.get("latency_samples", 0),
                    )

            # v0.0.20.959: Rust Audio Output Events (Phase RA1.3)

            elif evt_type == "AudioStarted":
                dev = event.get("device_name", "")
                sr = event.get("sample_rate", 0)
                buf = event.get("buffer_size", 0)
                lat = event.get("latency_ms", 0.0)
                log.info(
                    "Rust audio started: %s @ %dHz, buf=%d, latency=%.1fms",
                    dev, sr, buf, lat,
                )
                if _QT_AVAILABLE:
                    self.audio_started.emit(dev, sr, buf, lat)

            elif evt_type == "AudioStopped":
                log.info("Rust audio stopped")
                if _QT_AVAILABLE:
                    self.audio_stopped.emit()

            elif evt_type == "AudioError":
                msg = event.get("message", "Unknown audio error")
                log.error("Rust audio error: %s", msg)
                if _QT_AVAILABLE:
                    self.audio_error.emit(msg)

            elif evt_type == "AudioDeviceList":
                devices = event.get("devices", [])
                log.info("Rust audio: %d devices available", len(devices))
                if _QT_AVAILABLE:
                    self.audio_device_list.emit(devices)

            elif evt_type == "AudioStatusReport":
                log.debug(
                    "Rust audio status: active=%s, dev=%s, sr=%d, xruns=%d",
                    event.get("is_active", False),
                    event.get("device_name", ""),
                    event.get("sample_rate", 0),
                    event.get("xrun_count", 0),
                )
                if _QT_AVAILABLE:
                    self.audio_status_report.emit(event)

            # -- Audio Decode Events (v0.0.20.984: NS2) --------------------

            elif evt_type == "AudioDecoded":
                rid = event.get("request_id", "")
                log.info(
                    "Audio decoded: %s — %s, %dHz, %dch, %.1fs",
                    rid, event.get("codec", ""),
                    event.get("sample_rate", 0),
                    event.get("channels", 0),
                    event.get("duration_secs", 0),
                )
                # Store result for pending decode request
                cb = self._decode_callbacks.pop(rid, None)
                if cb is not None:
                    try:
                        cb(event)
                    except Exception as e:
                        log.warning("Decode callback error: %s", e)

            elif evt_type == "AudioDecodeError":
                rid = event.get("request_id", "")
                err = event.get("error", "unknown")
                log.warning("Audio decode failed: %s — %s", rid, err)
                cb = self._decode_callbacks.pop(rid, None)
                if cb is not None:
                    try:
                        cb(None, err)
                    except Exception:
                        pass

            # -- Video Engine Events (v0.0.20.970: RM2) --------------------

            elif evt_type == "VideoClipAdded":
                log.info("Video clip added: %s", event.get("clip_id", ""))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "VideoClipRemoved":
                log.info("Video clip removed: %s", event.get("clip_id", ""))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "VideoAnalysisResult":
                log.info("Video analysis: %s for %s",
                         event.get("analysis_type", ""), event.get("clip_id", ""))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "VideoExportComplete":
                log.info("Video export complete: %s", event.get("format", ""))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "VideoExportError":
                log.error("Video export error: %s — %s",
                          event.get("format", ""), event.get("error", ""))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "VideoTimecodeAt":
                log.debug("Timecode at beat %.2f: %s",
                          event.get("beat", 0.0), event.get("timecode", ""))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "MultiCamSyncResult":
                log.info("Multi-cam sync complete")
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "VideoSmartCutResult":
                log.info("Smart cut result for %s", event.get("clip_id", ""))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "VideoHighlightResult":
                log.info("Highlight reel generated")
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "ProjectModelSynced":
                log.info("Project model synced: %d tracks, %d clips",
                         event.get("num_tracks", 0), event.get("num_clips", 0))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            # -- Recording Events (v0.0.20.971: RM3.4) --------------------

            elif evt_type == "RecordStarted":
                log.info("Recording started: %s", event.get("track_id", ""))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "RecordStopped":
                log.info("Recording stopped: %s (%d samples)",
                         event.get("track_id", ""), event.get("num_samples", 0))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "RecordArmedChanged":
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            # -- MIDI Events (v0.0.20.971: RM4.1) -------------------------

            elif evt_type == "MidiPortList":
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "MidiPortOpened":
                log.info("MIDI port opened: %s", event.get("port_name", ""))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "MidiPortClosed":
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "MidiLearnResult":
                log.info("MIDI Learn: CC%d → %s",
                         event.get("cc", 0), event.get("target_param", ""))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "MidiInputEvent":
                # High-frequency — don't log
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            # -- Database Events (v0.0.20.971: RM1.3) ---------------------

            elif evt_type in ("DbProjectSaved", "DbProjectLoaded",
                              "DbSettingValue", "DbError"):
                if evt_type == "DbError":
                    log.error("DB error: %s", event.get("message", ""))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            # -- Waveform Peaks (v0.0.21.056: R6) ----------------------------

            elif evt_type == "WaveformPeaks":
                clip_id = event.get("clip_id", "")
                num_peaks = event.get("num_peaks", 0)
                log.info("WaveformPeaks received: clip=%s, %d peaks", clip_id, num_peaks)
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            # -- Plugin GUI (v0.0.21.056: R5.5) ----------------------------

            elif evt_type == "PluginGuiOpened":
                log.info("PluginGuiOpened: track=%s slot=%d win=0x%x %dx%d",
                         event.get("track_id", ""), event.get("slot_index", 0),
                         event.get("window_id", 0),
                         event.get("width", 0), event.get("height", 0))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "PluginGuiClosed":
                log.info("PluginGuiClosed: track=%s slot=%d",
                         event.get("track_id", ""), event.get("slot_index", 0))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            # -- Input Monitoring (v0.0.21.056: R7.3) ----------------------

            elif evt_type == "InputMonitoringChanged":
                log.info("InputMonitoringChanged: track=%s enabled=%s",
                         event.get("track_id", ""), event.get("enabled", False))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            # -- Performance Benchmark (v0.0.21.056: R9.3) -----------------

            elif evt_type == "PerformanceBenchmark":
                log.info("PerformanceBenchmark: cpu=%.1f%% render=%.0fus tracks=%d plugins=%d xruns=%d",
                         event.get("cpu_load", 0) * 100,
                         event.get("avg_render_us", 0),
                         event.get("active_tracks", 0),
                         event.get("active_plugins", 0),
                         event.get("xrun_count", 0))
                if _QT_AVAILABLE:
                    self.generic_event.emit(event)

            elif evt_type == "ShuttingDown":
                log.info("Engine confirmed shutdown")
                if _QT_AVAILABLE:
                    self.engine_shutdown.emit()

            else:
                log.debug("Unknown event type: %s", evt_type)

        except RuntimeError as e:
            # v0.0.20.666: "wrapped C/C++ object has been deleted" — stop immediately
            if "deleted" in str(e):
                self._shutting_down = True
                self._running = False
                log.warning("RustEngineBridge Qt object deleted — stopping event dispatch")
            else:
                log.error("Error dispatching event '%s': %s", evt_type, e)
        except Exception as e:
            log.error("Error dispatching event '%s': %s", evt_type, e)

    # --- Health Check -----------------------------------------------------

    def _health_check(self):
        """Periodic health check (called from Qt timer).

        v0.0.20.725: Added auto-reconnect on unexpected engine death.
        v0.0.20.746: P0A — delegates to exponential backoff reconnect.
        """
        if self._shutting_down:
            return

        # v0.0.20.722: Only check process health if WE started the process.
        if self._process is not None:
            if self._process.poll() is not None:
                exit_code = self._process.returncode
                log.warning(
                    "Engine process died unexpectedly! (exit code: %s) — scheduling reconnect",
                    exit_code,
                )
                self._connected = False
                self._running = False
                # v0.0.20.746: Use the new exponential-backoff reconnect path.
                self._schedule_reconnect()
                return
        elif not self._connected:
            # Socket-level disconnect detected (e.g. EOF already handled by reader).
            return

        # Engine is alive — send periodic ping to verify IPC health.
        self.ping()

    # --- Feature Flag Integration -----------------------------------------

    @staticmethod
    def is_available() -> bool:
        """Check if the Rust engine is available (binary exists)."""
        return _find_engine_binary() is not None

    @staticmethod
    def is_enabled() -> bool:
        """Check if the Rust engine is available.

        v0.0.20.722: Auto-detect — engine binary OR running socket = enabled.
        USE_RUST_ENGINE=0 to explicitly disable.
        """
        env = os.environ.get("USE_RUST_ENGINE", "").lower()
        if env in ("0", "false", "no"):
            return False
        if env in ("1", "true", "yes"):
            return True
        # Auto-detect: check if socket exists (engine already running)
        if os.path.exists(DEFAULT_SOCKET_PATH):
            return True
        # Auto-detect: check if binary exists
        import pathlib
        for p in [
            pathlib.Path(__file__).parent.parent.parent / "pydaw_engine" / "target" / "release" / "pydaw_engine",
            pathlib.Path.home() / "pydaw_engine" / "target" / "release" / "pydaw_engine",
        ]:
            if p.exists():
                return True
        return False
