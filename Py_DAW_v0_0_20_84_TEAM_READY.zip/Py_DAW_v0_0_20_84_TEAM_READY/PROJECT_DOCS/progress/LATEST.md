v0.0.20.84

- Hilfe → Arbeitsmappe: Tab „Shortcuts & Befehle“ listet jetzt alle Tastenkombinationen (auto: QAction/QShortcut + kuratierte Editor-Shortcuts).
- QShortcut-Metadaten für Tab-Wechsel (Ctrl+Tab/Ctrl+Shift+Tab), Browser-Toggle (B) und Notation-Palette (Alt+…).
