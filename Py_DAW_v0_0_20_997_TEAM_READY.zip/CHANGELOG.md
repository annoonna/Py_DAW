# CHANGELOG — Py_DAW ChronoScaleStudio

## v0.0.20.997 — 🔧 Rust Build Fix + CLAP Auto-ID (2026-04-05)

### Rust Build Fix (E0616 — 2 Errors)
- `engine.rs` Zeile 399: `ao.shared` → `ao.shared()` (private field → public accessor)
- `engine.rs` Zeile 577: `audio_out.shared` → `audio_out.shared()` (dito)
- **Ergebnis:** `cargo build --release` sollte jetzt fehlerfrei kompilieren
- Binary erhält damit: `AudioStatus`, `AudioTestSine`, cpal Audio Auto-Start
- **Das war der Blocker für "kein Ton"** — ohne erfolgreichen Build lief die alte Binary ohne cpal

### CLAP Plugin-ID Auto-Detection
- `clap_host.py` `_ClapPlugin._load()`: Wenn `plugin_id` leer ist, wird die Factory gescannt
- Erste gefundene Plugin-ID wird automatisch verwendet
- Behebt: "CLAP asked for plugin_id '' and JuceCLAPWrapper ID is 'org.surge-synth-team.surge-xt'"
- Wirkt für ClapFx UND ClapInstrumentEngine (beide nutzen _ClapPlugin)

## v0.0.20.959 — 🦀 Rust Audio Output (2026-04-03)

### RA1: cpal Audio Engine
- `audio_output.rs` (310 LOC) — cpal Stream, Device Enumeration, Test-Sine
- `render.rs` (250 LOC) — RT-safe Audio Render Loop, Meter Events
- IPC: 5 Commands (AudioStart/Stop/TestSine/Enumerate/Status)
- IPC: 6 Events (AudioStarted/Stopped/Error/DeviceList/StatusReport)
- engine.rs: AudioOutput Feld + Command-Handler

### RA4: Python Integration
- RustEngineBridge: 5 Methoden, 5 Qt Signals, Event-Dispatch
- RustAudioTakeover: audio_start/audio_stop Integration
- Audio-Einstellungen: "🦀 Rust Audio Output" UI-Bereich
- Roadmap: 37/55 Items abgehakt (67%)

# CHANGELOG v0.0.20.949 — Video Collab Transfer Fix

## v0.0.20.948 — Video Editor Pro (2026-04-01)

### 🎬 VE8: Timecode Pro + Smart Context
- **Frame-genauer Timecode** im Header (HH:MM:SS:FF) mit professionellem SMPTE-Format
- **Drop-Frame / Non-Drop-Frame** Unterstützung (29.97/59.94 fps)
- **FPS-Selector** in Toolbar (23.976, 24, 25, 29.97, 30, 50, 59.94, 60)
- **Timecode-Offset pro Clip** für externe Kamera-Synchronisation
- **LTC (Linear Time Code) Sync** Framework über Audio-Spur (Stub)
- **Timecode-Eingabe** (T): Springe zu exaktem Timecode via Dialog
- **Smart Context Tool** (C): Automatischer Tool-Wechsel nach Klick-Position
  - Klick auf Clip-Rand → Trim
  - Klick auf Clip-Mitte → Move
  - Klick in Header → Playhead setzen
- Neues Modul: `pydaw/services/video_timecode.py`

### 📈 VE9: Automation Draw (Opacity-Kurven)
- **Per-Clip Automation** für Opacity, Speed und Volume
- **Breakpoint-System** mit Linear- und Bezier-Interpolation
- **Automation Draw Tool** (A): Punkte setzen, ziehen, löschen (Rechtsklick)
- **Preset-Kurven**: Fade In, Fade Out, S-Curve, Bell
- **Speed-Ramping**: Geschwindigkeitskurve mit Slow-Mo Presets
- **Lane-Selector** in Toolbar (Opacity/Speed/Volume)
- **Preset-Button** mit Dropdown-Menü
- Neues Modul: `pydaw/services/video_automation.py`

### ✨ VE10: Transition Engine
- **Crossfade / Dissolve** zwischen Video-Clips
- **Wipe-Übergänge**: Links, Rechts, Hoch, Runter, Diagonal
- **Slide / Push** Übergänge
- **Dip to Black / Dip to White**
- **Beat-synced** Transition-Dauer (in Beats)
- **Kontextmenü-Integration**: Rechtsklick → Übergänge
- **ffmpeg filter_complex** Export-Unterstützung
- **KI-Morph Transition** Stub für zukünftige AI-Zwischenbilder
- Neues Modul: `pydaw/services/video_transitions.py`

### 📊 Neue Dateien
- `pydaw/services/video_timecode.py` — Timecode Pro Utilities
- `pydaw/services/video_automation.py` — Automation Engine
- `pydaw/services/video_transitions.py` — Transition Engine

### 📊 Stats
- 430/430 Python-Dateien kompilieren
- 0 Fehler
- Keine bestehende Funktionalität verändert

### 🐛 Collab-Fix: Remote-Spuren jetzt hörbar
- **Root Cause**: Nach `track_add`/`device_sync` wurde das Instrument-Widget erstellt,
  aber die Engine lud weder Sample-State noch registrierte sich im SamplerRegistry
- **Fix**: `_force_instrument_widget_reload()` erzwingt nach jedem remote device_sync:
  1. `_restore_instrument_state()` → Sample-Dateien laden
  2. SamplerRegistry Registrierung prüfen/erzwingen
  3. Pull-Source (Audio-Ausgang) prüfen/erzwingen
- Betrifft: `_apply_remote_device_sync`, `track_add`, `_on_instrument_sample_ready`

### 🐛 Fix: Record-Button NameError
- `set_recording_visual()` hatte `self.record_clicked.emit(checked)` mit undefinierter
  Variable `checked` statt `active` — verursachte NameError bei Record-Toggle
- Fix: Doppeltes emit entfernt (emit gehört nur in `_on_rec_toggled_internal`)

# CHANGELOG v0.0.20.945 — 3 Critical Fixes (Record, JACK Fallback, Video Spam)

## v0.0.20.945 — Critical Fixes (2026-04-01)

### 🐛 Fix 1: Record-Button bleibt nicht mehr ROT

**Problem:** Record drücken → ROT. Nochmal drücken (oder Recording scheitert)
→ Button bleibt ROT. Weil `blockSignals(True)` das Style-Reset überspringt.

**Fix:** Neue Methode `set_recording_visual(False)` wird an allen 5 Stellen
aufgerufen wo `btn_rec.setChecked(False)` mit `blockSignals` verwendet wird.

### 🐛 Fix 2: Recording Fallback JACK → sounddevice

**Problem:** JACK Server nicht erreichbar → Recording scheitert in Endlosschleife
(12× im Log!). Jeder Versuch startet einen neuen JACK Server der sofort crasht:
`ALSA: Cannot open PCM device alsa_pcm for playback`


<!-- Ältere Einträge archiviert — siehe Git History -->

**Integration:**
- In `ServiceContainer` integriert
- Cleanup in `shutdown()` Methode
- Status-Signale an Project-Service

---

#### 2. FluidSynth MIDI-Synthesis

**Neue Datei**: `pydaw/services/fluidsynth_service.py`

**Funktionen:**
- SoundFont (SF2) Unterstützung
- Echtzeit-MIDI-Playback
- 16 MIDI-Kanäle
- Program Changes
- Audio-Routing zu JACK/PipeWire
- Reverb & Chorus Effekte
- Konfigurierbare Interpolation

**API:**
```python
fluidsynth = FluidSynthService()
fluidsynth.load_soundfont("FluidR3_GM.sf2")
fluidsynth.note_on(channel=0, pitch=60, velocity=100)
fluidsynth.note_off(channel=0, pitch=60)
```

**Features:**
- Thread-sichere Note-Handling
- Automatische Driver-Erkennung (JACK/PipeWire/ALSA)
- Master Gain Control
- All Notes Off (Panic-Button)

---

#### 3. Erweiterte Notation-Integration

**Neue Datei**: `pydaw/ui/notation_editor_full.py`

**Status**: Framework vorbereitet, vollständige Integration folgt

**Vorbereitet:**
- ChronoScaleStudio-Komponenten-Struktur
- Skalen-Datenbank (500+ Skalen) bereits integriert
- Score-View-Wrapper
- MIDI-Clip Synchronisation
- Service-Container-Anbindung

**Existierende Dateien:**
- `pydaw/notation/` - Vollständiges Notationssystem
- `pydaw/notation/scales/scales.json` - Skalen-Datenbank
- `pydaw/ui/notation_editor_lite.py` - Leichtgewichtiger Editor (bereits funktionsfähig)

---

### 🔄 Verbesserungen

#### ServiceContainer Erweiterungen

**Datei**: `pydaw/services/container.py`

**Änderungen:**
- Neue Services hinzugefügt:
  - `recording: RecordingService`
  - `fluidsynth: FluidSynthService`
- Erweiterte `create_default()` Methode:
  - Recording-Service-Initialisierung
  - FluidSynth-Service-Initialisierung
  - Status/Error-Signal-Routing
- Erweiterte `shutdown()` Methode:
  - Recording-Cleanup
  - FluidSynth-Cleanup
  - Geordnetes Herunterfahren aller Services

---

#### Logging & Diagnostik

**Verbessert:**
- Detailliertere Log-Meldungen in allen Services
- Exception-Tracking in Event-Loop
- Startup-Diagnostik erweitert
- Backend-Erkennung mit Logging

**Log-Ausgaben jetzt verfügbar für:**
- Recording-Backend-Auswahl
- FluidSynth-Initialisierung
- Service-Container-Startup
- Event-Loop-Exceptions

---

#### Fehlerbehandlung

**Überall verbessert:**
- Try-Catch Blöcke in allen Service-Methoden
- Keine unbehandelten Exceptions mehr
- Graceful Degradation (Features fallen auf Fallbacks zurück)
- Status-Messages statt Silent-Failures

---

### 📚 Dokumentation

#### Neue Dokumentation

**README.md** - Komplett überarbeitet:
- Übersichtliche Feature-Liste
- Quick-Start Guide
- Installation Instructions
- Troubleshooting

**docs/USER_GUIDE.md** - NEU:
- Vollständiges Benutzerhandbuch
- Installation Step-by-Step
- Alle Features erklärt
- Workflow-Tipps
- Ausführliche Fehlerbehebung
- Screenshots (folgen)

**CHANGELOG.md** (diese Datei) - NEU:
- Strukturierte Versions-Historie
- Detaillierte Änderungsliste
- Breaking Changes dokumentiert

---

### 🐛 Behobene Bugs

#### Kritisch

1. **SIGABRT-Crash** (Issue #1)
   - **Symptom**: Programm stürzt sporadisch ab mit "Unhandled Python exception"
   - **Root Cause**: Rekursive notify() Aufrufe
   - **Fix**: Event-Loop-Architektur neu implementiert
   - **Status**: ✅ Vollständig behoben

2. **Qt Event-Loop Deadlocks**
   - **Symptom**: UI friert ein
   - **Cause**: Blocking Calls in Event-Handler
   - **Fix**: Thread-Safe Event-Handling
   - **Status**: ✅ Behoben

#### Hoch

3. **Service-Initialisierung-Fehler**
   - **Symptom**: Services manchmal nicht verfügbar
   - **Fix**: Defensive Service-Creation mit Fallbacks
   - **Status**: ✅ Behoben

4. **Logging-Setup-Timing**
   - **Symptom**: Frühe Fehler nicht geloggt
   - **Fix**: Logging vor QApplication-Init
   - **Status**: ✅ Behoben

#### Mittel

5. **JACK-Auto-Restart-Loop**
   - **Symptom**: Endlos-Restarts bei JACK-Problemen
   - **Fix**: Umgebungsvariablen-Prüfung verbessert
   - **Status**: ✅ Behoben

---

### ⚠️ Breaking Changes

Keine Breaking Changes in dieser Version.

Alle Änderungen sind rückwärtskompatibel mit v0.0.19.3.6_fix10b.

---

### 🔮 Bekannte Einschränkungen

1. **Notation-Editor**: Vollständige ChronoScaleStudio-Integration noch nicht abgeschlossen
   - **Workaround**: Leichtgewichtiger Editor (`notation_editor_lite.py`) funktioniert
   - **Status**: Framework vorbereitet, Implementation folgt

2. **FluidSynth-Latenz**: Bei niedriger Buffer-Size können Artefakte auftreten
   - **Workaround**: Buffer-Size auf 512+ erhöhen
   - **Status**: Akzeptabel für die meisten Anwendungsfälle

3. **Recording-Monitor**: Kein visuelles Input-Metering während Recording
   - **Workaround**: System-Tools wie `pavucontrol` verwenden
   - **Status**: Feature-Request für nächste Version

---

### 📦 Abhängigkeiten

#### Neu hinzugefügt
- `pyfluidsynth` (optional) - FluidSynth-Unterstützung
- `numpy` - Audio-Verarbeitung für Recording
- `sounddevice` - Multi-Backend Audio I/O

#### Aktualisiert
Keine Änderungen an bestehenden Abhängigkeiten.

---

### 🔧 Entwickler-Hinweise

#### API-Änderungen

**ServiceContainer:**
```python
# Neu verfügbar:
services.recording.start_recording(path, sample_rate, channels)
services.recording.stop_recording() -> Path

services.fluidsynth.load_soundfont(sf2_path)
services.fluidsynth.note_on(channel, pitch, velocity)
services.fluidsynth.note_off(channel, pitch)
```

**Event-Handling:**
```python
# Alt (entfernt):
class SafeApplication(QApplication):
    def notify(self, receiver, event):
        ...

# Neu:
class SafeApplication(QApplication):
    def event(self, event):
        ...
```

---

### 📊 Performance

**Startup-Zeit:**
- Fix10b: ~3-5 Sekunden
- Fix11: ~2-3 Sekunden (verbessert durch optimierte Service-Init)

**Memory-Footprint:**
- Fix10b: ~80 MB base
- Fix11: ~85 MB base (+5 MB durch Recording/FluidSynth-Services)

**CPU-Usage:**
- Idle: <1%
- Playback: 5-15% (abhängig von Track-Anzahl)
- Recording: +2-5%
- FluidSynth: +5-10% (abhängig von Polyphonie)

---

## [0.0.19.3.6_fix10b] - 2026-01-23

### Änderungen
- Notation-Tab experimentell hinzugefügt
- Verschiedene Bug-Fixes
- Bekannter Issue: SIGABRT-Crash

---

## [0.0.19.3.6] - 2026-01-20

### Basis-Version
- Projekt-Management
- MIDI-Editor (Piano Roll)
- Basic Audio-Engine
- JACK/PipeWire-Unterstützung (experimentell)
- Mixer & Transport

---

## Versionsschema

Format: `MAJOR.MINOR.PATCH.BUILD_SUFFIX`

- **MAJOR**: Inkompatible API-Änderungen
- **MINOR**: Neue Features (rückwärtskompatibel)
- **PATCH**: Bug-Fixes
- **BUILD**: Iterations-Nummer
- **SUFFIX**: `_fix<n>` für Hotfixes

Beispiel: `0.0.19.3.6_fix11`
- Major: 0 (Pre-Release)
- Minor: 0 (Beta-Phase)
- Patch: 19 (Patch-Level)
- Build: 3.6 (Build-Iteration)
- Suffix: fix11 (11. Hotfix dieser Version)

---

## Geplante Features (Roadmap)

### v0.0.20 (nächste Version)
- [ ] Vollständige ChronoScaleStudio-Integration
- [ ] VST/LV2 Plugin-Support
- [ ] Automation-Kurven-Editor
- [ ] Erweiterte Mixer-Features (Send/Return)

### v0.1.0 (Milestone)
- [ ] Stable Release
- [ ] Performance-Optimierungen
- [ ] Video-Tutorials
- [ ] Windows/macOS-Support

### v1.0.0 (Production-Ready)
- [ ] Feature-Complete
- [ ] Comprehensive Testing
- [ ] Professional Documentation
- [ ] Community Support

---

**Vollständiges Changelog**: https://github.com/yourrepo/pydaw/compare/v0.0.19.3.6_fix10b...v0.0.19.3.6_fix11
## v0.0.19.7.50
- Phase 2 Audio-Clip-Editor: Non-destructive AudioEvents (Knife split + Eraser merge)
- Context-Menu: Split at Playhead (Transport-basiert)
- Model: Clip.audio_events + robustes Project.from_dict (unknown keys ignoriert)

## v0.0.19.7.51
- Phase 2.1 AudioEventEditor: selektierbare AudioEvents + Group-Move (Multi-Selection)
- Context-Menü: Consolidate + Quantize (Events) aktiv (ProjectService-Implementierung)
- Middle-Mouse-Pan im Audio-Editor

## v0.0.19.7.51
- AudioEventEditor: AudioEvents als selektierbare Blöcke (Selection + Group-Move)
- Multi-Selection: Drag bewegt alle selektierten Events gemeinsam (Shift = Snap aus)
- Context Menu: Quantize (Events) + Consolidate (contiguous + source-aligned)
- ProjectService: move_audio_events / quantize_audio_events / consolidate_audio_events

## v0.0.20.28
- Mixer: Auto-Wiring der HybridEngineBridge (Track-Fader/Pan/Mute/Solo wirken live während Playback/Loop; VU-Meter laufen).
- MainWindow: Übergibt HybridBridge explizit an MixerPanel (robuster Verdrahtungspfad).

- v0.0.20.251: Pro Drum LADSPA Slot-FX rebuild loop fixed (safe UI init blocker).

## v0.0.20.265
- Safe fix: PianoRoll local clip/playhead sync restored (`clip.id` lookup)
- Safe UI fix: Note Expression Lane/Zoom updates faster on target note changes
- Safe MIDI data fix: join/split preserve per-note expressions/micropitch metadata


## v0.0.20.353
- Arranger-TrackList zeigt beim lokalen Maus-Reorder jetzt eine sichtbare Drop-Markierung an der Einfügeposition.
- Die Markierung bleibt strikt auf das interne Reorder-MIME begrenzt; Cross-Project-Track-Drag bleibt unverändert.


## v0.0.20.354
- DevicePanel trennt jetzt sichtbarer zwischen aktiver Spur und Gruppen-Aktionen.
- Zusätzliche Scope-Hinweisbox erklärt klar: sichtbare Devices unten gehören nur zur aktiven Spur.
- Gruppenbuttons heißen jetzt NOTE→Gruppe / AUDIO→Gruppe; die Gruppenleiste stellt ausdrücklich klar, dass hier noch kein gemeinsamer Gruppenbus existiert.


## v0.0.20.355
- Browser/Add-Flow zeigt jetzt kleine Scope-Badges in Instruments / Effects / Favorites / Recents; normales Add bleibt sichtbar der aktiven Spur zugeordnet.
- Scope-Badges werden beim Spurwechsel aktualisiert.
- DistortionFxWidget schützt Automation-Callbacks jetzt defensiv gegen bereits gelöschte Qt-Slider/Spinboxen.

## v0.0.20.481
- SmartDrop nutzt jetzt zentrale Zielregeln für ArrangerCanvas + TrackList (`pydaw/ui/smartdrop_rules.py`).
- Instrument→Audio-Spur zeigt jetzt eine konkrete Morphing-Vorprüfung (Audio-/MIDI-Clip- und FX-Summary) statt nur eines pauschalen später-Hinweises.
- Geblockte SmartDrop-Versuche auf bewusst gesperrte Ziele melden jetzt aktiv den Sperrgrund über die Statusleiste.


## v0.0.20.495
- SmartDrop: Morphing-Guard koppelt das vorhandene Snapshot-Bundle jetzt an einen read-only Dry-Run-/Transaktions-Runner.
- Der Dry-Run liefert `runner_key`, Capture-/Restore-/Rollback-Sequenzen, `rehearsed_steps` und `phase_results`, bleibt aber bewusst preview-only.
- Der Guard-Dialog zeigt die neue Dry-Run-Ebene sichtbar an; die Apply-Readiness kennt jetzt zusaetzlich den vorbereiteten Transaktions-Runner.


## v0.0.20.498
- SmartDrop: Morphing-Guard koppelt Runtime-Stubs jetzt an konkrete read-only Zustandstraeger / State-Carrier.
- Der Dry-Run liefert zusaetzlich `state_carrier_calls` und `state_carrier_summary` und bleibt weiterhin komplett preview-only.
- Guard-Dialog zeigt die neue Carrier-Ebene sichtbar an; kein Commit, kein Routing-Umbau, keine Projektmutation.

## v0.0.20.503 — SmartDrop: Morphing-Guard Runtime-State-Registries (2026-03-16)

- Runtime-State-Stores wurden an konkrete read-only **Runtime-State-Registries / Handle-Speicher** gekoppelt.
- Der Dry-Run fuehrt jetzt `state_registry_calls` und `state_registry_summary` und dispatcht `capture_registry_preview()` / `restore_registry_preview()` / `rollback_registry_preview()` read-only.
- Der Guard-Dialog zeigt die neue Ebene **Runtime-State-Registries / Handle-Speicher** sowie die neuen Dry-Run-Registry-Infos sichtbar an.


## v0.0.20.646
- Projekt-Tab-Leiste zeigt jetzt ein eigenständiges Rust-Badge nahe Neues Projekt/Öffnen.
- Rust-Badge ist bewusst komplett vom Qt-Badge getrennt und etwas größer für bessere Erkennbarkeit.


## v0.0.20.828
- VST3-Instrumente (z. B. Surge XT / Nekobi) werden jetzt vor dem ersten Load gezielt auf den Qt-Main-Thread verschoben, damit pedalboard nicht in den "must be reloaded on the main thread"-Loop faellt.
- Worker-seitige Retry-Timer fuer diese VST3-Instrumente wurden entfernt; dadurch verschwinden die QBasicTimer-Warnungen und die endlosen Reload-Stuerme.
- Erfolgreich auf dem Main-Thread geladene VST3-Instrumente registrieren SamplerRegistry + Pull-Source sofort und triggern danach den benoetigten Stream-Update sauber.


## v0.0.20.833
- Externer Surge-XT-Editor: X11-Reparenting in den Py_DAW-Rahmen statt doppeltem Shell+Pedalboard-Fenster versucht; Shell wird beim OOP-Wid jetzt in den Vordergrund geholt.
- Surge-XT-Surrogate-Sync: VST3-State-Blob wird jetzt zuerst auf die laufende CLAP-Instanz angewendet; Parameter-Snapshot bleibt als Fallback/Feinsync aktiv.
- CLAP-Editor-Cleanup: zerstörte Widgets lösen `_close_editor()` jetzt defensiv aus, ohne RuntimeError-Stürme über gelöschte Qt-Objekte.


## v0.0.20.836
- Surge-XT-OOP-Shell schrumpft nicht mehr auf fruehe/fehlerhafte Mini-Geometrien; Groessenhints werden jetzt nur noch vergroessert und fuer den Surge-Surrogate konservativ bei mindestens 960x720 gehalten.
- Der externe X11-Window-Watcher wartet kurz auf eine stabilere/gegroesserte Zielgeometrie und waehlt das groesste gefundene Plugin-Fenster, statt den ersten Mini-Frame sofort zu uebernehmen.
- Duplicate Surrogate-State-Blobs werden nicht mehr erneut auf die laufende CLAP-Engine angewendet; das reduziert unnoetige State-Loads und senkt das Risiko fuer Instabilitaeten beim Preset-Klicken.
