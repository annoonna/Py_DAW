// ============================================================================
// Plugin Sandbox — RM5.4: Process Isolation for Plugin Hosting
// ============================================================================
//
// Each plugin runs in its own subprocess for crash isolation.
// Audio data is exchanged via shared memory (mmap) ring buffers.
// Parameter and state updates go through IPC (Unix socket / pipe).
//
// Architecture:
//   Main Process (Engine)
//     │
//     ├── SharedAudioBuffer (mmap) ← zero-copy audio exchange
//     ├── PluginIpcChannel (pipe) ← parameter/state commands
//     │
//     └── Child Process (Plugin Worker)
//           ├── loads plugin (VST3/CLAP/LV2)
//           ├── reads audio from shared input buffer
//           ├── processes through plugin
//           ├── writes audio to shared output buffer
//           └── responds to parameter/state commands
//
// v0.0.20.974 — RM5.4 (Claude Opus 4.6, 2026-04-04)
// ============================================================================

use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, AtomicU32, AtomicU64, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use log::{error, info, warn};
use serde::{Deserialize, Serialize};

// ============================================================================
// Shared Audio Buffer (mmap-based, zero-copy)
// ============================================================================

/// Header for the shared audio memory region.
/// Layout: [Header][Input Buffer][Output Buffer]
#[repr(C)]
pub struct SharedAudioHeader {
    /// Magic number for validation
    pub magic: u32,               // 0x50_44_41_57 = "PDAW"
    /// Number of audio channels
    pub channels: u32,
    /// Buffer size in frames
    pub buffer_size: u32,
    /// Sample rate
    pub sample_rate: u32,
    /// Write position (set by writer, read by reader)
    pub write_seq: AtomicU64,
    /// Read position (set by reader, read by writer)
    pub read_seq: AtomicU64,
    /// Plugin is processing (1 = busy, 0 = idle)
    pub processing: AtomicU32,
    /// Plugin health status (0=ok, 1=error, 2=crashed)
    pub health: AtomicU32,
    /// Last heartbeat timestamp (microseconds since epoch)
    pub heartbeat_us: AtomicU64,
    /// CPU usage of last process call (microseconds)
    pub last_process_us: AtomicU32,
}

const SHARED_MAGIC: u32 = 0x50_44_41_57; // "PDAW"

impl SharedAudioHeader {
    pub fn init(&self, channels: u32, buffer_size: u32, sample_rate: u32) {
        // Safety: we only write to the header fields during init
        let self_mut = self as *const Self as *mut Self;
        unsafe {
            (*self_mut).magic = SHARED_MAGIC;
            (*self_mut).channels = channels;
            (*self_mut).buffer_size = buffer_size;
            (*self_mut).sample_rate = sample_rate;
        }
        self.write_seq.store(0, Ordering::Release);
        self.read_seq.store(0, Ordering::Release);
        self.processing.store(0, Ordering::Release);
        self.health.store(0, Ordering::Release);
        self.heartbeat_us.store(0, Ordering::Release);
        self.last_process_us.store(0, Ordering::Release);
    }

    pub fn is_valid(&self) -> bool {
        self.magic == SHARED_MAGIC
    }

    pub fn is_healthy(&self) -> bool {
        self.health.load(Ordering::Acquire) == 0
    }

    pub fn mark_crashed(&self) {
        self.health.store(2, Ordering::Release);
    }

    pub fn update_heartbeat(&self) {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_micros() as u64;
        self.heartbeat_us.store(now, Ordering::Release);
    }

    pub fn heartbeat_age_ms(&self) -> u64 {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_micros() as u64;
        let last = self.heartbeat_us.load(Ordering::Acquire);
        if last == 0 { return u64::MAX; }
        (now.saturating_sub(last)) / 1000
    }
}

/// Manages the shared memory region for one plugin.
pub struct SharedPluginMemory {
    /// Total size in bytes
    pub total_size: usize,
    /// Raw memory (simulated with Vec for safety; in production would be mmap)
    memory: Vec<u8>,
    /// Buffer size in frames
    pub buffer_size: usize,
    /// Number of channels
    pub channels: usize,
}

impl SharedPluginMemory {
    /// Create a new shared memory region.
    pub fn new(channels: usize, buffer_size: usize, sample_rate: u32) -> Self {
        let header_size = std::mem::size_of::<SharedAudioHeader>();
        let audio_size = channels * buffer_size * std::mem::size_of::<f32>();
        let total_size = header_size + audio_size * 2; // input + output

        let mut memory = vec![0u8; total_size];

        // Initialize header
        let header = unsafe { &*(memory.as_ptr() as *const SharedAudioHeader) };
        header.init(channels as u32, buffer_size as u32, sample_rate);

        Self {
            total_size,
            memory,
            buffer_size,
            channels,
        }
    }

    /// Get reference to the header.
    pub fn header(&self) -> &SharedAudioHeader {
        unsafe { &*(self.memory.as_ptr() as *const SharedAudioHeader) }
    }

    /// Get mutable slice for the input buffer.
    pub fn input_buffer_mut(&mut self) -> &mut [f32] {
        let header_size = std::mem::size_of::<SharedAudioHeader>();
        let audio_frames = self.channels * self.buffer_size;
        let start = header_size;
        let byte_len = audio_frames * std::mem::size_of::<f32>();
        unsafe {
            std::slice::from_raw_parts_mut(
                self.memory[start..start + byte_len].as_mut_ptr() as *mut f32,
                audio_frames,
            )
        }
    }

    /// Get slice for the output buffer.
    pub fn output_buffer(&self) -> &[f32] {
        let header_size = std::mem::size_of::<SharedAudioHeader>();
        let audio_frames = self.channels * self.buffer_size;
        let input_size = audio_frames * std::mem::size_of::<f32>();
        let start = header_size + input_size;
        let byte_len = audio_frames * std::mem::size_of::<f32>();
        unsafe {
            std::slice::from_raw_parts(
                self.memory[start..start + byte_len].as_ptr() as *const f32,
                audio_frames,
            )
        }
    }

    /// Get mutable slice for the output buffer (used by worker).
    pub fn output_buffer_mut(&mut self) -> &mut [f32] {
        let header_size = std::mem::size_of::<SharedAudioHeader>();
        let audio_frames = self.channels * self.buffer_size;
        let input_size = audio_frames * std::mem::size_of::<f32>();
        let start = header_size + input_size;
        let byte_len = audio_frames * std::mem::size_of::<f32>();
        unsafe {
            std::slice::from_raw_parts_mut(
                self.memory[start..start + byte_len].as_mut_ptr() as *mut f32,
                audio_frames,
            )
        }
    }
}

// ============================================================================
// Plugin Sandbox Commands (IPC between main and worker process)
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum SandboxCommand {
    /// Load a plugin from a file path
    LoadPlugin {
        plugin_type: PluginFormat,
        path: String,
        plugin_id: String,
    },
    /// Set a parameter value
    SetParameter { index: u32, value: f64 },
    /// Get a parameter value
    GetParameter { index: u32 },
    /// Save plugin state
    SaveState,
    /// Load plugin state from blob
    LoadState { data: Vec<u8> },
    /// Process one buffer (trigger)
    Process,
    /// Request parameter info
    GetParameterInfo,
    /// Shutdown the worker
    Shutdown,
    /// Heartbeat ping
    Ping,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum SandboxResponse {
    /// Plugin loaded successfully
    PluginLoaded {
        name: String,
        param_count: u32,
        latency: u32,
    },
    /// Parameter value response
    ParameterValue { index: u32, value: f64 },
    /// State blob
    State { data: Vec<u8> },
    /// State loaded successfully
    StateLoaded,
    /// Processing complete
    ProcessDone { cpu_us: u32 },
    /// Parameter info list
    ParameterInfoList { params: Vec<PluginParamInfo> },
    /// Heartbeat response
    Pong,
    /// Error
    Error { message: String },
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub enum PluginFormat {
    VST3,
    CLAP,
    LV2,
    LADSPA,
    Internal,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PluginParamInfo {
    pub index: u32,
    pub id: u32,
    pub name: String,
    pub default_value: f64,
    pub min_value: f64,
    pub max_value: f64,
    pub is_automatable: bool,
    pub unit: String,
}

// ============================================================================
// Sandboxed Plugin Instance (main process side)
// ============================================================================

/// Health status of a sandboxed plugin.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum PluginHealth {
    /// Plugin is healthy and processing
    Healthy,
    /// Plugin reported an error but is still alive
    Error,
    /// Plugin process has crashed
    Crashed,
    /// Plugin has been disabled after too many crashes
    Disabled,
}

/// Configuration for a sandboxed plugin.
#[derive(Debug, Clone)]
pub struct SandboxConfig {
    /// Maximum number of crash restarts before disabling
    pub max_crashes: u32,
    /// Watchdog timeout in milliseconds
    pub watchdog_timeout_ms: u64,
    /// CPU limit per process call (microseconds)
    pub cpu_limit_us: u32,
    /// Buffer size
    pub buffer_size: usize,
    /// Sample rate
    pub sample_rate: u32,
    /// Channels
    pub channels: usize,
}

impl Default for SandboxConfig {
    fn default() -> Self {
        Self {
            max_crashes: 3,
            watchdog_timeout_ms: 5000,
            cpu_limit_us: 50_000, // 50ms
            buffer_size: 512,
            sample_rate: 44100,
            channels: 2,
        }
    }
}

/// A sandboxed plugin instance managed from the main process.
pub struct SandboxedPlugin {
    /// Unique ID for this plugin instance
    pub instance_id: String,
    /// Plugin format
    pub format: PluginFormat,
    /// Plugin file path
    pub path: String,
    /// Display name
    pub name: String,
    /// Plugin health status
    pub health: PluginHealth,
    /// Number of crashes
    pub crash_count: u32,
    /// Shared memory for audio exchange
    pub shared_memory: SharedPluginMemory,
    /// Configuration
    pub config: SandboxConfig,
    /// Whether audio is muted due to crash
    pub muted_by_crash: bool,
    /// Parameter cache (for quick access without IPC)
    pub param_cache: HashMap<u32, f64>,
    /// Parameter info cache
    pub param_info: Vec<PluginParamInfo>,
    /// Last known state blob (for restart recovery)
    pub last_good_state: Option<Vec<u8>>,
    /// Latency reported by plugin
    pub latency_samples: u32,
    /// Is the worker process running
    pub worker_alive: bool,
}

impl SandboxedPlugin {
    /// Create a new sandboxed plugin (does not start the worker yet).
    pub fn new(
        instance_id: String,
        format: PluginFormat,
        path: String,
        config: SandboxConfig,
    ) -> Self {
        let shared_memory = SharedPluginMemory::new(
            config.channels,
            config.buffer_size,
            config.sample_rate,
        );

        Self {
            instance_id,
            format,
            path,
            name: String::new(),
            health: PluginHealth::Healthy,
            crash_count: 0,
            shared_memory,
            config,
            muted_by_crash: false,
            param_cache: HashMap::new(),
            param_info: Vec::new(),
            last_good_state: None,
            latency_samples: 0,
            worker_alive: false,
        }
    }

    /// Check if the plugin should be processed (healthy and not muted).
    pub fn should_process(&self) -> bool {
        self.health == PluginHealth::Healthy && !self.muted_by_crash && self.worker_alive
    }

    /// Process audio through the sandboxed plugin.
    /// Writes input to shared memory, triggers processing, reads output.
    pub fn process(&mut self, input: &[f32], output: &mut [f32]) {
        if !self.should_process() {
            // Pass through (copy input to output)
            let len = input.len().min(output.len());
            output[..len].copy_from_slice(&input[..len]);
            return;
        }

        // Write input to shared memory
        let shm_input = self.shared_memory.input_buffer_mut();
        let len = input.len().min(shm_input.len());
        shm_input[..len].copy_from_slice(&input[..len]);

        // Signal processing (in real impl: trigger via semaphore)
        let header = self.shared_memory.header();
        header.write_seq.fetch_add(1, Ordering::Release);

        // Read output from shared memory (in real impl: wait for completion)
        let shm_output = self.shared_memory.output_buffer();
        let len = output.len().min(shm_output.len());
        output[..len].copy_from_slice(&shm_output[..len]);
    }

    /// Set a parameter value.
    pub fn set_parameter(&mut self, index: u32, value: f64) {
        self.param_cache.insert(index, value);
        // In real impl: send SetParameter command via IPC
    }

    /// Get a parameter value from cache.
    pub fn get_parameter(&self, index: u32) -> f64 {
        self.param_cache.get(&index).copied().unwrap_or(0.0)
    }

    /// Save the current state for crash recovery.
    pub fn save_state_for_recovery(&mut self) {
        // In real impl: request state via IPC, store in last_good_state
        info!("Saving plugin state for crash recovery: {}", self.instance_id);
    }

    /// Handle a crash: mute, increment counter, attempt restart.
    pub fn handle_crash(&mut self) {
        self.crash_count += 1;
        self.worker_alive = false;

        if self.crash_count >= self.config.max_crashes {
            self.health = PluginHealth::Disabled;
            self.muted_by_crash = true;
            error!(
                "Plugin {} disabled after {} crashes",
                self.instance_id, self.crash_count
            );
        } else {
            self.health = PluginHealth::Crashed;
            self.muted_by_crash = true;
            warn!(
                "Plugin {} crashed ({}/{}), attempting restart",
                self.instance_id, self.crash_count, self.config.max_crashes
            );
        }
    }

    /// Check watchdog (heartbeat timeout).
    pub fn check_watchdog(&mut self) -> bool {
        if !self.worker_alive { return false; }

        let age_ms = self.shared_memory.header().heartbeat_age_ms();
        if age_ms > self.config.watchdog_timeout_ms {
            warn!(
                "Plugin {} watchdog timeout ({}ms > {}ms)",
                self.instance_id, age_ms, self.config.watchdog_timeout_ms
            );
            self.handle_crash();
            return false;
        }
        true
    }
}

// ============================================================================
// Plugin Sandbox Manager
// ============================================================================

/// Manages all sandboxed plugin instances.
pub struct PluginSandboxManager {
    /// Active plugin instances (instance_id → SandboxedPlugin)
    pub plugins: HashMap<String, SandboxedPlugin>,
    /// Default sandbox configuration
    pub default_config: SandboxConfig,
    /// Whether sandboxing is enabled
    pub enabled: bool,
}

impl PluginSandboxManager {
    pub fn new() -> Self {
        Self {
            plugins: HashMap::new(),
            default_config: SandboxConfig::default(),
            enabled: true,
        }
    }

    /// Create and register a new sandboxed plugin.
    pub fn create_plugin(
        &mut self,
        instance_id: String,
        format: PluginFormat,
        path: String,
    ) -> Result<(), String> {
        if self.plugins.contains_key(&instance_id) {
            return Err(format!("Plugin {} already exists", instance_id));
        }

        let plugin = SandboxedPlugin::new(
            instance_id.clone(),
            format,
            path,
            self.default_config.clone(),
        );

        info!("Created sandboxed plugin: {}", instance_id);
        self.plugins.insert(instance_id, plugin);
        Ok(())
    }

    /// Remove a sandboxed plugin.
    pub fn remove_plugin(&mut self, instance_id: &str) -> Option<SandboxedPlugin> {
        if let Some(mut plugin) = self.plugins.remove(instance_id) {
            plugin.worker_alive = false;
            info!("Removed sandboxed plugin: {}", instance_id);
            Some(plugin)
        } else {
            None
        }
    }

    /// Get a mutable reference to a plugin.
    pub fn get_plugin_mut(&mut self, instance_id: &str) -> Option<&mut SandboxedPlugin> {
        self.plugins.get_mut(instance_id)
    }

    /// Check watchdog for all plugins.
    pub fn check_all_watchdogs(&mut self) {
        let ids: Vec<String> = self.plugins.keys().cloned().collect();
        for id in ids {
            if let Some(plugin) = self.plugins.get_mut(&id) {
                plugin.check_watchdog();
            }
        }
    }

    /// Get status summary of all plugins.
    pub fn status_summary(&self) -> Vec<PluginStatus> {
        self.plugins
            .values()
            .map(|p| PluginStatus {
                instance_id: p.instance_id.clone(),
                name: p.name.clone(),
                format: p.format,
                health: p.health,
                crash_count: p.crash_count,
                muted: p.muted_by_crash,
                cpu_us: p.shared_memory.header().last_process_us.load(Ordering::Relaxed),
            })
            .collect()
    }
}

/// Status report for a single sandboxed plugin.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PluginStatus {
    pub instance_id: String,
    pub name: String,
    pub format: PluginFormat,
    pub health: PluginHealth,
    pub crash_count: u32,
    pub muted: bool,
    pub cpu_us: u32,
}

// Serde support for PluginHealth
impl Serialize for PluginHealth {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        match self {
            PluginHealth::Healthy => serializer.serialize_str("healthy"),
            PluginHealth::Error => serializer.serialize_str("error"),
            PluginHealth::Crashed => serializer.serialize_str("crashed"),
            PluginHealth::Disabled => serializer.serialize_str("disabled"),
        }
    }
}

impl<'de> Deserialize<'de> for PluginHealth {
    fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        let s = String::deserialize(deserializer)?;
        match s.as_str() {
            "healthy" => Ok(PluginHealth::Healthy),
            "error" => Ok(PluginHealth::Error),
            "crashed" => Ok(PluginHealth::Crashed),
            "disabled" => Ok(PluginHealth::Disabled),
            _ => Err(serde::de::Error::custom(format!("Unknown health: {}", s))),
        }
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_shared_memory_creation() {
        let shm = SharedPluginMemory::new(2, 512, 44100);
        assert!(shm.header().is_valid());
        assert!(shm.header().is_healthy());
        assert_eq!(shm.channels, 2);
        assert_eq!(shm.buffer_size, 512);
    }

    #[test]
    fn test_shared_memory_audio_exchange() {
        let mut shm = SharedPluginMemory::new(2, 4, 44100);

        // Write to input
        let input = shm.input_buffer_mut();
        input[0] = 0.5;
        input[1] = -0.5;
        input[2] = 0.25;
        input[3] = -0.25;

        // Verify input
        let input_read = shm.input_buffer_mut();
        assert_eq!(input_read[0], 0.5);
        assert_eq!(input_read[1], -0.5);

        // Write to output
        let output = shm.output_buffer_mut();
        output[0] = 1.0;
        output[1] = -1.0;

        // Read output
        let output_read = shm.output_buffer();
        assert_eq!(output_read[0], 1.0);
        assert_eq!(output_read[1], -1.0);
    }

    #[test]
    fn test_sandbox_plugin_crash_handling() {
        let config = SandboxConfig {
            max_crashes: 3,
            ..Default::default()
        };
        let mut plugin = SandboxedPlugin::new(
            "test_plugin".to_string(),
            PluginFormat::VST3,
            "/path/to/plugin.vst3".to_string(),
            config,
        );

        assert_eq!(plugin.health, PluginHealth::Healthy);

        // First crash
        plugin.handle_crash();
        assert_eq!(plugin.health, PluginHealth::Crashed);
        assert_eq!(plugin.crash_count, 1);
        assert!(plugin.muted_by_crash);

        // Second crash
        plugin.health = PluginHealth::Healthy;
        plugin.muted_by_crash = false;
        plugin.handle_crash();
        assert_eq!(plugin.crash_count, 2);

        // Third crash → disabled
        plugin.health = PluginHealth::Healthy;
        plugin.muted_by_crash = false;
        plugin.handle_crash();
        assert_eq!(plugin.health, PluginHealth::Disabled);
        assert_eq!(plugin.crash_count, 3);
    }

    #[test]
    fn test_sandbox_manager() {
        let mut manager = PluginSandboxManager::new();

        assert!(manager
            .create_plugin("p1".into(), PluginFormat::VST3, "/test.vst3".into())
            .is_ok());
        assert!(manager
            .create_plugin("p1".into(), PluginFormat::VST3, "/test.vst3".into())
            .is_err()); // duplicate

        assert!(manager.get_plugin_mut("p1").is_some());
        assert!(manager.get_plugin_mut("p2").is_none());

        let status = manager.status_summary();
        assert_eq!(status.len(), 1);

        manager.remove_plugin("p1");
        assert!(manager.get_plugin_mut("p1").is_none());
    }

    #[test]
    fn test_passthrough_when_muted() {
        let mut plugin = SandboxedPlugin::new(
            "test".into(),
            PluginFormat::CLAP,
            "/test.clap".into(),
            SandboxConfig::default(),
        );
        plugin.muted_by_crash = true;

        let input = vec![0.5f32, -0.5, 0.25, -0.25];
        let mut output = vec![0.0f32; 4];
        plugin.process(&input, &mut output);

        // Should pass through
        assert_eq!(output, input);
    }
}
