// ============================================================================
// File I/O — v0.0.20.973 (RM8)
// ============================================================================
//
// Audio file reading, project file management, media consolidation.
// ============================================================================

use log::{info, warn, error};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

// ============================================================================
// RM8.1: Audio File Reading
// ============================================================================

/// Audio file metadata
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AudioFileInfo {
    pub path: String,
    pub format: String,       // "wav", "flac", "mp3", "ogg", "aiff"
    pub sample_rate: u32,
    pub channels: u16,
    pub bit_depth: u16,
    pub num_samples: u64,     // per channel
    pub duration_secs: f64,
    pub file_size_bytes: u64,
}

/// Read audio file info without loading samples
pub fn probe_audio_file(path: &Path) -> Result<AudioFileInfo, String> {
    let ext = path.extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_lowercase();

    match ext.as_str() {
        "wav" | "wave" => probe_wav(path),
        "flac" => probe_flac(path),
        _ => Err(format!("Unsupported audio format: .{}", ext)),
    }
}

fn probe_wav(path: &Path) -> Result<AudioFileInfo, String> {
    let reader = hound::WavReader::open(path)
        .map_err(|e| format!("Cannot open WAV: {}", e))?;
    let spec = reader.spec();
    let num_samples = reader.len() as u64 / spec.channels as u64;
    let duration = num_samples as f64 / spec.sample_rate as f64;
    let file_size = std::fs::metadata(path).map(|m| m.len()).unwrap_or(0);

    Ok(AudioFileInfo {
        path: path.to_string_lossy().into(),
        format: "wav".into(),
        sample_rate: spec.sample_rate,
        channels: spec.channels,
        bit_depth: spec.bits_per_sample,
        num_samples,
        duration_secs: duration,
        file_size_bytes: file_size,
    })
}

fn probe_flac(path: &Path) -> Result<AudioFileInfo, String> {
    let reader = claxon::FlacReader::open(path)
        .map_err(|e| format!("Cannot open FLAC: {}", e))?;
    let info = reader.streaminfo();
    let num_samples = info.samples.unwrap_or(0);
    let duration = if info.sample_rate > 0 { num_samples as f64 / info.sample_rate as f64 } else { 0.0 };
    let file_size = std::fs::metadata(path).map(|m| m.len()).unwrap_or(0);

    Ok(AudioFileInfo {
        path: path.to_string_lossy().into(),
        format: "flac".into(),
        sample_rate: info.sample_rate,
        channels: info.channels as u16,
        bit_depth: info.bits_per_sample as u16,
        num_samples,
        duration_secs: duration,
        file_size_bytes: file_size,
    })
}

/// Read WAV file samples as f32 interleaved
pub fn read_wav_f32(path: &Path) -> Result<(Vec<f32>, u32, u16), String> {
    let mut reader = hound::WavReader::open(path)
        .map_err(|e| format!("Cannot open WAV: {}", e))?;
    let spec = reader.spec();

    let samples: Vec<f32> = match (spec.sample_format, spec.bits_per_sample) {
        (hound::SampleFormat::Float, _) => {
            reader.samples::<f32>()
                .filter_map(|s| s.ok())
                .collect()
        }
        (hound::SampleFormat::Int, 16) => {
            reader.samples::<i16>()
                .filter_map(|s| s.ok())
                .map(|s| s as f32 / 32768.0)
                .collect()
        }
        (hound::SampleFormat::Int, 24) => {
            reader.samples::<i32>()
                .filter_map(|s| s.ok())
                .map(|s| s as f32 / 8388608.0)
                .collect()
        }
        (hound::SampleFormat::Int, 32) => {
            reader.samples::<i32>()
                .filter_map(|s| s.ok())
                .map(|s| s as f32 / 2147483648.0)
                .collect()
        }
        _ => return Err(format!("Unsupported WAV format: {:?} {}bit", spec.sample_format, spec.bits_per_sample)),
    };

    Ok((samples, spec.sample_rate, spec.channels))
}

/// Read FLAC file samples as f32 interleaved
pub fn read_flac_f32(path: &Path) -> Result<(Vec<f32>, u32, u16), String> {
    let mut reader = claxon::FlacReader::open(path)
        .map_err(|e| format!("Cannot open FLAC: {}", e))?;
    let info = reader.streaminfo();
    let sr = info.sample_rate;
    let ch = info.channels as u16;
    let bps = info.bits_per_sample;
    let scale = 1.0 / (1u64 << (bps - 1)) as f32;

    let mut samples = Vec::new();
    let mut frame_reader = reader.blocks();
    let mut block_buf = Vec::new();

    loop {
        match frame_reader.read_next_or_eof(block_buf) {
            Ok(Some(block)) => {
                let frames = block.len();
                for frame in 0..frames {
                    for channel in 0..ch as u32 {
                        let sample = block.sample(channel, frame);
                        samples.push(sample as f32 * scale);
                    }
                }
                block_buf = block.into_buffer();
            }
            Ok(None) => break,
            Err(e) => return Err(format!("FLAC read error: {}", e)),
        }
    }

    Ok((samples, sr, ch))
}

// ============================================================================
// RM8.3: Project File Management
// ============================================================================

/// Consolidate all media files into the project directory
pub fn consolidate_media(
    project_dir: &Path,
    file_paths: &[String],
) -> Result<Vec<(String, String)>, String> {
    let media_dir = project_dir.join("media");
    std::fs::create_dir_all(&media_dir)
        .map_err(|e| format!("Cannot create media dir: {}", e))?;

    let mut mapping = Vec::new(); // (old_path, new_path)

    for original in file_paths {
        let src = Path::new(original);
        if !src.exists() {
            warn!("Media file not found, skipping: {}", original);
            continue;
        }

        let filename = src.file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("unknown");

        let mut dest = media_dir.join(filename);

        // Handle name collisions
        if dest.exists() && dest != src {
            let stem = src.file_stem().and_then(|s| s.to_str()).unwrap_or("file");
            let ext = src.extension().and_then(|e| e.to_str()).unwrap_or("");
            let hash = simple_hash(original);
            dest = media_dir.join(format!("{}_{}.{}", stem, &hash[..6], ext));
        }

        if dest != src {
            std::fs::copy(src, &dest)
                .map_err(|e| format!("Cannot copy {}: {}", original, e))?;
            info!("Consolidated: {} → {:?}", original, dest);
        }

        mapping.push((original.clone(), dest.to_string_lossy().into()));
    }

    info!("Media consolidated: {} files", mapping.len());
    Ok(mapping)
}

/// Create a backup/archive of the project directory
pub fn create_project_archive(
    project_dir: &Path,
    output_path: &Path,
) -> Result<u64, String> {
    use std::io::Write;

    let file = std::fs::File::create(output_path)
        .map_err(|e| format!("Cannot create archive: {}", e))?;
    let mut zip = zip_writer::ZipWriter::new(file);

    let mut total_size: u64 = 0;
    let base = project_dir;

    fn walk_dir(dir: &Path, base: &Path, zip: &mut zip_writer::ZipWriter<std::fs::File>, total: &mut u64)
        -> Result<(), String>
    {
        let entries = std::fs::read_dir(dir)
            .map_err(|e| format!("Cannot read dir {:?}: {}", dir, e))?;
        for entry in entries {
            let entry = entry.map_err(|e| format!("Dir entry error: {}", e))?;
            let path = entry.path();
            let relative = path.strip_prefix(base)
                .map_err(|e| format!("Strip prefix error: {}", e))?;

            if path.is_dir() {
                // Skip hidden dirs and __pycache__
                let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("");
                if name.starts_with('.') || name == "__pycache__" || name == "target" {
                    continue;
                }
                walk_dir(&path, base, zip, total)?;
            } else {
                let data = std::fs::read(&path)
                    .map_err(|e| format!("Cannot read {:?}: {}", path, e))?;
                *total += data.len() as u64;
                let name = relative.to_string_lossy();
                zip.add_entry(&name, &data);
            }
        }
        Ok(())
    }

    walk_dir(project_dir, base, &mut zip, &mut total_size)
        .map_err(|e| format!("Archive walk error: {}", e))?;

    zip.finish().map_err(|e| format!("ZIP finalize error: {}", e))?;

    info!("Project archive created: {:?} ({} bytes)", output_path, total_size);
    Ok(total_size)
}

/// Simple hash for deduplication
fn simple_hash(s: &str) -> String {
    let mut hash: u64 = 5381;
    for b in s.bytes() {
        hash = hash.wrapping_mul(33).wrapping_add(b as u64);
    }
    format!("{:016x}", hash)
}

// ============================================================================
// Minimal ZIP writer (no external crate dependency)
// ============================================================================
mod zip_writer {
    use std::io::{Write, Result};

    pub struct ZipWriter<W: Write> {
        writer: W,
        entries: Vec<(String, u32, u32, u32)>, // name, offset, compressed_size, crc32
        offset: u32,
    }

    impl<W: Write> ZipWriter<W> {
        pub fn new(writer: W) -> Self {
            Self { writer, entries: Vec::new(), offset: 0 }
        }

        pub fn add_entry(&mut self, name: &str, data: &[u8]) {
            let crc = crc32(data);
            let header_offset = self.offset;

            // Local file header
            let name_bytes = name.as_bytes();
            let header = local_file_header(name_bytes, data.len() as u32, crc);
            let _ = self.writer.write_all(&header);
            let _ = self.writer.write_all(name_bytes);
            let _ = self.writer.write_all(data);

            self.offset += header.len() as u32 + name_bytes.len() as u32 + data.len() as u32;
            self.entries.push((name.to_string(), header_offset, data.len() as u32, crc));
        }

        pub fn finish(mut self) -> Result<()> {
            let cd_offset = self.offset;
            let mut cd_size = 0u32;

            for (name, offset, size, crc) in &self.entries {
                let name_bytes = name.as_bytes();
                let cd = central_dir_entry(name_bytes, *size, *crc, *offset);
                self.writer.write_all(&cd)?;
                self.writer.write_all(name_bytes)?;
                cd_size += cd.len() as u32 + name_bytes.len() as u32;
            }

            // End of central directory
            let eocd = end_of_central_dir(self.entries.len() as u16, cd_size, cd_offset);
            self.writer.write_all(&eocd)?;
            self.writer.flush()
        }
    }

    fn local_file_header(name: &[u8], size: u32, crc: u32) -> Vec<u8> {
        let mut h = Vec::with_capacity(30);
        h.extend_from_slice(&[0x50, 0x4b, 0x03, 0x04]); // signature
        h.extend_from_slice(&20u16.to_le_bytes()); // version needed
        h.extend_from_slice(&0u16.to_le_bytes()); // flags
        h.extend_from_slice(&0u16.to_le_bytes()); // compression (stored)
        h.extend_from_slice(&0u16.to_le_bytes()); // mod time
        h.extend_from_slice(&0u16.to_le_bytes()); // mod date
        h.extend_from_slice(&crc.to_le_bytes());
        h.extend_from_slice(&size.to_le_bytes()); // compressed
        h.extend_from_slice(&size.to_le_bytes()); // uncompressed
        h.extend_from_slice(&(name.len() as u16).to_le_bytes());
        h.extend_from_slice(&0u16.to_le_bytes()); // extra field len
        h
    }

    fn central_dir_entry(name: &[u8], size: u32, crc: u32, offset: u32) -> Vec<u8> {
        let mut h = Vec::with_capacity(46);
        h.extend_from_slice(&[0x50, 0x4b, 0x01, 0x02]); // signature
        h.extend_from_slice(&20u16.to_le_bytes()); // version made by
        h.extend_from_slice(&20u16.to_le_bytes()); // version needed
        h.extend_from_slice(&0u16.to_le_bytes()); // flags
        h.extend_from_slice(&0u16.to_le_bytes()); // compression
        h.extend_from_slice(&0u16.to_le_bytes()); // mod time
        h.extend_from_slice(&0u16.to_le_bytes()); // mod date
        h.extend_from_slice(&crc.to_le_bytes());
        h.extend_from_slice(&size.to_le_bytes());
        h.extend_from_slice(&size.to_le_bytes());
        h.extend_from_slice(&(name.len() as u16).to_le_bytes());
        h.extend_from_slice(&0u16.to_le_bytes()); // extra
        h.extend_from_slice(&0u16.to_le_bytes()); // comment
        h.extend_from_slice(&0u16.to_le_bytes()); // disk start
        h.extend_from_slice(&0u16.to_le_bytes()); // internal attribs
        h.extend_from_slice(&0u32.to_le_bytes()); // external attribs
        h.extend_from_slice(&offset.to_le_bytes());
        h
    }

    fn end_of_central_dir(entries: u16, cd_size: u32, cd_offset: u32) -> Vec<u8> {
        let mut h = Vec::with_capacity(22);
        h.extend_from_slice(&[0x50, 0x4b, 0x05, 0x06]);
        h.extend_from_slice(&0u16.to_le_bytes()); // disk number
        h.extend_from_slice(&0u16.to_le_bytes()); // cd disk
        h.extend_from_slice(&entries.to_le_bytes());
        h.extend_from_slice(&entries.to_le_bytes());
        h.extend_from_slice(&cd_size.to_le_bytes());
        h.extend_from_slice(&cd_offset.to_le_bytes());
        h.extend_from_slice(&0u16.to_le_bytes()); // comment len
        h
    }

    fn crc32(data: &[u8]) -> u32 {
        let mut crc: u32 = 0xFFFFFFFF;
        for &byte in data {
            crc ^= byte as u32;
            for _ in 0..8 {
                crc = if crc & 1 == 1 { (crc >> 1) ^ 0xEDB88320 } else { crc >> 1 };
            }
        }
        !crc
    }
}
