// ============================================================================
// IPC Extended — RM10: IPC Vervollständigung
// ============================================================================
//
// Extends the IPC protocol with:
//   - Batch commands (multiple commands in one frame)
//   - Streaming events (meter, waveform, video frames)
//   - Binary data transfer (audio/video buffers via shared memory)
//   - Command acknowledgment (request-response pattern)
//   - Python bridge update helpers
//   - Error handling (Rust errors → structured error events)
//   - Hot-reload support (engine restart without DAW restart)
//
// v0.0.20.976 — RM10 (Claude Opus 4.6, 2026-04-04)
// ============================================================================

use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use log::{debug, error, info, warn};
use serde::{Deserialize, Serialize};

// ============================================================================
// RM10.1: Batch Commands
// ============================================================================

/// A batch of commands to be processed atomically in one audio frame.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatchCommand {
    /// Unique batch ID for acknowledgment
    pub batch_id: u64,
    /// Commands in this batch
    pub commands: Vec<BatchEntry>,
    /// Whether to acknowledge on completion
    pub require_ack: bool,
    /// Priority (0 = normal, 1 = high, 2 = realtime)
    pub priority: u8,
}

/// A single command within a batch.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatchEntry {
    /// Sequence number within the batch
    pub seq: u32,
    /// Command type name (matches ipc::Command variants)
    pub command_type: String,
    /// Command payload as JSON
    pub payload: String,
}

impl BatchCommand {
    pub fn new(batch_id: u64) -> Self {
        Self {
            batch_id,
            commands: Vec::new(),
            require_ack: true,
            priority: 0,
        }
    }

    /// Add a command to the batch.
    pub fn add(&mut self, command_type: &str, payload: &str) {
        let seq = self.commands.len() as u32;
        self.commands.push(BatchEntry {
            seq,
            command_type: command_type.to_string(),
            payload: payload.to_string(),
        });
    }

    /// Number of commands in this batch.
    pub fn len(&self) -> usize {
        self.commands.len()
    }

    pub fn is_empty(&self) -> bool {
        self.commands.is_empty()
    }
}

/// Batch command acknowledgment.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatchAck {
    pub batch_id: u64,
    pub total_commands: u32,
    pub successful: u32,
    pub failed: u32,
    pub errors: Vec<BatchError>,
    pub elapsed_us: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatchError {
    pub seq: u32,
    pub command_type: String,
    pub error_message: String,
}

// ============================================================================
// RM10.1: Streaming Events
// ============================================================================

/// Event stream types for real-time data.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum StreamType {
    /// Peak/RMS meters per track (30Hz)
    Meters,
    /// Playhead position (30Hz)
    Playhead,
    /// Waveform data for display (on demand)
    Waveform,
    /// Spectrum analyzer data (30Hz)
    Spectrum,
    /// Video frame for preview (frame rate)
    VideoFrame,
    /// MIDI activity indicator
    MidiActivity,
    /// CPU/DSP load
    Performance,
}

/// A streaming event subscription.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StreamSubscription {
    /// Stream type
    pub stream_type: StreamType,
    /// Update rate in Hz (0 = on-demand only)
    pub update_rate_hz: u32,
    /// Whether this subscription is active
    pub active: bool,
    /// Filter (e.g., specific track IDs for meter stream)
    pub filter: Option<String>,
}

/// Manager for event stream subscriptions.
pub struct StreamManager {
    /// Active subscriptions
    pub subscriptions: HashMap<StreamType, StreamSubscription>,
    /// Frame counter for rate limiting
    frame_counters: HashMap<StreamType, u32>,
    /// Audio frames per update for each stream type
    frames_per_update: HashMap<StreamType, u32>,
    /// Sample rate (for calculating frame intervals)
    sample_rate: u32,
    /// Buffer size
    buffer_size: u32,
}

impl StreamManager {
    pub fn new(sample_rate: u32, buffer_size: u32) -> Self {
        Self {
            subscriptions: HashMap::new(),
            frame_counters: HashMap::new(),
            frames_per_update: HashMap::new(),
            sample_rate,
            buffer_size,
        }
    }

    /// Subscribe to a stream type.
    pub fn subscribe(&mut self, sub: StreamSubscription) {
        let frames = if sub.update_rate_hz > 0 && self.buffer_size > 0 {
            (self.sample_rate / (sub.update_rate_hz * self.buffer_size)).max(1)
        } else {
            u32::MAX // on-demand only
        };

        self.frames_per_update.insert(sub.stream_type, frames);
        self.frame_counters.insert(sub.stream_type, 0);
        self.subscriptions.insert(sub.stream_type, sub);
    }

    /// Unsubscribe from a stream type.
    pub fn unsubscribe(&mut self, stream_type: StreamType) {
        self.subscriptions.remove(&stream_type);
        self.frame_counters.remove(&stream_type);
        self.frames_per_update.remove(&stream_type);
    }

    /// Check if a stream should emit this frame (rate limiting).
    pub fn should_emit(&mut self, stream_type: StreamType) -> bool {
        let sub = match self.subscriptions.get(&stream_type) {
            Some(s) if s.active => s,
            _ => return false,
        };

        let counter = self.frame_counters.entry(stream_type).or_insert(0);
        let interval = self.frames_per_update.get(&stream_type).copied().unwrap_or(u32::MAX);

        *counter += 1;
        if *counter >= interval {
            *counter = 0;
            true
        } else {
            false
        }
    }

    /// Get all active stream types.
    pub fn active_streams(&self) -> Vec<StreamType> {
        self.subscriptions
            .iter()
            .filter(|(_, s)| s.active)
            .map(|(t, _)| *t)
            .collect()
    }
}

// ============================================================================
// RM10.1: Binary Data Transfer
// ============================================================================

/// Shared memory region for binary data exchange.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SharedMemoryRegion {
    /// Region name (unique identifier)
    pub name: String,
    /// Size in bytes
    pub size: usize,
    /// Content type
    pub content_type: SharedMemoryType,
    /// Whether the region is locked (being written to)
    pub locked: bool,
    /// Sequence number (incremented on each write)
    pub write_seq: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum SharedMemoryType {
    /// Audio buffer (f32 interleaved)
    AudioBuffer,
    /// Video frame (RGBA)
    VideoFrame,
    /// Waveform overview data
    WaveformOverview,
    /// Spectrum data
    SpectrumData,
    /// MIDI event buffer
    MidiBuffer,
    /// Generic binary blob
    Binary,
}

/// Registry for shared memory regions.
pub struct SharedMemoryRegistry {
    pub regions: HashMap<String, SharedMemoryRegion>,
}

impl SharedMemoryRegistry {
    pub fn new() -> Self {
        Self { regions: HashMap::new() }
    }

    /// Register a new shared memory region.
    pub fn register(&mut self, name: &str, size: usize, content_type: SharedMemoryType) {
        self.regions.insert(name.to_string(), SharedMemoryRegion {
            name: name.to_string(),
            size,
            content_type,
            locked: false,
            write_seq: 0,
        });
        info!("Shared memory region registered: {} ({} bytes, {:?})", name, size, content_type);
    }

    /// Unregister a region.
    pub fn unregister(&mut self, name: &str) -> bool {
        self.regions.remove(name).is_some()
    }

    /// Get region info.
    pub fn get(&self, name: &str) -> Option<&SharedMemoryRegion> {
        self.regions.get(name)
    }

    /// Mark a region as written (increment sequence).
    pub fn mark_written(&mut self, name: &str) {
        if let Some(region) = self.regions.get_mut(name) {
            region.write_seq += 1;
            region.locked = false;
        }
    }
}

// ============================================================================
// RM10.1: Command Acknowledgment (Request-Response)
// ============================================================================

/// A pending command awaiting acknowledgment.
#[derive(Debug, Clone)]
pub struct PendingCommand {
    pub request_id: u64,
    pub command_type: String,
    pub sent_at: Instant,
    pub timeout: Duration,
}

/// Manages pending command acknowledgments.
pub struct AckTracker {
    /// Pending commands (request_id → PendingCommand)
    pending: HashMap<u64, PendingCommand>,
    /// Next request ID
    next_id: AtomicU64,
    /// Default timeout
    pub default_timeout: Duration,
}

impl AckTracker {
    pub fn new() -> Self {
        Self {
            pending: HashMap::new(),
            next_id: AtomicU64::new(1),
            default_timeout: Duration::from_secs(5),
        }
    }

    /// Track a new command, returns the request ID.
    pub fn track(&mut self, command_type: &str) -> u64 {
        let id = self.next_id.fetch_add(1, Ordering::Relaxed);
        self.pending.insert(id, PendingCommand {
            request_id: id,
            command_type: command_type.to_string(),
            sent_at: Instant::now(),
            timeout: self.default_timeout,
        });
        id
    }

    /// Acknowledge a command (remove from pending).
    pub fn acknowledge(&mut self, request_id: u64) -> bool {
        self.pending.remove(&request_id).is_some()
    }

    /// Get list of timed-out commands.
    pub fn check_timeouts(&mut self) -> Vec<PendingCommand> {
        let now = Instant::now();
        let timed_out: Vec<u64> = self.pending
            .iter()
            .filter(|(_, cmd)| now.duration_since(cmd.sent_at) > cmd.timeout)
            .map(|(id, _)| *id)
            .collect();

        let mut result = Vec::new();
        for id in timed_out {
            if let Some(cmd) = self.pending.remove(&id) {
                result.push(cmd);
            }
        }
        result
    }

    /// Number of pending commands.
    pub fn pending_count(&self) -> usize {
        self.pending.len()
    }
}

// ============================================================================
// RM10.2: Python Bridge Helpers
// ============================================================================

/// Maps Rust events to PyQt6 signal names.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SignalMapping {
    /// Rust event type
    pub event_type: String,
    /// PyQt6 signal name
    pub signal_name: String,
    /// Whether this signal carries data
    pub has_payload: bool,
    /// Signal argument types (for PyQt6 signature)
    pub arg_types: Vec<String>,
}

/// Registry of event→signal mappings for the Python bridge.
pub struct SignalRegistry {
    pub mappings: Vec<SignalMapping>,
}

impl SignalRegistry {
    pub fn new() -> Self {
        let mappings = vec![
            SignalMapping { event_type: "PlayheadPosition".into(), signal_name: "playhead_changed".into(), has_payload: true, arg_types: vec!["float".into(), "int".into(), "bool".into()] },
            SignalMapping { event_type: "TransportState".into(), signal_name: "transport_state_changed".into(), has_payload: true, arg_types: vec!["bool".into(), "float".into()] },
            SignalMapping { event_type: "MeterLevels".into(), signal_name: "meter_levels_received".into(), has_payload: true, arg_types: vec!["int".into(), "float".into(), "float".into()] },
            SignalMapping { event_type: "MasterMeterLevel".into(), signal_name: "master_meter_received".into(), has_payload: true, arg_types: vec!["float".into(), "float".into()] },
            SignalMapping { event_type: "Ready".into(), signal_name: "engine_ready".into(), has_payload: true, arg_types: vec!["int".into(), "int".into(), "str".into()] },
            SignalMapping { event_type: "Error".into(), signal_name: "engine_error".into(), has_payload: true, arg_types: vec!["int".into(), "str".into()] },
            SignalMapping { event_type: "SyncProjectAck".into(), signal_name: "sync_ack".into(), has_payload: true, arg_types: vec!["int".into()] },
            SignalMapping { event_type: "FxMeter".into(), signal_name: "fx_meter_received".into(), has_payload: true, arg_types: vec!["int".into(), "int".into(), "float".into()] },
            SignalMapping { event_type: "Pong".into(), signal_name: "pong_received".into(), has_payload: true, arg_types: vec!["float".into(), "int".into()] },
            SignalMapping { event_type: "BatchAck".into(), signal_name: "batch_ack_received".into(), has_payload: true, arg_types: vec!["int".into(), "int".into(), "int".into()] },
            SignalMapping { event_type: "RenderProgress".into(), signal_name: "render_progress".into(), has_payload: true, arg_types: vec!["float".into()] },
            SignalMapping { event_type: "RenderComplete".into(), signal_name: "render_complete".into(), has_payload: true, arg_types: vec!["str".into()] },
        ];
        Self { mappings }
    }

    /// Get signal name for an event type.
    pub fn signal_for_event(&self, event_type: &str) -> Option<&SignalMapping> {
        self.mappings.iter().find(|m| m.event_type == event_type)
    }

    /// Generate Python bridge code stub.
    pub fn generate_python_stub(&self) -> String {
        let mut code = String::from("# Auto-generated signal definitions for RustEngineBridge\n");
        code.push_str("# v0.0.20.976 — RM10.2\n\n");
        code.push_str("from PyQt6.QtCore import pyqtSignal\n\n");
        code.push_str("class RustEngineSignals:\n");

        for mapping in &self.mappings {
            let args = mapping.arg_types.join(", ");
            code.push_str(&format!(
                "    {} = pyqtSignal({})\n",
                mapping.signal_name, args
            ));
        }

        code
    }
}

// ============================================================================
// RM10.2: Structured Error Handling
// ============================================================================

/// Structured error from the Rust engine.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EngineError {
    /// Error code
    pub code: u32,
    /// Error category
    pub category: ErrorCategory,
    /// Human-readable message
    pub message: String,
    /// Source module
    pub source: String,
    /// Whether this error is recoverable
    pub recoverable: bool,
    /// Suggested recovery action
    pub recovery_hint: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum ErrorCategory {
    /// Audio engine error (buffer underrun, etc.)
    Audio,
    /// Plugin error (crash, timeout, etc.)
    Plugin,
    /// MIDI error (device disconnect, etc.)
    Midi,
    /// File I/O error
    FileIO,
    /// Project error (corrupt data, etc.)
    Project,
    /// IPC/protocol error
    Protocol,
    /// Internal error (should not happen)
    Internal,
}

impl EngineError {
    pub fn audio(code: u32, message: &str) -> Self {
        Self { code, category: ErrorCategory::Audio, message: message.to_string(), source: "audio".into(), recoverable: true, recovery_hint: None }
    }

    pub fn plugin(code: u32, message: &str) -> Self {
        Self { code, category: ErrorCategory::Plugin, message: message.to_string(), source: "plugin".into(), recoverable: true, recovery_hint: Some("Try reloading the plugin".into()) }
    }

    pub fn protocol(code: u32, message: &str) -> Self {
        Self { code, category: ErrorCategory::Protocol, message: message.to_string(), source: "ipc".into(), recoverable: false, recovery_hint: None }
    }
}

// ============================================================================
// RM10.2: Hot-Reload Support
// ============================================================================

/// Engine hot-reload state.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum ReloadState {
    /// Normal operation
    Running,
    /// Preparing to reload (saving state)
    PreparingReload,
    /// Reloading (engine restarting)
    Reloading,
    /// Reload complete (restoring state)
    RestoringState,
    /// Reload failed
    ReloadFailed,
}

/// Manages engine hot-reload.
pub struct HotReloadManager {
    pub state: ReloadState,
    /// Saved state for restoration
    pub saved_state: Option<Vec<u8>>,
    /// Saved project JSON
    pub saved_project: Option<String>,
    /// Whether hot-reload is supported
    pub supported: bool,
}

impl HotReloadManager {
    pub fn new() -> Self {
        Self {
            state: ReloadState::Running,
            saved_state: None,
            saved_project: None,
            supported: true,
        }
    }

    /// Prepare for hot-reload by saving current state.
    pub fn prepare_reload(&mut self, state: Vec<u8>, project_json: String) {
        self.saved_state = Some(state);
        self.saved_project = Some(project_json);
        self.state = ReloadState::PreparingReload;
        info!("Hot-reload prepared: {} bytes state saved", self.saved_state.as_ref().map_or(0, |s| s.len()));
    }

    /// Mark reload as complete.
    pub fn reload_complete(&mut self) {
        self.state = ReloadState::Running;
        self.saved_state = None;
        self.saved_project = None;
        info!("Hot-reload complete");
    }

    /// Mark reload as failed.
    pub fn reload_failed(&mut self, reason: &str) {
        self.state = ReloadState::ReloadFailed;
        error!("Hot-reload failed: {}", reason);
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_batch_command() {
        let mut batch = BatchCommand::new(42);
        batch.add("Play", "{}");
        batch.add("SetTempo", "{\"bpm\": 130.0}");
        batch.add("AddTrack", "{\"name\": \"Drums\"}");

        assert_eq!(batch.len(), 3);
        assert_eq!(batch.batch_id, 42);
        assert!(batch.require_ack);
    }

    #[test]
    fn test_stream_manager() {
        let mut sm = StreamManager::new(44100, 512);

        sm.subscribe(StreamSubscription {
            stream_type: StreamType::Meters,
            update_rate_hz: 30,
            active: true,
            filter: None,
        });

        sm.subscribe(StreamSubscription {
            stream_type: StreamType::Playhead,
            update_rate_hz: 30,
            active: true,
            filter: None,
        });

        assert_eq!(sm.active_streams().len(), 2);

        // Rate limiting
        let mut emit_count = 0;
        for _ in 0..100 {
            if sm.should_emit(StreamType::Meters) {
                emit_count += 1;
            }
        }
        // Should emit roughly 100/3 ≈ 33 times (every ~3 frames at 30Hz with 512 buf at 44100)
        assert!(emit_count > 0);
        assert!(emit_count < 100);

        sm.unsubscribe(StreamType::Meters);
        assert_eq!(sm.active_streams().len(), 1);
    }

    #[test]
    fn test_shared_memory_registry() {
        let mut registry = SharedMemoryRegistry::new();

        registry.register("track_audio_0", 44100 * 4, SharedMemoryType::AudioBuffer);
        registry.register("waveform_overview", 8192, SharedMemoryType::WaveformOverview);

        assert_eq!(registry.regions.len(), 2);
        assert!(registry.get("track_audio_0").is_some());

        registry.mark_written("track_audio_0");
        assert_eq!(registry.get("track_audio_0").unwrap().write_seq, 1);

        assert!(registry.unregister("waveform_overview"));
        assert_eq!(registry.regions.len(), 1);
    }

    #[test]
    fn test_ack_tracker() {
        let mut tracker = AckTracker::new();
        tracker.default_timeout = Duration::from_millis(100);

        let id1 = tracker.track("Play");
        let id2 = tracker.track("SetTempo");

        assert_eq!(tracker.pending_count(), 2);

        assert!(tracker.acknowledge(id1));
        assert_eq!(tracker.pending_count(), 1);

        assert!(!tracker.acknowledge(999)); // non-existent
    }

    #[test]
    fn test_signal_registry() {
        let registry = SignalRegistry::new();

        let mapping = registry.signal_for_event("PlayheadPosition");
        assert!(mapping.is_some());
        assert_eq!(mapping.unwrap().signal_name, "playhead_changed");

        let stub = registry.generate_python_stub();
        assert!(stub.contains("playhead_changed"));
        assert!(stub.contains("pyqtSignal"));
    }

    #[test]
    fn test_engine_error() {
        let err = EngineError::plugin(100, "Plugin crashed");
        assert_eq!(err.category, ErrorCategory::Plugin);
        assert!(err.recoverable);
        assert!(err.recovery_hint.is_some());
    }

    #[test]
    fn test_hot_reload() {
        let mut reload = HotReloadManager::new();
        assert_eq!(reload.state, ReloadState::Running);

        reload.prepare_reload(vec![1, 2, 3], "{}".into());
        assert_eq!(reload.state, ReloadState::PreparingReload);
        assert!(reload.saved_state.is_some());

        reload.reload_complete();
        assert_eq!(reload.state, ReloadState::Running);
        assert!(reload.saved_state.is_none());
    }
}
