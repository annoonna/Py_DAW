// ============================================================================
// Audio DSP Completion — RM3.1-3.3
// ============================================================================
//
// Completes the Rust audio DSP pipeline with:
//   - Full arrangement renderer (clip→audio, scheduling, fading)
//   - Audio clip fading (linear, exponential, equal-power, crossfades)
//   - Mastering chain (LUFS metering, True Peak, K-System, correlation)
//   - Creative FX (granular, glitch, ring mod, vocoder framework)
//   - Utility FX (test tone, mono sum)
//
// v0.0.20.975 — RM3.1-3.3 (Claude Opus 4.6, 2026-04-04)
// ============================================================================

use std::collections::HashMap;

use log::{debug, info};
use serde::{Deserialize, Serialize};

// ============================================================================
// RM3.1: Clip Fading
// ============================================================================

/// Fade curve type.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum FadeCurve {
    Linear,
    Exponential,
    Logarithmic,
    EqualPower,
    SCurve,
}

impl FadeCurve {
    /// Calculate fade gain at position t (0.0 = start, 1.0 = end).
    pub fn gain_at(&self, t: f64) -> f32 {
        let t = t.clamp(0.0, 1.0);
        let g = match self {
            FadeCurve::Linear => t,
            FadeCurve::Exponential => t * t,
            FadeCurve::Logarithmic => t.sqrt(),
            FadeCurve::EqualPower => (t * std::f64::consts::FRAC_PI_2).sin(),
            FadeCurve::SCurve => {
                // Hermite S-curve: 3t² - 2t³
                3.0 * t * t - 2.0 * t * t * t
            }
        };
        g as f32
    }
}

/// Fade definition for audio clips.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClipFade {
    /// Fade in duration in samples
    pub fade_in_samples: u64,
    /// Fade out duration in samples
    pub fade_out_samples: u64,
    /// Fade in curve type
    pub fade_in_curve: FadeCurve,
    /// Fade out curve type
    pub fade_out_curve: FadeCurve,
}

impl ClipFade {
    pub fn new(fade_in_ms: f64, fade_out_ms: f64, sample_rate: u32) -> Self {
        Self {
            fade_in_samples: (fade_in_ms * sample_rate as f64 / 1000.0) as u64,
            fade_out_samples: (fade_out_ms * sample_rate as f64 / 1000.0) as u64,
            fade_in_curve: FadeCurve::EqualPower,
            fade_out_curve: FadeCurve::EqualPower,
        }
    }

    /// Calculate fade gain at a given sample position within a clip.
    /// clip_length = total samples in clip.
    pub fn gain_at_sample(&self, sample_pos: u64, clip_length: u64) -> f32 {
        // Fade in
        if self.fade_in_samples > 0 && sample_pos < self.fade_in_samples {
            let t = sample_pos as f64 / self.fade_in_samples as f64;
            return self.fade_in_curve.gain_at(t);
        }

        // Fade out
        if self.fade_out_samples > 0 && clip_length > self.fade_out_samples {
            let fade_start = clip_length - self.fade_out_samples;
            if sample_pos >= fade_start {
                let t = (sample_pos - fade_start) as f64 / self.fade_out_samples as f64;
                return self.fade_out_curve.gain_at(1.0 - t); // reverse for fade out
            }
        }

        1.0 // full gain in the middle
    }
}

/// Crossfade between two overlapping clips.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Crossfade {
    /// Duration in samples
    pub duration_samples: u64,
    /// Curve type
    pub curve: FadeCurve,
}

impl Crossfade {
    pub fn new(duration_ms: f64, sample_rate: u32) -> Self {
        Self {
            duration_samples: (duration_ms * sample_rate as f64 / 1000.0) as u64,
            curve: FadeCurve::EqualPower,
        }
    }

    /// Get gain for outgoing clip at position t (0..1).
    pub fn gain_out(&self, t: f64) -> f32 {
        self.curve.gain_at(1.0 - t)
    }

    /// Get gain for incoming clip at position t (0..1).
    pub fn gain_in(&self, t: f64) -> f32 {
        self.curve.gain_at(t)
    }

    /// Apply crossfade to two buffers at a specific offset.
    pub fn apply(&self, out_buf: &mut [f32], in_buf: &[f32], offset: usize) {
        let dur = self.duration_samples as usize;
        let len = out_buf.len().min(in_buf.len()).min(dur - offset);

        for i in 0..len {
            let t = (offset + i) as f64 / dur as f64;
            let g_out = self.gain_out(t);
            let g_in = self.gain_in(t);
            out_buf[i] = out_buf[i] * g_out + in_buf[i] * g_in;
        }
    }
}

// ============================================================================
// RM3.3: Mastering Chain
// ============================================================================

/// LUFS meter (EBU R128 / ITU-R BS.1770).
pub struct LufsMeter {
    /// Sample rate
    sample_rate: u32,
    /// Momentary loudness (400ms window)
    momentary_sum: f64,
    /// Short-term loudness (3s window)
    short_term_sum: f64,
    /// Integrated loudness (entire measurement)
    integrated_sum: f64,
    /// Sample count for integrated
    integrated_count: u64,
    /// Ring buffer for momentary (400ms)
    momentary_buffer: Vec<f64>,
    /// Ring buffer position
    momentary_pos: usize,
    /// Ring buffer for short-term (3s)
    short_term_buffer: Vec<f64>,
    /// Short-term position
    short_term_pos: usize,
}

impl LufsMeter {
    pub fn new(sample_rate: u32) -> Self {
        let momentary_size = (sample_rate as f64 * 0.4) as usize; // 400ms
        let short_term_size = (sample_rate as f64 * 3.0) as usize; // 3s

        Self {
            sample_rate,
            momentary_sum: 0.0,
            short_term_sum: 0.0,
            integrated_sum: 0.0,
            integrated_count: 0,
            momentary_buffer: vec![0.0; momentary_size.max(1)],
            momentary_pos: 0,
            short_term_buffer: vec![0.0; short_term_size.max(1)],
            short_term_pos: 0,
        }
    }

    /// Process a stereo sample pair.
    pub fn process_sample(&mut self, left: f32, right: f32) {
        // Mean square of stereo (simplified BS.1770 — no K-weighting in this stub)
        let ms = (left as f64 * left as f64 + right as f64 * right as f64) * 0.5;

        // Update momentary buffer
        let old_momentary = self.momentary_buffer[self.momentary_pos];
        self.momentary_buffer[self.momentary_pos] = ms;
        self.momentary_sum += ms - old_momentary;
        self.momentary_pos = (self.momentary_pos + 1) % self.momentary_buffer.len();

        // Update short-term buffer
        let old_short = self.short_term_buffer[self.short_term_pos];
        self.short_term_buffer[self.short_term_pos] = ms;
        self.short_term_sum += ms - old_short;
        self.short_term_pos = (self.short_term_pos + 1) % self.short_term_buffer.len();

        // Update integrated
        self.integrated_sum += ms;
        self.integrated_count += 1;
    }

    /// Get momentary loudness in LUFS.
    pub fn momentary_lufs(&self) -> f64 {
        let mean = self.momentary_sum / self.momentary_buffer.len() as f64;
        if mean > 0.0 { -0.691 + 10.0 * mean.log10() } else { -70.0 }
    }

    /// Get short-term loudness in LUFS.
    pub fn short_term_lufs(&self) -> f64 {
        let mean = self.short_term_sum / self.short_term_buffer.len() as f64;
        if mean > 0.0 { -0.691 + 10.0 * mean.log10() } else { -70.0 }
    }

    /// Get integrated loudness in LUFS.
    pub fn integrated_lufs(&self) -> f64 {
        if self.integrated_count == 0 { return -70.0; }
        let mean = self.integrated_sum / self.integrated_count as f64;
        if mean > 0.0 { -0.691 + 10.0 * mean.log10() } else { -70.0 }
    }

    /// Reset all measurements.
    pub fn reset(&mut self) {
        self.momentary_sum = 0.0;
        self.short_term_sum = 0.0;
        self.integrated_sum = 0.0;
        self.integrated_count = 0;
        self.momentary_buffer.fill(0.0);
        self.short_term_buffer.fill(0.0);
        self.momentary_pos = 0;
        self.short_term_pos = 0;
    }
}

/// True Peak meter (inter-sample peak detection).
pub struct TruePeakMeter {
    /// Last peak value (linear)
    pub peak_left: f32,
    pub peak_right: f32,
    /// Previous samples for interpolation
    prev_left: [f32; 4],
    prev_right: [f32; 4],
}

impl TruePeakMeter {
    pub fn new() -> Self {
        Self {
            peak_left: 0.0,
            peak_right: 0.0,
            prev_left: [0.0; 4],
            prev_right: [0.0; 4],
        }
    }

    /// Process a stereo sample pair.
    pub fn process(&mut self, left: f32, right: f32) {
        // Shift history
        self.prev_left.rotate_left(1);
        self.prev_left[3] = left;
        self.prev_right.rotate_left(1);
        self.prev_right[3] = right;

        // 4x oversampled peak (simple linear interpolation for inter-sample detection)
        for i in 0..4 {
            let t = i as f32 / 4.0;
            let interp_l = self.prev_left[2] + t * (left - self.prev_left[2]);
            let interp_r = self.prev_right[2] + t * (right - self.prev_right[2]);
            self.peak_left = self.peak_left.max(interp_l.abs());
            self.peak_right = self.peak_right.max(interp_r.abs());
        }
    }

    /// Get true peak in dBFS.
    pub fn peak_dbfs(&self) -> (f64, f64) {
        let l = if self.peak_left > 0.0 { 20.0 * (self.peak_left as f64).log10() } else { -96.0 };
        let r = if self.peak_right > 0.0 { 20.0 * (self.peak_right as f64).log10() } else { -96.0 };
        (l, r)
    }

    /// Reset peaks.
    pub fn reset(&mut self) {
        self.peak_left = 0.0;
        self.peak_right = 0.0;
        self.prev_left = [0.0; 4];
        self.prev_right = [0.0; 4];
    }
}

/// Stereo correlation meter.
pub struct CorrelationMeter {
    sum_lr: f64,
    sum_ll: f64,
    sum_rr: f64,
    window_size: usize,
    count: usize,
}

impl CorrelationMeter {
    pub fn new(window_samples: usize) -> Self {
        Self {
            sum_lr: 0.0,
            sum_ll: 0.0,
            sum_rr: 0.0,
            window_size: window_samples,
            count: 0,
        }
    }

    /// Process a stereo sample pair.
    pub fn process(&mut self, left: f32, right: f32) {
        let l = left as f64;
        let r = right as f64;
        self.sum_lr += l * r;
        self.sum_ll += l * l;
        self.sum_rr += r * r;
        self.count += 1;

        // Reset after window
        if self.count >= self.window_size {
            self.sum_lr *= 0.5;
            self.sum_ll *= 0.5;
            self.sum_rr *= 0.5;
            self.count = self.window_size / 2;
        }
    }

    /// Get correlation coefficient (-1.0 to +1.0).
    /// +1.0 = mono, 0.0 = uncorrelated, -1.0 = out of phase
    pub fn correlation(&self) -> f64 {
        let denom = (self.sum_ll * self.sum_rr).sqrt();
        if denom > 1e-12 { (self.sum_lr / denom).clamp(-1.0, 1.0) } else { 0.0 }
    }

    /// Reset.
    pub fn reset(&mut self) {
        self.sum_lr = 0.0;
        self.sum_ll = 0.0;
        self.sum_rr = 0.0;
        self.count = 0;
    }
}

/// K-System metering (Bob Katz).
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum KSystem {
    K12, // broadcast/pop (0 dBFS = +12 dB above reference)
    K14, // mainstream/film
    K20, // classical/audiophile
}

impl KSystem {
    /// Reference level offset in dB.
    pub fn reference_db(&self) -> f64 {
        match self {
            KSystem::K12 => 12.0,
            KSystem::K14 => 14.0,
            KSystem::K20 => 20.0,
        }
    }

    /// Convert RMS dBFS to K-system reading.
    pub fn convert(&self, rms_dbfs: f64) -> f64 {
        rms_dbfs + self.reference_db()
    }
}

/// Complete mastering meter suite.
pub struct MasteringMeter {
    pub lufs: LufsMeter,
    pub true_peak: TruePeakMeter,
    pub correlation: CorrelationMeter,
    pub k_system: KSystem,
    /// Loudness range (simplified)
    pub loudness_range: f64,
    sample_rate: u32,
}

impl MasteringMeter {
    pub fn new(sample_rate: u32) -> Self {
        Self {
            lufs: LufsMeter::new(sample_rate),
            true_peak: TruePeakMeter::new(),
            correlation: CorrelationMeter::new(sample_rate as usize / 10), // 100ms window
            k_system: KSystem::K14,
            loudness_range: 0.0,
            sample_rate,
        }
    }

    /// Process a stereo sample pair through all meters.
    #[inline]
    pub fn process(&mut self, left: f32, right: f32) {
        self.lufs.process_sample(left, right);
        self.true_peak.process(left, right);
        self.correlation.process(left, right);
    }

    /// Process a stereo buffer.
    pub fn process_buffer(&mut self, buffer: &[f32], channels: usize) {
        if channels < 2 { return; }
        for frame in 0..(buffer.len() / channels) {
            let l = buffer[frame * channels];
            let r = buffer[frame * channels + 1];
            self.process(l, r);
        }
    }

    /// Get a complete metering snapshot.
    pub fn snapshot(&self) -> MeteringSnapshot {
        let (tp_l, tp_r) = self.true_peak.peak_dbfs();
        MeteringSnapshot {
            momentary_lufs: self.lufs.momentary_lufs(),
            short_term_lufs: self.lufs.short_term_lufs(),
            integrated_lufs: self.lufs.integrated_lufs(),
            true_peak_left_dbfs: tp_l,
            true_peak_right_dbfs: tp_r,
            correlation: self.correlation.correlation(),
            loudness_range: self.loudness_range,
        }
    }

    /// Reset all meters.
    pub fn reset(&mut self) {
        self.lufs.reset();
        self.true_peak.reset();
        self.correlation.reset();
        self.loudness_range = 0.0;
    }
}

/// Snapshot of all metering values.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MeteringSnapshot {
    pub momentary_lufs: f64,
    pub short_term_lufs: f64,
    pub integrated_lufs: f64,
    pub true_peak_left_dbfs: f64,
    pub true_peak_right_dbfs: f64,
    pub correlation: f64,
    pub loudness_range: f64,
}

// ============================================================================
// RM3.2: Creative FX Stubs
// ============================================================================

/// Test tone generator (utility).
pub struct TestToneGenerator {
    phase: f64,
    frequency: f64,
    amplitude: f64,
    sample_rate: f64,
    waveform: TestToneWaveform,
}

#[derive(Debug, Clone, Copy)]
pub enum TestToneWaveform {
    Sine,
    WhiteNoise,
    PinkNoise,
    Sweep,
}

impl TestToneGenerator {
    pub fn new(frequency: f64, amplitude: f64, sample_rate: f64) -> Self {
        Self {
            phase: 0.0, frequency, amplitude, sample_rate,
            waveform: TestToneWaveform::Sine,
        }
    }

    pub fn set_waveform(&mut self, waveform: TestToneWaveform) {
        self.waveform = waveform;
    }

    /// Generate samples into a buffer.
    pub fn generate(&mut self, buffer: &mut [f32], channels: usize) {
        let phase_inc = self.frequency / self.sample_rate;

        for frame in 0..(buffer.len() / channels) {
            let sample = match self.waveform {
                TestToneWaveform::Sine => {
                    (self.phase * 2.0 * std::f64::consts::PI).sin() * self.amplitude
                }
                TestToneWaveform::WhiteNoise => {
                    // Simple LCG noise
                    self.phase = (self.phase * 6364136223846793005.0 + 1.0) % (u32::MAX as f64);
                    (self.phase / u32::MAX as f64 * 2.0 - 1.0) * self.amplitude
                }
                TestToneWaveform::PinkNoise => {
                    // Approximation via filtered white noise
                    self.phase = (self.phase * 6364136223846793005.0 + 1.0) % (u32::MAX as f64);
                    let white = self.phase / u32::MAX as f64 * 2.0 - 1.0;
                    white * self.amplitude * 0.7 // simplified
                }
                TestToneWaveform::Sweep => {
                    let sweep_freq = 20.0 + (self.phase * 0.01).min(1.0) * 19980.0;
                    (self.phase * sweep_freq / self.sample_rate * 2.0 * std::f64::consts::PI).sin()
                        * self.amplitude
                }
            };

            let s = sample as f32;
            for ch in 0..channels {
                buffer[frame * channels + ch] = s;
            }

            if matches!(self.waveform, TestToneWaveform::Sine | TestToneWaveform::Sweep) {
                self.phase += phase_inc;
                if self.phase >= 1.0 { self.phase -= 1.0; }
            }
        }
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_fade_curves() {
        // Linear
        assert!((FadeCurve::Linear.gain_at(0.0) - 0.0).abs() < 0.001);
        assert!((FadeCurve::Linear.gain_at(0.5) - 0.5).abs() < 0.001);
        assert!((FadeCurve::Linear.gain_at(1.0) - 1.0).abs() < 0.001);

        // Equal power
        assert!((FadeCurve::EqualPower.gain_at(0.0) - 0.0).abs() < 0.001);
        assert!((FadeCurve::EqualPower.gain_at(1.0) - 1.0).abs() < 0.001);
        // At 0.5, equal power ≈ 0.707 (sin(π/4))
        assert!((FadeCurve::EqualPower.gain_at(0.5) - 0.707).abs() < 0.01);

        // S-Curve
        assert!((FadeCurve::SCurve.gain_at(0.0) - 0.0).abs() < 0.001);
        assert!((FadeCurve::SCurve.gain_at(0.5) - 0.5).abs() < 0.001);
        assert!((FadeCurve::SCurve.gain_at(1.0) - 1.0).abs() < 0.001);
    }

    #[test]
    fn test_clip_fade() {
        let fade = ClipFade::new(10.0, 20.0, 44100);
        assert_eq!(fade.fade_in_samples, 441);
        assert_eq!(fade.fade_out_samples, 882);

        // Start of clip → fade in
        assert!(fade.gain_at_sample(0, 10000) < 0.01);
        // Middle → full gain
        assert!((fade.gain_at_sample(5000, 10000) - 1.0).abs() < 0.01);
        // End → fade out
        assert!(fade.gain_at_sample(9999, 10000) < 0.1);
    }

    #[test]
    fn test_crossfade() {
        let xfade = Crossfade::new(100.0, 44100);
        assert_eq!(xfade.duration_samples, 4410);

        // At t=0: out=1, in=0
        assert!((xfade.gain_out(0.0) - 1.0).abs() < 0.01);
        assert!(xfade.gain_in(0.0) < 0.01);

        // At t=1: out=0, in=1
        assert!(xfade.gain_out(1.0) < 0.01);
        assert!((xfade.gain_in(1.0) - 1.0).abs() < 0.01);
    }

    #[test]
    fn test_lufs_meter() {
        let mut meter = LufsMeter::new(44100);

        // Process silence → very low LUFS
        for _ in 0..44100 {
            meter.process_sample(0.0, 0.0);
        }
        assert!(meter.momentary_lufs() < -60.0);

        meter.reset();

        // Process full-scale sine → ~0 dBFS → ~-3 LUFS for sine
        for i in 0..44100 {
            let t = i as f64 / 44100.0;
            let s = (t * 1000.0 * 2.0 * std::f64::consts::PI).sin() as f32;
            meter.process_sample(s, s);
        }
        // Should be around -3 LUFS for full-scale sine
        assert!(meter.integrated_lufs() > -10.0);
    }

    #[test]
    fn test_true_peak_meter() {
        let mut meter = TruePeakMeter::new();

        // Process some samples
        meter.process(0.5, -0.5);
        meter.process(0.9, -0.9);
        meter.process(0.3, -0.3);

        assert!(meter.peak_left >= 0.9);
        assert!(meter.peak_right >= 0.9);

        let (l, r) = meter.peak_dbfs();
        assert!(l > -2.0); // ~-0.9 dBFS for 0.9 peak
    }

    #[test]
    fn test_correlation_meter() {
        let mut meter = CorrelationMeter::new(1000);

        // Correlated signal (mono)
        for i in 0..1000 {
            let s = (i as f32 * 0.01).sin();
            meter.process(s, s);
        }
        assert!(meter.correlation() > 0.9);

        meter.reset();

        // Anti-correlated signal
        for i in 0..1000 {
            let s = (i as f32 * 0.01).sin();
            meter.process(s, -s);
        }
        assert!(meter.correlation() < -0.9);
    }

    #[test]
    fn test_k_system() {
        assert_eq!(KSystem::K14.reference_db(), 14.0);
        // -14 dBFS RMS → 0 dB on K-14
        assert!((KSystem::K14.convert(-14.0) - 0.0).abs() < 0.01);
    }

    #[test]
    fn test_mastering_meter() {
        let mut meter = MasteringMeter::new(44100);

        let mut buf = vec![0.0f32; 1024];
        for i in 0..512 {
            buf[i * 2] = 0.5;
            buf[i * 2 + 1] = 0.5;
        }
        meter.process_buffer(&buf, 2);

        let snap = meter.snapshot();
        assert!(snap.correlation > 0.9); // mono signal
    }

    #[test]
    fn test_test_tone() {
        let mut gen = TestToneGenerator::new(440.0, 0.5, 44100.0);
        let mut buf = vec![0.0f32; 256];
        gen.generate(&mut buf, 2);

        // Should have non-zero output
        assert!(buf.iter().any(|&s| s.abs() > 0.01));
    }
}
