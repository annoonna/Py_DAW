// ============================================================================
// MIDI Processing + File I/O — v0.0.20.972 (RM4.2 + RM4.3)
// ============================================================================
//
// MIDI note manipulation and Standard MIDI File (SMF) read/write.
// ============================================================================

use serde::{Deserialize, Serialize};
use crate::model::MidiNote;
use log::info;

// ============================================================================
// RM4.2: MIDI Processing
// ============================================================================

/// Quantize grid size
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum QuantizeGrid {
    Bar,            // 4.0 beats
    HalfNote,       // 2.0
    Quarter,        // 1.0
    Eighth,         // 0.5
    Sixteenth,      // 0.25
    ThirtySecond,   // 0.125
    Triplet8,       // 1/3 beat
    Triplet16,      // 1/6 beat
    Dotted8,        // 0.75
    Dotted16,       // 0.375
}

impl QuantizeGrid {
    pub fn beats(self) -> f64 {
        match self {
            Self::Bar => 4.0,
            Self::HalfNote => 2.0,
            Self::Quarter => 1.0,
            Self::Eighth => 0.5,
            Self::Sixteenth => 0.25,
            Self::ThirtySecond => 0.125,
            Self::Triplet8 => 1.0 / 3.0,
            Self::Triplet16 => 1.0 / 6.0,
            Self::Dotted8 => 0.75,
            Self::Dotted16 => 0.375,
        }
    }
}

/// MIDI processing operations
pub struct MidiProcessor;

impl MidiProcessor {
    /// Quantize note start positions to grid
    pub fn quantize(notes: &mut [MidiNote], grid: QuantizeGrid, strength: f64) {
        let g = grid.beats();
        let s = strength.clamp(0.0, 1.0);
        for note in notes.iter_mut() {
            let nearest = (note.start_beat / g).round() * g;
            note.start_beat += (nearest - note.start_beat) * s;
        }
    }

    /// Quantize note lengths
    pub fn quantize_lengths(notes: &mut [MidiNote], grid: QuantizeGrid, strength: f64) {
        let g = grid.beats();
        let s = strength.clamp(0.0, 1.0);
        for note in notes.iter_mut() {
            let nearest = (note.length_beats / g).round().max(1.0) * g;
            note.length_beats += (nearest - note.length_beats) * s;
            note.length_beats = note.length_beats.max(g * 0.1); // minimum 10% of grid
        }
    }

    /// Transpose notes by semitones
    pub fn transpose(notes: &mut [MidiNote], semitones: i8) {
        for note in notes.iter_mut() {
            let new_pitch = note.pitch as i16 + semitones as i16;
            note.pitch = new_pitch.clamp(0, 127) as u8;
        }
    }

    /// Scale velocities
    pub fn scale_velocity(notes: &mut [MidiNote], factor: f64) {
        for note in notes.iter_mut() {
            let v = (note.velocity as f64 * factor).round().clamp(1.0, 127.0);
            note.velocity = v as u8;
        }
    }

    /// Compress velocity range
    pub fn compress_velocity(notes: &mut [MidiNote], min: u8, max: u8) {
        if notes.is_empty() { return; }
        let cur_min = notes.iter().map(|n| n.velocity).min().unwrap() as f64;
        let cur_max = notes.iter().map(|n| n.velocity).max().unwrap() as f64;
        let cur_range = (cur_max - cur_min).max(1.0);
        let new_range = (max as f64 - min as f64).max(1.0);
        for note in notes.iter_mut() {
            let normalized = (note.velocity as f64 - cur_min) / cur_range;
            note.velocity = (min as f64 + normalized * new_range).round().clamp(1.0, 127.0) as u8;
        }
    }

    /// Humanize: add random timing and velocity variation
    pub fn humanize(notes: &mut [MidiNote], timing_amount: f64, velocity_amount: f64) {
        let mut rng: u32 = 0xCAFEBABE;
        for note in notes.iter_mut() {
            rng = rng.wrapping_mul(1103515245).wrapping_add(12345);
            let t_rand = ((rng >> 16) as f64 / 32768.0 - 1.0) * timing_amount * 0.05;
            note.start_beat = (note.start_beat + t_rand).max(0.0);

            rng = rng.wrapping_mul(1103515245).wrapping_add(12345);
            let v_rand = ((rng >> 16) as f64 / 32768.0 - 1.0) * velocity_amount * 20.0;
            note.velocity = (note.velocity as f64 + v_rand).round().clamp(1.0, 127.0) as u8;
        }
    }

    /// Legato: extend each note to reach the next note's start
    pub fn legato(notes: &mut [MidiNote]) {
        let mut sorted: Vec<usize> = (0..notes.len()).collect();
        sorted.sort_by(|&a, &b| notes[a].start_beat.partial_cmp(&notes[b].start_beat).unwrap());
        for i in 0..sorted.len().saturating_sub(1) {
            let cur = sorted[i];
            let next = sorted[i + 1];
            let gap = notes[next].start_beat - notes[cur].start_beat;
            if gap > 0.0 {
                notes[cur].length_beats = gap;
            }
        }
    }

    /// Staccato: shorten all notes to a fraction of their length
    pub fn staccato(notes: &mut [MidiNote], fraction: f64) {
        let f = fraction.clamp(0.1, 1.0);
        for note in notes.iter_mut() {
            note.length_beats *= f;
        }
    }

    /// Reverse the order of notes (keeping positions)
    pub fn reverse(notes: &mut [MidiNote]) {
        if notes.len() < 2 { return; }
        let mut sorted: Vec<(f64, usize)> = notes.iter()
            .enumerate().map(|(i, n)| (n.start_beat, i)).collect();
        sorted.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());

        let pitches: Vec<u8> = sorted.iter().map(|(_, i)| notes[*i].pitch).collect();
        let velocities: Vec<u8> = sorted.iter().map(|(_, i)| notes[*i].velocity).collect();
        let n = sorted.len();
        for (j, (_, idx)) in sorted.iter().enumerate() {
            notes[*idx].pitch = pitches[n - 1 - j];
            notes[*idx].velocity = velocities[n - 1 - j];
        }
    }

    /// Generate arpeggio from chord (notes at same position)
    pub fn arpeggiate(notes: &mut Vec<MidiNote>, rate: QuantizeGrid, pattern: ArpPattern) {
        // Group by start beat
        let mut groups: std::collections::BTreeMap<u64, Vec<usize>> =
            std::collections::BTreeMap::new();
        for (i, note) in notes.iter().enumerate() {
            let key = (note.start_beat * 10000.0) as u64;
            groups.entry(key).or_default().push(i);
        }

        let step = rate.beats();
        let mut new_notes = Vec::new();

        for (_key, indices) in &groups {
            if indices.len() < 2 { // single notes stay
                for &i in indices { new_notes.push(notes[i]); }
                continue;
            }
            let mut chord: Vec<MidiNote> = indices.iter().map(|&i| notes[i]).collect();
            chord.sort_by(|a, b| a.pitch.cmp(&b.pitch));

            let order = pattern.sequence(chord.len());
            let base_beat = chord[0].start_beat;
            let total_dur = chord[0].length_beats;

            for (step_idx, &note_idx) in order.iter().enumerate() {
                let mut n = chord[note_idx % chord.len()];
                n.start_beat = base_beat + step_idx as f64 * step;
                n.length_beats = step * 0.9; // slight gap
                if n.start_beat < base_beat + total_dur {
                    new_notes.push(n);
                }
            }
        }
        *notes = new_notes;
    }
}

/// Arpeggiator pattern
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum ArpPattern {
    Up,
    Down,
    UpDown,
    DownUp,
    Random,
}

impl ArpPattern {
    fn sequence(&self, len: usize) -> Vec<usize> {
        match self {
            Self::Up => (0..len * 2).map(|i| i % len).collect(),
            Self::Down => (0..len * 2).map(|i| (len - 1) - (i % len)).collect(),
            Self::UpDown => {
                let mut s: Vec<usize> = (0..len).collect();
                s.extend((1..len - 1).rev());
                s.extend(s.clone()); // repeat
                s
            }
            Self::DownUp => {
                let mut s: Vec<usize> = (0..len).rev().collect();
                s.extend(1..len - 1);
                s.extend(s.clone());
                s
            }
            Self::Random => {
                let mut rng: u32 = 0xFEEDFACE;
                (0..len * 4).map(|_| {
                    rng = rng.wrapping_mul(1103515245).wrapping_add(12345);
                    (rng >> 16) as usize % len
                }).collect()
            }
        }
    }
}

// ============================================================================
// RM4.3: Standard MIDI File (SMF) Import/Export
// ============================================================================

/// Standard MIDI File type
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum SmfType {
    Type0,  // single track
    Type1,  // multi-track
}

/// Read a Standard MIDI File and convert to MidiNote arrays (one per track)
pub fn read_smf(data: &[u8]) -> Result<Vec<Vec<MidiNote>>, String> {
    if data.len() < 14 { return Err("Too short for MIDI file".into()); }
    if &data[0..4] != b"MThd" { return Err("Not a MIDI file (missing MThd)".into()); }

    let header_len = u32::from_be_bytes([data[4], data[5], data[6], data[7]]) as usize;
    let format = u16::from_be_bytes([data[8], data[9]]);
    let num_tracks = u16::from_be_bytes([data[10], data[11]]);
    let ticks_per_beat = u16::from_be_bytes([data[12], data[13]]);

    if ticks_per_beat == 0 { return Err("Invalid ticks_per_beat".into()); }
    let tpb = ticks_per_beat as f64;

    info!("SMF: format={}, tracks={}, tpb={}", format, num_tracks, ticks_per_beat);

    let mut pos = 8 + header_len;
    let mut all_tracks = Vec::new();

    for _track_idx in 0..num_tracks {
        if pos + 8 > data.len() { break; }
        if &data[pos..pos + 4] != b"MTrk" {
            return Err(format!("Expected MTrk at offset {}", pos));
        }
        let track_len = u32::from_be_bytes([
            data[pos + 4], data[pos + 5], data[pos + 6], data[pos + 7]
        ]) as usize;
        pos += 8;

        let track_end = (pos + track_len).min(data.len());
        let track_data = &data[pos..track_end];
        let notes = parse_track(track_data, tpb)?;
        all_tracks.push(notes);

        pos = track_end;
    }

    Ok(all_tracks)
}

fn parse_track(data: &[u8], tpb: f64) -> Result<Vec<MidiNote>, String> {
    let mut notes = Vec::new();
    let mut active: std::collections::HashMap<(u8, u8), (f64, u8)> = std::collections::HashMap::new();
    let mut pos = 0;
    let mut tick: u64 = 0;
    let mut running_status: u8 = 0;

    while pos < data.len() {
        // Read variable-length delta time
        let (delta, bytes_read) = read_vlq(&data[pos..]);
        pos += bytes_read;
        tick += delta;
        let beat = tick as f64 / tpb;

        if pos >= data.len() { break; }

        let mut status = data[pos];
        if status < 0x80 {
            // Running status
            status = running_status;
        } else {
            pos += 1;
            if status < 0xF0 { running_status = status; }
        }

        let channel = status & 0x0F;
        match status & 0xF0 {
            0x90 if pos + 1 < data.len() => {
                let note = data[pos]; let vel = data[pos + 1]; pos += 2;
                if vel > 0 {
                    active.insert((channel, note), (beat, vel));
                } else {
                    if let Some((start, velocity)) = active.remove(&(channel, note)) {
                        notes.push(MidiNote {
                            pitch: note, velocity,
                            start_beat: start,
                            length_beats: (beat - start).max(0.001),
                            channel,
                            pressure: None, slide: None, pitch_bend: None,
                        });
                    }
                }
            }
            0x80 if pos + 1 < data.len() => {
                let note = data[pos]; let _vel = data[pos + 1]; pos += 2;
                if let Some((start, velocity)) = active.remove(&(channel, note)) {
                    notes.push(MidiNote {
                        pitch: note, velocity,
                        start_beat: start,
                        length_beats: (beat - start).max(0.001),
                        channel,
                        pressure: None, slide: None, pitch_bend: None,
                    });
                }
            }
            0xB0 | 0xE0 | 0xA0 if pos + 1 < data.len() => { pos += 2; } // CC, PitchBend, PolyPressure
            0xC0 | 0xD0 if pos < data.len() => { pos += 1; } // ProgramChange, ChannelPressure
            0xF0 => {
                // SysEx or Meta event
                if status == 0xFF && pos < data.len() {
                    let meta_type = data[pos]; pos += 1;
                    let (len, br) = read_vlq(&data[pos..]);
                    pos += br + len as usize;
                    if meta_type == 0x2F { break; } // End of track
                } else {
                    // SysEx: read until 0xF7
                    while pos < data.len() && data[pos] != 0xF7 { pos += 1; }
                    if pos < data.len() { pos += 1; }
                }
            }
            _ => { break; }
        }
    }

    // Close any remaining active notes
    let end_beat = tick as f64 / tpb;
    for ((ch, note), (start, vel)) in active {
        notes.push(MidiNote {
            pitch: note, velocity: vel,
            start_beat: start, length_beats: (end_beat - start).max(0.001),
            channel: ch, pressure: None, slide: None, pitch_bend: None,
        });
    }

    notes.sort_by(|a, b| a.start_beat.partial_cmp(&b.start_beat).unwrap());
    Ok(notes)
}

/// Write notes to Standard MIDI File format
pub fn write_smf(tracks: &[Vec<MidiNote>], ticks_per_beat: u16) -> Vec<u8> {
    let tpb = ticks_per_beat as f64;
    let num_tracks = tracks.len().max(1) as u16;
    let format: u16 = if num_tracks == 1 { 0 } else { 1 };

    let mut out = Vec::new();

    // MThd header
    out.extend_from_slice(b"MThd");
    out.extend_from_slice(&6u32.to_be_bytes());
    out.extend_from_slice(&format.to_be_bytes());
    out.extend_from_slice(&num_tracks.to_be_bytes());
    out.extend_from_slice(&ticks_per_beat.to_be_bytes());

    for track_notes in tracks {
        let track_data = write_track(track_notes, tpb);
        out.extend_from_slice(b"MTrk");
        out.extend_from_slice(&(track_data.len() as u32).to_be_bytes());
        out.extend_from_slice(&track_data);
    }

    out
}

fn write_track(notes: &[MidiNote], tpb: f64) -> Vec<u8> {
    // Build list of events sorted by tick
    let mut events: Vec<(u64, Vec<u8>)> = Vec::new();
    for note in notes {
        let on_tick = (note.start_beat * tpb) as u64;
        let off_tick = ((note.start_beat + note.length_beats) * tpb) as u64;
        events.push((on_tick, vec![0x90 | note.channel, note.pitch, note.velocity]));
        events.push((off_tick, vec![0x80 | note.channel, note.pitch, 0]));
    }
    events.sort_by_key(|(tick, _)| *tick);

    let mut out = Vec::new();
    let mut last_tick: u64 = 0;
    for (tick, data) in &events {
        let delta = tick - last_tick;
        write_vlq(&mut out, delta);
        out.extend_from_slice(data);
        last_tick = *tick;
    }

    // End of track meta event
    write_vlq(&mut out, 0);
    out.extend_from_slice(&[0xFF, 0x2F, 0x00]);

    out
}

/// Read variable-length quantity — returns (value, bytes_consumed)
fn read_vlq(data: &[u8]) -> (u64, usize) {
    let mut value: u64 = 0;
    let mut bytes = 0;
    for &b in data {
        value = (value << 7) | (b & 0x7F) as u64;
        bytes += 1;
        if b & 0x80 == 0 { break; }
        if bytes >= 4 { break; }
    }
    (value, bytes)
}

/// Write variable-length quantity
fn write_vlq(out: &mut Vec<u8>, mut value: u64) {
    if value == 0 {
        out.push(0);
        return;
    }
    let mut buf = [0u8; 5];
    let mut n = 0;
    while value > 0 {
        buf[n] = (value & 0x7F) as u8;
        value >>= 7;
        n += 1;
    }
    for i in (1..n).rev() {
        out.push(buf[i] | 0x80);
    }
    out.push(buf[0]);
}
