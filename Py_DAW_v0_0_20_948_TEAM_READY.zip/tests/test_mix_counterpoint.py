"""Tests for Mix Analysis, Counterpoint, and Smart Mixer services.

v0.0.20.910 — C4.3, C4.4, C4.7/C4.8 Tests.
"""

import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ---------------------------------------------------------------------------
# C4.3: MixAnalyzer Tests
# ---------------------------------------------------------------------------

class TestMixAnalyzer:
    """Tests for pydaw.services.mix_analysis.MixAnalyzer."""

    def _make_analyzer(self):
        from pydaw.services.mix_analysis import MixAnalyzer
        return MixAnalyzer(sample_rate=48000)

    def test_import(self):
        from pydaw.services.mix_analysis import MixAnalyzer, TrackAnalysis, MixReport
        assert MixAnalyzer is not None

    @pytest.mark.skipif(
        not pytest.importorskip("numpy", reason="numpy required"),
        reason="numpy not available",
    )
    def test_analyze_silence(self):
        import numpy as np
        analyzer = self._make_analyzer()
        silence = np.zeros(48000, dtype=np.float64)
        result = analyzer.analyze_track(silence, name="Silent")
        assert result.name == "Silent"
        assert result.rms_db <= -90.0
        assert result.peak_db <= -90.0
        assert result.duration_seconds == pytest.approx(1.0, abs=0.01)

    @pytest.mark.skipif(
        not pytest.importorskip("numpy", reason="numpy required"),
        reason="numpy not available",
    )
    def test_analyze_sine(self):
        import numpy as np
        analyzer = self._make_analyzer()
        sr = 48000
        t = np.linspace(0, 1.0, sr, endpoint=False)
        sine = 0.5 * np.sin(2 * np.pi * 440 * t)
        result = analyzer.analyze_track(sine, name="A440")
        assert result.name == "A440"
        assert result.rms_db > -10.0
        assert result.peak_db > -10.0
        assert not result.clipping

    @pytest.mark.skipif(
        not pytest.importorskip("numpy", reason="numpy required"),
        reason="numpy not available",
    )
    def test_analyze_clipping(self):
        import numpy as np
        analyzer = self._make_analyzer()
        clipping = np.ones(48000, dtype=np.float64)
        result = analyzer.analyze_track(clipping, name="Clip")
        assert result.clipping
        assert result.peak_db >= -0.1

    @pytest.mark.skipif(
        not pytest.importorskip("numpy", reason="numpy required"),
        reason="numpy not available",
    )
    def test_spectral_balance_has_bands(self):
        import numpy as np
        analyzer = self._make_analyzer()
        sr = 48000
        t = np.linspace(0, 1.0, sr, endpoint=False)
        sine = 0.5 * np.sin(2 * np.pi * 440 * t)
        result = analyzer.analyze_track(sine, name="440Hz")
        assert "mid" in result.spectral or "low_mid" in result.spectral
        assert len(result.spectral) == 7  # 7 bands

    @pytest.mark.skipif(
        not pytest.importorskip("numpy", reason="numpy required"),
        reason="numpy not available",
    )
    def test_stereo_width(self):
        import numpy as np
        analyzer = self._make_analyzer()
        sr = 48000
        t = np.linspace(0, 1.0, sr, endpoint=False)
        # Mono signal (L == R)
        mono = np.column_stack([np.sin(2 * np.pi * 440 * t)] * 2)
        result = analyzer.analyze_track(mono, name="Mono")
        assert result.stereo_width < 0.1

    @pytest.mark.skipif(
        not pytest.importorskip("numpy", reason="numpy required"),
        reason="numpy not available",
    )
    def test_analyze_mix_two_tracks(self):
        import numpy as np
        analyzer = self._make_analyzer()
        sr = 48000
        t = np.linspace(0, 1.0, sr, endpoint=False)
        kick = 0.8 * np.sin(2 * np.pi * 60 * t)
        vocal = 0.5 * np.sin(2 * np.pi * 1000 * t)
        report = analyzer.analyze_mix({"Kick": kick, "Vocal": vocal})
        assert len(report.tracks) == 2
        assert report.overall_lufs > -100.0

    @pytest.mark.skipif(
        not pytest.importorskip("numpy", reason="numpy required"),
        reason="numpy not available",
    )
    def test_format_report(self):
        import numpy as np
        analyzer = self._make_analyzer()
        sr = 48000
        t = np.linspace(0, 1.0, sr, endpoint=False)
        kick = 0.8 * np.sin(2 * np.pi * 60 * t)
        report = analyzer.analyze_mix({"Kick": kick})
        text = analyzer.format_report(report)
        assert "Kick" in text
        assert "LUFS" in text

    @pytest.mark.skipif(
        not pytest.importorskip("numpy", reason="numpy required"),
        reason="numpy not available",
    )
    def test_empty_track(self):
        import numpy as np
        analyzer = self._make_analyzer()
        result = analyzer.analyze_track(np.array([]), name="Empty")
        assert "Leere" in result.suggestions[0]


# ---------------------------------------------------------------------------
# C4.4: CounterpointAssistant Tests
# ---------------------------------------------------------------------------

class TestCounterpointAssistant:
    """Tests for pydaw.services.counterpoint_assistant.CounterpointAssistant."""

    def _make(self):
        from pydaw.services.counterpoint_assistant import CounterpointAssistant
        return CounterpointAssistant()

    def _simple_melody(self):
        return [
            {"pitch": 60, "start": 0.0, "duration": 1.0, "velocity": 100},
            {"pitch": 64, "start": 1.0, "duration": 1.0, "velocity": 100},
            {"pitch": 67, "start": 2.0, "duration": 1.0, "velocity": 100},
            {"pitch": 72, "start": 3.0, "duration": 1.0, "velocity": 100},
        ]

    def test_import(self):
        from pydaw.services.counterpoint_assistant import (
            CounterpointAssistant, CounterpointResult, STYLES,
        )
        assert len(STYLES) >= 5

    def test_generate_thirds_below(self):
        cp = self._make()
        result = cp.generate(self._simple_melody(), style="thirds_below")
        assert len(result.notes) == 4
        # All counter notes should be below melody
        for i, n in enumerate(result.notes):
            assert n["pitch"] <= self._simple_melody()[i]["pitch"]

    def test_generate_thirds_above(self):
        cp = self._make()
        result = cp.generate(self._simple_melody(), style="thirds_above")
        assert len(result.notes) == 4
        # All counter notes should be above melody
        for i, n in enumerate(result.notes):
            assert n["pitch"] >= self._simple_melody()[i]["pitch"]

    def test_generate_contrary_motion(self):
        cp = self._make()
        result = cp.generate(self._simple_melody(), style="contrary_motion")
        assert len(result.notes) == 4
        assert result.style == "contrary_motion"

    def test_generate_oblique(self):
        cp = self._make()
        result = cp.generate(self._simple_melody(), style="oblique")
        assert len(result.notes) == 4

    def test_generate_free(self):
        cp = self._make()
        result = cp.generate(self._simple_melody(), style="free")
        assert len(result.notes) == 4
        assert 0.0 <= result.quality_score <= 1.0

    def test_all_styles(self):
        cp = self._make()
        for style in cp.list_styles():
            result = cp.generate(self._simple_melody(), style=style)
            assert len(result.notes) == 4, f"Style {style} failed"

    def test_velocity_offset(self):
        cp = self._make()
        result = cp.generate(
            self._simple_melody(), style="thirds_below", velocity_offset=-20
        )
        for n in result.notes:
            assert n["velocity"] <= 100

    def test_empty_melody(self):
        cp = self._make()
        result = cp.generate([], style="thirds_below")
        assert len(result.notes) == 0
        assert len(result.warnings) > 0

    def test_unknown_style_fallback(self):
        cp = self._make()
        result = cp.generate(self._simple_melody(), style="nonexistent")
        assert result.style == "thirds_below"  # fallback
        assert len(result.warnings) > 0

    def test_quality_score_range(self):
        cp = self._make()
        result = cp.generate(self._simple_melody(), style="thirds_below")
        assert 0.0 <= result.quality_score <= 1.0

    def test_different_keys_and_scales(self):
        cp = self._make()
        for key in ["C", "D", "F#", "Bb"]:
            for scale in ["major", "natural_minor", "dorian"]:
                result = cp.generate(
                    self._simple_melody(), key=key, scale=scale
                )
                assert len(result.notes) == 4


# ---------------------------------------------------------------------------
# C2C.2: Conflict Detector Tests
# ---------------------------------------------------------------------------

class TestConflictDetector:
    """Tests for ConflictDetector and EditConflict."""

    def test_no_conflict_same_user(self):
        from pydaw.services.collab_service import ConflictDetector
        d = ConflictDetector(window_ms=5000)
        c1 = d.record_edit("user1", "t1", "volume", 0.5)
        c2 = d.record_edit("user1", "t1", "volume", 0.8)
        assert c1 is None
        assert c2 is None  # Same user → no conflict

    def test_conflict_different_users(self):
        from pydaw.services.collab_service import ConflictDetector
        d = ConflictDetector(window_ms=5000)
        d.record_edit("user1", "t1", "volume", 0.5)
        c = d.record_edit("user2", "t1", "volume", 0.8)
        assert c is not None
        assert c.user_a == "user1"
        assert c.user_b == "user2"

    def test_no_conflict_different_params(self):
        from pydaw.services.collab_service import ConflictDetector
        d = ConflictDetector(window_ms=5000)
        d.record_edit("user1", "t1", "volume", 0.5)
        c = d.record_edit("user2", "t1", "pan", 0.3)
        assert c is None  # Different params → no conflict

    def test_no_conflict_same_value(self):
        from pydaw.services.collab_service import ConflictDetector
        d = ConflictDetector(window_ms=5000)
        d.record_edit("user1", "t1", "volume", 0.5)
        c = d.record_edit("user2", "t1", "volume", 0.5)
        assert c is None  # Same value → no conflict


# ---------------------------------------------------------------------------
# SmartMixer gain staging tests (using existing smart_mixer.py)
# ---------------------------------------------------------------------------

class TestSmartMixerGainStaging:
    """Tests for the smart_mixer auto-gain-staging."""

    def test_import_smart_mixer(self):
        from pydaw.services.smart_mixer import compute_auto_gain, TrackAnalysis
        assert compute_auto_gain is not None

    def test_compute_auto_gain(self):
        from pydaw.services.smart_mixer import compute_auto_gain, TrackAnalysis
        ta = TrackAnalysis()
        ta.track_id = "t1"
        ta.track_name = "Kick"
        ta.lufs = -12.0
        gains = compute_auto_gain([ta], target_lufs=-18.0)
        assert "t1" in gains
        assert gains["t1"] < 0  # Should reduce gain (too loud)

    def test_generate_recommendations(self):
        from pydaw.services.smart_mixer import generate_recommendations, TrackAnalysis
        ta = TrackAnalysis()
        ta.track_id = "t1"
        ta.track_name = "Test"
        ta.lufs = -14.0
        ta.peak_db = -1.0
        recs, score = generate_recommendations([ta], [], -1.0, -14.0)
        assert isinstance(recs, list)
        assert isinstance(score, float)
