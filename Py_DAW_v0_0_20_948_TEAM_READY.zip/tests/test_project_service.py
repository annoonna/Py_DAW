"""Tests for ProjectService — Track CRUD, new/save project.

v0.0.20.911 — C3A.6: ProjectService Tests.

Uses unittest.mock to patch PyQt6 signals so tests run without a display.
"""

import os
import sys
import json
import tempfile
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# We need to mock PyQt6 if not available
try:
    from PyQt6.QtCore import QObject
    _HAS_QT = True
except ImportError:
    _HAS_QT = False


@pytest.fixture
def project_service():
    """Create a ProjectService with mocked threadpool."""
    if not _HAS_QT:
        pytest.skip("PyQt6 not available")
    # Suppress any GUI-related side effects
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    try:
        from pydaw.core.threading import ThreadPoolService
        from pydaw.services.project_service import ProjectService
        tp = ThreadPoolService.create_default()
        ps = ProjectService(threadpool=tp)
        return ps
    except Exception as e:
        pytest.skip(f"ProjectService init failed: {e}")


# ---------------------------------------------------------------------------
# Project Lifecycle Tests
# ---------------------------------------------------------------------------

class TestProjectServiceLifecycle:
    """Tests for new_project, save, open."""

    def test_new_project_default(self, project_service):
        ps = project_service
        ps.new_project()
        assert ps.ctx is not None
        assert ps.ctx.project is not None
        assert ps.ctx.project.bpm > 0

    def test_new_project_custom_name(self, project_service):
        ps = project_service
        ps.new_project(name="Test Song")
        assert ps.ctx.project.name == "Test Song"

    def test_new_project_has_master_track(self, project_service):
        ps = project_service
        ps.new_project()
        tracks = ps.ctx.project.tracks or []
        master = [t for t in tracks if getattr(t, 'kind', '') == 'master']
        assert len(master) >= 1

    def test_new_project_resets_undo(self, project_service):
        ps = project_service
        ps.new_project()
        assert ps.undo_stack.can_undo() is False

    def test_save_and_open_roundtrip(self, project_service, tmp_path):
        ps = project_service
        ps.new_project(name="Save Test")
        ps.add_track("audio", name="My Audio")
        save_path = tmp_path / "test_project.pydaw"

        # Save
        ps.save_project_as(save_path)
        assert save_path.exists()

        # Modify project
        ps.new_project(name="Other")
        assert ps.ctx.project.name == "Other"

        # Open saved project (async, so we call the sync parts)
        try:
            from pydaw.fileio.project_io import fm_open_project
            ctx = fm_open_project(save_path)
            assert ctx.project.name == "Save Test"
            audio_tracks = [t for t in ctx.project.tracks
                            if getattr(t, 'kind', '') == 'audio']
            assert len(audio_tracks) >= 1
        except Exception as e:
            pytest.skip(f"fm_open_project failed: {e}")


# ---------------------------------------------------------------------------
# Track CRUD Tests
# ---------------------------------------------------------------------------

class TestProjectServiceTrackCRUD:
    """Tests for add_track, remove_track, reorder."""

    def test_add_audio_track(self, project_service):
        ps = project_service
        ps.new_project()
        trk = ps.add_track("audio", name="Kick")
        assert trk is not None
        assert trk.name == "Kick"
        assert trk.kind == "audio"

    def test_add_instrument_track(self, project_service):
        ps = project_service
        ps.new_project()
        trk = ps.add_track("instrument", name="Synth Lead")
        assert trk.kind == "instrument"
        assert trk.name == "Synth Lead"

    def test_add_bus_track(self, project_service):
        ps = project_service
        ps.new_project()
        trk = ps.add_track("bus", name="Reverb Bus")
        assert trk.kind == "bus"

    def test_add_track_default_name(self, project_service):
        ps = project_service
        ps.new_project()
        trk = ps.add_track("audio")
        assert trk.name == "Audio Track"

    def test_add_multiple_tracks(self, project_service):
        ps = project_service
        ps.new_project()
        initial_count = len(ps.ctx.project.tracks)
        ps.add_track("audio", name="A1")
        ps.add_track("audio", name="A2")
        ps.add_track("instrument", name="I1")
        assert len(ps.ctx.project.tracks) == initial_count + 3

    def test_remove_track(self, project_service):
        ps = project_service
        ps.new_project()
        trk = ps.add_track("audio", name="To Remove")
        tid = trk.id
        count_before = len(ps.ctx.project.tracks)
        ps.remove_track(tid)
        assert len(ps.ctx.project.tracks) == count_before - 1
        assert not any(t.id == tid for t in ps.ctx.project.tracks)

    def test_remove_master_track_fails(self, project_service):
        ps = project_service
        ps.new_project()
        master = next(
            (t for t in ps.ctx.project.tracks if getattr(t, 'kind', '') == 'master'),
            None
        )
        if master:
            count_before = len(ps.ctx.project.tracks)
            ps.remove_track(master.id)
            # Master should NOT be removed
            assert len(ps.ctx.project.tracks) == count_before

    def test_remove_nonexistent_track(self, project_service):
        ps = project_service
        ps.new_project()
        count_before = len(ps.ctx.project.tracks)
        ps.remove_track("nonexistent-id-12345")
        assert len(ps.ctx.project.tracks) == count_before

    def test_add_track_with_insert_index(self, project_service):
        ps = project_service
        ps.new_project()
        ps.add_track("audio", name="First")
        ps.add_track("audio", name="Second")
        trk = ps.add_track("audio", name="Inserted", insert_index=1)
        # Should be somewhere near index 1 (master may be at end)
        names = [t.name for t in ps.ctx.project.tracks]
        assert "Inserted" in names

    def test_selected_track_after_add(self, project_service):
        ps = project_service
        ps.new_project()
        trk = ps.add_track("audio", name="Selected")
        assert ps._selected_track_id == trk.id

    def test_track_ids_unique(self, project_service):
        ps = project_service
        ps.new_project()
        t1 = ps.add_track("audio", name="A")
        t2 = ps.add_track("audio", name="B")
        t3 = ps.add_track("instrument", name="C")
        ids = {t1.id, t2.id, t3.id}
        assert len(ids) == 3  # All unique


# ---------------------------------------------------------------------------
# BPM / Project Properties
# ---------------------------------------------------------------------------

class TestProjectServiceProperties:
    """Tests for BPM, time signature, project properties."""

    def test_default_bpm(self, project_service):
        ps = project_service
        ps.new_project()
        assert 60.0 <= ps.ctx.project.bpm <= 300.0

    def test_set_bpm(self, project_service):
        ps = project_service
        ps.new_project()
        ps.ctx.project.bpm = 140.0
        assert ps.ctx.project.bpm == 140.0

    def test_project_has_tracks_list(self, project_service):
        ps = project_service
        ps.new_project()
        assert isinstance(ps.ctx.project.tracks, list)

    def test_project_has_clips_list(self, project_service):
        ps = project_service
        ps.new_project()
        assert isinstance(ps.ctx.project.clips, list)
