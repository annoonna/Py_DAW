"""Tests for pydaw.model.tempo_map — TempoMap beat↔time conversion.

v0.0.20.908 — Tests run without PyQt6.
"""

from __future__ import annotations

import pytest


class TestTempoMap:
    """TempoMap tests."""

    def test_constant_tempo_beat_to_time(self, tempo_map):
        """At 120 BPM, 1 beat = 0.5 seconds."""
        assert tempo_map.beat_to_time(0.0) == pytest.approx(0.0)
        assert tempo_map.beat_to_time(1.0) == pytest.approx(0.5)
        assert tempo_map.beat_to_time(4.0) == pytest.approx(2.0)
        assert tempo_map.beat_to_time(8.0) == pytest.approx(4.0)

    def test_constant_tempo_time_to_beat(self, tempo_map):
        """Inverse: 0.5s = 1 beat at 120 BPM."""
        assert tempo_map.time_to_beat(0.0) == pytest.approx(0.0)
        assert tempo_map.time_to_beat(0.5) == pytest.approx(1.0)
        assert tempo_map.time_to_beat(2.0) == pytest.approx(4.0)

    def test_bpm_at_beat_constant(self, tempo_map):
        assert tempo_map.bpm_at_beat(0.0) == 120.0
        assert tempo_map.bpm_at_beat(100.0) == 120.0

    def test_tempo_change(self, tempo_map):
        """Add tempo events: 120 BPM at beat 0, 60 BPM at beat 4."""
        tempo_map.add_event(0.0, 120.0)
        tempo_map.add_event(4.0, 60.0)
        assert tempo_map.bpm_at_beat(0.0) == 120.0
        assert tempo_map.bpm_at_beat(3.9) == 120.0
        assert tempo_map.bpm_at_beat(4.0) == 60.0
        assert tempo_map.bpm_at_beat(8.0) == 60.0

        # Beat 0-4 at 120 BPM = 2.0 seconds
        assert tempo_map.beat_to_time(4.0) == pytest.approx(2.0)
        # Beat 4-8 at 60 BPM = 4.0 seconds → total 6.0
        assert tempo_map.beat_to_time(8.0) == pytest.approx(6.0)

    def test_multiple_tempo_changes(self):
        from pydaw.model.tempo_map import TempoMap
        tm = TempoMap(global_bpm=120.0)
        tm.add_event(0.0, 120.0)   # Start at 120
        tm.add_event(4.0, 60.0)    # Slow down at beat 4
        tm.add_event(8.0, 240.0)   # Speed up at beat 8

        assert tm.bpm_at_beat(0.0) == 120.0
        assert tm.bpm_at_beat(3.0) == 120.0
        assert tm.bpm_at_beat(5.0) == 60.0
        assert tm.bpm_at_beat(10.0) == 240.0

    def test_remove_event(self, tempo_map):
        tempo_map.add_event(4.0, 60.0)
        assert tempo_map.bpm_at_beat(5.0) == 60.0
        tempo_map.remove_event(4.0)
        assert tempo_map.bpm_at_beat(5.0) == 120.0

    def test_clear_events(self, tempo_map):
        tempo_map.add_event(4.0, 60.0)
        tempo_map.add_event(8.0, 180.0)
        tempo_map.clear_events()
        assert tempo_map.bpm_at_beat(10.0) == 120.0

    def test_roundtrip_beat_time(self, tempo_map):
        """beat_to_time(time_to_beat(t)) ≈ t."""
        for t in [0.0, 0.5, 1.0, 2.5, 10.0]:
            beat = tempo_map.time_to_beat(t)
            reconstructed = tempo_map.beat_to_time(beat)
            assert reconstructed == pytest.approx(t, abs=1e-6)

    def test_tempo_ratio(self, tempo_map):
        """tempo_ratio_at_beat for time-stretching."""
        ratio = tempo_map.tempo_ratio_at_beat(0.0, project_bpm=120.0)
        assert ratio == pytest.approx(1.0)

        ratio = tempo_map.tempo_ratio_at_beat(0.0, project_bpm=60.0)
        assert ratio == pytest.approx(2.0)

    def test_serialization_roundtrip(self, tempo_map):
        tempo_map.add_event(4.0, 90.0)
        tempo_map.add_event(8.0, 150.0)
        d = tempo_map.to_dict()

        from pydaw.model.tempo_map import TempoMap
        restored = TempoMap.from_dict(d)
        assert restored.global_bpm == 120.0
        assert len(restored.events) == 2
        assert restored.bpm_at_beat(5.0) == 90.0
        assert restored.bpm_at_beat(10.0) == 150.0

    def test_global_bpm_setter(self):
        from pydaw.model.tempo_map import TempoMap
        tm = TempoMap(global_bpm=100.0)
        assert tm.global_bpm == 100.0
        tm.global_bpm = 200.0
        assert tm.global_bpm == 200.0

    def test_negative_beat(self, tempo_map):
        """Negative beats should not crash."""
        t = tempo_map.beat_to_time(-1.0)
        # Implementation-dependent, but should not raise
        assert isinstance(t, float)
