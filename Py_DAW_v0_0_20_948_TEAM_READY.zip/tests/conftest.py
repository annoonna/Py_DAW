"""Pytest fixtures for Py_DAW unit tests.

v0.0.20.908 — Test infrastructure.

These tests are designed to run WITHOUT PyQt6 / audio hardware.
They test pure-Python logic: models, services, DB, algorithms.

Usage:
    cd /path/to/pydaw_project
    pip install pytest --break-system-packages
    pytest tests/ -v
"""

from __future__ import annotations

import sys
import os
import tempfile
from pathlib import Path
from dataclasses import asdict

import pytest

# Ensure pydaw package is importable
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@pytest.fixture
def project():
    """Create a fresh empty Project for testing."""
    from pydaw.model.project import Project
    return Project(name="Test Projekt", bpm=120.0)


@pytest.fixture
def project_with_tracks():
    """Create a Project with 3 tracks and 2 clips."""
    from pydaw.model.project import Project, Track, Clip
    from pydaw.model.midi import MidiNote

    p = Project(name="Test Projekt", bpm=140.0)
    t1 = Track(id="trk_audio1", kind="audio", name="Drums")
    t2 = Track(id="trk_inst1", kind="instrument", name="Bass")
    t3 = Track(id="trk_master", kind="master", name="Master")
    p.tracks = [t1, t2, t3]

    c1 = Clip(id="clip_1", kind="audio", track_id="trk_audio1",
              start_beats=0.0, length_beats=8.0, label="Drum Loop")
    c2 = Clip(id="clip_2", kind="midi", track_id="trk_inst1",
              start_beats=0.0, length_beats=4.0, label="Bass Line")
    p.clips = [c1, c2]

    p.midi_notes["clip_2"] = [
        MidiNote(pitch=36, start_beats=0.0, length_beats=1.0, velocity=100),
        MidiNote(pitch=38, start_beats=1.0, length_beats=0.5, velocity=80),
        MidiNote(pitch=40, start_beats=2.0, length_beats=1.5, velocity=90),
    ]
    return p


@pytest.fixture
def tempo_map():
    """Create a TempoMap for testing."""
    from pydaw.model.tempo_map import TempoMap
    return TempoMap(global_bpm=120.0)


@pytest.fixture
def tmp_db_path(tmp_path):
    """Temporary SQLite database path."""
    return tmp_path / "test.db"
