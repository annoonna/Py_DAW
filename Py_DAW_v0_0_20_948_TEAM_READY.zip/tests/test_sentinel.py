"""Unit tests for Sentinel system services.

v0.0.20.913 — Tests for:
- SentinelDB (S1: Database)
- SentinelCrashAnalyzer (S5: Crash Analyzer) — pure-Python parts
- SentinelPatternLearner (S8: Pattern Learning) — match_score, helpers
- SentinelAIAnalyzer (S10: KI) — _anonymize helper

These tests run WITHOUT PyQt6 / audio hardware.
"""

from __future__ import annotations

import json
import os
import sys
import time

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ══════════════════════════════════════════════════════════════
# Fixtures
# ══════════════════════════════════════════════════════════════

@pytest.fixture
def sentinel_db(tmp_path):
    from pydaw.services.sentinel_db import SentinelDB
    db = SentinelDB.__new__(SentinelDB)
    db._db_path = tmp_path / "sentinel_test.db"
    db._loaded = False
    db._event_buffer = []
    db.ensure_loaded()
    return db


def _make_crash_analyzer(sentinel_db):
    from pydaw.services.sentinel_crash_analyzer import SentinelCrashAnalyzer
    a = SentinelCrashAnalyzer.__new__(SentinelCrashAnalyzer)
    a._db = sentinel_db
    a._recorder = None
    a._crash_count = 0
    a._last_crash = None
    a._session_id = "test"
    a._original_excepthook = None
    return a


# ══════════════════════════════════════════════════════════════
# S1: SentinelDB
# ══════════════════════════════════════════════════════════════

class TestSentinelDB:

    def test_tables_created(self, sentinel_db):
        conn = sentinel_db._conn()
        try:
            tables = [r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            ).fetchall()]
        finally:
            conn.close()
        for t in ('sentinel_events', 'sentinel_anomalies', 'sentinel_crashes',
                  'sentinel_patterns', 'sentinel_actions'):
            assert t in tables, f"Table {t} missing"

    def test_wal_mode(self, sentinel_db):
        conn = sentinel_db._conn()
        try:
            mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
            assert mode.lower() == "wal"
        finally:
            conn.close()

    def test_log_event_and_flush(self, sentinel_db):
        sentinel_db.log_event("cpu", severity=2, message="CPU spike 85%",
                               metric_value=85.0)
        sentinel_db.log_event("memory", severity=1, message="Memory OK",
                               metric_value=45.0)
        flushed = sentinel_db.flush_events()
        assert flushed >= 2

    def test_get_recent_events(self, sentinel_db):
        sentinel_db.log_event("audio", severity=3, message="XRun")
        sentinel_db.flush_events()
        events = sentinel_db.get_recent_events(seconds=60.0)
        assert len(events) >= 1
        assert events[0]['category'] == 'audio'

    def test_get_recent_events_category_filter(self, sentinel_db):
        sentinel_db.log_event("cpu", message="cpu")
        sentinel_db.log_event("memory", message="mem")
        sentinel_db.flush_events()
        cpu_events = sentinel_db.get_recent_events(seconds=60.0, category="cpu")
        for e in cpu_events:
            assert e['category'] == 'cpu'

    def test_prune_events(self, sentinel_db):
        sentinel_db.log_event("test", message="old")
        sentinel_db.flush_events()
        conn = sentinel_db._conn()
        try:
            conn.execute("UPDATE sentinel_events SET timestamp=?",
                         (time.time() - 300,))
            conn.commit()
        finally:
            conn.close()
        pruned = sentinel_db.prune_events(keep_seconds=60.0)
        assert pruned >= 1

    def test_log_anomaly(self, sentinel_db):
        aid = sentinel_db.log_anomaly("echo_loop", severity=4,
                                        description="Echo loop on collab",
                                        source="collab_panel")
        assert aid > 0

    def test_resolve_anomaly(self, sentinel_db):
        aid = sentinel_db.log_anomaly("cpu_spike", severity=3,
                                        description="CPU 90%")
        sentinel_db.resolve_anomaly(aid, user_response="Auto-resolved")
        active = sentinel_db.get_active_anomalies()
        active_ids = [a['id'] for a in active]
        assert aid not in active_ids

    def test_mark_false_positive(self, sentinel_db):
        aid = sentinel_db.log_anomaly("memory_leak", severity=2,
                                        description="Mem up")
        sentinel_db.mark_false_positive(aid)
        history = sentinel_db.get_anomaly_history(limit=10)
        found = [a for a in history if a['id'] == aid]
        assert len(found) == 1
        assert found[0]['false_positive'] == 1

    def test_get_active_anomalies(self, sentinel_db):
        sentinel_db.log_anomaly("a", severity=1, description="x")
        sentinel_db.log_anomaly("b", severity=2, description="y")
        active = sentinel_db.get_active_anomalies()
        assert len(active) >= 2

    def test_log_crash(self, sentinel_db):
        cid = sentinel_db.log_crash("segfault", component="vst3_host",
                                      error_message="SIGSEGV in libSurge",
                                      traceback_str="tb here",
                                      session_id="ses_abc")
        assert cid > 0

    def test_get_crashes(self, sentinel_db):
        sentinel_db.log_crash("exception", component="audio_engine",
                                error_message="IndexError")
        crashes = sentinel_db.get_crashes(limit=10)
        assert len(crashes) >= 1
        assert crashes[0]['crash_type'] == 'exception'

    def test_save_and_get_pattern(self, sentinel_db):
        pid = sentinel_db.save_pattern("crash_precursor",
                                         description="CPU > 80%",
                                         conditions={"high_cpu": True},
                                         confidence=0.85)
        assert pid > 0
        patterns = sentinel_db.get_patterns(pattern_type="crash_precursor")
        assert len(patterns) >= 1
        assert patterns[0]['confidence'] == pytest.approx(0.85)

    def test_increment_pattern(self, sentinel_db):
        pid = sentinel_db.save_pattern("test", description="t",
                                         conditions={})
        sentinel_db.increment_pattern(pid)
        sentinel_db.increment_pattern(pid)
        patterns = sentinel_db.get_patterns()
        found = [p for p in patterns if p['id'] == pid]
        assert found[0]['occurrences'] >= 2

    def test_log_action(self, sentinel_db):
        aid = sentinel_db.log_action("reduce_threads", target="audio_engine",
                                       reason="CPU too high")
        assert aid > 0

    def test_undo_action(self, sentinel_db):
        aid = sentinel_db.log_action("mute_track", target="trk_1")
        result = sentinel_db.undo_action(aid)
        assert result is True
        actions = sentinel_db.get_recent_actions(limit=10)
        found = [a for a in actions if a['id'] == aid]
        assert found[0]['undone'] == 1

    def test_stats(self, sentinel_db):
        sentinel_db.log_event("test", message="m")
        sentinel_db.flush_events()
        sentinel_db.log_anomaly("t", severity=1, description="a")
        sentinel_db.log_crash("t", error_message="c")
        stats = sentinel_db.stats()
        assert isinstance(stats, dict)
        assert stats.get('sentinel_events', 0) >= 1
        assert stats.get('sentinel_anomalies', 0) >= 1
        assert stats.get('sentinel_crashes', 0) >= 1


# ══════════════════════════════════════════════════════════════
# S5: CrashAnalyzer
# ══════════════════════════════════════════════════════════════

class TestCrashAnalyzer:

    def test_classify_engine(self):
        a = _make_crash_analyzer(None)
        assert a._classify_component("File audio_engine.py line 42") == "engine"

    def test_classify_plugin(self):
        a = _make_crash_analyzer(None)
        assert a._classify_component("device_panel.py add_plugin") == "plugin"

    def test_classify_collab(self):
        a = _make_crash_analyzer(None)
        assert a._classify_component("collab_panel.py _on_msg") == "collab"

    def test_classify_ui(self):
        a = _make_crash_analyzer(None)
        assert a._classify_component("main_window.py _on_click") == "ui"

    def test_classify_mixer(self):
        a = _make_crash_analyzer(None)
        assert a._classify_component("mixer.py _on_fader") == "mixer"

    def test_classify_editor(self):
        a = _make_crash_analyzer(None)
        assert a._classify_component("arranger_canvas.py paint") == "editor"

    def test_classify_unknown(self):
        a = _make_crash_analyzer(None)
        assert a._classify_component("random_module.py foo") == "unknown"

    def test_crash_count(self):
        a = _make_crash_analyzer(None)
        a._crash_count = 5
        assert a.crash_count == 5

    def test_get_last_crash_with_db(self, sentinel_db):
        sentinel_db.log_crash("segfault", component="vst3",
                                error_message="SIGSEGV")
        a = _make_crash_analyzer(sentinel_db)
        crash = a.get_last_crash()
        assert crash is not None
        assert crash['crash_type'] == 'segfault'

    def test_get_last_crash_no_db(self):
        a = _make_crash_analyzer(None)
        a._db = None
        assert a.get_last_crash() is None

    def test_get_last_crash_empty_db(self, sentinel_db):
        a = _make_crash_analyzer(sentinel_db)
        assert a.get_last_crash() is None


# ══════════════════════════════════════════════════════════════
# S10: AI Analyzer — _anonymize helper
# ══════════════════════════════════════════════════════════════

class TestAIAnalyzerHelpers:

    def test_anonymize_strips_pii_keys(self):
        from pydaw.services.sentinel_ai_analyzer import _anonymize
        data = {
            "crash_type": "segfault",
            "project_path": "/home/anno/music",
            "username": "anno",
            "component": "audio_engine",
            "hostname": "anno-pc",
        }
        result = _anonymize(data)
        assert "crash_type" in result
        assert "component" in result
        assert "project_path" not in result
        assert "username" not in result
        assert "hostname" not in result

    def test_anonymize_keeps_safe_keys(self):
        from pydaw.services.sentinel_ai_analyzer import _anonymize
        data = {"crash_type": "exc", "severity": 3, "traceback": "tb"}
        result = _anonymize(data)
        assert result == data

    def test_anonymize_nested(self):
        from pydaw.services.sentinel_ai_analyzer import _anonymize
        data = {"outer": {"project_path": "/secret", "info": "safe"}}
        result = _anonymize(data)
        assert "info" in result["outer"]
        assert "project_path" not in result["outer"]

    def test_anonymize_truncates_long_strings(self):
        from pydaw.services.sentinel_ai_analyzer import _anonymize
        long_str = "x" * 5000
        result = _anonymize(long_str)
        assert len(result) <= 3010

    def test_anonymize_list(self):
        from pydaw.services.sentinel_ai_analyzer import _anonymize
        data = [{"key": "val", "email": "a@b.c"}] * 5
        result = _anonymize(data)
        assert len(result) == 5
        for item in result:
            assert "key" in item
            assert "email" not in item

    def test_anonymize_depth_limit(self):
        from pydaw.services.sentinel_ai_analyzer import _anonymize
        d = {"val": "leaf"}
        for _ in range(25):
            d = {"nested": d}
        result = _anonymize(d)
        assert isinstance(result, dict)

    def test_anonymize_primitives(self):
        from pydaw.services.sentinel_ai_analyzer import _anonymize
        assert _anonymize(42) == 42
        assert _anonymize(3.14) == 3.14
        assert _anonymize(True) is True
        assert _anonymize(None) is None


# ══════════════════════════════════════════════════════════════
# S8: Pattern Learner
# ══════════════════════════════════════════════════════════════

class TestPatternLearner:

    def _make_learner(self, sentinel_db):
        from pydaw.services.sentinel_patterns import SentinelPatternLearner
        learner = SentinelPatternLearner.__new__(SentinelPatternLearner)
        learner._db = sentinel_db
        learner._recorder = None
        learner._anomaly_detector = None
        learner._patterns_cache = []
        learner._running = False
        return learner

    def test_match_score_full(self, sentinel_db):
        learner = self._make_learner(sentinel_db)
        pattern = {
            "conditions_json": json.dumps({"high_cpu": True, "high_memory": True}),
            "confidence": 1.0,
        }
        current = {"high_cpu": True, "high_memory": True}
        score = learner._match_score(pattern, current)
        assert score == pytest.approx(1.0)

    def test_match_score_partial(self, sentinel_db):
        learner = self._make_learner(sentinel_db)
        pattern = {
            "conditions_json": json.dumps({"high_cpu": True, "high_memory": True}),
            "confidence": 1.0,
        }
        current = {"high_cpu": True, "high_memory": False}
        score = learner._match_score(pattern, current)
        assert score == pytest.approx(0.5)

    def test_match_score_none(self, sentinel_db):
        learner = self._make_learner(sentinel_db)
        pattern = {
            "conditions_json": json.dumps({"high_cpu": True}),
            "confidence": 1.0,
        }
        current = {"high_cpu": False}
        score = learner._match_score(pattern, current)
        assert score == pytest.approx(0.0)

    def test_match_score_empty(self, sentinel_db):
        learner = self._make_learner(sentinel_db)
        pattern = {"conditions_json": json.dumps({}), "confidence": 1.0}
        current = {}
        score = learner._match_score(pattern, current)
        assert score == 0.0

    def test_match_score_with_confidence(self, sentinel_db):
        learner = self._make_learner(sentinel_db)
        pattern = {
            "conditions_json": json.dumps({"high_cpu": True}),
            "confidence": 0.5,
        }
        current = {"high_cpu": True}
        score = learner._match_score(pattern, current)
        assert score == pytest.approx(0.5)

    def test_generate_description(self, sentinel_db):
        learner = self._make_learner(sentinel_db)
        crash = {"crash_type": "segfault", "component": "vst3_host"}
        conditions = {"high_cpu": True, "high_memory": True}
        desc = learner._generate_description(crash, conditions)
        assert isinstance(desc, str) and len(desc) > 0

    def test_generate_prevention(self, sentinel_db):
        learner = self._make_learner(sentinel_db)
        crash = {"crash_type": "exception", "component": "audio_engine"}
        conditions = {"high_memory": True}
        prev = learner._generate_prevention(crash, conditions)
        assert isinstance(prev, str) and len(prev) > 0

    def test_export_patterns(self, sentinel_db, tmp_path):
        learner = self._make_learner(sentinel_db)
        sentinel_db.save_pattern("crash_precursor",
                                  description="CPU spike",
                                  conditions={"high_cpu": True},
                                  confidence=0.9)
        filepath = str(tmp_path / "patterns.json")
        result = learner.export_patterns(filepath=filepath)
        assert os.path.exists(filepath)
        with open(filepath) as f:
            data = json.load(f)
        assert isinstance(data, list) and len(data) >= 1

    def test_import_patterns(self, sentinel_db, tmp_path):
        learner = self._make_learner(sentinel_db)
        sentinel_db.save_pattern("test_type", description="t",
                                  conditions={"high_cpu": True})
        filepath = str(tmp_path / "export.json")
        learner.export_patterns(filepath=filepath)
        with open(filepath) as f:
            json_str = f.read()
        count = learner.import_patterns(json_str=json_str)
        assert count >= 0
