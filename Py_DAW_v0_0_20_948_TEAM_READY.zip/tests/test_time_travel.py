"""Unit tests for Time-Travel Engine services.

v0.0.20.913 — Tests for:
- TimeTravelDB (T1: Journal Database)
- UndoTree (T8/T9: Git-Style Undo)
- SoundDNAService helpers (T10/T11: Audio Fingerprinting)
- Tagger helpers (T6: KI-Auto-Tagging)
- Morph/Recall helpers (T12/T13: Live Recall + Morphing)

These tests run WITHOUT PyQt6 / audio hardware.
"""

from __future__ import annotations

import json
import math
import os
import struct
import sys
import tempfile
import time
import uuid

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ══════════════════════════════════════════════════════════════
# Fixtures
# ══════════════════════════════════════════════════════════════

@pytest.fixture
def tt_db(tmp_path):
    """Fresh TimeTravelDB with temp database."""
    from pydaw.services.time_travel_db import TimeTravelDB
    db = TimeTravelDB.__new__(TimeTravelDB)
    db._db_path = tmp_path / "time_travel_test.db"
    db._loaded = False
    db._event_buffer = []
    db._tag_buffer = []
    db.ensure_loaded()
    return db


@pytest.fixture
def session_id():
    return f"test-session-{uuid.uuid4().hex[:8]}"


@pytest.fixture
def undo_tree_with_db(tt_db, session_id):
    """UndoTree backed by real DB."""
    from pydaw.services.undo_tree import UndoTree

    class FakeJournal:
        def __init__(self, db, sid):
            self._db = db
            self._session_id = sid
            self._start_time = time.time()

        @property
        def session_id(self):
            return self._session_id

        def _timestamp_ms(self):
            return int((time.time() - self._start_time) * 1000)

    tt_db.start_session(session_id)
    journal = FakeJournal(tt_db, session_id)
    tree = UndoTree(journal)
    return tree


# ══════════════════════════════════════════════════════════════
# T1: TimeTravelDB — Journal Database Schema
# ══════════════════════════════════════════════════════════════

class TestTimeTravelDB:

    def test_ensure_loaded_creates_tables(self, tt_db):
        conn = tt_db._conn()
        try:
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            )
            tables = [row[0] for row in cursor.fetchall()]
        finally:
            conn.close()
        for t in ('journal_audio_fp', 'journal_branches', 'journal_events',
                  'journal_snapshots', 'journal_tags'):
            assert t in tables, f"Table {t} missing"

    def test_ensure_loaded_creates_fts(self, tt_db):
        conn = tt_db._conn()
        try:
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='journal_tags_fts'"
            )
            assert cursor.fetchone() is not None
        finally:
            conn.close()

    def test_start_session(self, tt_db, session_id):
        tt_db.start_session(session_id, project_path="/test/project",
                            project_name="Test", bpm=140.0)
        sessions = tt_db.get_sessions(limit=10)
        found = [s for s in sessions if s['id'] == session_id]
        assert len(found) == 1
        assert found[0]['bpm'] == 140.0

    def test_end_session(self, tt_db, session_id):
        tt_db.start_session(session_id)
        tt_db.end_session(session_id)
        sessions = tt_db.get_sessions(limit=10)
        found = [s for s in sessions if s['id'] == session_id]
        assert len(found) == 1
        assert found[0]['ended_at'] > 0

    def test_log_event_and_flush(self, tt_db, session_id):
        tt_db.start_session(session_id)
        tt_db.log_event(session_id, 1000, 'midi_note_on',
                        track_id='trk_1', value_int=60, value_float=0.8)
        tt_db.log_event(session_id, 1500, 'param_change',
                        track_id='trk_1', plugin_id='surge',
                        param_id='cutoff', value_float=0.75)
        flushed = tt_db.flush_events()
        assert flushed >= 2

    def test_get_events_in_range(self, tt_db, session_id):
        tt_db.start_session(session_id)
        for i in range(10):
            tt_db.log_event(session_id, i * 100, 'param_change',
                            track_id='trk_1', value_float=i * 0.1)
        tt_db.flush_events()
        events = tt_db.get_events_in_range(session_id, 200, 700)
        assert len(events) >= 4
        for e in events:
            assert 200 <= e['timestamp_ms'] <= 700

    def test_get_events_by_track(self, tt_db, session_id):
        tt_db.start_session(session_id)
        tt_db.log_event(session_id, 100, 'param_change', track_id='trk_1', value_float=0.5)
        tt_db.log_event(session_id, 200, 'param_change', track_id='trk_2', value_float=0.7)
        tt_db.log_event(session_id, 300, 'param_change', track_id='trk_1', value_float=0.9)
        tt_db.flush_events()
        events = tt_db.get_events_in_range(session_id, 0, 500, track_id='trk_1')
        assert len(events) == 2

    def test_save_and_get_snapshot(self, tt_db, session_id):
        tt_db.start_session(session_id)
        state = {"tracks": [{"id": "trk_1", "vol": 0.8}], "bpm": 120}
        sid = tt_db.save_snapshot(session_id, 5000, json.dumps(state),
                                  track_count=1, bpm=120.0, label="snap")
        assert sid is not None and sid > 0
        snap = tt_db.get_snapshot_before(session_id, 6000)
        assert snap is not None
        assert snap['timestamp_ms'] == 5000

    def test_get_snapshot_before_none(self, tt_db, session_id):
        tt_db.start_session(session_id)
        assert tt_db.get_snapshot_before(session_id, 1000) is None

    def test_snapshots_ordering(self, tt_db, session_id):
        tt_db.start_session(session_id)
        tt_db.save_snapshot(session_id, 1000, '{"t":1}', label="s1")
        tt_db.save_snapshot(session_id, 2000, '{"t":2}', label="s2")
        tt_db.save_snapshot(session_id, 3000, '{"t":3}', label="s3")
        snap = tt_db.get_snapshot_before(session_id, 2500)
        assert snap is not None and snap['timestamp_ms'] == 2000

    def test_add_and_search_tags(self, tt_db, session_id):
        tt_db.start_session(session_id)
        tt_db.add_tag(session_id, 1000, "warmer Pad Sound C-Moll")
        tt_db.add_tag(session_id, 2000, "Bass Filter Sweep aufwaerts")
        tt_db.flush_events()
        results = tt_db.search_tags("Pad")
        assert len(results) >= 1

    def test_search_tags_no_results(self, tt_db, session_id):
        tt_db.start_session(session_id)
        tt_db.add_tag(session_id, 1000, "Bass Synth deep")
        tt_db.flush_events()
        results = tt_db.search_tags("Violine Konzert Orchester")
        assert len(results) == 0

    def test_user_bookmark(self, tt_db, session_id):
        tt_db.start_session(session_id)
        tt_db.add_user_bookmark(session_id, 5000, "Geiler Sound hier")
        tt_db.flush_events()
        results = tt_db.search_tags("Geiler Sound")
        assert len(results) >= 1

    def test_save_audio_fingerprint(self, tt_db, session_id):
        tt_db.start_session(session_id)
        fp = struct.pack('128f', *([0.5] * 128))
        tt_db.save_audio_fingerprint(session_id, 1000, fp, track_id='trk_1')
        conn = tt_db._conn()
        try:
            count = conn.execute("SELECT COUNT(*) FROM journal_audio_fp").fetchone()[0]
            assert count == 1
        finally:
            conn.close()

    def test_create_and_get_branches(self, tt_db, session_id):
        tt_db.start_session(session_id)
        bid = tt_db.create_branch(session_id, "main", 0, description="Haupt")
        assert bid is not None and bid > 0
        bid2 = tt_db.create_branch(session_id, "alt", 5000,
                                    parent_branch_id=bid, description="Alt")
        assert bid2 is not None and bid2 > 0
        branches = tt_db.get_branches(session_id)
        names = [b['branch_name'] for b in branches]
        assert 'main' in names and 'alt' in names

    def test_save_sound_dna(self, tt_db):
        fp = struct.pack('128f', *([0.3] * 128))
        tt_db.save_sound_dna("/projects/song1", "trk_bass", "surge-xt",
                              "Deep Sub", "abc123", fp, "bass deep")
        conn = tt_db._conn()
        try:
            count = conn.execute("SELECT COUNT(*) FROM sound_dna").fetchone()[0]
            assert count == 1
        finally:
            conn.close()

    def test_get_param_state_at(self, tt_db, session_id):
        tt_db.start_session(session_id)
        tt_db.log_event(session_id, 100, 'param_change', track_id='trk_1',
                        plugin_id='synth', param_id='cutoff', value_float=0.3)
        tt_db.log_event(session_id, 200, 'param_change', track_id='trk_1',
                        plugin_id='synth', param_id='cutoff', value_float=0.7)
        tt_db.log_event(session_id, 300, 'param_change', track_id='trk_1',
                        plugin_id='synth', param_id='resonance', value_float=0.5)
        tt_db.flush_events()
        state = tt_db.get_param_state_at(session_id, 250)
        assert 'trk_1' in state
        assert 'cutoff' in state['trk_1']
        assert state['trk_1']['cutoff'] == pytest.approx(0.7)

    def test_stats(self, tt_db, session_id):
        tt_db.start_session(session_id)
        tt_db.log_event(session_id, 100, 'midi_note_on')
        tt_db.flush_events()
        stats = tt_db.stats()
        assert stats['journal_sessions'] >= 1
        assert stats['journal_events'] >= 1

    def test_prune_old_sessions(self, tt_db):
        old_id = "old-session"
        tt_db.start_session(old_id)
        conn = tt_db._conn()
        try:
            old_time = time.time() - (40 * 86400)
            conn.execute("UPDATE journal_sessions SET started_at=?, ended_at=? WHERE id=?",
                         (old_time, old_time + 100, old_id))
            conn.commit()
        finally:
            conn.close()
        pruned = tt_db.prune_old_sessions(max_age_days=30)
        assert pruned >= 1

    def test_multiple_sessions(self, tt_db):
        s1, s2 = "session-1", "session-2"
        tt_db.start_session(s1, project_name="Song A")
        tt_db.start_session(s2, project_name="Song B")
        tt_db.log_event(s1, 100, 'midi_note_on', track_id='trk_a')
        tt_db.log_event(s2, 100, 'midi_note_on', track_id='trk_b')
        tt_db.flush_events()
        e1 = tt_db.get_events_in_range(s1, 0, 500)
        e2 = tt_db.get_events_in_range(s2, 0, 500)
        assert len(e1) == 1 and e1[0]['track_id'] == 'trk_a'
        assert len(e2) == 1 and e2[0]['track_id'] == 'trk_b'

    def test_full_workflow(self, tt_db, session_id):
        tt_db.start_session(session_id, project_name="Song1", bpm=128.0)
        for i in range(20):
            tt_db.log_event(session_id, i * 100, 'midi_note_on',
                            track_id='trk_bass', value_int=36 + (i % 12))
        for i in range(10):
            tt_db.log_event(session_id, i * 200, 'param_change',
                            track_id='trk_bass', plugin_id='surge',
                            param_id='cutoff', value_float=i * 0.1)
        tt_db.flush_events()
        tt_db.save_snapshot(session_id, 1500, '{"bpm":128}', track_count=1, bpm=128.0)
        tt_db.add_tag(session_id, 1500, "Bass Line Filter Sweep")
        tt_db.flush_events()
        results = tt_db.search_tags("Bass Filter")
        assert len(results) >= 1
        tt_db.end_session(session_id)
        stats = tt_db.stats()
        assert stats['journal_events'] >= 30

    def test_search_tags_timerange(self, tt_db, session_id):
        tt_db.start_session(session_id)
        now = time.time()
        tt_db.add_tag(session_id, 1000, "old bass sound")
        tt_db.add_tag(session_id, 2000, "new pad sound")
        tt_db.flush_events()
        results = tt_db.search_tags_in_timerange("sound",
                                                   after_wall_clock=now - 60,
                                                   before_wall_clock=now + 3600)
        assert len(results) >= 2


# ══════════════════════════════════════════════════════════════
# T8/T9: UndoTree
# ══════════════════════════════════════════════════════════════

class TestUndoTree:

    def test_ensure_main_branch(self, undo_tree_with_db):
        tree = undo_tree_with_db
        bid = tree.ensure_main_branch()
        assert bid > 0
        assert tree.active_branch == 'main'

    def test_create_branch(self, undo_tree_with_db):
        tree = undo_tree_with_db
        tree.ensure_main_branch()
        bid = tree.create_branch("experiment", description="Test")
        assert bid > 0

    def test_switch_branch(self, undo_tree_with_db):
        tree = undo_tree_with_db
        tree.ensure_main_branch()
        tree.create_branch("alt")
        assert tree.switch_branch("main") is True
        assert tree.active_branch == 'main'

    def test_switch_nonexistent(self, undo_tree_with_db):
        tree = undo_tree_with_db
        tree.ensure_main_branch()
        assert tree.switch_branch("nope") is False

    def test_delete_branch(self, undo_tree_with_db):
        tree = undo_tree_with_db
        tree.ensure_main_branch()
        tree.create_branch("temp")
        tree.switch_branch("main")
        assert tree.delete_branch("temp") is True

    def test_cannot_delete_active(self, undo_tree_with_db):
        tree = undo_tree_with_db
        tree.ensure_main_branch()
        assert tree.delete_branch("main") is False

    def test_get_branches(self, undo_tree_with_db):
        tree = undo_tree_with_db
        tree.ensure_main_branch()
        tree.create_branch("a1")
        tree.create_branch("a2")
        names = [b['branch_name'] for b in tree.get_branches()]
        assert 'main' in names and 'a1' in names and 'a2' in names

    def test_get_tree_nodes(self, undo_tree_with_db):
        tree = undo_tree_with_db
        tree.ensure_main_branch()
        tree.create_branch("fork")
        nodes = tree.get_tree_nodes()
        assert len(nodes) >= 1
        # Count total including nested children
        def count_all(node_list):
            total = 0
            for n in node_list:
                total += 1 + count_all(n.children)
            return total
        assert count_all(nodes) >= 2

    def test_get_info(self, undo_tree_with_db):
        tree = undo_tree_with_db
        tree.ensure_main_branch()
        tree.create_branch("b1")
        info = tree.get_info()
        assert info.branch_count >= 2

    def test_merge_branch(self, undo_tree_with_db):
        tree = undo_tree_with_db
        tree.ensure_main_branch()
        tree.create_branch("feature")
        assert tree.merge_branch("feature", into="main") is True


# ══════════════════════════════════════════════════════════════
# T10/T11: SoundDNA
# ══════════════════════════════════════════════════════════════

class TestSoundDNA:

    def test_compute_fingerprint(self):
        from pydaw.services.sound_dna_service import _compute_fingerprint_from_buffer
        sr = 44100
        samples = [math.sin(2 * math.pi * 440 * i / sr) for i in range(sr * 2)]
        fp = _compute_fingerprint_from_buffer(samples, sr)
        assert isinstance(fp, bytes) and len(fp) == 128 * 4

    def test_fingerprint_deterministic(self):
        from pydaw.services.sound_dna_service import _compute_fingerprint_from_buffer
        sr = 44100
        samples = [math.sin(2 * math.pi * 440 * i / sr) for i in range(sr * 2)]
        assert _compute_fingerprint_from_buffer(samples, sr) == _compute_fingerprint_from_buffer(samples, sr)

    def test_cosine_similarity_identical(self):
        from pydaw.services.sound_dna_service import _cosine_similarity
        fp = struct.pack('128f', *([0.5] * 128))
        assert _cosine_similarity(fp, fp) == pytest.approx(1.0, abs=0.01)

    def test_cosine_similarity_orthogonal(self):
        from pydaw.services.sound_dna_service import _cosine_similarity
        fp1 = struct.pack('128f', *([1.0] + [0.0] * 127))
        fp2 = struct.pack('128f', *([0.0, 1.0] + [0.0] * 126))
        assert abs(_cosine_similarity(fp1, fp2)) < 0.01

    def test_cosine_similarity_similar(self):
        from pydaw.services.sound_dna_service import _cosine_similarity
        v1 = [0.5 + 0.001 * i for i in range(128)]
        v2 = [0.5 + 0.0012 * i for i in range(128)]
        assert _cosine_similarity(struct.pack('128f', *v1), struct.pack('128f', *v2)) > 0.99

    def test_spectral_features(self):
        from pydaw.services.sound_dna_service import _spectral_features
        sr = 44100
        samples = [math.sin(2 * math.pi * 440 * i / sr) for i in range(sr)]
        f = _spectral_features(samples, sr)
        assert 'centroid' in f and 'rms_db' in f and 'pitch' in f
        assert f['rms_db'] > -60

    def test_param_hash_consistent(self):
        from pydaw.services.sound_dna_service import _param_hash
        p = {"cutoff": 0.7, "resonance": 0.3}
        assert _param_hash(p) == _param_hash(p)

    def test_param_hash_order_independent(self):
        from pydaw.services.sound_dna_service import _param_hash
        assert _param_hash({"a": 1.0, "b": 2.0}) == _param_hash({"b": 2.0, "a": 1.0})

    def test_param_hash_differs(self):
        from pydaw.services.sound_dna_service import _param_hash
        assert _param_hash({"x": 0.1}) != _param_hash({"x": 0.9})

    def test_service_store_fingerprint(self, tt_db, session_id):
        from pydaw.services.sound_dna_service import SoundDNAService
        svc = SoundDNAService.__new__(SoundDNAService)
        svc._db = tt_db
        sr = 44100
        samples = [math.sin(2 * math.pi * 440 * i / sr) for i in range(sr * 2)]
        tt_db.start_session(session_id)
        svc.store_fingerprint(session_id, 1000, samples, track_id='trk_1', sample_rate=sr)
        conn = tt_db._conn()
        try:
            assert conn.execute("SELECT COUNT(*) FROM journal_audio_fp").fetchone()[0] == 1
        finally:
            conn.close()

    def test_service_find_similar(self, tt_db, session_id):
        from pydaw.services.sound_dna_service import SoundDNAService
        svc = SoundDNAService.__new__(SoundDNAService)
        svc._db = tt_db
        sr = 44100
        s440 = [math.sin(2 * math.pi * 440 * i / sr) for i in range(sr * 2)]
        s445 = [math.sin(2 * math.pi * 445 * i / sr) for i in range(sr * 2)]
        s880 = [math.sin(2 * math.pi * 880 * i / sr) for i in range(sr * 2)]
        tt_db.start_session(session_id)
        svc.store_fingerprint(session_id, 1000, s440, track_id='t1')
        svc.store_fingerprint(session_id, 2000, s445, track_id='t1')
        svc.store_fingerprint(session_id, 3000, s880, track_id='t1')
        ref = svc.compute_fingerprint(s440, sr)
        results = svc.find_similar_in_session(session_id, ref, limit=5)
        assert len(results) >= 1
        assert results[0]['similarity'] > 0.8


# ══════════════════════════════════════════════════════════════
# T6: Tagger Helpers
# ══════════════════════════════════════════════════════════════

class TestTaggerHelpers:

    def test_pitch_register_returns_strings(self):
        from pydaw.services.time_travel_tagger import _pitch_register
        for pitch in (20, 40, 60, 80, 100):
            r = _pitch_register(pitch)
            assert isinstance(r, str) and len(r) > 0

    def test_pitch_register_varies(self):
        from pydaw.services.time_travel_tagger import _pitch_register
        assert _pitch_register(30) != _pitch_register(90)

    def test_velocity_returns_strings(self):
        from pydaw.services.time_travel_tagger import _velocity_descriptor
        for v in (10, 64, 127):
            r = _velocity_descriptor(v)
            assert isinstance(r, str) and len(r) > 0

    def test_velocity_varies(self):
        from pydaw.services.time_travel_tagger import _velocity_descriptor
        assert _velocity_descriptor(20) != _velocity_descriptor(127)

    def test_density_returns_strings(self):
        from pydaw.services.time_travel_tagger import _density_descriptor
        for n, d in ((1, 30.0), (10, 5.0), (100, 2.0)):
            r = _density_descriptor(n, d)
            assert isinstance(r, str) and len(r) > 0

    def test_density_varies(self):
        from pydaw.services.time_travel_tagger import _density_descriptor
        assert _density_descriptor(1, 30.0) != _density_descriptor(200, 2.0)

    def test_detect_key(self):
        from pydaw.services.time_travel_tagger import _detect_key_from_pitches
        key = _detect_key_from_pitches([60, 64, 67, 72, 76, 79])
        assert isinstance(key, str) and len(key) > 0

    def test_detect_key_empty(self):
        from pydaw.services.time_travel_tagger import _detect_key_from_pitches
        key = _detect_key_from_pitches([])
        assert isinstance(key, str)

    def test_param_change_descriptor(self):
        from pydaw.services.time_travel_tagger import _param_change_descriptor
        d1 = _param_change_descriptor("cutoff", [0.1, 0.3, 0.6, 0.9])
        assert isinstance(d1, str) and len(d1) > 0
        d2 = _param_change_descriptor("volume", [0.5, 0.5, 0.5])
        assert isinstance(d2, str)


# ══════════════════════════════════════════════════════════════
# T12/T13: Morph/Recall Helpers
# ══════════════════════════════════════════════════════════════

class TestMorphHelpers:

    def test_apply_curve_linear(self):
        from pydaw.services.live_recall import _apply_curve
        assert _apply_curve(0.0, 'linear') == pytest.approx(0.0)
        assert _apply_curve(0.5, 'linear') == pytest.approx(0.5)
        assert _apply_curve(1.0, 'linear') == pytest.approx(1.0)

    def test_apply_curve_exponential(self):
        from pydaw.services.live_recall import _apply_curve
        assert _apply_curve(0.5, 'exponential') == pytest.approx(0.25)

    def test_apply_curve_scurve(self):
        from pydaw.services.live_recall import _apply_curve
        assert _apply_curve(0.5, 'scurve') == pytest.approx(0.5, abs=0.01)

    def test_apply_curve_boundaries(self):
        from pydaw.services.live_recall import _apply_curve
        for c in ('linear', 'exponential', 'scurve'):
            assert _apply_curve(0.0, c) == pytest.approx(0.0, abs=0.01)
            assert _apply_curve(1.0, c) == pytest.approx(1.0, abs=0.01)

    def test_apply_curve_clamped(self):
        from pydaw.services.live_recall import _apply_curve
        assert _apply_curve(-0.5, 'linear') == pytest.approx(0.0)
        assert _apply_curve(1.5, 'linear') == pytest.approx(1.0)

    def test_lerp(self):
        from pydaw.services.live_recall import _lerp
        assert _lerp(0.0, 1.0, 0.0) == pytest.approx(0.0)
        assert _lerp(0.0, 1.0, 0.5) == pytest.approx(0.5)
        assert _lerp(10.0, 20.0, 0.3) == pytest.approx(13.0)

    def test_lerp_negative(self):
        from pydaw.services.live_recall import _lerp
        assert _lerp(-10.0, 10.0, 0.5) == pytest.approx(0.0)

    def test_recall_target(self):
        from pydaw.services.live_recall import RecallTarget
        t = RecallTarget(timestamp_ms=5000)
        assert t.timestamp_ms == 5000

    def test_morph_state(self):
        from pydaw.services.live_recall import MorphState
        m = MorphState(state_a={"t": {"c": 0.3}}, state_b={"t": {"c": 0.9}}, position=0.5)
        assert m.position == 0.5

    def test_morph_state_defaults(self):
        from pydaw.services.live_recall import MorphState
        m = MorphState()
        assert m.position == 0.0 and m.state_a == {} and m.curve == "linear"
