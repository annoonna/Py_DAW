"""Tests for pydaw.model — Track, Clip, Project, MidiNote.

v0.0.20.908 — Tests run without PyQt6.
"""

from __future__ import annotations

from dataclasses import asdict

import pytest


class TestTrack:
    """Track dataclass tests."""

    def test_default_track(self):
        from pydaw.model.project import Track
        t = Track()
        assert t.kind == "audio"
        assert t.volume == 0.8
        assert t.pan == 0.0
        assert t.muted is False
        assert t.solo is False
        assert t.id.startswith("trk_")

    def test_instrument_track(self):
        from pydaw.model.project import Track
        t = Track(kind="instrument", name="Synth", sf2_path="/some/file.sf2")
        assert t.kind == "instrument"
        assert t.sf2_path == "/some/file.sf2"
        assert t.instrument_enabled is True

    def test_track_serialization(self):
        from pydaw.model.project import Track
        t = Track(id="trk_test", name="Test", volume=0.5, pan=-0.3)
        d = asdict(t)
        assert d["id"] == "trk_test"
        assert d["volume"] == 0.5
        assert d["pan"] == -0.3

    def test_track_sends_default_empty(self):
        from pydaw.model.project import Track
        t = Track()
        assert t.sends == []
        # Ensure separate instances don't share mutable defaults
        t2 = Track()
        t.sends.append({"target_track_id": "trk_x", "amount": 0.5})
        assert len(t2.sends) == 0

    def test_track_device_chains_default(self):
        from pydaw.model.project import Track
        t = Track()
        assert t.note_fx_chain == {"devices": []}
        assert t.audio_fx_chain["type"] == "chain"
        assert t.audio_fx_chain["devices"] == []


class TestClip:
    """Clip dataclass tests."""

    def test_default_clip(self):
        from pydaw.model.project import Clip
        c = Clip()
        assert c.kind == "audio"
        assert c.length_beats == 4.0
        assert c.gain == 1.0
        assert c.stretch_mode == "tones"
        assert c.muted is False
        assert c.id.startswith("clip_")

    def test_midi_clip(self):
        from pydaw.model.project import Clip
        c = Clip(kind="midi", track_id="trk_1", start_beats=8.0,
                 length_beats=16.0, label="Melody")
        assert c.kind == "midi"
        assert c.start_beats == 8.0
        assert c.label == "Melody"

    def test_clip_launcher_defaults(self):
        from pydaw.model.project import Clip
        c = Clip()
        assert c.launcher_start_quantize == "Project"
        assert c.launcher_playback_mode == "Trigger ab Start"
        assert c.launcher_release_action == "Stopp"

    def test_clip_take_group(self):
        from pydaw.model.project import Clip
        c = Clip(take_group_id="tkg_001", take_index=2, is_comp_active=False)
        assert c.take_group_id == "tkg_001"
        assert c.take_index == 2
        assert c.is_comp_active is False


class TestProject:
    """Project dataclass tests."""

    def test_default_project(self):
        from pydaw.model.project import Project
        p = Project()
        assert p.bpm == 120.0
        assert p.time_signature == "4/4"
        # Project auto-creates a Master track
        assert len(p.tracks) >= 1
        assert any(t.kind == "master" for t in p.tracks)
        assert p.clips == []

    def test_project_with_data(self, project_with_tracks):
        p = project_with_tracks
        assert p.name == "Test Projekt"
        assert p.bpm == 140.0
        assert len(p.tracks) == 3
        assert len(p.clips) == 2
        assert p.tracks[0].name == "Drums"
        assert p.tracks[1].kind == "instrument"
        assert p.tracks[2].kind == "master"

    def test_project_midi_notes(self, project_with_tracks):
        p = project_with_tracks
        notes = p.midi_notes.get("clip_2", [])
        assert len(notes) == 3
        assert notes[0].pitch == 36
        assert notes[1].velocity == 80

    def test_project_serialization_roundtrip(self, project_with_tracks):
        """Ensure asdict() produces JSON-serializable output."""
        import json
        p = project_with_tracks
        d = asdict(p)
        # Should not raise
        json_str = json.dumps(d)
        assert len(json_str) > 100
        restored = json.loads(json_str)
        assert restored["name"] == "Test Projekt"
        assert restored["bpm"] == 140.0
        assert len(restored["tracks"]) == 3

    def test_project_punch_defaults(self):
        from pydaw.model.project import Project
        p = Project()
        assert p.punch_enabled is False
        assert p.punch_in_beat == 4.0
        assert p.punch_out_beat == 16.0


class TestMidiNote:
    """MidiNote dataclass and helper tests."""

    def test_default_note(self):
        from pydaw.model.midi import MidiNote
        n = MidiNote(pitch=60, start_beats=0.0, length_beats=1.0)
        assert n.pitch == 60
        assert n.velocity == 100
        assert n.accidental == 0
        assert n.tie_to_next is False

    def test_clamp(self):
        from pydaw.model.midi import MidiNote
        n = MidiNote(pitch=200, start_beats=-5.0, length_beats=0.01, velocity=200)
        n.clamp()
        assert n.pitch == 127
        assert n.start_beats == 0.0
        assert n.length_beats == 0.125
        assert n.velocity == 127

    def test_clamp_low(self):
        from pydaw.model.midi import MidiNote
        n = MidiNote(pitch=-10, start_beats=0.0, length_beats=1.0, velocity=-5)
        n.clamp()
        assert n.pitch == 0
        assert n.velocity == 1

    def test_staff_position_c4(self):
        from pydaw.model.midi import MidiNote
        n = MidiNote(pitch=60, start_beats=0.0, length_beats=1.0)
        line, octave = n.to_staff_position()
        assert line == 0  # C
        assert octave == 4

    def test_staff_position_a4(self):
        from pydaw.model.midi import MidiNote
        n = MidiNote(pitch=69, start_beats=0.0, length_beats=1.0)
        line, octave = n.to_staff_position()
        assert line == 5  # A
        assert octave == 4

    def test_staff_position_roundtrip(self):
        from pydaw.model.midi import MidiNote
        for pitch in range(0, 128):
            n = MidiNote(pitch=pitch, start_beats=0.0, length_beats=1.0)
            line, octave = n.to_staff_position()
            reconstructed = MidiNote.from_staff_position(line, octave, n.accidental)
            assert reconstructed == pitch, f"Failed for pitch={pitch}"

    def test_expression_points(self):
        from pydaw.model.midi import MidiNote
        n = MidiNote(pitch=60, start_beats=0.0, length_beats=1.0)
        n.set_expression_points("pressure", [
            {"t": 0.0, "v": 0.0},
            {"t": 0.5, "v": 1.0},
            {"t": 1.0, "v": 0.0},
        ])
        pts = n.get_expression_points("pressure")
        assert len(pts) == 3
        assert pts[1]["v"] == 1.0

    def test_expression_clamp(self):
        from pydaw.model.midi import MidiNote
        n = MidiNote(pitch=60, start_beats=0.0, length_beats=1.0)
        n.set_expression_points("slide", [
            {"t": -0.5, "v": 0.5},  # t should clamp to 0.0
            {"t": 2.0, "v": 0.8},   # t should clamp to 1.0
        ])
        pts = n.get_expression_points("slide")
        assert len(pts) == 2
        assert pts[0]["t"] == 0.0
        assert pts[1]["t"] == 1.0
