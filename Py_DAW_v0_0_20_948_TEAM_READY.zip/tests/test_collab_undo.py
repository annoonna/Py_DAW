"""Tests for CollabUndoLog — undo/redo for collaborative editing.

v0.0.20.908 — Tests run without PyQt6.
"""

from __future__ import annotations

import time

import pytest


def _make_msg(user_id="user_a", user_name="Alice", op_type="track_volume", **extra):
    """Create a minimal CollabMessage-like object for testing."""
    from pydaw.services.collab_service import CollabMessage
    payload = {"op_type": op_type, **extra}
    return CollabMessage(
        type="operation",
        user_id=user_id,
        user_name=user_name,
        payload=payload,
        timestamp=time.time(),
    )


class TestCollabUndoLog:
    """CollabUndoLog push/undo/redo tests."""

    def _make_log(self):
        from pydaw.services.collab_service import CollabUndoLog
        return CollabUndoLog(max_entries=50)

    def test_push_and_undo(self):
        log = self._make_log()
        msg = _make_msg(track_id="trk_1", volume=0.5)
        inverse = {"op_type": "track_volume", "track_id": "trk_1", "volume": 0.8}
        log.push(msg, inverse)

        entry = log.undo()
        assert entry is not None
        assert entry.inverse_payload["volume"] == 0.8
        assert entry.op_type == "track_volume"

    def test_undo_empty(self):
        log = self._make_log()
        assert log.undo() is None

    def test_redo_after_undo(self):
        log = self._make_log()
        msg = _make_msg(track_id="trk_1", volume=0.3)
        inverse = {"op_type": "track_volume", "track_id": "trk_1", "volume": 0.8}
        log.push(msg, inverse)

        entry = log.undo()
        assert entry is not None

        redo_entry = log.redo()
        assert redo_entry is not None
        assert redo_entry.payload["volume"] == 0.3

    def test_redo_empty(self):
        log = self._make_log()
        assert log.redo() is None

    def test_push_clears_redo(self):
        log = self._make_log()
        msg1 = _make_msg(volume=0.5)
        log.push(msg1, {"volume": 0.8})

        log.undo()
        assert log.redo() is not None  # redo available

        # Push back into undo → redo available again
        log.undo()

        # New push should clear redo stack
        msg2 = _make_msg(volume=0.9)
        log.push(msg2, {"volume": 0.5})
        assert log.redo() is None  # redo cleared

    def test_multiple_operations(self):
        log = self._make_log()
        for i in range(5):
            msg = _make_msg(volume=float(i) / 10)
            log.push(msg, {"volume": float(i + 1) / 10})

        history = log.get_history(last_n=10)
        assert len(history) == 5

        # Undo all 5
        for _ in range(5):
            assert log.undo() is not None
        assert log.undo() is None  # exhausted

    def test_undo_per_user(self):
        log = self._make_log()

        msg_a = _make_msg(user_id="alice", volume=0.3)
        log.push(msg_a, {"volume": 0.8})

        msg_b = _make_msg(user_id="bob", volume=0.5)
        log.push(msg_b, {"volume": 0.7})

        msg_a2 = _make_msg(user_id="alice", volume=0.1)
        log.push(msg_a2, {"volume": 0.3})

        # Undo only alice's last operation
        entry = log.undo(user_id="alice")
        assert entry is not None
        assert entry.user_id == "alice"
        assert entry.inverse_payload["volume"] == 0.3

    def test_max_entries(self):
        from pydaw.services.collab_service import CollabUndoLog
        log = CollabUndoLog(max_entries=10)

        for i in range(20):
            msg = _make_msg(volume=float(i))
            log.push(msg, {"volume": 0.0})

        history = log.get_history(last_n=100)
        assert len(history) == 10  # Only last 10

    def test_clear(self):
        log = self._make_log()
        msg = _make_msg(volume=0.5)
        log.push(msg, {"volume": 0.8})
        log.undo()

        log.clear()
        assert log.undo() is None
        assert log.redo() is None
        assert log.get_history() == []

    def test_entry_fields(self):
        log = self._make_log()
        msg = _make_msg(user_id="u1", user_name="Anno", op_type="bpm_change", bpm=140)
        log.push(msg, {"op_type": "bpm_change", "bpm": 120})

        entry = log.undo()
        assert entry.user_id == "u1"
        assert entry.user_name == "Anno"
        assert entry.op_type == "bpm_change"
        assert entry.seq >= 1
        assert entry.timestamp > 0
