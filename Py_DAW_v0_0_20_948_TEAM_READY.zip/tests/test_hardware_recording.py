"""Tests for HardwareControllerService + RecordingService.

v0.0.20.912 — C5.1/C5.3 + C3A.8 Tests.
"""

import os
import sys
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ---------------------------------------------------------------------------
# C5.1/C5.3: HardwareControllerService Tests
# ---------------------------------------------------------------------------

class TestControllerProfiles:
    """Tests for built-in controller profiles."""

    def test_import(self):
        from pydaw.services.hardware_controller import (
            HardwareControllerService, ControllerProfile, BUILTIN_PROFILES,
        )
        assert HardwareControllerService is not None

    def test_builtin_profiles_exist(self):
        from pydaw.services.hardware_controller import BUILTIN_PROFILES
        assert len(BUILTIN_PROFILES) >= 7
        assert "launchpad_mini_mk3" in BUILTIN_PROFILES
        assert "apc40_mk2" in BUILTIN_PROFILES
        assert "generic_8x8" in BUILTIN_PROFILES
        assert "nanokey2" in BUILTIN_PROFILES
        assert "nanokontrol2" in BUILTIN_PROFILES
        assert "touchosc" in BUILTIN_PROFILES

    def test_launchpad_grid_8x8(self):
        from pydaw.services.hardware_controller import BUILTIN_PROFILES
        lp = BUILTIN_PROFILES["launchpad_mini_mk3"]
        assert lp.grid_rows == 8
        assert lp.grid_cols == 8
        assert len(lp.pad_map) == 64  # 8x8
        # All notes unique
        notes = [p.midi_note for p in lp.pad_map]
        assert len(set(notes)) == 64

    def test_apc40_grid_5x8(self):
        from pydaw.services.hardware_controller import BUILTIN_PROFILES
        apc = BUILTIN_PROFILES["apc40_mk2"]
        assert apc.grid_rows == 5
        assert apc.grid_cols == 8
        assert len(apc.pad_map) == 40
        assert apc.play_note >= 0
        assert apc.stop_note >= 0

    def test_launchpad_scene_buttons(self):
        from pydaw.services.hardware_controller import BUILTIN_PROFILES
        lp = BUILTIN_PROFILES["launchpad_mini_mk3"]
        assert len(lp.scene_notes) == 8

    def test_nanokontrol2_transport(self):
        from pydaw.services.hardware_controller import BUILTIN_PROFILES
        nk = BUILTIN_PROFILES["nanokontrol2"]
        assert nk.play_note == 41
        assert nk.stop_note == 42
        assert nk.record_note == 45

    def test_touchosc_is_osc(self):
        from pydaw.services.hardware_controller import BUILTIN_PROFILES
        tosc = BUILTIN_PROFILES["touchosc"]
        assert tosc.is_osc
        assert tosc.osc_port > 0


class TestHardwareControllerService:
    """Tests for HardwareControllerService logic."""

    def _make_svc(self):
        from pydaw.services.hardware_controller import HardwareControllerService
        return HardwareControllerService()

    def test_assign_profile(self):
        svc = self._make_svc()
        ok = svc.assign_profile("launchpad_mini_mk3")
        assert ok
        assert svc.get_profile() is not None
        assert svc.get_profile().name == "launchpad_mini_mk3"

    def test_assign_unknown_profile(self):
        svc = self._make_svc()
        ok = svc.assign_profile("nonexistent_controller")
        assert not ok
        assert svc.get_profile() is None

    def test_list_profiles(self):
        svc = self._make_svc()
        profiles = svc.list_profiles()
        assert len(profiles) >= 7
        names = [p["name"] for p in profiles]
        assert "launchpad_mini_mk3" in names
        assert "apc40_mk2" in names

    def test_auto_detect_launchpad(self):
        svc = self._make_svc()
        result = svc.auto_detect(["Launchpad Mini MK3 MIDI 1"])
        assert result == "launchpad_mini_mk3"
        assert svc.get_profile().name == "launchpad_mini_mk3"

    def test_auto_detect_apc(self):
        svc = self._make_svc()
        result = svc.auto_detect(["APC40 MK2"])
        assert result == "apc40_mk2"

    def test_auto_detect_nanokey(self):
        svc = self._make_svc()
        result = svc.auto_detect(["nanoKEY2 MIDI 1"])
        assert result == "nanokey2"

    def test_auto_detect_no_match(self):
        svc = self._make_svc()
        result = svc.auto_detect(["Unknown MIDI Device", "Generic Keyboard"])
        assert result is None

    def test_auto_detect_empty(self):
        svc = self._make_svc()
        result = svc.auto_detect([])
        assert result is None

    def test_handle_pad_note_on(self):
        svc = self._make_svc()
        svc.assign_profile("generic_8x8")
        # Note 0 = row 0, col 0
        consumed = svc.handle_midi_message({
            "type": "note_on", "note": 0, "velocity": 100, "channel": 0
        })
        assert consumed

    def test_handle_scene_note(self):
        svc = self._make_svc()
        svc.assign_profile("launchpad_mini_mk3")
        # Scene buttons are at notes 89, 79, etc.
        consumed = svc.handle_midi_message({
            "type": "note_on", "note": 89, "velocity": 127, "channel": 0
        })
        assert consumed

    def test_handle_transport_play(self):
        svc = self._make_svc()
        svc.assign_profile("apc40_mk2")
        consumed = svc.handle_midi_message({
            "type": "note_on", "note": 91, "velocity": 127, "channel": 0
        })
        assert consumed  # play_note = 91

    def test_handle_unassigned_note(self):
        svc = self._make_svc()
        svc.assign_profile("generic_8x8")
        # Note 200 is not mapped
        consumed = svc.handle_midi_message({
            "type": "note_on", "note": 200, "velocity": 100, "channel": 0
        })
        assert not consumed

    def test_handle_wrong_channel(self):
        svc = self._make_svc()
        svc.assign_profile("launchpad_mini_mk3")  # channel=0
        consumed = svc.handle_midi_message({
            "type": "note_on", "note": 11, "velocity": 100, "channel": 5
        })
        assert not consumed  # Wrong channel

    def test_no_profile_returns_false(self):
        svc = self._make_svc()
        consumed = svc.handle_midi_message({
            "type": "note_on", "note": 60, "velocity": 100, "channel": 0
        })
        assert not consumed


# ---------------------------------------------------------------------------
# C3A.8: RecordingService Tests (with mocked audio)
# ---------------------------------------------------------------------------

class TestRecordingService:
    """Basic tests for RecordingService without real audio hardware."""

    def test_import(self):
        from pydaw.services.recording_service import RecordingService
        assert RecordingService is not None

    def test_create_service(self):
        from pydaw.services.recording_service import RecordingService
        rs = RecordingService()
        assert rs is not None

    def test_initial_state_not_recording(self):
        from pydaw.services.recording_service import RecordingService
        rs = RecordingService()
        assert rs.is_recording() is False

    def test_get_backend(self):
        from pydaw.services.recording_service import RecordingService
        rs = RecordingService()
        backend = rs.get_backend()
        assert isinstance(backend, str)
        assert len(backend) > 0

    def test_get_buffer_size(self):
        from pydaw.services.recording_service import RecordingService
        rs = RecordingService()
        buf = rs.get_buffer_size()
        assert isinstance(buf, int)
        assert buf > 0

    def test_set_buffer_size(self):
        from pydaw.services.recording_service import RecordingService
        rs = RecordingService()
        rs.set_buffer_size(1024)
        assert rs.get_buffer_size() == 1024

    def test_cleanup_safe(self):
        from pydaw.services.recording_service import RecordingService
        rs = RecordingService()
        rs.cleanup()  # Should not crash

    def test_stop_when_not_recording(self):
        from pydaw.services.recording_service import RecordingService
        rs = RecordingService()
        # Stopping when not recording should be safe
        try:
            rs.stop_recording()
        except Exception:
            pass  # Some implementations may raise
        assert rs.is_recording() is False
