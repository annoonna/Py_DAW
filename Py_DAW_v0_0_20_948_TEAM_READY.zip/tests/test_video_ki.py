"""Unit tests for Video-KI Service (VK1+VK2+VK3).

v0.0.20.919 — Tests for:
- Mathematical random engine (Golden Hash, Perlin, Fibonacci BPM, Gaussian)
- Mood analysis (scene properties → mood profile)
- Sound suggestions (mood → AETERNA params, deterministic + varied)
- Scene/Dialog data models
- Duck automation generation

These tests run WITHOUT ffmpeg / video files.
"""

from __future__ import annotations

import math
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pydaw.services.video_ki_service import (
    VideoScene, DialogRegion, MoodProfile, SoundSuggestion,
    _golden_hash, _perlin_smooth, _fibonacci_bpm, _weighted_choice,
    _gaussian_clamp, _scene_seed, _generate_mood_tags,
    analyze_mood, suggest_sounds, generate_duck_automation,
    _generate_preset_params, VideoKIService,
    PHI, PHI_INV,
)


# ══════════════════════════════════════════════════════════════
# Mathematical Random Engine
# ══════════════════════════════════════════════════════════════

class TestGoldenHash:

    def test_range_0_1(self):
        for i in range(100):
            v = _golden_hash(i * 0.1, 0)
            assert 0.0 <= v <= 1.0

    def test_deterministic(self):
        assert _golden_hash(0.5, 0) == _golden_hash(0.5, 0)
        assert _golden_hash(1.234, 7) == _golden_hash(1.234, 7)

    def test_different_seeds(self):
        vals = {_golden_hash(i * 0.01, 0) for i in range(50)}
        assert len(vals) >= 45  # quasi-random should cover space well

    def test_different_dimensions(self):
        vals = [_golden_hash(0.5, d) for d in range(10)]
        assert len(set(vals)) == 10  # all different

    def test_uniform_distribution(self):
        """Values should be roughly uniformly distributed."""
        vals = [_golden_hash(i * 0.01, 0) for i in range(1000)]
        mean = sum(vals) / len(vals)
        assert 0.4 < mean < 0.6  # should be near 0.5


class TestPerlinSmooth:

    def test_boundaries(self):
        assert _perlin_smooth(0.0) == pytest.approx(0.0)
        assert _perlin_smooth(1.0) == pytest.approx(1.0)

    def test_midpoint(self):
        assert _perlin_smooth(0.5) == pytest.approx(0.5, abs=0.01)

    def test_clamped(self):
        assert _perlin_smooth(-1.0) == pytest.approx(0.0)
        assert _perlin_smooth(2.0) == pytest.approx(1.0)

    def test_monotonic(self):
        prev = 0.0
        for i in range(100):
            t = i / 99.0
            v = _perlin_smooth(t)
            assert v >= prev - 1e-10
            prev = v


class TestFibonacciBPM:

    def test_returns_int(self):
        assert isinstance(_fibonacci_bpm(120, 0.5), int)

    def test_reasonable_range(self):
        for base in [60, 90, 120, 150, 180]:
            for var in [0.0, 0.25, 0.5, 0.75, 1.0]:
                bpm = _fibonacci_bpm(base, var)
                assert 40 <= bpm <= 200

    def test_variation_matters(self):
        low = _fibonacci_bpm(100, 0.0)
        high = _fibonacci_bpm(100, 1.0)
        assert low != high

    def test_fibonacci_alignment(self):
        """BPM should be close to Fibonacci-like values."""
        fib_bpms = {55, 63, 70, 78, 85, 92, 100, 108, 118, 128, 140, 152, 168, 185}
        bpm = _fibonacci_bpm(100, 0.5)
        assert bpm in fib_bpms


class TestWeightedChoice:

    def test_single_option(self):
        result = _weighted_choice([("a", 1.0)], 0.5)
        assert result == "a"

    def test_heavily_weighted(self):
        options = [("rare", 0.01), ("common", 10.0)]
        results = [_weighted_choice(options, _golden_hash(i * 0.01, 0))
                   for i in range(100)]
        assert results.count("common") > results.count("rare")

    def test_deterministic(self):
        options = [("a", 1.0), ("b", 1.0), ("c", 1.0)]
        r1 = _weighted_choice(options, 0.3)
        r2 = _weighted_choice(options, 0.3)
        assert r1 == r2


class TestGaussianClamp:

    def test_range(self):
        for i in range(100):
            v = _gaussian_clamp(0.5, 0.3, i * 0.01, 0.0, 1.0)
            assert 0.0 <= v <= 1.0

    def test_centered(self):
        """Most values should be near center."""
        vals = [_gaussian_clamp(0.5, 0.1, i * 0.01) for i in range(200)]
        near_center = sum(1 for v in vals if 0.3 < v < 0.7)
        assert near_center > len(vals) * 0.5

    def test_custom_range(self):
        v = _gaussian_clamp(100.0, 20.0, 0.5, 50.0, 150.0)
        assert 50.0 <= v <= 150.0


class TestSceneSeed:

    def test_deterministic(self):
        s = VideoScene(start_seconds=1.5, brightness=0.4, warmth=0.6)
        assert _scene_seed(s) == _scene_seed(s)

    def test_different_scenes(self):
        s1 = VideoScene(start_seconds=1.0, brightness=0.3)
        s2 = VideoScene(start_seconds=5.0, brightness=0.8)
        assert _scene_seed(s1) != _scene_seed(s2)

    def test_range(self):
        s = VideoScene(start_seconds=42.0, brightness=0.5)
        seed = _scene_seed(s)
        assert 0.0 <= seed <= 1.0


# ══════════════════════════════════════════════════════════════
# Data Models
# ══════════════════════════════════════════════════════════════

class TestVideoScene:

    def test_duration(self):
        s = VideoScene(start_seconds=5.0, end_seconds=15.0)
        assert s.duration == pytest.approx(10.0)

    def test_to_dict(self):
        s = VideoScene(index=0, start_seconds=0, end_seconds=5,
                       dominant_color=(255, 128, 0), mood_tags=["warm"])
        d = s.to_dict()
        assert d["color"] == "#ff8000"
        assert "warm" in d["mood_tags"]


class TestDialogRegion:

    def test_duration(self):
        d = DialogRegion(start_seconds=2.0, end_seconds=5.0)
        assert d.duration == pytest.approx(3.0)

    def test_to_dict(self):
        d = DialogRegion(start_seconds=1.5, end_seconds=3.0, confidence=0.9)
        dd = d.to_dict()
        assert dd["start"] == 1.5
        assert dd["confidence"] == 0.9


# ══════════════════════════════════════════════════════════════
# VK3: Mood Analysis
# ══════════════════════════════════════════════════════════════

class TestMoodAnalysis:

    def test_dark_scene(self):
        s = VideoScene(brightness=0.1, contrast=0.8, saturation=0.2,
                       warmth=0.2, start_seconds=0, end_seconds=20)
        mood = analyze_mood(s)
        assert mood.darkness > 0.6
        assert mood.mode_suggestion == "minor"

    def test_bright_scene(self):
        s = VideoScene(brightness=0.9, contrast=0.3, saturation=0.7,
                       warmth=0.8, start_seconds=0, end_seconds=10)
        mood = analyze_mood(s)
        assert mood.valence > 0.5
        assert mood.darkness < 0.4
        assert mood.mode_suggestion == "major"

    def test_fast_scene(self):
        s = VideoScene(brightness=0.5, contrast=0.7, saturation=0.5,
                       warmth=0.5, start_seconds=0, end_seconds=1.5)
        mood = analyze_mood(s)
        assert mood.energy > 0.5
        assert mood.tempo_suggestion > 100

    def test_slow_scene(self):
        s = VideoScene(brightness=0.4, contrast=0.2, saturation=0.3,
                       warmth=0.4, start_seconds=0, end_seconds=40)
        mood = analyze_mood(s)
        assert mood.energy < 0.4
        assert mood.tempo_suggestion < 100

    def test_tense_scene(self):
        s = VideoScene(brightness=0.15, contrast=0.85, saturation=0.3,
                       warmth=0.2, start_seconds=0, end_seconds=3)
        mood = analyze_mood(s)
        assert mood.tension > 0.5

    def test_intimate_scene(self):
        s = VideoScene(brightness=0.3, contrast=0.15, saturation=0.1,
                       warmth=0.4, start_seconds=0, end_seconds=30)
        mood = analyze_mood(s)
        assert mood.intimacy > 0.5

    def test_mood_has_key_and_bpm(self):
        s = VideoScene(brightness=0.5, start_seconds=0, end_seconds=10)
        mood = analyze_mood(s)
        assert isinstance(mood.key_suggestion, str)
        assert len(mood.key_suggestion) >= 1
        assert 40 <= mood.tempo_suggestion <= 200

    def test_mood_deterministic(self):
        s = VideoScene(brightness=0.4, contrast=0.6, warmth=0.3,
                       start_seconds=5.0, end_seconds=15.0)
        m1 = analyze_mood(s)
        m2 = analyze_mood(s)
        assert m1.valence == m2.valence
        assert m1.key_suggestion == m2.key_suggestion
        assert m1.tempo_suggestion == m2.tempo_suggestion


class TestMoodTags:

    def test_dark_tags(self):
        s = VideoScene(brightness=0.1, start_seconds=0, end_seconds=20)
        tags = _generate_mood_tags(s)
        assert any("dunkel" in t for t in tags)

    def test_fast_tags(self):
        s = VideoScene(brightness=0.5, start_seconds=0, end_seconds=1.5)
        tags = _generate_mood_tags(s)
        assert any("schnell" in t for t in tags)

    def test_warm_tags(self):
        s = VideoScene(warmth=0.8, start_seconds=0, end_seconds=10)
        tags = _generate_mood_tags(s)
        assert "warm" in tags


# ══════════════════════════════════════════════════════════════
# VK3: Sound Suggestions
# ══════════════════════════════════════════════════════════════

class TestSoundSuggestions:

    def test_returns_suggestions(self):
        scene = VideoScene(brightness=0.3, contrast=0.6, saturation=0.4,
                           warmth=0.3, start_seconds=0, end_seconds=10)
        mood = analyze_mood(scene)
        sugs = suggest_sounds(mood, scene, n_suggestions=3)
        assert len(sugs) == 3

    def test_suggestions_have_params(self):
        scene = VideoScene(brightness=0.5, start_seconds=0, end_seconds=10)
        mood = analyze_mood(scene)
        sugs = suggest_sounds(mood, scene, n_suggestions=2)
        for s in sugs:
            assert s.instrument == "AETERNA"
            assert len(s.preset_params) > 10
            assert 40 <= s.bpm <= 200
            assert len(s.key) >= 1

    def test_suggestions_are_varied(self):
        """Multiple suggestions for same scene should differ."""
        scene = VideoScene(brightness=0.5, start_seconds=0, end_seconds=10)
        mood = analyze_mood(scene)
        sugs = suggest_sounds(mood, scene, n_suggestions=3)
        names = [s.preset_name for s in sugs]
        assert len(set(names)) == 3  # all different

    def test_suggestions_deterministic(self):
        """Same scene → same suggestions (reproducible)."""
        scene = VideoScene(brightness=0.4, warmth=0.6,
                           start_seconds=3.0, end_seconds=12.0)
        mood = analyze_mood(scene)
        s1 = suggest_sounds(mood, scene)
        s2 = suggest_sounds(mood, scene)
        assert s1[0].preset_name == s2[0].preset_name
        assert s1[0].bpm == s2[0].bpm

    def test_different_scenes_different_suggestions(self):
        s1 = VideoScene(brightness=0.1, warmth=0.2, start_seconds=0, end_seconds=20)
        s2 = VideoScene(brightness=0.9, warmth=0.8, start_seconds=0, end_seconds=5)
        m1 = analyze_mood(s1)
        m2 = analyze_mood(s2)
        sugs1 = suggest_sounds(m1, s1)
        sugs2 = suggest_sounds(m2, s2)
        # At least the first suggestion should differ
        assert sugs1[0].preset_name != sugs2[0].preset_name or sugs1[0].bpm != sugs2[0].bpm

    def test_dark_scene_gets_minor(self):
        scene = VideoScene(brightness=0.1, warmth=0.2,
                           start_seconds=0, end_seconds=15)
        mood = analyze_mood(scene)
        sugs = suggest_sounds(mood, scene)
        # At least one should be minor
        assert any(s.mode == "minor" for s in sugs)

    def test_bright_scene_gets_major(self):
        scene = VideoScene(brightness=0.9, warmth=0.8,
                           start_seconds=0, end_seconds=10)
        mood = analyze_mood(scene)
        sugs = suggest_sounds(mood, scene)
        assert any(s.mode == "major" for s in sugs)

    def test_preset_params_valid_ranges(self):
        """Generated params should be within AETERNA valid ranges."""
        scene = VideoScene(brightness=0.5, start_seconds=0, end_seconds=10)
        mood = analyze_mood(scene)
        sugs = suggest_sounds(mood, scene)
        p = sugs[0].preset_params
        assert 0 <= p.get("osc1_waveform", 0) <= 5
        assert 0.0 <= p.get("osc1_level", 0.8) <= 1.0
        assert 20 <= p.get("filter_cutoff", 8000) <= 18000
        assert 0.0 <= p.get("filter_resonance", 0) <= 1.0
        assert 0.0 <= p.get("reverb_mix", 0) <= 1.0
        assert p.get("amp_attack", 0.01) > 0
        assert 0.0 <= p.get("master_volume", 0.75) <= 1.0


# ══════════════════════════════════════════════════════════════
# VK2: Auto-Duck Automation
# ══════════════════════════════════════════════════════════════

class TestDuckAutomation:

    def test_empty(self):
        assert generate_duck_automation([]) == []

    def test_single_region(self):
        dialogs = [DialogRegion(start_seconds=5.0, end_seconds=10.0)]
        bp = generate_duck_automation(dialogs, duck_db=-8.0, bpm=120.0)
        assert len(bp) >= 4  # start, fade-down, duck, fade-up
        # First point should be full volume
        assert bp[0]["value"] == 1.0

    def test_duck_value(self):
        dialogs = [DialogRegion(start_seconds=5.0, end_seconds=10.0)]
        bp = generate_duck_automation(dialogs, duck_db=-12.0, bpm=120.0)
        duck_values = [p["value"] for p in bp if p["value"] < 1.0]
        for v in duck_values:
            assert v < 1.0  # ducked
            assert v > 0.0  # not muted

    def test_multiple_regions(self):
        dialogs = [
            DialogRegion(start_seconds=2.0, end_seconds=5.0),
            DialogRegion(start_seconds=15.0, end_seconds=20.0),
        ]
        bp = generate_duck_automation(dialogs, bpm=120.0)
        assert len(bp) >= 8  # 2 regions × 4 points + start

    def test_beat_conversion(self):
        dialogs = [DialogRegion(start_seconds=1.0, end_seconds=2.0)]
        bp = generate_duck_automation(dialogs, bpm=120.0, fade_seconds=0.0)
        # At 120 BPM, 1 second = 2 beats
        duck_beats = [p["beat"] for p in bp if p["value"] < 1.0]
        assert any(abs(b - 2.0) < 0.1 for b in duck_beats)  # ~2 beats = 1 second


# ══════════════════════════════════════════════════════════════
# VideoKIService High-Level
# ══════════════════════════════════════════════════════════════

class TestVideoKIService:

    def test_init(self):
        vki = VideoKIService()
        assert vki.scenes == []
        assert vki.dialogs == []

    def test_get_scene_at(self):
        vki = VideoKIService()
        vki._scenes = [
            VideoScene(index=0, start_seconds=0, end_seconds=5),
            VideoScene(index=1, start_seconds=5, end_seconds=15),
        ]
        s = vki.get_scene_at(7.0)
        assert s is not None
        assert s.index == 1

    def test_get_scene_at_none(self):
        vki = VideoKIService()
        assert vki.get_scene_at(100.0) is None

    def test_summary_empty(self):
        vki = VideoKIService()
        s = vki.summary()
        assert "0 Szenen" in s


# ══════════════════════════════════════════════════════════════
# VK4: Subtitles
# ══════════════════════════════════════════════════════════════

from pydaw.services.video_ki_service import (
    SubtitleSegment, export_subtitles_srt, export_subtitles_vtt,
    BeatCutSuggestion, suggest_beat_cuts,
    CueSheetEntry, generate_cue_sheet, export_cue_sheet_csv,
)


class TestSubtitleSegment:

    def test_srt_block(self):
        seg = SubtitleSegment(start_seconds=1.5, end_seconds=3.2, text="Hello world")
        srt = seg.to_srt_block(1)
        assert "1\n" in srt
        assert "00:00:01,500 --> 00:00:03,200" in srt
        assert "Hello world" in srt

    def test_vtt_block(self):
        seg = SubtitleSegment(start_seconds=61.0, end_seconds=65.5, text="Test")
        vtt = seg.to_vtt_block()
        assert "00:01:01.000 --> 00:01:05.500" in vtt

    def test_to_dict(self):
        seg = SubtitleSegment(start_seconds=0, end_seconds=2, text="Hi", language="de")
        d = seg.to_dict()
        assert d["text"] == "Hi"
        assert d["language"] == "de"

    def test_srt_hours(self):
        seg = SubtitleSegment(start_seconds=3661.5, end_seconds=3665.0, text="X")
        srt = seg.to_srt_block(1)
        assert "01:01:01,500" in srt


class TestExportSubtitles:

    def test_srt_export(self):
        segs = [
            SubtitleSegment(start_seconds=0, end_seconds=2, text="One"),
            SubtitleSegment(start_seconds=3, end_seconds=5, text="Two"),
        ]
        srt = export_subtitles_srt(segs)
        assert "1\n" in srt
        assert "2\n" in srt
        assert "One" in srt
        assert "Two" in srt

    def test_vtt_export(self):
        segs = [SubtitleSegment(start_seconds=0, end_seconds=1, text="X")]
        vtt = export_subtitles_vtt(segs)
        assert "WEBVTT" in vtt
        assert "X" in vtt


# ══════════════════════════════════════════════════════════════
# VK5: Beat-to-Cut
# ══════════════════════════════════════════════════════════════

class TestBeatCutSuggestion:

    def test_to_dict(self):
        bc = BeatCutSuggestion(scene_index=1, original_cut_seconds=5.3,
                                nearest_beat=10.0, nearest_beat_seconds=5.0,
                                offset_ms=300, direction="später")
        d = bc.to_dict()
        assert d["scene"] == 1
        assert d["direction"] == "später"


class TestSuggestBeatCuts:

    def test_empty(self):
        assert suggest_beat_cuts([], 120) == []

    def test_basic(self):
        scenes = [
            VideoScene(index=0, start_seconds=0, end_seconds=5),
            VideoScene(index=1, start_seconds=5.1, end_seconds=10),
            VideoScene(index=2, start_seconds=10.3, end_seconds=15),
        ]
        cuts = suggest_beat_cuts(scenes, bpm=120.0)
        assert len(cuts) == 2  # scene 0 is skipped (starts at 0)
        for c in cuts:
            assert c.offset_ms >= 0
            assert c.direction in ("früher", "später")

    def test_exact_beat(self):
        """A cut exactly on a beat should have ~0 offset."""
        scenes = [
            VideoScene(index=0, start_seconds=0, end_seconds=2),
            VideoScene(index=1, start_seconds=2.0, end_seconds=5),  # at 120 BPM, beat 4
        ]
        cuts = suggest_beat_cuts(scenes, bpm=120.0)
        assert len(cuts) == 1
        assert cuts[0].offset_ms < 1.0  # essentially zero

    def test_different_bpm(self):
        scenes = [
            VideoScene(index=0, start_seconds=0, end_seconds=3),
            VideoScene(index=1, start_seconds=3.0, end_seconds=8),
        ]
        c60 = suggest_beat_cuts(scenes, bpm=60.0)
        c120 = suggest_beat_cuts(scenes, bpm=120.0)
        # Different BPMs → different nearest beats
        assert c60[0].nearest_beat != c120[0].nearest_beat or c60[0].nearest_beat == c120[0].nearest_beat


# ══════════════════════════════════════════════════════════════
# VK6: ADR/Foley Cue-Sheet
# ══════════════════════════════════════════════════════════════

class TestCueSheetEntry:

    def test_timecode(self):
        e = CueSheetEntry(start_seconds=65, end_seconds=130)
        assert e.timecode == "01:05–02:10"

    def test_to_dict(self):
        e = CueSheetEntry(cue_id="ADR-001", cue_type="ADR",
                           start_seconds=1, end_seconds=3, description="Test")
        d = e.to_dict()
        assert d["id"] == "ADR-001"
        assert d["type"] == "ADR"


class TestGenerateCueSheet:

    def test_empty(self):
        assert generate_cue_sheet([], []) == []

    def test_adr_from_dialogs(self):
        dialogs = [DialogRegion(start_seconds=2, end_seconds=5, avg_energy_db=-20)]
        entries = generate_cue_sheet([], dialogs)
        assert len(entries) >= 1
        assert entries[0].cue_type == "ADR"

    def test_foley_from_scenes(self):
        scenes = [
            VideoScene(index=0, start_seconds=0, end_seconds=5),
            VideoScene(index=1, start_seconds=5, end_seconds=10),
        ]
        entries = generate_cue_sheet(scenes, [])
        foley = [e for e in entries if e.cue_type == "Foley"]
        assert len(foley) >= 1

    def test_ambience_dark_long(self):
        scenes = [
            VideoScene(index=0, start_seconds=0, end_seconds=15, brightness=0.2),
        ]
        entries = generate_cue_sheet(scenes, [])
        ambience = [e for e in entries if e.cue_type == "Ambience"]
        assert len(ambience) >= 1

    def test_no_ambience_with_dialog(self):
        scenes = [
            VideoScene(index=0, start_seconds=0, end_seconds=15, brightness=0.2),
        ]
        dialogs = [DialogRegion(start_seconds=3, end_seconds=10)]
        entries = generate_cue_sheet(scenes, dialogs)
        ambience = [e for e in entries if e.cue_type == "Ambience"]
        assert len(ambience) == 0  # dialog present → no ambience cue


class TestExportCueCSV:

    def test_csv(self):
        entries = [CueSheetEntry(cue_id="ADR-001", cue_type="ADR",
                                  start_seconds=1, end_seconds=3, description="Hallo")]
        csv = export_cue_sheet_csv(entries)
        assert "ADR-001" in csv
        assert "Hallo" in csv
        assert "ID;Typ" in csv  # header


# ══════════════════════════════════════════════════════════════
# VideoKIService Extended API
# ══════════════════════════════════════════════════════════════

class TestVideoKIServiceExtended:

    def test_subtitles_property(self):
        vki = VideoKIService()
        assert vki.subtitles == []

    def test_beat_cuts_property(self):
        vki = VideoKIService()
        assert vki.beat_cuts == []

    def test_cue_sheet_property(self):
        vki = VideoKIService()
        assert vki.cue_sheet == []

    def test_beat_cuts_with_scenes(self):
        vki = VideoKIService()
        vki._scenes = [
            VideoScene(index=0, start_seconds=0, end_seconds=4),
            VideoScene(index=1, start_seconds=4.2, end_seconds=10),
        ]
        cuts = vki.suggest_beat_cuts_for_scenes(bpm=120.0)
        assert len(cuts) == 1

    def test_cue_sheet_with_data(self):
        vki = VideoKIService()
        vki._scenes = [
            VideoScene(index=0, start_seconds=0, end_seconds=5),
            VideoScene(index=1, start_seconds=5, end_seconds=10),
        ]
        vki._dialogs = [DialogRegion(start_seconds=2, end_seconds=4)]
        entries = vki.generate_cue_sheet_for_video()
        assert len(entries) >= 2  # at least ADR + Foley
