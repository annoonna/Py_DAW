"""Tests for pydaw.model.ghost_notes — Ghost Note Layers.

v0.0.20.908 — Tests run without PyQt6.
"""

from __future__ import annotations

import pytest

# ghost_notes.py imports PyQt6 for signals — skip if not available
pytest.importorskip("PyQt6", reason="ghost_notes requires PyQt6")


class TestGhostNoteLayer:
    """GhostNoteLayer dataclass tests."""

    def test_default_layer(self):
        from pydaw.model.ghost_notes import GhostNoteLayer
        layer = GhostNoteLayer(
            clip_id="clip_1",
            track_id="trk_2",
            track_name="Bass",
        )
        assert layer.clip_id == "clip_1"
        assert layer.track_id == "trk_2"
        assert layer.opacity == 0.3
        assert layer.visible is True

    def test_layer_with_custom_opacity(self):
        from pydaw.model.ghost_notes import GhostNoteLayer
        layer = GhostNoteLayer(
            clip_id="c", track_id="t", track_name="X",
            opacity=0.7, color="#ff0000",
        )
        assert layer.opacity == 0.7
        assert layer.color == "#ff0000"


class TestGhostNoteManager:
    """GhostNoteManager tests."""

    def test_add_and_get_layers(self):
        from pydaw.model.ghost_notes import GhostNoteManager
        mgr = GhostNoteManager()
        mgr.add_layer("target_clip", "src_clip", "trk_2", "Bass")
        layers = mgr.get_layers("target_clip")
        assert len(layers) == 1
        assert layers[0].clip_id == "src_clip"

    def test_remove_layer(self):
        from pydaw.model.ghost_notes import GhostNoteManager
        mgr = GhostNoteManager()
        mgr.add_layer("target", "src1", "trk_1", "Track 1")
        mgr.add_layer("target", "src2", "trk_2", "Track 2")
        assert len(mgr.get_layers("target")) == 2

        mgr.remove_layer("target", "src1")
        layers = mgr.get_layers("target")
        assert len(layers) == 1
        assert layers[0].clip_id == "src2"

    def test_clear_layers(self):
        from pydaw.model.ghost_notes import GhostNoteManager
        mgr = GhostNoteManager()
        mgr.add_layer("target", "src1", "trk_1", "T1")
        mgr.add_layer("target", "src2", "trk_2", "T2")
        mgr.clear_layers("target")
        assert mgr.get_layers("target") == []

    def test_no_duplicate_layers(self):
        from pydaw.model.ghost_notes import GhostNoteManager
        mgr = GhostNoteManager()
        mgr.add_layer("target", "src1", "trk_1", "T1")
        mgr.add_layer("target", "src1", "trk_1", "T1")  # duplicate
        # Implementation may or may not deduplicate; at least shouldn't crash
        layers = mgr.get_layers("target")
        assert len(layers) >= 1
