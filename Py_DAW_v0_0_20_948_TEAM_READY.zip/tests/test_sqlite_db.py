"""Tests for SQLite DB classes (SettingsDatabase, PresetDatabase, PluginCacheDB).

v0.0.20.911 — C3A.7: SQLite DB Tests.

Uses temp DB files — no QSettings, no PyQt6 needed.
"""

import os
import sys
import sqlite3
import tempfile
import pytest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ---------------------------------------------------------------------------
# Helper: Create a SettingsDatabase with a temp DB path
# ---------------------------------------------------------------------------

def _make_settings_db(tmp_path):
    """Create a SettingsDatabase pointing at a temp DB file."""
    from pydaw.services.settings_database import SettingsDatabase
    db = SettingsDatabase.__new__(SettingsDatabase)
    db._db_path = Path(tmp_path) / "test_settings.db"
    db._cache = {}
    db._loaded = False
    db._migrated = True  # Skip QSettings migration
    return db


def _make_preset_db(tmp_path):
    """Create a PresetDatabase pointing at a temp DB file."""
    from pydaw.services.preset_database import PresetDatabase
    db = PresetDatabase.__new__(PresetDatabase)
    db._db_path = Path(tmp_path) / "test_presets.db"
    db._cache = []
    db._cache_by_id = {}
    db._loaded = False
    return db


# ---------------------------------------------------------------------------
# C3A.7: SettingsDatabase Tests
# ---------------------------------------------------------------------------

class TestSettingsDatabase:
    """CRUD tests for SettingsDatabase with temp DB."""

    def test_import(self):
        from pydaw.services.settings_database import SettingsDatabase
        assert SettingsDatabase is not None

    def test_init_db_creates_file(self, tmp_path):
        db = _make_settings_db(tmp_path)
        db._init_db()
        assert db._db_path.exists()

    def test_set_and_get(self, tmp_path):
        db = _make_settings_db(tmp_path)
        db._init_db()
        db._loaded = True
        db.set("audio/sample_rate", "48000", category="audio")
        val = db._cache.get("audio/sample_rate", {}).get("value")
        assert val == "48000"

    def test_set_writes_to_sqlite(self, tmp_path):
        db = _make_settings_db(tmp_path)
        db._init_db()
        db._loaded = True
        db.set("test/key1", "hello", category="test")
        # Read directly from SQLite
        conn = sqlite3.connect(str(db._db_path))
        try:
            row = conn.execute(
                "SELECT value FROM settings WHERE key = ?", ("test/key1",)
            ).fetchone()
            assert row is not None
            assert row[0] == "hello"
        finally:
            conn.close()

    def test_delete(self, tmp_path):
        db = _make_settings_db(tmp_path)
        db._init_db()
        db._loaded = True
        db.set("test/del", "delete_me", category="test")
        assert "test/del" in db._cache
        db.delete("test/del")
        assert "test/del" not in db._cache
        # Verify SQLite
        conn = sqlite3.connect(str(db._db_path))
        try:
            row = conn.execute(
                "SELECT value FROM settings WHERE key = ?", ("test/del",)
            ).fetchone()
            assert row is None
        finally:
            conn.close()

    def test_get_by_category(self, tmp_path):
        db = _make_settings_db(tmp_path)
        db._init_db()
        db._loaded = True
        db.set("audio/sr", "48000", category="audio")
        db.set("audio/buffer", "512", category="audio")
        db.set("ui/theme", "dark", category="ui")
        audio = db.get_by_category("audio")
        assert len(audio) == 2
        assert audio["audio/sr"] == "48000"
        assert audio["audio/buffer"] == "512"

    def test_get_all(self, tmp_path):
        db = _make_settings_db(tmp_path)
        db._init_db()
        db._loaded = True
        db.set("a", "1", category="test")
        db.set("b", "2", category="test")
        all_settings = db.get_all()
        assert len(all_settings) >= 2
        assert all_settings["a"] == "1"

    def test_get_nonexistent_returns_default(self, tmp_path):
        db = _make_settings_db(tmp_path)
        db._init_db()
        db._loaded = True
        # Direct cache read (bypass QSettings fallback)
        row = db._cache.get("nonexistent")
        assert row is None

    def test_overwrite_value(self, tmp_path):
        db = _make_settings_db(tmp_path)
        db._init_db()
        db._loaded = True
        db.set("key", "old", category="test")
        db.set("key", "new", category="test")
        assert db._cache["key"]["value"] == "new"
        # Verify in SQLite
        conn = sqlite3.connect(str(db._db_path))
        try:
            row = conn.execute(
                "SELECT value FROM settings WHERE key = ?", ("key",)
            ).fetchone()
            assert row[0] == "new"
        finally:
            conn.close()

    def test_load_to_ram_roundtrip(self, tmp_path):
        db = _make_settings_db(tmp_path)
        db._init_db()
        db._loaded = True
        db.set("persist/test", "hello_world", category="persist")
        # Clear cache and reload
        db._cache.clear()
        db._load_to_ram()
        assert "persist/test" in db._cache
        assert db._cache["persist/test"]["value"] == "hello_world"

    def test_get_categories(self, tmp_path):
        db = _make_settings_db(tmp_path)
        db._init_db()
        db._loaded = True
        db.set("a/1", "v", category="cat_a")
        db.set("b/1", "v", category="cat_b")
        cats = db.get_categories()
        assert "cat_a" in cats
        assert "cat_b" in cats


# ---------------------------------------------------------------------------
# C3A.7: PresetDatabase Tests
# ---------------------------------------------------------------------------

class TestPresetDatabase:
    """CRUD tests for PresetDatabase with temp DB."""

    def test_import(self):
        from pydaw.services.preset_database import PresetDatabase
        assert PresetDatabase is not None

    def test_init_db_creates_file(self, tmp_path):
        db = _make_preset_db(tmp_path)
        db._init_db()
        assert db._db_path.exists()

    def test_add_and_get_preset(self, tmp_path):
        db = _make_preset_db(tmp_path)
        db._init_db()
        db._loaded = True
        pid = db.add_preset(
            name="Test Pad",
            instrument="aeterna",
            plugin_id="aeterna",
            params={"morph": 0.5, "tone": 0.7},
            tags=["warm", "pad"],
            category="pad",
            author="test",
        )
        assert pid is not None
        presets = db.get_by_instrument("aeterna")
        assert len(presets) >= 1
        found = [p for p in presets if p.get("name") == "Test Pad"]
        assert len(found) == 1

    def test_delete_preset(self, tmp_path):
        db = _make_preset_db(tmp_path)
        db._init_db()
        db._loaded = True
        pid = db.add_preset(
            name="To Delete",
            instrument="fusion",
            plugin_id="fusion",
            params={"cutoff": 0.8},
            category="lead",
        )
        assert pid is not None
        ok = db.delete_preset(pid)
        assert ok
        presets = db.get_by_instrument("fusion")
        assert not any(p.get("name") == "To Delete" for p in presets)

    def test_search_presets(self, tmp_path):
        db = _make_preset_db(tmp_path)
        db._init_db()
        db._loaded = True
        db.add_preset(name="Dark Lead", instrument="aeterna", plugin_id="aeterna",
                      params={}, tags=["dark"], category="lead")
        db.add_preset(name="Bright Pad", instrument="aeterna", plugin_id="aeterna",
                      params={}, tags=["bright"], category="pad")
        results = db.search("dark")
        assert any("Dark" in p.get("name", "") for p in results)

    def test_all_presets(self, tmp_path):
        db = _make_preset_db(tmp_path)
        db._init_db()
        db._loaded = True
        db.add_preset(name="P1", instrument="x", plugin_id="x", params={})
        db.add_preset(name="P2", instrument="y", plugin_id="y", params={})
        all_p = db.all_presets()
        assert len(all_p) >= 2


# ---------------------------------------------------------------------------
# C3A.7: PluginCacheDB Tests
# ---------------------------------------------------------------------------

class TestPluginCacheDB:
    """Tests for PluginCacheDB with temp DB."""

    def test_import(self):
        from pydaw.services.plugin_cache_db import PluginCacheDB
        assert PluginCacheDB is not None

    def test_init_and_cache(self, tmp_path):
        from pydaw.services.plugin_cache_db import PluginCacheDB
        db = PluginCacheDB.__new__(PluginCacheDB)
        db._db_path = Path(tmp_path) / "test_plugin_cache.db"
        db._cache = []
        db._by_path = {}
        db._by_format = {}
        db._loaded = False
        db._init_db()
        assert db._db_path.exists()

    def test_upsert_and_get_plugin(self, tmp_path):
        from pydaw.services.plugin_cache_db import PluginCacheDB
        db = PluginCacheDB.__new__(PluginCacheDB)
        db._db_path = Path(tmp_path) / "test_plugin_cache.db"
        db._cache = []
        db._by_path = {}
        db._by_format = {}
        db._loaded = False
        db._init_db()
        ok = db.upsert_plugin(
            path="/usr/lib/vst3/Surge XT.vst3",
            name="Surge XT",
            fmt="vst3",
            is_instrument=True,
            vendor="Surge Synth Team",
        )
        assert ok
        plugins = db.get_all()
        assert len(plugins) >= 1
        found = [p for p in plugins if p.get("name") == "Surge XT"]
        assert len(found) == 1
        assert found[0]["format"] == "vst3"

    def test_get_by_format(self, tmp_path):
        from pydaw.services.plugin_cache_db import PluginCacheDB
        db = PluginCacheDB.__new__(PluginCacheDB)
        db._db_path = Path(tmp_path) / "test_plugin_cache.db"
        db._cache = []
        db._by_path = {}
        db._by_format = {}
        db._loaded = False
        db._init_db()
        db.upsert_plugin(path="/a.vst3", name="A", fmt="vst3", is_instrument=True)
        db.upsert_plugin(path="/b.clap", name="B", fmt="clap", is_instrument=False)
        vst3 = db.get_by_format("vst3")
        assert len(vst3) >= 1
        assert all(p["format"] == "vst3" for p in vst3)

    def test_remove_plugin(self, tmp_path):
        from pydaw.services.plugin_cache_db import PluginCacheDB
        db = PluginCacheDB.__new__(PluginCacheDB)
        db._db_path = Path(tmp_path) / "test_plugin_cache.db"
        db._cache = []
        db._by_path = {}
        db._by_format = {}
        db._loaded = False
        db._init_db()
        db.upsert_plugin(path="/remove.vst3", name="Remove", fmt="vst3")
        db.remove_plugin("/remove.vst3")
        plugins = db.get_all()
        assert not any(p.get("path") == "/remove.vst3" for p in plugins)


# ---------------------------------------------------------------------------
# ConflictDetector (expanded from v910 tests)
# ---------------------------------------------------------------------------

class TestConflictDetectorExpanded:
    """Additional ConflictDetector edge-case tests."""

    def test_conflict_window_expired(self):
        import time
        from pydaw.services.collab_service import ConflictDetector
        d = ConflictDetector(window_ms=1)  # 1ms window
        d.record_edit("user1", "t1", "volume", 0.5)
        time.sleep(0.01)  # Wait 10ms — well past 1ms window
        c = d.record_edit("user2", "t1", "volume", 0.8)
        assert c is None  # Expired — no conflict

    def test_multiple_tracks_independent(self):
        from pydaw.services.collab_service import ConflictDetector
        d = ConflictDetector(window_ms=5000)
        d.record_edit("user1", "t1", "volume", 0.5)
        d.record_edit("user1", "t2", "volume", 0.6)
        c = d.record_edit("user2", "t2", "volume", 0.8)
        assert c is not None
        assert c.track_id == "t2"

    def test_clear_resets(self):
        from pydaw.services.collab_service import ConflictDetector
        d = ConflictDetector(window_ms=5000)
        d.record_edit("user1", "t1", "volume", 0.5)
        d.clear()
        c = d.record_edit("user2", "t1", "volume", 0.8)
        assert c is None  # Cleared — no conflict
