"""Tests for KI/Composition services — ChordProgressionAI, VariationsGenerator, BasslineGenerator.

v0.0.20.909 — C4 KI-Features tests.
"""

from __future__ import annotations

import pytest


class TestChordProgressionAI:
    """ChordProgressionAI tests."""

    def _ai(self):
        from pydaw.services.chord_progression_ai import ChordProgressionAI
        return ChordProgressionAI(seed=42)

    def test_basic_progression(self):
        ai = self._ai()
        chords = ai.suggest_progression(key="C", scale="major", length=4)
        assert len(chords) == 4
        for c in chords:
            assert c.root_name in ["C", "C#", "D", "D#", "E", "F", "F#",
                                    "G", "G#", "A", "A#", "B"]
            assert c.quality in ["maj", "min", "dim", "aug"]
            assert len(c.midi_notes) >= 3
            assert c.roman != ""

    def test_minor_progression(self):
        ai = self._ai()
        chords = ai.suggest_progression(key="A", scale="minor", length=4)
        assert len(chords) == 4

    def test_preset_progression(self):
        ai = self._ai()
        chords = ai.suggest_from_preset("pop_1", key="G", scale="major")
        assert len(chords) == 4
        # First chord should be I (root = G)
        assert chords[0].root_name == "G"
        assert chords[0].quality == "maj"

    def test_blues_preset(self):
        ai = self._ai()
        chords = ai.suggest_from_preset("blues", key="E", scale="major")
        assert len(chords) == 12  # 12-bar blues

    def test_preset_names(self):
        ai = self._ai()
        names = ai.get_preset_names()
        assert "pop_1" in names
        assert "blues" in names
        assert "jazz_251" in names
        assert len(names) >= 6

    def test_chord_to_midi_c_major(self):
        ai = self._ai()
        midi = ai.chord_to_midi("C", "maj", octave=4)
        assert midi == [60, 64, 67]  # C4, E4, G4

    def test_chord_to_midi_a_minor(self):
        ai = self._ai()
        midi = ai.chord_to_midi("A", "min", octave=3)
        assert midi == [57, 60, 64]  # A3, C4, E4

    def test_chord_to_midi_7th(self):
        ai = self._ai()
        midi = ai.chord_to_midi("G", "7", octave=3)
        assert len(midi) == 4  # root, 3rd, 5th, 7th

    def test_analyze_key_c_major(self):
        ai = self._ai()
        # C major scale pitches
        pitches = [60, 62, 64, 65, 67, 69, 71]
        key, scale = ai.analyze_key(pitches)
        assert key == "C"
        assert scale == "major"

    def test_analyze_key_empty(self):
        ai = self._ai()
        key, scale = ai.analyze_key([])
        assert key == "C"  # default

    def test_deterministic_with_seed(self):
        from pydaw.services.chord_progression_ai import ChordProgressionAI
        ai1 = ChordProgressionAI(seed=123)
        ai2 = ChordProgressionAI(seed=123)
        c1 = ai1.suggest_progression(key="D", scale="minor", length=8)
        c2 = ai2.suggest_progression(key="D", scale="minor", length=8)
        assert [c.root_name for c in c1] == [c.root_name for c in c2]

    def test_flat_key(self):
        ai = self._ai()
        midi = ai.chord_to_midi("Bb", "maj", octave=3)
        assert midi[0] == 58  # Bb3

    def test_all_scales(self):
        ai = self._ai()
        from pydaw.services.chord_progression_ai import SCALE_INTERVALS
        for scale_name in SCALE_INTERVALS:
            chords = ai.suggest_progression(key="C", scale=scale_name, length=4)
            assert len(chords) == 4


class TestVariationsGenerator:
    """VariationsGenerator tests."""

    def _gen(self):
        from pydaw.services.variations_generator import VariationsGenerator
        return VariationsGenerator(seed=42)

    def _notes(self):
        from pydaw.model.midi import MidiNote
        return [
            MidiNote(pitch=60, start_beats=0.0, length_beats=1.0, velocity=100),
            MidiNote(pitch=64, start_beats=1.0, length_beats=1.0, velocity=90),
            MidiNote(pitch=67, start_beats=2.0, length_beats=1.0, velocity=80),
        ]

    def test_transpose_up(self):
        gen = self._gen()
        result = gen.transpose(self._notes(), semitones=7)
        assert len(result) == 3
        assert result[0].pitch == 67  # 60+7
        assert result[1].pitch == 71  # 64+7

    def test_transpose_down(self):
        gen = self._gen()
        result = gen.transpose(self._notes(), semitones=-12)
        assert result[0].pitch == 48  # 60-12

    def test_transpose_clamp(self):
        gen = self._gen()
        from pydaw.model.midi import MidiNote
        high = [MidiNote(pitch=125, start_beats=0.0, length_beats=1.0)]
        result = gen.transpose(high, semitones=10)
        assert result[0].pitch == 127  # clamped

    def test_rhythm_shift(self):
        gen = self._gen()
        result = gen.rhythm_shift(self._notes(), shift_beats=0.5)
        assert result[0].start_beats == 0.5
        assert result[1].start_beats == 1.5

    def test_humanize_velocity(self):
        gen = self._gen()
        result = gen.humanize_velocity(self._notes(), range_pct=20)
        # Velocities should change but stay in range
        for n in result:
            assert 1 <= n.velocity <= 127

    def test_invert(self):
        gen = self._gen()
        result = gen.invert(self._notes(), axis_pitch=64)
        # 60 → 2*64-60 = 68
        assert result[0].pitch == 68
        # 64 → 2*64-64 = 64 (unchanged at axis)
        assert result[1].pitch == 64
        # 67 → 2*64-67 = 61
        assert result[2].pitch == 61

    def test_invert_auto_axis(self):
        gen = self._gen()
        result = gen.invert(self._notes())
        # Axis should be (60+67)//2 = 63
        assert result[0].pitch == 66  # 2*63-60

    def test_retrograde(self):
        gen = self._gen()
        result = gen.retrograde(self._notes())
        # Notes should be in reverse order (by start time)
        assert len(result) == 3
        # Last note (pitch=67, start=2.0) should now start first
        assert result[0].pitch == 67

    def test_augmentation(self):
        gen = self._gen()
        result = gen.augmentation(self._notes(), factor=2.0)
        assert result[0].start_beats == 0.0
        assert result[0].length_beats == 2.0
        assert result[1].start_beats == 2.0

    def test_diminution(self):
        gen = self._gen()
        result = gen.augmentation(self._notes(), factor=0.5)
        assert result[0].length_beats == 0.5
        assert result[1].start_beats == 0.5

    def test_generate_all(self):
        gen = self._gen()
        all_vars = gen.generate_all(self._notes())
        assert "transpose" in all_vars
        assert "rhythm" in all_vars
        assert "humanize" in all_vars
        assert "invert" in all_vars
        for key, notes in all_vars.items():
            assert len(notes) == 3

    def test_works_with_dicts(self):
        gen = self._gen()
        notes = [
            {"pitch": 60, "start_beats": 0.0, "length_beats": 1.0, "velocity": 100},
            {"pitch": 64, "start_beats": 1.0, "length_beats": 1.0, "velocity": 90},
        ]
        result = gen.transpose(notes, semitones=5)
        assert result[0]["pitch"] == 65

    def test_empty_notes(self):
        gen = self._gen()
        assert gen.transpose([], 7) == []
        assert gen.invert([]) == []
        assert gen.retrograde([]) == []

    def test_original_unchanged(self):
        gen = self._gen()
        original = self._notes()
        original_pitches = [n.pitch for n in original]
        gen.transpose(original, 12)
        assert [n.pitch for n in original] == original_pitches


class TestBasslineGenerator:
    """BasslineGenerator tests."""

    def _gen(self):
        from pydaw.services.bassline_generator import BasslineGenerator
        return BasslineGenerator(seed=42)

    def _chords(self):
        """Simple I-IV-V-I in C major."""
        from pydaw.services.chord_progression_ai import ChordProgressionAI
        ai = ChordProgressionAI(seed=42)
        return ai.suggest_from_preset("rock", key="C", scale="major")

    def test_root_style(self):
        gen = self._gen()
        notes = gen.generate(self._chords(), style="root", beats_per_chord=4, octave=2)
        assert len(notes) == 4  # one per chord
        # First note should be C2
        assert notes[0]["pitch"] == 36  # (2+1)*12 + 0

    def test_walking_style(self):
        gen = self._gen()
        notes = gen.generate(self._chords(), style="walking", beats_per_chord=4, octave=2)
        assert len(notes) == 16  # 4 notes per chord × 4 chords

    def test_octave_style(self):
        gen = self._gen()
        notes = gen.generate(self._chords(), style="octave", beats_per_chord=4, octave=2)
        assert len(notes) == 8  # 2 per chord

    def test_arpeggio_style(self):
        gen = self._gen()
        notes = gen.generate(self._chords(), style="arpeggio", beats_per_chord=4, octave=2)
        assert len(notes) >= 12  # at least 3 per chord

    def test_syncopated_style(self):
        gen = self._gen()
        notes = gen.generate(self._chords(), style="syncopated", beats_per_chord=4, octave=2)
        assert len(notes) >= 4  # at least some hits

    def test_all_styles(self):
        gen = self._gen()
        for style in gen.get_style_names():
            notes = gen.generate(self._chords(), style=style, octave=2)
            assert len(notes) > 0, f"Style '{style}' produced no notes"

    def test_velocity_range(self):
        gen = self._gen()
        notes = gen.generate(self._chords(), style="walking", velocity=100)
        for n in notes:
            assert 1 <= n["velocity"] <= 127

    def test_pitch_range(self):
        gen = self._gen()
        notes = gen.generate(self._chords(), style="walking", octave=1)
        for n in notes:
            assert 0 <= n["pitch"] <= 127

    def test_notes_are_sorted(self):
        gen = self._gen()
        notes = gen.generate(self._chords(), style="walking")
        for i in range(len(notes) - 1):
            assert notes[i]["start_beats"] <= notes[i + 1]["start_beats"]

    def test_works_with_dicts(self):
        gen = self._gen()
        chords = [
            {"root_name": "C", "quality": "maj"},
            {"root_name": "G", "quality": "maj"},
        ]
        notes = gen.generate(chords, style="root", beats_per_chord=4)
        assert len(notes) == 2
