"""Tests for WarpMarker model and stretch/warp functionality.

v0.0.20.908 — Tests run without PyQt6.
"""

from __future__ import annotations

from dataclasses import asdict

import pytest


class TestWarpMarker:
    """WarpMarker dataclass tests."""

    def test_default_marker(self):
        from pydaw.model.project import WarpMarker
        m = WarpMarker()
        assert m.src_beat == 0.0
        assert m.dst_beat == 0.0
        assert m.is_anchor is False

    def test_marker_with_values(self):
        from pydaw.model.project import WarpMarker
        m = WarpMarker(src_beat=4.0, dst_beat=3.8, is_anchor=True)
        assert m.src_beat == 4.0
        assert m.dst_beat == 3.8
        assert m.is_anchor is True

    def test_marker_serialization(self):
        from pydaw.model.project import WarpMarker
        m = WarpMarker(src_beat=2.5, dst_beat=2.7)
        d = asdict(m)
        assert d["src_beat"] == 2.5
        assert d["dst_beat"] == 2.7


class TestClipStretchModes:
    """Clip stretch mode configuration tests."""

    def test_default_stretch_mode(self):
        from pydaw.model.project import Clip
        c = Clip()
        assert c.stretch_mode == "tones"
        assert c.stretch == 1.0

    @pytest.mark.parametrize("mode", ["tones", "beats", "texture", "repitch", "complex"])
    def test_valid_stretch_modes(self, mode):
        from pydaw.model.project import Clip
        c = Clip(stretch_mode=mode)
        assert c.stretch_mode == mode

    def test_clip_fade_defaults(self):
        from pydaw.model.project import Clip
        c = Clip()
        assert c.fade_in_beats == 0.0
        assert c.fade_out_beats == 0.0
        assert c.fade_in_curve == "linear"
        assert c.fade_out_curve == "linear"

    def test_clip_crossfade(self):
        from pydaw.model.project import Clip
        c = Clip(crossfade_beats=0.25, crossfade_curve="eqpower")
        assert c.crossfade_beats == 0.25
        assert c.crossfade_curve == "eqpower"

    def test_clip_reversed(self):
        from pydaw.model.project import Clip
        c = Clip(reversed=True)
        assert c.reversed is True

    def test_stretch_markers_list(self):
        from pydaw.model.project import Clip
        c = Clip()
        c.stretch_markers = [
            {"src_beat": 0.0, "dst_beat": 0.0},
            {"src_beat": 4.0, "dst_beat": 3.8},
        ]
        assert len(c.stretch_markers) == 2

    def test_audio_slices(self):
        from pydaw.model.project import Clip
        c = Clip()
        c.audio_slices = [0.0, 1.0, 2.0, 3.0]
        assert len(c.audio_slices) == 4
