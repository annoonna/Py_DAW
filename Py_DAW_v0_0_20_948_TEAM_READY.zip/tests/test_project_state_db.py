"""Unit tests for ProjectStateDB — C6 DB Phase 5+ Integration.

v0.0.20.914 — Tests for:
- sync_project round-trip (write → read)
- reconstruct_project_dict (crash recovery)
- try_recover_project (full Project reconstruction)
- has_project check
- Incremental queries (get_tracks, get_clips, get_midi_notes, get_automation)
- Multi-project isolation
- Edge cases (empty project, no tracks, no clips)

These tests run WITHOUT PyQt6 / audio hardware.
"""

from __future__ import annotations

import json
import os
import sys
import time

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ══════════════════════════════════════════════════════════════
# Fixtures
# ══════════════════════════════════════════════════════════════

@pytest.fixture
def pdb(tmp_path):
    """Fresh ProjectStateDB with temp database."""
    from pydaw.services.project_state_db import ProjectStateDB
    db = ProjectStateDB.__new__(ProjectStateDB)
    db._db_path = tmp_path / "project_state_test.db"
    db._loaded = False
    db.ensure_loaded()
    return db


@pytest.fixture
def sample_project():
    """Create a Project with tracks, clips, MIDI notes, and automation."""
    from pydaw.model.project import Project, Track, Clip
    from pydaw.model.midi import MidiNote

    p = Project(name="Test Song", bpm=140.0, sample_rate=44100,
                time_signature="3/4", snap_division="1/8",
                punch_enabled=True, punch_in_beat=4.0, punch_out_beat=32.0,
                launcher_quantize="1 Beat", launcher_mode="Toggle")

    t1 = Track(id="trk_drums", kind="audio", name="Drums",
               volume=0.75, pan=-0.2, muted=False, solo=False,
               record_arm=True, input_pair=2, channel_config="stereo")
    t2 = Track(id="trk_bass", kind="instrument", name="Bass",
               volume=0.9, pan=0.0, plugin_type="sampler",
               instrument_enabled=True,
               audio_fx_chain={"type": "chain", "mix": 1.0, "wet_gain": 1.0,
                               "devices": [{"type": "compressor", "threshold": -12}]})
    t3 = Track(id="trk_master", kind="master", name="Master",
               volume=0.8, pan=0.0)
    p.tracks = [t1, t2, t3]

    c1 = Clip(id="clip_d1", kind="audio", track_id="trk_drums",
              start_beats=0.0, length_beats=8.0, label="Drum Loop",
              source_path="/media/drums.wav", gain=0.9, stretch=1.05,
              stretch_mode="beats")
    c2 = Clip(id="clip_b1", kind="midi", track_id="trk_bass",
              start_beats=0.0, length_beats=16.0, label="Bass Line",
              muted=True, fade_in_beats=0.5)
    c3 = Clip(id="clip_b2", kind="midi", track_id="trk_bass",
              start_beats=16.0, length_beats=8.0, label="Bass Fill")
    p.clips = [c1, c2, c3]

    p.midi_notes["clip_b1"] = [
        MidiNote(pitch=36, start_beats=0.0, length_beats=1.0, velocity=100),
        MidiNote(pitch=38, start_beats=1.0, length_beats=0.5, velocity=80),
        MidiNote(pitch=40, start_beats=2.0, length_beats=1.5, velocity=90),
        MidiNote(pitch=43, start_beats=3.5, length_beats=0.5, velocity=70),
    ]
    p.midi_notes["clip_b2"] = [
        MidiNote(pitch=48, start_beats=0.0, length_beats=2.0, velocity=110),
    ]

    p.automation_manager_lanes = {
        "trk_bass:volume": {
            "track_id": "trk_bass",
            "breakpoints": [
                {"beat": 0.0, "value": 0.5},
                {"beat": 8.0, "value": 0.9},
                {"beat": 16.0, "value": 0.7},
            ]
        },
        "trk_drums:pan": {
            "track_id": "trk_drums",
            "breakpoints": [
                {"beat": 0.0, "value": 0.0},
                {"beat": 4.0, "value": -0.5},
            ]
        }
    }

    p.clip_launcher = {"0:0": "clip_d1", "1:0": "clip_b1"}
    p.launcher_scene_names = {"0": "Intro", "1": "Verse"}

    return p


@pytest.fixture
def empty_project():
    """Minimal project with no content."""
    from pydaw.model.project import Project, Track
    p = Project(name="Empty", bpm=120.0)
    p.tracks = [Track(kind="master", name="Master")]
    return p


PP = "/home/test/projects/song1.pydaw"
PP2 = "/home/test/projects/song2.pydaw"


# ══════════════════════════════════════════════════════════════
# Sync + Read Round-Trip
# ══════════════════════════════════════════════════════════════

class TestSyncRoundTrip:

    def test_sync_project_returns_true(self, pdb, sample_project):
        assert pdb.sync_project(PP, sample_project) is True

    def test_has_project(self, pdb, sample_project):
        assert pdb.has_project(PP) is False
        pdb.sync_project(PP, sample_project)
        assert pdb.has_project(PP) is True

    def test_get_project_meta(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        meta = pdb.get_project_meta(PP)
        assert meta is not None
        assert meta['project_name'] == 'Test Song'
        assert meta['bpm'] == 140.0
        assert meta['sample_rate'] == 44100
        assert meta['time_signature'] == '3/4'
        assert meta['track_count'] == 3
        assert meta['clip_count'] == 3

    def test_get_tracks(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        tracks = pdb.get_tracks(PP)
        assert len(tracks) == 3
        assert tracks[0]['track_id'] == 'trk_drums'
        assert tracks[0]['name'] == 'Drums'
        assert tracks[0]['volume'] == pytest.approx(0.75)
        assert tracks[1]['track_id'] == 'trk_bass'
        assert tracks[1]['plugin_type'] == 'sampler'

    def test_get_clips(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        clips = pdb.get_clips(PP)
        assert len(clips) == 3
        # Should be sorted by start_beats
        assert clips[0]['clip_id'] == 'clip_d1'
        assert clips[0]['source_path'] == '/media/drums.wav'

    def test_get_clips_by_track(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        bass_clips = pdb.get_clips(PP, track_id='trk_bass')
        assert len(bass_clips) == 2
        drum_clips = pdb.get_clips(PP, track_id='trk_drums')
        assert len(drum_clips) == 1

    def test_get_midi_notes(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        notes = pdb.get_midi_notes(PP)
        assert len(notes) == 5  # 4 in clip_b1 + 1 in clip_b2

    def test_get_midi_notes_by_clip(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        notes = pdb.get_midi_notes(PP, clip_id='clip_b1')
        assert len(notes) == 4
        assert notes[0]['pitch'] == 36

    def test_get_automation(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        lanes = pdb.get_automation(PP)
        assert len(lanes) == 2

    def test_get_automation_by_param(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        lanes = pdb.get_automation(PP, parameter_id='trk_bass:volume')
        assert len(lanes) == 1
        data = json.loads(lanes[0]['lane_json'])
        assert len(data['breakpoints']) == 3

    def test_stats(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        stats = pdb.stats()
        assert stats['project_meta'] >= 1
        assert stats['project_tracks'] >= 3
        assert stats['project_clips'] >= 3
        assert stats['project_midi_notes'] >= 5

    def test_list_synced_projects(self, pdb, sample_project, empty_project):
        pdb.sync_project(PP, sample_project)
        pdb.sync_project(PP2, empty_project)
        projects = pdb.list_synced_projects()
        assert len(projects) >= 2
        paths = [p['project_path'] for p in projects]
        assert PP in paths and PP2 in paths


# ══════════════════════════════════════════════════════════════
# C6.1: Crash Recovery — Reconstruct from DB
# ══════════════════════════════════════════════════════════════

class TestCrashRecovery:

    def test_reconstruct_project_dict_basic(self, pdb, sample_project):
        """reconstruct should return a dict suitable for Project.from_dict()."""
        pdb.sync_project(PP, sample_project)
        d = pdb.reconstruct_project_dict(PP)
        assert d is not None
        assert d['name'] == 'Test Song'
        assert d['bpm'] == 140.0
        assert d['time_signature'] == '3/4'

    def test_reconstruct_tracks(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        d = pdb.reconstruct_project_dict(PP)
        assert len(d['tracks']) == 3
        trk = d['tracks'][0]
        assert trk['id'] == 'trk_drums'
        assert trk['name'] == 'Drums'
        assert trk['volume'] == pytest.approx(0.75)
        assert trk['pan'] == pytest.approx(-0.2)

    def test_reconstruct_clips(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        d = pdb.reconstruct_project_dict(PP)
        assert len(d['clips']) == 3
        clip = [c for c in d['clips'] if c['id'] == 'clip_d1'][0]
        assert clip['source_path'] == '/media/drums.wav'
        assert clip['gain'] == pytest.approx(0.9)
        assert clip['stretch'] == pytest.approx(1.05)
        assert clip['stretch_mode'] == 'beats'

    def test_reconstruct_midi_notes(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        d = pdb.reconstruct_project_dict(PP)
        assert 'clip_b1' in d['midi_notes']
        assert len(d['midi_notes']['clip_b1']) == 4
        assert d['midi_notes']['clip_b1'][0]['pitch'] == 36

    def test_reconstruct_automation(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        d = pdb.reconstruct_project_dict(PP)
        assert 'automation_manager_lanes' in d
        assert 'trk_bass:volume' in d['automation_manager_lanes']

    def test_reconstruct_extra_fields(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        d = pdb.reconstruct_project_dict(PP)
        assert d.get('clip_launcher') == {"0:0": "clip_d1", "1:0": "clip_b1"}
        assert d.get('launcher_scene_names') == {"0": "Intro", "1": "Verse"}

    def test_reconstruct_nonexistent_returns_none(self, pdb):
        d = pdb.reconstruct_project_dict("/nonexistent/path")
        assert d is None

    def test_try_recover_project(self, pdb, sample_project):
        """try_recover_project should return a valid Project object."""
        pdb.sync_project(PP, sample_project)
        recovered = pdb.try_recover_project(PP)
        assert recovered is not None
        assert recovered.name == 'Test Song'
        assert recovered.bpm == 140.0
        assert len(recovered.tracks) == 3
        assert len(recovered.clips) == 3
        assert len(recovered.midi_notes.get('clip_b1', [])) == 4

    def test_try_recover_nonexistent(self, pdb):
        assert pdb.try_recover_project("/nonexistent") is None

    def test_recover_preserves_track_order(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        recovered = pdb.try_recover_project(PP)
        assert recovered.tracks[0].id == 'trk_drums'
        assert recovered.tracks[1].id == 'trk_bass'
        assert recovered.tracks[2].id == 'trk_master'

    def test_recover_preserves_track_fx_chain(self, pdb, sample_project):
        """Extra JSON fields (audio_fx_chain) should survive round-trip."""
        pdb.sync_project(PP, sample_project)
        recovered = pdb.try_recover_project(PP)
        bass = [t for t in recovered.tracks if t.id == 'trk_bass'][0]
        fx = bass.audio_fx_chain
        assert fx.get('type') == 'chain'
        assert len(fx.get('devices', [])) >= 1

    def test_recover_preserves_clip_properties(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        recovered = pdb.try_recover_project(PP)
        c2 = [c for c in recovered.clips if c.id == 'clip_b1'][0]
        assert c2.muted is True
        assert c2.fade_in_beats == pytest.approx(0.5)
        assert c2.label == 'Bass Line'

    def test_recover_preserves_midi_velocity(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        recovered = pdb.try_recover_project(PP)
        notes = recovered.midi_notes.get('clip_b1', [])
        assert notes[0].velocity == 100
        assert notes[1].velocity == 80

    def test_full_round_trip(self, pdb, sample_project):
        """Sync → reconstruct → from_dict → to_dict should preserve data."""
        from pydaw.model.project import Project

        pdb.sync_project(PP, sample_project)
        d = pdb.reconstruct_project_dict(PP)
        recovered = Project.from_dict(d)

        # Compare key properties
        assert recovered.name == sample_project.name
        assert recovered.bpm == sample_project.bpm
        assert recovered.time_signature == sample_project.time_signature
        assert len(recovered.tracks) == len(sample_project.tracks)
        assert len(recovered.clips) == len(sample_project.clips)

        for orig_t, rec_t in zip(sample_project.tracks, recovered.tracks):
            assert orig_t.id == rec_t.id
            assert orig_t.name == rec_t.name
            assert orig_t.volume == pytest.approx(rec_t.volume)
            assert orig_t.pan == pytest.approx(rec_t.pan)

        for orig_c, rec_c in zip(sample_project.clips, recovered.clips):
            assert orig_c.id == rec_c.id
            assert orig_c.start_beats == pytest.approx(rec_c.start_beats)
            assert orig_c.length_beats == pytest.approx(rec_c.length_beats)


# ══════════════════════════════════════════════════════════════
# Multi-Project Isolation
# ══════════════════════════════════════════════════════════════

class TestMultiProject:

    def test_projects_isolated(self, pdb, sample_project, empty_project):
        pdb.sync_project(PP, sample_project)
        pdb.sync_project(PP2, empty_project)
        assert len(pdb.get_tracks(PP)) == 3
        assert len(pdb.get_tracks(PP2)) == 1
        assert len(pdb.get_clips(PP)) == 3
        assert len(pdb.get_clips(PP2)) == 0

    def test_remove_project(self, pdb, sample_project, empty_project):
        pdb.sync_project(PP, sample_project)
        pdb.sync_project(PP2, empty_project)
        pdb.remove_project(PP)
        assert pdb.has_project(PP) is False
        assert pdb.has_project(PP2) is True

    def test_resync_updates(self, pdb, sample_project):
        """Re-syncing should update existing data, not duplicate."""
        pdb.sync_project(PP, sample_project)
        assert len(pdb.get_tracks(PP)) == 3

        # Modify and re-sync
        sample_project.name = "Updated Song"
        sample_project.bpm = 160.0
        from pydaw.model.project import Track
        sample_project.tracks.append(
            Track(id="trk_new", kind="audio", name="New Track"))
        pdb.sync_project(PP, sample_project)

        meta = pdb.get_project_meta(PP)
        assert meta['project_name'] == 'Updated Song'
        assert meta['bpm'] == 160.0
        assert len(pdb.get_tracks(PP)) == 4

    def test_search_clips_by_source(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        results = pdb.search_clips_by_source("/media/drums.wav")
        assert len(results) >= 1
        assert results[0]['clip_id'] == 'clip_d1'


# ══════════════════════════════════════════════════════════════
# Edge Cases
# ══════════════════════════════════════════════════════════════

class TestEdgeCases:

    def test_empty_project_sync(self, pdb, empty_project):
        assert pdb.sync_project(PP, empty_project) is True
        d = pdb.reconstruct_project_dict(PP)
        assert d is not None
        assert len(d['tracks']) == 1
        assert len(d['clips']) == 0

    def test_project_no_midi(self, pdb):
        from pydaw.model.project import Project, Track, Clip
        p = Project(name="Audio Only", bpm=120.0)
        p.tracks = [Track(id="trk_a", kind="audio", name="Audio")]
        p.clips = [Clip(id="clip_a", kind="audio", track_id="trk_a",
                        start_beats=0.0, length_beats=4.0)]
        pdb.sync_project(PP, p)
        d = pdb.reconstruct_project_dict(PP)
        assert d is not None
        assert d['midi_notes'] == {}

    def test_project_no_automation(self, pdb, empty_project):
        pdb.sync_project(PP, empty_project)
        d = pdb.reconstruct_project_dict(PP)
        assert 'automation_manager_lanes' not in d or d.get('automation_manager_lanes') == {}

    def test_sync_null_project_fails(self, pdb):
        assert pdb.sync_project(PP, None) is False

    def test_sync_empty_path_fails(self, pdb, sample_project):
        assert pdb.sync_project("", sample_project) is False

    def test_get_track_count(self, pdb, sample_project):
        pdb.sync_project(PP, sample_project)
        assert pdb.get_track_count(PP) == 3
