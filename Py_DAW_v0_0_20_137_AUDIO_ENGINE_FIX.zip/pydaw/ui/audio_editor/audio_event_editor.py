"""AudioEventEditor (Phase 2.1)

Pro-DAW-Style Clip-Editor (Audio) – modular & low-risk.

Phase 2.0 delivered:
- AudioEvents (non-destructive segments) derived from slices
- Knife = split event, Eraser = merge near boundary
- Loop region overlay (per clip)
- Context menu stubs

Phase 2.1 adds:
- Arrow tool: select + GROUP MOVE selected AudioEvents (Pro-DAW-like)
- Consolidate (only for contiguous, source-aligned chains)
- Quantize (selected events)
- Fixes: missing handlers + indentation error in v0.0.19.7.50

Design rules:
- Single Source of Truth: ProjectService updates Clip dataclass
- Editor renders from model and writes changes back via ProjectService
- Loose coupling: context menu emits action text, editor/controller decides
"""

from __future__ import annotations

import math
import os
from dataclasses import dataclass
from typing import Dict, List, Optional, Set

try:
    import numpy as np  # type: ignore
except Exception:  # pragma: no cover
    np = None  # type: ignore

try:
    import soundfile as sf  # type: ignore
except Exception:  # pragma: no cover
    sf = None  # type: ignore

from PyQt6.QtCore import Qt, pyqtSignal, QPointF, QRectF
from PyQt6.QtGui import QBrush, QColor, QPainter, QPainterPath, QPen, QPolygonF
from PyQt6.QtWidgets import (
    QComboBox,
    QDoubleSpinBox,
    QGraphicsLineItem,
    QGraphicsPathItem,
    QGraphicsPolygonItem,
    QGraphicsRectItem,
    QGraphicsScene,
    QGraphicsSimpleTextItem,
    QGraphicsView,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMenu,
    QToolBar,
    QToolButton,
    QVBoxLayout,
    QWidget,
)


@dataclass
class PeaksData:
    samplerate: int
    peaks: "np.ndarray"  # shape (N, 2): min/max per block
    block_size: int


class _FadeHandle(QGraphicsPolygonItem):
    """Draggable triangle handle for fade in/out (Bitwig-style).

    Renders as a small triangle that can be dragged horizontally to change fade length.
    """

    def __init__(self, x: float, height: float, *, role: str = "fade_in", on_moved=None):
        tri = QPolygonF()
        sz = 10.0  # triangle size
        if role == "fade_in":
            tri.append(QPointF(0.0, 0.0))
            tri.append(QPointF(sz, 0.0))
            tri.append(QPointF(0.0, sz))
        else:
            tri.append(QPointF(0.0, 0.0))
            tri.append(QPointF(-sz, 0.0))
            tri.append(QPointF(0.0, sz))
        super().__init__(tri)
        self.setPos(QPointF(float(x), 0.0))
        self.setZValue(35)
        self.setFlags(
            QGraphicsPolygonItem.GraphicsItemFlag.ItemIsMovable
            | QGraphicsPolygonItem.GraphicsItemFlag.ItemSendsGeometryChanges
        )
        self.setAcceptHoverEvents(True)
        self._role = str(role)
        self._on_moved = on_moved
        color = QColor(255, 165, 0) if role == "fade_in" else QColor(100, 149, 237)
        self.setBrush(QBrush(color))
        pen = QPen(color.darker(130))
        pen.setWidth(1)
        self.setPen(pen)

    def hoverEnterEvent(self, event):
        self.setCursor(Qt.CursorShape.SizeHorCursor)
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event):
        self.setCursor(Qt.CursorShape.ArrowCursor)
        super().hoverLeaveEvent(event)

    def itemChange(self, change, value):
        if change == QGraphicsPolygonItem.GraphicsItemChange.ItemPositionChange:
            p: QPointF = value
            return QPointF(p.x(), 0.0)  # constrain to horizontal
        if change == QGraphicsPolygonItem.GraphicsItemChange.ItemPositionHasChanged:
            try:
                if self._on_moved:
                    self._on_moved(float(self.pos().x()))
            except Exception:
                pass
        return super().itemChange(change, value)


class _LoopEdge(QGraphicsLineItem):
    """Draggable vertical line used as loop start/end edge.

    Note: QGraphicsItem is NOT a QObject, so we use a simple callback instead of Qt signals.
    """

    def __init__(self, x: float, height: float, *, color_role: str = "start"):
        # IMPORTANT:
        # Keep the line geometry anchored at x=0 and move it via setPos().
        # If we bake x into the line *and* move via setPos(), coordinates get doubled
        # (line at x + pos.x), which quickly leads to invalid values / re-entrant loops.
        super().__init__(0.0, 0.0, 0.0, height)
        try:
            self.setPos(QPointF(float(x), 0.0))
        except Exception:
            pass
        self.setZValue(30)
        self.setFlags(
            QGraphicsLineItem.GraphicsItemFlag.ItemIsMovable
            | QGraphicsLineItem.GraphicsItemFlag.ItemSendsGeometryChanges
        )
        self.setAcceptHoverEvents(True)
        self._height = float(height)
        self._role = str(color_role)
        self._on_moved = None  # type: ignore[assignment]

        pen = QPen()
        pen.setWidth(2)
        if self._role == "start":
            pen.setColor(Qt.GlobalColor.cyan)
        else:
            pen.setColor(Qt.GlobalColor.green)
        self.setPen(pen)

    def set_on_moved(self, cb) -> None:  # noqa: ANN001
        self._on_moved = cb

    def hoverEnterEvent(self, event):  # noqa: ANN001
        self.setCursor(Qt.CursorShape.SizeHorCursor)
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event):  # noqa: ANN001
        self.setCursor(Qt.CursorShape.ArrowCursor)
        super().hoverLeaveEvent(event)

    def itemChange(self, change, value):  # noqa: ANN001
        if change == QGraphicsLineItem.GraphicsItemChange.ItemPositionChange:
            p: QPointF = value
            # clamp Y, keep line anchored to top
            return QPointF(p.x(), 0.0)
        if change == QGraphicsLineItem.GraphicsItemChange.ItemPositionHasChanged:
            try:
                if self._on_moved:
                    self._on_moved(float(self.pos().x()))
            except Exception:
                pass
        return super().itemChange(change, value)


class BeatGridScene(QGraphicsScene):
    """Draws beat/bar grid as background via drawBackground."""

    def __init__(self, *, beats_per_bar: float = 4.0, px_per_beat: float = 80.0):
        super().__init__()
        self.beats_per_bar = float(beats_per_bar)
        self.px_per_beat = float(px_per_beat)

    def drawBackground(self, painter, rect):  # noqa: ANN001
        super().drawBackground(painter, rect)

        left = rect.left()
        right = rect.right()

        if self.px_per_beat <= 1e-6:
            return

        pen_beat = QPen(Qt.GlobalColor.darkGray)
        pen_beat.setWidth(1)
        pen_bar = QPen(Qt.GlobalColor.gray)
        pen_bar.setWidth(2)

        beat_start = max(0, int(math.floor(left / self.px_per_beat)) - 1)
        beat_end = int(math.ceil(right / self.px_per_beat)) + 1

        bpb = max(1, int(round(self.beats_per_bar)))
        for b in range(beat_start, beat_end + 1):
            x = b * self.px_per_beat
            is_bar = (b % bpb) == 0
            painter.setPen(pen_bar if is_bar else pen_beat)
            painter.drawLine(QPointF(x, rect.top()), QPointF(x, rect.bottom()))


class AudioEditorView(QGraphicsView):
    """Main interactive view: zoom + tool routing + context menu."""

    request_slice = pyqtSignal(float)  # at_beats
    request_remove_slice = pyqtSignal(float)  # at_beats
    request_set_loop = pyqtSignal(float, float)  # start_beats, end_beats
    # Knife Cut+Drag: split then drag right-part(s) immediately
    request_slice_drag = pyqtSignal(float, float)  # at_beats, press_scene_x
    knife_drag_update = pyqtSignal(float, int)  # scene_x, modifiers(int)
    knife_drag_end = pyqtSignal()
    context_action_selected = pyqtSignal(str)
    # Pencil tool: add/move/delete automation points
    pencil_add_point = pyqtSignal(float, float)  # at_beats, normalized_value (0..1)
    pencil_remove_point = pyqtSignal(float)  # at_beats
    pencil_drag_point = pyqtSignal(float, float)  # at_beats, normalized_value

    def __init__(self, scene: BeatGridScene, *, px_per_beat: float = 80.0, parent=None):
        super().__init__(scene, parent)
        self._scene = scene
        self._px_per_beat = float(px_per_beat)
        self._tool = "ARROW"
        self._clip_len_beats = 4.0
        # Snap quantum in beats (quarter-note beats). Updated by AudioEventEditor.
        self._snap_quantum_beats = 0.25

        self._drag_loop = False
        self._loop_drag_start_x: float | None = None

        # Knife Cut+Drag state
        self._knife_drag_active = False
        self._knife_press_scene_x = 0.0

        # middle-mouse panning
        self._panning = False
        self._pan_last = None

        self.setViewportUpdateMode(QGraphicsView.ViewportUpdateMode.SmartViewportUpdate)
        self.setRenderHints(self.renderHints())

        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._ctx_menu)

        self.set_tool("ARROW")

    def set_tool(self, tool: str) -> None:
        self._tool = str(tool or "ARROW").upper()
        # Reset Cut+Drag when leaving Knife
        if self._tool != "KNIFE":
            self._knife_drag_active = False
        if self._tool == "KNIFE":
            self.setCursor(Qt.CursorShape.CrossCursor)
            self.setDragMode(QGraphicsView.DragMode.NoDrag)
        elif self._tool in ("TIME", "TIMESELECT"):
            self.setCursor(Qt.CursorShape.IBeamCursor)
            self.setDragMode(QGraphicsView.DragMode.NoDrag)
        elif self._tool in ("ERASE", "ERASER"):
            self.setCursor(Qt.CursorShape.PointingHandCursor)
            self.setDragMode(QGraphicsView.DragMode.NoDrag)
        elif self._tool == "PENCIL":
            self.setCursor(Qt.CursorShape.CrossCursor)
            self.setDragMode(QGraphicsView.DragMode.NoDrag)
        else:
            # Arrow: items handle dragging (group move)
            self.setCursor(Qt.CursorShape.ArrowCursor)
            self.setDragMode(QGraphicsView.DragMode.NoDrag)

    def set_clip_length(self, beats: float) -> None:
        self._clip_len_beats = max(0.0, float(beats))

    def set_snap_quantum_beats(self, q: float) -> None:
        try:
            qf = float(q)
        except Exception:
            qf = 0.25
        self._snap_quantum_beats = max(1e-6, qf)

    def wheelEvent(self, event):  # noqa: ANN001
        # Default: zoom horizontally (like Arranger); Shift+Wheel: scroll
        if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
            super().wheelEvent(event)
            return
        delta = event.angleDelta().y()
        if delta == 0:
            return
        factor = 1.15 if delta > 0 else 1 / 1.15
        self.scale(factor, 1.0)
        event.accept()

    def mousePressEvent(self, event):  # noqa: ANN001
        # middle mouse: pan view
        if event.button() == Qt.MouseButton.MiddleButton:
            self._panning = True
            self._pan_last = event.pos()
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            event.accept()
            return

        if event.button() == Qt.MouseButton.LeftButton:
            sp = self.mapToScene(event.pos())
            at_beats = float(sp.x() / self._px_per_beat) if self._px_per_beat > 1e-6 else 0.0
            # clamp to clip bounds
            at_beats = max(0.0, min(float(self._clip_len_beats), float(at_beats)))
            if self._tool == "KNIFE":
                # Snap-to-grid unless Shift is held (Pro-DAW-like).
                if not (event.modifiers() & Qt.KeyboardModifier.ShiftModifier):
                    q = float(self._snap_quantum_beats) if self._snap_quantum_beats > 1e-9 else 0.25
                    at_beats = round(at_beats / q) * q
                    at_beats = max(0.0, min(float(self._clip_len_beats), float(at_beats)))
                # Cut+Drag: request a split, then drag starts immediately via editor
                self._knife_drag_active = True
                self._knife_press_scene_x = float(sp.x())
                try:
                    self.request_slice_drag.emit(float(at_beats), float(self._knife_press_scene_x))
                except Exception:
                    self.request_slice.emit(float(at_beats))
                event.accept()
                return

            if self._tool in ("ERASE", "ERASER"):
                self.request_remove_slice.emit(at_beats)
                event.accept()
                return

            if self._tool == "PENCIL":
                sp2 = self.mapToScene(event.pos())
                at_beats_p = float(sp2.x() / self._px_per_beat) if self._px_per_beat > 1e-6 else 0.0
                at_beats_p = max(0.0, min(float(self._clip_len_beats), at_beats_p))
                # Normalized value: y position relative to scene height
                scene_rect = self.scene().sceneRect() if self.scene() else QRectF(0, 0, 800, 220)
                h = max(1.0, scene_rect.height())
                norm_val = max(0.0, min(1.0, 1.0 - (float(sp2.y()) / h)))
                if event.button() == Qt.MouseButton.LeftButton:
                    self.pencil_add_point.emit(float(at_beats_p), float(norm_val))
                event.accept()
                return

            if self._tool in ("TIME", "TIMESELECT"):
                self._drag_loop = True
                self._loop_drag_start_x = float(sp.x())
                event.accept()
                return

        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):  # noqa: ANN001
        if self._knife_drag_active and self._tool == "KNIFE" and (event.buttons() & Qt.MouseButton.LeftButton):
            sp = self.mapToScene(event.pos())
            try:
                self.knife_drag_update.emit(float(sp.x()), int(event.modifiers()))
            except Exception:
                pass
            event.accept()
            return

        # Pencil continuous drawing (draw while dragging)
        if self._tool == "PENCIL" and (event.buttons() & Qt.MouseButton.LeftButton):
            sp = self.mapToScene(event.pos())
            at_beats = float(sp.x() / self._px_per_beat) if self._px_per_beat > 1e-6 else 0.0
            at_beats = max(0.0, min(float(self._clip_len_beats), at_beats))
            scene_rect = self.scene().sceneRect() if self.scene() else QRectF(0, 0, 800, 220)
            h = max(1.0, scene_rect.height())
            norm_val = max(0.0, min(1.0, 1.0 - (float(sp.y()) / h)))
            self.pencil_drag_point.emit(float(at_beats), float(norm_val))
            event.accept()
            return

        if self._panning and self._pan_last is not None:
            d = event.pos() - self._pan_last
            self._pan_last = event.pos()
            hs = self.horizontalScrollBar()
            vs = self.verticalScrollBar()
            hs.setValue(hs.value() - d.x())
            vs.setValue(vs.value() - d.y())
            event.accept()
            return

        if self._drag_loop and self._loop_drag_start_x is not None:
            sp = self.mapToScene(event.pos())
            x0 = float(self._loop_drag_start_x)
            x1 = float(sp.x())
            a = min(x0, x1) / self._px_per_beat
            b = max(x0, x1) / self._px_per_beat
            self.request_set_loop.emit(float(a), float(b))
            event.accept()
            return

        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):  # noqa: ANN001
        if event.button() == Qt.MouseButton.LeftButton and self._knife_drag_active:
            self._knife_drag_active = False
            try:
                self.knife_drag_end.emit()
            except Exception:
                pass
            event.accept()
            return

        if event.button() == Qt.MouseButton.MiddleButton:
            self._panning = False
            self._pan_last = None
            self.set_tool(self._tool)
            event.accept()
            return

        self._drag_loop = False
        self._loop_drag_start_x = None
        super().mouseReleaseEvent(event)

    def _ctx_menu(self, pos):  # noqa: ANN001
        # In Pencil mode, right-click removes automation point instead of showing menu
        if self._tool == "PENCIL":
            sp = self.mapToScene(pos)
            at_beats = float(sp.x() / self._px_per_beat) if self._px_per_beat > 1e-6 else 0.0
            at_beats = max(0.0, min(float(self._clip_len_beats), at_beats))
            self.pencil_remove_point.emit(float(at_beats))
            return

        menu = QMenu(self)

        menu.addAction("Split at Playhead")
        menu.addAction("Consolidate")
        menu.addSeparator()
        menu.addAction("Reverse")
        menu.addAction("Mute Clip")
        menu.addAction("Normalize")

        gain_sub = menu.addMenu("Gain")
        gain_sub.addAction("+3 dB")
        gain_sub.addAction("-3 dB")
        gain_sub.addAction("+6 dB")
        gain_sub.addAction("-6 dB")
        gain_sub.addAction("Reset (0 dB)")

        menu.addSeparator()

        fade_sub = menu.addMenu("Fades")
        fade_sub.addAction("Fade In 1/16")
        fade_sub.addAction("Fade In 1/8")
        fade_sub.addAction("Fade In 1/4")
        fade_sub.addAction("Fade In 1 Bar")
        fade_sub.addSeparator()
        fade_sub.addAction("Fade Out 1/16")
        fade_sub.addAction("Fade Out 1/8")
        fade_sub.addAction("Fade Out 1/4")
        fade_sub.addAction("Fade Out 1 Bar")
        fade_sub.addSeparator()
        fade_sub.addAction("Clear Fades")

        menu.addSeparator()
        menu.addAction("Quantize (Events)")

        sub = menu.addMenu("Transpose")
        sub.addAction("+1 Semitone")
        sub.addAction("-1 Semitone")
        sub.addAction("+12 Semitone (Octave Up)")
        sub.addAction("-12 Semitone (Octave Down)")

        menu.addSeparator()
        on = menu.addMenu("Onsets")
        on.addAction("Auto-Detect Onsets")
        on.addAction("Add Onset at Playhead")
        on.addAction("Slice at Onsets")
        on.addAction("Clear Onsets")

        menu.addSeparator()
        menu.addAction("Snap to Zero-Crossing")

        menu.addSeparator()
        auto_sub = menu.addMenu("Clip Automation")
        auto_sub.addAction("Clear Gain Automation")
        auto_sub.addAction("Clear Pan Automation")
        auto_sub.addAction("Clear Pitch Automation")
        auto_sub.addAction("Clear All Clip Automation")

        act = menu.exec(self.mapToGlobal(pos))
        if act:
            try:
                self.context_action_selected.emit(str(act.text()))
            except Exception:
                pass


class EventBlockItem(QGraphicsRectItem):
    """Clickable + selectable block representing one AudioEvent.

    Phase 2.1: dragging one block moves ALL selected blocks together (group move).
    """

    def __init__(
        self,
        editor: "AudioEventEditor",
        *,
        event_id: str,
        start_beats: float,
        length_beats: float,
        px_per_beat: float,
        height: float,
        alt_shade: bool,
    ):
        self.editor = editor
        self.event_id = str(event_id)
        self._px_per_beat = float(px_per_beat)
        self._length_beats = float(max(0.0, length_beats))

        w = max(1.0, self._length_beats * self._px_per_beat)
        super().__init__(QRectF(0.0, 0.0, w, float(height)))
        self.setPos(QPointF(float(start_beats) * self._px_per_beat, 0.0))

        self.setZValue(6)
        self.setFlags(
            QGraphicsRectItem.GraphicsItemFlag.ItemIsSelectable
            | QGraphicsRectItem.GraphicsItemFlag.ItemIsFocusable
        )
        self.setAcceptHoverEvents(True)

        base = editor.palette().alternateBase().color()
        self._brush = QBrush(base)
        self._opacity = 0.10 if alt_shade else 0.06

        self._pen = QPen(editor.palette().mid().color())
        self._pen.setWidth(1)
        self._pen_sel = QPen(editor.palette().highlight().color())
        self._pen_sel.setWidth(2)

    def start_beats(self) -> float:
        return float(self.pos().x() / self._px_per_beat) if self._px_per_beat > 1e-6 else 0.0

    def length_beats(self) -> float:
        return float(self._length_beats)

    def hoverEnterEvent(self, event):  # noqa: ANN001
        if self.editor.current_tool == "ARROW":
            self.setCursor(Qt.CursorShape.SizeAllCursor)
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event):  # noqa: ANN001
        if self.editor.current_tool == "ARROW":
            self.setCursor(Qt.CursorShape.ArrowCursor)
        super().hoverLeaveEvent(event)

    def mousePressEvent(self, event):  # noqa: ANN001
        if self.editor.current_tool != "ARROW" or event.button() != Qt.MouseButton.LeftButton:
            event.ignore()
            return

        mods = event.modifiers()
        ctrl = bool(mods & Qt.KeyboardModifier.ControlModifier)
        alt = bool(mods & Qt.KeyboardModifier.AltModifier)

        # Selection rule (Pro-DAW-like): Ctrl toggles multi-select, otherwise single-select
        scene = self.scene()
        if scene and not ctrl:
            scene.clearSelection()
            self.setSelected(True)
        elif ctrl:
            self.setSelected(not self.isSelected())
        else:
            self.setSelected(True)

        self.editor._begin_group_drag(self, event.scenePos().x(), mods, alt_duplicate=alt)
        event.accept()

    def mouseMoveEvent(self, event):  # noqa: ANN001
        if self.editor.current_tool != "ARROW":
            event.ignore()
            return
        self.editor._update_group_drag(event.scenePos().x(), event.modifiers())
        event.accept()

    def mouseReleaseEvent(self, event):  # noqa: ANN001
        if self.editor.current_tool != "ARROW":
            event.ignore()
            return
        self.editor._end_group_drag()
        event.accept()

    def paint(self, painter: QPainter, option, widget=None):  # noqa: ANN001
        painter.save()
        painter.setOpacity(self._opacity)
        painter.setBrush(self._brush)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRect(self.rect())
        painter.restore()

        painter.save()
        painter.setOpacity(0.9)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(self._pen_sel if self.isSelected() else self._pen)
        painter.drawRect(self.rect())
        painter.restore()


class AudioEventEditor(QWidget):
    """Central widget shown in bottom editor area for audio clips."""

    status_message = pyqtSignal(str)

    def __init__(self, project_service, *, transport=None, parent=None):
        super().__init__(parent)
        self.project = project_service
        self.transport = transport

        self._clip_id: str | None = None
        self._px_per_beat = 80.0

        self._scene: BeatGridScene | None = None
        self.view: AudioEditorView | None = None
        self.toolbar: QToolBar | None = None
        self.cmb_tool: QComboBox | None = None
        self.lbl_info: QLabel | None = None

        # Param controls (Gain/Pan/Pitch/Formant/Stretch)
        self.param_panel: QWidget | None = None
        self._param_spins: dict[str, QDoubleSpinBox] = {}
        self._param_labels: dict[str, QLabel] = {}
        self._suppress_param_signals = False
        self._show_onsets = False
        self._show_stretch = False
        self._stretch_items: list = []
        self._onset_items: list[QGraphicsLineItem] = []
        self._dup_drag_active = False
        self._dup_map: dict[str, str] = {}

        self._wave_item: QGraphicsPathItem | None = None
        self._slice_items: list[QGraphicsLineItem] = []
        self._event_items: Dict[str, EventBlockItem] = {}
        self._selected_event_ids: Set[str] = set()

        self._loop_rect: QGraphicsRectItem | None = None
        self._loop_start_edge: _LoopEdge | None = None
        self._loop_end_edge: _LoopEdge | None = None

        # Fade overlays + handles
        self._fade_in_overlay: QGraphicsPathItem | None = None
        self._fade_out_overlay: QGraphicsPathItem | None = None
        self._fade_in_handle: _FadeHandle | None = None
        self._fade_out_handle: _FadeHandle | None = None
        self._fade_update_guard = False

        # Mute/Reverse overlays
        self._mute_overlay: QGraphicsRectItem | None = None
        self._mute_label: QGraphicsSimpleTextItem | None = None
        self._reverse_tint: QGraphicsRectItem | None = None

        self._drag_active = False
        self._drag_base_id: str | None = None
        self._drag_start_scene_x = 0.0
        self._drag_init_pos_px: Dict[str, float] = {}
        self._drag_applied_delta_px = 0.0

        self._clip_len_beats = 4.0
        self._clip_width_px = 800.0
        self._clip_height = 220.0

        self.current_tool = "ARROW"

        # Pencil tool state (clip automation envelopes)
        self._auto_param = "gain"  # current automation parameter for pencil
        self._auto_items: list = []  # rendered automation line items
        self._auto_point_items: list = []  # rendered breakpoint dots
        self._auto_drag_idx: int | None = None  # index of dragged breakpoint
        self._auto_drag_param: str = ""

        # Guards:
        # - _suppress_project_refresh: avoid full scene rebuild while we are actively dragging loop edges
        #   (project_updated is emitted synchronously and would otherwise call refresh() recursively).
        # - _loop_update_guard: prevent re-entrant setPos()/itemChange feedback loops.
        self._suppress_project_refresh = False
        self._loop_update_guard = False
        self._last_loop_pair: tuple[float, float] | None = None

        self._build_ui()
        self._wire()

    def set_clip(self, clip_id: str | None) -> None:
        cid = str(clip_id or "").strip() if clip_id else ""
        self._clip_id = cid or None
        self.refresh()

    def refresh(self) -> None:
        scene = self._scene
        if scene is None:
            return

        prev_sel = set(self._selected_event_ids)
        scene.clear()

        self._wave_item = None
        self._slice_items = []
        self._onset_items = []
        self._event_items = {}
        self._selected_event_ids = set()

        self._loop_rect = None
        self._loop_start_edge = None
        self._loop_end_edge = None

        self._fade_in_overlay = None
        self._fade_out_overlay = None
        self._fade_in_handle = None
        self._fade_out_handle = None
        self._mute_overlay = None
        self._mute_label = None
        self._reverse_tint = None
        self._auto_items = []
        self._auto_point_items = []
        self._stretch_items = []

        clip = self._get_clip()
        if not clip:
            scene.setSceneRect(QRectF(0, 0, 800, 220))
            t = scene.addText("Kein Audio-Clip ausgewählt.")
            t.setDefaultTextColor(self.palette().mid().color())
            return

        self._sync_param_controls(clip)

        length_beats = float(getattr(clip, "length_beats", 4.0) or 4.0)
        self._clip_len_beats = max(0.001, length_beats)
        self._clip_height = 220.0

        # --- Zoom-to-Fit: Calculate px_per_beat so the clip fills the editor width ---
        # This ensures automation lines, audio events, and waveform all align correctly.
        editor_width = max(800.0, float(self.view.viewport().width() if self.view else 800))
        self._px_per_beat = editor_width / self._clip_len_beats
        self._clip_width_px = self._clip_len_beats * self._px_per_beat

        scene.setSceneRect(QRectF(0, 0, self._clip_width_px, self._clip_height))
        scene.px_per_beat = self._px_per_beat  # sync grid rendering
        if self.view:
            self.view.set_clip_length(self._clip_len_beats)
            self.view._px_per_beat = self._px_per_beat  # sync zoom-to-fit
            # Only reset view zoom when clip changes (not on every param update)
            if getattr(self, '_last_fit_clip_id', None) != self._clip_id:
                self._last_fit_clip_id = self._clip_id
                self.view.resetTransform()
            # Keep view snapping in sync with global project grid.
            try:
                self.view.set_snap_quantum_beats(self._snap_quantum_beats())
            except Exception:
                pass

        path = getattr(clip, "source_path", None)
        if path and os.path.exists(path):
            self._draw_waveform(
                path,
                self._clip_width_px,
                self._clip_height,
                gain=float(getattr(clip, "gain", 1.0) or 1.0),
                reversed_display=bool(getattr(clip, "reversed", False)),
            )
        else:
            t = scene.addText("Audiofile fehlt (source_path).")
            t.setDefaultTextColor(self.palette().mid().color())

        # events
        try:
            evs = list(getattr(clip, "audio_events", []) or [])
        except Exception:
            evs = []
        if not evs:
            try:
                self.project._ensure_audio_events(clip)  # type: ignore[attr-defined]
                evs = list(getattr(clip, "audio_events", []) or [])
            except Exception:
                evs = []

        evs_sorted = sorted(evs, key=lambda x: float(getattr(x, "start_beats", 0.0) or 0.0))
        for i, e in enumerate(evs_sorted):
            try:
                eid = str(getattr(e, "id", ""))
                s = float(getattr(e, "start_beats", 0.0) or 0.0)
                l = float(getattr(e, "length_beats", 0.0) or 0.0)
            except Exception:
                continue
            if not eid or l <= 1e-6:
                continue
            item = EventBlockItem(
                self,
                event_id=eid,
                start_beats=s,
                length_beats=l,
                px_per_beat=self._px_per_beat,
                height=self._clip_height,
                alt_shade=(i % 2 == 0),
            )
            scene.addItem(item)
            self._event_items[eid] = item

        # slices
        slices = list(getattr(clip, "audio_slices", []) or [])
        for s in slices:
            if not isinstance(s, (int, float)):
                continue
            x = float(s) * self._px_per_beat
            line = QGraphicsLineItem(x, 0.0, x, self._clip_height)
            pen = QPen(self.palette().highlight().color())
            pen.setWidth(1)
            line.setPen(pen)
            line.setZValue(20)
            line.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
            scene.addItem(line)
            self._slice_items.append(line)

        # Onset markers
        if bool(self._show_onsets):
            try:
                onsets = list(getattr(clip, 'onsets', []) or [])
            except Exception:
                onsets = []
            if onsets:
                try:
                    pen = QPen(self.palette().highlight().color())
                    pen.setWidthF(1.0)
                    pen.setStyle(Qt.PenStyle.DashLine)
                    c = pen.color()
                    c.setAlpha(140)
                    pen.setColor(c)
                except Exception:
                    pen = QPen(Qt.GlobalColor.cyan)
                for ob in onsets:
                    try:
                        bx = float(ob) * float(self._px_per_beat)
                        ln = QGraphicsLineItem(bx, 0.0, bx, float(self._clip_height))
                        ln.setZValue(4)
                        ln.setPen(pen)
                        ln.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
                        scene.addItem(ln)
                        self._onset_items.append(ln)
                    except Exception:
                        continue

        self._ensure_loop_items(clip, self._clip_width_px, self._clip_height)

        # --- Stretch warp markers (Bitwig-style orange vertical lines) ---
        self._stretch_items = []
        if bool(self._show_stretch):
            try:
                stretch_val = float(getattr(clip, 'stretch', 1.0) or 1.0)
                pen_s = QPen(QColor(255, 140, 0))
                pen_s.setWidthF(2.0)
                pen_s.setStyle(Qt.PenStyle.SolidLine)
                # Show markers at beat divisions (scaled by stretch)
                q = self._snap_quantum_beats()
                beat = 0.0
                while beat <= self._clip_len_beats + 0.001:
                    bx = float(beat) * float(self._px_per_beat)
                    ln = QGraphicsLineItem(bx, 0.0, bx, float(self._clip_height))
                    ln.setZValue(5)
                    ln.setPen(pen_s)
                    ln.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
                    scene.addItem(ln)
                    self._stretch_items.append(ln)
                    # Small triangle handle at top
                    tri_size = 6
                    tri = QGraphicsPolygonItem(QPolygonF([
                        QPointF(bx - tri_size, 0),
                        QPointF(bx + tri_size, 0),
                        QPointF(bx, tri_size * 1.5),
                    ]))
                    tri.setZValue(6)
                    tri.setBrush(QBrush(QColor(255, 140, 0)))
                    tri.setPen(QPen(Qt.PenStyle.NoPen))
                    tri.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
                    scene.addItem(tri)
                    self._stretch_items.append(tri)
                    beat += q
                # Stretch info label
                if abs(stretch_val - 1.0) > 0.005:
                    info = QGraphicsSimpleTextItem(f"Stretch: ×{stretch_val:.2f}")
                    info.setZValue(52)
                    info.setBrush(QBrush(QColor(255, 140, 0)))
                    f = info.font()
                    f.setPointSize(10)
                    f.setBold(True)
                    info.setFont(f)
                    info.setPos(8, self._clip_height - 20)
                    scene.addItem(info)
                    self._stretch_items.append(info)
            except Exception:
                pass

        # --- Fade overlays + handles (Bitwig-style) ---
        self._render_fade_overlays(clip, self._clip_width_px, self._clip_height)

        # --- Reverse tint (orange overlay when reversed) ---
        if bool(getattr(clip, 'reversed', False)):
            try:
                r_rect = QGraphicsRectItem(QRectF(0.0, 0.0, self._clip_width_px, self._clip_height))
                r_rect.setZValue(11)
                r_rect.setBrush(QBrush(QColor(255, 140, 0, 25)))
                r_rect.setPen(QPen(Qt.PenStyle.NoPen))
                r_rect.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
                scene.addItem(r_rect)
                self._reverse_tint = r_rect
            except Exception:
                pass

        # --- Mute overlay ---
        if bool(getattr(clip, 'muted', False)):
            try:
                m_rect = QGraphicsRectItem(QRectF(0.0, 0.0, self._clip_width_px, self._clip_height))
                m_rect.setZValue(50)
                m_rect.setBrush(QBrush(QColor(0, 0, 0, 120)))
                m_rect.setPen(QPen(Qt.PenStyle.NoPen))
                m_rect.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
                scene.addItem(m_rect)
                self._mute_overlay = m_rect

                m_txt = QGraphicsSimpleTextItem("MUTED")
                m_txt.setZValue(51)
                m_txt.setBrush(QBrush(QColor(255, 80, 80)))
                f = m_txt.font()
                f.setPointSize(16)
                f.setBold(True)
                m_txt.setFont(f)
                m_txt.setPos(self._clip_width_px * 0.5 - 40, self._clip_height * 0.5 - 12)
                scene.addItem(m_txt)
                self._mute_label = m_txt
            except Exception:
                pass

        # --- Clip Automation Envelope (Pencil tool lines) ---
        self._render_clip_automation(clip, self._clip_width_px, self._clip_height)

        for eid in prev_sel:
            it = self._event_items.get(eid)
            if it is not None:
                it.setSelected(True)
        self._selected_event_ids = set(prev_sel) & set(self._event_items.keys())

        if self.lbl_info:
            self.lbl_info.setText(
                f"Audio Clip: {getattr(clip, 'label', '')}   |   Gain {getattr(clip, 'gain', 1.0):0.2f}   Pan {getattr(clip, 'pan', 0.0):0.2f}   |   Events: {len(evs_sorted)}"
            )

    def _build_ui(self) -> None:
        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(6)

        top = QHBoxLayout()
        self.lbl_info = QLabel("Audio Clip Editor")
        top.addWidget(self.lbl_info)
        top.addStretch(1)
        lay.addLayout(top)

        self.toolbar = QToolBar("Audio Tools")
        self.toolbar.setMovable(False)

        self.cmb_tool = QComboBox()
        self.cmb_tool.addItems(["Arrow", "Knife", "Eraser", "Time", "Pencil"])
        self.toolbar.addWidget(QLabel("Werkzeug: "))
        self.toolbar.addWidget(self.cmb_tool)
        self.toolbar.addSeparator()

        # Automation parameter selector (for Pencil tool)
        self.toolbar.addWidget(QLabel("Automation: "))
        self.cmb_auto_param = QComboBox()
        self.cmb_auto_param.addItems(["Gain", "Pan", "Pitch", "Formant"])
        self.cmb_auto_param.setFixedWidth(90)
        self.toolbar.addWidget(self.cmb_auto_param)
        self.toolbar.addSeparator()

        # Zoom controls
        self.btn_zoom_in = QToolButton()
        self.btn_zoom_in.setText("🔍+")
        self.btn_zoom_in.setToolTip("Zoom In (Ctrl+Wheel)")
        self.btn_zoom_in.setAutoRaise(True)
        self.toolbar.addWidget(self.btn_zoom_in)

        self.btn_zoom_out = QToolButton()
        self.btn_zoom_out.setText("🔍−")
        self.btn_zoom_out.setToolTip("Zoom Out (Ctrl+Wheel)")
        self.btn_zoom_out.setAutoRaise(True)
        self.toolbar.addWidget(self.btn_zoom_out)

        self.btn_zoom_fit = QToolButton()
        self.btn_zoom_fit.setText("⊞ Fit")
        self.btn_zoom_fit.setToolTip("Zoom to Fit (Clip füllt Editor)")
        self.btn_zoom_fit.setAutoRaise(True)
        self.toolbar.addWidget(self.btn_zoom_fit)
        self.toolbar.addSeparator()

        self._btns: dict[str, QToolButton] = {}
        for name in ["Audio Events", "Comping", "Stretch", "Onsets", "Gain", "Pan", "Pitch", "Formant"]:
            b = QToolButton()
            b.setText(name)
            b.setCheckable(True)
            b.setAutoRaise(True)
            self._btns[name] = b
            self.toolbar.addWidget(b)

        lay.addWidget(self.toolbar)

        # --- Parameter Inspector (Pro-DAW-like) ---
        self.param_panel = QWidget()
        self.param_panel.setObjectName('AudioParamPanel')
        ph = QHBoxLayout(self.param_panel)
        ph.setContentsMargins(0, 0, 0, 0)
        ph.setSpacing(8)

        def _mk(name: str, mn: float, mx: float, step: float, dec: int, suffix: str = ''):
            lab = QLabel(name)
            sp = QDoubleSpinBox()
            sp.setRange(float(mn), float(mx))
            sp.setSingleStep(float(step))
            sp.setDecimals(int(dec))
            if suffix:
                sp.setSuffix(suffix)
            sp.setKeyboardTracking(False)  # avoid flooding during typing
            sp.setFixedWidth(110)
            self._param_labels[name] = lab
            self._param_spins[name] = sp
            ph.addWidget(lab)
            ph.addWidget(sp)

        _mk('Gain', 0.0, 4.0, 0.01, 2, '')
        _mk('Pan', -1.0, 1.0, 0.01, 2, '')
        _mk('Pitch', -24.0, 24.0, 0.10, 2, ' st')
        _mk('Formant', -24.0, 24.0, 0.10, 2, ' st')
        _mk('Stretch', 0.25, 4.0, 0.01, 2, '×')

        ph.addStretch(1)
        lay.addWidget(self.param_panel)

        beats_per_bar = 4.0
        try:
            ts = getattr(self.project.ctx.project, "time_signature", "4/4")
            num, den = ts.split("/", 1)
            beats_per_bar = float(num) * (4.0 / float(den))
        except Exception:
            beats_per_bar = 4.0

        self._scene = BeatGridScene(beats_per_bar=beats_per_bar, px_per_beat=self._px_per_beat)
        self._scene.selectionChanged.connect(self._on_selection_changed)

        self.view = AudioEditorView(self._scene, px_per_beat=self._px_per_beat)
        self.view.setMinimumHeight(240)
        lay.addWidget(self.view, 1)

    def _wire(self) -> None:
        if self.cmb_tool:
            self.cmb_tool.currentTextChanged.connect(self._on_tool_changed)

        # Param controls
        for _name, _sp in list(getattr(self, '_param_spins', {}).items()):
            try:
                _sp.valueChanged.connect(lambda _v, n=_name: self._on_param_changed(n, float(_v)))
            except Exception:
                pass

        # Toolbar button focus
        try:
            for _n in ['Gain', 'Pan', 'Pitch', 'Formant', 'Stretch', 'Onsets']:
                b = getattr(self, '_btns', {}).get(_n)
                if b is not None:
                    b.clicked.connect(lambda _chk=False, n=_n: self._on_param_button(n))
        except Exception:
            pass

        # Automation parameter selector
        try:
            if hasattr(self, 'cmb_auto_param') and self.cmb_auto_param:
                self.cmb_auto_param.currentTextChanged.connect(self._on_auto_param_changed)
        except Exception:
            pass

        # Zoom buttons
        try:
            self.btn_zoom_in.clicked.connect(self._on_zoom_in)
            self.btn_zoom_out.clicked.connect(self._on_zoom_out)
            self.btn_zoom_fit.clicked.connect(self._on_zoom_fit)
        except Exception:
            pass

        if self.view:
            self.view.request_slice.connect(self._on_slice_requested)
            self.view.request_remove_slice.connect(self._on_erase_requested)
            self.view.request_set_loop.connect(self._on_loop_dragged)
            self.view.context_action_selected.connect(self._on_context_action)

            # Pencil tool signals
            try:
                self.view.pencil_add_point.connect(self._on_pencil_add_point)
                self.view.pencil_remove_point.connect(self._on_pencil_remove_point)
                self.view.pencil_drag_point.connect(self._on_pencil_drag_point)
            except Exception:
                pass

            # Knife Cut+Drag
            try:
                self.view.request_slice_drag.connect(self._on_slice_drag_requested)
                self.view.knife_drag_update.connect(self._on_knife_drag_update)
                self.view.knife_drag_end.connect(self._on_knife_drag_end)
            except Exception:
                pass

        try:
            self.project.project_updated.connect(self._on_project_updated)
        except Exception:
            pass

    def _on_project_updated(self) -> None:
        """React to external project changes.

        We intentionally skip full refresh while loop handles are being dragged,
        because project_updated is emitted synchronously by ProjectService and a
        full scene rebuild during an itemChange() will crash Qt.
        """
        if self._suppress_project_refresh:
            return
        self.refresh()

    # selection
    def _on_selection_changed(self) -> None:
        scene = self._scene
        if scene is None:
            return
        ids: Set[str] = set()
        for it in scene.selectedItems():
            if isinstance(it, EventBlockItem):
                ids.add(it.event_id)
        self._selected_event_ids = ids

    def _snap_quantum_beats(self) -> float:
        try:
            q = float(self.project.snap_quantum_beats())  # type: ignore[attr-defined]
            return max(1e-6, q)
        except Exception:
            return 0.25

    def _pick_cut_targets(self, clip, at_beats: float) -> List[str]:  # noqa: ANN001
        """Selection rules for Knife/Split.

        - If any *selected* event contains at_beats -> split those selected events.
        - Else split the event that contains at_beats ("under cursor").
        """
        try:
            t = float(at_beats)
        except Exception:
            return []

        try:
            evs = list(getattr(clip, "audio_events", []) or [])
        except Exception:
            evs = []
        if not evs:
            return []

        eps = 1e-6
        selected = set(self._selected_event_ids) if self._selected_event_ids else set()

        # First: selected events that contain t
        selected_hits: List[tuple[float, str]] = []
        hits: List[tuple[float, str]] = []
        for e in evs:
            try:
                eid = str(getattr(e, "id", ""))
                s = float(getattr(e, "start_beats", 0.0) or 0.0)
                l = float(getattr(e, "length_beats", 0.0) or 0.0)
            except Exception:
                continue
            if not eid or l <= eps:
                continue
            eend = s + l
            if (s - eps) <= t <= (eend + eps):
                hits.append((s, eid))
                if eid in selected:
                    selected_hits.append((s, eid))

        if selected_hits:
            # Return selected hits (sorted by start so result is stable)
            return [eid for _, eid in sorted(selected_hits, key=lambda x: x[0])]

        if hits:
            # If overlaps exist, pick the one with the latest start (closest/"top")
            hits.sort(key=lambda x: x[0])
            return [hits[-1][1]]

        return []

    # group drag
    def _begin_group_drag(self, base_item: EventBlockItem, scene_x: float, mods: Qt.KeyboardModifier | None = None, *, alt_duplicate: bool = False) -> None:
        if self._scene is None:
            return
        sel = [it for it in self._scene.selectedItems() if isinstance(it, EventBlockItem)]
        if not sel:
            sel = [base_item]
        self._drag_active = True
        self._drag_base_id = base_item.event_id
        self._drag_start_scene_x = float(scene_x)
        self._drag_init_pos_px = {it.event_id: float(it.pos().x()) for it in sel}
        self._drag_applied_delta_px = 0.0

    
    def _begin_duplicate_drag(self, base_item: EventBlockItem, scene_x: float, mods: Qt.KeyboardModifier | None) -> None:
        """Alt=Duplicate: duplicate selected events and start dragging the duplicates."""
        if self._scene is None or not self._clip_id:
            return
        scene = self._scene
        sel_items = [it for it in scene.selectedItems() if isinstance(it, EventBlockItem)]
        if not sel_items:
            sel_items = [base_item]
        old_ids = [it.event_id for it in sel_items]

        # Duplicate in model (no immediate refresh to keep drag stable)
        try:
            self._suppress_project_refresh = True
            try:
                dup_map = self.project.duplicate_audio_events(self._clip_id, old_ids, emit_updated=True)  # type: ignore[attr-defined]
            finally:
                self._suppress_project_refresh = False
            if not isinstance(dup_map, dict) or not dup_map:
                return
        except Exception:
            return

        self._dup_map = {str(k): str(v) for k, v in dup_map.items() if str(k) and str(v)}
        new_ids = [self._dup_map.get(oid) for oid in old_ids if self._dup_map.get(oid)]
        if not new_ids:
            return

        # Create new graphics items for duplicates without full refresh
        clip = self._get_clip()
        if not clip:
            return
        try:
            evs = list(getattr(clip, 'audio_events', []) or [])
        except Exception:
            evs = []
        by_id = {str(getattr(e, 'id', '')): e for e in evs}

        # Deselect originals
        for it in sel_items:
            try:
                it.setSelected(False)
            except Exception:
                pass

        created: list[EventBlockItem] = []
        shade_toggle = False
        for oid in old_ids:
            nid = self._dup_map.get(str(oid))
            if not nid:
                continue
            e = by_id.get(str(nid))
            if e is None:
                continue
            try:
                start_b = float(getattr(e, 'start_beats', 0.0) or 0.0)
                len_b = float(getattr(e, 'length_beats', 0.0) or 0.0)
                it = EventBlockItem(self, event_id=str(nid), start_beats=start_b, length_beats=len_b, px_per_beat=self._px_per_beat, height=self._clip_height, alt_shade=shade_toggle)
                shade_toggle = not shade_toggle
                scene.addItem(it)
                self._event_items[str(nid)] = it
                created.append(it)
                it.setSelected(True)
            except Exception:
                continue

        if not created:
            return

        # Start drag with duplicates selected
        self._selected_event_ids = set(new_ids)
        base_new = self._dup_map.get(str(base_item.event_id), str(new_ids[0]))
        base_it = self._event_items.get(str(base_new))
        if base_it is None:
            base_it = created[0]

        # init drag state
        self._drag_active = True
        self._drag_base_id = str(base_it.event_id)
        self._drag_start_scene_x = float(scene_x)
        self._drag_init_pos_px = {it.event_id: float(it.pos().x()) for it in created if it.isSelected()}
        self._drag_applied_delta_px = 0.0

    def _update_group_drag(self, scene_x: float, mods: Qt.KeyboardModifier) -> None:
        if not self._drag_active or not self._drag_init_pos_px:
            return
        desired_delta_px = float(scene_x) - float(self._drag_start_scene_x)

        snap_enabled = not bool(mods & Qt.KeyboardModifier.ShiftModifier)
        delta_px = desired_delta_px

        if snap_enabled and self._drag_base_id and self._drag_base_id in self._drag_init_pos_px:
            q = self._snap_quantum_beats()
            init_x = self._drag_init_pos_px[self._drag_base_id]
            desired_base = init_x + desired_delta_px
            desired_beats = desired_base / self._px_per_beat
            snapped_beats = round(desired_beats / q) * q
            snapped_base = snapped_beats * self._px_per_beat
            delta_px = snapped_base - init_x

        min_init = min(self._drag_init_pos_px.values())
        max_init_end = 0.0
        for eid, ix in self._drag_init_pos_px.items():
            it = self._event_items.get(eid)
            if it is None:
                continue
            max_init_end = max(max_init_end, ix + it.rect().width())

        delta_min = -min_init
        delta_max = self._clip_width_px - max_init_end
        if delta_px < delta_min:
            delta_px = delta_min
        if delta_px > delta_max:
            delta_px = delta_max

        for eid, ix in self._drag_init_pos_px.items():
            it = self._event_items.get(eid)
            if it is None:
                continue
            it.setPos(QPointF(ix + delta_px, 0.0))

        self._drag_applied_delta_px = float(delta_px)

    def _end_group_drag(self) -> None:
        if not self._drag_active:
            return
        self._drag_active = False

        if not self._clip_id or not self._drag_init_pos_px:
            self._drag_init_pos_px = {}
            self._drag_base_id = None
            return

        delta_beats = float(self._drag_applied_delta_px / self._px_per_beat) if self._px_per_beat > 1e-6 else 0.0
        if abs(delta_beats) < 1e-6:
            self._drag_init_pos_px = {}
            self._drag_base_id = None
            return

        try:
            ids = list(self._drag_init_pos_px.keys())
            self.project.move_audio_events(self._clip_id, ids, delta_beats)  # type: ignore[attr-defined]
        except Exception:
            pass

        self._drag_init_pos_px = {}
        self._drag_base_id = None


    # --- Param Inspector handlers ---
    def _on_param_button(self, name: str) -> None:
        n = str(name or '').strip()
        if n == 'Onsets':
            try:
                self._show_onsets = bool(getattr(self, '_btns', {}).get('Onsets').isChecked())
            except Exception:
                self._show_onsets = not self._show_onsets
            self.refresh()
            return
        if n == 'Stretch':
            try:
                self._show_stretch = bool(getattr(self, '_btns', {}).get('Stretch').isChecked())
            except Exception:
                self._show_stretch = not self._show_stretch
            self.refresh()
            return
        sp = self._param_spins.get(n)
        if sp is not None:
            try:
                sp.setFocus()
                sp.selectAll()
            except Exception:
                pass

    def _on_auto_param_changed(self, text: str) -> None:
        """Handle automation parameter selector change."""
        self._auto_param = str(text or "Gain").strip().lower()
        self.refresh()

    def _on_zoom_in(self) -> None:
        """Zoom in (increase scale)."""
        if self.view:
            self.view.scale(1.3, 1.0)

    def _on_zoom_out(self) -> None:
        """Zoom out (decrease scale)."""
        if self.view:
            self.view.scale(1 / 1.3, 1.0)

    def _on_zoom_fit(self) -> None:
        """Reset zoom to fit entire clip in editor width."""
        if self.view:
            self._last_fit_clip_id = None  # force re-fit
            self.refresh()

    def _on_pencil_add_point(self, at_beats: float, norm_val: float) -> None:
        """Add an automation breakpoint at cursor position (Pencil tool)."""
        clip = self._get_clip()
        if not clip or not self._clip_id:
            return
        param = str(self._auto_param or "gain").lower()
        try:
            self._suppress_project_refresh = True
            self.project.add_clip_automation_point(str(self._clip_id), param, float(at_beats), float(norm_val))
        except Exception:
            pass
        finally:
            self._suppress_project_refresh = False
        self.refresh()
        try:
            self.status_message.emit(f"Automation: {param} @ {at_beats:.2f} = {norm_val:.2f}")
        except Exception:
            pass

    def _on_pencil_remove_point(self, at_beats: float) -> None:
        """Remove automation breakpoint near cursor (right-click in Pencil mode)."""
        if not self._clip_id:
            return
        param = str(self._auto_param or "gain").lower()
        try:
            self.project.remove_clip_automation_point(str(self._clip_id), param, float(at_beats))
        except Exception:
            pass
        self.refresh()

    def _on_pencil_drag_point(self, at_beats: float, norm_val: float) -> None:
        """Continuous drawing: add/update points while dragging (Pencil tool)."""
        if not self._clip_id:
            return
        param = str(self._auto_param or "gain").lower()
        try:
            # Snap to grid for cleaner automation
            q = self._snap_quantum_beats()
            at_snapped = round(float(at_beats) / q) * q
            self._suppress_project_refresh = True
            self.project.add_clip_automation_point(str(self._clip_id), param, float(at_snapped), float(norm_val))
        except Exception:
            pass
        finally:
            self._suppress_project_refresh = False
        self.refresh()

    def _sync_param_controls(self, clip) -> None:  # noqa: ANN001
        if not self._param_spins:
            return
        self._suppress_param_signals = True
        try:
            def _set(name: str, v: float):
                sp = self._param_spins.get(name)
                if sp is None:
                    return
                try:
                    sp.blockSignals(True)
                    sp.setValue(float(v))
                finally:
                    sp.blockSignals(False)

            _set('Gain', float(getattr(clip, 'gain', 1.0) or 1.0))
            _set('Pan', float(getattr(clip, 'pan', 0.0) or 0.0))
            _set('Pitch', float(getattr(clip, 'pitch', 0.0) or 0.0))
            _set('Formant', float(getattr(clip, 'formant', 0.0) or 0.0))
            _set('Stretch', float(getattr(clip, 'stretch', 1.0) or 1.0))
        finally:
            self._suppress_param_signals = False

    def _on_param_changed(self, name: str, value: float) -> None:
        if self._suppress_param_signals or not self._clip_id:
            return
        clip = self._get_clip()
        if not clip:
            return
        # Clamp + dispatch to ProjectService (single source of truth)
        kwargs = {}
        n = str(name or '').strip().lower()
        try:
            if n == 'gain':
                kwargs['gain'] = max(0.0, float(value))
            elif n == 'pan':
                kwargs['pan'] = max(-1.0, min(1.0, float(value)))
            elif n == 'pitch':
                kwargs['pitch'] = float(value)
            elif n == 'formant':
                kwargs['formant'] = float(value)
            elif n == 'stretch':
                kwargs['stretch'] = max(0.01, float(value))
            else:
                return
        except Exception:
            return

        # Avoid full scene rebuild on every knob step in this editor only.
        self._suppress_project_refresh = True
        try:
            self.project.update_audio_clip_params(self._clip_id, **kwargs)  # type: ignore[attr-defined]
        except Exception:
            pass
        finally:
            self._suppress_project_refresh = False

        # Update info label quickly (no rebuild).
        try:
            if self.lbl_info:
                self.lbl_info.setText(
                    f"Audio Clip: {getattr(clip, 'label', '')}   |   Gain {getattr(clip, 'gain', 1.0):0.2f}   Pan {getattr(clip, 'pan', 0.0):0.2f}   |   Events: {len(getattr(clip, 'audio_events', []) or [])}"
                )
        except Exception:
            pass

    # tools
    def _on_tool_changed(self, text: str) -> None:
        t = (text or "").strip().upper()
        if t.startswith("AR"):
            self.current_tool = "ARROW"
        elif t.startswith("KN"):
            self.current_tool = "KNIFE"
        elif t.startswith("ER"):
            self.current_tool = "ERASE"
        elif t.startswith("PE"):
            self.current_tool = "PENCIL"
        else:
            self.current_tool = "TIME"

        if self.view:
            self.view.set_tool(self.current_tool)

    def _knife_target_event_ids(self, clip, at_beats: float) -> List[str]:  # noqa: ANN001
        """Selection rules for Knife:

        - If selected events exist and one or more selected events contain the cut time,
          ONLY those selected events are cut.
        - Otherwise, cut the (first) event under the cursor/playhead.

        Returns a list (possibly empty) of eligible AudioEvent ids.
        """
        try:
            t = float(at_beats)
        except Exception:
            return []

        # Ensure events exist
        try:
            evs = list(getattr(clip, "audio_events", []) or [])
        except Exception:
            evs = []
        if not evs:
            try:
                self.project._ensure_audio_events(clip)  # type: ignore[attr-defined]
                evs = list(getattr(clip, "audio_events", []) or [])
            except Exception:
                evs = []
        if not evs:
            return []

        eps = 1e-6
        containing = []
        for e in evs:
            try:
                eid = str(getattr(e, "id", ""))
                s = float(getattr(e, "start_beats", 0.0) or 0.0)
                l = float(getattr(e, "length_beats", 0.0) or 0.0)
            except Exception:
                continue
            if not eid or l <= eps:
                continue
            end = s + l
            if (s - eps) <= t <= (end + eps):
                containing.append((s, eid))

        if not containing:
            return []

        sel = set(self._selected_event_ids) if self._selected_event_ids else set()
        if sel:
            sel_hits = [eid for _, eid in containing if eid in sel]
            if sel_hits:
                return sel_hits

        # no selected hit: return the event with the latest start (best match for overlaps)
        containing.sort(key=lambda x: float(x[0]))
        return [containing[-1][1]]

    def _right_ids_from_split(self, new_sel: list[str]) -> list[str]:
        """Selection policy after Knife: select only right-part(s).

        ProjectService.split_audio_events_at returns [left,right] per split.
        For multi-split, list is [L1,R1,L2,R2,...].
        """
        if not new_sel:
            return []
        if len(new_sel) >= 2:
            rights = [str(new_sel[i]) for i in range(1, len(new_sel), 2)]
            return [r for r in rights if r]
        return [str(new_sel[0])]

    def _on_slice_drag_requested(self, at_beats: float, press_scene_x: float) -> None:
        """Knife Cut+Drag: split then immediately start group-drag of right-part(s).

        press_scene_x is the mouse position in scene coordinates at press time.
        """
        clip = self._get_clip()
        if not clip or getattr(clip, 'kind', '') != 'audio':
            return
        ids = self._knife_target_event_ids(clip, float(at_beats))
        if not ids:
            return
        prev = bool(self._suppress_project_refresh)
        self._suppress_project_refresh = True
        new_sel: list[str] = []
        try:
            if hasattr(self.project, 'split_audio_events_at'):
                new_sel = list(self.project.split_audio_events_at(str(clip.id), float(at_beats), event_ids=list(ids)))  # type: ignore[attr-defined]
            else:
                self.project.split_audio_event(str(clip.id), float(at_beats))
        except Exception:
            new_sel = []
        finally:
            self._suppress_project_refresh = prev

        right_ids = self._right_ids_from_split(new_sel)
        if right_ids:
            self._selected_event_ids = set(right_ids)
        self.refresh()

        # Start drag on the right-part closest to the cut position.
        if not right_ids:
            return
        base_item = None
        best_d = None
        for rid in right_ids:
            it = self._event_items.get(rid)
            if it is None:
                continue
            d = abs(float(it.start_beats()) - float(at_beats))
            if best_d is None or d < best_d:
                best_d = d
                base_item = it
        if base_item is None:
            base_item = self._event_items.get(right_ids[0])
        if base_item is None:
            return
        # Begin group drag with current selection (right parts).
        self._begin_group_drag(base_item, float(press_scene_x))

    def _on_knife_drag_update(self, scene_x: float, modifiers_int: int) -> None:
        if not self._drag_active:
            return
        try:
            mods = Qt.KeyboardModifier(int(modifiers_int))
        except Exception:
            mods = Qt.KeyboardModifier.NoModifier
        self._update_group_drag(float(scene_x), mods)

    def _on_knife_drag_end(self) -> None:
        self._end_group_drag()

    def _on_slice_requested(self, at_beats: float) -> None:
        clip = self._get_clip()
        if not clip or getattr(clip, "kind", "") != "audio":
            return
        ids = self._knife_target_event_ids(clip, float(at_beats))
        if not ids:
            return

        # Keep selection stable: suppress auto refresh, then refresh once with new ids.
        prev = bool(self._suppress_project_refresh)
        self._suppress_project_refresh = True
        new_sel: List[str] = []
        try:
            if hasattr(self.project, "split_audio_events_at"):
                new_sel = list(self.project.split_audio_events_at(str(clip.id), float(at_beats), event_ids=list(ids)))  # type: ignore[attr-defined]
            else:
                # fallback (legacy): splits first containing event only
                self.project.split_audio_event(str(clip.id), float(at_beats))
        except Exception:
            new_sel = []
        finally:
            self._suppress_project_refresh = prev

        if new_sel:
            self._selected_event_ids = set(self._right_ids_from_split(list(new_sel)))
        self.refresh()
        try:
            self.status_message.emit(f"Split @ {float(at_beats):0.2f} beats")
        except Exception:
            pass

    def _on_erase_requested(self, at_beats: float) -> None:
        clip = self._get_clip()
        if not clip or getattr(clip, "kind", "") != "audio":
            return
        try:
            self.project.merge_audio_events_near(str(clip.id), float(at_beats), tolerance_beats=0.06)
            self.status_message.emit("Merge (Slice entfernt)")
        except Exception:
            pass

    def _on_loop_dragged(self, start_beats: float, end_beats: float) -> None:
        # Time-Selection tool: user drags a loop region.
        # We update overlay live, and persist to model, but we must NOT trigger a full refresh
        # while the drag is active (project_updated is synchronous).
        if self._loop_update_guard:
            return

        self._loop_update_guard = True
        try:
            clip = self._get_clip()
            if not clip or getattr(clip, "kind", "") != "audio":
                return

            length_beats = float(getattr(clip, "length_beats", 0.0) or 0.0)
            s = max(0.0, min(float(start_beats), max(0.0, length_beats)))
            e = max(0.0, min(float(end_beats), max(0.0, length_beats)))
            if e < s:
                s, e = e, s

            if e <= s + 1e-6:
                e = min(max(0.0, length_beats), s + 0.25)

            pair = (round(s, 6), round(e, 6))
            if self._last_loop_pair is not None and pair == self._last_loop_pair:
                return
            self._last_loop_pair = pair

            x0 = s * self._px_per_beat
            x1 = e * self._px_per_beat
            if self._loop_rect:
                self._loop_rect.setRect(QRectF(x0, 0.0, max(1.0, x1 - x0), self._loop_rect.rect().height()))
            if self._loop_start_edge:
                self._loop_start_edge.setPos(QPointF(x0, 0.0))
            if self._loop_end_edge:
                self._loop_end_edge.setPos(QPointF(x1, 0.0))

            self._suppress_project_refresh = True
            try:
                self.project.set_audio_clip_loop(str(clip.id), float(s), float(e))
            finally:
                self._suppress_project_refresh = False
        finally:
            self._loop_update_guard = False

    def _on_context_action(self, action_text: str) -> None:
        clip = self._get_clip()
        if not clip or getattr(clip, "kind", "") != "audio":
            return
        a = str(action_text or "").strip()

        if a == "Split at Playhead":
            t = self._local_playhead_beats(clip)
            ids = self._knife_target_event_ids(clip, float(t))
            if not ids:
                return

            prev = bool(self._suppress_project_refresh)
            self._suppress_project_refresh = True
            new_sel: List[str] = []
            try:
                if hasattr(self.project, "split_audio_events_at"):
                    new_sel = list(self.project.split_audio_events_at(str(clip.id), float(t), event_ids=list(ids)))  # type: ignore[attr-defined]
                else:
                    self.project.split_audio_event(str(clip.id), float(t))
            except Exception:
                new_sel = []
            finally:
                self._suppress_project_refresh = prev

            if new_sel:
                self._selected_event_ids = set(self._right_ids_from_split(list(new_sel)))
            self.refresh()
            try:
                self.status_message.emit(f"Split at Playhead @ {t:0.2f}")
            except Exception:
                pass
            return

        if a == "Consolidate":
            try:
                ids = list(self._selected_event_ids) if self._selected_event_ids else []
                self.project.consolidate_audio_events(str(clip.id), ids)  # type: ignore[attr-defined]
                self.status_message.emit("Consolidate")
            except Exception:
                pass
            return

        if a.startswith("Quantize"):
            try:
                ids = list(self._selected_event_ids) if self._selected_event_ids else []
                self.project.quantize_audio_events(str(clip.id), ids)  # type: ignore[attr-defined]
                self.status_message.emit("Quantize")
            except Exception:
                pass
            return

        if a == "+1 Semitone":
            try:
                self.project.update_audio_clip_params(
                    str(clip.id), pitch=float(getattr(clip, "pitch", 0.0) or 0.0) + 1.0
                )
                self.status_message.emit("Pitch +1")
            except Exception:
                pass
            return

        if a == "-1 Semitone":
            try:
                self.project.update_audio_clip_params(
                    str(clip.id), pitch=float(getattr(clip, "pitch", 0.0) or 0.0) - 1.0
                )
                self.status_message.emit("Pitch -1")
            except Exception:
                pass
            return

        if a == "Reverse":
            try:
                cur = bool(getattr(clip, "reversed", False))
                new_val = not cur
                self.project.update_audio_clip_params(str(clip.id), reversed=new_val)
                state = "ON" if new_val else "OFF"
                self.status_message.emit(f"Reverse {state}")
                self.refresh()
            except Exception:
                self.status_message.emit("Reverse (Fehler)")
            return

        if a == "Mute Clip":
            try:
                cur = bool(getattr(clip, "muted", False))
                new_val = not cur
                self.project.update_audio_clip_params(str(clip.id), muted=new_val)
                state = "ON" if new_val else "OFF"
                self.status_message.emit(f"Mute {state}")
                self.refresh()
            except Exception:
                self.status_message.emit("Mute (Fehler)")
            return

        if a == "Normalize":
            try:
                if hasattr(self.project, 'normalize_audio_clip'):
                    new_gain = self.project.normalize_audio_clip(str(clip.id))
                    if new_gain is not None:
                        import math
                        db = 20.0 * math.log10(max(1e-10, new_gain))
                        self.status_message.emit(f"Normalized → Gain {db:+.1f} dB")
                    else:
                        self.project.update_audio_clip_params(str(clip.id), gain=1.0)
                        self.status_message.emit("Normalized (Gain → 0 dB)")
                else:
                    self.project.update_audio_clip_params(str(clip.id), gain=1.0)
                    self.status_message.emit("Normalized (Gain → 0 dB)")
                self.refresh()
            except Exception:
                self.status_message.emit("Normalize (Fehler)")
            return

        if a == "+3 dB":
            try:
                cur_gain = float(getattr(clip, "gain", 1.0) or 1.0)
                new_gain = min(4.0, cur_gain * 1.4125)  # +3dB
                self.project.update_audio_clip_params(str(clip.id), gain=new_gain)
                import math
                db = 20.0 * math.log10(max(1e-10, new_gain))
                self.status_message.emit(f"Gain → {db:+.1f} dB")
                self.refresh()
            except Exception:
                self.status_message.emit("Gain +3 dB (Fehler)")
            return

        if a == "-3 dB":
            try:
                cur_gain = float(getattr(clip, "gain", 1.0) or 1.0)
                new_gain = max(0.01, cur_gain * 0.7079)  # -3dB
                self.project.update_audio_clip_params(str(clip.id), gain=new_gain)
                import math
                db = 20.0 * math.log10(max(1e-10, new_gain))
                self.status_message.emit(f"Gain → {db:+.1f} dB")
                self.refresh()
            except Exception:
                self.status_message.emit("Gain -3 dB (Fehler)")
            return

        if a == "+6 dB":
            try:
                cur_gain = float(getattr(clip, "gain", 1.0) or 1.0)
                new_gain = min(4.0, cur_gain * 1.9953)  # +6dB
                self.project.update_audio_clip_params(str(clip.id), gain=new_gain)
                import math
                db = 20.0 * math.log10(max(1e-10, new_gain))
                self.status_message.emit(f"Gain → {db:+.1f} dB")
                self.refresh()
            except Exception:
                self.status_message.emit("Gain +6 dB (Fehler)")
            return

        if a == "-6 dB":
            try:
                cur_gain = float(getattr(clip, "gain", 1.0) or 1.0)
                new_gain = max(0.01, cur_gain * 0.5012)  # -6dB
                self.project.update_audio_clip_params(str(clip.id), gain=new_gain)
                import math
                db = 20.0 * math.log10(max(1e-10, new_gain))
                self.status_message.emit(f"Gain → {db:+.1f} dB")
                self.refresh()
            except Exception:
                self.status_message.emit("Gain -6 dB (Fehler)")
            return

        if a == "Reset (0 dB)":
            try:
                self.project.update_audio_clip_params(str(clip.id), gain=1.0)
                self.status_message.emit("Gain → 0 dB")
                self.refresh()
            except Exception:
                pass
            return

        # --- Fade actions ---
        if a.startswith("Fade In "):
            fade_map = {"1/16": 0.25, "1/8": 0.5, "1/4": 1.0, "1 Bar": 4.0}
            suffix = a.replace("Fade In ", "")
            beats = fade_map.get(suffix, 0.25)
            try:
                self.project.update_audio_clip_params(str(clip.id), fade_in_beats=beats)
                self.status_message.emit(f"Fade In → {suffix}")
                self.refresh()
            except Exception:
                self.status_message.emit("Fade In (Fehler)")
            return

        if a.startswith("Fade Out "):
            fade_map = {"1/16": 0.25, "1/8": 0.5, "1/4": 1.0, "1 Bar": 4.0}
            suffix = a.replace("Fade Out ", "")
            beats = fade_map.get(suffix, 0.25)
            try:
                self.project.update_audio_clip_params(str(clip.id), fade_out_beats=beats)
                self.status_message.emit(f"Fade Out → {suffix}")
                self.refresh()
            except Exception:
                self.status_message.emit("Fade Out (Fehler)")
            return

        if a == "Clear Fades":
            try:
                self.project.update_audio_clip_params(str(clip.id), fade_in_beats=0.0, fade_out_beats=0.0)
                self.status_message.emit("Fades gelöscht")
                self.refresh()
            except Exception:
                pass
            return

        # --- Transpose octave ---
        if a == "+12 Semitone (Octave Up)":
            try:
                self.project.update_audio_clip_params(
                    str(clip.id), pitch=float(getattr(clip, "pitch", 0.0) or 0.0) + 12.0
                )
                self.status_message.emit("Pitch +12 (Octave Up)")
            except Exception:
                pass
            return

        if a == "-12 Semitone (Octave Down)":
            try:
                self.project.update_audio_clip_params(
                    str(clip.id), pitch=float(getattr(clip, "pitch", 0.0) or 0.0) - 12.0
                )
                self.status_message.emit("Pitch -12 (Octave Down)")
            except Exception:
                pass
            return

        # --- Onset actions ---
        if a == "Auto-Detect Onsets":
            try:
                onsets = self.project.detect_onsets(str(clip.id))
                count = len(onsets) if onsets else 0
                self.status_message.emit(f"Onsets erkannt: {count}")
                # Auto-enable onset display
                self._show_onsets = True
                try:
                    b = self._btns.get('Onsets')
                    if b:
                        b.setChecked(True)
                except Exception:
                    pass
                self.refresh()
            except Exception:
                self.status_message.emit("Onset-Erkennung (Fehler)")
            return

        if a == "Add Onset at Playhead":
            try:
                t = self._local_playhead_beats(clip)
                self.project.add_onset_at(str(clip.id), float(t))
                self.status_message.emit(f"Onset @ {t:0.2f}")
                self._show_onsets = True
                try:
                    b = self._btns.get('Onsets')
                    if b:
                        b.setChecked(True)
                except Exception:
                    pass
                self.refresh()
            except Exception:
                self.status_message.emit("Onset hinzufügen (Fehler)")
            return

        if a == "Slice at Onsets":
            try:
                count = self.project.slice_at_onsets(str(clip.id))
                self.status_message.emit(f"Sliced at {count} onsets")
                self.refresh()
            except Exception:
                self.status_message.emit("Slice at Onsets (Fehler)")
            return

        if a == "Clear Onsets":
            try:
                self.project.clear_onsets(str(clip.id))
                self.status_message.emit("Onsets gelöscht")
                self.refresh()
            except Exception:
                self.status_message.emit("Clear Onsets (Fehler)")
            return

        # --- Zero-Crossing ---
        if a == "Snap to Zero-Crossing":
            try:
                t = self._local_playhead_beats(clip)
                zc = self.project.find_zero_crossings(str(clip.id), float(t))
                self.status_message.emit(f"Zero-Crossing @ {zc:0.4f} beats")
            except Exception:
                self.status_message.emit("Zero-Crossing (Fehler)")
            return

        # --- Clip Automation ---
        if a == "Clear Gain Automation":
            try:
                self.project.clear_clip_automation(str(clip.id), "gain")
                self.status_message.emit("Gain Automation gelöscht")
                self.refresh()
            except Exception:
                pass
            return

        if a == "Clear Pan Automation":
            try:
                self.project.clear_clip_automation(str(clip.id), "pan")
                self.status_message.emit("Pan Automation gelöscht")
                self.refresh()
            except Exception:
                pass
            return

        if a == "Clear Pitch Automation":
            try:
                self.project.clear_clip_automation(str(clip.id), "pitch")
                self.status_message.emit("Pitch Automation gelöscht")
                self.refresh()
            except Exception:
                pass
            return

        if a == "Clear All Clip Automation":
            try:
                self.project.clear_clip_automation(str(clip.id))
                self.status_message.emit("Alle Clip-Automation gelöscht")
                self.refresh()
            except Exception:
                pass
            return

    # helpers
    def _local_playhead_beats(self, clip) -> float:  # noqa: ANN001
        gb = 0.0
        try:
            if self.transport is not None:
                gb = float(getattr(self.transport, "current_beat", getattr(self.transport, "beat", 0.0)) or 0.0)
        except Exception:
            gb = 0.0

        length = max(1e-6, float(getattr(clip, "length_beats", 4.0) or 4.0))
        ls = float(getattr(clip, "loop_start_beats", 0.0) or 0.0)
        le = float(getattr(clip, "loop_end_beats", 0.0) or 0.0)
        if le > ls + 1e-6:
            L = max(1e-6, le - ls)
            return ls + (gb % L)
        return gb % length

    def _render_clip_automation(self, clip, width: float, height: float) -> None:
        """Render automation envelope lines for the current parameter (Bitwig/Ableton-style)."""
        scene = self._scene
        if scene is None:
            return

        self._auto_items = []
        self._auto_point_items = []

        auto = getattr(clip, 'clip_automation', None)
        if not auto or not isinstance(auto, dict):
            return

        param = str(self._auto_param or "gain").lower()
        pts = auto.get(param, [])
        if not pts:
            return

        # Color per parameter
        colors = {
            "gain": QColor(0, 255, 128),    # green
            "pan": QColor(255, 200, 0),     # yellow
            "pitch": QColor(0, 180, 255),   # blue
            "formant": QColor(255, 100, 255),  # magenta
        }
        color = colors.get(param, QColor(0, 255, 128))

        # Draw lines between breakpoints
        sorted_pts = sorted(pts, key=lambda p: float(p.get("beat", 0)))
        pen = QPen(color)
        pen.setWidthF(2.0)

        for i in range(len(sorted_pts) - 1):
            p0 = sorted_pts[i]
            p1 = sorted_pts[i + 1]
            x0 = float(p0.get("beat", 0)) * self._px_per_beat
            x1 = float(p1.get("beat", 0)) * self._px_per_beat
            v0 = float(p0.get("value", 0.5))
            v1 = float(p1.get("value", 0.5))
            y0 = height - (v0 * height)
            y1 = height - (v1 * height)

            line = QGraphicsLineItem(x0, y0, x1, y1)
            line.setZValue(40)
            line.setPen(pen)
            line.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
            scene.addItem(line)
            self._auto_items.append(line)

        # Draw breakpoint dots
        dot_size = 8.0
        brush = QBrush(color)
        pen_dot = QPen(color.darker(140))
        pen_dot.setWidth(1)

        for pt in sorted_pts:
            bx = float(pt.get("beat", 0)) * self._px_per_beat
            v = float(pt.get("value", 0.5))
            by = height - (v * height)

            dot = QGraphicsRectItem(
                QRectF(bx - dot_size / 2, by - dot_size / 2, dot_size, dot_size)
            )
            dot.setZValue(41)
            dot.setBrush(brush)
            dot.setPen(pen_dot)
            dot.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
            scene.addItem(dot)
            self._auto_point_items.append(dot)

    def _render_fade_overlays(self, clip, width: float, height: float) -> None:
        """Render fade in/out triangular overlays + draggable handles (Bitwig-style)."""
        scene = self._scene
        if scene is None:
            return

        fi = float(getattr(clip, 'fade_in_beats', 0.0) or 0.0)
        fo = float(getattr(clip, 'fade_out_beats', 0.0) or 0.0)

        # Fade In overlay (dark triangle, left side)
        if fi > 0.001:
            try:
                fi_px = fi * self._px_per_beat
                path = QPainterPath()
                path.moveTo(0.0, 0.0)
                path.lineTo(fi_px, 0.0)
                path.lineTo(0.0, height)
                path.closeSubpath()
                item = QGraphicsPathItem(path)
                item.setZValue(25)
                item.setBrush(QBrush(QColor(0, 0, 0, 80)))
                pen = QPen(QColor(255, 165, 0))
                pen.setWidth(2)
                item.setPen(pen)
                item.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
                scene.addItem(item)
                self._fade_in_overlay = item
            except Exception:
                pass

        # Fade Out overlay (dark triangle, right side)
        if fo > 0.001:
            try:
                fo_px = fo * self._px_per_beat
                x_start = width - fo_px
                path = QPainterPath()
                path.moveTo(width, 0.0)
                path.lineTo(x_start, 0.0)
                path.lineTo(width, height)
                path.closeSubpath()
                item = QGraphicsPathItem(path)
                item.setZValue(25)
                item.setBrush(QBrush(QColor(0, 0, 0, 80)))
                pen = QPen(QColor(100, 149, 237))
                pen.setWidth(2)
                item.setPen(pen)
                item.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
                scene.addItem(item)
                self._fade_out_overlay = item
            except Exception:
                pass

        # Fade In handle (draggable triangle at fade boundary)
        fi_x = fi * self._px_per_beat
        handle_in = _FadeHandle(fi_x, height, role="fade_in",
                                on_moved=lambda x: self._on_fade_handle_moved("in", x))
        scene.addItem(handle_in)
        self._fade_in_handle = handle_in

        # Fade Out handle (draggable triangle at fade boundary)
        fo_x = width - fo * self._px_per_beat
        handle_out = _FadeHandle(fo_x, height, role="fade_out",
                                 on_moved=lambda x: self._on_fade_handle_moved("out", x))
        scene.addItem(handle_out)
        self._fade_out_handle = handle_out

    def _on_fade_handle_moved(self, which: str, x_pixels: float) -> None:
        """Handle drag of fade in/out handles."""
        if self._fade_update_guard:
            return
        self._fade_update_guard = True
        try:
            clip = self._get_clip()
            if not clip:
                return
            length_beats = float(getattr(clip, "length_beats", 4.0) or 4.0)
            max_fade = length_beats * 0.5  # max 50% of clip

            if which == "in":
                beats = max(0.0, min(max_fade, float(x_pixels) / self._px_per_beat))
                self._suppress_project_refresh = True
                try:
                    self.project.update_audio_clip_params(str(clip.id), fade_in_beats=beats)
                finally:
                    self._suppress_project_refresh = False
                # Update overlay live
                if self._fade_in_overlay and self._scene:
                    try:
                        self._scene.removeItem(self._fade_in_overlay)
                    except Exception:
                        pass
                    self._fade_in_overlay = None
                    if beats > 0.001:
                        try:
                            fi_px = beats * self._px_per_beat
                            path = QPainterPath()
                            path.moveTo(0.0, 0.0)
                            path.lineTo(fi_px, 0.0)
                            path.lineTo(0.0, self._clip_height)
                            path.closeSubpath()
                            item = QGraphicsPathItem(path)
                            item.setZValue(25)
                            item.setBrush(QBrush(QColor(0, 0, 0, 80)))
                            pen = QPen(QColor(255, 165, 0))
                            pen.setWidth(2)
                            item.setPen(pen)
                            item.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
                            self._scene.addItem(item)
                            self._fade_in_overlay = item
                        except Exception:
                            pass
            else:  # "out"
                width_px = self._clip_width_px
                fo_px = max(0.0, width_px - float(x_pixels))
                beats = max(0.0, min(max_fade, fo_px / self._px_per_beat))
                self._suppress_project_refresh = True
                try:
                    self.project.update_audio_clip_params(str(clip.id), fade_out_beats=beats)
                finally:
                    self._suppress_project_refresh = False
                # Update overlay live
                if self._fade_out_overlay and self._scene:
                    try:
                        self._scene.removeItem(self._fade_out_overlay)
                    except Exception:
                        pass
                    self._fade_out_overlay = None
                    if beats > 0.001:
                        try:
                            fo_px_d = beats * self._px_per_beat
                            x_start = width_px - fo_px_d
                            path = QPainterPath()
                            path.moveTo(width_px, 0.0)
                            path.lineTo(x_start, 0.0)
                            path.lineTo(width_px, self._clip_height)
                            path.closeSubpath()
                            item = QGraphicsPathItem(path)
                            item.setZValue(25)
                            item.setBrush(QBrush(QColor(0, 0, 0, 80)))
                            pen = QPen(QColor(100, 149, 237))
                            pen.setWidth(2)
                            item.setPen(pen)
                            item.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
                            self._scene.addItem(item)
                            self._fade_out_overlay = item
                        except Exception:
                            pass
        finally:
            self._fade_update_guard = False

    def _ensure_loop_items(self, clip, width: float, height: float) -> None:  # noqa: ANN001
        scene = self._scene
        if scene is None:
            return

        s = float(getattr(clip, "loop_start_beats", 0.0) or 0.0)
        e = float(getattr(clip, "loop_end_beats", 0.0) or 0.0)
        length_beats = float(getattr(clip, "length_beats", 0.0) or 0.0)

        if e <= s + 1e-6:
            s = 0.0
            e = max(0.0, length_beats)

        x0 = s * self._px_per_beat
        x1 = e * self._px_per_beat

        rect = QGraphicsRectItem(QRectF(x0, 0.0, max(1.0, x1 - x0), height))
        rect.setZValue(10)
        rect.setBrush(QBrush(self.palette().highlight().color()))
        rect.setOpacity(0.10)
        rect.setPen(QPen(Qt.PenStyle.NoPen))
        rect.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
        scene.addItem(rect)
        self._loop_rect = rect

        start_edge = _LoopEdge(x0, height, color_role="start")
        end_edge = _LoopEdge(x1, height, color_role="end")
        scene.addItem(start_edge)
        scene.addItem(end_edge)
        self._loop_start_edge = start_edge
        self._loop_end_edge = end_edge

        start_edge.set_on_moved(lambda x: self._on_loop_edge_moved("start", x))
        end_edge.set_on_moved(lambda x: self._on_loop_edge_moved("end", x))

        start_edge.setPos(QPointF(x0, 0.0))
        end_edge.setPos(QPointF(x1, 0.0))

    def _on_loop_edge_moved(self, which: str, x_pixels: float) -> None:
        # This callback is executed from within QGraphicsItem.itemChange.
        # Calling refresh() (via project_updated) while an itemChange is running will crash Qt.
        # We therefore:
        # 1) use a re-entrancy guard for setPos feedback loops
        # 2) suppress our own refresh while we update the model
        if self._loop_update_guard:
            return

        self._loop_update_guard = True
        try:
            clip = self._get_clip()
            if not clip:
                return

            length_beats = float(getattr(clip, "length_beats", 0.0) or 0.0)
            length_px = max(0.0, length_beats * self._px_per_beat)
            x = max(0.0, min(float(x_pixels), length_px))

            s = float(getattr(clip, "loop_start_beats", 0.0) or 0.0)
            e = float(getattr(clip, "loop_end_beats", 0.0) or 0.0)
            if e <= s + 1e-6:
                s = 0.0
                e = max(0.0, length_beats)

            if which == "start":
                s = x / self._px_per_beat
            else:
                e = x / self._px_per_beat

            # enforce a small minimum loop size
            if e <= s + 1e-6:
                e = min(max(0.0, length_beats), s + 0.25)

            # clamp
            s = max(0.0, min(s, max(0.0, length_beats)))
            e = max(0.0, min(e, max(0.0, length_beats)))

            pair = (round(s, 6), round(e, 6))
            if self._last_loop_pair is not None and pair == self._last_loop_pair:
                # nothing changed (prevents spamming signals)
                return
            self._last_loop_pair = pair

            # Update overlay immediately (no scene rebuild)
            x0 = s * self._px_per_beat
            x1 = e * self._px_per_beat
            if self._loop_rect:
                self._loop_rect.setRect(QRectF(x0, 0.0, max(1.0, x1 - x0), self._loop_rect.rect().height()))
            if self._loop_start_edge:
                self._loop_start_edge.setPos(QPointF(x0, 0.0))
            if self._loop_end_edge:
                self._loop_end_edge.setPos(QPointF(x1, 0.0))

            # Persist to model (and let other UI update), but do not refresh THIS editor synchronously.
            self._suppress_project_refresh = True
            try:
                self.project.set_audio_clip_loop(str(clip.id), float(s), float(e))
            finally:
                self._suppress_project_refresh = False
        finally:
            self._loop_update_guard = False

    def _get_clip(self):
        if not self._clip_id:
            return None
        return next((c for c in self.project.ctx.project.clips if getattr(c, "id", "") == self._clip_id), None)

    def _draw_waveform(self, abs_path: str, width: float, height: float, *, gain: float = 1.0, reversed_display: bool = False) -> None:
        scene = self._scene
        if scene is None:
            return
        if sf is None or np is None:
            t = scene.addText("Waveform: soundfile/numpy nicht verfügbar.")
            t.setDefaultTextColor(self.palette().mid().color())
            return

        try:
            data, sr = sf.read(abs_path, always_2d=True, dtype="float32")
        except Exception as e:
            t = scene.addText(f"Waveform: Fehler beim Laden: {e}")
            t.setDefaultTextColor(self.palette().mid().color())
            return

        if data.size == 0:
            return

        n = data.shape[0]
        target_points = int(max(512, min(8000, width)))
        block = max(1, n // target_points)

        mono = data.mean(axis=1)
        mono = mono * float(gain)

        blocks = int(math.ceil(n / block))
        mins = np.empty(blocks, dtype=np.float32)
        maxs = np.empty(blocks, dtype=np.float32)
        for i in range(blocks):
            a = i * block
            b = min(n, (i + 1) * block)
            seg = mono[a:b]
            mins[i] = float(seg.min()) if seg.size else 0.0
            maxs[i] = float(seg.max()) if seg.size else 0.0

        # Reverse display: flip the waveform data
        if reversed_display:
            mins = mins[::-1].copy()
            maxs = maxs[::-1].copy()

        mid_y = height * 0.5
        amp = height * 0.42
        path = QPainterPath()

        for i in range(blocks):
            x = (i / max(1, blocks - 1)) * width
            y = mid_y - maxs[i] * amp
            if i == 0:
                path.moveTo(x, y)
            else:
                path.lineTo(x, y)

        for i in range(blocks - 1, -1, -1):
            x = (i / max(1, blocks - 1)) * width
            y = mid_y - mins[i] * amp
            path.lineTo(x, y)

        path.closeSubpath()

        item = QGraphicsPathItem(path)
        item.setZValue(12)
        pen = QPen(self.palette().text().color())
        pen.setWidth(1)
        item.setPen(pen)
        item.setBrush(QBrush(self.palette().mid().color()))
        item.setOpacity(0.35)
        item.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
        scene.addItem(item)
        self._wave_item = item
