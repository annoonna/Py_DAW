# -*- coding: utf-8 -*-
"""FX Specs (built-in) for ChronoScaleStudio.

This is the "Browser catalog" of built-in Note-FX + Audio-FX modules.
Important UX rule (Bitwig/Ableton style):
- Browser entries are templates.
- Dragging/double-clicking creates a NEW instance on the track device chain.
- The browser catalog never disappears.

Keep this list small and stable; add more devices over time.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any, List


@dataclass(frozen=True)
class FxSpec:
    kind: str          # "note_fx" | "audio_fx"
    plugin_id: str
    name: str
    defaults: Dict[str, Any]


def get_note_fx() -> List[FxSpec]:
    return [
        FxSpec("note_fx", "chrono.note_fx.transpose", "Transpose", {"semitones": 0}),
        FxSpec("note_fx", "chrono.note_fx.velocity_scale", "VelScale", {"scale": 1.0}),
        FxSpec("note_fx", "chrono.note_fx.scale_snap", "ScaleSnap", {"root": 0, "scale": "major", "mode": "nearest"}),
        FxSpec("note_fx", "chrono.note_fx.chord", "Chord", {"chord": "maj"}),
        FxSpec("note_fx", "chrono.note_fx.arp", "Arp", {"step_beats": 0.5, "mode": "up", "octaves": 1, "gate": 0.9}),
        FxSpec("note_fx", "chrono.note_fx.random", "Random", {"pitch_range": 0, "vel_range": 0, "prob": 1.0}),
    ]


def get_audio_fx() -> List[FxSpec]:
    # NOTE: "CHAIN" (container) is not a draggable device — it is always present per track.
    return [
        FxSpec("audio_fx", "chrono.fx.gain", "Gain", {"gain_db": 0.0, "gain": 1.0}),
        FxSpec("audio_fx", "chrono.fx.distortion", "Distortion", {"drive": 0.25, "mix": 1.0}),
        # ── v105: 15 Bitwig-Style Audio-FX ──────────────────────
        FxSpec("audio_fx", "chrono.fx.eq5", "EQ-5", {}),
        FxSpec("audio_fx", "chrono.fx.delay2", "Delay-2", {}),
        FxSpec("audio_fx", "chrono.fx.reverb", "Reverb", {}),
        FxSpec("audio_fx", "chrono.fx.comb", "Comb", {}),
        FxSpec("audio_fx", "chrono.fx.compressor", "Compressor", {}),
        FxSpec("audio_fx", "chrono.fx.filter_plus", "Filter+", {}),
        FxSpec("audio_fx", "chrono.fx.distortion_plus", "Distortion+", {}),
        FxSpec("audio_fx", "chrono.fx.dynamics", "Dynamics", {}),
        FxSpec("audio_fx", "chrono.fx.flanger", "Flanger", {}),
        FxSpec("audio_fx", "chrono.fx.pitch_shifter", "Pitch Shifter", {}),
        FxSpec("audio_fx", "chrono.fx.tremolo", "Tremolo", {}),
        FxSpec("audio_fx", "chrono.fx.peak_limiter", "Peak Limiter", {}),
        FxSpec("audio_fx", "chrono.fx.chorus", "Chorus", {}),
        FxSpec("audio_fx", "chrono.fx.xy_fx", "XY FX", {}),
        FxSpec("audio_fx", "chrono.fx.de_esser", "De-Esser", {}),
    ]
