# Session: v0.0.20.608 — Bitwig-Style MIDI Input Routing
**Date:** 2026-03-18 | **Author:** Claude Opus 4.6

## 1 Version, 5 Dateien, nichts kaputt

### Was wurde gebaut
Bitwig-Style MIDI Input Routing pro Track:
- Track-Model: `midi_input` Feld mit Auto-Default (Instrument→"All ins", Audio→"No input")
- MidiManager: Source-Port Tagging, `_midi_input_accepts()` Filter, `inject_message()` API
- Arranger UI: Kategorisiertes Dropdown-Menü (NOTE INPUTS / Add Controller / TRACKS)
- Output-Label: "→ Master" / "→ Group" neben MIDI Input

### Routing-Regeln (Bitwig-konform)
| Einstellung | Akzeptiert |
|-------------|-----------|
| No input | Nichts |
| All ins | Alle Hardware-Ports (nicht Computer Keyboard) |
| Computer Keyboard | Nur QWERTY-Keyboard Events |
| Spezifischer Port | Nur dieser Port |
| track:<id> | Internes MIDI von anderem Track |

### Nächste Schritte
1. Computer Keyboard MIDI (QWERTY → inject_message)
2. MIDI Channel Filter pro Track
3. Touch Keyboard Widget
4. Track-to-Track MIDI Routing (Engine-Level)
5. OSC Input Source

### Nichts kaputt gemacht ✓
