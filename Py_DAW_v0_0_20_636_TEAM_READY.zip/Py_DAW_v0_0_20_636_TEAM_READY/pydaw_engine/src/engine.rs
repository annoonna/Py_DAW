use std::sync::Arc;

use crossbeam_channel::{Receiver, Sender};
use log::{error, info, warn};
use parking_lot::Mutex;

use crate::audio_graph::AudioGraph;
use crate::clip_renderer::{ArrangementRenderer, ArrangementSnapshot, AudioClipData, ClipStore, PlacedClip};
use crate::ipc::{Command, Event, TrackMeterLevel};
use crate::lock_free::ParamRing;
use crate::transport::Transport;

// ============================================================================
// Engine — The core audio engine coordinator
// ============================================================================
//
// Ownership model:
//   - Engine owns AudioGraph + Transport + ClipStore + ArrangementRenderer
//   - Audio callback borrows via Arc (lock-free reads)
//   - IPC handler sends Commands via crossbeam channel
//   - ParamRing: GUI writes, Audio thread drains (lock-free SPSC)
//
// Thread model:
//   - Main thread: IPC server
//   - Audio thread: cpal callback → drain params → render clips → process graph → output
//   - GUI thread: Python (separate process, connected via IPC)
// ============================================================================

/// Shared engine state, accessible from both IPC handler and audio callback.
pub struct EngineState {
    pub graph: Mutex<AudioGraph>,
    pub transport: Arc<Transport>,
    pub command_rx: Receiver<Command>,
    pub event_tx: Sender<Event>,
    pub running: std::sync::atomic::AtomicBool,

    /// Lock-free parameter ring (GUI → Audio thread).
    pub param_ring: Arc<ParamRing>,

    /// Audio clip data store (RwLock-protected, shared with renderer).
    pub clip_store: Arc<ClipStore>,

    /// Arrangement renderer (reads clips, writes into track buffers).
    pub renderer: ArrangementRenderer,

    /// Meter update counter — only send meter events every N process cycles (~30Hz).
    meter_counter: std::sync::atomic::AtomicU32,
    /// XRun counter.
    xrun_count: std::sync::atomic::AtomicU32,
}

impl EngineState {
    pub fn new(
        sample_rate: u32,
        buffer_size: u32,
        bpm: f64,
        command_rx: Receiver<Command>,
        event_tx: Sender<Event>,
    ) -> Self {
        let clip_store = Arc::new(ClipStore::new());
        let renderer = ArrangementRenderer::new(Arc::clone(&clip_store));
        Self {
            graph: Mutex::new(AudioGraph::new(buffer_size as usize, sample_rate)),
            transport: Arc::new(Transport::new(sample_rate, bpm)),
            command_rx,
            event_tx,
            running: std::sync::atomic::AtomicBool::new(true),
            param_ring: Arc::new(ParamRing::new()),
            clip_store,
            renderer,
            meter_counter: std::sync::atomic::AtomicU32::new(0),
            xrun_count: std::sync::atomic::AtomicU32::new(0),
        }
    }

    /// Process all pending commands from the IPC queue.
    /// Called at the start of each audio callback — MUST be fast.
    pub fn drain_commands(&self) {
        // Drain up to 64 commands per callback to prevent starvation
        for _ in 0..64 {
            match self.command_rx.try_recv() {
                Ok(cmd) => self.handle_command(cmd),
                Err(_) => break,
            }
        }
    }

    /// Handle a single command.
    fn handle_command(&self, cmd: Command) {
        match cmd {
            Command::Play => {
                self.transport.playing.store(true, std::sync::atomic::Ordering::Release);
                let _ = self.event_tx.try_send(Event::TransportState {
                    is_playing: true,
                    beat: self.transport.position_beats(),
                });
            }
            Command::Stop => {
                self.transport.playing.store(false, std::sync::atomic::Ordering::Release);
                self.transport.seek_to_sample(0);
                let _ = self.event_tx.try_send(Event::TransportState {
                    is_playing: false,
                    beat: 0.0,
                });
            }
            Command::Pause => {
                self.transport.playing.store(false, std::sync::atomic::Ordering::Release);
                let _ = self.event_tx.try_send(Event::TransportState {
                    is_playing: false,
                    beat: self.transport.position_beats(),
                });
            }
            Command::Seek { beat } => {
                self.transport.seek_to_beat(beat);
            }
            Command::SetTempo { bpm } => {
                self.transport.set_bpm(bpm);
            }
            Command::SetTimeSignature {
                numerator,
                denominator,
            } => {
                self.transport.set_time_signature(numerator, denominator);
            }
            Command::SetLoop {
                enabled,
                start_beat,
                end_beat,
            } => {
                self.transport.set_loop(enabled, start_beat, end_beat);
            }
            Command::AddTrack {
                track_id,
                track_index,
                kind,
            } => {
                let tk = crate::audio_graph::TrackKind::from_str(&kind);
                let mut graph = self.graph.lock();
                graph.add_track(track_id, track_index, tk);
            }
            Command::RemoveTrack { track_id } => {
                let mut graph = self.graph.lock();
                graph.remove_track(&track_id);
            }
            Command::SetTrackParam {
                track_index,
                param,
                value,
            } => {
                let graph = self.graph.lock();
                if let Some(track) = graph.get_track(track_index) {
                    track.set_param(param, value);
                }
            }
            Command::SetMasterParam { param, value } => {
                let graph = self.graph.lock();
                if let Some(master_idx) = graph.master_index() {
                    if let Some(track) = graph.get_track(master_idx) {
                        track.set_param(param, value);
                    }
                }
            }
            Command::SetGroupRouting {
                child_track_index,
                group_track_index,
            } => {
                let mut graph = self.graph.lock();
                graph.set_group_routing(child_track_index, group_track_index);
            }
            Command::Configure {
                sample_rate,
                buffer_size,
                device,
            } => {
                info!(
                    "Configure: sr={}, buf={}, dev='{}'",
                    sample_rate, buffer_size, device
                );
                self.transport.set_sample_rate(sample_rate);
                let mut graph = self.graph.lock();
                graph.sample_rate = sample_rate;
                graph.resize_buffers(buffer_size as usize);
                let _ = self.event_tx.try_send(Event::Ready {
                    sample_rate,
                    buffer_size,
                    device_name: device,
                });
            }
            Command::Ping { seq } => {
                let _ = self.event_tx.try_send(Event::Pong {
                    seq,
                    cpu_load: 0.0, // TODO: measure
                    xrun_count: self
                        .xrun_count
                        .load(std::sync::atomic::Ordering::Relaxed),
                });
            }
            Command::Shutdown => {
                info!("Shutdown command received");
                self.running
                    .store(false, std::sync::atomic::Ordering::Release);
                let _ = self.event_tx.try_send(Event::ShuttingDown);
            }
            // -- Audio Data (Phase 1B) ------------------------------------
            Command::LoadAudioClip {
                clip_id,
                channels,
                sample_rate,
                audio_b64,
            } => {
                match AudioClipData::from_base64(clip_id.clone(), channels, sample_rate, &audio_b64)
                {
                    Ok(clip) => {
                        info!(
                            "Loaded audio clip '{}': {}ch, {}Hz, {} frames",
                            clip_id, channels, sample_rate, clip.frame_count
                        );
                        self.clip_store.insert(clip);
                    }
                    Err(e) => {
                        error!("Failed to decode audio clip '{}': {}", clip_id, e);
                        let _ = self.event_tx.try_send(Event::Error {
                            code: 100,
                            message: format!("LoadAudioClip failed: {}", e),
                        });
                    }
                }
            }
            Command::SetArrangement { clips } => {
                let bpm = self.transport.bpm();
                let sr = self.transport.sample_rate() as u32;
                let placed: Vec<PlacedClip> = clips
                    .iter()
                    .map(|c| PlacedClip::from_ipc(c, sr, bpm))
                    .collect();
                let snapshot = ArrangementSnapshot::new(placed);
                info!(
                    "Arrangement updated: {} clips on {} tracks",
                    snapshot.clips.len(),
                    snapshot.clips_by_track.len()
                );
                self.renderer.set_arrangement(snapshot);
            }
            Command::LoadPlugin { .. }
            | Command::UnloadPlugin { .. }
            | Command::SetPluginParam { .. }
            | Command::SavePluginState { .. }
            | Command::LoadPluginState { .. } => {
                warn!("Plugin commands not yet implemented (Phase 1C)");
            }
            Command::MidiNoteOn { .. }
            | Command::MidiNoteOff { .. }
            | Command::MidiCC { .. } => {
                warn!("MIDI commands not yet implemented (Phase 1B)");
            }
        }
    }

    /// Called from the audio callback. Processes the graph and returns output.
    /// The output samples should be written to the audio device.
    pub fn process_audio(&self, output: &mut [f32], frames: usize, channels: usize) {
        // 1. Drain pending commands
        self.drain_commands();

        // 2. Drain lock-free parameter ring (GUI → audio thread)
        {
            let graph = self.graph.lock();
            self.param_ring.drain(|param_id, value| {
                // Decode param_id: high 16 bits = track_index, low 16 bits = param type
                let track_idx = (param_id >> 16) as u16;
                let param_type = (param_id & 0xFFFF) as u16;
                if let Some(track) = graph.get_track(track_idx) {
                    match param_type {
                        0 => track.set_param(crate::ipc::TrackParam::Volume, value),
                        1 => track.set_param(crate::ipc::TrackParam::Pan, value),
                        2 => track.set_param(crate::ipc::TrackParam::Mute, value),
                        3 => track.set_param(crate::ipc::TrackParam::Solo, value),
                        _ => {}
                    }
                }
            });
        }

        // 3. Render arrangement clips into track buffers
        {
            let mut graph = self.graph.lock();
            graph.silence_all();

            // Phase 1B: Render clips from ArrangementRenderer
            let position = self.transport.position_samples();
            let sr = graph.sample_rate;
            if self.transport.playing.load(std::sync::atomic::Ordering::Relaxed) {
                self.renderer.render_all_tracks(&mut graph, position, frames, sr);
            }

            // 4. Process the audio graph (apply volume/pan/mute/solo, mix to master)
            let master_buf = graph.process();

            // 5. Copy master output to device buffer
            let copy_len = (frames * channels).min(output.len()).min(master_buf.data.len());
            output[..copy_len].copy_from_slice(&master_buf.data[..copy_len]);

            // Zero any remaining output samples
            if copy_len < output.len() {
                output[copy_len..].fill(0.0);
            }

            // 4. Send meter levels (~30Hz)
            let counter = self
                .meter_counter
                .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            let sr = self.transport.sample_rate() as u32;
            let meter_interval = if sr > 0 { sr / (frames as u32 * 30).max(1) } else { 50 };

            if counter % meter_interval.max(1) == 0 {
                // Master meters
                let (pl, pr) = master_buf.peak_levels();
                let (rl, rr) = master_buf.rms_levels();
                let _ = self.event_tx.try_send(Event::MasterMeterLevel {
                    peak_l: pl,
                    peak_r: pr,
                    rms_l: rl,
                    rms_r: rr,
                });

                // Track meters
                let track_meters: Vec<TrackMeterLevel> = graph
                    .all_track_meters()
                    .into_iter()
                    .map(|(idx, pl, pr, rl, rr)| TrackMeterLevel {
                        track_index: idx,
                        peak_l: pl,
                        peak_r: pr,
                        rms_l: rl,
                        rms_r: rr,
                    })
                    .collect();

                if !track_meters.is_empty() {
                    let _ = self.event_tx.try_send(Event::MeterLevels {
                        levels: track_meters,
                    });
                }
            }
        }

        // 5. Advance transport
        self.transport.advance(frames);

        // 6. Send playhead position (~30Hz, reuse meter counter)
        let counter = self
            .meter_counter
            .load(std::sync::atomic::Ordering::Relaxed);
        let sr = self.transport.sample_rate() as u32;
        let meter_interval = if sr > 0 {
            sr / (frames as u32 * 30).max(1)
        } else {
            50
        };
        if counter % meter_interval.max(1) == 0 {
            let _ = self.event_tx.try_send(Event::PlayheadPosition {
                beat: self.transport.position_beats(),
                sample_position: self.transport.position_samples(),
                is_playing: self
                    .transport
                    .playing
                    .load(std::sync::atomic::Ordering::Relaxed),
            });
        }
    }

    /// Record an xrun.
    pub fn record_xrun(&self) {
        self.xrun_count
            .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    }
}
