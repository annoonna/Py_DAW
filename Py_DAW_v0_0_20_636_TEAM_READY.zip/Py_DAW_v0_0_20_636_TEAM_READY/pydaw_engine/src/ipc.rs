use serde::{Deserialize, Serialize};

// ============================================================================
// IPC Protocol for Py_DAW Audio Engine
// ============================================================================
//
// Transport: Unix Domain Socket (stream mode)
// Encoding:  MessagePack (rmp-serde)
// Framing:   [u32 LE length][msgpack payload]
//
// Direction:
//   Command  = Python GUI  →  Rust Engine
//   Event    = Rust Engine  →  Python GUI
//
// Design rules:
//   - No heap allocations in audio thread — commands are queued, events are pooled
//   - All parameter IDs are u32 (same as RTParamStore keys in Python)
//   - Track indices are u16 (max 65535 tracks, plenty)
//   - Sample positions are i64 (signed, for pre-roll)
// ============================================================================

// ---------------------------------------------------------------------------
// Commands: Python → Rust
// ---------------------------------------------------------------------------

/// Top-level command envelope sent from Python to Rust.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "cmd")]
pub enum Command {
    // -- Transport --------------------------------------------------------
    /// Start playback from current position.
    Play,

    /// Stop playback (reset to last play-start position).
    Stop,

    /// Pause playback (keep current position).
    Pause,

    /// Seek to a specific beat position.
    Seek { beat: f64 },

    /// Set tempo in BPM.
    SetTempo { bpm: f64 },

    /// Set time signature (numerator, denominator).
    SetTimeSignature { numerator: u8, denominator: u8 },

    /// Enable/disable loop region.
    SetLoop {
        enabled: bool,
        start_beat: f64,
        end_beat: f64,
    },

    // -- Audio Graph -------------------------------------------------------
    /// Add a track node to the audio graph.
    AddTrack {
        track_id: String,
        track_index: u16,
        /// "audio", "instrument", "group", "master", "fx_return"
        kind: String,
    },

    /// Remove a track node from the audio graph.
    RemoveTrack { track_id: String },

    /// Set track parameter (volume, pan, mute, solo).
    SetTrackParam {
        track_index: u16,
        param: TrackParam,
        value: f64,
    },

    /// Set master bus parameter.
    SetMasterParam { param: TrackParam, value: f64 },

    /// Configure group bus routing: child track → group track.
    SetGroupRouting {
        child_track_index: u16,
        group_track_index: Option<u16>,
    },

    // -- Audio Data --------------------------------------------------------
    /// Load audio data for a clip (base64-encoded f32 interleaved PCM).
    LoadAudioClip {
        clip_id: String,
        /// Channels (1=mono, 2=stereo)
        channels: u8,
        sample_rate: u32,
        /// Base64-encoded f32 LE samples
        audio_b64: String,
    },

    /// Set the arrangement state (which clips play where).
    SetArrangement { clips: Vec<ArrangementClip> },

    // -- Plugin Hosting ---------------------------------------------------
    /// Load a plugin on a track.
    LoadPlugin {
        track_id: String,
        slot_index: u8,
        plugin_path: String,
        /// "vst3", "clap", "lv2"
        plugin_format: String,
    },

    /// Unload a plugin from a track slot.
    UnloadPlugin { track_id: String, slot_index: u8 },

    /// Set a plugin parameter.
    SetPluginParam {
        track_id: String,
        slot_index: u8,
        param_index: u32,
        value: f64,
    },

    /// Save plugin state (request state blob back as Event).
    SavePluginState { track_id: String, slot_index: u8 },

    /// Load plugin state from blob.
    LoadPluginState {
        track_id: String,
        slot_index: u8,
        /// Base64-encoded state blob
        state_b64: String,
    },

    // -- MIDI --------------------------------------------------------------
    /// Send MIDI note-on to a track's instrument.
    MidiNoteOn {
        track_id: String,
        channel: u8,
        note: u8,
        velocity: f32,
    },

    /// Send MIDI note-off.
    MidiNoteOff {
        track_id: String,
        channel: u8,
        note: u8,
    },

    /// Send MIDI CC.
    MidiCC {
        track_id: String,
        channel: u8,
        cc: u8,
        value: f32,
    },

    // -- Engine Lifecycle --------------------------------------------------
    /// Configure audio backend (sample rate, buffer size, device).
    Configure {
        sample_rate: u32,
        buffer_size: u32,
        /// Device name or empty for default.
        device: String,
    },

    /// Request engine status/health.
    Ping { seq: u64 },

    /// Graceful shutdown.
    Shutdown,
}

/// Track parameter types (matches Python TRACK_VOL/PAN/MUTE/SOLO).
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum TrackParam {
    Volume,
    Pan,
    Mute,
    Solo,
}

/// Description of where a clip is placed in the arrangement.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ArrangementClip {
    pub clip_id: String,
    pub track_index: u16,
    pub start_beat: f64,
    pub end_beat: f64,
    pub offset_samples: i64,
    pub gain: f32,
}

// ---------------------------------------------------------------------------
// Events: Rust → Python
// ---------------------------------------------------------------------------

/// Top-level event envelope sent from Rust to Python.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "evt")]
pub enum Event {
    // -- Transport ---------------------------------------------------------
    /// Playhead position update (~30Hz for GUI).
    PlayheadPosition {
        beat: f64,
        sample_position: i64,
        is_playing: bool,
    },

    /// Transport state changed.
    TransportState {
        is_playing: bool,
        beat: f64,
    },

    // -- Metering ----------------------------------------------------------
    /// Per-track peak/RMS levels (sent ~30Hz).
    MeterLevels { levels: Vec<TrackMeterLevel> },

    /// Master bus levels.
    MasterMeterLevel {
        peak_l: f32,
        peak_r: f32,
        rms_l: f32,
        rms_r: f32,
    },

    // -- Engine Status -----------------------------------------------------
    /// Response to Ping.
    Pong {
        seq: u64,
        /// Engine CPU load (0.0 - 1.0).
        cpu_load: f32,
        /// Audio buffer underruns since start.
        xrun_count: u32,
    },

    /// Engine error (non-fatal, logged).
    Error {
        code: u32,
        message: String,
    },

    /// Plugin crashed — track is muted.
    PluginCrash {
        track_id: String,
        slot_index: u8,
        message: String,
    },

    /// Plugin state blob (response to SavePluginState).
    PluginState {
        track_id: String,
        slot_index: u8,
        /// Base64-encoded state blob.
        state_b64: String,
    },

    /// Engine is ready (sent after Configure).
    Ready {
        sample_rate: u32,
        buffer_size: u32,
        device_name: String,
    },

    /// Engine is shutting down.
    ShuttingDown,
}

/// Per-track meter data.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrackMeterLevel {
    pub track_index: u16,
    pub peak_l: f32,
    pub peak_r: f32,
    pub rms_l: f32,
    pub rms_r: f32,
}
