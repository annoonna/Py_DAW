# 🎯 Py_DAW ROADMAP — Weg zur Open-Source-Referenz-DAW

**Projekt:** Py_DAW (ChronoScaleStudio)
**Vision:** Open Source, erweiterbar, Python-scriptbar, Linux-first
**Erstellt:** 2026-03-19 (v0.0.20.626, aktualisiert v0.0.20.630)
**Autor:** Anno (Lead Developer) + Claude Opus 4.6

---

## ⚠️ OBERSTE DIREKTIVE — FÜR ALLE KOLLEGEN

```
🔴 DU DARFST NICHTS KAPUTT MACHEN. DAS IST DIE OBERSTE DIREKTIVE.
🔴 "Nichts kaputt machen" bedeutet: Alle bestehenden Features müssen
   nach deiner Arbeit exakt so funktionieren wie vorher.
🔴 Teste IMMER mit python3 -c "import py_compile; ..." vor dem ZIP.
🔴 Im Zweifel: NICHT ändern. Lieber fragen.
```

## 📦 ZIP-WORKFLOW — PFLICHT FÜR JEDEN KOLLEGEN

```bash
# 1. ZIP entpacken (DIREKT im Verzeichnis arbeiten!)
unzip Py_DAW_vX_X_XX_XXX_TEAM_READY.zip -d work
cd work

# 2. NIEMALS vom falschen Pfad ausgehen!
#    Prüfe IMMER: ls pydaw/  ← muss existieren

# 3. Nach Arbeit: VERSION erhöhen, ZIP bauen
echo -n "0.0.20.XXX" > VERSION
zip -r /path/Py_DAW_v0_0_20_XXX_TEAM_READY.zip \
  pydaw pydaw_engine PROJECT_DOCS docs *.py *.md *.txt VERSION *.sh \
  -x "*.pyc" "*__pycache__*" "*.egg-info*" "*/.git/*" "*/node_modules/*" "*/target/*"

# 4. ZIP verifizieren
cd /tmp && mkdir verify && cd verify
unzip -q /path/Py_DAW_v0_0_20_XXX_TEAM_READY.zip
python3 -c "import py_compile; py_compile.compile('pydaw/ui/main_window.py', doraise=True); print('OK')"
```

---

## 🏗️ ARBEITSPAKET 1: Rust/C++ Audio-Core (HÖCHSTE PRIORITÄT)

### Warum?
Pythons GIL (Global Interpreter Lock) verhindert echtes Multi-Thread Audio-Rendering.
Bei 20+ Tracks mit Plugins wird die CPU zum Bottleneck. Bitwig/Ableton/Cubase
rendern Audio in C++ mit Lock-Free-Ringbuffern und Thread-Pools.

### Zielarchitektur

```
┌─────────────────────────────────────┐
│  Python/PyQt6 GUI (wie bisher)      │
│  - Arranger, PianoRoll, Mixer, etc. │
│  - Projekt-Daten, Clips, Automation │
└──────────────┬──────────────────────┘
               │ IPC (SharedMemory / Unix Socket / gRPC)
               │ Commands: play, stop, seek, set_param, load_plugin
               │ Events:   playhead_pos, meter_levels, midi_events
               ▼
┌─────────────────────────────────────┐
│  Rust Audio-Engine (eigener Prozess)│
│  - Echtzeit Audio-Graph             │
│  - Lock-Free Ringbuffer             │
│  - Plugin-Hosting (VST3/CLAP/LV2)  │
│  - Multi-Thread Track-Rendering     │
│  - MIDI Dispatch                    │
│  - Mixer mit Send/Return Routing    │
└──────────────┬──────────────────────┘
               │ ALSA / PipeWire / JACK
               ▼
           🔊 Audio Output
```

### Phasenplan

**Phase 1A — Rust Skeleton + IPC Bridge (~2-3 Sessions)**
- [x] Neues Cargo-Projekt `pydaw_engine/` im Repository  *(v0.0.20.630)*
- [x] Grundstruktur: `main.rs`, `audio_graph.rs`, `ipc.rs`, `plugin_host.rs`  *(v0.0.20.630)*
- [x] IPC-Protokoll definieren (Protobuf oder MessagePack über Unix Socket)  *(v0.0.20.630 — MessagePack via rmp-serde)*
- [x] Python-seitig: `RustEngineBridge` Klasse die Commands sendet und Events empfängt  *(v0.0.20.630)*
- [x] Einfacher Proof-of-Concept: Sine-Wave Generator in Rust, Playhead-Position an Python  *(v0.0.20.630)*
- [x] NICHTS an der bestehenden Python-Engine ändern! Parallelbetrieb.  *(v0.0.20.630 — Feature-Flag USE_RUST_ENGINE)*

**Phase 1B — Audio-Graph in Rust (~3-5 Sessions)**
- [x] `AudioNode` Trait: `process(&mut self, buffer: &mut AudioBuffer, frames: usize)`  *(v0.0.20.631 — audio_node.rs mit ProcessContext, GainNode, SineNode, MixNode)*
- [x] `AudioGraph` mit topologischer Sortierung (wie JUCE AudioProcessorGraph)  *(v0.0.20.630 — audio_graph.rs)*
- [x] Track-Nodes: Volume, Pan, Mute/Solo  *(v0.0.20.630 — TrackNode mit atomaren Parametern)*
- [x] Master-Bus Node  *(v0.0.20.630 — TrackKind::Master, Soft-Limiter)*
- [x] ALSA/PipeWire Backend via `cpal` Crate  *(v0.0.20.630 — main.rs cpal Stream)*
- [x] Lock-Free Parameter-Updates via `crossbeam` Atomic Ringbuffer  *(v0.0.20.631 — lock_free.rs ParamRing SPSC)*
- [x] Metering: Peak/RMS pro Track → Python via IPC  *(v0.0.20.630 — MeterLevels + MasterMeterLevel Events ~30Hz)*

**Phase 1C — Plugin-Hosting in Rust (~3-5 Sessions)**
- [ ] VST3 Hosting via `vst3-sys` Crate
- [ ] CLAP Hosting via `clap-sys` Crate
- [ ] Plugin-Prozess-Isolation (jedes Plugin in eigenem Thread/Prozess)
- [ ] Parameter-Sync: Python GUI ↔ Rust Engine ↔ Plugin
- [ ] Plugin-State Save/Load (Base64 Blobs)
- [ ] Crash-Recovery: Plugin-Prozess stirbt → Engine läuft weiter

**Phase 1D — Migration (~2-3 Sessions)**
- [x] Feature-Flag: `USE_RUST_ENGINE=true/false`  *(v0.0.20.630 — RustEngineBridge.is_enabled())*
- [x] Python-Engine bleibt als Fallback erhalten  *(v0.0.20.630 — kein Byte am bestehenden Code geändert)*
- [ ] Schrittweise Migration: erst Audio-Playback, dann MIDI, dann Plugins  *(braucht Rust-Compilation + Test)*
- [ ] Performance-Vergleich: Python-Engine vs Rust-Engine
- [ ] Wenn stabil: Rust-Engine als Default

### Technologie-Empfehlung
- **Sprache:** Rust (Speichersicherheit, kein GC, excellentes Audio-Ökosystem)
- **Crates:** `cpal` (Audio I/O), `crossbeam` (Lock-Free), `vst3-sys`, `clack-host` (CLAP)
- **IPC:** Unix Domain Sockets + MessagePack (schnell, einfach)
- **Build:** `maturin` für Python-Bindings (PyO3) ODER reiner Socket-IPC

### Risiken
- Größtes Risiko: IPC-Latenz. Muss unter 1ms bleiben.
- Plugin-GUI: Bleibt vorerst in Python (X11 Window Embedding)
- Fallback: Python-Engine MUSS weiterhin funktionieren!

---

## 🎙️ ARBEITSPAKET 2: Audio Recording

### Aktueller Stand
Rudimentäres Recording über JACK Backend. Kein Comping, kein Punch In/Out,
keine Take-Lanes.

### Ziel-Features

**Phase 2A — Solides Single-Track Recording (~2 Sessions)**
- [x] Record-Arm Button pro Track (visuell + funktional)  *(v0.0.20.632 — Mixer R-Button + Arranger Kontextmenü, model.Track.record_arm)*
- [x] Pre-Roll / Count-In mit Metronom  *(v0.0.20.632 — RecordingService.set_count_in_bars(), finish_count_in())*
- [x] Aufnahme schreibt WAV-Datei in Projekt-Ordner  *(v0.0.20.632 — project/media/recordings/, 24-bit WAV)*
- [x] Automatische Clip-Erstellung nach Stop  *(v0.0.20.632 — on_recording_complete Callback → add_audio_clip_from_file_at)*
- [x] Input-Monitoring (Echtzeit-Abhöre des Eingangs)  *(v0.0.20.632 — get_input_level(), set_input_monitoring())*

**Phase 2B — Multi-Track Recording (~2-3 Sessions)**
- [x] Mehrere Tracks gleichzeitig aufnehmen  *(v0.0.20.636 — Multi-Track RecordingService, JACK + sounddevice)*
- [x] Input-Routing: Welcher Hardware-Input → welcher Track  *(v0.0.20.636 — Mixer ComboBox + Track.input_pair, Auto-Detection)*
- [x] Latenz-Kompensation (Plugin Delay Compensation — PDC)  *(v0.0.20.636 — PDC Framework: set/get_track_pdc_latency, Sample-Trimming)*
- [x] Buffer-Size Einstellungen (64/128/256/512/1024/2048)  *(v0.0.20.636 — AudioSettingsDialog ComboBox, Settings → RecordingService)*

**Phase 2C — Punch In/Out (~1-2 Sessions)**
- [ ] Punch-Region im Arranger definieren (Start/End Marker)
- [ ] Automatisches Punch In/Out bei Play
- [ ] Pre-/Post-Roll Einstellungen
- [ ] Crossfade an Punch-Grenzen

**Phase 2D — Comping / Take-Lanes (~3-4 Sessions)**
- [ ] Loop-Recording: Jeder Durchlauf wird als separater Take gespeichert
- [ ] Take-Lanes im Arranger (übereinander gestapelt, wie Cubase/Logic)
- [ ] Comp-Tool: Bereiche aus verschiedenen Takes auswählen
- [ ] Flatten: Comp zu einem einzelnen Clip zusammenfügen
- [ ] Take-Management: Umbenennen, Löschen, Farben

### Abhängigkeiten
- Wenn AP1 (Rust-Engine) fertig: Recording direkt in Rust implementieren
- Wenn nicht: Bestehenden JACK-Backend erweitern

---

## 🎵 ARBEITSPAKET 3: Time-Stretching & Warping

### Aktueller Stand
Grundlagen vorhanden (Essentia Pool, Rubberband-Integration), aber kein
interaktives Warp-Marker-System.

### Ziel-Features

**Phase 3A — Warp-Marker System (~2-3 Sessions)**
- [ ] Warp-Marker Datenmodell: `WarpMarker(beat_position, sample_position)`
- [ ] Beat-Detection via Essentia/Aubio → automatische Marker-Platzierung
- [ ] Manuelle Marker im Audio-Editor (Klick auf Transiente → Marker setzen)
- [ ] Marker verschieben = Audio wird elastisch gestreckt/gestaucht

**Phase 3B — Stretch-Modi (~2 Sessions)**
- [ ] Beats Mode (für Drums/Percussion — Slice-basiert)
- [ ] Tones Mode (für melodisches Material — Rubberband)
- [ ] Texture Mode (für Ambient/Pads — Granular)
- [ ] Re-Pitch Mode (einfaches Resampling, kein Stretch)
- [ ] Complex/Complex Pro (höchste Qualität, CPU-intensiv)

**Phase 3C — Tempo-Anpassung (~1-2 Sessions)**
- [ ] Clip-Tempo erkennen (BPM Detection)
- [ ] Automatische Anpassung an Projekt-Tempo
- [ ] Tempo-Automation: Clips folgen Tempo-Änderungen in Echtzeit
- [ ] Clip-Warp im Arranger (nicht nur im Audio-Editor)

### Technologie
- **Rubberband** (C-Bibliothek, bereits integriert) für Tones/Complex
- **Slice-basiert** (eigene Implementierung) für Beats Mode
- **Granular** (numpy-basiert oder Rust) für Texture Mode

---

## 🔌 ARBEITSPAKET 4: Plugin-Hosting Robustheit

### Aktueller Stand
VST3 via pedalboard, CLAP direkt, LV2/LADSPA via lilvlib.
Kein Sandboxing, kein vollständiger Preset-Browser.

### Ziel-Features

**Phase 4A — Sandboxed Plugin-Hosting (~3-4 Sessions)**
- [ ] Jedes Plugin in eigenem Subprocess (wie Bitwig)
- [ ] IPC für Audio-Daten (Shared Memory Ringbuffer)
- [ ] IPC für Parameter-Updates (Unix Socket)
- [ ] Crash-Detection: Plugin-Prozess stirbt → Track wird gemutet, Fehlermeldung
- [ ] Auto-Restart: Plugin-Prozess wird neu gestartet, State wiederhergestellt

**Phase 4B — Preset-Browser (~2-3 Sessions)**
- [ ] VST3 Preset-Scan: Alle Presets aus Plugin auslesen
- [ ] CLAP Preset-Scan via `clap.preset-load` Extension
- [ ] Preset-Liste im Device-Widget (Dropdown + Search)
- [ ] Preset-Kategorien (Factory, User, Favoriten)
- [ ] A/B Vergleich: Zwei Preset-Slots zum schnellen Wechseln

**Phase 4C — Plugin-State Management (~1-2 Sessions)**
- [ ] Automatische State-Sicherung bei Projektänderungen
- [ ] State als Base64-Blob in Project-JSON
- [ ] State-Wiederherstellung beim Projekt-Öffnen
- [ ] Undo/Redo für Parameter-Änderungen

### Abhängigkeiten
- AP1 (Rust-Engine) macht Sandboxing deutlich einfacher (Plugin in Rust-Thread)
- Ohne Rust: Python-Subprocess-Ansatz (langsamer, aber machbar)

---

## 🎛️ ARBEITSPAKET 5: Mixer / Routing

### Aktueller Stand
Basis-Mixer mit Volume/Pan/Mute/Solo pro Track, Master-Bus,
Group-Tracks mit 2-Pass Rendering. Kein Send/Return, kein Sidechain.

### Ziel-Features

**Phase 5A — Send/Return Tracks (~2-3 Sessions)**
- [ ] FX Return Track Typ (empfängt nur Send-Signale)
- [ ] Send-Knob pro Track (Pre-Fader / Post-Fader wählbar)
- [ ] Mehrere Sends pro Track (wie Cubase: bis zu 8)
- [ ] Send-Amount Automation
- [ ] Visuelles Routing im Mixer (Linien zwischen Tracks)

**Phase 5B — Sidechain-Routing (~1-2 Sessions)**
- [ ] Sidechain-Input Selector pro Plugin
- [ ] Track-zu-Track Sidechain (z.B. Kick → Compressor auf Bass)
- [ ] Visueller Indikator im Mixer
- [ ] Sidechain-Routing Matrix (Übersicht aller Verbindungen)

**Phase 5C — Routing-Matrix (~2-3 Sessions)**
- [ ] Patchbay-Ansicht (wie Cubase MixConsole Routing)
- [ ] Drag&Drop Routing zwischen Tracks
- [ ] Multi-Output Plugins (z.B. Drum-Sampler → separate Outputs)
- [ ] Mono/Stereo/Surround Track-Konfiguration

---

## 🎹 ARBEITSPAKET 6: MIDI-Editing Tiefe

### Aktueller Stand
Piano Roll mit Pencil/Select/Erase/Knife, Loop-Editor, Expression Lanes,
Ghost Layers, MIDI Learn, CC Automation. Grundsolide, aber es fehlen Power-Tools.

### Ziel-Features

**Phase 6A — MIDI Effects Chain (~3-4 Sessions)**
- [ ] MIDI Effect Slot pro Track (vor dem Instrument)
- [ ] Built-in MIDI Effects:
  - [ ] Arpeggiator (Pattern, Rate, Gate, Octave Range)
  - [ ] Chord Generator (Chord Type, Voicing, Spread)
  - [ ] Scale Quantizer (Force to Scale, Nearest Note)
  - [ ] Randomizer (Pitch, Velocity, Timing, Length Randomization)
  - [ ] Note Echo (Delay, Feedback, Transpose per Repeat)
  - [ ] Velocity Curve (Compress/Expand/Limit)
- [ ] MIDI FX Chain: Mehrere Effekte hintereinander
- [ ] MIDI FX Preset-System

**Phase 6B — MPE Support (~2-3 Sessions)**
- [ ] Per-Note Pitch Bend (Channel per Note)
- [ ] Per-Note Pressure / Slide
- [ ] MPE Configuration (Lower/Upper Zone, Pitch Bend Range)
- [ ] MPE-aware Piano Roll (Pitch Bend + Pressure pro Note visualisieren)
- [ ] MPE Controller Support (Roli Seaboard, Linnstrument, Sensel Morph)

**Phase 6C — Groove Templates (~1-2 Sessions)**
- [ ] Groove Template Bibliothek (Swing, MPC, TR-808, Live-Drummer)
- [ ] Groove aus MIDI-Clip extrahieren
- [ ] Groove auf andere Clips anwenden
- [ ] Groove-Amount Slider (0-100%)
- [ ] Humanize: Zufällige Timing/Velocity-Variation

---

## 🥁 ARBEITSPAKET 7: Sampler / Instrument-Tiefe

### Aktueller Stand
Pro Audio Sampler (basic), AETERNA Synth, SF2 via FluidSynth.
Kein Multi-Sample-Mapping, kein Drum Rack.

### Ziel-Features

**Phase 7A — Advanced Sampler (~3-4 Sessions)**
- [ ] Multi-Sample Mapping Editor (Key + Velocity Zones visuell)
- [ ] Round-Robin Gruppen (zyklische Sample-Auswahl)
- [ ] Sample-Start/End/Loop-Punkte im Editor
- [ ] Filter (LP/HP/BP) + Amp Envelope (ADSR) pro Sample-Zone
- [ ] Modulations-Matrix (LFO/Envelope → Pitch/Filter/Amp/Pan)
- [ ] Sample Import: Drag&Drop, Auto-Mapping (chromatisch/Drum)

**Phase 7B — Drum Rack (~2-3 Sessions)**
- [ ] 4x4 oder 8x8 Pad-Grid (wie Ableton Drum Rack)
- [ ] Ein Sample/Instrument pro Pad
- [ ] Per-Pad: Volume, Pan, Tune, FX Chain
- [ ] Per-Pad: Choke Groups (Hi-Hat Open/Closed)
- [ ] Pad-Zuordnung via Drag&Drop
- [ ] MIDI-Mapping: C1-D#2 = Standard GM Drum Map

**Phase 7C — Wavetable-Erweiterung für AETERNA (~2-3 Sessions)**
- [ ] Wavetable Import (Serum .wav Format)
- [ ] Wavetable Morphing (Position Automation)
- [ ] Wavetable Editor (Draw/Import/FFT)
- [ ] Unison Engine (Detune, Spread, Width)

---

## 🎚️ ARBEITSPAKET 8: Built-in Effects

### Aktueller Stand
Keine eingebauten Audio-Effekte. Komplett abhängig von externen Plugins.

### Ziel-Features (nach Priorität)

**Phase 8A — Essential FX (~4-5 Sessions)**
- [ ] **EQ (Parametric 8-Band)**: Bell, Shelf, HP/LP, Analyzer-Display
- [ ] **Compressor**: Threshold, Ratio, Attack, Release, Knee, Sidechain, Gain Reduction Meter
- [ ] **Reverb**: Algorithmic (Hall/Room/Plate), Pre-Delay, Decay, Damping, Mix
- [ ] **Delay**: Tempo-Sync, Ping-Pong, Filter, Feedback, Mix
- [ ] **Limiter**: Brickwall, Ceiling, Release, Gain

**Phase 8B — Creative FX (~3-4 Sessions)**
- [ ] **Chorus**: Rate, Depth, Voices, Mix
- [ ] **Phaser**: Rate, Depth, Stages, Feedback
- [ ] **Flanger**: Rate, Depth, Feedback, Mix
- [ ] **Distortion**: Drive, Tone, Type (Soft/Hard/Tube/Tape/Bitcrush)
- [ ] **Tremolo**: Rate, Depth, Shape (Sine/Square/Triangle)

**Phase 8C — Utility FX (~2-3 Sessions)**
- [ ] **Gate**: Threshold, Attack, Hold, Release, Sidechain
- [ ] **De-Esser**: Frequency, Threshold, Range
- [ ] **Stereo Widener**: Width, Mid/Side Balance
- [ ] **Utility**: Gain, Phase Invert, Mono, DC Offset
- [ ] **Spectrum Analyzer**: FFT Display, Peak Hold

### Technologie
- **Wenn Rust-Engine (AP1):** FX in Rust implementieren (beste Performance)
- **Ohne Rust:** numpy/scipy DSP in Python (funktioniert, aber CPU-intensiv)
- **Alternative:** Fertige C-Bibliotheken wrappen (z.B. Faust DSP)

---

## 📈 ARBEITSPAKET 9: Automation (Ausbau)

### Aktueller Stand
AutomatableParameter, Breakpoint-Envelopes (Bezier/Step/Smooth),
Write/Touch/Latch Modi, MIDI Learn, Inline Arranger Lanes.

### Ziel-Features

**Phase 9A — Plugin-Parameter Automation (~2 Sessions)**
- [ ] Alle Plugin-Parameter als Automations-Ziele
- [ ] Parameter-Discovery: Plugin → Liste aller automatisierbaren Parameter
- [ ] "Arm" Button pro Parameter (Write-Modus gezielt)
- [ ] Parameter-Name im Automation-Lane Header

**Phase 9B — Relative/Trim Automation (~1-2 Sessions)**
- [ ] Relative Mode: Automation ist Offset auf aktuellen Wert
- [ ] Trim Mode: Automation als Multiplikator
- [ ] Visuell: Separate Linie für Basis-Wert + Automation-Offset

**Phase 9C — Automation Workflow (~1-2 Sessions)**
- [ ] Automation-Snapshot: Aktuellen Zustand als Startpunkt einfrieren
- [ ] Automation auf Clip-Ebene (nicht nur Track-Ebene)
- [ ] Clip-Automation kopieren bei Clip-Duplikation
- [ ] Automation-Curves: Logarithmisch, Exponentiell, S-Curve

---

## 📤 ARBEITSPAKET 10: Export & Collaboration

### Aktueller Stand
Basis WAV-Export, DAWproject Export/Import Grundlagen.

### Ziel-Features

**Phase 10A — Multi-Format Export (~1-2 Sessions)**
- [ ] Export-Dialog: WAV (16/24/32bit), FLAC, MP3, OGG
- [ ] Sample-Rate Auswahl (44.1/48/88.2/96 kHz)
- [ ] Dither-Optionen (Triangular, POW-R)
- [ ] Normalisierung (Peak / LUFS)
- [ ] Progress-Bar mit Abbrechen

**Phase 10B — Stem Export (~1-2 Sessions)**
- [ ] Alle Tracks als separate Dateien exportieren
- [ ] Track-Gruppen als Stems (Drums, Bass, Keys, Vocals, etc.)
- [ ] Naming Convention: `Projektname_Trackname_BPM.wav`
- [ ] Pre-/Post-FX Export Optionen

**Phase 10C — DAWproject Roundtrip (~2-3 Sessions)**
- [ ] Vollständiger DAWproject Export (Clips, Automation, Plugins)
- [ ] Import von Bitwig/Studio One DAWproject Dateien
- [ ] Roundtrip-Test: Export → Import → Vergleich
- [ ] Plugin-Mapping: VST3 ID ↔ DAWproject Device ID

**Phase 10D — Cloud & Collaboration (~2-3 Sessions)**
- [ ] Projekt-Backup in Cloud (optional, Git-basiert)
- [ ] Projekt-Sharing per Link
- [ ] Versionierung: Projekt-Snapshots mit Diff
- [ ] Collaborative Editing (optional, langfristiges Ziel)

---

## 📊 GESAMTÜBERSICHT: Aufwand & Priorität

| AP | Feature | Priorität | Sessions | Abhängigkeit |
|----|---------|-----------|----------|--------------|
| 1  | Rust Audio-Core | 🔴 KRITISCH | 10-16 | — |
| 2  | Audio Recording | 🔴 KRITISCH | 8-11 | AP1 (optional) |
| 3  | Time-Stretch/Warp | 🟠 HOCH | 5-7 | — |
| 4  | Plugin Robustheit | 🟠 HOCH | 6-9 | AP1 (optional) |
| 5  | Mixer/Routing | 🟠 HOCH | 5-8 | AP1 (optional) |
| 6  | MIDI-Editing | 🟡 MITTEL | 6-9 | — |
| 7  | Sampler/Instrumente | 🟡 MITTEL | 7-10 | — |
| 8  | Built-in FX | 🟡 MITTEL | 9-12 | AP1 (empfohlen) |
| 9  | Automation Ausbau | 🟢 NORMAL | 4-6 | — |
| 10 | Export/Collaboration | 🟢 NORMAL | 6-10 | — |
| **TOTAL** | | | **~66-98 Sessions** | |

### Empfohlene Reihenfolge
```
AP1 (Rust Core) → AP2 (Recording) → AP5 (Routing) → AP4 (Plugins)
                → AP3 (Warp) → AP8 (FX) → AP6 (MIDI) → AP7 (Sampler)
                → AP9 (Automation) → AP10 (Export)
```

AP1 ist der Grundstein — alles wird besser wenn die Audio-Engine in Rust läuft.
AP2+AP5 sind die nächsten Kern-Features die jede DAW braucht.
AP3-AP8 können parallel angegangen werden.
AP9-AP10 sind Polish/Workflow-Verbesserungen.

---

## 🔧 TECHNISCHE RICHTLINIEN FÜR ALLE KOLLEGEN

### Code-Stil
- Python 3.12+, PyQt6
- Type Hints wo möglich
- Docstrings für alle öffentlichen Methoden
- `try/except` um alle Qt-Virtual-Overrides (PyQt6 kann SIGABRT bei Exceptions)
- Keine `print()` in Production-Code (nur `logging.getLogger()`)

### Git/ZIP Konventionen
- VERSION-Datei IMMER erhöhen (Format: `0.0.20.XXX`)
- CHANGELOG_v0.0.20.XXX_KURZTITEL.md für jede Version
- TODO.md und DONE.md in PROJECT_DOCS/progress/ aktualisieren
- Session-Log in PROJECT_DOCS/sessions/

### Testing
- `python3 -c "import py_compile; py_compile.compile('datei.py', doraise=True)"` für JEDE geänderte Datei
- ZIP entpacken und nochmal prüfen
- Manuelle Tests: "Funktioniert der Slot-Drag noch? Piano Roll? Transport?"

### Performance-Regeln
- Keine Allokationen im Audio-Callback (Lock-Free only)
- GUI-Updates maximal 30Hz (Timer, nicht pro Sample)
- `set()` Kopien für sichere Iteration über veränderliche Collections
- `getattr(obj, 'attr', default)` statt direktem Zugriff für Robustheit

---

*Dieses Dokument wird mit jeder Major-Version aktualisiert.*
*Aktueller Stand: v0.0.20.636 — 2026-03-19*
