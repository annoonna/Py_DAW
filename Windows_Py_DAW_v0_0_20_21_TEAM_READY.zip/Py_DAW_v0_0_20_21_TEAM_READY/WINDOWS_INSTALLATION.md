# 🎹 PyDAW v0.0.20.21 - Windows Installations-Anleitung

**Komplette Schritt-für-Schritt Anleitung für Windows 10/11**

---

## 📋 Voraussetzungen

- **Windows 10 oder 11** (64-bit empfohlen)
- **Python 3.10 oder höher** ([Download hier](https://www.python.org/downloads/))
- **Administratorrechte** (für PATH-Änderungen)
- **ca. 500 MB freier Speicherplatz**

---

## 🚀 Installation

### Schritt 1: Python installieren

1. Lade Python von [python.org](https://www.python.org/downloads/) herunter
2. **Wichtig:** Aktiviere beim Installieren "Add Python to PATH" ✅
3. Installiere mit "Install Now"
4. Verifiziere die Installation:

```cmd
python --version
```

**Sollte zeigen:** `Python 3.13.x` oder höher

---

### Schritt 2: PyDAW herunterladen und entpacken

1. Lade `Py_DAW_v0_0_20_21_TEAM_READY.zip` herunter
2. Entpacke nach:
   ```
   C:\Users\<dein-name>\Dokumente\Meine_Python_Projekte\Py_DAW_v0_0_20_21_TEAM_READY
   ```
3. Öffne ein **Terminal** (CMD):
   - Windows-Taste → tippe `cmd` → Enter

---

### Schritt 3: Python-Abhängigkeiten installieren

Öffne ein Terminal und navigiere zum Projekt-Ordner:

```cmd
cd C:\Users\<dein-name>\Dokumente\Meine_Python_Projekte\Py_DAW_v0_0_20_21_TEAM_READY
pip install -r requirements.txt
```

**Das installiert:**
- PyQt6 (GUI-Framework)
- NumPy (Audio-Verarbeitung)
- sounddevice, soundfile (Audio I/O)
- mido, python-rtmidi (MIDI-Handling)
- pydub (Audio-Konvertierung)
- und mehr...

⏱️ **Dauer:** ca. 2-5 Minuten

---

### Schritt 4: FluidSynth installieren (für MIDI-Playback)

FluidSynth wird benötigt, um MIDI-Noten mit SoundFonts (SF2) in Audio umzuwandeln.

#### 4.1 FluidSynth herunterladen

1. Gehe zu: https://github.com/FluidSynth/fluidsynth/releases/latest
2. Lade herunter: **`fluidsynth-v2.5.2-win10-x64-glib.zip`** (ca. 3.26 MB)
3. Entpacke nach: `C:\fluidsynth`

**Struktur sollte sein:**
```
C:\fluidsynth\
├── bin\
│   ├── fluidsynth.exe  ← Diese Datei ist wichtig!
│   ├── libfluidsynth-3.dll
│   └── (weitere DLLs)
├── include\
└── lib\
```

#### 4.2 FluidSynth zum PATH hinzufügen

**Option A - GUI (Empfohlen für Einsteiger):**

1. **Windows-Taste** drücken
2. Tippe: `Umgebungsvariablen`
3. Klicke: **"Umgebungsvariablen für dieses Konto bearbeiten"**
4. Unter "Benutzervariablen für <dein-name>":
   
   **a) PATH erweitern:**
   - Wähle **Path** → Klicke **Bearbeiten**
   - Klicke **Neu**
   - Gib ein: `C:\fluidsynth\bin`
   - Klicke **OK**
   
   **b) FLUIDSYNTH_PATH setzen:**
   - Klicke **Neu**
   - **Variablenname:** `FLUIDSYNTH_PATH`
   - **Variablenwert:** `C:\fluidsynth\bin\fluidsynth.exe`
   - Klicke **OK**

5. Klicke **OK** → **OK** → Fertig!

**Option B - PowerShell (Schnell für Fortgeschrittene):**

Öffne **PowerShell als Administrator** und führe aus:

```powershell
[Environment]::SetEnvironmentVariable("Path", $env:Path + ";C:\fluidsynth\bin", "User")
[Environment]::SetEnvironmentVariable("FLUIDSYNTH_PATH", "C:\fluidsynth\bin\fluidsynth.exe", "User")
```

#### 4.3 Verifizierung

**Schließe alle Terminals und öffne ein NEUES CMD-Fenster**, dann:

```cmd
where fluidsynth
```

**Sollte zeigen:** `C:\fluidsynth\bin\fluidsynth.exe`

```cmd
fluidsynth --version
```

**Sollte zeigen:** `FluidSynth runtime version 2.5.2`

✅ **Perfekt!** FluidSynth ist installiert.

---

### Schritt 5: pyFluidSynth installieren (Python-Bindings)

```cmd
pip install pyfluidsynth
```

Das ist der Python-Fallback für FluidSynth-Rendering.

---

### Schritt 6: SoundFont herunterladen (optional, aber empfohlen)

SoundFonts (.sf2) enthalten die Instrument-Samples für MIDI-Playback.

**Empfohlen:** FluidR3_GM.sf2 (ca. 140 MB)

1. Download: https://member.keymusician.com/Member/FluidR3_GM/index.html
2. Oder: https://musical-artifacts.com/artifacts/738
3. Speichere nach: `C:\Soundfonts\FluidR3_GM.sf2`

**Alternative SoundFonts:**
- GeneralUser GS: https://schristiancollins.com/generaluser.php
- MuseScore_General.sf2: https://ftp.osuosl.org/pub/musescore/soundfont/

---

## 🎵 PyDAW starten

### Erste Schritte:

1. Öffne ein **neues Terminal** (CMD)
2. Navigiere zum Projekt:

```cmd
cd C:\Users\<dein-name>\Dokumente\Meine_Python_Projekte\Py_DAW_v0_0_20_21_TEAM_READY
```

3. Starte PyDAW:

```cmd
python main.py
```

**Das Fenster sollte sich öffnen!** 🎉

---

## 🔧 Troubleshooting

### Problem: "FluidSynth CLI nicht gefunden"

**Symptom:** Warnung beim MIDI-Playback:
```
MIDI->WAV Render fehlgeschlagen (SF2/FluidSynth): Kein Sound
```

**Lösung:**

1. Prüfe ob FluidSynth im PATH ist:
   ```cmd
   where fluidsynth
   ```
   
2. Falls **nicht gefunden** → Wiederhole Schritt 4.2

3. Setze temporär (für aktuelles Terminal):
   ```cmd
   set FLUIDSYNTH_PATH=C:\fluidsynth\bin\fluidsynth.exe
   set PATH=%PATH%;C:\fluidsynth\bin
   python main.py
   ```

---

### Problem: "ModuleNotFoundError: No module named 'PyQt6'"

**Lösung:**
```cmd
pip install -r requirements.txt
```

Oder gezielt:
```cmd
pip install PyQt6
```

---

### Problem: "Python wurde nicht gefunden"

**Lösung:**

1. Reinstalliere Python mit "Add Python to PATH" aktiviert
2. Oder füge manuell zum PATH hinzu:
   ```
   C:\Users\<dein-name>\AppData\Local\Programs\Python\Python313\
   C:\Users\<dein-name>\AppData\Local\Programs\Python\Python313\Scripts\
   ```

---

### Problem: "setHighDpiScaleFactorRoundingPolicy" Warnung

**Symptom:**
```
setHighDpiScaleFactorRoundingPolicy must be called before creating QGuiApplication
```

**Info:** Das ist nur eine **Warnung**, kein Fehler! Die App funktioniert trotzdem.

**Optional beheben:** Wird in einer zukünftigen Version gefixt.

---

### Problem: OpenGL Warnung "QT_OPENGL=angle not supported"

**Symptom:**
```
QT_OPENGL=angle is no longer supported in Qt 6
```

**Info:** Harmlose Warnung, beeinflusst die Funktion nicht.

**Optional:** Setze die Umgebungsvariable:
```cmd
set QT_OPENGL=desktop
```

---

## 📁 Projektstruktur

```
Py_DAW_v0_0_20_21_TEAM_READY/
├── main.py                    # Hauptprogramm - hier starten!
├── requirements.txt           # Python-Abhängigkeiten
├── VERSION                    # Versionsnummer
├── README.md                  # Projekt-Übersicht
├── QUICKSTART.md              # Schnellstart-Guide
├── TROUBLESHOOTING.md         # Problemlösungen
├── WINDOWS_INSTALLATION.md    # Diese Datei
├── pydaw/                     # Hauptmodul
│   ├── app.py
│   ├── audio/                 # Audio-Engine
│   ├── ui/                    # GUI-Komponenten
│   ├── services/              # FluidSynth, Recording, etc.
│   └── ...
└── docs/                      # Dokumentation
```

---

## 🎹 Erste Schritte nach der Installation

### 1. Neues Projekt erstellen

1. Starte PyDAW: `python main.py`
2. File → New Project
3. Wähle Speicherort und Namen

### 2. MIDI-Track erstellen

1. Klicke auf "+" → MIDI Track
2. Lade eine SoundFont (.sf2)
3. Zeichne MIDI-Noten auf

### 3. Audio-Track aufnehmen

1. Klicke auf "+" → Audio Track
2. Wähle dein Mikrofon/Interface
3. Klicke Record (●)

### 4. Projekt exportieren

1. File → Export → Mixdown
2. Wähle Format (WAV/MP3)
3. Fertig! 🎵

---

## 📚 Weitere Ressourcen

- **Projekt-GitHub:** (falls vorhanden)
- **Dokumentation:** Siehe `docs/` Ordner
- **Quickstart:** `QUICKSTART.md`
- **Troubleshooting:** `TROUBLESHOOTING.md`
- **Feature-Übersicht:** `FEATURE_ZUSAMMENFASSUNG_DE.md`

---

## 💡 Tipps & Tricks

### Performance optimieren:

```cmd
# Setze Thread-Priorität für Audio
set PYDAW_AUDIO_PRIORITY=HIGH

# Nutze mehr CPU-Cores für Rendering
set PYDAW_RENDER_THREADS=4
```

### Tastatur-Shortcuts:

- **Space:** Play/Pause
- **Ctrl+S:** Projekt speichern
- **Ctrl+Z:** Rückgängig
- **Ctrl+Y:** Wiederherstellen
- **Ctrl+N:** Neues Projekt

---

## ❓ Support & Hilfe

Bei Problemen:

1. **Prüfe TROUBLESHOOTING.md**
2. **Schaue in die Logs:**
   ```
   C:\Users\<dein-name>\.cache\ChronoScaleStudio\pydaw.log
   ```
3. **GitHub Issues** (falls Repository öffentlich)

---

## 📝 Changelog v0.0.20.21

### 🐛 Behobene Bugs:
- **Kritischer SyntaxError** in `midi_render.py` (58 Zeilen falsche Einrückung)
- **IndentationError** in `fluidsynth_service.py` (3 Methoden)
- **SyntaxWarning** mit ungültigem Escape-Zeichen

### ✅ Validierung:
- Alle Python-Module kompilieren fehlerfrei
- FluidSynth-Integration vollständig funktionsfähig
- MIDI→Audio Rendering getestet

---

## 🎉 Fertig!

**Viel Spaß beim Musikmachen mit PyDAW!** 🎵🎹✨

**Version:** 0.0.20.21  
**Datum:** 08.02.2026  
**Erstellt von:** PyDAW Team & Claude AI

---

## ⚖️ Lizenz

PyDAW ist Open Source Software. Siehe LICENSE-Datei für Details.

FluidSynth ist unter der LGPL-Lizenz lizenziert.
