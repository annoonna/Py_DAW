# Session Log — 2026-02-08 — Windows COM Dialog Crash Fix (v0.0.20.18)

## Kontext
User-Report: **Windows fatal exception: code 0x8001010e** beim Öffnen von File-Dialogen (z.B. SF2 laden / Projekt öffnen) während sounddevice läuft.

0x8001010e entspricht typischerweise **RPC_E_WRONG_THREAD** (COM Objekt aus falschem Thread / Apartment).
Qt-native Windows File Dialogs nutzen COM (IFileDialog) und können in einigen Setups dadurch hart crashen.

## Ziel
- Windows: File-Dialoge dürfen nicht mehr den Prozess crashen.
- Workaround soll **default safe** sein, aber optional wieder Native Dialogs erlauben.

## Änderungen
### 1) Global: Native Dialogs auf Windows deaktivieren (default)
- In `pydaw/app.py` wird **vor** dem Erzeugen der QApplication gesetzt:
  - `QApplication.setAttribute(Qt.AA_DontUseNativeDialogs, True)`
- Opt-out per Env:
  - `PYDAW_USE_NATIVE_DIALOGS=1`

### 2) Extra Safety: Kritische Dialoge mit `DontUseNativeDialog`
- In `pydaw/ui/main_window.py`:
  - Helper `_qfd_options()` eingeführt
  - `_open_project()` und `load_sf2_for_selected_track()` übergeben `options=_qfd_options()`

## Test-Plan (Windows)
1. App starten (sounddevice, WASAPI).
2. Datei → Projekt öffnen (Dialog darf nicht crashen).
3. Instrument Track → SF2 laden (Dialog darf nicht crashen).
4. Optional: `set PYDAW_USE_NATIVE_DIALOGS=1` testen (native Dialogs).

## Ergebnis
- Default-Setting nutzt Qt-Dialoge → keine COM-Dialog-Instabilität.
