# -*- coding: utf-8 -*-
"""Plugin registry for instruments/effects.

This keeps the core DAW decoupled from optional plugin modules.
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
from typing import Callable, Optional

from PyQt6.QtWidgets import QWidget

log = logging.getLogger(__name__)

@dataclass(frozen=True)
class InstrumentSpec:
    plugin_id: str
    name: str
    vendor: str = "ChronoScaleStudio"
    category: str = "Instrument"
    description: str = ""
    factory: Callable[..., QWidget] = lambda **_: QWidget()

def get_instruments() -> list[InstrumentSpec]:
    instruments: list[InstrumentSpec] = []
    # Pro Audio Sampler (Qt6)
    try:
        from pydaw.plugins.sampler import SamplerWidget
        instruments.append(
            InstrumentSpec(
                plugin_id="chrono.pro_audio_sampler",
                name="Pro Audio Sampler",
                vendor="ChronoScaleStudio",
                category="Sampler",
                description="WAV Sampler mit Pitch/Filter/FX/ADHSR, Preview-Sync (PianoRoll/Notation).",
                factory=lambda project_service=None, audio_engine=None, **_: SamplerWidget(
                    project_service=project_service, audio_engine=audio_engine
                ),
            )
        )
    except Exception:
        log.exception('Failed to load instrument plugin: sampler')

    return instruments
