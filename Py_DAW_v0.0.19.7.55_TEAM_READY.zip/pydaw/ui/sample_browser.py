"""Sample Browser with Drag & Drop support for PyDAW.

User can browse external folders and drag audio files onto tracks.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PyQt6.QtCore import Qt, QMimeData, QUrl, QDir, pyqtSignal
from PyQt6.QtGui import QDrag, QFileSystemModel  # FIXED: QFileSystemModel is in QtGui!
from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTreeView,
    QLineEdit,
    QComboBox,
)


AUDIO_EXTS = {".wav", ".flac", ".ogg", ".mp3", ".m4a", ".aac", ".mp4", ".aiff", ".aif", ".wv"}


def _is_audio_file(path_str: str) -> bool:
    try:
        return Path(path_str).suffix.lower() in AUDIO_EXTS
    except Exception:
        return False


def _build_drag_pixmap(path_str: str):
    # lightweight ghost cursor preview (waveform for wav, icon otherwise)
    from PyQt6.QtGui import QPixmap, QPainter, QColor, QFont, QPen
    name = Path(path_str).stem
    w, h = 180, 52
    pm = QPixmap(w, h)
    pm.fill(QColor(0, 0, 0, 0))

    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    # background
    p.setPen(QPen(QColor(255, 255, 255, 40), 1))
    p.setBrush(QColor(30, 30, 30, 235))
    p.drawRoundedRect(0, 0, w-1, h-1, 10, 10)

    ext = Path(path_str).suffix.lower()
    if ext == ".wav":
        try:
            import wave, struct
            wf = wave.open(path_str, 'rb')
            ch = max(1, int(wf.getnchannels()))
            n = min(int(wf.getnframes()), 2200)
            raw = wf.readframes(n)
            wf.close()
            if wf.getsampwidth() == 2 and raw:
                samples = struct.unpack('<' + 'h' * (len(raw) // 2), raw)
                # take first channel only
                s = samples[0::ch]
                if s:
                    bins = 110
                    step = max(1, len(s) // bins)
                    mid = 28
                    p.setPen(QPen(QColor(0, 200, 255, 220), 2))
                    for i in range(bins):
                        seg = s[i*step:(i+1)*step]
                        if not seg:
                            continue
                        mn = min(seg) / 32768.0
                        mx = max(seg) / 32768.0
                        x = 10 + i
                        y1 = mid - int(mx * 16)
                        y2 = mid - int(mn * 16)
                        p.drawLine(x, y1, x, y2)
        except Exception:
            pass

    # label
    p.setPen(QColor(255, 255, 255, 210))
    f = QFont()
    f.setPointSize(9)
    f.setBold(True)
    p.setFont(f)
    p.drawText(10, 46, name[:22])
    p.end()
    return pm


class _SampleTreeView(QTreeView):
    drag_started = pyqtSignal(str)
    drag_finished = pyqtSignal()

    def startDrag(self, supportedActions):  # noqa: ANN001
        idx = self.currentIndex()
        try:
            model = self.model()
            path_str = model.filePath(idx) if model is not None else ""
        except Exception:
            path_str = ""

        if not path_str or not Path(path_str).is_file() or not _is_audio_file(path_str):
            return super().startDrag(supportedActions)

        md = QMimeData()
        md.setUrls([QUrl.fromLocalFile(path_str)])
        md.setText(path_str)

        drag = QDrag(self)
        drag.setMimeData(md)
        try:
            pm = _build_drag_pixmap(path_str)
            drag.setPixmap(pm)
            drag.setHotSpot(pm.rect().center())
        except Exception:
            pass

        self.drag_started.emit(Path(path_str).name)
        drag.exec(Qt.DropAction.CopyAction)
        self.drag_finished.emit()


class SampleBrowserWidget(QWidget):
    """File browser for audio samples with drag & drop support.
    
    Features:
    - Browse external folders
    - Filter audio files (.wav, .flac, .ogg, .mp3)
    - Drag & Drop onto tracks
    - Quick access to common folders
    """

    audio_drag_started = pyqtSignal(str)
    audio_drag_ended = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_path = str(Path.home())
        self._build_ui()
    
    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)
        
        # Header
        header = QHBoxLayout()
        header.addWidget(QLabel("Sample Browser"))
        
        # Quick access dropdown
        self.cmb_quick = QComboBox()
        self.cmb_quick.addItem("Home", str(Path.home()))
        self.cmb_quick.addItem("Downloads", str(Path.home() / "Downloads"))
        self.cmb_quick.addItem("Music", str(Path.home() / "Music"))
        self.cmb_quick.addItem("Desktop", str(Path.home() / "Desktop"))
        self.cmb_quick.addItem("Documents", str(Path.home() / "Documents"))
        self.cmb_quick.currentIndexChanged.connect(self._on_quick_access)
        self.cmb_quick.setMaximumWidth(150)
        header.addWidget(self.cmb_quick)
        
        header.addStretch(1)
        layout.addLayout(header)
        
        # Path bar
        path_bar = QHBoxLayout()
        path_bar.addWidget(QLabel("Pfad:"))
        
        self.txt_path = QLineEdit()
        self.txt_path.setText(self._current_path)
        self.txt_path.returnPressed.connect(self._on_path_changed)
        path_bar.addWidget(self.txt_path)
        
        self.btn_up = QPushButton("↑ Hoch")
        self.btn_up.setMaximumWidth(80)
        self.btn_up.clicked.connect(self._go_up)
        path_bar.addWidget(self.btn_up)
        
        layout.addLayout(path_bar)
        
        # File system model
        self.model = QFileSystemModel()
        self.model.setRootPath(QDir.rootPath())
        
        # FIXED v0.0.19.7.18: Show ALL directories + audio files only!
        # Step 1: Set filter to show directories and files
        self.model.setFilter(
            QDir.Filter.AllDirs |      # Show ALL directories
            QDir.Filter.Files |         # Show files
            QDir.Filter.NoDotAndDotDot  # Hide . and ..
        )
        
        # Step 2: Name filter ONLY applies to files (not directories!)
        self.model.setNameFilters([
            "*.wav", "*.WAV",
            "*.mp3", "*.MP3",
            "*.flac", "*.FLAC",
            "*.ogg", "*.OGG",
            "*.aiff", "*.AIFF",
            "*.m4a", "*.M4A",
            "*.wv", "*.WV",
        ])
        self.model.setNameFilterDisables(False)  # Enable filter (show matching files)
        
        # Tree view
        self.tree = _SampleTreeView()
        self.tree.drag_started.connect(self.audio_drag_started.emit)
        self.tree.drag_finished.connect(self.audio_drag_ended.emit)
        self.tree.setModel(self.model)
        self.tree.setRootIndex(self.model.index(self._current_path))
        
        # Show only name and size columns
        self.tree.setColumnWidth(0, 300)
        for i in range(1, self.model.columnCount()):
            if i != 1:  # Keep size column
                self.tree.hideColumn(i)
        
        self.tree.setSelectionMode(QTreeView.SelectionMode.SingleSelection)
        self.tree.setDragEnabled(True)
        self.tree.setDragDropMode(QTreeView.DragDropMode.DragOnly)
        
        # Double-click to enter directory
        self.tree.doubleClicked.connect(self._on_double_click)
        
        layout.addWidget(self.tree)
        
        # Info label
        self.lbl_info = QLabel(
            "💡 Drag & Drop: Ziehe Samples auf Tracks im Arranger\n"
            "🎵 Unterstützt: WAV, MP3, FLAC, OGG, AIFF, M4A, WV"
        )
        self.lbl_info.setStyleSheet("QLabel { color: #888; font-style: italic; font-size: 11px; }")
        layout.addWidget(self.lbl_info)
    
    def _on_quick_access(self, index: int) -> None:
        """Quick access dropdown changed."""
        path = self.cmb_quick.itemData(index)
        if path:
            self._set_path(str(path))
    
    def _on_path_changed(self) -> None:
        """User changed path in text field."""
        new_path = self.txt_path.text()
        if Path(new_path).exists():
            self._set_path(new_path)
        else:
            self.txt_path.setText(self._current_path)
    
    def _go_up(self) -> None:
        """Go to parent directory."""
        parent = str(Path(self._current_path).parent)
        if parent != self._current_path:
            self._set_path(parent)
    
    def _set_path(self, path: str) -> None:
        """Set current browser path."""
        self._current_path = path
        self.txt_path.setText(path)
        self.tree.setRootIndex(self.model.index(path))
    
    def _on_double_click(self, index) -> None:
        """Handle double-click: enter directory or preview file."""
        file_path = self.model.filePath(index)
        
        if Path(file_path).is_dir():
            # Enter directory
            self._set_path(file_path)
        else:
            # TODO: Preview audio file (play in separate thread)
            self.lbl_info.setText(f"Datei: {Path(file_path).name}")
