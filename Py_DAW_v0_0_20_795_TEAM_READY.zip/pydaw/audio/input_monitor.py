"""Input-Monitor — Echtzeit-Audio-Passthrough via sounddevice.

v0.0.20.757 P0D:
  - Öffnet separaten sounddevice-Duplex-Stream (InputStream → OutputStream)
  - Latenz: buffer_size / sample_rate (~10ms bei 512/48000)
  - Thread-sicher: start/stop von GUI-Thread, Audio-Callback im RT-Thread
  - Volume + Mute steuerbar
  - Automatisch gestoppt wenn Recording startet (keine Rückkopplung)
"""
from __future__ import annotations

import threading
import logging
from typing import Optional

log = logging.getLogger(__name__)

try:
    import numpy as np
    _NP = True
except ImportError:
    _NP = False


class InputMonitor:
    """Echtzeit-Audio-Passthrough via sounddevice Duplex-Stream."""

    def __init__(self):
        self._lock      = threading.Lock()
        self._active    = False
        self._stream    = None
        self._volume    = 1.0    # 0..1
        self._muted     = False
        self._sr        = 48000
        self._buf       = 512
        self._in_dev    = None   # None = default
        self._out_dev   = None   # None = default
        self._vol_ref   = None   # v0.0.20.759: Shared ref für Audio-Callback
        self._mute_ref  = None   # v0.0.20.759: Shared ref für Audio-Callback

    # ── Konfiguration ──────────────────────────────────────────────────────

    def configure(self, sample_rate: int = 48000, buffer_size: int = 512,
                  input_device=None, output_device=None) -> None:
        self._sr     = int(sample_rate)
        self._buf    = int(buffer_size)
        self._in_dev  = input_device
        self._out_dev = output_device

    def set_volume(self, vol: float) -> None:
        self._volume = max(0.0, min(1.0, float(vol)))
        # v0.0.20.759: Auch die Audio-Callback-Referenz aktualisieren
        try:
            if hasattr(self, '_vol_ref') and self._vol_ref is not None:
                self._vol_ref[0] = self._volume
        except Exception:
            pass

    def set_muted(self, muted: bool) -> None:
        self._muted = bool(muted)
        # v0.0.20.759: Auch die Audio-Callback-Referenz aktualisieren
        try:
            if hasattr(self, '_mute_ref') and self._mute_ref is not None:
                self._mute_ref[0] = self._muted
        except Exception:
            pass

    def is_active(self) -> bool:
        return self._active

    # ── Start / Stop ───────────────────────────────────────────────────────

    def start(self) -> bool:
        """Startet den Passthrough-Stream. Gibt True bei Erfolg zurück."""
        with self._lock:
            if self._active:
                return True
            if not _NP:
                log.warning("InputMonitor: numpy nicht verfügbar")
                return False
            try:
                import sounddevice as sd

                vol_ref   = [self._volume]
                mute_ref  = [self._muted]
                self._vol_ref  = vol_ref
                self._mute_ref = mute_ref

                def _callback(indata, outdata, frames, time, status):
                    if status:
                        log.debug("InputMonitor status: %s", status)
                    if mute_ref[0]:
                        outdata.fill(0)
                    else:
                        try:
                            # Stereo: mono-Input auf beide Kanäle
                            if indata.shape[1] >= 2:
                                np.multiply(indata[:frames], vol_ref[0], out=outdata[:frames])
                            else:
                                # Mono-Input → beide Kanäle
                                mono = indata[:frames, 0:1] * vol_ref[0]
                                outdata[:frames, 0] = mono[:, 0]
                                outdata[:frames, 1] = mono[:, 0]
                        except Exception:
                            outdata.fill(0)

                self._stream = sd.Stream(
                    samplerate=self._sr,
                    blocksize=self._buf,
                    device=(self._in_dev, self._out_dev),
                    channels=(1, 2),   # 1 Eingang, 2 Ausgang
                    dtype="float32",
                    latency="low",
                    callback=_callback,
                )
                self._stream.start()
                self._active = True
                lat_ms = (self._stream.latency[0] + self._stream.latency[1]) * 1000
                log.info("InputMonitor gestartet: SR=%d buf=%d latenz=%.1fms",
                         self._sr, self._buf, lat_ms)
                return True
            except Exception as e:
                log.error("InputMonitor Start fehlgeschlagen: %s", e)
                self._stream = None
                self._active = False
                return False

    def stop(self) -> None:
        """Stoppt den Passthrough-Stream."""
        with self._lock:
            if not self._active:
                return
            try:
                if self._stream is not None:
                    self._stream.stop()
                    self._stream.close()
            except Exception as e:
                log.debug("InputMonitor Stop: %s", e)
            finally:
                self._stream  = None
                self._active  = False
                log.info("InputMonitor gestoppt")

    def get_latency_ms(self) -> float:
        """Gibt die aktuelle Latenz in ms zurück."""
        try:
            if self._stream and self._active:
                return (self._stream.latency[0] + self._stream.latency[1]) * 1000.0
        except Exception:
            pass
        return (self._buf / max(1, self._sr)) * 2000.0  # Schätzung

    def __del__(self):
        try:
            self.stop()
        except Exception:
            pass
