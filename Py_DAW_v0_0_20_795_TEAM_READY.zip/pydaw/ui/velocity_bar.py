"""Velocity Bar — Ableton/Bitwig-style Velocity-Streifen unter dem Piano Roll.

v0.0.20.752 P0B:
  - Zeigt für jede Note einen vertikalen Balken (Höhe = velocity/127)
  - Links-Drag auf Balken → Velocity ändern
  - Mehrere Noten selektiert → alle gemeinsam verschieben (Delta)
  - Scrollt synchron mit dem Piano Roll Canvas
  - Standard-Velocity-Anzeige oben links
"""
from __future__ import annotations

import math
from typing import Optional

from PyQt6.QtCore import Qt, QPointF, QRectF, QTimer
from PyQt6.QtGui import QColor, QPainter, QPen, QBrush, QFont
from PyQt6.QtWidgets import QWidget, QSizePolicy


_VEL_BAR_H = 70          # Standardhöhe in Pixeln
_BAR_MIN_W  = 4.0         # Mindestbreite eines Balkens
_BAR_GAP    = 1.0         # Abstand zwischen Balken


class VelocityBar(QWidget):
    """Velocity-Bar unter dem Piano Roll Canvas."""

    def __init__(self, canvas, scroll_area, parent=None):
        super().__init__(parent)
        self.canvas = canvas
        self.scroll_area = scroll_area

        self.setMinimumHeight(0)
        self.setFixedHeight(_VEL_BAR_H)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setMouseTracking(True)

        # Drag-State
        self._drag_active = False
        self._drag_note_idx: int = -1          # Einzelne Note die gezogen wird
        self._drag_start_y: float = 0.0
        self._drag_start_vel: int = 100
        self._drag_group_start: dict = {}      # {idx: start_vel} für Multi-Select

        # Hover
        self._hover_idx: int = -1

        # Scroll-Sync
        try:
            self.scroll_area.horizontalScrollBar().valueChanged.connect(self.update)
        except Exception:
            pass

        # Projekt-Update
        try:
            self.canvas.project.project_updated.connect(self.update)
        except Exception:
            pass

    # ── Koordinaten ────────────────────────────────────────────────────────

    def _scroll_x(self) -> float:
        try:
            return float(self.scroll_area.horizontalScrollBar().value())
        except Exception:
            return 0.0

    def _ppb(self) -> float:
        try:
            return float(getattr(self.canvas, "pixels_per_beat", 90.0) or 90.0)
        except Exception:
            return 90.0

    def _notes(self):
        try:
            cid = str(getattr(self.canvas, "clip_id", "") or "")
            if not cid:
                return []
            return list(self.canvas.project.get_midi_notes(cid) or [])
        except Exception:
            return []

    def _selected_indices(self):
        try:
            return set(self.canvas.selected_indices or set())
        except Exception:
            return set()

    def _note_bar_rect(self, note, idx: int) -> QRectF:
        """Gibt das Rechteck des Velocity-Balkens für eine Note zurück."""
        ppb = self._ppb()
        sx  = self._scroll_x()
        h   = float(self.height())

        note_x  = float(getattr(note, "start_beats", 0.0)) * ppb - sx
        note_w  = max(_BAR_MIN_W, float(getattr(note, "length_beats", 1.0)) * ppb - _BAR_GAP)
        vel     = max(1, min(127, int(getattr(note, "velocity", 100))))
        bar_h   = (vel / 127.0) * (h - 4.0)

        return QRectF(note_x, h - bar_h - 2.0, note_w, bar_h)

    def _note_at_x(self, x: float) -> int:
        """Index der Note deren Balken sich bei x befindet, oder -1."""
        notes = self._notes()
        for i, n in enumerate(notes):
            r = self._note_bar_rect(n, i)
            # Hit-Test: leicht verbreiterter Bereich
            if (r.left() - 2.0) <= x <= (r.right() + 2.0):
                return i
        return -1

    # ── Paint ──────────────────────────────────────────────────────────────

    def paintEvent(self, event):  # noqa: ANN001
        w, h = float(self.width()), float(self.height())
        # v0.0.20.759: Guard — kein Zeichnen wenn collapsed (h<=2)
        if h <= 2.0 or w <= 0.0:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)

        # Hintergrund
        p.fillRect(self.rect(), QColor(28, 28, 30))

        # Trennlinie oben
        p.setPen(QPen(QColor(60, 60, 65), 1))
        p.drawLine(QPointF(0, 0), QPointF(w, 0))

        notes  = self._notes()
        sel    = self._selected_indices()
        hover  = self._hover_idx

        for i, note in enumerate(notes):
            r = self._note_bar_rect(note, i)
            if r.right() < 0 or r.left() > w:
                continue  # außerhalb sichtbarem Bereich

            is_sel   = i in sel
            is_hover = i == hover
            vel      = max(1, min(127, int(getattr(note, "velocity", 100))))

            # Farbe: blau (normal) / orange (selected) / hell (hover)
            if is_sel:
                color = QColor(255, 165, 0, 220) if not is_hover else QColor(255, 200, 80, 255)
            elif is_hover:
                color = QColor(120, 200, 255, 220)
            else:
                # Farbverlauf: leise=dunkelblau, laut=hellblau
                t = vel / 127.0
                r_c = int(60  + t * 80)
                g_c = int(120 + t * 80)
                b_c = int(200 + t * 55)
                color = QColor(r_c, g_c, b_c, 200)

            p.setBrush(QBrush(color))
            p.setPen(QPen(color.lighter(130), 0))
            p.drawRect(r)

            # Velocity-Zahl über dem Balken (nur wenn breit genug)
            if r.width() >= 16 and (is_sel or is_hover):
                p.setPen(QPen(QColor(255, 255, 255, 200)))
                f = p.font()
                f.setPointSize(7)
                p.setFont(f)
                p.drawText(
                    QRectF(r.left(), r.top() - 12, r.width(), 12),
                    Qt.AlignmentFlag.AlignCenter,
                    str(vel)
                )

        # Label "Velocity" links oben
        p.setPen(QPen(QColor(120, 120, 130)))
        f2 = QFont()
        f2.setPointSize(7)
        p.setFont(f2)
        p.drawText(QRectF(2, 2, 50, 12), Qt.AlignmentFlag.AlignLeft, "Velocity")

        p.end()

    # ── Mouse ──────────────────────────────────────────────────────────────

    def mousePressEvent(self, event):  # noqa: ANN001
        if event.button() != Qt.MouseButton.LeftButton:
            return
        x = float(event.position().x())
        y = float(event.position().y())
        idx = self._note_at_x(x)
        if idx < 0:
            return

        notes = self._notes()
        sel   = self._selected_indices()

        self._drag_active    = True
        self._drag_note_idx  = idx
        self._drag_start_y   = y
        self._drag_start_vel = max(1, min(127, int(getattr(notes[idx], "velocity", 100))))

        # Undo-Snapshot vor dem Drag
        try:
            cid = str(getattr(self.canvas, "clip_id", "") or "")
            self._drag_before = self.canvas.project.snapshot_midi_notes(cid)
        except Exception:
            self._drag_before = None

        # Wenn die geklickte Note selektiert → Delta-Drag für alle Selektierten
        self._drag_group_start = {}
        if idx in sel:
            for si in sel:
                if 0 <= si < len(notes):
                    self._drag_group_start[si] = max(1, min(127,
                        int(getattr(notes[si], "velocity", 100))))
        else:
            self._drag_group_start = {idx: self._drag_start_vel}

        self.update()

    def mouseMoveEvent(self, event):  # noqa: ANN001
        x = float(event.position().x())
        y = float(event.position().y())

        if self._drag_active:
            h    = max(1.0, float(self.height()) - 4.0)
            dy   = float(self._drag_start_y) - y   # nach oben = mehr Velocity
            dvel = int(dy / h * 127.0)

            notes = self._notes()
            cid   = str(getattr(self.canvas, "clip_id", "") or "")
            if not cid:
                return

            for ni, base_vel in self._drag_group_start.items():
                if 0 <= ni < len(notes):
                    new_vel = max(1, min(127, base_vel + dvel))
                    try:
                        self.canvas.project.set_midi_note_velocity(cid, ni, new_vel)
                    except Exception:
                        # Fallback: direkt auf Note-Objekt schreiben + commit
                        try:
                            notes[ni].velocity = new_vel
                            self.canvas.project._emit_updated()
                        except Exception:
                            pass
            self.update()
        else:
            # Hover
            new_hover = self._note_at_x(x)
            if new_hover != self._hover_idx:
                self._hover_idx = new_hover
                self.update()

    def mouseReleaseEvent(self, event):  # noqa: ANN001
        if not self._drag_active:
            return
        self._drag_active = False
        # Commit Undo-Snapshot
        try:
            cid = str(getattr(self.canvas, "clip_id", "") or "")
            before = getattr(self, '_drag_before', None)
            self.canvas.project.commit_midi_notes_edit(cid, before, "Velocity ändern")
        except Exception:
            pass
        self._drag_before = None
        self.update()

    def leaveEvent(self, event):  # noqa: ANN001
        self._hover_idx = -1
        self.update()

    def mouseDoubleClickEvent(self, event):  # noqa: ANN001
        """Doppelklick auf Hintergrund → Default-Velocity auf aktueller Y-Position setzen."""
        if event.button() != Qt.MouseButton.LeftButton:
            return
        y = float(event.position().y())
        h = max(1.0, float(self.height()) - 4.0)
        new_vel = max(1, min(127, int((1.0 - y / h) * 127.0)))
        try:
            self.canvas._default_velocity = new_vel
        except Exception:
            pass
        self.update()

    def contextMenuEvent(self, event):  # noqa: ANN001
        """Rechtsklick → Velocity-Wert für alle selektierten Noten setzen."""
        from PyQt6.QtWidgets import QMenu, QInputDialog
        menu = QMenu(self)
        a_set = menu.addAction("Velocity für Selektion setzen…")
        a_default = menu.addAction(f"Default-Velocity: {getattr(self.canvas, '_default_velocity', 100)}")
        a_reset = menu.addAction("Alle selektierten → 100")
        act = menu.exec(event.globalPos())
        if act == a_set:
            val, ok = QInputDialog.getInt(self, "Velocity", "Velocity (1–127):",
                                          value=100, min=1, max=127)
            if ok:
                self._set_selected_velocity(val)
        elif act == a_default:
            val, ok = QInputDialog.getInt(self, "Default-Velocity",
                                          "Neue Default-Velocity (1–127):",
                                          value=int(getattr(self.canvas, '_default_velocity', 100)),
                                          min=1, max=127)
            if ok:
                try:
                    self.canvas._default_velocity = val
                except Exception:
                    pass
        elif act == a_reset:
            self._set_selected_velocity(100)

    def _set_selected_velocity(self, velocity: int) -> None:
        sel = self._selected_indices()
        notes = self._notes()
        if not sel:
            return
        cid = str(getattr(self.canvas, "clip_id", "") or "")
        try:
            before = self.canvas.project.snapshot_midi_notes(cid)
        except Exception:
            before = None
        for i in sel:
            if 0 <= i < len(notes):
                try:
                    self.canvas.project.set_midi_note_velocity(cid, i, velocity)
                except Exception:
                    try:
                        notes[i].velocity = max(1, min(127, int(velocity)))
                    except Exception:
                        pass
        try:
            self.canvas.project.commit_midi_notes_edit(cid, before, "Velocity setzen")
        except Exception:
            pass
        self.update()
