"""Fusion Oscillators — Sine, Triangle, Pulse, Saw with PolyBLEP.

v0.0.20.572: Phase 1 core oscillators.
v0.0.20.577: Performance — vectorized phase accumulation for Sine/Triangle,
             local variable caching, inline PolyBLEP (no function call overhead).
"""
from __future__ import annotations
import numpy as np
from .base import OscillatorBase
from typing import Optional


def _polyblep(t: float, dt: float) -> float:
    """PolyBLEP correction for a discontinuity at phase = 0.

    t: current phase position (0..1)
    dt: phase increment per sample (freq/sr)
    Returns correction value to add to the naive waveform.
    """
    if t < dt:
        # Rising edge: polynomial correction
        t_n = t / dt
        return t_n + t_n - t_n * t_n - 1.0
    elif t > 1.0 - dt:
        # Falling edge (wrap-around)
        t_n = (t - 1.0) / dt
        return t_n * t_n + t_n + t_n + 1.0
    return 0.0


# ═══════════════════════════════════════════════════════════
#  Vectorized Waveform Helpers (v0.0.20.785)
# ═══════════════════════════════════════════════════════════

def _vec_saw_polyblep(phases: np.ndarray, dt: float) -> np.ndarray:
    """Vectorized bandlimited sawtooth with PolyBLEP."""
    out = 2.0 * phases - 1.0
    if dt > 1e-12:
        mask_lo = phases < dt
        if np.any(mask_lo):
            t_n = phases[mask_lo] / dt
            out[mask_lo] -= t_n + t_n - t_n * t_n - 1.0
        mask_hi = phases > (1.0 - dt)
        if np.any(mask_hi):
            t_n = (phases[mask_hi] - 1.0) / dt
            out[mask_hi] -= t_n * t_n + t_n + t_n + 1.0
    return out


def _vec_pulse_polyblep(phases: np.ndarray, dt: float, width: float) -> np.ndarray:
    """Vectorized bandlimited pulse with PolyBLEP."""
    out = np.where(phases < width, 1.0, -1.0)
    if dt > 1e-12:
        # Rising edge
        mask_lo = phases < dt
        if np.any(mask_lo):
            t_n = phases[mask_lo] / dt
            out[mask_lo] -= t_n + t_n - t_n * t_n - 1.0
        mask_hi = phases > (1.0 - dt)
        if np.any(mask_hi):
            t_n = (phases[mask_hi] - 1.0) / dt
            out[mask_hi] -= t_n * t_n + t_n + t_n + 1.0
        # Falling edge
        tp2 = (phases - width + 1.0) % 1.0
        m2_lo = tp2 < dt
        if np.any(m2_lo):
            t_n = tp2[m2_lo] / dt
            out[m2_lo] += t_n + t_n - t_n * t_n - 1.0
        m2_hi = tp2 > (1.0 - dt)
        if np.any(m2_hi):
            t_n = (tp2[m2_hi] - 1.0) / dt
            out[m2_hi] += t_n * t_n + t_n + t_n + 1.0
    return out


def _vec_wave(wave_id: int, phases: np.ndarray, dt: float, width: float = 0.5) -> np.ndarray:
    """Vectorized waveform generation by wave ID.

    0=sine, 1=triangle, 2=saw (PolyBLEP), 3=pulse (PolyBLEP)
    """
    if wave_id == 0:
        return np.sin(2.0 * np.pi * phases)
    elif wave_id == 1:
        return np.where(phases < 0.5, 4.0 * phases - 1.0, 3.0 - 4.0 * phases)
    elif wave_id == 2:
        return _vec_saw_polyblep(phases, dt)
    else:
        return _vec_pulse_polyblep(phases, dt, width)


# ═══════════════════════════════════════════════════════════
#  Sine Oscillator
# ═══════════════════════════════════════════════════════════

class SineOscillator(OscillatorBase):
    """Pure sine with optional Skew and Fold waveshaping.

    v0.0.20.577: Vectorized phase accumulation with np.arange.
    Plain sine (no skew/fold) is ~10x faster. Fold still per-sample.
    """

    NAME = "Sine"

    def __init__(self, sr: int = 48000):
        super().__init__(sr)
        self._skew = 0.0    # -1..+1
        self._fold = 0.0    # 0..1

    def set_param(self, key: str, value: float) -> None:
        if key == "skew":
            self._skew = max(-1.0, min(1.0, float(value)))
        elif key == "fold":
            self._fold = max(0.0, min(1.0, float(value)))
        else:
            super().set_param(key, value)

    def get_param(self, key: str) -> float:
        if key == "skew":
            return self._skew
        if key == "fold":
            return self._fold
        return super().get_param(key)

    def param_names(self) -> list[str]:
        return ["skew", "fold"]

    def render(self, frames: int, freq: float, sr: int,
               phase_mod_buf: Optional[np.ndarray] = None) -> np.ndarray:
        dt = freq / sr
        phase0 = self._phase

        # Generate phase array (vectorized)
        phases = (phase0 + np.arange(frames, dtype=np.float64) * dt) % 1.0
        self._phase = (phase0 + frames * dt) % 1.0

        # Add phase modulation if present
        if phase_mod_buf is not None and self._phase_mod > 0.001:
            pm_len = min(frames, len(phase_mod_buf))
            phases[:pm_len] += phase_mod_buf[:pm_len] * self._phase_mod

        skew = self._skew
        fold = self._fold

        # Fast path: plain sine (most common, fully vectorized)
        if abs(skew) < 0.001 and fold < 0.001:
            return np.sin(2.0 * np.pi * phases)

        # Skew: asymmetric phase distortion
        if abs(skew) > 0.001:
            sp = phases.copy()
            lo = sp < 0.5
            hi = ~lo
            denom_lo = 1.0 - skew * 0.49
            denom_hi = 1.0 + skew * 0.49
            if abs(denom_lo) > 1e-9:
                sp[lo] = sp[lo] / denom_lo * 0.5
            if abs(denom_hi) > 1e-9:
                sp[hi] = 0.5 + (sp[hi] - 0.5) / denom_hi * 0.5
            raw = np.sin(2.0 * np.pi * sp)
        else:
            raw = np.sin(2.0 * np.pi * phases)

        # Fold waveshaping (vectorized reflection — replaces per-sample while loop)
        # v0.0.20.784: ~10x faster for fold > 0
        if fold > 0.001:
            gain = 1.0 + fold * 4.0
            raw *= gain
            # Reflect into [-1, 1] using triangle wave wrapping
            # Map to period 4: fold at ±1 boundaries
            raw = np.mod(raw - 1.0, 4.0)  # shift so 1.0 maps to 0
            raw = np.where(raw < 2.0, raw, 4.0 - raw) - 1.0

        return raw


# ═══════════════════════════════════════════════════════════
#  Triangle Oscillator
# ═══════════════════════════════════════════════════════════

class TriangleOscillator(OscillatorBase):
    """Bandlimited triangle wave with Skew and Fold.

    v0.0.20.577: Vectorized phase accumulation. Plain triangle fully
    vectorized (~8x faster). Skew/fold still per-sample where needed.
    """

    NAME = "Triangle"

    def __init__(self, sr: int = 48000):
        super().__init__(sr)
        self._skew = 0.0
        self._fold = 0.0

    def set_param(self, key: str, value: float) -> None:
        if key == "skew":
            self._skew = max(-1.0, min(1.0, float(value)))
        elif key == "fold":
            self._fold = max(0.0, min(1.0, float(value)))
        else:
            super().set_param(key, value)

    def get_param(self, key: str) -> float:
        if key == "skew":
            return self._skew
        if key == "fold":
            return self._fold
        return super().get_param(key)

    def param_names(self) -> list[str]:
        return ["skew", "fold"]

    def render(self, frames: int, freq: float, sr: int,
               phase_mod_buf: Optional[np.ndarray] = None) -> np.ndarray:
        dt = freq / sr
        phase0 = self._phase

        # Vectorized phase array
        phases = (phase0 + np.arange(frames, dtype=np.float64) * dt) % 1.0
        self._phase = (phase0 + frames * dt) % 1.0

        if phase_mod_buf is not None and self._phase_mod > 0.001:
            pm_len = min(frames, len(phase_mod_buf))
            phases[:pm_len] = (phases[:pm_len] + phase_mod_buf[:pm_len] * self._phase_mod) % 1.0

        # Vectorized naive triangle: 4*t-1 for t<0.5, 3-4*t for t>=0.5
        lo = phases < 0.5
        raw = np.where(lo, 4.0 * phases - 1.0, 3.0 - 4.0 * phases)

        skew = self._skew
        fold = self._fold

        # Fast path: no skew, no fold
        if abs(skew) < 0.001 and fold < 0.001:
            return raw

        # Skew (vectorized tanh)
        if abs(skew) > 0.001:
            factor = 1.0 + abs(skew) * 2.0
            raw = np.tanh(raw * factor) / np.tanh(factor)

        # Fold (vectorized reflection — v0.0.20.784)
        if fold > 0.001:
            gain = 1.0 + fold * 4.0
            raw *= gain
            # Reflect into [-1, 1] using triangle wave wrapping
            raw = np.mod(raw - 1.0, 4.0)
            raw = np.where(raw < 2.0, raw, 4.0 - raw) - 1.0

        return raw


# ═══════════════════════════════════════════════════════════
#  Pulse Oscillator (with PWM)
# ═══════════════════════════════════════════════════════════

class PulseOscillator(OscillatorBase):
    """Bandlimited pulse/square wave with variable pulse width (PWM).

    v0.0.20.577: Local variable caching, inline PolyBLEP.
    v0.0.20.784: Fully vectorized — numpy phase + vectorized PolyBLEP.
                 ~15-20x faster than per-sample loop.
    """

    NAME = "Pulse"

    def __init__(self, sr: int = 48000):
        super().__init__(sr)
        self._width = 0.5  # 0..1, 0.5 = square

    def set_param(self, key: str, value: float) -> None:
        if key == "width":
            self._width = max(0.01, min(0.99, float(value)))
        else:
            super().set_param(key, value)

    def get_param(self, key: str) -> float:
        if key == "width":
            return self._width
        return super().get_param(key)

    def param_names(self) -> list[str]:
        return ["width"]

    def render(self, frames: int, freq: float, sr: int,
               phase_mod_buf: Optional[np.ndarray] = None) -> np.ndarray:
        dt = freq / sr
        phase0 = self._phase
        width = self._width

        # Vectorized phase accumulation
        phases = (phase0 + np.arange(frames, dtype=np.float64) * dt) % 1.0
        self._phase = (phase0 + frames * dt) % 1.0

        # Phase modulation
        if phase_mod_buf is not None and self._phase_mod > 0.001:
            pm_len = min(frames, len(phase_mod_buf))
            phases[:pm_len] = (phases[:pm_len] + phase_mod_buf[:pm_len] * self._phase_mod) % 1.0

        # Naive pulse: +1 where phase < width, -1 otherwise (vectorized)
        out = np.where(phases < width, 1.0, -1.0)

        if dt > 1e-12:
            # PolyBLEP at rising edge (phase ≈ 0)
            mask_lo = phases < dt
            if np.any(mask_lo):
                t_n = phases[mask_lo] / dt
                out[mask_lo] -= t_n + t_n - t_n * t_n - 1.0
            mask_hi = phases > (1.0 - dt)
            if np.any(mask_hi):
                t_n = (phases[mask_hi] - 1.0) / dt
                out[mask_hi] -= t_n * t_n + t_n + t_n + 1.0

            # PolyBLEP at falling edge (phase ≈ width)
            tp2 = (phases - width + 1.0) % 1.0
            mask_lo2 = tp2 < dt
            if np.any(mask_lo2):
                t_n = tp2[mask_lo2] / dt
                out[mask_lo2] += t_n + t_n - t_n * t_n - 1.0
            mask_hi2 = tp2 > (1.0 - dt)
            if np.any(mask_hi2):
                t_n = (tp2[mask_hi2] - 1.0) / dt
                out[mask_hi2] += t_n * t_n + t_n + t_n + 1.0

        return out


# ═══════════════════════════════════════════════════════════
#  Saw Oscillator
# ═══════════════════════════════════════════════════════════

class SawOscillator(OscillatorBase):
    """Bandlimited sawtooth wave with PolyBLEP.

    v0.0.20.577: Local variable caching, inline PolyBLEP (no function call).
    v0.0.20.784: Fully vectorized — numpy phase array + vectorized PolyBLEP.
                 ~15-20x faster than per-sample loop.
    """

    NAME = "Saw"

    def render(self, frames: int, freq: float, sr: int,
               phase_mod_buf: Optional[np.ndarray] = None) -> np.ndarray:
        dt = freq / sr
        phase0 = self._phase

        # Vectorized phase accumulation
        phases = (phase0 + np.arange(frames, dtype=np.float64) * dt) % 1.0
        self._phase = (phase0 + frames * dt) % 1.0

        # Phase modulation
        if phase_mod_buf is not None and self._phase_mod > 0.001:
            pm_len = min(frames, len(phase_mod_buf))
            phases[:pm_len] = (phases[:pm_len] + phase_mod_buf[:pm_len] * self._phase_mod) % 1.0

        # Naive saw: 2*phase - 1 (vectorized)
        out = 2.0 * phases - 1.0

        # Vectorized PolyBLEP correction at discontinuity (phase ≈ 0/1)
        if dt > 1e-12:
            # Rising edge: tp < dt
            mask_lo = phases < dt
            if np.any(mask_lo):
                t_n = phases[mask_lo] / dt
                out[mask_lo] -= t_n + t_n - t_n * t_n - 1.0

            # Falling edge: tp > 1-dt
            mask_hi = phases > (1.0 - dt)
            if np.any(mask_hi):
                t_n = (phases[mask_hi] - 1.0) / dt
                out[mask_hi] -= t_n * t_n + t_n + t_n + 1.0

        return out


# ═══════════════════════════════════════════════════════════
#  Registry
# ═══════════════════════════════════════════════════════════

OSC_REGISTRY: dict[str, type] = {
    "sine": SineOscillator,
    "triangle": TriangleOscillator,
    "pulse": PulseOscillator,
    "saw": SawOscillator,
}


def create_oscillator(name: str, sr: int = 48000) -> OscillatorBase:
    """Factory: create oscillator by name."""
    cls = OSC_REGISTRY.get(name.lower())
    if cls is None:
        raise ValueError(f"Unknown oscillator: {name}")
    return cls(sr=sr)
