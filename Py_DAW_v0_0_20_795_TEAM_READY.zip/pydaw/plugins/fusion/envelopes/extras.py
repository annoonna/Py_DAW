"""Fusion Envelopes — AR (Attack-Release), AD (Attack-Decay with Loop), Pluck.

v0.0.20.573: Phase 2 extended envelopes.
v0.0.20.577: Performance — local variable caching, pre-computed rates,
             vectorized sustain (AR), vectorized decay (Pluck).
"""
from __future__ import annotations
import math
import numpy as np
from .adsr import EnvelopeBase

_OFF = 0
_ATTACK = 1
_SUSTAIN = 2
_RELEASE = 3
_DECAY = 4


class AREnvelope(EnvelopeBase):
    """Attack-Release envelope. Sustain = 100% while gate is held."""

    NAME = "AR"

    def __init__(self, sr: int = 48000):
        super().__init__(sr)
        self._attack = 0.01
        self._release = 0.5
        self._curve = 0.0     # -1..+1 (neg=log, 0=linear, pos=exp)
        self._stage = _OFF
        self._level = 0.0
        self._vel = 1.0

    def set_param(self, key: str, value: float) -> None:
        if key == "attack":
            self._attack = max(0.0001, min(10.0, float(value)))
        elif key == "release":
            self._release = max(0.0001, min(30.0, float(value)))
        elif key == "curve":
            self._curve = max(-1.0, min(1.0, float(value)))

    def gate_on(self, velocity: float = 1.0) -> None:
        self._vel = max(0.0, min(1.0, float(velocity)))
        self._stage = _ATTACK

    def gate_off(self) -> None:
        if self._stage != _OFF:
            self._stage = _RELEASE

    def is_active(self) -> bool:
        return self._stage != _OFF

    def render(self, frames: int) -> np.ndarray:
        """v0.0.20.784: Block-per-stage vectorization."""
        # Fast paths
        if self._stage == _OFF:
            return np.zeros(frames, dtype=np.float64)
        if self._stage == _SUSTAIN:
            return np.full(frames, self._vel, dtype=np.float64)

        out = np.empty(frames, dtype=np.float64)
        sr = self._sr
        stage = self._stage
        level = self._level
        vel = self._vel
        atk_rate = 1.0 / max(1, int(self._attack * sr))
        rel_rate = 1.0 / max(1, int(self._release * sr))

        pos = 0
        while pos < frames:
            remaining = frames - pos

            if stage == _OFF:
                out[pos:] = 0.0
                pos = frames
            elif stage == _SUSTAIN:
                out[pos:] = vel
                pos = frames
            elif stage == _ATTACK:
                n_to_one = max(1, int((1.0 - level) / atk_rate) + 1)
                n_block = min(remaining, n_to_one)
                indices = np.arange(n_block, dtype=np.float64)
                levels = level + indices * atk_rate
                crossed = levels >= 1.0
                if np.any(crossed):
                    fc = int(np.argmax(crossed))
                    n_block = fc + 1
                    levels = levels[:n_block]
                    levels[fc] = 1.0
                    level = 1.0
                    stage = _SUSTAIN
                else:
                    level = float(levels[-1])
                np.clip(levels, 0.0, 1.0, out=levels)
                out[pos:pos + n_block] = levels * vel
                pos += n_block
            elif stage == _RELEASE:
                n_to_zero = max(1, int(level / rel_rate) + 1)
                n_block = min(remaining, n_to_zero)
                indices = np.arange(n_block, dtype=np.float64)
                levels = level - indices * rel_rate
                crossed = levels <= 0.0
                if np.any(crossed):
                    fc = int(np.argmax(crossed))
                    n_block = fc + 1
                    levels = levels[:n_block]
                    levels[fc] = 0.0
                    level = 0.0
                    stage = _OFF
                else:
                    level = float(levels[-1])
                np.clip(levels, 0.0, 1.0, out=levels)
                out[pos:pos + n_block] = levels * vel
                pos += n_block
            else:
                out[pos] = 0.0
                pos += 1

        self._stage = stage
        self._level = level
        return out


class ADEnvelope(EnvelopeBase):
    """Attack-Decay envelope with optional loop (becomes LFO-like)."""

    NAME = "AD"

    def __init__(self, sr: int = 48000):
        super().__init__(sr)
        self._attack = 0.005
        self._decay = 0.3
        self._loop = False
        self._stage = _OFF
        self._level = 0.0
        self._vel = 1.0

    def set_param(self, key: str, value: float) -> None:
        if key == "attack":
            self._attack = max(0.0001, min(10.0, float(value)))
        elif key == "decay":
            self._decay = max(0.0001, min(30.0, float(value)))
        elif key == "loop":
            self._loop = bool(float(value) > 0.5)

    def gate_on(self, velocity: float = 1.0) -> None:
        self._vel = max(0.0, min(1.0, float(velocity)))
        self._level = 0.0
        self._stage = _ATTACK

    def gate_off(self) -> None:
        self._stage = _OFF
        self._level = 0.0

    def is_active(self) -> bool:
        return self._stage != _OFF

    def render(self, frames: int) -> np.ndarray:
        """v0.0.20.784: Block-per-stage vectorization."""
        if self._stage == _OFF:
            return np.zeros(frames, dtype=np.float64)

        out = np.empty(frames, dtype=np.float64)
        sr = self._sr
        stage = self._stage
        level = self._level
        vel = self._vel
        loop = self._loop
        atk_rate = 1.0 / max(1, int(self._attack * sr))
        dec_rate = 1.0 / max(1, int(self._decay * sr))

        pos = 0
        while pos < frames:
            remaining = frames - pos

            if stage == _OFF:
                out[pos:] = 0.0
                pos = frames
            elif stage == _ATTACK:
                n_to_one = max(1, int((1.0 - level) / atk_rate) + 1)
                n_block = min(remaining, n_to_one)
                indices = np.arange(n_block, dtype=np.float64)
                levels = level + indices * atk_rate
                crossed = levels >= 1.0
                if np.any(crossed):
                    fc = int(np.argmax(crossed))
                    n_block = fc + 1
                    levels = levels[:n_block]
                    levels[fc] = 1.0
                    level = 1.0
                    stage = _DECAY
                else:
                    level = float(levels[-1])
                np.clip(levels, 0.0, 1.0, out=levels)
                out[pos:pos + n_block] = levels * vel
                pos += n_block
            elif stage == _DECAY:
                n_to_zero = max(1, int(level / dec_rate) + 1)
                n_block = min(remaining, n_to_zero)
                indices = np.arange(n_block, dtype=np.float64)
                levels = level - indices * dec_rate
                crossed = levels <= 0.0
                if np.any(crossed):
                    fc = int(np.argmax(crossed))
                    n_block = fc + 1
                    levels = levels[:n_block]
                    levels[fc] = 0.0
                    level = 0.0
                    stage = _ATTACK if loop else _OFF
                else:
                    level = float(levels[-1])
                np.clip(levels, 0.0, 1.0, out=levels)
                out[pos:pos + n_block] = levels * vel
                pos += n_block
            else:
                out[pos] = 0.0
                pos += 1

        self._stage = stage
        self._level = level
        return out


class PluckEnvelope(EnvelopeBase):
    """Exponential pluck decay — string-like, no sustain."""

    NAME = "Pluck"

    def __init__(self, sr: int = 48000):
        super().__init__(sr)
        self._decay = 0.5        # seconds
        self._brightness = 0.5   # 0..1 (LP filter on output)
        self._stage = _OFF
        self._level = 0.0
        self._vel = 1.0
        self._lp_state = 0.0

    def set_param(self, key: str, value: float) -> None:
        if key == "decay":
            self._decay = max(0.0001, min(30.0, float(value)))
        elif key == "brightness":
            self._brightness = max(0.0, min(1.0, float(value)))

    def gate_on(self, velocity: float = 1.0) -> None:
        self._vel = max(0.0, min(1.0, float(velocity)))
        self._level = 1.0
        self._lp_state = 0.0
        self._stage = _DECAY

    def gate_off(self) -> None:
        pass  # Pluck ignores gate off — it's purely decay-based

    def is_active(self) -> bool:
        return self._stage != _OFF and self._level > 0.0001

    def render(self, frames: int) -> np.ndarray:
        """v0.0.20.784: Vectorized exponential decay + scipy.signal.lfilter
        for the brightness LP filter. ~10x faster.
        """
        if self._stage == _OFF:
            return np.zeros(frames, dtype=np.float64)

        # Pre-compute coefficients
        decay_rate = math.exp(-1.0 / (self._decay * self._sr)) if self._decay > 0 else 0.0
        lp_coeff = 0.05 + self._brightness * 0.95
        vel = self._vel
        level = self._level

        # Vectorized exponential decay: level * decay_rate^n
        indices = np.arange(frames, dtype=np.float64)
        levels = level * (decay_rate ** indices)

        # Find where level drops below threshold
        below = levels < 0.0001
        if np.any(below):
            first_below = int(np.argmax(below))
            levels[first_below:] = 0.0
            self._level = 0.0
            self._stage = _OFF
        else:
            self._level = float(levels[-1]) * decay_rate

        # LP filter on levels: lp_state += lp_coeff * (level - lp_state)
        # This is a 1-pole IIR: H(z) = lp_coeff / (1 - (1 - lp_coeff) * z^-1)
        try:
            from scipy.signal import lfilter
            b = np.array([lp_coeff])
            a = np.array([1.0, -(1.0 - lp_coeff)])
            zi = np.array([self._lp_state * (1.0 - lp_coeff)])
            filtered, zf = lfilter(b, a, levels, zi=zi)
            self._lp_state = float(zf[0]) / (1.0 - lp_coeff) if abs(1.0 - lp_coeff) > 1e-12 else float(levels[-1])
        except ImportError:
            # Fallback: per-sample LP
            filtered = np.empty(frames, dtype=np.float64)
            lp_state = self._lp_state
            for i in range(frames):
                lp_state += lp_coeff * (levels[i] - lp_state)
                filtered[i] = lp_state
            self._lp_state = lp_state

        return filtered * vel
