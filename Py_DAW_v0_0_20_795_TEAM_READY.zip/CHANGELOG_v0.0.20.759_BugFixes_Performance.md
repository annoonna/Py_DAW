# CHANGELOG v0.0.20.759 — Bug-Fixes, Performance & Code-Review

**Datum:** 2026-03-23
**Autor:** Claude Opus 4.6
**Arbeitspaket:** Code-Review + Bug-Fixes (Qualitätssicherung)

## Was wurde gemacht

### 🔴 Bug-Fixes (kritisch)

1. **InputMonitor: set_volume/set_muted hatten keinen Effekt nach start()**
   - `set_volume()` und `set_muted()` aktualisierten `self._volume`/`self._muted`,
     aber der Audio-Callback las aus `vol_ref[0]`/`mute_ref[0]` — einer Closure-Variable
     die nur beim `start()` gesetzt wurde.
   - **Fix:** `set_volume()`/`set_muted()` aktualisieren jetzt auch die `_vol_ref[0]`/`_mute_ref[0]`
     Referenzen. `__init__` initialisiert `_vol_ref`/`_mute_ref` mit `None` (vorher undefiniert).

2. **main_window: Falscher Import-Pfad in _on_monitor_toggled()**
   - `from pydaw.utils.settings import get_value, SettingsKeys` → Modul existiert nicht!
   - **Fix:** Korrekter Pfad: `from pydaw.core.settings import SettingsKeys` +
     `from pydaw.core.settings_store import get_value`
   - Dieser Bug verhinderte die Audio-Buffer-Synchronisierung beim Monitor-Start
     (fiel in den `except`-Block und wurde verschluckt).

3. **BRRR Engine: `pull()` ignorierte den `sr`-Parameter**
   - Die Engine rechnete immer mit `self._sr` vom Konstruktor, nicht mit der
     tatsächlichen Sample-Rate die von der AudioEngine übergeben wird.
   - **Fix:** SR-Wechsel-Erkennung in `pull()` — aktualisiert alle Voice-SRs
     und berechnet BP-Filter-Koeffizienten neu.

### 🟡 Performance-Verbesserungen

4. **BRRR `_SampleAndHoldLFO`: Echte Vektorisierung**
   - Der alte Code hatte einen Python `for i in range(frames)` Loop trotz
     "vektorisiert" Docstring → ~10x langsamer als nötig.
   - **Fix:** Segment-basierter Ansatz: `np.diff()` + `np.nonzero()` statt per-Sample.
   - Ergebnis: 100×1024 Blocks in 2.3ms (vorher >20ms).

5. **BRRR `_SimpleEnv`: Block-ADSR statt per-Sample Loop**
   - Alter Code: `for i in range(frames)` mit Python if/elif pro Sample.
   - **Fix:** Stage-basierte Blockverarbeitung mit `np.linspace()` — Attack, Decay,
     Release als durchgehende Rampen. Sustain als `np.full()`.
   - Ergebnis: 100×1024 Blocks in 0.3ms.

### 🟢 Robustheit

6. **VelocityBar: Guard für collapsed-Zustand**
   - `paintEvent()` konnte bei `height=0` (collapsed) unnötig QPainter erstellen.
   - **Fix:** Early-return wenn `h <= 2.0`.

## Geänderte Dateien

| Datei | Änderung |
|---|---|
| `pydaw/audio/input_monitor.py` | set_volume/set_muted ref-sync, _vol_ref/_mute_ref init |
| `pydaw/ui/main_window.py` | Import-Pfad Fix (pydaw.utils.settings → pydaw.core.settings) |
| `pydaw/plugins/brrr/brrr_engine.py` | SR-Sync in pull(), S&H LFO vectorization, SimpleEnv block processing |
| `pydaw/ui/velocity_bar.py` | paintEvent collapsed guard |
| `pydaw/version.py` | 0.0.20.759 |
| `VERSION` | 0.0.20.759 |

## Tests

- ✅ 314 Python-Dateien kompilieren fehlerfrei
- ✅ BRRR Engine: note_on → pull → Stereo-Output korrekt
- ✅ BRRR S&H LFO: 5 unique values/s bei 5Hz (korrekt)
- ✅ BRRR SimpleEnv: Attack→Decay→Sustain→Release Phasen korrekt
- ✅ BRRR SR-Wechsel: 44100→48000 ohne Crash
- ✅ InputMonitor: vol_ref/mute_ref Sync nach start()

## Was als nächstes zu tun ist

- [ ] Hardware-Test: InputMonitor Start → Volume-Slider → Latenz?
- [ ] BRRR auf echtem Audio: Note spielen → Ton hörbar, keine Clicks?
- [ ] P0D Beta-Changelog schreiben
- [ ] P1A Recording-Workflow testen

## Bekannte Probleme / Offene Fragen

- Keine neuen Probleme eingeführt
- InputMonitor `channels=(1, 2)` → der Stereo-Input-Branch im Callback ist aktuell
  toter Code (wird nur aktiv wenn jemand channels auf (2,2) ändert). Nicht kaputt,
  aber könnte vereinfacht werden.
