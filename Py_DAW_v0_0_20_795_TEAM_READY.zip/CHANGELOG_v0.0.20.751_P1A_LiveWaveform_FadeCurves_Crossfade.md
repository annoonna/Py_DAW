# CHANGELOG v0.0.20.751 — P1A: Live-Waveform, Fade-Kurven, Crossfade-Editor

**Datum:** 2026-03-23  **Autor:** Claude Sonnet 4.6

## Was wurde gemacht

### P1A — Live-Waveform-Preview während Recording
- `recording_service.py`: `get_live_waveform_peaks(track_id, num_pixels)` — gibt Peak-Arrays der letzten 10s
- `main_window.py`: 100ms QTimer → `_update_recording_waveform_preview()` → `canvas._live_waveform_cache`
- `arranger_canvas.py`: Roter "● REC"-Clip mit wachsender Live-Waveform im Arranger

### P1A — Clip-Gain-Envelope Visualisierung
- `arranger_canvas.py` (`_draw_audio_waveform`): Grüne Kurve + Dots direkt über Waveform
- Liest `clip.clip_automation["gain"]` Breakpoints — Bitwig-Stil

### P1A — Fade-Kurven: Log, Exp, S-Kurve
- `model/project.py`: `fade_in_curve` + `fade_out_curve` Felder (linear/log/exp/scurve)
- `project_service.py`: `update_audio_clip_params()` um beide Felder erweitert
- `arrangement_renderer.py`: `_fade_ramp()` mit echten Kurven
- `arranger_canvas.py` (`_draw_clip_fades`): Kurvenförmige Fade-Overlays + Kurventyp-Label
- Kontextmenü "Fades → Fade-In/Out Kurve → [Linear/Log/Exp/S-Kurve]"

### P1A — Crossfade-Editor
- `model/project.py`: `crossfade_beats` + `crossfade_curve` Felder (linear/eqpower/scurve)
- `project_service.py`: update_audio_clip_params um crossfade erweitert
- `arrangement_renderer.py` (`PreparedClip`): `crossfade_samples` + `crossfade_curve`; in `render_track()`: Equal-Power/Linear/S-Kurve Crossfade bei Clip-Überlappung
- `arranger_canvas.py` (`_draw_crossfade`): X-förmige Crossfade-Visualisierung zwischen überlappenden Clips; automatische Erkennung + Zeichnung im paintEvent
- Kontextmenü "Fades → ↔ Crossfade → [1/16/1/8/1/4/1/2/1 Bar] + Kurve"

## Geänderte Dateien
| Datei | Änderung |
|---|---|
| `pydaw/model/project.py` | fade_in/out_curve, crossfade_beats/curve |
| `pydaw/services/project_service.py` | update_audio_clip_params +crossfade |
| `pydaw/services/recording_service.py` | get_live_waveform_peaks() |
| `pydaw/audio/arrangement_renderer.py` | _fade_ramp(), crossfade in PreparedClip + render_track |
| `pydaw/ui/arranger_canvas.py` | Live-Waveform, Gain-Env, Fade-Kurven, _draw_crossfade |
| `pydaw/ui/main_window.py` | _rec_waveform_timer, _update_recording_waveform_preview |
