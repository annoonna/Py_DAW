# Session Log — v0.0.20.782

**Datum:** 2026-03-23
**Kollege:** Claude Opus 4.6
**Aufgabe:** Rust Engine Crash-Reconnect-Zyklus fixen (cpal entfernen, Listener-Loop)

## Analyse

Aus den Screenshots und dem Terminal-Log war der Crash-Zyklus klar ersichtlich:

```
Engine startet (48000Hz/1024buf) → Python sendet Configure(44100/512)
→ Graph-Buffers resized auf 512 → cpal-Callback ruft process_audio mit 1024 Frames
→ Buffer-Overflow → Engine crasht → EOF → Python Reconnect → selber Crash
```

Im PipeWire Graph waren zwei Audio-Nodes sichtbar:
- "PipeWire ALSA [python3.13]" (Python sounddevice — korrekt)
- "PipeWire ALSA [pydaw_engine]" (Rust cpal — ÜBERFLÜSSIG und Crash-Ursache)

## Was wurde erledigt

### 1. main.rs komplett umgeschrieben
- **cpal komplett entfernt** — kein eigener Audio-Stream, kein PipeWire-Node
- **Listener-Loop**: Engine bleibt nach Client-Disconnect am Leben, wartet auf neuen Connect
- **Command-Drain-Ticker** (100Hz Thread): Ersetzt cpal-Callback als drain_commands()-Treiber
- Frische EngineState pro Connection

### 2. start_daw.sh
- ALSA Dev-Headers Check entfernt (cpal braucht kein libasound2-dev mehr)

### 3. Version + Dokumentation
- VERSION → 0.0.20.782
- version.py → 0.0.20.782
- CHANGELOG, Session-Log, LATEST.md, TODO.md, DONE.md

## Geänderte Dateien
- pydaw_engine/src/main.rs (komplett umgeschrieben)
- start_daw.sh (ALSA-Check entfernt)
- VERSION, pydaw/version.py (→ 0.0.20.782)
- CHANGELOG_v0.0.20.782_IPC_ONLY_ENGINE.md (neu)
- PROJECT_DOCS/sessions/SESSION_v0.0.20.782_IPC_ONLY_ENGINE.md (neu)
- PROJECT_DOCS/sessions/LATEST.md (überschrieben)
- PROJECT_DOCS/progress/TODO.md (aktualisiert)
- PROJECT_DOCS/progress/DONE.md (aktualisiert)

## Nächste Schritte
1. `cargo build --release` — Build ohne cpal-Dependency sollte deutlich schneller sein
2. PipeWire Graph testen — nur noch 1 Audio-Node (Python) statt 2
3. Engine-Reconnect testen — kein Crash-Zyklus mehr
4. Export-Dialog testen — Realtime-Capture sollte jetzt funktionieren
5. Optional: Phase R12 (IPC Audio-Buffer Bridge) für Rust-basiertes Rendering
