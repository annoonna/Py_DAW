# Session Log — v0.0.20.783

**Datum:** 2026-03-23
**Kollege:** Claude Opus 4.6
**Aufgabe:** Export Fix (Offline-Rendering + Dateiname-Dialog)

## Was wurde erledigt

### 1. render_offline() komplett umgeschrieben
- Echtes Offline-Rendering statt kaputtem Realtime-Capture
- ArrangementState + prepare_clips() + MIDI Dispatch + Pull-Sources
- Track vol/pan/mute/solo + Master Volume + Soft Clip
- track_ids Filter für Stem-Export

### 2. Export-Dialog: Save-Dialog mit Dateiname
- QFileDialog.getSaveFileName statt getExistingDirectory
- Auto-Vorschlag: Projektname_BPM.ext
- Filter-String je Format

### 3. Export-Service: Dateiname direkt nutzen
- Kein _120BPM Suffix mehr für Einzelexport

### 4. UI-Fixes
- Echtzeit-Checkbox default unchecked
- Progress-Text korrigiert
- Cancel-Logic bereinigt

## Geänderte Dateien
- pydaw/audio/audio_engine.py
- pydaw/ui/audio_export_dialog.py
- pydaw/services/audio_export_service.py
- VERSION, pydaw/version.py

## Nächste Schritte
- Testen: Datei → Exportieren → Dateiname wählen → Datei im Ordner prüfen
- Audio-Inhalt verifizieren (nicht nur Stille)
