# Session Log — v0.0.20.793

**Datum:** 2026-03-24
**Kollege:** Claude Opus 4.6
**Aufgabe:** Rust-Engine Disconnect-Loop — Root Cause Fix

## Root Cause (jetzt korrekt identifiziert)

### Problem 1: Doppelte Engine (start_daw.sh + Python Bridge)
`start_daw.sh` startete Engine als Hintergrundprozess → Engine band Socket.
Python-Bridge rief `start_engine()` auf → startete ZWEITE Engine → Socket-Konflikt.

### Problem 2: PIPE-Buffer Overflow (der ECHTE 1s-EOF Bug)
`subprocess.Popen(..., stdout=PIPE, stderr=PIPE)` — NIEMAND liest diese Pipes!
Die Rust-Engine nutzt `env_logger` → schreibt auf stderr → 65KB Pipe-Buffer füllt sich
→ Engine blockiert bei nächstem `write()` → Socket wird nicht mehr bedient → EOF.

## Fix (2 Stellen)

### 1. start_daw.sh — Engine NICHT mehr als Hintergrundprozess starten
- Baut weiterhin die Engine (`cargo build --release`)
- Startet sie NICHT mehr als Background-Prozess
- Python-Bridge macht das jetzt selbst via `start_engine()`
- Kein Socket-Konflikt, kein Race

### 2. rust_engine_bridge.py — KEIN PIPE mehr!
- `stdout=subprocess.DEVNULL` (Engine hat keinen stdout Output)
- `stderr=None` (erbt Parent-Terminal → Logs sichtbar in Terminal)
- KEIN Pipe-Buffer der volllaufen kann → KEIN Deadlock → KEIN EOF

## Erwartetes Log (nachher)
```
🦀 Rust-Engine: bereit
🚀 Starte Py_DAW...
[Bridge] Starting engine: pydaw_engine
[Bridge] Engine PID: 12345
[Engine] Py_DAW Audio Engine starting...
[Engine] Listening on /tmp/pydaw_engine.sock
[Engine] Client connected
[Bridge] Connected to engine
[Bridge] Engine ready: sr=44100, buf=512
                                          ← KEIN DISCONNECT
```

## Geänderte Dateien
- start_daw.sh (Engine-Start entfernt, nur noch Build)
- pydaw/services/rust_engine_bridge.py (PIPE → DEVNULL/None)
- VERSION, pydaw/version.py
