# Session Log — v0.0.20.774

**Datum:** 2026-03-23
**Kollege:** Claude Opus 4.6
**Aufgabe:** VST2 Plugin-State Persistenz (ZynAddSubFX Presets bleiben erhalten)

## Bug
ZynAddSubFX Presets gingen beim Projekt-Neuladen verloren weil
`embed_project_state_blobs()` versuchte den State mit pedalboard (VST3-only)
zu laden. Für VST2 Plugins schlug das immer fehl:
```
[VST3] export_state_blob: load failed for ZynAddSubFX.so: unsupported plugin format
```

## Root Cause
- Save: `embed_project_state_blobs()` → `export_state_blob()` → pedalboard → FAIL für VST2
- Load: `Vst2InstrumentEngine._load()` → `set_chunk()` → war schon implementiert!
- Problem war NUR die Save-Seite

## Fix
1. `embed_project_state_blobs(project, audio_engine)` — neuer Parameter
2. Für `ext.vst2:` Plugins: `_get_vst2_state_blob()` holt Chunk von laufender Engine
   via `audio_engine._vst_instrument_engines[track_id]._plugin.get_chunk()`
3. Chunk → Base64 → `__ext_state_b64` in Project JSON
4. Beim Laden: bestehender Code in `Vst2InstrumentEngine._load()` restauriert via `set_chunk()`
5. `project_service.py`: Beide Save-Aufrufe geben jetzt `audio_engine` mit

## Geänderte Dateien
- pydaw/audio/vst3_host.py (embed_project_state_blobs + _get_vst2_state_blob)
- pydaw/services/project_service.py (audio_engine Parameter mitgeben)
- pydaw/version.py, VERSION (→ 0.0.20.774)

## Test
1. ZynAddSubFX Preset laden (z.B. mosipledream5)
2. Projekt speichern (Ctrl+S)
3. Py_DAW schließen + neu starten
4. ZynAddSubFX sollte das Preset noch haben
