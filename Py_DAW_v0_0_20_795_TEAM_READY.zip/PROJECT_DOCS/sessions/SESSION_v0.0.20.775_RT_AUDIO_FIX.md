# Session Log — v0.0.20.775

**Datum:** 2026-03-23
**Kollege:** Claude Opus 4.6
**Aufgabe:** Realtime Audio Performance Fix (Stottern, 3s Aussetzer, kein RT)

## Problem (vom Auftraggeber)
- Sound stockt komplett, 3-Sekunden-Aussetzer
- CPU bei 21%, nichts ist flüssig
- Benchmark zeigt gute rohe Performance aber echte Wiedergabe unbrauchbar
- 5 Tracks, Buffer 1024, SR 48000

## Root Cause Analysis
6 separate Ursachen identifiziert durch Code-Analyse:

1. Audio-Thread ohne RT-Priority → Kernel preempts für GUI
2. Python GIL-Contention zwischen GUI und Audio
3. GC-Pausen im Audio-Thread (5-50ms)
4. threading.Lock in VST2 host callback (Audio-Thread!)
5. threading.RLock in _pull_sources_snapshot (Audio-Thread!)
6. **HAUPTURSACHE:** Jeder MIDI-Edit → stop() + deepcopy + prepare + restart = 2-3s Lücke

## Was wurde erledigt
- **NEU: pydaw/audio/rt_thread.py** — SCHED_FIFO/RR, GC disable, mlockall
- **FIX: audio_engine.py** — RT-Priority in _EngineThread.run()
- **FIX: audio_engine.py** — hot_swap_arrangement() statt Stop/Restart
- **FIX: audio_engine.py** — Lock-free _pull_sources_snapshot()
- **FIX: vst2_host.py** — Lock-free _audio_master_callback
- **FIX: main_window.py** — Hot-swap in _restart_playback_if_playing
- **FIX: main_window.py** — MIDI debounce 80ms → 200ms

## Geänderte Dateien
- pydaw/audio/rt_thread.py (NEU, 130 Zeilen)
- pydaw/audio/audio_engine.py (3 Stellen geändert)
- pydaw/audio/vst2_host.py (1 Stelle geändert)
- pydaw/ui/main_window.py (2 Stellen geändert)
- pydaw/version.py, VERSION (→ 0.0.20.775)

## Nächste Schritte
- Testen: Playback starten, MIDI editieren → kein Aussetzer mehr?
- Falls noch Stutter: Buffer-Size erhöhen (512/1024)
- Langfristig: Rust Engine aktivieren (alle Phasen R1-R13 fertig)
- RT-Permissions einrichten: `@audio - rtprio 95` in limits.conf

## Offene Fragen an den Auftraggeber
- Hat dein User-Account rtprio-Permissions? (`ulimit -r` prüfen)
- Welche Buffer-Size ist eingestellt? (Audio → Einstellungen)
- Nutzt du PipeWire oder PulseAudio?
