# Session Log — v0.0.20.792

**Datum:** 2026-03-24
**Kollege:** Claude Opus 4.6
**Aufgabe:** Rust-Engine Disconnect-Loop Fix

## Root Cause

`start_daw.sh` startet die Rust-Engine als Hintergrundprozess → Engine bindet Socket.
Dann startet Python die DAW → `RustEngineBridge.start_engine()` wird aufgerufen →
`os.unlink(socket_path)` LÖSCHT den Socket → Engine verliert alle Clients →
Bridge startet ZWEITE Engine → Socket-Konflikt → EOF → Disconnect-Loop → Reconnect.

## Was wurde gefixt

### 1. start_engine() — Try existing socket first
- Prüft ERST ob `/tmp/pydaw_engine.sock` existiert
- Versucht sich an bestehenden Socket zu verbinden (Connect-only, kein Subprocess)
- Nur wenn das fehlschlägt → Socket als stale löschen → neuen Subprocess starten
- **Effekt:** Wenn start_daw.sh die Engine gestartet hat, verbindet sich Python direkt — kein zweiter Prozess, kein Socket-Konflikt

### 2. _do_reconnect_with_backoff() — Socket-first reconnect
- Versucht IMMER erst Socket-Reconnect (auch ohne self._process)
- Funktioniert jetzt mit extern gestarteter Engine (start_daw.sh)
- Full-Restart nur als letzter Fallback

## Erwartetes Ergebnis im Log (nachher)

```
🦀 Rust-Engine: ✅ gebaut
🚀 Starte Py_DAW...
[Engine] Listening on /tmp/pydaw_engine.sock
[Engine] Client connected
[Bridge] Socket exists — trying to connect to existing engine...
[Bridge] Connected to existing engine (no subprocess needed)
[Bridge] Engine ready: sr=44100, buf=512, dev=''
```

Kein Disconnect, kein Reconnect, keine zweite Engine.

## Geänderte Dateien
- pydaw/services/rust_engine_bridge.py (start_engine + _do_reconnect_with_backoff)
- VERSION, pydaw/version.py

## Nächste Schritte
- Auf Zielrechner testen — Disconnect-Loop sollte weg sein
- Falls EOF nach Configure weiterhin auftritt: Rust-Engine reader thread prüfen
