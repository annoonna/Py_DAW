# Session Log — v0.0.20.773

**Datum:** 2026-03-23
**Kollege:** Claude Opus 4.6
**Aufgabe:** KI-Assistent: Noten werden jetzt wirklich eingefügt

## Bugs gefixt

### BUG 1: add_midi_clip existiert nicht → add_midi_clip_at
- Handler rief `ps.add_midi_clip(...)` — diese Methode gibt es nicht!
- Die echte Methode heißt `ps.add_midi_clip_at(...)`
- try/except fing den AttributeError still ab → Status zeigte "eingefügt" aber nichts passierte
- FIX: `add_midi_clip` → `add_midi_clip_at`

### BUG 2: Piano Roll Refresh nach Insert
- `ps.select_clip()` emitted Signal, aber Piano Roll refreshte nicht immer
- FIX: Expliziter `editor_tabs.set_clip(clip_id)` + `arranger.update()` Aufruf

### BUG 3: Stille Fehler
- Fehler wurden verschluckt (nur traceback.print_exc)
- FIX: StatusBar zeigt jetzt "Fehler beim Einfügen" statt nichts

## Geänderte Dateien
- pydaw/ui/main_window.py (_on_ki_insert_notes komplett überarbeitet)
- pydaw/version.py, VERSION (→ 0.0.20.773)
