# Session Log — v0.0.20.767

**Datum:** 2026-03-23
**Kollege:** Claude Opus 4.6
**Aufgabe:** S&H-Flutter durch Vibrato+Tremolo ersetzen

## Was wurde erledigt

### S&H-Flutter komplett raus — Vibrato+Tremolo rein
- **S&H-Flutter (Layer B)** erzeugte Random-Pitch-Sprünge → R2D2-Sound
- **Vibrato**: Smooth Sine-LFO auf Amplitude (±Cents, default 15ct @ 4.5Hz)
- **Tremolo**: Smooth Sine-LFO auf Lautstärke (default depth 0.3 @ 3Hz)
- Beide modulieren direkt den PADsynth-Output (kein separater Layer)
- "Mod Amt" Knob steuert Gesamt-Intensität (0=trocken, 100%=voll)

### Warum besser als S&H?
- ZynAddSubFX nutzt smooth LFOs, nicht S&H
- Vibrato = leichte Pitch-Variation → Wärme, wie echte Instrumente
- Tremolo = Lautstärke-Pulsieren → Lebendigkeit
- Beides zusammen = organisch, musikalisch, kein Roboter

### BP Freq Knob-Bug (aus v765)
- Range 200-8000 → 20-800 mit Scale 10.0 → jetzt draggbar

## Geänderte Dateien
- pydaw/plugins/brrr/brrr_engine.py (Vibrato+Tremolo statt S&H)
- pydaw/plugins/brrr/brrr_widget.py (Labels, Presets, Knob ranges)
- pydaw/version.py, VERSION (→ 0.0.20.767)
