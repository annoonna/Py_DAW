# Session Log — v0.0.20.780

**Datum:** 2026-03-23
**Kollege:** Claude Opus 4.6
**Aufgabe:** Doppel-Node Fix + Export Realtime-Capture

## Problem 1: Doppelte PipeWire Nodes beim Start
`ensure_preview_output()` wird bei JEDEM Instrument-Scan aufgerufen
(6× beim Laden eines Projekts mit ZynAddSubFX + DrumMachine).
Jeder Aufruf erstellt einen neuen `sd.OutputStream` → mehrere PipeWire Nodes.

### Fix
- `_preview_stream_active` Flag — `ensure_preview_output()` ist jetzt idempotent
- Flag wird in `stop()` zurückgesetzt
- Guard prüft ob Thread noch läuft bevor er überspringt

## Problem 2: Export Dialog erzeugt keine Datei
`render_offline()` versuchte Instrumente (ZynAddSubFX, DrumMachine) offline
zu rendern. VST-Plugins produzieren aber NUR Audio im Live-Audio-Callback.

### Fix: Realtime-Capture statt Offline-Rendering
1. Transport zu `start_beat` seeked
2. Capture-Buffer im Audio-Callback aktiviert
3. Playback gestartet
4. Wartet bis Buffer voll (mit Progress)
5. Playback gestoppt → Buffer als WAV/FLAC/OGG/MP3 gespeichert

- Export läuft in QThread → GUI bleibt responsiv
- Abbrechen-Button stoppt Capture
- Ergebnis = exakt was der User hört (inkl. FX + Master)

## Geänderte Dateien
- pydaw/audio/audio_engine.py (ensure_preview_output, render_offline, callback capture)
- pydaw/ui/audio_export_dialog.py (QThread export, progress)
- pydaw/version.py, VERSION (→ 0.0.20.780)
