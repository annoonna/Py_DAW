# Session Log — v0.0.20.793

**Datum:** 2026-03-24
**Kollege:** Claude Opus 4.6
**Aufgabe:** Rust-Engine Disconnect-Loop Fix (Final)

## Dual Root Cause

### Problem 1: start_daw.sh startete Engine separat
start_daw.sh → Engine bindet Socket → Python startet → Python löscht Socket →
Zweite Engine → Socket-Konflikt → EOF → Disconnect-Loop

### Problem 2: subprocess.Popen mit PIPE
Python startete Engine mit stdout=PIPE, stderr=PIPE → Niemand liest die Pipes →
65KB Pipe-Buffer füllt sich (besonders durch ScanPlugins Log-Output) →
Engine blockiert auf nächstem log::info!() → Alle Threads blockiert →
Socket stirbt → EOF → Disconnect

## Fixes (3 Stellen)

### 1. start_daw.sh — Engine NICHT mehr im Hintergrund starten
- Engine wird nur noch GEBAUT (cargo build), nicht gestartet
- Python-Bridge startet die Engine selbst als Subprocess
- Kein Socket-Ownership-Konflikt mehr

### 2. Popen: stderr=None statt PIPE
- Engine-Logs gehen direkt ins Terminal (stderr des Parent-Prozesses)
- Kein Pipe-Buffer-Deadlock mehr
- ScanPlugins kann beliebig viel loggen ohne Blockade

### 3. start_engine(): Try existing socket first (v792)
- Prüft erst ob Socket existiert und verbindet sich
- Nur wenn Connect fehlschlägt → neuer Subprocess
- Robuster bei manuell gestarteter Engine

## Erwartetes Verhalten nach Fix

```
🚀 Starte Py_DAW...
  🦀 Rust-Engine wird von der DAW automatisch gestartet
[Bridge] Starting engine: pydaw_engine
[Bridge] Engine PID: 12345
[Engine] Listening on /tmp/pydaw_engine.sock
[Bridge] Connected to engine
[Bridge] Engine ready: sr=44100, buf=512
```

Keine Disconnects, keine Reconnects, eine Engine.

## Geänderte Dateien
- start_daw.sh (Engine-Start entfernt, Cleanup vereinfacht)
- pydaw/services/rust_engine_bridge.py (Popen stderr=None, try-existing-socket)
- VERSION, pydaw/version.py
