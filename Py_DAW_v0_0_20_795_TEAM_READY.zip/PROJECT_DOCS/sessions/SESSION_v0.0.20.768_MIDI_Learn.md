# Session Log — v0.0.20.768

**Datum:** 2026-03-23
**Kollege:** Claude Opus 4.6
**Aufgabe:** MIDI Learn + Rechtsklick-Menü für BRRR Knobs

## Was wurde erledigt
- `_setup_automation()` komplett neu: nutzt jetzt `knob.bind_automation()`
  identisch wie Fusion-Synth
- Alle BRRR-Knobs bekommen Rechtsklick-Menü mit:
  - "Show Automation in Arranger"
  - "MIDI Learn" (CC-Mapping via nanoKONTROL2 etc.)
  - "Reset to Default"
- Parameter-IDs: `trk:{track_id}:brrr:{attr}` (sauberes Namespace)

## Geänderte Dateien
- pydaw/plugins/brrr/brrr_widget.py (_setup_automation → bind_automation)
- pydaw/version.py, VERSION (→ 0.0.20.768)
