# Session Log — v0.0.20.771

**Datum:** 2026-03-23
**Kollege:** Claude Opus 4.6
**Aufgabe:** KI-Assistent: Track-/Instrument-Kontext + Drum-Mapping im System-Prompt

## Was wurde erledigt

### KI weiß jetzt welches Instrument auf dem Track ist
- Neuer `_get_track_context()` → erkennt Track-Name + plugin_type
- System-Prompt enthält:
  - Track-Name, Kind, Plugin-Type
  - Instrument-spezifische Pitch-Bereiche
  - GM Drum-Mapping (Kick=C1, Snare=D1, HiHat=F#1 etc.)
  - Typische Pattern-Hinweise (Kick 1+3, Snare 2+4, HiHat Achtel)

### Erkannte Instrumente
| Plugin/Name | Kontext |
|-------------|---------|
| Drum Machine | GM Drum Map, kurze Noten, typische Patterns |
| Bass | C1-C3, Root auf starke Zählzeiten |
| AETERNA/Pad | C3-C5, lange Noten, Akkorde |
| BRRR | C2-C5, tiefe Noten am besten |
| Fusion | C2-C6, flexibel |
| Bach Orgel | C2-C6, Polyphonie |
| Sampler | C4=Root |

## Geänderte Dateien
- pydaw/ui/ki_assistant_panel.py (_build_sys + _get_track_context)
- pydaw/version.py, VERSION (→ 0.0.20.771)
