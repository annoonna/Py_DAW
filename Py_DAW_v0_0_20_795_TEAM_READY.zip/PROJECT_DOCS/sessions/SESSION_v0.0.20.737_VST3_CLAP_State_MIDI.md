# Session Log — v0.0.20.737

**Datum:** 2026-03-22
**Kollege:** Claude Sonnet 4.6
**Arbeitspaket:** P7 Plugin-Hosting — State Save/Load + CLAP MIDI Injection
**Aufgabe:** VST3 IBStream + CLAP Streams + CLAP MIDI Events (3 TODOs seit v0.0.20.716)

## Was wurde erledigt

### VST3 MemoryStream (IBStream COM-Objekt)
- `MemoryStream` Struct mit `vtbl` als erster Field (COM ABI!)
- Statische `IBStreamVtbl`: read/write/seek/tell/query_interface
- `new_writer()` / `new_reader(data)` Konstruktoren
- `save_state()` nutzt `get_state(component, &stream)` → liefert echte Bytes
- `load_state()` nutzt `set_state(component, &stream)` + `set_component_state(controller, &stream2)`
- 8 Unit-Tests (alle ohne Plugin)

### CLAP Streams
- `ClapReadCtx` + `clap_read_fn` für load
- `clap_write_fn` direkt in `Vec<u8>`
- `save_state()` / `load_state()` vollständig implementiert
- Non-fatal bei false-return (CLAP-Eigenheit)
- 6 Unit-Tests

### CLAP MIDI Event Injection
- `ClapNoteEvent` (32 Bytes, CLAP ABI-konform)
- `NoteEventList<'a>` — zero-alloc slice-backed
- `push_note_on()` / `push_note_off()` / `clear_notes()` auf ClapInstance
- `process()` baut echte `ClapInputEvents` wenn `pending_notes` nicht leer
- Notes werden nach process() gecleart
- 7 Unit-Tests (inkl. ABI-Größe-Check)

## Testergebnis
320/320 grün, 0 errors, 0 neue Warnings

## Nächste Schritte
1. Live-Test: CLAP-Plugin laden (Surge XT / Vital), NoteOn senden → Audio
2. Plugin-Browser GUI-Integration
3. LV2 Atom Port MIDI (lv2_host.rs)
