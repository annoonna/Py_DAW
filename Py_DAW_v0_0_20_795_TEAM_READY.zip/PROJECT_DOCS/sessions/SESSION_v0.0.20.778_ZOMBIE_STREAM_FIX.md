# Session Log — v0.0.20.778

**Datum:** 2026-03-23
**Kollege:** Claude Opus 4.6
**Aufgabe:** Zombie PipeWire Stream Fix — aufgeräumte Audio-Streams

## Problem
Nach dem Schließen von Py_DAW bleiben 7-8 "PipeWire ALSA [pydaw_engine/...]"
Zombie-Nodes in qpwgraph aktiv. Jede Play/Stop-Iteration erzeugt einen NEUEN
sounddevice OutputStream der nicht aufgeräumt wird.

**DAS war die Hauptursache für die Audio-Aussetzer** — mehrere Streams
schreiben gleichzeitig auf denselben Output!

## Root Cause
- `start()` (Zeile 1688): Prüfte nur `isRunning()` — wenn der alte Thread
  schon beendet war (crashed/finished), wurde einfach ein NEUER erstellt
  ohne den alten Stream zu schließen
- `stop()`: Stoppte nur den LETZTEN Thread (`self._engine_thread`), nicht
  die vorher verwaisten
- `closeEvent()`: Kein `sd.stop()` / `sd._terminate()` → Zombie-Nodes
  überleben den App-Close

## Fixes
1. **`start()` — Kill before Create**: Alte Thread wird IMMER gestoppt +
   `deleteLater()` bevor ein neuer erzeugt wird
2. **`stop()` — Aggressiver**: 2s Timeout, dann `terminate()` + `deleteLater()`
3. **`closeEvent()` — `sd.stop()` + `sd._terminate()`**: Alle PortAudio-Streams
   werden beim Schließen gekillt
4. **`atexit` Handler**: Auch bei Crash/Force-Quit werden Streams terminiert

## Geänderte Dateien
- pydaw/audio/audio_engine.py (start, stop, __init__, _atexit_cleanup)
- pydaw/ui/main_window.py (closeEvent sounddevice cleanup)
- pydaw/version.py, VERSION (→ 0.0.20.778)

## Test
1. Py_DAW starten
2. Play → Stop → Play → Stop (5× wiederholen)
3. qpwgraph öffnen: Sollte nur 1 pydaw_engine Node zeigen (nicht 7)
4. Py_DAW schließen: Alle pydaw_engine Nodes sollten verschwinden
