# Session Log — v0.0.20.747

**Datum:** 2026-03-23
**Kollege:** Claude Sonnet 4.6
**Arbeitspakete:** PRO_ROADMAP_2026 → P2A (KI-Kompositions-Assistent) + P0D (First-Run-Experience)
**Aufgabe:** Alleinstellungsmerkmal der DAW implementieren: KI-gestützte Komposition via Claude API

---

## Was wurde erledigt

### P2A — KI-Kompositions-Assistent ✅

**`pydaw/ui/ki_assistant_panel.py`** (NEU, 261 Zeilen):
- Dockbares Panel mit vollständiger Claude-API-Integration (`urllib.request`, kein extra Dependency)
- 6 Quick-Prompt-Buttons: 🥁 Drum Groove, 🎹 Chord Prog, 🎸 Bassline, 🎵 Melodie, 🎲 Variation, 🤔 Erkläre
- Freier Prompt-Input mit Kontext-Anzeige (BPM, Tonart, Taktart, Track-Name)
- JSON-MIDI-Parser: Extrahiert `{"type":"midi_notes","notes":[...]}` aus KI-Antwort
- API-Worker in eigenem QThread — GUI blockiert nie
- API-Key sicher in QSettings (lokal, kein Cloud-Upload)
- System-Prompt sendet vollen Projekt-Kontext an Claude

**`pydaw/ui/main_window.py`** Änderungen:
- Menü-Action: Projekt → 🤖 KI-Assistent… (Ctrl+Alt+K)
- Dock-Widget: tabbed mit Browser-Dock rechts, standardmäßig ausgeblendet
- `_toggle_ki_assistant_dock()` — Ein/Ausblenden inkl. refresh_context()
- `_on_ki_insert_notes(notes, track_id)` — Neuen MIDI-Clip anlegen, Noten einfügen
- `_on_track_selected()` — KI-Panel Kontext automatisch aktualisieren bei Track-Wechsel
- `_maybe_show_first_run()` — P0D-Hook via QTimer.singleShot(500, ...)

### P0D — First-Run-Experience ✅

**`pydaw/ui/first_run_dialog.py`** (NEU, 248 Zeilen):
- 5-seitiger QWizard mit DAW-Theme (dunkles Stylesheet)
- Seite 1: Willkommen + Feature-Highlights
- Seite 2: Schnellstart — 4 Schritte zum ersten Ton in < 30s
- Seite 3: Audio-Setup — Live-Check PipeWire/JACK/ALSA + Rust-Engine-Status
- Seite 4: KI-Assistent — Optionale Einrichtung mit Beispiel-Prompts
- Seite 5: Fertig! — Tastenkürzel-Übersicht
- Erscheint genau einmal beim ersten Start (QSettings-Flag)
- `should_show_first_run()` + `mark_first_run_done()` + `maybe_show_first_run()`

---

## Geänderte Dateien

1. `pydaw/ui/ki_assistant_panel.py` — NEU
2. `pydaw/ui/first_run_dialog.py` — NEU
3. `pydaw/ui/main_window.py` — +KI-Dock, +Methoden, +First-Run-Timer
4. `PROJECT_DOCS/PRO_ROADMAP_2026.md` — P2A + P0D Checkboxen abgehakt
5. `PROJECT_DOCS/progress/TODO.md` — aktualisiert
6. `PROJECT_DOCS/progress/DONE.md` — aktualisiert
7. `CHANGELOG_v0.0.20.747_*.md` — geschrieben
8. `VERSION` → 0.0.20.747

---

## Nächste Schritte (für den nächsten Kollegen)

### Sofort testbar (kein Hardware-Test nötig):
```bash
python3 main.py
# → First-Run-Wizard erscheint (1× beim ersten Start)
# → Projekt → 🤖 KI-Assistent → API-Key eingeben → Prompt senden
```

### Hardware-Tests (Anno muss selbst testen):
- P0A: `USE_RUST_ENGINE=1 python3 main.py` → Engine > 5 Min stabil?
- P0B: Advanced Sampler Zone → Speichern → Neustart → Zone noch da?
- P0C: Surge XT CLAP laden → NoteOn → Ton hörbar?

### Nächste Code-Aufgaben (PRO_ROADMAP Phase 2):
1. **P2A Variations-Generator**: Clip auswählen → "4 Variationen" → wählen
2. **P2A Streaming**: Server-Sent Events für Echtzeit-Textausgabe
3. **P2A Chat-History**: Mehrere Nachrichten (Konversation) im Panel
4. **P1A Recording-Workflow**: Input-Monitoring < 10ms, Waveform-Preview

### Meilenstein:
Nach P0B/P0C Hardware-Tests → **CHANGELOG v0.1.0-beta schreiben** → erster öffentlicher Beta-Release!

---

## Offene Fragen an Anno

1. **API-Key-Sicherheit**: QSettings speichert Key im Klartext in `~/.config/Py_DAW/ChronoScaleStudio.conf` — reicht das, oder soll keyring (systemd-Keyring) verwendet werden?
2. **Streaming**: Anthropic SSE-Streaming würde Echtzeit-Textausgabe ermöglichen — gewünscht?
3. **First-Run-Reset**: Zum Testen: `python3 -c "from PyQt6.QtCore import QSettings; s=QSettings('Py_DAW','ChronoScaleStudio'); s.remove('first_run_done')"` setzt den Dialog zurück.
