// ==========================================================================
// MIDI Clip Scheduler — Beat-accurate MIDI dispatching during playback
// ==========================================================================
// v0.0.20.736 — Loop-Region Support
//
// This module bridges the gap between:
//   - MIDI notes stored in the arrangement (from ProjectSync)
//   - InstrumentNode::push_midi() on the audio thread
//
// During playback, process_audio() calls schedule_for_buffer() which:
//   1. Calculates the beat range for the current buffer
//   2. Finds NoteOn events in that range -> push_midi(NoteOn)
//   3. Finds NoteOff events (note_start + note_length) -> push_midi(NoteOff)
//
// Loop-Region Support (v0.0.20.736):
//   When transport loop is active and a buffer crosses the loop-end boundary,
//   schedule_for_buffer() emits events from TWO ranges in a single call:
//     Range 1: [beat_start, loop_end)        -- pre-wrap events
//     Range 2: [loop_start, loop_start + overflow) -- post-wrap events
//   MidiBufferIter holds both ranges with zero allocations.
//
// Architecture:
//   ProjectSync --> MidiScheduler::load_from_sync()
//                     | (sorted event list per track)
//   SetLoop     --> MidiScheduler::set_loop()
//                     | (stored loop state)
//   process_audio --> MidiScheduler::schedule_for_buffer()
//                     |
//                   track.instrument.push_midi(NoteOn/NoteOff)
//
// Rules:
//   NO allocations in schedule_for_buffer() (pre-sorted, index scan)
//   Lock-free: owned by engine, called only from audio thread
//   Handles loop regions correctly (dual-range iterator)
//   Handles seek forward/backward via binary search
//   Does NOT handle tempo automation (assumes constant BPM per buffer)
// ==========================================================================

use crate::audio_bridge::{MidiNoteConfig, ClipConfig};

/// A pre-computed, time-sorted MIDI event for the scheduler.
#[derive(Debug, Clone, Copy)]
pub struct ScheduledEvent {
    /// Absolute beat position of this event.
    pub beat: f64,
    /// Track index (matches AudioGraph track index).
    pub track_index: u16,
    /// MIDI note number (0-127).
    pub pitch: u8,
    /// Velocity (0.0-1.0). 0.0 = NoteOff.
    pub velocity: f32,
    /// True = NoteOn, False = NoteOff.
    pub is_note_on: bool,
}

/// MIDI Clip Scheduler -- holds all arrangement MIDI events, sorted by beat.
///
/// Call `load_from_sync()` when the project changes.
/// Call `set_loop()` when the transport loop region changes.
/// Call `schedule_for_buffer()` from the audio callback.
pub struct MidiScheduler {
    /// All events sorted by beat position (ascending).
    events: Vec<ScheduledEvent>,
    /// Current scan index (advances as playback progresses).
    /// Reset via binary search on seek or loop.
    scan_index: usize,
    /// Last processed beat_end position (for seek detection).
    last_beat: f64,
    /// Total number of events.
    event_count: usize,

    // Loop region (updated via set_loop)
    loop_enabled: bool,
    loop_start_beat: f64,
    loop_end_beat: f64,
}

impl MidiScheduler {
    /// Create an empty scheduler.
    pub fn new() -> Self {
        Self {
            events: Vec::new(),
            scan_index: 0,
            last_beat: -1.0,
            event_count: 0,
            loop_enabled: false,
            loop_start_beat: 0.0,
            loop_end_beat: 0.0,
        }
    }

    /// Update the loop region. Call whenever the transport SetLoop command is processed.
    /// NOT called from the audio thread -- safe to call from command handler.
    pub fn set_loop(&mut self, enabled: bool, start_beat: f64, end_beat: f64) {
        self.loop_enabled = enabled;
        self.loop_start_beat = start_beat;
        self.loop_end_beat = end_beat;
        // Invalidate scan so next schedule_for_buffer() binary-searches correctly
        self.scan_index = 0;
        self.last_beat = -1.0;
    }

    /// Load MIDI events from a ProjectSync.
    /// Called from the command thread (NOT audio thread) so allocations are OK.
    pub fn load_from_sync(
        &mut self,
        clips: &[ClipConfig],
        midi_notes: &[MidiNoteConfig],
        tracks: &[crate::audio_bridge::TrackConfig],
    ) {
        self.events.clear();
        self.scan_index = 0;
        self.last_beat = -1.0;

        // Build clip_id -> (track_id, clip_start_beats, clip_offset_beats) map
        let mut clip_map: std::collections::HashMap<&str, (&str, f64, f64)> =
            std::collections::HashMap::new();
        for clip in clips {
            if clip.kind == "midi" {
                clip_map.insert(
                    &clip.clip_id,
                    (&clip.track_id, clip.start_beats, clip.offset_beats),
                );
            }
        }

        // Build track_id -> track_index map
        let mut track_idx_map: std::collections::HashMap<&str, u16> =
            std::collections::HashMap::new();
        for tc in tracks {
            track_idx_map.insert(&tc.track_id, tc.track_index);
        }

        // Convert MIDI notes to absolute-beat ScheduledEvents
        for note in midi_notes {
            let (track_id, clip_start, clip_offset) = match clip_map.get(note.clip_id.as_str()) {
                Some(v) => *v,
                None => continue,
            };
            let track_index = match track_idx_map.get(track_id) {
                Some(&idx) => idx,
                None => continue,
            };

            // Absolute beat = clip_start + note_start_in_clip - clip_offset
            let abs_start = clip_start + note.start_beats - clip_offset;
            let abs_end = abs_start + note.length_beats;

            let velocity = note.velocity as f32 / 127.0;

            self.events.push(ScheduledEvent {
                beat: abs_start,
                track_index,
                pitch: note.pitch,
                velocity,
                is_note_on: true,
            });
            self.events.push(ScheduledEvent {
                beat: abs_end,
                track_index,
                pitch: note.pitch,
                velocity: 0.0,
                is_note_on: false,
            });
        }

        // Sort by beat. NoteOff before NoteOn at same beat (avoid stuck notes).
        self.events.sort_by(|a, b| {
            a.beat.partial_cmp(&b.beat).unwrap_or(std::cmp::Ordering::Equal)
                .then_with(|| a.is_note_on.cmp(&b.is_note_on))
        });

        self.event_count = self.events.len();
        if self.event_count > 0 {
            log::info!(
                "MidiScheduler: loaded {} events ({} notes) across {} MIDI clips",
                self.event_count,
                midi_notes.len(),
                clip_map.len(),
            );
        }
    }

    /// Schedule MIDI events for one audio buffer.
    ///
    /// Called from `process_audio()` on the AUDIO THREAD.
    /// NO allocations, NO locks.
    ///
    /// Loop-Region Handling:
    ///   When the transport loop is active and beat_end exceeds loop_end_beat,
    ///   the returned iterator transparently emits events from two ranges:
    ///     Range 1: [beat_start, loop_end_beat)
    ///     Range 2: [loop_start_beat, loop_start_beat + overflow)
    pub fn schedule_for_buffer(
        &mut self,
        beat_start: f64,
        beat_end: f64,
        is_playing: bool,
    ) -> MidiBufferIter<'_> {
        if !is_playing || self.event_count == 0 {
            return MidiBufferIter::empty(&self.events);
        }

        // Seek detection: did playhead jump?
        let jumped_backward = beat_start < self.last_beat - 0.01;
        let jumped_forward  = beat_start > self.last_beat + 1.0;
        let first_call      = self.last_beat < 0.0;

        if jumped_backward || jumped_forward || first_call {
            self.scan_index = self.events.partition_point(|e| e.beat < beat_start);
        }

        self.last_beat = beat_end;

        // Loop-transition buffer:
        //   loop enabled, this buffer crosses loop_end_beat
        //   (beat_start < loop_end AND beat_end > loop_end)
        if self.loop_enabled
            && self.loop_end_beat > self.loop_start_beat
            && beat_start < self.loop_end_beat
            && beat_end > self.loop_end_beat
        {
            let overflow_beats = beat_end - self.loop_end_beat;
            let wrapped_end   = self.loop_start_beat + overflow_beats;

            // Range 1: [beat_start, loop_end_beat)
            while self.scan_index < self.event_count
                && self.events[self.scan_index].beat < beat_start
            {
                self.scan_index += 1;
            }
            let range1_start = self.scan_index;
            let mut range1_end = range1_start;
            while range1_end < self.event_count
                && self.events[range1_end].beat < self.loop_end_beat
            {
                range1_end += 1;
            }

            // Range 2: [loop_start_beat, loop_start_beat + overflow)
            let range2_start = self.events.partition_point(|e| e.beat < self.loop_start_beat);
            let mut range2_end = range2_start;
            while range2_end < self.event_count
                && self.events[range2_end].beat < wrapped_end
            {
                range2_end += 1;
            }

            // Hint for next call (will be overridden by seek-backward detection anyway)
            self.scan_index = range2_end;

            log::trace!(
                "MidiScheduler: loop-wrap [{:.3},{:.3}) -> r1[{},{}] r2[{},{}] overflow={:.4}",
                beat_start, beat_end, range1_start, range1_end, range2_start, range2_end,
                overflow_beats,
            );

            return MidiBufferIter {
                events: &self.events,
                start: range1_start,
                end: range1_end,
                start2: range2_start,
                end2: range2_end,
                on_second: false,
            };
        }

        // Normal (non-transition) buffer
        while self.scan_index < self.event_count
            && self.events[self.scan_index].beat < beat_start
        {
            self.scan_index += 1;
        }
        let range_start = self.scan_index;
        let mut range_end = range_start;
        while range_end < self.event_count
            && self.events[range_end].beat < beat_end
        {
            range_end += 1;
        }
        self.scan_index = range_end;

        MidiBufferIter {
            events: &self.events,
            start: range_start,
            end: range_end,
            start2: 0,
            end2: 0,
            on_second: false,
        }
    }

    /// Reset playback position (on seek, stop, or loop).
    pub fn reset(&mut self) {
        self.scan_index = 0;
        self.last_beat = -1.0;
    }

    /// Number of loaded events.
    pub fn event_count(&self) -> usize {
        self.event_count
    }

    /// Clear all events.
    pub fn clear(&mut self) {
        self.events.clear();
        self.event_count = 0;
        self.scan_index = 0;
        self.last_beat = -1.0;
    }
}

// ==========================================================================
// Zero-allocation dual-range iterator
// ==========================================================================

/// Iterator over events in up to two beat ranges.
///
/// Range 1: pre-wrap events in [beat_start, loop_end)
/// Range 2: post-wrap events in [loop_start, loop_start + overflow)
///
/// range2 is empty (start2 == end2) for non-loop-transition buffers.
pub struct MidiBufferIter<'a> {
    events: &'a [ScheduledEvent],
    start: usize,
    end: usize,
    start2: usize,
    end2: usize,
    on_second: bool,
}

impl<'a> MidiBufferIter<'a> {
    #[inline]
    fn empty(events: &'a [ScheduledEvent]) -> Self {
        Self { events, start: 0, end: 0, start2: 0, end2: 0, on_second: false }
    }
}

impl<'a> Iterator for MidiBufferIter<'a> {
    type Item = &'a ScheduledEvent;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        if !self.on_second {
            if self.start < self.end {
                let evt = &self.events[self.start];
                self.start += 1;
                return Some(evt);
            }
            self.on_second = true;
        }
        if self.start2 < self.end2 {
            let evt = &self.events[self.start2];
            self.start2 += 1;
            Some(evt)
        } else {
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let r1 = if self.on_second { 0 } else { self.end.saturating_sub(self.start) };
        let r2 = self.end2.saturating_sub(self.start2);
        let n = r1 + r2;
        (n, Some(n))
    }
}

// ==========================================================================
// Tests
// ==========================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::audio_bridge::{ClipConfig, MidiNoteConfig, TrackConfig};

    fn make_track(id: &str, idx: u16) -> TrackConfig {
        TrackConfig {
            track_id: id.to_string(),
            track_index: idx,
            kind: "instrument".to_string(),
            volume: 1.0,
            pan: 0.0,
            muted: false,
            soloed: false,
            instrument_type: None,
            instrument_id: None,
            group_index: None,
        }
    }

    fn make_clip(clip_id: &str, track_id: &str, start: f64, len: f64) -> ClipConfig {
        ClipConfig {
            clip_id: clip_id.to_string(),
            track_id: track_id.to_string(),
            start_beats: start,
            length_beats: len,
            kind: "midi".to_string(),
            audio_b64: None,
            source_sr: None,
            source_channels: None,
            gain: 1.0,
            offset_beats: 0.0,
        }
    }

    fn make_note(clip_id: &str, pitch: u8, vel: u8, start: f64, len: f64) -> MidiNoteConfig {
        MidiNoteConfig {
            clip_id: clip_id.to_string(),
            pitch,
            velocity: vel,
            start_beats: start,
            length_beats: len,
        }
    }

    // ---- existing tests (unchanged) ----

    #[test]
    fn test_empty_scheduler() {
        let mut sched = MidiScheduler::new();
        assert_eq!(sched.schedule_for_buffer(0.0, 1.0, true).count(), 0);
    }

    #[test]
    fn test_basic_note_scheduling() {
        let mut sched = MidiScheduler::new();
        let tracks = vec![make_track("t1", 0)];
        let clips = vec![make_clip("c1", "t1", 0.0, 4.0)];
        let notes = vec![make_note("c1", 60, 100, 1.0, 0.5)];
        sched.load_from_sync(&clips, &notes, &tracks);
        assert_eq!(sched.event_count(), 2);

        let e: Vec<_> = sched.schedule_for_buffer(0.0, 1.0, true).collect();
        assert_eq!(e.len(), 0);

        let e: Vec<_> = sched.schedule_for_buffer(1.0, 2.0, true).collect();
        assert_eq!(e.len(), 2);
        assert!(e[0].is_note_on && e[0].pitch == 60);
        assert!(!e[1].is_note_on && e[1].pitch == 60);
    }

    #[test]
    fn test_seek_backward_resets() {
        let mut sched = MidiScheduler::new();
        let tracks = vec![make_track("t1", 0)];
        let clips = vec![make_clip("c1", "t1", 0.0, 8.0)];
        let notes = vec![
            make_note("c1", 60, 100, 1.0, 0.5),
            make_note("c1", 64,  80, 3.0, 0.5),
        ];
        sched.load_from_sync(&clips, &notes, &tracks);
        let _ = sched.schedule_for_buffer(0.0, 4.0, true);
        let e: Vec<_> = sched.schedule_for_buffer(0.0, 2.0, true).collect();
        assert!(e.iter().any(|ev| ev.pitch == 60 && ev.is_note_on));
    }

    #[test]
    fn test_noteoff_before_noteon_at_same_beat() {
        let mut sched = MidiScheduler::new();
        let tracks = vec![make_track("t1", 0)];
        let clips = vec![make_clip("c1", "t1", 0.0, 4.0)];
        let notes = vec![
            make_note("c1", 60, 100, 1.0, 1.0),
            make_note("c1", 64, 100, 2.0, 1.0),
        ];
        sched.load_from_sync(&clips, &notes, &tracks);
        let e: Vec<_> = sched.schedule_for_buffer(1.5, 2.5, true).collect();
        let at2: Vec<_> = e.iter().filter(|ev| (ev.beat - 2.0).abs() < 0.001).collect();
        assert_eq!(at2.len(), 2);
        assert!(!at2[0].is_note_on);
        assert!(at2[1].is_note_on);
    }

    #[test]
    fn test_not_playing_returns_empty() {
        let mut sched = MidiScheduler::new();
        let tracks = vec![make_track("t1", 0)];
        let clips = vec![make_clip("c1", "t1", 0.0, 4.0)];
        let notes = vec![make_note("c1", 60, 100, 0.0, 1.0)];
        sched.load_from_sync(&clips, &notes, &tracks);
        assert_eq!(sched.schedule_for_buffer(0.0, 1.0, false).count(), 0);
    }

    #[test]
    fn test_multi_track() {
        let mut sched = MidiScheduler::new();
        let tracks = vec![make_track("bass", 0), make_track("drums", 1)];
        let clips = vec![
            make_clip("c_bass",  "bass",  0.0, 4.0),
            make_clip("c_drums", "drums", 0.0, 4.0),
        ];
        let notes = vec![
            make_note("c_bass",  36, 100, 0.0, 1.0),
            make_note("c_drums", 42,  80, 0.0, 0.25),
            make_note("c_drums", 36, 120, 0.0, 0.5),
        ];
        sched.load_from_sync(&clips, &notes, &tracks);
        assert_eq!(sched.event_count(), 6);
        let e: Vec<_> = sched.schedule_for_buffer(0.0, 0.5, true).collect();
        let ons: Vec<_> = e.iter().filter(|ev| ev.is_note_on).collect();
        assert_eq!(ons.len(), 3);
        assert!(ons.iter().any(|ev| ev.track_index == 0));
        assert!(ons.iter().any(|ev| ev.track_index == 1));
    }

    // ---- NEW: Loop-Region tests ----

    /// Buffer crossing loop_end: events from BOTH pre-wrap and post-wrap ranges.
    #[test]
    fn test_loop_transition_emits_both_ranges() {
        let mut sched = MidiScheduler::new();
        let tracks = vec![make_track("t1", 0)];
        let clips  = vec![make_clip("c1", "t1", 0.0, 8.0)];
        let notes  = vec![
            make_note("c1", 60, 100, 3.9,  0.05), // NoteOn@3.9  NoteOff@3.95 (pre-wrap)
            make_note("c1", 64,  80, 0.05, 0.1),  // NoteOn@0.05 NoteOff@0.15 (post-wrap)
        ];
        sched.load_from_sync(&clips, &notes, &tracks);
        sched.set_loop(true, 0.0, 4.0);

        // Buffer [3.85, 4.15): crosses loop_end=4.0, overflow=0.15 -> wrapped_end=0.15
        let evts: Vec<_> = sched.schedule_for_buffer(3.85, 4.15, true).collect();
        assert_eq!(evts.len(), 4, "Expected 4 events (2 pre-wrap + 2 post-wrap)");
        assert!(evts.iter().any(|e| e.pitch == 60 && e.is_note_on),  "pre-wrap NoteOn(60)");
        assert!(evts.iter().any(|e| e.pitch == 64 && e.is_note_on),  "post-wrap NoteOn(64)");
        assert!(evts.iter().any(|e| e.pitch == 60 && !e.is_note_on), "pre-wrap NoteOff(60)");
        assert!(evts.iter().any(|e| e.pitch == 64 && !e.is_note_on), "post-wrap NoteOff(64)");
    }

    /// Events past loop_end must NOT be scheduled in the transition buffer.
    #[test]
    fn test_loop_transition_excludes_post_loop_events() {
        let mut sched = MidiScheduler::new();
        let tracks = vec![make_track("t1", 0)];
        let clips  = vec![make_clip("c1", "t1", 0.0, 8.0)];
        let notes  = vec![
            make_note("c1", 60, 100, 4.5,  0.1), // beat 4.5 -- past loop_end=4.0, must NOT play
            make_note("c1", 64,  80, 0.05, 0.1), // beat 0.05 -- in overflow range, MUST play
        ];
        sched.load_from_sync(&clips, &notes, &tracks);
        sched.set_loop(true, 0.0, 4.0);

        // Buffer [3.9, 4.2): overflow=0.2, wrapped_end=0.2
        let evts: Vec<_> = sched.schedule_for_buffer(3.9, 4.2, true).collect();
        assert!(!evts.iter().any(|e| e.pitch == 60),
            "Note at 4.5 (past loop_end) must not appear");
        assert!(evts.iter().any(|e| e.pitch == 64 && e.is_note_on),
            "Note at 0.05 (within overflow 0.2) must appear");
    }

    /// After a transition buffer, subsequent buffers play correctly (seek-backward detection).
    #[test]
    fn test_post_loop_buffers_correct() {
        let mut sched = MidiScheduler::new();
        let tracks = vec![make_track("t1", 0)];
        let clips  = vec![make_clip("c1", "t1", 0.0, 8.0)];
        let notes  = vec![
            make_note("c1", 60, 100, 1.0, 0.5),
            make_note("c1", 64,  80, 3.0, 0.5),
        ];
        sched.load_from_sync(&clips, &notes, &tracks);
        sched.set_loop(true, 0.0, 4.0);

        // First pass
        assert!(sched.schedule_for_buffer(0.0, 2.0, true).any(|e| e.pitch == 60 && e.is_note_on));
        assert!(sched.schedule_for_buffer(2.0, 4.0, true).any(|e| e.pitch == 64 && e.is_note_on));

        // Second iteration (seek backward detected)
        assert!(sched.schedule_for_buffer(0.0, 2.0, true).any(|e| e.pitch == 60 && e.is_note_on),
            "Note at beat 1.0 must play again in second loop iteration");
    }

    /// Loop disabled: events past beat 4.0 play normally (no filtering).
    #[test]
    fn test_no_loop_no_filtering() {
        let mut sched = MidiScheduler::new();
        let tracks = vec![make_track("t1", 0)];
        let clips  = vec![make_clip("c1", "t1", 0.0, 8.0)];
        let notes  = vec![make_note("c1", 60, 100, 4.5, 0.1)];
        sched.load_from_sync(&clips, &notes, &tracks);
        sched.set_loop(false, 0.0, 4.0);

        let evts: Vec<_> = sched.schedule_for_buffer(4.0, 5.0, true).collect();
        assert!(evts.iter().any(|e| e.pitch == 60 && e.is_note_on),
            "Loop disabled: note at 4.5 must play normally");
    }

    /// set_loop() resets scan state for correct binary search on next call.
    #[test]
    fn test_set_loop_resets_scan() {
        let mut sched = MidiScheduler::new();
        let tracks = vec![make_track("t1", 0)];
        let clips  = vec![make_clip("c1", "t1", 0.0, 8.0)];
        let notes  = vec![
            make_note("c1", 60, 100, 1.0, 0.5),
            make_note("c1", 64,  80, 5.0, 0.5),
        ];
        sched.load_from_sync(&clips, &notes, &tracks);

        // Advance scan_index by playing to beat 6
        let _ = sched.schedule_for_buffer(0.0, 6.0, true);
        assert!(sched.scan_index > 0);

        sched.set_loop(true, 0.0, 4.0);
        assert_eq!(sched.scan_index, 0);

        let evts: Vec<_> = sched.schedule_for_buffer(0.5, 2.0, true).collect();
        assert!(evts.iter().any(|e| e.pitch == 60 && e.is_note_on),
            "After set_loop(), binary search must find note at beat 1.0");
    }

    /// size_hint() reports correct total for dual-range iteration.
    #[test]
    fn test_size_hint_dual_range() {
        let mut sched = MidiScheduler::new();
        let tracks = vec![make_track("t1", 0)];
        let clips  = vec![make_clip("c1", "t1", 0.0, 8.0)];
        let notes  = vec![
            make_note("c1", 60, 100, 3.9,  0.05),
            make_note("c1", 64,  80, 0.05, 0.1),
        ];
        sched.load_from_sync(&clips, &notes, &tracks);
        sched.set_loop(true, 0.0, 4.0);

        let iter = sched.schedule_for_buffer(3.85, 4.15, true);
        let (lo, hi) = iter.size_hint();
        assert_eq!(lo, 4);
        assert_eq!(hi, Some(4));
    }

    /// Loop with non-zero loop_start (e.g., loop from beat 2.0 to 6.0).
    #[test]
    fn test_loop_non_zero_start() {
        let mut sched = MidiScheduler::new();
        let tracks = vec![make_track("t1", 0)];
        let clips  = vec![make_clip("c1", "t1", 0.0, 8.0)];
        let notes  = vec![
            make_note("c1", 60, 100, 5.9, 0.05), // pre-wrap near loop_end=6.0
            make_note("c1", 64,  80, 2.1, 0.1),  // post-wrap near loop_start=2.0
        ];
        sched.load_from_sync(&clips, &notes, &tracks);
        sched.set_loop(true, 2.0, 6.0);

        // Transition buffer [5.85, 6.15): overflow=0.15, wrapped_end=2.0+0.15=2.15
        let evts: Vec<_> = sched.schedule_for_buffer(5.85, 6.15, true).collect();
        assert!(evts.iter().any(|e| e.pitch == 60 && e.is_note_on), "pre-wrap NoteOn");
        assert!(evts.iter().any(|e| e.pitch == 64 && e.is_note_on), "post-wrap NoteOn");
    }
}
