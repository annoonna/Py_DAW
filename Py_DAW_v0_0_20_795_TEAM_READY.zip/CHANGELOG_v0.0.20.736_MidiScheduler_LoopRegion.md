# CHANGELOG v0.0.20.736 — MidiScheduler Loop-Region Support

**Datum:** 2026-03-22
**Autor:** Claude Sonnet 4.6
**Arbeitspaket:** Rust DSP Migration — MIDI Scheduler Loop-Region

---

## Problem

Der `MidiScheduler` (v0.0.20.725) behandelte Loop-Regions **nicht korrekt**:

- Bei einem Buffer, der die `loop_end_beat`-Grenze überschritt (Transition-Buffer),
  wurden **nur** Events aus dem pre-wrap Bereich `[beat_start, beat_end)` ausgegeben —
  also als wäre `beat_end` nie am Loop-Anfang weitergeführt.
- Events aus dem post-wrap Bereich `[loop_start, loop_start + overflow)` wurden
  **nicht** dispatched → fehlende NoteOn/NoteOff am Loop-Anfang.
- Resultat: **Stuck Notes** (NoteOn ohne NoteOff am Loop-Ende) und
  **stille erste Beats** nach jedem Loop-Wrap.

Der `MidiScheduler` kannte außerdem den Loop-Zustand nicht; er wurde nie
über Loop-Änderungen (`SetLoop`-Command) informiert.

---

## Lösung

### `pydaw_engine/src/midi_scheduler.rs` — Dual-Range Iterator

**Neues Feld `loop_enabled / loop_start_beat / loop_end_beat`** im `MidiScheduler`:
- Gesetzt via neuer `set_loop(enabled, start_beat, end_beat)` Methode.

**Loop-Transition-Erkennung in `schedule_for_buffer()`:**
- Wenn `loop_enabled` und `beat_start < loop_end` und `beat_end > loop_end`:
  - `overflow = beat_end - loop_end`
  - `wrapped_end = loop_start + overflow`
  - Range 1: `[beat_start, loop_end_beat)` — pre-wrap Events
  - Range 2: `[loop_start_beat, wrapped_end)` — post-wrap Events via
    `partition_point()` (O(log n), zero-alloc)
- Beide Ranges werden als **doppelter Iterator** `MidiBufferIter` zurückgegeben.

**`MidiBufferIter` erweitert** mit `start2/end2/on_second`:
- Iteriert Range 1, danach nahtlos Range 2.
- `size_hint()` gibt korrekte Gesamtanzahl zurück.
- Weiterhin **zero allocation** auf dem Audio-Thread.

**`set_loop()` resettet `scan_index = 0` und `last_beat = -1.0`**:
- Stellt sicher, dass der nächste Buffer-Aufruf via Binary Search den korrekten
  Einstiegspunkt findet, nicht den alten `scan_index`.

### `pydaw_engine/src/engine.rs` — SetLoop-Handler + apply_project_sync

- **`Command::SetLoop`-Handler**: ruft jetzt zusätzlich
  `self.midi_scheduler.lock().set_loop(enabled, start_beat, end_beat)` auf.
- **`apply_project_sync()`**: synchronisiert den Loop-Zustand aus dem
  ProjectSync-Paket beim Projekt-Öffnen / SyncProject-Command an den
  MidiScheduler weiter.

### `pydaw/ui/main_window.py` — `_on_transport_loop_changed()`

- Beim Loop-Signal vom TransportService wird jetzt auch
  `RustEngineBridge.instance().set_loop(...)` aufgerufen (sofern Rust-Engine
  aktiv ist), damit Python-seitige Loop-Änderungen (Toggle-Button, Marker
  im Arranger) den Rust-MidiScheduler sofort erreichen.

---

## Tests

13 Unit-Tests in `midi_scheduler.rs` — alle grün:

**Bestehende Tests (unverändert, weiterhin grün):**
- `test_empty_scheduler`
- `test_basic_note_scheduling`
- `test_seek_backward_resets`
- `test_noteoff_before_noteon_at_same_beat`
- `test_not_playing_returns_empty`
- `test_multi_track`

**Neue Loop-Tests:**
- `test_loop_transition_emits_both_ranges` — Transition-Buffer liefert Events aus beiden Ranges
- `test_loop_transition_excludes_post_loop_events` — Events nach `loop_end` werden nicht fälschlich scheduliert
- `test_post_loop_buffers_correct` — Seek-backward-Detection nach Transition-Buffer funktioniert
- `test_no_loop_no_filtering` — Loop disabled: kein Filtereffekt
- `test_set_loop_resets_scan` — `set_loop()` invalidiert scan_index korrekt
- `test_size_hint_dual_range` — `size_hint()` korrekt für Dual-Range-Iterator
- `test_loop_non_zero_start` — Loop startet nicht bei 0.0 (Allgemeinfall)

**Gesamt: 299/299 Rust-Tests grün** (`cargo test`).

**Python Syntax-Checks:**
- `pydaw/ui/main_window.py` ✅
- `pydaw/services/rust_engine_bridge.py` ✅
- `pydaw/services/transport_service.py` ✅

---

## Geänderte Dateien

| Datei | Änderung |
|---|---|
| `pydaw_engine/src/midi_scheduler.rs` | Loop-State, `set_loop()`, Dual-Range `schedule_for_buffer()`, erweiterter `MidiBufferIter`, 7 neue Tests |
| `pydaw_engine/src/engine.rs` | `SetLoop`-Handler + `apply_project_sync()` rufen `midi_scheduler.set_loop()` auf |
| `pydaw/ui/main_window.py` | `_on_transport_loop_changed()` → Bridge.set_loop() |
| `pydaw_engine/Cargo.toml` | `rmp-serde` + `rmp` auf exakte Versionen gepinnt (Rust 1.75 Kompatibilität) |
| `VERSION` | 0.0.20.736 |
| `pydaw/version.py` | 0.0.20.736 |

---

## Was als nächstes zu tun ist

1. `cargo build --release` auf Zielmaschine mit Rust ≥ 1.80 (nicht 1.75 des Container)
2. Live-Test: Loop aktivieren, Play — Noten am Loop-Übergang korrekt?
3. Keine Stuck Notes nach mehreren Loop-Runden?
4. A/B-Vergleich Python-Engine vs Rust-Engine auf echtem Projekt
