# CHANGELOG v0.0.20.749 — P2A KI-Assistent: Datei-Analyse (Bilder, JSON, ZIP, Text)

**Datum:** 2026-03-23  **Autor:** Claude Sonnet 4.6  **AP:** PRO_ROADMAP P2A

## Was wurde gemacht

### Datei-Analyse im KI-Assistent

**Unterstützte Dateitypen:**
| Typ | Formate | Was passiert |
|---|---|---|
| 🖼 Bilder | PNG, JPG, JPEG, WebP, GIF | Base64 → direkt an Claude Vision |
| 📄 JSON | .json, .pydaw | Hübsch formatiert als Text |
| 📦 ZIP | .zip | Inhaltsübersicht + alle JSON/Text extrahiert + Bilder (max 3) |
| 📝 Text | .txt, .md, .yaml, .csv, .xml | Als Text |
| ⚠️ Limit | Bilder max 4MB, Text max 80kB | Größere Dateien abgeschnitten |

**Neue Klassen:**
- `_read_file_for_api(path)` — liest Datei → Claude API Content-Block
- `_analyse_zip(path)` — ZIP öffnen, Inhalt extrahieren, multi-block
- `_AttachChip` — Chip-Widget pro Datei mit X-Button
- `_AttachmentBar` — Scroll-Leiste mit Drag&Drop + 📎-Button

**Anwendungsfälle:**
- 🖼 Spektrogramm-Screenshot → "Was ist bei 2kHz los?"
- 📦 ZIP mit Projekt + Samples → "Analysiere diese Session"
- 📄 Preset-JSON → "Erkläre diese AETERNA-Einstellungen"
- 📝 MIDI-CSV → "Welche Akkordfolge steckt dahinter?"

## Geänderte Dateien
| Datei | Änderung |
|---|---|
| `pydaw/ui/ki_assistant_panel.py` | +_AttachmentBar, +_AttachChip, +_read_file_for_api, +_analyse_zip (898 Zeilen) |
| `VERSION` | 0.0.20.748 → 0.0.20.749 |
