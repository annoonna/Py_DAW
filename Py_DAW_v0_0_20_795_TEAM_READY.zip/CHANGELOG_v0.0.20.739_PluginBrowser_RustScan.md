# CHANGELOG v0.0.20.739 — Plugin-Browser GUI-Integration (Rust-Scanner Auto-Trigger)

**Datum:** 2026-03-22
**Autor:** Claude Sonnet 4.6
**Arbeitspaket:** P7 Plugin-Hosting — Plugin-Browser ↔ Rust-Scanner Verdrahtung

---

## Problem

Drei Lücken in der Rust-Scanner → Browser Kopplung:

1. **Cache-Pfad übersprungen**: Wenn der Plugin-Cache frisch war (`cache_is_fresh()`),
   wurde `rescan()` nicht aufgerufen — und damit auch `_trigger_rust_scan_if_available()`
   nie ausgelöst. Rust-Scan passierte nur nach manuellem Rescan-Klick.

2. **Engine-Toggle ohne Scan**: Wenn der User die Rust-Engine über
   "Audio → Rust Engine aktivieren" einschaltet, passierte kein Plugin-Scan.
   Der Browser zeigte weiterhin nur Python-gefundene Plugins.

3. **Kein Routing Engine → Browser**: `_trigger_rust_browser_scan()` fehlte
   im MainWindow komplett — es gab keine Brücke von Engine-State-Change zu
   PluginsBrowserWidget.

---

## Lösung

### `pydaw/ui/plugins_browser.py` — Deferred Auto-Scan im Cache-Pfad

```python
# Im __init__, nach Cache-Laden (wenn kein Rescan nötig):
QTimer.singleShot(2000, self._trigger_rust_scan_if_available)
```

2 Sekunden Delay damit das UI vollständig gerendert ist, bevor der
Rust-Engine-Socket angesprochen wird.

### `pydaw/ui/main_window.py` — Engine-Toggle triggert Browser-Scan

In `_apply_rust_engine_state(enabled=True)`:
```python
QTimer.singleShot(3000, self._trigger_rust_browser_scan)
```

3 Sekunden Delay: Der Rust-Engine-Prozess braucht ~1-2 s zum Start.

Neue Methode `_trigger_rust_browser_scan()`:
- Navigiert `self.library.plugins_tab._trigger_rust_scan_if_available()`
- Vollständig in try/except — bricht nichts wenn Browser nicht offen

---

## Was passiert jetzt beim User

| Szenario | Vorher | Nachher |
|----------|--------|---------|
| DAW öffnen, Cache frisch, Rust AN | Kein Rust-Scan | Auto-Scan nach 2 s |
| Rust-Engine über Menü einschalten | Kein Scan | Auto-Scan nach 3 s |
| Manueller Rescan-Klick | Rust-Scan ✅ | Rust-Scan ✅ (unverändert) |
| Python-Rescan nach Scan | Rust-Scan ✅ | Rust-Scan ✅ (unverändert) |

Alle Änderungen sind **rein additiv** — bestehender Code unberührt.

---

## Geänderte Dateien

| Datei | Änderung |
|---|---|
| `pydaw/ui/plugins_browser.py` | `__init__`: `QTimer.singleShot(2000, ...)` im Cache-Pfad |
| `pydaw/ui/main_window.py` | `_apply_rust_engine_state`: `QTimer.singleShot(3000, ...)` + neue Methode `_trigger_rust_browser_scan()` |
| `VERSION` | 0.0.20.739 |
| `pydaw/version.py` | 0.0.20.739 |

## Tests

- 332/332 Rust-Tests grün (unverändert)
- Python Syntax: `plugins_browser.py` ✅, `main_window.py` ✅, `device_browser.py` ✅

---

## Was als nächstes zu tun ist

Die P7 Plugin-Hosting Bausteine sind vollständig:
- ✅ VST3 IBStream State Save/Load
- ✅ CLAP Streams State Save/Load
- ✅ CLAP MIDI Event Injection
- ✅ LV2 Atom Port MIDI + State
- ✅ Plugin-Browser GUI-Integration

**Nächste Priorität:** Live-Tests auf echter Hardware:
1. CLAP-Instrument (Surge XT / Vital): NoteOn → Audio, State erhalten?
2. LV2-Instrument (Calf / ZynAddSubFX): NoteOn → Audio?
3. A/B Vergleich Python vs Rust Engine auf echtem Projekt
