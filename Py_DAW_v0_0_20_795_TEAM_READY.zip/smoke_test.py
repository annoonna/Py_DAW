#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Py_DAW Smoke Test — validates all modules compile and core imports work.

v0.0.20.712 — Run this after any code changes to ensure nothing is broken.

Usage:
    python3 smoke_test.py

Exit codes:
    0 — All checks passed
    1 — Compilation or import errors found

This does NOT require a running GUI, audio device, or Rust engine.
It only validates Python syntax and import chains.
"""
import os
import sys
import py_compile
import importlib
import traceback

# ---------------------------------------------------------------------------
# 1. Compile-check all .py files
# ---------------------------------------------------------------------------

def check_compilation() -> list:
    """Compile-check every .py file under pydaw/."""
    errors = []
    for root, _dirs, files in os.walk("pydaw"):
        for f in files:
            if f.endswith(".py"):
                path = os.path.join(root, f)
                try:
                    py_compile.compile(path, doraise=True)
                except py_compile.PyCompileError as e:
                    errors.append(f"COMPILE ERROR: {path}: {e}")
    return errors


# ---------------------------------------------------------------------------
# 2. Import-check core modules
# ---------------------------------------------------------------------------

CORE_MODULES = [
    # Core
    "pydaw.core.settings",
    "pydaw.core.settings_store",
    # Model
    "pydaw.model.project",
    # Services — Plugin Sandbox
    "pydaw.services.plugin_ipc",
    "pydaw.services.plugin_sandbox",
    "pydaw.services.sandbox_process_manager",
    "pydaw.services.sandboxed_fx",
    "pydaw.services.sandbox_overrides",
    # Services — Rust
    "pydaw.services.rust_project_sync",
    "pydaw.services.rust_sample_sync",
    "pydaw.services.rust_audio_takeover",
    "pydaw.services.rust_hybrid_engine",
    # Plugin Workers
    "pydaw.plugin_workers",
    "pydaw.plugin_workers.vst3_worker",
    "pydaw.plugin_workers.vst2_worker",
    "pydaw.plugin_workers.lv2_ladspa_worker",
    "pydaw.plugin_workers.clap_worker",
    # Plugins
    "pydaw.plugins.registry",
]


def check_imports() -> list:
    """Try importing core modules."""
    errors = []
    for mod_name in CORE_MODULES:
        try:
            importlib.import_module(mod_name)
        except ImportError as e:
            # Some modules need PyQt6 etc. — only flag truly broken imports
            err_msg = str(e)
            if "PyQt6" in err_msg or "Qt" in err_msg:
                continue  # Expected: no GUI in headless
            if "pedalboard" in err_msg:
                continue  # Optional: not always installed
            if "lilv" in err_msg:
                continue  # Optional: needs apt install
            if "sounddevice" in err_msg or "soundfile" in err_msg:
                continue  # Optional: audio libs
            errors.append(f"IMPORT ERROR: {mod_name}: {e}")
        except Exception as e:
            # Some modules fail due to missing Qt Application etc.
            err_msg = str(e)
            if "QApplication" in err_msg or "Qt" in err_msg:
                continue
            errors.append(f"IMPORT ERROR: {mod_name}: {e}")
    return errors


# ---------------------------------------------------------------------------
# 3. Validate VERSION file
# ---------------------------------------------------------------------------

def check_version() -> list:
    errors = []
    try:
        with open("VERSION", "r") as f:
            ver = f.read().strip()
        parts = ver.split(".")
        if len(parts) != 4:
            errors.append(f"VERSION format error: expected X.X.X.X, got '{ver}'")
        else:
            for p in parts:
                try:
                    int(p)
                except ValueError:
                    errors.append(f"VERSION non-integer part: '{p}' in '{ver}'")
    except FileNotFoundError:
        errors.append("VERSION file not found!")
    return errors


# ---------------------------------------------------------------------------
# 4. Validate documentation files exist
# ---------------------------------------------------------------------------

REQUIRED_DOCS = [
    "PROJECT_DOCS/ROADMAP_MASTER_PLAN.md",
    "PROJECT_DOCS/TEAM_RELAY_PROTOCOL.md",
    "PROJECT_DOCS/PLUGIN_SANDBOX_ROADMAP.md",
    "PROJECT_DOCS/RUST_DSP_MIGRATION_PLAN.md",
    "PROJECT_DOCS/sessions/LATEST.md",
    "PROJECT_DOCS/progress/TODO.md",
    "PROJECT_DOCS/progress/DONE.md",
]


def check_docs() -> list:
    errors = []
    for doc in REQUIRED_DOCS:
        if not os.path.isfile(doc):
            errors.append(f"MISSING DOC: {doc}")
    return errors


# ---------------------------------------------------------------------------
# 5. Count Rust .rs files (no compile check, just existence)
# ---------------------------------------------------------------------------

def check_rust_files() -> dict:
    """Count Rust source files and total lines."""
    rs_files = 0
    rs_lines = 0
    for root, _dirs, files in os.walk("pydaw_engine"):
        for f in files:
            if f.endswith(".rs"):
                rs_files += 1
                try:
                    with open(os.path.join(root, f), "r") as fh:
                        rs_lines += sum(1 for _ in fh)
                except Exception:
                    pass
    return {"files": rs_files, "lines": rs_lines}


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    print("=" * 60)
    print("  Py_DAW Smoke Test")
    print("=" * 60)

    all_errors = []

    # 1. Compilation
    print("\n[1/5] Checking Python compilation...")
    py_count = sum(1 for r, _, fs in os.walk("pydaw") for f in fs if f.endswith(".py"))
    errs = check_compilation()
    all_errors.extend(errs)
    if errs:
        for e in errs:
            print(f"  ❌ {e}")
    else:
        print(f"  ✅ {py_count} .py files compile OK")

    # 2. Imports
    print("\n[2/5] Checking core imports...")
    errs = check_imports()
    all_errors.extend(errs)
    if errs:
        for e in errs:
            print(f"  ❌ {e}")
    else:
        print(f"  ✅ {len(CORE_MODULES)} core modules importable")

    # 3. VERSION
    print("\n[3/5] Checking VERSION file...")
    errs = check_version()
    all_errors.extend(errs)
    if errs:
        for e in errs:
            print(f"  ❌ {e}")
    else:
        with open("VERSION") as f:
            print(f"  ✅ VERSION = {f.read().strip()}")

    # 4. Documentation
    print("\n[4/5] Checking documentation...")
    errs = check_docs()
    all_errors.extend(errs)
    if errs:
        for e in errs:
            print(f"  ❌ {e}")
    else:
        print(f"  ✅ {len(REQUIRED_DOCS)} required docs present")

    # 5. Rust files
    print("\n[5/5] Counting Rust source files...")
    rust = check_rust_files()
    print(f"  📊 {rust['files']} .rs files, {rust['lines']} lines")

    # 6. P0A/P0B regression checks (v0.0.20.746)
    print("\n[6/6] P0A/P0B regression checks (v0.0.20.746)...")
    p0_errors = []

    # P0A: Verify ScanPlugins runs in a background thread (not in drain_commands)
    try:
        engine_rs = "pydaw_engine/src/engine.rs"
        if os.path.exists(engine_rs):
            with open(engine_rs, encoding="utf-8") as f:
                engine_src = f.read()
            if "thread::Builder::new()" in engine_src and "pydaw-plugin-scan" in engine_src:
                print("  ✅ P0A: ScanPlugins runs in background thread (Rust)")
            else:
                p0_errors.append("P0A: ScanPlugins background thread NOT found in engine.rs")
                print("  ❌ P0A: ScanPlugins background thread NOT found")
        else:
            print("  ⚠️  P0A: engine.rs not found (Rust not built) — skipping")
    except Exception as e:
        p0_errors.append(f"P0A check error: {e}")

    # P0A: Verify Python bridge has exponential backoff reconnect
    try:
        bridge_py = "pydaw/services/rust_engine_bridge.py"
        with open(bridge_py, encoding="utf-8") as f:
            bridge_src = f.read()
        if "_do_reconnect_with_backoff" in bridge_src and "_schedule_reconnect" in bridge_src:
            print("  ✅ P0A: Exponential-backoff reconnect present in bridge")
        else:
            p0_errors.append("P0A: Exponential-backoff reconnect NOT found in rust_engine_bridge.py")
            print("  ❌ P0A: Reconnect logic NOT found in bridge")
    except Exception as e:
        p0_errors.append(f"P0A bridge check error: {e}")

    # P0B: Verify scrawl envelope is wired in multisample_engine
    try:
        eng_py = "pydaw/plugins/sampler/multisample_engine.py"
        with open(eng_py, encoding="utf-8") as f:
            eng_src = f.read()
        if "_use_scrawl" in eng_src and "scrawl_env_pts" in eng_src:
            print("  ✅ P0B: Scrawl amp-envelope wired in MultiSampleEngine")
        else:
            p0_errors.append("P0B: Scrawl envelope NOT wired in multisample_engine.py")
            print("  ❌ P0B: Scrawl envelope NOT wired")
    except Exception as e:
        p0_errors.append(f"P0B engine check error: {e}")

    # P0B: Verify project_service flushes sampler state before save
    try:
        ps_py = "pydaw/services/project_service.py"
        with open(ps_py, encoding="utf-8") as f:
            ps_src = f.read()
        if "_flush_advanced_sampler_states" in ps_src:
            print("  ✅ P0B: Advanced sampler state flush in project_service")
        else:
            p0_errors.append("P0B: _flush_advanced_sampler_states NOT found in project_service.py")
            print("  ❌ P0B: Sampler flush NOT found")
    except Exception as e:
        p0_errors.append(f"P0B project_service check error: {e}")

    # P0D: Verify crash reporter is installed
    try:
        app_py = "pydaw/app.py"
        with open(app_py, encoding="utf-8") as f:
            app_src = f.read()
        if "_install_crash_reporter" in app_src and "sys.excepthook" in app_src:
            print("  ✅ P0D: Global crash reporter installed in app.py")
        else:
            p0_errors.append("P0D: Crash reporter NOT found in app.py")
            print("  ❌ P0D: Crash reporter NOT found")
    except Exception as e:
        p0_errors.append(f"P0D check error: {e}")

    all_errors.extend(p0_errors)

    # Summary
    print("\n" + "=" * 60)
    if all_errors:
        print(f"  ❌ FAILED — {len(all_errors)} error(s)")
        for e in all_errors:
            print(f"    • {e}")
        return 1
    else:
        print("  ✅ ALL CHECKS PASSED")
        return 0


if __name__ == "__main__":
    sys.exit(main())
