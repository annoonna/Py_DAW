# CHANGELOG v0.0.20.747 — P2A KI-Assistent + P0D First-Run

**Datum:** 2026-03-23
**Autor:** Claude Sonnet 4.6
**Arbeitspakete:** PRO_ROADMAP_2026 → P2A (KI-Kompositions-Assistent) + P0D (First-Run-Experience)

---

## Was wurde gemacht

### P2A — KI-Kompositions-Assistent (Claude API) ✅

**Neue Datei: `pydaw/ui/ki_assistant_panel.py`**

Dockbares Panel mit vollständiger Claude-API-Integration:

- **Quick Prompts**: 6 vorkonfigurierte Buttons (🥁 Drum Groove, 🎹 Chord Prog, 🎸 Bassline, 🎵 Melodie, 🎲 Variation, 🤔 Erkläre)
- **Freier Prompt**: Natürliche Sprache → MIDI-Pattern
- **Kontext-aware**: Liest BPM, Tonart, Taktart, Track-Name aus aktivem Projekt
- **JSON-MIDI-Parser**: Extrahiert `{"type": "midi_notes", "notes": [...]}` aus KI-Antwort
- **Direktes Einfügen**: "Direkt einfügen" Checkbox → Noten sofort in aktiven Track
- **API-Key**: Sicher in QSettings gespeichert (nur lokal, kein Cloud-Upload)
- **Worker-Thread**: API-Call läuft in eigenem QThread — GUI friert nicht ein
- **Fehlerbehandlung**: Benutzerfreundliche Fehlermeldungen, Link zu console.anthropic.com

**Integration in `pydaw/ui/main_window.py`:**
- Menü: Projekt → 🤖 KI-Assistent… (Ctrl+Alt+K)
- Dock: Rechts, tabbed mit Browser-Dock, standardmäßig ausgeblendet
- `_toggle_ki_assistant_dock()` — Ein/Ausblenden
- `_on_ki_insert_notes()` — Noten in Track einfügen (neuer Clip wird angelegt)
- `_on_track_selected()` — KI-Panel Kontext wird bei Track-Wechsel automatisch aktualisiert

### P0D — First-Run-Experience ✅

**Neue Datei: `pydaw/ui/first_run_dialog.py`**

5-seitiger QWizard der einmalig beim ersten Start erscheint:

1. **Willkommen** — Feature-Highlights, Projekt-Vision
2. **Schnellstart** — 4 Schritte: Projekt → Track → Instrument → Note → Ton
3. **Audio-Setup** — Live-Prüfung PipeWire/JACK/ALSA + Rust-Engine-Status
4. **KI-Assistent** — Optionale Claude-API-Einrichtung, Beispiele
5. **Fertig!** — Tastenkürzel-Übersicht, "Nicht mehr zeigen" Checkbox

- Erscheint 500ms nach Start via `QTimer.singleShot`
- Wird nach erstem Schließen permanent deaktiviert (QSettings)
- Nicht kritisch: Exception → DAW startet trotzdem

---

## Geänderte Dateien

| Datei | Änderung |
|---|---|
| `pydaw/ui/ki_assistant_panel.py` | NEU — KI-Assistent Panel (261 Zeilen) |
| `pydaw/ui/first_run_dialog.py` | NEU — First-Run-Wizard (248 Zeilen) |
| `pydaw/ui/main_window.py` | +_act_ki_assistant, +KI-Dock, +_toggle_ki_assistant_dock, +_on_ki_insert_notes, +_maybe_show_first_run, +KI-Kontext in _on_track_selected |
| `VERSION` | 0.0.20.746 → 0.0.20.747 |

---

## Was als nächstes zu tun ist

### P0B Rest (Hardware-Tests — nicht automatisierbar):
- `./start_daw.sh` → Advanced Sampler → Zone laden → Speichern → Neu starten → Zone noch da?
- Piano Roll: 12 Noten mit verschiedenen Velocities → Lautstärke-Unterschied hörbar?

### P0C — Rust Live-Validierung (Hardware):
- `USE_RUST_ENGINE=1 python3 main.py` → Engine bleibt > 5 Min verbunden?
- CLAP (Surge XT) laden → NoteOn → Ton

### P2A Erweiterungen (nächste Session):
- Streaming-Support (Server-Sent Events) für Echtzeit-Textausgabe
- Chat-History: Mehrere Nachrichten im Panel (Konversation)
- MIDI-Pattern direkt im Panel als Mini-Piano-Roll vorschauen

### P0D Erweiterung:
- CHANGELOG v0.1.0-beta schreiben (Meilenstein-Erreichen dokumentieren)

---

## Bekannte Einschränkungen

- KI-Assistent benötigt Internet-Verbindung + Anthropic API-Key
- First-Run-Wizard Audio-Check: `subprocess` Call — falls Shell nicht verfügbar → graceful fallback
- `_on_ki_insert_notes`: `tracks_by_id()` Aufruf — falls Methode nicht existiert → try/except fängt es
