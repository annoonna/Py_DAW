# CHANGELOG v0.0.20.750 — BRRR Flutter Synthesizer (ZynAddSubFX BRRRRRR2 Port)

**Datum:** 2026-03-23  **Autor:** Claude Sonnet 4.6

## Was wurde gemacht

### Neues Instrument: BRRR Flutter Synth (`chrono.brrr`)

Vollständiger Port des ZynAddSubFX BRRRRRR2-Fantasy Klangs als eigenständiges
Py_DAW-Instrument — mit allen Stabilitäts-Features die Fusion auch hat.

#### Architektur (exakt wie das Original):
**Layer A — FM-Buzz (kein Sustain):**
- Power-Welle mit Harmonischen H1/H2/H6 (wie Zyn base_function=5)
- Phase-Modulation via Harmonische 25 (das charakteristische Brummen)
- 3 Stimmen: Center + Links (−35 Cent) + Rechts (+27 Cent)
- Schnell abklingend (A=0, D=350ms, S=0) — keine Sustain-Phase

**Layer B — S&H-Flutter (das BRRRRRR):**
- 2 Noise-Voices mit Sample-and-Hold LFO
- S&H springt Pitch zufällig ±3 Oktaven (exakt wie Zyn Voices 3+4)
- Rate A: 0.78 Hz, Rate B: 0.67 Hz (originale Werte)
- BandPass-Filter (BP 2-stufig wie Original)
- Voller Sustain, langsamer Attack

#### Features:
- **5 Factory-Presets**: Original, Soft Flutter, Hard Buzz Attack, Deep Low BRRR, Space Firefly
- **Scrawl-Hüllkurven** für Buzz und Flutter (zeichenbar mit der Maus)
- **Alle Parameter per CompactKnob** → MIDI Learn + Automation
- **State-Persistenz**: Zustand wird im Projekt gespeichert (gleich wie Fusion)
- **Pull-Source**: Registriert in Audio-Engine für Live-Preview
- **SamplerRegistry**: MIDI Note On/Off funktioniert
- **Preset-Save/Load**: JSON-Dateien (*.brrr.json)

#### Neue Dateien:
| Datei | Inhalt |
|---|---|
| `pydaw/plugins/brrr/__init__.py` | Plugin-Package |
| `pydaw/plugins/brrr/brrr_engine.py` | DSP-Engine (575 Zeilen) |
| `pydaw/plugins/brrr/brrr_widget.py` | PyQt6-UI (604 Zeilen) |

#### Geänderte Dateien:
| Datei | Änderung |
|---|---|
| `pydaw/ui/fx_specs.py` | `chrono.brrr` im Instrument-Browser |
| `pydaw/ui/device_panel.py` | BrrrWidget Factory-Case |
| `pydaw_engine/src/instruments/mod.rs` | `chrono.brrr` → Fusion-Alias |

## Wie benutzen:
1. Browser → Instrumente → "BRRR Flutter Synth" → Doppelklick
2. Preset wählen: "BRRRRRR2 Fantasy (Original)"
3. Piano Roll → Note spielen → BRRRRRR!
4. Scrawl-Envs Tab → eigene Hüllkurvenformen zeichnen
5. Preset → 💾 → eigenes Preset speichern
