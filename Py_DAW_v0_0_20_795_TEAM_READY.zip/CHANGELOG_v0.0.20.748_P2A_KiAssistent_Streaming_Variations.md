# CHANGELOG v0.0.20.748 — P2A KI-Assistent: Streaming + Chat-History + Variations-Generator

**Datum:** 2026-03-23
**Autor:** Claude Sonnet 4.6
**Arbeitspaket:** PRO_ROADMAP_2026 → P2A

## Was wurde gemacht

### ki_assistant_panel.py — Kompletterweiterung

**Streaming (SSE) — `_StreamWorker`:**
- `"stream": True` in API-Payload
- Liest SSE-Events (`data: {...}`) Zeile für Zeile
- `content_block_delta` → `text_delta` → `chunk_received` Signal
- Text erscheint Wort für Wort im Chat-Display — keine Blockierung

**Chat-History — `self._history`:**
- `List[Dict[str, str]]` mit role=user/assistant
- Alle Nachrichten werden als `messages=[...]` an API übergeben
- KI "erinnert" sich an vorherige Runden innerhalb einer Session
- "🗑 Neu"-Button setzt History zurück

**Variations-Generator — `_do_variations()` + `_VariationsWidget`:**
- Quick Prompt "🎲 4×Variation" → liest aktiven Clip-Noten als Kontext
- Prompt fordert 4 separate JSON-Blöcke an (V1–V4)
- `_parse_vars()` extrahiert mehrere `midi_notes`-Blöcke aus Antwort
- `_VariationsWidget`: QTabWidget mit 4 Tabs → je "🎹 Einfügen"-Button
- Kein Auto-Insert bei Variationen — User wählt aktiv aus

**Clip-Kontext — `_active_clip_notes()`:**
- Liest `project.midi_notes[active_clip_id]`
- `_notes_to_summary()`: MIDI-Noten → kompakter Text für System-Prompt
- "🤔 Analyse"-Quick-Prompt sendet Noten automatisch mit

**Weitere Verbesserungen:**
- Enter = senden, Shift+Enter = neue Zeile (eventFilter)
- Kontext-Leiste: BPM/Tonart/Taktart/Track + aktiver Clip-Name
- Farbige Chat-Bubbles: Du (blau) / KI (grün) / Fehler (rot)

## Geänderte Dateien

| Datei | Änderung |
|---|---|
| `pydaw/ui/ki_assistant_panel.py` | Komplette Überarbeitung: +Streaming, +History, +Variations (597 Zeilen) |
| `VERSION` | 0.0.20.747 → 0.0.20.748 |

## Was als nächstes zu tun ist

- P2A: MIDI-Vorschau im Panel (Mini-Piano-Roll)
- P0D: CHANGELOG v0.1.0-beta schreiben
- P1A: Recording-Workflow polieren
