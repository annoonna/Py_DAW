# CHANGELOG v0.0.20.752 — P0B: Velocity-Bar im Piano Roll

**Datum:** 2026-03-23  **Autor:** Claude Sonnet 4.6

## Was wurde gemacht

### P0B — Velocity-Bar unter dem Piano Roll
**Neue Datei:** `pydaw/ui/velocity_bar.py` (329 Zeilen)
- Balken pro Note: Höhe = velocity/127 (linear)
- Farbe: blau (normal), orange (selektiert), hell (hover)
- Linkes Drag auf Balken → Velocity live ändern (mit Undo)
- Mehrere Noten selektiert → Delta-Drag für alle gemeinsam
- Doppelklick auf Hintergrund → Default-Velocity für neue Noten setzen
- Rechtsklick-Menü: "Velocity für Selektion setzen", Default-Velocity ändern, Reset auf 100
- Scrollt synchron mit Piano Roll Canvas
- Velocity-Zahl erscheint über Balken bei Hover/Selektion

**`pydaw/ui/pianoroll_editor.py`:**
- Import VelocityBar
- Row 3 im Grid nach Expression Lane

**`pydaw/ui/pianoroll_canvas.py`:**
- `_default_velocity: int = 100` — neue Noten bekommen diese Velocity
- `MidiNote(velocity=self._default_velocity)` beim Zeichnen

**`pydaw/services/project_service.py`:**
- `set_midi_note_velocity(clip_id, note_index, velocity)` — live Velocity setzen ohne Undo-Commit

## Geänderte Dateien
| Datei | Änderung |
|---|---|
| `pydaw/ui/velocity_bar.py` | NEU — Velocity-Bar Widget |
| `pydaw/ui/pianoroll_editor.py` | Import + Grid Row 3 |
| `pydaw/ui/pianoroll_canvas.py` | _default_velocity |
| `pydaw/services/project_service.py` | set_midi_note_velocity() |
