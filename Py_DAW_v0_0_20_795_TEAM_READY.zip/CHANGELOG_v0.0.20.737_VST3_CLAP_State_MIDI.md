# CHANGELOG v0.0.20.737 — VST3 IBStream + CLAP Streams + CLAP MIDI Injection

**Datum:** 2026-03-22
**Autor:** Claude Sonnet 4.6
**Arbeitspaket:** P7 Plugin-Hosting — State Save/Load + MIDI Event Injection

---

## Erledigte TODOs (waren seit v0.0.20.716 offen)

### 1. VST3 IBStream — echtes State Save/Load (`vst3_host.rs`)

**Problem:** `save_state()` / `load_state()` hatten `// TODO: IBStream` Stubs und
lieferten immer nur den letzten gespeicherten Blob zurück — Plugins verloren ihren
Zustand beim Projekt-Öffnen komplett.

**Lösung:** `MemoryStream` — ein vollständiges COM `IBStream`-Objekt in Rust:

```rust
#[repr(C)]
struct MemoryStream {
    vtbl: *const IBStreamVtbl,  // ← COM ABI: vtable MUSS erste Field sein
    data: Vec<u8>,
    pos:  usize,
}
```

- Statische `IBStreamVtbl` mit `read`, `write`, `seek`, `tell`, `query_interface`
- `MemoryStream::new_writer()` → Plugin schreibt in uns → wir sammeln Bytes
- `MemoryStream::new_reader(data)` → Plugin liest aus uns → liefert `data`
- `save_state()`: `get_state(component, &stream)` → `stream.data`
- `load_state()`: `set_state(component, &stream)` + `set_component_state(controller, &stream2)`
  damit GUI-Parameter mit dem geladenen State synchronisiert werden

**8 Unit-Tests** — alle ohne echtes Plugin:
`test_memory_stream_write_read`, `_seek_tell`, `_partial_read`, `_write_append`,
`_new_writer_empty`, `_new_reader_prefilled`, `_query_interface_ibstream`,
`_query_interface_unknown_returns_error`

---

### 2. CLAP State Save/Load (`clap_host.rs`)

**Problem:** `save_state()` / `load_state()` hatten `// TODO: ClapOStream/ClapIStream`.

**Lösung:** Zwei schlanke C-kompatible Stream-Adapter:

```rust
// Lesen: &[u8] → Plugin
struct ClapReadCtx { data_ptr, data_len, pos }
unsafe extern "C" fn clap_read_fn(stream, buffer, size) -> i64

// Schreiben: Plugin → Vec<u8>  
unsafe extern "C" fn clap_write_fn(stream, buffer, size) -> i64
```

- `save_state()`: `clap_plugin_state.save(plugin, &ostream)` → `Vec<u8>`
- `load_state()`: `clap_plugin_state.load(plugin, &istream)`
- Non-fatal bei `return false` (viele Plugins returnen false auch bei Erfolg)

**5 Stream-Tests:** `test_clap_ostream_write_collects_bytes`,
`_multiple_writes_append`, `_istream_read_full`, `_partial_read`,
`_read_at_eof_returns_zero`, `_incremental_reads`

---

### 3. CLAP MIDI Event Injection (`clap_host.rs`)

**Problem:** CLAP-Instrumente (Surge XT, Vital, etc.) empfingen **keine Noten** aus dem
MidiScheduler — `in_events` war immer die leere `empty_in_size/empty_in_get` Liste.

**Lösung:**

```rust
// Neue CLAP ABI-konforme structs (clap/events.h)
struct ClapEventHeader { size, time, space_id, event_type, flags }
struct ClapNoteEvent   { header, note_id, port_index, channel, key, velocity }
```

- `ClapNoteEvent::note_on(key, velocity, sample_offset)` / `::note_off(key, offset)`
- `struct NoteEventList<'a>` — zero-alloc, kein Heap auf dem Audio-Thread
- `ClapInstance::push_note_on()` / `push_note_off()` / `clear_notes()`
- `process()`: wenn `pending_notes` nicht leer → baut echte `ClapInputEvents` mit
  `note_list_size`/`note_list_get` Callbacks → übergibt an `clap_plugin.process()`
- Notes werden nach `process()` gecleart

**7 MIDI-Tests:** ABI-Größe (32 Bytes!), Felder, NoteEventList size/get,
null-safety für read/write

---

## Geänderte Dateien

| Datei | Änderung |
|---|---|
| `pydaw_engine/src/vst3_host.rs` | +`MemoryStream` COM IBStream (~140 Zeilen + 8 Tests) |
| `pydaw_engine/src/clap_host.rs` | +CLAP Streams + `ClapNoteEvent` + `NoteEventList` + `pending_notes` + 13 Tests |
| `VERSION` | 0.0.20.737 |
| `pydaw/version.py` | 0.0.20.737 |

## Testergebnis

**320/320 Rust-Tests grün** (vorher 299, +21 neue Tests)
0 errors, 0 neue Warnings

---

## Was als nächstes zu tun ist

1. **Plugin-Browser GUI-Integration** — `rust_engine_bridge.py`: `plugin_scan_result`
   Signal → Plugin-Browser-Model updaten (additiv zu pedalboard-Scan)
2. **Live-Test** mit echtem CLAP-Plugin (Surge XT / Vital):
   - Plugin laden, NoteOn senden, Audio prüfen
   - State speichern, Projekt neu laden → Parameter erhalten?
3. **LV2 Atom Port MIDI** — `lv2_host.rs`: MIDI über Atom-Events (nächste Baustelle)
