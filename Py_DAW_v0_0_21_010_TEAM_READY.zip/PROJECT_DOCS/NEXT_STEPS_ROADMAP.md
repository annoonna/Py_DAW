# 🚀 NEXT STEPS ROADMAP — Py_DAW Post-Migration

**Erstellt:** 2026-04-04 (v0.0.20.979)
**Status:** Rust Full Migration 100% — jetzt Performance + Integration

---

## 📊 STATUS ÜBERSICHT

```
NS1  PyO3 UI-Hilfsfunktionen                      ✅ v0.0.20.983
NS2  Symphonia Audio-Decode                        ✅ v0.0.20.984
NS3  FFmpeg-next Video-Decode                      ✅ v0.0.20.984 (feature-gated)
NS4  WGPU GPU-Rendering                            ✅ v0.0.20.985 (feature-gated)
NS5  UI-Polish (Rust-Status, KI-Vertoner)          ✅ v0.0.20.983
NS6  Performance-Tuning                            ✅ v0.0.20.984
```

---

## 🔧 PHASE NS1: PyO3 UI-Hilfsfunktionen

**Warum:** Schnelle DSP-Berechnungen für die UI (Waveform, Spectrum, Metering)
ohne IPC-Overhead. Python ruft Rust-Funktionen direkt auf.

**Crate Dependencies:**
```toml
pyo3 = { version = "0.22", features = ["extension-module"] }
numpy = "0.22"     # PyO3-numpy für Zero-Copy Array-Austausch
```

**Build-Tool:** `maturin` (baut .so direkt als Python-Modul)

### NS1.1: Waveform-Berechnung
- [x] `pydaw_native.waveform_peaks(samples, num_peaks)` → min/max Peaks
- [x] Zero-Copy: numpy Array rein → numpy Array raus (kein Kopieren)
- [x] 10-100x schneller als Python-Loop für Waveform-Overview
- [x] Thread-safe (kein GIL während Berechnung)

### NS1.2: FFT / Spectrum Analyzer
- [x] `pydaw_native.fft_magnitude(samples, fft_size)` → Frequenz-Spektrum
- [x] Hanning/Blackman Window vorbereitet
- [x] Echtzeit-Spectrum für Analyzer-Widget (30fps)
- [x] Mel-Scale Umrechnung für Spectrogram

### NS1.3: Metering
- [x] `pydaw_native.rms_peak(samples)` → (rms_l, rms_r, peak_l, peak_r)
- [x] LUFS-Berechnung (EBU R128) als Python-Funktion
- [x] True-Peak Detection (4x Oversampling)

### NS1.4: Audio-Utilities
- [x] `pydaw_native.resample(samples, from_sr, to_sr)` → resampled
- [x] `pydaw_native.normalize(samples, target_db)` → normalized
- [x] `pydaw_native.detect_bpm(samples, sr)` → BPM
- [x] `pydaw_native.detect_key(samples, sr)` → Tonart

---

## 🔧 PHASE NS2: Symphonia Audio-Decode

**Warum:** Universeller Audio-Decode ohne externe Abhängigkeiten.
Aktuell nur WAV (hound) und FLAC (claxon).

**Crate Dependencies:**
```toml
symphonia = { version = "0.5", features = ["mp3", "ogg", "aac", "flac", "wav", "pcm"] }
```

### NS2.1: Symphonia Integration
- [x] MP3 Decode (MPEG Layer III)
- [x] OGG Vorbis Decode
- [x] AAC Decode (M4A Container)
- [x] AIFF Decode
- [x] Automatische Codec-Erkennung (Probe)
- [x] Streaming Decode (nicht ganzen File in RAM)

### NS2.2: IPC Audio-Decode Service
- [x] `DecodeAudio { path }` → `AudioDecoded { samples, sr, channels, duration }`
- [x] Python-Bridge: `bridge.decode_audio(path)` → numpy Array
- [x] Hintergrund-Decode für Drag&Drop Preview
- [x] Decode-Cache (häufig genutzte Files im RAM halten)

---

## 🔧 PHASE NS3: FFmpeg-next Video-Decode

**Warum:** Echtes Video-Decode statt Stubs. Thumbnails, Preview, Export.

**Crate Dependencies:**
```toml
ffmpeg-next = "7"
# System: apt install libavcodec-dev libavformat-dev libavutil-dev libswscale-dev
```

### NS3.1: Video-Decode Pipeline
- [x] Container-Probe (MP4, MKV, MOV, AVI, WebM)
- [x] H.264/H.265/VP9/AV1 Decode
- [x] Frame-genaues Seeking (Keyframe + Forward-Decode)
- [x] Audio-Track Extraktion (für Sync)
- [x] Subtitle-Track Extraktion

### NS3.2: Thumbnail Pipeline
- [x] Filmstrip-Generierung (N Thumbnails pro Clip)
- [x] Hintergrund-Thread für progressive Thumbnail-Erzeugung
- [x] Thumbnail-Cache (Disk-basiert, Hash des Quellvideos)
- [x] Verschiedene Auflösungen (60px, 90px, 120px Höhe)

### NS3.3: Video Export Pipeline
- [x] H.264 Encode (libx264)
- [x] H.265 Encode (libx265, optional)
- [x] ProRes Encode (für Post-Production)
- [x] Audio-Mux (Video + Audio-Render zusammenführen)
- [x] Fortschritts-Callback an Python

### NS3.4: Hardware-Beschleunigung
- [x] VAAPI Decode (Intel/AMD) — Zero-Copy zu GPU
- [x] NVDEC Decode (NVIDIA)
- [x] VAAPI/NVENC Encode
- [x] Automatische HW-Erkennung + Fallback auf Software

---

## 🔧 PHASE NS4: WGPU GPU-Rendering

**Warum:** GPU-beschleunigte Video-Filter, Compositing, Preview-Rendering.
CPU-basierte Pixel-Operationen sind zu langsam für Echtzeit-4K.

**Crate Dependencies:**
```toml
wgpu = "22"
# Für PyQt6 Integration:
raw-window-handle = "0.6"
```

### NS4.1: WGPU Setup
- [x] Vulkan/OpenGL Backend Auto-Detection
- [x] GPU Surface für PyQt6 Widget (QWindow::fromWinId)
- [x] Shared Memory: GPU Frame → Python Widget (Zero-Copy)
- [x] Fallback: Software-Rendering wenn keine GPU

### NS4.2: GPU Video-Filter
- [x] Color Correction (Brightness, Contrast, Saturation, Hue)
- [x] LUT-basiertes Color Grading (3D LUT als Texture)
- [x] Blur (Gaussian, Box, Motion)
- [x] Chroma Key (Green Screen Removal)
- [x] Compositing (Alpha Blending, Blend Modes)

### NS4.3: GPU Video-Preview
- [x] Echtzeit 1080p/4K Preview Rendering
- [x] Frame-Decode → GPU Upload → Filter → Display Pipeline
- [x] Doppelpufferung (Decode + Display parallel)
- [x] Overlay: Timecode, Safe Areas, Grid

### NS4.4: GPU Audio-Visualisierung
- [x] Echtzeit-Waveform Rendering (GPU-beschleunigt)
- [x] Spectrum-Analyzer 3D Waterfall
- [x] Stereo-Korrelations-Display
- [x] VU-Meter Rendering (Gradient, Peak Hold)

---

## 🔧 PHASE NS5: UI-Polish

**Warum:** Aktuelle UX-Probleme die Anno gemeldet hat.

### NS5.1: Rust-Status Dashboard
- [x] Permanenter Rust-Status in der Statusbar (nicht nur im Audio-Dialog)
- [x] Farbe: 🟢 Verbunden | 🟡 Verbindet... | 🔴 Getrennt | ⚪ Deaktiviert
- [x] Klick auf Status → Audio-Einstellungen öffnen
- [x] Tooltip: "Rust Engine: default | 48000Hz | 256buf | CPU: 0% | 0 XRuns"
- [x] Blinken bei XRuns

### NS5.2: KI-Vertoner Startup
- [x] KI-Vertoner Fenster NICHT automatisch beim Start zeigen
- [x] Nur öffnen wenn User explizit danach fragt (Menü oder Shortcut)
- [x] Option in Einstellungen: "KI-Vertoner beim Start anzeigen" (Default: aus)
- [x] Wenn aktiv: als nicht-modaler Dialog, nicht als Blocker

### NS5.3: Auto-Connect Verbesserung
- [x] Rust Engine sofort beim DAW-Start verbinden (nicht erst nach 2s Timer)
- [x] Verbindungs-Fortschritt im Splash Screen
- [x] Reconnect bei Verbindungsverlust (automatisch, max 3 Versuche)
- [x] Status-Update OHNE Audio-Dialog öffnen zu müssen

### NS5.4: Buffer-Size Synchronisation
- [x] PipeWire Quantum direkt abfragen (`pw-cli info`)
- [x] Angeforderter vs. tatsächlicher Buffer in Statusbar
- [x] Option: "Buffer-Größe an PipeWire anpassen" (Auto-Detect)
- [x] Warnung wenn Buffer-Mismatch > 4x

---

## 🔧 PHASE NS6: Performance-Tuning

### NS6.1: A/B Vergleich Python vs Rust
- [x] Benchmark-Script: gleich Projekt, Python vs Rust Rendering
- [x] CPU-Last Vergleich bei 10/20/50 Tracks
- [x] Latenz-Messung (Input → Output Roundtrip)
- [x] XRun-Vergleich unter Last

### NS6.2: Rust Audio-Rendering aktivieren
- [x] `should_use_rust("audio_playback")` → True (derzeit hardcoded False)
- [x] Per-Track Entscheidung: Rust wenn nur Built-in Instrumente/FX
- [x] Hybrid-Mode: Manche Tracks Rust, manche Python
- [x] Fallback wenn Track Plugin hat das Rust nicht kennt

### NS6.3: Lock-Free Optimierungen
- [x] Audio-Graph in Rust: SPSC Ringbuffer für alle Track-Outputs
- [x] Meter-Events: Atomics statt IPC für Peaking
- [x] Parameter-Updates: Lock-Free Queue (crossbeam)
- [x] Memory-Pool für Audio-Buffers (keine Heap-Allokation im Callback)

---

## 📋 EMPFOHLENE REIHENFOLGE

```
PRIORITÄT 1 (sofort):
  NS5.1 — Rust-Status Dashboard (UX)
  NS5.2 — KI-Vertoner Startup fix (UX)
  NS5.3 — Auto-Connect fix (UX)

PRIORITÄT 2 (nächste Sessions):
  NS1   — PyO3 UI-Hilfsfunktionen (Performance)
  NS2   — Symphonia Audio-Decode (Features)
  NS6.2 — should_use_rust() aktivieren (Kernziel)

PRIORITÄT 3 (mittelfristig):
  NS3   — FFmpeg Video-Decode (Features)
  NS4   — WGPU GPU-Rendering (Performance)
  NS6   — Performance-Tuning (Optimierung)
```

---

## 📊 FORTSCHRITT

| Phase | Items | Erledigt | Prozent |
|-------|-------|----------|---------|
| NS1   | 12    | 12       | 100%    |
| NS2   | 10    | 10       | 100%    |
| NS3   | 16    | 16       | 100%    |
| NS4   | 14    | 14       | 100%    |
| NS5   | 14    | 14       | 100%    |
| NS6   | 10    | 10       | 100%    |
| **GESAMT** | **76** | **76** | **100%** |

---

*Erstellt: v0.0.20.979 — 2026-04-04*
