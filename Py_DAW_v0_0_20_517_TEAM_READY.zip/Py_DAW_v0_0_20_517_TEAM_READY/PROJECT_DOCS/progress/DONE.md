## v0.0.20.517 — Ctrl+Drag Copy, Auto Track-Type, Belegte Audio-Spuren Morph (2026-03-16)

- `pydaw/ui/main_window.py`:
  - **`_is_ctrl_held()`**: Neuer statischer Helper prueft `QApplication.keyboardModifiers()` auf `ControlModifier`.
  - **`_smartdrop_remove_from_source()`**: Erweitert um Auto Track-Type: nach Instrument-Entfernung von einer Instrument-Spur wird `kind="audio"` gesetzt wenn kein plugin_type mehr vorhanden.
  - **`_on_arranger_smartdrop_instrument_to_track()`**: Prueft jetzt `_is_ctrl_held()` — bei Ctrl wird Device kopiert statt verschoben. Statusmeldung zeigt "kopiert"/"verschoben"/"gesetzt".
  - **`_on_arranger_smartdrop_fx_to_track()`**: Ebenso Ctrl-Copy-Support. Undo-Label und Status passen sich dynamisch an.
  - **`_on_arranger_smartdrop_instrument_morph_guard()`**: Ebenso Ctrl-Copy fuer Cross-Track-Morph auf Audio-Spuren.
- `pydaw/services/smartdrop_morph_guard.py`:
  - **`build_audio_to_instrument_morph_plan()`**: Setzt `can_apply=True` und `apply_mode="audio_to_instrument_with_content"` fuer ALLE Audio-Spuren (nicht nur leere). Belegte Spuren zeigen `requires_confirmation=True` fuer Bestaetigungsdialog.
  - **`apply_audio_to_instrument_morph_plan()`**: Akzeptiert jetzt beide Modi (`minimal_empty_audio` und `audio_to_instrument_with_content`). Die Mutation ist identisch: Before-Snapshot → set_track_kind → After-Snapshot → Undo-Push. Audio-Clips und FX-Kette bleiben komplett erhalten.
  - **`validate_audio_to_instrument_morph_plan()`**: Bewahrt `can_apply=True` fuer beide Modi.
- **Getestet**: Leere Audio-Spur (no dialog), Audio+Clips (dialog→morph→clips erhalten), Audio+FX (dialog→morph→FX erhalten), Undo/Redo korrekt, Instrument-Spur bleibt blockiert.

## v0.0.20.516 — Cross-Track Device Drag&Drop / Bitwig-Style (2026-03-16)

- `pydaw/ui/device_panel.py`:
  - **`_DeviceCard.__init__()`**: 3 neue Parameter: `plugin_type_id`, `plugin_name`, `source_track_id` fuer Cross-Track-Drag-Metadaten. Abwaertskompatibel (alle defaults="").
  - **`_DeviceCard.mouseMoveEvent()`**: Drag-Payload erweitert um `plugin_id`, `name`, `source_track_id`. Drag-Action erlaubt jetzt `MoveAction | CopyAction` statt nur `MoveAction`.
  - **Note-FX Card Creation**: Setzt jetzt `plugin_type_id`, `plugin_name`, `source_track_id` aus dem Device-Dict.
  - **Audio-FX Card Creation**: Ebenso erweitert.
  - **SF2-Instrument-Card**: Bekommt `fx_kind="instrument"`, `device_id=tid`, `plugin_type_id="sf2"`, `source_track_id=tid` — damit erstmals draggbar!
  - **Plugin-Instrument-Card**: Bekommt `fx_kind="instrument"`, `device_id=tid`, `plugin_type_id=plugin_id`, `source_track_id=tid` — erstmals draggbar!
  - Internes Reorder innerhalb derselben Chain bleibt komplett unveraendert (selber `_INTERNAL_MIME` Pfad).
- `pydaw/ui/main_window.py`:
  - **`_smartdrop_remove_from_source()`**: Neue zentrale Helper-Methode. Entfernt nach erfolgreichem Cross-Track-Move das Device von der Quellspur. Kennt instrument, audio_fx, note_fx. Safe: bei Fehler bleibt das Device auf beiden Spuren.
  - **`_on_arranger_smartdrop_instrument_to_track()`**: Erkennt jetzt `source_track_id` im Payload. Bei Cross-Track: Insert auf Ziel + `_smartdrop_remove_from_source()` auf Quellspur. Undo-Label angepasst.
  - **`_on_arranger_smartdrop_fx_to_track()`**: Ebenso erweitert fuer Note-FX und Audio-FX Cross-Track-Moves.
  - **`_on_arranger_smartdrop_instrument_morph_guard()`**: Bei Cross-Track-Morph (Instrument auf leere Audio-Spur) wird nach erfolgreichem Morph + Insert auch `_smartdrop_remove_from_source()` aufgerufen.
- Alle bestehenden Pfade (Browser-Drop, internes Device-Reorder, SmartDrop-Guard fuer belegte Spuren) bleiben exakt unveraendert.
- **BITWIG-PARITÄT erreicht fuer:** Device-Move zwischen Tracks per Drag&Drop (Instrument, Audio-FX, Note-FX).

## v0.0.20.515 — SmartDrop: Erster ECHTER atomarer Live-Pfad fuer leere Audio-Spur (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`:
  - **`_build_shadow_commit_rehearsal()`**: Neue Funktion simuliert den kompletten Undo-Zyklus read-only: deepcopy des Projekts, track.kind-Aenderung auf der Kopie, `ProjectSnapshotEditCommand` mit do()/undo() gegen lokalen Recorder, Round-Trip-Verifikation. Beruehrt das Live-Projekt nie.
  - **`apply_audio_to_instrument_morph_plan()`**: Fuehrt jetzt bei `apply_mode="minimal_empty_audio"` + `can_apply=True` die ECHTE atomare Mutation durch: Before-Snapshot → `set_track_kind("instrument")` → After-Snapshot → Undo-Push. Bei Fehlern sofortiger Rollback per Snapshot-Restore.
  - **`build_audio_to_instrument_morph_plan()`**: Setzt `can_apply=True` und `apply_mode="minimal_empty_audio"` wenn: track_kind==audio, keine Clips, keine FX, keine Note-FX, Shadow-Rehearsal bestanden.
  - **`validate_audio_to_instrument_morph_plan()`**: Bewahrt `can_apply=True` fuer den Minimalfall (vorher wurde can_apply immer auf False gesetzt).
  - **Apply-Readiness**: 3 neue dynamische Checks: `shadow_commit_rehearsal`, `routing_atomic`, `undo_commit` kippen auf `ready` wenn der Minimalfall vorliegt.
- `pydaw/ui/main_window.py`:
  - **`_on_arranger_smartdrop_instrument_morph_guard()`**: Fuehrt nach erfolgreichem Morph (`ok=True, applied=True`) die Instrument-Einfuegung via `device_panel.add_instrument_to_track()` durch, selektiert die Spur, oeffnet das DevicePanel und emittiert UI-Refresh-Signale.
- Guard blockiert weiterhin ALLE nicht-leeren Audio-Spuren (Clips/FX/Note-FX vorhanden → can_apply=False).
- Undo/Redo funktioniert: Die gesamte Aenderung wird als ein einziger Undo-Punkt gekapselt (Ctrl+Z stellt den Audio-Spur-Zustand komplett wieder her).
- **ERSTER ECHTER MUTIERENDER SMARTDROP-PFAD in der gesamten Projektgeschichte!**

## v0.0.20.514 — SmartDrop: read-only Dry-Command-Executor / do()-undo()-Simulations-Harness (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Hinter der bestehenden read-only Preview-Command-Konstruktion haengt jetzt ein eigener `runtime_snapshot_dry_command_executor` / `runtime_snapshot_dry_command_executor_summary`-Block. Er koppelt den spaeteren Minimalfall der leeren Audio-Spur read-only an eine echte `do()`-/`undo()`-Simulation mit Recorder-Callback, Callback-Trace und Payload-Wiederverwendung.
- `pydaw/services/project_service.py`: Der `ProjectService` exponiert jetzt den sicheren read-only Owner-Deskriptor `preview_audio_to_instrument_morph_dry_command_executor`, der `ProjectSnapshotEditCommand.do()/undo()` nur gegen einen lokalen In-Memory-Recorder laufen laesst und weder Live-Projekt noch Undo-Stack anfasst.
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt jetzt den neuen Block **Read-only Dry-Command-Executor / do()-undo()-Simulations-Harness** inklusive do/undo-Zaehlern, Callback-Trace, Callback-Digests und einzelnen Simulations-Schritten sichtbar an; Preview-/Statuslabel und Apply-Readiness fuehren die neue Schicht ebenfalls mit.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** echter Commit, **kein** Undo-Push, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.513 — SmartDrop: read-only Preview-Command-Konstruktion (`ProjectSnapshotEditCommand(before=..., after=..., ...)`) (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Hinter der vorhandenen read-only Before-/After-Snapshot-Command-Factory haengt jetzt ein eigener `runtime_snapshot_preview_command_construction` / `runtime_snapshot_preview_command_construction_summary`-Block. Er koppelt den spaeteren Minimalfall der leeren Audio-Spur read-only an die echte Constructor-Form von `ProjectSnapshotEditCommand`, die Callback-Bindung sowie die Feldliste der Dataclass.
- `pydaw/services/project_service.py`: Der `ProjectService` exponiert jetzt den sicheren read-only Owner-Deskriptor `preview_audio_to_instrument_morph_preview_snapshot_command`, der `ProjectSnapshotEditCommand(before=..., after=..., label=..., apply_snapshot=...)` nur in-memory konstruiert, aber weder `do()` noch `undo()` ausfuehrt.
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt jetzt den neuen Block **Read-only Preview-Command-Konstruktion** inklusive Constructor-Form, Callback, Feldliste, Payload-Digests und einzelnen Preview-Schritten sichtbar an; Preview-/Statuslabel und Apply-Readiness fuehren die neue Schicht ebenfalls mit.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Commit, **kein** Undo-Push, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.512 — SmartDrop: read-only Before-/After-Snapshot-Command-Factory / materialisierte Payloads (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Hinter der vorhandenen read-only `ProjectSnapshotEditCommand`-/Undo-Huelle haengt jetzt ein eigener `runtime_snapshot_command_factory_payloads` / `runtime_snapshot_command_factory_payload_summary`-Block. Er koppelt den spaeteren Minimalfall der leeren Audio-Spur read-only an eine explizite Before-/After-Snapshot-Factory, materialisierte Payload-Metadaten, Restore-Callback und Payload-Paritaet.
- `pydaw/services/project_service.py`: Der `ProjectService` exponiert jetzt den sicheren read-only Owner-Deskriptor `preview_audio_to_instrument_morph_before_after_snapshot_command_factory`, der Before-/After-Snapshot-Payloads nur in-memory materialisiert und daraus Digests, Byte-Groessen und Top-Level-Key-Metadaten ableitet.
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt jetzt den neuen Block **Read-only Before-/After-Snapshot-Command-Factory** inklusive Payload-Zusammenfassung, Digests, Byte-Groessen, Delta-Kind und einzelnen Factory-Schritten sichtbar an; Preview-/Statuslabel und Apply-Readiness fuehren die neue Schicht ebenfalls mit.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Commit, **kein** Routing-Umbau, **kein** Undo-Push und **keine** Projektmutation.

## v0.0.20.511 — SmartDrop: read-only ProjectSnapshotEditCommand / Undo-Huelle (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Hinter Mutation-Gate und Transaction-Capsule haengt jetzt ein eigener `runtime_snapshot_command_undo_shell` / `runtime_snapshot_command_undo_shell_summary`-Block. Er koppelt den spaeteren Minimalfall der leeren Audio-Spur read-only an `ProjectSnapshotEditCommand`, eine explizite Command-/Undo-Huelle, Projekt-Snapshot-Capture/Restore sowie Undo-Stack-Push.
- `pydaw/services/project_service.py`: Der `ProjectService` exponiert jetzt sichere read-only Owner-Deskriptoren fuer `ProjectSnapshotEditCommand` und die spaetere Command-/Undo-Huelle (`preview_audio_to_instrument_morph_project_snapshot_edit_command`, `preview_audio_to_instrument_morph_command_undo_shell`).
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt jetzt den neuen Block **Read-only ProjectSnapshotEditCommand / Undo-Huelle** inklusive Huelle-Sequenz und Einzelstatus sichtbar an; Preview-/Statuslabel und Apply-Readiness fuehren die neue Schicht ebenfalls mit.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Commit, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.510 — SmartDrop: read-only Mutation-Gate / Transaction-Capsule (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Hinter den read-only atomaren Entry-Points haengt jetzt ein eigener `runtime_snapshot_mutation_gate_capsule` / `runtime_snapshot_mutation_gate_capsule_summary`-Block. Er koppelt den spaeteren Minimalfall der leeren Audio-Spur read-only an explizites Mutation-Gate, Transaction-Capsule, Projekt-Snapshot-Capture/Restore sowie Kapsel-Commit-/Rollback-Stubs.
- `pydaw/services/project_service.py`: Der `ProjectService` exponiert jetzt sichere read-only Owner-Deskriptoren fuer Mutation-Gate und Transaction-Capsule (`preview_audio_to_instrument_morph_mutation_gate`, `preview_audio_to_instrument_morph_transaction_capsule`, `preview_audio_to_instrument_morph_capsule_commit`, `preview_audio_to_instrument_morph_capsule_rollback`).
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt jetzt den neuen Block **Read-only Mutation-Gate / Transaction-Capsule** inklusive Kapsel-Sequenz und Einzelstatus sichtbar an; Preview-/Statuslabel und Apply-Readiness fuehren die neue Schicht ebenfalls mit.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Commit, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.509 — SmartDrop: read-only atomare Commit-/Undo-/Routing-Entry-Points (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Hinter dem read-only Pre-Commit-Vertrag haengt jetzt ein eigener `runtime_snapshot_atomic_entrypoints` / `runtime_snapshot_atomic_entrypoints_summary`-Block. Er koppelt den spaeteren Minimalfall der leeren Audio-Spur read-only an reale Owner-/Service-Entry-Points (`preview_audio_to_instrument_morph`, `validate_audio_to_instrument_morph`, `apply_audio_to_instrument_morph`, `set_track_kind`, `undo_stack.push`) sowie an Routing-/Undo-/Track-Kind-Snapshot-Entry-Points.
- `pydaw/services/project_service.py`: Die Preview-/Validate-Pfade uebergeben jetzt den echten `ProjectService` als Runtime-Owner in den Guard-Builder, sodass die neue Entry-Point-Kopplung im Hauptpfad wirklich an realen Service-Methoden aufgeloest wird.
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt jetzt den neuen Block **Read-only atomare Commit-/Undo-/Routing-Entry-Points** inklusive Owner, Dispatch-Sequenz und einzelnen Entry-Point-Statuszeilen sichtbar an.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Commit, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.508 — SmartDrop: Leere Audio-Spur read-only Pre-Commit-Vertrag (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Hinter der vorhandenen Minimalfall-Vorqualifizierung haengt jetzt ein eigener read-only `runtime_snapshot_precommit_contract` / `runtime_snapshot_precommit_contract_summary`. Der neue Vertrag beschreibt Undo-, Routing-, Track-Kind- und Instrument-Commit-Sequenz fuer die spaetere leere Audio-Spur, bleibt aber vollstaendig preview-only.
- `pydaw/services/smartdrop_morph_guard.py`: Die Apply-Readiness fuehrt jetzt einen eigenen Check **Leere Audio-Spur: read-only Pre-Commit-Vertrag vorbereitet** und trennt damit die neue Vorschau-Ebene sauber von echter Routing-/Undo-Mutation.
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt jetzt den neuen Block **Leere Audio-Spur: read-only Pre-Commit-Vertrag** inklusive Commit-/Rollback-Sequenz, Mutation-Gate und Preview-Phasen sichtbar an.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Commit, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.507 — SmartDrop: Erster spaeterer Minimalfall (leere Audio-Spur) read-only vorqualifiziert (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Der Morphing-Guard fuehrt jetzt `first_minimal_case_report` / `first_minimal_case_summary` ein. Damit wird eine leere Audio-Spur erstmals explizit als spaeterer erster echter Freigabefall read-only erkannt, ohne Commit, Routing-Umbau oder Projektmutation.
- `pydaw/services/smartdrop_morph_guard.py`: Preview-Label, Status-Text und Apply-Preview unterscheiden jetzt gezielt zwischen leerer Audio-Spur (Minimalfall vorbereitet) und Audio-Spur mit Clips/FX (weiter klar blockiert).
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt jetzt einen eigenen Block **Erster spaeterer Minimalfall (leere Audio-Spur)** mit Scope, offenen Punkten sowie Bundle-/Apply-Runner-/Dry-Run-Vorqualifizierung.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau, **kein** Commit und **keine** Projektmutation.

## v0.0.20.506 — SmartDrop: Read-only Snapshot-Transaktions-Dispatch / Apply-Runner (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Hinter den vorhandenen Runtime-State-Registry-Backend-Adaptern haengt jetzt ein eigener, read-only `runtime_snapshot_apply_runner` / `runtime_snapshot_apply_runner_summary`. Der neue Runner dispatcht Snapshot-Adapter, Backend-Store-Adapter und Registry-Slot-Backends als eigene Preview-Phase hinter dem Snapshot-Bundle.
- `pydaw/services/smartdrop_morph_guard.py`: Die Apply-Readiness fuehrt jetzt einen separaten Check fuer den neuen Snapshot-Transaktions-Dispatch / Apply-Runner. Zusaetzlich gibt es eigene Dispatch-Summaries fuer `backend_store_adapter_calls` und `registry_slot_backend_calls`.
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt jetzt den neuen Block **Read-only Snapshot-Transaktions-Dispatch / Apply-Runner** inklusive Apply-/Restore-/Rollback-Sequenz, Dispatch-Summaries und Beispiel-Phasen sichtbar an.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau, **kein** Commit und **keine** Projektmutation.

## v0.0.20.505 — SmartDrop: Runtime-State-Registry-Backend-Adapter / Backend-Store-Adapter / Registry-Slot-Backends (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Die vorhandenen Runtime-State-Registry-Backends werden jetzt an konkrete, read-only `runtime_snapshot_state_registry_backend_adapters` / `runtime_snapshot_state_registry_backend_adapter_summary` gekoppelt. Jeder Adapter-Eintrag traegt stabilen `adapter_key`, `backend_store_adapter_key` und `registry_slot_backend_key`.
- Der read-only Dry-Run fuehrt jetzt zusaetzlich `state_registry_backend_adapter_calls` / `state_registry_backend_adapter_summary` und nutzt die neuen `capture_adapter_preview()` / `restore_adapter_preview()` / `rollback_adapter_preview()`-Pfade direkt.
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt jetzt die neue Ebene **Runtime-State-Registry-Backend-Adapter / Backend-Store-Adapter / Registry-Slot-Backends** sichtbar an und fuehrt die neuen Adapter-Dispatch-Infos im Dry-Run-Block mit auf.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.504 — SmartDrop: Runtime-State-Registry-Backends / Handle-Register / Registry-Slots (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Die bestehenden Runtime-State-Registries werden jetzt an konkrete, read-only `runtime_snapshot_state_registry_backends` / `runtime_snapshot_state_registry_backend_summary` gekoppelt. Jeder Backend-Eintrag traegt `backend_key`, `backend_class`, `handle_register_key`, `handle_register_class`, `registry_slot_key` und `registry_slot_class`.
- `pydaw/services/smartdrop_morph_guard.py`: Der read-only Dry-Run fuehrt jetzt zusaetzlich `state_registry_backend_calls` / `state_registry_backend_summary` und nutzt die neuen `capture_backend_preview()` / `restore_backend_preview()` / `rollback_backend_preview()`-Pfade direkt.
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt die neue Ebene jetzt sichtbar an und fuehrt die neuen Backend-Dispatch-Infos im Dry-Run-Block mit auf.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.502 — SmartDrop: Runtime-State-Stores / Capture-Handles (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Die vorhandenen Runtime-State-Slots werden jetzt an konkrete, read-only `runtime_snapshot_state_stores` / `runtime_snapshot_state_store_summary` gekoppelt. Jeder Store traegt eigenen `store_key`, Store-Klasse sowie `capture_handle_key` / `restore_handle_key` / `rollback_handle_key`.
- `pydaw/services/smartdrop_morph_guard.py`: Der read-only Dry-Run fuehrt jetzt zusaetzlich `state_store_calls` / `state_store_summary` und nutzt die neuen `capture_store_preview()` / `restore_store_preview()` / `rollback_store_preview()`-Pfade direkt.
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt jetzt sowohl die bisherige **Runtime-State-Slot**-Ebene als auch die neue **Runtime-State-Stores / Capture-Handles**-Ebene sichtbar an; der Dry-Run-Block fuehrt die neuen Store-Dispatch-Infos ebenfalls mit auf.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.500 — SmartDrop: Separate Runtime-State-Halter (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Die bestehenden separaten Runtime-State-Container werden jetzt an konkrete, read-only `runtime_snapshot_state_holders` / `runtime_snapshot_state_holder_summary` gekoppelt. Jeder Halter traegt eigenen `holder_key`, Holder-Klasse, Holder-Payload und Holder-Digest.
- `pydaw/services/smartdrop_morph_guard.py`: Der read-only Dry-Run fuehrt jetzt zusaetzlich `state_holder_calls` / `state_holder_summary` und ruft `capture_holder_preview()` / `restore_holder_preview()` / `rollback_holder_preview()` ueber die neuen Halter auf.
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt die neue Ebene jetzt als **Separate Runtime-State-Halter** an und fuehrt die neuen Holder-Dispatch-Infos im Dry-Run-Block mit auf.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.499 — SmartDrop: Separate Runtime-State-Container (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Die bestehenden Runtime-Zustandstraeger werden jetzt an konkrete, read-only `runtime_snapshot_state_containers` / `runtime_snapshot_state_container_summary` gekoppelt. Jeder Container traegt eigenen `container_key`, Container-Klasse, Payload-Digest und separate Capture-/Restore-/Rollback-Container-Previews.
- `pydaw/services/smartdrop_morph_guard.py`: Der read-only Dry-Run fuehrt jetzt zusaetzlich `state_container_calls` / `state_container_summary` und nutzt die Container-Previews direkt, weiterhin ohne Commit oder Projektmutation.
- `pydaw/ui/main_window.py`: Der zentrale Guard-Dialog zeigt die neue Ebene jetzt als **Separate Runtime-State-Container** an und fuehrt die neuen Container-Dispatch-Infos im Dry-Run-Block mit auf.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.497 — SmartDrop: Runtime-Stubs / Klassenkopplung (2026-03-16)

- Die vorbereiteten Runtime-Snapshot-Objektbindungen werden jetzt an konkrete read-only Runtime-Stub-Klassen gekoppelt (`runtime_snapshot_stubs`, `runtime_snapshot_stub_summary`).
- Der Safe-Runner instanziiert diese Stub-Klassen und laesst Capture-/Restore-/Rollback-Previews ueber `capture_preview()` / `restore_preview()` / `rollback_preview()` laufen.
- `pydaw/ui/main_window.py` zeigt die neue Ebene im zentralen Morphing-Guard-Dialog sichtbar an.
- Safety first: weiterhin kein echtes Audio->Instrument-Morphing, kein Routing-Umbau und keine Projektmutation.

## v0.0.20.494 — SmartDrop: Morphing-Guard mit Snapshot-Bundle / Transaktions-Container (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Der Morphing-Guard-Plan liefert jetzt zusaetzlich `runtime_snapshot_bundle` und `runtime_snapshot_bundle_summary`; die vorhandenen Runtime-Snapshot-Objektbindungen werden damit in einen stabilen, read-only Transaktions-Container mit `bundle_key`, `commit_stub`, `rollback_stub`, Capture-/Restore-Methoden und Rollback-Slots zusammengefuehrt.
- `pydaw/ui/main_window.py`: Der bestehende Guard-Dialog zeigt diese Struktur jetzt als **Snapshot-Bundle / Transaktions-Container** an und meldet die neue Bundle-Ebene bereits im Infotext.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.493 — SmartDrop: Morphing-Guard mit Runtime-Snapshot-Objekt-Bindung (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Der Morphing-Guard-Plan liefert jetzt zusaetzlich `runtime_snapshot_objects` und `runtime_snapshot_object_summary`; die bisherigen Snapshot-Instanzen werden damit an konkrete, read-only Snapshot-Objektbindungen mit `snapshot_object_key`, Objektklasse sowie Capture-/Restore-Methoden gekoppelt.
- `pydaw/ui/main_window.py`: Der bestehende Guard-Dialog zeigt diese Struktur jetzt als **Runtime-Snapshot-Objekt-Bindung** an und meldet die neue Objekt-Ebene bereits im Infotext.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.492 — SmartDrop: Morphing-Guard mit Runtime-Snapshot-Instanz-Vorschau (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Der Morphing-Guard-Plan liefert jetzt zusaetzlich `runtime_snapshot_instances` und `runtime_snapshot_instance_summary`; die vorhandenen Capture-Objekte werden damit in konkrete, read-only Snapshot-Instanzen mit stabilem `snapshot_instance_key`, Payload und `payload_digest` materialisiert.
- `pydaw/ui/main_window.py`: Der bestehende Guard-Dialog zeigt diese Struktur jetzt als **Runtime-Snapshot-Instanz-Vorschau** an und meldet die neue Instanz-Ebene bereits im Infotext.
- `pydaw/services/project_service.py`: Kleiner Safety-Hotfix — die zentralen Guard-Funktionen werden jetzt explizit importiert, damit Preview/Validate/Apply nicht an fehlenden Symbolen scheitern.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation.

## v0.0.20.491 — SmartDrop: Morphing-Guard mit Runtime-Capture-Objekt-Vorschau (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Der Morphing-Guard-Plan liefert jetzt zusaetzlich `runtime_snapshot_captures` und `runtime_snapshot_capture_summary`; die bisherigen Runtime-Handles werden damit in konkrete, read-only Capture-Objekt-Deskriptoren mit Payload-Vorschau ueberfuehrt.
- `pydaw/ui/main_window.py`: Der bestehende Guard-Dialog zeigt diese Struktur jetzt als **Runtime-Capture-Objekt-Vorschau** an und meldet die vorbereitete Capture-Ebene bereits im Infotext.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation; der Schritt bleibt reine Snapshot-/Capture-Vorschau.

## v0.0.20.489 — SmartDrop: Morphing-Guard mit Runtime-Snapshot-Vorschau (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Der Morphing-Guard-Plan liefert jetzt zusaetzlich `runtime_snapshot_preview` und `runtime_snapshot_summary`; die bestehenden Snapshot-Referenzen werden erstmals direkt gegen den aktuellen Track-/Clip-/Chain-Zustand aufgeloest, weiterhin komplett read-only.
- `pydaw/ui/main_window.py`: Der bestehende Guard-Dialog zeigt diese Struktur jetzt zusaetzlich als **Aktuelle Runtime-Snapshot-Vorschau** an und meldet die aktuelle Aufloesbarkeit bereits im Infotext.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation; der Schritt bleibt reine Laufzeit-Vorschau.

## v0.0.20.488 — SmartDrop: Morphing-Guard mit Apply-Readiness-Checkliste (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Der Morphing-Guard-Plan liefert jetzt zusaetzlich `readiness_checks` und `readiness_summary`, damit die spaetere echte Apply-Phase auf einer zentralen Sicherheitsmatrix fuer Snapshot-/Routing-/Undo-Bereitschaft aufbauen kann.
- `pydaw/ui/main_window.py`: Der bestehende Guard-Dialog zeigt diese Struktur jetzt zusaetzlich als **Apply-Readiness-Checkliste** an und meldet die zusammengefasste Bereitschaft bereits im Infotext.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation; der Schritt bleibt reine Vorschau.

## v0.0.20.487 — SmartDrop: Morphing-Guard mit Snapshot-Referenzvorschau (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py`: Der Morphing-Guard-Plan liefert jetzt zusaetzlich `snapshot_refs`, `snapshot_ref_map` und `snapshot_ref_summary`; die Referenzen werden deterministisch aus `transaction_key` und den bereits geplanten Snapshot-Namen aufgebaut.
- `pydaw/ui/main_window.py`: Der bestehende Guard-Dialog zeigt diese Struktur jetzt zusaetzlich als **Geplante Snapshot-Referenzen** an und meldet die vorbereitete Referenzanzahl bereits im Infotext.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation; der Schritt bleibt reine Vorschau.

## v0.0.20.486 — SmartDrop: Morphing-Guard mit atomarer Transaktionsvorschau (2026-03-15)

- `pydaw/services/smartdrop_morph_guard.py`: Der Morphing-Guard-Plan liefert jetzt zusaetzlich `required_snapshots`, `transaction_steps`, `transaction_key` und `transaction_summary`, damit die spaetere echte Apply-Phase auf einer klaren atomaren Vorschau aufbauen kann.
- `pydaw/ui/main_window.py`: Der bestehende Guard-Dialog zeigt diese Struktur jetzt zusaetzlich als **Noetige Snapshots** und **Geplanter atomarer Ablauf** an.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation; der Schritt bleibt reine Vorschau.

## v0.0.20.485 — SmartDrop: Guard-Dialog mit Risiko-/Rueckbau-Zusammenfassung (2026-03-15)

- `pydaw/services/smartdrop_morph_guard.py`: Der Morphing-Guard-Plan liefert jetzt zusaetzlich `impact_summary`, `rollback_lines` und `future_apply_steps`, damit die spaetere echte Apply-Phase bereits auf einer klareren Sicherheitsstruktur aufbauen kann.
- `pydaw/ui/main_window.py`: Der bestehende Guard-Dialog zeigt diese Struktur jetzt getrennt als **Risiken / Blocker**, **Rueckbau vor echter Freigabe** und **Spaetere atomare Apply-Phase** an.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation; der Schritt bleibt reine Sicherheitsvorschau.

## v0.0.20.484 — SmartDrop: Guard-Dialog auf spätere Apply-Phase vorbereitet (2026-03-15)

- `pydaw/ui/main_window.py`: Der Morphing-Guard-Dialog liefert jetzt ein kleines Ergebnisobjekt (`shown / accepted / can_apply / requires_confirmation`) statt nur `True/False`.
- `pydaw/ui/main_window.py`: Dieselbe Dialog-Stelle ist bereits fuer die spaetere echte Bestaetigung vorbereitet; falls `can_apply` spaeter freigeschaltet wird, kann der Dialog schon jetzt zwischen `Morphing bestaetigen` und `Abbrechen` unterscheiden.
- `pydaw/ui/main_window.py`: Der zentrale Guard-Handler respektiert diese spaetere Struktur bereits, bleibt aktuell aber bewusst nicht-mutierend, weil `can_apply` weiterhin `False` bleibt.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau, **keine** Projektmutation.

## v0.0.20.483 — SmartDrop: Guard-Dialog aus Morphing-Plan (2026-03-15)

- `pydaw/ui/main_window.py`: Geblockte `Instrument -> Audio-Spur`-Drops oeffnen jetzt optional einen read-only Sicherheitsdialog, wenn der Morphing-Guard `requires_confirmation` meldet.
- `pydaw/ui/main_window.py`: Der Dialog zeigt direkt Daten aus dem bestehenden Guard-Plan (`blocked_message`, `summary`, `blocked_reasons`) und bleibt damit konsistent mit Preview/Validate/Apply.
- Safety first: weiterhin **kein** echtes Audio->Instrument-Morphing, **kein** Routing-Umbau, **keine** Projektmutation; der Dialog ist nur eine Sicherheitsvorschau.

## v0.0.20.482 — SmartDrop: Morphing-Guard-Command vorbereitet (2026-03-15)

- `pydaw/services/smartdrop_morph_guard.py`: Neues zentrales Guard-Modul für künftiges **Audio→Instrument-Morphing** mit gemeinsamem `preview / validate / apply`-Schema; in dieser Phase bewusst noch **nicht mutierend**.
- `pydaw/services/project_service.py`: Neue Wrapper `preview_audio_to_instrument_morph(...)`, `validate_audio_to_instrument_morph(...)` und `apply_audio_to_instrument_morph(...)` bündeln den Guard jetzt service-seitig für spätere echte Undo-/Routing-Schritte.
- `pydaw/ui/main_window.py`: MainWindow besitzt jetzt einen eigenen Guard-Einstiegspunkt für geblockte Instrument→Audio-Drops und ruft dafür bereits denselben zukünftigen Apply-Hook auf — aktuell absichtlich nur als blockierte Stub-Anwendung.
- `pydaw/ui/arranger_canvas.py` + `pydaw/ui/arranger.py`: Geblockte Instrument→Audio-Drops werden nicht mehr nur lokal kommentiert, sondern an den neuen zentralen Morphing-Guard weitergereicht.
- `pydaw/ui/smartdrop_rules.py`: Die Audio-Spur-Preview nutzt jetzt denselben Guard-Plan wie ProjectService/MainWindow, damit Summary/Blocked-Message nicht mehr doppelt auseinanderlaufen.
- Safety first: weiterhin **kein** echtes Audio→Instrument-Morphing, **kein** Routing-Umbau, **keine** Projektmutation in der neuen Guard-Apply-Stelle.


## v0.0.20.481 — SmartDrop: Zentrale Morphing-Vorprüfung + Block-Hinweis (2026-03-15)

- `pydaw/ui/smartdrop_rules.py`: Neues zentrales Regelmodul bewertet Plugin-Drop-Ziele gemeinsam für ArrangerCanvas und linke TrackList; inklusive Audio-/MIDI-Clip-Zählung und FX-Ketten-Summary pro Zielspur.
- `pydaw/ui/arranger_canvas.py`: Canvas nutzt jetzt dieselbe Zielbewertung wie die TrackList und zeigt bei Instrument→Audio-Spur eine aussagekräftigere Preview; geblockte Ziele melden beim echten Drop aktiv den Sperrgrund über die Statusleiste.
- `pydaw/ui/arranger.py`: Die linke TrackList verwendet dieselbe zentrale Zielbewertung und meldet geblockte SmartDrop-Versuche jetzt ebenfalls explizit statt still zu ignorieren.
- Safety first: weiterhin **kein** echtes Audio→Instrument-Morphing, **kein** Routing-Umbau und **keine** Projektmutation auf bewusst gesperrten Zielen.

## v0.0.20.480 — SmartDrop: Kompatible FX-Ziele (2026-03-15)

- `pydaw/ui/arranger.py`: Die linke Arranger-TrackList kennt jetzt echte kompatible FX-Ziele und emittiert bei `Note-FX`/`Audio-FX` auf passenden bestehenden Spuren einen zentralen SmartDrop-Request statt nur Preview.
- `pydaw/ui/arranger_canvas.py`: Der ArrangerCanvas behandelt kompatible bestehende FX-Ziele jetzt ebenfalls als echte Drops; `Note-FX` werden nur auf Instrument-Spuren, `Audio-FX` nur auf kompatiblen bestehenden Spuren angenommen.
- `pydaw/ui/main_window.py`: Neues zentrales Handling für FX-SmartDrop nutzt die vorhandenen sicheren DevicePanel-Pfade (`add_note_fx_to_track` / `add_audio_fx_to_track`), selektiert danach die Zielspur und fokussiert das DevicePanel.
- Safety first: weiterhin **kein** Audio→MIDI-Morphing, **kein** Routing-Umbau und **keine** Erweiterung auf inkompatible Ziele.

## v0.0.20.479 — SmartDrop auf bestehende Instrument-Spur (2026-03-15)

- `pydaw/ui/arranger_canvas.py`: Instrument-Drops auf **bestehende Instrument-Spuren** werden jetzt im Canvas wirklich angenommen; Audio-Spuren bleiben bewusst Preview-only.
- `pydaw/ui/arranger.py`: Die linke Arranger-TrackList akzeptiert denselben echten Instrument-Drop ebenfalls und meldet ihn zentral weiter.
- `pydaw/ui/main_window.py`: MainWindow führt den SmartDrop auf bestehende Instrument-Spuren über die vorhandenen DevicePanel-Pfade aus und selektiert danach die Zielspur.
- UX-Härtung: Tooltip-/Status-Texte unterscheiden jetzt sauber zwischen **echter Aktion** (`Instrument → Einfügen auf ...`) und reiner Preview.
- Safety first: weiterhin **kein** Audio→MIDI-Morphing, **kein** SmartDrop auf Audio-Spuren und **kein** Routing-Umbau vorhandener Tracks.

## v0.0.20.478 — SmartDrop: Neue Instrument-Spur aus Leerraum-Drop (2026-03-15)

- `pydaw/ui/arranger_canvas.py`: Plugin-Drops im freien Arranger-Bereich **unterhalb der letzten Spur** werden jetzt erstmals wirklich ausgewertet — aber nur für **Instrumente**.
- `pydaw/ui/arranger_canvas.py`: Der Canvas emittiert dafür einen kleinen zentralen SmartDrop-Request statt selbst Tracks/Devices direkt umzubauen; bestehende Track-Drops bleiben damit getrennt und risikoarm.
- `pydaw/ui/main_window.py`: MainWindow legt bei diesem SmartDrop eine **neue Instrument-Spur** an, benennt sie nach dem Plugin und fügt das Instrument über die vorhandenen DevicePanel-Pfade ein.
- Safety first: weiterhin **kein** Spur-Morphing bestehender Tracks, **kein** echter SmartDrop auf bestehende Spuren, **kein** Routing-Umbau vorhandener Audio-Spuren.

## v0.0.20.477 — TrackList Preview-Hinweis Parität (2026-03-15)

- `pydaw/ui/arranger.py`: Die Arranger-TrackList zeigt beim Plugin-Hover jetzt denselben reinen Preview-Hinweis wie der ArrangerCanvas (`… · Nur Preview — SmartDrop folgt später`).
- `pydaw/ui/arranger.py`: Der Hinweis erscheint links ebenfalls als best-effort Tooltip in Cursor-Nähe und wird zusätzlich über die bestehende `status_message`-Leiste gemeldet.
- `pydaw/ui/arranger.py`: Beim Verlassen des Preview-Modus werden Tooltip/Hint sauber entfernt und der normale Standard-Tooltip der TrackList wiederhergestellt.
- Safety first: weiterhin **kein** echter Plugin-Drop in der TrackList, **keine** neue Spur, **kein** Spur-Morphing, **kein** Routing-/Undo-/Projektformat-Umbau.

## v0.0.20.476 — Arranger Preview-Hinweis am Cursor / in Statusleiste (2026-03-15)

- `pydaw/ui/arranger_canvas.py`: Plugin-Hover-Preview zeigt jetzt zusätzlich einen klaren Hinweis `… · Nur Preview — SmartDrop folgt später` an.
- `pydaw/ui/arranger_canvas.py`: Der Hinweis erscheint als best-effort Tooltip in Cursor-Nähe und wird parallel über die bestehende `status_message`-Leiste gemeldet.
- `pydaw/ui/arranger_canvas.py`: Beim Verlassen des Preview-Modus werden Tooltip/Hint sauber wieder entfernt.
- Safety first: weiterhin **kein** echter Plugin-Drop im Arranger, **keine** neue Spur, **kein** Spur-Morphing, **kein** Routing-/Undo-/Projektformat-Umbau.

## v0.0.20.475 — Arranger Leerraum-Preview unter letzter Spur (2026-03-15)

- `pydaw/ui/arranger_canvas.py`: Instrument-Drags zeigen jetzt im freien Bereich **unterhalb der letzten Spur** eine rein visuelle cyanfarbene Linie/Badge wie `Neue Instrument-Spur: …`.
- `pydaw/ui/arranger_canvas.py`: Track-Lane-Preview und Leerraum-Preview laufen jetzt über einen zentralen Parse/Clear/Update-Pfad (`_parse_plugin_drag_info`, `_update_plugin_drag_preview`, `_clear_plugin_drag_preview`).
- Safety first: weiterhin **kein** echter Plugin-Drop im Arranger, **keine** neue Spur, **kein** Spur-Morphing, **kein** Routing-/Undo-/Projektformat-Umbau.
- Kleiner Härtungseffekt: der ArrangerCanvas enthält keinen fehlerhaften Inline-Preview-Block im Konstruktor mehr; der Preview-Code lebt jetzt nur noch im Paint-/Helper-Pfad.

## v0.0.20.474 — Arranger/TrackList Plugin Hover Preview (2026-03-15)

- `pydaw/ui/arranger.py`: Die Arranger-TrackList wertet Plugin-Drag-Payloads jetzt **rein visuell** aus und markiert die Zielspur mit einem cyanfarbenen Hover-Rahmen.
- `pydaw/ui/arranger_canvas.py`: Der Arranger zeichnet jetzt beim Plugin-Hover ein cyanfarbenes Spur-Overlay mit Rollenhinweis für **Instrument**, **Effekt** oder **Note-FX**.
- Instrument-Hover auf einer Audio-Spur zeigt bewusst nur eine **Preview** („Morphing folgt später“) — also noch **kein** Spur-Umbau, **kein** Routing-Umbau und **kein** neues Drop-Verhalten.
- Risikoarm: bestehende Clip-/Datei-/Cross-Project-Drops bleiben unberührt; Plugin-Drops auf Track/Arranger werden in diesem Schritt weiterhin nur visuell behandelt.

## v0.0.20.473 — Plugins Browser Scope-Badge + Rollen-Metadaten (2026-03-15)

- `pydaw/ui/plugins_browser.py`: Plugins-Browser zeigt jetzt ebenfalls eine **trackbezogene Scope-Badge** im Header, analog zu Instruments / Effects / Favorites / Recents.
- `pydaw/ui/plugins_browser.py`: Externe Plugin-Payloads für **Add** und **Drag&Drop** tragen jetzt zusätzlich die erkannte Rolle **Instrument vs. Effekt** mit (`device_kind`, `__ext_is_instrument`).
- `pydaw/ui/device_browser.py`: Scope-Badge-Refresh berücksichtigt jetzt auch den Plugins-Tab.
- Risikoarm: bestehender Insert-/Drop-Pfad bleibt unverändert; kein Routing-Umbau, kein DSP-Eingriff, kein neues Projektformat.

## v0.0.20.472 — VST Header Main-Bus Hint (2026-03-15)

- `pydaw/ui/fx_device_widgets.py`: `Vst3AudioFxWidget` zeigt jetzt direkt unter dem Status eine kleine Main-Bus-Hinweiszeile wie `Main-Bus: 1→1`, `1→2` oder `2→2`.
- `pydaw/ui/fx_device_widgets.py`: Die Anzeige liest den Bus bevorzugt aus der bereits laufenden Runtime-Host-Instanz (FX oder Instrument) und bleibt dadurch rein UI-seitig — kein zweiter Plugin-Load, kein neuer Rebuild-Pfad.
- `pydaw/audio/vst3_host.py`: `Vst3Fx` und `Vst3InstrumentEngine` stellen dafür einen kleinen `get_main_bus_layout()`-Accessor bereit.
- Risikoarm: keine Änderung an DSP, Audio-Callback oder Routing; nur zusätzliche Diagnose-/Header-Information für externe pedalboard-VSTs.

## v0.0.20.471 — CLAP Instrument Engine Reuse Fix (Preset/Editor-Stabilität) (2026-03-15)

- `pydaw/audio/audio_engine.py`: Der Instrument-Reuse-Pfad behandelt CLAP-Referenzen jetzt korrekt als `bundle_path + plugin_id` statt sie fälschlich mit dem kompletten `path::plugin_id`-String gegen `engine.path` zu vergleichen.
- Ergebnis: bereits laufende CLAP-Instrument-Engines (z. B. Surge XT) werden bei normalen Rebuild-/Refresh-Zyklen wiederverwendet statt neu geladen.
- Risikoarm: kein Eingriff in DSP, kein Routing-Umbau, keine Änderung am Audio-Callback selbst — nur der Engine-Reuse-Check wurde korrigiert.

## v0.0.20.470 — CLAP GUI Async-IO Host Support (POSIX-FD + Timer) (2026-03-15)

- `pydaw/audio/clap_host.py`: Offizielle Host-Erweiterungen für `clap.posix-fd-support` und `clap.timer-support` ergänzt, inklusive ctypes-Structs, Host-Callbacks und pro Plugin gespeicherten FD-/Timer-Registrierungen.
- `pydaw/audio/clap_host.py`: `_ClapPlugin` liest nun optional `clap_plugin_posix_fd_support_t` und `clap_plugin_timer_support_t` aus und bietet `dispatch_gui_fd()` / `dispatch_gui_timer()` für den GUI-Pfad an.
- `pydaw/ui/fx_device_widgets.py`: `ClapAudioFxWidget` synchronisiert registrierte GUI-FDs mit `QSocketNotifier` und Timer mit `QTimer`, aber nur solange das CLAP-Editorfenster wirklich offen ist.
- `pydaw/ui/fx_device_widgets.py`: FD-/Timer-Events pumpen danach wieder gezielt den CLAP-Main-Thread und räumen alle Async-Quellen beim Editor-Schließen sauber weg.
- Risikoarm: keine Änderung an CLAP-DSP, Audio-Callback oder Routing; Fokus ausschließlich auf den nativen Editor-/GUI-Pfad.

## v0.0.20.469 — CLAP Editor Bootstrap Main-Thread Handshake + Low-Rate Keepalive (2026-03-15)

- `pydaw/audio/clap_host.py`: `_ClapPlugin.create_gui()` pumpt jetzt den CLAP-Main-Thread gezielt in drei Phasen (`create` → `set_parent` → `show`), statt erst nach dem kompletten GUI-Aufruf. Das reduziert das Risiko, dass ein Plugin seinen nativen Child asynchron zu spät initialisiert und nur ein leerer Host-Container sichtbar bleibt.
- `pydaw/audio/clap_host.py`: Best-Effort `set_scale(1.0)` ergänzt und Host-Version auf `0.0.20.469` angehoben.
- `pydaw/ui/fx_device_widgets.py`: Der CLAP-Editor-Pump stoppt bei offenem Editor nicht mehr vollständig, sondern läuft nach der Prime-Phase mit 120 ms als sehr leichter Keepalive weiter. Dadurch können spätere `request_callback()`-Signale des Plugins weiterhin abgearbeitet werden.
- Risikoarm: keine Änderung am Audio-Callback, kein Eingriff in CLAP-DSP/Parameter-Events, Änderungen ausschließlich im Editor-Lifecycle solange das Editorfenster offen ist.

## v0.0.20.468 — CLAP Editor Deferred-Mapping + GUI-Visibility/Resize-Handshake (2026-03-15)

- `pydaw/ui/fx_device_widgets.py`: `ClapAudioFxWidget` öffnet den nativen CLAP-Editor jetzt deferred erst nach `show()` + `processEvents()`; `create_gui()` läuft dadurch nicht mehr direkt im Button-Klick auf einem potentiell noch instabilen Child-Handle.
- `pydaw/ui/fx_device_widgets.py`: `_editor_gui_container` nutzt jetzt zusätzlich `WA_DontCreateNativeAncestors`; der Pump-Timer schaltet nach der Prime-Phase automatisch von 16 ms auf einen langsameren Takt zurück.
- `pydaw/ui/fx_device_widgets.py`: GUI-Requests aus dem Host (`request_resize`, `request_show`, `request_hide`) werden an das Qt-Fenster gespiegelt, inklusive optionalem `set_gui_size()` Rückruf an das Plugin.
- `pydaw/audio/clap_host.py`: `_ClapPlugin` merkt sich die letzte GUI-Größe und stellt `take_requested_gui_visibility()` sowie `set_gui_size()` bereit.
- Risikoarm: kein Eingriff in CLAP-DSP, keine Änderung am Audio-Callback, Fokus ausschließlich auf Editor-Lifecycle und GUI-Handshake.

## v0.0.20.467 — CLAP Live-Plugin-Cache + Find-Log-Drosselung (2026-03-15)

- `pydaw/ui/fx_device_widgets.py`: `ClapAudioFxWidget` ergänzt um `_live_plugin_cache`, `_invalidate_live_clap_plugin_cache()` und einen gedrosselten `_find_live_clap_plugin()`-Pfad mit optionalem `use_cache=False` Refresh.
- Editor-Pump und GUI-Check nutzen jetzt bevorzugt den Cache statt pro Timer-Tick erneut `_track_audio_fx_map` / `_vst_instrument_engines` zu durchsuchen.
- `[CLAP-FIND]`-Diagnosen werden nur noch einmal pro Statuswechsel geloggt, damit das Terminal beim offenen CLAP-Editor nicht vollgeschrieben wird.
- Risikoarm: keine Änderung am Audio-Callback, keine Änderung an DSP/CLAP-Events, nur Widget-seitiger Lookup-/Diagnose-Pfad.

## v0.0.20.466 — CLAP MIDI-Learn / Kontextmenü-Parität (2026-03-15)

- `pydaw/ui/fx_device_widgets.py`: `ClapAudioFxWidget` ergänzt um `_automation_params`, `_param_key()` sowie die gleiche `_install_automation_menu()` / `_register_automatable_param()`-Verdrahtung wie bei den externen VST-Widgets.
- CLAP-Slider/Spinbox/Label unterstützen jetzt ebenfalls per Rechtsklick: **Show Automation in Arranger**, **MIDI Learn**, **Reset to Default**.
- Performance-sicher: die Registrierung passiert nur dann, wenn eine CLAP-Zeile durch die Lazy-UI wirklich gebaut wurde; keine zusätzliche Vollmaterialisierung großer Plugins wie Surge XT.

## v0.0.20.464 — CLAP Editor Callback Pump + Lazy Parameter UI

#### 2026-03-15 — Surge-XT-Editor und CLAP-Parameter-UI gehärtet
**Task:** CLAP Editor bleibt leer + Spurwechsel mit großem CLAP zu langsam
**Developer:** OpenAI GPT-5.4 Thinking
**Änderungen:**
- `pydaw/audio/clap_host.py`
  - Pro Plugin-Instanz eigenes `clap_host_t` mit `host_data`-Cookie
  - Host-Callbacks (`request_callback`, `request_resize`, `request_show/hide`) werden dem owning `_ClapPlugin` zugeordnet
  - `pump_main_thread()` + `take_requested_gui_size()` ergänzt
- `pydaw/ui/fx_device_widgets.py`
  - CLAP-Widget lädt Parameter bevorzugt aus der laufenden Audio-Engine
  - Initial nur kleiner Parameter-Batch, weitere Rows per „Mehr Parameter laden“
  - Suchfeld kann gezielt zusätzliche Parameter aufbauen statt immer alle auf einmal zu rendern
  - Editor startet nach `create_gui()` einen kurzen Qt-Pump-Timer für CLAP `on_main_thread()` und übernimmt Resize-Wünsche
**Erfolg:** ✅ Kein Syntaxfehler, keine riskante Audio-Engine-Neuarchitektur, Fokus nur auf CLAP-Editor-Lifecycle und UI-Performance

---

## v0.0.20.463 — CLAP Editor Pin/Roll Fix (x11_set_above)

#### 2026-03-15 — CLAP Editor Custom-Titelleiste repariert
**Task:** CLAP Editor 📌 Pin + 🔺 Roll Fix
**Developer:** Claude Opus 4.6
**Änderungen:**
- Pin: `setWindowFlags()` → `x11_set_above()` (verhindert X11 Re-Parenting / GUI-Zerstörung)
- Roll: Originalgröße wird gespeichert/wiederhergestellt (kein sizeHint-Fallback)
- Tooltips zeigen Pin-Status an
**Dateien:** `pydaw/ui/fx_device_widgets.py`

---

## v0.0.20.457 — CLAP Plugin Hosting (First-Class-Citizen)

#### 2026-03-15 — CLAP Plugin-Standard komplett integriert
**Task:** CLAP Plugin Hosting als vollwertiges Plugin-Format
**Developer:** Claude Opus 4.6
**Dauer:** 1 Session

**Was gemacht:**
- [x] `pydaw/audio/clap_host.py` NEU — ~830 Zeilen, kompletter CLAP C-ABI Host via ctypes
- [x] `pydaw/services/plugin_scanner.py` — CLAP Suchpfade + scan_clap() + scan_all()
- [x] `pydaw/audio/fx_chain.py` — ext.clap: Branch (FX + Instrument)
- [x] `pydaw/ui/plugins_browser.py` — CLAP Tab mit Favoriten, Drag&Drop, Status
- [x] `pydaw/ui/device_panel.py` — CLAP Metadata-Normalisierung
- [x] `pydaw/ui/fx_device_widgets.py` — ClapAudioFxWidget + make_audio_fx_widget Branch
- [x] `pydaw/audio/audio_engine.py` — ClapInstrumentEngine in Phase 1/2/3

**Files:** pydaw/audio/clap_host.py (NEU), pydaw/services/plugin_scanner.py, pydaw/audio/fx_chain.py, pydaw/ui/plugins_browser.py, pydaw/ui/device_panel.py, pydaw/ui/fx_device_widgets.py, pydaw/audio/audio_engine.py
**Erfolg:** ✅ Alle 7 Dateien kompilieren fehlerfrei, nichts kaputt gemacht

## v0.0.20.444 — Detachable Panels + Bitwig-Style Multi-Monitor Layout System

- `pydaw/ui/screen_layout.py`: Neues Modul — `PanelId`, `DetachablePanel`, `_FloatingWindow`, `ScreenLayoutManager`, `LayoutPreset`, `PanelPlacement`, 8 vordefinierte `LAYOUT_PRESETS`.
- `pydaw/ui/main_window.py`: Import `screen_layout`; `_init_screen_layout_manager()` registriert Editor/Mixer/Device/Browser/Automation als DetachablePanel; `_populate_screen_layout_menu()` baut dynamisches Menü; `_apply_screen_layout()`, `_toggle_panel_detach()`, `_dock_all_panels()` Handler; `closeEvent` speichert Layout-State.

## v0.0.20.436 — Performance Fix: Automation Recording Audio-Stutter

- `pydaw/audio/automatable_parameter.py`: sort_points() entfernt, lane_data_changed auf 8 Hz throttled, _flush_cc_ui() Timer.
- `pydaw/services/midi_mapping_service.py`: sort entfernt, emit throttled, legacy store write deferred.

## v0.0.20.435 — Fix: Automation Playback dB→Linear RT-Store Overwrite

- `pydaw/audio/automatable_parameter.py`: `tick()` + `clear_automation_values()`: Guard `if not param._listeners` vor `_mirror_to_rt_store()`.

## v0.0.20.434 — Fix: CC→Automation für ALLE Plugin-Typen

- `pydaw/audio/automatable_parameter.py`: `_write_cc_automation()` akzeptiert jetzt `afx:`, `afxchain:`, `trk:` Prefixe.
- `pydaw/ui/fx_device_widgets.py`: Generic CC Re-Registration in `_install_automation_menu()`.

## v0.0.20.433 — CC→Automation Recording für MIDI Learn Fast Path + REC Button

- `pydaw/audio/automatable_parameter.py`: `set_transport()`, `set_project()`, `_write_cc_automation()` — Fast Path MIDI Learn schreibt jetzt Automation-Breakpoints bei write/touch/latch.
- `pydaw/services/container.py`: Transport + Project Referenzen an AutomationManager übergeben.
- `pydaw/ui/automation_editor.py`: ● REC Button mit Touch/Read Toggle + Mode-Sync.

## v0.0.20.432 — Multi-Lane Stacking + Touch/Latch Automation Modi

- `pydaw/ui/automation_editor.py`: `_LaneStrip` + Multi-Lane `EnhancedAutomationLanePanel` (bis zu 8 gleichzeitig).
- `pydaw/services/midi_mapping_service.py`: Touch/Latch Timer + `_should_write_automation()`.
- `pydaw/services/automation_playback.py`: Mode-Check erweitert: read + touch + latch.

## v0.0.20.429 — Bounce in Place: plugin_type Matching Fix (chrono-Prefix)

- `pydaw/services/project_service.py`: `plugin_type` Matching erweitert: `'sampler'` → `in ('sampler', 'chrono.pro_audio_sampler')`, `'drum_machine'` → `in ('drum_machine', 'chrono.pro_drum_machine')`, `'aeterna'` → `in ('aeterna', 'chrono.aeterna')`, plus `'chrono.bach_orgel'`.

## v0.0.20.428 — Bounce in Place: Best-Practice Fix (Borrow Running Engine)

- `pydaw/services/container.py`: `project._audio_engine_ref = audio_engine` — Brücke zur laufenden Audio-Engine.
- `pydaw/services/project_service.py`: `_track_has_vst_device()` — Prüft ob Track VST-Devices hat.
- `pydaw/services/project_service.py`: `_create_vst_instrument_engine_offline()` — Borgt ZUERST die laufende Engine (Best-Practice), Offline-Fallback nur wenn nötig.
- `pydaw/services/project_service.py`: `_render_track_subset_offline()` — Relaxierte kind-Prüfung + borrowed-Engine Handling.

## v0.0.20.427 — Bounce in Place: VST Offline Fix #2 (Warmup + Suspend/Resume)

- `pydaw/services/project_service.py`: VST2 Suspend/Resume Zyklus nach State-Restore (`effMainsChanged(0)→(1)→effStartProcess`).
- `pydaw/services/project_service.py`: 200ms Warmup-Phase nach Engine-Erstellung (Plugin-Initialisierung).
- `pydaw/services/project_service.py`: Relaxierte Instrument-Erkennung (Fallback: jedes ext.vst = Instrument wenn MIDI-Bounce).
- `pydaw/services/project_service.py`: Umfangreiche stderr-Diagnose-Logs für den gesamten Offline-Bounce-Pfad.
- `pydaw/services/project_service.py`: Exception-Logging statt stummes `except: pass`.

## v0.0.20.426 — Bounce in Place: VST2/VST3 Offline Rendering Fix

- `pydaw/services/project_service.py`: Neue Methode `_create_vst_instrument_engine_offline()` — erstellt temporäre VST2/VST3-Engine aus Track-FX-Chain für Offline-Bounce.
- `pydaw/services/project_service.py`: Neue Methode `_render_vst_notes_offline()` — rendert MIDI-Noten mit korrektem note_on/note_off-Scheduling + Release-Tail durch VST-Engine.
- `pydaw/services/project_service.py`: `_render_track_subset_offline()` hat jetzt VST-Instrument-Fallback wenn keine interne Engine (Sampler/Drum/Aeterna) verfügbar.
- Bounce in Place, Bounce + Mute, Bounce Dry funktionieren jetzt für VST2/VST3-Instrument-Tracks (Dexed, Helm, Surge XT, etc.).

## v0.0.20.373 — VST3 Widget Main-Thread Reload Hotfix

- `pydaw/ui/fx_device_widgets.py` importiert jetzt `QCheckBox`, sodass Bool-Parameter im externen VST3-Widget wieder sauber als Checkboxen aufgebaut werden können.
- Der bestehende Async-Fallback im `Vst3AudioFxWidget` bleibt erhalten, reagiert aber jetzt auf den Spezialfall `must be reloaded on the main thread` mit einem gezielten einmaligen Retry im Qt-Main-Thread.
- Fokus blieb bewusst auf einem kleinen Widget-/Fallback-Hotfix; Audio-Routing, Host-Core, Mixer und Projektformat wurden nicht angefasst.

## v0.0.20.372 — VST3 Widget Embedded-State Hint

- `Vst3AudioFxWidget` zeigt jetzt einen kleinen sichtbaren **Preset/State-Hinweis** direkt im Widget an.
- Das Widget erkennt projektseitig, ob für das aktuelle externe **VST2/VST3-Device** bereits ein eingebetteter `__ext_state_b64`-Blob vorhanden ist.
- Bei vorhandenem Blob wird ein kompakter Hinweis mit grober Größenanzeige angezeigt; ohne Blob erscheint defensiv ein klarer Hinweis, dass der State erst nach dem Speichern erzeugt wird.
- Umsetzung bleibt vollständig **UI-seitig** in `pydaw/ui/fx_device_widgets.py`; kein Eingriff in Audio-Callback, Routing, Mixer oder Plugin-Hosting.


## v0.0.20.371 — VST3 Project-State Raw-Blob Save/Load

- Externe **VST2/VST3-Devices** schreiben beim Projektspeichern jetzt zusätzlich einen **Base64-`raw_state`-Blob** (`__ext_state_b64`) in ihre Device-`params`.
- Der Blob wird **aus den aktuell gespeicherten Projekt-Parametern** auf einer frischen Plugin-Instanz erzeugt; die laufende DSP-Instanz wird dafür bewusst **nicht** direkt angefasst.
- `Vst3Fx` restauriert diesen Blob beim Laden vor der normalen Parameter-Initialisierung, sodass projektseitige Preset-/State-Daten erhalten bleiben.

## v0.0.20.370 — VST3 Widget Runtime-Param-Reuse Hotfix

- `Vst3AudioFxWidget` liest Parameter-Infos jetzt bevorzugt direkt aus der **bereits laufenden VST-DSP-Instanz** im Audio-Engine-FX-Map.
- Dadurch müssen frisch eingefügte Plugins wie **Autogain Mono** oder **GOTT Compressor LeftRight** für die Widget-Parameter nicht mehr sofort erneut in einem Worker-Thread geladen werden.
- Vor dem Async-Fallback wartet das Widget kurz auf den FX-Rebuild; das hält den Insert weiter responsiv, ohne die gerade aktive Live-Instanz aus dem Tritt zu bringen.
- `Vst3Fx` extrahiert Parameter-Metadaten jetzt direkt aus der schon geladenen Plugin-Instanz und macht beim Build keinen unnötigen Zweit-Load mehr.
- Fokus blieb bewusst auf **VST-Widget/Host-Metadaten**; kein Eingriff in Audio-Routing, Mixer, Automation-Architektur oder Projektformat.

## v0.0.20.369 — VST3 Mono/Stereo Bus-Adapt Hotfix

- `pydaw/audio/vst3_host.py` adaptiert externe VST3/VST2-FX jetzt sicher zwischen dem internen **Stereo-Track-Pfad** und dem tatsächlichen **Plugin-Main-Bus**.
- Mono-FX wie **LSP Autogain Mono** oder **Filter Mono** laufen dadurch jetzt ohne dauerhaften `2-channel output`-Fehler im Audio-Callback.
- Stereo→Mono nutzt einen kleinen Downmix an der Bridge; Mono-Outputs werden für den Host wieder sauber auf links/rechts gespiegelt.
- Falls `pedalboard` die Busgrößen nicht vorab verrät, liest der Host die Kanalzahlen einmalig aus der Fehlermeldung, stellt sich darauf um und cached das Layout für die weiteren Blöcke.
- Rein auf den externen VST-Bridge-Pfad begrenzt; kein Umbau an Mixer, Arranger, Routing oder DSP-Grundarchitektur.

## v0.0.20.366 — VST3 Device Exact-Reference Hotfix

- Externe VST3/VST2-Devices tragen jetzt immer eine **kanonische Komplett-Referenz** (`__ext_ref`) zusätzlich zu `__ext_path` und optional `__ext_plugin_name`.
- Browser-Insert und Drag&Drop geben diese exakte Referenz jetzt direkt mit.
- DevicePanel normalisiert die VST-Metadaten beim Hinzufügen, damit auch ältere Payloads oder gemischte Insert-Wege stabil auf dasselbe Sub-Plugin zeigen.
- Audio-FX-Build und VST-Widget bevorzugen jetzt die exakte Referenz statt nur des Basis-Pfads.
- Ziel: **kein stiller Verlust des gewählten Sub-Plugins** mehr beim Insert/Rebuild von Multi-Plugin-Bundles wie `lsp-plugins.vst3`.
- Kein Eingriff in Transport, Routing, Mixer, Automation-Architektur oder DSP-Grundverhalten.

## v0.0.20.365 — VST3 Startup Scan Hang Hotfix

- Kritischen Start-Hänger behoben: Der Plugins-Browser instanziiert beim automatischen Rescan nicht mehr blind jedes VST3 über `pedalboard`.
- Ursache war die neue Multi-Plugin-Erkennung aus v0.0.20.364; Plugins wie `ZamVerb.vst3` konnten dabei schon während des Browser-Scans hängen bleiben.
- Sicherer Hotfix: Eager-Probing nur noch für bekannte sichere Collection-Bundles wie `lsp-plugins.vst3`; normale VST3s bleiben beim Scan rein dateibasiert.
- Debug-Override `PYDAW_VST_MULTI_PROBE=1` ergänzt.
- Keine Änderung an Audio-Engine, Transport, Mixer oder Projektformat.

## v0.0.20.364 — VST3 Browser Multi-Plugin Bundle Fix

- **VST3-Browser** erkennt Mehrfach-Bundles wie `lsp-plugins.vst3` jetzt als mehrere separate Plugin-Einträge statt als eine unklare Datei.
- **`__ext_plugin_name`** wird durch Browser → DevicePanel → Widget → Live-Host durchgereicht, damit genau das ausgewählte Sub-Plugin geladen wird.
- **`pydaw/audio/vst3_host.py`** erhielt sichere Helper für Ref-Aufbau/-Split, Mehrfach-Bundle-Erkennung und exaktes Laden via `plugin_name`.
- **`install.py`** installiert `pedalboard` jetzt explizit; **`requirements.txt`** enthält die Abhängigkeit ebenfalls.
- Veraltete **Placeholder-Labels** im Plugins-Browser wurden auf echtes Live-Hosting / Rescan-Hinweise umgestellt.
- Rein auf Plugin-Discovery/-UI/-Hosting-Metadaten begrenzt; kein Eingriff in Arranger, Transport, Routing oder DSP-Grundarchitektur.

## v0.0.20.361 — MIDI Content Scaling + Instrument-Browser Doppelklick-Fix

- **Alt + Drag am MIDI-Clip-Rand** skaliert alle MIDI-Noten proportional (Bitwig-Style).
- **Alt + Drag am Audio-Clip-Rand** passt `clip.stretch` proportional an.
- **Instrument-Browser Doppelklick** repariert (Methode war leer).
- **Alt+Drag-auf-Body DnD-Copy entfernt** (kollidierte, Ctrl+Drag ist Copy-Methode).
- Neon-Glow-Effekt (🎵/🔊), Lazy Update, Original-Snapshot, Free Mode (Alt+Shift).
- Kein Eingriff in Audio-Engine, Transport, FX-Chain.

## v0.0.20.360 — DAWproject Export Cross-Device Hotfix

- Kritischen Export-Fehler **`[Errno 18] Ungültiger Link über Gerätegrenzen hinweg`** behoben.
- Finale `.dawproject`-Datei wird jetzt als **temporäre Schwesterdatei direkt im Zielordner** geschrieben statt in `/tmp`.
- Atomarer Abschluss via `os.replace()` bleibt erhalten, auch wenn Staging in `/tmp` und Zielordner auf verschiedenen Dateisystemen liegen.
- Zusätzlicher Cleanup für temporäre Zieldateien im Fehlerfall ergänzt.
- Kein Eingriff in Audio-Engine, Routing, Mixer, Transport, Undo/Redo oder Projektmodell.

## v0.0.20.359 — DAWproject Export UI Hook

- Neuer Menüeintrag **Datei → DAWproject exportieren… (.dawproject)** direkt neben dem vorhandenen Import ergänzt.
- Export läuft im Hintergrund über den bereits sicheren **`DawProjectExportRunnable`** auf Basis eines **read-only Snapshots**.
- **QProgressDialog** zeigt den Export-Fortschritt, ohne Audio-Core oder Arranger-Playback anzufassen.
- **QFileDialog** schlägt automatisch einen sinnvollen `.dawproject`-Dateinamen vor.
- Nach Erfolg erscheint ein Summary-Dialog mit Export-Zahlen und optionalen Warnungen.
- Bewusst **kein** Eingriff in Engine, Routing, Mixer, Transport, Undo/Redo oder Projekt-Mutationen.


## v0.0.20.358 — DAWproject Exporter Scaffold (snapshot-safe)

- Neuer sicherer **`pydaw/fileio/dawproject_exporter.py`** ergänzt.
- Export arbeitet bewusst nur auf einer **tief kopierten Snapshot-Instanz** des Projekts und berührt die laufende Session nicht.
- Neue **Temp-File-First Pipeline**: Staging-Ordner, XML-Erzeugung, ZIP-Bau, Validierung, anschließend atomarer Replace auf das Ziel.
- **Audio-Dateien** werden aus `Project.media` und Audio-Clips gesammelt und in `audio/` innerhalb des `.dawproject`-Containers geschrieben.
- **Automation-Lanes** aus `automation_manager_lanes` werden pro Spur in eine konservative XML-Struktur gemappt.
- **Instrument-/Device-Zustände** werden als erste sichere Grundlage als **Base64-XML-State-Blobs** serialisiert.
- Optionaler **`DawProjectExportRunnable`** für non-blocking PyQt6-Integration ergänzt.
- Neue Architektur-Dokumentation mit Datenfluss und Mermaid-Klassendiagramm unter `PROJECT_DOCS/plans/DAWPROJECT_EXPORT_ARCHITECTURE.md`.
- Bewusst **kein** Eingriff in Audio-Engine, Arranger-Playback, Mixer, Transport oder Undo/Redo-Core.


## v0.0.20.357 — Echter Group-Bus mit eigener Device-Chain (Bitwig-Style)

- **Echte Gruppenspur** mit `kind="group"` und eigener `audio_fx_chain` implementiert.
- **Group-Bus-Routing** im Audio-Callback: Kind-Audio wird summiert, durch Gruppen-FX verarbeitet, dann erst in den Master gemischt.
- **Pull-Sources** (Sampler/Drum/SF2) fließen ebenfalls durch den Group-Bus.
- **Group-Header-Klick** wählt den Group-Track aus → DevicePanel zeigt Gruppen-Chain.
- **Effects auf Gruppe** landen auf der Gruppen-FX-Chain, nicht auf der kick-Spur.
- Alte Projekte ohne Group-Tracks → kein Routing → Audio unverändert.
- 8 Dateien geändert: hybrid_engine, audio_engine, project_service (2×), arranger (2×), version, model.

## v0.0.20.356 — Kritischer Bugfix: Collapsed-Group Clip-Track-Zuordnung

- **Clip-Track-Korruption bei Drag in eingeklappter Gruppe** behoben: Clips wurden beim Drag auf `members[0]` umgehängt, sodass alle Instrumente gleichzeitig spielten.
- Neue Helper-Methode `_is_same_collapsed_group()` schützt alle drei Drag-Pfade (Single/Multi/Copy).
- **Track-Lookup Fallback** für collapsed Groups: Volume-Anzeige für Non-First-Members korrigiert.
- **Spur-Name-Prefix** in Clip-Labels bei eingeklappter Gruppe (🔹kick: ..., 🔹open hi: ...) für bessere Unterscheidbarkeit.
- Rein UI/Canvas-Fix, kein Eingriff in Audio-Engine, Routing oder Projektformat.

## v0.0.20.355 — Browser Scope-Badges + Distortion Automation Guard

- Browser/Add-Flow zeigt jetzt kleine **Scope-Badges** direkt neben den Add-Buttons in **Instruments**, **Effects**, **Favorites** und **Recents**.
- Die Badges nennen klar das aktuelle Ziel der normalen Browser-Aktion: **aktive Spur**, nicht die ganze Gruppe.
- Bei Gruppenspuren bleibt damit vor dem Add sichtbarer, dass **normales Add / Doppelklick / Drag&Drop** weiter nur auf die aktive Einzelspur wirkt.
- Die Scope-Badges aktualisieren sich sicher beim Spurwechsel über `DeviceBrowser.set_selected_track(...)`.
- Zusätzlich wurde ein sicherer Guard im **DistortionFxWidget** ergänzt, damit Automation-Callbacks nicht mehr auf bereits gelöschte Qt-Slider/Spinboxen zugreifen.

## v0.0.20.354 — DevicePanel Gruppen-/Spur-Zieltrennung klarer

- DevicePanel erhielt eine zusätzliche **Aktive Spur-Ziel**-Hinweisbox direkt oberhalb der sichtbaren Device-Kette.
- Die Box erklärt jetzt klar, dass die **sichtbare Device-Kette unten nur zur aktiven Spur** gehört.
- Für Gruppenspuren werden **NOTE→Gruppe** und **AUDIO→Gruppe** als getrennte Gruppen-Aktionen klar ausgewiesen.
- Die bisherige Gruppenleiste wurde sprachlich auf **Gruppen-Aktionen** geschärft und nennt ausdrücklich, dass hier noch **kein gemeinsamer Gruppenbus** existiert.
- Umsetzung blieb vollständig **UI-only** in `pydaw/ui/device_panel.py`.

## v0.0.20.353 — TrackList Drop-Markierung beim Maus-Reorder

- Linke Arranger-TrackList zeigt beim lokalen Maus-Reorder jetzt eine **sichtbare cyanfarbene Drop-Markierung** direkt an der Einfügeposition.
- Die Markierung folgt **oben/unten pro Zielzeile** und zeigt auch **Drop am Listenende** korrekt an.
- Die Lösung greift nur bei internem **TrackList-Reorder-MIME**; bestehender **Cross-Project-Track-Drag** bleibt unangetastet.
- Keine Änderung an Routing, Mixer, DSP, Playback oder Projekt-Audiodaten.

## v0.0.20.352 — Gruppenkopf-Mausdrag + Doppelklick-Umbenennen

- Gruppenköpfe lassen sich im linken Arranger jetzt **direkt per Maus-Drag als kompletter Block** verschieben.
- Das nutzt weiterhin den bestehenden sicheren Drag-Weg: **Cross-Project-Track-Drag bleibt erhalten**, lokal kommt nur derselbe Reorder-Mechanismus für Gruppenmitglieder zum Einsatz.
- **Doppelklick auf Track-Namen** öffnet jetzt direkt den sicheren Umbenennen-Dialog; **Doppelklick auf Gruppenkopf** öffnet den Gruppen-Umbenennen-Dialog.
- DevicePanel-Gruppenstreifen zeigt jetzt deutlicher an: **Track-FX = nur aktive Spur**, **N→G / A→G = ganze Gruppe**.

## v0.0.20.351 — Arranger Maus-Reorder in TrackList

- Spuren lassen sich im linken Arranger-Bereich jetzt **mit der Maus neu anordnen**.
- Mehrfachauswahl wird als **zusammenhängender Block** verschoben, statt Spur für Spur.
- Der bestehende **Cross-Project-Track-Drag** bleibt erhalten; lokales Reorder nutzt nur ein zusätzliches internes MIME und greift ausschließlich bei **same-widget Drops**.
- Umsetzung bleibt bewusst **UI-/Projektordnungs-safe**: kein Eingriff in Audio-Routing, Mixer, DSP oder Playback-Core.

## v0.0.20.350 — Arranger Gruppen-Alignment / Move Buttons

- ArrangerCanvas zeigt jetzt **ausgeklappte Gruppen mit Gruppenkopf + allen Mitgliedsspuren** synchron zur linken TrackList.
- Das behebt die sichtbare Fehlzuordnung, bei der in ausgeklappten Gruppen nicht alle Instrument-/Audio-/Busspuren korrekt erschienen.
- Direkt sichtbare **▲/▼-Buttons** in Track-/Gruppenzeilen ergänzt.
- **Gruppen als Block verschiebbar** gemacht.

## v0.0.20.349 — Gruppen-Fold-State + Arranger-Gruppen-Lane + Track-Reorder

- Arranger speichert jetzt den **Gruppen-Einklappstatus** direkt im Projekt (`arranger_collapsed_group_ids`), sodass Gruppen nach dem erneuten Laden in ihrem letzten Fold-Zustand wieder erscheinen.
- Eingeklappte Gruppen werden jetzt nicht nur links in der TrackList, sondern auch **rechts im Arranger-Canvas als eine gemeinsame Spur/Lane** dargestellt; die Clips der Gruppenmitglieder werden sicher auf diese Gruppen-Lane abgebildet.
- Arranger-Track-Menüs können Spuren jetzt **nach oben/unten verschieben**, ohne Master-Position oder Audio-Core anzufassen.
- Über Gruppenkopf- und Track-Menüs lassen sich neue **Instrument-/Audio-/Busspuren direkt in die bestehende Gruppe einfügen**, statt nur unterhalb der Gruppe am Listenende zu landen.
- Umsetzung bleibt bewusst **UI-/Projektmodell-safe**: kein Bus-Routing-Umbau, kein Mixer-Core-Redesign, keine DSP-Änderung.

## v0.0.20.348 — Master-FX hörbar + globales Projekt-Undo + reparierte Track-Menüs

- Master-Audio-FX werden jetzt im Summenpfad wirklich verarbeitet und sind hörbar, ohne Routing-/Bus-Core-Umbau.
- Globaler Projekt-Undo-Fallback ergänzt: modellweite Änderungen mit `project_updated` werden jetzt zusätzlich als sichere Snapshot-Undo-Schritte erfasst.
- Ctrl+Z / Ctrl+Shift+Z / Ctrl+Y als globale Application-Shortcuts verdrahtet, damit Undo/Redo auch bei Fokus in Unterwidgets greift.
- Track-Kontextmenüs im Arranger erweitert/repariert: **Umbenennen**, **Track löschen**, **Instrument-/Audio-/Bus-Spur hinzufügen**.
- Gruppenköpfe im Arranger sind jetzt wirklich **einklappbar** und bieten ein passendes Gruppenmenü.
- Track-Löschen aus dem Kontextmenü ist wieder funktionsfähig; Umbenennen läuft jetzt sicher per Dialog statt instabiler Inline-Editierung.

## v0.0.20.347 — Arranger Track-/Gruppen-Flow + Gruppen-Sektion im DevicePanel

- Arranger-Clipauswahl synchronisiert jetzt sicher die zugehörige Spur mit, sodass beim Klick auf einen MIDI-/Audio-Clip auch die Instrument-/Track-Zeile aktiv wird.
- Direktes Rechtsklick-Menü auf Track-Zeilen im Arranger ergänzt; Gruppierungsfunktionen sind jetzt dort auffindbar statt nur über Tastenkürzel oder den kleinen ▾-Button.
- Gruppierte Spuren werden im Arranger als sichtbare **Gruppen-Sektion** mit Gruppenkopf und eingerückten Mitgliedern dargestellt.
- DevicePanel zeigt für gruppierte Spuren jetzt eine lokale **Gruppen-Sektion** mit Mitgliederliste und sicheren Batch-Aktionen **N→G** / **A→G**, um NOTE-FX oder AUDIO-FX auf die komplette aktive Gruppe anzuwenden.
- Umsetzung bleibt bewusst **UI-/Projektmodell-first**: kein Eingriff in Playback-Core, Mixer-Engine, Transport oder Audio-Routing.

## v0.0.20.339 — AETERNA Knob-Mini-Meter / aktive Mod-Badges direkt an Synth-Knobs

- AETERNA zeigt jetzt kleine **Mini-Meter direkt an wichtigen Synth-Knobs** im lokalen Synth Panel (Filter, Voice, AEG, FEG, Layer, Noise, Timbre, Drive).
- Die Meter nennen kompakt **aktuellen Wert + kleine Balkenanzeige**; darunter erscheinen **aktive Mod-Badges pro Ziel-Knob** wie z. B. **A+20** oder **B−18**, falls Web A/B gerade wirklich auf diesen Knob zielen.
- Die bestehenden **Knob-Tooltips** wurden passend erweitert: neben Automation-Hinweis und gespeichertem Mod-Profil nennen sie jetzt auch **Mini-Meter** und **aktive Mod-Badges**.
- Reiner Widget-/State-Schritt in `aeterna_widget.py`; kein Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport, Playback-Core oder AETERNA-DSP.

## v0.0.20.338 — AETERNA Live ARP via bestehendem Note-FX-Arp

- AETERNA **Arp A** hat jetzt einen sicheren **Live-ARP-ON/OFF**-Weg: Das Widget pflegt lokal auf der aktuellen Spur ein eigenes **Track Note-FX Arp** (markiert als `aeterna_owner=arp_a`) und schaltet dieses per **ARP Live** an/aus.
- Damit bleibt der Eingriff **außerhalb des Playback-Cores** und nutzt die bereits vorhandene projektweite **Note-FX-Kette** statt eines riskanten neuen Echtzeit-Arp-Cores in AETERNA.
- Die AETERNA-Arp-Stepdaten wirken jetzt nicht mehr nur beim **ARP→MIDI**-Weg, sondern auch für den sicheren **Live-ARP**: **Transpose / Skip / Velocity / Gate / Shuffle / Note Type** werden im bestehenden `chrono.note_fx.arp` berücksichtigt.
- AETERNA zeigt den Zustand jetzt klarer als **ARP Live** vs. **ARP→MIDI**; zusätzlich wurden Card-/Hint-Schriften lokal leicht vergrößert, damit die Screens auf kleineren Höhen lesbarer bleiben.
- Weiterhin keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

## v0.0.20.328 — AETERNA Mod Rack / Flow + Collapsible UI

- AETERNA lokal um ein **MOD RACK / FLOW (LOCAL SAFE)** erweitert.
- Neue lokale **Drag-&-Drop-Quellen**: **LFO1**, **LFO2**, **MSEG**, **Chaos**, **ENV**, **VEL**.
- Drop auf stabile Ziele (**Morph, Tone, Gain, Release, Space, Motion, Cathedral, Drift, Chaos**) weist die Quelle sicher einem der realen Slots **Web A/B** zu.
- Zusätzliche lokale Slot-Helfer: **Drop-Slot Auto/A/B**, **Swap A/B**, **Clear A**, **Clear B**.
- Alle großen AETERNA-Bereiche sind jetzt **einklappbar** (Dreiecks-Header), damit das Instrument kompakter bleibt.
- Neue lokale **Signalfluss-Karte** erklärt den AETERNA-Aufbau kompakt.
- Kleine echte Engine-Erweiterung nur innerhalb AETERNA: **ENV**- und **VEL**-Modulationsquellen können jetzt in den beiden Web-Slots genutzt werden.
- Keine Änderungen an Arranger-Core, Playback-Core, Mixer-Engine, Transport oder anderen Instrumenten.

## v0.0.20.324 — AETERNA staged Init / sanfteres Laden

- AETERNA lädt jetzt lokal **sanfter und flüssiger**: beim Restore werden UI-Signale geblockt und Widget-Updates gebündelt, damit nicht dutzende Komfort-Callbacks gleichzeitig im GUI-Thread anlaufen.
- Komfort-/Lesbarkeitsbereiche (**Formel-Info, Web-/Snapshot-Karte, Composer-Zusammenfassung, Preset-Kurzliste, Phase-3a-Summary**) werden jetzt **gestaffelt per Deferred Refresh** aufgebaut, sodass das Grund-Widget früher sichtbar wird.
- Lokale Button-Neubindung für Preset-/Snapshot-Schnellaufrufe auf **gezieltes Rebind statt blindem disconnect()** umgestellt; das vermeidet überflüssige Qt-Hardening-Fehlermeldungen beim Refresh.
- Weiterhin nur **AETERNA-Widget**, kein Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.

## v0.0.20.321 — AETERNA Preset-/Snapshot-Schnellaufrufe lokal

- AETERNA zeigt jetzt kleine lokale **Preset-/Snapshot-Schnellaufrufe** direkt im Widget: gefüllte Snapshot-Slots werden als kompakte Recall-Buttons sichtbar, ergänzt um Preset-Schnellaufrufe aus der bestehenden Kurzliste.
- Die neue Schnellaufruf-Zeile leitet alles rein lokal aus bereits vorhandenen **Snapshot-Daten**, **Preset-Metadaten** und **Formel/Web-Kombitipps** ab; Tooltips nennen kompakt **Hörbild**, **Formel** und **Web-Startweg**.
- Keine neue Engine- oder State-Logik: reiner Widget-/Komfortschritt in AETERNA ohne Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.

---

## v0.0.20.320 — AETERNA Formel-/Web-Kombitipps direkt an Presets

- AETERNA zeigt jetzt lokale **Preset→Startweg**-Hinweise direkt im Widget: pro Preset wird ein kompakter Tipp für **Formel + Web-Vorlage/Intensität** sichtbar.
- Die **Preset-Kurzliste** nennt diese Startwege jetzt direkt in der Textzeile; Schnellpreset-Tooltips zeigen zusätzlich **Hörbild**, **Formelidee** und **Web-Startweg** zusammen an.
- Der kompakte **Preset-Fokus** des aktuell gewählten Presets enthält jetzt ebenfalls den lokalen **Startweg**.
- Rein lokale Ableitung aus bereits vorhandenen Preset-Metadaten, Formelideen und Web-Vorlagen; **kein** neuer Core-State und kein Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.

---

## v0.0.20.319 — AETERNA Preset-Kurzliste mit Direktmarkern

- AETERNA-Preset-Kurzliste zeigt jetzt lokale **Direktmarker** für **Kategorie** und **Charakter**.
- Die sichtbaren Kurzlisten-Einträge werden kompakter als Marker dargestellt, z. B. **Sakral • Hell** oder **Ambient • Weich**.
- Tooltips der Schnell-Presets zeigen zusätzlich den Direktmarker neben Hörbild und Presetnamen.
- Der Aktiv-Status der Kurzliste enthält jetzt ebenfalls den aktuellen **Kategorie/Charakter-Marker**.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.

---

## v0.0.20.318 — AETERNA Snapshot-Slots mit Farbbadges/Statusmarkern

- AETERNA lokal um kleine **Farbbadges/Statusmarker** direkt an den Snapshot-Slots **A/B/C** erweitert: **leer**, **gefüllt** und **aktiv** werden jetzt sofort sichtbar.
- Zusätzlicher kleiner **Hörbild-Marker** pro Slot (z. B. sakral, klar, getragen, belebt) wird rein lokal aus den bereits vorhandenen Snapshot-Daten abgeleitet.
- **Recall** ist für leere Slots lokal deaktiviert; Tooltips von **Store/Recall** zeigen jetzt kompakt den aktuellen Snapshot-Inhalt an.
- Reiner Widget-/Darstellungsschritt auf Basis vorhandener lokaler Snapshot-Daten; **kein** Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport, Playback-Core oder Projektstruktur.

## v0.0.20.317 — AETERNA Preset-Bibliothek kompakt nach Kategorie/Charakter

- AETERNA lokal um eine kompakte **Preset-Bibliotheksansicht** erweitert: sichtbare Zusammenfassung der lokalen Presets nach **Kategorie** und **Charakter** direkt im Widget.
- Neue **Fokuszeile** für das aktive Preset: zeigt **Kategorie / Charakter / Favorit / Tags / Hörbild** kompakt an.
- Die bestehende **Preset-Kurzliste** zeigt jetzt zusätzlich **Kategorie/Charakter** direkt in der Textzeile sowie im Tooltip der Schnellwahl-Buttons.
- Reiner Widget-/Darstellungsschritt auf Basis vorhandener lokaler Preset-Metadaten; **kein** Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport, Playback-Core oder Projektstruktur.

## v0.0.20.316 — AETERNA lokaler Automation-Schnellzugriff

- AETERNA lokal um einen **Automation-Schnellzugriff** erweitert: alle bereits stabil freigegebenen Ziele (**Morph, Tone, Gain, Release, Space, Motion, Cathedral, Drift, Chaos, LFO1 Rate, LFO2 Rate, MSEG Rate, Web A, Web B**) können jetzt direkt aus dem Widget in die passende Automation-Lane geöffnet werden.
- Bestehende AETERNA-Knobs zeigen lokal klarere **Automation-ready-Tooltips** mit einer kleinen musikalischen Einordnung (z. B. Sweeps, sakrale Weite, Schwebung, Web-Tiefe).
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport, Playback-Core oder Projektstruktur.

- 2026-03-07 v0.0.20.315: AETERNA Formel-/Preset-Vorschläge um lokale Hörhinweise ergänzt (z. B. sakral, klar, getragen, belebt, kristallin, dunkel) – nur im Widget.
- 2026-03-07 v0.0.20.314: AETERNA Snapshot-Karte kompakter und musikalischer lesbar gemacht (Preset, Stimmung, Formelhinweis, Web).
- 2026-03-07 v0.0.20.312: AETERNA Web-Vorlagen um „Basis wiederherstellen“ erweitert; aktive Web-Vorlage und Intensität werden lokal gespeichert/geladen.
## v0.0.20.311 — AETERNA Web-Vorlagen mit Intensitätsstufen

- AETERNA lokal um sichere **Intensitätsstufen** für Web-A/Web-B-Startvorlagen erweitert: **Sanft**, **Mittel**, **Präsent**.
- Intensität skaliert nur lokale **Amount-/Rate-Werte** der Web-Vorlagen und greift nicht in den DAW-Core ein.
- Die gewählte Intensität wird sauber im **Instrument-State** mitgespeichert und beim Projektladen wiederhergestellt.
- Web-Karte zeigt jetzt kompakt: **aktive Vorlage + Intensität + Web A/B**.
- Weiterhin nur **AETERNA-Widget**, kein Eingriff in Arranger, Audio Editor, Clip Launcher, Mixer, Transport oder Playback-Core.

## v0.0.20.309 — AETERNA Macro-A/B-Feinsteuerung lesbarer

- AETERNA lokal um eine kompakte **Macro-A/B-Karte** erweitert.
- Zeigt jetzt lesbar: **Quelle → Ziel → Amount** für **Web A** und **Web B**.
- Zusätzliche Kurz-Hinweise im Widget ordnen die aktuelle Modulationsidee ein, z. B. eher **Sweep**, **gezeichneter Verlauf**, **organische Bewegung** oder **spielabhängige Dynamik**.
- Fokus bleibt lokal auf sicheren Makro-Wege: **Source/Target/Amount** statt roher interner Zustände.
- Weiterhin nur **AETERNA-Widget**, kein Core-Eingriff.

## v0.0.20.308 — AETERNA Formel-/Preset-Verknüpfung sichtbar

- Lokale **Preset→Formel-Hinweiszeile** direkt im AETERNA-Formelbereich ergänzt.
- Zeigt jetzt, welche **Formelidee** zum aktuellen Preset passt (z. B. Sakral, Organisch, Drone, Chaos, Warm Start).
- Zusätzlicher Button **„… laden“**, um die vorgeschlagene Formelidee nur lokal ins Formelfeld zu übernehmen.
- Status unterscheidet: passende Idee bereit / im Feld / angewendet / eigene Formel.
- Weiterhin **nur AETERNA-Widget**, kein Core-Eingriff.

## v0.0.20.307 — AETERNA Preset-Kurzliste mit lokalem Filter

- AETERNA lokal um einen sicheren Filter für die Preset-Kurzliste erweitert: **Alle**, **Sakral**, **Kristall**, **Drone** und **Favoriten**.
- Die vier Schnellwahl-Buttons passen sich jetzt lokal dem gewählten Filter an.
- Hilft beim schnellen Finden von sakralen, gläsernen oder ruhigen Startpresets, ohne Eingriff in den DAW-Core.

## v0.0.20.306 — AETERNA Preset-Kurzliste lokal

- kompakte lokale Preset-Kurzliste direkt im AETERNA-Widget ergänzt
- Schnellwahl-Buttons für: Kristall Bach, Bach Glas, Kathedrale, Celesta Chapel
- lokale Statuszeile zeigt aktives Preset, Favorit und Tag-Vorschau
- nur AETERNA-Widget angepasst, keine Core-Änderungen

## v0.0.20.304
- AETERNA lokal um weitere kuratierte **Formel-Startbeispiele** erweitert: **Organisch** und **Drone**.
- Lokales **AETERNA-Voicing** in der Engine entschärft und verfeinert: weniger chipig/kratzig, mehr klarer, luftiger, orgeliger Grundcharakter.
- Bestehende sakrale/organartige Presets lokal nachgeschärft und neues Preset **Kristall Bach** ergänzt.
- Lokalen Bugfix ergänzt: `AeternaEngine.get_formula_status()` nachgezogen, damit die Formelstatus-Anzeige im Widget keinen AttributeError mehr wirft.
- Weiterhin nur **AETERNA** geändert; keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

## v0.0.20.303
- AETERNA lokal um eine **Formel-Infozeile** erweitert.
- Die Infozeile zeigt jetzt klar: **Beispiel im Feld**, **manuell geändert**, **angewendet** oder **noch nicht angewendet**.
- Der Status bleibt rein lokal im AETERNA-Widget und wird mit dem lokalen Instrument-State mitgespeichert.

## v0.0.20.302

- AETERNA lokal um eine klare **"Jetzt lokal freigegeben"-Karte** für stabile Automationsziele erweitert.
- Freigegeben und sichtbar gruppiert: **Direkt auf Knobs**, **Modulations-Rates** und **Depth/Amounts**.
- Die bereits vorhandene sichere Anbindung an das DAW-Automationssystem wird jetzt im Widget klar erklärt: **Rechtsklick auf einen AETERNA-Knob → Show Automation in Arranger**.
- Knob-Tooltips weisen lokal zusätzlich auf die Automationsnutzung hin.
- Keine Änderungen am globalen DAW-Core, Playback-Core, Arranger, Clip Launcher, Audio Editor, Mixer oder Transport.

---

## v0.0.20.301

- AETERNA lokal um eine kompakte **Automation-Zielkarte** erweitert.
- Spätere sichere Ziele jetzt lesbar gruppiert: **Klang**, **Raum/Bewegung**, **Modulation**, **Web**.
- Zusätzlicher Hinweis im Widget: später vorzugsweise **Knobs/Rates/Amounts** automatisieren, nicht flüchtige UI- oder rohe Phasen-Zustände.
- Keine Änderungen am globalen DAW-Core.

---

## v0.0.20.300 — AETERNA kompakte Badge-/Kurzansicht für Preset-Metadaten

- Lokale **Badge-/Kurzansicht** direkt im AETERNA-Widget ergänzt.
- Zeigt kompakt **Favorit**, **Kategorie**, **Charakter**, **Tags** und eine gekürzte **Notiz** an.
- Badge-Ansicht aktualisiert sich bei Änderungen der lokalen Preset-Metadaten sofort.
- Weiterhin nur **AETERNA** geändert, ohne Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.
---

## v0.0.20.299 — AETERNA lokale Preset-Metadaten mit Tags/Favorit

- Lokale **Preset-Metadaten** in AETERNA um **Tags** und **Favorit** erweitert.
- Tags werden lokal als kurze Liste normalisiert und dedupliziert.
- Favorit-Status läuft lokal in **AETERNA-State** und **Preset-Snapshot** mit.
- Phase-3a-Metadaten-Zeile zeigt jetzt zusätzlich **Favorit** und **Tags** lesbar an.
- State-Schema auf **Version 5**, Preset-Schema auf **Version 3** angehoben.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.
---

## v0.0.20.298 — AETERNA Formel-Startkarte / Onboarding-Hilfe

- Lokale **Formel-Startkarte** direkt im AETERNA-Formelbereich ergänzt.
- Vier sichere lokale **Startbeispiele** eingebaut: **Warm Start**, **Sakral**, **Chaos** und **Glitch**.
- Beispiele schreiben nur das **Formelfeld lokal vor**; der Klang ändert sich weiterhin erst nach **"Formel anwenden"**.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

---

## v0.0.20.297 — AETERNA Formel-Editor-Fix + lokale Preset-Metadaten

- Das AETERNA-Formelfeld ist jetzt wieder **praktisch beschreibbar**: statt einer knappen Ein-Zeile wird ein **mehrzeiliges lokales Edit-Feld** verwendet.
- Token-Einfügen per **Klick** und **Drag&Drop** funktioniert weiter im mehrzeiligen Formelbereich.
- Lokale **Preset-Metadaten** ergänzt: **Kategorie**, **Charakter** und **Notiz** direkt im AETERNA-Widget.
- Preset-Metadaten werden lokal in **AETERNA-State** und **Preset-Snapshot** mitgeführt.
- State-Schema auf **Version 4**, Preset-Schema auf **Version 2** angehoben.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

---

## v0.0.20.295 — AETERNA Formel-Aliase + sichtbare Formel-Mod-Slots

- Lokale sichere Formel-Aliase ergänzt: **$VEL**, **$NOTE**, **$T_REM**, **$T_REMAINING**, **$GLITCH**.
- Sichere lokale Formel-Funktionen ergänzt: **rand(t)** und **random()**.
- Formelbereich zeigt jetzt lesbar die **aktiven Formelquellen** und eine kurze **Alias-Ansicht**.
- UI-State-Schema auf **Version 4** angehoben.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

---


## v0.0.20.293 — AETERNA Phase 3a Preset A/B + lesbare Automation-Zielsektionen

- Lokale **Preset-A/B**-Aktionen ergänzt: **Store A**, **Store B**, **Recall A**, **Recall B**, **Compare A/B**.
- Phase-3a-Bereich zeigt lokale Automation-Ziele jetzt lesbarer in vier Gruppen: **Klang**, **Raum/Bewegung**, **Modulation**, **Web**.
- Preset-A/B-Zustände werden lokal im AETERNA-Instrumentzustand mitgespeichert.
- UI-State-Schema auf **Version 3** angehoben.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

---

## v0.0.20.294 — AETERNA Phase 3a Formel-Modulationshilfen

- Lokales **Formel-Insert-System** ergänzt: **LFO1**, **LFO2**, **MSEG**, **CHAOS**, **ENV** und **VEL** können per **Klick** oder **Drag&Drop** in die Formel eingefügt werden.
- Neue **Quick-Snippets** für typische Modulationsideen direkt im Formelbereich.
- Formel-Engine akzeptiert jetzt zusätzlich die lokalen Formelquellen **lfo1**, **lfo2**, **mseg** und **chaos_src**.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.


---

## v0.0.20.305 — AETERNA Klang-/Preset-Pack safe

- AETERNA lokal um vier neue kuratierte Startpresets erweitert: **Bach Glas**, **Celesta Chapel**, **Choral Crystal** und **Abendmanual**.
- Bestehende sakrale/kristalline Richtung weiter geschärft, weiterhin nur in **AETERNA**.
- Lokale Voicing-Mischung vorsichtig geglättet, damit spektrale/formelbasierte Klänge weniger chipig und klarer/kristalliner wirken.
- Preset-Metadaten für die neuen AETERNA-Presets ergänzt (Kategorie, Charakter, Notiz, Tags/Favorit lokal).
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

---

## v0.0.20.310 — AETERNA Web-A/Web-B-Startvorlagen

- Neue lokale **Web-Startvorlagen** direkt im Bereich **THE WEB (LOCAL SAFE)**: **Langsam**, **Lebendig**, **Organisch**, **Sakral**.
- Vorlagen setzen nur sichere lokale AETERNA-Werte für **mod1/mod2 source**, **target**, **amount** sowie **LFO/MSEG-Rates**.
- Neue kompakte **Web-Vorlagen-Karte** zeigt aktive Vorlage plus Kurzansicht von **Web A** und **Web B**.
- Manuelle Abweichungen werden lokal als **Eigen** erkannt.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.


## v0.0.20.313 — AETERNA lokale Snapshot-Karte

- Neue lokale Snapshot-Karte in AETERNA für **Klang / Formel / Web** mit drei Slots: **A / B / C**.
- Pro Slot gibt es **Store** und **Recall**, nur lokal im AETERNA-Widget.
- Snapshot speichert nur sichere AETERNA-Zustände: Preset, Formel, Web-Template/Intensität, Web A/B, wichtige Klang- und Rate-Knobs.
- Snapshot-Slots werden im **Instrument-State** mit dem Projekt gespeichert und beim Laden wiederhergestellt.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.

---

## v0.0.20.322 — AETERNA Snapshot-Last-Action-Hinweis

- Lokale Snapshot-Karte in AETERNA um eine kompakte **„Zuletzt: Store/Recall …“**-Hinweiszeile erweitert.
- Die Zeile zeigt direkt **Aktion**, **Slot**, **Preset**, **Hörbild**, **Formelhinweis** und **Web-Startweg/Intensität**.
- Hinweis bleibt rein lokal im AETERNA-Widget und wird mit dem lokalen Instrument-State im Projekt gespeichert und beim Laden wiederhergestellt.
- Zusätzlich wird die Hinweiszeile bei Snapshot-Store/Recall automatisch mit der bestehenden Snapshot-Karte synchronisiert.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.

## v0.0.20.323 — AETERNA Composer + Snapshot-Slot-Kurznamen

- Lokalen **AETERNA Composer (LOCAL SAFE)** direkt im Widget ergänzt.
- Neuer **Dreiecks-/Menü-Button** erzeugt MIDI-Clips direkt auf der aktuellen **AETERNA-Spur** oder überschreibt den aktiven Clip dieser Spur.
- Breiter lokaler **Weltstil-Katalog** mit freier Eingabe ergänzt; zwei Stile können gemischt werden (**Style A × Style B**).
- Mathematische/deterministische Seed-Logik via Hash/PRNG ergänzt; **Seed**, **Style-Mix**, **Bars**, **Grid**, **Swing**, **Dichte** und **Mix** bleiben lokal im AETERNA-State gespeichert.
- Neue Voice-Schalter nur für **Bass**, **Melodie**, **Lead**, **Pad** und **Arp**; ausdrücklich **keine Drums**.
- Umsetzung nutzt nur bestehende sichere Projekt-APIs für **MIDI-Clip-Erzeugung** und **MIDI-Noten-Schreiben**; kein Eingriff in Playback-Core, Arranger, Clip Launcher, Audio Editor, Mixer oder Transport.
- Lokale **Snapshot-Slot-Kurznamen** ergänzt und zusätzlich in Schnellaufrufen sichtbar gemacht.



## v0.0.20.325 — AETERNA sichtbare Ladezeit + feinere Composer-Profile

- Lokale **Ladeprofil-Anzeige** direkt im AETERNA-Widget ergänzt.
- Sichtbar gemacht werden **Build**, **Restore** und der letzte **staged UI refresh**; alles rein lokal als Widget-/Restore-Messung.
- AETERNA Composer lokal um **Phrasenprofile** erweitert: **Sehr getragen**, **Getragen**, **Ausgewogen**, **Belebt**, **Sehr belebt**.
- AETERNA Composer lokal um **Dichteprofile** erweitert: **Luftig**, **Offen**, **Mittel**, **Dicht**, **Schimmernd**.
- Die neuen Profile wirken nur lokal auf **Notendichte**, **Notenlängen** und **Arp-/Lead-/Pad-Verhalten** für **Bass / Melodie / Lead / Pad / Arp**.
- Neue Composer-Profile werden im lokalen **AETERNA-State** gespeichert und beim Projektladen wiederhergestellt.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.


## v0.0.20.326 — Bounce in Place / Freeze Track (erste sichere Workflow-Stufe)

- Erste sichere **Bounce-in-Place**-Stufe ergänzt: Im Arranger-Kontextmenü können ausgewählte Clips jetzt auf **eine neue Audiospur** gebounced werden (**+FX**, **Dry**, optional **Quelle stummschalten**).
- Erste sichere **Freeze-Track**-Stufe ergänzt: Im Track-Kontextmenü können Spuren jetzt als **Audio-Proxy** auf eine neue Audiospur gebounced und die Quellspur(en) dabei **stumm/Instrument aus** geschaltet werden.
- Wenn eine Spur bereits zu einer **Track-Gruppe** gehört, ist zusätzlich ein erster **Gruppe einfrieren**-Eintrag im Track-Kontextmenü verfügbar.
- Für Freeze-Proxys gibt es einen ersten **Auftauen-/Reaktivieren**-Weg: **Freeze-Quellen wieder aktivieren** im Track-Kontextmenü der Proxy-Spur.
- Umsetzung bleibt projekt-/UI-seitig: neue Offline-Render-Helfer in `ProjectService`, neue Arranger-/Track-Kontextmenü-Einträge; **kein** Umbau von Arranger-Core, Playback-Core, Mixer oder Transport.
- AETERNA lokal zusätzlich um **breitere mathematische Formel-/Random-Familien** in Hilfe und Randomizer ergänzt (z. B. env/coherent/cloud/logistic/brown-artige Startideen), weiterhin nur im Widget.


## v0.0.20.327 — Bounce/Freeze-Dialoge + sichtbare Freeze-Marker + breitere AETERNA-Math-Familien

- Neue kleine **Bounce/Freeze-Dialoge** für Clip-Bounce, Track-Freeze/Bounce und Group-Freeze ergänzt.
- Dialoge erlauben jetzt lokal/gezielt: **Label**, **+FX/Dry** sowie optional **Quelle stummschalten/deaktivieren**.
- **TrackList** zeigt jetzt sichtbare **Freeze-Marker** für **Proxy-Spuren** und **Freeze-Quellspuren** inklusive Tooltip.
- Laufzeitfehler in der ersten Bounce-Stufe lokal behoben: sichere Label-Verwendung für neu erzeugte Audio-Clips bei Clip-/Track-Bounce.
- AETERNA lokal um weitere **Math-/Random-Familien** in Formelhilfen, Onboarding und Randomizer erweitert (z. B. harmonic lattice, pink bloom, lorenz breath, sample hold veil, tent lattice, modal drift).
- Keine Änderungen an Playback-Core, Mixer-Engine, Transport oder globaler Audio-Architektur.

## v0.0.20.329 — AETERNA Mod-Rack Amount/Polarität + Signalfluss-Karte

- AETERNA **Web A / Web B** lokal um echte **Polaritätsumschaltung (+ / −)** erweitert; bleibt vollständig auf das interne Instrument begrenzt.
- Mod-Rack-Karte zeigt pro Slot jetzt **Amount + Polarität + kleine Balkenanzeige**.
- Neue lokale **Signalfluss-Linienansicht** ergänzt, die aktive Wege wie **Quelle → Web A/B → Ziel** direkt sichtbar macht.
- Polarity bleibt im lokalen AETERNA-State gespeichert und wird beim Projektladen wiederhergestellt.
- Zusätzlich ein sicherer **Stufenplan** für die größere gewünschte AETERNA-Synth-Erweiterung dokumentiert: erst UI-/Stage-Plan, dann Filter, dann weitere Wunschfamilien wie Unison/Sub/Shape/Noise/Glide/Drive — ausdrücklich **nicht alles in einem riskanten Schritt**.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

## v0.0.20.330 — AETERNA Synth Panel Stage 1 (safe UI grouping)

- Neuer lokaler Bereich **AETERNA SYNTH PANEL (STAGE 1 SAFE)** direkt im Widget.
- Vorhandene stabile Parameter werden dort lesbarer gruppiert in **Core Voice**, **Space / Motion** und **Mod / Web**.
- Kleine Navigations-Buttons öffnen direkt die bereits vorhandenen Bereiche **ENGINE**, **MORPHOGENETIC CONTROLS**, **THE WEB** und **MOD RACK / FLOW**.
- Neue kompakte Statuskarten zeigen die aktuellen Werte der bereits vorhandenen stabilen AETERNA-Parameter inklusive **Web A / Web B**-Kurzansicht.
- Zusätzlich wurden bewusst deaktivierte **Preview-/Platzhalterfelder** für spätere sichere Ausbaustufen ergänzt (z. B. **Filter Type**, **Envelope**, **Layer**, **Unison/Sub/Noise**), damit die UI-Richtung klar ist ohne neue Audio-Engine-Risiken.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

## v0.0.20.331 — AETERNA Filter Stage 2 (größerer sicherer Ausbau)

- Echter lokaler **AETERNA-Filterblock** ergänzt: **Cutoff**, **Resonance** und **Type** (**LP 12 / LP 24 / HP 12 / BP / Notch / Comb+**).
- Filter sitzt vollständig **innerhalb von AETERNA**; kein Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalen Playback-Core.
- Neue echte Filter-Bedienung im **AETERNA SYNTH PANEL** statt nur Preview-Platzhalter.
- **Filter Cutoff** und **Filter Resonance** sind jetzt als stabile **Automation-Ziele** sichtbar und direkt über die vorhandenen Automation-Wege nutzbar.
- **Web A / Web B** können jetzt lokal auch auf **Filter Cutoff** und **Filter Resonance** zielen.
- Neue Filter-Zustände werden mit dem **AETERNA-State** gespeichert und beim Projektladen wiederhergestellt; Snapshot-/Randomize-Pfade wurden lokal mitgezogen.
- Signalfluss-/Synth-Panel-Hinweise wurden lokal erweitert, damit die größere Ausbau-Richtung sichtbarer wird.



## v0.0.20.332 — AETERNA Voice Family + AEG/FEG ADSR (größerer Familien-Block)

- Größeren lokalen **Voice-Block** in AETERNA ergänzt: **Pan**, **Glide**, **Stereo-Spread** und **Retrig**.
- **Pan / Glide / Stereo-Spread** sind als stabile **Automation-Ziele** und lokale **Mod-Rack-Ziele** innerhalb von AETERNA verfügbar; **Retrig** bleibt in dieser sicheren Stufe als lokaler Schalter umgesetzt.
- Größeren lokalen **Envelope-Block** ergänzt: **AEG ADSR** und **FEG ADSR** inklusive **FEG Amount**.
- AEG steuert jetzt lokal die Amplituden-Hüllkurve, FEG formt lokal den Filterverlauf (Cutoff/Resonance) – alles innerhalb von AETERNA ohne Eingriff in DAW-Core, Arranger, Mixer oder Transport.
- Neue Familien wurden im **AETERNA SYNTH PANEL** sichtbar gruppiert, inklusive Statuskarten, erklärender Hinweise und weiterhin einklappbarer Struktur.
- Save/Load, Snapshot und Randomize lokal mitgezogen; bestehende AETERNA-Zustände bleiben kompatibel durch konservative Defaults.
- Zusätzlich eine kleine lokale Runtime-Lücke in der aktuellen AETERNA-Engine geschlossen: fehlende interne **LFO-/MSEG-Helfer** ergänzt, damit der reine Engine-Pull-Pfad wieder lokal ausführbar ist.

## v0.0.20.333 — AETERNA Unison / Sub / Noise (größerer Familien-Block)

- Größeren lokalen **Layer-Block** in AETERNA ergänzt: **Unison / Sub / Noise**.
- Neue echte Klangparameter: **Unison Mix**, **Unison Detune**, **Sub Level**, **Noise Level**, **Noise Color**.
- Neue lokale Comboboxen: **Unison Voices** (**1 / 2 / 4 / 6**) und **Sub Oktave** (**-1 / -2**).
- Stabile kontinuierliche Ziele **Unison Mix / Unison Detune / Sub Level / Noise Level / Noise Color** sind jetzt im AETERNA-Kontext als Automation-/Mod-Rack-Ziele verfügbar.
- Umsetzung bleibt vollständig lokal in **AETERNA Engine + Widget**; kein Eingriff in Arranger, Mixer, Transport oder globalen Playback-Core.
- Save/Load, Snapshot und Randomize für die neue Familie lokal mitgezogen.
- Engine-Smoketest ohne GUI lief sauber für **note_on() / pull() / note_off()** mit aktivem Unison/Sub/Noise-Block.



## v0.0.20.334 — AETERNA Pitch/Shape/Pulse Width + Drive/Feedback (größerer Familien-Block)

- Größeren lokalen **Pitch/Timbre-Block** in AETERNA ergänzt: **Pitch**, **Shape** und **Pulse Width**.
- **Pitch** wirkt jetzt lokal als musikalische globale Tonhöhen-Verschiebung (zentriert um 50%), bleibt aber vollständig innerhalb von AETERNA.
- **Shape** morpht lokal die Wellenform zwischen eher **sine/triangle** und **saw/square**-artigen Verläufen.
- **Pulse Width** steuert lokal die Pulsbreite des Rechteckanteils und damit den Vokal-/Nasalcharakter.
- Größeren lokalen **Drive/Feedback-Block** ergänzt: **Drive** und **Feedback** mit echter Audio-Wirkung innerhalb von AETERNA.
- **Drive** erweitert lokal die Sättigung/Bissigkeit, **Feedback** fügt kontrollierte interne Rückkopplung hinzu — ohne den DAW-Core, Mixer oder Transport anzutasten.
- Neue kontinuierliche Ziele **Pitch / Shape / Pulse Width / Drive / Feedback** sind jetzt im AETERNA-Kontext als stabile **Automation-** und **Mod-Rack-Ziele** verfügbar.
- Familien wurden direkt im **AETERNA SYNTH PANEL** sichtbar ergänzt, inklusive neuer Statuskarten und erweitertem Automation-Schnellzugriff.
- Save/Load, Snapshot und Randomize lokal mitgezogen; bestehende AETERNA-Zustände bleiben kompatibel durch konservative Defaults.
- Engine-Smoketest ohne GUI lief sauber mit den neuen Familien (**note_on / pull / note_off**).

## v0.0.20.335 — AETERNA Visual Polish + sichtbare Familienkarten

- Größeren lokalen **AETERNA-Polish-Block** umgesetzt: deutlichere **Farbtrennung** zwischen Core, Filter, Voice, AEG, FEG, Layer, Timbre und Drive.
- Neue kleine **Familien-Legende** direkt im **AETERNA SYNTH PANEL**, damit die großen Familien schneller lesbar und farblich unterscheidbar sind.
- Neue kleine **grafische Signalfluss-Ansicht** im Bereich **MOD RACK / FLOW**: Audio-Pfad und Mod-Pfad werden jetzt als lokale Linien-/Kartenübersicht sichtbar dargestellt.
- Bestehende Zusammenfassungs-Karten (**Overview, Core, Space, Mod, Future, Filter, Voice, AEG, FEG, Unison/Sub, Noise/Color**) farblich getönt und klarer getrennt.
- Bisher im State/Update schon angelegte Familien **Pitch / Shape / Pulse Width** sowie **Drive / Feedback** jetzt auch als echte **sichtbare Karten mit Knobs** im **AETERNA SYNTH PANEL** ergänzt.
- Umsetzung bleibt vollständig lokal in **pydaw/plugins/aeterna/aeterna_widget.py**; kein Eingriff in Arranger, Playback-Core, Mixer, Transport oder andere Instrumente.


## v0.0.20.336 — AETERNA Layer-Toggles + Mod-Badges/Mini-Meter

- Irreführende Vorschau-Checkboxen im **AETERNA SYNTH PANEL** für **Unison / Sub / Noise** in echte lokale **Layer-Schnellschalter** umgebaut.
- Die drei Schalter greifen jetzt direkt auf die realen Layer-Level **Unison Mix / Sub Level / Noise Level** zu und schalten diese sicher an/aus, ohne Playback-Core oder andere Instrumente anzufassen.
- Letzter sinnvoller Layer-Wert wird lokal gemerkt, sodass ein erneutes Einschalten nicht hart bei 0 startet.
- **Familienkarten** im Synth-Panel zeigen jetzt zusätzlich kompakte **Mini-Meter** und **aktive Mod-Ziel-Badges** pro Familie (z. B. Web A/B auf Filter-, Voice-, Layer- oder Drive-Ziele).
- Umsetzung bleibt vollständig lokal in `pydaw/plugins/aeterna/aeterna_widget.py`.


## v0.0.20.337 — AETERNA Arp A + Per-Knob Mod-Menüs + Readability

- Lokalen **AETERNA Arp A (LOCAL SAFE)** ergänzt: als **sicherer Clip-Arpeggiator** für die aktuelle AETERNA-Spur, ohne Playback-Core-Umbau.
- Arp A bietet jetzt **Pattern** (u. a. up/down/chords/random/flow/blossom/low&up/hi&down), **Rate** (1/1 bis 1/64), **Straight/Dotted/Triplets** und **16 editierbare Steps**.
- Pro Step vorhanden: **Transpose**, **Skip**, **Velocity** und **Gate Length 0–400%**.
- Lokale **Shuffle**-Option für Arp A ergänzt, inklusive Anzahl der betroffenen Steps.
- Arp A kann direkt als **neuen MIDI-Clip** auf der aktuellen AETERNA-Spur schreiben oder den **aktiven Clip überschreiben**.
- Rechtsklick-Kontextmenü auf **allen AETERNA-Knobs** erweitert: **Show Automation in Arranger** plus **Add Modulator** direkt auf den angeklickten Ziel-Knob.
- Neue lokale **Per-Knob-Mod-Profile** eingeführt: jeder AETERNA-Knob kann seinen eigenen gespeicherten Modulator-Zustand behalten, statt einen gemeinsamen Platzhalterzustand zu teilen.
- Lesbarkeit in AETERNA lokal verbessert: **größere Karten-/Hint-Schriften**, **größere Controls** und **deutlichere Signalfluss-Karten**.
- Umsetzung bleibt vollständig lokal in `pydaw/plugins/aeterna/aeterna_widget.py`; kein Eingriff in Arranger, Mixer, Transport, Audio Editor oder globalen Playback-Core.


## v0.0.20.340 — AETERNA Layer-Visibility + Qt Selection Guard

- **Layer-/Noise-Familienkarten** in AETERNA zeigen jetzt **Unison Voices** und **Sub Oktave** klarer direkt in den Karten und im Preview-Hinweis.
- **AETERNA Live-ARP Refresh** wurde lokal koalesziert, damit Checkbox-Klicks nicht mehrere direkte verschachtelte Refresh-Wellen durch die UI jagen.
- **ARP-Live-Sync** besitzt jetzt einen lokalen **Reentrancy-Guard** und emittiert Projekt-Refresh nur noch bei echten State-Änderungen.
- **TrackList**, **Arranger-TrackList** und **Automation-Lanes** wurden um kleine **Refresh-/Signalguards** ergänzt, damit `QListWidget`-Selektionen während Refresh/Restore nicht rekursiv `setCurrentRow`/`setCurrentItem` auslösen.
- Umsetzung bleibt vollständig lokal in AETERNA/UI; kein Eingriff in Playback-Core, Mixer, Transport oder Arranger-Engine.

## v0.0.20.377 — VST3 Editor Stability Fixes (2026-03-10)

**Bug 1 — `RuntimeError: wrapped C/C++ object of type QPushButton has been deleted`**
- Root cause: `_on_editor_process_finished()` and `_on_editor_process_error()` tried to
  call `btn.setText()` AFTER the widget (and its child QPushButton) was already destroyed
  by Qt — e.g. when the Device panel was closed while an editor was open.
- Fix in `fx_device_widgets.py`: All `btn.setText/setEnabled/setStyleSheet` calls wrapped
  in `try/except RuntimeError`. Same guard added to `_on_editor_stdout` ready-event handler.
  `_on_editor_process_error` now also catches RuntimeError from `_show_editor_error`.

**Bug 2 — `QProcess: Destroyed while process is still running`**
- Root cause: `closeEvent` called `proc.kill()` but did NOT disconnect QProcess signals first.
  After widget deletion, `finished` / `errorOccurred` signals still fired against the dead
  widget, causing the RuntimeError above as a secondary effect.
- Fix: `closeEvent` now disconnects ALL QProcess signals (`readyReadStandardOutput`,
  `finished`, `errorOccurred`) BEFORE terminating, using `terminate()` → `waitForFinished(500)`
  → `kill()` sequence.

**Bug 3 — Native editor param changes not reflected in PyDAW sliders (no movement)**
- Root cause: `_snapshot_params()` in `vst_gui_process.py` used `dir(plugin)` + `getattr()`
  to enumerate numeric attributes — completely bypassing pedalboard's official parameter API.
  This never returned actual plugin parameter values, so the `_ParamPoller` never emitted
  any `param` events.
- Fix: `_snapshot_params()` rewritten to use `plugin.parameters` dict
  (name → `AudioProcessorParameter`) and `param.raw_value` for current value.
  Fallback to `getattr(plugin, name)` only for older pedalboard builds without `raw_value`.

Files changed: `pydaw/audio/vst_gui_process.py`, `pydaw/ui/fx_device_widgets.py`

## v0.0.20.378 — VST3 Sliders + Audio-Params Fix (2026-03-10)

**Bug 1 — Alle VST3-Parameter erscheinen als Checkbox (keine Slider)**
- Root cause: `_extract_param_infos()` in vst3_host.py enthielt eine Heuristik:
  `if not is_bool and mx - mn <= 1.0 and mx == 1.0 and mn == 0.0: is_bool = True`
  Da pedalboard ALLE VST3-Parameter normalisiert auf [0.0, 1.0] meldet (minimum_value=0.0,
  maximum_value=1.0), wurde jeder kontinuierliche Parameter (time_ms, lpf_hz, feedback …)
  fälschlicherweise als Boolean klassifiziert und als Checkbox gerendert.
- Fix: Heuristik entfernt. Nur noch `param.is_boolean` aus pedalboard wird verwendet.

**Bug 2 — VST3-Plugins laden aber wirken sich nicht auf Audio aus**
- Root cause: `_apply_rt_params()` verwendete `setattr(plugin, name, val)` mit dem
  normalisierten 0-1 Wert aus dem RTParamStore. pedalboard's setattr() erwartet aber
  den *physikalischen* Wert (z.B. 500.0 für 500 ms). Das Setzen von 0.5 für "time_ms"
  ergab also 0.5 ms — nahezu Null, weshalb alle Plugins wirkungslos erschienen.
- Fix: `_apply_rt_params()` verwendet jetzt `plugin.parameters[name].raw_value = val`
  (normalisierter 0-1 Setter). Für Boolean-Params weiterhin setattr(plugin, name, True/False).
- Gleiches Fix in `get_current_values()` (raw_value statt getattr) und
  `vst_gui_process.py` `set_param`-Handler.

Files changed: `pydaw/audio/vst3_host.py`, `pydaw/audio/vst_gui_process.py`

## v0.0.20.379 — VST3 Editor In-Process: Echte Meter/Analyser (2026-03-10)

**Problem: Nativer Editor zeigt keine Pegel / Spectrum-Anzeige**
- Root cause: Der bisherige Subprocess-Ansatz lud eine SEPARATE Plugin-Instanz nur
  um die GUI anzuzeigen. Diese Instanz bekam niemals Audio → alle Meter/Analyser
  (Spectrum, VU, Loudness-Graph) zeigten nichts.

**Lösung: In-Process QThread (_VstInProcessEditorThread)**
- Neue Klasse `_VstInProcessEditorThread(QThread)` ruft `show_editor()` direkt auf
  dem Plugin-Objekt der `Vst3Fx`-Instanz auf, die echtes Audio prozessiert.
- Zugriffspfad: `services.audio_engine._track_audio_fx_map[track_id].devices`
  → `Vst3Fx` mit passendem `device_id` → `._plugin` (pedalboard plugin object)
- Selbe Plugin-Instanz = native Editor sieht den echten Audio-Datenstrom → Meter ✓

**Bidirektionale Param-Sync im In-Process-Modus**
- `_editor_poll_timer` (80ms): liest `plugin.parameters[name].raw_value`,
  vergleicht mit RT-Store, ruft `_apply_param_from_editor()` bei Änderungen.

**Fallback**
- `_get_vst3_fx_instance()` gibt None zurück wenn Engine nicht erreichbar →
  automatischer Fallback auf den bisherigen QProcess-Subprocess (unverändert).

**Kein Code gelöscht**: Alle bestehenden Subprocess-Methoden bleiben vollständig
erhalten als Fallback-Pfad.

Files changed: `pydaw/ui/fx_device_widgets.py` (neuer Thread, neue Methoden,
               erweiterter closeEvent)

## v0.0.20.490 — SmartDrop: Morphing-Guard Runtime-Snapshot-Handles (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py` baut jetzt konkrete `runtime_snapshot_handles` samt `handle_key`, `handle_kind`, `owner_scope`, `owner_ids`, `capture_state` und `capture_stub` auf.
- Die Apply-Readiness enthaelt jetzt einen zusaetzlichen Check fuer bereits vorverdrahtete Runtime-Snapshot-Handles.
- `pydaw/ui/main_window.py` zeigt einen neuen Abschnitt **Runtime-Snapshot-Handle-Vorschau** und fuehrt die Handle-Zusammenfassung auch im Guard-Dialog-Infotext.
- Kleiner UI-Hotfix nebenbei: Variablen-Ueberschattung im Guard-Dialog bereinigt, damit `Zielspur:` wieder sicher die eigentliche Spurzusammenfassung anzeigt.



## v0.0.20.495 — SmartDrop: Morphing-Guard Dry-Run Runner (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py` koppelt das Snapshot-Bundle jetzt an einen read-only Dry-Run-/Transaktions-Runner mit `runner_key`, Capture-/Restore-/Rollback-Sequenzen und `phase_results`.
- Die Apply-Readiness enthaelt jetzt einen zusaetzlichen Check fuer den vorbereiteten Dry-Run-Runner.
- `pydaw/ui/main_window.py` zeigt einen neuen Abschnitt **Read-only Dry-Run / Transaktions-Runner** und fuehrt die Dry-Run-Zusammenfassung im Guard-Dialog-Infotext.

## v0.0.20.496 — SmartDrop: Morphing-Guard Safe-Runner Dispatch (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py` dispatcht Capture-/Restore-Phasen jetzt ueber konkrete read-only Preview-Funktionen je Snapshot-Typ (`capture_track_state_snapshot`, `capture_routing_snapshot`, `restore_*` usw.) statt nur ueber generische Platzhaltertexte.
- Der Dry-Run-Bericht enthaelt jetzt zusaetzlich `capture_method_calls`, `restore_method_calls` und `runner_dispatch_summary`, sodass sichtbar ist, welche Safe-Runner-Methoden bereits zentral vorverdrahtet sind.
- `pydaw/ui/main_window.py` zeigt diese neuen Safe-Runner-Dispatch-Infos im bestehenden Block **Read-only Dry-Run / Transaktions-Runner** mit an.



## v0.0.20.498 — SmartDrop: Morphing-Guard State-Carriers (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py` koppelt Runtime-Stubs jetzt an konkrete read-only Zustandstraeger / State-Carrier mit eigener Payload-Vorschau.
- Der Dry-Run ruft jetzt `capture_state_preview()` / `restore_state_preview()` / `rollback_state_preview()` ueber die Carrier auf und fuehrt `state_carrier_calls` plus `state_carrier_summary` im Plan mit.
- `pydaw/ui/main_window.py` zeigt die neue Ebene als **Runtime-Zustandstraeger / State-Carrier** an und fuehrt die Carrier-Infos auch im Dry-Run-Detailblock.

## v0.0.20.501 — Runtime-State-Slots / Snapshot-State-Speicher

- Runtime-State-Halter wurden an konkrete read-only **Runtime-State-Slots / Snapshot-State-Speicher** gekoppelt.
- Der Safe-Runner nutzt jetzt `capture_slot_preview()` / `restore_slot_preview()` / `rollback_slot_preview()` direkt ueber die neuen Slot-Klassen.
- Der Guard-Dialog zeigt die neue Slot-Ebene sowie die neuen Dry-Run-Dispatch-Infos sichtbar an.

## v0.0.20.503 — Runtime-State-Registries / Handle-Speicher

- Runtime-State-Stores wurden an konkrete read-only **Runtime-State-Registries / Handle-Speicher** gekoppelt.
- Der Safe-Runner nutzt jetzt `capture_registry_preview()` / `restore_registry_preview()` / `rollback_registry_preview()` direkt ueber die neuen Registry-Klassen.
- Der Guard-Dialog zeigt die neue Registry-Ebene sowie die neuen Dry-Run-Dispatch-Infos sichtbar an.
