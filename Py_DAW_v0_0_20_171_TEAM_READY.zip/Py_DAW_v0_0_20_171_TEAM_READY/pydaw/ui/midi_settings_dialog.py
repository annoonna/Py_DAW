"""MIDI Settings dialog (v0.0.14)."""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QComboBox,
    QPushButton,
    QMessageBox,
)

from pydaw.services.midi_service import MidiService


class MidiSettingsDialog(QDialog):
    def __init__(self, midi: MidiService, parent=None):
        super().__init__(parent)
        self.setWindowTitle("MIDI Settings")
        self.setModal(True)
        self.midi = midi

        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("MIDI Input:"))
        self.cmb_in = QComboBox()
        self.cmb_in.setMinimumWidth(360)
        layout.addWidget(self.cmb_in)

        row = QHBoxLayout()
        self.btn_refresh = QPushButton("Refresh")
        self.btn_connect = QPushButton("Connect")
        self.btn_disconnect = QPushButton("Disconnect")
        row.addWidget(self.btn_refresh)
        row.addStretch(1)
        row.addWidget(self.btn_disconnect)
        row.addWidget(self.btn_connect)
        layout.addLayout(row)

        row2 = QHBoxLayout()
        row2.addStretch(1)
        self.btn_ok = QPushButton("OK")
        row2.addWidget(self.btn_ok)
        layout.addLayout(row2)

        self.btn_ok.clicked.connect(self.accept)
        self.btn_refresh.clicked.connect(self.refresh)
        self.btn_connect.clicked.connect(self._connect)
        self.btn_disconnect.clicked.connect(self._disconnect)

        self.refresh()

    def refresh(self) -> None:
        self.cmb_in.clear()
        ins = self.midi.list_inputs()
        if not ins:
            self.cmb_in.addItem("(keine MIDI Inputs gefunden)")
            self.cmb_in.setEnabled(False)
        else:
            self.cmb_in.setEnabled(True)
            self.cmb_in.addItems(ins)
            cur = self.midi.current_input()
            if cur and cur in ins:
                self.cmb_in.setCurrentText(cur)

    def _connect(self) -> None:
        if not self.cmb_in.isEnabled():
            QMessageBox.information(self, "MIDI", "Keine MIDI Inputs verfügbar.")
            return
        name = self.cmb_in.currentText()
        ok = self.midi.connect_input(name)
        if ok:
            QMessageBox.information(self, "MIDI", f"Verbunden: {name}")
        else:
            QMessageBox.warning(self, "MIDI", "Verbinden fehlgeschlagen (siehe Statusleiste).")

    def _disconnect(self) -> None:
        self.midi.disconnect_input()
        QMessageBox.information(self, "MIDI", "MIDI Input getrennt.")
