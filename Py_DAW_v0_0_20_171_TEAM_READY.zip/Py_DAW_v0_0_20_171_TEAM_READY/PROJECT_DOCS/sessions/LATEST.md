# Session: v0.0.20.171 — Ctrl+J Varianten Fix (Alt-Mod) + PyQt6 QShortcut Import

## Kontext
User-Report:
- Im Clip-Launcher Audio Editor erschien bei **Ctrl+J / Shift+Ctrl+J / Alt+Ctrl+J / Ctrl+Shift+Alt+J** nur **„Zusammenführen fehlgeschlagen“**.
- Zusätzlich schlug der Start in einigen Umgebungen mit **ImportError: cannot import name 'QShortcut' from PyQt6.QtWidgets** fehl.

## Root Cause
1) Im Shortcut-Handler (`handle_key_event`) fehlte die Modifikator-Variable `alt` → **NameError** in der Ctrl+J-Logik.
2) `QShortcut` liegt in PyQt6 unter **PyQt6.QtGui**, nicht `QtWidgets`.

## Fix (safe)
- `alt = bool(mods & Qt.KeyboardModifier.AltModifier)` ergänzt.
- `QShortcut` Import auf `PyQt6.QtGui` umgestellt.
- Consolidate-Behavior selbst bleibt unverändert (Default bleibt bar-anchored).

## Testplan
1) Clip-Launcher Audio Editor: Lasso → **Ctrl+J** → Bounce-Consolidate funktioniert.
2) **Shift+Ctrl+J** → Trim.
3) **Alt+Ctrl+J** → Handles.
4) **Ctrl+Shift+Alt+J** → Join (keep events).
5) App startet ohne ImportError.

## Geänderte Dateien
- `pydaw/ui/audio_editor/audio_event_editor.py`
- `VERSION`, `pydaw/version.py`, `pydaw/model/project.py`
