# -*- coding: utf-8 -*-
"""MidiManager (v0.0.20.x)

Ziel
----
Ein zentraler MIDI-Manager, der:
- verfügbare MIDI-Geräte erkennt (mido/python-rtmidi)
- eingehende MIDI Messages nicht-blockierend ins Qt-Eventloop forwardet
- Live-Monitoring + Recording in den aktiven MIDI-Clip (Transport-Sync)
- Live-Visualisierung (Ghost Notes) via Qt-Signale
- Panic / All Notes Off (No-Hang)

Hinweis:
Dieses Modul ist bewusst *MVP-sicher* gehalten:
- keine exklusiven Locks auf GUI-Daten aus dem MIDI-Thread
- Processing der MIDI-Messages im Qt-Thread via Queue+QTimer
"""

from __future__ import annotations

import threading
import time
import queue
from dataclasses import dataclass
from typing import Callable, Optional, List, Dict, Tuple

from PyQt6.QtCore import QObject, pyqtSignal, QTimer

try:
    import mido  # type: ignore
except Exception:  # noqa: BLE001
    mido = None  # type: ignore


@dataclass
class _ActiveNote:
    clip_id: str
    track_id: str
    channel: int
    pitch: int
    velocity: int
    start_global_beat: float
    start_clip_beat: float
    start_time: float


class MidiManager(QObject):
    # Backwards-compat status text
    message_received = pyqtSignal(str)
    # Raw message object (mido.Message) for services like MidiMappingService
    message_obj = pyqtSignal(object)

    # Live routing outputs (Bitwig-like triple output – at least for editors)
    live_note_on = pyqtSignal(str, str, int, int, int, float)   # clip_id, track_id, pitch, velocity, channel, start_clip_beats
    live_note_off = pyqtSignal(str, str, int, int)              # clip_id, track_id, pitch, channel

    # Panic / No-Hang
    panic = pyqtSignal(str)  # reason text

    def __init__(
        self,
        *,
        project_service=None,
        transport=None,
        status_cb: Callable[[str], None] | None = None,
    ):
        super().__init__()
        self._status = status_cb or (lambda _m: None)

        self._project = project_service
        self._transport = transport

        # --- Live monitoring vs recording ---
        # Monitor/thru: hear notes on an armed track even without recording.
        # Recording: write notes into the active MIDI clip ONLY when enabled
        # (UI: Piano Roll "Record" toggle). This matches typical DAW behavior.
        self._midi_record_enabled: bool = False

        self._lock = threading.Lock()
        self._stop = False
        self._thread: Optional[threading.Thread] = None

        self._in_name: str = ""
        self._in_port = None

        # MIDI thread -> Qt thread queue
        self._queue: "queue.Queue[object]" = queue.Queue()
        self._drain_timer = QTimer(self)
        self._drain_timer.setInterval(5)  # low-latency drain
        self._drain_timer.timeout.connect(self._drain_queue)
        self._drain_timer.start()

        # active notes for duration calculation (Note Lifetime)
        # key: (track_id, channel, pitch) -> stack[list]
        self._active_notes: Dict[Tuple[str, int, int], List[_ActiveNote]] = {}

        # Transport stop -> panic
        try:
            if self._transport is not None and hasattr(self._transport, "playing_changed"):
                self._transport.playing_changed.connect(self._on_transport_playing_changed)
        except Exception:
            pass

    # ---------------- device enumeration ----------------

    def list_inputs(self) -> List[str]:
        if mido is None:
            return []
        try:
            return list(mido.get_input_names())
        except Exception:  # noqa: BLE001
            return []

    def list_outputs(self) -> List[str]:
        if mido is None:
            return []
        try:
            return list(mido.get_output_names())
        except Exception:  # noqa: BLE001
            return []

    def current_input(self) -> str:
        return self._in_name

    # ---------------- live record toggle ----------------

    def set_record_enabled(self, enabled: bool) -> None:
        """Enable/disable MIDI recording into the active clip.

        When disabled, live MIDI still passes through (monitoring) but nothing
        is committed to the project/clip. UI hook: Piano Roll "Record" button.
        """
        self._midi_record_enabled = bool(enabled)
        try:
            self._status(
                "MIDI Record: ON (schreibt in Clip)" if self._midi_record_enabled
                else "MIDI Record: OFF (nur Monitoring)"
            )
        except Exception:
            pass

    def is_record_enabled(self) -> bool:
        return bool(self._midi_record_enabled)

    # ---------------- connect / disconnect ----------------

    def connect_input(self, name: str) -> bool:
        """Connect to a MIDI input port (best effort)."""
        if mido is None:
            self._status("MIDI: mido nicht verfügbar (pip install mido python-rtmidi).")
            return False

        self.disconnect_input()
        try:
            port = mido.open_input(str(name))
        except Exception as exc:  # noqa: BLE001
            self._status(f"MIDI: Input konnte nicht geöffnet werden: {exc}")
            return False

        with self._lock:
            self._in_port = port
            self._in_name = str(name)
            self._stop = False

        self._status(f"MIDI: Input verbunden: {name}")
        self._start_thread()
        return True

    def disconnect_input(self) -> None:
        with self._lock:
            self._stop = True
            port = self._in_port
            self._in_port = None
            self._in_name = ""

        # flush active notes (avoid hangs)
        try:
            self.panic_all("disconnect_input")
        except Exception:
            pass

        if port is not None:
            try:
                port.close()
            except Exception:
                pass

        if self._thread is not None:
            try:
                self._thread.join(timeout=0.5)
            except Exception:
                pass
            self._thread = None

    def shutdown(self) -> None:
        self.disconnect_input()

    # ---------------- panic / no hang ----------------

    def panic_all(self, reason: str = "panic") -> None:
        """Clear internal active-notes and notify listeners."""
        with self._lock:
            self._active_notes.clear()
        try:
            self.panic.emit(str(reason))
        except Exception:
            pass
        try:
            self.message_received.emit("MIDI: PANIC / All Notes Off")
        except Exception:
            pass

    def _on_transport_playing_changed(self, playing: bool) -> None:
        # When transport stops we want to avoid hanging notes.
        if not bool(playing):
            self.panic_all("transport_stop")

    # ---------------- internal threading ----------------

    def _start_thread(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        # Poll the input port. mido ports are iterable; polling avoids blocking shutdown.
        while True:
            with self._lock:
                if self._stop:
                    return
                port = self._in_port
            if port is None:
                return

            try:
                for msg in port.iter_pending():
                    try:
                        self._queue.put(msg)
                    except Exception:
                        pass
            except Exception as exc:  # noqa: BLE001
                self._status(f"MIDI: Fehler beim Lesen: {exc}")
                time.sleep(0.2)

            time.sleep(0.001)  # low latency

    # ---------------- Qt thread processing ----------------

    def _drain_queue(self) -> None:
        # Process many messages per tick to avoid lag.
        for _ in range(128):
            try:
                msg = self._queue.get_nowait()
            except Exception:
                return
            try:
                self._handle_message(msg)
            except Exception:
                # never crash the GUI
                continue

    def _handle_message(self, msg) -> None:  # noqa: ANN001
        # broadcast raw message for other services
        try:
            self.message_obj.emit(msg)
        except Exception:
            pass

        # short status text (optional)
        try:
            self.message_received.emit(f"MIDI: {getattr(msg, 'type', '')} {msg}")
        except Exception:
            pass

        mtype = str(getattr(msg, "type", "") or "")
        if not mtype:
            return

        # Note-on/off normalization
        if mtype == "note_on" and int(getattr(msg, "velocity", 0)) <= 0:
            mtype = "note_off"

        if mtype not in ("note_on", "note_off"):
            return

        pitch = int(getattr(msg, "note", 0))
        vel = int(getattr(msg, "velocity", 0))
        ch = int(getattr(msg, "channel", 0))

        # Determine routing target.
        # Monitoring should work with an armed track even if no clip is active.
        # Recording still requires an active MIDI clip (handled later).
        target = self._resolve_target()
        if target is None:
            return
        clip_id, track_id, clip_start, clip_offset = target

        # Global beat from master clock
        gbeat = 0.0
        try:
            if self._transport is not None:
                gbeat = float(self._transport.get_beat())
        except Exception:
            gbeat = 0.0

        # Clip-relative position for record + editor ghost.
        clip_beat = float(gbeat - clip_start + clip_offset)
        if clip_beat < 0.0:
            clip_beat = 0.0

        if mtype == "note_on":
            self._on_note_on(clip_id, track_id, ch, pitch, vel, gbeat, clip_beat)
        else:
            self._on_note_off(clip_id, track_id, ch, pitch, gbeat)

    def _resolve_target(self) -> Optional[tuple[str, str, float, float]]:
        """Return (clip_id, track_id, clip_start_beats, clip_offset_beats) or None."""
        ps = self._project
        if ps is None:
            return None

        # Which track is armed?
        try:
            tracks = list(getattr(ps.ctx.project, "tracks", []) or [])
        except Exception:
            tracks = []
        armed = [t for t in tracks if bool(getattr(t, "record_arm", False))]
        sel_tid = ""
        try:
            sel_tid = str(getattr(ps, "selected_track_id", "") or "")
        except Exception:
            sel_tid = ""

        track = None
        if armed:
            # Prefer selected track if it is armed; else first armed.
            track = next((t for t in armed if str(getattr(t, "id", "")) == sel_tid), None) or armed[0]
        else:
            # No armed track -> do not record/route by default (Bitwig-like).
            return None

        track_id = str(getattr(track, "id", "") or "")
        if not track_id:
            return None

        # Active clip is optional for monitoring.
        try:
            clip_id = str(ps.active_clip_id() or "")
        except Exception:
            clip_id = ""

        if not clip_id:
            # Monitoring-only mode (no active clip)
            return ("", track_id, 0.0, 0.0)

        clip = None
        try:
            for c in list(getattr(ps.ctx.project, "clips", []) or []):
                if str(getattr(c, "id", "")) == clip_id:
                    clip = c
                    break
        except Exception:
            clip = None

        if clip is None:
            return ("", track_id, 0.0, 0.0)
        if str(getattr(clip, "kind", "")) != "midi":
            return ("", track_id, 0.0, 0.0)
        if str(getattr(clip, "track_id", "")) != track_id:
            return ("", track_id, 0.0, 0.0)

        try:
            clip_start = float(getattr(clip, "start_beats", 0.0))
        except Exception:
            clip_start = 0.0
        try:
            clip_offset = float(getattr(clip, "offset_beats", 0.0))
        except Exception:
            clip_offset = 0.0

        return (clip_id, track_id, clip_start, clip_offset)

    def _on_note_on(
        self,
        clip_id: str,
        track_id: str,
        channel: int,
        pitch: int,
        velocity: int,
        start_global_beat: float,
        start_clip_beat: float,
    ) -> None:
        key = (str(track_id), int(channel), int(pitch))
        an = _ActiveNote(
            clip_id=str(clip_id),
            track_id=str(track_id),
            channel=int(channel),
            pitch=int(pitch),
            velocity=int(max(0, min(127, velocity))),
            start_global_beat=float(start_global_beat),
            start_clip_beat=float(start_clip_beat),
            start_time=float(time.time()),
        )
        with self._lock:
            self._active_notes.setdefault(key, []).append(an)

        # Live ghost for editors
        try:
            self.live_note_on.emit(str(clip_id), str(track_id), int(pitch), int(velocity), int(channel), float(start_clip_beat))
        except Exception:
            pass

    def _on_note_off(
        self,
        clip_id: str,
        track_id: str,
        channel: int,
        pitch: int,
        end_global_beat: float,
    ) -> None:
        key = (str(track_id), int(channel), int(pitch))
        an: Optional[_ActiveNote] = None
        with self._lock:
            lst = self._active_notes.get(key, [])
            if lst:
                an = lst.pop(0)
            if not lst and key in self._active_notes:
                self._active_notes.pop(key, None)

        # Remove live ghost immediately (even if we can't record)
        try:
            self.live_note_off.emit(str(clip_id), str(track_id), int(pitch), int(channel))
        except Exception:
            pass

        if an is None:
            return

        # Duration calculation (Transport-Sync + Note Lifetime)
        dur_beats = 0.25
        try:
            playing = bool(getattr(self._transport, "playing", False)) if self._transport is not None else False
            if playing:
                dur_beats = float(end_global_beat) - float(an.start_global_beat)
            else:
                # fallback to wall-clock
                bpm = float(getattr(self._transport, "bpm", 120.0)) if self._transport is not None else 120.0
                dur_beats = (float(time.time()) - float(an.start_time)) * (float(bpm) / 60.0)
        except Exception:
            dur_beats = 0.25
        if dur_beats <= 0.0:
            dur_beats = 0.0625  # 1/16 minimum
        if dur_beats > 64.0:
            dur_beats = 64.0

        # If MIDI record is disabled, do NOT write into the clip.
        # Live monitoring is handled via live_note_on/off signals.
        if not bool(self._midi_record_enabled):
            return

        # Recording needs a valid active clip id.
        if not str(getattr(an, "clip_id", "") or ""):
            return

        # Commit note into the active clip (recording-ready)
        ps = self._project
        if ps is None:
            return
        try:
            ps.add_midi_note(
                str(an.clip_id),
                pitch=int(an.pitch),
                start_beats=float(an.start_clip_beat),
                length_beats=float(dur_beats),
                velocity=int(an.velocity),
            )
        except Exception:
            # never crash
            return
