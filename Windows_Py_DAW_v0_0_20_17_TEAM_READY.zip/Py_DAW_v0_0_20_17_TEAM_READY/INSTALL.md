# 📦 ChronoScaleStudio / Py_DAW – Installation

## System Requirements
- **Python:** 3.10+ (empfohlen: **3.13**)
- **RAM:** 8 GB+ (empfohlen 16 GB+ für große Sample-Libraries)
- **Audio:**
  - **Windows:** WASAPI (über `sounddevice` / PortAudio)
  - **Linux:** PipeWire-JACK oder JACK (optional zusätzlich `qpwgraph`)

---

## ✅ Quick Install (Windows 10/11)

### 1) ZIP entpacken
Entpacke die ZIP in einen Ordner, z.B.:
`C:\Users\<du>\Downloads\Py_DAW\`

### 2) Virtualenv erstellen + aktivieren
```bat
cd Py_DAW_v0_0_20_17_TEAM_READY
py -m venv .venv
.venv\Scripts\activate
```

### 3) Dependencies installieren
```bat
pip install --upgrade pip
pip install -r requirements.txt
```

### 4) Start
```bat
python main.py
```

### Windows Audio (WASAPI) – Optionen
Standard: **WASAPI** wird automatisch bevorzugt.

Optional:
- **Host API wählen:**
  - `PYDAW_SD_HOSTAPI=wasapi` (default)
  - `PYDAW_SD_HOSTAPI=asio`
  - `PYDAW_SD_HOSTAPI=directsound`
  - `PYDAW_SD_HOSTAPI=mme`
- **WASAPI Exclusive Mode** (niedrigere Latenz, kann andere Apps blockieren):
  - `PYDAW_WASAPI_EXCLUSIVE=1`

Beispiel:
```bat
set PYDAW_SD_HOSTAPI=wasapi
set PYDAW_WASAPI_EXCLUSIVE=0
python main.py
```

### Windows Rendering (Direct3D)
Qt wird in `main.py` vor dem PyQt6-Import so konfiguriert, dass **ANGLE → D3D11** genutzt wird.

Optional:
- `CHRONOSCALE_D3D=d3d11` (default)
- `CHRONOSCALE_D3D=d3d12` (nur wenn du es testen willst)

---

## ✅ Quick Install (Linux)

```bash
cd Py_DAW_v0_0_20_17_TEAM_READY
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
python3 main.py
```

### PipeWire-JACK / JACK (optional)
Wenn du möchtest, dass PyDAW als JACK-Client in `qpwgraph` erscheint:
```bash
export PYDAW_ENABLE_JACK=1
python3 main.py
```

---

## Troubleshooting

### ModuleNotFoundError
```bash
pip install -r requirements.txt
```

### Knackser / Dropouts (Windows)
- Buffer erhöhen (z.B. 256 → 512)
- WASAPI Exclusive deaktivieren (falls aktiv)
- `PYDAW_SD_HOSTAPI=wasapi` nutzen (oder ASIO, falls vorhanden)

---
