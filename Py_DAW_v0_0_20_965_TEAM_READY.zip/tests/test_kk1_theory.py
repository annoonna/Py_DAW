"""Unit tests for KK1: Musiktheorie-Engine (v0.0.20.958).

Tests: Scales, Chords, Voice Leading, Cadences, Key Detection, Modulation, Generalbass.
"""

from __future__ import annotations
import os, sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pydaw.services.ki_composition_theory import (
    Scale, Chord, VoiceLeader, CadenceEngine, KeyDetector,
    Modulator, GeneralBass,
    note_name_to_pc, pc_to_note_name, midi_to_name, name_to_midi,
    interval_name, is_consonant, is_perfect_consonance,
    generate_progression, get_all_scale_names, get_all_chord_qualities,
    SCALE_INTERVALS,
)


class TestNoteUtils:
    def test_note_to_pc(self):
        assert note_name_to_pc("C") == 0
        assert note_name_to_pc("A") == 9

    def test_midi_to_name(self):
        assert midi_to_name(60) == "C4"
        assert midi_to_name(69) == "A4"

    def test_enharmonic(self):
        assert note_name_to_pc("Db") == note_name_to_pc("C#")


class TestIntervals:
    def test_consonance(self):
        assert is_consonant(7)       # P5
        assert not is_consonant(6)   # Tritone

    def test_perfect(self):
        assert is_perfect_consonance(0)
        assert not is_perfect_consonance(4)


class TestScales:
    def test_c_major(self):
        s = Scale("C", "major")
        assert s.get_notes() == [60, 62, 64, 65, 67, 69, 71]

    def test_church_modes(self):
        for m in ["dorian", "phrygian", "lydian", "mixolydian", "aeolian", "locrian"]:
            s = Scale("D", m)
            assert len(s.intervals) == 7

    def test_contains(self):
        s = Scale("C", "major")
        assert s.contains(64)       # E
        assert not s.contains(61)   # C#

    def test_relative(self):
        assert Scale("C", "major").relative().root == "A"

    def test_parallel(self):
        assert Scale("C", "major").parallel().mode == "minor"

    def test_alias(self):
        assert Scale("C", "dur").mode == "major"

    def test_all_scales(self):
        assert len(get_all_scale_names()) >= 20

    def test_degree(self):
        s = Scale("C", "major")
        assert s.degree_to_midi(1) == 60
        assert s.degree_to_midi(5) == 67

    def test_serialization(self):
        s = Scale("D", "dorian")
        s2 = Scale.from_dict(s.to_dict())
        assert s2.root == "D" and s2.mode == "dorian"


class TestChords:
    def test_c_major(self):
        c = Chord("C", "major")
        assert 60 in c.get_notes(4) and 64 in c.get_notes(4)

    def test_name(self):
        assert Chord("D", "minor").name == "Dm"
        assert Chord("G", "dom7").name == "G7"
        assert Chord("E", "power").name == "E5"

    def test_from_scale(self):
        s = Scale("C", "major")
        assert Chord.from_scale(s, 1).quality == "major"
        assert Chord.from_scale(s, 2).quality == "minor"
        assert Chord.from_scale(s, 5, seventh=True).quality == "dom7"

    def test_from_roman(self):
        key = Scale("C", "major")
        c = Chord.from_roman("V7", key)
        assert c.root == "G" and c.quality == "dom7"

    def test_all_qualities(self):
        for q in get_all_chord_qualities():
            assert len(Chord("C", q["quality"]).get_notes()) >= 2


class TestVoiceLeading:
    def test_parallel_fifths(self):
        issues = VoiceLeader.check_parallels(60, 62, 67, 69)
        assert any("Quinte" in i for i in issues)

    def test_contrary_motion(self):
        assert VoiceLeader.motion_type(60, 62, 67, 65) == "contrary"

    def test_leading_tone(self):
        assert VoiceLeader.resolve_leading_tone(71, Scale("C", "major")) == 72


class TestCadences:
    def test_authentic(self):
        cad = CadenceEngine(Scale("C", "major")).authentic()
        assert len(cad.chords) == 2 and "V" in cad.roman

    def test_all_cadences(self):
        assert len(CadenceEngine(Scale("D", "minor")).all_cadences()) == 7

    def test_picardy(self):
        cad = CadenceEngine(Scale("A", "minor")).picardy()
        assert cad.chords[-1].quality == "major"


class TestKeyDetection:
    def test_c_major(self):
        # Use 2 octaves to give stronger signal
        notes = [60, 62, 64, 65, 67, 69, 71, 72, 64, 67, 60]
        results = KeyDetector.detect(notes, include_modes=False)
        top3 = [(r[0], r[1]) for r in results[:3]]
        assert ("C", "major") in top3


class TestModulation:
    def test_pivots(self):
        pivots = Modulator.find_pivot_chords(Scale("C", "major"), Scale("G", "major"))
        assert len(pivots) > 0

    def test_distance(self):
        assert Modulator.distance(Scale("C", "major"), Scale("G", "major")) == 1
        assert Modulator.distance(Scale("C", "major"), Scale("F#", "major")) == 6


class TestGeneralBass:
    def test_root_position(self):
        assert len(GeneralBass.realize(48, "")) == 3

    def test_seventh(self):
        assert len(GeneralBass.realize(48, "7")) == 4


class TestProgressions:
    def test_all_patterns(self):
        key = Scale("C", "major")
        for p in ["pop", "blues12", "jazz", "baroque", "romantic",
                   "modal", "pachelbel", "gospel", "andalusian", "circle"]:
            assert len(generate_progression(key, p)) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
