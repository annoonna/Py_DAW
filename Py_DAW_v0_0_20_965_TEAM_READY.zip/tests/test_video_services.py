"""Unit tests for Video Services VE11–VE18 + VK Arranger (v0.0.20.954).

Tests run WITHOUT ffmpeg, Whisper, or video files.
All services are tested via their data models and logic.

Coverage:
- VE11: Transcript/Word data models, cut regions, SRT/VTT export
- VE12: Smart Cut (filler detection, pause detection, repetitions, highlight)
- VE13: Mood Matcher (film look presets, filter generation)
- VE14: GPU Decode (backend detection, filter strings)
- VE15: Multi-Cam (sync, switch, edit list)
- VE16: Interchange Export (EDL, XML timecodes)
- VE17: Immersive Audio (spatial positions, ambisonics)
- VE18: Cloud Collab (comments, versions, proxy)
- VK: Arranger integration (scene markers, auto-duck, mood suggestions)
"""

from __future__ import annotations

import json
import math
import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ═══════════════════════════════════════════════════════════════
# VE11: Whisper / Transcript
# ═══════════════════════════════════════════════════════════════

class TestTranscript:
    def test_word_creation(self):
        from pydaw.services.video_whisper_service import TranscriptWord
        w = TranscriptWord(word="Hello", start=1.0, end=1.5, confidence=0.9)
        assert w.word == "Hello"
        assert w.duration == pytest.approx(0.5)
        assert w.word_id  # auto-generated
        assert not w.deleted

    def test_word_serialization(self):
        from pydaw.services.video_whisper_service import TranscriptWord
        w = TranscriptWord(word="Test", start=0.0, end=0.5, confidence=0.8)
        d = w.to_dict()
        w2 = TranscriptWord.from_dict(d)
        assert w2.word == "Test"
        assert w2.start == 0.0
        assert w2.confidence == 0.8

    def test_transcript_delete_word(self):
        from pydaw.services.video_whisper_service import (
            Transcript, TranscriptSegment, TranscriptWord)
        w1 = TranscriptWord(word="Hello", start=0.0, end=0.5, confidence=0.9)
        w2 = TranscriptWord(word="World", start=0.6, end=1.0, confidence=0.9)
        seg = TranscriptSegment(words=[w1, w2], start=0.0, end=1.0)
        t = Transcript(segments=[seg], duration=1.0)

        assert len(t.active_words) == 2
        assert t.delete_word(w1.word_id)
        assert len(t.active_words) == 1
        assert t.active_words[0].word == "World"

    def test_cut_regions(self):
        from pydaw.services.video_whisper_service import (
            Transcript, TranscriptSegment, TranscriptWord)
        w1 = TranscriptWord(word="A", start=0.0, end=0.5, confidence=0.9, deleted=True)
        w2 = TranscriptWord(word="B", start=0.6, end=1.0, confidence=0.9)
        w3 = TranscriptWord(word="C", start=1.1, end=1.5, confidence=0.9, deleted=True)
        seg = TranscriptSegment(words=[w1, w2, w3], start=0.0, end=1.5)
        t = Transcript(segments=[seg], duration=2.0)

        cuts = t.get_cut_regions()
        assert len(cuts) == 2
        assert cuts[0] == (0.0, 0.5)
        assert cuts[1] == (1.1, 1.5)

    def test_keep_regions(self):
        from pydaw.services.video_whisper_service import (
            Transcript, TranscriptSegment, TranscriptWord)
        w1 = TranscriptWord(word="X", start=0.0, end=0.5, confidence=0.9, deleted=True)
        w2 = TranscriptWord(word="Y", start=0.6, end=1.5, confidence=0.9)
        seg = TranscriptSegment(words=[w1, w2], start=0.0, end=1.5)
        t = Transcript(segments=[seg], duration=2.0)

        keeps = t.get_keep_regions()
        assert len(keeps) == 1  # 0.5–2.0 (after deleted word to end)
        assert keeps[0][0] == pytest.approx(0.5)
        assert keeps[0][1] == pytest.approx(2.0)

    def test_stub_transcript(self):
        from pydaw.services.video_whisper_service import _generate_stub_transcript
        t = _generate_stub_transcript("/fake/video.mp4", 10.0)
        assert t.duration == 10.0
        assert len(t.segments) == 2  # 10s / 5s per segment
        assert len(t.all_words) > 0

    def test_full_text(self):
        from pydaw.services.video_whisper_service import (
            Transcript, TranscriptSegment, TranscriptWord)
        w1 = TranscriptWord(word="Hello", start=0.0, end=0.5, confidence=0.9)
        w2 = TranscriptWord(word="World", start=0.6, end=1.0, confidence=0.9)
        seg = TranscriptSegment(words=[w1, w2])
        t = Transcript(segments=[seg])
        assert t.full_text == "Hello World"


# ═══════════════════════════════════════════════════════════════
# VE11: Subtitle Export
# ═══════════════════════════════════════════════════════════════

class TestSubtitleExport:
    def test_srt_time_format(self):
        from pydaw.services.video_subtitle_export import _format_srt_time
        assert _format_srt_time(0.0) == "00:00:00,000"
        assert _format_srt_time(61.5) == "00:01:01,500"
        assert _format_srt_time(3661.123) == "01:01:01,123"

    def test_vtt_time_format(self):
        from pydaw.services.video_subtitle_export import _format_vtt_time
        assert _format_vtt_time(0.0) == "00:00:00.000"
        assert _format_vtt_time(61.5) == "00:01:01.500"

    def test_srt_export(self):
        from pydaw.services.video_whisper_service import (
            Transcript, TranscriptSegment, TranscriptWord)
        from pydaw.services.video_subtitle_export import export_srt
        w1 = TranscriptWord(word="Hello", start=0.0, end=0.5, confidence=0.9)
        w2 = TranscriptWord(word="World", start=0.6, end=1.0, confidence=0.9)
        seg = TranscriptSegment(words=[w1, w2], start=0.0, end=1.0)
        t = Transcript(segments=[seg])

        with tempfile.NamedTemporaryFile(suffix=".srt", delete=False) as f:
            path = f.name
        try:
            assert export_srt(t, path)
            content = open(path).read()
            assert "00:00:00,000" in content
            assert "Hello World" in content
        finally:
            os.unlink(path)


# ═══════════════════════════════════════════════════════════════
# VE12: Smart Cut
# ═══════════════════════════════════════════════════════════════

class TestSmartCut:
    def _make_transcript(self):
        from pydaw.services.video_whisper_service import (
            Transcript, TranscriptSegment, TranscriptWord)
        words = [
            TranscriptWord(word="Ich", start=0.0, end=0.3, confidence=0.9),
            TranscriptWord(word="ähm", start=0.4, end=0.6, confidence=0.8),
            TranscriptWord(word="denke", start=0.7, end=1.0, confidence=0.9),
            TranscriptWord(word="also", start=1.1, end=1.3, confidence=0.7),
            TranscriptWord(word="das", start=2.5, end=2.7, confidence=0.9),  # pause before
            TranscriptWord(word="das", start=2.8, end=3.0, confidence=0.9),  # repetition
            TranscriptWord(word="ist", start=3.1, end=3.3, confidence=0.3),  # low conf
            TranscriptWord(word="gut", start=3.4, end=3.6, confidence=0.3),  # low conf
        ]
        seg = TranscriptSegment(words=words, start=0.0, end=3.6)
        return Transcript(segments=[seg], duration=4.0, language="de")

    def test_detect_fillers(self):
        from pydaw.services.video_smart_cut import detect_fillers
        t = self._make_transcript()
        fillers = detect_fillers(t, "de")
        filler_words = [s.word_ids[0] for s in fillers]
        # "ähm" and "also" should be detected
        assert len(fillers) >= 2

    def test_detect_pauses(self):
        from pydaw.services.video_smart_cut import detect_pauses
        t = self._make_transcript()
        pauses = detect_pauses(t, min_pause=0.8)
        assert len(pauses) >= 1  # gap between "also" (1.3) and "das" (2.5)

    def test_detect_repetitions(self):
        from pydaw.services.video_smart_cut import detect_repetitions
        t = self._make_transcript()
        reps = detect_repetitions(t)
        assert len(reps) >= 1  # "das das"

    def test_detect_low_confidence(self):
        from pydaw.services.video_smart_cut import detect_low_confidence
        t = self._make_transcript()
        lows = detect_low_confidence(t, threshold=0.4)
        assert len(lows) >= 1  # "ist" + "gut" both 0.3

    def test_smart_cut_service(self):
        from pydaw.services.video_smart_cut import SmartCutService
        t = self._make_transcript()
        svc = SmartCutService()
        result = svc.analyze(t)
        assert result.total_cut_duration > 0
        assert len(result.all_suggestions) > 0
        assert result.summary()  # non-empty string

    def test_highlight_reel(self):
        from pydaw.services.video_smart_cut import generate_highlight_reel
        from pydaw.services.video_whisper_service import (
            Transcript, TranscriptSegment, TranscriptWord)
        words = [TranscriptWord(word=f"w{i}", start=i*0.5, end=i*0.5+0.4,
                                 confidence=0.9) for i in range(20)]
        seg = TranscriptSegment(words=words, start=0.0, end=10.0)
        t = Transcript(segments=[seg], duration=10.0)
        regions = generate_highlight_reel(t, target_duration=5.0)
        assert len(regions) > 0


# ═══════════════════════════════════════════════════════════════
# VE13: Mood Matcher
# ═══════════════════════════════════════════════════════════════

class TestMoodMatcher:
    def test_preset_list(self):
        from pydaw.services.video_mood_matcher import get_preset_list
        presets = get_preset_list()
        assert len(presets) == 15
        names = [p["id"] for p in presets]
        assert "cinematic" in names
        assert "noir" in names
        assert "teal_orange" in names

    def test_generate_filters(self):
        from pydaw.services.video_mood_matcher import generate_grade_filters
        f = generate_grade_filters("cinematic")
        assert "eq=" in f
        assert "contrast=" in f

    def test_generate_filters_noir(self):
        from pydaw.services.video_mood_matcher import generate_grade_filters
        f = generate_grade_filters("noir")
        assert "saturation=0.15" in f  # noir is very desaturated

    def test_color_profile(self):
        from pydaw.services.video_mood_matcher import ColorProfile
        p = ColorProfile(avg_brightness=0.6, avg_saturation=0.4, contrast=1.2)
        d = p.to_dict()
        p2 = ColorProfile.from_dict(d)
        assert p2.avg_brightness == 0.6


# ═══════════════════════════════════════════════════════════════
# VE14: GPU Decode
# ═══════════════════════════════════════════════════════════════

class TestGPUDecode:
    def test_backend_enum(self):
        from pydaw.services.video_gpu_decode import GPUBackend
        assert GPUBackend.VAAPI.value == "vaapi"
        assert GPUBackend.NVDEC.value == "nvdec"
        assert GPUBackend.NONE.value == "none"

    def test_hw_decode_args(self):
        from pydaw.services.video_gpu_decode import get_hw_decode_args, GPUBackend
        args = get_hw_decode_args(GPUBackend.VAAPI, "/dev/dri/renderD128")
        assert "-hwaccel" in args
        assert "vaapi" in args

    def test_hw_scale_filter(self):
        from pydaw.services.video_gpu_decode import get_hw_scale_filter, GPUBackend
        f = get_hw_scale_filter(GPUBackend.VAAPI, 1280)
        assert "scale_vaapi" in f
        f2 = get_hw_scale_filter(GPUBackend.NONE, 1280)
        assert "scale=" in f2

    def test_hw_filter(self):
        from pydaw.services.video_gpu_decode import get_hw_filter, GPUBackend
        f = get_hw_filter(GPUBackend.VAAPI, "denoise", {"strength": 3})
        assert "denoise_vaapi" in f

    def test_gpu_capability(self):
        from pydaw.services.video_gpu_decode import GPUCapability, GPUBackend
        cap = GPUCapability(backend=GPUBackend.NVDEC, device="RTX 4090",
                            codecs=["h264", "hevc"], priority=90)
        d = cap.to_dict()
        assert d["backend"] == "nvdec"
        assert d["priority"] == 90


# ═══════════════════════════════════════════════════════════════
# VE15: Multi-Cam
# ═══════════════════════════════════════════════════════════════

class TestMultiCam:
    def test_cam_source(self):
        from pydaw.services.video_multicam import CamSource
        src = CamSource(path="/cam1.mp4", label="Front", duration=60.0)
        d = src.to_dict()
        assert d["label"] == "Front"

    def test_multicam_service(self):
        from pydaw.services.video_multicam import MultiCamService
        svc = MultiCamService()
        svc.add_source("/cam1.mp4", "Front")
        svc.add_source("/cam2.mp4", "Side")
        assert len(svc.sources) == 2
        assert svc.sources[0].label == "Front"

    def test_camera_switch(self):
        from pydaw.services.video_multicam import MultiCamService
        svc = MultiCamService()
        svc.add_source("/cam1.mp4", "A")
        svc.add_source("/cam2.mp4", "B")
        svc.switch_at(10.0, 1)
        svc.switch_at(20.0, 0)
        assert svc.active_source_at(5.0) == 0
        assert svc.active_source_at(15.0) == 1
        assert svc.active_source_at(25.0) == 0

    def test_edit_list(self):
        from pydaw.services.video_multicam import MultiCamService
        svc = MultiCamService()
        svc.add_source("/cam1.mp4", "A")
        svc.add_source("/cam2.mp4", "B")
        svc.sources[0].duration = 30.0
        svc.project.total_duration = 30.0
        svc.switch_at(10.0, 1)
        edits = svc.get_edit_list()
        assert len(edits) == 2


# ═══════════════════════════════════════════════════════════════
# VE16: Interchange Export
# ═══════════════════════════════════════════════════════════════

class TestInterchangeExport:
    def test_timecode_format(self):
        from pydaw.services.video_interchange_export import _seconds_to_tc
        assert _seconds_to_tc(0.0, 24.0) == "00:00:00:00"
        assert _seconds_to_tc(61.5, 24.0) == "00:01:01:12"

    def test_edl_export(self):
        from pydaw.services.video_interchange_export import (
            export_edl, ExportProject, ExportClip)
        proj = ExportProject(name="Test", fps=24.0)
        proj.clips.append(ExportClip(
            clip_id="c1", name="Clip 1", file_path="/video.mp4",
            start_time=0.0, end_time=5.0, source_in=0.0, source_out=5.0))
        with tempfile.NamedTemporaryFile(suffix=".edl", delete=False) as f:
            path = f.name
        try:
            assert export_edl(proj, path)
            content = open(path).read()
            assert "TITLE: Test" in content
            assert "001" in content
        finally:
            os.unlink(path)

    def test_xml_export(self):
        from pydaw.services.video_interchange_export import (
            export_xml, ExportProject, ExportClip)
        proj = ExportProject(name="Test", fps=24.0, width=1920, height=1080)
        proj.clips.append(ExportClip(
            clip_id="c1", name="Clip 1", file_path="/video.mp4",
            start_time=0.0, end_time=5.0, source_in=0.0, source_out=5.0))
        with tempfile.NamedTemporaryFile(suffix=".xml", delete=False) as f:
            path = f.name
        try:
            assert export_xml(proj, path)
            content = open(path).read()
            assert "xmeml" in content
            assert "Test" in content
        finally:
            os.unlink(path)


# ═══════════════════════════════════════════════════════════════
# VE17: Immersive Audio
# ═══════════════════════════════════════════════════════════════

class TestImmersiveAudio:
    def test_spatial_position(self):
        from pydaw.services.video_immersive_audio import SpatialPosition
        p = SpatialPosition(x=0.0, y=1.0, z=0.0)
        assert p.azimuth == pytest.approx(0.0, abs=0.1)  # front
        assert p.elevation == pytest.approx(0.0, abs=0.1)
        assert p.distance == pytest.approx(1.0)

    def test_spatial_from_spherical(self):
        from pydaw.services.video_immersive_audio import SpatialPosition
        p = SpatialPosition.from_spherical(90, 0, 1.0)  # right
        assert p.x == pytest.approx(1.0, abs=0.01)
        assert p.y == pytest.approx(0.0, abs=0.01)

    def test_ambisonics_foa(self):
        from pydaw.services.video_immersive_audio import (
            encode_ambisonics_foa, SpatialPosition)
        p = SpatialPosition(x=0.0, y=1.0, z=0.0)  # front center
        gains = encode_ambisonics_foa(p, gain=1.0)
        assert len(gains) == 4  # W, Y, Z, X
        assert gains[0] > 0  # W (omni) always positive
        assert gains[3] > 0  # X (front) positive for front source

    def test_immersive_service(self):
        from pydaw.services.video_immersive_audio import (
            ImmersiveAudioService, SpatialFormat)
        svc = ImmersiveAudioService()
        svc.set_format(SpatialFormat.ATMOS_714)
        assert svc.channel_count == 12
        obj = svc.create_object("Vocals", x=0, y=1, z=0)
        assert obj.name == "Vocals"
        assert len(svc.objects) == 1


# ═══════════════════════════════════════════════════════════════
# VE18: Cloud Collab
# ═══════════════════════════════════════════════════════════════

class TestCloudCollab:
    def test_review_comment(self):
        from pydaw.services.video_cloud_collab import (
            ReviewComment, CommentPriority)
        c = ReviewComment(time_start=10.0, text="Fix here",
                          author="Anno", priority=CommentPriority.IMPORTANT)
        assert c.color == "#ff6644"
        assert not c.is_range

    def test_comment_reply(self):
        from pydaw.services.video_cloud_collab import ReviewComment
        c = ReviewComment(time_start=5.0, text="Check this")
        c.add_reply("Looks good", "Reviewer B")
        assert len(c.replies) == 1

    def test_cloud_service(self):
        from pydaw.services.video_cloud_collab import VideoCloudService
        svc = VideoCloudService()
        sid = svc.create_session("proj_1")
        assert sid == "proj_1"
        c = svc.add_comment(10.0, "Cut here", author="Anno")
        assert len(svc.comments) == 1
        assert svc.get_comments_at(10.0)[0].text == "Cut here"

    def test_version_control(self):
        from pydaw.services.video_cloud_collab import VideoCloudService
        svc = VideoCloudService()
        v = svc.save_version("v1.0", description="Initial")
        assert v.name == "v1.0"
        assert len(svc.versions) == 1


# ═══════════════════════════════════════════════════════════════
# VK: Arranger Integration
# ═══════════════════════════════════════════════════════════════

class TestKIArranger:
    def test_annotation_manager(self):
        from pydaw.services.video_ki_arranger import AnnotationManager
        mgr = AnnotationManager()
        ann = mgr.add(beat=16.0, text="Schnitt hier", color="red")
        assert len(mgr.annotations) == 1
        assert ann.hex_color == "#ff4444"

    def test_annotation_search(self):
        from pydaw.services.video_ki_arranger import AnnotationManager
        mgr = AnnotationManager()
        mgr.add(beat=0.0, text="Intro start")
        mgr.add(beat=32.0, text="Chorus start")
        results = mgr.search("chorus")
        assert len(results) == 1

    def test_annotation_status(self):
        from pydaw.services.video_ki_arranger import AnnotationManager
        mgr = AnnotationManager()
        ann = mgr.add(beat=0.0, text="Fix this", status="todo")
        assert mgr.set_status(ann.annotation_id, "done")
        assert ann.status == "done"
        assert ann.color == "green"

    def test_cue_sheet_csv_export(self):
        from pydaw.services.video_ki_arranger import (
            CueSheetEntry, export_cue_sheet_csv)
        entries = [
            CueSheetEntry(cue_id="ADR-001", timecode="00:00:10:00",
                          time_seconds=10.0, duration=3.0,
                          cue_type="ADR", description="Dialog 1"),
        ]
        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
            path = f.name
        try:
            assert export_cue_sheet_csv(entries, path)
            content = open(path).read()
            assert "ADR-001" in content
            assert "Dialog 1" in content
        finally:
            os.unlink(path)

    def test_beat_cut_suggestion(self):
        from pydaw.services.video_ki_arranger import BeatCutSuggestion
        s = BeatCutSuggestion(scene_index=0, original_time=5.0,
                               nearest_beat=10.0, nearest_bar=8.0,
                               offset_ms=50.0, suggested_bpm=120)
        d = s.to_dict()
        assert d["nearest_beat"] == 10.0

    def test_mood_presets(self):
        from pydaw.services.video_ki_arranger import _MOOD_PRESETS
        assert "dark" in _MOOD_PRESETS
        assert "happy" in _MOOD_PRESETS
        assert _MOOD_PRESETS["dark"]["preset"] == "AETERNA Dark Pad"


# ═══════════════════════════════════════════════════════════════
# Run
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
