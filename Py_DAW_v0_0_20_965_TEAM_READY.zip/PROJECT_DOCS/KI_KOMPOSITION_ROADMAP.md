# 🎼 KI-KOMPOSITIONS-ENGINE — ROADMAP

**Codename:** BACH-KI (Biblische Analyse & Composition Harmonik KI)
**Ziel:** Vollständige Songs generieren aus allen Epochen und Stilen — rein mathematisch, keine neuronalen Netze
**Was es noch NICHT gibt:** Kein Tool der Welt kann regelbasiert aus allen Epochen komponieren UND importierte Dokumente (Gesangbücher, Noten, Texte) als Grundlage nehmen

---

## Phase 1: KI-Kompositions-Kern (KK1–KK5)

### KK1: Musiktheorie-Engine
- [ ] Skalen-System: Alle Kirchentonarten (Dorisch, Phrygisch, Lydisch, Mixolydisch, Äolisch, Ionisch, Lokrisch)
- [ ] Akkord-Generierung: Dreiklänge, Septakkorde, Nonenakkorde, Vorhaltakkorde, Neapolitaner, Tristan-Akkord
- [ ] Stimmführung: Parallelen-Verbot, Gegenbewegung, Auflösungsregeln
- [ ] Kadenz-System: Authentisch, Plagal, Trugschluss, Halbschluss, Kirchenkadenz
- [ ] Generalbass: Bezifferte Bass-Interpretation → volle Akkordfolgen
- [ ] Tonart-Erkennung: Aus importierten Noten die Tonart ableiten
- [ ] Modulation: Diatonisch, Chromatisch, Enharmonisch, Mediantik

### KK2: Kontrapunkt-Engine (Bach-Fokus)
- [ ] Cantus Firmus Generator (aus Choralmelodie oder importiertem Text)
- [ ] 1:1 Kontrapunkt (Note gegen Note)
- [ ] 2:1 Kontrapunkt (zwei Noten gegen eine)
- [ ] 4:1 Kontrapunkt (vier Noten gegen eine)
- [ ] Freier Kontrapunkt
- [ ] Fuge: Thema → Antwort (real/tonal) → Durchführung → Zwischenspiel → Engführung
- [ ] Kanon: Krebs, Umkehrung, Krebs-Umkehrung, Augmentation, Diminution
- [ ] Choral-Harmonisierung: Sopran-Melodie → vierstimmiger Satz nach Bach-Regeln
- [ ] Invention: Zweistimmig (BWV 772–786 Regeln), Dreistimmig (Sinfonien)
- [ ] Passacaglia/Chaconne: Ostinato-Bass mit Variationen

### KK3: Epochen-Profile (Style-Engine)
- [ ] **Mittelalter** (800–1400): Gregorianik, Organum, Ars Nova, Modalität
- [ ] **Renaissance** (1400–1600): Palestrina-Stil, Vokalpolyphonie, Imitation
- [ ] **Barock** (1600–1750): Bach, Händel, Vivaldi — Generalbass, Concerto, Fuge
- [ ] **Klassik** (1750–1820): Mozart, Haydn, Beethoven — Sonatenform, Durchführung
- [ ] **Romantik** (1820–1900): Chopin, Liszt, Wagner — Chromatik, Leitmotiv
- [ ] **Impressionismus** (1880–1920): Debussy, Ravel — Ganztonleiter, Quartenakkorde
- [ ] **Jazz** (1900–): Blues-Schema, Bebop-Changes, Modal Jazz, Free Jazz
- [ ] **Blues** (1870–): 12-Takt, Pentatonik, Blue Notes, Shuffle
- [ ] **Rock/Pop** (1950–): Vierakkord-Progressionen, Vers-Refrain, Power Chords
- [ ] **Electronic** (1970–): Synth-Sequenzen, Arpeggiator, Sidechain, Drop
- [ ] **Hip-Hop** (1980–): Boom Bap, Trap, Lo-Fi Beats, Sample-Chop-Logik
- [ ] **Metal** (1970–): Riff-Generator, Palm Mute, Blast Beat, Drop Tuning
- [ ] **Latin** (Salsa, Bossa Nova, Samba): Clave-Rhythmen, Montuno
- [ ] **Filmmusik** (1930–): Leitmotiv, Mickey-Mousing, Orchestration
- [ ] **Minimalismus** (1960–): Steve Reich Phasing, Glass Arpeggios, Additive Prozesse
- [ ] **Ambient** (1970–): Drones, Generative Loops, Granular Texturen

### KK4: Rhythmus-Engine
- [ ] Taktarten: 4/4, 3/4, 6/8, 5/4, 7/8, 12/8, frei
- [ ] Swing/Shuffle: 0–100% parametrisch
- [ ] Polyrhythmik: 3:4, 5:4, 7:4 überlagert
- [ ] Hemiole: Metrische Verschiebung (3×2 → 2×3)
- [ ] Rhythmus-Patterns: Pro Stil 20+ Drum-/Begleitmuster
- [ ] Humanize: Timing + Velocity-Variation (Box-Muller + Golden Ratio)
- [ ] Tempo-Kurven: Rubato, Accelerando, Ritardando, Fermaten

### KK5: Arrangement-Engine
- [ ] Orchestration: Welches Instrument in welcher Lage (Streichersatz, Bläsersatz, Chor)
- [ ] Instrumenten-Bereiche: Geige (G3–E7), Cello (C2–A5), Trompete (F#3–D6), etc.
- [ ] Dynamik-Kurven: pp → ff Verläufe, Crescendo, Decrescendo
- [ ] Song-Struktur: Intro → Vers → Pre-Chorus → Chorus → Bridge → Outro
- [ ] Formenlehre: Sonatenform, Rondo, ABA, Variationsform, Strophenlied
- [ ] Mixturen: Stil A + Stil B = neuer Stil (z.B. Bach + Electronic, Jazz + Kirchenmusik)
- [ ] Medley-Generator: Mehrere Stücke intelligent verbinden

---

## Phase 2: Dokument-Import & Analyse (KK6–KK8)

### KK6: Dokument-Import
- [ ] PDF Import (mit OCR für gescannte Gesangbücher)
- [ ] DOCX/DOC Import (Text + Formatierung)
- [ ] TXT Import (reiner Text)
- [ ] MusicXML Import (Noten direkt)
- [ ] MIDI Import (bestehende Noten analysieren)
- [ ] Liedtext-Erkennung: Verse, Refrain, Strophen automatisch erkennen
- [ ] Noten-OCR: Gescannte Notenblätter → MIDI (experimental)

### KK7: Text-Analyse (Gesangbücher / Liturgie)
- [ ] Vers-Metrik: Jambus, Trochäus, Daktylus, Anapäst → Rhythmus-Ableitung
- [ ] Silben-Zählung: Pro Zeile → Melodie-Länge bestimmen
- [ ] Reim-Erkennung: Paarreim, Kreuzreim, Umarmungsreim → Melodie-Wiederholung
- [ ] Stimmung-Analyse: Freude, Trauer, Feierlichkeit, Buße → Tonart + Tempo
- [ ] Liturgische Zuordnung: Advent, Weihnachten, Passion, Ostern, Pfingsten → Stil-Profil
- [ ] Sprach-Erkennung: Deutsch, Latein, Englisch → Betonungsmuster
- [ ] Psalm-Ton-System: 8 Psalm-Töne → Rezitation + Flexa + Mediatio + Terminatio

### KK8: KI-Entscheidungslogik
- [ ] Stil-Auswahl: Text-Analyse → „Dieser Text passt zu: Barock (85%), Romantik (72%)"
- [ ] Tonart-Vorschlag: „Für diesen feierlichen Text: D-Dur oder B-Dur"
- [ ] Tempo-Vorschlag: „Andante (72 BPM) für meditativen Text"
- [ ] Instrumenten-Vorschlag: „Orgel + Chor (SATB) für Kirchenmusik"
- [ ] Mix-Vorschläge: „Klassischer Choral + moderne Harmonien (Neo-Barock)"
- [ ] Längen-Presets: 30s, 1min, 3min, 5min, volle Messe (60min+)
- [ ] A/B Vergleich: Zwei Arrangements generieren → User wählt

---

## Phase 3: Kirchenmusik-Spezial (KK9–KK11)

### KK9: Choral-Datenbank
- [ ] Evangelisches Gesangbuch (EG): Melodien + Texte (Public Domain vor 1900)
- [ ] Gotteslob (GL): Melodie-Strukturen (Public Domain Anteil)
- [ ] Bach-Choräle (371 Choräle BWV): Alle Harmonisierungen als Referenz
- [ ] Gregorianische Melodien: Antiphonen, Hymnen, Sequenzen
- [ ] Psalm-Melodien: Genfer Psalter, Anglikanische Chants
- [ ] Weihnachtslieder: Stille Nacht, O du fröhliche, etc. (Public Domain)

### KK10: Orgel-Spezifisch
- [ ] Registrierung: Plenum, Prinzipal-Chor, Flöten, Zungen, Mixturen
- [ ] Pedalstimme: Eigenständige Bass-Linie (nicht nur Verdopplung)
- [ ] Orgelpunkt: Liegende Bassnote unter wechselnden Harmonien
- [ ] Manual-Wechsel: Hauptwerk → Schwellwerk → Positiv → Pedal
- [ ] Tremulant, Koppeln: Als MIDI-CC Automation
- [ ] Orgelchoral-Formen: Cantus-Firmus-Choral, Figuralchoral, Triosonate

### KK11: Chor-Satz (SATB)
- [ ] Vierstimmiger Satz: Sopran, Alt, Tenor, Bass
- [ ] Stimmumfänge: S (C4–A5), A (F3–D5), T (C3–A4), B (E2–E4)
- [ ] Stimmkreuzungs-Vermeidung
- [ ] Textverteilung: Syllabisch, Melismatisch, Rezitativisch
- [ ] Atemzeichen: Automatische Zäsuren
- [ ] Doppelchor: Zwei SATB-Gruppen antiphonal (Venezianischer Stil)

---

## Phase 4: Song-Generator & UI (KK12–KK14)

### KK12: One-Click Song Generator
- [ ] „Generiere mir einen Song" → Stil wählen → Tonart → Tempo → Länge → Go
- [ ] Random Seed: Jeder Seed = anderer Song (reproduzierbar via Golden Ratio)
- [ ] Variation: „Nochmal, aber jazziger" → Parameter-Shift
- [ ] Multitrack-Output: Jedes Instrument = eigener Track in der DAW
- [ ] MIDI + AETERNA: Generierte Noten + passende Synthese-Parameter
- [ ] Export: MIDI, MusicXML, PDF (Notensatz), Audio (via DAW-Render)

### KK13: Kompositions-Assistent Panel
- [ ] Dock-Widget in der DAW (wie Video-KI Panel)
- [ ] Stil-Browser: Alle Epochen als Kacheln mit Audio-Preview
- [ ] Mix-Slider: „Barock ←→ Jazz" stufenlos
- [ ] Dokument-Drop: PDF/DOCX reinziehen → Text wird analysiert
- [ ] Live-Preview: Generierte Noten sofort anhören (AETERNA)
- [ ] „Überrasch mich": Zufälliger Stil-Mix + zufälliger Seed
- [ ] Song-Bibliothek: Generierte Songs speichern + wieder laden

### KK14: Mathematische Basis (keine KI-Modelle!)
- [ ] Golden Ratio: Phrase-Längen, Formproportionen (0.618 × Gesamtlänge = Höhepunkt)
- [ ] Fibonacci: Taktzahlen (5, 8, 13, 21, 34 Takte pro Abschnitt)
- [ ] Fraktal-Melodien: Selbstähnlichkeit über verschiedene Zeitskalen
- [ ] Markov-Ketten: Stilspezifische Übergangswahrscheinlichkeiten
- [ ] Schenkerian Analysis: Ursatz → Mittelgrund → Vordergrund (Auskomponierung)
- [ ] Gruppentheorie: Transformations-Netzwerke (Neo-Riemannian Theory)
- [ ] Fourier-Analyse: Rhythmische Spektren → Style-Fingerprint
- [ ] Stochastik: Xenakis-Style probabilistische Verteilungen
- [ ] Zelluläre Automaten: Game-of-Life-basierte Pattern-Generierung
- [ ] L-Systeme: Lindenmayer-Systeme für organische Melodie-Entwicklung

---

## Zusammenfassung

| Phase | Items | Beschreibung |
|-------|-------|-------------|
| Phase 1: Kern (KK1–KK5) | 80+ | Musiktheorie + Kontrapunkt + Epochen + Rhythmus + Arrangement |
| Phase 2: Import (KK6–KK8) | 35+ | PDF/DOCX Import + Text-Analyse + KI-Entscheidung |
| Phase 3: Kirche (KK9–KK11) | 30+ | Choräle + Orgel + SATB Chor |
| Phase 4: Generator (KK12–KK14) | 30+ | One-Click Songs + UI + Mathe-Basis |
| **TOTAL** | **175+** | **Vollständige KI-Kompositions-Engine** |

### Empfohlene Reihenfolge:
1. **KK1** (Musiktheorie) → Fundament für alles
2. **KK3** (Epochen-Profile) → Stile definieren
3. **KK4** (Rhythmus) → Beats + Patterns
4. **KK2** (Kontrapunkt) → Bach-Qualität
5. **KK12** (Generator) → Erste Songs!
6. **KK6** (Import) → Dokumente laden
7. **KK7** (Text-Analyse) → Gesangbücher
8. **KK9–11** (Kirchenmusik) → Spezialisierung
9. **KK13** (UI) → Kompositions-Panel
10. **KK14** (Mathe) → Verfeinerung

---

*Was es noch nie gab: Eine KI-Komposition die NICHT auf neuronalen Netzen basiert, sondern auf jahrhundertealter Musiktheorie — mathematisch exakt, reproduzierbar, und in JEDER Epoche zuhause.*

*Py_DAW wäre die einzige DAW der Welt mit eingebauter regelbasierter Kompositions-KI.*
