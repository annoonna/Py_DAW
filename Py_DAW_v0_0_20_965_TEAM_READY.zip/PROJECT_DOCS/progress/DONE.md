## v0.0.20.959 — Rust Audio Output RA1+RA4 (2026-04-03)

- [x] (Claude Opus 4.6, 2026-04-03): **RA1.1 cpal Audio Output** — audio_output.rs (310 LOC), AudioOutput struct, enumerate_devices, test sine
- [x] (Claude Opus 4.6, 2026-04-03): **RA1.2 Audio Render Loop** — render.rs (250 LOC), AudioRenderer, drain→transport→render→graph→output
- [x] (Claude Opus 4.6, 2026-04-03): **RA1.3 IPC Commands** — 5 Commands (AudioStart/Stop/TestSine/Enumerate/Status), 6 Events, AudioDeviceEntry
- [x] (Claude Opus 4.6, 2026-04-03): **RA4.1 Engine Migration** — RustEngineBridge 5 Methoden + Signals, RustAudioTakeover audio_start/stop
- [x] (Claude Opus 4.6, 2026-04-03): **RA4.4 Audio Settings UI** — "🦀 Rust Audio Output" GroupBox, Device-Auswahl, Test-Sine, Start/Stop, Live-Status

## v0.0.20.952 — VK1-VK9 Video-KI Arranger Integration (2026-04-02)

- [x] (Claude Opus 4.6, 2026-04-02): **VK1 Scene Markers** — generate_scene_markers() mit Beat-Position, Farbe, Mood-Tags
- [x] (Claude Opus 4.6, 2026-04-02): **VK2 Auto-Duck** — Dialog-Markers + generate_auto_duck() Automation (duck_db, fade_beats)
- [x] (Claude Opus 4.6, 2026-04-02): **VK3 Mood Suggestions** — 12 AETERNA Presets, Scene Color Bar, BPM/Key per Mood
- [x] (Claude Opus 4.6, 2026-04-02): **VK4 Subtitle Integration** — Arranger Blocks, search_transcript(), chapter_titles()
- [x] (Claude Opus 4.6, 2026-04-02): **VK5 Beat-to-Cut** — BeatCutSuggestion mit nearest_beat/bar/offset + suggested_bpm
- [x] (Claude Opus 4.6, 2026-04-02): **VK6 ADR/Foley Cue-Sheet** — CueSheetEntry Generator + CSV/PDF Export
- [x] (Claude Opus 4.6, 2026-04-02): **VK9 Annotations** — AnnotationManager, Sticky Notes, farbkodiert, suchbar, exportierbar
- [x] (Claude Opus 4.6, 2026-04-02): **P7 Korrektur** — VST3 IBStream + CLAP MIDI + LV2 State/Atom nachträglich abgehakt

## v0.0.20.951 — VE14-VE18 GPU + Multi-Cam + Export + Immersive + Cloud (2026-04-02)

- [x] (Claude Opus 4.6, 2026-04-02): **VE14 GPU Decode** — VAAPI/NVDEC/Vulkan/CUDA Auto-Detect, HW Scale/Filter, Preview Pipeline
- [x] (Claude Opus 4.6, 2026-04-02): **VE15 Multi-Cam Sync** — Audio Cross-Correlation, Clap Detection, Timecode Sync, Camera Switch
- [x] (Claude Opus 4.6, 2026-04-02): **VE16 EDL/XML/AAF/OMF Export** — CMX 3600, XMEML v5, AAF/OMF JSON Manifeste
- [x] (Claude Opus 4.6, 2026-04-02): **VE17 Immersive Audio** — Dolby Atmos Objects, FOA/HOA Ambisonics, Binaural, 7.1.4/9.1.6
- [x] (Claude Opus 4.6, 2026-04-02): **VE18 Cloud Collab** — ReviewComment (4 Prioritäten), Proxy Generator, Version Control, WebSocket Protocol
- [x] 🎬 **VIDEO_EDITOR_ROADMAP.md KOMPLETT** — VE1–VE18 alle abgeschlossen ✅

## v0.0.20.950 — VE11+VE12+VE13 KI Text-Editing + Smart Cut + Mood Matcher (2026-04-02)

- [x] (Claude Opus 4.6, 2026-04-02): **VE11 Whisper Transkription** — lokale Whisper-Integration (faster-whisper/openai-whisper/Stub), Thread-safe, SQLite
- [x] (Claude Opus 4.6, 2026-04-02): **VE11 Text-Editor** — Interaktiver Text neben Timeline, Wort-Klick→Seek, Delete→Jump Cut
- [x] (Claude Opus 4.6, 2026-04-02): **VE11 Word Markers** — Wort-Grenzen auf Timeline, TranscriptHighlighter, Undo-Stack
- [x] (Claude Opus 4.6, 2026-04-02): **VE11 Subtitle Export** — SRT, VTT, Plain Text mit Timestamps
- [x] (Claude Opus 4.6, 2026-04-02): **VE12 Filler-Erkennung** — 60+ Füllwörter in 5 Sprachen (de/en/fr/es + universal)
- [x] (Claude Opus 4.6, 2026-04-02): **VE12 Pausen/Wiederholungen** — Silence >0.8s, Stotterer, Low-Confidence Gruppierung
- [x] (Claude Opus 4.6, 2026-04-02): **VE12 Highlight Reel** — Segment-Scoring + Compress-to-Duration Algorithmus
- [x] (Claude Opus 4.6, 2026-04-02): **VE12 SmartCutPanel** — One-Click UI für Filler/Pausen/Reps/Auto-Clean
- [x] (Claude Opus 4.6, 2026-04-02): **VE13 Film-Look Presets** — 15 Presets (Cinematic, Noir, Teal/Orange, Vintage, etc.)
- [x] (Claude Opus 4.6, 2026-04-02): **VE13 Referenz-Grading** — Clip analysieren + ColorProfile → ffmpeg Filter
- [x] (Claude Opus 4.6, 2026-04-02): **VE13 Audio-Match** — Loudness + EQ-Übertragung von Referenz-Clip
- [x] (Claude Opus 4.6, 2026-04-02): **VE13 MoodMatcherPanel** — Preset-Gallery + Referenz-Loader + Audio-Match Button

## v0.0.20.946 — Video Editor VE8+VE9+VE10 (2026-04-01)

- [x] (Claude Opus 4.6, 2026-04-01): **VE8 Timecode Pro** — HH:MM:SS:FF mit DF/NDF, FPS-Selector (23.976–60), TC-Eingabe Dialog (T)
- [x] (Claude Opus 4.6, 2026-04-01): **VE8 Smart Context Tool** — Auto tool switch (C): Clip-Rand→Trim, Mitte→Move, Header→Playhead
- [x] (Claude Opus 4.6, 2026-04-01): **VE8 LTC Sync** — Framework/Stub für Linear Time Code über Audio
- [x] (Claude Opus 4.6, 2026-04-01): **VE9 Automation Draw** — Per-Clip Curves (Opacity/Speed/Volume), Breakpoint-Editor, Bezier
- [x] (Claude Opus 4.6, 2026-04-01): **VE9 Presets** — Fade In, Fade Out, S-Curve, Bell, Speed Ramp
- [x] (Claude Opus 4.6, 2026-04-01): **VE10 Transition Engine** — Crossfade, Dissolve, Wipe, Slide, Push, Dip Black/White
- [x] (Claude Opus 4.6, 2026-04-01): **VE10 Beat-synced** — Transition-Dauer in Beats, ffmpeg xfade Export
- [x] Neue Module: video_timecode.py (276 LOC), video_automation.py (358 LOC), video_transitions.py (305 LOC)
- [x] 430/430 Python-Dateien kompilieren — 0 Fehler

## v0.0.20.927 — Video-Drop → VideoPanel Auto-Load Fix (2026-04-01)

- [x] (Claude Opus 4.6, 2026-04-01): **Video-Drop Bug Fix** — VideoConnector.on_video_loaded() nach Clip-Erstellung

<!-- Ältere Einträge archiviert — siehe Git History -->


- Neue kleine **Bounce/Freeze-Dialoge** für Clip-Bounce, Track-Freeze/Bounce und Group-Freeze ergänzt.
- Dialoge erlauben jetzt lokal/gezielt: **Label**, **+FX/Dry** sowie optional **Quelle stummschalten/deaktivieren**.
- **TrackList** zeigt jetzt sichtbare **Freeze-Marker** für **Proxy-Spuren** und **Freeze-Quellspuren** inklusive Tooltip.
- Laufzeitfehler in der ersten Bounce-Stufe lokal behoben: sichere Label-Verwendung für neu erzeugte Audio-Clips bei Clip-/Track-Bounce.
- AETERNA lokal um weitere **Math-/Random-Familien** in Formelhilfen, Onboarding und Randomizer erweitert (z. B. harmonic lattice, pink bloom, lorenz breath, sample hold veil, tent lattice, modal drift).
- Keine Änderungen an Playback-Core, Mixer-Engine, Transport oder globaler Audio-Architektur.

## v0.0.20.329 — AETERNA Mod-Rack Amount/Polarität + Signalfluss-Karte

- AETERNA **Web A / Web B** lokal um echte **Polaritätsumschaltung (+ / −)** erweitert; bleibt vollständig auf das interne Instrument begrenzt.
- Mod-Rack-Karte zeigt pro Slot jetzt **Amount + Polarität + kleine Balkenanzeige**.
- Neue lokale **Signalfluss-Linienansicht** ergänzt, die aktive Wege wie **Quelle → Web A/B → Ziel** direkt sichtbar macht.
- Polarity bleibt im lokalen AETERNA-State gespeichert und wird beim Projektladen wiederhergestellt.
- Zusätzlich ein sicherer **Stufenplan** für die größere gewünschte AETERNA-Synth-Erweiterung dokumentiert: erst UI-/Stage-Plan, dann Filter, dann weitere Wunschfamilien wie Unison/Sub/Shape/Noise/Glide/Drive — ausdrücklich **nicht alles in einem riskanten Schritt**.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

## v0.0.20.330 — AETERNA Synth Panel Stage 1 (safe UI grouping)

- Neuer lokaler Bereich **AETERNA SYNTH PANEL (STAGE 1 SAFE)** direkt im Widget.
- Vorhandene stabile Parameter werden dort lesbarer gruppiert in **Core Voice**, **Space / Motion** und **Mod / Web**.
- Kleine Navigations-Buttons öffnen direkt die bereits vorhandenen Bereiche **ENGINE**, **MORPHOGENETIC CONTROLS**, **THE WEB** und **MOD RACK / FLOW**.
- Neue kompakte Statuskarten zeigen die aktuellen Werte der bereits vorhandenen stabilen AETERNA-Parameter inklusive **Web A / Web B**-Kurzansicht.
- Zusätzlich wurden bewusst deaktivierte **Preview-/Platzhalterfelder** für spätere sichere Ausbaustufen ergänzt (z. B. **Filter Type**, **Envelope**, **Layer**, **Unison/Sub/Noise**), damit die UI-Richtung klar ist ohne neue Audio-Engine-Risiken.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

## v0.0.20.331 — AETERNA Filter Stage 2 (größerer sicherer Ausbau)

- Echter lokaler **AETERNA-Filterblock** ergänzt: **Cutoff**, **Resonance** und **Type** (**LP 12 / LP 24 / HP 12 / BP / Notch / Comb+**).
- Filter sitzt vollständig **innerhalb von AETERNA**; kein Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalen Playback-Core.
- Neue echte Filter-Bedienung im **AETERNA SYNTH PANEL** statt nur Preview-Platzhalter.
- **Filter Cutoff** und **Filter Resonance** sind jetzt als stabile **Automation-Ziele** sichtbar und direkt über die vorhandenen Automation-Wege nutzbar.
- **Web A / Web B** können jetzt lokal auch auf **Filter Cutoff** und **Filter Resonance** zielen.
- Neue Filter-Zustände werden mit dem **AETERNA-State** gespeichert und beim Projektladen wiederhergestellt; Snapshot-/Randomize-Pfade wurden lokal mitgezogen.
- Signalfluss-/Synth-Panel-Hinweise wurden lokal erweitert, damit die größere Ausbau-Richtung sichtbarer wird.



## v0.0.20.332 — AETERNA Voice Family + AEG/FEG ADSR (größerer Familien-Block)

- Größeren lokalen **Voice-Block** in AETERNA ergänzt: **Pan**, **Glide**, **Stereo-Spread** und **Retrig**.
- **Pan / Glide / Stereo-Spread** sind als stabile **Automation-Ziele** und lokale **Mod-Rack-Ziele** innerhalb von AETERNA verfügbar; **Retrig** bleibt in dieser sicheren Stufe als lokaler Schalter umgesetzt.
- Größeren lokalen **Envelope-Block** ergänzt: **AEG ADSR** und **FEG ADSR** inklusive **FEG Amount**.
- AEG steuert jetzt lokal die Amplituden-Hüllkurve, FEG formt lokal den Filterverlauf (Cutoff/Resonance) – alles innerhalb von AETERNA ohne Eingriff in DAW-Core, Arranger, Mixer oder Transport.
- Neue Familien wurden im **AETERNA SYNTH PANEL** sichtbar gruppiert, inklusive Statuskarten, erklärender Hinweise und weiterhin einklappbarer Struktur.
- Save/Load, Snapshot und Randomize lokal mitgezogen; bestehende AETERNA-Zustände bleiben kompatibel durch konservative Defaults.
- Zusätzlich eine kleine lokale Runtime-Lücke in der aktuellen AETERNA-Engine geschlossen: fehlende interne **LFO-/MSEG-Helfer** ergänzt, damit der reine Engine-Pull-Pfad wieder lokal ausführbar ist.

## v0.0.20.333 — AETERNA Unison / Sub / Noise (größerer Familien-Block)

- Größeren lokalen **Layer-Block** in AETERNA ergänzt: **Unison / Sub / Noise**.
- Neue echte Klangparameter: **Unison Mix**, **Unison Detune**, **Sub Level**, **Noise Level**, **Noise Color**.
- Neue lokale Comboboxen: **Unison Voices** (**1 / 2 / 4 / 6**) und **Sub Oktave** (**-1 / -2**).
- Stabile kontinuierliche Ziele **Unison Mix / Unison Detune / Sub Level / Noise Level / Noise Color** sind jetzt im AETERNA-Kontext als Automation-/Mod-Rack-Ziele verfügbar.
- Umsetzung bleibt vollständig lokal in **AETERNA Engine + Widget**; kein Eingriff in Arranger, Mixer, Transport oder globalen Playback-Core.
- Save/Load, Snapshot und Randomize für die neue Familie lokal mitgezogen.
- Engine-Smoketest ohne GUI lief sauber für **note_on() / pull() / note_off()** mit aktivem Unison/Sub/Noise-Block.



## v0.0.20.334 — AETERNA Pitch/Shape/Pulse Width + Drive/Feedback (größerer Familien-Block)

- Größeren lokalen **Pitch/Timbre-Block** in AETERNA ergänzt: **Pitch**, **Shape** und **Pulse Width**.
- **Pitch** wirkt jetzt lokal als musikalische globale Tonhöhen-Verschiebung (zentriert um 50%), bleibt aber vollständig innerhalb von AETERNA.
- **Shape** morpht lokal die Wellenform zwischen eher **sine/triangle** und **saw/square**-artigen Verläufen.
- **Pulse Width** steuert lokal die Pulsbreite des Rechteckanteils und damit den Vokal-/Nasalcharakter.
- Größeren lokalen **Drive/Feedback-Block** ergänzt: **Drive** und **Feedback** mit echter Audio-Wirkung innerhalb von AETERNA.
- **Drive** erweitert lokal die Sättigung/Bissigkeit, **Feedback** fügt kontrollierte interne Rückkopplung hinzu — ohne den DAW-Core, Mixer oder Transport anzutasten.
- Neue kontinuierliche Ziele **Pitch / Shape / Pulse Width / Drive / Feedback** sind jetzt im AETERNA-Kontext als stabile **Automation-** und **Mod-Rack-Ziele** verfügbar.
- Familien wurden direkt im **AETERNA SYNTH PANEL** sichtbar ergänzt, inklusive neuer Statuskarten und erweitertem Automation-Schnellzugriff.
- Save/Load, Snapshot und Randomize lokal mitgezogen; bestehende AETERNA-Zustände bleiben kompatibel durch konservative Defaults.
- Engine-Smoketest ohne GUI lief sauber mit den neuen Familien (**note_on / pull / note_off**).

## v0.0.20.335 — AETERNA Visual Polish + sichtbare Familienkarten

- Größeren lokalen **AETERNA-Polish-Block** umgesetzt: deutlichere **Farbtrennung** zwischen Core, Filter, Voice, AEG, FEG, Layer, Timbre und Drive.
- Neue kleine **Familien-Legende** direkt im **AETERNA SYNTH PANEL**, damit die großen Familien schneller lesbar und farblich unterscheidbar sind.
- Neue kleine **grafische Signalfluss-Ansicht** im Bereich **MOD RACK / FLOW**: Audio-Pfad und Mod-Pfad werden jetzt als lokale Linien-/Kartenübersicht sichtbar dargestellt.
- Bestehende Zusammenfassungs-Karten (**Overview, Core, Space, Mod, Future, Filter, Voice, AEG, FEG, Unison/Sub, Noise/Color**) farblich getönt und klarer getrennt.
- Bisher im State/Update schon angelegte Familien **Pitch / Shape / Pulse Width** sowie **Drive / Feedback** jetzt auch als echte **sichtbare Karten mit Knobs** im **AETERNA SYNTH PANEL** ergänzt.
- Umsetzung bleibt vollständig lokal in **pydaw/plugins/aeterna/aeterna_widget.py**; kein Eingriff in Arranger, Playback-Core, Mixer, Transport oder andere Instrumente.


## v0.0.20.336 — AETERNA Layer-Toggles + Mod-Badges/Mini-Meter

- Irreführende Vorschau-Checkboxen im **AETERNA SYNTH PANEL** für **Unison / Sub / Noise** in echte lokale **Layer-Schnellschalter** umgebaut.
- Die drei Schalter greifen jetzt direkt auf die realen Layer-Level **Unison Mix / Sub Level / Noise Level** zu und schalten diese sicher an/aus, ohne Playback-Core oder andere Instrumente anzufassen.
- Letzter sinnvoller Layer-Wert wird lokal gemerkt, sodass ein erneutes Einschalten nicht hart bei 0 startet.
- **Familienkarten** im Synth-Panel zeigen jetzt zusätzlich kompakte **Mini-Meter** und **aktive Mod-Ziel-Badges** pro Familie (z. B. Web A/B auf Filter-, Voice-, Layer- oder Drive-Ziele).
- Umsetzung bleibt vollständig lokal in `pydaw/plugins/aeterna/aeterna_widget.py`.


## v0.0.20.337 — AETERNA Arp A + Per-Knob Mod-Menüs + Readability

- Lokalen **AETERNA Arp A (LOCAL SAFE)** ergänzt: als **sicherer Clip-Arpeggiator** für die aktuelle AETERNA-Spur, ohne Playback-Core-Umbau.
- Arp A bietet jetzt **Pattern** (u. a. up/down/chords/random/flow/blossom/low&up/hi&down), **Rate** (1/1 bis 1/64), **Straight/Dotted/Triplets** und **16 editierbare Steps**.
- Pro Step vorhanden: **Transpose**, **Skip**, **Velocity** und **Gate Length 0–400%**.
- Lokale **Shuffle**-Option für Arp A ergänzt, inklusive Anzahl der betroffenen Steps.
- Arp A kann direkt als **neuen MIDI-Clip** auf der aktuellen AETERNA-Spur schreiben oder den **aktiven Clip überschreiben**.
- Rechtsklick-Kontextmenü auf **allen AETERNA-Knobs** erweitert: **Show Automation in Arranger** plus **Add Modulator** direkt auf den angeklickten Ziel-Knob.
- Neue lokale **Per-Knob-Mod-Profile** eingeführt: jeder AETERNA-Knob kann seinen eigenen gespeicherten Modulator-Zustand behalten, statt einen gemeinsamen Platzhalterzustand zu teilen.
- Lesbarkeit in AETERNA lokal verbessert: **größere Karten-/Hint-Schriften**, **größere Controls** und **deutlichere Signalfluss-Karten**.
- Umsetzung bleibt vollständig lokal in `pydaw/plugins/aeterna/aeterna_widget.py`; kein Eingriff in Arranger, Mixer, Transport, Audio Editor oder globalen Playback-Core.


## v0.0.20.340 — AETERNA Layer-Visibility + Qt Selection Guard

- **Layer-/Noise-Familienkarten** in AETERNA zeigen jetzt **Unison Voices** und **Sub Oktave** klarer direkt in den Karten und im Preview-Hinweis.
- **AETERNA Live-ARP Refresh** wurde lokal koalesziert, damit Checkbox-Klicks nicht mehrere direkte verschachtelte Refresh-Wellen durch die UI jagen.
- **ARP-Live-Sync** besitzt jetzt einen lokalen **Reentrancy-Guard** und emittiert Projekt-Refresh nur noch bei echten State-Änderungen.
- **TrackList**, **Arranger-TrackList** und **Automation-Lanes** wurden um kleine **Refresh-/Signalguards** ergänzt, damit `QListWidget`-Selektionen während Refresh/Restore nicht rekursiv `setCurrentRow`/`setCurrentItem` auslösen.
- Umsetzung bleibt vollständig lokal in AETERNA/UI; kein Eingriff in Playback-Core, Mixer, Transport oder Arranger-Engine.

## v0.0.20.377 — VST3 Editor Stability Fixes (2026-03-10)

**Bug 1 — `RuntimeError: wrapped C/C++ object of type QPushButton has been deleted`**
- Root cause: `_on_editor_process_finished()` and `_on_editor_process_error()` tried to
  call `btn.setText()` AFTER the widget (and its child QPushButton) was already destroyed
  by Qt — e.g. when the Device panel was closed while an editor was open.
- Fix in `fx_device_widgets.py`: All `btn.setText/setEnabled/setStyleSheet` calls wrapped
  in `try/except RuntimeError`. Same guard added to `_on_editor_stdout` ready-event handler.
  `_on_editor_process_error` now also catches RuntimeError from `_show_editor_error`.

**Bug 2 — `QProcess: Destroyed while process is still running`**
- Root cause: `closeEvent` called `proc.kill()` but did NOT disconnect QProcess signals first.
  After widget deletion, `finished` / `errorOccurred` signals still fired against the dead
  widget, causing the RuntimeError above as a secondary effect.
- Fix: `closeEvent` now disconnects ALL QProcess signals (`readyReadStandardOutput`,
  `finished`, `errorOccurred`) BEFORE terminating, using `terminate()` → `waitForFinished(500)`
  → `kill()` sequence.

**Bug 3 — Native editor param changes not reflected in PyDAW sliders (no movement)**
- Root cause: `_snapshot_params()` in `vst_gui_process.py` used `dir(plugin)` + `getattr()`
  to enumerate numeric attributes — completely bypassing pedalboard's official parameter API.
  This never returned actual plugin parameter values, so the `_ParamPoller` never emitted
  any `param` events.
- Fix: `_snapshot_params()` rewritten to use `plugin.parameters` dict
  (name → `AudioProcessorParameter`) and `param.raw_value` for current value.
  Fallback to `getattr(plugin, name)` only for older pedalboard builds without `raw_value`.

Files changed: `pydaw/audio/vst_gui_process.py`, `pydaw/ui/fx_device_widgets.py`

## v0.0.20.378 — VST3 Sliders + Audio-Params Fix (2026-03-10)

**Bug 1 — Alle VST3-Parameter erscheinen als Checkbox (keine Slider)**
- Root cause: `_extract_param_infos()` in vst3_host.py enthielt eine Heuristik:
  `if not is_bool and mx - mn <= 1.0 and mx == 1.0 and mn == 0.0: is_bool = True`
  Da pedalboard ALLE VST3-Parameter normalisiert auf [0.0, 1.0] meldet (minimum_value=0.0,
  maximum_value=1.0), wurde jeder kontinuierliche Parameter (time_ms, lpf_hz, feedback …)
  fälschlicherweise als Boolean klassifiziert und als Checkbox gerendert.
- Fix: Heuristik entfernt. Nur noch `param.is_boolean` aus pedalboard wird verwendet.

**Bug 2 — VST3-Plugins laden aber wirken sich nicht auf Audio aus**
- Root cause: `_apply_rt_params()` verwendete `setattr(plugin, name, val)` mit dem
  normalisierten 0-1 Wert aus dem RTParamStore. pedalboard's setattr() erwartet aber
  den *physikalischen* Wert (z.B. 500.0 für 500 ms). Das Setzen von 0.5 für "time_ms"
  ergab also 0.5 ms — nahezu Null, weshalb alle Plugins wirkungslos erschienen.
- Fix: `_apply_rt_params()` verwendet jetzt `plugin.parameters[name].raw_value = val`
  (normalisierter 0-1 Setter). Für Boolean-Params weiterhin setattr(plugin, name, True/False).
- Gleiches Fix in `get_current_values()` (raw_value statt getattr) und
  `vst_gui_process.py` `set_param`-Handler.

Files changed: `pydaw/audio/vst3_host.py`, `pydaw/audio/vst_gui_process.py`

## v0.0.20.379 — VST3 Editor In-Process: Echte Meter/Analyser (2026-03-10)

**Problem: Nativer Editor zeigt keine Pegel / Spectrum-Anzeige**
- Root cause: Der bisherige Subprocess-Ansatz lud eine SEPARATE Plugin-Instanz nur
  um die GUI anzuzeigen. Diese Instanz bekam niemals Audio → alle Meter/Analyser
  (Spectrum, VU, Loudness-Graph) zeigten nichts.

**Lösung: In-Process QThread (_VstInProcessEditorThread)**
- Neue Klasse `_VstInProcessEditorThread(QThread)` ruft `show_editor()` direkt auf
  dem Plugin-Objekt der `Vst3Fx`-Instanz auf, die echtes Audio prozessiert.
- Zugriffspfad: `services.audio_engine._track_audio_fx_map[track_id].devices`
  → `Vst3Fx` mit passendem `device_id` → `._plugin` (pedalboard plugin object)
- Selbe Plugin-Instanz = native Editor sieht den echten Audio-Datenstrom → Meter ✓

**Bidirektionale Param-Sync im In-Process-Modus**
- `_editor_poll_timer` (80ms): liest `plugin.parameters[name].raw_value`,
  vergleicht mit RT-Store, ruft `_apply_param_from_editor()` bei Änderungen.

**Fallback**
- `_get_vst3_fx_instance()` gibt None zurück wenn Engine nicht erreichbar →
  automatischer Fallback auf den bisherigen QProcess-Subprocess (unverändert).

**Kein Code gelöscht**: Alle bestehenden Subprocess-Methoden bleiben vollständig
erhalten als Fallback-Pfad.

Files changed: `pydaw/ui/fx_device_widgets.py` (neuer Thread, neue Methoden,
               erweiterter closeEvent)

## v0.0.20.490 — SmartDrop: Morphing-Guard Runtime-Snapshot-Handles (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py` baut jetzt konkrete `runtime_snapshot_handles` samt `handle_key`, `handle_kind`, `owner_scope`, `owner_ids`, `capture_state` und `capture_stub` auf.
- Die Apply-Readiness enthaelt jetzt einen zusaetzlichen Check fuer bereits vorverdrahtete Runtime-Snapshot-Handles.
- `pydaw/ui/main_window.py` zeigt einen neuen Abschnitt **Runtime-Snapshot-Handle-Vorschau** und fuehrt die Handle-Zusammenfassung auch im Guard-Dialog-Infotext.
- Kleiner UI-Hotfix nebenbei: Variablen-Ueberschattung im Guard-Dialog bereinigt, damit `Zielspur:` wieder sicher die eigentliche Spurzusammenfassung anzeigt.



## v0.0.20.495 — SmartDrop: Morphing-Guard Dry-Run Runner (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py` koppelt das Snapshot-Bundle jetzt an einen read-only Dry-Run-/Transaktions-Runner mit `runner_key`, Capture-/Restore-/Rollback-Sequenzen und `phase_results`.
- Die Apply-Readiness enthaelt jetzt einen zusaetzlichen Check fuer den vorbereiteten Dry-Run-Runner.
- `pydaw/ui/main_window.py` zeigt einen neuen Abschnitt **Read-only Dry-Run / Transaktions-Runner** und fuehrt die Dry-Run-Zusammenfassung im Guard-Dialog-Infotext.

## v0.0.20.496 — SmartDrop: Morphing-Guard Safe-Runner Dispatch (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py` dispatcht Capture-/Restore-Phasen jetzt ueber konkrete read-only Preview-Funktionen je Snapshot-Typ (`capture_track_state_snapshot`, `capture_routing_snapshot`, `restore_*` usw.) statt nur ueber generische Platzhaltertexte.
- Der Dry-Run-Bericht enthaelt jetzt zusaetzlich `capture_method_calls`, `restore_method_calls` und `runner_dispatch_summary`, sodass sichtbar ist, welche Safe-Runner-Methoden bereits zentral vorverdrahtet sind.
- `pydaw/ui/main_window.py` zeigt diese neuen Safe-Runner-Dispatch-Infos im bestehenden Block **Read-only Dry-Run / Transaktions-Runner** mit an.



## v0.0.20.498 — SmartDrop: Morphing-Guard State-Carriers (2026-03-16)

- `pydaw/services/smartdrop_morph_guard.py` koppelt Runtime-Stubs jetzt an konkrete read-only Zustandstraeger / State-Carrier mit eigener Payload-Vorschau.
- Der Dry-Run ruft jetzt `capture_state_preview()` / `restore_state_preview()` / `rollback_state_preview()` ueber die Carrier auf und fuehrt `state_carrier_calls` plus `state_carrier_summary` im Plan mit.
- `pydaw/ui/main_window.py` zeigt die neue Ebene als **Runtime-Zustandstraeger / State-Carrier** an und fuehrt die Carrier-Infos auch im Dry-Run-Detailblock.

## v0.0.20.501 — Runtime-State-Slots / Snapshot-State-Speicher

- Runtime-State-Halter wurden an konkrete read-only **Runtime-State-Slots / Snapshot-State-Speicher** gekoppelt.
- Der Safe-Runner nutzt jetzt `capture_slot_preview()` / `restore_slot_preview()` / `rollback_slot_preview()` direkt ueber die neuen Slot-Klassen.
- Der Guard-Dialog zeigt die neue Slot-Ebene sowie die neuen Dry-Run-Dispatch-Infos sichtbar an.

## v0.0.20.503 — Runtime-State-Registries / Handle-Speicher

- Runtime-State-Stores wurden an konkrete read-only **Runtime-State-Registries / Handle-Speicher** gekoppelt.
- Der Safe-Runner nutzt jetzt `capture_registry_preview()` / `restore_registry_preview()` / `rollback_registry_preview()` direkt ueber die neuen Registry-Klassen.
- Der Guard-Dialog zeigt die neue Registry-Ebene sowie die neuen Dry-Run-Dispatch-Infos sichtbar an.

## v0.0.20.736 — 🔁 MidiScheduler Loop-Region Support (2026-03-22)

- [x] (Claude Sonnet 4.6): **midi_scheduler.rs** — Loop-State + set_loop() + Dual-Range Iterator (13/13 Tests, 299/299 gesamt)
- [x] (Claude Sonnet 4.6): **engine.rs** — SetLoop + apply_project_sync → midi_scheduler.set_loop()
- [x] (Claude Sonnet 4.6): **main_window.py** — bridge.set_loop() in _on_transport_loop_changed()

## v0.0.20.737 — 🔌 VST3 IBStream + CLAP Streams + CLAP MIDI Injection (2026-03-22)

- [x] (Claude Sonnet 4.6): **vst3_host.rs** — MemoryStream COM IBStream, echtes VST3 State Save/Load
- [x] (Claude Sonnet 4.6): **clap_host.rs** — CLAP Streams + echtes State Save/Load
- [x] (Claude Sonnet 4.6): **clap_host.rs** — ClapNoteEvent ABI + NoteEventList + MIDI Injection in process()
- 320/320 Tests grün (+21 neue)

## v0.0.20.738 — 🎵 LV2 Atom MIDI + LV2 State (2026-03-22)

- [x] (Claude Sonnet 4.6): **lv2_host.rs** — LV2_Atom_Sequence Buffer, MIDI Injection, State Save/Load, 12 Tests
- 332/332 Tests grün (+12 neue)

## v0.0.20.739 — 🖥️ Plugin-Browser Rust-Scanner Auto-Trigger (2026-03-22)

- [x] (Claude Sonnet 4.6): **plugins_browser.py** — Auto-Scan nach Cache-Load (QTimer 2s)
- [x] (Claude Sonnet 4.6): **main_window.py** — Auto-Scan nach Rust-Engine-Toggle (QTimer 3s + _trigger_rust_browser_scan)
- P7 Plugin-Hosting komplett: IBStream + CLAP Streams + CLAP MIDI + LV2 Atom + Browser-Integration

## v0.0.20.741 — 🔧 Advanced Sampler Fix + 1/64 Snap (2026-03-22)

- [x] (Claude Sonnet 4.6): 1/64 Snap in Toolbar
- [x] (Claude Sonnet 4.6): Advanced Sampler vollständige State-Kette (Widget→instrument_state→audio_engine)

## v0.0.20.746 — P0A Rust-Disconnect + P0B Sampler + P0D Crash-Reporter (2026-03-23)

- [x] (Claude Sonnet 4.6, 2026-03-23): **P0A Root-Cause** — ScanPlugins blockierte RT-Audio-Callback → cpal XRun → IPC-EOF
- [x] (Claude Sonnet 4.6, 2026-03-23): **P0A engine.rs** — ScanPlugins → pydaw-plugin-scan Background-Thread
- [x] (Claude Sonnet 4.6, 2026-03-23): **P0A bridge.py** — _do_reconnect_with_backoff() + _schedule_reconnect()
- [x] (Claude Sonnet 4.6, 2026-03-23): **P0B multisample_engine.py** — Scrawl-Envelope in EnvState.step() + _activate_voice()
- [x] (Claude Sonnet 4.6, 2026-03-23): **P0B project_service.py** — _flush_advanced_sampler_states() vor save
- [x] (Claude Sonnet 4.6, 2026-03-23): **P0D app.py** — _install_crash_reporter() + sys.excepthook + crash.log + QMessageBox
- [x] (Claude Sonnet 4.6, 2026-03-23): **smoke_test.py** — 5 neue Regression-Checks [6/6]


## v0.0.20.828 — VST3 Main-Thread Instrument Load (2026-03-26)

- [x] (OpenAI GPT-5.4 Thinking, 2026-03-26): **AudioEngine** — VST3-Instrumente preemptive auf den Qt-Main-Thread verschoben, Worker-Retry-Sturm entfernt, Stream-Update nach erfolgreichem Main-Thread-Load abgesichert
## v0.0.20.830 — Surge XT CLAP Editor Surrogate (2026-03-26)

- [x] (OpenAI GPT-5.4 Thinking, 2026-03-26): **Surge XT CLAP Editor-Surrogate** — Linux/X11 nutzt fuer Surge XT einen externen VST3-Surrogate-Editor statt des blockierenden CLAP-Helper-Pfads
- [x] (OpenAI GPT-5.4 Thinking, 2026-03-26): **QProcess-Haertung** — parent-loser Editor-Prozess + Registry + widget-sichere Button/Status-Updates verhindern `QProcess destroyed` / `QLabel deleted` Folgefehler
