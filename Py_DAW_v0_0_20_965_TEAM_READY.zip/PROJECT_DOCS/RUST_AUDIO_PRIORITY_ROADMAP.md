# 🦀 RUST AUDIO ENGINE — PRIORITÄTS-ROADMAP

**STATUS: HÖCHSTE PRIORITÄT — NÄCHSTE SESSION ZUERST**
**Problem:** GIL-Blockade bei GUI-Interaktion → Audio-Stutter, XRuns schon bei 5 Tracks
**Lösung:** Rust-Engine muss Audio DIREKT ausgeben, Python nur noch GUI

---

## Das Problem (MUSS GELÖST WERDEN)

```
AKTUELL (kaputt):
┌─────────────────────────────────────────────────────┐
│ Python-Prozess (EIN Prozess, EIN GIL)               │
│                                                      │
│ UI Thread ──────█████ Slider █████ Paint ████────── │
│                      ↑ GIL                           │
│ Audio Thread ──WAIT──── render ──WAIT──── render ── │
│                 ↑ BLOCKIERT! → XRun!                │
└─────────────────────────────────────────────────────┘
Ergebnis: 1 XRun bei 5 Tracks, 40ms Spikes, Audio stottert bei GUI-Bedienung

ZIEL (funktioniert):
┌──────────────────────┐    IPC     ┌──────────────────────┐
│ Python-Prozess       │ ◄═══════► │ Rust-Prozess         │
│ NUR GUI + Control    │  Commands  │ Audio + DSP          │
│ - Slider bewegen     │ ────────► │ - cpal/PipeWire Out  │
│ - Plugins zeichnen   │           │ - MIDI Processing    │
│ - Waveform malen     │ ◄──────── │ - Plugin Rendering   │
│ (GIL egal!)          │  Meters   │ - Sample Playback    │
└──────────────────────┘           └──────────────────────┘
Ergebnis: GUI kann machen was sie will, Audio läuft UNABHÄNGIG
```

---

## Phase RA1: Rust Audio Output (ZUERST!)

### RA1.1: cpal Audio-Output
- [x] Dependency: `cpal = "0.15"` in pydaw_engine/Cargo.toml
- [x] `audio_output.rs`: cpal Host → Device → Stream öffnen
- [x] Auto-Detect: PipeWire → PulseAudio → ALSA → JACK Fallback
- [x] Samplerate: 44100/48000/96000 konfigurierbar
- [x] Buffer Size: 64/128/256/512/1024 konfigurierbar
- [x] Callback: `stream.build_output_stream(move |data, _| { mix_audio(data) })`
- [x] Fehler-Handling: Device lost → reconnect

**Datei:** `pydaw_engine/src/audio_output.rs`
```rust
use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};

pub struct AudioOutput {
    stream: Option<cpal::Stream>,
    sample_rate: u32,
    buffer_size: u32,
    channels: u16,
}

impl AudioOutput {
    pub fn new(sr: u32, buf: u32) -> Self { ... }
    pub fn start(&mut self, render_fn: impl FnMut(&mut [f32]) + Send + 'static) { ... }
    pub fn stop(&mut self) { ... }
}
```

### RA1.2: Audio Render Loop in Rust
- [x] `render.rs`: Mixing-Loop der alle Tracks zusammenmischt
- [x] Pro Track: MIDI → Synth/Sampler → FX Chain → Bus → Master
- [x] Lock-free Ringbuffer für Audio-Daten (kein Mutex im Audio-Thread!)
- [x] Echtzeit-sicher: keine Allocations, kein I/O im Audio-Callback
- [x] XRun-Counter: eigener Zähler in Rust (nicht Python)

**Datei:** `pydaw_engine/src/render.rs`

### RA1.3: IPC Kommandos erweitern
Neue Kommandos die Python → Rust schickt:
- [x] `AudioStart { device, sr, buffer_size }` → Rust öffnet cpal Stream
- [x] `AudioStop` → Stream stoppen
- [x] `SetVolume { track_id, volume }` → Track-Lautstärke
- [x] `SetPan { track_id, pan }` → Track-Panning
- [x] `SetMute { track_id, mute }` → Track Mute/Solo
- [x] `NoteOn { track_id, note, velocity }` → MIDI Note
- [x] `NoteOff { track_id, note }` → MIDI Note Off
- [x] `SetParam { track_id, param_id, value }` → Plugin-Parameter

Neue Events die Rust → Python schickt:
- [x] `Meters { track_id, peak_l, peak_r, rms_l, rms_r }` → VU Meter
- [x] `PlaybackPosition { beat, sample }` → Playhead Position
- [x] `XRunCount { count }` → XRun Zähler
- [x] `CpuLoad { percent }` → Rust CPU Last

**Datei:** `pydaw_engine/src/ipc.rs` (erweitern)

---

## Phase RA2: MIDI in Rust

### RA2.1: MIDI Input direkt in Rust
- [ ] Dependency: `midir = "0.9"` in Cargo.toml
- [ ] MIDI Ports öffnen (nanoKEY2, nanoKONTROL2 etc.)
- [ ] MIDI → Audio Thread Lock-free weiterleiten
- [ ] MIDI Learn: CC-Werte an Parameter binden

### RA2.2: MIDI Playback in Rust
- [ ] MIDI Clips aus Python laden (via IPC: `LoadMidiClip { track_id, notes }`)
- [ ] Playback-Position → welche Noten gerade aktiv
- [ ] Scheduling: Sample-genaues Timing (nicht Beat-basiert wie Python)

---

## Phase RA3: Built-in Synthesizer in Rust

### RA3.1: Basis-Synth (AETERNA in Rust)
- [ ] Oszillatoren: Sine, Saw, Square, Triangle, Noise
- [ ] Filter: SVF (State Variable Filter) — Low/High/Band/Notch
- [ ] Envelope: ADSR
- [ ] LFO: Sine, Triangle, Square → Filter/Pitch/Amp
- [ ] Polyphonie: 16 Stimmen

### RA3.2: Sample Player
- [ ] WAV/FLAC Dateien laden (in Rust, nicht Python)
- [ ] Pitch-Shifting (einfach: Playback-Rate ändern)
- [ ] Loop Points

---

## Phase RA4: Python-seitige Änderungen

### RA4.1: Audio Engine Switch
- [x] `engine_migration.py`: `should_use_rust("audio_output") → True`
- [x] Python Audio-Engine NICHT mehr starten wenn Rust Audio aktiv
- [x] sounddevice/PortAudio komplett deaktivieren
- [x] Nur noch IPC-Kommandos an Rust senden

### RA4.2: UI → Rust Brücke
- [x] Slider-Änderung → `SetParam` IPC Kommando
- [x] Transport (Play/Stop) → `PlaybackStart/Stop` IPC
- [x] VU Meter ← `Meters` Events von Rust empfangen
- [x] Playhead ← `PlaybackPosition` Events

### RA4.3: Benchmark aktualisieren
- [ ] Rust Audio Playback MESSEN (nicht mehr 0µs)
- [ ] Winner-Logik: Rust vs Python tatsächlich vergleichen
- [ ] Anzeige in UI: "🦀 Rust Audio: AKTIV | Latenz: 5.3ms | CPU: 2%"

### RA4.4: Audio-Einstellungen Dialog
- [x] Neuer Bereich: "🦀 Rust Audio Output"
- [x] Device-Auswahl (cpal enumeriert Devices)
- [x] Samplerate, Buffer Size
- [x] "Test: Start (Sine)" → Test-Ton über Rust
- [x] Status-Anzeige: "Rust Audio: ✅ Aktiv | PipeWire | 48kHz | 256 Samples"

---

## Aktueller Zustand der Dateien

### pydaw_engine/src/main.rs (AKTUELL)
```
- IPC Socket Server (Unix Domain Socket)
- Empfängt Kommandos von Python
- Sendet Events zurück
- KEIN Audio Output (nur IPC-Relay)
```

### pydaw_engine/Cargo.toml (AKTUELL)
```toml
[dependencies]
serde = { version = "1", features = ["derive"] }
serde_json = "1"
hound = "3.5"          # WAV Dateien
rmp-serde = "1"        # MessagePack
# FEHLT: cpal, midir
```

### Was hinzugefügt werden muss:
```toml
# Audio Output
cpal = "0.15"

# MIDI Input
midir = "0.9"

# Lock-free Ringbuffer
ringbuf = "0.3"

# Resampling (optional)
rubato = "0.14"
```

---

## Empfohlene Reihenfolge für nächste Session

```
1. RA1.1 — cpal Audio Output (Sine-Ton als Test)     ~30 min
2. RA1.2 — Render Loop (leere Buffers füllen)         ~20 min
3. RA1.3 — IPC Kommandos (AudioStart/Stop)            ~20 min
4. RA4.1 — Python: Rust Audio aktivieren               ~15 min
5. RA4.4 — Audio-Einstellungen: "Test Sine" Button     ~15 min
6. TESTEN — Sine-Ton über Rust hören!                  ~10 min
```

**Danach:** MIDI (RA2), Synth (RA3), Mixer (RA4.2)

---

## Wichtige Regeln für die Implementierung

1. **NICHTS im Audio-Callback allocaten** — kein `Vec::new()`, kein `String`, kein `Box`
2. **Kein Mutex im Audio-Thread** — nur lock-free Atomics + Ringbuffer
3. **cpal Callback ist `FnMut + Send + 'static`** — Ownership beachten
4. **Fehler nie paniken** — `unwrap()` verboten im Audio-Pfad, nur `unwrap_or_default()`
5. **Python GIL NIE in Rust anfassen** — die ganze Pointe ist GIL-Freiheit

---

*Dieser Roadmap hat HÖCHSTE PRIORITÄT. Audio-Stutter bei GUI-Bedienung macht die DAW unbenutzbar. Erst wenn Rust Audio läuft, kann an Features (KI-Komposition etc.) weitergearbeitet werden.*
