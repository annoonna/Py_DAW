# 🎬 Py_DAW Video & Video-KI — Benutzerhandbuch

**Version:** v0.0.20.952
**Stand:** April 2026
**Für:** Py_DAW / ChronoScaleStudio

---

## Inhaltsverzeichnis

1. Überblick — Was kann Py_DAW mit Video?
2. Schnellstart — Erstes Video in 2 Minuten
3. Video laden & Vorschau
4. Der Video-Editor (Timeline)
5. Werkzeuge & Tastenkürzel
6. Clip-Eigenschaften
7. Filter & Farbkorrektur
8. KI-Werkzeuge (Clip Properties)
9. Transitions (Übergänge)
10. Automation (Opacity, Speed, Volume)
11. Timecode Pro (SMPTE)
12. Video-KI Panel — Analyse & Assistent
13. Text-Editor (Whisper Transkription)
14. Smart Cut — Automatisches Schneiden
15. Mood Matcher — Film-Looks
16. Multi-Cam
17. Export (Video, Untertitel, EDL/XML)
18. Python Console — Video-API
19. Collab — Video im Team bearbeiten
20. Tipps & Fehlerbehebung

---

## 1. Überblick — Was kann Py_DAW mit Video?

Py_DAW ist die **erste Open-Source-DAW mit integriertem Video-Editor**. Du musst nicht zwischen DAW und NLE (Premiere, DaVinci) hin- und herwechseln — alles passiert in einem Programm.

Was Py_DAW kann, was keine andere DAW kann:

- Video-Editing direkt in der DAW (nicht nur Playback wie Cubase/Pro Tools)
- Video-Schnitte auf dem Beat-Grid (beat-synced Cuts)
- KI-Szenen-Erkennung mit automatischen Markern
- KI-Dialog-Erkennung mit Auto-Duck für Musik
- Whisper-Transkription: Text bearbeiten = Video schneiden
- 15 Film-Look Presets (Cinematic, Noir, Teal/Orange…)
- GPU-beschleunigtes Decoding (VAAPI, NVDEC, Vulkan)
- Multi-Cam Sync über Audio-Wellenform
- Export als EDL, FCP XML, SRT, VTT

---

## 2. Schnellstart — Erstes Video in 2 Minuten

```
1. Py_DAW starten
2. Eine Videodatei (.mp4, .mkv, .mov, .avi) in den Browser ziehen
   ODER: Datei → Öffnen → Video auswählen
3. Video aus dem Browser auf die Arrangement-Timeline ziehen
4. → Automatisch: Video-Spur wird erstellt,
     Thumbnails erscheinen, Video-Preview öffnet sich
5. Play drücken → Video + Audio laufen synchron
6. Unten auf "Video" Tab klicken → Video-Editor öffnet sich
```

**Das war's.** Du hast jetzt einen Video-Clip im Arrangement, kannst ihn schneiden, filtern und mit deiner Musik synchronisieren.

---

## 3. Video laden & Vorschau

### Video-Preview Panel

Wenn ein Video geladen ist, öffnet sich automatisch das **Video-Preview** Dock-Widget (oben links oder frei verschiebbar). Es zeigt:

- Das aktuelle Frame passend zur Playhead-Position
- SMPTE Timecode (HH:MM:SS:FF)
- Transport-Buttons (Play, Stop, zum Anfang)

Das Preview aktualisiert sich live beim Abspielen und beim Scrubben.

### Unterstützte Formate

Alles was ffmpeg kann:

- **Video:** MP4, MKV, AVI, MOV, WebM, FLV, WMV, MPG
- **Codecs:** H.264, H.265/HEVC, VP9, AV1, ProRes
- **Audio:** AAC, MP3, WAV, FLAC, Opus, Vorbis

### Video-Spur im Arrangement

Nach dem Laden erscheint der Video-Clip im Arrangement mit echten Filmstrip-Thumbnails. Die Thumbnails werden im Hintergrund generiert — bei langen Videos dauert es ein paar Sekunden.

---

## 4. Der Video-Editor (Timeline)

Klicke unten auf den **"Video"** Tab (neben Audio, Notation, Piano Roll) um den Video-Editor zu öffnen.

### Was du siehst

```
┌─────────────────────────────────────────────────────────┐
│ 🎬 Video-Editor │ Werkzeuge │ Snap │ FPS │ DF │ TC │    │
├─────────────────────────────────────────────────────────┤
│ 00:00:00:00  00:00:02:00  00:00:04:00  00:00:06:00     │ ← Timecode-Leiste
│ Bar 1        Bar 2        Bar 3        Bar 4           │ ← Beat-Grid
│ ┌──────────┐┌──────────┐┌──────────┐┌──────────┐      │
│ │ Thumb 1  ││ Thumb 2  ││ Thumb 3  ││ Thumb 4  │      │ ← Filmstrip
│ │          ││          ││          ││          │      │
│ └──────────┘└──────────┘└──────────┘└──────────┘      │
│        ▲ Playhead                                       │
│ Tool: SELECT │ Clip: 0.0-4.0 │ BPM: 120 │ Snap: Beat  │ ← Info-Leiste
└─────────────────────────────────────────────────────────┘
```

### Rechts daneben: Text-Editor Panel

Der Text-Editor zeigt die Whisper-Transkription. Mehr dazu in Kapitel 13.

---

## 5. Werkzeuge & Tastenkürzel

### Werkzeuge (Toolbar oder Tastatur)

| Taste | Werkzeug | Was es tut |
|-------|----------|-----------|
| **1** | 👆 Auswahl (Select) | Clips auswählen, verschieben |
| **2** | ✂ Messer (Knife) | Clip an Klickposition splitten |
| **3** | ↔ Trimmen (Trim) | Clip-Ränder ziehen (Start/Ende ändern) |
| **4** | ⇄ Slip | Inhalt im Clip verschieben (Ränder bleiben) |
| **Q** | ☐ Lasso | Rechteck-Auswahl über mehrere Clips |
| **H** | ✋ Hand | Timeline scrollen (Pan) |
| **Z** | 🔍 Lupe | Zoom in (Klick), Zoom out (Alt+Klick) |
| **C** | 🎯 Smart Context | Automatischer Tool-Wechsel je nach Klickposition |
| **A** | 📈 Automation Draw | Opacity/Speed/Volume Kurven malen |

### Allgemeine Tastenkürzel

| Taste | Funktion |
|-------|----------|
| **S** | Split (Clip am Playhead schneiden) |
| **Del** | Ausgewählten Clip löschen |
| **Shift+Del** | Ripple Delete (löschen + Lücke schließen) |
| **Ctrl+C** | Kopieren |
| **Ctrl+V** | Einfügen |
| **Ctrl+D** | Duplizieren |
| **Ctrl+J** | Clips zusammenfügen (Join) |
| **Ctrl+A** | Alle Clips auswählen |
| **Ctrl+G** | Ausgewählte Clips gruppieren |
| **Ctrl+Shift+G** | Gruppe auflösen |
| **Ctrl+Z** | Rückgängig (Undo) |
| **L** | Loop ein/aus |
| **G** | Ghost-Clips ein/aus |
| **T** | Timecode-Eingabe (zu exaktem TC springen) |
| **+/-** | Zoom in/out |

### Snap-Raster

| Taste | Raster |
|-------|--------|
| **5** | Snap aus |
| **6** | 1 Beat |
| **7** | 1/2 Beat |
| **8** | 1/4 Beat |
| **9** | 1 Bar (4 Beats) |

Oder über die Snap-Dropdown-Box in der Toolbar: Bar, Beat, 1/2, 1/4, Off.

### Smart Context Tool (C)

Der Smart Context wechselt automatisch das Werkzeug basierend darauf, wo du klickst:

- Klick auf **Clip-Rand** → Trim Tool
- Klick auf **Clip-Mitte** → Move Tool
- Klick auf **leere Fläche** → Selection
- Klick auf **Header (Timecode-Leiste)** → Playhead setzen
- Klick auf **Automation-Lane** → Draw Tool

---

## 6. Clip-Eigenschaften

Öffne die Clip-Eigenschaften durch:
- **Dreieck-Menü** (▼) am Clip → "Eigenschaften"
- **Rechtsklick** auf Clip → "Eigenschaften"
- **Doppelklick** auf Clip

### Transparenz

- **Opacity** (0–100%): Wie durchsichtig der Clip ist. 100% = voll sichtbar.

### Geschwindigkeit

- **Speed** (0.1×–4.0×): Video-Geschwindigkeit
- Schnellwahl-Buttons: ¼×, ½×, 1×, 2×, 4×, Rückwärts

### Blendmodus

- Normal, Multiply, Screen, Overlay, Add, Difference, etc.
- Wie Photoshop-Ebenen — bestimmt wie sich überlappende Clips mischen.

### Fade In/Out

- **Fade In** (0–16 Beats): Einblendung am Anfang
- **Fade Out** (0–16 Beats): Ausblendung am Ende

### Anwenden-Button

**Wichtig:** Nach jeder Änderung musst du **"✅ Anwenden"** klicken, damit die Werte gespeichert werden! Ohne Anwenden gehen die Änderungen verloren.

---

## 7. Filter & Farbkorrektur

Im Clip-Eigenschaften-Dialog findest du die Filter-Sektion:

### Basis-Filter (Slider)

| Filter | Bereich | Standard | Was es tut |
|--------|---------|----------|-----------|
| ☀ Helligkeit | -1.0 – 1.0 | 0.0 | Bild heller/dunkler |
| ◐ Kontrast | 0.0 – 3.0 | 1.0 | Unterschied hell/dunkel |
| 🎨 Sättigung | 0.0 – 3.0 | 1.0 | Farbintensität (0 = S/W) |
| 💨 Weichzeichner | 0.0 – 10.0 | 0.0 | Bild weichzeichnen (Blur) |
| 🔪 Schärfe | 0.0 – 5.0 | 0.0 | Schärfen |
| 🔲 Vignette | 0.0 – 1.0 | 0.0 | Dunkle Ränder |

### Filter-Presets (Rechtsklick auf Clip)

Vorgefertigte Filter-Kombinationen:

| Preset | Effekt |
|--------|--------|
| Warm Sunset | Warm, gesättigt, leicht hell |
| Cool Blue | Kühl, entsättigt, blauer Farbton |
| Film Noir | Schwarzweiß, hoher Kontrast, Vignette |
| Vintage 8mm | Verblasst, warm, Vignette |
| High Contrast | Sehr kontrastreich, scharf |
| Soft Dreamy | Weich, hell, verträumt |

### Nicht-destruktiv

Alle Filter sind **nicht-destruktiv** — das Originalvideo wird nie verändert. Die Filter werden erst beim Export angewendet (ffmpeg filter_complex).

---

## 8. KI-Werkzeuge (Clip Properties)

Im Clip-Eigenschaften-Dialog unter **"🤖 KI-Werkzeuge"** findest du 6 KI-Tools:

### 🎵 Beat-Sync Cuts

**Was:** Schneidet den Video-Clip automatisch an jeder Bar-Grenze (alle 4 Beats).

**Wie:** Klicke den Button → die Schnitte passieren sofort. Der eine Clip wird in mehrere Clips aufgeteilt, jeder exakt einen Takt lang.

**Ergebnis:** 60-Sekunden-Video bei 120 BPM → ~29 Schnitte, jeder Clip = 1 Bar.

**Tipp:** Ändere die BPM vor dem Klicken, um die Schnitt-Frequenz zu steuern.

### 🎨 Mood Color

**Was:** Passt Sättigung, Kontrast und Helligkeit automatisch an die Stimmung der Musik an.

**Voraussetzung:** Das Video muss vorher im **Video-KI Panel** analysiert worden sein (siehe Kapitel 12).

**Wie:** Video-KI Panel → "Alles analysieren" → dann Mood Color klicken → dann "Anwenden".

### 🏃 Motion Match

**Was:** Setzt die Video-Geschwindigkeit auf 0.5× (Slow-Motion für ruhige Abschnitte).

**Wie:** Klicke den Button → Speed wird auf 0.5× gesetzt → "Anwenden" klicken.

**Hinweis:** Aktuell nur ein einfacher Slow-Mo-Effekt. Zukünftig wird die Geschwindigkeit der Musik-Energie folgen.

### 🌅 Auto-Fade

**Was:** Setzt automatisch Fade In = 2 Beats und Fade Out = 2 Beats.

**Wie:** Klicke den Button → Werte werden intern gesetzt → "Anwenden" klicken.

**Hinweis:** Die Slider im Dialog aktualisieren sich noch nicht visuell — die Werte werden aber korrekt gespeichert.

### 🎬 Szenen-Farbe

**Was:** Wendet für jede erkannte Szene eine eigene Farbkorrektur an, basierend auf der dominanten Farbe der Szene.

**Voraussetzung:** Video-KI-Analyse muss vorher gelaufen sein.

### ❄ Freeze @ Peak

**Was:** Setzt ein Standbild (Freeze Frame) an der lautesten Stelle des Clips.

**Hinweis:** Aktuell ein Platzhalter — setzt den Freeze bei ~30 Sekunden. Echte Peak-Erkennung folgt.

---

## 9. Transitions (Übergänge)

### Verfügbare Transition-Typen

| Transition | Beschreibung |
|-----------|-------------|
| Crossfade | Sanfte Überblendung (Standard) |
| Dissolve | Überblendung mit Easing |
| Wipe (Links/Rechts/Oben/Unten/Diagonal) | Wischblende in eine Richtung |
| Slide (Links/Rechts) | Clip gleitet rein/raus |
| Push (Links/Rechts) | Neuer Clip schiebt alten weg |
| Dip to Black | Ausblenden → Schwarz → Einblenden |
| Dip to White | Ausblenden → Weiß → Einblenden |

### Transition hinzufügen

1. Zwei Clips nebeneinander platzieren
2. **Rechtsklick** zwischen die Clips
3. "Transition hinzufügen" → Typ wählen
4. Transition-Dauer wird in Beats angegeben (beat-synced!)

### Transition entfernen

- Rechtsklick auf die Transition → "Entfernen"

---

## 10. Automation (Opacity, Speed, Volume)

### Automation Draw Tool (A)

1. Drücke **A** oder klicke das 📈 Symbol in der Toolbar
2. Wähle die Lane: **Opacity**, **Speed** oder **Volume** (Dropdown in der Toolbar)
3. Klicke in den Clip um Breakpoints zu setzen
4. Ziehe Breakpoints um die Kurve zu formen

### Kurventypen

- **Linear:** Gerade Linie zwischen Punkten
- **Bezier:** Glatte Kurve mit Kontrollpunkten

### Preset-Kurven

Klicke "Preset" in der Toolbar:

| Preset | Effekt |
|--------|--------|
| Fade In | Langsam von 0 auf 1 |
| Fade Out | Langsam von 1 auf 0 |
| S-Curve | Sanfter S-förmiger Übergang |
| Bell | Hoch in der Mitte, niedrig an den Rändern |

### Automation löschen

- Rechtsklick auf einen Breakpoint → "Punkt löschen"
- Oder: Breakpoint nach unten/oben aus dem Bereich ziehen

---

## 11. Timecode Pro (SMPTE)

### Timecode-Anzeige

Oben rechts im Video-Editor siehst du den aktuellen SMPTE Timecode: **00:00:00:00** (HH:MM:SS:FF)

### FPS einstellen

Wähle die Framerate in der Toolbar-Dropdown:
23.976, 24, 25, 29.97, 30, 50, 59.94, 60

### Drop-Frame / Non-Drop-Frame

- Klicke **DF** in der Toolbar um zwischen Drop-Frame und Non-Drop-Frame umzuschalten
- Drop-Frame (DF): Für 29.97/59.94 fps (US-Standard, NTSC)
- Non-Drop-Frame (NDF): Für alle anderen Framerates

### Zu Timecode springen

1. Drücke **T**
2. Gib den Timecode ein (z.B. "00:01:30:00")
3. Enter → Playhead springt zu dieser Position

---

## 12. Video-KI Panel — Analyse & Assistent

Das Video-KI Panel ist das Herzstück der KI-Features. Öffne es über **Ansicht → Video-KI** oder das Dock-Widget.

### Video-KI Analyse starten

1. Video laden (wie in Kapitel 3)
2. Im Video-KI Panel: **"🎬 Alles analysieren"** klicken
3. Warten (dauert je nach Videolänge 10–60 Sekunden)
4. Die Analyse läuft im Hintergrund — du kannst weiterarbeiten

### Was die Analyse findet

**Tab "Szenen":**
- Liste aller erkannten Szenenwechsel
- Jede Szene mit Timecode, Dauer und Dominanzfarbe
- Klick auf Szene → Playhead springt dorthin

**Tab "Dialog":**
- Erkannte Sprachregionen (wo jemand spricht)
- Start/Ende mit Dauer
- **"🔇 Auto-Duck"** Button → Erzeugt Automation-Punkte die die Musik leiser machen wo gesprochen wird

**Tab "Vorschläge":**
- Stimmungs-Analyse pro Szene (Valence, Energy, Tension, Darkness)
- Preset-Vorschläge: "Empfohlen: AETERNA Dark Pad, BPM 70"
- **"🎵 Vertonen"** Button → Wendet den vorgeschlagenen Preset an

**Tab "Extras":**
- Beat-to-Cut Rechner: Zeigt wo Schnitte auf Beats fallen
- Cue-Sheet Generator für ADR/Foley
- Transkription (Whisper)
- SRT Export

### Auto-Duck — Musik ducken wo gesprochen wird

1. Video-KI analysieren lassen
2. Tab "Dialog" öffnen
3. **"🔇 Auto-Duck"** klicken
4. Parameter einstellen:
   - Duck-Tiefe: -12 dB (Standard)
   - Fade-Zeit: 200ms
   - Schwelle: Wie empfindlich die Dialog-Erkennung ist
5. Die Automation wird für alle Musik-Tracks erzeugt

---

## 13. Text-Editor (Whisper Transkription)

Der Text-Editor erscheint rechts neben der Video-Timeline (als Splitter-Panel).

### Whisper installieren

Für echte Transkription brauchst du Whisper:

```bash
# In deinem venv:
pip install faster-whisper

# Oder systemweit:
pip install faster-whisper --break-system-packages
```

Ohne Whisper funktioniert alles — es wird nur ein Platzhalter-Text angezeigt.

### Transkription starten

1. Video laden
2. Im Text-Editor Panel: **"🎤 Transkribieren"** klicken
3. Modell wählen:
   - **tiny:** Schnell, weniger genau (empfohlen zum Testen)
   - **base:** Gute Balance (Standard)
   - **small:** Genauer, langsamer
   - **medium:** Sehr genau
   - **large:** Beste Qualität (braucht viel RAM)
4. Sprache wählen: Auto, de, en, fr, es, ...
5. Warten — die Transkription läuft im Hintergrund

### Text-basiertes Editing

**Das ist die revolutionäre Funktion:** Du bearbeitest Text, und das Video wird entsprechend geschnitten.

- **Wort anklicken** → Video springt zu dieser Stelle (Playhead-Seek)
- **Wort löschen (Delete/Backspace)** → Das Wort wird rot durchgestrichen, das Video wird dort geschnitten (Jump Cut)
- **Text markieren + Delete** → Mehrere Wörter auf einmal löschen
- **Ctrl+Z** → Letztes gelöschtes Wort wiederherstellen

### Farbkodierung

| Farbe | Bedeutung |
|-------|-----------|
| Weiß | Normales Wort |
| Rot durchgestrichen | Gelöschtes Wort (wird geschnitten) |
| Gelb | Unsichere Erkennung (Confidence < 50%) |
| Blau hervorgehoben | Aktuelles Wort (Playhead-Position) |

### Wort-Marker auf der Timeline

Gelöschte Wörter werden auch auf der Video-Timeline angezeigt:
- **Blaue Striche** = Wort-Grenzen (aktive Wörter)
- **Rote Flächen** = Gelöschte Regionen (werden beim Export geschnitten)

### Untertitel exportieren

Klicke **"💾 Export"** im Text-Editor:

| Format | Verwendung |
|--------|-----------|
| SRT | YouTube, VLC, die meisten Player |
| VTT (WebVTT) | Web-Videos, HTML5 |
| Text | Einfaches Transkript mit Zeitstempeln |

Oder über Rechtsklick → "Exportieren" → Format wählen.

---

## 14. Smart Cut — Automatisches Schneiden

**Voraussetzung:** Whisper-Transkription muss gelaufen sein.

Das Smart Cut Panel findest du im Video-KI Bereich.

### Analysieren

Klicke **"🔍 Analysieren"** — der Smart Cut Service prüft 4 Kategorien:

### 🗣 Füllwörter entfernen

Erkennt "ähm", "äh", "ehm", "also", "halt", "sozusagen" und ~60 weitere Füllwörter in 5 Sprachen (DE, EN, FR, ES + Universal).

→ Klicke **"✂ Füllwörter entfernen"** → Alle erkannten Füllwörter werden als gelöscht markiert.

### ⏸ Pausen kürzen

Erkennt Stille zwischen Wörtern:
- Kurze Pausen: > 0.8 Sekunden
- Lange Pausen: > 1.5 Sekunden

→ Klicke **"✂ Pausen kürzen"** → Überlange Pausen werden entfernt.

### 🔁 Wiederholungen

Erkennt Stotterer und Neuanfänge: "Ich ich ich wollte sagen" → nur das letzte "Ich" bleibt.

→ Klicke **"✂ Wiederholungen entfernen"**

### 🚀 Auto-Clean

Wendet nur die **sicheren** Vorschläge an (hohe Confidence). Perfekt für den schnellen Durchgang.

### ⭐ Highlight Reel

Wählt automatisch die besten Segmente aus und erstellt ein Highlight-Reel.

1. Zieldauer einstellen (z.B. 30 Sekunden)
2. **"⭐ Highlight Reel erstellen"** klicken
3. Die besten Segmente werden nach Score ausgewählt

### 📐 Zusammenfassung

Kürzt das Video automatisch auf eine Zieldauer.

1. Zieldauer eingeben (z.B. 30 Sekunden)
2. **"📐 Auf Zieldauer kürzen"** klicken
3. Reihenfolge: Füllwörter → Pausen → Wiederholungen → Unsichere Stellen

---

## 15. Mood Matcher — Film-Looks

### 15 Film-Look Presets

| Preset | Beschreibung |
|--------|-------------|
| 🎬 Cinematic | Professioneller Kino-Look |
| 🌅 Warm Cinematic | Goldene Stunde |
| ❄ Cool Cinematic | Thriller/Sci-Fi |
| 📷 Vintage | Verblasst, warm |
| 🖤 Noir | Hartes Schwarzweiß |
| 🔶 Teal/Orange | Hollywood-Blockbuster |
| 🌇 Sunset | Sonnenuntergang |
| 🌙 Moonlight | Nachtszenen |
| ⬜ Bleach Bypass | Entsättigt, kontrastreich |
| 📹 Doku | Neutral, natürlich |
| 👻 Horror | Grünlich, dunkel |
| 💭 Dream | Weich, verträumt |
| 🕹 80er Retro | Kräftige Neon-Farben |
| 📱 Instagram | Warm, sonnig |
| 🎭 Entsättigt | Kriegsfilm/Drama |

### Referenz-Clip Grading

Du kannst auch einen Referenz-Clip laden und dessen Look auf dein Video übertragen:

1. **"📂 Referenz laden"** → Video/Bild auswählen
2. Das System analysiert Helligkeit, Sättigung, Kontrast und Farbton
3. **"🎨 Anwenden"** → Der Look wird auf deinen Clip übertragen

### Audio-EQ Match

Zusätzlich zum visuellen Look kannst du auch den Audio-Charakter eines Referenz-Clips übernehmen:

1. Referenz-Clip laden (wie oben)
2. **"🔊 Audio-EQ übertragen"** klicken
3. Loudness und Frequenzbalance werden angepasst

---

## 16. Multi-Cam

### Kameras hinzufügen

1. Mehrere Video-Dateien laden (jede Kamera = eine Datei)
2. Im Multi-Cam Panel: Quellen zuweisen

### Synchronisieren

3 Methoden:

| Methode | Genauigkeit | Wann nutzen |
|---------|-------------|-------------|
| Audio-Sync | Sehr hoch | Wenn alle Kameras den gleichen Ton aufnehmen |
| Clap Detection | Hoch | Wenn eine Filmklappe benutzt wurde |
| Timecode | Perfekt | Wenn alle Kameras SMPTE Timecode haben |

### Kamera-Wechsel

- Definiere Schnittpunkte auf der Timeline
- Wähle welche Kamera ab welchem Zeitpunkt aktiv ist
- Transition-Typ pro Schnitt: Cut, Dissolve, Wipe

---

## 17. Export

### Video-Export (mit Filtern)

1. **Datei → Exportieren → Video** (oder Projekt → Export)
2. Alle Filter, Transitions und Automation werden über ffmpeg filter_complex angewendet
3. Format wählen: MP4 (H.264), MKV (H.265), WebM

### Untertitel-Export

Über den Text-Editor:
- **SRT** → Für YouTube, VLC, Premiere
- **VTT** → Für Web-Videos

### NLE-Interchange Export

Für die Weiterarbeit in anderen Programmen:

| Format | Kompatibel mit |
|--------|---------------|
| EDL (CMX 3600) | Alle NLEs |
| FCP XML (XMEML v5) | DaVinci Resolve, Premiere Pro, Final Cut |
| AAF Manifest | Pro Tools, Media Composer |
| OMF Manifest | Legacy-Systeme |

### Cue-Sheet Export

Aus dem Video-KI Panel:
- **CSV** → Für Excel/Tabellenkalkulation
- **TXT** → Professionelles Cue-Sheet Format

---

## 18. Python Console — Video-API

Öffne die Console mit **Ctrl+Alt+P**. Das `video` Objekt gibt dir Zugriff:

### Clips

```python
video.clips                          # Liste aller Video-Clips
video.set_opacity("clip_id", 0.5)    # Opacity setzen
video.set_speed("clip_id", 2.0)      # Geschwindigkeit setzen
video.add_filter("clip_id", "bw")    # Filter hinzufügen
```

### Filter & Automation

```python
video.filters("clip_id")             # Filter-Chain anzeigen
video.automation("clip_id")          # Automation-Daten
video.add_fade_in("clip_id", 4)      # 4-Beat Fade In
```

### Transitions & Timecode

```python
video.transitions                    # Alle Transitions
video.timecode                       # TC-Einstellungen
video.set_fps(29.97)                 # FPS ändern
```

### Transkription (VE11)

```python
video.transcribe("/pfad/video.mp4")                    # Transkription starten
video.transcript("/pfad/video.mp4")                     # Text anzeigen
video.words("/pfad/video.mp4")                          # Wort-Liste mit Zeiten
video.export_srt("/pfad/video.mp4", "/pfad/output.srt") # SRT exportieren
video.export_vtt("/pfad/video.mp4", "/pfad/output.vtt") # VTT exportieren
```

---

## 19. Collab — Video im Team bearbeiten

### Video-Collab starten

1. PC1: **Collab → Server starten**
2. PC2: **Collab → Verbinden** (IP eingeben)
3. Video-Operationen werden automatisch synchronisiert

### Was wird synchronisiert?

- Video-Clips hinzufügen/verschieben/löschen/splitten
- Clip-Eigenschaften (Opacity, Speed, Filter)
- Transitions
- Automation-Kurven
- Timecode-Einstellungen

### Video-Datei Transfer

- Dateien ≤ 200 MB werden automatisch übertragen
- Dateien > 200 MB: Benachrichtigung wird angezeigt

### Review-Kommentare

Im Cloud-Collab-Modus kannst du Kommentare auf der Timeline platzieren:

- Klicke an die gewünschte Stelle → Kommentar schreiben
- 4 Prioritäten: Info (blau), Note (gelb), Wichtig (orange), Kritisch (rot)
- Kommentare können beantwortet und als "erledigt" markiert werden

---

## 20. Tipps & Fehlerbehebung

### Video-Preview ist schwarz

- Prüfe ob ffmpeg installiert ist: `ffmpeg -version`
- Prüfe das Video-Format: `ffprobe video.mp4`
- Manche Codecs brauchen zusätzliche Pakete: `sudo apt install ffmpeg`

### Thumbnails laden langsam

- Normal bei langen Videos (>10 Min)
- Die Thumbnails werden im Hintergrund generiert
- Beim nächsten Öffnen sind sie im Cache

### Transkription funktioniert nicht

- Whisper installieren: `pip install faster-whisper`
- Ohne Whisper: Stub-Text wird angezeigt (Platzhalter)
- Bei "backend=none" im Log: Whisper ist nicht installiert

### KI-Werkzeuge zeigen keine Änderung

- **Mood Color / Szenen-Farbe:** Vorher Video-KI analysieren lassen!
- **Auto-Fade:** Werte werden intern gesetzt — "Anwenden" klicken
- **Motion Match:** Setzt Speed auf 0.5× — "Anwenden" klicken

### GPU-Beschleunigung aktivieren

Py_DAW erkennt automatisch die GPU:
- **NVIDIA:** NVDEC (automatisch wenn nvidia-smi verfügbar)
- **Intel/AMD:** VAAPI (automatisch wenn /dev/dri/renderD128 existiert)
- **Vulkan:** Fallback wenn vulkaninfo verfügbar

Falls keine GPU erkannt wird: Software-Decode (funktioniert immer, nur langsamer).

### Performance-Tipps

- Verwende **Proxy-Videos** für lange Clips (Cloud → Proxy generieren)
- Reduziere die Preview-Auflösung bei 4K-Material
- Schließe nicht benötigte Plugins
- GPU-Beschleunigung nutzen wenn verfügbar

---

*Dieses Handbuch bezieht sich auf Py_DAW v0.0.20.952. Features können sich in neueren Versionen ändern.*
