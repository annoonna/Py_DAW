from .aeterna_widget import AeternaWidget

__all__ = ["AeternaWidget"]
