# Session Log — v0.0.20.376
**Datum:** 2026-03-10  
**Bearbeiter:** Claude Sonnet 4.6  
**Vorgänger-Version:** 0.0.20.375  
**Neue Version:** 0.0.20.376

## Bugfixes

### BUG 1 FIXED: VST Editor "plugin file not found" Fehler
**Ursache:** `_vst3_path` speichert das kombinierte PyDAW-Referenzformat:
```
/usr/lib/vst3/lsp-plugins.vst3::pydaw_plugin::Autogain%20Mono
```
Dieses wurde 1:1 als Dateipfad an `pedalboard.load_plugin()` übergeben — pedalboard kennt das Format nicht.

**Fix:** `_launch_editor_process()` ruft jetzt `split_plugin_reference()` aus `vst3_host.py` auf:
```python
from pydaw.audio.vst3_host import split_plugin_reference
real_path, ref_name = split_plugin_reference(self._vst3_path)
# → ("/usr/lib/vst3/lsp-plugins.vst3", "Autogain Mono")
```
Nur `real_path` wird als positionales Arg 1 übergeben, `ref_name` (oder `self._plugin_name`) als positionales Arg 2.

### BUG 2 FIXED: VST3-Parameter nicht automatisierbar
**Ursache:** `_build_rows_from_infos()` installierte nur `_install_automation_menu` (Rechtsklick-Menü), aber rief `_register_automatable_param()` **nicht** auf. Dadurch wurden VST3-Params nie im AutomationManager registriert und erschienen nicht in Automation-Lanes.

**Fix:** Analog zu `LV2AudioFxWidget`:
- `self._automation_params: dict = {}` in `__init__` hinzugefügt
- Für Slider-Params: `_register_automatable_param(services, track_id, param_key, info.name, mn, mx, df)` nach den `_install_automation_menu`-Aufrufen
- Für Checkbox-Params: gleiches Pattern + `_install_automation_menu` für Label und Checkbox selbst

## Geänderte Dateien
- `pydaw/ui/fx_device_widgets.py`
  - `__init__`: `_automation_params: dict = {}` hinzugefügt
  - `_launch_editor_process()`: `split_plugin_reference()` Pfad-Splitting
  - `_build_rows_from_infos()`: `_register_automatable_param` für Slider + Checkbox Params
- `pydaw/version.py` / `VERSION` → 0.0.20.376
