# v0.0.20.373 — VST3 Widget Main-Thread Reload Hotfix

**Datum**: 2026-03-10
**Bearbeiter**: GPT-5
**Aufgabe**: Kleinstmöglichen sicheren Fix für VST3-Parameter-Widgets mit Main-Thread-Reload-Fehler plus fehlendem QCheckBox-Import ergänzen
**Ausgangsversion**: 0.0.20.372
**Ergebnisversion**: 0.0.20.373

## Ziel

Nach v0.0.20.370 konnte das Widget Parameter meist direkt aus der laufenden DSP-Instanz holen. Im seltenen Fallback-Fall blieb aber noch ein Restproblem:

- `Plugin ... must be reloaded on the main thread`
- zusätzlich konnte der Bool-Row-Bau an `QCheckBox` scheitern, weil der Import fehlte

Ziel war ein **minimaler Hotfix**, ohne den responsiven Insert oder bestehendes Hosting zurückzubauen.

## Umgesetzte Änderungen

- `pydaw/ui/fx_device_widgets.py`
  - `QCheckBox` sauber in den Widget-Imports ergänzt
  - VST3-Widget merkt sich jetzt, ob ein Main-Thread-Retry schon versucht wurde
  - wenn der bestehende Async-Loader explizit mit einem **Main-Thread-Reload-Hinweis** scheitert, wird automatisch **ein einmaliger Retry im Qt-Main-Thread** geplant
  - normale Plugins behalten weiterhin den bestehenden Async-Fallback

## Sicherheitsprinzip

- Kein Eingriff in Audio-Callback, Routing, Mixer, Transport oder Projektformat
- Kein Rückbau des Runtime-Param-Reuse-Hotfixes aus v0.0.20.370
- Nur UI-/Fallback-Härtung im VST3-Widget

## Benutzerwirkung

- Bool-/Toggle-Parameter im VST3-Widget bauen wieder stabil auf
- Plugins, die im Worker einen Main-Thread-Reload verlangen, bekommen jetzt automatisch einen sicheren Nachladeversuch
- Der normale responsive Insert-Pfad bleibt für unkritische Plugins erhalten

## Tests

- ✅ `python -m py_compile pydaw/ui/fx_device_widgets.py pydaw/audio/vst3_host.py`
- ℹ️ echter Qt-/PyQt6-Lauftest war im Container nicht möglich

## Nächste sichere Schritte

- [ ] Optional einen kleinen Header-Status ergänzen: **Fallback async** / **Fallback main-thread**
- [ ] Optional Diagnose-Hinweis ergänzen, wenn auch der Main-Thread-Retry keine Parameter liefert
