# Session Log — v0.0.20.862

**Datum:** 2026-03-28
**Kollege:** Claude Opus 4.6
**Basis:** v0.0.20.861

## Erledigt

- Chat/Ops Deduplizierung: exclude=sender_id bei Broadcast
- Server-Callbacks Guard wenn Client gleichzeitig verbunden
- LAN-Test bestätigt: Chat funktioniert, aber war doppelt → jetzt einmal

## Geaenderte Dateien
- pydaw/services/collab_service.py
- pydaw/ui/collab_panel.py
