# Session Log — v0.0.20.840

**Datum:** 2026-03-27
**Kollege:** Claude Opus 4.6
**Basis:** v0.0.20.839
**Aufgabe:** Surge XT CLAP Preset-Wechsel bringen keinen neuen Ton (Anno-Report)

## Beobachtung

Anno: "presets reagieren nicht immer wieder der selbe ton auf dem plugin"
Log zeigt: `[CLAP] State loaded: 69464 bytes` bei jedem Wechsel, aber Ton bleibt gleich.

## Root Cause

VST3-State-Blob (IBStream-Format) ist format-inkompatibel mit CLAP-State.
`set_state()` returned True, aber die CLAP-Instanz kann die VST3-Bytes nicht parsen.

## Fix

State-Blob wird nicht mehr auf CLAP angewendet. Stattdessen nur die 775
individuellen Parameter-Werte aus dem Surrogate-Snapshot.

## Geänderte Dateien

- `pydaw/ui/fx_device_widgets.py` — State-Event-Handler
- `VERSION` → 0.0.20.840
- `pydaw/version.py` → 0.0.20.840
- `PROJECT_DOCS/ROADMAP_MASTER_PLAN.md`

## Nächste Schritte

- Hardware-Test: Surge XT CLAP Presets wechseln → Ton muss sich ändern
- Hardware-Test: Shell Frameless (v0.0.20.839) prüfen
