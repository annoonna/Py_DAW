# Session Log — v0.0.20.902

**Datum:** 2026-03-31
**Kollege:** Claude Opus 4.6
**Aufgabe:** Collab Device-Sync Echo-Loop Fix (3 kritische Bugs)

## Was wurde erledigt

### Log-Analyse (anno.txt 2917 Zeilen + onna.txt 2828 Zeilen)
- 994 device_sync Messages in anno.txt identifiziert (Endlos-Loop)
- 238 show_track() Aufrufe in onna.txt (Fenster-Focus-Steal)
- Root Cause: 500ms Device-Monitor erkennt Remote-Aenderungen als "lokal"

### 3 Bugs gefixt in collab_panel.py

**Bug 1 — Echo-Loop (HAUPTURSACHE):**
- Per-Track Cooldown (3s) nach Remote device_sync Empfang
- Hash-Cache sofort aktualisieren bei Remote-Apply
- _suppress_collab_hook Check am Anfang des Monitors

**Bug 2 — Main-Fenster oeffnen sich:**
- Unbedingter show_track() Aufruf entfernt
- Model-Daten werden ohne Focus-Steal gesetzt

**Bug 3 — send_device_change Echo:**
- Cooldown-Check auch beim Senden

## Geaenderte Dateien
- pydaw/ui/collab_panel.py (3 Methoden)

## Status
394/394 kompiliert | Nichts kaputt
