# Session Log — v0.0.20.825

**Datum:** 2026-03-26
**Kollege:** GPT-5.4 Thinking
**Basis:** v0.0.20.824
**Aufgabe:** Tiefe Analyse: Surge XT CLAP Editor friert bei Stage 1 weiter ein

## Problem

Der Restore aus v0.0.20.824 hat die künstliche UI-Sperre korrekt entfernt,
aber auf echter Hardware blieb Surge XT CLAP trotzdem hängen.

Dein Log zeigt sehr klar:
- Container-WinId wird erzeugt
- danach blockiert `gui_stage1_create()`
- GNOME meldet `main.py antwortet nicht`

Nekobi funktioniert weiter normal. Das Problem sitzt also spezifisch im
Surge/JUCE-Stage-1-Create auf Linux/X11.

## Was wurde erledigt

- asynchronen Stage-1-Pfad nur für Surge XT ergänzt
- blockierenden Native-Create aus dem Qt-GUI-Thread herausgenommen
- Main-Thread-Callbacks weiter sauber auf dem Qt-Main-Thread belassen
- Close/Reopen gegen stale Futures abgesichert
- Cleanup gehärtet, damit `destroy_gui()` nicht in einen noch laufenden Stage-1-Call hineinfunkt
- `clap_host.py` dafür um optionales `pump_callbacks=False` erweitert

## Geänderte Dateien

- `pydaw/ui/fx_device_widgets.py`
- `pydaw/audio/clap_host.py`
- `pydaw/version.py`
- `VERSION`
- `CHANGELOG_v0.0.20.825_SURGE_XT_CLAP_ASYNC_STAGE1.md`
- `PROJECT_DOCS/progress/TODO.md`
- `PROJECT_DOCS/progress/DONE.md`
- `PROJECT_DOCS/sessions/SESSION_v0.0.20.825.md`
- `PROJECT_DOCS/sessions/LATEST.md`

## Tests

- `python3 -m py_compile pydaw/ui/fx_device_widgets.py pydaw/audio/clap_host.py`
- kompletter `py_compile`-Lauf über `pydaw/`

## Nächste Schritte

- Surge XT CLAP erneut auf echter Zielmaschine öffnen
- prüfen, ob Log jetzt mindestens zeigt:
  - `Stage 1 (create): async worker start`
  - `Stage 1 (create, async): ok=True`
  - `Stage 2 (set_parent): ...`
  - `Stage 3 (show): ok=True`
- nur falls das weiterhin hängt: optionalen Out-of-Process-Editorpfad **nur für Surge XT** prüfen
