# Session Log — v0.0.20.823

**Datum:** 2026-03-26
**Kollege:** Claude Opus 4.6
**Basis:** v0.0.20.822
**Aufgabe:** CLAP Editor Blacklist nur Surge XT (nicht alle CLAP)

## Problem

v0.0.20.822 blockierte ALLE CLAP-Editoren unter Linux.
Aber nur Surge XT (JUCE-basiert) hat das Deadlock-Problem.
LSP-Plugins, MaGigaverb, MaPitchshift etc. funktionieren einwandfrei.

## Fix

Blanket `sys.platform.startswith("linux")` Check ersetzt durch
Plugin-spezifische Blacklist:

```python
_CLAP_EDITOR_BLACKLIST = {
    "org.surge-synth-team.surge-xt",
    "org.surge-synth-team.surge-xt-fx",
}
```

Nur Surge XT wird geblockt. Alle anderen CLAP-Editoren öffnen normal.

## Geänderte Dateien

- pydaw/ui/fx_device_widgets.py — Blacklist statt Linux-Blanket
- VERSION → 0.0.20.823
