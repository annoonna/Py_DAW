# Session Log — v0.0.20.841

**Datum:** 2026-03-27
**Kollege:** Claude Opus 4.6
**Basis:** v0.0.20.840
**Aufgabe:** Surge XT Presets funktionieren nicht + Darstellungsproblem

## Root Cause (endgueltig)

Die VST3-Surrogate-Architektur war der Fehler:
- Surrogate-Editor lud Surge XT als VST3 (via Pedalboard)
- Live-Instanz ist CLAP
- VST3 Parameter-Namen != CLAP Parameter-Namen -> 0/775 matched
- VST3 State-Format != CLAP State-Format -> Blob nutzlos

## Fix

VST3-Surrogate komplett deaktiviert. Externer Editor nutzt jetzt
clap_gui_process.py direkt mit dem CLAP-Plugin.

## Naechste Schritte

- Hardware-Test: Presets wechseln -> Ton aendert sich
