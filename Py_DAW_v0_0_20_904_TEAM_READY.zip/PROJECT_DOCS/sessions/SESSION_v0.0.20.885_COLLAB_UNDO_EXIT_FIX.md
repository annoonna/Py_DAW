# Session Log — v0.0.20.885

**Datum:** 2026-03-31
**Kollege:** Claude Opus 4.6
**Aufgabe:** Collab Undo-Erweiterung für Track/Clip/BPM Ops + Exit-Segfault Fix

## Was wurde erledigt

### Collab Undo-Erweiterung
Das Undo-System (v0.0.20.876) unterstützte bisher nur Mixer-Ops (Volume/Pan/Mute/Solo).
Jetzt werden automatisch Undo-Einträge für 9 weitere Operation-Typen erstellt:

- BPM-Änderungen (cached alten Wert)
- Clip Move (alte Position + Track)
- Clip Resize (alte Länge)
- Clip Remove (Metadaten vor Löschung erfasst)
- Clip Rename (alter Label)
- Clip Mute (invertiert)
- Track Add (inverse: remove)
- Track Remove (inverse: add mit Name/Kind/Index)
- Track Rename (alter Name)

Zentrale neue Methode: `_build_inverse_payload()` in collab_panel.py.
project_service.py sendet jetzt `_old_*` Felder in allen collab_notify Payloads.

### Exit-Segfault Fix
- Alle QTimer werden in closeEvent() als allererste Aktion gestoppt
- CollapPanel.shutdown() stoppt _collab_timer vor Discovery/Server/Client
- Doppelter _recovery_timer.stop() entfernt

## Geänderte Dateien
- `pydaw/ui/collab_panel.py` — _build_inverse_payload(), BPM undo, Timer-Stop
- `pydaw/services/project_service.py` — _old_* Felder in 6 Methoden
- `pydaw/ui/main_window.py` — Timer-Stopp-Schleife in closeEvent
- `VERSION` — 0.0.20.885

## Nächste Schritte
- Live-Test: Collab Undo für BPM/Track/Clip auf 2 Rechnern
- Live-Test: DAW schließen nach Collab → kein Segfault?
- Undo-Erweiterung: Automation, Device-Chain
