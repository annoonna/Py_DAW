"""Melody & Counterpoint Generator (P2C) — Algorithmic composition tools.

Pure Python, no ML dependencies. Works offline.

Features:
- Bassline generator from chord progression
- Counterpoint assistant (simple species counterpoint rules)
- Lead melody generator
- Motif development (repetition, sequence, inversion, augmentation)
- Scale-aware note suggestion

v0.0.20.808 — Phase P2C
"""

from __future__ import annotations

import logging
import math
import random
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MAJOR_SCALE = [0, 2, 4, 5, 7, 9, 11]
MINOR_SCALE = [0, 2, 3, 5, 7, 8, 10]
DORIAN_SCALE = [0, 2, 3, 5, 7, 9, 10]
MIXOLYDIAN_SCALE = [0, 2, 4, 5, 7, 9, 10]
PENTATONIC_MAJ = [0, 2, 4, 7, 9]
PENTATONIC_MIN = [0, 3, 5, 7, 10]
BLUES_SCALE = [0, 3, 5, 6, 7, 10]

SCALE_MAP = {
    "major": MAJOR_SCALE, "minor": MINOR_SCALE,
    "dorian": DORIAN_SCALE, "mixolydian": MIXOLYDIAN_SCALE,
    "pentatonic_maj": PENTATONIC_MAJ, "pentatonic_min": PENTATONIC_MIN,
    "blues": BLUES_SCALE,
}


def _scale_pitches(root_pc: int, scale: List[int], octave_lo: int = 2,
                   octave_hi: int = 6) -> List[int]:
    """Generate all MIDI pitches in a scale across octave range."""
    pitches = []
    for oct in range(octave_lo, octave_hi + 1):
        for interval in scale:
            p = (oct + 1) * 12 + root_pc + interval
            if 0 <= p <= 127:
                pitches.append(p)
    return sorted(pitches)


def _nearest_scale_pitch(pitch: int, scale_pitches: List[int]) -> int:
    """Snap pitch to nearest scale pitch."""
    if not scale_pitches:
        return pitch
    return min(scale_pitches, key=lambda p: abs(p - pitch))


def _interval_between(p1: int, p2: int) -> int:
    """Semitone interval (signed)."""
    return p2 - p1


# ---------------------------------------------------------------------------
# Bassline Generator
# ---------------------------------------------------------------------------

@dataclass
class BasslineStyle:
    """Configuration for bassline generation."""
    style: str = "root"           # "root" | "walking" | "syncopated" | "octave" | "arpeggiated"
    octave: int = 2               # bass octave
    density: float = 0.5          # 0..1 (note density)
    ghost_notes: bool = False     # include ghost notes (low velocity)
    swing: float = 0.0            # 0..1
    seed: int = 42


def generate_bassline(
    chords: List[Dict[str, Any]],
    *,
    root_pc: int = 0,
    scale_name: str = "major",
    bars: int = 4,
    bpm: float = 120.0,
    style: Optional[BasslineStyle] = None,
) -> List[Dict[str, Any]]:
    """Generate a bassline from a chord progression.

    chords: list of dicts with 'beat', 'duration_beats', 'root_pc', 'quality'
    Returns: list of note dicts {pitch, start, duration, velocity}
    """
    if style is None:
        style = BasslineStyle()

    rng = random.Random(style.seed)
    scale = SCALE_MAP.get(scale_name, MAJOR_SCALE)
    scale_p = _scale_pitches(root_pc, scale, style.octave, style.octave + 1)
    notes: List[Dict[str, Any]] = []

    for chord in chords:
        beat = float(chord.get("beat", 0))
        dur = float(chord.get("duration_beats", 4))
        chord_root = int(chord.get("root_pc", 0))
        quality = str(chord.get("quality", "maj"))
        base_pitch = _nearest_scale_pitch((style.octave + 1) * 12 + chord_root, scale_p)

        # Chord tones
        third = base_pitch + (3 if "min" in quality else 4)
        fifth = base_pitch + 7
        octave_up = base_pitch + 12

        if style.style == "root":
            # Simple root notes on each beat
            steps = max(1, int(dur))
            for i in range(steps):
                notes.append({
                    "pitch": base_pitch,
                    "start": beat + i,
                    "duration": 0.9,
                    "velocity": 100 if i == 0 else 80,
                })

        elif style.style == "octave":
            # Root + octave pattern
            steps = max(1, int(dur))
            for i in range(steps):
                p = base_pitch if i % 2 == 0 else octave_up
                notes.append({
                    "pitch": p, "start": beat + i,
                    "duration": 0.45, "velocity": 100 if i == 0 else 75,
                })

        elif style.style == "walking":
            # Walking bass: chromatic/scale approach notes
            steps = max(1, int(dur))
            targets = [base_pitch, third, fifth, base_pitch + 12]
            for i in range(steps):
                target = targets[i % len(targets)]
                p = _nearest_scale_pitch(target, scale_p)
                # Approach note on last 8th
                notes.append({
                    "pitch": p, "start": beat + i,
                    "duration": 0.8, "velocity": 95 - i * 5,
                })
                if style.density > 0.5 and i < steps - 1:
                    approach = p + rng.choice([-1, 1, -2, 2])
                    notes.append({
                        "pitch": max(24, min(72, approach)),
                        "start": beat + i + 0.5,
                        "duration": 0.4,
                        "velocity": 60,
                    })

        elif style.style == "syncopated":
            # Syncopated: off-beat accents
            pattern_16ths = [0, 3, 6, 8, 10, 13]  # syncopated pattern
            for p16 in pattern_16ths:
                t = beat + p16 * 0.25
                if t >= beat + dur:
                    break
                p = rng.choice([base_pitch, fifth, third])
                vel = 100 if p16 in (0, 6) else 70
                notes.append({
                    "pitch": p, "start": t,
                    "duration": 0.2 + rng.random() * 0.3,
                    "velocity": vel,
                })

        elif style.style == "arpeggiated":
            # Arpeggiated: cycle through chord tones
            arp_notes = [base_pitch, third, fifth, octave_up]
            grid = 0.25  # 16th notes
            t = beat
            idx = 0
            while t < beat + dur:
                p = arp_notes[idx % len(arp_notes)]
                notes.append({
                    "pitch": p, "start": t,
                    "duration": grid * 0.8,
                    "velocity": 90 if idx % 4 == 0 else 70,
                })
                t += grid
                idx += 1

        # Ghost notes
        if style.ghost_notes and dur >= 2:
            for _ in range(int(dur)):
                gt = beat + rng.random() * dur
                notes.append({
                    "pitch": base_pitch + rng.choice([0, 12, -12]),
                    "start": gt,
                    "duration": 0.15,
                    "velocity": rng.randint(25, 45),
                })

    return sorted(notes, key=lambda n: n["start"])


# ---------------------------------------------------------------------------
# Counterpoint Assistant
# ---------------------------------------------------------------------------

def generate_counterpoint(
    melody_notes: List[Dict[str, Any]],
    *,
    root_pc: int = 0,
    scale_name: str = "major",
    interval_preference: str = "third",  # "third" | "sixth" | "mixed"
    motion: str = "contrary",            # "contrary" | "parallel" | "oblique" | "mixed"
    octave_offset: int = -1,             # -1 = below melody, +1 = above
    seed: int = 42,
) -> List[Dict[str, Any]]:
    """Generate a counterpoint line for a given melody.

    Follows simplified species counterpoint rules:
    - Prefer consonant intervals (3rd, 6th, 5th, octave)
    - Avoid parallel 5ths/octaves
    - Prefer contrary motion
    - Start and end on consonant intervals
    """
    if not melody_notes:
        return []

    rng = random.Random(seed)
    scale = SCALE_MAP.get(scale_name, MAJOR_SCALE)
    scale_p = _scale_pitches(root_pc, scale, 1, 7)

    # Consonant intervals in semitones
    consonant = {3, 4, 5, 7, 8, 9, 12, 15, 16}  # thirds, sixths, fifths, octaves

    # Preferred intervals based on setting
    if interval_preference == "third":
        preferred = [3, 4, -3, -4]
    elif interval_preference == "sixth":
        preferred = [8, 9, -8, -9]
    else:
        preferred = [3, 4, 7, 8, 9, -3, -4, -7, -8, -9]

    counter_notes: List[Dict[str, Any]] = []
    prev_counter_pitch = None
    prev_melody_pitch = None

    for note in sorted(melody_notes, key=lambda n: n.get("start", 0)):
        mel_pitch = int(note.get("pitch", 60))
        start = float(note.get("start", 0))
        dur = float(note.get("duration", 1))
        vel = int(note.get("velocity", 80))

        # Generate candidate pitches
        candidates = []
        for interval in preferred:
            cp = mel_pitch + interval + (octave_offset * 12)
            cp_snapped = _nearest_scale_pitch(cp, scale_p)
            if 24 <= cp_snapped <= 108:
                candidates.append(cp_snapped)

        if not candidates:
            candidates = [_nearest_scale_pitch(mel_pitch + octave_offset * 12, scale_p)]

        # Apply motion preference
        best = candidates[0]
        if prev_counter_pitch is not None and prev_melody_pitch is not None:
            mel_dir = mel_pitch - prev_melody_pitch  # melody direction

            scored = []
            for c in candidates:
                score = 0.0
                c_dir = c - prev_counter_pitch

                # Motion scoring
                if motion == "contrary" and mel_dir * c_dir < 0:
                    score += 2.0  # contrary motion bonus
                elif motion == "parallel" and mel_dir * c_dir > 0:
                    score += 2.0
                elif motion == "oblique" and abs(c_dir) < 2:
                    score += 2.0
                elif motion == "mixed":
                    score += 1.0

                # Consonance check
                interval_abs = abs(mel_pitch - c) % 12
                if interval_abs in {3, 4, 7, 8, 9, 0}:
                    score += 1.5

                # Avoid parallel fifths/octaves
                if prev_counter_pitch is not None:
                    prev_int = abs(prev_melody_pitch - prev_counter_pitch) % 12
                    curr_int = abs(mel_pitch - c) % 12
                    if prev_int == curr_int and prev_int in {7, 0}:
                        score -= 3.0  # heavy penalty

                # Smooth voice leading (small intervals)
                if prev_counter_pitch is not None:
                    step_size = abs(c - prev_counter_pitch)
                    if step_size <= 4:
                        score += 1.0
                    elif step_size > 7:
                        score -= 0.5

                scored.append((c, score))

            scored.sort(key=lambda x: x[1], reverse=True)
            # Add slight randomness
            top_n = min(3, len(scored))
            best = scored[rng.randint(0, top_n - 1)][0] if scored else candidates[0]

        counter_notes.append({
            "pitch": best,
            "start": start,
            "duration": dur,
            "velocity": max(40, vel - 15),
        })

        prev_counter_pitch = best
        prev_melody_pitch = mel_pitch

    return counter_notes


# ---------------------------------------------------------------------------
# Lead Melody Generator
# ---------------------------------------------------------------------------

def generate_melody(
    *,
    root_pc: int = 0,
    scale_name: str = "major",
    bars: int = 8,
    beats_per_bar: float = 4.0,
    octave: int = 5,
    density: float = 0.6,
    contour: str = "arch",  # "arch" | "ascending" | "descending" | "wave" | "random"
    seed: int = 42,
) -> List[Dict[str, Any]]:
    """Generate a melodic line algorithmically.

    contour: overall shape of the melody
        arch: rises then falls (classic phrase shape)
        ascending: generally moves upward
        descending: generally moves downward
        wave: oscillates up and down
        random: random walk
    """
    rng = random.Random(seed)
    scale = SCALE_MAP.get(scale_name, MAJOR_SCALE)
    scale_p = _scale_pitches(root_pc, scale, octave - 1, octave + 1)
    total_beats = bars * beats_per_bar

    if not scale_p:
        return []

    # Generate rhythm first
    note_starts: List[Tuple[float, float]] = []  # (start, duration)
    beat = 0.0
    durations = [0.25, 0.5, 0.75, 1.0, 1.5, 2.0]
    weights = [0.1, 0.3, 0.15, 0.25, 0.1, 0.1]  # preference for 8ths and quarters

    while beat < total_beats:
        if rng.random() < density:
            dur = rng.choices(durations, weights=weights, k=1)[0]
            dur = min(dur, total_beats - beat)
            if dur > 0.1:
                note_starts.append((beat, dur))
            beat += dur
        else:
            beat += rng.choice([0.25, 0.5])  # rest

    if not note_starts:
        return []

    # Generate pitches following contour
    center_idx = len(scale_p) // 2
    center_pitch = scale_p[center_idx]
    notes: List[Dict[str, Any]] = []
    prev_pitch = center_pitch

    for i, (start, dur) in enumerate(note_starts):
        progress = start / total_beats  # 0..1

        # Target register based on contour
        if contour == "arch":
            # Rise to middle, then fall
            height = 1.0 - abs(progress - 0.5) * 2
        elif contour == "ascending":
            height = progress
        elif contour == "descending":
            height = 1.0 - progress
        elif contour == "wave":
            height = 0.5 + 0.5 * math.sin(progress * math.pi * 4)
        else:  # random
            height = rng.random()

        # Map height to pitch range
        range_semitones = 14  # ~octave + some
        target = center_pitch + int((height - 0.5) * range_semitones)
        target = _nearest_scale_pitch(target, scale_p)

        # Smooth: prefer stepwise motion (within 4 semitones of prev)
        if abs(target - prev_pitch) > 7:
            # Try to step closer
            step_dir = 1 if target > prev_pitch else -1
            step = prev_pitch + step_dir * rng.choice([2, 3, 4, 5])
            target = _nearest_scale_pitch(step, scale_p)

        # Occasional leap for interest
        if rng.random() < 0.15:
            leap = rng.choice([-7, -5, 5, 7, 12])
            target = _nearest_scale_pitch(prev_pitch + leap, scale_p)

        # Velocity: stronger on beat 1, phrase peaks
        vel = 80 + int(height * 20)
        if start % beats_per_bar < 0.01:
            vel = min(127, vel + 10)

        notes.append({
            "pitch": max(36, min(96, target)),
            "start": start,
            "duration": dur,
            "velocity": max(50, min(120, vel)),
        })
        prev_pitch = target

    return notes


# ---------------------------------------------------------------------------
# Motif Development
# ---------------------------------------------------------------------------

def develop_motif(
    motif_notes: List[Dict[str, Any]],
    *,
    techniques: Optional[List[str]] = None,
    root_pc: int = 0,
    scale_name: str = "major",
    seed: int = 42,
) -> Dict[str, List[Dict[str, Any]]]:
    """Develop a short motif into variations using classical techniques.

    techniques: list of development types to apply. Default = all.
        "repetition" — exact copy at next position
        "sequence" — transpose by scale steps
        "inversion" — flip intervals
        "retrograde" — play backwards
        "augmentation" — double durations
        "diminution" — halve durations
        "fragmentation" — use only first half
        "extension" — add notes to the end

    Returns dict mapping technique name → list of note dicts.
    """
    if not motif_notes:
        return {}

    rng = random.Random(seed)
    scale = SCALE_MAP.get(scale_name, MAJOR_SCALE)

    if techniques is None:
        techniques = ["repetition", "sequence", "inversion", "retrograde",
                      "augmentation", "diminution", "fragmentation", "extension"]

    # Sort by start time
    motif = sorted(motif_notes, key=lambda n: n.get("start", 0))
    motif_start = float(motif[0].get("start", 0))
    motif_end = max(float(n.get("start", 0)) + float(n.get("duration", 1)) for n in motif)
    motif_len = motif_end - motif_start

    # Normalize to start at 0
    norm = []
    for n in motif:
        norm.append({
            "pitch": int(n.get("pitch", 60)),
            "start": float(n.get("start", 0)) - motif_start,
            "duration": float(n.get("duration", 1)),
            "velocity": int(n.get("velocity", 80)),
        })

    results: Dict[str, List[Dict[str, Any]]] = {}
    offset = motif_len  # start after original

    for tech in techniques:
        developed: List[Dict[str, Any]] = []

        if tech == "repetition":
            for n in norm:
                developed.append({**n, "start": n["start"] + offset})

        elif tech == "sequence":
            # Transpose up by a third (scale-aware)
            transpose = rng.choice([3, 4, 5, 7])  # third, fourth, fifth
            for n in norm:
                developed.append({
                    **n,
                    "pitch": max(24, min(108, n["pitch"] + transpose)),
                    "start": n["start"] + offset,
                })

        elif tech == "inversion":
            # Flip intervals around first note
            pivot = norm[0]["pitch"]
            for n in norm:
                interval = n["pitch"] - pivot
                developed.append({
                    **n,
                    "pitch": max(24, min(108, pivot - interval)),
                    "start": n["start"] + offset,
                })

        elif tech == "retrograde":
            # Play backwards
            for i, n in enumerate(reversed(norm)):
                new_start = norm[i]["start"] + offset  # keep original timing
                developed.append({**n, "start": new_start})

        elif tech == "augmentation":
            # Double all durations
            t = offset
            for n in norm:
                developed.append({
                    **n,
                    "start": t,
                    "duration": n["duration"] * 2,
                })
                t += n["duration"] * 2 if len(norm) > 1 else 0

        elif tech == "diminution":
            # Halve all durations
            for n in norm:
                developed.append({
                    **n,
                    "start": n["start"] * 0.5 + offset,
                    "duration": max(0.125, n["duration"] * 0.5),
                })

        elif tech == "fragmentation":
            # Use only first half of motif
            half_len = motif_len / 2
            for n in norm:
                if n["start"] < half_len:
                    developed.append({**n, "start": n["start"] + offset})

        elif tech == "extension":
            # Copy motif + add extra notes at the end
            for n in norm:
                developed.append({**n, "start": n["start"] + offset})
            # Add 2-3 extra notes
            last = developed[-1] if developed else norm[-1]
            for j in range(rng.randint(2, 4)):
                step = rng.choice([-2, -1, 1, 2, 3, 5])
                extra_pitch = max(24, min(108, int(last.get("pitch", 60)) + step))
                extra_start = float(last.get("start", 0)) + float(last.get("duration", 1))
                dur = rng.choice([0.5, 1.0, 1.5])
                developed.append({
                    "pitch": extra_pitch,
                    "start": extra_start,
                    "duration": dur,
                    "velocity": int(last.get("velocity", 80)) - 5,
                })
                last = developed[-1]

        if developed:
            results[tech] = sorted(developed, key=lambda n: n["start"])
        offset += motif_len

    return results


# ---------------------------------------------------------------------------
# Scale-aware next note suggestion
# ---------------------------------------------------------------------------

def suggest_next_notes(
    existing_notes: List[Dict[str, Any]],
    *,
    root_pc: int = 0,
    scale_name: str = "major",
    n_suggestions: int = 5,
) -> List[Dict[str, Any]]:
    """Suggest the next note(s) based on existing notes and music theory.

    Returns a list of candidate notes ranked by likelihood.
    """
    if not existing_notes:
        return []

    scale = SCALE_MAP.get(scale_name, MAJOR_SCALE)
    scale_p = _scale_pitches(root_pc, scale, 2, 7)

    # Get last note
    sorted_notes = sorted(existing_notes, key=lambda n: n.get("start", 0))
    last = sorted_notes[-1]
    last_pitch = int(last.get("pitch", 60))
    last_end = float(last.get("start", 0)) + float(last.get("duration", 1))

    # Score candidates
    candidates: List[Tuple[int, float]] = []

    for p in scale_p:
        if abs(p - last_pitch) > 14:
            continue  # too far
        score = 0.0
        interval = abs(p - last_pitch)

        # Stepwise motion preferred
        if interval <= 2:
            score += 3.0
        elif interval <= 4:
            score += 2.0
        elif interval <= 7:
            score += 1.0
        else:
            score += 0.3

        # Tonic/dominant get bonus
        if p % 12 == root_pc:
            score += 1.5  # tonic
        if p % 12 == (root_pc + 7) % 12:
            score += 0.8  # dominant

        # Avoid repetition
        if p == last_pitch:
            score -= 1.0

        # Prefer similar register
        register_diff = abs(p - last_pitch)
        score -= register_diff * 0.05

        candidates.append((p, score))

    # Sort by score descending
    candidates.sort(key=lambda x: x[1], reverse=True)

    suggestions = []
    for pitch, score in candidates[:n_suggestions]:
        suggestions.append({
            "pitch": pitch,
            "start": last_end,
            "duration": float(last.get("duration", 1)),
            "velocity": int(last.get("velocity", 80)),
            "score": round(score, 2),
        })

    return suggestions
