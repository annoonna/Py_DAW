"""Harmony Analysis Engine (P2B + P2E) — Offline chord/key/scale detection.

Pure Python, no ML dependencies. Works on MIDI notes directly.

Features:
- Chord recognition from simultaneous notes
- Key detection (Krumhansl-Schmuckler algorithm)
- Harmonic analysis of note sequences
- Roman numeral analysis
- Tension/resolution tracking

v0.0.20.807 — Phase P2B/P2E
"""

from __future__ import annotations

import logging
import math
from collections import Counter
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
NOTE_NAMES_FLAT = ["C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B"]
NOTE_NAMES_DE = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "H"]

# Krumhansl-Schmuckler key profiles (correlation weights)
_MAJOR_PROFILE = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88]
_MINOR_PROFILE = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]

# Chord templates: (name, intervals from root)
CHORD_TEMPLATES: List[Tuple[str, List[int]]] = [
    # Triads
    ("maj", [0, 4, 7]),
    ("min", [0, 3, 7]),
    ("dim", [0, 3, 6]),
    ("aug", [0, 4, 8]),
    ("sus2", [0, 2, 7]),
    ("sus4", [0, 5, 7]),
    # Seventh chords
    ("maj7", [0, 4, 7, 11]),
    ("7", [0, 4, 7, 10]),
    ("min7", [0, 3, 7, 10]),
    ("dim7", [0, 3, 6, 9]),
    ("m7b5", [0, 3, 6, 10]),
    ("minMaj7", [0, 3, 7, 11]),
    ("aug7", [0, 4, 8, 10]),
    # Extended
    ("add9", [0, 4, 7, 14]),
    ("9", [0, 4, 7, 10, 14]),
    ("min9", [0, 3, 7, 10, 14]),
    ("maj9", [0, 4, 7, 11, 14]),
    ("11", [0, 4, 7, 10, 14, 17]),
    ("13", [0, 4, 7, 10, 14, 21]),
    # Power
    ("5", [0, 7]),
]

# Scale intervals for Roman numeral analysis
MAJOR_SCALE = [0, 2, 4, 5, 7, 9, 11]
MINOR_SCALE = [0, 2, 3, 5, 7, 8, 10]

ROMAN_NUMERALS_MAJ = ["I", "ii", "iii", "IV", "V", "vi", "vii°"]
ROMAN_NUMERALS_MIN = ["i", "ii°", "III", "iv", "v", "VI", "VII"]


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class ChordInfo:
    """A recognized chord at a specific time position."""
    beat: float = 0.0
    duration_beats: float = 1.0
    root_pc: int = 0              # pitch class 0-11
    root_name: str = "C"
    quality: str = "maj"          # chord quality name
    full_name: str = "Cmaj"       # e.g. "C#min7"
    bass_pc: int = -1             # bass note PC (-1 = root position)
    confidence: float = 0.0       # 0..1
    notes: List[int] = field(default_factory=list)  # MIDI notes in chord

    def to_dict(self) -> dict:
        return {
            "beat": self.beat, "duration_beats": self.duration_beats,
            "root_pc": self.root_pc, "root_name": self.root_name,
            "quality": self.quality, "full_name": self.full_name,
            "bass_pc": self.bass_pc, "confidence": self.confidence,
            "notes": self.notes,
        }


@dataclass
class KeyInfo:
    """Detected musical key."""
    root_pc: int = 0
    root_name: str = "C"
    mode: str = "major"           # "major" | "minor"
    full_name: str = "C major"
    confidence: float = 0.0       # 0..1 correlation
    all_correlations: List[Tuple[str, float]] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "root_pc": self.root_pc, "root_name": self.root_name,
            "mode": self.mode, "full_name": self.full_name,
            "confidence": self.confidence,
            "top_5": self.all_correlations[:5],
        }


@dataclass
class HarmonyReport:
    """Complete harmonic analysis of a MIDI clip."""
    key: KeyInfo = field(default_factory=KeyInfo)
    chords: List[ChordInfo] = field(default_factory=list)
    chord_progression: str = ""       # "I - vi - IV - V"
    roman_numerals: List[str] = field(default_factory=list)
    tension_curve: List[Tuple[float, float]] = field(default_factory=list)
    complexity_score: float = 0.0     # 0..1
    description: str = ""

    def to_dict(self) -> dict:
        return {
            "key": self.key.to_dict(),
            "chords": [c.to_dict() for c in self.chords],
            "chord_progression": self.chord_progression,
            "roman_numerals": self.roman_numerals,
            "complexity_score": self.complexity_score,
            "description": self.description,
        }


# ---------------------------------------------------------------------------
# Key Detection (Krumhansl-Schmuckler)
# ---------------------------------------------------------------------------

def detect_key(notes: List[Dict[str, Any]]) -> KeyInfo:
    """Detect the musical key using the Krumhansl-Schmuckler algorithm.

    notes: list of dicts with at least 'pitch' (MIDI) and optionally
           'duration' (beats) for weighted analysis.
    """
    if not notes:
        return KeyInfo()

    # Build pitch class histogram weighted by duration
    pc_histogram = [0.0] * 12
    for n in notes:
        try:
            pitch = int(n.get("pitch", 0) if isinstance(n, dict) else getattr(n, "pitch", 0))
            dur = float(n.get("duration", 1.0) if isinstance(n, dict) else getattr(n, "duration", 1.0))
            pc = pitch % 12
            pc_histogram[pc] += max(0.01, dur)
        except Exception:
            continue

    total = sum(pc_histogram)
    if total < 0.01:
        return KeyInfo()

    # Normalize
    pc_norm = [x / total for x in pc_histogram]

    # Correlate with all 24 key profiles (12 major + 12 minor)
    correlations: List[Tuple[str, float, int, str]] = []

    for root in range(12):
        # Rotate histogram so 'root' aligns with index 0
        rotated = pc_norm[root:] + pc_norm[:root]

        # Major correlation
        maj_corr = _pearson_correlation(rotated, _MAJOR_PROFILE)
        correlations.append((
            f"{NOTE_NAMES[root]} major", maj_corr, root, "major"
        ))

        # Minor correlation
        min_corr = _pearson_correlation(rotated, _MINOR_PROFILE)
        correlations.append((
            f"{NOTE_NAMES[root]} minor", min_corr, root, "minor"
        ))

    # Sort by correlation (highest first)
    correlations.sort(key=lambda x: x[1], reverse=True)

    best = correlations[0]
    return KeyInfo(
        root_pc=best[2],
        root_name=NOTE_NAMES[best[2]],
        mode=best[3],
        full_name=best[0],
        confidence=max(0.0, min(1.0, best[1])),
        all_correlations=[(name, round(corr, 3)) for name, corr, _, _ in correlations[:10]],
    )


def _pearson_correlation(x: List[float], y: List[float]) -> float:
    """Pearson correlation coefficient between two lists."""
    n = len(x)
    if n != len(y) or n == 0:
        return 0.0
    mean_x = sum(x) / n
    mean_y = sum(y) / n
    num = sum((xi - mean_x) * (yi - mean_y) for xi, yi in zip(x, y))
    den_x = math.sqrt(sum((xi - mean_x) ** 2 for xi in x))
    den_y = math.sqrt(sum((yi - mean_y) ** 2 for yi in y))
    if den_x * den_y < 1e-10:
        return 0.0
    return num / (den_x * den_y)


# ---------------------------------------------------------------------------
# Chord Recognition
# ---------------------------------------------------------------------------

def recognize_chord(pitch_classes: List[int]) -> Tuple[str, int, str, float]:
    """Recognize a chord from a set of pitch classes.

    Returns (full_name, root_pc, quality, confidence).
    """
    if not pitch_classes:
        return ("N.C.", -1, "none", 0.0)

    pcs = sorted(set(pc % 12 for pc in pitch_classes))

    if len(pcs) < 2:
        name = NOTE_NAMES[pcs[0]]
        return (name, pcs[0], "note", 0.5)

    best_match = ("?", -1, "?", 0.0)
    best_score = -1.0

    for root in range(12):
        for quality, intervals in CHORD_TEMPLATES:
            template_pcs = set((root + i) % 12 for i in intervals)

            # Score: how many template notes are present / how many extra notes
            matched = len(template_pcs & set(pcs))
            total_template = len(template_pcs)
            extra = len(set(pcs) - template_pcs)

            if matched < 2:
                continue

            # Score favors more matched notes and fewer extras
            score = matched / total_template - extra * 0.15

            if score > best_score:
                best_score = score
                root_name = NOTE_NAMES[root]
                if quality == "maj":
                    full = root_name
                elif quality == "min":
                    full = f"{root_name}m"
                else:
                    full = f"{root_name}{quality}"
                best_match = (full, root, quality, min(1.0, max(0.0, score)))

    return best_match


def recognize_chords_from_notes(
    notes: List[Dict[str, Any]],
    *,
    resolution_beats: float = 1.0,
    total_beats: float = 0.0,
) -> List[ChordInfo]:
    """Recognize chords from a sequence of MIDI notes.

    Groups notes by time windows and recognizes chords per window.
    """
    if not notes:
        return []

    # Determine total length
    if total_beats <= 0:
        for n in notes:
            try:
                s = float(n.get("start", 0) if isinstance(n, dict) else getattr(n, "start_beats", 0))
                d = float(n.get("duration", 1) if isinstance(n, dict) else getattr(n, "duration", 1))
                total_beats = max(total_beats, s + d)
            except Exception:
                continue
        total_beats = max(total_beats, 1.0)

    chords: List[ChordInfo] = []
    beat = 0.0

    while beat < total_beats:
        window_end = beat + resolution_beats

        # Collect notes sounding in this window
        window_pitches = []
        window_notes = []
        for n in notes:
            try:
                s = float(n.get("start", 0) if isinstance(n, dict) else getattr(n, "start_beats", 0))
                d = float(n.get("duration", 1) if isinstance(n, dict) else getattr(n, "duration", 1))
                p = int(n.get("pitch", 0) if isinstance(n, dict) else getattr(n, "pitch", 0))
                # Note overlaps with window?
                if s < window_end and (s + d) > beat:
                    window_pitches.append(p)
                    window_notes.append(p)
            except Exception:
                continue

        if window_pitches:
            pcs = [p % 12 for p in window_pitches]
            full_name, root_pc, quality, conf = recognize_chord(pcs)

            # Determine bass note (lowest pitch)
            bass_pc = min(window_pitches) % 12 if window_pitches else -1

            # Slash chord notation if bass != root
            if root_pc >= 0 and bass_pc >= 0 and bass_pc != root_pc:
                full_name = f"{full_name}/{NOTE_NAMES[bass_pc]}"

            chords.append(ChordInfo(
                beat=beat,
                duration_beats=resolution_beats,
                root_pc=root_pc,
                root_name=NOTE_NAMES[root_pc] if root_pc >= 0 else "?",
                quality=quality,
                full_name=full_name,
                bass_pc=bass_pc,
                confidence=conf,
                notes=window_notes,
            ))

        beat += resolution_beats

    # Merge consecutive identical chords
    merged: List[ChordInfo] = []
    for chord in chords:
        if merged and merged[-1].full_name == chord.full_name:
            merged[-1].duration_beats += chord.duration_beats
        else:
            merged.append(chord)

    return merged


# ---------------------------------------------------------------------------
# Roman numeral analysis
# ---------------------------------------------------------------------------

def chord_to_roman(chord: ChordInfo, key: KeyInfo) -> str:
    """Convert a chord to Roman numeral notation relative to the key."""
    if chord.root_pc < 0 or not chord.full_name or chord.full_name == "N.C.":
        return "N.C."

    # Scale degrees
    scale = MAJOR_SCALE if key.mode == "major" else MINOR_SCALE
    romans = ROMAN_NUMERALS_MAJ if key.mode == "major" else ROMAN_NUMERALS_MIN

    # Find which scale degree this chord root is
    interval = (chord.root_pc - key.root_pc) % 12

    degree_idx = -1
    for i, s in enumerate(scale):
        if s == interval:
            degree_idx = i
            break

    if degree_idx < 0:
        # Non-diatonic chord — use chromatic notation
        semitone_names = ["I", "bII", "II", "bIII", "III", "IV", "#IV", "V", "bVI", "VI", "bVII", "VII"]
        base = semitone_names[interval]
        if chord.quality in ("min", "min7", "min9", "minMaj7"):
            base = base.lower()
        suffix = ""
        if "7" in chord.quality:
            suffix = "7"
        return base + suffix

    base_roman = romans[degree_idx]

    # Add quality suffixes
    suffix = ""
    q = chord.quality
    if "7" in q or "9" in q or "11" in q or "13" in q:
        if "maj7" in q:
            suffix = "Δ7"
        elif "7" in q:
            suffix = "7"
    if "dim" in q and "°" not in base_roman:
        suffix = "°" + suffix
    if "aug" in q:
        suffix = "+" + suffix
    if "sus" in q:
        suffix = q.replace("sus", "sus")

    return base_roman + suffix


# ---------------------------------------------------------------------------
# Full analysis
# ---------------------------------------------------------------------------

def analyze_harmony(
    notes: List[Dict[str, Any]],
    *,
    chord_resolution: float = 1.0,
) -> HarmonyReport:
    """Complete harmonic analysis of MIDI notes.

    Returns a HarmonyReport with key, chords, roman numerals, etc.
    """
    if not notes:
        return HarmonyReport(description="Keine Noten für Analyse.")

    # Detect key
    key = detect_key(notes)

    # Detect chords
    chords = recognize_chords_from_notes(notes, resolution_beats=chord_resolution)

    # Roman numerals
    roman_nums = [chord_to_roman(c, key) for c in chords]

    # Build progression string
    prog = " — ".join(roman_nums) if roman_nums else ""

    # Tension curve: simple model based on chord complexity + non-diatonic notes
    scale_pcs = set()
    scale_intervals = MAJOR_SCALE if key.mode == "major" else MINOR_SCALE
    for interval in scale_intervals:
        scale_pcs.add((key.root_pc + interval) % 12)

    tension: List[Tuple[float, float]] = []
    for chord in chords:
        # Tension factors
        t = 0.0
        # Non-diatonic root
        if chord.root_pc >= 0 and chord.root_pc not in scale_pcs:
            t += 0.3
        # 7th/extended chords add tension
        if "7" in chord.quality:
            t += 0.2
        if "9" in chord.quality or "11" in chord.quality or "13" in chord.quality:
            t += 0.1
        # Diminished / augmented
        if "dim" in chord.quality:
            t += 0.3
        if "aug" in chord.quality:
            t += 0.2
        # Dominant function (V or V7)
        interval = (chord.root_pc - key.root_pc) % 12
        if interval == 7:  # dominant
            t += 0.15
        tension.append((chord.beat, min(1.0, t)))

    # Complexity score
    unique_chords = len(set(c.full_name for c in chords))
    non_diatonic = sum(1 for c in chords if c.root_pc >= 0 and c.root_pc not in scale_pcs)
    complexity = min(1.0, (unique_chords * 0.1 + non_diatonic * 0.15))

    # Generate description
    desc_parts = [f"Tonart: {key.full_name} (Konfidenz: {key.confidence:.0%})"]
    if chords:
        desc_parts.append(f"Akkordfolge: {prog}")
        desc_parts.append(f"{len(chords)} Akkorde, {unique_chords} verschiedene")
        if non_diatonic > 0:
            desc_parts.append(f"{non_diatonic} leiterfremde Akkorde → {'hohe' if non_diatonic > 2 else 'moderate'} harmonische Komplexität")
    description = ". ".join(desc_parts)

    return HarmonyReport(
        key=key,
        chords=chords,
        chord_progression=prog,
        roman_numerals=roman_nums,
        tension_curve=tension,
        complexity_score=complexity,
        description=description,
    )


# ---------------------------------------------------------------------------
# Chord progression generation (offline, algorithmic)
# ---------------------------------------------------------------------------

# Common chord progressions by style
PROGRESSIONS_DB: Dict[str, List[List[int]]] = {
    # Intervals from tonic (scale degree indices, 0-based)
    "Pop": [[0, 4, 5, 3], [0, 5, 3, 4], [0, 3, 4, 4]],
    "Rock": [[0, 3, 4, 4], [0, 4, 5, 3], [0, 0, 3, 4]],
    "Jazz": [[1, 4, 0, 0], [1, 4, 0, 3], [0, 5, 1, 4]],
    "Blues": [[0, 0, 0, 0, 3, 3, 0, 0, 4, 3, 0, 4]],
    "Classical": [[0, 3, 4, 0], [0, 5, 1, 4], [0, 2, 4, 0]],
    "Ambient": [[0, 5, 3, 4], [0, 2, 5, 3], [0, 3, 5, 0]],
    "Funk": [[0, 3, 0, 4], [0, 6, 3, 4]],
    "R&B": [[0, 5, 3, 4], [1, 4, 0, 5], [0, 3, 5, 4]],
    "EDM": [[0, 5, 3, 4], [5, 3, 0, 4], [0, 4, 5, 3]],
    "Bossa Nova": [[0, 6, 1, 4], [0, 3, 6, 1]],
}


def generate_chord_progression(
    key_root: int = 0,
    mode: str = "major",
    style: str = "Pop",
    bars: int = 4,
    seed: int = 42,
) -> List[ChordInfo]:
    """Generate a chord progression algorithmically.

    Returns ChordInfo list with proper chord names.
    """
    import random
    rng = random.Random(seed)

    scale = MAJOR_SCALE if mode == "major" else MINOR_SCALE
    major_quality = ["maj", "min", "min", "maj", "maj", "min", "dim"]
    minor_quality = ["min", "dim", "maj", "min", "min", "maj", "maj"]
    qualities = major_quality if mode == "major" else minor_quality

    # Get progression template
    templates = PROGRESSIONS_DB.get(style, PROGRESSIONS_DB["Pop"])
    template = rng.choice(templates)

    # Extend/repeat to fill bars
    prog_degrees: List[int] = []
    while len(prog_degrees) < bars:
        prog_degrees.extend(template)
    prog_degrees = prog_degrees[:bars]

    chords: List[ChordInfo] = []
    for i, degree in enumerate(prog_degrees):
        degree_idx = degree % len(scale)
        root_pc = (key_root + scale[degree_idx]) % 12
        quality = qualities[degree_idx]
        root_name = NOTE_NAMES[root_pc]

        if quality == "maj":
            full = root_name
        elif quality == "min":
            full = f"{root_name}m"
        elif quality == "dim":
            full = f"{root_name}dim"
        else:
            full = f"{root_name}{quality}"

        chords.append(ChordInfo(
            beat=float(i * 4),  # 1 bar = 4 beats
            duration_beats=4.0,
            root_pc=root_pc,
            root_name=root_name,
            quality=quality,
            full_name=full,
            confidence=1.0,
        ))

    return chords


def chord_to_midi_notes(
    chord: ChordInfo,
    octave: int = 4,
    voicing: str = "close",
) -> List[Dict[str, Any]]:
    """Convert a ChordInfo to MIDI note dicts for Piano Roll insertion.

    voicing: "close" | "open" | "drop2" | "spread"
    """
    if chord.root_pc < 0:
        return []

    # Find template intervals
    template_intervals = [0, 4, 7]  # default major
    for quality, intervals in CHORD_TEMPLATES:
        if quality == chord.quality:
            template_intervals = intervals
            break

    base_midi = chord.root_pc + (octave + 1) * 12  # C4 = MIDI 60

    pitches = [(base_midi + i) for i in template_intervals]

    # Apply voicing
    if voicing == "open" and len(pitches) >= 3:
        # Move middle note up an octave
        pitches[1] += 12
    elif voicing == "drop2" and len(pitches) >= 3:
        # Drop 2nd-from-top note down an octave
        pitches[-2] -= 12
        pitches.sort()
    elif voicing == "spread" and len(pitches) >= 3:
        # Spread across 2 octaves
        for i in range(1, len(pitches)):
            if i % 2 == 0:
                pitches[i] += 12

    notes = []
    for p in pitches:
        notes.append({
            "pitch": max(0, min(127, p)),
            "start": chord.beat,
            "duration": chord.duration_beats,
            "velocity": 80,
        })

    return notes
