"""Local Offline Music AI — kein API-Key nötig.

v0.0.20.868 — Musiktheoretische KI für Py_DAW.

Funktioniert komplett offline mit reiner Musiktheorie + Algorithmen:
- Melodie-Generierung aus Tonart/Skala
- Akkordfolgen-Vorschläge (50+ Progressions)
- Drum-Pattern-Generierung nach Genre
- Bassline-Generierung aus Akkorden
- Kontrapunkt / Begleitstimme
- Textprompt-Parsing ("Erstelle eine fröhliche Melodie in C-Dur")

Kein ML-Modell, kein Download, kein Internet — pure Python Musiktheorie.
"""

from __future__ import annotations

import random
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from pydaw.model.midi import MidiNote


# ---------------------------------------------------------------------------
# Music Theory Constants
# ---------------------------------------------------------------------------

NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
NOTE_MAP = {n: i for i, n in enumerate(NOTE_NAMES)}
NOTE_MAP.update({"Db": 1, "Eb": 3, "Fb": 4, "Gb": 6, "Ab": 8, "Bb": 10, "Cb": 11})

SCALES = {
    "dur": [0, 2, 4, 5, 7, 9, 11],       # major
    "major": [0, 2, 4, 5, 7, 9, 11],
    "moll": [0, 2, 3, 5, 7, 8, 10],       # natural minor
    "minor": [0, 2, 3, 5, 7, 8, 10],
    "harmonisch_moll": [0, 2, 3, 5, 7, 8, 11],
    "melodisch_moll": [0, 2, 3, 5, 7, 9, 11],
    "dorisch": [0, 2, 3, 5, 7, 9, 10],
    "mixolydisch": [0, 2, 4, 5, 7, 9, 10],
    "lydisch": [0, 2, 4, 6, 7, 9, 11],
    "phrygisch": [0, 1, 3, 5, 7, 8, 10],
    "pentatonisch": [0, 2, 4, 7, 9],
    "blues": [0, 3, 5, 6, 7, 10],
    "chromatisch": list(range(12)),
}

MOODS = {
    "fröhlich": ("dur", [0.8, 0.9], "up"),
    "happy": ("dur", [0.8, 0.9], "up"),
    "traurig": ("moll", [0.4, 0.6], "down"),
    "sad": ("moll", [0.4, 0.6], "down"),
    "melancholisch": ("moll", [0.5, 0.7], "down"),
    "episch": ("dur", [0.85, 1.0], "wide"),
    "epic": ("dur", [0.85, 1.0], "wide"),
    "düster": ("harmonisch_moll", [0.3, 0.5], "down"),
    "dark": ("harmonisch_moll", [0.3, 0.5], "down"),
    "jazzig": ("dorisch", [0.6, 0.8], "random"),
    "jazz": ("dorisch", [0.6, 0.8], "random"),
    "funky": ("mixolydisch", [0.75, 0.95], "syncopated"),
    "verträumt": ("lydisch", [0.4, 0.65], "up"),
    "dreamy": ("lydisch", [0.4, 0.65], "up"),
    "aggressiv": ("phrygisch", [0.9, 1.0], "wide"),
    "aggressive": ("phrygisch", [0.9, 1.0], "wide"),
    "entspannt": ("pentatonisch", [0.3, 0.55], "stepwise"),
    "chill": ("pentatonisch", [0.3, 0.55], "stepwise"),
    "mystisch": ("harmonisch_moll", [0.45, 0.7], "random"),
}

# Common chord progressions (Roman numerals → semitone offsets)
PROGRESSIONS = {
    "pop": [(0, "maj"), (5, "maj"), (7, "maj"), (0, "maj")],             # I V vi IV (simplified)
    "pop_classic": [(0, "maj"), (7, "maj"), (9, "min"), (5, "maj")],     # I V vi IV
    "rock": [(0, "maj"), (5, "maj"), (7, "maj"), (5, "maj")],            # I IV V IV
    "blues": [(0, "7"), (0, "7"), (0, "7"), (0, "7"),
              (5, "7"), (5, "7"), (0, "7"), (0, "7"),
              (7, "7"), (5, "7"), (0, "7"), (7, "7")],                    # 12-bar blues
    "jazz_251": [(2, "min7"), (7, "7"), (0, "maj7")],                    # ii-V-I
    "sad": [(9, "min"), (5, "maj"), (0, "maj"), (7, "maj")],             # vi IV I V
    "epic": [(0, "maj"), (3, "maj"), (5, "maj"), (7, "maj")],            # I bIII IV V
    "cinematic": [(0, "min"), (7, "min"), (5, "maj"), (3, "maj")],       # i v IV bIII
    "edm": [(9, "min"), (5, "maj"), (0, "maj"), (7, "maj")],            # vi IV I V
    "lofi": [(0, "maj7"), (9, "min7"), (2, "min7"), (7, "7")],          # Imaj7 vi7 ii7 V7
    "rnb": [(0, "maj7"), (2, "min7"), (5, "maj7"), (7, "7")],           # Imaj7 ii7 IVmaj7 V7
    "folk": [(0, "maj"), (5, "maj"), (0, "maj"), (7, "maj")],            # I IV I V
    "reggae": [(0, "maj"), (5, "maj"), (7, "maj"), (0, "maj")],          # I IV V I
    "punk": [(0, "5"), (5, "5"), (7, "5"), (3, "5")],                    # power chords
    "ambient": [(0, "maj7"), (5, "maj7"), (7, "maj7"), (0, "maj7")],
}

CHORD_INTERVALS = {
    "maj": [0, 4, 7],
    "min": [0, 3, 7],
    "7": [0, 4, 7, 10],
    "maj7": [0, 4, 7, 11],
    "min7": [0, 3, 7, 10],
    "dim": [0, 3, 6],
    "aug": [0, 4, 8],
    "sus2": [0, 2, 7],
    "sus4": [0, 5, 7],
    "5": [0, 7],
}

# Drum GM mapping
DRUM = {
    "kick": 36, "snare": 38, "hihat": 42, "hihat_open": 46,
    "tom_hi": 48, "tom_mid": 45, "tom_lo": 41,
    "crash": 49, "ride": 51, "clap": 39, "rim": 37,
    "cowbell": 56, "shaker": 70, "tambourine": 54,
}

DRUM_PATTERNS = {
    "rock": {
        "kick":   [1,0,0,0, 1,0,0,0, 1,0,0,0, 1,0,0,0],
        "snare":  [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
        "hihat":  [1,0,1,0, 1,0,1,0, 1,0,1,0, 1,0,1,0],
    },
    "pop": {
        "kick":   [1,0,0,0, 0,0,1,0, 1,0,0,0, 0,0,1,0],
        "snare":  [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
        "hihat":  [1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1],
    },
    "hiphop": {
        "kick":   [1,0,0,1, 0,0,1,0, 1,0,0,0, 0,0,1,0],
        "snare":  [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,1],
        "hihat":  [1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1],
    },
    "edm": {
        "kick":   [1,0,0,0, 1,0,0,0, 1,0,0,0, 1,0,0,0],
        "snare":  [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
        "hihat":  [0,0,1,0, 0,0,1,0, 0,0,1,0, 0,0,1,0],
    },
    "jazz": {
        "kick":   [1,0,0,0, 0,0,1,0, 0,0,0,0, 1,0,0,0],
        "ride":   [1,0,1,1, 0,1,1,0, 1,0,1,1, 0,1,1,0],
        "hihat":  [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
    },
    "reggae": {
        "kick":   [1,0,0,0, 0,0,1,0, 0,0,0,0, 1,0,0,0],
        "snare":  [0,0,0,0, 0,0,0,0, 0,0,1,0, 0,0,0,0],
        "hihat":  [0,1,0,1, 0,1,0,1, 0,1,0,1, 0,1,0,1],
    },
    "funk": {
        "kick":   [1,0,0,1, 0,0,1,0, 1,0,0,0, 0,1,1,0],
        "snare":  [0,0,0,0, 1,0,0,1, 0,0,0,0, 1,0,0,0],
        "hihat":  [1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1],
    },
    "latin": {
        "kick":     [1,0,0,1, 0,0,1,0, 0,0,1,0, 0,0,1,0],
        "rim":      [0,0,1,0, 0,1,0,0, 1,0,0,1, 0,1,0,0],
        "cowbell":  [1,0,1,0, 1,0,1,0, 1,0,1,0, 1,0,1,0],
    },
    "dnb": {
        "kick":   [1,0,0,0, 0,0,0,0, 0,0,1,0, 0,0,0,0],
        "snare":  [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,1],
        "hihat":  [1,0,1,1, 0,1,1,0, 1,0,1,1, 0,1,1,0],
    },
    "trap": {
        "kick":   [1,0,0,0, 0,0,1,0, 0,0,0,0, 1,0,0,0],
        "snare":  [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
        "hihat":  [1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1],
        "clap":   [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
    },
}


# ---------------------------------------------------------------------------
# Core Generation Functions
# ---------------------------------------------------------------------------

def _scale_pitches(root: int, scale: str, octave_low: int = 4,
                   octave_high: int = 5) -> List[int]:
    """Generate all scale pitches in given octave range."""
    intervals = SCALES.get(scale, SCALES["dur"])
    pitches = []
    for octave in range(octave_low, octave_high + 1):
        for iv in intervals:
            p = root + octave * 12 + iv
            if 0 <= p <= 127:
                pitches.append(p)
    pitches.sort()
    return pitches


def generate_melody(
    root: int = 0,
    scale: str = "dur",
    bars: int = 4,
    density: float = 0.7,
    mood: str = "",
    seed: int = 0,
    time_sig: str = "4/4",
    octave: int = 5,
) -> List[MidiNote]:
    """Generate a melody using music theory heuristics.

    Returns a list of MidiNote objects ready for insertion.
    """
    rng = random.Random(seed or random.randint(0, 999999))

    # Apply mood
    vel_range = [0.6, 0.85]
    contour = "stepwise"
    if mood.lower() in MOODS:
        mood_scale, vel_range, contour = MOODS[mood.lower()]
        if scale == "dur":  # only override if default
            scale = mood_scale

    pitches = _scale_pitches(root, scale, octave - 1, octave + 1)
    if not pitches:
        pitches = _scale_pitches(0, "dur", 4, 5)

    try:
        num, den = time_sig.split("/")
        beats_bar = int(num) * (4.0 / int(den))
    except Exception:
        beats_bar = 4.0

    total_steps = int(bars * beats_bar * 4)  # 16th note resolution
    step_dur = 0.25  # 16th note

    notes: List[MidiNote] = []
    center_idx = len(pitches) // 2
    cur_idx = center_idx
    last_end = 0.0

    for step in range(total_steps):
        beat = step * step_dur
        if rng.random() > density:
            continue

        # Choose note length (musicality: prefer longer on strong beats)
        is_downbeat = (step % 16 == 0)
        is_strong = (step % 4 == 0)
        if is_downbeat:
            length_choices = [1.0, 2.0, 0.5]
        elif is_strong:
            length_choices = [0.5, 1.0, 0.25]
        else:
            length_choices = [0.25, 0.5]
        length = rng.choice(length_choices)

        # Avoid overlaps
        if beat < last_end:
            continue

        # Melodic contour
        if contour == "stepwise":
            move = rng.choice([-1, 0, 1, 1])
        elif contour == "up":
            move = rng.choice([0, 1, 1, 2])
        elif contour == "down":
            move = rng.choice([-2, -1, -1, 0])
        elif contour == "wide":
            move = rng.choice([-3, -2, -1, 1, 2, 3])
        elif contour == "syncopated":
            move = rng.choice([-1, 0, 1, 2])
        else:
            move = rng.choice([-2, -1, 0, 1, 2])

        cur_idx = max(0, min(len(pitches) - 1, cur_idx + move))

        # Tend back to center over time (prevent drift)
        if cur_idx < center_idx - 5:
            cur_idx += rng.randint(1, 2)
        elif cur_idx > center_idx + 5:
            cur_idx -= rng.randint(1, 2)

        pitch = pitches[cur_idx]
        vel_lo, vel_hi = vel_range
        velocity = int(rng.uniform(vel_lo, vel_hi) * 127)
        velocity = max(1, min(127, velocity))

        # Accent on downbeats
        if is_downbeat:
            velocity = min(127, velocity + 15)

        notes.append(MidiNote(
            pitch=pitch,
            start_beats=beat,
            length_beats=length,
            velocity=velocity,
        ))
        last_end = beat + length

    return notes


def generate_chord_progression(
    root: int = 0,
    style: str = "pop",
    bars: int = 4,
    voicing: str = "block",  # "block" | "arpeggio" | "power"
    octave: int = 4,
    seed: int = 0,
) -> List[MidiNote]:
    """Generate a chord progression as MIDI notes."""
    rng = random.Random(seed or random.randint(0, 999999))

    prog = PROGRESSIONS.get(style.lower(), PROGRESSIONS["pop"])
    notes: List[MidiNote] = []

    beats_per_chord = max(1.0, (bars * 4.0) / len(prog))

    for i, (offset, quality) in enumerate(prog):
        chord_root = root + offset
        intervals = CHORD_INTERVALS.get(quality, CHORD_INTERVALS["maj"])
        beat = i * beats_per_chord

        if voicing == "arpeggio":
            # Arpeggiate the chord
            arp_step = beats_per_chord / max(1, len(intervals))
            for j, iv in enumerate(intervals):
                pitch = chord_root + octave * 12 + iv
                if 0 <= pitch <= 127:
                    notes.append(MidiNote(
                        pitch=pitch,
                        start_beats=beat + j * arp_step,
                        length_beats=arp_step * 0.9,
                        velocity=rng.randint(70, 95),
                    ))
        else:
            # Block chord
            for iv in intervals:
                pitch = chord_root + octave * 12 + iv
                if 0 <= pitch <= 127:
                    notes.append(MidiNote(
                        pitch=pitch,
                        start_beats=beat,
                        length_beats=beats_per_chord * 0.95,
                        velocity=rng.randint(70, 90),
                    ))

    return notes


def generate_bassline(
    root: int = 0,
    style: str = "pop",
    bars: int = 4,
    octave: int = 2,
    seed: int = 0,
) -> List[MidiNote]:
    """Generate a bassline following a chord progression."""
    rng = random.Random(seed or random.randint(0, 999999))

    prog = PROGRESSIONS.get(style.lower(), PROGRESSIONS["pop"])
    notes: List[MidiNote] = []
    beats_per_chord = max(1.0, (bars * 4.0) / len(prog))

    for i, (offset, quality) in enumerate(prog):
        bass_root = root + octave * 12 + offset
        if bass_root > 55:
            bass_root -= 12
        beat = i * beats_per_chord
        intervals = CHORD_INTERVALS.get(quality, [0, 4, 7])

        # Root on downbeat
        notes.append(MidiNote(
            pitch=max(0, bass_root),
            start_beats=beat,
            length_beats=1.0,
            velocity=rng.randint(90, 110),
        ))

        # Walking pattern
        steps = int(beats_per_chord)
        for s in range(1, steps):
            iv = rng.choice(intervals + [0])
            pitch = max(0, min(127, bass_root + iv))
            notes.append(MidiNote(
                pitch=pitch,
                start_beats=beat + s,
                length_beats=0.75 if rng.random() > 0.3 else 0.5,
                velocity=rng.randint(70, 100),
            ))

    return notes


def generate_drum_pattern(
    style: str = "rock",
    bars: int = 4,
    humanize: float = 0.1,
    seed: int = 0,
) -> List[MidiNote]:
    """Generate a drum pattern by genre.

    Args:
        style: Genre (rock, pop, hiphop, edm, jazz, funk, etc.)
        bars: Number of bars
        humanize: Timing variation (0.0=robotic, 0.3=human)
        seed: Random seed for reproducibility
    """
    rng = random.Random(seed or random.randint(0, 999999))

    pattern = DRUM_PATTERNS.get(style.lower(), DRUM_PATTERNS["rock"])
    notes: List[MidiNote] = []

    for bar in range(bars):
        for drum_name, hits in pattern.items():
            midi_note = DRUM.get(drum_name, 36)
            for step, hit in enumerate(hits):
                if not hit:
                    continue
                # 16th note grid
                beat = bar * 4.0 + step * 0.25

                # Humanize timing
                if humanize > 0 and step > 0:
                    beat += rng.uniform(-humanize, humanize) * 0.25

                # Velocity variation
                is_downbeat = (step % 4 == 0)
                base_vel = 100 if is_downbeat else 80
                vel = max(1, min(127, base_vel + rng.randint(-15, 15)))

                # Ghost notes for hi-hats on weak beats
                if drum_name in ("hihat", "ride") and not is_downbeat:
                    vel = max(1, vel - 20)

                notes.append(MidiNote(
                    pitch=midi_note,
                    start_beats=max(0.0, beat),
                    length_beats=0.2 if drum_name in ("hihat", "ride") else 0.25,
                    velocity=vel,
                ))

    return notes


# ---------------------------------------------------------------------------
# Text Prompt Parser
# ---------------------------------------------------------------------------

def _parse_root(text: str) -> int:
    """Extract root note from text. Returns MIDI note number (0-11)."""
    # Try contextual patterns first: "in C-Dur", "in A-Moll", "in F#"
    m = re.search(r'(?:in|key|tonart)\s+([A-Ga-g][#b]?)', text, re.IGNORECASE)
    if m:
        name = m.group(1)
        name = name[0].upper() + name[1:] if len(name) > 1 else name.upper()
        if name in NOTE_MAP:
            return NOTE_MAP[name]

    # Fallback: match standalone note names (longest first, but only real notes)
    for name in ["C#", "D#", "F#", "G#", "A#", "Db", "Eb", "Gb", "Ab", "Bb",
                 "C", "D", "E", "F", "G", "A", "B"]:
        # Must be preceded by space/start and followed by non-letter (avoid matching inside words)
        pattern = r'(?:^|[\s,])' + re.escape(name) + r'(?:[\s\-]|$|[Dd]ur|[Mm]oll|[Mm]aj|[Mm]in)'
        if re.search(pattern, text):
            return NOTE_MAP[name]

    return 0  # default C


def _parse_scale(text: str) -> str:
    """Extract scale/mode from text."""
    tl = text.lower()
    for name in SCALES:
        if name in tl:
            return name
    if "minor" in tl or "moll" in tl:
        return "moll"
    if "major" in tl or "dur" in tl:
        return "dur"
    return "dur"


def _parse_style(text: str) -> str:
    """Extract genre/style from text."""
    tl = text.lower()
    for style in DRUM_PATTERNS:
        if style in tl:
            return style
    for style in PROGRESSIONS:
        if style in tl:
            return style
    # Aliases
    aliases = {
        "hip hop": "hiphop", "hip-hop": "hiphop",
        "drum and bass": "dnb", "drum & bass": "dnb",
        "lo-fi": "lofi", "lo fi": "lofi",
        "r&b": "rnb", "r und b": "rnb",
    }
    for alias, style in aliases.items():
        if alias in tl:
            return style
    return "pop"


def _parse_bars(text: str) -> int:
    """Extract bar count from text."""
    m = re.search(r"(\d+)\s*(?:bar|takt|bars|takte)", text, re.IGNORECASE)
    if m:
        return max(1, min(32, int(m.group(1))))
    return 4


def _parse_mood(text: str) -> str:
    """Extract mood from text."""
    tl = text.lower()
    for mood in MOODS:
        if mood in tl:
            return mood
    return ""


def _detect_request_type(text: str) -> str:
    """Detect what the user wants: melody, chords, bass, drums, or full."""
    tl = text.lower()
    if any(w in tl for w in ["drum", "schlagzeug", "beat", "rhythm", "rhythmus"]):
        return "drums"
    if any(w in tl for w in ["bass", "bassline", "basslinie"]):
        return "bass"
    if any(w in tl for w in ["akkord", "chord", "harmonie", "harmony", "progression"]):
        return "chords"
    if any(w in tl for w in ["melodie", "melody", "linie", "line", "motiv"]):
        return "melody"
    # Default: generate everything
    return "full"


# ---------------------------------------------------------------------------
# Main Interface
# ---------------------------------------------------------------------------

@dataclass
class LocalAIResult:
    """Result of a local AI generation."""
    notes: List[MidiNote] = field(default_factory=list)
    description: str = ""
    request_type: str = ""  # melody, chords, bass, drums, full
    parameters: Dict[str, Any] = field(default_factory=dict)
    tracks: Dict[str, List[MidiNote]] = field(default_factory=dict)


def process_prompt(prompt: str, seed: int = 0) -> LocalAIResult:
    """Process a natural language prompt and generate music.

    This is the main entry point. Accepts prompts in German or English:
    - "Erstelle eine fröhliche Melodie in C-Dur"
    - "Generate a rock drum pattern, 8 bars"
    - "Akkordfolge im Jazz-Stil"
    - "Bassline zu einer Pop-Progression in A-Moll, 4 Takte"
    - "Erstelle einen kompletten Song-Sketch in E-Moll"

    Returns a LocalAIResult with generated MIDI notes and description.
    """
    req_type = _detect_request_type(prompt)
    root = _parse_root(prompt)
    scale = _parse_scale(prompt)
    style = _parse_style(prompt)
    bars = _parse_bars(prompt)
    mood = _parse_mood(prompt)

    root_name = NOTE_NAMES[root % 12]
    scale_name = "Dur" if scale in ("dur", "major") else scale.replace("_", " ").title()

    result = LocalAIResult(
        request_type=req_type,
        parameters={
            "root": root_name, "scale": scale_name, "style": style,
            "bars": bars, "mood": mood or "neutral", "seed": seed,
        },
    )

    if req_type == "melody":
        result.notes = generate_melody(root, scale, bars, mood=mood, seed=seed)
        result.description = (
            f"🎵 Melodie in {root_name}-{scale_name}, {bars} Takte, "
            f"Stimmung: {mood or 'neutral'}, {len(result.notes)} Noten"
        )

    elif req_type == "chords":
        voicing = "arpeggio" if any(w in prompt.lower() for w in [
            "arpeggio", "gebrochen", "broken"]) else "block"
        result.notes = generate_chord_progression(
            root, style, bars, voicing=voicing, seed=seed)
        result.description = (
            f"🎹 Akkordfolge '{style}' in {root_name}-{scale_name}, "
            f"{bars} Takte, {len(result.notes)} Noten"
        )

    elif req_type == "bass":
        result.notes = generate_bassline(root, style, bars, seed=seed)
        result.description = (
            f"🎸 Bassline '{style}' in {root_name}, "
            f"{bars} Takte, {len(result.notes)} Noten"
        )

    elif req_type == "drums":
        result.notes = generate_drum_pattern(style, bars, seed=seed)
        result.description = (
            f"🥁 Drum-Pattern '{style}', "
            f"{bars} Takte, {len(result.notes)} Noten"
        )

    elif req_type == "full":
        # Generate a complete multi-track sketch
        melody = generate_melody(root, scale, bars, mood=mood, seed=seed)
        chords = generate_chord_progression(root, style, bars, seed=seed + 1)
        bass = generate_bassline(root, style, bars, seed=seed + 2)
        drums = generate_drum_pattern(style, bars, seed=seed + 3)

        result.notes = melody  # primary track
        result.tracks = {
            "Melodie": melody,
            "Akkorde": chords,
            "Bass": bass,
            "Drums": drums,
        }
        total = len(melody) + len(chords) + len(bass) + len(drums)
        result.description = (
            f"🎼 Song-Sketch in {root_name}-{scale_name}, Stil: {style}, "
            f"{bars} Takte\n"
            f"  🎵 Melodie: {len(melody)} Noten\n"
            f"  🎹 Akkorde: {len(chords)} Noten\n"
            f"  🎸 Bass: {len(bass)} Noten\n"
            f"  🥁 Drums: {len(drums)} Noten\n"
            f"  Gesamt: {total} Noten"
        )

    return result


def get_available_styles() -> List[str]:
    """Return all available genre/style names."""
    return sorted(set(list(DRUM_PATTERNS.keys()) + list(PROGRESSIONS.keys())))


def get_available_moods() -> List[str]:
    """Return all available mood names."""
    return sorted(MOODS.keys())


def get_available_scales() -> List[str]:
    """Return all available scale names."""
    return sorted(SCALES.keys())
