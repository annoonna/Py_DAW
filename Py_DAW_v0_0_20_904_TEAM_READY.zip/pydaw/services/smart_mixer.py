"""Smart Mixer Service (P3A) — Offline mix analysis & auto-correction.

Pure Python + numpy. No ML. Works on rendered audio buffers.

Features:
- Auto-gain-staging: normalize all tracks to -18 LUFS
- Frequency conflict detection: find overlapping bands
- Stereo image analysis: width, correlation, balance
- Dynamic range analysis: crest factor, loudness range
- Mix recommendations (text-based)

v0.0.20.808 — Phase P3A
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any

log = logging.getLogger(__name__)

try:
    import numpy as np
except Exception:
    np = None  # type: ignore


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class TrackAnalysis:
    """Analysis results for a single track."""
    track_id: str = ""
    track_name: str = ""
    peak_db: float = -96.0
    rms_db: float = -96.0
    lufs: float = -96.0
    crest_factor_db: float = 0.0      # peak - rms
    dc_offset: float = 0.0
    is_clipping: bool = False
    suggested_gain_db: float = 0.0    # gain to reach target LUFS
    # Frequency analysis
    dominant_freq_hz: float = 0.0
    spectral_centroid_hz: float = 0.0
    low_energy: float = 0.0           # 0..1 energy ratio < 250 Hz
    mid_energy: float = 0.0           # 0..1 energy ratio 250-4000 Hz
    high_energy: float = 0.0          # 0..1 energy ratio > 4000 Hz
    # Stereo
    stereo_width: float = 0.0         # 0..1 (0=mono, 1=full stereo)
    stereo_correlation: float = 1.0   # -1..1 (1=mono, 0=uncorrelated, -1=out of phase)
    balance: float = 0.0             # -1..1 (negative=left, positive=right)

    def to_dict(self) -> dict:
        return {
            "track_id": self.track_id, "track_name": self.track_name,
            "peak_db": round(self.peak_db, 1), "rms_db": round(self.rms_db, 1),
            "lufs": round(self.lufs, 1), "crest_factor_db": round(self.crest_factor_db, 1),
            "dc_offset": round(self.dc_offset, 4), "is_clipping": self.is_clipping,
            "suggested_gain_db": round(self.suggested_gain_db, 1),
            "dominant_freq_hz": round(self.dominant_freq_hz, 1),
            "spectral_centroid_hz": round(self.spectral_centroid_hz, 1),
            "low_energy": round(self.low_energy, 3),
            "mid_energy": round(self.mid_energy, 3),
            "high_energy": round(self.high_energy, 3),
            "stereo_width": round(self.stereo_width, 3),
            "stereo_correlation": round(self.stereo_correlation, 3),
            "balance": round(self.balance, 3),
        }


@dataclass
class FrequencyConflict:
    """Detected frequency conflict between two tracks."""
    track_a_id: str = ""
    track_b_id: str = ""
    track_a_name: str = ""
    track_b_name: str = ""
    freq_band: str = ""              # "sub" | "low" | "low_mid" | "mid" | "high_mid" | "high"
    freq_range_hz: Tuple[float, float] = (0.0, 0.0)
    overlap_score: float = 0.0       # 0..1 severity
    suggestion: str = ""             # e.g. "EQ cut Track B at 200 Hz"

    def to_dict(self) -> dict:
        return {
            "track_a": self.track_a_name, "track_b": self.track_b_name,
            "band": self.freq_band,
            "range_hz": [round(self.freq_range_hz[0], 0), round(self.freq_range_hz[1], 0)],
            "severity": round(self.overlap_score, 2),
            "suggestion": self.suggestion,
        }


@dataclass
class MixReport:
    """Complete mix analysis report."""
    tracks: List[TrackAnalysis] = field(default_factory=list)
    conflicts: List[FrequencyConflict] = field(default_factory=list)
    overall_peak_db: float = -96.0
    overall_lufs: float = -96.0
    headroom_db: float = 0.0
    dynamic_range_db: float = 0.0
    recommendations: List[str] = field(default_factory=list)
    score: float = 0.0               # 0..100 mix quality score

    def to_dict(self) -> dict:
        return {
            "tracks": [t.to_dict() for t in self.tracks],
            "conflicts": [c.to_dict() for c in self.conflicts],
            "overall_peak_db": round(self.overall_peak_db, 1),
            "overall_lufs": round(self.overall_lufs, 1),
            "headroom_db": round(self.headroom_db, 1),
            "dynamic_range_db": round(self.dynamic_range_db, 1),
            "recommendations": self.recommendations,
            "score": round(self.score, 0),
        }


# ---------------------------------------------------------------------------
# LUFS measurement (ITU-R BS.1770 simplified)
# ---------------------------------------------------------------------------

def _measure_lufs(audio: "np.ndarray", sr: int = 48000) -> float:
    """Simplified LUFS measurement (ITU-R BS.1770 approximation).

    For true LUFS, a K-weighting pre-filter is needed. This is a
    simplified version using RMS with a frequency-weighting approximation.
    """
    if np is None or len(audio) < 256:
        return -96.0

    audio = np.asarray(audio, dtype=np.float64).flatten()

    # K-weighting approximation: high-shelf boost + high-pass
    # Simplified: apply a gentle high-frequency emphasis
    # True K-weighting has 2 biquad stages — we approximate with a simple emphasis
    from_idx = max(1, len(audio) // 100)
    # Simple high-shelf: boost above 1.5 kHz by ~4 dB
    # This is a rough approximation — real LUFS uses specific filter coefficients
    n_fft = min(4096, len(audio))
    if n_fft > 256:
        spec = np.fft.rfft(audio[:n_fft])
        freqs = np.fft.rfftfreq(n_fft, 1.0 / sr)
        # K-weighting boost curve (simplified)
        boost = np.ones_like(freqs)
        boost[freqs > 1500] *= 1.6   # +4 dB above 1.5 kHz
        boost[freqs < 60] *= 0.0     # kill sub-bass
        spec *= boost
        weighted = np.fft.irfft(spec, n=n_fft)
        rms = float(np.sqrt(np.mean(weighted ** 2)))
    else:
        rms = float(np.sqrt(np.mean(audio ** 2)))

    if rms < 1e-10:
        return -96.0

    # LUFS ≈ -0.691 + 10 * log10(mean_square_of_K_weighted)
    lufs = -0.691 + 10.0 * math.log10(rms ** 2 + 1e-20)
    return max(-96.0, lufs)


def _measure_peak_db(audio: "np.ndarray") -> float:
    """Peak level in dBFS."""
    if np is None or len(audio) < 1:
        return -96.0
    peak = float(np.max(np.abs(np.asarray(audio, dtype=np.float64))))
    if peak < 1e-10:
        return -96.0
    return 20.0 * math.log10(peak)


def _measure_rms_db(audio: "np.ndarray") -> float:
    """RMS level in dBFS."""
    if np is None or len(audio) < 1:
        return -96.0
    rms = float(np.sqrt(np.mean(np.asarray(audio, dtype=np.float64) ** 2)))
    if rms < 1e-10:
        return -96.0
    return 20.0 * math.log10(rms)


# ---------------------------------------------------------------------------
# Spectral analysis
# ---------------------------------------------------------------------------

# Frequency bands
BANDS = {
    "sub": (20, 60),
    "low": (60, 250),
    "low_mid": (250, 1000),
    "mid": (1000, 4000),
    "high_mid": (4000, 8000),
    "high": (8000, 20000),
}


def _spectral_analysis(audio: "np.ndarray", sr: int = 48000) -> Dict[str, float]:
    """Compute spectral energy per frequency band."""
    if np is None or len(audio) < 512:
        return {"low_energy": 0.33, "mid_energy": 0.34, "high_energy": 0.33,
                "dominant_freq": 440.0, "centroid": 1000.0}

    audio = np.asarray(audio, dtype=np.float64).flatten()
    n_fft = min(8192, len(audio))
    spec = np.abs(np.fft.rfft(audio[:n_fft]))
    freqs = np.fft.rfftfreq(n_fft, 1.0 / sr)

    total_energy = float(np.sum(spec ** 2)) + 1e-20

    # Energy per band
    band_energy: Dict[str, float] = {}
    for band_name, (f_lo, f_hi) in BANDS.items():
        mask = (freqs >= f_lo) & (freqs < f_hi)
        band_energy[band_name] = float(np.sum(spec[mask] ** 2)) / total_energy

    # Aggregate into low/mid/high
    low = band_energy.get("sub", 0) + band_energy.get("low", 0)
    mid = band_energy.get("low_mid", 0) + band_energy.get("mid", 0)
    high = band_energy.get("high_mid", 0) + band_energy.get("high", 0)

    # Dominant frequency
    dominant_idx = int(np.argmax(spec[1:])) + 1
    dominant_freq = float(freqs[dominant_idx]) if dominant_idx < len(freqs) else 440.0

    # Spectral centroid
    centroid = float(np.sum(freqs * spec) / (np.sum(spec) + 1e-10))

    return {
        "low_energy": low, "mid_energy": mid, "high_energy": high,
        "dominant_freq": dominant_freq, "centroid": centroid,
        "band_energy": band_energy,
    }


def _stereo_analysis(left: "np.ndarray", right: "np.ndarray") -> Dict[str, float]:
    """Analyze stereo image: width, correlation, balance."""
    if np is None or len(left) < 64:
        return {"width": 0.0, "correlation": 1.0, "balance": 0.0}

    l = np.asarray(left, dtype=np.float64).flatten()
    r = np.asarray(right, dtype=np.float64).flatten()
    n = min(len(l), len(r))
    l, r = l[:n], r[:n]

    # Mid/Side
    mid = (l + r) * 0.5
    side = (l - r) * 0.5

    mid_rms = float(np.sqrt(np.mean(mid ** 2)))
    side_rms = float(np.sqrt(np.mean(side ** 2)))

    # Width: ratio of side to mid energy (0=mono, 1=full stereo)
    if mid_rms + side_rms > 1e-10:
        width = side_rms / (mid_rms + side_rms)
    else:
        width = 0.0

    # Correlation (Pearson)
    l_mean = float(np.mean(l))
    r_mean = float(np.mean(r))
    num = float(np.sum((l - l_mean) * (r - r_mean)))
    den_l = float(np.sqrt(np.sum((l - l_mean) ** 2)))
    den_r = float(np.sqrt(np.sum((r - r_mean) ** 2)))
    if den_l * den_r > 1e-10:
        correlation = num / (den_l * den_r)
    else:
        correlation = 1.0

    # Balance: RMS difference between L and R
    l_rms = float(np.sqrt(np.mean(l ** 2)))
    r_rms = float(np.sqrt(np.mean(r ** 2)))
    if l_rms + r_rms > 1e-10:
        balance = (r_rms - l_rms) / (l_rms + r_rms)
    else:
        balance = 0.0

    return {
        "width": max(0.0, min(1.0, width)),
        "correlation": max(-1.0, min(1.0, correlation)),
        "balance": max(-1.0, min(1.0, balance)),
    }


# ---------------------------------------------------------------------------
# Track analysis
# ---------------------------------------------------------------------------

def analyze_track(
    audio: "np.ndarray",
    sr: int = 48000,
    *,
    track_id: str = "",
    track_name: str = "",
    target_lufs: float = -18.0,
) -> TrackAnalysis:
    """Analyze a single track's audio."""
    if np is None:
        return TrackAnalysis(track_id=track_id, track_name=track_name)

    audio = np.asarray(audio, dtype=np.float64)
    is_stereo = audio.ndim == 2 and audio.shape[1] >= 2

    if is_stereo:
        mono = np.mean(audio[:, :2], axis=1)
        left = audio[:, 0]
        right = audio[:, 1]
    else:
        mono = audio.flatten()
        left = mono
        right = mono

    peak = _measure_peak_db(mono)
    rms = _measure_rms_db(mono)
    lufs = _measure_lufs(mono, sr)
    crest = peak - rms

    # DC offset
    dc = float(np.mean(mono))

    # Spectral
    spec_data = _spectral_analysis(mono, sr)

    # Stereo
    stereo_data = _stereo_analysis(left, right) if is_stereo else {"width": 0.0, "correlation": 1.0, "balance": 0.0}

    # Suggested gain
    suggested_gain = target_lufs - lufs if lufs > -90 else 0.0

    return TrackAnalysis(
        track_id=track_id,
        track_name=track_name,
        peak_db=peak,
        rms_db=rms,
        lufs=lufs,
        crest_factor_db=crest,
        dc_offset=dc,
        is_clipping=peak > -0.1,
        suggested_gain_db=suggested_gain,
        dominant_freq_hz=spec_data["dominant_freq"],
        spectral_centroid_hz=spec_data["centroid"],
        low_energy=spec_data["low_energy"],
        mid_energy=spec_data["mid_energy"],
        high_energy=spec_data["high_energy"],
        stereo_width=stereo_data["width"],
        stereo_correlation=stereo_data["correlation"],
        balance=stereo_data["balance"],
    )


# ---------------------------------------------------------------------------
# Frequency conflict detection
# ---------------------------------------------------------------------------

def detect_frequency_conflicts(
    track_analyses: List[Tuple[TrackAnalysis, "np.ndarray"]],
    sr: int = 48000,
    *,
    threshold: float = 0.3,
) -> List[FrequencyConflict]:
    """Detect frequency band conflicts between pairs of tracks.

    track_analyses: list of (TrackAnalysis, audio_mono_array) tuples
    threshold: overlap score threshold (0..1) to report
    """
    if np is None or len(track_analyses) < 2:
        return []

    # Compute per-band spectra for each track
    n_fft = 4096
    track_spectra: List[Dict[str, float]] = []

    for ta, audio in track_analyses:
        audio = np.asarray(audio, dtype=np.float64).flatten()
        if len(audio) < n_fft:
            track_spectra.append({b: 0.0 for b in BANDS})
            continue
        spec = np.abs(np.fft.rfft(audio[:n_fft]))
        freqs = np.fft.rfftfreq(n_fft, 1.0 / sr)
        total = float(np.sum(spec ** 2)) + 1e-20

        band_e = {}
        for band_name, (f_lo, f_hi) in BANDS.items():
            mask = (freqs >= f_lo) & (freqs < f_hi)
            band_e[band_name] = float(np.sum(spec[mask] ** 2)) / total
        track_spectra.append(band_e)

    conflicts: List[FrequencyConflict] = []

    for i in range(len(track_analyses)):
        for j in range(i + 1, len(track_analyses)):
            ta_i = track_analyses[i][0]
            ta_j = track_analyses[j][0]
            spec_i = track_spectra[i]
            spec_j = track_spectra[j]

            for band_name, (f_lo, f_hi) in BANDS.items():
                energy_i = spec_i.get(band_name, 0)
                energy_j = spec_j.get(band_name, 0)

                # Overlap = product of normalized energies (both high = conflict)
                overlap = math.sqrt(energy_i * energy_j)

                if overlap >= threshold:
                    # Generate suggestion
                    if energy_i > energy_j:
                        suggestion = f"EQ-Cut {ta_j.track_name} bei {int((f_lo + f_hi) / 2)} Hz (-3 dB)"
                    else:
                        suggestion = f"EQ-Cut {ta_i.track_name} bei {int((f_lo + f_hi) / 2)} Hz (-3 dB)"

                    conflicts.append(FrequencyConflict(
                        track_a_id=ta_i.track_id,
                        track_b_id=ta_j.track_id,
                        track_a_name=ta_i.track_name,
                        track_b_name=ta_j.track_name,
                        freq_band=band_name,
                        freq_range_hz=(f_lo, f_hi),
                        overlap_score=overlap,
                        suggestion=suggestion,
                    ))

    # Sort by severity
    conflicts.sort(key=lambda c: c.overlap_score, reverse=True)
    return conflicts


# ---------------------------------------------------------------------------
# Mix recommendations
# ---------------------------------------------------------------------------

def generate_recommendations(
    tracks: List[TrackAnalysis],
    conflicts: List[FrequencyConflict],
    overall_peak: float,
    overall_lufs: float,
) -> Tuple[List[str], float]:
    """Generate mix recommendations and quality score.

    Returns (recommendations, score).
    """
    recs: List[str] = []
    score = 100.0

    # Overall level
    if overall_peak > -0.5:
        recs.append("⚠ Master clippt! Gesamtpegel senken um mindestens 1 dB.")
        score -= 15
    elif overall_peak > -3.0:
        recs.append(f"💡 Wenig Headroom ({overall_peak:.1f} dBFS). Empfehlung: -6 dBFS Peak.")
        score -= 5

    if overall_lufs > -10:
        recs.append(f"⚠ Mix zu laut ({overall_lufs:.1f} LUFS). Ziel: -14 LUFS (Spotify) oder -16 LUFS (Apple).")
        score -= 10
    elif overall_lufs < -24:
        recs.append(f"💡 Mix leise ({overall_lufs:.1f} LUFS). Gain-Staging prüfen.")
        score -= 5

    # Per-track issues
    clipping_tracks = [t for t in tracks if t.is_clipping]
    if clipping_tracks:
        names = ", ".join(t.track_name for t in clipping_tracks[:3])
        recs.append(f"⚠ Clipping auf: {names}. Pegel reduzieren.")
        score -= len(clipping_tracks) * 5

    # DC offset
    dc_tracks = [t for t in tracks if abs(t.dc_offset) > 0.01]
    if dc_tracks:
        names = ", ".join(t.track_name for t in dc_tracks[:3])
        recs.append(f"💡 DC-Offset auf: {names}. High-Pass-Filter empfohlen.")
        score -= len(dc_tracks) * 2

    # Gain staging
    loud_tracks = [t for t in tracks if t.lufs > -10]
    quiet_tracks = [t for t in tracks if -90 < t.lufs < -30]
    if loud_tracks:
        names = ", ".join(t.track_name for t in loud_tracks[:3])
        recs.append(f"💡 Zu laut: {names}. Auto-Gain auf -18 LUFS empfohlen.")
        score -= len(loud_tracks) * 3
    if quiet_tracks:
        names = ", ".join(t.track_name for t in quiet_tracks[:3])
        recs.append(f"💡 Sehr leise: {names}. Gain erhöhen.")
        score -= len(quiet_tracks) * 2

    # Stereo issues
    phase_tracks = [t for t in tracks if t.stereo_correlation < 0.0]
    if phase_tracks:
        names = ", ".join(t.track_name for t in phase_tracks[:3])
        recs.append(f"⚠ Phasenprobleme auf: {names}. Mono-Check machen!")
        score -= len(phase_tracks) * 8

    wide_tracks = [t for t in tracks if t.stereo_width > 0.8]
    if len(wide_tracks) > len(tracks) * 0.5:
        recs.append("💡 Viele Tracks sehr breit. Bass + Kick lieber mono/zentriert.")
        score -= 5

    # Balance
    unbalanced = [t for t in tracks if abs(t.balance) > 0.3]
    if unbalanced:
        names = ", ".join(t.track_name for t in unbalanced[:3])
        recs.append(f"💡 Stereo-Balance ungleichmäßig: {names}.")
        score -= len(unbalanced) * 2

    # Frequency conflicts
    if conflicts:
        severe = [c for c in conflicts if c.overlap_score > 0.5]
        if severe:
            for c in severe[:3]:
                recs.append(f"🔴 Frequenzkonflikt: {c.track_a_name} ↔ {c.track_b_name} im {c.freq_band}-Band. {c.suggestion}")
            score -= len(severe) * 5
        moderate = [c for c in conflicts if 0.3 <= c.overlap_score <= 0.5]
        if moderate and not severe:
            recs.append(f"💡 {len(moderate)} moderate Frequenzüberlappungen. EQ-Trennung prüfen.")
            score -= len(moderate) * 2

    # Positive feedback
    if not recs:
        recs.append("✅ Mix sieht gut aus! Keine kritischen Probleme erkannt.")

    if score >= 80 and recs:
        recs.append(f"📊 Mix-Score: {max(0, score):.0f}/100 — {'Gut' if score >= 80 else 'Verbesserungspotenzial'}")

    return recs, max(0.0, min(100.0, score))


# ---------------------------------------------------------------------------
# Full mix analysis pipeline
# ---------------------------------------------------------------------------

def analyze_mix(
    track_data: List[Dict[str, Any]],
    sr: int = 48000,
    *,
    target_lufs: float = -18.0,
) -> MixReport:
    """Analyze a complete mix.

    track_data: list of dicts with:
        'id': track ID
        'name': track name
        'audio': numpy array (mono or stereo)

    Returns MixReport with all analysis + recommendations.
    """
    if np is None or not track_data:
        return MixReport(recommendations=["Keine Track-Daten für Analyse."])

    # Analyze each track
    track_analyses: List[TrackAnalysis] = []
    track_with_audio: List[Tuple[TrackAnalysis, "np.ndarray"]] = []

    for td in track_data:
        audio = td.get("audio")
        if audio is None:
            continue
        audio = np.asarray(audio, dtype=np.float64)
        ta = analyze_track(
            audio, sr,
            track_id=str(td.get("id", "")),
            track_name=str(td.get("name", "Track")),
            target_lufs=target_lufs,
        )
        track_analyses.append(ta)

        # Get mono for conflict detection
        mono = np.mean(audio, axis=1) if audio.ndim == 2 else audio.flatten()
        track_with_audio.append((ta, mono))

    # Detect conflicts
    conflicts = detect_frequency_conflicts(track_with_audio, sr)

    # Overall levels (sum all tracks)
    if track_with_audio:
        all_mono = [a for _, a in track_with_audio]
        min_len = min(len(a) for a in all_mono)
        summed = np.zeros(min_len, dtype=np.float64)
        for a in all_mono:
            summed += a[:min_len]
        overall_peak = _measure_peak_db(summed)
        overall_lufs = _measure_lufs(summed, sr)
    else:
        overall_peak = -96.0
        overall_lufs = -96.0

    headroom = 0.0 - overall_peak
    dynamic_range = overall_peak - overall_lufs if overall_lufs > -90 else 0.0

    # Recommendations
    recs, score = generate_recommendations(
        track_analyses, conflicts, overall_peak, overall_lufs)

    return MixReport(
        tracks=track_analyses,
        conflicts=conflicts,
        overall_peak_db=overall_peak,
        overall_lufs=overall_lufs,
        headroom_db=headroom,
        dynamic_range_db=dynamic_range,
        recommendations=recs,
        score=score,
    )


# ---------------------------------------------------------------------------
# Auto-gain-staging
# ---------------------------------------------------------------------------

def compute_auto_gain(
    tracks: List[TrackAnalysis],
    target_lufs: float = -18.0,
) -> Dict[str, float]:
    """Compute gain adjustments to normalize all tracks to target LUFS.

    Returns dict mapping track_id → gain_db adjustment.
    """
    gains: Dict[str, float] = {}
    for t in tracks:
        if t.lufs > -90:
            gain = target_lufs - t.lufs
            # Clamp to reasonable range
            gain = max(-24.0, min(24.0, gain))
            gains[t.track_id] = round(gain, 1)
        else:
            gains[t.track_id] = 0.0
    return gains
