"""LV2 Builder (P6B) — Generate LV2 plugins from Python DSP code.

Takes a Python DSP class and generates a complete LV2 plugin bundle:
- manifest.ttl (plugin discovery)
- plugin.ttl (metadata, ports, parameters)
- plugin.so (C wrapper that calls Python via embedded interpreter)

This enables users to write DSP in Python and export it as a
standard LV2 plugin usable in any LV2 host (Ardour, Carla, etc.).

v0.0.20.812 — Phase P6B
"""

from __future__ import annotations

import logging
import os
import textwrap
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Any

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class Lv2Port:
    """LV2 port definition."""
    name: str
    symbol: str              # short C-compatible name
    port_type: str = "control"  # "control"|"audio"|"atom"
    direction: str = "input"    # "input"|"output"
    default: float = 0.0
    minimum: float = 0.0
    maximum: float = 1.0
    is_logarithmic: bool = False
    is_integer: bool = False
    is_toggle: bool = False
    unit: str = ""           # "dB"|"Hz"|"ms"|"%"

    def to_dict(self) -> dict:
        return {
            "name": self.name, "symbol": self.symbol,
            "type": self.port_type, "direction": self.direction,
            "default": self.default, "min": self.minimum, "max": self.maximum,
        }


@dataclass
class Lv2PluginSpec:
    """Complete LV2 plugin specification."""
    uri: str                            # e.g. "urn:pydaw:plugins:my-gain"
    name: str = ""
    author: str = "Py_DAW"
    license: str = "ISC"
    category: str = "UtilityPlugin"     # LV2 class
    ports: List[Lv2Port] = field(default_factory=list)
    python_class: str = ""              # Python class name implementing the DSP
    python_module: str = ""             # Python module path
    description: str = ""

    def to_dict(self) -> dict:
        return {
            "uri": self.uri, "name": self.name,
            "author": self.author, "category": self.category,
            "ports": [p.to_dict() for p in self.ports],
            "python_class": self.python_class,
            "python_module": self.python_module,
        }


# ---------------------------------------------------------------------------
# TTL generators
# ---------------------------------------------------------------------------

_LV2_CATEGORIES = {
    "UtilityPlugin": "lv2:UtilityPlugin",
    "AmplifierPlugin": "lv2:AmplifierPlugin",
    "FilterPlugin": "lv2:FilterPlugin",
    "DelayPlugin": "lv2:DelayPlugin",
    "ReverbPlugin": "lv2:ReverbPlugin",
    "CompressorPlugin": "lv2:CompressorPlugin",
    "DistortionPlugin": "lv2:DistortionPlugin",
    "ChorusPlugin": "lv2:ChorusPlugin",
    "InstrumentPlugin": "lv2:InstrumentPlugin",
    "AnalyserPlugin": "lv2:AnalyserPlugin",
}


def _generate_manifest_ttl(spec: Lv2PluginSpec) -> str:
    """Generate manifest.ttl for plugin discovery."""
    return textwrap.dedent(f"""\
        @prefix lv2: <http://lv2plug.in/ns/lv2core#> .
        @prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .

        <{spec.uri}>
            a lv2:Plugin ;
            lv2:binary <{_safe_symbol(spec.name)}.so> ;
            rdfs:seeAlso <{_safe_symbol(spec.name)}.ttl> .
    """)


def _generate_plugin_ttl(spec: Lv2PluginSpec) -> str:
    """Generate plugin.ttl with metadata and port definitions."""
    category = _LV2_CATEGORIES.get(spec.category, "lv2:Plugin")

    lines = [
        '@prefix lv2:  <http://lv2plug.in/ns/lv2core#> .',
        '@prefix doap: <http://usefulinc.com/ns/doap#> .',
        '@prefix foaf: <http://xmlns.com/foaf/0.1/> .',
        '@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .',
        '@prefix units: <http://lv2plug.in/ns/extensions/units#> .',
        '',
        f'<{spec.uri}>',
        f'    a lv2:Plugin, {category} ;',
        f'    doap:name "{spec.name}" ;',
        f'    doap:license <http://opensource.org/licenses/{spec.license}> ;',
        f'    lv2:optionalFeature lv2:hardRTCapable ;',
    ]

    if spec.author:
        lines.append(f'    doap:developer [ foaf:name "{spec.author}" ] ;')

    # Add audio I/O ports first
    port_idx = 0

    # Audio In L/R
    lines.append(f'    lv2:port [')
    lines.append(f'        a lv2:InputPort, lv2:AudioPort ;')
    lines.append(f'        lv2:index {port_idx} ;')
    lines.append(f'        lv2:symbol "in_l" ;')
    lines.append(f'        lv2:name "Audio In L"')
    lines.append(f'    ] , [')
    port_idx += 1
    lines.append(f'        a lv2:InputPort, lv2:AudioPort ;')
    lines.append(f'        lv2:index {port_idx} ;')
    lines.append(f'        lv2:symbol "in_r" ;')
    lines.append(f'        lv2:name "Audio In R"')
    lines.append(f'    ] , [')
    port_idx += 1

    # Audio Out L/R
    lines.append(f'        a lv2:OutputPort, lv2:AudioPort ;')
    lines.append(f'        lv2:index {port_idx} ;')
    lines.append(f'        lv2:symbol "out_l" ;')
    lines.append(f'        lv2:name "Audio Out L"')
    lines.append(f'    ] , [')
    port_idx += 1
    lines.append(f'        a lv2:OutputPort, lv2:AudioPort ;')
    lines.append(f'        lv2:index {port_idx} ;')
    lines.append(f'        lv2:symbol "out_r" ;')
    lines.append(f'        lv2:name "Audio Out R"')

    # Control ports
    for port in spec.ports:
        if port.port_type != "control":
            continue
        lines.append(f'    ] , [')
        port_idx += 1
        direction = "lv2:InputPort" if port.direction == "input" else "lv2:OutputPort"
        lines.append(f'        a {direction}, lv2:ControlPort ;')
        lines.append(f'        lv2:index {port_idx} ;')
        lines.append(f'        lv2:symbol "{port.symbol}" ;')
        lines.append(f'        lv2:name "{port.name}" ;')
        lines.append(f'        lv2:default {port.default} ;')
        lines.append(f'        lv2:minimum {port.minimum} ;')
        lines.append(f'        lv2:maximum {port.maximum}')

        if port.is_toggle:
            lines.append(f'        ; lv2:portProperty lv2:toggled')
        if port.is_integer:
            lines.append(f'        ; lv2:portProperty lv2:integer')
        if port.is_logarithmic:
            lines.append(f'        ; lv2:portProperty <http://lv2plug.in/ns/ext/port-props#logarithmic>')

    lines.append(f'    ] .')

    return "\n".join(lines)


def _generate_python_wrapper(spec: Lv2PluginSpec) -> str:
    """Generate the Python DSP wrapper script.

    This script is loaded by the C host wrapper to call the Python DSP.
    """
    return textwrap.dedent(f"""\
        # Auto-generated LV2 Python wrapper for: {spec.name}
        # URI: {spec.uri}
        # Do not edit — regenerate via lv2_builder.py

        import sys
        import os

        # Add project to path
        _dir = os.path.dirname(os.path.abspath(__file__))
        if _dir not in sys.path:
            sys.path.insert(0, _dir)

        # Import the DSP class
        from {spec.python_module} import {spec.python_class}

        _instance = None
        _sample_rate = 44100.0


        def lv2_init(sample_rate: float, bundle_path: str) -> None:
            global _instance, _sample_rate
            _sample_rate = sample_rate
            _instance = {spec.python_class}()
            if hasattr(_instance, 'init'):
                _instance.init(sample_rate)


        def lv2_process(inputs, outputs, n_frames, ports):
            global _instance
            if _instance is None:
                return
            # Set parameters from control ports
            if hasattr(_instance, 'set_params'):
                _instance.set_params(ports)
            # Process audio
            if hasattr(_instance, 'process_block'):
                _instance.process_block(inputs, outputs, n_frames)
            elif hasattr(_instance, 'process_inplace'):
                _instance.process_inplace(inputs[0], inputs[1], n_frames)


        def lv2_cleanup():
            global _instance
            if _instance and hasattr(_instance, 'shutdown'):
                _instance.shutdown()
            _instance = None
    """)


def _safe_symbol(name: str) -> str:
    """Convert a name to a safe C/filesystem symbol."""
    import re
    s = re.sub(r"[^a-zA-Z0-9_]", "_", name.lower())
    return s.strip("_") or "plugin"


# ---------------------------------------------------------------------------
# Public API: Build LV2 bundle
# ---------------------------------------------------------------------------

def build_lv2_bundle(
    spec: Lv2PluginSpec,
    output_dir: str,
) -> Optional[str]:
    """Generate a complete LV2 plugin bundle.

    Args:
        spec: Plugin specification with ports and Python class info
        output_dir: Directory to create the bundle in

    Returns:
        Path to the .lv2 bundle directory, or None on failure.
    """
    bundle_name = _safe_symbol(spec.name) + ".lv2"
    bundle_path = Path(output_dir) / bundle_name

    try:
        bundle_path.mkdir(parents=True, exist_ok=True)

        # manifest.ttl
        manifest = _generate_manifest_ttl(spec)
        (bundle_path / "manifest.ttl").write_text(manifest, encoding="utf-8")

        # plugin.ttl
        plugin_ttl = _generate_plugin_ttl(spec)
        (bundle_path / f"{_safe_symbol(spec.name)}.ttl").write_text(
            plugin_ttl, encoding="utf-8"
        )

        # Python wrapper
        wrapper = _generate_python_wrapper(spec)
        (bundle_path / "dsp_wrapper.py").write_text(wrapper, encoding="utf-8")

        # README
        readme = (
            f"# {spec.name}\n\n"
            f"LV2 Plugin generated by Py_DAW LV2 Builder\n\n"
            f"URI: {spec.uri}\n"
            f"Author: {spec.author}\n"
            f"Category: {spec.category}\n\n"
            f"## Ports\n"
        )
        for p in spec.ports:
            readme += f"- {p.name} ({p.direction}): {p.minimum}..{p.maximum} (default {p.default})\n"
        readme += (
            f"\n## Python DSP\n"
            f"Module: {spec.python_module}\n"
            f"Class: {spec.python_class}\n\n"
            f"NOTE: This plugin requires a Python-capable LV2 host\n"
            f"or the Py_DAW built-in host to function.\n"
        )
        (bundle_path / "README.md").write_text(readme, encoding="utf-8")

        log.info("LV2 bundle created: %s", bundle_path)
        return str(bundle_path)

    except Exception as exc:
        log.error("LV2 build failed: %s", exc)
        return None


def build_from_pydaw_effect(
    effect_class: type,
    uri: str,
    name: str = "",
    output_dir: str = "",
) -> Optional[str]:
    """Build an LV2 bundle from a PyDawEffect class.

    Inspects the class for get_params() or PARAMS to auto-generate ports.

    Args:
        effect_class: Python class with process_inplace() or process_block()
        uri: LV2 URI for the plugin
        name: Display name (defaults to class name)
        output_dir: Where to write the bundle

    Returns:
        Path to the .lv2 bundle, or None.
    """
    if not name:
        name = getattr(effect_class, "name", effect_class.__name__)
    if not output_dir:
        output_dir = str(Path.home() / ".lv2")

    # Discover parameters
    ports: List[Lv2Port] = []
    params = getattr(effect_class, "PARAMS", None)
    if isinstance(params, dict):
        for key, info in params.items():
            if isinstance(info, dict):
                ports.append(Lv2Port(
                    name=info.get("label", key),
                    symbol=_safe_symbol(key),
                    default=float(info.get("default", 0)),
                    minimum=float(info.get("min", 0)),
                    maximum=float(info.get("max", 1)),
                    unit=info.get("unit", ""),
                ))
            elif isinstance(info, (list, tuple)) and len(info) >= 3:
                ports.append(Lv2Port(
                    name=key, symbol=_safe_symbol(key),
                    minimum=float(info[0]),
                    maximum=float(info[1]),
                    default=float(info[2]),
                ))

    # Try get_params() method
    if not ports and hasattr(effect_class, "get_params"):
        try:
            inst = effect_class()
            param_list = inst.get_params()
            if isinstance(param_list, list):
                for p in param_list:
                    if isinstance(p, dict):
                        ports.append(Lv2Port(
                            name=p.get("label", p.get("name", "?")),
                            symbol=_safe_symbol(p.get("name", f"p{len(ports)}")),
                            default=float(p.get("default", 0)),
                            minimum=float(p.get("min", 0)),
                            maximum=float(p.get("max", 1)),
                        ))
        except Exception:
            pass

    spec = Lv2PluginSpec(
        uri=uri,
        name=name,
        python_class=effect_class.__name__,
        python_module=effect_class.__module__,
        ports=ports,
        category=_guess_category(name),
    )

    return build_lv2_bundle(spec, output_dir)


def _guess_category(name: str) -> str:
    """Guess LV2 category from plugin name."""
    lower = name.lower()
    if any(k in lower for k in ("eq", "filter", "lowpass", "highpass")):
        return "FilterPlugin"
    if any(k in lower for k in ("comp", "limiter", "gate")):
        return "CompressorPlugin"
    if any(k in lower for k in ("reverb", "room", "hall")):
        return "ReverbPlugin"
    if any(k in lower for k in ("delay", "echo")):
        return "DelayPlugin"
    if any(k in lower for k in ("dist", "drive", "overdrive", "saturate")):
        return "DistortionPlugin"
    if any(k in lower for k in ("chorus", "flanger", "phaser")):
        return "ChorusPlugin"
    if any(k in lower for k in ("gain", "utility", "tool")):
        return "UtilityPlugin"
    return "UtilityPlugin"
