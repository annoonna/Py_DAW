"""sentinel_db.py — SENTINEL Database (Phase S1).

v0.0.20.904 — Phase S1 der SENTINEL_ROADMAP.

Tabellen:
- sentinel_events       — Flight Recorder Ringbuffer (letzte 60s)
- sentinel_anomalies    — Erkannte Anomalien
- sentinel_crashes      — Crash-Reports mit Blackbox
- sentinel_patterns     — Gelerntes Wissen
- sentinel_actions      — Audit-Log + Undo

Singleton via SentinelDB.get(). WAL mode fuer nicht-blockierendes Schreiben.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

# Ringbuffer-Limits
MAX_EVENTS_RINGBUFFER = 5000      # letzte ~60s bei 500ms Intervall
MAX_ANOMALIES = 1000
MAX_CRASHES = 200
MAX_PATTERNS = 500
MAX_ACTIONS = 2000

_SCHEMA_SQL = """
-- Flight Recorder Ringbuffer
CREATE TABLE IF NOT EXISTS sentinel_events (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp     REAL NOT NULL,
    category      TEXT NOT NULL,
    severity      INTEGER NOT NULL DEFAULT 1,
    source        TEXT NOT NULL DEFAULT '',
    metric_name   TEXT NOT NULL DEFAULT '',
    metric_value  REAL,
    message       TEXT DEFAULT '',
    context_json  TEXT DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_se_time ON sentinel_events(timestamp);
CREATE INDEX IF NOT EXISTS idx_se_severity ON sentinel_events(severity, timestamp);
CREATE INDEX IF NOT EXISTS idx_se_source ON sentinel_events(source, timestamp);

-- Erkannte Anomalien
CREATE TABLE IF NOT EXISTS sentinel_anomalies (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    detected_at   REAL NOT NULL,
    resolved_at   REAL DEFAULT 0,
    anomaly_type  TEXT NOT NULL,
    severity      INTEGER NOT NULL DEFAULT 2,
    source        TEXT NOT NULL DEFAULT '',
    description   TEXT NOT NULL DEFAULT '',
    evidence_json TEXT DEFAULT '{}',
    action_taken  TEXT DEFAULT '',
    user_response TEXT DEFAULT '',
    false_positive INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_sa_type ON sentinel_anomalies(anomaly_type, detected_at);

-- Crash-Reports mit Blackbox-Daten
CREATE TABLE IF NOT EXISTS sentinel_crashes (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    crash_time    REAL NOT NULL,
    session_id    TEXT NOT NULL DEFAULT '',
    crash_type    TEXT NOT NULL,
    component     TEXT NOT NULL DEFAULT '',
    error_message TEXT DEFAULT '',
    traceback     TEXT DEFAULT '',
    blackbox_json TEXT DEFAULT '{}',
    system_state  TEXT DEFAULT '{}',
    track_state   TEXT DEFAULT '{}',
    resolved      INTEGER DEFAULT 0,
    resolution    TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_sc_time ON sentinel_crashes(crash_time);
CREATE INDEX IF NOT EXISTS idx_sc_type ON sentinel_crashes(crash_type);

-- Gelerntes Wissen
CREATE TABLE IF NOT EXISTS sentinel_patterns (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern_type    TEXT NOT NULL,
    description     TEXT NOT NULL,
    conditions_json TEXT NOT NULL,
    confidence      REAL DEFAULT 0.5,
    occurrences     INTEGER DEFAULT 1,
    last_seen       REAL NOT NULL,
    prevention      TEXT DEFAULT '',
    auto_action     TEXT DEFAULT 'warn'
);
CREATE INDEX IF NOT EXISTS idx_sp_type ON sentinel_patterns(pattern_type);

-- Audit-Log + Undo
CREATE TABLE IF NOT EXISTS sentinel_actions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    action_time   REAL NOT NULL,
    action_type   TEXT NOT NULL,
    target        TEXT NOT NULL DEFAULT '',
    reason        TEXT DEFAULT '',
    severity      INTEGER DEFAULT 3,
    undone        INTEGER DEFAULT 0,
    undone_at     REAL DEFAULT 0,
    auto_action   INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_sact_time ON sentinel_actions(action_time);
"""


class SentinelDB:
    """SQLite-backed database for the SENTINEL diagnostics engine.

    Singleton. WAL mode for non-blocking writes.
    """

    _instance: Optional["SentinelDB"] = None

    @classmethod
    def get(cls) -> "SentinelDB":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "sentinel.db"
        self._loaded = False
        self._event_buffer: List[tuple] = []

    def ensure_loaded(self) -> None:
        if self._loaded:
            return
        try:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute("PRAGMA journal_mode=WAL")
                conn.executescript(_SCHEMA_SQL)
                conn.commit()
            finally:
                conn.close()
            self._loaded = True
            log.info("[SentinelDB] Tables ready: %s", self._db_path)
        except Exception as e:
            log.warning("[SentinelDB] Init failed: %s", e)

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        return conn

    # ══════════════════════════════════════════════════════════════
    # Flight Recorder Events (Buffered Write)
    # ══════════════════════════════════════════════════════════════

    def log_event(self, category: str, severity: int = 1,
                   source: str = "", metric_name: str = "",
                   metric_value: float = 0.0, message: str = "",
                   context: Optional[dict] = None) -> None:
        """Buffer a flight recorder event."""
        self._event_buffer.append((
            time.time(), category, severity, source, metric_name,
            metric_value, message,
            json.dumps(context or {}, ensure_ascii=False, default=str),
        ))
        if len(self._event_buffer) >= 50:
            self.flush_events()

    def flush_events(self) -> int:
        """Write buffered events to disk."""
        if not self._event_buffer:
            return 0
        batch = self._event_buffer[:]
        self._event_buffer.clear()
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.executemany(
                    """INSERT INTO sentinel_events
                       (timestamp, category, severity, source, metric_name,
                        metric_value, message, context_json)
                       VALUES (?,?,?,?,?,?,?,?)""",
                    batch,
                )
                conn.commit()
            finally:
                conn.close()
            return len(batch)
        except Exception as e:
            log.debug("[SentinelDB] flush failed: %s", e)
            return 0

    def get_recent_events(self, seconds: float = 60.0,
                            category: str = "",
                            severity_min: int = 0) -> List[dict]:
        """Get events from the last N seconds."""
        cutoff = time.time() - seconds
        try:
            conn = self._conn()
            try:
                sql = "SELECT * FROM sentinel_events WHERE timestamp >= ?"
                params: list = [cutoff]
                if category:
                    sql += " AND category=?"
                    params.append(category)
                if severity_min > 0:
                    sql += " AND severity >= ?"
                    params.append(severity_min)
                sql += " ORDER BY timestamp DESC LIMIT 500"
                return [dict(r) for r in conn.execute(sql, params).fetchall()]
            finally:
                conn.close()
        except Exception:
            return []

    def prune_events(self, keep_seconds: float = 120.0) -> int:
        """Remove events older than keep_seconds."""
        cutoff = time.time() - keep_seconds
        try:
            conn = self._conn()
            try:
                cur = conn.execute(
                    "DELETE FROM sentinel_events WHERE timestamp < ?", (cutoff,))
                conn.commit()
                return cur.rowcount
            finally:
                conn.close()
        except Exception:
            return 0

    # ══════════════════════════════════════════════════════════════
    # Anomalies
    # ══════════════════════════════════════════════════════════════

    def log_anomaly(self, anomaly_type: str, severity: int,
                      source: str = "", description: str = "",
                      evidence: Optional[dict] = None,
                      action_taken: str = "") -> int:
        """Log a detected anomaly. Returns anomaly ID."""
        try:
            conn = self._conn()
            try:
                cur = conn.execute(
                    """INSERT INTO sentinel_anomalies
                       (detected_at, anomaly_type, severity, source,
                        description, evidence_json, action_taken)
                       VALUES (?,?,?,?,?,?,?)""",
                    (time.time(), anomaly_type, severity, source,
                     description,
                     json.dumps(evidence or {}, ensure_ascii=False, default=str),
                     action_taken),
                )
                conn.commit()
                return cur.lastrowid or 0
            finally:
                conn.close()
        except Exception:
            return 0

    def resolve_anomaly(self, anomaly_id: int,
                          user_response: str = "resolved") -> None:
        try:
            conn = self._conn()
            try:
                conn.execute(
                    "UPDATE sentinel_anomalies SET resolved_at=?, user_response=? WHERE id=?",
                    (time.time(), user_response, anomaly_id),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    def mark_false_positive(self, anomaly_id: int) -> None:
        try:
            conn = self._conn()
            try:
                conn.execute(
                    "UPDATE sentinel_anomalies SET false_positive=1, user_response='false_positive' WHERE id=?",
                    (anomaly_id,),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    def get_active_anomalies(self) -> List[dict]:
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM sentinel_anomalies WHERE resolved_at=0 ORDER BY detected_at DESC LIMIT 50"
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def get_anomaly_history(self, limit: int = 100) -> List[dict]:
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM sentinel_anomalies ORDER BY detected_at DESC LIMIT ?",
                    (limit,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Crashes
    # ══════════════════════════════════════════════════════════════

    def log_crash(self, crash_type: str, component: str = "",
                    error_message: str = "", traceback_str: str = "",
                    blackbox: Optional[dict] = None,
                    system_state: Optional[dict] = None,
                    track_state: Optional[dict] = None,
                    session_id: str = "") -> int:
        try:
            conn = self._conn()
            try:
                cur = conn.execute(
                    """INSERT INTO sentinel_crashes
                       (crash_time, session_id, crash_type, component,
                        error_message, traceback, blackbox_json,
                        system_state, track_state)
                       VALUES (?,?,?,?,?,?,?,?,?)""",
                    (time.time(), session_id, crash_type, component,
                     error_message, traceback_str,
                     json.dumps(blackbox or {}, ensure_ascii=False, default=str),
                     json.dumps(system_state or {}, ensure_ascii=False, default=str),
                     json.dumps(track_state or {}, ensure_ascii=False, default=str)),
                )
                conn.commit()
                return cur.lastrowid or 0
            finally:
                conn.close()
        except Exception:
            return 0

    def get_crashes(self, limit: int = 50) -> List[dict]:
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM sentinel_crashes ORDER BY crash_time DESC LIMIT ?",
                    (limit,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Patterns
    # ══════════════════════════════════════════════════════════════

    def save_pattern(self, pattern_type: str, description: str,
                       conditions: dict, confidence: float = 0.5,
                       prevention: str = "") -> int:
        try:
            conn = self._conn()
            try:
                cur = conn.execute(
                    """INSERT INTO sentinel_patterns
                       (pattern_type, description, conditions_json,
                        confidence, last_seen, prevention)
                       VALUES (?,?,?,?,?,?)""",
                    (pattern_type, description,
                     json.dumps(conditions, ensure_ascii=False, default=str),
                     confidence, time.time(), prevention),
                )
                conn.commit()
                return cur.lastrowid or 0
            finally:
                conn.close()
        except Exception:
            return 0

    def increment_pattern(self, pattern_id: int) -> None:
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """UPDATE sentinel_patterns
                       SET occurrences=occurrences+1, last_seen=?
                       WHERE id=?""",
                    (time.time(), pattern_id),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    def get_patterns(self, pattern_type: str = "", limit: int = 100) -> List[dict]:
        try:
            conn = self._conn()
            try:
                if pattern_type:
                    rows = conn.execute(
                        "SELECT * FROM sentinel_patterns WHERE pattern_type=? ORDER BY occurrences DESC LIMIT ?",
                        (pattern_type, limit),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT * FROM sentinel_patterns ORDER BY occurrences DESC LIMIT ?",
                        (limit,),
                    ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Actions (Audit-Log + Undo)
    # ══════════════════════════════════════════════════════════════

    def log_action(self, action_type: str, target: str = "",
                     reason: str = "", severity: int = 3,
                     auto_action: bool = False) -> int:
        try:
            conn = self._conn()
            try:
                cur = conn.execute(
                    """INSERT INTO sentinel_actions
                       (action_time, action_type, target, reason,
                        severity, auto_action)
                       VALUES (?,?,?,?,?,?)""",
                    (time.time(), action_type, target, reason,
                     severity, 1 if auto_action else 0),
                )
                conn.commit()
                return cur.lastrowid or 0
            finally:
                conn.close()
        except Exception:
            return 0

    def undo_action(self, action_id: int) -> bool:
        try:
            conn = self._conn()
            try:
                conn.execute(
                    "UPDATE sentinel_actions SET undone=1, undone_at=? WHERE id=?",
                    (time.time(), action_id),
                )
                conn.commit()
                return True
            finally:
                conn.close()
        except Exception:
            return False

    def get_recent_actions(self, limit: int = 50) -> List[dict]:
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM sentinel_actions ORDER BY action_time DESC LIMIT ?",
                    (limit,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Stats + Maintenance
    # ══════════════════════════════════════════════════════════════

    def stats(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {}
        try:
            conn = self._conn()
            try:
                for table in ("sentinel_events", "sentinel_anomalies",
                               "sentinel_crashes", "sentinel_patterns",
                               "sentinel_actions"):
                    row = conn.execute(
                        f"SELECT COUNT(*) as cnt FROM {table}"
                    ).fetchone()
                    result[table] = int(row["cnt"]) if row else 0
            finally:
                conn.close()
        except Exception:
            pass
        return result
