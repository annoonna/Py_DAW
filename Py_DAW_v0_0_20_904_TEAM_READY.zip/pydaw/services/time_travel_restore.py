"""time_travel_restore.py — State Reconstruction & Restore.

v0.0.20.901 — Phase T3 COMPLETE der TIME_TRAVEL_ROADMAP.

Kernfunktion: "Geh 5 Minuten zurück"
1. Findet den letzten Snapshot VOR dem Ziel-Zeitpunkt
2. Replayed alle Events zwischen Snapshot und Ziel
3. Wendet den rekonstruierten State auf die DAW an

Vier Modi:
- FULL: Alles wiederherstellen (Mixer + Plugins + Transport)
- SELECTIVE: Nur bestimmte Tracks / nur Mixer / nur ein Plugin
- PREVIEW: State temporär laden ohne Commit (probehören)
- MIDI_RESTORE: Captured MIDI Notes als neue Clips einfügen

Sicherheit:
- Vor jedem Restore wird der aktuelle State als Snapshot gesichert
- "Restore rückgängig" ist IMMER möglich
- Kein Datenverlust — nur Parameter werden überschrieben

Usage:
    from pydaw.services.time_travel_restore import TimeTravelRestore
    restore = TimeTravelRestore(project_service, journal)

    # Geh 5 Minuten zurück
    restore.restore_minutes_ago(5)

    # Geh zu einem bestimmten Zeitpunkt
    restore.restore_to_timestamp(timestamp_ms)

    # Nur einen Track wiederherstellen
    restore.restore_track(track_id, timestamp_ms)

    # Preview (temporär)
    restore.preview_at(timestamp_ms)
    restore.cancel_preview()
    restore.confirm_preview()

    # Nur MIDI-Noten wiederherstellen (als neuen Clip)
    restore.restore_midi(track_id, timestamp_ms, duration_ms=30000)
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

log = logging.getLogger(__name__)


@dataclass
class RestoreResult:
    """Result of a restore operation."""
    success: bool = False
    message: str = ""
    timestamp_ms: int = 0
    tracks_restored: int = 0
    params_restored: int = 0
    snapshot_used: bool = False
    events_replayed: int = 0
    safety_snapshot_id: int = 0  # ID des Sicherheits-Snapshots
    clips_created: int = 0      # MIDI-Restore: wie viele Clips erstellt
    notes_restored: int = 0     # MIDI-Restore: wie viele Noten


@dataclass
class RestoreOptions:
    """Options for selective restore."""
    restore_mixer: bool = True       # Volume, Pan, Mute, Solo
    restore_plugins: bool = True     # Plugin parameters
    restore_transport: bool = False  # BPM (usually not wanted)
    restore_midi: bool = False       # MIDI notes as new clips
    track_ids: Optional[Set[str]] = None  # None = alle Tracks
    plugin_ids: Optional[Set[str]] = None  # None = alle Plugins
    transition_ms: int = 0           # 0 = instant, >0 = smooth morph
    midi_duration_ms: int = 30000    # Zeitfenster für MIDI-Capture (30s default)


class TimeTravelRestore:
    """Reconstructs and applies past DAW states.

    Not a singleton — created per usage context with explicit dependencies.
    """

    def __init__(self, project_service=None, journal=None):
        self._project_service = project_service
        self._journal = journal
        self._db = None
        self._preview_backup: Optional[dict] = None  # State before preview
        self._in_preview = False
        self._last_safety_snapshot_id: int = 0

        # Try to get DB
        try:
            from pydaw.services.time_travel_db import TimeTravelDB
            self._db = TimeTravelDB.get()
            self._db.ensure_loaded()
        except Exception:
            pass

    @property
    def in_preview(self) -> bool:
        return self._in_preview

    @property
    def last_safety_snapshot_id(self) -> int:
        """ID of the last safety snapshot (for undo-restore)."""
        return self._last_safety_snapshot_id

    # ══════════════════════════════════════════════════════════════
    # High-Level API
    # ══════════════════════════════════════════════════════════════

    def restore_minutes_ago(self, minutes: int = 5,
                              options: Optional[RestoreOptions] = None) -> RestoreResult:
        """Geh N Minuten zurück. Default: 5 Minuten."""
        if not self._journal or not self._journal.is_running:
            return RestoreResult(message="Journal nicht aktiv")

        current_ms = self._journal._timestamp_ms()
        target_ms = max(0, current_ms - (minutes * 60 * 1000))
        return self.restore_to_timestamp(target_ms, options)

    def restore_to_timestamp(self, timestamp_ms: int,
                               options: Optional[RestoreOptions] = None) -> RestoreResult:
        """Restore DAW state to a specific timestamp."""
        if not self._db or not self._journal:
            return RestoreResult(message="DB oder Journal nicht verfügbar")

        opts = options or RestoreOptions()
        session_id = self._journal.session_id
        result = RestoreResult(timestamp_ms=timestamp_ms)

        # 1. Safety: Save current state as snapshot BEFORE any changes
        safety_id = self._save_safety_snapshot(session_id)
        result.safety_snapshot_id = safety_id
        self._last_safety_snapshot_id = safety_id

        # 2. Reconstruct state at target timestamp
        state = self._reconstruct_state(session_id, timestamp_ms)
        if not state:
            result.message = f"Kein State für Zeitpunkt {timestamp_ms}ms gefunden"
            return result

        # 3. Apply state to DAW
        applied = self._apply_state(state, opts)
        result.success = True
        result.tracks_restored = applied.get("tracks", 0)
        result.params_restored = applied.get("params", 0)
        result.snapshot_used = applied.get("snapshot_used", False)
        result.events_replayed = applied.get("events_replayed", 0)

        # 4. MIDI Restore (optional)
        if opts.restore_midi:
            midi_result = self._restore_midi_events(
                session_id, timestamp_ms, opts
            )
            result.clips_created = midi_result.get("clips", 0)
            result.notes_restored = midi_result.get("notes", 0)

        minutes_back = (self._journal._timestamp_ms() - timestamp_ms) / 60000
        parts = [
            f"State von vor {minutes_back:.1f} Min wiederhergestellt",
            f"({result.tracks_restored} Tracks, {result.params_restored} Parameter)",
        ]
        if result.clips_created > 0:
            parts.append(
                f"+ {result.notes_restored} MIDI-Noten in "
                f"{result.clips_created} neuen Clips"
            )
        result.message = " ".join(parts)

        # Log the restore as an event
        self._db.log_event(
            session_id, self._journal._timestamp_ms(),
            "time_travel_restore",
            value_int=timestamp_ms,
            value_text=result.message,
        )
        self._db.flush_events()

        log.info("[Restore] %s", result.message)
        return result

    def restore_track(self, track_id: str, timestamp_ms: int) -> RestoreResult:
        """Restore only a single track to a past state."""
        opts = RestoreOptions(
            track_ids={track_id},
            restore_transport=False,
        )
        return self.restore_to_timestamp(timestamp_ms, opts)

    def restore_mixer_only(self, timestamp_ms: int) -> RestoreResult:
        """Restore only mixer settings (Volume/Pan/Mute/Solo)."""
        opts = RestoreOptions(
            restore_mixer=True,
            restore_plugins=False,
            restore_transport=False,
        )
        return self.restore_to_timestamp(timestamp_ms, opts)

    def restore_midi(self, track_id: str, timestamp_ms: int,
                       duration_ms: int = 30000) -> RestoreResult:
        """Restore MIDI notes from a time window as new clips."""
        opts = RestoreOptions(
            restore_mixer=False,
            restore_plugins=False,
            restore_transport=False,
            restore_midi=True,
            track_ids={track_id},
            midi_duration_ms=duration_ms,
        )
        return self.restore_to_timestamp(timestamp_ms, opts)

    def undo_restore(self) -> RestoreResult:
        """Undo the last restore by jumping back to the safety snapshot."""
        if not self._last_safety_snapshot_id or not self._db:
            return RestoreResult(message="Kein Sicherheits-Snapshot vorhanden")

        if not self._journal:
            return RestoreResult(message="Journal nicht aktiv")

        # Load the safety snapshot
        try:
            conn = self._db._conn()
            try:
                row = conn.execute(
                    "SELECT * FROM journal_snapshots WHERE id=?",
                    (self._last_safety_snapshot_id,),
                ).fetchone()
                if not row:
                    return RestoreResult(message="Sicherheits-Snapshot nicht gefunden")
                snapshot_json = row["snapshot_json"]
            finally:
                conn.close()
        except Exception as e:
            return RestoreResult(message=f"Fehler: {e}")

        # Apply the snapshot state directly
        try:
            state_data = json.loads(snapshot_json)
        except Exception:
            return RestoreResult(message="Snapshot JSON ungueltig")

        self._apply_snapshot_state(state_data)

        result = RestoreResult(
            success=True,
            message="Restore rueckgaengig — vorheriger Zustand wiederhergestellt",
        )
        log.info("[Restore] Undo-Restore: safety snapshot %d applied",
                 self._last_safety_snapshot_id)
        self._last_safety_snapshot_id = 0
        return result

    # ══════════════════════════════════════════════════════════════
    # Preview Mode
    # ══════════════════════════════════════════════════════════════

    def preview_at(self, timestamp_ms: int) -> RestoreResult:
        """Temporarily load state at timestamp (can be cancelled)."""
        if self._in_preview:
            self.cancel_preview()

        # Save current state as backup
        self._preview_backup = self._capture_current_state()
        self._in_preview = True

        # Apply the target state
        result = self.restore_to_timestamp(timestamp_ms)
        if not result.success:
            self._in_preview = False
            self._preview_backup = None
        return result

    def cancel_preview(self) -> bool:
        """Cancel preview — restore the state from before preview."""
        if not self._in_preview or not self._preview_backup:
            return False
        self._apply_captured_state(self._preview_backup)
        self._in_preview = False
        self._preview_backup = None
        log.info("[Restore] Preview cancelled — original state restored")
        return True

    def confirm_preview(self) -> bool:
        """Confirm preview — keep the restored state permanently."""
        if not self._in_preview:
            return False
        self._in_preview = False
        self._preview_backup = None
        log.info("[Restore] Preview confirmed — state kept")
        return True

    # ══════════════════════════════════════════════════════════════
    # Safety Guard
    # ══════════════════════════════════════════════════════════════

    def _save_safety_snapshot(self, session_id: str) -> int:
        """Save a safety snapshot before any restore operation.

        Returns the snapshot ID (for undo-restore).
        """
        if not self._db or not self._journal:
            return 0

        try:
            # Force journal to take an immediate snapshot
            self._journal._take_snapshot()

            # Also save explicitly with safety label
            proj = None
            if self._project_service:
                try:
                    proj = self._project_service.ctx.project
                except Exception:
                    pass

            if proj and hasattr(proj, 'to_dict'):
                state_json = json.dumps(proj.to_dict(), ensure_ascii=False)
                snap_id = self._db.save_snapshot(
                    session_id,
                    self._journal._timestamp_ms(),
                    state_json,
                    track_count=len(getattr(proj, 'tracks', []) or []),
                    clip_count=len(getattr(proj, 'clips', []) or []),
                    bpm=float(getattr(proj, 'bpm', 120.0)),
                    label="Safety-Snapshot vor Restore",
                )
                return snap_id
        except Exception as e:
            log.warning("[Restore] Safety snapshot failed: %s", e)
        return 0

    # ══════════════════════════════════════════════════════════════
    # State Reconstruction
    # ══════════════════════════════════════════════════════════════

    def _reconstruct_state(self, session_id: str,
                            timestamp_ms: int) -> Optional[Dict[str, Any]]:
        """Reconstruct full DAW state at a given timestamp.

        Algorithm:
        1. Find latest snapshot BEFORE timestamp
        2. Load snapshot as base state
        3. Replay all param_change events from snapshot to timestamp
        4. Result = exact state at timestamp
        """
        if not self._db:
            return None

        # 1. Find snapshot
        snapshot = self._db.get_snapshot_before(session_id, timestamp_ms)
        base_state = {}
        base_ms = 0

        if snapshot:
            base_ms = int(snapshot.get("timestamp_ms", 0))
            try:
                base_state = json.loads(snapshot.get("snapshot_json", "{}"))
            except Exception:
                base_state = {}

        # 2. Get events between snapshot and target
        events = self._db.get_events_in_range(
            session_id, base_ms, timestamp_ms,
        )

        # 3. Build param state by replaying events on top of snapshot
        track_params: Dict[str, Dict[str, Any]] = {}
        for track in base_state.get("tracks", []):
            tid = str(track.get("id", ""))
            if tid:
                track_params[tid] = {
                    "volume": float(track.get("volume", 0.8)),
                    "pan": float(track.get("pan", 0.0)),
                    "muted": bool(track.get("muted", False)),
                    "solo": bool(track.get("solo", False)),
                    "name": str(track.get("name", "")),
                    "kind": str(track.get("kind", "")),
                    "plugin_type": str(track.get("plugin_type", "") or ""),
                    "audio_fx_chain": track.get("audio_fx_chain", {}),
                    "note_fx_chain": track.get("note_fx_chain", {}),
                    "instrument_state": track.get("instrument_state", {}),
                }

        # Replay events
        transport_state = {
            "bpm": float(base_state.get("bpm", 120.0)),
        }
        plugin_params: Dict[str, Dict[str, float]] = {}

        for ev in events:
            et = ev.get("event_type", "")
            tid = ev.get("track_id", "")
            pid = ev.get("param_id", "")
            plg = ev.get("plugin_id", "")
            vf = ev.get("value_float")
            vi = ev.get("value_int")

            if et == "param_change" and tid:
                if tid not in track_params:
                    track_params[tid] = {}
                if pid in ("volume", "pan") and vf is not None:
                    track_params[tid][pid] = float(vf)
                elif pid in ("muted", "solo") and vi is not None:
                    track_params[tid][pid] = bool(vi)
                elif pid and vf is not None:
                    key = f"{plg}:{pid}" if plg else pid
                    track_params[tid][key] = float(vf)
                    pkey = f"{tid}:{plg}" if plg else tid
                    if pkey not in plugin_params:
                        plugin_params[pkey] = {}
                    plugin_params[pkey][pid] = float(vf)

            elif et == "transport_bpm" and vf is not None:
                transport_state["bpm"] = float(vf)

        return {
            "tracks": track_params,
            "transport": transport_state,
            "plugin_params": plugin_params,
            "snapshot_used": bool(snapshot),
            "events_replayed": len(events),
            "base_ms": base_ms,
            "base_state": base_state,
        }

    # ══════════════════════════════════════════════════════════════
    # Apply State to DAW
    # ══════════════════════════════════════════════════════════════

    def _apply_state(self, state: Dict[str, Any],
                       opts: RestoreOptions) -> Dict[str, int]:
        """Apply reconstructed state to the running DAW."""
        if not self._project_service:
            return {"tracks": 0, "params": 0}

        tracks_done = 0
        params_done = 0

        try:
            proj = self._project_service.ctx.project
            tracks = getattr(proj, 'tracks', []) or []
            track_params = state.get("tracks", {})

            for trk in tracks:
                tid = str(getattr(trk, 'id', ''))
                if not tid or tid not in track_params:
                    continue

                # Filter by track_ids if specified
                if opts.track_ids is not None and tid not in opts.track_ids:
                    continue

                tp = track_params[tid]

                if opts.restore_mixer:
                    if "volume" in tp:
                        trk.volume = float(tp["volume"])
                        params_done += 1
                    if "pan" in tp:
                        trk.pan = float(tp["pan"])
                        params_done += 1
                    if "muted" in tp:
                        trk.muted = bool(tp["muted"])
                        params_done += 1
                    if "solo" in tp:
                        trk.solo = bool(tp["solo"])
                        params_done += 1

                if opts.restore_plugins:
                    # Restore audio_fx_chain from snapshot if available
                    if "audio_fx_chain" in tp and isinstance(tp["audio_fx_chain"], dict):
                        chain = tp["audio_fx_chain"]
                        if chain.get("devices"):
                            trk.audio_fx_chain = chain
                            params_done += 1

                    if "note_fx_chain" in tp and isinstance(tp["note_fx_chain"], dict):
                        chain = tp["note_fx_chain"]
                        if chain.get("devices"):
                            trk.note_fx_chain = chain
                            params_done += 1

                    if "instrument_state" in tp and isinstance(tp["instrument_state"], dict):
                        if tp["instrument_state"]:
                            trk.instrument_state = tp["instrument_state"]
                            params_done += 1

                    # Count individual plugin parameters from events
                    for key, val in tp.items():
                        if key not in ("volume", "pan", "muted", "solo",
                                       "name", "kind", "plugin_type",
                                       "audio_fx_chain", "note_fx_chain",
                                       "instrument_state"):
                            if opts.plugin_ids is not None:
                                plugin_part = key.split(":")[0] if ":" in key else ""
                                if plugin_part and plugin_part not in opts.plugin_ids:
                                    continue
                            params_done += 1

                tracks_done += 1

            # Transport
            if opts.restore_transport:
                transport_state = state.get("transport", {})
                bpm = transport_state.get("bpm")
                if bpm is not None and bpm > 0:
                    proj.bpm = float(bpm)
                    params_done += 1

            # Emit update signal so UI refreshes
            self._emit_ui_refresh()

        except Exception as e:
            log.warning("[Restore] Apply state failed: %s", e)

        return {
            "tracks": tracks_done,
            "params": params_done,
            "snapshot_used": state.get("snapshot_used", False),
            "events_replayed": state.get("events_replayed", 0),
        }

    def _apply_snapshot_state(self, state_data: dict) -> None:
        """Apply a full snapshot state dict (from Project.to_dict()) to the DAW."""
        if not self._project_service:
            return
        try:
            proj = self._project_service.ctx.project
            tracks_by_id = {str(getattr(t, 'id', '')): t
                            for t in (getattr(proj, 'tracks', []) or [])}

            for track_data in state_data.get("tracks", []):
                tid = str(track_data.get("id", ""))
                trk = tracks_by_id.get(tid)
                if not trk:
                    continue
                trk.volume = float(track_data.get("volume", trk.volume))
                trk.pan = float(track_data.get("pan", trk.pan))
                trk.muted = bool(track_data.get("muted", trk.muted))
                trk.solo = bool(track_data.get("solo", trk.solo))
                # Restore FX chains
                afx = track_data.get("audio_fx_chain")
                if isinstance(afx, dict) and afx.get("devices"):
                    trk.audio_fx_chain = afx
                nfx = track_data.get("note_fx_chain")
                if isinstance(nfx, dict) and nfx.get("devices"):
                    trk.note_fx_chain = nfx
                ist = track_data.get("instrument_state")
                if isinstance(ist, dict) and ist:
                    trk.instrument_state = ist

            bpm = state_data.get("bpm")
            if bpm and float(bpm) > 0:
                proj.bpm = float(bpm)

            self._emit_ui_refresh()
        except Exception as e:
            log.warning("[Restore] Apply snapshot state failed: %s", e)

    # ══════════════════════════════════════════════════════════════
    # MIDI Restore — Insert captured MIDI as new clips
    # ══════════════════════════════════════════════════════════════

    def _restore_midi_events(self, session_id: str, timestamp_ms: int,
                               opts: RestoreOptions) -> Dict[str, int]:
        """Restore MIDI events from a time window as new clips in timeline.

        Collects midi_note_on/midi_note_off events from the journal,
        pairs them into MidiNote objects, and creates a new clip
        per track.
        """
        if not self._db or not self._project_service:
            return {"clips": 0, "notes": 0}

        duration_ms = opts.midi_duration_ms
        start_ms = max(0, timestamp_ms - duration_ms)
        end_ms = timestamp_ms

        # Get MIDI events in the window
        events = self._db.get_events_in_range(
            session_id, start_ms, end_ms,
        )

        # Filter for MIDI note events
        midi_events = [
            e for e in events
            if e.get("event_type", "") in ("midi_note_on", "midi_note_off")
        ]

        if not midi_events:
            return {"clips": 0, "notes": 0}

        # Group by track
        by_track: Dict[str, List[dict]] = {}
        for ev in midi_events:
            tid = ev.get("track_id", "")
            if not tid:
                continue
            if opts.track_ids is not None and tid not in opts.track_ids:
                continue
            by_track.setdefault(tid, []).append(ev)

        clips_created = 0
        notes_created = 0

        try:
            proj = self._project_service.ctx.project
            bpm = float(getattr(proj, 'bpm', 120.0))
            ms_per_beat = 60000.0 / bpm

            for track_id, track_events in by_track.items():
                # Pair note_on / note_off
                notes = self._pair_midi_events(track_events, ms_per_beat,
                                                start_ms)
                if not notes:
                    continue

                # Calculate clip bounds
                min_beat = min(n["start_beats"] for n in notes)
                max_end = max(n["start_beats"] + n["length_beats"]
                              for n in notes)
                clip_length = max(4.0, max_end - min_beat)

                # Create clip
                from pydaw.model.project import Clip
                clip_id = f"clip_{uuid.uuid4().hex[:8]}"
                clip = Clip(
                    id=clip_id,
                    kind="midi",
                    track_id=track_id,
                    start_beats=min_beat,
                    length_beats=clip_length,
                    label="Time-Travel Capture",
                )
                proj.clips.append(clip)

                # Create MidiNote objects
                from pydaw.model.midi import MidiNote
                clip_notes = []
                for n in notes:
                    mn = MidiNote(
                        pitch=n["pitch"],
                        start_beats=n["start_beats"] - min_beat,
                        length_beats=n["length_beats"],
                        velocity=n["velocity"],
                    )
                    clip_notes.append(mn)

                proj.midi_notes[clip_id] = clip_notes
                clips_created += 1
                notes_created += len(clip_notes)

            if clips_created > 0:
                self._emit_ui_refresh()

        except Exception as e:
            log.warning("[Restore] MIDI restore failed: %s", e)

        return {"clips": clips_created, "notes": notes_created}

    def _pair_midi_events(self, events: List[dict],
                            ms_per_beat: float,
                            base_ms: int) -> List[dict]:
        """Pair note_on/note_off events into note dicts.

        Returns list of {pitch, start_beats, length_beats, velocity}.
        """
        events.sort(key=lambda e: (e.get("timestamp_ms", 0),
                                    0 if e.get("event_type") == "midi_note_on" else 1))

        pending: Dict[Tuple[int, str], Tuple[int, int]] = {}
        notes: List[dict] = []

        for ev in events:
            et = ev.get("event_type", "")
            ts = int(ev.get("timestamp_ms", 0))
            pitch = int(ev.get("value_int", 60) or 60)
            velocity = int(ev.get("value_float", 100) or 100)
            channel = ev.get("param_id", "0")
            key = (pitch, channel)

            if et == "midi_note_on":
                pending[key] = (ts, velocity)
            elif et == "midi_note_off" and key in pending:
                on_ts, on_vel = pending.pop(key)
                length_ms = max(1, ts - on_ts)
                notes.append({
                    "pitch": pitch,
                    "start_beats": (on_ts - base_ms) / ms_per_beat,
                    "length_beats": max(0.125, length_ms / ms_per_beat),
                    "velocity": on_vel,
                })

        # Close remaining pending notes (1 beat default)
        for (pitch, _channel), (on_ts, on_vel) in pending.items():
            notes.append({
                "pitch": pitch,
                "start_beats": (on_ts - base_ms) / ms_per_beat,
                "length_beats": 1.0,
                "velocity": on_vel,
            })

        return notes

    # ══════════════════════════════════════════════════════════════
    # Capture / Restore Current State (for Preview)
    # ══════════════════════════════════════════════════════════════

    def _capture_current_state(self) -> Optional[dict]:
        """Capture the current DAW state for preview backup."""
        if not self._project_service:
            return None
        try:
            proj = self._project_service.ctx.project
            tracks = {}
            for trk in (getattr(proj, 'tracks', []) or []):
                tid = str(getattr(trk, 'id', ''))
                if tid:
                    tracks[tid] = {
                        "volume": float(trk.volume),
                        "pan": float(trk.pan),
                        "muted": bool(trk.muted),
                        "solo": bool(trk.solo),
                        "audio_fx_chain": getattr(trk, 'audio_fx_chain', {}),
                        "note_fx_chain": getattr(trk, 'note_fx_chain', {}),
                        "instrument_state": getattr(trk, 'instrument_state', {}),
                    }
            return {
                "tracks": tracks,
                "transport": {"bpm": float(getattr(proj, 'bpm', 120.0))},
            }
        except Exception:
            return None

    def _apply_captured_state(self, captured: dict) -> None:
        """Re-apply a previously captured state."""
        if not self._project_service or not captured:
            return
        try:
            proj = self._project_service.ctx.project
            track_data = captured.get("tracks", {})
            for trk in (getattr(proj, 'tracks', []) or []):
                tid = str(getattr(trk, 'id', ''))
                if tid in track_data:
                    td = track_data[tid]
                    trk.volume = float(td.get("volume", trk.volume))
                    trk.pan = float(td.get("pan", trk.pan))
                    trk.muted = bool(td.get("muted", trk.muted))
                    trk.solo = bool(td.get("solo", trk.solo))
                    afx = td.get("audio_fx_chain")
                    if isinstance(afx, dict):
                        trk.audio_fx_chain = afx
                    nfx = td.get("note_fx_chain")
                    if isinstance(nfx, dict):
                        trk.note_fx_chain = nfx
                    ist = td.get("instrument_state")
                    if isinstance(ist, dict):
                        trk.instrument_state = ist
            transport = captured.get("transport", {})
            bpm = transport.get("bpm")
            if bpm:
                proj.bpm = float(bpm)
            self._emit_ui_refresh()
        except Exception as e:
            log.warning("[Restore] Apply captured state failed: %s", e)

    # ══════════════════════════════════════════════════════════════
    # UI Refresh Helpers
    # ══════════════════════════════════════════════════════════════

    def _emit_ui_refresh(self) -> None:
        """Emit signals so all UI components refresh from model."""
        if not self._project_service:
            return
        try:
            self._project_service.project_updated.emit()
        except Exception:
            pass
        try:
            self._project_service._emit_changed()
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════
    # Query API
    # ══════════════════════════════════════════════════════════════

    def get_available_restore_points(self, session_id: str = "",
                                       limit: int = 30) -> List[dict]:
        """Get available restore points (snapshots + bookmarks)."""
        if not self._db:
            return []
        sid = session_id or (self._journal.session_id if self._journal else "")
        if not sid:
            return []

        points = []

        # Snapshots
        snapshots = self._db.get_snapshots(sid, limit=limit)
        for s in snapshots:
            points.append({
                "type": "snapshot",
                "timestamp_ms": s.get("timestamp_ms", 0),
                "wall_clock": s.get("wall_clock", 0),
                "label": s.get("label", ""),
                "bpm": s.get("bpm", 120),
                "track_count": s.get("track_count", 0),
                "snapshot_id": s.get("id", 0),
            })

        # User bookmarks
        try:
            conn = self._db._conn()
            try:
                rows = conn.execute(
                    """SELECT * FROM journal_tags
                       WHERE session_id=? AND source='user'
                       ORDER BY timestamp_ms DESC LIMIT ?""",
                    (sid, limit),
                ).fetchall()
                for r in rows:
                    points.append({
                        "type": "bookmark",
                        "timestamp_ms": r["timestamp_ms"],
                        "wall_clock": r["wall_clock"],
                        "label": r["tag_text"],
                    })
            finally:
                conn.close()
        except Exception:
            pass

        # Sort by timestamp descending
        points.sort(key=lambda p: p.get("timestamp_ms", 0), reverse=True)
        return points[:limit]

    def get_event_summary(self, session_id: str = "",
                            start_ms: int = 0,
                            end_ms: int = 0) -> Dict[str, int]:
        """Get a summary of event counts by type in a range."""
        if not self._db:
            return {}
        sid = session_id or (self._journal.session_id if self._journal else "")
        if not sid:
            return {}
        try:
            conn = self._db._conn()
            try:
                rows = conn.execute(
                    """SELECT event_type, COUNT(*) as cnt
                       FROM journal_events
                       WHERE session_id=? AND timestamp_ms >= ? AND timestamp_ms <= ?
                       GROUP BY event_type""",
                    (sid, start_ms, end_ms),
                ).fetchall()
                return {r["event_type"]: r["cnt"] for r in rows}
            finally:
                conn.close()
        except Exception:
            return {}

    def get_event_density(self, session_id: str = "",
                            bucket_ms: int = 10000,
                            max_buckets: int = 200) -> List[Dict[str, Any]]:
        """Get event density per time bucket (for heatmap/timeline).

        Returns list of {start_ms, end_ms, count, types: {type: count}}.
        """
        if not self._db:
            return []
        sid = session_id or (self._journal.session_id if self._journal else "")
        if not sid:
            return []

        try:
            conn = self._db._conn()
            try:
                rows = conn.execute(
                    """SELECT
                         (timestamp_ms / ?) * ? as bucket_start,
                         event_type,
                         COUNT(*) as cnt
                       FROM journal_events
                       WHERE session_id=?
                       GROUP BY bucket_start, event_type
                       ORDER BY bucket_start
                       LIMIT ?""",
                    (bucket_ms, bucket_ms, sid, max_buckets * 10),
                ).fetchall()

                buckets: Dict[int, Dict[str, Any]] = {}
                for r in rows:
                    bs = int(r["bucket_start"])
                    if bs not in buckets:
                        buckets[bs] = {
                            "start_ms": bs,
                            "end_ms": bs + bucket_ms,
                            "count": 0,
                            "types": {},
                        }
                    buckets[bs]["count"] += int(r["cnt"])
                    buckets[bs]["types"][r["event_type"]] = int(r["cnt"])

                result = sorted(buckets.values(),
                                key=lambda b: b["start_ms"])
                return result[:max_buckets]
            finally:
                conn.close()
        except Exception:
            return []
