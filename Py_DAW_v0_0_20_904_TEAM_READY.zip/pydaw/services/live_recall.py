"""live_recall.py — Live Recall & Parameter Morphing (Phases T12+T13).

v0.0.20.901 — Phases T12 + T13 der TIME_TRAVEL_ROADMAP.

T12: Live Recall (ohne Playback-Stop)
- "Recall to Timestamp" → smooth Parameter-Transition
- Transition-Zeit einstellbar (0.5s, 1s, 2s, 5s)
- Integration mit Clip Launcher moeglich
- MIDI-Controller Binding moeglich

T13: Parameter Morphing (A↔B)
- State A = Zeitpunkt 1, State B = Zeitpunkt 2
- Morph-Slider: 0% = State A, 100% = State B
- Morph-Kurven: Linear, Exponentiell, S-Curve, Random-Walk
- Automations-Export: Morph als Automation-Lane aufzeichnen
"""

from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import QObject, QTimer, pyqtSignal
    _QT = True
except ImportError:
    _QT = False


@dataclass
class RecallTarget:
    """Target state for a live recall operation."""
    track_params: Dict[str, Dict[str, float]] = field(default_factory=dict)
    transport_bpm: Optional[float] = None
    label: str = ""
    timestamp_ms: int = 0


@dataclass
class MorphState:
    """State for A/B morphing."""
    state_a: Dict[str, Dict[str, float]] = field(default_factory=dict)
    state_b: Dict[str, Dict[str, float]] = field(default_factory=dict)
    position: float = 0.0  # 0.0 = A, 1.0 = B
    curve: str = "linear"  # linear, exponential, scurve, random


def _apply_curve(t: float, curve: str) -> float:
    """Apply a morph curve to a 0-1 position value."""
    t = max(0.0, min(1.0, t))
    if curve == "exponential":
        return t * t
    elif curve == "scurve":
        return t * t * (3.0 - 2.0 * t)
    elif curve == "random":
        # Jittered linear
        import random
        jitter = random.gauss(0, 0.05)
        return max(0.0, min(1.0, t + jitter))
    return t  # linear


def _lerp(a: float, b: float, t: float) -> float:
    """Linear interpolation."""
    return a + (b - a) * t


if _QT:

    class LiveRecall(QObject):
        """Live parameter recall with smooth transitions.

        Morphs all parameters from current state to target state
        over a configurable transition time, without stopping playback.
        """

        recall_started = pyqtSignal(str)    # label
        recall_finished = pyqtSignal(str)   # label
        morph_position_changed = pyqtSignal(float)  # 0.0-1.0

        _instance: Optional["LiveRecall"] = None

        @classmethod
        def get(cls) -> "LiveRecall":
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

        def __init__(self, parent=None):
            super().__init__(parent)
            self._project_service = None
            self._journal = None

            # Recall transition
            self._recalling = False
            self._recall_start_state: Dict[str, Dict[str, float]] = {}
            self._recall_target: Optional[RecallTarget] = None
            self._recall_start_time: float = 0.0
            self._recall_duration_ms: float = 1000.0
            self._recall_timer = QTimer(self)
            self._recall_timer.setInterval(16)  # ~60 fps
            self._recall_timer.timeout.connect(self._recall_tick)

            # A/B Morphing
            self._morph = MorphState()
            self._morph_active = False

        @property
        def is_recalling(self) -> bool:
            return self._recalling

        @property
        def morph_active(self) -> bool:
            return self._morph_active

        def set_services(self, project_service=None, journal=None) -> None:
            self._project_service = project_service
            self._journal = journal

        # ══════════════════════════════════════════════════════════
        # T12: Live Recall
        # ══════════════════════════════════════════════════════════

        def recall_to_timestamp(self, timestamp_ms: int,
                                  transition_ms: float = 1000.0,
                                  label: str = "") -> bool:
            """Smoothly recall parameters from a past timestamp.

            Does NOT stop playback. Morphs all parameters over transition_ms.
            """
            if not self._journal or not self._project_service:
                return False

            # Get the target state from journal
            try:
                from pydaw.services.time_travel_restore import TimeTravelRestore
                restore = TimeTravelRestore(self._project_service, self._journal)
                state = restore._reconstruct_state(
                    self._journal.session_id, timestamp_ms
                )
                if not state:
                    return False
            except Exception as e:
                log.warning("[LiveRecall] State reconstruction failed: %s", e)
                return False

            target = RecallTarget(
                track_params=state.get("tracks", {}),
                transport_bpm=state.get("transport", {}).get("bpm"),
                label=label or f"Recall @ {timestamp_ms}ms",
                timestamp_ms=timestamp_ms,
            )
            return self._start_recall(target, transition_ms)

        def recall_to_bookmark(self, bookmark_label: str,
                                 transition_ms: float = 1000.0) -> bool:
            """Recall to a named bookmark."""
            if not self._journal:
                return False
            # Search for the bookmark
            try:
                from pydaw.services.time_travel_db import TimeTravelDB
                db = TimeTravelDB.get()
                conn = db._conn()
                try:
                    row = conn.execute(
                        """SELECT timestamp_ms FROM journal_tags
                           WHERE session_id=? AND source='user'
                           AND tag_text LIKE ?
                           ORDER BY timestamp_ms DESC LIMIT 1""",
                        (self._journal.session_id, f"%{bookmark_label}%"),
                    ).fetchone()
                    if row:
                        return self.recall_to_timestamp(
                            row["timestamp_ms"], transition_ms,
                            label=bookmark_label,
                        )
                finally:
                    conn.close()
            except Exception:
                pass
            return False

        def cancel_recall(self) -> None:
            """Stop an ongoing recall transition."""
            self._recall_timer.stop()
            self._recalling = False
            self._recall_target = None

        def _start_recall(self, target: RecallTarget,
                            transition_ms: float) -> bool:
            """Start the recall transition."""
            if self._recalling:
                self.cancel_recall()

            # Capture current state as start
            self._recall_start_state = self._capture_param_state()
            self._recall_target = target
            self._recall_duration_ms = max(16, transition_ms)
            self._recall_start_time = time.time()
            self._recalling = True
            self._recall_timer.start()
            self.recall_started.emit(target.label)
            log.info("[LiveRecall] Started: %s (%dms transition)",
                     target.label, int(transition_ms))
            return True

        def _recall_tick(self) -> None:
            """Timer tick — interpolate parameters toward target."""
            if not self._recalling or not self._recall_target:
                self._recall_timer.stop()
                return

            elapsed = (time.time() - self._recall_start_time) * 1000
            t = min(1.0, elapsed / max(1, self._recall_duration_ms))

            # Apply smooth curve
            t_curved = _apply_curve(t, "scurve")

            # Interpolate all parameters
            self._apply_interpolated_state(
                self._recall_start_state,
                self._recall_target.track_params,
                t_curved,
            )

            if t >= 1.0:
                self._recall_timer.stop()
                self._recalling = False
                label = self._recall_target.label
                self._recall_target = None
                self.recall_finished.emit(label)
                log.info("[LiveRecall] Finished: %s", label)

        # ══════════════════════════════════════════════════════════
        # T13: Parameter Morphing (A↔B)
        # ══════════════════════════════════════════════════════════

        def set_morph_a(self, timestamp_ms: int) -> bool:
            """Set State A for morphing from a timestamp."""
            state = self._get_state_at(timestamp_ms)
            if not state:
                return False
            self._morph.state_a = state
            log.info("[LiveRecall] Morph State A set @ %dms", timestamp_ms)
            return True

        def set_morph_b(self, timestamp_ms: int) -> bool:
            """Set State B for morphing from a timestamp."""
            state = self._get_state_at(timestamp_ms)
            if not state:
                return False
            self._morph.state_b = state
            log.info("[LiveRecall] Morph State B set @ %dms", timestamp_ms)
            return True

        def set_morph_a_current(self) -> bool:
            """Set State A from current DAW state."""
            self._morph.state_a = self._capture_param_state()
            return bool(self._morph.state_a)

        def set_morph_b_current(self) -> bool:
            """Set State B from current DAW state."""
            self._morph.state_b = self._capture_param_state()
            return bool(self._morph.state_b)

        def set_morph_position(self, position: float,
                                 curve: str = "linear") -> None:
            """Set morph position (0.0 = A, 1.0 = B).

            Immediately applies the interpolated state.
            """
            self._morph.position = max(0.0, min(1.0, position))
            self._morph.curve = curve
            self._morph_active = True

            t = _apply_curve(self._morph.position, curve)
            self._apply_interpolated_state(
                self._morph.state_a,
                self._morph.state_b,
                t,
            )
            self.morph_position_changed.emit(self._morph.position)

        def morph_sweep(self, duration_ms: float = 4000,
                          curve: str = "linear") -> None:
            """Automated morph from A to B over duration_ms.

            Can be used for "Morph von A nach B ueber 8 Takte".
            """
            if not self._morph.state_a or not self._morph.state_b:
                return
            # Use recall mechanism with morph states
            target = RecallTarget(
                track_params=self._morph.state_b,
                label="Morph A→B",
            )
            self._recall_start_state = self._morph.state_a
            self._recall_target = target
            self._recall_duration_ms = max(16, duration_ms)
            self._recall_start_time = time.time()
            self._recalling = True
            self._morph.curve = curve
            self._recall_timer.start()

        def get_morph_position(self) -> float:
            return self._morph.position

        # ══════════════════════════════════════════════════════════
        # Internal
        # ══════════════════════════════════════════════════════════

        def _capture_param_state(self) -> Dict[str, Dict[str, float]]:
            """Capture current mixer params from project."""
            if not self._project_service:
                return {}
            try:
                proj = self._project_service.ctx.project
                result: Dict[str, Dict[str, float]] = {}
                for trk in (getattr(proj, 'tracks', []) or []):
                    tid = str(getattr(trk, 'id', ''))
                    if tid:
                        result[tid] = {
                            "volume": float(trk.volume),
                            "pan": float(trk.pan),
                        }
                return result
            except Exception:
                return {}

        def _get_state_at(self, timestamp_ms: int) -> Dict[str, Dict[str, float]]:
            """Get parameter state at a timestamp from the journal."""
            if not self._journal or not self._project_service:
                return {}
            try:
                from pydaw.services.time_travel_restore import TimeTravelRestore
                restore = TimeTravelRestore(self._project_service, self._journal)
                state = restore._reconstruct_state(
                    self._journal.session_id, timestamp_ms
                )
                if not state:
                    return {}
                # Extract just the numeric params
                result: Dict[str, Dict[str, float]] = {}
                for tid, tp in state.get("tracks", {}).items():
                    params: Dict[str, float] = {}
                    for key, val in tp.items():
                        if isinstance(val, (int, float)):
                            params[key] = float(val)
                    if params:
                        result[tid] = params
                return result
            except Exception:
                return {}

        def _apply_interpolated_state(self,
                                        state_from: Dict[str, Dict[str, float]],
                                        state_to: Dict[str, Dict[str, float]],
                                        t: float) -> None:
            """Apply interpolated state between two param states."""
            if not self._project_service:
                return
            try:
                proj = self._project_service.ctx.project
                for trk in (getattr(proj, 'tracks', []) or []):
                    tid = str(getattr(trk, 'id', ''))
                    if not tid:
                        continue
                    from_p = state_from.get(tid, {})
                    to_p = state_to.get(tid, {})
                    if not from_p and not to_p:
                        continue

                    # Volume
                    if "volume" in from_p or "volume" in to_p:
                        va = from_p.get("volume", float(trk.volume))
                        vb = to_p.get("volume", float(trk.volume))
                        trk.volume = _lerp(va, vb, t)

                    # Pan
                    if "pan" in from_p or "pan" in to_p:
                        pa = from_p.get("pan", float(trk.pan))
                        pb = to_p.get("pan", float(trk.pan))
                        trk.pan = _lerp(pa, pb, t)

                # Emit UI update
                try:
                    self._project_service.project_updated.emit()
                except Exception:
                    pass
            except Exception as e:
                log.warning("[LiveRecall] Apply interpolated failed: %s", e)

else:
    class LiveRecall:
        _instance = None

        @classmethod
        def get(cls):
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

        def __init__(self):
            pass

        def set_services(self, **kw):
            pass
