"""time_travel_journal.py — Continuous Journaling Service.

v0.0.20.898 — Phase T2 der TIME_TRAVEL_ROADMAP.

Hookt sich in bestehende DAW-Signals ein und loggt ALLE Events:
- MIDI: Note On/Off, CC, Pitch Bend
- Parameter: Volume, Pan, Mute, Solo, Plugin-Params
- Plugin: Load, Remove, Preset-Wechsel
- Transport: Play, Stop, Record, BPM-Change

Alle 30s wird ein Voll-Snapshot gespeichert (Crash Recovery).
Default Lookback: 5 Minuten.

Usage:
    from pydaw.services.time_travel_journal import TimeTravelJournal
    journal = TimeTravelJournal.get()
    journal.start(project_service, midi_manager, transport_service)
    # ... DAW läuft, alles wird automatisch geloggt ...
    journal.stop()

    # Manueller Bookmark
    journal.bookmark("Cooler Bass-Sound")

    # Letzte 5 Minuten holen
    events = journal.get_recent_events(minutes=5)
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

try:
    from PyQt6.QtCore import QObject, QTimer, pyqtSignal
    _QT = True
except ImportError:
    _QT = False

log = logging.getLogger(__name__)


@dataclass
class JournalConfig:
    """Konfiguration für den Journal Writer."""
    enabled: bool = True
    lookback_minutes: int = 5
    snapshot_interval_sec: int = 30
    flush_interval_ms: int = 500
    max_events_per_session: int = 100_000
    log_midi: bool = True
    log_params: bool = True
    log_plugins: bool = True
    log_transport: bool = True


if _QT:
    class TimeTravelJournal(QObject):
        """Continuous journaling service — logs everything to SQLite.

        Singleton. Hooks into DAW signals, writes to TimeTravelDB.
        """

        # Signals for UI
        bookmark_added = pyqtSignal(str)  # label
        snapshot_saved = pyqtSignal(int)   # snapshot_id
        event_count_changed = pyqtSignal(int)  # total events this session

        _instance: Optional["TimeTravelJournal"] = None

        @classmethod
        def get(cls) -> "TimeTravelJournal":
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

        def __init__(self, parent=None):
            super().__init__(parent)
            self._config = JournalConfig()
            self._session_id: str = ""
            self._session_start_time: float = 0.0
            self._running = False
            self._event_count = 0

            # Flush timer
            self._flush_timer = QTimer(self)
            self._flush_timer.setInterval(self._config.flush_interval_ms)
            self._flush_timer.timeout.connect(self._flush)

            # Snapshot timer
            self._snapshot_timer = QTimer(self)
            self._snapshot_timer.setInterval(self._config.snapshot_interval_sec * 1000)
            self._snapshot_timer.timeout.connect(self._take_snapshot)

            # References to services (set in start())
            self._project_service = None
            self._midi_manager = None
            self._transport_service = None
            self._db = None

        @property
        def is_running(self) -> bool:
            return self._running

        @property
        def session_id(self) -> str:
            return self._session_id

        @property
        def event_count(self) -> int:
            return self._event_count

        def _timestamp_ms(self) -> int:
            """Milliseconds since session start."""
            if self._session_start_time <= 0:
                return 0
            return int((time.time() - self._session_start_time) * 1000)

        # ══════════════════════════════════════════════════════════
        # Start / Stop
        # ══════════════════════════════════════════════════════════

        def start(self, project_service=None, midi_manager=None,
                   transport_service=None) -> None:
            """Start journaling. Call once after DAW is initialized."""
            if self._running:
                return
            if not self._config.enabled:
                log.info("[Journal] Disabled by config")
                return

            # Init DB
            try:
                from pydaw.services.time_travel_db import TimeTravelDB
                self._db = TimeTravelDB.get()
                self._db.ensure_loaded()
            except Exception as e:
                log.warning("[Journal] DB init failed: %s", e)
                return

            self._project_service = project_service
            self._midi_manager = midi_manager
            self._transport_service = transport_service

            # New session
            self._session_id = self._db.new_session_id()
            self._session_start_time = time.time()

            # Register session
            proj_path = ""
            proj_name = ""
            bpm = 120.0
            try:
                if project_service and hasattr(project_service, 'ctx'):
                    proj = project_service.ctx.project
                    proj_path = str(getattr(project_service.ctx, 'path', '') or '')
                    proj_name = str(getattr(proj, 'name', ''))
                    bpm = float(getattr(proj, 'bpm', 120.0))
            except Exception:
                pass

            self._db.start_session(
                self._session_id, proj_path, proj_name, bpm,
            )

            # Hook into signals
            self._connect_signals()

            # Start timers
            self._flush_timer.start()
            self._snapshot_timer.start()

            # Initial snapshot
            QTimer.singleShot(1000, self._take_snapshot)

            self._running = True
            self._event_count = 0
            log.info("[Journal] Started session %s (lookback: %d min)",
                     self._session_id, self._config.lookback_minutes)

        def stop(self) -> None:
            """Stop journaling and flush remaining events."""
            if not self._running:
                return
            self._running = False
            self._flush_timer.stop()
            self._snapshot_timer.stop()
            self._disconnect_signals()

            # Final snapshot + flush
            self._take_snapshot()
            self._flush()

            if self._db:
                self._db.end_session(self._session_id)

            log.info("[Journal] Stopped session %s (%d events)",
                     self._session_id, self._event_count)

        # ══════════════════════════════════════════════════════════
        # Signal Connections
        # ══════════════════════════════════════════════════════════

        def _connect_signals(self) -> None:
            """Hook into existing DAW signals (safe, no crashes)."""
            # MIDI
            if self._config.log_midi and self._midi_manager:
                try:
                    self._midi_manager.message_received.connect(self._on_midi)
                except Exception:
                    pass

            # Project changes (Volume, Pan, Mute, etc.)
            if self._config.log_params and self._project_service:
                try:
                    self._project_service.project_updated.connect(self._on_project_updated)
                except Exception:
                    pass

            # Transport
            if self._config.log_transport and self._transport_service:
                try:
                    ts = self._transport_service
                    if hasattr(ts, 'playing_changed'):
                        ts.playing_changed.connect(self._on_transport_play)
                    if hasattr(ts, 'bpm_changed'):
                        ts.bpm_changed.connect(self._on_bpm_changed)
                    if hasattr(ts, 'recording_changed'):
                        ts.recording_changed.connect(self._on_recording_changed)
                except Exception:
                    pass

        def _disconnect_signals(self) -> None:
            """Safely disconnect all signals."""
            for target, slot in [
                (self._midi_manager, self._on_midi),
                (self._project_service, self._on_project_updated),
            ]:
                if target is not None:
                    try:
                        for sig_name in ('message_received', 'project_updated',
                                          'playing_changed', 'bpm_changed',
                                          'recording_changed'):
                            sig = getattr(target, sig_name, None)
                            if sig is not None:
                                try:
                                    sig.disconnect(slot)
                                except (TypeError, RuntimeError):
                                    pass
                    except Exception:
                        pass

        # ══════════════════════════════════════════════════════════
        # Event Handlers
        # ══════════════════════════════════════════════════════════

        def _on_midi(self, msg_text: str) -> None:
            """Handle MIDI message signal."""
            if not self._running or not self._db:
                return
            try:
                # Parse MIDI message text
                # Format varies: "Note On C3 vel=100 ch=0" or "CC 74=64 ch=0"
                parts = str(msg_text).split()
                if len(parts) < 2:
                    return

                event_type = "midi_unknown"
                value_int = None
                value_float = None
                value_text = msg_text

                msg_lower = msg_text.lower()
                if "note on" in msg_lower or "note_on" in msg_lower:
                    event_type = "midi_note_on"
                    # Try to extract note number
                    for p in parts:
                        if p.startswith("vel="):
                            try:
                                value_int = int(p.split("=")[1])
                            except Exception:
                                pass
                elif "note off" in msg_lower or "note_off" in msg_lower:
                    event_type = "midi_note_off"
                elif "cc" in msg_lower or "control" in msg_lower:
                    event_type = "midi_cc"
                    for p in parts:
                        if "=" in p:
                            try:
                                value_int = int(p.split("=")[1])
                            except Exception:
                                pass

                self._db.log_event(
                    self._session_id, self._timestamp_ms(),
                    event_type, value_text=value_text,
                    value_int=value_int,
                )
                self._event_count += 1
            except Exception:
                pass

        def _on_project_updated(self) -> None:
            """Handle project update signal — log changed parameters."""
            if not self._running or not self._db or not self._project_service:
                return
            try:
                proj = self._project_service.ctx.project
                tracks = getattr(proj, 'tracks', []) or []
                for trk in tracks:
                    tid = str(getattr(trk, 'id', ''))
                    if not tid:
                        continue
                    # Log mixer params
                    for param, attr in [("volume", "volume"), ("pan", "pan")]:
                        val = float(getattr(trk, attr, 0))
                        self._db.log_event(
                            self._session_id, self._timestamp_ms(),
                            "param_change",
                            track_id=tid,
                            param_id=param,
                            value_float=val,
                        )
                    # Log mute/solo
                    for param, attr in [("muted", "muted"), ("solo", "solo")]:
                        val = bool(getattr(trk, attr, False))
                        self._db.log_event(
                            self._session_id, self._timestamp_ms(),
                            "param_change",
                            track_id=tid,
                            param_id=param,
                            value_int=1 if val else 0,
                        )
                self._event_count += len(tracks) * 4
            except Exception:
                pass

        def _on_transport_play(self, playing: bool) -> None:
            if not self._running or not self._db:
                return
            self._db.log_event(
                self._session_id, self._timestamp_ms(),
                "transport_play" if playing else "transport_stop",
            )
            self._event_count += 1

        def _on_bpm_changed(self, bpm: float) -> None:
            if not self._running or not self._db:
                return
            self._db.log_event(
                self._session_id, self._timestamp_ms(),
                "transport_bpm", value_float=float(bpm),
            )
            self._event_count += 1

        def _on_recording_changed(self, recording: bool) -> None:
            if not self._running or not self._db:
                return
            self._db.log_event(
                self._session_id, self._timestamp_ms(),
                "transport_record_start" if recording else "transport_record_stop",
            )
            self._event_count += 1

        # ══════════════════════════════════════════════════════════
        # Manual Logging (from UI or other services)
        # ══════════════════════════════════════════════════════════

        def log_plugin_load(self, track_id: str, plugin_id: str,
                              plugin_name: str = "", preset_name: str = "") -> None:
            """Log a plugin load event."""
            if not self._running or not self._db:
                return
            self._db.log_event(
                self._session_id, self._timestamp_ms(),
                "plugin_load", track_id=track_id,
                plugin_id=plugin_id,
                value_text=f"{plugin_name}|{preset_name}",
            )
            self._event_count += 1

        def log_plugin_remove(self, track_id: str, plugin_id: str) -> None:
            """Log a plugin remove event."""
            if not self._running or not self._db:
                return
            self._db.log_event(
                self._session_id, self._timestamp_ms(),
                "plugin_remove", track_id=track_id, plugin_id=plugin_id,
            )
            self._event_count += 1

        def log_preset_change(self, track_id: str, plugin_id: str,
                                preset_name: str) -> None:
            """Log a preset change."""
            if not self._running or not self._db:
                return
            self._db.log_event(
                self._session_id, self._timestamp_ms(),
                "preset_change", track_id=track_id,
                plugin_id=plugin_id, value_text=preset_name,
            )
            self._event_count += 1

        def log_param_change(self, track_id: str, plugin_id: str,
                               param_id: str, value: float) -> None:
            """Log a parameter change (from any source)."""
            if not self._running or not self._db:
                return
            self._db.log_event(
                self._session_id, self._timestamp_ms(),
                "param_change", track_id=track_id,
                plugin_id=plugin_id, param_id=param_id,
                value_float=float(value),
            )
            self._event_count += 1

        # ══════════════════════════════════════════════════════════
        # Bookmarks
        # ══════════════════════════════════════════════════════════

        def bookmark(self, label: str = "") -> None:
            """Set a user bookmark at the current moment."""
            if not self._running or not self._db:
                return
            ts = self._timestamp_ms()
            self._db.add_user_bookmark(self._session_id, ts, label)
            self._take_snapshot()  # Extra snapshot at bookmark
            try:
                self.bookmark_added.emit(label or f"Bookmark @ {ts // 1000}s")
            except Exception:
                pass
            log.info("[Journal] Bookmark: %s @ %ds", label, ts // 1000)

        # ══════════════════════════════════════════════════════════
        # Snapshots
        # ══════════════════════════════════════════════════════════

        def _take_snapshot(self) -> None:
            """Save a full project state snapshot."""
            if not self._running or not self._db or not self._project_service:
                return
            try:
                proj = self._project_service.ctx.project
                state_json = json.dumps(proj.to_dict(), ensure_ascii=False)
                tracks = getattr(proj, 'tracks', []) or []
                clips = getattr(proj, 'clips', []) or []
                bpm = float(getattr(proj, 'bpm', 120.0))

                # Auto-label from recent activity
                label = self._generate_snapshot_label()

                sid = self._db.save_snapshot(
                    self._session_id, self._timestamp_ms(),
                    state_json,
                    track_count=len(tracks),
                    clip_count=len(clips),
                    bpm=bpm,
                    label=label,
                )
                if sid:
                    try:
                        self.snapshot_saved.emit(sid)
                    except Exception:
                        pass
            except Exception:
                pass

        def _generate_snapshot_label(self) -> str:
            """Generate a human-readable label from recent events."""
            if not self._db:
                return ""
            try:
                ts = self._timestamp_ms()
                events = self._db.get_events_in_range(
                    self._session_id,
                    max(0, ts - 30_000),  # Last 30 seconds
                    ts,
                )
                if not events:
                    return "Idle"

                types = set()
                tracks = set()
                for ev in events:
                    types.add(ev.get("event_type", ""))
                    t = ev.get("track_id", "")
                    if t:
                        tracks.add(t)

                parts = []
                if any("midi" in t for t in types):
                    parts.append("MIDI")
                if "param_change" in types:
                    parts.append("Parameter")
                if "plugin_load" in types:
                    parts.append("Plugin")
                if any("transport" in t for t in types):
                    parts.append("Transport")

                label = " + ".join(parts) if parts else "Aktivität"
                if tracks:
                    label += f" ({len(tracks)} Track{'s' if len(tracks) > 1 else ''})"
                return label
            except Exception:
                return ""

        # ══════════════════════════════════════════════════════════
        # Read API (convenience wrappers)
        # ══════════════════════════════════════════════════════════

        def get_recent_events(self, minutes: int = 5) -> List[dict]:
            """Get events from the last N minutes. Default: 5 Min."""
            if not self._db:
                return []
            return self._db.get_events_last_n_minutes(
                self._session_id, minutes, self._timestamp_ms(),
            )

        def get_param_state_at(self, timestamp_ms: int) -> Dict[str, Dict[str, float]]:
            """Reconstruct parameter state at a given time."""
            if not self._db:
                return {}
            return self._db.get_param_state_at(self._session_id, timestamp_ms)

        def get_state_5_min_ago(self) -> Dict[str, Dict[str, float]]:
            """Shortcut: Get parameter state from 5 minutes ago."""
            ts = max(0, self._timestamp_ms() - (5 * 60 * 1000))
            return self.get_param_state_at(ts)

        # ══════════════════════════════════════════════════════════
        # Flush
        # ══════════════════════════════════════════════════════════

        def _flush(self) -> None:
            """Periodic flush of buffered events to disk."""
            if self._db:
                written = self._db.flush_events()
                if written > 0:
                    try:
                        self.event_count_changed.emit(self._event_count)
                    except Exception:
                        pass

else:
    class TimeTravelJournal:  # type: ignore
        """Fallback when PyQt6 is not available."""
        _instance = None
        @classmethod
        def get(cls):
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance
        def start(self, *a, **kw): pass
        def stop(self): pass
        def bookmark(self, label=""): pass
        def log_param_change(self, *a, **kw): pass
        def log_plugin_load(self, *a, **kw): pass
        def log_plugin_remove(self, *a, **kw): pass
        def log_preset_change(self, *a, **kw): pass
        def get_recent_events(self, minutes=5): return []
        def get_param_state_at(self, ts): return {}
        def get_state_5_min_ago(self): return {}
        @property
        def is_running(self): return False
        @property
        def session_id(self): return ""
        @property
        def event_count(self): return 0
