"""fileio_state_db.py — SQLite-backed File I/O history + Plugin Sandbox crash log.

v0.0.20.892 — Phases 35+36 der SQLite Migration Roadmap.

Phase 35 — FileIO State:
- Recent project files (path, last_opened, open_count)
- Recent media imports (audio files, MIDI files, samples)
- Export history (format, path, timestamp)

Phase 36 — PluginSandbox State:
- Plugin crash log (plugin_id, crash_count, last_crash, error_msg)
- Sandbox process history for diagnostics

Tables:
- recent_projects: project file access history
- recent_media: imported media file history
- export_history: export operations log
- plugin_crash_log: plugin crash events

Usage:
    from pydaw.services.fileio_state_db import FileIOStateDB
    db = FileIOStateDB.get()
    db.ensure_loaded()

    # Recent projects
    db.add_recent_project("/path/to/project.pydaw", "My Song")
    recents = db.get_recent_projects(limit=10)

    # Media imports
    db.add_recent_media("/path/to/sample.wav", "audio")
    db.get_recent_media(file_type="audio", limit=20)

    # Export history
    db.add_export_entry("/path/to/export.wav", "wav", 44100, 24)

    # Plugin crashes
    db.log_plugin_crash("surge-xt", "vst3", "SIGSEGV in process()")
    crashes = db.get_crash_log("surge-xt")
    db.get_problematic_plugins(min_crashes=3)
"""

import sqlite3
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional, Any

log = logging.getLogger(__name__)


_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS recent_projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    path        TEXT NOT NULL UNIQUE,
    name        TEXT NOT NULL DEFAULT '',
    open_count  INTEGER NOT NULL DEFAULT 1,
    last_opened REAL NOT NULL DEFAULT 0.0,
    created_at  REAL NOT NULL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS recent_media (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    path        TEXT NOT NULL,
    file_type   TEXT NOT NULL DEFAULT 'audio',
    name        TEXT NOT NULL DEFAULT '',
    use_count   INTEGER NOT NULL DEFAULT 1,
    last_used   REAL NOT NULL DEFAULT 0.0,
    UNIQUE(path, file_type)
);

CREATE TABLE IF NOT EXISTS export_history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    output_path TEXT NOT NULL,
    format      TEXT NOT NULL DEFAULT 'wav',
    sample_rate INTEGER NOT NULL DEFAULT 44100,
    bit_depth   INTEGER NOT NULL DEFAULT 24,
    project_name TEXT NOT NULL DEFAULT '',
    duration_sec REAL NOT NULL DEFAULT 0.0,
    exported_at REAL NOT NULL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS plugin_crash_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    plugin_id   TEXT NOT NULL,
    plugin_type TEXT NOT NULL DEFAULT '',
    plugin_name TEXT NOT NULL DEFAULT '',
    error_msg   TEXT NOT NULL DEFAULT '',
    track_id    TEXT NOT NULL DEFAULT '',
    crashed_at  REAL NOT NULL DEFAULT 0.0,
    auto_restarted INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_rp_last ON recent_projects(last_opened DESC);
CREATE INDEX IF NOT EXISTS idx_rm_last ON recent_media(last_used DESC);
CREATE INDEX IF NOT EXISTS idx_eh_time ON export_history(exported_at DESC);
CREATE INDEX IF NOT EXISTS idx_pcl_plugin ON plugin_crash_log(plugin_id);
CREATE INDEX IF NOT EXISTS idx_pcl_time ON plugin_crash_log(crashed_at DESC);
"""


class FileIOStateDB:
    """SQLite-backed file I/O history and plugin crash log.

    Singleton. All writes go directly to disk (WAL mode).
    """

    _instance: Optional["FileIOStateDB"] = None

    @classmethod
    def get(cls) -> "FileIOStateDB":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        self._loaded = False

    def ensure_loaded(self) -> None:
        """Create tables if needed. Idempotent."""
        if self._loaded:
            return
        try:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.executescript(_SCHEMA_SQL)
                conn.commit()
            finally:
                conn.close()
            self._loaded = True
            log.info("[FileIOStateDB] Tables ready")
        except Exception as e:
            log.warning("[FileIOStateDB] Init failed: %s", e)

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        return conn

    # ── Recent Projects (Phase 35) ────────────────────────────────

    def add_recent_project(self, path: str, name: str = "") -> None:
        """Record a project file access."""
        now = time.time()
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO recent_projects (path, name, open_count, last_opened, created_at)
                       VALUES (?, ?, 1, ?, ?)
                       ON CONFLICT(path) DO UPDATE SET
                           name = CASE WHEN excluded.name != '' THEN excluded.name ELSE name END,
                           open_count = open_count + 1,
                           last_opened = excluded.last_opened
                    """,
                    (str(path), str(name or Path(path).stem), now, now),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FileIOStateDB] add_recent_project failed: %s", e)

    def get_recent_projects(self, limit: int = 20) -> List[dict]:
        """Get recent projects ordered by last_opened desc."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM recent_projects ORDER BY last_opened DESC LIMIT ?",
                    (limit,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def remove_recent_project(self, path: str) -> None:
        """Remove a project from recent history."""
        try:
            conn = self._conn()
            try:
                conn.execute("DELETE FROM recent_projects WHERE path=?", (str(path),))
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    # ── Recent Media (Phase 35) ───────────────────────────────────

    def add_recent_media(
        self, path: str, file_type: str = "audio", name: str = ""
    ) -> None:
        """Record a media file import/use."""
        now = time.time()
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO recent_media (path, file_type, name, use_count, last_used)
                       VALUES (?, ?, ?, 1, ?)
                       ON CONFLICT(path, file_type) DO UPDATE SET
                           use_count = use_count + 1,
                           last_used = excluded.last_used
                    """,
                    (str(path), str(file_type), str(name or Path(path).name), now),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FileIOStateDB] add_recent_media failed: %s", e)

    def get_recent_media(
        self, file_type: str = "", limit: int = 30
    ) -> List[dict]:
        """Get recent media files, optionally filtered by type."""
        try:
            conn = self._conn()
            try:
                if file_type:
                    rows = conn.execute(
                        "SELECT * FROM recent_media WHERE file_type=? ORDER BY last_used DESC LIMIT ?",
                        (file_type, limit),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT * FROM recent_media ORDER BY last_used DESC LIMIT ?",
                        (limit,),
                    ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ── Export History (Phase 35) ──────────────────────────────────

    def add_export_entry(
        self,
        output_path: str,
        fmt: str = "wav",
        sample_rate: int = 44100,
        bit_depth: int = 24,
        project_name: str = "",
        duration_sec: float = 0.0,
    ) -> None:
        """Record an export operation."""
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO export_history
                       (output_path, format, sample_rate, bit_depth, project_name, duration_sec, exported_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (str(output_path), str(fmt), sample_rate, bit_depth,
                     str(project_name), duration_sec, time.time()),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FileIOStateDB] add_export_entry failed: %s", e)

    def get_export_history(self, limit: int = 50) -> List[dict]:
        """Get export history ordered by most recent."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM export_history ORDER BY exported_at DESC LIMIT ?",
                    (limit,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ── Plugin Crash Log (Phase 36) ───────────────────────────────

    def log_plugin_crash(
        self,
        plugin_id: str,
        plugin_type: str = "",
        error_msg: str = "",
        plugin_name: str = "",
        track_id: str = "",
        auto_restarted: bool = False,
    ) -> None:
        """Record a plugin crash event."""
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO plugin_crash_log
                       (plugin_id, plugin_type, plugin_name, error_msg, track_id,
                        crashed_at, auto_restarted)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (str(plugin_id), str(plugin_type), str(plugin_name),
                     str(error_msg), str(track_id), time.time(),
                     1 if auto_restarted else 0),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FileIOStateDB] log_plugin_crash failed: %s", e)

    def get_crash_log(
        self, plugin_id: str = "", limit: int = 50
    ) -> List[dict]:
        """Get crash log for a specific plugin or all."""
        try:
            conn = self._conn()
            try:
                if plugin_id:
                    rows = conn.execute(
                        "SELECT * FROM plugin_crash_log WHERE plugin_id=? ORDER BY crashed_at DESC LIMIT ?",
                        (plugin_id, limit),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT * FROM plugin_crash_log ORDER BY crashed_at DESC LIMIT ?",
                        (limit,),
                    ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def get_crash_count(self, plugin_id: str) -> int:
        """Get total crash count for a plugin."""
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT COUNT(*) as cnt FROM plugin_crash_log WHERE plugin_id=?",
                    (plugin_id,),
                ).fetchone()
                return int(row["cnt"]) if row else 0
            finally:
                conn.close()
        except Exception:
            return 0

    def get_problematic_plugins(self, min_crashes: int = 3) -> List[dict]:
        """Get plugins that have crashed at least min_crashes times."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    """SELECT plugin_id, plugin_type, plugin_name,
                              COUNT(*) as crash_count,
                              MAX(crashed_at) as last_crash
                       FROM plugin_crash_log
                       GROUP BY plugin_id
                       HAVING crash_count >= ?
                       ORDER BY crash_count DESC""",
                    (min_crashes,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ── Maintenance ───────────────────────────────────────────────

    def prune_old_entries(self, max_age_days: int = 180) -> Dict[str, int]:
        """Prune entries older than max_age_days from all tables."""
        cutoff = time.time() - (max_age_days * 86400)
        result = {}
        try:
            conn = self._conn()
            try:
                for table in ("recent_media", "export_history", "plugin_crash_log"):
                    time_col = {
                        "recent_media": "last_used",
                        "export_history": "exported_at",
                        "plugin_crash_log": "crashed_at",
                    }[table]
                    cur = conn.execute(
                        f"DELETE FROM {table} WHERE {time_col} < ?", (cutoff,)
                    )
                    result[table] = cur.rowcount
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FileIOStateDB] prune failed: %s", e)
        return result

    def stats(self) -> Dict[str, int]:
        """Return row counts per table."""
        result = {}
        try:
            conn = self._conn()
            try:
                for table in ("recent_projects", "recent_media",
                              "export_history", "plugin_crash_log"):
                    row = conn.execute(f"SELECT COUNT(*) as cnt FROM {table}").fetchone()
                    result[table] = int(row["cnt"]) if row else 0
            finally:
                conn.close()
        except Exception:
            pass
        return result
