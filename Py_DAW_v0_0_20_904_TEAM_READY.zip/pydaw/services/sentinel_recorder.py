"""sentinel_recorder.py — Flight Recorder / Blackbox (Phase S2).

v0.0.20.904 — Phase S2 der SENTINEL_ROADMAP.

Zeichnet die letzten 60 Sekunden auf: CPU, Memory, Audio, Threads,
Plugins, Collab-Messages. Bei Crash → Blackbox wird als JSON in
sentinel_crashes gespeichert.

Performance-Budget: < 0.5% CPU.
"""

from __future__ import annotations

import logging
import os
import sys
import threading
import time
from collections import deque
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import QObject, QTimer
    _QT = True
except ImportError:
    _QT = False


def _get_process_cpu_percent() -> float:
    """Get current process CPU percent (cross-platform, no psutil needed)."""
    try:
        import resource
        usage = resource.getrusage(resource.RUSAGE_SELF)
        return usage.ru_utime + usage.ru_stime
    except Exception:
        return 0.0


def _get_memory_mb() -> float:
    """Get RSS memory in MB."""
    try:
        if sys.platform == "linux":
            with open("/proc/self/status") as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        return int(line.split()[1]) / 1024.0
        import resource
        return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0
    except Exception:
        return 0.0


def _get_thread_count() -> int:
    return threading.active_count()


def _get_disk_free_mb(path: str = ".") -> float:
    try:
        st = os.statvfs(path)
        return (st.f_bavail * st.f_frsize) / (1024 * 1024)
    except Exception:
        return -1.0


if _QT:

    class SentinelRecorder(QObject):
        """Flight Recorder — continuous metrics sampling.

        Samples CPU/Memory/Threads/Audio every 500ms-2s.
        Stores in SentinelDB + in-memory deque for instant blackbox access.
        """

        _instance: Optional["SentinelRecorder"] = None

        @classmethod
        def get(cls) -> "SentinelRecorder":
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

        def __init__(self, parent=None):
            super().__init__(parent)
            self._db = None
            self._running = False
            self._project_service = None

            # In-memory ringbuffer (instant access for blackbox dump)
            self._ringbuffer: deque = deque(maxlen=240)  # ~120s at 500ms

            # CPU tracking
            self._last_cpu_time: float = 0.0
            self._last_cpu_wall: float = 0.0

            # Collab message rate tracking
            self._collab_msg_counts: Dict[str, int] = {}
            self._collab_msg_window_start: float = 0.0

            # Timers
            self._fast_timer = QTimer(self)   # 500ms — CPU, audio
            self._fast_timer.setInterval(500)
            self._fast_timer.timeout.connect(self._sample_fast)

            self._slow_timer = QTimer(self)   # 2000ms — memory, threads, disk
            self._slow_timer.setInterval(2000)
            self._slow_timer.timeout.connect(self._sample_slow)

            # Prune timer (every 60s, remove old events from DB)
            self._prune_timer = QTimer(self)
            self._prune_timer.setInterval(60000)
            self._prune_timer.timeout.connect(self._prune)

        @property
        def is_running(self) -> bool:
            return self._running

        def start(self, project_service=None) -> None:
            self._project_service = project_service
            try:
                from pydaw.services.sentinel_db import SentinelDB
                self._db = SentinelDB.get()
                self._db.ensure_loaded()
            except Exception:
                pass
            self._last_cpu_time = _get_process_cpu_percent()
            self._last_cpu_wall = time.time()
            self._running = True
            self._fast_timer.start()
            self._slow_timer.start()
            self._prune_timer.start()
            log.info("[SENTINEL] Flight Recorder started")

        def stop(self) -> None:
            self._fast_timer.stop()
            self._slow_timer.stop()
            self._prune_timer.stop()
            if self._db:
                self._db.flush_events()
            self._running = False
            log.info("[SENTINEL] Flight Recorder stopped")

        # ══════════════════════════════════════════════════════════
        # Sampling
        # ══════════════════════════════════════════════════════════

        def _sample_fast(self) -> None:
            """Fast sampling: CPU, audio XRuns (every 500ms)."""
            now = time.time()

            # CPU usage (delta)
            cpu_now = _get_process_cpu_percent()
            wall_delta = max(0.001, now - self._last_cpu_wall)
            cpu_delta = cpu_now - self._last_cpu_time
            cpu_percent = (cpu_delta / wall_delta) * 100.0
            self._last_cpu_time = cpu_now
            self._last_cpu_wall = now

            entry = {
                "t": now,
                "cpu": round(cpu_percent, 1),
            }

            # XRun count from audio engine
            xruns = 0
            latency_ms = 0.0
            if self._project_service:
                try:
                    svc = getattr(self._project_service, '_services', None)
                    ae = getattr(svc, 'audio_engine', None) if svc else None
                    if ae:
                        xruns = getattr(ae, '_xrun_count', 0)
                        latency_ms = getattr(ae, '_current_latency_ms', 0.0)
                except Exception:
                    pass

            entry["xruns"] = xruns
            entry["latency"] = round(latency_ms, 1)

            self._ringbuffer.append(entry)

            # Log to DB
            if self._db:
                self._db.log_event("cpu", 1, "", "cpu_percent", cpu_percent)
                if xruns > 0:
                    self._db.log_event("audio", 2, "", "xrun_count", float(xruns))

        def _sample_slow(self) -> None:
            """Slow sampling: memory, threads, disk (every 2s)."""
            mem_mb = _get_memory_mb()
            threads = _get_thread_count()

            # Add to last ringbuffer entry
            if self._ringbuffer:
                last = self._ringbuffer[-1]
                last["mem_mb"] = round(mem_mb, 1)
                last["threads"] = threads

            if self._db:
                self._db.log_event("memory", 1, "", "rss_mb", mem_mb)
                self._db.log_event("thread", 1, "", "thread_count", float(threads))

                # Track count + plugin count
                if self._project_service:
                    try:
                        proj = self._project_service.ctx.project
                        track_count = len(getattr(proj, 'tracks', []) or [])
                        plugin_count = 0
                        for t in (proj.tracks or []):
                            afx = getattr(t, 'audio_fx_chain', None)
                            if isinstance(afx, dict):
                                plugin_count += len(afx.get("devices", []) or [])
                        self._db.log_event("plugin", 1, "", "track_count",
                                            float(track_count))
                        self._db.log_event("plugin", 1, "", "plugin_count",
                                            float(plugin_count))
                    except Exception:
                        pass

                self._db.flush_events()

        def _prune(self) -> None:
            """Remove old events (keep last 120s in DB)."""
            if self._db:
                self._db.prune_events(keep_seconds=120.0)

        # ══════════════════════════════════════════════════════════
        # Collab Message Tracking (called from collab_panel)
        # ══════════════════════════════════════════════════════════

        def track_collab_message(self, op_type: str) -> int:
            """Track a collab message. Returns current rate for this op_type.

            Called by collab_panel._send_collab_op() and message handler.
            """
            now = time.time()
            # Reset window every second
            if now - self._collab_msg_window_start > 1.0:
                self._collab_msg_counts.clear()
                self._collab_msg_window_start = now
            self._collab_msg_counts[op_type] = self._collab_msg_counts.get(op_type, 0) + 1
            return self._collab_msg_counts[op_type]

        def get_collab_message_rate(self, op_type: str = "") -> Dict[str, int]:
            """Get current message rates per op_type."""
            now = time.time()
            if now - self._collab_msg_window_start > 1.0:
                return {}
            if op_type:
                return {op_type: self._collab_msg_counts.get(op_type, 0)}
            return dict(self._collab_msg_counts)

        # ══════════════════════════════════════════════════════════
        # Blackbox Dump
        # ══════════════════════════════════════════════════════════

        def get_blackbox(self) -> Dict[str, Any]:
            """Get the current blackbox data (last ~60s of metrics).

            Called when a crash happens to dump into sentinel_crashes.
            """
            entries = list(self._ringbuffer)
            now = time.time()

            # System state
            system_state = {
                "memory_mb": _get_memory_mb(),
                "threads": _get_thread_count(),
                "disk_free_mb": _get_disk_free_mb(),
                "python_version": sys.version.split()[0],
                "platform": sys.platform,
                "timestamp": now,
            }

            # Track state
            track_state = {}
            if self._project_service:
                try:
                    proj = self._project_service.ctx.project
                    for t in (proj.tracks or []):
                        tid = str(getattr(t, 'id', ''))
                        if tid:
                            track_state[tid] = {
                                "name": getattr(t, 'name', ''),
                                "kind": getattr(t, 'kind', ''),
                                "plugin_type": getattr(t, 'plugin_type', ''),
                                "muted": getattr(t, 'muted', False),
                                "volume": getattr(t, 'volume', 0.8),
                            }
                except Exception:
                    pass

            return {
                "metrics": entries,
                "system_state": system_state,
                "track_state": track_state,
                "collab_rates": dict(self._collab_msg_counts),
                "sample_count": len(entries),
                "duration_s": (entries[-1]["t"] - entries[0]["t"]) if len(entries) > 1 else 0,
            }

else:
    class SentinelRecorder:
        _instance = None

        @classmethod
        def get(cls):
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

        def __init__(self):
            pass

        def start(self, project_service=None):
            pass

        def stop(self):
            pass

        def track_collab_message(self, op_type=""):
            return 0

        def get_blackbox(self):
            return {}
