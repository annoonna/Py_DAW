"""db_manager.py — Zentrale SQLite Datenbank-Verwaltung für Py_DAW.

v0.0.20.887 — Phase 1 der SQLite Migration Roadmap.

Stellt eine Singleton-Verbindung zur App-Datenbank bereit.
Thread-Safety: Nur vom GUI-Thread aufrufen, RAM-Cache ist read-only.
"""

import sqlite3
import logging
import shutil
from pathlib import Path
from typing import Optional

log = logging.getLogger(__name__)

# App-weite DB Pfad
_DEFAULT_DB_DIR = Path.home() / ".config" / "ChronoScaleStudio"
_DEFAULT_DB_NAME = "pydaw.db"


class DbManager:
    """Singleton manager for the app-wide SQLite database.

    Usage:
        db = DbManager.get()
        db.ensure_ready()
        conn = db.connection()
        ...
    """

    _instance: Optional["DbManager"] = None

    @classmethod
    def get(cls) -> "DbManager":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self, db_path: Optional[Path] = None):
        self._db_path = db_path or (_DEFAULT_DB_DIR / _DEFAULT_DB_NAME)
        self._conn: Optional[sqlite3.Connection] = None
        self._ready = False

    @property
    def db_path(self) -> Path:
        return self._db_path

    def ensure_ready(self) -> None:
        """Create DB directory and connection if needed. Idempotent."""
        if self._ready:
            return
        try:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(self._db_path))
            self._conn.row_factory = sqlite3.Row
            # WAL mode for better concurrent reads
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._ready = True
            log.info("[DbManager] Database ready: %s", self._db_path)
        except Exception as e:
            log.warning("[DbManager] Failed to init DB: %s", e)

    def connection(self) -> Optional[sqlite3.Connection]:
        """Get the database connection. Returns None if not ready."""
        self.ensure_ready()
        return self._conn

    def execute_schema(self, schema_sql: str) -> None:
        """Execute a schema SQL string (CREATE TABLE etc.)."""
        conn = self.connection()
        if conn is None:
            return
        try:
            conn.executescript(schema_sql)
            conn.commit()
        except Exception as e:
            log.warning("[DbManager] Schema execution failed: %s", e)

    def backup(self, suffix: str = "backup") -> Optional[Path]:
        """Create a backup of the database file."""
        if not self._db_path.exists():
            return None
        backup_path = self._db_path.with_suffix(f".{suffix}.db")
        try:
            shutil.copy2(str(self._db_path), str(backup_path))
            log.info("[DbManager] Backup created: %s", backup_path)
            return backup_path
        except Exception as e:
            log.warning("[DbManager] Backup failed: %s", e)
            return None

    def close(self) -> None:
        """Close the database connection."""
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None
        self._ready = False

    def __del__(self):
        self.close()
