"""Macro Recorder (P6A) — Record DAW actions → export as Python script.

Records user interactions (volume changes, mute/solo toggles, plugin parameter
changes, transport actions, clip operations) and converts them into replayable
Python scripts using the ScriptingService API.

Features:
- Start/stop/pause recording
- Timestamped action log
- Export to Python script (ScriptingService-compatible)
- Replay recorded macros
- Action filtering (record only certain categories)
- Undo/Redo integration

v0.0.20.811 — Phase P6A
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Callable

from PyQt6.QtCore import QObject, pyqtSignal

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class MacroAction:
    """Single recorded DAW action."""
    timestamp: float = 0.0       # seconds since recording start
    category: str = ""           # "mixer"|"transport"|"clip"|"plugin"|"track"|"project"
    action: str = ""             # human-readable description
    script_line: str = ""        # Python code to replay this action
    track_id: str = ""
    track_name: str = ""
    param_name: str = ""
    old_value: Any = None
    new_value: Any = None

    def to_dict(self) -> dict:
        return {
            "timestamp": round(self.timestamp, 3),
            "category": self.category,
            "action": self.action,
            "script_line": self.script_line,
            "track_id": self.track_id,
            "track_name": self.track_name,
        }


@dataclass
class MacroRecording:
    """Complete macro recording."""
    name: str = "Unbenannte Aufnahme"
    actions: List[MacroAction] = field(default_factory=list)
    duration_s: float = 0.0
    created: str = ""
    description: str = ""

    def to_script(self, include_timing: bool = False, include_comments: bool = True) -> str:
        """Export recording as Python script.

        Args:
            include_timing: if True, add time.sleep() between actions
            include_comments: if True, add # comments for each action

        Returns:
            Python script string.
        """
        lines: List[str] = []
        lines.append(f'# Py_DAW Macro: {self.name}')
        if self.description:
            lines.append(f'# {self.description}')
        lines.append(f'# Aufgenommen: {self.created}')
        lines.append(f'# Dauer: {self.duration_s:.1f}s, {len(self.actions)} Aktionen')
        lines.append('')

        if include_timing and len(self.actions) > 1:
            lines.append('import time')
            lines.append('')

        prev_ts = 0.0
        for act in self.actions:
            if include_timing and act.timestamp - prev_ts > 0.1:
                delay = act.timestamp - prev_ts
                lines.append(f'time.sleep({delay:.2f})')

            if include_comments:
                lines.append(f'# {act.action}')

            if act.script_line:
                lines.append(act.script_line)
                lines.append('')

            prev_ts = act.timestamp

        return '\n'.join(lines)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "actions": [a.to_dict() for a in self.actions],
            "duration_s": round(self.duration_s, 1),
            "created": self.created,
            "description": self.description,
        }


# ---------------------------------------------------------------------------
# Action categories for filtering
# ---------------------------------------------------------------------------

CATEGORY_MIXER = "mixer"
CATEGORY_TRANSPORT = "transport"
CATEGORY_CLIP = "clip"
CATEGORY_PLUGIN = "plugin"
CATEGORY_TRACK = "track"
CATEGORY_PROJECT = "project"

ALL_CATEGORIES = {
    CATEGORY_MIXER, CATEGORY_TRANSPORT, CATEGORY_CLIP,
    CATEGORY_PLUGIN, CATEGORY_TRACK, CATEGORY_PROJECT,
}


# ---------------------------------------------------------------------------
# Macro Recorder Service
# ---------------------------------------------------------------------------

class MacroRecorder(QObject):
    """Records DAW actions for macro playback.

    Connect to DAW signals to automatically capture actions.
    Export recordings as Python scripts for the ScriptingService.
    """

    recording_started = pyqtSignal()
    recording_stopped = pyqtSignal(object)  # MacroRecording
    recording_paused = pyqtSignal(bool)     # is_paused
    action_recorded = pyqtSignal(object)    # MacroAction

    def __init__(self, parent=None):
        super().__init__(parent)
        self._recording = False
        self._paused = False
        self._start_time: float = 0.0
        self._current: Optional[MacroRecording] = None
        self._history: List[MacroRecording] = []
        self._enabled_categories = set(ALL_CATEGORIES)
        self._db_loaded = False

    def _ensure_db_history(self) -> None:
        """v0.0.20.896: Load saved macros from ExtendedStateDB (once)."""
        if self._db_loaded:
            return
        self._db_loaded = True
        try:
            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            rows = edb.get_macros(limit=50)
            for r in rows:
                rec = MacroRecording(
                    name=str(r.get("name", "Macro")),
                    description=str(r.get("description", "")),
                    duration_s=float(r.get("duration_sec", 0)),
                )
                self._history.append(rec)
        except Exception:
            pass

    @property
    def is_recording(self) -> bool:
        return self._recording

    @property
    def is_paused(self) -> bool:
        return self._paused

    @property
    def current_recording(self) -> Optional[MacroRecording]:
        return self._current

    @property
    def history(self) -> List[MacroRecording]:
        self._ensure_db_history()
        return list(self._history)

    def set_categories(self, categories: set) -> None:
        """Set which action categories to record."""
        self._enabled_categories = categories & ALL_CATEGORIES

    # ── Recording control ─────────────────────────────────────────────────

    def start(self, name: str = "") -> None:
        """Start recording a new macro."""
        if self._recording:
            self.stop()

        from datetime import datetime
        self._current = MacroRecording(
            name=name or f"Macro {len(self._history) + 1}",
            created=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )
        self._start_time = time.time()
        self._recording = True
        self._paused = False
        log.info("Macro recording started: %s", self._current.name)
        try:
            self.recording_started.emit()
        except Exception:
            pass

    def stop(self) -> Optional[MacroRecording]:
        """Stop recording and return the MacroRecording."""
        if not self._recording or self._current is None:
            return None

        self._recording = False
        self._paused = False
        self._current.duration_s = time.time() - self._start_time

        result = self._current
        self._history.append(result)
        self._current = None

        log.info("Macro recording stopped: %s (%d actions)",
                 result.name, len(result.actions))
        try:
            self.recording_stopped.emit(result)
        except Exception:
            pass
        # v0.0.20.893 P16: Persist to SQLite
        try:
            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            import json
            actions_j = json.dumps([a.to_dict() for a in result.actions], ensure_ascii=False)
            edb.save_macro(
                name=result.name,
                actions_json=actions_j,
                duration_sec=result.duration_s,
                action_count=len(result.actions),
                script_code=result.to_script(include_timing=False),
                description=result.description,
            )
        except Exception:
            pass
        return result

    def pause(self) -> None:
        """Toggle pause."""
        if not self._recording:
            return
        self._paused = not self._paused
        try:
            self.recording_paused.emit(self._paused)
        except Exception:
            pass

    # ── Action recording ──────────────────────────────────────────────────

    def record_action(
        self,
        category: str,
        action: str,
        script_line: str,
        track_id: str = "",
        track_name: str = "",
        param_name: str = "",
        old_value: Any = None,
        new_value: Any = None,
    ) -> None:
        """Record a single DAW action.

        Args:
            category: one of CATEGORY_* constants
            action: human-readable description
            script_line: Python code to replay
            track_id: affected track ID (optional)
            track_name: affected track name (optional)
        """
        if not self._recording or self._paused:
            return
        if category not in self._enabled_categories:
            return

        ts = time.time() - self._start_time
        act = MacroAction(
            timestamp=ts,
            category=category,
            action=action,
            script_line=script_line,
            track_id=track_id,
            track_name=track_name,
            param_name=param_name,
            old_value=old_value,
            new_value=new_value,
        )

        if self._current is not None:
            self._current.actions.append(act)

        try:
            self.action_recorded.emit(act)
        except Exception:
            pass

    # ── Convenience methods (call from DAW signals) ───────────────────────

    def record_volume_change(self, track_idx: int, track_name: str,
                             old_vol: float, new_vol: float) -> None:
        self.record_action(
            CATEGORY_MIXER,
            f"Volume: {track_name} {old_vol:.2f} → {new_vol:.2f}",
            f"tracks[{track_idx}].volume = {new_vol:.4f}",
            track_name=track_name,
            param_name="volume",
            old_value=old_vol, new_value=new_vol,
        )

    def record_pan_change(self, track_idx: int, track_name: str,
                          old_pan: float, new_pan: float) -> None:
        self.record_action(
            CATEGORY_MIXER,
            f"Pan: {track_name} {old_pan:.2f} → {new_pan:.2f}",
            f"tracks[{track_idx}].pan = {new_pan:.4f}",
            track_name=track_name,
            param_name="pan",
            old_value=old_pan, new_value=new_pan,
        )

    def record_mute_toggle(self, track_idx: int, track_name: str, muted: bool) -> None:
        self.record_action(
            CATEGORY_MIXER,
            f"{'Mute' if muted else 'Unmute'}: {track_name}",
            f"tracks[{track_idx}].muted = {muted}",
            track_name=track_name,
            param_name="muted",
            new_value=muted,
        )

    def record_solo_toggle(self, track_idx: int, track_name: str, solo: bool) -> None:
        self.record_action(
            CATEGORY_MIXER,
            f"{'Solo' if solo else 'Unsolo'}: {track_name}",
            f"tracks[{track_idx}].solo = {solo}",
            track_name=track_name,
            param_name="solo",
            new_value=solo,
        )

    def record_transport(self, action_name: str) -> None:
        action_map = {
            "play": "transport.play()",
            "stop": "transport.stop()",
            "record": "transport.toggle_record()",
            "pause": "transport.pause()",
        }
        script = action_map.get(action_name, f"# transport.{action_name}()")
        self.record_action(
            CATEGORY_TRANSPORT,
            f"Transport: {action_name}",
            script,
        )

    def record_bpm_change(self, old_bpm: float, new_bpm: float) -> None:
        self.record_action(
            CATEGORY_PROJECT,
            f"BPM: {old_bpm:.1f} → {new_bpm:.1f}",
            f"project.bpm = {new_bpm:.1f}",
            param_name="bpm",
            old_value=old_bpm, new_value=new_bpm,
        )

    def record_plugin_param(self, track_idx: int, track_name: str,
                            plugin_name: str, param: str,
                            old_val: float, new_val: float) -> None:
        self.record_action(
            CATEGORY_PLUGIN,
            f"{plugin_name}.{param}: {old_val:.3f} → {new_val:.3f} ({track_name})",
            f"# tracks[{track_idx}].plugin.{param} = {new_val:.4f}",
            track_name=track_name,
            param_name=f"{plugin_name}.{param}",
            old_value=old_val, new_value=new_val,
        )

    def record_add_track(self, name: str, kind: str) -> None:
        self.record_action(
            CATEGORY_TRACK,
            f"Track hinzugefügt: {name} ({kind})",
            f'add_track("{name}", kind="{kind}")',
            track_name=name,
        )

    def record_delete_track(self, track_idx: int, track_name: str) -> None:
        self.record_action(
            CATEGORY_TRACK,
            f"Track gelöscht: {track_name}",
            f"# delete_track({track_idx})  # {track_name}",
            track_name=track_name,
        )

    # ── Export / Replay ───────────────────────────────────────────────────

    def export_script(
        self,
        recording: Optional[MacroRecording] = None,
        include_timing: bool = False,
    ) -> str:
        """Export a recording as Python script string."""
        rec = recording or (self._history[-1] if self._history else None)
        if rec is None:
            return "# Keine Aufnahme vorhanden"
        return rec.to_script(include_timing=include_timing)

    def get_last_recording(self) -> Optional[MacroRecording]:
        """Return the most recent recording."""
        return self._history[-1] if self._history else None

    def clear_history(self) -> None:
        """Clear all recorded macros."""
        self._history.clear()
