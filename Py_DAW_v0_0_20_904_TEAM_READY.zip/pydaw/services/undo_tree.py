"""undo_tree.py — Git-Style Undo Tree (Phase T8).

v0.0.20.901 — Phase T8 der TIME_TRAVEL_ROADMAP.

Statt linearem Undo (A → B → C, Undo = C → B → A) ein Baum:

          A (Start)
          |
          B (Bass hinzugefuegt)
         / \
        C   D (Branch: anderer Bass-Sound)
        |   |
        E   F
        |
        G (← du bist hier)

Du kannst zu D springen ohne C/E/G zu verlieren.

Implementierung:
- UndoTree Datenstruktur (nicht UndoStack)
- Jeder Knoten = Snapshot-ID + Event-Range + Label
- Branches werden in journal_branches gespeichert
- Branch-Operationen: create, switch, merge, delete

Usage:
    from pydaw.services.undo_tree import UndoTree
    tree = UndoTree(journal)
    tree.ensure_main_branch()

    # Branch erstellen
    tree.create_branch("experiment-bass")

    # Branch wechseln
    tree.switch_branch("experiment-bass")

    # Branch mergen
    tree.merge_branch("experiment-bass", into="main")

    # Baum-Struktur fuer UI
    nodes = tree.get_tree_nodes()
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


@dataclass
class BranchNode:
    """A node in the undo tree."""
    id: int = 0
    session_id: str = ""
    branch_name: str = "main"
    parent_branch_id: Optional[int] = None
    fork_timestamp_ms: int = 0
    snapshot_id: int = 0
    is_active: bool = False
    created_at: float = 0.0
    description: str = ""
    # Computed: child branches
    children: List["BranchNode"] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "branch_name": self.branch_name,
            "parent_branch_id": self.parent_branch_id,
            "fork_timestamp_ms": self.fork_timestamp_ms,
            "snapshot_id": self.snapshot_id,
            "is_active": self.is_active,
            "created_at": self.created_at,
            "description": self.description,
            "children": [c.to_dict() for c in self.children],
        }


@dataclass
class TreeInfo:
    """Summary of the undo tree state."""
    branch_count: int = 0
    active_branch: str = "main"
    active_branch_id: int = 0
    total_snapshots: int = 0


class UndoTree:
    """Git-style undo tree backed by journal_branches table.

    Not a singleton — created per session with journal reference.
    """

    def __init__(self, journal=None):
        self._journal = journal
        self._db = None
        self._active_branch_id: int = 0
        self._active_branch_name: str = "main"

        try:
            from pydaw.services.time_travel_db import TimeTravelDB
            self._db = TimeTravelDB.get()
            self._db.ensure_loaded()
        except Exception:
            pass

    @property
    def active_branch(self) -> str:
        return self._active_branch_name

    @property
    def active_branch_id(self) -> int:
        return self._active_branch_id

    # ══════════════════════════════════════════════════════════════
    # Branch Management
    # ══════════════════════════════════════════════════════════════

    def ensure_main_branch(self) -> int:
        """Ensure a 'main' branch exists for the current session.

        Returns the branch ID.
        """
        if not self._db or not self._journal:
            return 0

        session_id = self._journal.session_id
        branches = self._db.get_branches(session_id)

        # Find existing main branch
        for b in branches:
            if b.get("branch_name") == "main":
                bid = b.get("id", 0)
                self._active_branch_id = bid
                self._active_branch_name = "main"
                # Make sure it's marked active
                self._set_active(session_id, bid)
                return bid

        # Create main branch
        bid = self._db.create_branch(
            session_id, "main",
            fork_timestamp_ms=0,
            description="Haupt-Branch",
        )
        self._active_branch_id = bid
        self._active_branch_name = "main"
        self._set_active(session_id, bid)
        return bid

    def create_branch(self, name: str, description: str = "") -> int:
        """Create a new branch at the current timestamp.

        Forks from the active branch. Returns the new branch ID.
        """
        if not self._db or not self._journal:
            return 0

        session_id = self._journal.session_id
        current_ms = self._journal._timestamp_ms()

        # Take a snapshot at the fork point
        snapshot_id = 0
        try:
            self._journal._take_snapshot()
            # Get the latest snapshot ID
            snapshots = self._db.get_snapshots(session_id, limit=1)
            if snapshots:
                snapshot_id = snapshots[0].get("id", 0)
        except Exception:
            pass

        bid = self._db.create_branch(
            session_id, name,
            fork_timestamp_ms=current_ms,
            snapshot_id=snapshot_id,
            parent_branch_id=self._active_branch_id or None,
            description=description or f"Branch '{name}' bei {current_ms}ms",
        )

        log.info("[UndoTree] Created branch '%s' (id=%d) at %dms",
                 name, bid, current_ms)
        return bid

    def switch_branch(self, name: str) -> bool:
        """Switch to a different branch. Restores the snapshot at fork point.

        Returns True if switch was successful.
        """
        if not self._db or not self._journal:
            return False

        session_id = self._journal.session_id
        branches = self._db.get_branches(session_id)

        target = None
        for b in branches:
            if b.get("branch_name") == name:
                target = b
                break

        if not target:
            log.warning("[UndoTree] Branch '%s' not found", name)
            return False

        bid = target.get("id", 0)
        snapshot_id = target.get("snapshot_id", 0)

        # Restore the snapshot at the fork point
        if snapshot_id > 0:
            try:
                from pydaw.services.time_travel_restore import TimeTravelRestore
                restore = TimeTravelRestore(
                    project_service=getattr(self._journal, '_project_service', None),
                    journal=self._journal,
                )
                # Load snapshot and apply
                conn = self._db._conn()
                try:
                    row = conn.execute(
                        "SELECT snapshot_json FROM journal_snapshots WHERE id=?",
                        (snapshot_id,),
                    ).fetchone()
                    if row:
                        state_data = json.loads(row["snapshot_json"])
                        restore._apply_snapshot_state(state_data)
                finally:
                    conn.close()
            except Exception as e:
                log.warning("[UndoTree] Switch snapshot restore failed: %s", e)

        # Update active branch
        self._active_branch_id = bid
        self._active_branch_name = name
        self._set_active(session_id, bid)

        log.info("[UndoTree] Switched to branch '%s' (id=%d)", name, bid)
        return True

    def delete_branch(self, name: str) -> bool:
        """Delete a branch. Cannot delete 'main' or the active branch.

        Returns True if deletion was successful.
        """
        if name == "main":
            log.warning("[UndoTree] Cannot delete 'main' branch")
            return False

        if name == self._active_branch_name:
            log.warning("[UndoTree] Cannot delete active branch '%s'", name)
            return False

        if not self._db or not self._journal:
            return False

        session_id = self._journal.session_id
        branches = self._db.get_branches(session_id)

        target_id = None
        for b in branches:
            if b.get("branch_name") == name:
                target_id = b.get("id")
                break

        if target_id is None:
            return False

        try:
            conn = self._db._conn()
            try:
                conn.execute(
                    "DELETE FROM journal_branches WHERE id=? AND session_id=?",
                    (target_id, session_id),
                )
                conn.commit()
            finally:
                conn.close()
            log.info("[UndoTree] Deleted branch '%s' (id=%d)", name, target_id)
            return True
        except Exception as e:
            log.warning("[UndoTree] Delete failed: %s", e)
            return False

    def merge_branch(self, source_name: str, into: str = "main") -> bool:
        """Merge source branch into target.

        Takes the snapshot from source and applies it on the target branch.
        Then deletes the source branch.
        """
        if not self._db or not self._journal:
            return False

        session_id = self._journal.session_id
        branches = self._db.get_branches(session_id)

        source = None
        target = None
        for b in branches:
            bname = b.get("branch_name", "")
            if bname == source_name:
                source = b
            if bname == into:
                target = b

        if not source or not target:
            log.warning("[UndoTree] Merge: source or target not found")
            return False

        # Switch to target first
        if self._active_branch_name != into:
            self.switch_branch(into)

        # Apply source snapshot on top
        snapshot_id = source.get("snapshot_id", 0)
        if snapshot_id > 0:
            try:
                conn = self._db._conn()
                try:
                    row = conn.execute(
                        "SELECT snapshot_json FROM journal_snapshots WHERE id=?",
                        (snapshot_id,),
                    ).fetchone()
                    if row:
                        from pydaw.services.time_travel_restore import TimeTravelRestore
                        restore = TimeTravelRestore(
                            project_service=getattr(self._journal, '_project_service', None),
                            journal=self._journal,
                        )
                        state_data = json.loads(row["snapshot_json"])
                        restore._apply_snapshot_state(state_data)
                finally:
                    conn.close()
            except Exception as e:
                log.warning("[UndoTree] Merge snapshot apply failed: %s", e)
                return False

        # Delete source branch
        self.delete_branch(source_name)

        log.info("[UndoTree] Merged '%s' into '%s'", source_name, into)
        return True

    # ══════════════════════════════════════════════════════════════
    # Tree Query
    # ══════════════════════════════════════════════════════════════

    def get_branches(self) -> List[dict]:
        """Get all branches for the current session."""
        if not self._db or not self._journal:
            return []
        return self._db.get_branches(self._journal.session_id)

    def get_tree_nodes(self) -> List[BranchNode]:
        """Build the tree structure for UI rendering.

        Returns a list of root nodes (usually just 'main') with
        children populated recursively.
        """
        if not self._db or not self._journal:
            return []

        branches = self._db.get_branches(self._journal.session_id)

        # Build nodes
        nodes_by_id: Dict[int, BranchNode] = {}
        for b in branches:
            node = BranchNode(
                id=b.get("id", 0),
                session_id=b.get("session_id", ""),
                branch_name=b.get("branch_name", ""),
                parent_branch_id=b.get("parent_branch_id"),
                fork_timestamp_ms=b.get("fork_timestamp_ms", 0),
                snapshot_id=b.get("snapshot_id", 0),
                is_active=bool(b.get("is_active", 0)),
                created_at=b.get("created_at", 0),
                description=b.get("description", ""),
            )
            nodes_by_id[node.id] = node

        # Build parent-child relationships
        roots: List[BranchNode] = []
        for node in nodes_by_id.values():
            parent_id = node.parent_branch_id
            if parent_id and parent_id in nodes_by_id:
                nodes_by_id[parent_id].children.append(node)
            else:
                roots.append(node)

        return roots

    def get_info(self) -> TreeInfo:
        """Get summary info about the undo tree."""
        branches = self.get_branches()
        info = TreeInfo(
            branch_count=len(branches),
            active_branch=self._active_branch_name,
            active_branch_id=self._active_branch_id,
        )
        for b in branches:
            if b.get("is_active"):
                info.active_branch = b.get("branch_name", "main")
                info.active_branch_id = b.get("id", 0)
        return info

    # ══════════════════════════════════════════════════════════════
    # Internal
    # ══════════════════════════════════════════════════════════════

    def _set_active(self, session_id: str, branch_id: int) -> None:
        """Mark a branch as active (deactivate all others)."""
        if not self._db:
            return
        try:
            conn = self._db._conn()
            try:
                conn.execute(
                    "UPDATE journal_branches SET is_active=0 WHERE session_id=?",
                    (session_id,),
                )
                conn.execute(
                    "UPDATE journal_branches SET is_active=1 WHERE id=?",
                    (branch_id,),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[UndoTree] _set_active failed: %s", e)
