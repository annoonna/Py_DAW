"""Faust DSP Integration (P6B) — Compile .dsp files to Python DSP.

Faust (Functional Audio Stream) is a functional DSP language.
This module wraps the Faust compiler to generate C++ code, then loads
the compiled shared library for real-time audio processing.

Workflow:
1. Write .dsp file (Faust DSP code)
2. faust_compile() → .cpp → .so via faust + g++
3. Load .so via ctypes → FaustDspInstance
4. Process audio blocks through the compiled DSP

Requirements (optional):
- faust compiler (https://faust.grame.fr/)
- g++ or clang++ for C++ compilation

Falls back gracefully if faust is not installed.

v0.0.20.812 — Phase P6B
"""

from __future__ import annotations

import ctypes
import logging
import os
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Any

log = logging.getLogger(__name__)

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    np = None  # type: ignore
    _HAS_NUMPY = False


# ---------------------------------------------------------------------------
# Availability check
# ---------------------------------------------------------------------------

def is_faust_available() -> bool:
    """Check if the Faust compiler is installed."""
    try:
        result = subprocess.run(
            ["faust", "--version"], capture_output=True, text=True, timeout=5
        )
        return result.returncode == 0
    except Exception:
        return False


def get_faust_version() -> str:
    """Return Faust compiler version string."""
    try:
        result = subprocess.run(
            ["faust", "--version"], capture_output=True, text=True, timeout=5
        )
        return result.stdout.strip()
    except Exception:
        return "not installed"


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class FaustParam:
    """A Faust DSP UI parameter."""
    address: str = ""      # e.g. "/volume"
    label: str = ""
    init: float = 0.0
    minimum: float = 0.0
    maximum: float = 1.0
    step: float = 0.01
    current: float = 0.0

    def to_dict(self) -> dict:
        return {
            "address": self.address, "label": self.label,
            "init": self.init, "min": self.minimum, "max": self.maximum,
            "step": self.step, "current": round(self.current, 6),
        }


@dataclass
class FaustDspInfo:
    """Metadata about a compiled Faust DSP."""
    name: str = ""
    author: str = ""
    description: str = ""
    version: str = ""
    license: str = ""
    num_inputs: int = 0
    num_outputs: int = 0
    params: List[FaustParam] = field(default_factory=list)
    source_file: str = ""
    compiled_lib: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name, "author": self.author,
            "description": self.description,
            "inputs": self.num_inputs, "outputs": self.num_outputs,
            "params": [p.to_dict() for p in self.params],
            "source_file": self.source_file,
            "compiled_lib": self.compiled_lib,
        }


# ---------------------------------------------------------------------------
# Faust compiler wrapper
# ---------------------------------------------------------------------------

def faust_compile(
    dsp_source: str,
    name: str = "pydaw_faust",
    output_dir: Optional[str] = None,
    sample_rate: int = 44100,
) -> Optional[FaustDspInfo]:
    """Compile a Faust .dsp source to a shared library.

    Args:
        dsp_source: Faust DSP source code
        name: output library name
        output_dir: directory for compiled files (default: temp dir)
        sample_rate: target sample rate

    Returns:
        FaustDspInfo on success, None on failure.
    """
    if not is_faust_available():
        log.warning("Faust compiler not found — install from https://faust.grame.fr/")
        return None

    if output_dir is None:
        output_dir = tempfile.mkdtemp(prefix="pydaw_faust_")

    out_path = Path(output_dir)
    dsp_file = out_path / f"{name}.dsp"
    cpp_file = out_path / f"{name}.cpp"
    so_file = out_path / f"{name}.so"

    # Write .dsp file
    dsp_file.write_text(dsp_source, encoding="utf-8")

    try:
        # Step 1: faust → C++
        result = subprocess.run(
            ["faust", "-lang", "cpp", "-a", "minimal.cpp",
             "-o", str(cpp_file), str(dsp_file)],
            capture_output=True, text=True, timeout=30,
        )
        if result.returncode != 0:
            # Try without architecture file
            result = subprocess.run(
                ["faust", "-lang", "cpp",
                 "-o", str(cpp_file), str(dsp_file)],
                capture_output=True, text=True, timeout=30,
            )
        if result.returncode != 0:
            log.error("Faust compilation failed: %s", result.stderr)
            return None

        # Step 2: C++ → .so
        compiler = "g++"
        compile_result = subprocess.run(
            [compiler, "-shared", "-fPIC", "-O3", "-march=native",
             "-o", str(so_file), str(cpp_file), "-lm"],
            capture_output=True, text=True, timeout=60,
        )
        if compile_result.returncode != 0:
            log.error("C++ compilation failed: %s", compile_result.stderr)
            return None

        # Parse metadata from source
        info = FaustDspInfo(
            name=name,
            source_file=str(dsp_file),
            compiled_lib=str(so_file),
        )

        # Extract metadata from DSP source
        for line in dsp_source.split("\n"):
            line = line.strip()
            if "declare name" in line:
                info.name = _extract_declare(line)
            elif "declare author" in line:
                info.author = _extract_declare(line)
            elif "declare description" in line:
                info.description = _extract_declare(line)
            elif "declare version" in line:
                info.version = _extract_declare(line)
            elif "declare license" in line:
                info.license = _extract_declare(line)

        log.info("Faust DSP compiled: %s → %s", dsp_file, so_file)
        return info

    except Exception as exc:
        log.error("Faust compile error: %s", exc)
        return None


def _extract_declare(line: str) -> str:
    """Extract value from: declare name "value";"""
    import re
    m = re.search(r'"([^"]*)"', line)
    return m.group(1) if m else ""


# ---------------------------------------------------------------------------
# Faust DSP Instance (for runtime processing)
# ---------------------------------------------------------------------------

class FaustDspInstance:
    """Runtime instance of a compiled Faust DSP.

    Loads the compiled .so and provides process_block().
    This is a stub that demonstrates the architecture —
    actual ctypes FFI bindings depend on the Faust C API.
    """

    def __init__(self, info: FaustDspInfo, sample_rate: float = 44100.0):
        self._info = info
        self._sample_rate = sample_rate
        self._lib = None
        self._dsp = None
        self._loaded = False

    @property
    def info(self) -> FaustDspInfo:
        return self._info

    def load(self) -> bool:
        """Load the compiled shared library."""
        if not self._info.compiled_lib or not os.path.exists(self._info.compiled_lib):
            log.error("Faust .so not found: %s", self._info.compiled_lib)
            return False

        try:
            self._lib = ctypes.CDLL(self._info.compiled_lib)
            self._loaded = True
            log.info("Faust DSP loaded: %s", self._info.name)
            return True
        except OSError as exc:
            log.error("Failed to load Faust DSP: %s", exc)
            return False

    def process_block(self, left: Any, right: Any) -> None:
        """Process an audio block through the Faust DSP.

        Args:
            left, right: numpy arrays, modified in-place.
        """
        if not self._loaded or self._lib is None:
            return
        # NOTE: Actual implementation requires Faust C API bindings
        # (createDSP, initDSP, computeDSP, etc.)
        # This is a structural placeholder showing the integration pattern.
        log.debug("FaustDspInstance.process_block called (stub)")

    def set_param(self, address: str, value: float) -> None:
        """Set a Faust parameter by its UI address."""
        for p in self._info.params:
            if p.address == address:
                p.current = max(p.minimum, min(p.maximum, value))
                break

    def unload(self) -> None:
        """Unload the DSP."""
        self._lib = None
        self._dsp = None
        self._loaded = False

    def shutdown(self) -> None:
        self.unload()


# ---------------------------------------------------------------------------
# Example Faust DSP sources
# ---------------------------------------------------------------------------

EXAMPLE_GAIN = """
declare name "SimpleGain";
declare author "Py_DAW";
import("stdfaust.lib");
gain = hslider("gain", 0, -60, 12, 0.1) : ba.db2linear;
process = _ * gain, _ * gain;
"""

EXAMPLE_TREMOLO = """
declare name "Tremolo";
declare author "Py_DAW";
import("stdfaust.lib");
rate = hslider("rate", 4, 0.1, 20, 0.1);
depth = hslider("depth", 50, 0, 100, 1) / 100;
lfo = os.osc(rate) * depth * 0.5 + (1 - depth * 0.5);
process = _ * lfo, _ * lfo;
"""

EXAMPLE_LOWPASS = """
declare name "LowpassFilter";
declare author "Py_DAW";
import("stdfaust.lib");
freq = hslider("cutoff", 1000, 20, 20000, 1);
q = hslider("resonance", 0.707, 0.1, 10, 0.01);
process = fi.resonlp(freq, q, 1), fi.resonlp(freq, q, 1);
"""

BUILTIN_FAUST: Dict[str, str] = {
    "Simple Gain": EXAMPLE_GAIN,
    "Tremolo": EXAMPLE_TREMOLO,
    "Lowpass Filter": EXAMPLE_LOWPASS,
}
