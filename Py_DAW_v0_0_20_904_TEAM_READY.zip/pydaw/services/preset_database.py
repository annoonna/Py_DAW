"""preset_database.py — SQLite-backed Preset Database mit FTS5 Volltext-Suche.

v0.0.20.887 — Phase 2 der SQLite Migration Roadmap.

Replaces in-memory preset lists with persistent SQLite storage.
All presets (factory, user, community, KI-generated) in one place.
FTS5 for semantic search across name, tags, description, character.

Usage:
    from pydaw.services.preset_database import PresetDatabase
    db = PresetDatabase.get()
    db.ensure_loaded()
    db.add_preset("Warm Pad", "aeterna", "chrono.aeterna", params={...},
                  category="Pad", tags=["warm","analog","reverb"])
    results = db.search("warm 80s pad")
    db.toggle_favorite(preset_id)
"""

import json
import sqlite3
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional, Any

log = logging.getLogger(__name__)


class PresetDatabase:
    """SQLite-backed preset database with FTS5 full-text search.

    Singleton. RAM-cached for fast reads, writes go to disk.
    """

    _instance: Optional["PresetDatabase"] = None

    @classmethod
    def get(cls) -> "PresetDatabase":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "preset_database.db"
        self._cache: List[dict] = []
        self._cache_by_id: Dict[int, dict] = {}
        self._loaded = False

    def ensure_loaded(self) -> None:
        """Create DB, seed factory data if empty, load into RAM. Idempotent."""
        if self._loaded:
            return
        try:
            self._init_db()
            self._load_to_ram()
            self._loaded = True
            log.info("[PresetDB] Loaded %d presets", len(self._cache))
        except Exception as e:
            log.warning("[PresetDB] Failed to load: %s", e)

    def _init_db(self) -> None:
        """Create tables + FTS index if not exist."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.executescript(_SCHEMA_SQL)
            conn.commit()
        finally:
            conn.close()

    def _load_to_ram(self) -> None:
        """Load all presets into RAM cache for O(1) access."""
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute(
                "SELECT * FROM presets ORDER BY instrument, name"
            ).fetchall()
            self._cache = [dict(r) for r in rows]
            self._cache_by_id = {r["id"]: r for r in self._cache}
        finally:
            conn.close()

    def reload(self) -> None:
        """Force reload from DB."""
        self._loaded = False
        self.ensure_loaded()

    # ── Read API ────────────────────────────────────────────────

    def all_presets(self) -> List[dict]:
        """All presets (RAM cache)."""
        self.ensure_loaded()
        return list(self._cache)

    def get_preset(self, preset_id: int) -> Optional[dict]:
        """Get a single preset by ID."""
        self.ensure_loaded()
        return self._cache_by_id.get(preset_id)

    def get_by_instrument(self, instrument: str) -> List[dict]:
        """All presets for a specific instrument."""
        self.ensure_loaded()
        return [p for p in self._cache if p.get("instrument") == instrument]

    def get_by_source(self, source: str) -> List[dict]:
        """All presets from a specific source (factory/user/community/ki)."""
        self.ensure_loaded()
        return [p for p in self._cache if p.get("source") == source]

    def get_favorites(self) -> List[dict]:
        """All favorite presets."""
        self.ensure_loaded()
        return [p for p in self._cache if p.get("is_favorite")]

    def get_categories(self, instrument: str = "") -> List[str]:
        """Get all unique category names, optionally filtered by instrument."""
        self.ensure_loaded()
        cats = set()
        for p in self._cache:
            if instrument and p.get("instrument") != instrument:
                continue
            cat = p.get("category", "")
            if cat:
                cats.add(cat)
        return sorted(cats)

    def search(self, query: str, instrument: str = "", category: str = "",
               source: str = "", limit: int = 100) -> List[dict]:
        """Full-text search across name, tags, description, character.

        Uses FTS5 for fast, ranked search. Falls back to RAM filter if FTS fails.
        """
        self.ensure_loaded()
        if not query.strip():
            # No query → return filtered list
            results = self._cache
            if instrument:
                results = [p for p in results if p.get("instrument") == instrument]
            if category:
                results = [p for p in results if p.get("category") == category]
            if source:
                results = [p for p in results if p.get("source") == source]
            return results[:limit]

        # Try FTS5 search
        try:
            conn = sqlite3.connect(str(self._db_path))
            conn.row_factory = sqlite3.Row
            try:
                # FTS5 match with rank
                fts_query = " OR ".join(query.split())
                sql = "SELECT p.* FROM presets p JOIN presets_fts f ON p.id = f.rowid WHERE presets_fts MATCH ?"
                params_list: list = [fts_query]
                if instrument:
                    sql += " AND p.instrument = ?"
                    params_list.append(instrument)
                if category:
                    sql += " AND p.category = ?"
                    params_list.append(category)
                if source:
                    sql += " AND p.source = ?"
                    params_list.append(source)
                sql += " ORDER BY rank LIMIT ?"
                params_list.append(limit)
                rows = conn.execute(sql, params_list).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            pass

        # Fallback: RAM-based search
        q = query.lower()
        results = []
        for p in self._cache:
            if instrument and p.get("instrument") != instrument:
                continue
            if category and p.get("category") != category:
                continue
            if source and p.get("source") != source:
                continue
            searchable = " ".join([
                str(p.get("name", "")),
                str(p.get("tags", "")),
                str(p.get("description", "")),
                str(p.get("character", "")),
            ]).lower()
            if q in searchable:
                results.append(p)
        return results[:limit]

    # ── Write API ───────────────────────────────────────────────

    def add_preset(self, name: str, instrument: str, plugin_id: str,
                   params: dict, **kwargs) -> Optional[int]:
        """Add a preset. Returns the new ID or None on failure."""
        self.ensure_loaded()
        tags = kwargs.get("tags", [])
        tags_str = ",".join(tags) if isinstance(tags, list) else str(tags or "")

        conn = sqlite3.connect(str(self._db_path))
        try:
            cur = conn.execute(
                "INSERT OR REPLACE INTO presets "
                "(name, instrument, plugin_id, category, source, author, "
                " tags, description, character, is_favorite, params, "
                " factory_sample, created_at, updated_at) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'),datetime('now'))",
                (name, instrument, plugin_id,
                 kwargs.get("category", ""),
                 kwargs.get("source", "user"),
                 kwargs.get("author", ""),
                 tags_str,
                 kwargs.get("description", ""),
                 kwargs.get("character", ""),
                 1 if kwargs.get("is_favorite") else 0,
                 json.dumps(params, ensure_ascii=False),
                 kwargs.get("factory_sample", ""))
            )
            conn.commit()
            preset_id = cur.lastrowid

            # Update FTS
            self._update_fts(conn, preset_id, name, tags_str,
                             kwargs.get("description", ""),
                             kwargs.get("character", ""))
            conn.commit()

            # Reload cache
            self._load_to_ram()
            return preset_id
        except Exception as e:
            log.warning("[PresetDB] add_preset failed: %s", e)
            return None
        finally:
            conn.close()

    def add_presets_batch(self, presets: List[dict]) -> int:
        """Add multiple presets in a single transaction. Returns count added."""
        self.ensure_loaded()
        conn = sqlite3.connect(str(self._db_path))
        count = 0
        try:
            for p in presets:
                tags = p.get("tags", [])
                tags_str = ",".join(tags) if isinstance(tags, list) else str(tags or "")
                params_json = json.dumps(p.get("params", {}), ensure_ascii=False)
                try:
                    cur = conn.execute(
                        "INSERT OR IGNORE INTO presets "
                        "(name, instrument, plugin_id, category, source, author, "
                        " tags, description, character, is_favorite, params, "
                        " factory_sample, created_at, updated_at) "
                        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'),datetime('now'))",
                        (p.get("name", ""), p.get("instrument", ""),
                         p.get("plugin_id", ""), p.get("category", ""),
                         p.get("source", "factory"), p.get("author", ""),
                         tags_str, p.get("description", ""),
                         p.get("character", ""), 0, params_json,
                         p.get("factory_sample", ""))
                    )
                    if cur.rowcount > 0:
                        count += 1
                        self._update_fts(conn, cur.lastrowid,
                                         p.get("name", ""), tags_str,
                                         p.get("description", ""),
                                         p.get("character", ""))
                except Exception:
                    pass
            conn.commit()
            self._load_to_ram()
        except Exception as e:
            log.warning("[PresetDB] batch add failed: %s", e)
        finally:
            conn.close()
        return count

    def toggle_favorite(self, preset_id: int) -> bool:
        """Toggle favorite status. Returns new state."""
        self.ensure_loaded()
        p = self._cache_by_id.get(preset_id)
        if not p:
            return False
        new_val = 0 if p.get("is_favorite") else 1
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.execute("UPDATE presets SET is_favorite=?, updated_at=datetime('now') WHERE id=?",
                         (new_val, preset_id))
            conn.commit()
            p["is_favorite"] = new_val
            return bool(new_val)
        except Exception:
            return False
        finally:
            conn.close()

    def increment_play_count(self, preset_id: int) -> None:
        """Increment play count for popularity tracking."""
        self.ensure_loaded()
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.execute("UPDATE presets SET play_count = play_count + 1 WHERE id=?",
                         (preset_id,))
            conn.commit()
            p = self._cache_by_id.get(preset_id)
            if p:
                p["play_count"] = p.get("play_count", 0) + 1
        except Exception:
            pass
        finally:
            conn.close()

    def delete_preset(self, preset_id: int) -> bool:
        """Delete a preset. Returns True on success."""
        self.ensure_loaded()
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.execute("DELETE FROM presets WHERE id=?", (preset_id,))
            conn.execute("DELETE FROM presets_fts WHERE rowid=?", (preset_id,))
            conn.commit()
            self._load_to_ram()
            return True
        except Exception:
            return False
        finally:
            conn.close()

    def get_popular(self, limit: int = 20) -> List[dict]:
        """Get most-played presets."""
        self.ensure_loaded()
        return sorted(self._cache, key=lambda p: p.get("play_count", 0),
                      reverse=True)[:limit]

    def count(self, instrument: str = "", source: str = "") -> int:
        """Count presets, optionally filtered."""
        self.ensure_loaded()
        c = self._cache
        if instrument:
            c = [p for p in c if p.get("instrument") == instrument]
        if source:
            c = [p for p in c if p.get("source") == source]
        return len(c)

    # ── FTS helpers ─────────────────────────────────────────────

    def _update_fts(self, conn: sqlite3.Connection, rowid: int,
                    name: str, tags: str, description: str, character: str) -> None:
        """Insert/update FTS5 index entry."""
        try:
            conn.execute(
                "INSERT OR REPLACE INTO presets_fts(rowid, name, tags, description, character) "
                "VALUES (?,?,?,?,?)",
                (rowid, name, tags, description, character)
            )
        except Exception:
            pass

    def rebuild_fts(self) -> None:
        """Rebuild the FTS index from scratch."""
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.execute("DELETE FROM presets_fts")
            rows = conn.execute(
                "SELECT id, name, tags, description, character FROM presets"
            ).fetchall()
            for r in rows:
                conn.execute(
                    "INSERT INTO presets_fts(rowid, name, tags, description, character) "
                    "VALUES (?,?,?,?,?)", r
                )
            conn.commit()
            log.info("[PresetDB] FTS index rebuilt: %d entries", len(rows))
        except Exception as e:
            log.warning("[PresetDB] FTS rebuild failed: %s", e)
        finally:
            conn.close()

    # ── Import/Export ───────────────────────────────────────────

    def export_presets(self, preset_ids: List[int]) -> List[dict]:
        """Export presets as portable dicts (for sharing)."""
        self.ensure_loaded()
        result = []
        for pid in preset_ids:
            p = self._cache_by_id.get(pid)
            if p:
                export = dict(p)
                export.pop("id", None)
                # Parse params back from JSON string
                if isinstance(export.get("params"), str):
                    try:
                        export["params"] = json.loads(export["params"])
                    except Exception:
                        pass
                result.append(export)
        return result

    def import_presets(self, presets: List[dict], source: str = "community") -> int:
        """Import presets from external source. Returns count imported."""
        for p in presets:
            p.setdefault("source", source)
        return self.add_presets_batch(presets)

    def to_universe_preset(self, row: dict) -> dict:
        """Convert a DB row to a UniversePreset-compatible dict."""
        params = row.get("params", "{}")
        if isinstance(params, str):
            try:
                params = json.loads(params)
            except Exception:
                params = {}
        tags = str(row.get("tags", "")).split(",") if row.get("tags") else []
        return {
            "name": row.get("name", ""),
            "synth": row.get("instrument", ""),
            "synth_display": row.get("instrument", "").upper(),
            "plugin_id": row.get("plugin_id", ""),
            "category": row.get("category", ""),
            "source": row.get("source", "factory"),
            "tags": [t.strip() for t in tags if t.strip()],
            "auto_tags": [],
            "params": params,
            "description": row.get("description", ""),
            "author": row.get("author", ""),
            "is_favorite": bool(row.get("is_favorite")),
            "file_path": row.get("factory_sample", ""),
            "timestamp": 0.0,
            "character": row.get("character", ""),
            "_db_id": row.get("id"),
        }


# ── Schema SQL ──────────────────────────────────────────────────

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS presets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    instrument TEXT NOT NULL,
    plugin_id TEXT NOT NULL,
    category TEXT,
    source TEXT DEFAULT 'factory',
    author TEXT DEFAULT 'ChronoScaleStudio',
    tags TEXT,
    description TEXT,
    character TEXT,
    is_favorite INTEGER DEFAULT 0,
    params TEXT NOT NULL,
    factory_sample TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    play_count INTEGER DEFAULT 0,
    UNIQUE(name, instrument, source)
);

CREATE INDEX IF NOT EXISTS idx_preset_instrument ON presets(instrument);
CREATE INDEX IF NOT EXISTS idx_preset_category ON presets(category);
CREATE INDEX IF NOT EXISTS idx_preset_source ON presets(source);
CREATE INDEX IF NOT EXISTS idx_preset_favorite ON presets(is_favorite);

CREATE VIRTUAL TABLE IF NOT EXISTS presets_fts USING fts5(
    name, tags, description, character,
    content='presets', content_rowid='id'
);
"""
