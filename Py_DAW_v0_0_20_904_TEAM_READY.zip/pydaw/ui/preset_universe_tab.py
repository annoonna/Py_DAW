# -*- coding: utf-8 -*-
"""Semantic Preset Universe — Cross-Plugin KI-powered Preset Browser.

The global Presets tab in the Browser panel. Aggregates ALL presets from
all plugin types (built-in AETERNA/Fusion/Sampler/DrumMachine + external
VST3/CLAP/LV2 + community presets) into one unified, searchable,
auto-tagged, KI-enhanced view.

Features no other DAW has:
- Cross-plugin semantic search ("warm 80s pad with reverb") across ALL synths
- Auto-tagging: parameter analysis → semantic tags (bright, dark, plucky…)
- Tag-Cloud navigation for visual discovery
- Similar-preset recommendations (parameter-distance)
- KI Preset Generation from text description (inline)
- Mini parameter visualization (ADSR / filter / oscillator icons)
- Preset history across sessions
- Drag-to-load: drag preset onto track to create instrument + load

Design:
- SAFE: All operations wrapped in try/except — never crashes the DAW
- Lazy: Scanning is deferred and cached — no startup delay
- Decoupled: Uses existing services (PresetBrowserService, preset_generator,
  community_preset_browser, plugins/registry) without modifying them

v0.0.20.881 — Semantic Preset Universe + Drag-to-Track + External Plugin Integration
"""

from __future__ import annotations

import json
import logging
import math
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from PyQt6.QtCore import Qt, QTimer, QMimeData, pyqtSignal, QSize, QThread
from PyQt6.QtGui import (
    QColor, QPainter, QPen, QBrush, QFont, QLinearGradient,
    QPainterPath, QDrag, QPixmap, QCursor,
)
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QListWidget, QListWidgetItem, QComboBox,
    QScrollArea, QFrame, QToolButton, QMenu, QInputDialog,
    QSizePolicy, QApplication, QTextEdit, QStackedWidget,
    QGridLayout, QAbstractItemView, QProgressBar,
)

log = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# Data Model — Unified Preset Entry
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class UniversePreset:
    """A preset from any source, enriched with semantic metadata."""
    name: str = ""
    synth: str = ""              # "aeterna"|"fusion"|"drum_machine"|"sampler"|"vst3"|…
    synth_display: str = ""      # Human-friendly synth name
    plugin_id: str = ""          # stable plugin identifier
    category: str = ""           # "Bass"|"Lead"|"Pad"|"Keys"|"Pluck"|"FX"|…
    source: str = "builtin"      # "builtin"|"factory"|"user"|"community"
    tags: List[str] = field(default_factory=list)
    auto_tags: List[str] = field(default_factory=list)   # KI-generated
    params: Dict[str, Any] = field(default_factory=dict)
    description: str = ""
    author: str = ""
    is_favorite: bool = False
    file_path: str = ""
    timestamp: float = 0.0
    # Computed
    character: str = ""          # "warm, dark, plucky" — from auto-analysis
    _sort_score: float = 0.0     # For relevance sorting


# ═══════════════════════════════════════════════════════════════════════════════
# Parameter Analysis — Auto-Tagging Engine
# ═══════════════════════════════════════════════════════════════════════════════

def _auto_tag_preset(params: Dict[str, Any]) -> Tuple[List[str], str]:
    """Analyze preset parameters → semantic tags + character string.

    Works with AETERNA/Fusion parameter dicts. Safe for empty/foreign params.
    Returns (tags, character_description).
    """
    tags: List[str] = []
    traits: List[str] = []

    if not params:
        return tags, ""

    try:
        # --- Oscillator analysis ---
        wf1 = int(params.get("osc1_waveform", -1))
        wf2 = int(params.get("osc2_waveform", -1))
        wf_names = {0: "sine", 1: "saw", 2: "square", 3: "triangle", 4: "noise", 5: "wavetable"}
        if wf1 in wf_names:
            tags.append(wf_names[wf1])
        if wf2 in wf_names and float(params.get("osc2_level", 0)) > 0.05:
            tags.append("dual-osc")

        # --- Filter analysis ---
        cutoff = float(params.get("filter_cutoff", 8000))
        reso = float(params.get("filter_resonance", 0))
        ftype = int(params.get("filter_type", 0))
        ftype_names = {0: "lowpass", 1: "highpass", 2: "bandpass", 3: "notch"}

        if ftype in ftype_names and ftype != 4:
            if cutoff < 2000:
                tags.append("dark")
                traits.append("dunkel")
            elif cutoff < 5000:
                tags.append("warm")
                traits.append("warm")
            elif cutoff > 12000:
                tags.append("bright")
                traits.append("hell")
            if reso > 0.5:
                tags.append("resonant")
                traits.append("resonant")

        # --- Envelope analysis → character ---
        atk = float(params.get("amp_attack", 0.01))
        dec = float(params.get("amp_decay", 0.3))
        sus = float(params.get("amp_sustain", 0.7))
        rel = float(params.get("amp_release", 0.5))

        if atk < 0.005 and sus < 0.1 and dec < 0.3:
            tags.extend(["plucky", "staccato"])
            traits.append("perkussiv")
        elif atk < 0.005 and sus > 0.7:
            tags.extend(["lead", "sustained"])
            traits.append("Lead")
        elif atk > 1.0 and rel > 2.0:
            tags.extend(["pad", "atmospheric"])
            traits.append("Fläche")
        elif atk < 0.01 and dec < 0.15:
            tags.extend(["stab", "percussive"])
            traits.append("Stab")
        elif atk > 0.3:
            tags.extend(["slow-attack", "swelling"])
            traits.append("schwellend")

        if rel > 3.0:
            tags.append("long-release")

        # --- Modulation ---
        lfo_amt = float(params.get("lfo1_amount", 0))
        if lfo_amt > 0.2:
            lfo_rate = float(params.get("lfo1_rate", 2))
            if lfo_rate < 1.0:
                tags.append("evolving")
                traits.append("moduliert")
            elif lfo_rate > 6:
                tags.append("vibrato")
            else:
                tags.append("modulated")
                traits.append("bewegt")

        # --- Unison / Width ---
        uv = int(params.get("unison_voices", 1))
        if uv >= 4:
            tags.extend(["fat", "wide"])
            traits.append("breit")
        elif uv > 1:
            tags.append("detuned")

        # --- FX ---
        if float(params.get("chorus_mix", 0)) > 0.1:
            tags.append("chorus")
        if float(params.get("reverb_mix", 0)) > 0.2:
            tags.extend(["reverb", "spacious"])
            traits.append("räumlich")
        if float(params.get("delay_mix", 0)) > 0.1:
            tags.append("delay")

        # --- Octave / Register ---
        oct1 = int(params.get("osc1_octave", 0))
        if oct1 <= -1:
            tags.append("bass")
        elif oct1 >= 1:
            tags.append("high")

        # --- Supersaw detection ---
        if wf1 == 1 and wf2 == 1 and uv >= 5:
            tags.append("supersaw")

    except Exception:
        pass

    # Deduplicate
    seen: Set[str] = set()
    unique_tags: List[str] = []
    for t in tags:
        if t not in seen:
            seen.add(t)
            unique_tags.append(t)

    character = ", ".join(traits) if traits else ""
    return unique_tags, character


def _preset_distance(params_a: Dict[str, Any], params_b: Dict[str, Any]) -> float:
    """Compute normalized distance between two preset parameter dicts.

    Lower = more similar. Returns 0.0–1.0 range.
    Safe for empty/mismatched dicts.
    """
    if not params_a or not params_b:
        return 1.0

    # Normalization ranges (same as preset_generator)
    ranges = {
        "filter_cutoff": (20, 20000), "filter_resonance": (0, 1),
        "amp_attack": (0.001, 10), "amp_decay": (0.01, 10),
        "amp_sustain": (0, 1), "amp_release": (0.01, 20),
        "osc1_waveform": (0, 5), "osc2_waveform": (0, 5),
        "osc2_level": (0, 1), "osc1_octave": (-2, 2), "osc2_octave": (-2, 2),
        "lfo1_rate": (0.01, 50), "lfo1_amount": (0, 1),
        "chorus_mix": (0, 1), "reverb_mix": (0, 1), "delay_mix": (0, 1),
        "unison_voices": (1, 16), "unison_detune": (0, 100),
        "filter_env_amount": (-1, 1),
    }

    total = 0.0
    count = 0
    try:
        for key, (lo, hi) in ranges.items():
            va = params_a.get(key)
            vb = params_b.get(key)
            if va is None or vb is None:
                continue
            span = hi - lo
            if span <= 0:
                continue
            diff = abs(float(va) - float(vb)) / span
            total += diff * diff
            count += 1
    except Exception:
        return 1.0

    if count == 0:
        return 1.0
    return min(1.0, math.sqrt(total / count))


# ═══════════════════════════════════════════════════════════════════════════════
# Semantic Search Engine
# ═══════════════════════════════════════════════════════════════════════════════

# Import the keyword map from preset_generator for semantic matching
try:
    from pydaw.services.preset_generator import _KEYWORD_MAP as _SEMANTIC_KEYWORDS
except ImportError:
    _SEMANTIC_KEYWORDS = {}


def _semantic_score(preset: UniversePreset, query: str) -> float:
    """Score a preset against a search query. Higher = better match.

    Matches against: name, tags, auto_tags, category, character, description.
    Also matches semantic keywords from the KI preset generator.
    """
    if not query:
        return 1.0  # No query = everything matches equally

    q_lower = query.lower()
    terms = q_lower.split()
    score = 0.0

    # Name match (strongest signal)
    name_lower = preset.name.lower()
    for t in terms:
        if t in name_lower:
            score += 10.0
            if name_lower.startswith(t):
                score += 5.0

    # Tag match
    all_tags = set(t.lower() for t in preset.tags + preset.auto_tags)
    for t in terms:
        if t in all_tags:
            score += 8.0

    # Category match
    if preset.category and any(t in preset.category.lower() for t in terms):
        score += 6.0

    # Character match
    if preset.character:
        for t in terms:
            if t in preset.character.lower():
                score += 5.0

    # Description match
    if preset.description:
        desc_lower = preset.description.lower()
        for t in terms:
            if t in desc_lower:
                score += 3.0

    # Synth match
    if any(t in preset.synth.lower() or t in preset.synth_display.lower() for t in terms):
        score += 4.0

    # Semantic keyword expansion — check if query terms are known KI keywords
    for t in terms:
        if t in _SEMANTIC_KEYWORDS:
            # This term maps to synth parameters — check if preset params match
            expected = _SEMANTIC_KEYWORDS[t]
            if preset.params:
                match_count = 0
                for pk, pv in expected.items():
                    actual = preset.params.get(pk)
                    if actual is not None:
                        try:
                            diff = abs(float(actual) - float(pv))
                            # Rough tolerance
                            if diff < max(abs(float(pv)) * 0.5, 1.0):
                                match_count += 1
                        except (ValueError, TypeError):
                            pass
                if match_count > 0:
                    score += match_count * 2.0

    return score


# ═══════════════════════════════════════════════════════════════════════════════
# Factory Presets — Built-in presets for AETERNA/Fusion
# ═══════════════════════════════════════════════════════════════════════════════

def _generate_factory_presets() -> List[UniversePreset]:
    """Generate factory presets for built-in instruments.

    Uses the preset_generator keyword map to create a curated set.
    """
    presets: List[UniversePreset] = []

    try:
        from pydaw.services.preset_generator import (
            description_to_preset, _AETERNA_PARAMS,
        )
    except ImportError:
        return presets

    # ══════════════════════════════════════════════════════════════════════
    # Helper: generate preset entries for a synth from (name, desc, kw) list
    # ══════════════════════════════════════════════════════════════════════
    def _add(entries, synth, synth_display, plugin_id, prefix="",
             extra_params=None):
        for entry in entries:
            name, desc, keywords = entry[0], entry[1], entry[2]
            try:
                result = description_to_preset(keywords, synth="aeterna",
                                               seed=hash(f"{prefix}{name}") & 0xFFFF)
                auto_tags, character = _auto_tag_preset(result.params)
                params = dict(result.params)
                # Merge extra params (e.g. sample paths)
                if extra_params:
                    params.update(extra_params)
                # Per-entry extra params (4th element if present)
                if len(entry) > 3 and isinstance(entry[3], dict):
                    params.update(entry[3])
                presets.append(UniversePreset(
                    name=name, synth=synth, synth_display=synth_display,
                    plugin_id=plugin_id,
                    category=_guess_category(auto_tags, name), source="factory",
                    tags=result.matched_keywords, auto_tags=auto_tags,
                    params=params, description=desc,
                    author="ChronoScaleStudio", character=character,
                ))
            except Exception:
                pass

    # ── AETERNA (20) ─────────────────────────────────────────────────────
    _add([
        ("Init", "Clean starting point", "basic"),
        ("Classic Pad", "Warm pad with reverb", "pad warm reverb"),
        ("80s Synthwave", "80er analog saw chorus", "80s analog chorus"),
        ("Fat Bass", "Fat bass with filter envelope", "bass fat dark"),
        ("Supersaw Lead", "Supersaw lead bright", "supersaw lead bright"),
        ("Pluck Bell", "Plucky bell clean", "plucky bell clean"),
        ("Dark Drone", "Dark drone evolving", "drone dark evolving"),
        ("String Ensemble", "String chorus wide", "string chorus wide"),
        ("Brass Stab", "Brass stab percussive", "brass stab"),
        ("Soft Keys", "Soft organ-like keys", "organ soft clean"),
        ("Ambient Texture", "Pad reverb evolving wide", "pad reverb evolving wide"),
        ("Wobble Bass", "Bass wobble dirty", "bass wobble dirty"),
        ("Acid Lead", "Lead bright resonant", "lead bright resonant"),
        ("Cinematic Swell", "Cinematic pad wide reverb", "cinematic pad wide"),
        ("Retro Arp", "Retro arp plucky chorus", "retro arp plucky"),
        ("Metallic Hit", "Metallic stab harsh", "metallic stab harsh"),
        ("Warm Analog", "Warm analog soft", "warm analog soft"),
        ("Digital Shimmer", "Digital bright wide delay", "digital bright wide delay"),
        ("Deep Sub", "Bass dark mono", "bass dark mono"),
        ("Evolving Texture", "Pad evolving vibrato wide", "pad evolving vibrato wide"),
    ], "aeterna", "AETERNA", "chrono.aeterna", "A_")

    # ── AETERNA 80s Underground (15) ─────────────────────────────────────
    _add([
        ("Kraftwerk Autobahn", "Motorik-Sequenz Düsseldorf 1974", "analog clean arp"),
        ("Tangerine Dream", "Berliner Schule kosmische Fläche", "pad evolving wide reverb analog"),
        ("YMO Technopolis", "Yellow Magic Orchestra Japan digital", "digital plucky arp clean"),
        ("Polivoks Soviet", "Russischer Analog-Synth dunkel aggressiv", "analog dark bass"),
        ("Miami Vice Pad", "Pastel-Neon Synthwave Fläche", "pad warm chorus reverb 80s"),
        ("WarGames Terminal", "WOPR Hacker-Terminal Bleep", "digital plucky clean"),
        ("Neuromancer ICE", "Gibson Cyberspace Interface kalt", "digital dark evolving delay"),
        ("BBS Modem Handshake", "Akustikkoppler Carrier-Tone", "digital bright"),
        ("Tron Lightcycle", "Neon-Grid Arpeggiated Bass", "bass arp bright digital"),
        ("Blade Runner Vangelis", "CS-80 Dystopie Fläche", "pad warm analog wide reverb cinematic"),
        ("Depeche Mode Stab", "Basildon Synth-Pop Stab", "stab analog clean chorus"),
        ("Italo Disco Bass", "München Giorgio Moroder Bass", "bass fat analog 80s"),
        ("Commodore SID", "C64 Chiptune Arpeggio", "digital plucky arp bright"),
        ("Akira Synthwave", "Tokyo Cyberpunk Neon Lead", "lead bright wide supersaw"),
        ("Stranger Things", "Juno-106 Horror Pad", "pad dark analog chorus evolving"),
    ], "aeterna", "AETERNA", "chrono.aeterna", "A80_")

    # ── Fusion (20) ──────────────────────────────────────────────────────
    _add([
        ("Fusion Init", "Clean Fusion starting point", "clean"),
        ("Modular Pad", "Evolving pad wide reverb", "pad evolving wide reverb"),
        ("FM Bass", "Bass dark aggressive", "bass dark"),
        ("Scrawl Lead", "Lead bright vibrato", "lead bright vibrato"),
        ("Grain Texture", "Atmospheric evolving pad", "pad evolving cinematic"),
        ("Fusion Pluck", "Digital plucky bell", "plucky bell digital"),
        ("Wavetable Sweep", "Bright evolving wide", "bright evolving wide"),
        ("Sub Growl", "Deep bass wobble dark", "bass wobble dark"),
        ("Hybrid Strings", "String chorus warm", "string chorus warm"),
        ("Glitch Stab", "Percussive digital stab", "stab digital"),
        ("Ambient Wash", "Pad reverb wide cinematic", "pad reverb wide cinematic"),
        ("FM Keys", "Clean keys organ", "organ clean"),
        ("Fusion Brass", "Brass warm analog", "brass warm analog"),
        ("Reso Sweep", "Lead resonant wobble", "lead resonant wobble"),
        ("Particle Pad", "Pad evolving delay wide", "pad evolving delay wide"),
        ("Noise Riser", "Bright noise evolving", "bright evolving"),
        ("Fusion Arp", "Plucky arp retro", "plucky arp retro"),
        ("Dark Matter", "Dark drone evolving reverb", "dark drone evolving reverb"),
        ("Crystal Bell", "Bell clean bright delay", "bell clean bright delay"),
        ("Fusion Sub", "Bass fat mono dark", "bass fat mono dark"),
    ], "fusion", "Fusion", "chrono.fusion", "F_")

    # ── Fusion 80s Underground (15) ──────────────────────────────────────
    _add([
        ("Komputer Musik", "Kraftwerk Computer World Sequenz", "digital arp clean"),
        ("Soviet Formanta", "Formanta UDS Drone dunkel", "drone dark analog evolving"),
        ("Japan Koto Synth", "Digitale Koto Kitaro-Style", "plucky bright delay"),
        ("East Berlin Mauer", "DDR Elektronik kalt industrial", "dark stab digital"),
        ("Hacker War Dialer", "Autodialer Modem-Sweep Sequenz", "digital arp bright"),
        ("Miami Hotline", "Outrun Neon Sunset Lead", "lead bright supersaw 80s"),
        ("Kraftwerk Roboter", "Vocoderartiger Roboter-Sound", "digital clean vibrato"),
        ("Cyberdeck Neural", "Neuromancer Neural Jack Interface", "digital evolving dark delay"),
        ("Fairlight CMI", "Sampling-Revolution 1982", "digital clean"),
        ("Oberheim OB-Xa", "Jump Van Halen Brass", "brass fat wide 80s"),
        ("Soviet Elektronika", "EM-25 Theremin-artig", "lead warm vibrato evolving"),
        ("Tokyo City Pop", "Japanischer City-Pop Glanz", "bright chorus warm 80s"),
        ("Amiga Tracker", "ProTracker MOD-Sound", "digital plucky arp"),
        ("Munich Disco Synth", "Moroder Sequencer-Bass", "bass analog arp 80s"),
        ("Unix Terminal Bell", "VAX/VMS System Alert", "bell digital clean bright"),
    ], "fusion", "Fusion", "chrono.fusion", "F80_")

    # ── BRRR Flutter Synth (20) ──────────────────────────────────────────
    _add([
        ("Flutter Init", "Clean BRRR starting point", "clean"),
        ("Flutter Pad", "Warm pad chorus wide", "warm pad chorus wide"),
        ("Flutter Bass", "Fat bass dark wobble", "bass fat dark wobble"),
        ("Flutter Lead", "Lead bright supersaw", "lead bright supersaw"),
        ("Flutter Ambient", "Drone evolving reverb", "drone evolving reverb wide"),
        ("Additive Wash", "Pad wide bright chorus", "pad wide bright chorus"),
        ("ZynSub Bass", "Deep sub bass dark", "bass dark mono"),
        ("PAD Shimmer", "Pad delay bright evolving", "pad delay bright evolving"),
        ("Flutter Stab", "Stab percussive clean", "stab clean"),
        ("Spectral Pad", "Pad cinematic wide reverb", "pad cinematic wide reverb"),
        ("Flutter Pluck", "Plucky digital clean", "plucky digital clean"),
        ("Additive Lead", "Lead warm analog", "lead warm analog"),
        ("Flutter Drone", "Dark drone wide", "dark drone wide"),
        ("ZynPad Brass", "Brass warm reverb", "brass warm reverb"),
        ("Noise Pad", "Pad evolving dirty", "pad evolving dirty"),
        ("Flutter Arp", "Arp plucky retro", "arp plucky retro"),
        ("Sub Rumble", "Bass dark fat", "bass dark fat"),
        ("Spectral Lead", "Lead digital bright wide", "lead digital bright wide"),
        ("Flutter Keys", "Organ soft clean", "organ soft clean"),
        ("Additive Texture", "Pad evolving vibrato wide", "pad evolving vibrato wide"),
    ], "brrr", "BRRR Flutter Synth", "chrono.brrr", "B_")

    # ── BRRR 80s Underground (15) ────────────────────────────────────────
    _add([
        ("DX7 Electric Piano", "Yamaha FM E-Piano Classic", "warm clean 80s"),
        ("Prophet-5 Pad", "Sequential Circuits Vintage", "pad warm analog wide"),
        ("Polivoks Filter", "Sowjet-Filter Resonanz-Sweep", "bass dark resonant analog"),
        ("Buchla Voltage", "West Coast Synthesis experimentell", "evolving bright"),
        ("Roland Jupiter-8", "Japanischer Analog-Klassiker", "pad warm fat wide 80s chorus"),
        ("Hacker Phreaker", "2600Hz Blue-Box Tone", "digital bright clean"),
        ("Synthwave Chase", "Outrun Verfolgungsjagd Bass", "bass fat dark 80s"),
        ("CPC Amstrad Beep", "Heimcomputer Sound 8-Bit", "digital plucky bright"),
        ("Korg M1 Universe", "Die Preset-Revolution 1988", "pad digital wide reverb"),
        ("Soviet Aelita", "Aelita Synthesizer Leningrad", "lead analog warm"),
        ("Matrix Mainframe", "Großrechner Tape-Echo Pad", "pad dark delay evolving"),
        ("Moog Taurus Pedal", "Taurus Bass-Pedal fett", "bass fat dark analog"),
        ("Japan PC-88 FM", "NEC PC-88 FM-Synthese", "digital plucky arp"),
        ("Detroit Techno Proto", "Belleville Three Prototyp", "bass dark stab"),
        ("Neon Grid Runner", "Wireframe Vector Arpeggio", "arp bright digital wide"),
    ], "brrr", "BRRR Flutter Synth", "chrono.brrr", "B80_")

    # ── BachOrgel (20 + 15 Kirchen = 35) ─────────────────────────────────
    _add([
        # Klassische Orgel-Register
        ("Prinzipal 8'", "Klares Prinzipal-Register", "organ clean bright"),
        ("Flöte 8'", "Sanfte Flötenstimme", "organ soft clean"),
        ("Gedackt 8'", "Gedecktes warmes Register", "organ warm dark"),
        ("Oktave 4'", "Helles Oktav-Register", "organ bright"),
        ("Quinte 2⅔'", "Quinten-Aliquot", "organ bright clean"),
        ("Mixtur IV", "Scharfe Mixtur", "organ bright fat wide"),
        ("Trompete 8'", "Zungen-Register Trompete", "brass warm"),
        ("Oboe 8'", "Zungen-Register Oboe", "organ warm vibrato"),
        ("Vox Humana", "Menschliche Stimme Register", "organ warm vibrato chorus"),
        ("Sesquialtera", "Terz-Quint Kombination", "organ bright wide"),
        ("Bourdon 16'", "Tiefes Bourdon-Register", "organ dark bass"),
        ("Celeste", "Schwebendes Celeste-Register", "organ warm chorus wide"),
        ("Tremulant", "Register mit Tremolo", "organ warm vibrato evolving"),
        ("Schwellwerk", "Schwellwerk zart", "organ soft warm"),
        ("Tutti Full", "Alle Register gezogen", "organ fat wide bright"),
        ("Regal 8'", "Kleines Regal zart", "organ soft"),
        ("Cornet V", "Fünffach-Cornet solo", "organ bright"),
        ("Fagott 16'", "Tiefes Fagott Register", "organ dark bass warm"),
        ("Schalmei", "Scharfes Schalmei-Register", "organ bright"),
        ("Unda Maris", "Schwebendes Unda Maris", "organ warm chorus evolving"),
        # ── Gottesdienst & Kirchenmusik (15) ──
        ("Gottesdienst Einzug", "Feierlicher Einzug in die Kirche", "organ warm reverb wide"),
        ("Gottesdienst Choral", "Ruhiger vierstimmiger Choral", "organ clean warm"),
        ("Gottesdienst Lied", "Gemeindegesang Begleitung", "organ soft warm"),
        ("Gottesdienst Meditation", "Stille Meditation nach Predigt", "organ soft dark evolving reverb"),
        ("Gottesdienst Auszug", "Festlicher Auszug Postludium", "organ bright fat wide reverb"),
        ("Kammermusik Continuo", "Generalbass-Continuo 8'+4'", "organ clean warm"),
        ("Kammermusik Trio-Sonate", "Bach Trio-Sonate Register", "organ clean bright"),
        ("Kammermusik Choralsuite", "Choralvorspiel Register", "organ warm clean"),
        ("Kammermusik Fuge", "Register für Fugenspiel", "organ bright clean"),
        ("Kammermusik Pastorale", "Hirtenmusik zart", "organ soft warm chorus"),
        ("Hofmusik Festlich", "Höfische Festmusik mit Trompete", "organ brass bright fat wide"),
        ("Hofmusik Menuett", "Elegantes Menuett-Register", "organ clean soft"),
        ("Hofmusik Intrade", "Feierliche Intrade", "organ brass bright reverb"),
        ("Hofmusik Galant", "Galanter Stil zart", "organ soft clean chorus"),
        ("Hofmusik Tafelmusik", "Tafelmusik leicht und hell", "organ bright clean"),
    ], "bachorgel", "BachOrgel", "chrono.bach_orgel", "O_")

    # ── BachOrgel 80s Elektronische Orgel (10) ───────────────────────────
    _add([
        ("Wersi Galaxis", "Wersi Heimorgel 80s Disco", "organ warm chorus 80s"),
        ("Hammond B3 Prog", "Progressive Rock Orgel", "organ warm fat"),
        ("Farfisa Compact", "60s-80s Combo-Orgel", "organ bright clean"),
        ("Vox Continental", "British Invasion Orgel", "organ bright clean"),
        ("Eminent 310U", "Jean-Michel Jarre Orgel", "organ wide chorus 80s evolving"),
        ("Solina Strings", "String Ensemble Machine", "string warm chorus wide 80s"),
        ("Elka Synthex Organ", "Italienische Synthese-Orgel", "organ warm analog chorus"),
        ("Korg CX-3 Mod", "Modifizierte Korg Orgel", "organ warm vibrato"),
        ("DDR Vermona", "VEB Klingenthal Formation", "organ analog warm"),
        ("Bontempi Hit", "Heimorgel-Kitsch-Charme", "organ digital clean bright"),
    ], "bachorgel", "BachOrgel", "chrono.bach_orgel", "O80_")

    # ── Pro Drum Machine (20) ────────────────────────────────────────────
    _add([
        ("808 Kit", "Klassisches TR-808 Kit", "bass stab",
         {"__factory_sample": "drums/kick_808.wav"}),
        ("909 Kit", "Klassisches TR-909 Kit", "stab clean",
         {"__factory_sample": "drums/kick_909.wav"}),
        ("Acoustic Kit", "Akustisches Drum Kit", "clean",
         {"__factory_sample": "drums/kick_acoustic.wav"}),
        ("Electronic Kit", "Elektronisches Kit", "digital stab delay",
         {"__factory_sample": "drums/kick_909.wav"}),
        ("Lo-Fi Kit", "Lofi warm dirty Drums", "warm dirty",
         {"__factory_sample": "drums/snare_808.wav"}),
        ("Cinematic Hits", "Cinematic Impact Drums", "cinematic stab reverb",
         {"__factory_sample": "drums/tom_low.wav"}),
        ("Trap Kit", "Modern Trap Hi-Hats", "bright stab",
         {"__factory_sample": "drums/hihat_closed.wav"}),
        ("Breakbeat Kit", "Jungle/DnB Breaks", "stab bright",
         {"__factory_sample": "drums/snare_909.wav"}),
        ("Ambient Percussion", "Atmosphärische Perkussion", "pad reverb evolving",
         {"__factory_sample": "drums/rim.wav"}),
        ("Industrial Kit", "Industrielle harte Drums", "stab harsh dark",
         {"__factory_sample": "drums/clap.wav"}),
        ("Jazz Brushes", "Jazz Besen Kit", "soft clean warm",
         {"__factory_sample": "drums/snare_acoustic.wav"}),
        ("Afrobeat Kit", "Westafrikanische Perkussion", "warm clean",
         {"__factory_sample": "drums/tom_high.wav"}),
        ("Latin Kit", "Conga Bongo Timbales", "warm bright",
         {"__factory_sample": "drums/tom_mid.wav"}),
        ("Minimal Kit", "Minimal Techno Drums", "clean stab",
         {"__factory_sample": "drums/kick_808.wav"}),
        ("Glitch Kit", "Glitch-Percussion digital", "digital stab",
         {"__factory_sample": "drums/hihat_closed.wav"}),
        ("Orchestral Kit", "Orchestrale Pauken Becken", "reverb cinematic",
         {"__factory_sample": "drums/tom_low.wav"}),
        ("Dub Kit", "Dub Reggae Drums", "warm reverb delay dark",
         {"__factory_sample": "drums/kick_808.wav"}),
        ("House Kit", "Classic House Drums", "stab clean",
         {"__factory_sample": "drums/kick_909.wav"}),
        ("Finger Drums", "MPD-Style Pads", "clean",
         {"__factory_sample": "drums/clap.wav"}),
        ("Foley Kit", "Found-Sound Perkussion", "dark evolving",
         {"__factory_sample": "drums/rim.wav"}),
    ], "drum_machine", "Drum Machine", "chrono.pro_drum_machine", "D_")

    # ── Drum Machine 80s Underground (15) ────────────────────────────────
    _add([
        ("LinnDrum Classic", "Prince / Human League Drums", "clean stab"),
        ("Simmons SDS-V", "Hexagonale E-Drums 1981", "stab bright digital"),
        ("Oberheim DMX", "Hip-Hop Foundation Beat", "stab clean"),
        ("CR-78 CompuRhythm", "Roland Ur-Drumcomputer", "soft clean"),
        ("808 Cowbell", "More Cowbell! Klassisch", "bright stab"),
        ("909 Acid House", "Chicago Acid Warehouse", "stab bright"),
        ("Kraftwerk Pocket", "Taschenrechner Perkussion", "digital stab clean"),
        ("Soviet Ritm-2", "Sowjetischer Drumcomputer", "stab dark"),
        ("Linn 9000 Breaks", "Sampling-Drum Revolution", "stab clean"),
        ("Casio RZ-1 Lo-Fi", "Budget-Sampler Drums", "stab warm"),
        ("Fairlight Page R", "CMI Sampling Drums 1983", "stab clean"),
        ("E-mu Drumulator", "Affordable Sampling 1983", "stab clean"),
        ("Korg KPR-77", "Japanischer Analog-Beat", "stab warm"),
        ("Alesis HR-16", "Digital Perfekt 1987", "stab bright clean"),
        ("Syndrum Disco", "Synthetische Disco-Toms", "stab bright"),
    ], "drum_machine", "Drum Machine", "chrono.pro_drum_machine", "D80_",
       extra_params={"__factory_sample": "drums/kick_808.wav"})

    # ── Pro Audio Sampler (20) ───────────────────────────────────────────
    _add([
        ("Clean Piano", "Klarer Klavier-Sampler", "clean soft",
         {"__factory_sample": "melodic/pluck_A4.wav"}),
        ("Electric Piano", "E-Piano mit Chorus", "warm chorus",
         {"__factory_sample": "melodic/bell_C5.wav"}),
        ("Ambient Textures", "Atmosphärische Texturen", "pad reverb evolving",
         {"__factory_sample": "melodic/pad_C4.wav"}),
        ("Vocal Chop", "Vocal-Schnipsel Instrument", "plucky clean",
         {"__factory_sample": "melodic/pluck_C5.wav"}),
        ("Orchestral Strings", "Orchestrale Streicher", "string warm wide",
         {"__factory_sample": "melodic/string_A3.wav"}),
        ("Choir Sustain", "Chor-Fläche legato", "pad warm wide reverb",
         {"__factory_sample": "melodic/pad_E4.wav"}),
        ("Marimba", "Holz-Marimba Sampler", "plucky clean",
         {"__factory_sample": "melodic/pluck_A4.wav"}),
        ("Vibraphone", "Jazz-Vibraphone", "plucky warm chorus",
         {"__factory_sample": "melodic/bell_E5.wav"}),
        ("Harp Glissando", "Harfe Glissando", "plucky bright clean",
         {"__factory_sample": "melodic/pluck_E5.wav"}),
        ("Cello Solo", "Solo-Cello expressiv", "string warm vibrato",
         {"__factory_sample": "melodic/string_D4.wav"}),
        ("Flute Ensemble", "Flöten-Ensemble", "soft warm reverb",
         {"__factory_sample": "melodic/pad_G4.wav"}),
        ("Organ Samples", "Gesampelte Kirchenorgel", "organ warm reverb",
         {"__factory_sample": "melodic/organ_C4.wav"}),
        ("Guitar Nylon", "Nylon-Gitarre clean", "plucky warm clean",
         {"__factory_sample": "melodic/pluck_A4.wav"}),
        ("Guitar Steel", "Steel-String Gitarre", "plucky bright",
         {"__factory_sample": "melodic/pluck_E5.wav"}),
        ("Bass Upright", "Kontrabass gezupft", "bass warm clean",
         {"__factory_sample": "melodic/bass_sub_A1.wav"}),
        ("Kalimba", "Afrikanische Kalimba", "plucky bell clean",
         {"__factory_sample": "melodic/bell_C5.wav"}),
        ("Glockenspiel", "Glockenspiel hell", "bell bright clean",
         {"__factory_sample": "melodic/bell_E5.wav"}),
        ("Tabla", "Indische Tabla", "warm clean",
         {"__factory_sample": "drums/tom_high.wav"}),
        ("Wind Chimes", "Windspiel atmosphärisch", "bright evolving reverb",
         {"__factory_sample": "melodic/bell_E5.wav"}),
        ("Synth Sampler", "Gesampelte Synth-Sounds", "bright digital wide",
         {"__factory_sample": "melodic/lead_saw_A4.wav"}),
    ], "sampler", "Sampler", "chrono.pro_audio_sampler", "S_")

    # ── Sampler 80s Underground (15) ─────────────────────────────────────
    _add([
        ("Fairlight Orch Hit", "DER Orchester-Hit 1982", "stab bright reverb"),
        ("Emulator Choir", "E-mu Emulator Chor 1982", "pad warm wide reverb"),
        ("Synclavier Brass", "Digital Brass Section NED", "brass bright wide"),
        ("Mellotron Strings", "Tape-Replay Streicher", "string warm dark"),
        ("PPG Waveterm", "Wolfgang Palm Wavetable", "digital evolving wide"),
        ("Akai S900 Loop", "Sampler-Revolution 1986", "clean"),
        ("Soviet Tape Echo", "Bandecho Magnetofon", "warm delay dark"),
        ("Japan Shakuhachi", "Digitale Bambusflöte", "soft warm reverb"),
        ("Vinyl Crackle Pad", "Schallplatten-Atmosphäre", "pad warm dark"),
        ("VHS Tape Warble", "Videokassetten-Wobble", "pad warm chorus dark"),
        ("Dial-Up Connect", "Internet-Einwahl 1988", "digital bright"),
        ("CRT Monitor Hum", "Röhrenmonitor Summen", "drone dark"),
        ("Floppy Drive Seek", "Disketten-Stepper-Motor", "digital stab"),
        ("Dot Matrix Print", "Nadeldrucker Rhythmus", "stab clean"),
        ("Arcade Coin Drop", "Spielhalle Münzeinwurf", "plucky bright clean"),
    ], "sampler", "Sampler", "chrono.pro_audio_sampler", "S80_",
       extra_params={"__factory_sample": "melodic/pad_C4.wav"})

    # ── Advanced Sampler (20) ────────────────────────────────────────────
    _add([
        ("Multi-Zone Piano", "Piano mit Velocity-Zonen", "clean soft",
         {"__factory_sample": "melodic/pluck_A4.wav"}),
        ("Round-Robin Strings", "Streicher mit Round-Robin", "string warm",
         {"__factory_sample": "melodic/string_A3.wav"}),
        ("Layered Pad", "Geschichteter Pad-Sound", "pad wide reverb",
         {"__factory_sample": "melodic/pad_C4.wav"}),
        ("Percussion Kit", "Perkussion Multi-Sample", "clean",
         {"__factory_sample": "drums/tom_mid.wav"}),
        ("Brass Section", "Bläser-Sektion geschichtet", "brass warm wide",
         {"__factory_sample": "melodic/lead_saw_A4.wav"}),
        ("Woodwind Ensemble", "Holzbläser Ensemble", "soft warm",
         {"__factory_sample": "melodic/pad_G4.wav"}),
        ("Grand Piano Velocity", "Konzertflügel 5 Layers", "clean soft",
         {"__factory_sample": "melodic/pluck_C5.wav"}),
        ("Electric Organ", "Hammond-artiger Sound", "organ warm chorus",
         {"__factory_sample": "melodic/organ_C4.wav"}),
        ("Choir Vowels", "Chor A-E-I-O-U Morphing", "pad warm wide",
         {"__factory_sample": "melodic/pad_E4.wav"}),
        ("Ethnic Strings", "Ethnische Saiten Sitar", "plucky warm",
         {"__factory_sample": "melodic/pluck_E5.wav"}),
        ("Mallet Ensemble", "Mallets Marimba Vibes", "plucky clean",
         {"__factory_sample": "melodic/bell_C5.wav"}),
        ("Textural Bows", "Gestrichene Texturen", "string dark evolving",
         {"__factory_sample": "melodic/string_D4.wav"}),
        ("Drum Layers", "Geschichtete Drum-Hits", "stab clean",
         {"__factory_sample": "drums/snare_909.wav"}),
        ("Synth Layers", "Multi-Layer Synth Pad", "pad wide chorus",
         {"__factory_sample": "melodic/pad_C4.wav"}),
        ("Ambient Keys", "Atmosphärische Keys", "pad soft reverb",
         {"__factory_sample": "melodic/bell_E5.wav"}),
        ("Pluck Ensemble", "Geschichtetes Pluck-Ensemble", "plucky bright",
         {"__factory_sample": "melodic/pluck_A4.wav"}),
        ("Bass Layers", "Multi-Velocity Bass", "bass fat warm",
         {"__factory_sample": "melodic/bass_saw_A1.wav"}),
        ("Choir Legato", "Legato-Chor mit Crossfade", "pad warm wide reverb",
         {"__factory_sample": "melodic/pad_E4.wav"}),
        ("FX Risers", "Impact und Riser Samples", "bright evolving",
         {"__factory_sample": "melodic/lead_square_A4.wav"}),
        ("Cinematic Textures", "Filmmusik Texturen", "cinematic pad evolving reverb",
         {"__factory_sample": "melodic/pad_G4.wav"}),
    ], "sampler", "Advanced Sampler", "chrono.advanced_sampler", "AS_")

    # ── Advanced Sampler 80s Underground (15) ────────────────────────────
    _add([
        ("Synclavier Multi", "NED Multi-Layer Digital", "digital clean wide"),
        ("Fairlight Page R Kit", "CMI Drum-Sampling Layers", "stab clean"),
        ("Emulator II Stack", "E-mu Stack Pad+Strings", "pad string warm wide"),
        ("Kurzweil K250", "Stevie Wonder Piano Layers", "clean soft warm"),
        ("Ensoniq Mirage", "Budget-Sampler Texturen", "pad warm"),
        ("PPG Wave 2.3", "Wavetable Multi-Zone", "digital evolving wide"),
        ("Roland S-50 Pad", "Roland Sampler Fläche", "pad warm chorus 80s"),
        ("Akai S1000 Multi", "Profi-Sampler Multi-Zone", "clean"),
        ("Casio FZ-1 Crunch", "16-Bit Sampling Budget", "digital warm"),
        ("Soviet Sampler DIY", "Selbstbau-Sampler UdSSR", "dark warm"),
        ("Japan Taiko Layer", "Geschichtete Taiko-Drums", "stab wide reverb"),
        ("Clavinet D6 Funk", "Stevie Wonder Clavinet", "plucky warm"),
        ("Electric Sitar", "Coral Sitar Sampling", "plucky bright delay"),
        ("Vocoder Robot", "Korg VC-10 Vocoder-Pads", "pad digital wide"),
        ("Mainframe Data", "IBM 3270 Terminal Sound", "digital bright clean"),
    ], "sampler", "Advanced Sampler", "chrono.advanced_sampler", "AS80_",
       extra_params={"__factory_sample": "melodic/lead_saw_A4.wav"})

    return presets


def _guess_category(tags: List[str], name: str = "") -> str:
    """Guess preset category from tags and name."""
    tag_set = set(t.lower() for t in tags)
    name_lower = name.lower()

    if "bass" in tag_set or "bass" in name_lower:
        return "Bass"
    if "drums" in tag_set or "drum" in name_lower or "kit" in name_lower:
        return "Drums"
    if "lead" in tag_set or "lead" in name_lower:
        return "Lead"
    if "pad" in tag_set or "atmospheric" in tag_set or "pad" in name_lower:
        return "Pad"
    if "plucky" in tag_set or "bell" in tag_set or "pluck" in name_lower:
        return "Pluck"
    if "stab" in tag_set or "percussive" in tag_set:
        return "Stab"
    if any(t in tag_set for t in ("string", "brass", "organ")):
        return "Keys"
    if "drone" in tag_set or "evolving" in tag_set or "ambient" in name_lower:
        return "Ambient"
    if "arp" in name_lower:
        return "Arp"
    return "Other"


# ═══════════════════════════════════════════════════════════════════════════════
# History Manager — Recently used presets
# ═══════════════════════════════════════════════════════════════════════════════

class _PresetHistory:
    """Persists recently used/browsed presets across sessions."""

    _MAX = 50

    def __init__(self):
        self._entries: List[Dict[str, Any]] = []
        self._load()

    def _path(self) -> Path:
        d = Path.home() / ".cache" / "ChronoScaleStudio"
        try:
            d.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return d / "preset_universe_history.json"

    def _load(self) -> None:
        try:
            p = self._path()
            if p.is_file():
                data = json.loads(p.read_text(encoding="utf-8"))
                if isinstance(data, list):
                    self._entries = data[:self._MAX]
        except Exception:
            pass

    def _save(self) -> None:
        try:
            self._path().write_text(
                json.dumps(self._entries[:self._MAX], indent=1, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception:
            pass

    def add(self, preset_name: str, synth: str, plugin_id: str) -> None:
        entry = {
            "name": str(preset_name),
            "synth": str(synth),
            "plugin_id": str(plugin_id),
            "ts": time.time(),
        }
        # Remove duplicate
        self._entries = [e for e in self._entries
                         if not (e.get("name") == preset_name
                                 and e.get("plugin_id") == plugin_id)]
        self._entries.insert(0, entry)
        self._entries = self._entries[:self._MAX]
        self._save()

    def get_recent_names(self, limit: int = 20) -> List[Tuple[str, str]]:
        """Returns [(name, synth), ...]"""
        result = []
        for e in self._entries[:limit]:
            result.append((str(e.get("name", "")), str(e.get("synth", ""))))
        return result


# ═══════════════════════════════════════════════════════════════════════════════
# Mini Parameter Visualization Widget
# ═══════════════════════════════════════════════════════════════════════════════

class _MiniADSRWidget(QWidget):
    """Tiny ADSR envelope visualization (48×24 px)."""

    def __init__(self, atk: float = 0.01, dec: float = 0.3,
                 sus: float = 0.7, rel: float = 0.5, parent=None):
        super().__init__(parent)
        self._a = atk
        self._d = dec
        self._s = sus
        self._r = rel
        self.setFixedSize(48, 24)

    def paintEvent(self, event) -> None:  # noqa: N802
        try:
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            w, h = self.width() - 2, self.height() - 4
            x0, y0 = 1, 2

            # Normalize times to visual space
            total_t = self._a + self._d + 0.3 + self._r  # sustain gets fixed width
            if total_t <= 0:
                total_t = 1.0
            scale = w / total_t

            xa = x0 + self._a * scale
            xd = xa + self._d * scale
            xs = xd + 0.3 * scale
            xr = xs + self._r * scale

            pen = QPen(QColor("#7bd389"), 1.5)
            p.setPen(pen)

            # A: 0→peak
            p.drawLine(int(x0), int(y0 + h), int(xa), int(y0))
            # D: peak→sustain
            sy = y0 + h * (1.0 - self._s)
            p.drawLine(int(xa), int(y0), int(xd), int(sy))
            # S: sustain hold
            p.drawLine(int(xd), int(sy), int(xs), int(sy))
            # R: sustain→0
            p.drawLine(int(xs), int(sy), int(min(xr, x0 + w)), int(y0 + h))

            p.end()
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════════════════════
# Tag Cloud Widget
# ═══════════════════════════════════════════════════════════════════════════════

class _TagCloudWidget(QWidget):
    """Interactive tag cloud for visual preset discovery."""

    tag_clicked = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._tags: Dict[str, int] = {}  # tag → count
        self._buttons: List[QPushButton] = []
        self._active_tag: str = ""
        self._layout = None
        self._build_ui()

    def _build_ui(self) -> None:
        self._flow_widget = QWidget()
        self._flow_layout = _FlowLayout(self._flow_widget)
        self._flow_layout.setSpacing(3)
        self._flow_layout.setContentsMargins(2, 2, 2, 2)

        scroll = QScrollArea()
        scroll.setWidget(self._flow_widget)
        scroll.setWidgetResizable(True)
        scroll.setMaximumHeight(60)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("QScrollArea { background: transparent; }")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(scroll)

    def set_tags(self, tags: Dict[str, int]) -> None:
        """Update the tag cloud with tag → count mapping."""
        try:
            self._tags = dict(tags)
            # Clear old buttons
            for btn in self._buttons:
                try:
                    btn.deleteLater()
                except Exception:
                    pass
            self._buttons.clear()

            if not tags:
                return

            # Sort by count, take top 30
            sorted_tags = sorted(tags.items(), key=lambda x: -x[1])[:30]
            max_count = max(c for _, c in sorted_tags) if sorted_tags else 1

            for tag, count in sorted_tags:
                btn = QPushButton(f"{tag} ({count})")
                # Scale font size by frequency
                rel = count / max_count if max_count > 0 else 0.5
                font_size = max(8, min(13, int(8 + rel * 5)))
                is_active = (tag == self._active_tag)
                bg = "#2d5a27" if is_active else "#333"
                fg = "#7bd389" if is_active else "#aaa"
                border = "1px solid #7bd389" if is_active else "1px solid #555"
                btn.setStyleSheet(
                    f"QPushButton {{ font-size: {font_size}px; padding: 1px 5px; "
                    f"border-radius: 8px; background: {bg}; color: {fg}; "
                    f"border: {border}; }}"
                    f"QPushButton:hover {{ background: #3a3a3a; color: #7bd389; }}"
                )
                btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
                btn.setFixedHeight(20)
                btn.clicked.connect(lambda checked, t=tag: self._on_tag_click(t))
                self._flow_layout.addWidget(btn)
                self._buttons.append(btn)

        except Exception:
            pass

    def _on_tag_click(self, tag: str) -> None:
        if self._active_tag == tag:
            self._active_tag = ""
        else:
            self._active_tag = tag
        self.set_tags(self._tags)  # Refresh highlight
        try:
            self.tag_clicked.emit(self._active_tag)
        except Exception:
            pass

    def clear_active(self) -> None:
        self._active_tag = ""
        self.set_tags(self._tags)


class _FlowLayout(QVBoxLayout):
    """Simplified flow layout using wrapping QHBoxLayouts.

    Not a true QLayout subclass (complex, error-prone in PyQt6).
    Instead we use nested HBox rows with word-wrap simulation.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._pending: List[QWidget] = []
        self._rows: List[QHBoxLayout] = []
        self.setSpacing(2)
        self.setContentsMargins(2, 2, 2, 2)

    def addWidget(self, widget: QWidget) -> None:  # noqa: N802
        """Add widget to flow — creates new rows as needed."""
        if not self._rows:
            row = QHBoxLayout()
            row.setSpacing(3)
            row.setContentsMargins(0, 0, 0, 0)
            row.addStretch(1)
            super().addLayout(row)
            self._rows.append(row)

        # Always add to last row (before stretch)
        last_row = self._rows[-1]
        count = last_row.count()
        if count > 12:  # Start new row after ~12 tags
            row = QHBoxLayout()
            row.setSpacing(3)
            row.setContentsMargins(0, 0, 0, 0)
            row.addStretch(1)
            super().addLayout(row)
            self._rows.append(row)
            last_row = row

        # Insert before the stretch
        last_row.insertWidget(last_row.count() - 1, widget)


# ═══════════════════════════════════════════════════════════════════════════════
# Preset Card Widget — Rich list item with mini visualization
# ═══════════════════════════════════════════════════════════════════════════════

class _PresetCardWidget(QFrame):
    """Rich preset card for the list — shows name, synth, tags, mini ADSR."""

    clicked = pyqtSignal()
    double_clicked = pyqtSignal()
    fav_toggled = pyqtSignal()

    def __init__(self, preset: UniversePreset, parent=None):
        super().__init__(parent)
        self.preset = preset
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.setStyleSheet(
            "QFrame { background: #252525; border: 1px solid #3a3a3a; "
            "border-radius: 4px; padding: 3px; }"
            "QFrame:hover { background: #2d2d2d; border-color: #555; }"
        )
        self._selected = False
        self._build_ui()

    def _build_ui(self) -> None:
        layout = QHBoxLayout(self)
        layout.setContentsMargins(4, 2, 4, 2)
        layout.setSpacing(6)

        # Favorite star
        fav_btn = QPushButton("⭐" if self.preset.is_favorite else "☆")
        fav_btn.setFixedSize(20, 20)
        fav_btn.setStyleSheet(
            "QPushButton { border: none; font-size: 12px; background: transparent; }"
        )
        fav_btn.clicked.connect(lambda: self.fav_toggled.emit())
        layout.addWidget(fav_btn)

        # Info column
        info_col = QVBoxLayout()
        info_col.setSpacing(0)
        info_col.setContentsMargins(0, 0, 0, 0)

        # Name + Synth row
        name_row = QHBoxLayout()
        name_row.setSpacing(4)
        name_lbl = QLabel(self.preset.name)
        name_lbl.setStyleSheet("font-weight: bold; font-size: 11px; color: #eee;")
        name_row.addWidget(name_lbl)

        synth_lbl = QLabel(self.preset.synth_display or self.preset.synth)
        synth_lbl.setStyleSheet(
            "font-size: 9px; color: #888; background: #1a1a1a; "
            "padding: 0 4px; border-radius: 3px;"
        )
        name_row.addWidget(synth_lbl)

        if self.preset.category:
            cat_lbl = QLabel(self.preset.category)
            cat_lbl.setStyleSheet(
                "font-size: 9px; color: #7bd389; background: #1e3a1e; "
                "padding: 0 4px; border-radius: 3px;"
            )
            name_row.addWidget(cat_lbl)

        name_row.addStretch(1)
        info_col.addLayout(name_row)

        # Tags row
        all_tags = self.preset.tags + self.preset.auto_tags
        if all_tags:
            tag_str = " · ".join(all_tags[:6])
            tag_lbl = QLabel(tag_str)
            tag_lbl.setStyleSheet("font-size: 9px; color: #777;")
            info_col.addWidget(tag_lbl)

        layout.addLayout(info_col, stretch=1)

        # Mini ADSR visualization
        if self.preset.params:
            try:
                adsr = _MiniADSRWidget(
                    atk=float(self.preset.params.get("amp_attack", 0.01)),
                    dec=float(self.preset.params.get("amp_decay", 0.3)),
                    sus=float(self.preset.params.get("amp_sustain", 0.7)),
                    rel=float(self.preset.params.get("amp_release", 0.5)),
                )
                layout.addWidget(adsr)
            except Exception:
                pass

    def set_selected(self, selected: bool) -> None:
        self._selected = selected
        if selected:
            self.setStyleSheet(
                "QFrame { background: #37474f; border: 1px solid #7bd389; "
                "border-radius: 4px; padding: 3px; }"
            )
        else:
            self.setStyleSheet(
                "QFrame { background: #252525; border: 1px solid #3a3a3a; "
                "border-radius: 4px; padding: 3px; }"
                "QFrame:hover { background: #2d2d2d; border-color: #555; }"
            )

    def mousePressEvent(self, event) -> None:  # noqa: N802
        try:
            self.clicked.emit()
            # Store drag start position
            if event.button() == Qt.MouseButton.LeftButton:
                self._drag_start = event.position().toPoint()
        except Exception:
            pass
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        """Drag-to-Track: drag preset onto arranger/device panel."""
        try:
            if not (event.buttons() & Qt.MouseButton.LeftButton):
                return
            if not hasattr(self, '_drag_start'):
                return
            dist = (event.position().toPoint() - self._drag_start).manhattanLength()
            if dist < 10:
                return

            p = self.preset
            # Determine device kind from plugin_id
            pid = p.plugin_id or ""
            is_instrument = pid.startswith("chrono.") and pid not in (
                "chrono.midi_fx",
            )
            # For external plugins check the ext flag
            if pid.startswith("ext."):
                is_instrument = bool(getattr(p, '_is_ext_instrument', False))

            kind = "instrument" if is_instrument else "audio_fx"

            # Build MIME payload matching effects_browser / plugins_browser format
            payload = {
                "kind": kind,
                "device_kind": kind,
                "plugin_id": pid,
                "name": p.name,
                "params": dict(p.params) if isinstance(p.params, dict) else {},
            }
            # Include ext params for external plugins
            if pid.startswith("ext."):
                ext_kind = ""
                ext_id = pid
                if ":" in pid:
                    parts = pid.split(":", 1)
                    ext_kind = parts[0].replace("ext.", "")
                    ext_id = parts[1]
                payload["__ext_kind"] = ext_kind
                payload["__ext_id"] = ext_id
                payload["__ext_ref"] = ext_id
                payload["__ext_path"] = p.file_path or ext_id
                payload["__ext_is_instrument"] = is_instrument

            # Carry preset params for post-load application
            if p.params:
                payload["__preset_params"] = p.params
            if p.source:
                payload["__preset_source"] = p.source

            md = QMimeData()
            md.setData(
                "application/x-pydaw-plugin",
                json.dumps(payload).encode("utf-8"),
            )
            drag = QDrag(self)
            drag.setMimeData(md)

            # Create drag pixmap
            pm = QPixmap(120, 28)
            pm.fill(QColor("#2d5a27"))
            painter = QPainter(pm)
            painter.setPen(QColor("#7bd389"))
            painter.setFont(QFont("sans-serif", 9))
            icon = "🎹" if is_instrument else "🎚️"
            painter.drawText(4, 18, f"{icon} {p.name[:18]}")
            painter.end()
            drag.setPixmap(pm)

            drag.exec(Qt.DropAction.CopyAction)
        except Exception:
            pass

    def mouseDoubleClickEvent(self, event) -> None:  # noqa: N802
        try:
            self.double_clicked.emit()
        except Exception:
            pass
        super().mouseDoubleClickEvent(event)


# ═══════════════════════════════════════════════════════════════════════════════
# Main Widget — Semantic Preset Universe Tab
# ═══════════════════════════════════════════════════════════════════════════════

class PresetUniverseTab(QWidget):
    """The global Presets tab for the Browser panel.

    Aggregates ALL presets, provides semantic search, tag cloud,
    KI generation, similar-preset recommendations, and drag-to-load.

    Signals:
        preset_load_requested(dict): Emitted when user wants to load a preset.
            Dict contains: {"plugin_id": ..., "name": ..., "params": ..., "synth": ...}
    """

    preset_load_requested = pyqtSignal(dict)

    def __init__(
        self,
        on_add_instrument: Optional[Callable] = None,
        get_add_scope: Optional[Callable] = None,
        parent: Optional[QWidget] = None,
    ):
        super().__init__(parent)
        self._on_add_instrument = on_add_instrument
        self._get_add_scope = get_add_scope

        self._all_presets: List[UniversePreset] = []
        self._filtered: List[UniversePreset] = []
        self._selected_idx: int = -1
        self._history = _PresetHistory()
        self._scanned = False
        self._tag_filter: str = ""

        self._build_ui()

        # Deferred scan on first show
        QTimer.singleShot(200, self._lazy_scan)

    # ── UI Construction ───────────────────────────────────────────────────

    def _build_ui(self) -> None:
        main = QVBoxLayout(self)
        main.setContentsMargins(4, 4, 4, 4)
        main.setSpacing(4)

        # ── Header ──
        header = QHBoxLayout()
        header.setSpacing(4)
        title = QLabel("🎛 Preset Universe")
        title.setStyleSheet("font-size: 13px; font-weight: bold; color: #7bd389;")
        header.addWidget(title)
        header.addStretch(1)

        # Scan button
        self._btn_scan = QPushButton("🔄")
        self._btn_scan.setFixedSize(24, 22)
        self._btn_scan.setToolTip("Alle Presets neu scannen")
        self._btn_scan.clicked.connect(self._do_scan)
        header.addWidget(self._btn_scan)

        # Count label
        self._lbl_count = QLabel("0 Presets")
        self._lbl_count.setStyleSheet("font-size: 10px; color: #888;")
        header.addWidget(self._lbl_count)
        main.addLayout(header)

        # ── Search Bar ──
        search_row = QHBoxLayout()
        search_row.setSpacing(4)

        self._search = QLineEdit()
        self._search.setPlaceholderText("🔍 Semantische Suche — z.B. 'warm 80s pad reverb'…")
        self._search.setStyleSheet(
            "QLineEdit { background: #2a2a2a; border: 1px solid #555; "
            "border-radius: 4px; padding: 4px 8px; color: #eee; font-size: 11px; }"
            "QLineEdit:focus { border-color: #7bd389; }"
        )
        self._search.textChanged.connect(self._on_search_changed)
        self._search.returnPressed.connect(self._on_search_enter)
        search_row.addWidget(self._search, 1)
        main.addLayout(search_row)

        # ── Filter Row ──
        filter_row = QHBoxLayout()
        filter_row.setSpacing(4)

        # Category filter
        self._cmb_category = QComboBox()
        self._cmb_category.setFixedHeight(22)
        self._cmb_category.setMaximumWidth(90)
        self._cmb_category.setStyleSheet("QComboBox { font-size: 10px; }")
        self._cmb_category.addItems([
            "Alle", "Bass", "Lead", "Pad", "Pluck", "Keys", "Drums",
            "Stab", "Ambient", "Arp", "FX", "Instrument", "Effect", "Other",
        ])
        self._cmb_category.currentTextChanged.connect(self._on_filter_changed)
        filter_row.addWidget(self._cmb_category)

        # Synth filter
        self._cmb_synth = QComboBox()
        self._cmb_synth.setFixedHeight(22)
        self._cmb_synth.setMaximumWidth(100)
        self._cmb_synth.setStyleSheet("QComboBox { font-size: 10px; }")
        self._cmb_synth.addItems([
            "Alle Synths", "AETERNA", "Fusion", "BRRR", "Sampler",
            "BachOrgel", "Drum Machine",
            "VST3", "CLAP", "LV2", "VST2", "Extern (alle)",
        ])
        self._cmb_synth.currentTextChanged.connect(self._on_filter_changed)
        filter_row.addWidget(self._cmb_synth)

        # Source filter
        self._cmb_source = QComboBox()
        self._cmb_source.setFixedHeight(22)
        self._cmb_source.setMaximumWidth(80)
        self._cmb_source.setStyleSheet("QComboBox { font-size: 10px; }")
        self._cmb_source.addItems(["Alle", "Factory", "User", "Community", "Installed", "KI"])
        self._cmb_source.currentTextChanged.connect(self._on_filter_changed)
        filter_row.addWidget(self._cmb_source)

        # Favorites only
        self._btn_fav = QPushButton("⭐")
        self._btn_fav.setCheckable(True)
        self._btn_fav.setFixedSize(24, 22)
        self._btn_fav.setToolTip("Nur Favoriten")
        self._btn_fav.toggled.connect(self._on_filter_changed)
        filter_row.addWidget(self._btn_fav)

        filter_row.addStretch(1)
        main.addLayout(filter_row)

        # ── Tag Cloud ──
        self._tag_cloud = _TagCloudWidget()
        self._tag_cloud.tag_clicked.connect(self._on_tag_filter)
        main.addWidget(self._tag_cloud)

        # ── Preset List (scrollable card list) ──
        self._scroll_area = QScrollArea()
        self._scroll_area.setWidgetResizable(True)
        self._scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        self._scroll_area.setStyleSheet(
            "QScrollArea { background: #1a1a1a; }"
        )

        self._list_container = QWidget()
        self._list_layout = QVBoxLayout(self._list_container)
        self._list_layout.setContentsMargins(2, 2, 2, 2)
        self._list_layout.setSpacing(3)
        self._list_layout.addStretch(1)

        self._scroll_area.setWidget(self._list_container)
        main.addWidget(self._scroll_area, stretch=1)

        # ── Detail Panel ──
        self._detail_frame = QFrame()
        self._detail_frame.setStyleSheet(
            "QFrame { background: #222; border: 1px solid #3a3a3a; "
            "border-radius: 4px; }"
        )
        self._detail_frame.setMaximumHeight(95)
        detail_lay = QVBoxLayout(self._detail_frame)
        detail_lay.setContentsMargins(6, 4, 6, 4)
        detail_lay.setSpacing(2)

        self._lbl_detail_name = QLabel("Kein Preset ausgewählt")
        self._lbl_detail_name.setStyleSheet("font-weight: bold; font-size: 12px; color: #eee;")
        detail_lay.addWidget(self._lbl_detail_name)

        self._lbl_detail_info = QLabel("")
        self._lbl_detail_info.setStyleSheet("font-size: 10px; color: #aaa;")
        self._lbl_detail_info.setWordWrap(True)
        detail_lay.addWidget(self._lbl_detail_info)

        # Detail action buttons
        detail_btns = QHBoxLayout()
        detail_btns.setSpacing(4)

        self._btn_load = QPushButton("📥 Laden")
        self._btn_load.setEnabled(False)
        self._btn_load.setFixedHeight(24)
        self._btn_load.setStyleSheet(
            "QPushButton { background: #2d5a27; color: #7bd389; border-radius: 4px; "
            "font-size: 11px; padding: 2px 10px; }"
            "QPushButton:hover { background: #3a7a33; }"
            "QPushButton:disabled { background: #333; color: #666; }"
        )
        def _laden_clicked():
            log.info("[PRESET-BTN] 'Laden' button CLICKED! enabled=%s, selected_idx=%d",
                     self._btn_load.isEnabled(), self._selected_idx)
            self._on_load_preset()
        self._btn_load.clicked.connect(_laden_clicked)
        detail_btns.addWidget(self._btn_load)

        self._btn_similar = QPushButton("🔗 Ähnliche")
        self._btn_similar.setEnabled(False)
        self._btn_similar.setFixedHeight(24)
        self._btn_similar.setStyleSheet(
            "QPushButton { background: #333; color: #aaa; border-radius: 4px; "
            "font-size: 10px; padding: 2px 8px; }"
            "QPushButton:hover { background: #444; color: #eee; }"
            "QPushButton:disabled { background: #2a2a2a; color: #555; }"
        )
        self._btn_similar.clicked.connect(self._show_similar)
        detail_btns.addWidget(self._btn_similar)

        detail_btns.addStretch(1)
        detail_lay.addLayout(detail_btns)

        main.addWidget(self._detail_frame)

        # ── KI Generate Bar ──
        ki_row = QHBoxLayout()
        ki_row.setSpacing(4)

        self._ki_input = QLineEdit()
        self._ki_input.setPlaceholderText("🤖 KI: Beschreibe deinen Sound… z.B. 'warmer 80er Pad'")
        self._ki_input.setFixedHeight(24)
        self._ki_input.setStyleSheet(
            "QLineEdit { background: #1e2e1e; border: 1px solid #2d5a27; "
            "border-radius: 4px; padding: 2px 8px; color: #7bd389; font-size: 10px; }"
            "QLineEdit:focus { border-color: #7bd389; }"
        )
        self._ki_input.returnPressed.connect(self._on_ki_generate)
        ki_row.addWidget(self._ki_input, 1)

        self._btn_generate = QPushButton("🎲 Generieren")
        self._btn_generate.setFixedHeight(24)
        self._btn_generate.setStyleSheet(
            "QPushButton { background: #2d5a27; color: #7bd389; border-radius: 4px; "
            "font-size: 10px; padding: 2px 8px; }"
            "QPushButton:hover { background: #3a7a33; }"
        )
        self._btn_generate.clicked.connect(self._on_ki_generate)
        ki_row.addWidget(self._btn_generate)

        self._btn_random = QPushButton("🎰")
        self._btn_random.setFixedSize(24, 24)
        self._btn_random.setToolTip("Smart Randomize — musikalisch zufällig")
        self._btn_random.setStyleSheet(
            "QPushButton { background: #333; border-radius: 4px; font-size: 13px; }"
            "QPushButton:hover { background: #444; }"
        )
        self._btn_random.clicked.connect(self._on_smart_random)
        ki_row.addWidget(self._btn_random)

        main.addLayout(ki_row)

        # ── Status Bar ──
        self._lbl_status = QLabel("")
        self._lbl_status.setStyleSheet("font-size: 9px; color: #888;")
        self._lbl_status.setVisible(False)
        main.addWidget(self._lbl_status)

    # ── Scanning & Data Loading ───────────────────────────────────────────

    def _lazy_scan(self) -> None:
        """Scan only once on first visible. v0.0.20.896: DB-first."""
        if not self._scanned:
            # Try loading from PresetDatabase first (instant, no scan needed)
            if self._load_from_db():
                self._scanned = True
                self._apply_filters()
                self._update_tag_cloud()
                self._show_status(f"✓ {len(self._all_presets)} Presets aus DB geladen")
                # Schedule a background re-scan to catch new plugins
                from PyQt6.QtCore import QTimer
                QTimer.singleShot(3000, lambda: self._do_scan(is_auto=True))
                return
            self._do_scan()

    def _load_from_db(self) -> bool:
        """Try loading presets from PresetDatabase. Returns True if data found."""
        try:
            from pydaw.services.preset_database import PresetDatabase
            db = PresetDatabase.get()
            db.ensure_loaded()
            rows = db.search("", limit=5000)  # get all
            if not rows or len(rows) < 5:
                return False
            presets = []
            for r in rows:
                p = UniversePreset(
                    name=str(r.get("name", "")),
                    synth=str(r.get("instrument", "")),
                    plugin_id=str(r.get("plugin_id", "")),
                    category=str(r.get("category", "")),
                    source=str(r.get("source", "scan")),
                    character=str(r.get("character", "")),
                    description=str(r.get("description", "")),
                    tags=[t for t in str(r.get("tags", "")).split(",") if t],
                    is_favorite=bool(r.get("is_favorite", 0)),
                )
                if p.name:
                    presets.append(p)
            if presets:
                self._all_presets = presets
                return True
        except Exception:
            pass
        return False

    def _do_scan(self, is_auto: bool = False) -> None:
        """Aggregate presets from all sources.

        Args:
            is_auto: If True, this is an auto-rescan — don't clear if result is
                     smaller (indicates scan failure, not real data loss).
        """
        try:
            new_presets: List[UniversePreset] = []
            if not is_auto:
                self._show_status("🔄 Scanne Presets…")

            # 0. Generate factory samples (drums, melodics) if not yet done
            try:
                from pydaw.audio.factory_sample_gen import ensure_factory_samples
                ensure_factory_samples()
            except Exception:
                pass

            # 1. Factory presets from KI generator
            factory = _generate_factory_presets()
            new_presets.extend(factory)

            # 2. User presets from PresetBrowserService
            self._scan_into(new_presets, self._collect_user_presets)

            # 3. Community presets
            self._scan_into(new_presets, self._collect_community_presets)

            # 4. Built-in instrument presets from widgets
            self._scan_into(new_presets, self._collect_builtin_presets)

            # 5. External plugins (VST3/CLAP/LV2) — from scanner cache
            self._scan_into(new_presets, self._collect_external_plugins)

            # Safety: don't replace with fewer presets on auto-rescan
            # (protects against transient scan failures)
            if is_auto and len(new_presets) < len(self._all_presets) * 0.5:
                log.info("Preset Universe auto-rescan: fewer results (%d vs %d), keeping old data",
                         len(new_presets), len(self._all_presets))
                return

            # Auto-tag all presets
            for p in new_presets:
                if not p.auto_tags and p.params:
                    try:
                        p.auto_tags, p.character = _auto_tag_preset(p.params)
                    except Exception:
                        pass
                if not p.category and (p.tags or p.auto_tags):
                    p.category = _guess_category(p.tags + p.auto_tags, p.name)

            # Atomic replace — never leave _all_presets in a half-cleared state
            self._all_presets = new_presets
            self._scanned = True

            log.info("Preset Universe: %d presets loaded (factory=%d, ext=%d)",
                     len(self._all_presets),
                     sum(1 for p in self._all_presets if p.source == "factory"),
                     sum(1 for p in self._all_presets if p.synth in ("vst3", "vst2", "clap", "lv2", "ladspa", "dssi")))

            self._apply_filters()
            self._update_tag_cloud()

            # Start auto-detection watcher (once)
            if not hasattr(self, '_watcher_started'):
                # Delay auto-detection setup to avoid immediate re-scan
                QTimer.singleShot(5000, self._setup_auto_detection)
                self._watcher_started = True

            total = len(self._all_presets)
            self._show_status(f"✓ {total} Presets geladen")

            # v0.0.20.892: Sync to PresetDatabase (SQLite) — best-effort
            self._sync_to_preset_db(self._all_presets)

        except Exception as e:
            log.warning("Preset Universe scan failed: %s", e)
            self._show_status(f"Scan-Fehler: {e}")

    def _sync_to_preset_db(self, presets: List[UniversePreset]) -> None:
        """Sync scanned presets to PresetDatabase (SQLite) — best-effort.

        v0.0.20.892: Enables persistent preset data across sessions.
        """
        try:
            from pydaw.services.preset_database import PresetDatabase
            db = PresetDatabase.get()
            db.ensure_loaded()
        except Exception:
            return
        batch = []
        for p in presets:
            try:
                batch.append({
                    "name": str(getattr(p, "name", "") or ""),
                    "instrument": str(getattr(p, "synth", "") or ""),
                    "plugin_id": str(getattr(p, "plugin_id", "") or ""),
                    "category": str(getattr(p, "category", "") or ""),
                    "tags": ",".join(getattr(p, "tags", []) or []),
                    "params_json": "",  # Skip heavy params for batch sync
                    "source": str(getattr(p, "source", "scan") or "scan"),
                    "character": str(getattr(p, "character", "") or ""),
                    "description": str(getattr(p, "description", "") or ""),
                })
            except Exception:
                continue
        if batch:
            try:
                added = db.add_presets_batch(batch)
                if added > 0:
                    log.info("[PresetUniverse] Synced %d new presets to DB", added)
            except Exception as exc:
                log.debug("[PresetUniverse] DB sync failed: %s", exc)

    @staticmethod
    def _scan_into(target: List[UniversePreset],
                   collector: Callable[[], List[UniversePreset]]) -> None:
        """Run a collector and append results to target. Safe."""
        try:
            results = collector()
            if results:
                target.extend(results)
        except Exception:
            pass

    def _collect_user_presets(self) -> List[UniversePreset]:
        """Scan user presets via PresetBrowserService."""
        result: List[UniversePreset] = []
        try:
            from pydaw.services.preset_browser_service import get_preset_browser_service
            svc = get_preset_browser_service()

            # (scan_type, plugin_id, display_name, synth_key)
            for ptype, pid, display_name, synth_key in [
                ("builtin", "chrono.aeterna", "AETERNA", "aeterna"),
                ("builtin", "chrono.fusion", "Fusion", "fusion"),
                ("builtin", "chrono.brrr", "BRRR", "brrr"),
                ("builtin", "chrono.pro_drum_machine", "Drum Machine", "drum_machine"),
                ("builtin", "chrono.pro_audio_sampler", "Sampler", "sampler"),
                ("builtin", "chrono.bach_orgel", "BachOrgel", "bachorgel"),
                ("builtin", "chrono.advanced_sampler", "Advanced Sampler", "sampler"),
            ]:
                try:
                    user_presets = svc.scan_user_presets(ptype, pid)
                    for up in user_presets:
                        auto_tags, character = _auto_tag_preset({})
                        result.append(UniversePreset(
                            name=up.name,
                            synth=synth_key,
                            synth_display=display_name,
                            plugin_id=pid,
                            category=up.category if up.category != "User" else "",
                            source="user" if not up.is_factory else "factory",
                            tags=up.tags,
                            auto_tags=auto_tags,
                            is_favorite=up.is_favorite,
                            file_path=up.file_path,
                            timestamp=up.timestamp,
                            character=character,
                        ))
                except Exception:
                    pass
        except Exception:
            pass
        return result

    def _collect_community_presets(self) -> List[UniversePreset]:
        """Scan community presets."""
        result: List[UniversePreset] = []
        try:
            from pydaw.ui.community_preset_browser import PresetRepositoryService
            repo = PresetRepositoryService()
            community = repo.scan_local()
            for cp in community:
                auto_tags, character = _auto_tag_preset(cp.params)
                result.append(UniversePreset(
                    name=cp.name,
                    synth=cp.instrument.lower() if cp.instrument else "aeterna",
                    synth_display=cp.instrument or "Community",
                    plugin_id=f"community.{cp.id}",
                    category=cp.category,
                    source="community",
                    tags=cp.tags,
                    auto_tags=auto_tags,
                    params=cp.params,
                    description=cp.description,
                    author=cp.author,
                    is_favorite=cp.is_favorite,
                    file_path=cp.file_path,
                    character=character,
                ))
        except Exception:
            pass
        return result

    def _collect_builtin_presets(self) -> List[UniversePreset]:
        """Scan presets embedded in built-in instruments (MIDI FX presets etc.)."""
        result: List[UniversePreset] = []
        try:
            from pydaw.audio.midi_fx_presets import MidiFxPresetManager
            mgr = MidiFxPresetManager()
            midi_presets = mgr.get_factory_presets()
            if isinstance(midi_presets, list):
                for pdata in midi_presets:
                    pname = str(pdata.get("name", "MIDI FX")) if isinstance(pdata, dict) else "MIDI FX"
                    result.append(UniversePreset(
                        name=pname,
                        synth="midi_fx",
                        synth_display="MIDI FX",
                        plugin_id="chrono.midi_fx",
                        category="FX",
                        source="factory",
                        tags=["midi-fx"],
                        params=pdata if isinstance(pdata, dict) else {},
                        author="ChronoScaleStudio",
                    ))
        except Exception:
            pass
        return result

    def _collect_external_plugins(self) -> List[UniversePreset]:
        """Scan external VST3/CLAP/LV2/VST2 plugins and their presets.

        Uses the plugin_scanner cache for installed plugins, then
        PresetBrowserService for each plugin's factory+user presets.
        """
        result: List[UniversePreset] = []
        try:
            from pydaw.services import plugin_scanner
            from pydaw.services.preset_browser_service import get_preset_browser_service

            svc = get_preset_browser_service()

            # Load cached scan results (fast — no filesystem rescan)
            cache = plugin_scanner.load_cache()
            if not cache:
                try:
                    cache = plugin_scanner.scan_all()
                    plugin_scanner.save_cache(cache)
                except Exception:
                    pass

            if not cache:
                return result

            for kind, plugins in cache.items():
                if not isinstance(plugins, list):
                    continue
                for ext_plugin in plugins:
                    try:
                        pid = str(getattr(ext_plugin, 'plugin_id', '') or '')
                        name = str(getattr(ext_plugin, 'name', '') or '') or pid
                        path = str(getattr(ext_plugin, 'path', '') or '')
                        is_inst = bool(getattr(ext_plugin, 'is_instrument', False))
                        ext_kind = str(getattr(ext_plugin, 'kind', kind) or kind)

                        if not pid:
                            continue

                        dev_pid = f"ext.{ext_kind}:{pid}"

                        kind_display = {
                            "vst3": "VST3", "vst2": "VST2", "clap": "CLAP",
                            "lv2": "LV2", "ladspa": "LADSPA", "dssi": "DSSI",
                        }.get(ext_kind, ext_kind.upper())

                        # Scan presets for this plugin (factory + user)
                        plugin_presets = []
                        try:
                            vst3_path = path if ext_kind in ("vst3", "vst2") else ""
                            plugin_presets = svc.scan_all_presets(
                                ext_kind, pid, vst3_path=vst3_path,
                            )
                        except Exception:
                            pass

                        if plugin_presets:
                            for pp in plugin_presets:
                                preset_tags = list(pp.tags) if pp.tags else []
                                preset_tags.append(ext_kind)
                                if is_inst:
                                    preset_tags.append("instrument")
                                else:
                                    preset_tags.append("effect")

                                up = UniversePreset(
                                    name=pp.name,
                                    synth=ext_kind,
                                    synth_display=f"{name} ({kind_display})",
                                    plugin_id=dev_pid,
                                    category=pp.category if pp.category not in ("User", "") else (
                                        "Instrument" if is_inst else "Effect"
                                    ),
                                    source="factory" if pp.is_factory else "user",
                                    tags=preset_tags,
                                    is_favorite=pp.is_favorite,
                                    file_path=pp.file_path,
                                    timestamp=pp.timestamp,
                                )
                                up._is_ext_instrument = is_inst  # type: ignore[attr-defined]
                                result.append(up)
                        else:
                            up = UniversePreset(
                                name=name,
                                synth=ext_kind,
                                synth_display=kind_display,
                                plugin_id=dev_pid,
                                category="Instrument" if is_inst else "Effect",
                                source="installed",
                                tags=[ext_kind, "instrument" if is_inst else "effect"],
                                file_path=path,
                                description=f"{kind_display} Plugin: {path}",
                            )
                            up._is_ext_instrument = is_inst  # type: ignore[attr-defined]
                            result.append(up)

                    except Exception:
                        continue

            if result:
                log.info("Preset Universe: %d external plugin entries loaded", len(result))

        except ImportError:
            log.debug("plugin_scanner not available — skipping external plugins")
        except Exception as e:
            log.warning("External plugin scan failed: %s", e)
        return result

    # ── Auto-Detection — Watches plugin dirs for new installs ─────────

    def _setup_auto_detection(self) -> None:
        """Watch common plugin directories for new plugin installations.

        Uses QFileSystemWatcher on:
        - /usr/lib/vst3, /usr/local/lib/vst3, ~/.vst3
        - /usr/lib/clap, /usr/local/lib/clap, ~/.clap
        - /usr/lib/lv2, /usr/local/lib/lv2, ~/.lv2

        Also runs a periodic rescan every 5 minutes to catch indirect changes.
        """
        try:
            from PyQt6.QtCore import QFileSystemWatcher

            self._plugin_watcher = QFileSystemWatcher(self)

            # Standard Linux plugin directories
            watch_dirs = []
            for base in ["/usr/lib", "/usr/local/lib", str(Path.home())]:
                for subdir in ["vst3", ".vst3", "clap", ".clap", "lv2", ".lv2",
                               "vst", ".vst"]:
                    d = os.path.join(base, subdir)
                    if os.path.isdir(d):
                        watch_dirs.append(d)

            # Also watch ~/.config/ChronoScaleStudio/presets for user presets
            preset_dir = str(Path.home() / ".config" / "ChronoScaleStudio" / "presets")
            if os.path.isdir(preset_dir):
                watch_dirs.append(preset_dir)

            # Community preset dirs
            for d in [
                str(Path.home() / ".pydaw" / "presets"),
                str(Path.home() / ".pydaw" / "community_presets"),
            ]:
                if os.path.isdir(d):
                    watch_dirs.append(d)

            if watch_dirs:
                self._plugin_watcher.addPaths(watch_dirs)
                self._plugin_watcher.directoryChanged.connect(self._on_plugin_dir_changed)
                log.info("Preset Universe: watching %d plugin directories", len(watch_dirs))

            # Periodic rescan every 5 minutes (catches plugins installed
            # via package managers, Flatpak, etc.)
            self._rescan_timer = QTimer(self)
            self._rescan_timer.setInterval(5 * 60 * 1000)  # 5 min
            self._rescan_timer.timeout.connect(self._on_periodic_rescan)
            self._rescan_timer.start()

        except Exception as e:
            log.debug("Auto-detection setup failed (non-critical): %s", e)

    def _on_plugin_dir_changed(self, path: str) -> None:
        """A watched plugin directory changed — schedule rescan."""
        try:
            # Debounce: wait 2 seconds before rescanning (plugin installs
            # often write multiple files)
            if not hasattr(self, '_rescan_debounce'):
                self._rescan_debounce = QTimer(self)
                self._rescan_debounce.setSingleShot(True)
                self._rescan_debounce.timeout.connect(self._do_auto_rescan)
            self._rescan_debounce.start(2000)
        except Exception:
            pass

    def _on_periodic_rescan(self) -> None:
        """Periodic silent rescan to catch new plugins."""
        self._do_auto_rescan()

    def _do_auto_rescan(self) -> None:
        """Rescan external plugins and refresh if count changed."""
        try:
            self._do_scan(is_auto=True)
        except Exception:
            pass

    # ── Filtering ─────────────────────────────────────────────────────────

    def _on_search_changed(self, text: str) -> None:
        self._apply_filters()

    def _on_search_enter(self) -> None:
        self._apply_filters()

    def _on_filter_changed(self) -> None:
        self._apply_filters()

    def _on_tag_filter(self, tag: str) -> None:
        self._tag_filter = tag
        self._apply_filters()

    def _apply_filters(self) -> None:
        """Apply all active filters and re-render the list."""
        try:
            query = self._search.text().strip()
            category = self._cmb_category.currentText()
            synth = self._cmb_synth.currentText()
            source = self._cmb_source.currentText()
            fav_only = self._btn_fav.isChecked()
            tag_filter = self._tag_filter

            results = list(self._all_presets)
            total_before = len(results)

            # Category filter
            if category and category != "Alle":
                results = [p for p in results if p.category == category]

            # Synth filter
            if synth and synth != "Alle Synths":
                synth_lower = synth.lower()
                _builtin_synths = {"aeterna", "fusion", "brrr",
                                   "drum_machine", "sampler", "bachorgel",
                                   "midi_fx", "builtin"}
                before_synth = len(results)
                if synth_lower.startswith("extern"):
                    results = [p for p in results
                               if p.synth not in _builtin_synths]
                elif synth_lower in ("vst3", "vst2", "clap", "lv2"):
                    results = [p for p in results
                               if p.synth == synth_lower
                               or synth_lower in (p.synth_display or "").lower()]
                else:
                    # Normalize: replace spaces with underscores for matching
                    synth_norm = synth_lower.replace(" ", "_")
                    results = [p for p in results
                               if synth_lower in (p.synth or "").lower()
                               or synth_norm in (p.synth or "").lower()
                               or synth_lower in (p.synth_display or "").lower()]
                log.debug("Filter synth=%s: %d → %d", synth, before_synth, len(results))

            # Source filter
            if source and source != "Alle":
                src_lower = source.lower()
                if src_lower == "ki":
                    results = [p for p in results if p.source == "ki-generated"]
                elif src_lower == "installed":
                    results = [p for p in results if p.source == "installed"]
                else:
                    results = [p for p in results if p.source == src_lower]

            # Favorites
            if fav_only:
                results = [p for p in results if p.is_favorite]

            # Tag filter (from tag cloud click)
            if tag_filter:
                results = [p for p in results
                           if tag_filter in p.tags or tag_filter in p.auto_tags]

            # Semantic search
            if query:
                for p in results:
                    p._sort_score = _semantic_score(p, query)
                results = [p for p in results if p._sort_score > 0]
                results.sort(key=lambda p: -p._sort_score)
            else:
                # Default sort: favorites first, then by synth, then name
                try:
                    results.sort(key=lambda p: (
                        not p.is_favorite,
                        p.synth or "",
                        (p.name or "").lower(),
                    ))
                except Exception:
                    pass

            self._filtered = results
            self._selected_idx = -1
            self._render_list()
            self._update_detail(None)
            self._lbl_count.setText(f"{len(results)} Presets")

            if total_before > 0 and len(results) == 0 and synth != "Alle Synths":
                log.info("Filter result 0 — total=%d, synth=%s, cat=%s, src=%s",
                         total_before, synth, category, source)

        except Exception as e:
            log.warning("Filter error: %s", e)

    def _render_list(self) -> None:
        """Re-render the card list from self._filtered."""
        try:
            # Clear existing cards
            while self._list_layout.count() > 1:  # Keep the stretch
                item = self._list_layout.takeAt(0)
                if item and item.widget():
                    item.widget().deleteLater()

            # Add cards (limit to 200 for performance)
            display = self._filtered[:200]
            for i, preset in enumerate(display):
                card = _PresetCardWidget(preset)
                card.clicked.connect(lambda idx=i: self._on_card_clicked(idx))
                card.double_clicked.connect(lambda idx=i: self._on_card_double_clicked(idx))
                card.fav_toggled.connect(lambda idx=i: self._on_toggle_fav(idx))
                self._list_layout.insertWidget(i, card)

            if len(self._filtered) > 200:
                more_lbl = QLabel(f"… und {len(self._filtered) - 200} weitere")
                more_lbl.setStyleSheet("font-size: 10px; color: #666; padding: 4px;")
                more_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
                self._list_layout.insertWidget(len(display), more_lbl)

        except Exception as e:
            log.warning("Render error: %s", e)

    def _update_tag_cloud(self) -> None:
        """Build tag frequency map and update tag cloud widget."""
        try:
            tag_counts: Dict[str, int] = {}
            for p in self._all_presets:
                for t in p.tags + p.auto_tags:
                    tag_counts[t] = tag_counts.get(t, 0) + 1

            # Filter out very rare tags
            tag_counts = {t: c for t, c in tag_counts.items() if c >= 2}
            self._tag_cloud.set_tags(tag_counts)
        except Exception:
            pass

    # ── Selection & Detail ────────────────────────────────────────────────

    def _on_card_clicked(self, idx: int) -> None:
        """Select a preset card."""
        try:
            # Deselect previous
            if 0 <= self._selected_idx < self._list_layout.count() - 1:
                old_item = self._list_layout.itemAt(self._selected_idx)
                if old_item and old_item.widget() and isinstance(old_item.widget(), _PresetCardWidget):
                    old_item.widget().set_selected(False)

            self._selected_idx = idx
            if 0 <= idx < self._list_layout.count() - 1:
                new_item = self._list_layout.itemAt(idx)
                if new_item and new_item.widget() and isinstance(new_item.widget(), _PresetCardWidget):
                    new_item.widget().set_selected(True)

            if 0 <= idx < len(self._filtered):
                self._update_detail(self._filtered[idx])
        except Exception:
            pass

    def _on_card_double_clicked(self, idx: int) -> None:
        """Double-click → select card + load preset."""
        try:
            log.info("[PRESET-DBLCLICK] idx=%d", idx)
            self._on_card_clicked(idx)
            log.info("[PRESET-DBLCLICK] _on_card_clicked OK, calling _on_load_preset")
        except Exception as e:
            log.warning("[PRESET-DBLCLICK] _on_card_clicked CRASHED: %s", e, exc_info=True)
            # Still try to set the index and load
            try:
                self._selected_idx = idx
            except Exception:
                pass
        try:
            self._on_load_preset()
        except Exception as e:
            log.warning("[PRESET-DBLCLICK] _on_load_preset CRASHED: %s", e, exc_info=True)

    def _update_detail(self, preset: Optional[UniversePreset]) -> None:
        """Update the detail panel."""
        try:
            if preset is None:
                self._lbl_detail_name.setText("Kein Preset ausgewählt")
                self._lbl_detail_info.setText("")
                self._btn_load.setEnabled(False)
                self._btn_similar.setEnabled(False)
                return

            self._lbl_detail_name.setText(f"{preset.name}")
            info_parts = []
            if preset.synth_display:
                info_parts.append(f"Synth: {preset.synth_display}")
            if preset.category:
                info_parts.append(f"Kategorie: {preset.category}")
            if preset.source:
                info_parts.append(f"Quelle: {preset.source.capitalize()}")
            if preset.author:
                info_parts.append(f"Autor: {preset.author}")
            if preset.character:
                info_parts.append(f"Charakter: {preset.character}")
            if preset.description:
                info_parts.append(preset.description)

            self._lbl_detail_info.setText(" | ".join(info_parts))
            has_params = bool(preset.params or preset.file_path)
            log.info("[PRESET-DETAIL] name='%s' has_params=%s params_type=%s params_len=%d btn_enabled=%s",
                     preset.name, has_params, type(preset.params).__name__,
                     len(preset.params) if isinstance(preset.params, dict) else 0, has_params)
            self._btn_load.setEnabled(has_params)
            self._btn_similar.setEnabled(bool(preset.params))
        except Exception:
            pass

    # ── Actions ───────────────────────────────────────────────────────────

    def _on_load_preset(self) -> None:
        """Load the selected preset into the appropriate instrument."""
        try:
            if self._selected_idx < 0 or self._selected_idx >= len(self._filtered):
                log.warning("[PRESET-LOAD] No preset selected (idx=%d, len=%d)",
                            self._selected_idx, len(self._filtered))
                return

            preset = self._filtered[self._selected_idx]
            log.info("[PRESET-LOAD] === START === name='%s' synth='%s' plugin_id='%s'",
                     preset.name, preset.synth, preset.plugin_id)

            self._history.add(preset.name, preset.synth, preset.plugin_id)

            load_data = {
                "plugin_id": preset.plugin_id,
                "name": preset.name,
                "params": preset.params,
                "synth": preset.synth,
                "file_path": preset.file_path,
                "source": preset.source,
            }

            # Step 1: Ensure instrument track exists
            if self._on_add_instrument and preset.plugin_id:
                log.info("[PRESET-LOAD] Step 1: calling _on_add_instrument(%s)", preset.plugin_id)
                try:
                    self._on_add_instrument(preset.plugin_id)
                    log.info("[PRESET-LOAD] Step 1: _on_add_instrument returned OK")
                except Exception as e:
                    log.warning("[PRESET-LOAD] Step 1: _on_add_instrument FAILED: %s", e)
            else:
                log.warning("[PRESET-LOAD] Step 1: SKIPPED — _on_add_instrument=%s, plugin_id=%s",
                            bool(self._on_add_instrument), preset.plugin_id)

            # Step 2: Delay then apply
            log.info("[PRESET-LOAD] Step 2: scheduling _apply_pending_preset in 300ms")
            try:
                self._pending_preset_data = load_data
                QTimer.singleShot(300, self._apply_pending_preset)
            except Exception as e:
                log.warning("[PRESET-LOAD] Step 2: timer setup FAILED: %s", e)

            self._show_status(f"✓ Preset '{preset.name}' wird geladen…")

        except Exception as e:
            log.warning("[PRESET-LOAD] EXCEPTION: %s", e)
            self._show_status(f"Fehler: {e}")

    def _apply_pending_preset(self) -> None:
        """Apply preset after instrument widget has been created (delayed)."""
        try:
            data = getattr(self, '_pending_preset_data', None)
            if not data:
                log.warning("[PRESET-LOAD] Step 3: _apply_pending_preset — NO pending data!")
                return
            self._pending_preset_data = None

            log.info("[PRESET-LOAD] Step 3: emitting preset_load_requested signal for '%s'",
                     data.get("name", "?"))

            # Count connected slots
            try:
                n_receivers = self.preset_load_requested.receivers(
                    self.preset_load_requested.signal
                ) if hasattr(self.preset_load_requested, 'receivers') else -1
            except Exception:
                n_receivers = -1
            log.info("[PRESET-LOAD] Step 3: signal has ~%s receiver(s)", n_receivers)

            try:
                self.preset_load_requested.emit(data)
                log.info("[PRESET-LOAD] Step 3: signal EMITTED OK")
            except Exception as e:
                log.warning("[PRESET-LOAD] Step 3: signal emit FAILED: %s", e)

            name = data.get("name", "")
            self._show_status(f"✓ Preset '{name}' geladen")
        except Exception as e:
            log.warning("[PRESET-LOAD] Step 3 EXCEPTION: %s", e)

    def _on_toggle_fav(self, idx: int) -> None:
        """Toggle favorite on a preset."""
        try:
            if 0 <= idx < len(self._filtered):
                preset = self._filtered[idx]
                preset.is_favorite = not preset.is_favorite

                # Persist via PresetBrowserService
                try:
                    from pydaw.services.preset_browser_service import get_preset_browser_service
                    svc = get_preset_browser_service()
                    ptype = preset.synth if preset.synth != "aeterna" else "builtin"
                    svc.toggle_favorite(ptype, preset.plugin_id, preset.name)
                except Exception:
                    pass

                # Refresh display
                self._apply_filters()
        except Exception:
            pass

    def _show_similar(self) -> None:
        """Find and show presets similar to the selected one."""
        try:
            if self._selected_idx < 0 or self._selected_idx >= len(self._filtered):
                return

            ref = self._filtered[self._selected_idx]
            if not ref.params:
                self._show_status("Keine Parameter für Ähnlichkeitssuche")
                return

            # Score all presets by parameter distance
            scored: List[Tuple[float, UniversePreset]] = []
            for p in self._all_presets:
                if p.name == ref.name and p.plugin_id == ref.plugin_id:
                    continue
                if not p.params:
                    continue
                dist = _preset_distance(ref.params, p.params)
                if dist < 0.8:  # Only reasonably similar
                    scored.append((dist, p))

            scored.sort(key=lambda x: x[0])
            top = [p for _, p in scored[:20]]

            if not top:
                self._show_status("Keine ähnlichen Presets gefunden")
                return

            # Display as filtered results
            self._filtered = top
            self._selected_idx = -1
            self._render_list()
            self._lbl_count.setText(f"🔗 {len(top)} ähnliche zu '{ref.name}'")
            self._show_status(f"🔗 {len(top)} ähnliche Presets gefunden")

        except Exception as e:
            self._show_status(f"Fehler: {e}")

    # ── KI Features ───────────────────────────────────────────────────────

    def _on_ki_generate(self) -> None:
        """Generate a preset from text description using KI."""
        try:
            desc = self._ki_input.text().strip()
            if not desc:
                self._show_status("Bitte Beschreibung eingeben")
                return

            from pydaw.services.preset_generator import (
                description_to_preset, describe_preset,
            )

            result = description_to_preset(desc, synth="aeterna")
            auto_tags, character = _auto_tag_preset(result.params)

            # Create preset entry
            generated = UniversePreset(
                name=result.name or f"KI: {desc[:30]}",
                synth="aeterna",
                synth_display="AETERNA",
                plugin_id="chrono.aeterna",
                category=_guess_category(auto_tags + result.matched_keywords, desc),
                source="ki-generated",
                tags=result.matched_keywords,
                auto_tags=auto_tags,
                params=result.params,
                description=result.description or desc,
                author="KI Generator",
                character=character,
            )

            # Add to universe and select it
            self._all_presets.insert(0, generated)
            self._filtered = [generated] + self._filtered
            self._render_list()
            self._on_card_clicked(0)
            self._update_tag_cloud()
            self._show_status(f"🤖 KI-Preset generiert: {generated.name}")
            self._ki_input.clear()

            # Emit for collab sync
            try:
                self.preset_load_requested.emit({
                    "name": generated.name,
                    "synth": generated.synth,
                    "plugin_id": generated.plugin_id,
                    "params": generated.params,
                    "source": "ki-generated",
                    "description": generated.description,
                })
            except Exception:
                pass

        except Exception as e:
            self._show_status(f"KI-Fehler: {e}")

    def _on_smart_random(self) -> None:
        """Generate a musically-aware random preset variation."""
        try:
            from pydaw.services.preset_generator import (
                smart_randomize, _AETERNA_PARAMS,
            )

            # If a preset is selected, use it as base
            base_params = {}
            if 0 <= self._selected_idx < len(self._filtered):
                base_params = dict(self._filtered[self._selected_idx].params or {})

            if not base_params:
                # Start from defaults
                base_params = {k: v[2] for k, v in _AETERNA_PARAMS.items()}

            import random
            chars = ["warm", "bright", "dark", "aggressive", "gentle"]
            char = random.choice(chars)

            result = smart_randomize(base_params, amount=0.5, character=char)
            auto_tags, character = _auto_tag_preset(result.params)

            generated = UniversePreset(
                name=result.name,
                synth="aeterna",
                synth_display="AETERNA",
                plugin_id="chrono.aeterna",
                category=_guess_category(auto_tags, result.name),
                source="ki-generated",
                tags=result.matched_keywords,
                auto_tags=auto_tags,
                params=result.params,
                description=result.description,
                author="Smart Randomize",
                character=character,
            )

            self._all_presets.insert(0, generated)
            self._filtered = [generated] + self._filtered
            self._render_list()
            self._on_card_clicked(0)
            self._show_status(f"🎰 Random Preset: {generated.name}")

            # Emit for collab sync
            try:
                self.preset_load_requested.emit({
                    "name": generated.name,
                    "synth": generated.synth,
                    "plugin_id": generated.plugin_id,
                    "params": generated.params,
                    "source": "ki-generated",
                    "description": generated.description,
                })
            except Exception:
                pass

        except Exception as e:
            self._show_status(f"Random-Fehler: {e}")

    # ── Status ────────────────────────────────────────────────────────────

    def _show_status(self, text: str, duration_ms: int = 4000) -> None:
        try:
            self._lbl_status.setText(text)
            self._lbl_status.setVisible(True)
            QTimer.singleShot(duration_ms, self._hide_status)
        except Exception:
            pass

    def _hide_status(self) -> None:
        try:
            self._lbl_status.setVisible(False)
        except Exception:
            pass

    # ── Public API ────────────────────────────────────────────────────────

    def reload(self) -> None:
        """Force re-scan of all preset sources."""
        self._scanned = False
        self._do_scan()

    def get_selected_preset(self) -> Optional[UniversePreset]:
        if 0 <= self._selected_idx < len(self._filtered):
            return self._filtered[self._selected_idx]
        return None
