"""Live Performance Panel (P4A) — Vollbild-Live-Modus.

Touch-optimiertes Fullscreen-UI für Live-Performance.
Große Buttons, Clip-Launcher-Grid, Transport, BPM, Level-Meter.

Features:
- Fullscreen toggle (F11 or button)
- Big clip launcher grid (touch targets ≥ 60px)
- Transport bar (Play/Stop/Record/BPM)
- Per-track level meters
- Scene launch buttons
- Minimal distraction — no menu, no sidebar
- Keyboard shortcuts for common actions

v0.0.20.810 — Phase P4A
"""

from __future__ import annotations

import logging
from typing import Optional, List, Dict, Any

from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QSize
from PyQt6.QtGui import QColor, QFont, QPainter, QKeySequence, QShortcut
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QPushButton, QLabel, QFrame, QSizePolicy,
    QApplication, QSpacerItem,
)

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Clip Grid Button
# ---------------------------------------------------------------------------

class _ClipButton(QPushButton):
    """Large touch-friendly clip trigger button."""

    clip_triggered = pyqtSignal(int, int)  # track_idx, scene_idx

    _COLORS = {
        "empty": "#2a2a2a",
        "loaded": "#3a5f3a",
        "playing": "#4caf50",
        "queued": "#ff9800",
        "recording": "#f44336",
    }

    def __init__(self, track_idx: int, scene_idx: int, parent=None):
        super().__init__(parent)
        self._track = track_idx
        self._scene = scene_idx
        self._state = "empty"
        self._clip_name = ""

        self.setMinimumSize(60, 60)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.clicked.connect(self._on_click)
        self._update_style()

    def set_state(self, state: str, name: str = "") -> None:
        self._state = state
        self._clip_name = name
        self._update_style()
        if name:
            self.setText(name[:8])
        elif state == "empty":
            self.setText("")

    def _update_style(self) -> None:
        color = self._COLORS.get(self._state, "#2a2a2a")
        border = "#666" if self._state != "empty" else "#444"
        text_color = "#fff" if self._state != "empty" else "#555"
        self.setStyleSheet(
            f"QPushButton {{"
            f"  background: {color}; border: 2px solid {border};"
            f"  border-radius: 6px; color: {text_color};"
            f"  font-size: 11px; font-weight: bold; padding: 4px;"
            f"}}"
            f"QPushButton:hover {{ border-color: #aaa; }}"
            f"QPushButton:pressed {{ background: #666; }}"
        )

    def _on_click(self) -> None:
        try:
            self.clip_triggered.emit(self._track, self._scene)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Transport Bar
# ---------------------------------------------------------------------------

class _TransportBar(QFrame):
    """Big transport controls for live performance."""

    play_clicked = pyqtSignal()
    stop_clicked = pyqtSignal()
    record_clicked = pyqtSignal()
    tap_tempo = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setStyleSheet("background: #1a1a1a; border-radius: 8px;")

        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 6, 10, 6)

        # Play
        self._play_btn = self._make_btn("▶", "#4caf50", 70, 50)
        self._play_btn.clicked.connect(self.play_clicked.emit)
        lay.addWidget(self._play_btn)

        # Stop
        self._stop_btn = self._make_btn("■", "#f44336", 70, 50)
        self._stop_btn.clicked.connect(self.stop_clicked.emit)
        lay.addWidget(self._stop_btn)

        # Record
        self._rec_btn = self._make_btn("●", "#ff1744", 70, 50)
        self._rec_btn.clicked.connect(self.record_clicked.emit)
        lay.addWidget(self._rec_btn)

        lay.addSpacerItem(QSpacerItem(30, 0))

        # BPM
        self._bpm_label = QLabel("120 BPM")
        self._bpm_label.setStyleSheet(
            "color: #ffd54f; font-size: 28px; font-weight: bold;"
        )
        lay.addWidget(self._bpm_label)

        # Tap tempo
        self._tap_btn = self._make_btn("TAP", "#ff9800", 70, 50)
        self._tap_btn.clicked.connect(self.tap_tempo.emit)
        lay.addWidget(self._tap_btn)

        lay.addSpacerItem(QSpacerItem(30, 0))

        # Position
        self._pos_label = QLabel("1.1.1")
        self._pos_label.setStyleSheet(
            "color: #81c784; font-size: 24px; font-family: monospace;"
        )
        lay.addWidget(self._pos_label)

        lay.addStretch()

        # Exit button
        self._exit_btn = self._make_btn("✕ EXIT", "#555", 90, 50)
        lay.addWidget(self._exit_btn)

    @property
    def exit_button(self) -> QPushButton:
        return self._exit_btn

    def set_bpm(self, bpm: float) -> None:
        self._bpm_label.setText(f"{bpm:.0f} BPM")

    def set_position(self, bar: int, beat: int, tick: int) -> None:
        self._pos_label.setText(f"{bar}.{beat}.{tick}")

    def set_playing(self, playing: bool) -> None:
        color = "#4caf50" if not playing else "#81c784"
        self._play_btn.setStyleSheet(
            self._play_btn.styleSheet().replace("#4caf50", color)
        )

    def set_recording(self, recording: bool) -> None:
        color = "#ff1744" if not recording else "#ff5252"
        self._rec_btn.setStyleSheet(
            self._rec_btn.styleSheet().replace("#ff1744", color)
        )

    @staticmethod
    def _make_btn(text: str, color: str, w: int, h: int) -> QPushButton:
        btn = QPushButton(text)
        btn.setMinimumSize(w, h)
        btn.setStyleSheet(
            f"QPushButton {{"
            f"  background: {color}; border: none; border-radius: 8px;"
            f"  color: white; font-size: 18px; font-weight: bold;"
            f"  padding: 6px 12px;"
            f"}}"
            f"QPushButton:hover {{ opacity: 0.8; }}"
            f"QPushButton:pressed {{ background: #888; }}"
        )
        return btn


# ---------------------------------------------------------------------------
# Scene Launch Column
# ---------------------------------------------------------------------------

class _SceneColumn(QFrame):
    """Vertical column of scene launch buttons."""

    scene_launched = pyqtSignal(int)  # scene_idx

    def __init__(self, num_scenes: int = 8, parent=None):
        super().__init__(parent)
        self.setStyleSheet("background: transparent;")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        lay.setSpacing(4)

        self._buttons: List[QPushButton] = []
        for i in range(num_scenes):
            btn = QPushButton(f"S{i + 1}")
            btn.setMinimumSize(50, 50)
            btn.setStyleSheet(
                "QPushButton {"
                "  background: #37474f; border: 2px solid #546e7a;"
                "  border-radius: 6px; color: #b0bec5;"
                "  font-size: 13px; font-weight: bold;"
                "}"
                "QPushButton:hover { background: #455a64; }"
                "QPushButton:pressed { background: #4caf50; }"
            )
            btn.clicked.connect(lambda checked, idx=i: self.scene_launched.emit(idx))
            lay.addWidget(btn)
            self._buttons.append(btn)


# ---------------------------------------------------------------------------
# Level Meter (simple)
# ---------------------------------------------------------------------------

class _LevelMeter(QFrame):
    """Simple vertical level meter for live view."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._level: float = 0.0
        self.setMinimumSize(20, 40)
        self.setMaximumWidth(30)

    def set_level(self, level: float) -> None:
        self._level = max(0.0, min(1.0, level))
        self.update()

    def paintEvent(self, event) -> None:
        try:
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            w, h = self.width(), self.height()

            # Background
            p.fillRect(0, 0, w, h, QColor("#1a1a1a"))

            # Level bar
            bar_h = int(h * self._level)
            if self._level > 0.9:
                color = QColor("#f44336")
            elif self._level > 0.7:
                color = QColor("#ff9800")
            else:
                color = QColor("#4caf50")
            p.fillRect(2, h - bar_h, w - 4, bar_h, color)

            p.end()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Live Performance Panel (main widget)
# ---------------------------------------------------------------------------

class LivePerformancePanel(QWidget):
    """Fullscreen live performance mode.

    Shows a big clip launcher grid with transport, scene launch,
    and level meters. Touch-optimized with large targets.

    Usage:
        panel = LivePerformancePanel(transport, project_service, clip_launcher)
        panel.showFullScreen()  # or toggle with F11
    """

    exit_requested = pyqtSignal()

    def __init__(
        self,
        transport=None,
        project_service=None,
        clip_launcher=None,
        num_tracks: int = 8,
        num_scenes: int = 8,
        parent: Optional[QWidget] = None,
    ):
        super().__init__(parent)
        self._transport = transport
        self._project = project_service
        self._launcher = clip_launcher
        self._num_tracks = num_tracks
        self._num_scenes = num_scenes

        self.setWindowTitle("Py_DAW — Live Performance")
        self.setStyleSheet("background: #121212; color: #eee;")

        self._setup_ui()
        self._setup_shortcuts()

        # Update timer (30 Hz)
        self._update_timer = QTimer(self)
        self._update_timer.setInterval(33)
        self._update_timer.timeout.connect(self._update_state)

    def _setup_ui(self) -> None:
        main_lay = QVBoxLayout(self)
        main_lay.setContentsMargins(8, 8, 8, 8)
        main_lay.setSpacing(6)

        # ── Transport bar ─────────────────────────────────────────────
        self._transport_bar = _TransportBar(self)
        self._transport_bar.play_clicked.connect(self._on_play)
        self._transport_bar.stop_clicked.connect(self._on_stop)
        self._transport_bar.record_clicked.connect(self._on_record)
        self._transport_bar.tap_tempo.connect(self._on_tap)
        self._transport_bar.exit_button.clicked.connect(self._on_exit)
        main_lay.addWidget(self._transport_bar)

        # ── Clip grid + scene buttons ─────────────────────────────────
        grid_row = QHBoxLayout()
        grid_row.setSpacing(4)

        # Track headers
        header_lay = QVBoxLayout()
        header_lay.addSpacerItem(QSpacerItem(0, 10))
        self._track_labels: List[QLabel] = []
        # (headers are horizontal, meters are below grid — skip for simplicity)

        # Clip grid
        self._grid_frame = QFrame(self)
        self._grid_lay = QGridLayout(self._grid_frame)
        self._grid_lay.setSpacing(4)
        self._grid_lay.setContentsMargins(2, 2, 2, 2)

        self._clip_buttons: Dict[tuple, _ClipButton] = {}

        # Track name headers
        for col in range(self._num_tracks):
            lbl = QLabel(f"Track {col + 1}")
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lbl.setStyleSheet(
                "color: #90a4ae; font-size: 11px; font-weight: bold; padding: 2px;"
            )
            self._grid_lay.addWidget(lbl, 0, col)
            self._track_labels.append(lbl)

        # Clip buttons
        for row in range(self._num_scenes):
            for col in range(self._num_tracks):
                btn = _ClipButton(col, row, self._grid_frame)
                btn.clip_triggered.connect(self._on_clip_trigger)
                self._grid_lay.addWidget(btn, row + 1, col)
                self._clip_buttons[(col, row)] = btn

        grid_row.addWidget(self._grid_frame, stretch=1)

        # Scene launch column
        self._scene_col = _SceneColumn(self._num_scenes, self)
        self._scene_col.scene_launched.connect(self._on_scene_launch)
        grid_row.addWidget(self._scene_col)

        main_lay.addLayout(grid_row, stretch=1)

        # ── Level meters row ──────────────────────────────────────────
        meter_lay = QHBoxLayout()
        meter_lay.setSpacing(4)
        self._meters: List[_LevelMeter] = []
        for i in range(self._num_tracks):
            meter = _LevelMeter(self)
            meter_lay.addWidget(meter)
            self._meters.append(meter)
        meter_lay.addSpacerItem(QSpacerItem(54, 0))  # space for scene column
        main_lay.addLayout(meter_lay)

    def _setup_shortcuts(self) -> None:
        """Keyboard shortcuts for live performance."""
        QShortcut(QKeySequence(Qt.Key.Key_F11), self, self._toggle_fullscreen)
        QShortcut(QKeySequence(Qt.Key.Key_Escape), self, self._on_exit)
        QShortcut(QKeySequence(Qt.Key.Key_Space), self, self._on_play)

    # ── Actions ───────────────────────────────────────────────────────────

    def _on_play(self) -> None:
        if self._transport:
            try: self._transport.play()
            except Exception: pass

    def _on_stop(self) -> None:
        if self._transport:
            try: self._transport.stop()
            except Exception: pass

    def _on_record(self) -> None:
        if self._transport:
            try: self._transport.toggle_record()
            except Exception: pass

    def _on_tap(self) -> None:
        if self._transport:
            try: self._transport.tap_tempo()
            except Exception: pass

    def _on_clip_trigger(self, track_idx: int, scene_idx: int) -> None:
        if self._launcher:
            try:
                self._launcher.launch_clip_at(track_idx, scene_idx)
            except Exception:
                try:
                    self._launcher.launch_scene(scene_idx)
                except Exception:
                    pass

    def _on_scene_launch(self, scene_idx: int) -> None:
        if self._launcher:
            try:
                self._launcher.launch_scene(scene_idx)
            except Exception:
                pass

    def _on_exit(self) -> None:
        if self.isFullScreen():
            self.showNormal()
        try:
            self.exit_requested.emit()
        except Exception:
            pass
        self.close()

    def _toggle_fullscreen(self) -> None:
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()

    # ── State update (30 Hz) ──────────────────────────────────────────────

    def _update_state(self) -> None:
        """Refresh transport display and track states."""
        try:
            t = self._transport
            if t:
                bpm = float(getattr(t, 'bpm', 120))
                self._transport_bar.set_bpm(bpm)
                pos = float(getattr(t, 'position_beats', 0))
                bar = int(pos / 4) + 1
                beat = int(pos % 4) + 1
                tick = int((pos % 1) * 4) + 1
                self._transport_bar.set_position(bar, beat, tick)
                self._transport_bar.set_playing(bool(getattr(t, 'is_playing', False)))
                self._transport_bar.set_recording(bool(getattr(t, 'is_recording', False)))
        except Exception:
            pass

        # Update track names
        try:
            ps = self._project
            proj = getattr(getattr(ps, 'ctx', None), 'project', None) if ps else None
            if proj is None:
                proj = getattr(ps, 'project', None)
            if proj:
                tracks = getattr(proj, 'tracks', [])
                for i, lbl in enumerate(self._track_labels):
                    if i < len(tracks):
                        lbl.setText(getattr(tracks[i], 'name', f'T{i + 1}')[:10])
        except Exception:
            pass

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self._update_timer.start()
        self._update_state()

    def hideEvent(self, event) -> None:
        self._update_timer.stop()
        super().hideEvent(event)

    def closeEvent(self, event) -> None:
        self._update_timer.stop()
        super().closeEvent(event)
