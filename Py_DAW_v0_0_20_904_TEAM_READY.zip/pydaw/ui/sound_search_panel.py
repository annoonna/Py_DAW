"""sound_search_panel.py — Sound Search UI (Phase T7).

v0.0.20.901 — "Finde den Sound von letzter Woche"

Search types:
- Text-Suche: "warmer pad sound letzte woche" (FTS5)
- Plugin-Suche: "Alle Surge XT Sounds dieser Woche"
- Stimmungs-Suche: "froehlich", "dunkel", "aggressiv" → mapped to tags
- Aehnlichkeits-Suche: "Finde Sounds aehnlich zu JETZT" (audio fingerprint, future)

UI:
- Search field with smart suggestions
- Result cards with time, tags, preview/restore buttons
- Grouping: Heute / Gestern / Diese Woche / Aelter
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import Qt, pyqtSignal, pyqtSlot, QTimer
    from PyQt6.QtGui import QFont
    from PyQt6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
        QLineEdit, QScrollArea, QFrame, QComboBox, QSizePolicy,
        QGroupBox,
    )
    _QT = True
except ImportError:
    _QT = False


# ── Mood-to-tag mapping ──
_MOOD_MAP = {
    "froehlich":  ["dur", "major", "hoch", "schnell", "dicht", "laut"],
    "happy":      ["dur", "major", "hoch", "schnell", "dicht", "laut"],
    "dunkel":     ["moll", "minor", "tief", "Bass", "leise", "Filter schliesst"],
    "dark":       ["moll", "minor", "tief", "Bass", "leise", "Filter schliesst"],
    "aggressiv":  ["laut", "sehr laut", "dicht", "Distortion", "drive"],
    "aggressive": ["laut", "sehr laut", "dicht", "Distortion", "drive"],
    "ruhig":      ["leise", "spaerlich", "locker", "Hall"],
    "calm":       ["leise", "spaerlich", "locker", "Hall"],
    "warm":       ["Filter oeffnet", "pad", "Mittel", "Hall"],
    "kalt":       ["hoch", "Filter schliesst", "Hoehe", "Resonanz"],
    "episch":     ["laut", "dicht", "Akkorde", "Hall", "Crescendo"],
    "epic":       ["laut", "dicht", "Akkorde", "Hall", "Crescendo"],
    "minimal":    ["spaerlich", "locker", "leise"],
    "percussive": ["dicht", "Sub-Bass", "Bass", "laut"],
    "ambient":    ["spaerlich", "Hall", "Delay", "leise", "pad"],
    "psychedelic": ["Filter Sweep", "LFO", "Delay", "Resonanz"],
}

# Time filter presets
_TIME_FILTERS = {
    "alle":          0,
    "heute":         1,
    "gestern":       2,
    "diese woche":   7,
    "dieser monat":  30,
    "letzte stunde": -1,  # special: 1 hour ago
}


def _format_wall(wc: float) -> str:
    """Format wall clock timestamp."""
    try:
        dt = datetime.fromtimestamp(wc)
        now = datetime.now()
        if dt.date() == now.date():
            return f"Heute {dt.strftime('%H:%M')}"
        elif dt.date() == (now - timedelta(days=1)).date():
            return f"Gestern {dt.strftime('%H:%M')}"
        return dt.strftime("%d.%m. %H:%M")
    except Exception:
        return "?"


def _time_group(wc: float) -> str:
    """Assign a time group label for grouping results."""
    try:
        dt = datetime.fromtimestamp(wc)
        now = datetime.now()
        if dt.date() == now.date():
            return "Heute"
        elif dt.date() == (now - timedelta(days=1)).date():
            return "Gestern"
        elif (now - dt).days < 7:
            return "Diese Woche"
        return "Aelter"
    except Exception:
        return "Unbekannt"


if _QT:

    class SoundSearchPanel(QWidget):
        """Sound Search panel — "Finde den Sound von letzter Woche".

        Provides text, plugin, and mood-based search over journal tags.
        """

        preview_requested = pyqtSignal(int)   # timestamp_ms
        restore_requested = pyqtSignal(int)    # timestamp_ms

        def __init__(self, parent=None, project_service=None):
            super().__init__(parent)
            self._project_service = project_service
            self._restore = None
            self._db = None
            self._search_history: List[str] = []

            self._setup_ui()

        def _setup_ui(self) -> None:
            layout = QVBoxLayout(self)
            layout.setContentsMargins(4, 4, 4, 4)
            layout.setSpacing(6)

            # ── Header ──
            title = QLabel("Sound-Suche")
            title.setStyleSheet("font-weight:bold; font-size:13px; color:#ccc;")
            layout.addWidget(title)

            # ── Search bar ──
            search_row = QHBoxLayout()
            search_row.setSpacing(4)

            self._search_input = QLineEdit()
            self._search_input.setPlaceholderText(
                "z.B. 'warmer pad', 'Surge XT', 'Bass letzte Woche', "
                "'dunkel', 'froehlich'..."
            )
            self._search_input.returnPressed.connect(self._on_search)
            search_row.addWidget(self._search_input, stretch=1)

            self._btn_search = QPushButton("Suchen")
            self._btn_search.clicked.connect(self._on_search)
            self._btn_search.setFixedWidth(70)
            search_row.addWidget(self._btn_search)

            layout.addLayout(search_row)

            # ── Filter row ──
            filter_row = QHBoxLayout()
            filter_row.setSpacing(4)

            filter_row.addWidget(QLabel("Zeitraum:"))
            self._cmb_time = QComboBox()
            self._cmb_time.addItems([
                "Alle", "Heute", "Gestern", "Diese Woche",
                "Dieser Monat", "Letzte Stunde",
            ])
            self._cmb_time.setFixedWidth(110)
            filter_row.addWidget(self._cmb_time)

            filter_row.addWidget(QLabel("Typ:"))
            self._cmb_type = QComboBox()
            self._cmb_type.addItems([
                "Alles", "MIDI", "Parameter", "Plugins",
            ])
            self._cmb_type.setFixedWidth(90)
            filter_row.addWidget(self._cmb_type)

            # Mood buttons
            filter_row.addStretch()
            for mood in ["warm", "dunkel", "aggressiv", "ruhig"]:
                btn = QPushButton(mood)
                btn.setFixedWidth(65)
                btn.setStyleSheet("font-size:10px; padding:2px 4px;")
                btn.clicked.connect(
                    lambda checked, m=mood: self._on_mood_search(m)
                )
                filter_row.addWidget(btn)

            layout.addLayout(filter_row)

            # ── Results area ──
            self._results_area = QScrollArea()
            self._results_area.setWidgetResizable(True)
            self._results_widget = QWidget()
            self._results_layout = QVBoxLayout(self._results_widget)
            self._results_layout.setContentsMargins(2, 2, 2, 2)
            self._results_layout.setSpacing(4)
            self._results_layout.addStretch()
            self._results_area.setWidget(self._results_widget)
            layout.addWidget(self._results_area, stretch=1)

            # ── Status ──
            self._lbl_status = QLabel("")
            self._lbl_status.setStyleSheet("color:#888; font-size:10px;")
            layout.addWidget(self._lbl_status)

        def set_services(self, project_service=None, restore=None) -> None:
            self._project_service = project_service
            self._restore = restore
            try:
                from pydaw.services.time_travel_db import TimeTravelDB
                self._db = TimeTravelDB.get()
                self._db.ensure_loaded()
            except Exception:
                pass

        # ══════════════════════════════════════════════════════════
        # Search Logic
        # ══════════════════════════════════════════════════════════

        @pyqtSlot()
        def _on_search(self) -> None:
            """Execute search based on input text and filters."""
            query = self._search_input.text().strip()
            if not query:
                return
            self._execute_search(query)

        def _on_mood_search(self, mood: str) -> None:
            """Search by mood descriptor."""
            # Map mood to search terms
            terms = _MOOD_MAP.get(mood.lower(), [mood])
            query = " OR ".join(terms[:3])
            self._search_input.setText(mood)
            self._execute_search(query)

        def _execute_search(self, query: str) -> None:
            """Run the search and display results."""
            if not self._db:
                self._lbl_status.setText("DB nicht verfuegbar")
                return

            # Save to history
            if query not in self._search_history:
                self._search_history.append(query)
                self._search_history = self._search_history[-20:]

            # Time filter
            after_wc = 0.0
            before_wc = 0.0
            tf_idx = self._cmb_time.currentIndex()
            now = time.time()

            if tf_idx == 1:    # Heute
                today = datetime.now().replace(hour=0, minute=0, second=0)
                after_wc = today.timestamp()
            elif tf_idx == 2:  # Gestern
                yesterday = datetime.now().replace(hour=0, minute=0, second=0) - timedelta(days=1)
                today = datetime.now().replace(hour=0, minute=0, second=0)
                after_wc = yesterday.timestamp()
                before_wc = today.timestamp()
            elif tf_idx == 3:  # Diese Woche
                after_wc = now - 7 * 86400
            elif tf_idx == 4:  # Dieser Monat
                after_wc = now - 30 * 86400
            elif tf_idx == 5:  # Letzte Stunde
                after_wc = now - 3600

            # Execute
            try:
                if after_wc > 0 or before_wc > 0:
                    results = self._db.search_tags_in_timerange(
                        query,
                        after_wall_clock=after_wc,
                        before_wall_clock=before_wc if before_wc > 0 else 0,
                        limit=40,
                    )
                else:
                    results = self._db.search_tags(query, limit=40)
            except Exception as e:
                self._lbl_status.setText(f"Suchfehler: {e}")
                return

            self._display_results(results, query)

        def _display_results(self, results: List[dict], query: str) -> None:
            """Display search results grouped by time."""
            # Clear
            while self._results_layout.count() > 1:
                item = self._results_layout.takeAt(0)
                w = item.widget()
                if w:
                    w.deleteLater()

            if not results:
                self._lbl_status.setText(f"Keine Treffer fuer '{query}'")
                no_results = QLabel("Keine Ergebnisse gefunden.")
                no_results.setStyleSheet("color:#888; font-size:12px; padding:20px;")
                no_results.setAlignment(Qt.AlignmentFlag.AlignCenter)
                idx = self._results_layout.count() - 1
                self._results_layout.insertWidget(idx, no_results)
                return

            self._lbl_status.setText(f"{len(results)} Treffer fuer '{query}'")

            # Group by time period
            groups: Dict[str, List[dict]] = {}
            group_order = ["Heute", "Gestern", "Diese Woche", "Aelter", "Unbekannt"]
            for r in results:
                wc = r.get("wall_clock", 0)
                group = _time_group(wc)
                groups.setdefault(group, []).append(r)

            insert_idx = 0
            for group_name in group_order:
                group_results = groups.get(group_name)
                if not group_results:
                    continue

                # Group header
                header = QLabel(f"— {group_name} ({len(group_results)}) —")
                header.setStyleSheet(
                    "color:#aaa; font-size:11px; font-weight:bold; "
                    "padding: 4px 0 2px 0;"
                )
                self._results_layout.insertWidget(insert_idx, header)
                insert_idx += 1

                for r in group_results:
                    card = self._create_result_card(r)
                    self._results_layout.insertWidget(insert_idx, card)
                    insert_idx += 1

        def _create_result_card(self, result: dict) -> QFrame:
            """Create a result card widget."""
            card = QFrame()
            card.setFrameStyle(QFrame.Shape.NoFrame)
            card.setStyleSheet(
                "QFrame { background: #2a2a32; border-radius: 4px; "
                "padding: 4px; margin: 1px 0; }"
                "QFrame:hover { background: #35354a; }"
            )

            layout = QHBoxLayout(card)
            layout.setContentsMargins(6, 4, 6, 4)
            layout.setSpacing(6)

            # Time
            wc = result.get("wall_clock", 0)
            time_str = _format_wall(wc)
            time_lbl = QLabel(time_str)
            time_lbl.setFixedWidth(90)
            time_lbl.setStyleSheet("color:#88aacc; font-size:11px;")
            layout.addWidget(time_lbl)

            # Tag text as badges
            tag_text = str(result.get("tag_text", ""))
            tags = [t.strip() for t in tag_text.split(",") if t.strip()]

            tags_widget = QWidget()
            tags_layout = QHBoxLayout(tags_widget)
            tags_layout.setContentsMargins(0, 0, 0, 0)
            tags_layout.setSpacing(3)

            for tag in tags[:5]:
                badge = QLabel(tag)
                badge.setStyleSheet(
                    "background: #3a3a50; color: #ccc; "
                    "border-radius: 3px; padding: 1px 5px; "
                    "font-size: 10px;"
                )
                tags_layout.addWidget(badge)
            tags_layout.addStretch()

            layout.addWidget(tags_widget, stretch=1)

            # Preview button
            ms = int(result.get("timestamp_ms", 0))
            btn_preview = QPushButton("Preview")
            btn_preview.setFixedWidth(55)
            btn_preview.setStyleSheet("font-size:10px;")
            btn_preview.clicked.connect(
                lambda checked, t=ms: self.preview_requested.emit(t)
            )
            layout.addWidget(btn_preview)

            # Restore button
            btn_restore = QPushButton("Restore")
            btn_restore.setFixedWidth(55)
            btn_restore.setStyleSheet("font-size:10px; background:#2a5a2a;")
            btn_restore.clicked.connect(
                lambda checked, t=ms: self.restore_requested.emit(t)
            )
            layout.addWidget(btn_restore)

            return card

else:
    class SoundSearchPanel:
        def __init__(self, *a, **kw):
            pass
