"""undo_tree_widget.py — Git-Style Undo Tree Visualisation (Phase T9).

v0.0.20.901 — Phase T9 der TIME_TRAVEL_ROADMAP.

Vertikaler Baum-Graph (QPainter) mit:
- Farbige Knoten pro Branch (wie Git)
- Hover → Snapshot-Info (BPM, Tracks, Tags)
- Klick → Preview, Doppelklick → Switch Branch
- Rechtsklick → Branch/Merge/Delete Kontextmenue
- "Vergleichen" Modus: zwei Knoten nebeneinander
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import (
        Qt, pyqtSignal, pyqtSlot, QRectF, QPointF, QSize, QTimer,
    )
    from PyQt6.QtGui import (
        QPainter, QColor, QPen, QBrush, QFont, QFontMetrics,
        QPainterPath, QMouseEvent, QWheelEvent, QAction,
    )
    from PyQt6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
        QScrollArea, QFrame, QSizePolicy, QToolTip, QMenu,
        QInputDialog, QMessageBox, QLineEdit,
    )
    _QT = True
except ImportError:
    _QT = False

# Branch colors (like Git GUI)
_BRANCH_COLORS = [
    QColor(100, 180, 255) if _QT else None,   # Blue
    QColor(255, 140, 80) if _QT else None,     # Orange
    QColor(120, 220, 120) if _QT else None,    # Green
    QColor(220, 130, 220) if _QT else None,    # Purple
    QColor(255, 220, 80) if _QT else None,     # Yellow
    QColor(130, 220, 220) if _QT else None,    # Cyan
    QColor(255, 130, 130) if _QT else None,    # Red
    QColor(180, 180, 180) if _QT else None,    # Gray
]

_NODE_RADIUS = 8
_ROW_HEIGHT = 50
_COL_WIDTH = 30
_LEFT_MARGIN = 20
_TOP_MARGIN = 20


if _QT:

    class _TreeCanvas(QWidget):
        """Custom QPainter canvas for the undo tree graph."""

        node_clicked = pyqtSignal(int)          # branch_id
        node_double_clicked = pyqtSignal(int)   # branch_id
        node_right_clicked = pyqtSignal(int, object)  # branch_id, QPoint

        def __init__(self, parent=None):
            super().__init__(parent)
            self.setMinimumSize(200, 100)
            self.setMouseTracking(True)
            self._nodes: List[dict] = []  # Flat list of positioned nodes
            self._hovered_id: int = -1
            self._active_id: int = -1

        def set_tree(self, flat_nodes: List[dict], active_id: int) -> None:
            """Set the tree data. Each node dict has:
            id, branch_name, x, y, color_index, parent_id, description, is_active
            """
            self._nodes = flat_nodes
            self._active_id = active_id
            h = max(100, _TOP_MARGIN * 2 + len(flat_nodes) * _ROW_HEIGHT)
            self.setMinimumHeight(h)
            self.update()

        def _node_at(self, pos) -> Optional[dict]:
            for n in self._nodes:
                nx = n.get("x", 0)
                ny = n.get("y", 0)
                if abs(pos.x() - nx) < _NODE_RADIUS + 4 and abs(pos.y() - ny) < _NODE_RADIUS + 4:
                    return n
            return None

        def paintEvent(self, event):
            if not self._nodes:
                return
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            w, h = self.width(), self.height()
            p.fillRect(0, 0, w, h, QColor(28, 28, 32))

            font = QFont("monospace", 9)
            p.setFont(font)

            # Draw edges (parent → child lines)
            for n in self._nodes:
                pid = n.get("parent_id")
                if pid is not None:
                    parent = None
                    for pn in self._nodes:
                        if pn.get("id") == pid:
                            parent = pn
                            break
                    if parent:
                        ci = n.get("color_index", 0) % len(_BRANCH_COLORS)
                        color = _BRANCH_COLORS[ci]
                        pen = QPen(color, 2)
                        p.setPen(pen)
                        px, py = parent["x"], parent["y"]
                        nx, ny = n["x"], n["y"]
                        # Draw L-shaped connector
                        if px != nx:
                            p.drawLine(QPointF(px, py + _NODE_RADIUS),
                                       QPointF(px, ny))
                            p.drawLine(QPointF(px, ny),
                                       QPointF(nx, ny))
                        else:
                            p.drawLine(QPointF(px, py + _NODE_RADIUS),
                                       QPointF(nx, ny - _NODE_RADIUS))

            # Draw nodes
            for n in self._nodes:
                nx, ny = n["x"], n["y"]
                ci = n.get("color_index", 0) % len(_BRANCH_COLORS)
                color = _BRANCH_COLORS[ci]
                is_active = n.get("is_active", False)
                is_hovered = n.get("id") == self._hovered_id

                # Node circle
                if is_active:
                    p.setPen(QPen(QColor(255, 255, 255), 2.5))
                    p.setBrush(QBrush(color))
                    p.drawEllipse(QPointF(nx, ny), _NODE_RADIUS + 2, _NODE_RADIUS + 2)
                elif is_hovered:
                    p.setPen(QPen(color.lighter(130), 2))
                    p.setBrush(QBrush(color.darker(120)))
                    p.drawEllipse(QPointF(nx, ny), _NODE_RADIUS + 1, _NODE_RADIUS + 1)
                else:
                    p.setPen(QPen(color.darker(130), 1.5))
                    p.setBrush(QBrush(color))
                    p.drawEllipse(QPointF(nx, ny), _NODE_RADIUS, _NODE_RADIUS)

                # Branch name label
                name = n.get("branch_name", "")
                desc = n.get("description", "")
                label = name
                if desc and len(desc) < 30:
                    label = f"{name}: {desc}"
                p.setPen(QPen(QColor(200, 200, 210)))
                p.drawText(QPointF(nx + _NODE_RADIUS + 8, ny + 4), label[:40])

            p.end()

        def mouseMoveEvent(self, event: QMouseEvent):
            pos = event.position() if hasattr(event, 'position') else event.localPos()
            node = self._node_at(pos)
            old = self._hovered_id
            self._hovered_id = node.get("id", -1) if node else -1
            if old != self._hovered_id:
                self.update()
            # Tooltip
            if node:
                tip = f"{node.get('branch_name', '')}"
                desc = node.get("description", "")
                if desc:
                    tip += f"\n{desc}"
                QToolTip.showText(event.globalPosition().toPoint(), tip, self)

        def mousePressEvent(self, event: QMouseEvent):
            pos = event.position() if hasattr(event, 'position') else event.localPos()
            node = self._node_at(pos)
            if not node:
                return
            bid = node.get("id", 0)
            if event.button() == Qt.MouseButton.RightButton:
                self.node_right_clicked.emit(bid, event.globalPosition().toPoint())
            else:
                self.node_clicked.emit(bid)

        def mouseDoubleClickEvent(self, event: QMouseEvent):
            pos = event.position() if hasattr(event, 'position') else event.localPos()
            node = self._node_at(pos)
            if node:
                self.node_double_clicked.emit(node.get("id", 0))

    # ──────────────────────────────────────────────────────────

    class UndoTreeWidget(QWidget):
        """Undo Tree panel — shows Git-style branch graph."""

        branch_switched = pyqtSignal(str)  # branch_name

        def __init__(self, parent=None):
            super().__init__(parent)
            self._undo_tree = None
            self._refresh_timer = QTimer(self)
            self._refresh_timer.setInterval(5000)
            self._refresh_timer.timeout.connect(self._refresh)
            self._branch_id_to_name: Dict[int, str] = {}

            self._setup_ui()

        def _setup_ui(self) -> None:
            layout = QVBoxLayout(self)
            layout.setContentsMargins(4, 4, 4, 4)
            layout.setSpacing(4)

            # Header
            header = QHBoxLayout()
            title = QLabel("Undo-Baum")
            title.setStyleSheet("font-weight:bold; font-size:13px; color:#ccc;")
            header.addWidget(title)
            header.addStretch()

            self._lbl_branch = QLabel("Branch: main")
            self._lbl_branch.setStyleSheet("color:#88aacc; font-size:11px;")
            header.addWidget(self._lbl_branch)

            btn_new = QPushButton("+ Branch")
            btn_new.setFixedWidth(70)
            btn_new.clicked.connect(self._on_new_branch)
            header.addWidget(btn_new)

            layout.addLayout(header)

            # Canvas in scroll area
            self._scroll = QScrollArea()
            self._scroll.setWidgetResizable(True)
            self._canvas = _TreeCanvas()
            self._canvas.node_clicked.connect(self._on_node_click)
            self._canvas.node_double_clicked.connect(self._on_node_dblclick)
            self._canvas.node_right_clicked.connect(self._on_node_right_click)
            self._scroll.setWidget(self._canvas)
            layout.addWidget(self._scroll, stretch=1)

            # Status
            self._lbl_status = QLabel("")
            self._lbl_status.setStyleSheet("color:#888; font-size:10px;")
            layout.addWidget(self._lbl_status)

        def set_undo_tree(self, undo_tree) -> None:
            """Wire up the UndoTree service."""
            self._undo_tree = undo_tree
            self._refresh()
            self._refresh_timer.start()

        def showEvent(self, event):
            super().showEvent(event)
            self._refresh_timer.start()
            self._refresh()

        def hideEvent(self, event):
            super().hideEvent(event)
            self._refresh_timer.stop()

        def _refresh(self) -> None:
            if not self._undo_tree:
                return
            info = self._undo_tree.get_info()
            self._lbl_branch.setText(f"Branch: {info.active_branch}")
            self._lbl_status.setText(f"{info.branch_count} Branches")

            # Build flat positioned node list from tree
            roots = self._undo_tree.get_tree_nodes()
            flat: List[dict] = []
            self._branch_id_to_name.clear()

            def _flatten(node, depth: int, col: int, color_idx: int):
                y = _TOP_MARGIN + len(flat) * _ROW_HEIGHT
                x = _LEFT_MARGIN + col * _COL_WIDTH
                flat.append({
                    "id": node.id,
                    "branch_name": node.branch_name,
                    "description": node.description,
                    "is_active": node.is_active,
                    "parent_id": node.parent_branch_id,
                    "x": x, "y": y,
                    "color_index": color_idx,
                })
                self._branch_id_to_name[node.id] = node.branch_name
                for i, child in enumerate(node.children):
                    _flatten(child, depth + 1, col + i + 1, color_idx + i + 1)

            for i, root in enumerate(roots):
                _flatten(root, 0, i, i)

            self._canvas.set_tree(flat, info.active_branch_id)

        def _on_node_click(self, branch_id: int) -> None:
            name = self._branch_id_to_name.get(branch_id, "")
            self._lbl_status.setText(f"Ausgewaehlt: {name}")

        def _on_node_dblclick(self, branch_id: int) -> None:
            name = self._branch_id_to_name.get(branch_id, "")
            if name and self._undo_tree:
                ok = self._undo_tree.switch_branch(name)
                if ok:
                    self._lbl_status.setText(f"Gewechselt zu: {name}")
                    self.branch_switched.emit(name)
                    self._refresh()

        def _on_node_right_click(self, branch_id: int, pos) -> None:
            name = self._branch_id_to_name.get(branch_id, "")
            if not name or not self._undo_tree:
                return

            menu = QMenu(self)

            act_switch = menu.addAction(f"Wechseln zu '{name}'")
            act_switch.triggered.connect(lambda: self._on_node_dblclick(branch_id))

            if name != "main":
                menu.addSeparator()
                act_merge = menu.addAction(f"Merge '{name}' → main")
                act_merge.triggered.connect(lambda: self._on_merge(name))

                act_del = menu.addAction(f"Loeschen '{name}'")
                act_del.triggered.connect(lambda: self._on_delete(name))

            menu.exec(pos)

        def _on_new_branch(self) -> None:
            if not self._undo_tree:
                return
            name, ok = QInputDialog.getText(
                self, "Neuer Branch",
                "Branch-Name:",
                QLineEdit.EchoMode.Normal,
                "experiment",
            )
            if ok and name:
                bid = self._undo_tree.create_branch(name.strip())
                if bid:
                    self._lbl_status.setText(f"Branch '{name}' erstellt (ID {bid})")
                    self._refresh()

        def _on_merge(self, name: str) -> None:
            if not self._undo_tree:
                return
            reply = QMessageBox.question(
                self, "Branch Merge",
                f"'{name}' in 'main' mergen?\nDer Branch wird danach geloescht.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            if reply == QMessageBox.StandardButton.Yes:
                ok = self._undo_tree.merge_branch(name, into="main")
                self._lbl_status.setText(
                    f"Merge {'erfolgreich' if ok else 'fehlgeschlagen'}"
                )
                self._refresh()

        def _on_delete(self, name: str) -> None:
            if not self._undo_tree:
                return
            reply = QMessageBox.question(
                self, "Branch Loeschen",
                f"Branch '{name}' wirklich loeschen?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            if reply == QMessageBox.StandardButton.Yes:
                ok = self._undo_tree.delete_branch(name)
                self._lbl_status.setText(
                    f"Loeschen {'erfolgreich' if ok else 'fehlgeschlagen'}"
                )
                self._refresh()

else:
    class UndoTreeWidget:
        def __init__(self, *a, **kw):
            pass

    class _TreeCanvas:
        pass
