"""sentinel_widgets.py — SENTINEL Health UI Widgets (Phases S4 + S6).

v0.0.20.904 — Phases S4 (Health UI) + S6 (Self-Healing UI)

Widgets:
- SentinelStatusWidget: Herz-Icon in der Status-Bar (gruen/gelb/rot)
- SentinelAlertBanner: Warnung am oberen Fensterrand (Stufe 3+)
- SentinelDashboard: Health Dashboard als Dock-Widget
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import Qt, pyqtSignal, pyqtSlot, QTimer, QSize
    from PyQt6.QtGui import QColor, QFont, QPainter, QBrush, QPen
    from PyQt6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
        QFrame, QScrollArea, QSizePolicy, QToolTip,
    )
    _QT = True
except ImportError:
    _QT = False

if _QT:

    class SentinelStatusWidget(QWidget):
        """Heart icon in the status bar — green/yellow/red."""

        clicked = pyqtSignal()

        def __init__(self, parent=None):
            super().__init__(parent)
            self.setFixedSize(24, 24)
            self.setCursor(Qt.CursorShape.PointingHandCursor)
            self.setToolTip("SENTINEL Health — Klick fuer Details")
            self._status = "healthy"  # healthy, warning, critical
            self._pulse = False

        def set_status(self, status: str) -> None:
            self._status = status
            tip_map = {
                "healthy": "SENTINEL: Alles OK",
                "warning": "SENTINEL: Warnung aktiv",
                "critical": "SENTINEL: Problem erkannt!",
            }
            self.setToolTip(tip_map.get(status, "SENTINEL"))
            self.update()

        def paintEvent(self, event):
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            colors = {
                "healthy": QColor(80, 200, 80),
                "warning": QColor(240, 200, 40),
                "critical": QColor(220, 60, 60),
            }
            color = colors.get(self._status, colors["healthy"])
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(color))
            p.drawEllipse(4, 4, 16, 16)

            # Inner highlight
            p.setBrush(QBrush(color.lighter(140)))
            p.drawEllipse(7, 6, 6, 5)
            p.end()

        def mousePressEvent(self, event):
            self.clicked.emit()

    # ──────────────────────────────────────────────────────

    class SentinelAlertBanner(QWidget):
        """Alert banner at the top of the window (severity 3+).

        Shows warning/error messages with action buttons.
        Non-modal — does NOT block DAW usage.
        """

        action_requested = pyqtSignal(str, int)  # action_type, anomaly_id
        dismissed = pyqtSignal(int)               # anomaly_id

        def __init__(self, parent=None):
            super().__init__(parent)
            self.setFixedHeight(0)  # Hidden by default
            self._visible = False
            self._anomaly_id = 0
            self._action_type = ""

            layout = QHBoxLayout(self)
            layout.setContentsMargins(8, 4, 8, 4)
            layout.setSpacing(8)

            self._icon = QLabel("")
            self._icon.setFixedWidth(20)
            layout.addWidget(self._icon)

            self._lbl_message = QLabel("")
            self._lbl_message.setWordWrap(True)
            layout.addWidget(self._lbl_message, stretch=1)

            self._btn_action = QPushButton("Details")
            self._btn_action.setFixedWidth(70)
            self._btn_action.clicked.connect(self._on_action)
            layout.addWidget(self._btn_action)

            self._btn_undo = QPushButton("Rueckgaengig")
            self._btn_undo.setFixedWidth(90)
            self._btn_undo.clicked.connect(self._on_undo)
            self._btn_undo.setVisible(False)
            layout.addWidget(self._btn_undo)

            self._btn_dismiss = QPushButton("X")
            self._btn_dismiss.setFixedWidth(28)
            self._btn_dismiss.clicked.connect(self._on_dismiss)
            layout.addWidget(self._btn_dismiss)

        def show_alert(self, severity: int, anomaly_type: str,
                         message: str, anomaly_id: int = 0,
                         show_undo: bool = False) -> None:
            self._anomaly_id = anomaly_id
            self._action_type = anomaly_type

            if severity >= 5:
                self.setStyleSheet("background: #8b1a1a; color: white; border-radius: 4px;")
                self._icon.setText("!!!")
            elif severity >= 4:
                self.setStyleSheet("background: #8b4513; color: white; border-radius: 4px;")
                self._icon.setText("!!")
            else:
                self.setStyleSheet("background: #6b6b00; color: white; border-radius: 4px;")
                self._icon.setText("!")

            self._lbl_message.setText(message)
            self._btn_undo.setVisible(show_undo)
            self.setFixedHeight(36)
            self._visible = True

        def hide_alert(self) -> None:
            self.setFixedHeight(0)
            self._visible = False

        @property
        def is_showing(self) -> bool:
            return self._visible

        def _on_action(self):
            self.action_requested.emit(self._action_type, self._anomaly_id)

        def _on_undo(self):
            self.action_requested.emit("undo", self._anomaly_id)
            self.hide_alert()

        def _on_dismiss(self):
            self.dismissed.emit(self._anomaly_id)
            self.hide_alert()

    # ──────────────────────────────────────────────────────

    class SentinelDashboard(QWidget):
        """SENTINEL Health Dashboard — shows metrics, anomalies, crashes.

        Dock-widget for detailed system health overview.
        """

        def __init__(self, parent=None):
            super().__init__(parent)
            self._recorder = None
            self._anomaly = None
            self._db = None
            self._refresh_timer = QTimer(self)
            self._refresh_timer.setInterval(3000)
            self._refresh_timer.timeout.connect(self._refresh)
            self._setup_ui()

        def _setup_ui(self):
            layout = QVBoxLayout(self)
            layout.setContentsMargins(6, 6, 6, 6)
            layout.setSpacing(6)

            # Title
            title = QLabel("SENTINEL Health Dashboard")
            title.setStyleSheet("font-weight:bold; font-size:14px; color:#ccc;")
            layout.addWidget(title)

            # Metrics row
            metrics_frame = QFrame()
            metrics_frame.setStyleSheet("background:#2a2a30; border-radius:4px; padding:6px;")
            ml = QHBoxLayout(metrics_frame)
            ml.setSpacing(16)

            self._lbl_cpu = QLabel("CPU: --")
            self._lbl_cpu.setStyleSheet("color:#8cf; font-size:12px;")
            ml.addWidget(self._lbl_cpu)

            self._lbl_mem = QLabel("RAM: --")
            self._lbl_mem.setStyleSheet("color:#8cf; font-size:12px;")
            ml.addWidget(self._lbl_mem)

            self._lbl_xruns = QLabel("XRuns: 0")
            self._lbl_xruns.setStyleSheet("color:#8cf; font-size:12px;")
            ml.addWidget(self._lbl_xruns)

            self._lbl_threads = QLabel("Threads: --")
            self._lbl_threads.setStyleSheet("color:#8cf; font-size:12px;")
            ml.addWidget(self._lbl_threads)

            self._lbl_status = QLabel("Status: OK")
            self._lbl_status.setStyleSheet("color:#8f8; font-size:12px; font-weight:bold;")
            ml.addWidget(self._lbl_status)

            ml.addStretch()
            layout.addWidget(metrics_frame)

            # Anomalies section
            anom_label = QLabel("Aktive Anomalien")
            anom_label.setStyleSheet("color:#aaa; font-size:11px; font-weight:bold;")
            layout.addWidget(anom_label)

            self._anom_area = QScrollArea()
            self._anom_area.setWidgetResizable(True)
            self._anom_area.setMaximumHeight(150)
            self._anom_widget = QWidget()
            self._anom_layout = QVBoxLayout(self._anom_widget)
            self._anom_layout.setContentsMargins(2, 2, 2, 2)
            self._anom_layout.setSpacing(2)
            self._anom_layout.addStretch()
            self._anom_area.setWidget(self._anom_widget)
            layout.addWidget(self._anom_area)

            # Crashes section
            crash_label = QLabel("Letzte Crashes")
            crash_label.setStyleSheet("color:#aaa; font-size:11px; font-weight:bold;")
            layout.addWidget(crash_label)

            self._crash_area = QScrollArea()
            self._crash_area.setWidgetResizable(True)
            self._crash_area.setMaximumHeight(150)
            self._crash_widget = QWidget()
            self._crash_layout = QVBoxLayout(self._crash_widget)
            self._crash_layout.setContentsMargins(2, 2, 2, 2)
            self._crash_layout.setSpacing(2)
            self._crash_layout.addStretch()
            self._crash_area.setWidget(self._crash_widget)
            layout.addWidget(self._crash_area)

            # Stats
            self._lbl_stats = QLabel("")
            self._lbl_stats.setStyleSheet("color:#666; font-size:10px;")
            layout.addWidget(self._lbl_stats)

            layout.addStretch()

        def set_services(self, recorder=None, anomaly=None) -> None:
            self._recorder = recorder
            self._anomaly = anomaly
            try:
                from pydaw.services.sentinel_db import SentinelDB
                self._db = SentinelDB.get()
                self._db.ensure_loaded()
            except Exception:
                pass

        def showEvent(self, event):
            super().showEvent(event)
            self._refresh_timer.start()
            self._refresh()

        def hideEvent(self, event):
            super().hideEvent(event)
            self._refresh_timer.stop()

        def _refresh(self):
            # Metrics
            if self._recorder and self._recorder._ringbuffer:
                last = self._recorder._ringbuffer[-1]
                self._lbl_cpu.setText(f"CPU: {last.get('cpu', 0):.0f}%")
                self._lbl_mem.setText(f"RAM: {last.get('mem_mb', 0):.0f} MB")
                self._lbl_xruns.setText(f"XRuns: {last.get('xruns', 0)}")
                self._lbl_threads.setText(f"Threads: {last.get('threads', 0)}")

            # Status
            if self._anomaly:
                status = self._anomaly.get_health_status()
                colors = {"healthy": "#8f8", "warning": "#ff0", "critical": "#f66"}
                self._lbl_status.setText(f"Status: {status.upper()}")
                self._lbl_status.setStyleSheet(
                    f"color:{colors.get(status, '#8f8')}; font-size:12px; font-weight:bold;"
                )

            # Anomalies
            if self._db:
                self._update_list(
                    self._anom_layout,
                    self._db.get_active_anomalies(),
                    lambda a: f"[Sev {a.get('severity',1)}] {a.get('anomaly_type','')} — {a.get('description','')}",
                    "#3a2a2a" if True else "#2a2a30",
                )

                crashes = self._db.get_crashes(limit=10)
                self._update_list(
                    self._crash_layout,
                    crashes,
                    lambda c: f"{c.get('crash_type','')} in {c.get('component','')} — {c.get('error_message','')[:60]}",
                    "#2a2a3a",
                )

                stats = self._db.stats()
                self._lbl_stats.setText(
                    f"Events: {stats.get('sentinel_events', 0)} | "
                    f"Anomalien: {stats.get('sentinel_anomalies', 0)} | "
                    f"Crashes: {stats.get('sentinel_crashes', 0)} | "
                    f"Patterns: {stats.get('sentinel_patterns', 0)}"
                )

        def _update_list(self, layout, items, formatter, bg_color):
            while layout.count() > 1:
                item = layout.takeAt(0)
                w = item.widget()
                if w:
                    w.deleteLater()

            for i, item in enumerate(items[:10]):
                lbl = QLabel(formatter(item))
                lbl.setStyleSheet(
                    f"background: {bg_color}; color: #ccc; "
                    f"font-size: 10px; padding: 3px 6px; "
                    f"border-radius: 3px; margin: 1px;"
                )
                lbl.setWordWrap(True)
                layout.insertWidget(i, lbl)

            if not items:
                lbl = QLabel("Keine Eintraege")
                lbl.setStyleSheet("color:#666; font-size:10px; padding:4px;")
                layout.insertWidget(0, lbl)

else:
    class SentinelStatusWidget:
        def __init__(self, *a, **kw): pass

    class SentinelAlertBanner:
        def __init__(self, *a, **kw): pass

    class SentinelDashboard:
        def __init__(self, *a, **kw): pass
