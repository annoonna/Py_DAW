"""time_travel_panel.py — Time-Travel UI Panel (Phase T4 + T5).

v0.0.20.901 — Phases T4 (Time-Travel UI) + T5 (FTS5 Search)

Features:
- Horizontal timeline slider (last 2 hours, configurable)
- Event markers (MIDI=blue, Param=orange, Plugin=green, Snapshot=gray, Bookmark=yellow)
- Click to preview, double-click to restore
- Bookmark button, Capture-last-30s button
- FTS5 full-text search over journal tags
- A/B comparison mode
- Track filter
- Keyboard shortcuts: Ctrl+Shift+Z, Ctrl+B, Ctrl+Shift+B

Architecture:
- TimeTravelPanel: Main panel widget (dockable)
- _TimelineCanvas: Custom QPainter timeline with event markers
- _RestorePointList: Scrollable list of snapshots/bookmarks
- _SearchBar: FTS5 search with result list
"""

from __future__ import annotations

import logging
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import (
        Qt, QTimer, pyqtSignal, pyqtSlot, QRectF, QPointF, QSize,
    )
    from PyQt6.QtGui import (
        QPainter, QColor, QPen, QBrush, QFont, QFontMetrics,
        QPainterPath, QLinearGradient, QMouseEvent, QWheelEvent,
        QKeyEvent, QAction, QShortcut, QKeySequence,
    )
    from PyQt6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QSlider, QPushButton,
        QLabel, QLineEdit, QScrollArea, QFrame, QSplitter,
        QComboBox, QToolButton, QMenu, QSizePolicy, QToolTip,
        QMessageBox, QCheckBox, QGroupBox,
    )
    _QT = True
except ImportError:
    _QT = False


# ── Event type colors ──
_EVENT_COLORS = {
    "midi_note_on": QColor(80, 140, 255) if _QT else None,      # Blue
    "midi_note_off": QColor(80, 140, 255) if _QT else None,
    "midi_cc": QColor(80, 140, 255) if _QT else None,
    "param_change": QColor(255, 160, 50) if _QT else None,      # Orange
    "plugin_load": QColor(80, 200, 120) if _QT else None,       # Green
    "plugin_remove": QColor(80, 200, 120) if _QT else None,
    "preset_change": QColor(80, 200, 120) if _QT else None,
    "transport_play": QColor(180, 180, 180) if _QT else None,   # Gray
    "transport_stop": QColor(180, 180, 180) if _QT else None,
    "transport_bpm": QColor(180, 180, 180) if _QT else None,
    "snapshot": QColor(160, 160, 180) if _QT else None,         # Gray
    "bookmark": QColor(255, 215, 0) if _QT else None,           # Gold
    "time_travel_restore": QColor(200, 100, 200) if _QT else None,  # Purple
}

_DEFAULT_COLOR = QColor(120, 120, 120) if _QT else None


def _format_ms(ms: int) -> str:
    """Format milliseconds as mm:ss."""
    total_s = ms // 1000
    m, s = divmod(abs(total_s), 60)
    sign = "-" if total_s < 0 else ""
    return f"{sign}{m}:{s:02d}"


def _format_wall(wc: float) -> str:
    """Format wall clock as HH:MM:SS."""
    try:
        return datetime.fromtimestamp(wc).strftime("%H:%M:%S")
    except Exception:
        return "??:??:??"


if _QT:

    class _TimelineCanvas(QWidget):
        """Custom-painted timeline showing event density and markers."""

        # Emitted with timestamp_ms when user clicks
        clicked = pyqtSignal(int)
        double_clicked = pyqtSignal(int)
        hover_at = pyqtSignal(int)  # timestamp_ms under cursor

        def __init__(self, parent=None):
            super().__init__(parent)
            self.setMinimumHeight(60)
            self.setMaximumHeight(80)
            self.setMouseTracking(True)
            self.setSizePolicy(QSizePolicy.Policy.Expanding,
                               QSizePolicy.Policy.Fixed)

            self._density: List[Dict[str, Any]] = []
            self._markers: List[Dict[str, Any]] = []
            self._range_start_ms: int = 0
            self._range_end_ms: int = 0
            self._cursor_ms: int = -1  # hovered position
            self._current_ms: int = 0  # current journal position
            self._preview_ms: int = -1  # preview indicator

        def set_data(self, density: List[Dict[str, Any]],
                       markers: List[Dict[str, Any]],
                       range_start_ms: int, range_end_ms: int,
                       current_ms: int) -> None:
            self._density = density
            self._markers = markers
            self._range_start_ms = range_start_ms
            self._range_end_ms = range_end_ms
            self._current_ms = current_ms
            self.update()

        def set_preview_ms(self, ms: int) -> None:
            self._preview_ms = ms
            self.update()

        def _ms_to_x(self, ms: int) -> float:
            rng = max(1, self._range_end_ms - self._range_start_ms)
            return (ms - self._range_start_ms) / rng * self.width()

        def _x_to_ms(self, x: float) -> int:
            rng = max(1, self._range_end_ms - self._range_start_ms)
            return int(self._range_start_ms + (x / max(1, self.width())) * rng)

        def paintEvent(self, event):
            if not self._range_end_ms:
                return
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            w, h = self.width(), self.height()

            # Background
            p.fillRect(0, 0, w, h, QColor(30, 30, 35))

            # Density bars
            if self._density:
                max_count = max((d.get("count", 1) for d in self._density), default=1)
                bar_h = h - 20  # leave room for time labels
                for d in self._density:
                    x1 = self._ms_to_x(d["start_ms"])
                    x2 = self._ms_to_x(d["end_ms"])
                    bw = max(1.0, x2 - x1 - 0.5)
                    ratio = d["count"] / max(1, max_count)
                    bh = max(2, int(ratio * bar_h * 0.7))
                    color = QColor(60, 100, 160, int(80 + 120 * ratio))
                    p.fillRect(QRectF(x1, h - 18 - bh, bw, bh), color)

            # Event markers (colored dots)
            for m in self._markers:
                mx = self._ms_to_x(m.get("timestamp_ms", 0))
                mt = m.get("type", "")
                color = _EVENT_COLORS.get(mt, _DEFAULT_COLOR)
                if mt == "bookmark":
                    # Star marker
                    p.setPen(Qt.PenStyle.NoPen)
                    p.setBrush(QBrush(color))
                    p.drawEllipse(QPointF(mx, 8), 4, 4)
                else:
                    p.setPen(QPen(color, 1.5))
                    p.drawLine(QPointF(mx, h - 18), QPointF(mx, h - 18 - 10))

            # Current position line (white)
            cx = self._ms_to_x(self._current_ms)
            p.setPen(QPen(QColor(255, 255, 255), 1.5))
            p.drawLine(QPointF(cx, 0), QPointF(cx, h - 16))

            # Preview position line (cyan dashed)
            if self._preview_ms >= 0:
                pen = QPen(QColor(0, 220, 255), 1.5, Qt.PenStyle.DashLine)
                p.setPen(pen)
                px = self._ms_to_x(self._preview_ms)
                p.drawLine(QPointF(px, 0), QPointF(px, h - 16))

            # Hover cursor (thin yellow)
            if self._cursor_ms >= 0:
                hx = self._ms_to_x(self._cursor_ms)
                p.setPen(QPen(QColor(255, 255, 100, 120), 1))
                p.drawLine(QPointF(hx, 0), QPointF(hx, h - 16))

            # Time labels
            p.setPen(QPen(QColor(180, 180, 180)))
            font = QFont("monospace", 8)
            p.setFont(font)
            rng = self._range_end_ms - self._range_start_ms
            # Show 5-10 labels
            step = max(10000, rng // 8)
            t = self._range_start_ms
            while t <= self._range_end_ms:
                lx = self._ms_to_x(t)
                label = _format_ms(t)
                p.drawText(QPointF(lx - 15, h - 2), label)
                p.setPen(QPen(QColor(60, 60, 65)))
                p.drawLine(QPointF(lx, h - 16), QPointF(lx, h - 13))
                p.setPen(QPen(QColor(180, 180, 180)))
                t += step

            p.end()

        def mouseMoveEvent(self, event: QMouseEvent):
            pos = event.position() if hasattr(event, 'position') else event.localPos()
            self._cursor_ms = self._x_to_ms(pos.x())
            self.hover_at.emit(self._cursor_ms)
            self.update()

        def leaveEvent(self, event):
            self._cursor_ms = -1
            self.update()

        def mousePressEvent(self, event: QMouseEvent):
            pos = event.position() if hasattr(event, 'position') else event.localPos()
            ms = self._x_to_ms(pos.x())
            self.clicked.emit(ms)

        def mouseDoubleClickEvent(self, event: QMouseEvent):
            pos = event.position() if hasattr(event, 'position') else event.localPos()
            ms = self._x_to_ms(pos.x())
            self.double_clicked.emit(ms)

    # ──────────────────────────────────────────────────────────────
    # Main Panel
    # ──────────────────────────────────────────────────────────────

    class TimeTravelPanel(QWidget):
        """Main Time-Travel panel — dockable widget.

        Shows timeline, event markers, restore points, search.
        """

        restore_requested = pyqtSignal(int)    # timestamp_ms
        preview_requested = pyqtSignal(int)
        bookmark_requested = pyqtSignal(str)   # label

        def __init__(self, parent=None, project_service=None):
            super().__init__(parent)
            self._project_service = project_service
            self._journal = None
            self._restore = None
            self._lookback_ms = 2 * 60 * 60 * 1000  # 2 hours default
            self._refresh_timer = QTimer(self)
            self._refresh_timer.setInterval(3000)  # refresh every 3s
            self._refresh_timer.timeout.connect(self._refresh_timeline)

            self._setup_ui()
            self._setup_shortcuts()

        def _setup_ui(self) -> None:
            layout = QVBoxLayout(self)
            layout.setContentsMargins(4, 4, 4, 4)
            layout.setSpacing(4)

            # ── Header row ──
            header = QHBoxLayout()
            header.setSpacing(6)

            title = QLabel("Time-Travel")
            title.setStyleSheet("font-weight:bold; font-size:13px; color:#ccc;")
            header.addWidget(title)
            header.addStretch()

            # Lookback combo
            self._cmb_lookback = QComboBox()
            self._cmb_lookback.addItems(
                ["5 Min", "15 Min", "30 Min", "1 Std", "2 Std"]
            )
            self._cmb_lookback.setCurrentIndex(4)
            self._cmb_lookback.currentIndexChanged.connect(self._on_lookback_changed)
            self._cmb_lookback.setFixedWidth(80)
            header.addWidget(QLabel("Zeitfenster:"))
            header.addWidget(self._cmb_lookback)

            layout.addLayout(header)

            # ── Timeline canvas ──
            self._canvas = _TimelineCanvas(self)
            self._canvas.clicked.connect(self._on_timeline_click)
            self._canvas.double_clicked.connect(self._on_timeline_dblclick)
            self._canvas.hover_at.connect(self._on_timeline_hover)
            layout.addWidget(self._canvas)

            # ── Status label ──
            self._lbl_status = QLabel("Journal inaktiv")
            self._lbl_status.setStyleSheet("color:#888; font-size:11px;")
            layout.addWidget(self._lbl_status)

            # ── Button row ──
            btn_row = QHBoxLayout()
            btn_row.setSpacing(4)

            self._btn_bookmark = QPushButton("Bookmark (Ctrl+B)")
            self._btn_bookmark.setToolTip("Aktuellen Moment markieren")
            self._btn_bookmark.clicked.connect(self._on_bookmark)
            btn_row.addWidget(self._btn_bookmark)

            self._btn_capture = QPushButton("Capture 30s (Ctrl+Shift+B)")
            self._btn_capture.setToolTip("Letzte 30 Sekunden einfangen")
            self._btn_capture.clicked.connect(self._on_capture_30s)
            btn_row.addWidget(self._btn_capture)

            self._btn_undo_restore = QPushButton("Restore Undo")
            self._btn_undo_restore.setToolTip("Letzten Restore rueckgaengig machen")
            self._btn_undo_restore.clicked.connect(self._on_undo_restore)
            self._btn_undo_restore.setEnabled(False)
            btn_row.addWidget(self._btn_undo_restore)

            btn_row.addStretch()

            # Preview controls
            self._btn_preview_cancel = QPushButton("Preview abbrechen")
            self._btn_preview_cancel.clicked.connect(self._on_preview_cancel)
            self._btn_preview_cancel.setVisible(False)
            btn_row.addWidget(self._btn_preview_cancel)

            self._btn_preview_confirm = QPushButton("Bestaetigen")
            self._btn_preview_confirm.clicked.connect(self._on_preview_confirm)
            self._btn_preview_confirm.setVisible(False)
            self._btn_preview_confirm.setStyleSheet("background:#2a7a2a;")
            btn_row.addWidget(self._btn_preview_confirm)

            layout.addLayout(btn_row)

            # ── Search bar (T5: FTS5 Suche) ──
            search_frame = QFrame()
            search_frame.setFrameStyle(QFrame.Shape.StyledPanel)
            search_layout = QVBoxLayout(search_frame)
            search_layout.setContentsMargins(4, 4, 4, 4)
            search_layout.setSpacing(4)

            search_header = QHBoxLayout()
            search_header.setSpacing(4)
            self._search_input = QLineEdit()
            self._search_input.setPlaceholderText(
                "Suche: 'warm pad', 'filter sweep', 'Surge XT'..."
            )
            self._search_input.returnPressed.connect(self._on_search)
            search_header.addWidget(self._search_input)

            self._btn_search = QPushButton("Suchen")
            self._btn_search.clicked.connect(self._on_search)
            self._btn_search.setFixedWidth(70)
            search_header.addWidget(self._btn_search)

            # Time filter
            self._cmb_time_filter = QComboBox()
            self._cmb_time_filter.addItems([
                "Alle", "Heute", "Letzte Stunde", "Diese Woche",
            ])
            self._cmb_time_filter.setFixedWidth(100)
            search_header.addWidget(self._cmb_time_filter)

            search_layout.addLayout(search_header)

            # Search results list
            self._search_results_area = QScrollArea()
            self._search_results_area.setWidgetResizable(True)
            self._search_results_area.setMaximumHeight(150)
            self._search_results_widget = QWidget()
            self._search_results_layout = QVBoxLayout(self._search_results_widget)
            self._search_results_layout.setContentsMargins(2, 2, 2, 2)
            self._search_results_layout.setSpacing(2)
            self._search_results_layout.addStretch()
            self._search_results_area.setWidget(self._search_results_widget)
            search_layout.addWidget(self._search_results_area)

            layout.addWidget(search_frame)

            # ── Restore points list ──
            self._restore_area = QScrollArea()
            self._restore_area.setWidgetResizable(True)
            self._restore_area.setMinimumHeight(80)
            self._restore_widget = QWidget()
            self._restore_layout = QVBoxLayout(self._restore_widget)
            self._restore_layout.setContentsMargins(2, 2, 2, 2)
            self._restore_layout.setSpacing(2)
            self._restore_layout.addStretch()
            self._restore_area.setWidget(self._restore_widget)

            rp_label = QLabel("Restore-Punkte")
            rp_label.setStyleSheet("color:#aaa; font-size:11px; font-weight:bold;")
            layout.addWidget(rp_label)
            layout.addWidget(self._restore_area)

        def _setup_shortcuts(self) -> None:
            """Register keyboard shortcuts (Ctrl+B, Ctrl+Shift+B, Ctrl+Shift+Z)."""
            try:
                sc_bookmark = QShortcut(QKeySequence("Ctrl+B"), self)
                sc_bookmark.activated.connect(self._on_bookmark)

                sc_capture = QShortcut(QKeySequence("Ctrl+Shift+B"), self)
                sc_capture.activated.connect(self._on_capture_30s)

                sc_open = QShortcut(QKeySequence("Ctrl+Shift+Z"), self)
                sc_open.activated.connect(self._toggle_visibility)
            except Exception:
                pass

        # ══════════════════════════════════════════════════════════
        # Service Wiring
        # ══════════════════════════════════════════════════════════

        def set_services(self, project_service=None, journal=None,
                           restore=None) -> None:
            """Wire up services after construction."""
            self._project_service = project_service
            self._journal = journal
            self._restore = restore
            if journal and journal.is_running:
                self._refresh_timer.start()
                self._refresh_timeline()

        def showEvent(self, event) -> None:
            super().showEvent(event)
            self._refresh_timer.start()
            self._refresh_timeline()

        def hideEvent(self, event) -> None:
            super().hideEvent(event)
            self._refresh_timer.stop()

        # ══════════════════════════════════════════════════════════
        # Timeline Refresh
        # ══════════════════════════════════════════════════════════

        def _refresh_timeline(self) -> None:
            """Refresh the timeline canvas with current journal data."""
            if not self._journal or not self._journal.is_running:
                self._lbl_status.setText("Journal inaktiv")
                return

            if not self._restore:
                return

            session_id = self._journal.session_id
            current_ms = self._journal._timestamp_ms()

            # Range
            range_start = max(0, current_ms - self._lookback_ms)
            range_end = current_ms

            # Get density data
            bucket_ms = max(1000, self._lookback_ms // 100)
            density = self._restore.get_event_density(
                session_id, bucket_ms=bucket_ms, max_buckets=120
            )

            # Get markers (bookmarks + snapshots)
            markers = []
            points = self._restore.get_available_restore_points(session_id)
            for pt in points:
                ms = pt.get("timestamp_ms", 0)
                if range_start <= ms <= range_end:
                    markers.append({
                        "timestamp_ms": ms,
                        "type": pt.get("type", "snapshot"),
                        "label": pt.get("label", ""),
                    })

            self._canvas.set_data(density, markers, range_start, range_end,
                                   current_ms)

            # Update status
            event_count = self._journal.event_count
            self._lbl_status.setText(
                f"Session: {session_id[:12]}... | "
                f"{event_count} Events | "
                f"Pos: {_format_ms(current_ms)}"
            )

            # Update restore points list
            self._update_restore_points(points)

            # Enable/disable undo button
            if self._restore:
                self._btn_undo_restore.setEnabled(
                    self._restore.last_safety_snapshot_id > 0
                )

            # Preview buttons
            in_preview = self._restore.in_preview if self._restore else False
            self._btn_preview_cancel.setVisible(in_preview)
            self._btn_preview_confirm.setVisible(in_preview)

        def _update_restore_points(self, points: List[dict]) -> None:
            """Update the restore points list widget."""
            # Clear existing
            while self._restore_layout.count() > 1:
                item = self._restore_layout.takeAt(0)
                w = item.widget()
                if w:
                    w.deleteLater()

            for pt in points[:20]:
                row = QFrame()
                row.setFrameStyle(QFrame.Shape.NoFrame)
                row.setStyleSheet(
                    "QFrame { background: #2a2a30; border-radius: 3px; "
                    "padding: 2px; margin: 1px; }"
                    "QFrame:hover { background: #35354a; }"
                )
                rl = QHBoxLayout(row)
                rl.setContentsMargins(4, 2, 4, 2)
                rl.setSpacing(4)

                # Icon
                ptype = pt.get("type", "snapshot")
                icon_text = {"snapshot": "cam", "bookmark": "star"}.get(ptype, "?")
                icon_lbl = QLabel(icon_text)
                icon_lbl.setFixedWidth(24)
                icon_lbl.setStyleSheet(
                    f"color: {'#ffd700' if ptype == 'bookmark' else '#888'}; "
                    f"font-size: 10px;"
                )
                rl.addWidget(icon_lbl)

                # Time + label
                wc = pt.get("wall_clock", 0)
                ms = pt.get("timestamp_ms", 0)
                label = pt.get("label", "")
                time_str = _format_wall(wc) if wc else _format_ms(ms)
                text = f"{time_str}"
                if label:
                    text += f"  {label[:40]}"
                lbl = QLabel(text)
                lbl.setStyleSheet("color: #ccc; font-size: 11px;")
                rl.addWidget(lbl, stretch=1)

                # Preview button
                btn_prev = QPushButton("Preview")
                btn_prev.setFixedWidth(55)
                btn_prev.setStyleSheet("font-size:10px;")
                ts = ms
                btn_prev.clicked.connect(
                    lambda checked, t=ts: self._on_preview_at(t)
                )
                rl.addWidget(btn_prev)

                # Restore button
                btn_rest = QPushButton("Restore")
                btn_rest.setFixedWidth(55)
                btn_rest.setStyleSheet("font-size:10px; background:#2a5a2a;")
                btn_rest.clicked.connect(
                    lambda checked, t=ts: self._on_restore_at(t)
                )
                rl.addWidget(btn_rest)

                idx = self._restore_layout.count() - 1
                self._restore_layout.insertWidget(idx, row)

        # ══════════════════════════════════════════════════════════
        # Timeline Interaction
        # ══════════════════════════════════════════════════════════

        def _on_timeline_click(self, ms: int) -> None:
            """Single click on timeline -> preview."""
            self._on_preview_at(ms)

        def _on_timeline_dblclick(self, ms: int) -> None:
            """Double click on timeline -> restore."""
            self._on_restore_at(ms)

        def _on_timeline_hover(self, ms: int) -> None:
            """Show tooltip with event info at hover position."""
            pass  # Could show tooltip with event details

        # ══════════════════════════════════════════════════════════
        # Actions
        # ══════════════════════════════════════════════════════════

        @pyqtSlot()
        def _on_bookmark(self) -> None:
            """Set a bookmark at the current moment."""
            if not self._journal or not self._journal.is_running:
                return
            self._journal.bookmark("")
            self._refresh_timeline()
            self.bookmark_requested.emit("")

        @pyqtSlot()
        def _on_capture_30s(self) -> None:
            """Capture the last 30 seconds (all events)."""
            if not self._journal or not self._journal.is_running:
                return
            self._journal.bookmark("Capture 30s")
            # Force a snapshot
            try:
                self._journal._take_snapshot()
            except Exception:
                pass
            self._lbl_status.setText("Letzte 30s eingefangen!")
            self._refresh_timeline()

        @pyqtSlot()
        def _on_undo_restore(self) -> None:
            """Undo the last restore operation."""
            if not self._restore:
                return
            result = self._restore.undo_restore()
            if result.success:
                self._lbl_status.setText(result.message)
            else:
                self._lbl_status.setText(f"Undo fehlgeschlagen: {result.message}")
            self._refresh_timeline()

        def _on_preview_at(self, timestamp_ms: int) -> None:
            """Preview DAW state at a given timestamp."""
            if not self._restore:
                return
            result = self._restore.preview_at(timestamp_ms)
            if result.success:
                self._canvas.set_preview_ms(timestamp_ms)
                self._lbl_status.setText(
                    f"Preview @ {_format_ms(timestamp_ms)} — "
                    f"{result.tracks_restored} Tracks"
                )
            else:
                self._lbl_status.setText(f"Preview fehlgeschlagen: {result.message}")
            self._btn_preview_cancel.setVisible(True)
            self._btn_preview_confirm.setVisible(True)

        def _on_restore_at(self, timestamp_ms: int) -> None:
            """Restore DAW state to a given timestamp."""
            if not self._restore:
                return
            # Cancel any active preview first
            if self._restore.in_preview:
                self._restore.cancel_preview()

            result = self._restore.restore_to_timestamp(timestamp_ms)
            if result.success:
                self._lbl_status.setText(result.message)
            else:
                self._lbl_status.setText(f"Restore fehlgeschlagen: {result.message}")
            self._canvas.set_preview_ms(-1)
            self._refresh_timeline()

        @pyqtSlot()
        def _on_preview_cancel(self) -> None:
            if self._restore:
                self._restore.cancel_preview()
            self._canvas.set_preview_ms(-1)
            self._btn_preview_cancel.setVisible(False)
            self._btn_preview_confirm.setVisible(False)
            self._lbl_status.setText("Preview abgebrochen")
            self._refresh_timeline()

        @pyqtSlot()
        def _on_preview_confirm(self) -> None:
            if self._restore:
                self._restore.confirm_preview()
            self._canvas.set_preview_ms(-1)
            self._btn_preview_cancel.setVisible(False)
            self._btn_preview_confirm.setVisible(False)
            self._lbl_status.setText("State uebernommen")
            self._refresh_timeline()

        def _on_lookback_changed(self, index: int) -> None:
            lookup = {
                0: 5 * 60 * 1000,
                1: 15 * 60 * 1000,
                2: 30 * 60 * 1000,
                3: 60 * 60 * 1000,
                4: 2 * 60 * 60 * 1000,
            }
            self._lookback_ms = lookup.get(index, 2 * 60 * 60 * 1000)
            self._refresh_timeline()

        def _toggle_visibility(self) -> None:
            self.setVisible(not self.isVisible())

        # ══════════════════════════════════════════════════════════
        # T5: FTS5 Search
        # ══════════════════════════════════════════════════════════

        @pyqtSlot()
        def _on_search(self) -> None:
            """Execute FTS5 search over journal tags."""
            query = self._search_input.text().strip()
            if not query:
                return

            db = None
            try:
                from pydaw.services.time_travel_db import TimeTravelDB
                db = TimeTravelDB.get()
                db.ensure_loaded()
            except Exception:
                return

            # Time filter
            after_wc = 0.0
            tf_idx = self._cmb_time_filter.currentIndex()
            now = time.time()
            if tf_idx == 1:   # Heute
                # Start of today
                from datetime import datetime as _dt
                today = _dt.now().replace(hour=0, minute=0, second=0)
                after_wc = today.timestamp()
            elif tf_idx == 2:  # Letzte Stunde
                after_wc = now - 3600
            elif tf_idx == 3:  # Diese Woche
                after_wc = now - 7 * 86400

            # Execute search
            if after_wc > 0:
                results = db.search_tags_in_timerange(query, after_wall_clock=after_wc)
            else:
                results = db.search_tags(query)

            self._display_search_results(results)

        def _display_search_results(self, results: List[dict]) -> None:
            """Display search results in the search area."""
            # Clear existing
            while self._search_results_layout.count() > 1:
                item = self._search_results_layout.takeAt(0)
                w = item.widget()
                if w:
                    w.deleteLater()

            if not results:
                lbl = QLabel("Keine Treffer")
                lbl.setStyleSheet("color:#888; font-size:11px;")
                self._search_results_layout.insertWidget(0, lbl)
                return

            for i, r in enumerate(results[:15]):
                row = QFrame()
                row.setStyleSheet(
                    "QFrame { background: #2a2a35; border-radius: 3px; "
                    "padding: 2px; margin: 1px; }"
                    "QFrame:hover { background: #35354a; }"
                )
                rl = QHBoxLayout(row)
                rl.setContentsMargins(4, 2, 4, 2)
                rl.setSpacing(4)

                # Tag text
                tag = str(r.get("tag_text", ""))[:50]
                wc = r.get("wall_clock", 0)
                time_str = _format_wall(wc) if wc else "?"
                sid = str(r.get("session_id", ""))[:8]

                lbl = QLabel(f"{time_str} | {tag}")
                lbl.setStyleSheet("color: #ccc; font-size: 11px;")
                rl.addWidget(lbl, stretch=1)

                # Preview button
                ms = int(r.get("timestamp_ms", 0))
                btn = QPushButton("Preview")
                btn.setFixedWidth(55)
                btn.setStyleSheet("font-size:10px;")
                btn.clicked.connect(
                    lambda checked, t=ms: self._on_preview_at(t)
                )
                rl.addWidget(btn)

                # Restore button
                btn_r = QPushButton("Restore")
                btn_r.setFixedWidth(55)
                btn_r.setStyleSheet("font-size:10px; background:#2a5a2a;")
                btn_r.clicked.connect(
                    lambda checked, t=ms: self._on_restore_at(t)
                )
                rl.addWidget(btn_r)

                idx = self._search_results_layout.count() - 1
                self._search_results_layout.insertWidget(idx, row)

else:
    # No Qt fallback
    class _TimelineCanvas:
        pass

    class TimeTravelPanel:
        def __init__(self, *a, **kw):
            pass
