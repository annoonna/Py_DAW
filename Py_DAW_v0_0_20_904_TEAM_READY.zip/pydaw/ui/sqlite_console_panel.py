"""sqlite_console_panel.py — Integrierter SQLite-Browser & Editor.

v0.0.20.897 — Wie die Python-Console, aber für die Datenbank.

Features:
- Tabellen-Liste links (Klick → Daten anzeigen)
- Daten-Tabelle rechts (Doppelklick → Wert bearbeiten → Enter → gespeichert)
- SQL-Console unten (beliebiges SQL ausführen)
- Nur pydaw.db — sicher, kein Projekt-JSON betroffen

Erreichbar via:
- Menü: Ansicht → SQLite Console
- SQLite-Badge Rechtsklick → "Console öffnen"
"""

from __future__ import annotations

import logging
import sqlite3
import time
from pathlib import Path
from typing import List, Optional, Any

try:
    from PyQt6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
        QListWidget, QListWidgetItem, QTableWidget, QTableWidgetItem,
        QLineEdit, QTextEdit, QPushButton, QLabel, QHeaderView,
        QMessageBox, QComboBox, QGroupBox,
    )
    from PyQt6.QtCore import Qt, pyqtSignal
    from PyQt6.QtGui import QFont, QColor
    _QT = True
except ImportError:
    _QT = False

log = logging.getLogger(__name__)

_DB_DIR = Path.home() / ".config" / "ChronoScaleStudio"

_DB_FILES = {
    "pydaw.db": "Haupt-DB",
    "preset_database.db": "Preset-DB",
    "param_registry.db": "Param-Registry",
}


if _QT:
    class SQLiteConsolePanel(QWidget):
        """Integrated SQLite browser and editor panel."""

        status_message = pyqtSignal(str)

        def __init__(self, parent=None):
            super().__init__(parent)
            self.setObjectName("sqliteConsolePanel")
            self._current_db: Optional[str] = None
            self._current_table: Optional[str] = None
            self._conn: Optional[sqlite3.Connection] = None
            self._columns: List[str] = []
            self._build_ui()
            self._select_db("pydaw.db")

        def _build_ui(self):
            main_layout = QVBoxLayout(self)
            main_layout.setContentsMargins(4, 4, 4, 4)
            main_layout.setSpacing(4)

            # Top: DB selector
            top_row = QHBoxLayout()
            top_row.addWidget(QLabel("Datenbank:"))
            self._cmb_db = QComboBox()
            for fname, label in _DB_FILES.items():
                self._cmb_db.addItem(f"{label} ({fname})", fname)
            self._cmb_db.currentIndexChanged.connect(self._on_db_changed)
            top_row.addWidget(self._cmb_db, 1)
            self._lbl_status = QLabel("")
            self._lbl_status.setStyleSheet("color: #888; font-size: 10px;")
            top_row.addWidget(self._lbl_status)
            main_layout.addLayout(top_row)

            # Main splitter: table list | data view
            splitter_h = QSplitter(Qt.Orientation.Horizontal)

            # Left: table list
            left_box = QGroupBox("Tabellen")
            left_layout = QVBoxLayout(left_box)
            left_layout.setContentsMargins(2, 2, 2, 2)
            self._table_list = QListWidget()
            self._table_list.currentItemChanged.connect(self._on_table_selected)
            left_layout.addWidget(self._table_list)
            self._lbl_table_info = QLabel("")
            self._lbl_table_info.setStyleSheet("font-size: 9px; color: #888;")
            left_layout.addWidget(self._lbl_table_info)
            splitter_h.addWidget(left_box)

            # Right: data table + SQL console (vertical split)
            right_widget = QWidget()
            right_layout = QVBoxLayout(right_widget)
            right_layout.setContentsMargins(0, 0, 0, 0)
            right_layout.setSpacing(4)

            # Data table (editable)
            self._data_table = QTableWidget()
            self._data_table.setAlternatingRowColors(True)
            self._data_table.cellChanged.connect(self._on_cell_changed)
            self._data_table.setStyleSheet(
                "QTableWidget { font-size: 11px; }"
                "QHeaderView::section { font-size: 10px; font-weight: bold; }"
            )
            right_layout.addWidget(self._data_table, 3)

            # SQL Console
            sql_group = QGroupBox("SQL Console")
            sql_layout = QVBoxLayout(sql_group)
            sql_layout.setContentsMargins(4, 4, 4, 4)
            sql_layout.setSpacing(2)

            self._sql_input = QLineEdit()
            self._sql_input.setPlaceholderText("SQL eingeben... (z.B. SELECT * FROM settings LIMIT 10)")
            self._sql_input.setFont(QFont("monospace", 10))
            self._sql_input.returnPressed.connect(self._execute_sql)
            sql_layout.addWidget(self._sql_input)

            btn_row = QHBoxLayout()
            btn_exec = QPushButton("▶ Ausführen")
            btn_exec.clicked.connect(self._execute_sql)
            btn_row.addWidget(btn_exec)
            btn_row.addStretch()

            self._lbl_sql_status = QLabel("")
            self._lbl_sql_status.setStyleSheet("font-size: 10px;")
            btn_row.addWidget(self._lbl_sql_status)
            sql_layout.addLayout(btn_row)

            self._sql_output = QTextEdit()
            self._sql_output.setReadOnly(True)
            self._sql_output.setFont(QFont("monospace", 9))
            self._sql_output.setMaximumHeight(150)
            self._sql_output.setStyleSheet("background: #1a1d23; color: #c8d0e0;")
            sql_layout.addWidget(self._sql_output)

            right_layout.addWidget(sql_group, 1)
            splitter_h.addWidget(right_widget)

            splitter_h.setSizes([180, 500])
            main_layout.addWidget(splitter_h, 1)

        # ── DB Connection ────────────────────────────────────────────

        def _select_db(self, filename: str) -> None:
            """Open a DB file."""
            if self._conn:
                try:
                    self._conn.close()
                except Exception:
                    pass
            self._current_db = filename
            db_path = _DB_DIR / filename
            if not db_path.exists():
                self._lbl_status.setText("❌ DB nicht vorhanden")
                self._table_list.clear()
                return
            try:
                self._conn = sqlite3.connect(str(db_path))
                self._conn.row_factory = sqlite3.Row
                self._load_table_list()
                size = db_path.stat().st_size
                if size < 1024:
                    s = f"{size} B"
                elif size < 1024 * 1024:
                    s = f"{size / 1024:.1f} KB"
                else:
                    s = f"{size / (1024*1024):.2f} MB"
                self._lbl_status.setText(f"✅ {s}")
            except Exception as e:
                self._lbl_status.setText(f"❌ {e}")

        def _on_db_changed(self, index: int) -> None:
            fname = self._cmb_db.itemData(index)
            if fname:
                self._select_db(str(fname))

        # ── Table List ───────────────────────────────────────────────

        def _load_table_list(self) -> None:
            self._table_list.clear()
            if not self._conn:
                return
            try:
                tables = self._conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
                ).fetchall()
                for t in tables:
                    name = t["name"]
                    try:
                        row = self._conn.execute(
                            f"SELECT COUNT(*) as cnt FROM [{name}]"
                        ).fetchone()
                        cnt = int(row["cnt"]) if row else 0
                    except Exception:
                        cnt = 0
                    item = QListWidgetItem(f"{name} ({cnt})")
                    item.setData(Qt.ItemDataRole.UserRole, name)
                    if cnt > 0:
                        item.setForeground(QColor("#c8d0e0"))
                    else:
                        item.setForeground(QColor("#555"))
                    self._table_list.addItem(item)
                self._lbl_table_info.setText(f"{len(tables)} Tabellen")
            except Exception as e:
                self._lbl_table_info.setText(f"Fehler: {e}")

        def _on_table_selected(self, current, previous) -> None:
            if current is None:
                return
            table_name = current.data(Qt.ItemDataRole.UserRole)
            if table_name:
                self._load_table_data(str(table_name))

        # ── Data View ────────────────────────────────────────────────

        def _load_table_data(self, table_name: str, limit: int = 200) -> None:
            """Load table contents into the data grid."""
            self._current_table = table_name
            self._data_table.blockSignals(True)
            self._data_table.clear()

            if not self._conn:
                self._data_table.blockSignals(False)
                return

            try:
                # Get columns
                cols = self._conn.execute(
                    f"PRAGMA table_info([{table_name}])"
                ).fetchall()
                self._columns = [c["name"] for c in cols]
                pk_col = None
                for c in cols:
                    if c["pk"] == 1:
                        pk_col = c["name"]
                        break

                # Get data
                rows = self._conn.execute(
                    f"SELECT * FROM [{table_name}] LIMIT ?", (limit,)
                ).fetchall()

                self._data_table.setColumnCount(len(self._columns))
                self._data_table.setRowCount(len(rows))
                self._data_table.setHorizontalHeaderLabels(self._columns)

                for r_idx, row in enumerate(rows):
                    for c_idx, col_name in enumerate(self._columns):
                        val = row[col_name]
                        item = QTableWidgetItem(str(val) if val is not None else "")
                        # Store original value for change detection
                        item.setData(Qt.ItemDataRole.UserRole, val)
                        # Make PK column read-only
                        if col_name == pk_col:
                            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                            item.setForeground(QColor("#666"))
                        self._data_table.setItem(r_idx, c_idx, item)

                # Auto-resize
                try:
                    header = self._data_table.horizontalHeader()
                    header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
                    # Let last column stretch
                    if len(self._columns) > 0:
                        header.setSectionResizeMode(
                            len(self._columns) - 1,
                            QHeaderView.ResizeMode.Stretch,
                        )
                except Exception:
                    pass

                total = self._conn.execute(
                    f"SELECT COUNT(*) as cnt FROM [{table_name}]"
                ).fetchone()
                total_cnt = int(total["cnt"]) if total else 0
                showing = min(limit, total_cnt)
                self._lbl_table_info.setText(
                    f"{table_name}: {showing}/{total_cnt} Zeilen"
                )

            except Exception as e:
                self._lbl_table_info.setText(f"Fehler: {e}")

            self._data_table.blockSignals(False)

        # ── Cell Editing ─────────────────────────────────────────────

        def _on_cell_changed(self, row: int, col: int) -> None:
            """Handle cell edit — write change to DB."""
            if not self._conn or not self._current_table:
                return
            if col >= len(self._columns):
                return

            item = self._data_table.item(row, col)
            if item is None:
                return

            new_val = item.text()
            old_val = item.data(Qt.ItemDataRole.UserRole)

            # No change
            if str(new_val) == str(old_val if old_val is not None else ""):
                return

            col_name = self._columns[col]

            # Find PK value for this row
            pk_col = None
            pk_val = None
            try:
                cols_info = self._conn.execute(
                    f"PRAGMA table_info([{self._current_table}])"
                ).fetchall()
                for c in cols_info:
                    if c["pk"] == 1:
                        pk_col = c["name"]
                        break
            except Exception:
                pass

            if pk_col:
                pk_idx = self._columns.index(pk_col) if pk_col in self._columns else -1
                if pk_idx >= 0:
                    pk_item = self._data_table.item(row, pk_idx)
                    if pk_item:
                        pk_val = pk_item.data(Qt.ItemDataRole.UserRole)

            if pk_col is None or pk_val is None:
                self._show_sql_output(
                    f"⚠️ Kann nicht speichern: keine Primary Key Spalte gefunden.",
                    error=True,
                )
                return

            # Execute UPDATE
            try:
                sql = f"UPDATE [{self._current_table}] SET [{col_name}] = ? WHERE [{pk_col}] = ?"
                self._conn.execute(sql, (new_val, pk_val))
                self._conn.commit()
                # Update stored original value
                item.setData(Qt.ItemDataRole.UserRole, new_val)
                # Flash green
                item.setBackground(QColor(40, 80, 40))
                self._show_sql_output(
                    f"✅ {self._current_table}.{col_name} = '{new_val}' "
                    f"(WHERE {pk_col}={pk_val})"
                )
                self.status_message.emit(
                    f"DB: {self._current_table}.{col_name} geändert"
                )
                # Refresh table list counts
                self._load_table_list()
            except Exception as e:
                item.setBackground(QColor(80, 30, 30))
                self._show_sql_output(f"❌ UPDATE fehlgeschlagen: {e}", error=True)

        # ── SQL Console ──────────────────────────────────────────────

        def _execute_sql(self) -> None:
            """Execute SQL from the input field."""
            sql = self._sql_input.text().strip()
            if not sql:
                return
            if not self._conn:
                self._show_sql_output("❌ Keine DB-Verbindung", error=True)
                return

            # Safety check for destructive operations
            sql_upper = sql.upper().strip()
            if any(sql_upper.startswith(kw) for kw in ("DROP ", "ALTER ", "TRUNCATE ")):
                reply = QMessageBox.warning(
                    self,
                    "Gefährliche Operation",
                    f"Dieses SQL könnte die Datenbank-Struktur ändern:\n\n{sql}\n\n"
                    f"Wirklich ausführen?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No,
                )
                if reply != QMessageBox.StandardButton.Yes:
                    return

            start = time.time()
            try:
                if sql_upper.startswith("SELECT ") or sql_upper.startswith("PRAGMA "):
                    # Read query → show results
                    rows = self._conn.execute(sql).fetchall()
                    elapsed = (time.time() - start) * 1000

                    if not rows:
                        self._show_sql_output(
                            f"(leere Ergebnismenge) — {elapsed:.1f}ms"
                        )
                        self._lbl_sql_status.setText(f"0 Zeilen, {elapsed:.1f}ms")
                        return

                    # Format as text table
                    cols = rows[0].keys()
                    lines = [" | ".join(str(c) for c in cols)]
                    lines.append("-" * len(lines[0]))
                    for row in rows[:100]:
                        vals = []
                        for c in cols:
                            v = row[c]
                            s = str(v) if v is not None else "NULL"
                            if len(s) > 60:
                                s = s[:57] + "..."
                            vals.append(s)
                        lines.append(" | ".join(vals))

                    if len(rows) > 100:
                        lines.append(f"... ({len(rows)} Zeilen gesamt, 100 angezeigt)")

                    self._show_sql_output("\n".join(lines))
                    self._lbl_sql_status.setText(
                        f"{len(rows)} Zeilen, {elapsed:.1f}ms"
                    )
                else:
                    # Write query (INSERT/UPDATE/DELETE)
                    cursor = self._conn.execute(sql)
                    self._conn.commit()
                    elapsed = (time.time() - start) * 1000
                    affected = cursor.rowcount
                    self._show_sql_output(
                        f"✅ {affected} Zeile(n) betroffen — {elapsed:.1f}ms"
                    )
                    self._lbl_sql_status.setText(
                        f"{affected} geändert, {elapsed:.1f}ms"
                    )
                    # Refresh view
                    self._load_table_list()
                    if self._current_table:
                        self._load_table_data(self._current_table)

            except Exception as e:
                elapsed = (time.time() - start) * 1000
                self._show_sql_output(f"❌ {e}", error=True)
                self._lbl_sql_status.setText(f"Fehler, {elapsed:.1f}ms")

        def _show_sql_output(self, text: str, error: bool = False) -> None:
            """Append text to SQL output area."""
            ts = time.strftime("%H:%M:%S")
            prefix = f"[{ts}] "
            if error:
                self._sql_output.append(
                    f'<span style="color:#f44;">{prefix}{text}</span>'
                )
            else:
                self._sql_output.append(f"{prefix}{text}")
            # Auto-scroll
            sb = self._sql_output.verticalScrollBar()
            if sb:
                sb.setValue(sb.maximum())

        # ── Cleanup ──────────────────────────────────────────────────

        def closeEvent(self, event):
            if self._conn:
                try:
                    self._conn.close()
                except Exception:
                    pass
            super().closeEvent(event)

else:
    class SQLiteConsolePanel:  # type: ignore
        """Fallback stub."""
        def __init__(self, *a, **kw):
            pass
