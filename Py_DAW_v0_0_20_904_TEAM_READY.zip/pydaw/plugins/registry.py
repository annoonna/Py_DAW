# -*- coding: utf-8 -*-
"""Plugin registry for instruments/effects.

This keeps the core DAW decoupled from optional plugin modules.
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
from typing import Callable

from PyQt6.QtWidgets import QWidget

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class InstrumentSpec:
    plugin_id: str
    name: str
    vendor: str = "ChronoScaleStudio"
    category: str = "Instrument"
    description: str = ""
    factory: Callable[..., QWidget] = lambda **_: QWidget()


def get_instruments() -> list[InstrumentSpec]:
    instruments: list[InstrumentSpec] = []

    # Pro Audio Sampler (Qt6)
    try:
        from pydaw.plugins.sampler import SamplerWidget
        instruments.append(
            InstrumentSpec(
                plugin_id="chrono.pro_audio_sampler",
                name="Pro Audio Sampler",
                vendor="ChronoScaleStudio",
                category="Sampler",
                description="WAV Sampler mit Pitch/Filter/FX/ADHSR, Preview-Sync (PianoRoll/Notation).",
                factory=lambda project_service=None, audio_engine=None, automation_manager=None, **_: SamplerWidget(
                    project_service=project_service,
                    audio_engine=audio_engine,
                    automation_manager=automation_manager,
                ),
            )
        )
    except Exception:
        log.exception("Failed to load instrument plugin: sampler")

    # Bachs Orgel (Qt6)
    try:
        from pydaw.plugins.bach_orgel import BachOrgelWidget
        instruments.append(
            InstrumentSpec(
                plugin_id="chrono.bach_orgel",
                name="Bachs Orgel",
                vendor="ChronoScaleStudio",
                category="Orgel",
                description="Barocke Orgel-Synthese mit Presets (Gottesdienst/Plenum/Flöte) und Automation",
                factory=lambda project_service=None, audio_engine=None, automation_manager=None, **_: BachOrgelWidget(
                    project_service=project_service,
                    audio_engine=audio_engine,
                    automation_manager=automation_manager,
                ),
            )
        )
    except Exception:
        log.exception("Failed to load instrument plugin: bach_orgel")


    # AETERNA (Qt6)
    try:
        from pydaw.plugins.aeterna import AeternaWidget
        instruments.append(
            InstrumentSpec(
                plugin_id="chrono.aeterna",
                name="AETERNA",
                vendor="ChronoScaleStudio",
                category="Flagship Synth",
                description="The Morphogenetic Engine: Formel-/Chaos-/Terrain-Synth mit sakralen Presets und Random-Math.",
                factory=lambda project_service=None, audio_engine=None, automation_manager=None, **_: AeternaWidget(
                    project_service=project_service,
                    audio_engine=audio_engine,
                    automation_manager=automation_manager,
                ),
            )
        )
    except Exception:
        log.exception("Failed to load instrument plugin: aeterna")

    # Pro Drum Machine (Qt6)
    try:
        from pydaw.plugins.drum_machine import DrumMachineWidget
        instruments.append(
            InstrumentSpec(
                plugin_id="chrono.pro_drum_machine",
                name="Pro Drum Machine",
                vendor="ChronoScaleStudio",
                category="Drums",
                description="16-Pad Drum Machine (C1=Slot1) mit per-pyqtSlot Sampler + Pattern-Generator (Skeleton).",
                factory=lambda project_service=None, audio_engine=None, automation_manager=None, **_: DrumMachineWidget(
                    project_service=project_service,
                    audio_engine=audio_engine,
                    automation_manager=automation_manager,
                ),
            )
        )
    except Exception:
        log.exception("Failed to load instrument plugin: drum_machine")

    # Fusion Synthesizer (Qt6) — v0.0.20.574
    try:
        from pydaw.plugins.fusion import FusionWidget
        instruments.append(
            InstrumentSpec(
                plugin_id="chrono.fusion",
                name="Fusion",
                vendor="ChronoScaleStudio",
                category="Hybrid Synth",
                description="Semi-modularer Hybrid-Synthesizer mit austauschbaren OSC/FLT/ENV Modulen.",
                factory=lambda project_service=None, audio_engine=None, automation_manager=None, **_: FusionWidget(
                    project_service=project_service,
                    audio_engine=audio_engine,
                    automation_manager=automation_manager,
                ),
            )
        )
    except Exception:
        log.exception("Failed to load instrument plugin: fusion")

    # Advanced Multi-Sample Sampler (Qt6) — v0.0.20.656
    try:
        from pydaw.plugins.sampler.multisample_widget import MultiSampleEditorWidget
        instruments.append(
            InstrumentSpec(
                plugin_id="chrono.advanced_sampler",
                name="Advanced Sampler",
                vendor="ChronoScaleStudio",
                category="Sampler",
                description="Multi-Sample Sampler: Key×Velocity Zones, Round-Robin, Filter+ADSR, Mod-Matrix, Auto-Mapping.",
                factory=lambda project_service=None, audio_engine=None, automation_manager=None, **_: MultiSampleEditorWidget(
                    project_service=project_service,
                    audio_engine=audio_engine,
                    automation_manager=automation_manager,
                ),
            )
        )
    except Exception:
        log.exception("Failed to load instrument plugin: advanced_sampler")

    # BRRR Flutter Synth (Qt6) — v0.0.20.750 — ZynAddSubFX BRRRRRR2 Port
    try:
        from pydaw.plugins.brrr.brrr_widget import BrrrWidget
        instruments.append(
            InstrumentSpec(
                plugin_id="chrono.brrr",
                name="BRRR Flutter Synth",
                vendor="ChronoScaleStudio",
                category="Flutter Synth",
                description="S&H-Flutter Synthesizer: FM-Buzz + Noise mit Sample-and-Hold LFO ±3 Oktaven (ZynAddSubFX BRRRRRR2 Port).",
                factory=lambda project_service=None, audio_engine=None, automation_manager=None, **_: BrrrWidget(
                    project_service=project_service,
                    audio_engine=audio_engine,
                    automation_manager=automation_manager,
                ),
            )
        )
    except Exception:
        log.exception("Failed to load instrument plugin: brrr")

    return instruments


# ── v0.0.20.890: SQLite InstrumentRegistry sync (Phase 3 integration) ──

def _sync_instrument_registry() -> None:
    """Ensure InstrumentRegistry DB contains all registered instruments.

    Called lazily — no impact if InstrumentRegistry is not available.
    """
    try:
        from pydaw.services.instrument_registry import InstrumentRegistry
        reg = InstrumentRegistry.get()
        reg.ensure_loaded()
    except Exception:
        pass  # SQLite registry is optional


def get_instrument_display_name(plugin_id: str) -> str:
    """Get human-readable display name for a plugin_id.

    Uses InstrumentRegistry (SQLite) if available, else falls back
    to scanning get_instruments().
    """
    try:
        from pydaw.services.instrument_registry import InstrumentRegistry
        reg = InstrumentRegistry.get()
        name = reg.get_display_name(plugin_id)
        if name and name != plugin_id:
            return name
    except Exception:
        pass
    # Fallback: search in hardcoded list
    for spec in get_instruments():
        if spec.plugin_id == plugin_id:
            return spec.name
    return plugin_id


def get_instrument_icon(plugin_id: str) -> str:
    """Get emoji icon for a plugin_id."""
    try:
        from pydaw.services.instrument_registry import InstrumentRegistry
        reg = InstrumentRegistry.get()
        return reg.get_icon(plugin_id)
    except Exception:
        return "🎹"
