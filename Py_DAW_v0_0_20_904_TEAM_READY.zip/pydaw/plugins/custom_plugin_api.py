"""Custom Plugin API — Write your own instruments and FX in Python.

v0.0.20.800 — Phase 6A: Custom-Plugin API

Allows users to create their own audio instruments and effects as simple
Python classes, load them into the DAW, and use them like built-in plugins.

Architecture:
  - User writes a .py file with a class inheriting from PyDawPlugin
  - The class implements process() for audio, note_on/note_off for MIDI
  - The plugin declares parameters via define_params()
  - Py_DAW scans a plugins directory, discovers classes, instantiates them
  - Parameters are exposed in the device panel like built-in FX

Plugin Types:
  - PyDawEffect: Audio in → Audio out (insert FX)
  - PyDawInstrument: MIDI in → Audio out (synthesizer/sampler)
  - PyDawMidiFx: MIDI in → MIDI out (arpeggiator, chord generator)

Example Effect (save as my_plugins/tremolo.py):
    from pydaw.plugins.custom_plugin_api import PyDawEffect, Param

    class MyTremolo(PyDawEffect):
        name = "My Tremolo"
        author = "Anno"
        version = "1.0"

        def define_params(self):
            return [
                Param("rate", 4.0, 0.1, 20.0, "Hz"),
                Param("depth", 0.5, 0.0, 1.0, ""),
            ]

        def process(self, buffer, frames, sr):
            import numpy as np
            rate = self.params["rate"]
            depth = self.params["depth"]
            t = np.arange(frames) / sr + self._phase
            mod = 1.0 - depth * 0.5 * (1.0 + np.sin(2 * np.pi * rate * t))
            buffer[:frames, 0] *= mod
            buffer[:frames, 1] *= mod
            self._phase += frames / sr

Example Instrument (save as my_plugins/simple_sine.py):
    from pydaw.plugins.custom_plugin_api import PyDawInstrument, Param

    class SimpleSine(PyDawInstrument):
        name = "Simple Sine"

        def define_params(self):
            return [Param("volume", 0.5, 0.0, 1.0, "")]

        def note_on(self, pitch, velocity):
            self._freq = 440.0 * (2 ** ((pitch - 69) / 12.0))
            self._vel = velocity / 127.0
            self._active = True

        def note_off(self, pitch):
            self._active = False

        def process(self, buffer, frames, sr):
            if not self._active:
                return
            import numpy as np
            t = np.arange(frames) / sr + self._phase
            vol = self.params["volume"] * self._vel
            signal = vol * np.sin(2 * np.pi * self._freq * t)
            buffer[:frames, 0] += signal.astype(np.float32)
            buffer[:frames, 1] += signal.astype(np.float32)
            self._phase += frames / sr
"""

from __future__ import annotations

import importlib.util
import inspect
import logging
import os
import sys
import traceback
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Type

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Parameter definition
# ---------------------------------------------------------------------------

@dataclass
class Param:
    """A plugin parameter definition.

    Args:
        name: Parameter name (unique within plugin).
        default: Default value.
        min_val: Minimum value.
        max_val: Maximum value.
        unit: Display unit ("Hz", "dB", "ms", "%", "").
        label: Human-readable label (defaults to name).
        choices: For enum params, list of string choices.
    """
    name: str = ""
    default: float = 0.0
    min_val: float = 0.0
    max_val: float = 1.0
    unit: str = ""
    label: str = ""
    choices: List[str] = field(default_factory=list)

    def __post_init__(self):
        if not self.label:
            self.label = self.name.replace("_", " ").title()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Base plugin classes
# ---------------------------------------------------------------------------

class PyDawPlugin:
    """Base class for all custom Py_DAW plugins.

    Subclass this and implement the required methods.
    """

    # Plugin metadata — override in your class
    name: str = "Unnamed Plugin"
    author: str = ""
    version: str = "1.0"
    description: str = ""
    category: str = "Custom"  # "Custom", "Synth", "Effect", "MIDI FX"

    def __init__(self, sample_rate: int = 48000, block_size: int = 512):
        self._sample_rate = sample_rate
        self._block_size = block_size
        self._phase = 0.0  # common utility: running phase
        self._param_defs: List[Param] = []
        self.params: Dict[str, float] = {}

        # Initialize parameters
        try:
            self._param_defs = self.define_params() or []
            for p in self._param_defs:
                self.params[p.name] = p.default
        except Exception as e:
            log.error("Plugin '%s' define_params() failed: %s", self.name, e)

    def define_params(self) -> List[Param]:
        """Override: Define plugin parameters.

        Returns:
            List of Param objects defining the plugin's parameters.
        """
        return []

    def set_param(self, name: str, value: float) -> None:
        """Set a parameter value (called by the host)."""
        if name in self.params:
            param_def = next((p for p in self._param_defs if p.name == name), None)
            if param_def:
                value = max(param_def.min_val, min(param_def.max_val, float(value)))
            self.params[name] = value

    def get_param(self, name: str) -> float:
        """Get a parameter value."""
        return self.params.get(name, 0.0)

    def get_param_defs(self) -> List[Param]:
        """Get parameter definitions."""
        return list(self._param_defs)

    def reset(self) -> None:
        """Reset plugin state (called on transport stop)."""
        self._phase = 0.0

    def get_info(self) -> Dict[str, Any]:
        """Get plugin info dict."""
        return {
            "name": self.name,
            "author": self.author,
            "version": self.version,
            "description": self.description,
            "category": self.category,
            "type": self.__class__.__bases__[0].__name__,
            "params": [p.to_dict() for p in self._param_defs],
        }


class PyDawEffect(PyDawPlugin):
    """Base class for custom audio effects.

    Override process() to apply your effect to the audio buffer.
    """
    category = "Effect"

    def process(self, buffer, frames: int, sr: int) -> None:
        """Process audio in-place.

        Args:
            buffer: numpy array (frames, 2) — modify in-place.
            frames: Number of frames to process.
            sr: Sample rate.
        """
        pass  # Override this


class PyDawInstrument(PyDawPlugin):
    """Base class for custom instruments (synthesizers/samplers).

    Override note_on(), note_off(), and process() to generate audio.
    """
    category = "Synth"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._active = False
        self._freq = 440.0
        self._vel = 1.0
        self._active_notes: Dict[int, float] = {}  # pitch -> velocity

    def note_on(self, pitch: int, velocity: int) -> None:
        """Handle MIDI note on.

        Args:
            pitch: MIDI note number (0-127).
            velocity: Velocity (0-127).
        """
        self._active_notes[pitch] = velocity / 127.0
        self._active = True

    def note_off(self, pitch: int) -> None:
        """Handle MIDI note off."""
        self._active_notes.pop(pitch, None)
        if not self._active_notes:
            self._active = False

    def process(self, buffer, frames: int, sr: int) -> None:
        """Generate audio into the buffer (additive).

        Args:
            buffer: numpy array (frames, 2) — ADD your signal to it.
            frames: Number of frames to process.
            sr: Sample rate.
        """
        pass  # Override this

    def all_notes_off(self) -> None:
        """All notes off (panic)."""
        self._active_notes.clear()
        self._active = False


class PyDawMidiFx(PyDawPlugin):
    """Base class for custom MIDI effects.

    Override process_midi() to transform MIDI events.
    """
    category = "MIDI FX"

    def process_midi(self, events: List[Dict[str, Any]],
                     frames: int, sr: int) -> List[Dict[str, Any]]:
        """Process MIDI events.

        Args:
            events: List of MIDI event dicts with keys:
                    type ("note_on"/"note_off"/"cc"),
                    pitch, velocity, channel, cc, value, offset.
            frames: Buffer size in frames.
            sr: Sample rate.

        Returns:
            Transformed list of MIDI events.
        """
        return events  # Override this — passthrough by default


# ---------------------------------------------------------------------------
# Plugin Scanner / Registry
# ---------------------------------------------------------------------------

@dataclass
class PluginEntry:
    """Registry entry for a discovered custom plugin."""
    name: str = ""
    class_name: str = ""
    module_path: str = ""
    plugin_type: str = ""  # "effect", "instrument", "midi_fx"
    author: str = ""
    version: str = ""
    description: str = ""
    params: List[Dict[str, Any]] = field(default_factory=list)
    error: str = ""


class CustomPluginRegistry:
    """Discovers, loads, and manages custom Python plugins.

    Scans directories for .py files containing PyDawPlugin subclasses.
    """

    # Default scan directories (relative to project root)
    DEFAULT_DIRS = [
        "my_plugins",
        "custom_plugins",
        "user_plugins",
    ]

    def __init__(self):
        self._entries: Dict[str, PluginEntry] = {}  # class_name -> entry
        self._classes: Dict[str, Type[PyDawPlugin]] = {}  # class_name -> class
        self._instances: Dict[str, PyDawPlugin] = {}  # instance_id -> instance
        self._scan_dirs: List[Path] = []

    def add_scan_directory(self, path: Path) -> None:
        """Add a directory to scan for plugins."""
        p = Path(path)
        if p.is_dir() and p not in self._scan_dirs:
            self._scan_dirs.append(p)

    def scan(self, project_root: Optional[Path] = None) -> List[PluginEntry]:
        """Scan directories for custom plugins.

        Returns list of discovered plugin entries.
        """
        dirs_to_scan = list(self._scan_dirs)

        # Add default directories relative to project root
        if project_root:
            for d in self.DEFAULT_DIRS:
                dp = Path(project_root) / d
                if dp.is_dir() and dp not in dirs_to_scan:
                    dirs_to_scan.append(dp)

        # Also check ~/.pydaw/plugins/
        user_dir = Path.home() / ".pydaw" / "plugins"
        if user_dir.is_dir() and user_dir not in dirs_to_scan:
            dirs_to_scan.append(user_dir)

        discovered = []
        for scan_dir in dirs_to_scan:
            for py_file in sorted(scan_dir.glob("*.py")):
                if py_file.name.startswith("_"):
                    continue  # Skip __init__.py etc.
                entries = self._scan_file(py_file)
                discovered.extend(entries)

        log.info("Custom plugin scan: %d plugins found in %d directories",
                 len(discovered), len(dirs_to_scan))
        return discovered

    def _scan_file(self, py_file: Path) -> List[PluginEntry]:
        """Scan a single .py file for plugin classes."""
        entries = []
        try:
            spec = importlib.util.spec_from_file_location(
                f"pydaw_custom_{py_file.stem}", str(py_file)
            )
            if spec is None or spec.loader is None:
                return entries

            module = importlib.util.module_from_spec(spec)
            # Don't add to sys.modules to avoid conflicts
            spec.loader.exec_module(module)

            for name, obj in inspect.getmembers(module, inspect.isclass):
                if obj in (PyDawPlugin, PyDawEffect, PyDawInstrument, PyDawMidiFx):
                    continue  # Skip base classes
                if not issubclass(obj, PyDawPlugin):
                    continue

                # Determine plugin type
                if issubclass(obj, PyDawEffect):
                    ptype = "effect"
                elif issubclass(obj, PyDawInstrument):
                    ptype = "instrument"
                elif issubclass(obj, PyDawMidiFx):
                    ptype = "midi_fx"
                else:
                    ptype = "unknown"

                # Try to get param defs
                params = []
                try:
                    instance = obj(sample_rate=48000, block_size=512)
                    params = [p.to_dict() for p in instance.get_param_defs()]
                    info = instance.get_info()
                except Exception:
                    info = {"name": getattr(obj, 'name', name)}

                entry = PluginEntry(
                    name=info.get("name", name),
                    class_name=name,
                    module_path=str(py_file),
                    plugin_type=ptype,
                    author=info.get("author", ""),
                    version=info.get("version", "1.0"),
                    description=info.get("description", ""),
                    params=params,
                )
                self._entries[name] = entry
                self._classes[name] = obj
                entries.append(entry)
                log.info("Discovered custom plugin: %s (%s) from %s",
                         entry.name, ptype, py_file.name)

        except Exception as e:
            log.warning("Failed to scan %s: %s", py_file, e)
            entries.append(PluginEntry(
                name=py_file.stem,
                module_path=str(py_file),
                error=str(e),
            ))

        return entries

    def create_instance(self, class_name: str,
                        sample_rate: int = 48000,
                        block_size: int = 512,
                        instance_id: str = "") -> Optional[PyDawPlugin]:
        """Create an instance of a custom plugin.

        Args:
            class_name: The Python class name of the plugin.
            sample_rate: Audio sample rate.
            block_size: Processing block size.
            instance_id: Unique ID for this instance.

        Returns:
            Plugin instance or None.
        """
        cls = self._classes.get(class_name)
        if cls is None:
            log.warning("Custom plugin class '%s' not found", class_name)
            return None

        try:
            instance = cls(sample_rate=sample_rate, block_size=block_size)
            if instance_id:
                self._instances[instance_id] = instance
            return instance
        except Exception as e:
            log.error("Failed to create plugin '%s': %s", class_name, e)
            return None

    def get_instance(self, instance_id: str) -> Optional[PyDawPlugin]:
        """Get a plugin instance by ID."""
        return self._instances.get(instance_id)

    def destroy_instance(self, instance_id: str) -> None:
        """Remove a plugin instance."""
        self._instances.pop(instance_id, None)

    def list_plugins(self) -> List[PluginEntry]:
        """Get all discovered plugins."""
        return list(self._entries.values())

    def list_effects(self) -> List[PluginEntry]:
        """Get only effect plugins."""
        return [e for e in self._entries.values() if e.plugin_type == "effect"]

    def list_instruments(self) -> List[PluginEntry]:
        """Get only instrument plugins."""
        return [e for e in self._entries.values() if e.plugin_type == "instrument"]

    def list_midi_fx(self) -> List[PluginEntry]:
        """Get only MIDI FX plugins."""
        return [e for e in self._entries.values() if e.plugin_type == "midi_fx"]


# ---------------------------------------------------------------------------
# Singleton registry
# ---------------------------------------------------------------------------

_registry: Optional[CustomPluginRegistry] = None


def get_registry() -> CustomPluginRegistry:
    """Get the global custom plugin registry (singleton)."""
    global _registry
    if _registry is None:
        _registry = CustomPluginRegistry()
    return _registry


def scan_plugins(project_root: Optional[Path] = None) -> List[PluginEntry]:
    """Convenience: scan and return all custom plugins."""
    return get_registry().scan(project_root)
