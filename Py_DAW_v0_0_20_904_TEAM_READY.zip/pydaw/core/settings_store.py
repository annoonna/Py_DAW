"""QSettings convenience wrapper — now with SQLite backend (P6 Integration).

v0.0.2 introduces first real preferences.
v0.0.20.890: SettingsDatabase (SQLite) as primary backend.
             QSettings remains as fallback if SQLite fails.

Keep all persistence here so UI and engine modules stay clean.
"""

from __future__ import annotations

from typing import Any, Optional

from PyQt6.QtCore import QSettings

from .settings import SettingsKeys

# ── SQLite backend (lazy init) ──────────────────────────────────
_settings_db = None
_settings_db_failed = False


def _get_db():
    """Lazy-init SettingsDatabase singleton. Returns None on failure."""
    global _settings_db, _settings_db_failed
    if _settings_db_failed:
        return None
    if _settings_db is not None:
        return _settings_db
    try:
        from pydaw.services.settings_database import SettingsDatabase
        db = SettingsDatabase.get()
        db.ensure_loaded()
        _settings_db = db
        return db
    except Exception:
        _settings_db_failed = True
        return None


# ── Public API (unchanged signatures) ──────────────────────────

def get_settings() -> QSettings:
    """Return application QSettings instance."""
    keys = SettingsKeys()
    return QSettings(keys.organization, keys.application)


def get_value(key: str, default: Any = None) -> Any:
    # Try SQLite first
    db = _get_db()
    if db is not None:
        try:
            val = db.get(key, None)
            if val is not None:
                return val
        except Exception:
            pass
    # Fallback to QSettings
    s = get_settings()
    return s.value(key, default)


def set_value(key: str, value: Any) -> None:
    # Write to SQLite
    db = _get_db()
    if db is not None:
        try:
            db.set(key, value)
            return  # SettingsDatabase.set() already dual-writes to QSettings
        except Exception:
            pass
    # Fallback: write directly to QSettings
    s = get_settings()
    s.setValue(key, value)
