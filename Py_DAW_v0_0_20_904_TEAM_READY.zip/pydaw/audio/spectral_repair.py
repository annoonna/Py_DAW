"""Spectral Repair Engine (P1B) — FFT-based spectral editing.

Provides tools for:
- Spectral noise profile learning + denoising
- Frequency-band selection + attenuation/removal
- Spectral gap filling (interpolation)
- Spectral display data for UI visualization

Non-destructive: all operations return new audio arrays.

v0.0.20.806 — Phase P1B
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Tuple

log = logging.getLogger(__name__)

try:
    import numpy as np
except Exception:
    np = None  # type: ignore


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class SpectralRegion:
    """A selected region in the spectrogram for repair.

    freq_lo/hi: Hz range
    time_start/end: sample positions
    action: "attenuate" | "remove" | "fill" | "denoise"
    attenuation_db: how much to reduce (for "attenuate")
    """
    id: str = ""
    freq_lo_hz: float = 0.0
    freq_hi_hz: float = 24000.0
    time_start_sample: int = 0
    time_end_sample: int = 0
    action: str = "attenuate"
    attenuation_db: float = -20.0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "SpectralRegion":
        try:
            return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})
        except Exception:
            return cls()


@dataclass
class NoiseProfile:
    """Learned noise floor from a reference segment."""
    magnitude_floor: Optional["np.ndarray"] = None  # shape (n_bins,)
    n_fft: int = 2048
    sr: int = 48000
    n_frames_averaged: int = 0

    def to_dict(self) -> dict:
        d = {"n_fft": self.n_fft, "sr": self.sr, "n_frames_averaged": self.n_frames_averaged}
        if self.magnitude_floor is not None and np is not None:
            d["magnitude_floor"] = self.magnitude_floor.tolist()
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "NoiseProfile":
        try:
            prof = cls(n_fft=d.get("n_fft", 2048), sr=d.get("sr", 48000),
                       n_frames_averaged=d.get("n_frames_averaged", 0))
            if "magnitude_floor" in d and np is not None:
                prof.magnitude_floor = np.array(d["magnitude_floor"], dtype=np.float64)
            return prof
        except Exception:
            return cls()


# ---------------------------------------------------------------------------
# STFT helpers
# ---------------------------------------------------------------------------

def _stft(audio: "np.ndarray", n_fft: int = 2048, hop: int = 512) -> "np.ndarray":
    """Short-Time Fourier Transform. Returns complex spectrogram (bins × frames)."""
    if np is None:
        return audio
    audio = np.asarray(audio, dtype=np.float64).flatten()
    win = np.hanning(n_fft).astype(np.float64)
    pad = n_fft
    x = np.pad(audio, (pad, pad), mode="constant")

    n_frames = max(1, 1 + (len(x) - n_fft) // hop)
    n_bins = n_fft // 2 + 1

    spec = np.zeros((n_bins, n_frames), dtype=np.complex128)
    for i in range(n_frames):
        start = i * hop
        frame = x[start:start + n_fft] * win
        spec[:, i] = np.fft.rfft(frame)

    return spec


def _istft(spec: "np.ndarray", n_fft: int = 2048, hop: int = 512,
           target_len: int = 0) -> "np.ndarray":
    """Inverse STFT with overlap-add."""
    if np is None:
        return spec
    n_bins, n_frames = spec.shape
    win = np.hanning(n_fft).astype(np.float64)
    pad = n_fft

    out_len = n_frames * hop + n_fft + 2 * pad
    y = np.zeros(out_len, dtype=np.float64)
    win_sum = np.zeros(out_len, dtype=np.float64)

    for i in range(n_frames):
        frame = np.fft.irfft(spec[:, i], n=n_fft)
        start = i * hop + pad
        y[start:start + n_fft] += frame * win
        win_sum[start:start + n_fft] += win * win

    nz = win_sum > 1e-10
    y[nz] /= win_sum[nz]

    # Remove padding
    y = y[pad:-pad]
    if target_len > 0:
        if len(y) > target_len:
            y = y[:target_len]
        elif len(y) < target_len:
            y = np.pad(y, (0, target_len - len(y)))

    return y.astype(np.float32)


# ---------------------------------------------------------------------------
# Spectrogram for UI display
# ---------------------------------------------------------------------------

def compute_spectrogram(
    audio: "np.ndarray",
    sr: int = 48000,
    n_fft: int = 2048,
    hop: int = 512,
) -> Dict[str, Any]:
    """Compute magnitude spectrogram for UI display.

    Returns dict with:
        magnitude_db: 2D array (n_bins × n_frames), dB scale
        freq_axis: 1D array of frequency values (Hz)
        time_axis: 1D array of time values (seconds)
        n_fft, hop, sr: parameters
    """
    if np is None:
        return {"magnitude_db": [], "freq_axis": [], "time_axis": []}

    audio = np.asarray(audio, dtype=np.float64).flatten()
    spec = _stft(audio, n_fft=n_fft, hop=hop)

    mag = np.abs(spec)
    # Convert to dB with floor
    mag_db = 20.0 * np.log10(np.maximum(mag, 1e-10))

    freq_axis = np.linspace(0, sr / 2, spec.shape[0])
    time_axis = np.arange(spec.shape[1]) * hop / sr

    return {
        "magnitude_db": mag_db,
        "freq_axis": freq_axis,
        "time_axis": time_axis,
        "n_fft": n_fft,
        "hop": hop,
        "sr": sr,
    }


# ---------------------------------------------------------------------------
# Noise profile learning
# ---------------------------------------------------------------------------

def learn_noise_profile(
    audio: "np.ndarray",
    sr: int = 48000,
    start_sample: int = 0,
    end_sample: int = -1,
    n_fft: int = 2048,
    hop: int = 512,
) -> NoiseProfile:
    """Learn a noise profile from a reference segment (e.g. silence/noise-only).

    The profile stores the average magnitude spectrum of the noise.
    """
    if np is None:
        return NoiseProfile()

    audio = np.asarray(audio, dtype=np.float64).flatten()
    if end_sample <= 0:
        end_sample = len(audio)
    segment = audio[start_sample:end_sample]

    if len(segment) < n_fft:
        return NoiseProfile(sr=sr, n_fft=n_fft)

    spec = _stft(segment, n_fft=n_fft, hop=hop)
    mag = np.abs(spec)

    # Average magnitude across frames
    avg_mag = np.mean(mag, axis=1)

    return NoiseProfile(
        magnitude_floor=avg_mag,
        n_fft=n_fft,
        sr=sr,
        n_frames_averaged=spec.shape[1],
    )


# ---------------------------------------------------------------------------
# Spectral denoising (spectral subtraction)
# ---------------------------------------------------------------------------

def spectral_denoise(
    audio: "np.ndarray",
    noise_profile: NoiseProfile,
    *,
    reduction_db: float = -20.0,
    n_fft: int = 2048,
    hop: int = 512,
    smoothing: float = 0.5,
) -> "np.ndarray":
    """Remove noise using spectral subtraction.

    Parameters
    ----------
    audio : 1D float32 mono
    noise_profile : learned noise floor
    reduction_db : how aggressively to reduce noise (e.g. -20 dB)
    smoothing : temporal smoothing for the noise gate (0..1)

    Returns
    -------
    Denoised audio (same length).
    """
    if np is None:
        return audio

    audio = np.asarray(audio, dtype=np.float64).flatten()
    original_len = len(audio)

    spec = _stft(audio, n_fft=n_fft, hop=hop)
    mag = np.abs(spec)
    phase = np.angle(spec)

    if noise_profile.magnitude_floor is None:
        return audio.astype(np.float32)

    noise_floor = noise_profile.magnitude_floor
    if len(noise_floor) != spec.shape[0]:
        return audio.astype(np.float32)

    # Over-subtraction factor from reduction_db
    alpha = 10.0 ** (abs(reduction_db) / 20.0)

    # Spectral subtraction with soft mask
    noise_estimate = noise_floor[:, np.newaxis] * alpha
    # Wiener-like soft mask
    mask = np.maximum(0.0, 1.0 - (noise_estimate / np.maximum(mag, 1e-10)) ** 2)

    # Temporal smoothing
    if smoothing > 0:
        for i in range(1, mask.shape[1]):
            mask[:, i] = smoothing * mask[:, i - 1] + (1.0 - smoothing) * mask[:, i]

    # Apply mask
    spec_clean = mag * mask * np.exp(1j * phase)

    result = _istft(spec_clean, n_fft=n_fft, hop=hop, target_len=original_len)
    return result


# ---------------------------------------------------------------------------
# Frequency-band operations
# ---------------------------------------------------------------------------

def _freq_to_bin(freq_hz: float, sr: int, n_fft: int) -> int:
    """Convert frequency in Hz to FFT bin index."""
    return max(0, min(n_fft // 2, int(round(freq_hz * n_fft / sr))))


def _sample_to_frame(sample_pos: int, hop: int) -> int:
    """Convert sample position to STFT frame index."""
    return max(0, sample_pos // hop)


def apply_spectral_regions(
    audio: "np.ndarray",
    regions: List[SpectralRegion],
    sr: int = 48000,
    n_fft: int = 2048,
    hop: int = 512,
    noise_profile: Optional[NoiseProfile] = None,
) -> "np.ndarray":
    """Apply spectral repair operations defined by regions.

    Supported actions:
    - "attenuate": reduce magnitude in the region by attenuation_db
    - "remove": zero out the region
    - "fill": interpolate from surrounding frequencies
    - "denoise": spectral subtraction using noise_profile
    """
    if np is None or not regions:
        return audio

    audio = np.asarray(audio, dtype=np.float64).flatten()
    original_len = len(audio)

    spec = _stft(audio, n_fft=n_fft, hop=hop)
    mag = np.abs(spec)
    phase = np.angle(spec)

    for region in regions:
        bin_lo = _freq_to_bin(region.freq_lo_hz, sr, n_fft)
        bin_hi = _freq_to_bin(region.freq_hi_hz, sr, n_fft)
        frame_start = _sample_to_frame(region.time_start_sample, hop)
        frame_end = _sample_to_frame(region.time_end_sample, hop)

        # Clamp
        bin_lo = max(0, min(spec.shape[0] - 1, bin_lo))
        bin_hi = max(bin_lo + 1, min(spec.shape[0], bin_hi))
        frame_start = max(0, min(spec.shape[1] - 1, frame_start))
        frame_end = max(frame_start + 1, min(spec.shape[1], frame_end))

        action = str(region.action or "attenuate").lower().strip()

        if action == "remove":
            mag[bin_lo:bin_hi, frame_start:frame_end] = 0.0

        elif action == "attenuate":
            factor = 10.0 ** (region.attenuation_db / 20.0)
            mag[bin_lo:bin_hi, frame_start:frame_end] *= factor

        elif action == "fill":
            # Interpolate from surrounding frequency bands
            _spectral_fill(mag, bin_lo, bin_hi, frame_start, frame_end)

        elif action == "denoise" and noise_profile is not None:
            if noise_profile.magnitude_floor is not None:
                nf = noise_profile.magnitude_floor
                if len(nf) == spec.shape[0]:
                    alpha = 10.0 ** (abs(region.attenuation_db) / 20.0)
                    sub = mag[bin_lo:bin_hi, frame_start:frame_end]
                    noise_est = nf[bin_lo:bin_hi, np.newaxis] * alpha
                    mask = np.maximum(0.0, 1.0 - (noise_est / np.maximum(sub, 1e-10)) ** 2)
                    mag[bin_lo:bin_hi, frame_start:frame_end] *= mask

    # Reconstruct
    spec_out = mag * np.exp(1j * phase)
    result = _istft(spec_out, n_fft=n_fft, hop=hop, target_len=original_len)
    return result


def _spectral_fill(
    mag: "np.ndarray",
    bin_lo: int, bin_hi: int,
    frame_start: int, frame_end: int,
) -> None:
    """Fill a spectral region by interpolating from surrounding bins."""
    if np is None:
        return

    n_bins = mag.shape[0]
    # Get average magnitude from bins above and below the region
    margin = max(1, (bin_hi - bin_lo) // 4)

    lo_start = max(0, bin_lo - margin)
    lo_end = bin_lo
    hi_start = bin_hi
    hi_end = min(n_bins, bin_hi + margin)

    for frame in range(frame_start, frame_end):
        lo_avg = np.mean(mag[lo_start:lo_end, frame]) if lo_end > lo_start else 0.0
        hi_avg = np.mean(mag[hi_start:hi_end, frame]) if hi_end > hi_start else 0.0

        # Linear interpolation between lo_avg and hi_avg
        n_fill = bin_hi - bin_lo
        if n_fill > 0:
            interp = np.linspace(lo_avg, hi_avg, n_fill, dtype=np.float64)
            mag[bin_lo:bin_hi, frame] = interp


# ---------------------------------------------------------------------------
# Convenience: one-shot spectral edit
# ---------------------------------------------------------------------------

def remove_frequency_band(
    audio: "np.ndarray",
    freq_lo_hz: float,
    freq_hi_hz: float,
    sr: int = 48000,
    *,
    start_sample: int = 0,
    end_sample: int = -1,
    attenuation_db: float = -60.0,
) -> "np.ndarray":
    """Remove or attenuate a frequency band from audio.

    Convenience wrapper around apply_spectral_regions.
    """
    if end_sample <= 0:
        end_sample = len(audio) if np is not None else 0

    region = SpectralRegion(
        id="sr_0",
        freq_lo_hz=freq_lo_hz,
        freq_hi_hz=freq_hi_hz,
        time_start_sample=start_sample,
        time_end_sample=end_sample,
        action="attenuate",
        attenuation_db=attenuation_db,
    )
    return apply_spectral_regions(audio, [region], sr=sr)


def spectral_repair_selection(
    audio: "np.ndarray",
    freq_lo_hz: float,
    freq_hi_hz: float,
    sr: int = 48000,
    *,
    start_sample: int = 0,
    end_sample: int = -1,
) -> "np.ndarray":
    """Fill (interpolate) a spectral region — use for removing hum/clicks."""
    if end_sample <= 0:
        end_sample = len(audio) if np is not None else 0

    region = SpectralRegion(
        id="sr_0",
        freq_lo_hz=freq_lo_hz,
        freq_hi_hz=freq_hi_hz,
        time_start_sample=start_sample,
        time_end_sample=end_sample,
        action="fill",
    )
    return apply_spectral_regions(audio, [region], sr=sr)
