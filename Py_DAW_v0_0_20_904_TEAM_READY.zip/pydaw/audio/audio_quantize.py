"""Audio Quantization Engine (P1C) — Transient-based timing correction.

Provides:
1. **Transient detection** — energy-based onset detection for audio
2. **Audio quantization** — snap transients to beat grid
3. **Swing quantization** — apply groove template to audio timing
4. **Elastic Audio** — per-transient manipulation with crossfade splicing

Non-destructive: all operations return new audio arrays.
Original audio is preserved for undo.

v0.0.20.806 — Phase P1C
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any, Tuple

log = logging.getLogger(__name__)

try:
    import numpy as np
except Exception:
    np = None  # type: ignore


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class TransientMarker:
    """A detected transient/onset in audio.

    position_samples: original position in samples
    target_samples: quantized/adjusted position (user-editable)
    strength: 0..1 detection strength/confidence
    locked: if True, this marker won't be auto-adjusted
    """
    id: str = ""
    position_samples: int = 0
    target_samples: int = 0
    strength: float = 0.0
    locked: bool = False
    is_adjusted: bool = False  # True if target != position

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "TransientMarker":
        try:
            return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})
        except Exception:
            return cls()

    @property
    def shift_samples(self) -> int:
        """How many samples to shift (positive = later)."""
        return self.target_samples - self.position_samples


@dataclass
class QuantizeSettings:
    """Settings for audio quantization."""
    grid_beats: float = 0.25      # grid size in beats (0.25 = 1/16th note)
    strength: float = 1.0         # 0..1, how much to snap (1=full, 0=none)
    swing_amount: float = 0.0     # 0..1, swing on even grid positions
    swing_feel: str = "8th"       # "8th" or "16th" — which division swings
    sensitivity: float = 0.5      # transient detection sensitivity (0..1)
    preserve_length: bool = True  # keep original audio length
    crossfade_ms: float = 5.0     # crossfade at splice points

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "QuantizeSettings":
        try:
            return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})
        except Exception:
            return cls()


# ---------------------------------------------------------------------------
# Transient detection
# ---------------------------------------------------------------------------

def detect_transients(
    audio: "np.ndarray",
    sr: int = 48000,
    *,
    sensitivity: float = 0.5,
    min_gap_ms: float = 30.0,
    method: str = "energy",
) -> List[TransientMarker]:
    """Detect transients/onsets in mono audio.

    Parameters
    ----------
    audio : 1D float32 array
    sr : sample rate
    sensitivity : 0..1, lower = fewer transients (higher threshold)
    min_gap_ms : minimum gap between consecutive transients
    method : "energy" (default) or "spectral_flux"

    Returns
    -------
    List of TransientMarker with detected positions.
    """
    if np is None:
        return []

    audio = np.asarray(audio, dtype=np.float32).flatten()
    if len(audio) < 256:
        return []

    if method == "spectral_flux":
        return _detect_spectral_flux(audio, sr, sensitivity, min_gap_ms)
    else:
        return _detect_energy(audio, sr, sensitivity, min_gap_ms)


def _detect_energy(
    audio: "np.ndarray",
    sr: int,
    sensitivity: float,
    min_gap_ms: float,
) -> List[TransientMarker]:
    """Energy-based onset detection."""
    if np is None:
        return []

    hop = max(64, sr // 200)  # ~5ms hop
    min_gap_samples = max(1, int(min_gap_ms * 0.001 * sr))

    # Compute energy envelope
    n_frames = max(1, (len(audio) - hop) // hop)
    energy = np.zeros(n_frames, dtype=np.float64)
    for i in range(n_frames):
        start = i * hop
        end = min(start + hop, len(audio))
        frame = audio[start:end]
        energy[i] = float(np.sum(frame * frame))

    if np.max(energy) < 1e-10:
        return []

    # Normalize
    energy /= np.max(energy) + 1e-10

    # Compute onset detection function (energy difference)
    odf = np.zeros(n_frames, dtype=np.float64)
    for i in range(1, n_frames):
        diff = energy[i] - energy[i - 1]
        odf[i] = max(0.0, diff)

    # Adaptive threshold
    # sensitivity: 0 = very high threshold (few transients), 1 = low threshold (many)
    threshold_factor = 1.0 - 0.8 * max(0.0, min(1.0, sensitivity))
    if np.max(odf) > 1e-10:
        threshold = float(np.mean(odf)) + threshold_factor * float(np.std(odf))
    else:
        return []

    # Peak picking
    markers: List[TransientMarker] = []
    counter = 0
    last_onset = -min_gap_samples

    for i in range(1, n_frames - 1):
        if odf[i] > threshold and odf[i] >= odf[i - 1] and odf[i] >= odf[i + 1]:
            sample_pos = i * hop
            if sample_pos - last_onset >= min_gap_samples:
                strength = min(1.0, odf[i] / (float(np.max(odf)) + 1e-10))
                markers.append(TransientMarker(
                    id=f"tm_{counter:04d}",
                    position_samples=sample_pos,
                    target_samples=sample_pos,
                    strength=float(strength),
                ))
                counter += 1
                last_onset = sample_pos

    return markers


def _detect_spectral_flux(
    audio: "np.ndarray",
    sr: int,
    sensitivity: float,
    min_gap_ms: float,
) -> List[TransientMarker]:
    """Spectral flux onset detection — more accurate for complex material."""
    if np is None:
        return []

    n_fft = 1024
    hop = n_fft // 4
    min_gap_samples = max(1, int(min_gap_ms * 0.001 * sr))

    # STFT
    win = np.hanning(n_fft).astype(np.float64)
    n_frames = max(1, (len(audio) - n_fft) // hop)

    prev_mag = None
    flux = np.zeros(n_frames, dtype=np.float64)

    for i in range(n_frames):
        start = i * hop
        frame = audio[start:start + n_fft].astype(np.float64) * win
        spec = np.fft.rfft(frame)
        mag = np.abs(spec)

        if prev_mag is not None:
            # Only positive differences (onset = energy increase)
            diff = mag - prev_mag
            flux[i] = float(np.sum(np.maximum(0, diff)))
        prev_mag = mag

    if np.max(flux) < 1e-10:
        return []

    # Normalize
    flux /= np.max(flux) + 1e-10

    # Threshold
    threshold_factor = 1.0 - 0.8 * max(0.0, min(1.0, sensitivity))
    threshold = float(np.mean(flux)) + threshold_factor * float(np.std(flux))

    # Peak picking
    markers: List[TransientMarker] = []
    counter = 0
    last_onset = -min_gap_samples

    for i in range(1, n_frames - 1):
        if flux[i] > threshold and flux[i] >= flux[i - 1] and flux[i] >= flux[i + 1]:
            sample_pos = i * hop
            if sample_pos - last_onset >= min_gap_samples:
                strength = min(1.0, flux[i])
                markers.append(TransientMarker(
                    id=f"tm_{counter:04d}",
                    position_samples=sample_pos,
                    target_samples=sample_pos,
                    strength=float(strength),
                ))
                counter += 1
                last_onset = sample_pos

    return markers


# ---------------------------------------------------------------------------
# Audio quantization
# ---------------------------------------------------------------------------

def _beat_to_sample(beat: float, bpm: float, sr: int) -> int:
    """Convert beat position to sample position."""
    seconds = beat * 60.0 / bpm
    return int(round(seconds * sr))


def _sample_to_beat(sample_pos: int, bpm: float, sr: int) -> float:
    """Convert sample position to beat position."""
    seconds = sample_pos / sr
    return seconds * bpm / 60.0


def _nearest_grid_beat(beat: float, grid_beats: float, swing: float = 0.0,
                       swing_feel: str = "8th") -> float:
    """Find the nearest grid position, optionally with swing.

    swing: 0..1, how much to offset even positions (0.5 = triplet feel)
    swing_feel: "8th" → swing on 8th-note positions, "16th" → on 16th-note
    """
    if grid_beats <= 0:
        return beat

    grid_pos = round(beat / grid_beats)
    base = grid_pos * grid_beats

    # Apply swing: offset even-numbered grid positions
    if swing > 0 and grid_pos % 2 == 1:
        swing_division = 0.5 if swing_feel == "8th" else 0.25
        swing_offset = swing * swing_division * 0.5
        base += swing_offset

    return base


def quantize_transients(
    markers: List[TransientMarker],
    bpm: float,
    sr: int,
    settings: Optional[QuantizeSettings] = None,
) -> List[TransientMarker]:
    """Quantize transient markers to a beat grid.

    Modifies target_samples for each marker based on grid and strength.
    Locked markers are not modified.
    """
    if settings is None:
        settings = QuantizeSettings()

    for marker in markers:
        if marker.locked:
            continue

        beat = _sample_to_beat(marker.position_samples, bpm, sr)
        grid_beat = _nearest_grid_beat(
            beat, settings.grid_beats,
            swing=settings.swing_amount,
            swing_feel=settings.swing_feel,
        )

        # Apply strength (0=no move, 1=full snap)
        adjusted_beat = beat + (grid_beat - beat) * settings.strength
        target = _beat_to_sample(adjusted_beat, bpm, sr)

        marker.target_samples = max(0, target)
        marker.is_adjusted = abs(marker.target_samples - marker.position_samples) > 1

    return markers


# ---------------------------------------------------------------------------
# Groove template application
# ---------------------------------------------------------------------------

def apply_groove_to_transients(
    markers: List[TransientMarker],
    groove_timing: List[float],
    bpm: float,
    sr: int,
    *,
    amount: float = 1.0,
    grid_beats: float = 0.25,
) -> List[TransientMarker]:
    """Apply a groove template's timing offsets to transient markers.

    groove_timing: list of timing offsets in beats (one per grid step,
                   0.0 = on grid, positive = late, negative = early)
    amount: 0..1, blend between straight and grooved timing
    """
    if not groove_timing:
        return markers

    n_steps = len(groove_timing)
    amount = max(0.0, min(1.0, amount))

    for marker in markers:
        if marker.locked:
            continue

        beat = _sample_to_beat(marker.position_samples, bpm, sr)
        # Which grid step is this closest to?
        grid_idx = int(round(beat / grid_beats)) % n_steps
        timing_offset = groove_timing[grid_idx] * amount

        # Snap to grid first, then apply groove offset
        grid_beat = round(beat / grid_beats) * grid_beats
        grooved_beat = grid_beat + timing_offset

        target = _beat_to_sample(grooved_beat, bpm, sr)
        marker.target_samples = max(0, target)
        marker.is_adjusted = abs(marker.target_samples - marker.position_samples) > 1

    return markers


# ---------------------------------------------------------------------------
# Elastic Audio rendering
# ---------------------------------------------------------------------------

def apply_elastic_audio(
    audio: "np.ndarray",
    markers: List[TransientMarker],
    sr: int = 48000,
    *,
    crossfade_ms: float = 5.0,
    preserve_length: bool = True,
) -> "np.ndarray":
    """Apply transient adjustments to audio using elastic splicing.

    Splits audio at transient positions, repositions each segment
    to its target position, and crossfades at splice points.

    Parameters
    ----------
    audio : 1D float32 mono
    markers : list of TransientMarker with target_samples set
    sr : sample rate
    crossfade_ms : crossfade length at splice points
    preserve_length : if True, output length = input length

    Returns
    -------
    Time-adjusted audio.
    """
    if np is None:
        return audio

    audio = np.asarray(audio, dtype=np.float32).flatten()
    original_len = len(audio)

    if not markers:
        return audio.copy()

    # Sort markers by original position
    sorted_markers = sorted(
        [m for m in markers if not m.locked or m.is_adjusted],
        key=lambda m: m.position_samples,
    )

    if not sorted_markers:
        return audio.copy()

    xfade_samples = max(1, int(crossfade_ms * 0.001 * sr))

    # Build segment list: (src_start, src_end, dst_start)
    segments: List[Tuple[int, int, int]] = []

    # Add implicit start marker at position 0 if not present
    positions = [m.position_samples for m in sorted_markers]
    targets = [m.target_samples for m in sorted_markers]

    if positions[0] > 0:
        positions.insert(0, 0)
        targets.insert(0, 0)

    # Add implicit end marker
    positions.append(original_len)
    targets.append(original_len if preserve_length else
                   targets[-1] + (original_len - positions[-2]))

    for i in range(len(positions) - 1):
        src_start = positions[i]
        src_end = positions[i + 1]
        dst_start = targets[i]
        if src_end > src_start:
            segments.append((src_start, src_end, dst_start))

    if not segments:
        return audio.copy()

    # Determine output length
    if preserve_length:
        out_len = original_len
    else:
        max_end = 0
        for src_start, src_end, dst_start in segments:
            seg_len = src_end - src_start
            max_end = max(max_end, dst_start + seg_len)
        out_len = max_end

    result = np.zeros(out_len, dtype=np.float32)

    for src_start, src_end, dst_start in segments:
        seg_len = src_end - src_start
        segment = audio[src_start:src_end].copy()

        # Where to place in output
        dst_end = dst_start + seg_len
        if dst_start < 0:
            # Trim from start
            trim = -dst_start
            segment = segment[trim:]
            seg_len -= trim
            dst_start = 0
            dst_end = dst_start + seg_len

        if dst_end > out_len:
            trim = dst_end - out_len
            segment = segment[:seg_len - trim]
            seg_len = len(segment)
            dst_end = out_len

        if seg_len <= 0:
            continue

        # Apply crossfade at boundaries
        if xfade_samples > 0 and seg_len > xfade_samples * 2:
            fade_in = np.linspace(0.0, 1.0, xfade_samples, dtype=np.float32)
            fade_out = np.linspace(1.0, 0.0, xfade_samples, dtype=np.float32)
            segment[:xfade_samples] *= fade_in
            segment[-xfade_samples:] *= fade_out

        # Overlap-add into result
        result[dst_start:dst_start + seg_len] += segment[:seg_len]

    return result


# ---------------------------------------------------------------------------
# Convenience: full quantize pipeline
# ---------------------------------------------------------------------------

def quantize_audio(
    audio: "np.ndarray",
    sr: int = 48000,
    bpm: float = 120.0,
    *,
    settings: Optional[QuantizeSettings] = None,
) -> Tuple["np.ndarray", List[TransientMarker]]:
    """Full pipeline: detect transients → quantize → apply.

    Returns (quantized_audio, markers).
    """
    if np is None:
        return (audio, [])

    if settings is None:
        settings = QuantizeSettings()

    # Step 1: Detect
    markers = detect_transients(audio, sr, sensitivity=settings.sensitivity)

    # Step 2: Quantize
    markers = quantize_transients(markers, bpm, sr, settings)

    # Step 3: Apply
    result = apply_elastic_audio(
        audio, markers, sr,
        crossfade_ms=settings.crossfade_ms,
        preserve_length=settings.preserve_length,
    )

    return (result, markers)


def quantize_audio_stereo(
    audio: "np.ndarray",
    sr: int = 48000,
    bpm: float = 120.0,
    *,
    settings: Optional[QuantizeSettings] = None,
) -> Tuple["np.ndarray", List[TransientMarker]]:
    """Quantize stereo audio. Detects from mono sum, applies to both channels."""
    if np is None:
        return (audio, [])

    audio = np.asarray(audio, dtype=np.float32)
    if audio.ndim == 1:
        result, markers = quantize_audio(audio, sr, bpm, settings=settings)
        return (result, markers)

    if audio.shape[1] > 2:
        audio = audio[:, :2]

    # Detect from mono sum
    mono = np.mean(audio, axis=1)
    if settings is None:
        settings = QuantizeSettings()
    markers = detect_transients(mono, sr, sensitivity=settings.sensitivity)
    markers = quantize_transients(markers, bpm, sr, settings)

    # Apply to each channel
    left = apply_elastic_audio(audio[:, 0], markers, sr,
                               crossfade_ms=settings.crossfade_ms,
                               preserve_length=settings.preserve_length)
    right = apply_elastic_audio(audio[:, 1], markers, sr,
                                crossfade_ms=settings.crossfade_ms,
                                preserve_length=settings.preserve_length)

    n = min(len(left), len(right))
    result = np.stack([left[:n], right[:n]], axis=1).astype(np.float32)
    return (result, markers)


# ---------------------------------------------------------------------------
# Built-in groove templates (from groove_templates.py integration)
# ---------------------------------------------------------------------------

def get_swing_groove(amount: float = 0.5, divisions: int = 16) -> List[float]:
    """Generate a simple swing groove timing template.

    amount: 0..1 (0 = straight, 0.5 = triplet, 1 = dotted)
    divisions: number of grid steps per bar (8 or 16)
    """
    groove: List[float] = []
    for i in range(divisions):
        if i % 2 == 1:
            # Swing on off-beats
            groove.append(amount * 0.5 / (divisions / 4))  # offset in beats
        else:
            groove.append(0.0)
    return groove


def get_mpc_groove(style: str = "60") -> List[float]:
    """Classic MPC swing grooves.

    style: "50" (straight), "54", "58", "60", "62", "66", "71"
    """
    # MPC swing percentages → timing offsets
    # 50% = straight, higher = more swing
    percent_map = {
        "50": 50, "54": 54, "58": 58, "60": 60,
        "62": 62, "66": 66, "71": 71,
    }
    pct = percent_map.get(str(style), 60)
    # Convert to 16th-note offset
    # At 50%, even/odd 16ths are equal. At 66%, triplet feel.
    ratio = pct / 100.0
    offset_beats = (ratio - 0.5) * 0.25  # offset in beats for 16th grid

    groove = []
    for i in range(16):
        if i % 2 == 1:
            groove.append(offset_beats)
        else:
            groove.append(0.0)
    return groove
