# -*- coding: utf-8 -*-
"""Factory Sample Generator — Synthesis-based WAV samples for built-in presets.

Generates small mono WAV files from pure synthesis (numpy). No external
dependencies, no large sample packs. Files are created lazily on first
access in ~/.config/ChronoScaleStudio/factory_samples/.

Typical sizes: Kick ~40KB, Hi-Hat ~15KB, Pad ~80KB. Total < 2MB.

SAFE: All operations wrapped in try/except. If generation fails,
presets simply won't have samples (graceful degradation).

v0.0.20.883 — Factory Sample Generator
"""

from __future__ import annotations

import logging
import math
import os
import struct
import wave
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger(__name__)

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    _HAS_NUMPY = False


# ═══════════════════════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════════════════════

SR = 44100  # Sample rate
_FACTORY_DIR: Optional[Path] = None


def _get_factory_dir() -> Path:
    """Return (and create) the factory samples directory."""
    global _FACTORY_DIR
    if _FACTORY_DIR is not None:
        return _FACTORY_DIR
    d = Path.home() / ".config" / "ChronoScaleStudio" / "factory_samples"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        d = Path("/tmp") / "pydaw_factory_samples"
        try:
            d.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    _FACTORY_DIR = d
    return d


# ═══════════════════════════════════════════════════════════════════════════════
# WAV Writer
# ═══════════════════════════════════════════════════════════════════════════════

def _write_wav(path: str, samples: "np.ndarray", sr: int = SR) -> bool:
    """Write mono float32 array to 16-bit WAV file."""
    try:
        # Normalize to prevent clipping
        peak = float(np.max(np.abs(samples)))
        if peak > 0.001:
            samples = samples / peak * 0.95
        # Convert to 16-bit PCM
        pcm = (samples * 32767).astype(np.int16)
        with wave.open(str(path), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sr)
            wf.writeframes(pcm.tobytes())
        return True
    except Exception as e:
        log.debug("Failed to write WAV %s: %s", path, e)
        return False


# ═══════════════════════════════════════════════════════════════════════════════
# Synthesis Primitives
# ═══════════════════════════════════════════════════════════════════════════════

def _sine(freq: float, duration: float, sr: int = SR) -> "np.ndarray":
    t = np.arange(int(sr * duration), dtype=np.float32) / sr
    return np.sin(2.0 * np.pi * freq * t).astype(np.float32)


def _saw(freq: float, duration: float, sr: int = SR) -> "np.ndarray":
    t = np.arange(int(sr * duration), dtype=np.float32) / sr
    return (2.0 * (t * freq - np.floor(0.5 + t * freq))).astype(np.float32)


def _square(freq: float, duration: float, sr: int = SR) -> "np.ndarray":
    return np.sign(_sine(freq, duration, sr)).astype(np.float32)


def _noise(duration: float, sr: int = SR) -> "np.ndarray":
    return np.random.uniform(-1, 1, int(sr * duration)).astype(np.float32)


def _env_ad(n: int, attack_ms: float, decay_ms: float, sr: int = SR) -> "np.ndarray":
    """Attack-Decay envelope."""
    a_samps = max(1, int(attack_ms * sr / 1000))
    d_samps = max(1, int(decay_ms * sr / 1000))
    env = np.zeros(n, dtype=np.float32)
    # Attack
    end_a = min(a_samps, n)
    env[:end_a] = np.linspace(0, 1, end_a, dtype=np.float32)
    # Decay
    start_d = end_a
    end_d = min(start_d + d_samps, n)
    if end_d > start_d:
        env[start_d:end_d] = np.linspace(1, 0, end_d - start_d, dtype=np.float32)
    return env


def _env_adsr(n: int, a_ms: float, d_ms: float, s_level: float,
              r_ms: float, sr: int = SR) -> "np.ndarray":
    """ADSR envelope."""
    a = max(1, int(a_ms * sr / 1000))
    d = max(1, int(d_ms * sr / 1000))
    r = max(1, int(r_ms * sr / 1000))
    sus_n = max(0, n - a - d - r)
    parts = []
    parts.append(np.linspace(0, 1, a, dtype=np.float32))
    parts.append(np.linspace(1, s_level, d, dtype=np.float32))
    if sus_n > 0:
        parts.append(np.full(sus_n, s_level, dtype=np.float32))
    parts.append(np.linspace(s_level, 0, r, dtype=np.float32))
    env = np.concatenate(parts)
    return env[:n] if len(env) >= n else np.pad(env, (0, n - len(env)))


def _lp_filter(sig: "np.ndarray", cutoff: float, sr: int = SR) -> "np.ndarray":
    """Simple one-pole lowpass."""
    rc = 1.0 / (2.0 * np.pi * cutoff)
    dt = 1.0 / sr
    alpha = dt / (rc + dt)
    out = np.zeros_like(sig)
    y = 0.0
    for i in range(len(sig)):
        y += alpha * (float(sig[i]) - y)
        out[i] = y
    return out


def _hp_filter(sig: "np.ndarray", cutoff: float, sr: int = SR) -> "np.ndarray":
    """Simple one-pole highpass."""
    rc = 1.0 / (2.0 * np.pi * cutoff)
    dt = 1.0 / sr
    alpha = rc / (rc + dt)
    out = np.zeros_like(sig)
    prev_x = 0.0
    y = 0.0
    for i in range(len(sig)):
        x = float(sig[i])
        y = alpha * (y + x - prev_x)
        prev_x = x
        out[i] = y
    return out


# ═══════════════════════════════════════════════════════════════════════════════
# Drum Synthesis
# ═══════════════════════════════════════════════════════════════════════════════

def _synth_kick(style: str = "808") -> "np.ndarray":
    """Synthesize a kick drum."""
    n = int(SR * 0.5)
    t = np.arange(n, dtype=np.float32) / SR

    if style == "808":
        # Sine sweep from 150Hz to 40Hz + sub
        freq = 40 + 110 * np.exp(-t * 15)
        phase = np.cumsum(2 * np.pi * freq / SR)
        sig = np.sin(phase).astype(np.float32) * 0.9
        # Transient click
        click = _noise(0.005) * _env_ad(int(SR * 0.005), 0.1, 4)
        sig[:len(click)] += click * 0.3
    elif style == "909":
        freq = 55 + 120 * np.exp(-t * 20)
        phase = np.cumsum(2 * np.pi * freq / SR)
        sig = np.sin(phase).astype(np.float32) * 0.8
        # Noise burst
        nb = _noise(0.02) * _env_ad(int(SR * 0.02), 0.1, 10)
        sig[:len(nb)] += nb * 0.4
    else:  # acoustic-ish
        freq = 80 + 200 * np.exp(-t * 30)
        phase = np.cumsum(2 * np.pi * freq / SR)
        sig = np.sin(phase).astype(np.float32) * 0.7
        nb = _lp_filter(_noise(0.03), 3000) * _env_ad(int(SR * 0.03), 0.1, 15)
        sig[:len(nb)] += nb * 0.5

    env = _env_ad(n, 0.5, 350)
    return sig * env


def _synth_snare(style: str = "808") -> "np.ndarray":
    """Synthesize a snare drum."""
    n = int(SR * 0.35)

    if style == "808":
        tone = _sine(180, 0.35) * _env_ad(n, 0.5, 150) * 0.5
        ns = _hp_filter(_noise(0.35), 2000) * _env_ad(n, 0.5, 200) * 0.7
    elif style == "909":
        tone = _sine(200, 0.35) * _env_ad(n, 0.3, 100) * 0.4
        ns = _hp_filter(_noise(0.35), 3000) * _env_ad(n, 0.3, 180) * 0.8
    else:
        tone = _sine(220, 0.35) * _env_ad(n, 0.5, 80) * 0.3
        ns = _lp_filter(_noise(0.35), 8000) * _env_ad(n, 0.5, 150) * 0.7

    sig = tone[:n] + ns[:n]
    return sig


def _synth_hihat(open_hat: bool = False) -> "np.ndarray":
    """Synthesize a hi-hat."""
    dur = 0.4 if open_hat else 0.08
    n = int(SR * dur)
    ns = _hp_filter(_noise(dur), 6000)
    decay = 300 if open_hat else 40
    env = _env_ad(n, 0.3, decay)
    return ns[:n] * env


def _synth_clap() -> "np.ndarray":
    """Synthesize a clap."""
    n = int(SR * 0.25)
    sig = np.zeros(n, dtype=np.float32)
    # Multiple short bursts
    for offset_ms in [0, 15, 30, 50]:
        start = int(offset_ms * SR / 1000)
        burst_len = int(SR * 0.015)
        end = min(start + burst_len, n)
        ns = _hp_filter(_noise(0.015), 1000)
        sig[start:end] += ns[:end - start] * 0.5
    # Tail
    tail = _hp_filter(_noise(0.25), 1500) * _env_ad(n, 1, 180) * 0.4
    sig += tail[:n]
    return sig


def _synth_tom(pitch: float = 120) -> "np.ndarray":
    """Synthesize a tom."""
    n = int(SR * 0.4)
    t = np.arange(n, dtype=np.float32) / SR
    freq = pitch + pitch * 0.5 * np.exp(-t * 12)
    phase = np.cumsum(2 * np.pi * freq / SR)
    sig = np.sin(phase).astype(np.float32) * 0.8
    env = _env_ad(n, 0.5, 250)
    return sig * env


def _synth_cowbell() -> "np.ndarray":
    """Synthesize a cowbell (808 style)."""
    n = int(SR * 0.3)
    sig = (_sine(545, 0.3) + _sine(815, 0.3)) * 0.4
    env = _env_ad(n, 0.3, 200)
    return sig[:n] * env


def _synth_rim() -> "np.ndarray":
    """Synthesize a rimshot."""
    n = int(SR * 0.05)
    tone = _sine(500, 0.05) * 0.6
    click = _hp_filter(_noise(0.05), 4000) * 0.5
    env = _env_ad(n, 0.2, 30)
    return (tone[:n] + click[:n]) * env


# ═══════════════════════════════════════════════════════════════════════════════
# Melodic Synthesis
# ═══════════════════════════════════════════════════════════════════════════════

def _synth_bass(freq: float = 55, style: str = "sub") -> "np.ndarray":
    """Synthesize a bass note."""
    dur = 1.0
    n = int(SR * dur)
    if style == "sub":
        sig = _sine(freq, dur) * 0.9
    elif style == "saw":
        sig = _lp_filter(_saw(freq, dur), 2000) * 0.7
    else:  # square
        sig = _lp_filter(_square(freq, dur), 1500) * 0.6
    env = _env_adsr(n, 5, 200, 0.6, 300)
    return sig[:n] * env


def _synth_pad(freq: float = 261.63, dur: float = 2.0) -> "np.ndarray":
    """Synthesize a pad/texture sound."""
    n = int(SR * dur)
    # Detuned oscillators
    sig = (_sine(freq, dur) * 0.3 +
           _sine(freq * 1.003, dur) * 0.25 +
           _sine(freq * 0.997, dur) * 0.25 +
           _sine(freq * 2.0, dur) * 0.1 +
           _sine(freq * 3.0, dur) * 0.05)
    sig = _lp_filter(sig, 3000)
    env = _env_adsr(n, 300, 500, 0.7, 800)
    return sig[:n] * env


def _synth_pluck(freq: float = 440) -> "np.ndarray":
    """Karplus-Strong pluck synthesis."""
    dur = 1.0
    n = int(SR * dur)
    # Karplus-Strong
    period = max(2, int(SR / freq))
    buf = np.random.uniform(-1, 1, period).astype(np.float32)
    out = np.zeros(n, dtype=np.float32)
    idx = 0
    for i in range(n):
        out[i] = buf[idx]
        avg = 0.5 * (buf[idx] + buf[(idx + 1) % period])
        buf[idx] = avg * 0.996  # Decay
        idx = (idx + 1) % period
    return out * 0.8


def _synth_bell(freq: float = 880) -> "np.ndarray":
    """FM bell synthesis."""
    dur = 1.5
    n = int(SR * dur)
    t = np.arange(n, dtype=np.float32) / SR
    mod_freq = freq * 1.4
    mod_depth = freq * 2.0 * np.exp(-t * 3)
    sig = np.sin(2 * np.pi * freq * t + mod_depth * np.sin(2 * np.pi * mod_freq * t))
    env = _env_ad(n, 1, 1200)
    return sig.astype(np.float32) * env * 0.6


def _synth_string(freq: float = 220) -> "np.ndarray":
    """Synthesize a string-like sound."""
    dur = 2.0
    n = int(SR * dur)
    sig = (_saw(freq, dur) * 0.3 +
           _saw(freq * 1.005, dur) * 0.25 +
           _saw(freq * 0.995, dur) * 0.25)
    sig = _lp_filter(sig, 4000)
    env = _env_adsr(n, 200, 300, 0.8, 500)
    return sig[:n] * env


def _synth_organ(freq: float = 261.63) -> "np.ndarray":
    """Synthesize organ drawbar sound."""
    dur = 1.5
    n = int(SR * dur)
    # Drawbar harmonics: 16' 8' 4' 2⅔' 2' 1⅗'
    sig = (_sine(freq * 0.5, dur) * 0.3 +
           _sine(freq, dur) * 0.8 +
           _sine(freq * 2, dur) * 0.5 +
           _sine(freq * 3, dur) * 0.2 +
           _sine(freq * 4, dur) * 0.3 +
           _sine(freq * 5, dur) * 0.1)
    env = _env_adsr(n, 5, 50, 0.95, 50)
    return sig[:n] * env * 0.5


def _synth_lead(freq: float = 440, style: str = "saw") -> "np.ndarray":
    """Synthesize a lead sound."""
    dur = 1.0
    n = int(SR * dur)
    if style == "saw":
        sig = _lp_filter(_saw(freq, dur), 6000) * 0.7
    else:  # square
        sig = _lp_filter(_square(freq, dur), 4000) * 0.6
    env = _env_adsr(n, 10, 100, 0.7, 200)
    return sig[:n] * env


# ═══════════════════════════════════════════════════════════════════════════════
# Factory Sample Sets — Definitions
# ═══════════════════════════════════════════════════════════════════════════════

# Each entry: (filename, generator_function, args)
_DRUM_SAMPLES = [
    ("kick_808.wav", _synth_kick, ("808",)),
    ("kick_909.wav", _synth_kick, ("909",)),
    ("kick_acoustic.wav", _synth_kick, ("acoustic",)),
    ("snare_808.wav", _synth_snare, ("808",)),
    ("snare_909.wav", _synth_snare, ("909",)),
    ("snare_acoustic.wav", _synth_snare, ("acoustic",)),
    ("hihat_closed.wav", _synth_hihat, (False,)),
    ("hihat_open.wav", _synth_hihat, (True,)),
    ("clap.wav", _synth_clap, ()),
    ("tom_high.wav", _synth_tom, (200,)),
    ("tom_mid.wav", _synth_tom, (140,)),
    ("tom_low.wav", _synth_tom, (80,)),
    ("cowbell.wav", _synth_cowbell, ()),
    ("rim.wav", _synth_rim, ()),
]

_MELODIC_SAMPLES = [
    ("bass_sub_A1.wav", _synth_bass, (55, "sub")),
    ("bass_saw_A1.wav", _synth_bass, (55, "saw")),
    ("bass_square_A1.wav", _synth_bass, (55, "square")),
    ("pad_C4.wav", _synth_pad, (261.63, 2.0)),
    ("pad_E4.wav", _synth_pad, (329.63, 2.0)),
    ("pad_G4.wav", _synth_pad, (392.0, 2.0)),
    ("pluck_A4.wav", _synth_pluck, (440,)),
    ("pluck_C5.wav", _synth_pluck, (523.25,)),
    ("pluck_E5.wav", _synth_pluck, (659.25,)),
    ("bell_C5.wav", _synth_bell, (523.25,)),
    ("bell_E5.wav", _synth_bell, (659.25,)),
    ("string_A3.wav", _synth_string, (220,)),
    ("string_D4.wav", _synth_string, (293.66,)),
    ("organ_C4.wav", _synth_organ, (261.63,)),
    ("lead_saw_A4.wav", _synth_lead, (440, "saw")),
    ("lead_square_A4.wav", _synth_lead, (440, "square")),
]


# ═══════════════════════════════════════════════════════════════════════════════
# Public API
# ═══════════════════════════════════════════════════════════════════════════════

_generated = False


def ensure_factory_samples() -> Path:
    """Generate factory samples if they don't exist yet.

    Returns the factory samples directory path.
    Thread-safe: multiple calls are idempotent.
    """
    global _generated
    if _generated:
        return _get_factory_dir()
    if not _HAS_NUMPY:
        log.warning("numpy not available — cannot generate factory samples")
        return _get_factory_dir()

    d = _get_factory_dir()
    drums_dir = d / "drums"
    melodic_dir = d / "melodic"

    try:
        drums_dir.mkdir(parents=True, exist_ok=True)
        melodic_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    count = 0
    for fname, gen_fn, args in _DRUM_SAMPLES:
        path = drums_dir / fname
        if not path.exists():
            try:
                samples = gen_fn(*args)
                if _write_wav(str(path), samples):
                    count += 1
            except Exception:
                pass

    for fname, gen_fn, args in _MELODIC_SAMPLES:
        path = melodic_dir / fname
        if not path.exists():
            try:
                samples = gen_fn(*args)
                if _write_wav(str(path), samples):
                    count += 1
            except Exception:
                pass

    _generated = True
    if count > 0:
        log.info("Generated %d factory samples in %s", count, d)
    return d


def get_drum_sample_path(name: str) -> str:
    """Get path to a drum factory sample. Generates if needed."""
    d = ensure_factory_samples()
    return str(d / "drums" / name)


def get_melodic_sample_path(name: str) -> str:
    """Get path to a melodic factory sample. Generates if needed."""
    d = ensure_factory_samples()
    return str(d / "melodic" / name)


def get_all_drum_paths() -> Dict[str, str]:
    """Return dict of drum sample name → path."""
    d = ensure_factory_samples()
    drums_dir = d / "drums"
    result = {}
    for fname, _, _ in _DRUM_SAMPLES:
        p = drums_dir / fname
        if p.exists():
            result[fname.replace(".wav", "")] = str(p)
    return result


def get_all_melodic_paths() -> Dict[str, str]:
    """Return dict of melodic sample name → path."""
    d = ensure_factory_samples()
    mel_dir = d / "melodic"
    result = {}
    for fname, _, _ in _MELODIC_SAMPLES:
        p = mel_dir / fname
        if p.exists():
            result[fname.replace(".wav", "")] = str(p)
    return result
