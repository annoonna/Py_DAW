# -*- coding: utf-8 -*-
"""Plugins Browser (LV2/LADSPA/DSSI/VST) — replaces placeholder.

SAFE / NON-DESTRUCTIVE
----------------------
This widget only lists external plugins installed on the system.
It does **NOT** load/host plugins yet.

Features:
- Tabs per plugin type
- Search + "Only Favorites"
- ⭐ Favorites (stored in existing device_prefs.json, under ext_* keys)
- Cache + async rescan
- Context menu (copy id/path, open folder)
- Paths dialog (QSettings overrides)
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Dict, List, Optional

from PyQt6.QtCore import Qt, QMimeData, QThread, pyqtSignal, QObject, QUrl
from PyQt6.QtGui import QDrag, QDesktopServices, QGuiApplication
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTabWidget, QListWidget, QListWidgetItem, QMenu, QCheckBox, QMessageBox
)

from .device_prefs import DevicePrefs
from .plugin_paths_dialog import PluginPathsDialog
from ..services import plugin_scanner

# NOTE:
# We intentionally use the **existing** device DnD mime so the DevicePanel
# can accept drops without any risky refactors.
_MIME = "application/x-pydaw-plugin"

# Legacy/Reserved (kept for future): a dedicated ext-plugin mime.
_MIME_EXT = "application/x-pydaw-ext-plugin"


class _StarDragList(QListWidget):
    """List with a left-star hitbox for favorites + drag payload."""

    def __init__(self, kind_key: str, on_toggle_fav=None, parent=None):  # noqa: ANN001
        super().__init__(parent)
        self.kind_key = str(kind_key)
        self._on_toggle_fav = on_toggle_fav
        self.setSelectionMode(QListWidget.SelectionMode.SingleSelection)
        self.setDragEnabled(True)
        self.setDragDropMode(QListWidget.DragDropMode.DragOnly)
        self.setDefaultDropAction(Qt.DropAction.CopyAction)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)

    def mousePressEvent(self, event):  # noqa: N802, ANN001
        try:
            if event.button() == Qt.MouseButton.LeftButton:
                try:
                    pos = event.position().toPoint()
                except Exception:
                    pos = event.pos()
                if pos.x() < 18:
                    it = self.itemAt(pos)
                    if it is not None and self._on_toggle_fav is not None:
                        self.setCurrentItem(it)
                        payload = it.data(Qt.ItemDataRole.UserRole) or {}
                        if isinstance(payload, dict):
                            pid = str(payload.get("plugin_id") or "")
                            name = str(payload.get("name") or "")
                            if pid:
                                try:
                                    self._on_toggle_fav(self.kind_key, pid, name)
                                except Exception:
                                    pass
                                event.accept()
                                return
        except Exception:
            pass
        try:
            super().mousePressEvent(event)
        except Exception:
            pass

    def startDrag(self, supportedActions):  # noqa: N802, ANN001
        try:
            it = self.currentItem()
            if it is None:
                return
            payload = it.data(Qt.ItemDataRole.UserRole) or {}
            if not isinstance(payload, dict):
                return
            ext_id = str(payload.get("plugin_id") or "")
            name = str(payload.get("name") or it.text() or "")
            ext_kind = str(payload.get("kind") or "")
            path = str(payload.get("path") or "")
            if not ext_id:
                return
            # Create a stable "device plugin_id" that is unique per external plugin.
            # This remains UI-only for now; the audio engine will simply ignore unknown ids.
            dev_pid = f"ext.{ext_kind}:{ext_id}" if ext_kind else f"ext:{ext_id}"
            params = {
                "__ext_kind": ext_kind,
                "__ext_id": ext_id,
                "__ext_path": path,
            }
            md = QMimeData()
            md.setData(
                _MIME,
                json.dumps({
                    "kind": "audio_fx",
                    "plugin_id": dev_pid,
                    "name": name,
                    "params": params,
                }).encode("utf-8"),
            )
            drag = QDrag(self)
            drag.setMimeData(md)
            drag.exec(Qt.DropAction.CopyAction)
        except Exception:
            return


class _ScanWorker(QObject):
    finished = pyqtSignal(dict)
    status = pyqtSignal(str)

    def __init__(self, extra_paths: Dict[str, List[str]]):
        super().__init__()
        self._extra_paths = extra_paths

    def run(self) -> None:
        try:
            self.status.emit("Scanning plugins…")
        except Exception:
            pass
        try:
            res = plugin_scanner.scan_all(self._extra_paths)
        except Exception:
            res = {}
        try:
            try:
                plugin_scanner.save_cache(res)
            except Exception:
                pass
            self.finished.emit(res)
        except Exception:
            pass


class PluginsBrowserWidget(QWidget):
    prefs_changed = pyqtSignal()

    def __init__(self, on_add_audio_fx=None, parent=None):  # noqa: ANN001
        super().__init__(parent)
        self._on_add_audio_fx = on_add_audio_fx
        self._data: Dict[str, List[plugin_scanner.ExtPlugin]] = {}
        self._thread: Optional[QThread] = None
        self._worker: Optional[_ScanWorker] = None
        self._build()
        self._load_cache_fast()
        self.rescan(async_=True)

    def _safe(self, fn, *a, **k):  # noqa: ANN001
        try:
            return fn(*a, **k)
        except Exception:
            return None

    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(8)

        header = QLabel("Plugins")
        header.setObjectName("pluginsBrowserTitle")

        row = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Suchen… (LV2 / LADSPA / DSSI / VST)")
        self.search.textChanged.connect(lambda _t: self._safe(self._refilter_all))

        self.only_favs = QCheckBox("Only Favorites")
        self.only_favs.stateChanged.connect(lambda _v: self._safe(self._refilter_all))

        self.btn_add = QPushButton("Add to Device")
        self.btn_add.clicked.connect(lambda _=False: self._safe(self._add_selected))

        self.btn_rescan = QPushButton("Rescan")
        self.btn_rescan.clicked.connect(lambda _=False: self._safe(self.rescan, True))

        self.btn_paths = QPushButton("Paths…")
        self.btn_paths.clicked.connect(lambda _=False: self._safe(self._open_paths_dialog))

        row.addWidget(self.search, 1)
        row.addWidget(self.only_favs, 0)
        row.addWidget(self.btn_add, 0)
        row.addWidget(self.btn_rescan, 0)
        row.addWidget(self.btn_paths, 0)

        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.TabPosition.North)

        self.list_lv2 = _StarDragList("ext_lv2", on_toggle_fav=lambda k, pid, nm: self._safe(self._toggle_favorite, k, pid, nm))
        self.list_ladspa = _StarDragList("ext_ladspa", on_toggle_fav=lambda k, pid, nm: self._safe(self._toggle_favorite, k, pid, nm))
        self.list_dssi = _StarDragList("ext_dssi", on_toggle_fav=lambda k, pid, nm: self._safe(self._toggle_favorite, k, pid, nm))
        self.list_vst2 = _StarDragList("ext_vst2", on_toggle_fav=lambda k, pid, nm: self._safe(self._toggle_favorite, k, pid, nm))
        self.list_vst3 = _StarDragList("ext_vst3", on_toggle_fav=lambda k, pid, nm: self._safe(self._toggle_favorite, k, pid, nm))

        for lst in (self.list_lv2, self.list_ladspa, self.list_dssi, self.list_vst2, self.list_vst3):
            lst.itemDoubleClicked.connect(lambda _it, _lst=lst: self._safe(self._add_selected, _lst))
            lst.customContextMenuRequested.connect(lambda pos, _lst=lst: self._safe(self._context_menu, _lst, pos))

        self.tabs.addTab(self.list_lv2, "LV2")
        self.tabs.addTab(self.list_ladspa, "LADSPA")
        self.tabs.addTab(self.list_dssi, "DSSI")
        self.tabs.addTab(self.list_vst2, "VST2")
        self.tabs.addTab(self.list_vst3, "VST3")

        self.status = QLabel("")
        self.status.setStyleSheet("color:#9a9a9a;")
        self.status.setWordWrap(True)
        self._set_status(
            "Hinweis: LV2 Hosting (Audio-FX) ist jetzt optional verfügbar (benötigt python-lilv). "
            "LADSPA/DSSI/VST bleiben vorerst Placeholder. "
            "Du kannst Plugins in die Audio-FX Device-Chain einfügen (Drag&Drop / Add)."
        )

        root.addWidget(header)
        root.addLayout(row)
        root.addWidget(self.tabs, 1)
        root.addWidget(self.status)

    def _set_status(self, text: str) -> None:
        try:
            self.status.setText(str(text))
        except Exception:
            pass

    def _load_cache_fast(self) -> None:
        try:
            cached = plugin_scanner.load_cache() or {}
        except Exception:
            cached = {}
        if cached:
            self._data = cached
            self._refilter_all()
            total = sum(len(v) for v in cached.values())
            self._set_status(f"Cache geladen: {total} Plugins. (Rescan aktualisiert)")

    def _gather_extra_paths(self) -> Dict[str, List[str]]:
        from PyQt6.QtCore import QSettings
        from ..core.settings import SettingsKeys

        s = QSettings(SettingsKeys.organization, SettingsKeys.application)
        out: Dict[str, List[str]] = {}
        for kind in ("lv2", "ladspa", "dssi", "vst2", "vst3"):
            key = f"plugins/paths/{kind}"
            val = s.value(key, [])
            paths: List[str] = []
            if isinstance(val, (list, tuple)):
                paths = [str(x) for x in val if str(x).strip()]
            elif isinstance(val, str) and val.strip():
                paths = [val.strip()]
            if paths:
                out[kind] = paths
        return out

    def rescan(self, async_: bool = True) -> None:
        try:
            if self._thread is not None:
                self._thread.quit()
                self._thread.wait(200)
        except Exception:
            pass
        self._thread = None
        self._worker = None

        extra = self._gather_extra_paths()

        if not async_:
            try:
                self._set_status("Scanning plugins…")
                res = plugin_scanner.scan_all(extra)
                try:
                    plugin_scanner.save_cache(res)
                except Exception:
                    pass
                self._on_scan_finished(res)
            except Exception:
                self._set_status("Scan fehlgeschlagen.")
            return

        try:
            self.btn_rescan.setEnabled(False)
        except Exception:
            pass

        t = QThread(self)
        w = _ScanWorker(extra)
        w.moveToThread(t)
        t.started.connect(w.run)
        w.finished.connect(self._on_scan_finished)
        w.status.connect(lambda msg: self._set_status(msg))
        w.finished.connect(lambda _res: self._safe(self._cleanup_thread))
        t.start()

        self._thread = t
        self._worker = w

    def _cleanup_thread(self) -> None:
        try:
            if self._thread is not None:
                self._thread.quit()
                self._thread.wait(500)
        except Exception:
            pass
        try:
            if self._worker is not None:
                self._worker.deleteLater()
        except Exception:
            pass
        try:
            if self._thread is not None:
                self._thread.deleteLater()
        except Exception:
            pass
        self._thread = None
        self._worker = None
        try:
            self.btn_rescan.setEnabled(True)
        except Exception:
            pass

    def _on_scan_finished(self, res: dict) -> None:
        try:
            data: Dict[str, List[plugin_scanner.ExtPlugin]] = {}
            for k, arr in (res or {}).items():
                if isinstance(arr, list):
                    data[str(k)] = [x for x in arr if isinstance(x, plugin_scanner.ExtPlugin)]
            self._data = data
            self._refilter_all()
            total = sum(len(v) for v in data.values())
            # LV2 hosting availability hint (safe)
            lv2_hint = "LV2 Host: unbekannt"
            try:
                from pydaw.audio import lv2_host
                if lv2_host.is_available():
                    lv2_hint = "LV2 Host: OK (Audio‑FX live)"
                else:
                    lv2_hint = "LV2 Host: " + str(lv2_host.availability_hint())
            except Exception:
                pass

            self._set_status(
                f"Scan fertig: {total} Plugins (LV2 {len(data.get('lv2', []))}, "
                f"LADSPA {len(data.get('ladspa', []))}, DSSI {len(data.get('dssi', []))}, "
                f"VST2 {len(data.get('vst2', []))}, VST3 {len(data.get('vst3', []))}). "
                f"{lv2_hint}. "
                "LADSPA/DSSI/VST: aktuell nur Browser/Placeholder."
            )
        except Exception:
            self._set_status("Scan fertig (mit Fehlern).")

    def _toggle_favorite(self, kind_key: str, plugin_id: str, name: str) -> None:
        try:
            prefs = DevicePrefs.load()
            prefs.toggle_favorite(str(kind_key), str(plugin_id), str(name))
            prefs.save()
            self._refilter_all()
            try:
                self.prefs_changed.emit()
            except Exception:
                pass
        except Exception:
            pass

    def _add_selected(self, lst: Optional[QListWidget] = None) -> None:
        try:
            lst = lst or self.tabs.currentWidget()
            if not isinstance(lst, QListWidget):
                return
            it = lst.currentItem()
            if it is None:
                return
            payload = it.data(Qt.ItemDataRole.UserRole) or {}
            if not isinstance(payload, dict):
                return
            kind_key = str(payload.get("kind_key") or "")
            ext_id = str(payload.get("plugin_id") or "")
            name = str(payload.get("name") or "")
            ext_kind = str(payload.get("kind") or "")
            path = str(payload.get("path") or "")
            if not ext_id:
                return
            prefs = DevicePrefs.load()
            prefs.add_recent(kind_key or "ext", ext_id, name)
            prefs.save()

            dev_pid = f"ext.{ext_kind}:{ext_id}" if ext_kind else f"ext:{ext_id}"
            params = {"__ext_kind": ext_kind, "__ext_id": ext_id, "__ext_path": path}

            # Insert as Audio-FX placeholder (safe). If callback is missing, we still update recents.
            if self._on_add_audio_fx is not None:
                try:
                    self._on_add_audio_fx(dev_pid, name, params)
                    msg = f"Added to Device: {name}"
                    if ext_kind == "lv2":
                        try:
                            from pydaw.audio import lv2_host
                            if lv2_host.is_available():
                                msg += " — LV2 live OK"
                            else:
                                msg += " — LV2 no-op (python-lilv fehlt)"
                        except Exception:
                            msg += " — LV2 (Status unbekannt)"
                    else:
                        msg += " — Placeholder (Hosting noch nicht implementiert)"
                    self._set_status(msg)
                    return
                except TypeError:
                    # Backward compatible: callback might only accept (plugin_id)
                    try:
                        self._on_add_audio_fx(dev_pid)
                        msg = f"Added to Device: {name}"
                        if ext_kind == "lv2":
                            try:
                                from pydaw.audio import lv2_host
                                if lv2_host.is_available():
                                    msg += " — LV2 live OK"
                                else:
                                    msg += " — LV2 no-op (python-lilv fehlt)"
                            except Exception:
                                msg += " — LV2 (Status unbekannt)"
                        else:
                            msg += " — Placeholder (Hosting noch nicht implementiert)"
                        self._set_status(msg)
                        return
                    except Exception:
                        pass
                except Exception:
                    pass

            self._set_status(f"Ausgewählt: {name}  —  (Hosting noch nicht implementiert)")
        except Exception:
            pass

    def _context_menu(self, lst: QListWidget, pos) -> None:  # noqa: ANN001
        try:
            it = lst.itemAt(pos)
            if it is None:
                return
            payload = it.data(Qt.ItemDataRole.UserRole) or {}
            if not isinstance(payload, dict):
                return
            pid = str(payload.get("plugin_id") or "")
            name = str(payload.get("name") or "")
            kind_key = str(payload.get("kind_key") or "")
            path = str(payload.get("path") or "")
            if not pid:
                return

            prefs = DevicePrefs.load()
            fav = bool(prefs.is_favorite(kind_key, pid))

            m = QMenu(self)

            a_add = m.addAction("Add to Device (Placeholder)")
            a_add.triggered.connect(lambda _=False: self._safe(self._add_selected, lst))
            m.addSeparator()

            a_fav = m.addAction("⭐ Remove from Favorites" if fav else "⭐ Add to Favorites")
            a_fav.triggered.connect(lambda _=False: self._safe(self._toggle_favorite, kind_key, pid, name))
            m.addSeparator()
            a_copy_id = m.addAction("Copy ID")
            a_copy_id.triggered.connect(lambda _=False: self._safe(self._copy_to_clipboard, pid))

            # Offline debug helper (LV2 only): render an audio file through this plugin.
            if str(payload.get("kind") or "") == "lv2":
                try:
                    from PyQt6.QtWidgets import QFileDialog
                    a_off = m.addAction("Offline: Render WAV through LV2…")
                    def _do_offline(_=False, _pid=pid, _name=name):
                        try:
                            from pydaw.audio.lv2_host import offline_process_wav_subprocess
                        except Exception:
                            try:
                                QMessageBox.information(self, "LV2", "LV2 Hosting ist nicht verfügbar.")
                            except Exception:
                                pass
                            return
                        try:
                            uri = str(_pid)
                            if not uri:
                                return
                            in_path, _ = QFileDialog.getOpenFileName(
                                self, "Input Audio wählen", str(Path.home()),
                                "Audio (*.wav *.flac *.ogg *.aiff *.aif);;All (*.*)"
                            )
                            if not in_path:
                                return
                            p_in = Path(in_path)
                            out_suggest = str(p_in.with_name(p_in.stem + f"_{_name or 'lv2'}_out.wav"))
                            out_path, _ = QFileDialog.getSaveFileName(self, "Output WAV speichern", out_suggest, "WAV (*.wav)")
                            if not out_path:
                                return
                            ok, msg = offline_process_wav_subprocess(uri=uri, in_path=in_path, out_path=out_path)
                            if ok:
                                QMessageBox.information(self, "LV2 Offline Render", f"OK: {Path(out_path).name}")
                            else:
                                QMessageBox.warning(self, "LV2 Offline Render", str(msg))
                        except Exception as e:
                            try:
                                QMessageBox.warning(self, "LV2 Offline Render", str(e))
                            except Exception:
                                pass
                    a_off.triggered.connect(_do_offline)
                    m.addSeparator()
                except Exception:
                    pass
            if path:
                a_copy_path = m.addAction("Copy Path")
                a_copy_path.triggered.connect(lambda _=False: self._safe(self._copy_to_clipboard, path))
                a_open = m.addAction("Open in File Manager")
                a_open.triggered.connect(lambda _=False: self._safe(self._open_in_file_manager, path))
            m.exec(lst.mapToGlobal(pos))
        except Exception:
            pass

    def _copy_to_clipboard(self, text: str) -> None:
        try:
            QGuiApplication.clipboard().setText(str(text))
            self._set_status("Copied to clipboard.")
        except Exception:
            pass

    def _open_in_file_manager(self, path: str) -> None:
        try:
            p = Path(path)
            if p.is_file():
                p = p.parent
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(p)))
        except Exception:
            pass

    def _open_paths_dialog(self) -> None:
        try:
            dlg = PluginPathsDialog(self)
            if dlg.exec():
                self.rescan(async_=True)
        except Exception:
            QMessageBox.information(self, "Plugins", "Paths dialog failed.")

    def _refilter_all(self) -> None:
        q = (self.search.text() or "").strip().lower()
        only_favs = bool(self.only_favs.isChecked())
        try:
            prefs = DevicePrefs.load()
        except Exception:
            prefs = None

        def fill(lst: _StarDragList, kind: str, kind_key: str) -> None:
            lst.clear()
            arr = self._data.get(kind, []) or []
            for p in arr:
                try:
                    pid = str(p.plugin_id)
                    name = str(p.name or pid)
                    path = str(p.path or "")
                    hay = f"{name} {pid} {path}".lower()
                    if q and q not in hay:
                        continue
                    fav = bool(prefs and prefs.is_favorite(kind_key, pid))
                    if only_favs and not fav:
                        continue
                    star = "★" if fav else "☆"
                    shown_id = pid
                    if os.path.sep in shown_id:
                        try:
                            shown_id = Path(shown_id).name
                        except Exception:
                            pass
                    it = QListWidgetItem(f"{star}  {name}   —   {shown_id}")
                    it.setData(
                        Qt.ItemDataRole.UserRole,
                        {"kind": kind, "kind_key": kind_key, "plugin_id": pid, "name": name, "path": path, "favorite": fav},
                    )
                    lst.addItem(it)
                except Exception:
                    continue

        fill(self.list_lv2, "lv2", "ext_lv2")
        fill(self.list_ladspa, "ladspa", "ext_ladspa")
        fill(self.list_dssi, "dssi", "ext_dssi")
        fill(self.list_vst2, "vst2", "ext_vst2")
        fill(self.list_vst3, "vst3", "ext_vst3")
