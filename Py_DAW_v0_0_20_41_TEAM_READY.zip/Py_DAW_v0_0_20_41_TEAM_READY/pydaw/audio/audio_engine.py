"""Audio engine abstraction (PipeWire preferred).

v0.0.2 goals:
- Detect a suitable audio backend automatically.
  * Preferred: JACK client (typically provided by PipeWire via pipewire-jack)
  * Fallback: sounddevice (PortAudio)
- Provide device/port enumeration for an Audio Settings dialog.
- Provide a non-blocking start/stop skeleton (threaded), so the GUI never freezes.

Notes for Linux/PipeWire:
- If pipewire-jack is installed and PipeWire is running, JACK ports will appear
  in qpwgraph and are routable like a modern DAW graph.
"""

from __future__ import annotations

from dataclasses import dataclass
from collections import OrderedDict
from typing import List, Optional, Literal, Dict, Any, Tuple
import copy
import math
import shutil
import threading

import os
import contextlib
import time

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None

try:
    import soundfile as sf
except Exception:  # pragma: no cover
    sf = None

from .midi_render import RenderKey, ensure_rendered_wav
from .arrangement_renderer import prepare_clips, ArrangementState

# v0.0.20.14 Hybrid Engine imports (Phase 2: per-track + JACK + default callback)
try:
    from .hybrid_engine import (
        HybridAudioCallback, HybridEngineBridge, get_hybrid_bridge,
        PARAM_MASTER_VOL, PARAM_MASTER_PAN,
    )
    from .ring_buffer import (
        ParamRingBuffer, AudioRingBuffer, TrackParamState,
        track_param_id, TRACK_VOL, TRACK_PAN, TRACK_MUTE, TRACK_SOLO,
    )
    from .async_loader import get_async_loader, get_sample_cache
    _HYBRID_AVAILABLE = True
except Exception:
    _HYBRID_AVAILABLE = False

# v0.0.20.14: Essentia Worker Pool
try:
    from .essentia_pool import get_essentia_pool, EssentiaWorkerPool
    _ESSENTIA_POOL_AVAILABLE = True
except Exception:
    _ESSENTIA_POOL_AVAILABLE = False


def _midi_notes_content_hash(notes) -> str:  # noqa: ANN001
    """Stable hash for MIDI note content.

    Used to invalidate the FluidSynth render cache when notes change.
    """
    import hashlib

    h = hashlib.sha1()
    for n in (notes or []):
        try:
            pitch = int(getattr(n, "pitch", 0))
            sb = float(getattr(n, "start_beats", 0.0))
            lb = float(getattr(n, "length_beats", 0.0))
            vel = int(getattr(n, "velocity", 0))
        except Exception:
            continue
        h.update(f"{pitch}:{sb:.6f}:{lb:.6f}:{vel};".encode("utf-8"))
    return h.hexdigest()[:16]


@contextlib.contextmanager
def _suppress_stderr_fd():
    """Suppress C-level stderr (e.g., JACK/PortAudio noise) temporarily."""
    try:
        devnull = os.open(os.devnull, os.O_WRONLY)
        old = os.dup(2)
        os.dup2(devnull, 2)
        os.close(devnull)
        yield
    finally:
        try:
            os.dup2(old, 2)
            os.close(old)
        except Exception:
            pass

from PyQt6.QtCore import QObject, QThread, pyqtSignal

Backend = Literal["jack", "sounddevice", "none"]


@dataclass(frozen=True)
class AudioEndpoint:
    """Represents a selectable input/output endpoint."""
    id: str
    label: str


@dataclass
class AudioBackendInfo:
    backend: Backend
    available: bool
    details: str


class _EngineThread(QThread):
    """Background thread for long-running audio operations.

    In v0.0.2 this is intentionally minimal: it demonstrates that audio work
    can live off the GUI thread and provides a place to host a realtime loop
    later (recording, transport sync, etc.).
    """

    started_ok = pyqtSignal(str)
    stopped_ok = pyqtSignal()
    error = pyqtSignal(str)

    def __init__(self, backend: Backend, config: Dict[str, Any]):
        super().__init__()
        self._backend = backend
        self._config = config
        self._stop_flag = False

        # Optional: TransportService für sample-accurate UI-Sync.
        # Muss thread-safe sein (keine Qt-Signale vom Audio-Thread).
        self._transport_service = config.get("transport_service")

        # Small in-memory cache to avoid re-reading / re-decoding the same files
        # during rapid stop/play iterations. Keeps UI responsive on slower disks.
        # Key: (path, target_sr) -> cached stereo float32 array at target_sr.
        self._wav_cache = OrderedDict()
        self._wav_cache_max = int(config.get("wav_cache_max", 16) or 16)

    def request_stop(self) -> None:
        self._stop_flag = True

    def run(self) -> None:
        try:
            if self._backend == "sounddevice":
                mode = (self._config.get("mode") or "silence").lower()
                if mode == "arrangement" and self._config.get("project_snapshot") is not None:
                    self._run_sounddevice_arrangement()
                else:
                    self._run_sounddevice_silence()
            elif self._backend == "jack":
                # For JACK we do not start a stream here; connecting/processing
                # is handled via JACK callbacks in future versions.
                # We still keep a thread alive to show non-blocking structure.
                self.started_ok.emit("JACK bereit (Platzhalter-Engine-Thread aktiv)")
                while not self._stop_flag:
                    self.msleep(50)
            else:
                self.error.emit("Kein Audio-Backend verfügbar.")
        except Exception as exc:  # pragma: no cover
            self.error.emit(str(exc))
        finally:
            self.stopped_ok.emit()

    def _run_sounddevice_silence(self) -> None:
        try:
            import numpy as np
            import sounddevice as sd
        except Exception as exc:
            raise RuntimeError(
                "sounddevice/numpy nicht verfügbar. Bitte requirements installieren."
            ) from exc

        sr = int(self._config.get("sample_rate") or 48000)
        bs = int(self._config.get("buffer_size") or 256)

        out_dev = self._config.get("output_device")
        out_dev = int(out_dev) if out_dev not in (None, "", "None") else None

        self.started_ok.emit(f"sounddevice gestartet (SR={sr}, Buffer={bs})")

        audio_engine_ref = self._config.get("audio_engine_ref")
        last_gen = -1
        pull_sources = []

        # Sample-accurate playhead even in "silence" mode (needed for ClipLauncher).
        silence_playhead = 0
        scratch_buf = np.zeros((8192, 2), dtype=np.float32)

        def callback(outdata, frames, time, status):  # noqa: ANN001
            nonlocal last_gen, pull_sources, silence_playhead
            if status:
                pass

            # Start with silence (no allocations)
            outdata.fill(0)

            # Advance RT param smoothing
            rt = getattr(audio_engine_ref, "rt_params", None) if audio_engine_ref else None
            if rt is not None:
                try:
                    rt.advance(int(frames), int(sr))
                except Exception:
                    pass

            # Provide start playhead to Transport
            try:
                if self._transport_service is not None and bool(getattr(self._transport_service, "playing", False)):
                    self._transport_service._set_external_playhead_samples(int(silence_playhead), float(sr))
            except Exception:
                pass

            if audio_engine_ref is not None:
                # Update pull-source cache if needed
                try:
                    gen, srcs = audio_engine_ref._pull_sources_snapshot(last_gen)
                    if gen != last_gen:
                        last_gen = gen
                        pull_sources = srcs
                except Exception:
                    pass

                # Mix pull sources (per-track gain/pan/mute/solo when track-id metadata is present)
                any_solo = False
                try:
                    if rt is not None:
                        any_solo = bool(rt.any_solo())
                except Exception:
                    any_solo = False

                hb = getattr(audio_engine_ref, "_hybrid_bridge", None)
                hcb = getattr(hb, "callback", None) if hb is not None else None

                for fn in (pull_sources or []):
                    try:
                        b = fn(int(frames), int(sr))
                        if b is None:
                            continue

                        # Ensure 2ch
                        b2 = b[:frames, :2]

                        # Optional per-track routing via metadata on pull fn
                        tid_attr = getattr(fn, "_pydaw_track_id", None)
                        tid = tid_attr() if callable(tid_attr) else tid_attr
                        tid = str(tid) if tid not in (None, "", "None") else ""

                        if tid and rt is not None:
                            # Mute/Solo gating
                            try:
                                if rt.is_track_muted(tid):
                                    continue
                            except Exception:
                                pass
                            try:
                                if any_solo and (not rt.is_track_solo(tid)):
                                    continue
                            except Exception:
                                pass

                            # Smoothed track vol/pan
                            try:
                                tv = float(rt.get_track_vol(tid))
                            except Exception:
                                tv = 1.0
                            try:
                                tp = float(rt.get_track_pan(tid))
                            except Exception:
                                tp = 0.0

                            tp = max(-1.0, min(1.0, tp))
                            a = (tp + 1.0) * 0.25 * math.pi
                            gl, gr = math.cos(a) * tv, math.sin(a) * tv

                            # Track metering (so VU moves in Live/Preview mode)
                            try:
                                if hb is not None and hcb is not None:
                                    idx = None
                                    try_get = getattr(hb, "try_get_track_idx", None)
                                    if callable(try_get):
                                        idx = try_get(tid)
                                    if idx is None:
                                        idx = hb.get_track_idx(tid)
                                    if idx is not None:
                                        meter = hcb.get_track_meter(int(idx))
                                        meter.update_from_block(b2, float(gl), float(gr))
                            except Exception:
                                pass

                            # Apply gains without allocations (reuse scratch buffer)
                            try:
                                tmp = scratch_buf[:frames, :2]
                                np.multiply(b2, (float(gl), float(gr)), out=tmp, casting="unsafe")
                                outdata[:frames, :2] += tmp
                            except Exception:
                                outdata[:frames, :2] += b2 * np.array([gl, gr], dtype=np.float32)
                        else:
                            outdata[:frames, :2] += b2
                    except Exception:
                        pass

                # Master volume/pan (smoothed via RTParamStore)
                try:
                    if rt is not None:
                        master_vol = rt.get_smooth("master:vol", 0.8)
                        master_pan = rt.get_smooth("master:pan", 0.0)
                    else:
                        master_vol = float(getattr(audio_engine_ref, "_master_volume", 1.0))
                        master_pan = float(getattr(audio_engine_ref, "_master_pan", 0.0))

                    if master_vol != 1.0:
                        outdata[:frames, :2] *= master_vol

                    if abs(master_pan) > 0.01:
                        a = (master_pan + 1.0) * 0.25 * math.pi
                        gl, gr = math.cos(a), math.sin(a)
                        outdata[:frames, 0] *= gl
                        outdata[:frames, 1] *= gr
                except Exception:
                    pass

            # soft clip
            try:
                np.clip(outdata, -1.0, 1.0, out=outdata)
            except Exception:
                pass

            # Metering (Preview/Live Mode): push master block into hybrid meter ring
            # so the Mixer VU moves even when we are not in arrangement mode.
            try:
                hb = getattr(audio_engine_ref, "_hybrid_bridge", None)
                if hb is not None:
                    hb.meter_ring.write(outdata[:frames, :2])
            except Exception:
                pass

            # Advance playhead (only while transport is playing) + honor transport loop (audio-clock)
            try:
                if self._transport_service is not None and bool(getattr(self._transport_service, "playing", False)):
                    silence_playhead += int(frames)

                    # Audio-clock Looping (Transport loops only when no external clock is active)
                    try:
                        loop_enabled = bool(getattr(self._transport_service, "loop_enabled", False))
                        if loop_enabled:
                            bpm = float(getattr(self._transport_service, "bpm", 120.0) or 120.0)
                            ls_beat = float(getattr(self._transport_service, "loop_start", 0.0) or 0.0)
                            le_beat = float(getattr(self._transport_service, "loop_end", 0.0) or 0.0)
                            if le_beat > ls_beat + 1e-6:
                                bps = bpm / 60.0
                                if bps > 1e-9:
                                    sppb = float(sr) / bps
                                    ls = int(ls_beat * sppb)
                                    le = int(le_beat * sppb)
                                    if le > ls and silence_playhead >= le:
                                        silence_playhead = ls + (silence_playhead - le)
                    except Exception:
                        pass
            except Exception:
                pass


        with sd.OutputStream(
            samplerate=sr,
            blocksize=bs,
            device=out_dev,
            channels=2,
            dtype="float32",
            callback=callback,
        ):
            while not self._stop_flag:
                self.msleep(20)

    @dataclass
    class _PreparedAudioClip:
        start_sample: int
        end_sample: int
        offset_sample: int
        data: "np.ndarray"  # shape (n, 2)
        gain_l: float  # Fallback only (v0.0.20.34)
        gain_r: float  # Fallback only (v0.0.20.34)
        track_id: str  # NEW v0.0.20.34: For atomic dict lookup

    def _run_sounddevice_arrangement(self) -> None:
        """Arrangement playback via sounddevice.

        v0.0.20.14: Prefers HybridAudioCallback (zero-lock, zero-alloc)
        when available, falls back to legacy per-clip mixer.
        """
        if np is None:
            raise RuntimeError("numpy nicht verfügbar. Bitte requirements installieren.")

        try:
            import sounddevice as sd
            import soundfile as sf
        except Exception as exc:
            raise RuntimeError("sounddevice/soundfile nicht verfügbar. Bitte requirements installieren.") from exc

        sr = int(self._config.get("sample_rate") or 48000)
        bs = int(self._config.get("buffer_size") or 256)
        out_dev = self._config.get("output_device")
        out_dev = int(out_dev) if out_dev not in (None, "", "None") else None

        project = self._config.get("project_snapshot")
        start_beat = float(self._config.get("start_beat") or 0.0)

        bpm = float(getattr(project, "bpm", getattr(project, "tempo_bpm", 120.0)) or 120.0)

        # v0.0.20.14: Hybrid callback path (preferred)
        hybrid_bridge = self._config.get("hybrid_bridge")
        if hybrid_bridge is not None:
            try:
                loop_enabled = bool(self._config.get("loop_enabled", False))
                loop_start_beat = float(self._config.get("loop_start_beat", 0.0))
                loop_end_beat = float(self._config.get("loop_end_beat", 0.0))
                arranger_cache = self._config.get("arranger_cache_ref")

                # v0.0.20.25: Ensure deterministic track index mapping (project order)
                try:
                    if hasattr(hybrid_bridge, "set_track_index_map"):
                        mapping = {t.id: int(i) for i, t in enumerate(getattr(project, "tracks", []) or [])}
                        hybrid_bridge.set_track_index_map(mapping)
                except Exception:
                    pass

                prepared, _bpm = prepare_clips(project, sr, cache=arranger_cache)
                arr_state = ArrangementState(
                    prepared=prepared, sr=sr,
                    start_beat=float(start_beat), bpm=float(_bpm),
                    loop_enabled=loop_enabled,
                    loop_start_beat=loop_start_beat,
                    loop_end_beat=loop_end_beat,
                )
                hybrid_cb = hybrid_bridge.callback
                hybrid_cb.set_arrangement_state(arr_state)
                hybrid_cb.set_transport_ref(self._config.get("transport_service"))
                hybrid_bridge.set_sample_rate(sr)

                # v0.0.20.41: Wire direct peak storage for reliable VU metering
                ae_ref = self._config.get("audio_engine_ref")
                if ae_ref is not None and hasattr(ae_ref, "_direct_peaks"):
                    hybrid_cb._direct_peaks_ref = ae_ref._direct_peaks

                self.started_ok.emit(f"Hybrid Engine (sounddevice, SR={sr}, Buffer={bs}, lock-free)")

                with sd.OutputStream(
                    samplerate=sr, blocksize=bs, device=out_dev,
                    channels=2, dtype="float32", callback=hybrid_cb,
                ):
                    while not self._stop_flag:
                        self.msleep(20)

                # Clear arrangement state on stop
                hybrid_cb.set_arrangement_state(None)
                return
            except Exception as e:
                # Fallback to legacy path
                try:
                    self.status.emit(f"Hybrid Engine fehlgeschlagen ({e}), Legacy-Modus…")
                except Exception:
                    pass

        # --- Legacy arrangement path (pre-v0.0.20.14) ---
        beats_per_second = bpm / 60.0
        samples_per_beat = sr / beats_per_second

        def beats_to_samples(beats: float) -> int:
            return int(round(beats * samples_per_beat))

        # Prepare track map
        tracks_by_id = {t.id: t for t in getattr(project, "tracks", [])}
        solos = [t for t in tracks_by_id.values() if getattr(t, "solo", False)]
        solo_ids = {t.id for t in solos}
        use_solo = len(solo_ids) > 0
        
        # FIXED v0.0.19.7.14: Reference to self for LIVE master volume! ✅
        engine_self = self  # Closure reference for callback
        audio_engine_ref = self._config.get("audio_engine_ref")
        arranger_cache = self._config.get("arranger_cache_ref")
        if arranger_cache is None:
            try:
                from pydaw.audio.arranger_cache import DEFAULT_ARRANGER_CACHE

                arranger_cache = DEFAULT_ARRANGER_CACHE
            except Exception:
                arranger_cache = None
        last_gen = -1
        pull_sources = []

        # Use a small LRU-style cache across play runs (per engine thread).
        # This dramatically reduces stutter when toggling Play/Stop quickly.
        def _cache_get(path: str, target_sr: int):
            """Decode/resample cache lookup.

            Prefer global ArrangerRenderCache if available, fallback to per-thread LRU.
            """
            if arranger_cache is not None:
                try:
                    v = arranger_cache.get_decoded(str(path), int(target_sr))
                    if v is not None:
                        return v
                except Exception:
                    pass
            key = (path, int(target_sr))
            try:
                v = self._wav_cache.get(key)
            except Exception:
                return None
            if v is None:
                return None
            try:
                # mark as recently used
                self._wav_cache.move_to_end(key)
            except Exception:
                pass
            return v

        def _cache_put(path: str, target_sr: int, arr):
            # Global cache stores itself inside get_decoded(). For fallback per-thread LRU we keep put().
            if arranger_cache is not None:
                return
            key = (path, int(target_sr))
            try:
                self._wav_cache[key] = arr
                self._wav_cache.move_to_end(key)
                while len(self._wav_cache) > int(self._wav_cache_max):
                    self._wav_cache.popitem(last=False)
            except Exception:
                pass
        prepared: List[_EngineThread._PreparedAudioClip] = []

        def _pan_gains(vol: float, pan: float) -> Tuple[float, float]:
            # equal-power pan
            pan = max(-1.0, min(1.0, float(pan)))
            angle = (pan + 1.0) * (math.pi / 4.0)
            return float(vol) * math.cos(angle), float(vol) * math.sin(angle)

        for clip in getattr(project, "clips", []) or []:
            kind = str(getattr(clip, "kind", "") or "")
            track = tracks_by_id.get(getattr(clip, "track_id", ""))
            if not track:
                continue

            muted = bool(getattr(track, "muted", getattr(track, "mute", False)))
            if muted:
                continue
            if use_solo and track.id not in solo_ids:
                continue

            path = None
            file_sr = None
            data = None
            cache_path = None  # str path used for waveform cache

            if kind == "audio":
                path = getattr(clip, "source_path", None)
                if not path:
                    continue
                cache_path = str(path)
                cached = _cache_get(cache_path, sr)
                if cached is not None:
                    data = cached
                    file_sr = int(sr)
                else:
                    try:
                        data, file_sr = sf.read(path, dtype="float32", always_2d=True)
                    except Exception:
                        # Unsupported/failed read -> skip
                        continue

            elif kind == "midi":
                # Phase 4: Render MIDI clip -> WAV using track SoundFont (SF2)
                sf2_path = getattr(track, "sf2_path", None)
                if not sf2_path:
                    continue
                midi_notes_map = getattr(project, "midi_notes", {}) or {}
                notes_raw = list(midi_notes_map.get(getattr(clip, "id", ""), []) or [])
                # Apply notation tie markers for playback (non-destructive).
                try:
                    from .arrangement_renderer import _apply_ties_to_notes
                    notes = list(_apply_ties_to_notes(project, str(getattr(clip, "id", "")), notes_raw) or [])
                except Exception:
                    notes = list(notes_raw or [])
                clip_len_beats = float(getattr(clip, "length_beats", 4.0) or 4.0)
                # Extend render length to the furthest note end (prevents "only bar 1" playback).
                try:
                    if notes:
                        note_end = max(float(getattr(n, "start_beats", 0.0)) + float(getattr(n, "length_beats", 0.0)) for n in notes)
                        clip_len_beats = max(clip_len_beats, float(note_end))
                except Exception:
                    pass

                content_hash = _midi_notes_content_hash(notes)
                key = RenderKey(
                    clip_id=str(getattr(clip, "id", "")),
                    sf2_path=str(sf2_path),
                    sf2_bank=int(getattr(track, "sf2_bank", 0)),
                    sf2_preset=int(getattr(track, "sf2_preset", 0)),
                    bpm=float(bpm),
                    samplerate=int(sr),
                    clip_length_beats=float(clip_len_beats),
                    content_hash=str(content_hash),
                )
                wav_path = ensure_rendered_wav(
                    key=key,
                    midi_notes=notes,
                    clip_start_beats=float(getattr(clip, "start_beats", 0.0)),
                    clip_length_beats=float(clip_len_beats),
                )
                if not wav_path:
                    continue
                cache_path = wav_path.as_posix()
                cached = _cache_get(cache_path, sr)
                if cached is not None:
                    data = cached
                    file_sr = int(sr)
                else:
                    try:
                        data, file_sr = sf.read(wav_path.as_posix(), dtype="float32", always_2d=True)
                    except Exception:
                        continue
            else:
                continue

            # Normalize channels to stereo
            if data.shape[1] == 1:
                data = np.repeat(data, 2, axis=1)
            elif data.shape[1] >= 2:
                data = data[:, :2]

            # Resample (linear) if needed
            if int(file_sr) != int(sr) and data.shape[0] > 1:
                ratio = float(sr) / float(file_sr)
                n_out = max(1, int(round(data.shape[0] * ratio)))
                x_old = np.linspace(0.0, 1.0, num=data.shape[0], endpoint=False)
                x_new = np.linspace(0.0, 1.0, num=n_out, endpoint=False)
                data = np.vstack([
                    np.interp(x_new, x_old, data[:, 0]),
                    np.interp(x_new, x_old, data[:, 1]),
                ]).T.astype(np.float32, copy=False)

            # Cache base waveform (stereo float32 at target sample rate) BEFORE any tempo-stretch.
            if cache_path and data is not None:
                _cache_put(cache_path, sr, data)
            # Optional tempo sync (pitch-preserving time-stretch):
            # If the clip has a known `source_bpm`, we time-stretch to match the project BPM
            # WITHOUT changing pitch. Additionally apply per-clip time factor `clip.stretch`.
            source_bpm = float(getattr(clip, "source_bpm", 0.0) or 0.0)
            user_stretch = float(getattr(clip, "stretch", 1.0) or 1.0)

            tempo_ratio = (bpm / source_bpm) if (source_bpm > 0.0) else 1.0
            # Effective play-rate: >1 faster/shorter, <1 slower/longer
            # `clip.stretch` is a length-multiplier (2.0 => twice as long), so it divides the play-rate.
            effective_rate = float(tempo_ratio) / max(1e-6, float(user_stretch))

            if 0.25 <= effective_rate <= 4.0 and abs(effective_rate - 1.0) > 1e-3 and data.shape[0] > 1:
                # Prefer shared ArrangerRenderCache (reuses stretched buffers across Play/Stop).
                if arranger_cache is not None and cache_path:
                    try:
                        stretched = arranger_cache.get_stretched(str(cache_path), int(sr), float(effective_rate))
                        if stretched is not None:
                            data = stretched
                        else:
                            # fallback to local compute
                            from .time_stretch import time_stretch_stereo
                            data = time_stretch_stereo(data, rate=effective_rate, sr=sr)
                    except Exception:
                        effective_rate = 1.0
                else:
                    try:
                        from .time_stretch import time_stretch_stereo
                        data = time_stretch_stereo(data, rate=effective_rate, sr=sr)
                    except Exception:
                        # Never crash playback because of a stretch failure.
                        effective_rate = 1.0

            offset_s = float(getattr(clip, "offset_seconds", 0.0) or 0.0)
            offset_sample = max(0, int(round((offset_s * sr) / max(1e-6, effective_rate))))

            start_sample = beats_to_samples(float(getattr(clip, "start_beats", 0.0) or 0.0))
            clip_len_beats = float(getattr(clip, "length_beats", 0.0) or 0.0)
            # If length is zero/invalid, play full file from offset
            if clip_len_beats <= 0:
                clip_len_samples = max(0, data.shape[0] - offset_sample)
            else:
                clip_len_samples = beats_to_samples(clip_len_beats)

            end_sample = start_sample + max(0, clip_len_samples)

            gain_l, gain_r = _pan_gains(float(getattr(track, "volume", 1.0) or 1.0), float(getattr(track, "pan", 0.0) or 0.0))

            prepared.append(
                self._PreparedAudioClip(
                    start_sample=start_sample,
                    end_sample=end_sample,
                    offset_sample=offset_sample,
                    data=data,
                    gain_l=gain_l,  # Fallback only
                    gain_r=gain_r,  # Fallback only
                    track_id=str(track.id),  # NEW v0.0.20.34: For atomic dict lookup
                )
            )

        prepared.sort(key=lambda c: c.start_sample)

        self.started_ok.emit(f"sounddevice gestartet (ARRANGEMENT, SR={sr}, Buffer={bs})")

        playhead = beats_to_samples(start_beat)

        # Loop region from Transport (beats -> samples)
        loop_enabled = bool(self._config.get("loop_enabled", False))
        loop_start_samp = beats_to_samples(float(self._config.get("loop_start_beat", 0.0) or 0.0))
        loop_end_samp = beats_to_samples(float(self._config.get("loop_end_beat", 0.0) or 0.0))

        # Guardrails: disable invalid loop settings
        if loop_enabled:
            if loop_end_samp <= loop_start_samp:
                loop_enabled = False
            # If playhead starts outside the loop, snap to loop start
            elif playhead < loop_start_samp or playhead >= loop_end_samp:
                playhead = loop_start_samp

        def callback(outdata, frames, _time, status):  # noqa: ANN001
            nonlocal playhead, last_gen, pull_sources
            if status:
                pass
            out = np.zeros((frames, 2), dtype=np.float32)
            start = playhead
            end = playhead + frames

            # Provide the *start* playhead to Transport before pull-sources run,
            # so ClipLauncher can sync sample-accurately (no 1-buffer latency).
            try:
                if self._transport_service is not None:
                    self._transport_service._set_external_playhead_samples(int(start), float(sr))
            except Exception:
                pass

            for c in prepared:
                if c.end_sample <= start:
                    continue
                if c.start_sample >= end:
                    break
                # overlap
                o_start = max(start, c.start_sample)
                o_end = min(end, c.end_sample)
                n = o_end - o_start
                if n <= 0:
                    continue
                out_off = o_start - start
                rel = o_start - c.start_sample
                src_start = c.offset_sample + rel
                src_end = src_start + n
                if src_start >= c.data.shape[0]:
                    continue
                if src_end > c.data.shape[0]:
                    src_end = c.data.shape[0]
                    n = src_end - src_start
                if n <= 0:
                    continue
                chunk = c.data[src_start:src_end]
                
                # NEW v0.0.20.37: Get LIVE gains (EXACTLY like Master!)
                track_id = getattr(c, "track_id", None)
                if track_id and audio_engine_ref:
                    # Direct dict lookup with defaults (LIKE MASTER: _master_volume fallback!)
                    vol = audio_engine_ref._track_volumes.get(track_id, 1.0)  # Default: 1.0 like baked-in
                    pan = audio_engine_ref._track_pans.get(track_id, 0.0)  # Default: 0.0 (center)
                    gain_l, gain_r = _pan_gains(vol, pan)
                else:
                    # Ultimate fallback: use baked-in gains
                    gain_l, gain_r = c.gain_l, c.gain_r
                
                out[out_off:out_off + n, 0] += chunk[:, 0] * gain_l
                out[out_off:out_off + n, 1] += chunk[:, 1] * gain_r

                # v0.0.20.41: Write per-track peak directly to AudioEngine (most reliable path)
                try:
                    if audio_engine_ref is not None and track_id and n > 0:
                        pk_l = float(np.max(np.abs(chunk[:n, 0]))) * abs(gain_l)
                        pk_r = float(np.max(np.abs(chunk[:n, min(1, chunk.shape[1]-1)]))) * abs(gain_r)
                        dp = audio_engine_ref._direct_peaks
                        old = dp.get(track_id, (0.0, 0.0))
                        dp[track_id] = (max(old[0], pk_l), max(old[1], pk_r))
                except Exception:
                    pass

                # v0.0.20.40: Per-track metering in arrangement callback
                # Update TrackMeterRing so VU meters move for each track during playback
                try:
                    hb = getattr(audio_engine_ref, "_hybrid_bridge", None) if audio_engine_ref else None
                    if hb is not None and track_id:
                        hcb = getattr(hb, "callback", None)
                        if hcb is not None:
                            idx = None
                            try_get = getattr(hb, "try_get_track_idx", None)
                            if callable(try_get):
                                idx = try_get(track_id)
                            if idx is None:
                                idx = hb.get_track_idx(track_id)
                            if idx is not None:
                                meter = hcb.get_track_meter(int(idx))
                                meter.update_from_block(chunk[:n], float(gain_l), float(gain_r))
                except Exception:
                    pass

            # Add pull sources (Sampler preview, synths, etc.)
            if audio_engine_ref is not None:
                # Advance RT param smoothing
                rt = getattr(audio_engine_ref, "rt_params", None)
                if rt is not None:
                    try:
                        rt.advance(int(frames), int(sr))
                    except Exception:
                        pass

                try:
                    gen, srcs = audio_engine_ref._pull_sources_snapshot(last_gen)
                    if gen != last_gen:
                        last_gen = gen
                        pull_sources = srcs
                except Exception:
                    pass
                for fn in (pull_sources or []):
                    try:
                        b = fn(int(frames), int(sr))
                        if b is not None:
                            out[:frames, :2] += b[:frames, :2]
                    except Exception:
                        pass

            # Apply MASTER Volume/Pan (smoothed via RTParamStore)
            try:
                rt = getattr(audio_engine_ref, "rt_params", None) if audio_engine_ref else None
                if rt is not None:
                    master_vol = rt.get_smooth("master:vol", 0.8)
                    master_pan = rt.get_smooth("master:pan", 0.0)
                elif audio_engine_ref is not None:
                    master_vol = float(getattr(audio_engine_ref, "_master_volume", 1.0))
                    master_pan = float(getattr(audio_engine_ref, "_master_pan", 0.0))
                else:
                    master_vol = float(getattr(engine_self, "_master_volume", 1.0))
                    master_pan = float(getattr(engine_self, "_master_pan", 0.0))
                
                out *= master_vol
                
                if abs(master_pan) > 0.01:
                    # IMPORTANT (RT-safe):
                    # Never import inside the real-time audio callback.
                    # Import statements bind names locally and can cause
                    # UnboundLocalError for outer-scope closures (as seen
                    # with `_pan_gains`), plus they add avoidable overhead.
                    # We already have a closure-scope `_pan_gains()` above.
                    gain_l, gain_r = _pan_gains(1.0, master_pan)
                    out[:, 0] *= gain_l
                    out[:, 1] *= gain_r
            except Exception:
                pass  # Silent - realtime critical!
            
            # soft clamp
            np.clip(out, -1.0, 1.0, out=out)
            outdata[:frames, :2] = out.astype(outdata.dtype, copy=False)
            if outdata.shape[1] > 2:
                outdata[:, 2:] = 0

            # v0.0.20.41: Write master peak directly to AudioEngine
            try:
                if audio_engine_ref is not None and frames > 0:
                    mk_l = float(np.max(np.abs(out[:frames, 0])))
                    mk_r = float(np.max(np.abs(out[:frames, 1])))
                    old_m = audio_engine_ref._direct_peaks.get("__master__", (0.0, 0.0))
                    audio_engine_ref._direct_peaks["__master__"] = (max(old_m[0], mk_l), max(old_m[1], mk_r))
            except Exception:
                pass

            # Metering (Arrangement Mode): push the master block into the hybrid meter ring
            # so the Mixer VU can move continuously while looping/playing.
            try:
                hb = getattr(audio_engine_ref, "_hybrid_bridge", None) if audio_engine_ref else None
                if hb is not None:
                    hb.meter_ring.write(out[:frames, :2])
            except Exception:
                pass
            # advance playhead, handle looping with overflow preservation
            next_playhead = playhead + frames
            if loop_enabled and next_playhead >= loop_end_samp:
                overflow = next_playhead - loop_end_samp
                span = max(1, loop_end_samp - loop_start_samp)
                # Wrap overflow inside the loop span
                overflow = overflow % span
                playhead = loop_start_samp + overflow
            else:
                playhead = next_playhead

            # Sample-accurate Sync: Transport bekommt Playhead in Samples.
            try:
                if self._transport_service is not None:
                    self._transport_service._set_external_playhead_samples(int(playhead), float(sr))
            except Exception:
                # Keine harten Fehler im Audio-Callback.
                pass

        with sd.OutputStream(
            samplerate=sr,
            blocksize=bs,
            device=out_dev,
            channels=2,
            dtype="float32",
            callback=callback,
        ):
            while not self._stop_flag:
                self.msleep(20)


class AudioEngine(QObject):
    """High-level audio engine service."""

    backend_changed = pyqtSignal(str)
    status = pyqtSignal(str)
    error = pyqtSignal(str)
    running_changed = pyqtSignal(bool)

    def __init__(self):
        super().__init__()
        self._backend: Backend = "none"
        self._engine_thread: Optional[_EngineThread] = None

        # Optional Binding: Project + Transport, um beim Abspielen echte
        # Audio-Clips aus dem Arranger auszugeben.
        self._bound_project_service: Any = None
        self._bound_transport_service: Any = None

        # Optional: JACK client service for realtime routing/playback
        self._bound_jack_service: Any = None
        self._jack_state: Any = None
        self._jack_prepare_thread = None
        
        # DSP engine (JACK mixing + master gain/pan)
        self._dsp_engine = None  # lazy

        # RT Parameter Store — smoothed, lock-free audio parameters
        from .rt_params import RTParamStore
        self.rt_params = RTParamStore(default_smooth_ms=5.0)
        self.rt_params.ensure("master:vol", 0.8)
        self.rt_params.ensure("master:pan", 0.0)

        # FIXED v0.0.19.7.14: Master Volume/Pan als LIVE Variable! ✅
        # Thread-Safe: Float read/write ist atomar in Python
        self._master_volume = 1.0  # 0.0 - 1.0
        self._master_pan = 0.0     # -1.0 - 1.0

        # NEW v0.0.20.33: Per-Track atomic storage (SAFE - not used by callback yet!)
        self._track_volumes = {}  # {track_id: float 0.0-1.0}
        self._track_pans = {}     # {track_id: float -1.0-1.0}
        self._track_mutes = {}    # {track_id: bool}
        self._track_solos = {}    # {track_id: bool}

        # v0.0.20.41: Direct peak storage — written from audio callback, read by mixer.
        # This bypasses the complex HybridBridge chain and provides reliable metering.
        # Keys: track_id (str) or "__master__". Values: (peak_l, peak_r) linear.
        self._direct_peaks: dict = {}  # {track_id_or_master: (float, float)}
        self._direct_peaks_decay = 0.92  # per GUI-read decay

        # Shared arrangement render cache (decoded/resampled + tempo-stretched).
        # Used by both JACK prepare thread and sounddevice arrangement thread.
        try:
            from .arranger_cache import DEFAULT_ARRANGER_CACHE

            self._arranger_cache = DEFAULT_ARRANGER_CACHE
        except Exception:
            self._arranger_cache = None

        # v0.0.20.13: Hybrid Engine Bridge (lock-free ring-buffer communication)
        self._hybrid_bridge: Any = None
        if _HYBRID_AVAILABLE:
            try:
                self._hybrid_bridge = get_hybrid_bridge(rt_params=self.rt_params)
                self._hybrid_bridge.set_transport_ref(None)  # set later via bind_transport
            except Exception:
                self._hybrid_bridge = None

        # v0.0.20.13: Async Sample Loader
        self._async_loader = None
        if _HYBRID_AVAILABLE:
            try:
                self._async_loader = get_async_loader()
            except Exception:
                self._async_loader = None

        # v0.0.20.14: Essentia Worker Pool for time-stretch jobs
        self._essentia_pool = None
        if _ESSENTIA_POOL_AVAILABLE:
            try:
                self._essentia_pool = get_essentia_pool(
                    num_workers=4, cache_ref=self._arranger_cache)
            except Exception:
                self._essentia_pool = None


        # Pull sources (Sampler preview, synths, etc.)
        # Thread-safe: we replace the cached list object on updates.
        self._pull_sources_lock = threading.RLock()
        self._pull_sources_dict: Dict[str, Any] = {}
        self._pull_sources_list: List[Any] = []
        self._pull_sources_gen: int = 0
        self._backend = self.detect_best_backend().backend
        self.backend_changed.emit(self._backend)

    # --- detection

    def detect_best_backend(self) -> AudioBackendInfo:
        """Prefer JACK (PipeWire-JACK), otherwise sounddevice."""
        jack_info = self._probe_jack()
        if jack_info.available:
            return jack_info

        sd_info = self._probe_sounddevice()
        if sd_info.available:
            return sd_info

        return AudioBackendInfo(backend="none", available=False, details="Kein Backend gefunden")

    def _probe_jack(self) -> AudioBackendInfo:
        pw_cli = shutil.which("pw-cli")
        qpwgraph = shutil.which("qpwgraph")
        pipewire_hint = []
        if pw_cli:
            pipewire_hint.append("pw-cli gefunden")
        if qpwgraph:
            pipewire_hint.append("qpwgraph gefunden")

        try:
            import jack  # type: ignore
        except Exception:
            details = "python-jack-client nicht installiert. "
            if pipewire_hint:
                details += f"PipeWire-Hinweis: {', '.join(pipewire_hint)}"
            else:
                details += "(PipeWire/JACK Status unbekannt)"
            return AudioBackendInfo(backend="jack", available=False, details=details)

        try:
            # Attempt to connect to JACK server (PipeWire-JACK or jackd)
            with _suppress_stderr_fd():
                c = jack.Client("pydaw_probe", no_start_server=True)  # type: ignore
            c.deactivate()
            c.close()
            details = "JACK Server erreichbar (evtl. PipeWire-JACK)."
            if pipewire_hint:
                details += f" {', '.join(pipewire_hint)}"
            return AudioBackendInfo(backend="jack", available=True, details=details)
        except Exception as exc:
            details = f"JACK Client vorhanden, aber Server nicht erreichbar: {exc}"
            if pipewire_hint:
                details += f" | {', '.join(pipewire_hint)}"
            return AudioBackendInfo(backend="jack", available=False, details=details)

    def _probe_sounddevice(self) -> AudioBackendInfo:
        try:
            import sounddevice as sd  # type: ignore
            with _suppress_stderr_fd():
                _ = sd.query_devices()
            return AudioBackendInfo(
                backend="sounddevice",
                available=True,
                details="sounddevice (PortAudio) verfügbar.",
            )
        except Exception as exc:
            return AudioBackendInfo(
                backend="sounddevice",
                available=False,
                details=f"sounddevice nicht verfügbar: {exc}",
            )

    # --- enumeration

    def list_inputs(self, backend: Optional[Backend] = None) -> List[AudioEndpoint]:
        b = backend or self._backend
        if b == "jack":
            return self._jack_list_capture_sources()
        if b == "sounddevice":
            return self._sd_list_inputs()
        return []

    def list_outputs(self, backend: Optional[Backend] = None) -> List[AudioEndpoint]:
        b = backend or self._backend
        if b == "jack":
            return self._jack_list_playback_sinks()
        if b == "sounddevice":
            return self._sd_list_outputs()
        return []

    def _sd_list_inputs(self) -> List[AudioEndpoint]:
        try:
            import sounddevice as sd  # type: ignore
            devs = sd.query_devices()
        except Exception:
            return []
        out: List[AudioEndpoint] = []
        for idx, d in enumerate(devs):
            if int(d.get("max_input_channels", 0)) > 0:
                out.append(AudioEndpoint(id=str(idx), label=f"[{idx}] {d.get('name')}"))  # type: ignore
        return out

    def _sd_list_outputs(self) -> List[AudioEndpoint]:
        try:
            import sounddevice as sd  # type: ignore
            devs = sd.query_devices()
        except Exception:
            return []
        out: List[AudioEndpoint] = []
        for idx, d in enumerate(devs):
            if int(d.get("max_output_channels", 0)) > 0:
                out.append(AudioEndpoint(id=str(idx), label=f"[{idx}] {d.get('name')}"))  # type: ignore
        return out

    def _jack_list_capture_sources(self) -> List[AudioEndpoint]:
        try:
            import jack  # type: ignore
            # libjack prints directly to stderr when no server is reachable.
            # We suppress that here to avoid terminal spam from mere enumeration.
            with _suppress_stderr_fd():
                c = jack.Client("pydaw_enum", no_start_server=True)  # type: ignore
            ports = list(c.get_ports(is_output=True))
            # PipeWire-JACK may not mark ports as physical; prefer system:capture* when present.
            sys_ports = [p for p in ports if p.name.startswith('system:')]
            if sys_ports:
                ports = [p for p in sys_ports if ('capture' in p.name.lower()) or ('input' in p.name.lower()) or p.name.startswith('system:')]
            else:
                ports = [p for p in ports if ('capture' in p.name.lower()) or ('input' in p.name.lower())]
            if not ports:
                ports = list(c.get_ports(is_output=True))
            out = [AudioEndpoint(id=p.name, label=p.name) for p in ports]
            c.close()
            return out
        except Exception:
            return []

    def _jack_list_playback_sinks(self) -> List[AudioEndpoint]:
        try:
            import jack  # type: ignore
            with _suppress_stderr_fd():
                c = jack.Client("pydaw_enum", no_start_server=True)  # type: ignore
            ports = list(c.get_ports(is_input=True))
            sys_ports = [p for p in ports if p.name.startswith('system:')]
            if sys_ports:
                ports = [p for p in sys_ports if ('playback' in p.name.lower()) or ('output' in p.name.lower()) or p.name.startswith('system:')]
            else:
                ports = [p for p in ports if ('playback' in p.name.lower()) or ('output' in p.name.lower())]
            if not ports:
                ports = list(c.get_ports(is_input=True))
            out = [AudioEndpoint(id=p.name, label=p.name) for p in ports]
            c.close()
            return out
        except Exception:
            return []

    # --- lifecycle (non-blocking skeleton)

    def start(self, backend: Optional[Backend] = None, config: Optional[Dict[str, Any]] = None) -> None:
        if self._engine_thread and self._engine_thread.isRunning():
            self.status.emit("Audio läuft bereits.")
            return

        b = backend or self._backend
        cfg = dict(config or {})
        cfg.setdefault("audio_engine_ref", self)

        self._engine_thread = _EngineThread(b, cfg)
        self._engine_thread.started_ok.connect(self.status.emit)
        self._engine_thread.error.connect(self.error.emit)
        self._engine_thread.stopped_ok.connect(lambda: self.status.emit("Audio gestoppt."))
        self._engine_thread.start()

    def stop(self) -> None:
        """Stoppt jede aktive Wiedergabe (sounddevice *und* JACK).

        Wichtig: JACK-Playback nutzt aktuell keinen _EngineThread (es läuft über
        einen Render-Callback im JackClientService). In diesem Modus MUSS stop()
        trotzdem den Callback entfernen – sonst läuft Audio trotz Transport-Stop
        weiter.
        """

        # 1) sounddevice / thread-based engine
        try:
            if self._engine_thread is not None:
                self._engine_thread.request_stop()
                self._engine_thread.wait(1500)
        finally:
            self._engine_thread = None

        # 2) JACK: Render callback entfernen + State zurücksetzen
        # Clear DSP arrangement source (if present)
        try:
            if self._dsp_engine is not None:
                self._dsp_engine.set_arrangement_state(None)
        except Exception:
            pass
        try:
            if self._bound_jack_service is not None:
                self._bound_jack_service.clear_render_callback()
        except Exception:
            pass
        try:
            self._jack_state = None
        except Exception:
            pass

        # 3) Transport-Clock (Audio-Engine) wieder freigeben
        try:
            if self._bound_transport_service is not None:
                # beide Namen existieren je nach Version
                if hasattr(self._bound_transport_service, "_clear_external_playhead"):
                    self._bound_transport_service._clear_external_playhead()
                elif hasattr(self._bound_transport_service, "_clear_external_clock"):
                    self._bound_transport_service._clear_external_clock()
        except Exception:
            pass

    def bind_transport(self, project_service: Any, transport_service: Any) -> None:
        """Bindet ProjectService + TransportService, sodass Transport-Play
        automatisch Audio-Clips aus dem Arranger ausgibt.

        Diese Bindung ist optional; ohne Bindung bleibt der Engine-Output bei
        "Silence" (nur Status/Backendverwaltung).
        """
        self._bound_project_service = project_service
        self._bound_transport_service = transport_service

        # v0.0.20.13: Wire transport to hybrid bridge
        try:
            if self._hybrid_bridge is not None:
                self._hybrid_bridge.set_transport_ref(transport_service)
                # v0.0.20.28: ensure stable track-id→index mapping for Live/Preview per-track faders
                try:
                    proj = getattr(project_service, "ctx", None).project if hasattr(project_service, "ctx") else None
                    tracks = getattr(proj, "tracks", []) if proj is not None else []
                    mapping = {str(getattr(t, "id", "")): int(i) for i, t in enumerate(tracks) if str(getattr(t, "id", ""))}
                    if mapping:
                        self._hybrid_bridge.set_track_index_map(mapping)
                except Exception:
                    pass
        except Exception:
            pass

        # Transport->Audio: Beim Starten Wiedergabe anwerfen, beim Stoppen schließen
        try:
            transport_service.playing_changed.connect(self._on_transport_playing_changed)
            transport_service.loop_changed.connect(self._on_transport_params_changed)
            transport_service.bpm_changed.connect(self._on_transport_params_changed)
            transport_service.time_signature_changed.connect(self._on_transport_params_changed)
        except Exception:
            # Nicht hart fehlschlagen – UI kann trotzdem laufen.
            pass

    def bind_jack(self, jack_service: Any) -> None:
        """Bind JackClientService for JACK backend playback/recording."""
        self._bound_jack_service = jack_service


    def _ensure_dsp_engine(self):
        # Lazy-create DSPJackEngine and keep its bindings minimal (no GUI changes).
        try:
            if self._dsp_engine is None:
                from pydaw.audio.dsp_engine import DSPJackEngine
                self._dsp_engine = DSPJackEngine(rt_params=self.rt_params)
                # Bind master getter as legacy fallback
                self._dsp_engine.set_master_getter(lambda: (float(self._master_volume), float(self._master_pan)))
                # v0.0.20.28: Bind HybridEngineBridge for metering + per-track pull-source mixing
                try:
                    if self._hybrid_bridge is not None and hasattr(self._dsp_engine, "set_hybrid_bridge"):
                        self._dsp_engine.set_hybrid_bridge(self._hybrid_bridge)
                except Exception:
                    pass
                # Bind transport ref for external playhead updates (optional)
                if self._bound_transport_service is not None:
                    self._dsp_engine.set_transport_ref(self._bound_transport_service)
            else:
                # refresh transport ref if it became available later
                if self._bound_transport_service is not None:
                    try:
                        self._dsp_engine.set_transport_ref(self._bound_transport_service)
                    except Exception:
                        pass
                try:
                    if self._hybrid_bridge is not None and hasattr(self._dsp_engine, "set_hybrid_bridge"):
                        self._dsp_engine.set_hybrid_bridge(self._hybrid_bridge)
                except Exception:
                    pass
            return self._dsp_engine
        except Exception:
            return None
    
    def set_master_volume(self, volume: float) -> None:
        """Set master volume (0.0-1.0) in REALTIME with smoothing.
        
        Writes to: atomic float (legacy) + RTParamStore (smoothed) + HybridRing (lock-free).
        """
        v = max(0.0, min(1.0, float(volume)))
        self._master_volume = v
        try:
            self.rt_params.set_param("master:vol", v)
        except Exception:
            pass
        # v0.0.20.13: Push to hybrid ring buffer (lock-free, zero-latency)
        try:
            if self._hybrid_bridge is not None:
                self._hybrid_bridge.set_master_volume(v)
        except Exception:
            pass
    
    def set_master_pan(self, pan: float) -> None:
        """Set master pan (-1.0-1.0) in REALTIME with smoothing.
        
        Writes to: atomic float (legacy) + RTParamStore (smoothed) + HybridRing (lock-free).
        """
        p = max(-1.0, min(1.0, float(pan)))
        self._master_pan = p
        try:
            self.rt_params.set_param("master:pan", p)
        except Exception:
            pass
        # v0.0.20.13: Push to hybrid ring buffer (lock-free, zero-latency)
        try:
            if self._hybrid_bridge is not None:
                self._hybrid_bridge.set_master_pan(p)
        except Exception:
            pass

    # NEW v0.0.20.33: Per-Track setters (LIKE MASTER, but for tracks!)
    # NOTE: Callback in v0.0.20.33 does NOT use these yet (stays safe!)
    # Future versions will use these for live fader response.
    
    def set_track_volume(self, track_id: str, volume: float) -> None:
        """Set track volume - writes to atomic dict + RTParamStore + HybridBridge."""
        v = max(0.0, min(1.0, float(volume)))
        self._track_volumes[str(track_id)] = v
        try:
            self.rt_params.set_track_vol(str(track_id), v)
        except Exception:
            pass
        try:
            if self._hybrid_bridge is not None:
                self._hybrid_bridge.set_track_volume(str(track_id), v)
        except Exception:
            pass
    
    def set_track_pan(self, track_id: str, pan: float) -> None:
        """Set track pan - writes to atomic dict + RTParamStore + HybridBridge."""
        p = max(-1.0, min(1.0, float(pan)))
        self._track_pans[str(track_id)] = p
        try:
            self.rt_params.set_track_pan(str(track_id), p)
        except Exception:
            pass
        try:
            if self._hybrid_bridge is not None:
                self._hybrid_bridge.set_track_pan(str(track_id), p)
        except Exception:
            pass
    
    def set_track_mute(self, track_id: str, muted: bool) -> None:
        """Set track mute - writes to atomic dict + RTParamStore + HybridBridge."""
        m = bool(muted)
        self._track_mutes[str(track_id)] = m
        try:
            self.rt_params.set_track_mute(str(track_id), m)
        except Exception:
            pass
        try:
            if self._hybrid_bridge is not None:
                self._hybrid_bridge.set_track_mute(str(track_id), m)
        except Exception:
            pass
    
    def set_track_solo(self, track_id: str, solo: bool) -> None:
        """Set track solo - writes to atomic dict + RTParamStore + HybridBridge."""
        s = bool(solo)
        self._track_solos[str(track_id)] = s
        try:
            self.rt_params.set_track_solo(str(track_id), s)
        except Exception:
            pass
        try:
            if self._hybrid_bridge is not None:
                self._hybrid_bridge.set_track_solo(str(track_id), s)
        except Exception:
            pass


    def read_track_peak(self, track_id: str) -> Tuple[float, float]:
        """Read per-track peak levels (GUI thread, lock-free)."""
        # v0.0.20.41: Try direct peaks first
        dp = self._direct_peaks.get(str(track_id))
        if dp is not None:
            l, r = dp
            decay = self._direct_peaks_decay
            self._direct_peaks[str(track_id)] = (l * decay, r * decay)
            if l > 0.0001 or r > 0.0001:
                return (l, r)
        try:
            if self._hybrid_bridge is not None:
                return self._hybrid_bridge.read_track_peak(track_id)
        except Exception:
            pass
        return (0.0, 0.0)

    def _pull_sources_snapshot(self, last_gen: int) -> Tuple[int, List[Any]]:
        """Return (gen, sources). Safe for realtime callbacks.

        We do NOT mutate the list in-place; updates replace the list object.
        """
        try:
            with self._pull_sources_lock:
                gen = int(self._pull_sources_gen)
                lst = self._pull_sources_list
            return gen, lst
        except Exception:
            return last_gen, []

    
    def add_source(self, source, name: str | None = None) -> str | None:  # noqa: ANN001
        """Compatibility helper: register a sampler/device as audible source.

        Accepts:
        - a callable: fn(frames, sr) -> (frames,2) float32
        - an object with .pull(frames, sr)

        Returns the registered name (or None on failure).
        """
        try:
            fn = None
            if callable(source):
                fn = source
            else:
                fn = getattr(source, "pull", None)
            if fn is None:
                return None
            if name is None:
                name = f"src:{source.__class__.__name__}:{id(source) & 0xFFFF:04x}"
            self.register_pull_source(str(name), fn)
            try:
                self.ensure_preview_output()
            except Exception:
                pass
            return str(name)
        except Exception:
            return None

    def register_pull_source(self, name: str, fn) -> None:  # noqa: ANN001
        """Register a pull-based audio source: fn(frames, sr) -> np.ndarray (frames,2)."""
        try:
            with self._pull_sources_lock:
                self._pull_sources_dict[str(name)] = fn
                self._pull_sources_list = list(self._pull_sources_dict.values())
                self._pull_sources_gen += 1
        except Exception:
            pass
        # Forward to JACK DSP engine if present
        try:
            dsp = self._ensure_dsp_engine()
            if dsp is not None:
                dsp.register_pull_source(str(name), fn)
        except Exception:
            pass
        # v0.0.20.13: Sync to hybrid bridge (atomic list swap)
        try:
            if self._hybrid_bridge is not None:
                self._hybrid_bridge.set_pull_sources(self._pull_sources_list)
        except Exception:
            pass

    def unregister_pull_source(self, name: str) -> None:
        try:
            with self._pull_sources_lock:
                self._pull_sources_dict.pop(str(name), None)
                self._pull_sources_list = list(self._pull_sources_dict.values())
                self._pull_sources_gen += 1
        except Exception:
            pass
        try:
            if self._dsp_engine is not None:
                self._dsp_engine.unregister_pull_source(str(name))
        except Exception:
            pass
        # v0.0.20.13: Sync to hybrid bridge
        try:
            if self._hybrid_bridge is not None:
                self._hybrid_bridge.set_pull_sources(self._pull_sources_list)
        except Exception:
            pass

    def ensure_preview_output(self) -> None:
        """Ensure an output stream is running so pull sources are audible."""
        # If JACK is the selected backend, prefer that (PipeWire graph).
        # BUT: if no JACK server is reachable (common when not started via pw-jack),
        # we must fall back to sounddevice, otherwise the user hears nothing at all.
        try:
            if self._backend == "jack" and self._bound_jack_service is not None:
                jack_ok = True
                try:
                    probe = getattr(self._bound_jack_service, "probe_available", None)
                    if callable(probe):
                        jack_ok = bool(probe())
                except Exception:
                    jack_ok = True

                if jack_ok:
                    try:
                        self._bound_jack_service.start_async(client_name="PyDAW")
                    except Exception:
                        jack_ok = False

                if jack_ok:
                    # v0.0.20.14: Prefer HybridAudioCallback for JACK preview
                    try:
                        if _HYBRID_AVAILABLE and self._hybrid_bridge is not None:
                            hybrid_cb = self._hybrid_bridge.callback
                            hybrid_cb.set_arrangement_state(None)  # No arrangement, preview only
                            hybrid_cb.set_transport_ref(self._bound_transport_service)
                            self._bound_jack_service.set_render_callback(hybrid_cb.render_for_jack)
                            return
                    except Exception:
                        pass

                    # Legacy fallback
                    dsp = None
                    try:
                        dsp = self._ensure_dsp_engine()
                    except Exception:
                        dsp = None
                    if dsp is not None:
                        try:
                            dsp.set_arrangement_state(None)
                        except Exception:
                            pass
                        try:
                            self._bound_jack_service.set_render_callback(dsp.render_callback)
                        except Exception:
                            pass
                    return

                # Fall back to sounddevice if JACK isn't available
                try:
                    self.status.emit(
                        "JACK nicht erreichbar → Monitoring/Preview via sounddevice (Starte mit 'pw-jack python3 main.py' für qpwgraph-Ports)."
                    )
                except Exception:
                    pass
        except Exception:
            pass

        # sounddevice fallback
        try:
            if self._engine_thread is not None and self._engine_thread.isRunning():
                return
        except Exception:
            pass

        cfg: Dict[str, Any] = {
            "mode": "silence",
            "sample_rate": 48000,
            "buffer_size": 512,
            "audio_engine_ref": self,
        }
        try:
            self.start(backend="sounddevice", config=cfg)
        except Exception:
            # best-effort
            pass

    def _on_transport_params_changed(self, *args: Any, **kwargs: Any) -> None:
        """Wenn Transport-Parameter (Loop/BPM/TS) geändert werden, starte die
        Engine neu, damit die Audio-Config konsistent bleibt.

        Diese Strategie ist einfach und robust (Phase 4). Feingranulare
        Live-Updates der EngineConfig können später folgen.
        """
        try:
            if self._bound_transport_service is None:
                return
            if not bool(getattr(self._bound_transport_service, "is_playing", False)):
                return
        except Exception:
            return

        # Neustart: Stop -> Start mit aktuellem Beat
        try:
            self.stop()
        except Exception:
            pass
        try:
            self.start_arrangement_playback()
        except Exception as e:
            try:
                self.error.emit(str(e))
            except Exception:
                pass

    def _on_transport_playing_changed(self, playing: bool) -> None:
        if playing:
            self.start_arrangement_playback()
        else:
            self.stop()

    def start_arrangement_playback(self) -> None:
        """Startet Arrangement-Wiedergabe über das aktuell gewählte Backend.

        - JACK: Output erscheint als ein Client ("PyDAW") in qpwgraph; optional Monitoring bleibt additiv.
        - sounddevice: Fallback über PortAudio.
        """
        if not self._bound_project_service or not self._bound_transport_service:
            return

        # Snapshot erzeugen (thread-safe)
        try:
            project_snapshot = copy.deepcopy(self._bound_project_service.ctx.project)
        except Exception:
            project_snapshot = getattr(self._bound_project_service, "ctx", None).project if hasattr(self._bound_project_service, "ctx") else None

        start_beat = float(getattr(self._bound_transport_service, "current_beat", 0.0) or 0.0)
        loop_enabled = bool(getattr(self._bound_transport_service, "loop_enabled", False))
        loop_start_beat = float(getattr(self._bound_transport_service, "loop_start", 0.0) or 0.0)
        loop_end_beat = float(getattr(self._bound_transport_service, "loop_end", 0.0) or 0.0)

        # Prefer selected backend (set via Audio Settings dialog)
        backend = self._backend

        # JACK path
        if backend == "jack" and self._bound_jack_service is not None:
            # Ensure JACK client is running
            try:
                self._bound_jack_service.start_async(client_name="PyDAW")
            except Exception:
                pass

            # Prepare audio outside JACK process callback
            import threading

            def _prepare():
                try:
                    sr = int(getattr(self._bound_jack_service, "samplerate", 48000) or 48000)
                except Exception:
                    sr = 48000
                try:
                    self.status.emit("JACK: bereite Arrangement (Clips/MIDI-Renders) vor…")
                except Exception:
                    pass
                try:
                    prepared, bpm = prepare_clips(project_snapshot, sr, cache=self._arranger_cache)
                    self._jack_state = ArrangementState(
                        prepared=prepared,
                        sr=sr,
                        start_beat=float(start_beat),
                        bpm=float(bpm),
                        loop_enabled=bool(loop_enabled),
                        loop_start_beat=float(loop_start_beat),
                        loop_end_beat=float(loop_end_beat),
                    )
                except Exception as e:
                    self._jack_state = None
                    try:
                        self.error.emit(f"JACK: Arrange-Vorbereitung fehlgeschlagen: {e}")
                    except Exception:
                        pass
                    return

                # v0.0.20.14: Prefer HybridAudioCallback for JACK (lock-free)
                try:
                    if _HYBRID_AVAILABLE and self._hybrid_bridge is not None:
                        # v0.0.20.39: Ensure deterministic track-index mapping for JACK too (fixes live mixer faders)
                        try:
                            tracks = getattr(project_snapshot, 'tracks', None) or []
                            self._hybrid_bridge.set_track_index_map({getattr(t, 'id', str(i)): i for i, t in enumerate(tracks)})
                        except Exception:
                            pass
                        hybrid_cb = self._hybrid_bridge.callback
                        hybrid_cb.set_arrangement_state(self._jack_state)
                        hybrid_cb.set_transport_ref(self._bound_transport_service)
                        self._hybrid_bridge.set_sample_rate(sr)
                        # v0.0.20.41: Wire direct peak storage for JACK VU metering
                        if hasattr(self, "_direct_peaks"):
                            hybrid_cb._direct_peaks_ref = self._direct_peaks
                        self._bound_jack_service.set_render_callback(hybrid_cb.render_for_jack)
                        try:
                            self.status.emit("JACK: Hybrid Engine aktiv (lock-free, per-track mix)")
                        except Exception:
                            pass
                        return
                except Exception:
                    pass

                # Legacy fallback: DSP engine or direct render
                def _render_cb(frames, in_bufs, out_bufs, sr_int):  # noqa: ANN001
                    st = self._jack_state
                    if st is None:
                        return False
                    try:
                        buf = st.render(int(frames))
                    except Exception:
                        return False
                    try:
                        if len(out_bufs) >= 1:
                            out_bufs[0][:frames] += buf[:, 0]
                        if len(out_bufs) >= 2:
                            out_bufs[1][:frames] += buf[:, 1]
                        for ch in range(2, len(out_bufs)):
                            out_bufs[ch][:frames] += 0.0
                        try:
                            if self._bound_transport_service is not None:
                                self._bound_transport_service._set_external_playhead_samples(int(st.playhead), float(sr_int))
                        except Exception:
                            pass
                        return True
                    except Exception:
                        return False

                try:
                    dsp = None
                    try:
                        dsp = self._ensure_dsp_engine()
                    except Exception:
                        dsp = None
                    if dsp is not None:
                        try:
                            dsp.set_arrangement_state(self._jack_state)
                        except Exception:
                            pass
                        self._bound_jack_service.set_render_callback(dsp.render_callback)
                        self.status.emit("JACK: DSP Engine aktiv (Mix+Master)")
                    else:
                        self._bound_jack_service.set_render_callback(_render_cb)
                        self.status.emit("JACK: Arrangement aktiv")
                except Exception as e:
                    try:
                        self.error.emit(f"JACK: Render-Callback konnte nicht gesetzt werden: {e}")
                    except Exception:
                        pass

            # Start/replace worker
            try:
                if self._jack_prepare_thread and self._jack_prepare_thread.is_alive():
                    return
            except Exception:
                pass
            self._jack_prepare_thread = threading.Thread(target=_prepare, daemon=True)
            self._jack_prepare_thread.start()
            return

        # sounddevice path — v0.0.20.14: prefer Hybrid Callback as default
        bpm = getattr(project_snapshot, "bpm", getattr(project_snapshot, "tempo_bpm", 120.0)) if project_snapshot is not None else 120.0
        cfg: Dict[str, Any] = {
            "mode": "arrangement",
            "audio_engine_ref": self,
            "arranger_cache_ref": self._arranger_cache,
            "project_snapshot": project_snapshot,
            "transport_service": self._bound_transport_service,
            "bpm": float(bpm),
            "start_beat": float(start_beat),
            "loop_enabled": loop_enabled,
            "loop_start_beat": loop_start_beat,
            "loop_end_beat": loop_end_beat,
            "sample_rate": 48000,
            "buffer_size": 512,
            # v0.0.20.14: Pass hybrid bridge for sounddevice hybrid mode
            "hybrid_bridge": self._hybrid_bridge if _HYBRID_AVAILABLE else None,
        }
        self.stop()
        self.start(backend="sounddevice", config=cfg)


    @property
    def backend(self) -> Backend:
        return self._backend

    def set_backend(self, backend: Backend) -> None:
        if backend != self._backend:
            self._backend = backend
            self.backend_changed.emit(self._backend)

    # v0.0.20.14: Hybrid Engine access (per-track ring + JACK + sounddevice default)
    @property
    def hybrid_bridge(self) -> Any:
        """Access the HybridEngineBridge for lock-free metering/params."""
        return self._hybrid_bridge

    @property
    def async_loader(self) -> Any:
        """Access the AsyncSampleLoader for background file loading."""
        return self._async_loader

    @property
    def essentia_pool(self) -> Any:
        """Access the EssentiaWorkerPool for background time-stretch jobs."""
        return self._essentia_pool

    def read_master_peak(self) -> Tuple[float, float]:
        """Read master peak levels (GUI thread, lock-free)."""
        # v0.0.20.41: Try direct peaks first (most reliable)
        dp = self._direct_peaks.get("__master__")
        if dp is not None:
            l, r = dp
            # Apply GUI-side decay
            decay = self._direct_peaks_decay
            self._direct_peaks["__master__"] = (l * decay, r * decay)
            if l > 0.0001 or r > 0.0001:
                return (l, r)
        # Fallback: hybrid bridge
        try:
            if self._hybrid_bridge is not None:
                return self._hybrid_bridge.read_master_peak()
        except Exception:
            pass
        return (0.0, 0.0)

    def read_direct_track_peak(self, track_id: str) -> Tuple[float, float]:
        """Read per-track peak from direct storage (v0.0.20.41, GUI thread)."""
        dp = self._direct_peaks.get(str(track_id))
        if dp is not None:
            l, r = dp
            decay = self._direct_peaks_decay
            self._direct_peaks[str(track_id)] = (l * decay, r * decay)
            return (l, r)
        return (0.0, 0.0)