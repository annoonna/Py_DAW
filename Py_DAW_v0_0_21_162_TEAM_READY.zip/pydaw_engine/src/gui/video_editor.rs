// ============================================================================
// Video Editor GUI — RM11.6: Video NLE Interface State
// ============================================================================
//
// Framework-independent state management for the video editor UI.
//
// v0.0.20.978 — RM11.6 (Claude Opus 4.6, 2026-04-04)
// ============================================================================

use serde::{Deserialize, Serialize};
use super::app_state::Rect;

// ============================================================================
// Video Timeline Canvas
// ============================================================================

/// Visual state of the video timeline.
#[derive(Debug, Clone)]
pub struct VideoTimelineState {
    /// Pixels per beat (horizontal zoom)
    pub pixels_per_beat: f64,
    /// Scroll position (beats)
    pub scroll_x_beats: f64,
    /// Track height
    pub track_height: f32,
    /// Scroll Y
    pub scroll_y: f32,
    /// Viewport rect
    pub viewport: Rect,
    /// Video tracks
    pub tracks: Vec<VideoTrackHeader>,
    /// Visible clip visuals
    pub clip_visuals: Vec<VideoClipVisual>,
    /// Playhead position (beats)
    pub playhead_beat: f64,
    /// Current frame rate
    pub frame_rate: f64,
    /// Drop-frame timecode mode
    pub drop_frame: bool,
    /// Active tool
    pub tool: VideoTool,
    /// Snap to beats
    pub snap_to_beats: bool,
    /// Snap to frames
    pub snap_to_frames: bool,
    /// Ruler height
    pub ruler_height: f32,
    /// Show filmstrip thumbnails
    pub show_thumbnails: bool,
    /// Thumbnail height
    pub thumbnail_height: f32,
}

impl Default for VideoTimelineState {
    fn default() -> Self {
        Self {
            pixels_per_beat: 60.0,
            scroll_x_beats: 0.0,
            track_height: 80.0,
            scroll_y: 0.0,
            viewport: Rect::new(0.0, 0.0, 1200.0, 400.0),
            tracks: Vec::new(),
            clip_visuals: Vec::new(),
            playhead_beat: 0.0,
            frame_rate: 30.0,
            drop_frame: false,
            tool: VideoTool::Select,
            snap_to_beats: true,
            snap_to_frames: true,
            ruler_height: 28.0,
            show_thumbnails: true,
            thumbnail_height: 60.0,
        }
    }
}

impl VideoTimelineState {
    pub fn beat_to_x(&self, beat: f64) -> f32 {
        ((beat - self.scroll_x_beats) * self.pixels_per_beat) as f32
    }

    pub fn x_to_beat(&self, x: f32) -> f64 {
        x as f64 / self.pixels_per_beat + self.scroll_x_beats
    }

    pub fn track_to_y(&self, index: usize) -> f32 {
        self.ruler_height + index as f32 * self.track_height - self.scroll_y
    }

    pub fn y_to_track(&self, y: f32) -> Option<usize> {
        if y < self.ruler_height { return None; }
        let idx = ((y - self.ruler_height + self.scroll_y) / self.track_height) as usize;
        if idx < self.tracks.len() { Some(idx) } else { None }
    }

    /// Convert beat position to timecode string (HH:MM:SS:FF).
    pub fn beat_to_timecode(&self, beat: f64, bpm: f64) -> String {
        let seconds = beat * 60.0 / bpm;
        let total_frames = (seconds * self.frame_rate) as u64;
        let ff = total_frames % self.frame_rate as u64;
        let total_secs = total_frames / self.frame_rate as u64;
        let ss = total_secs % 60;
        let mm = (total_secs / 60) % 60;
        let hh = total_secs / 3600;
        format!("{:02}:{:02}:{:02}:{:02}", hh, mm, ss, ff)
    }

    /// Snap a beat position to the nearest frame boundary.
    pub fn snap_to_frame(&self, beat: f64, bpm: f64) -> f64 {
        if !self.snap_to_frames { return beat; }
        let seconds = beat * 60.0 / bpm;
        let frame = (seconds * self.frame_rate).round();
        let snapped_seconds = frame / self.frame_rate;
        snapped_seconds * bpm / 60.0
    }

    /// Update clip visuals from data.
    pub fn update_clips(&mut self, clips: &[VideoClipInfo]) {
        self.clip_visuals.clear();
        for clip in clips {
            if clip.track_index >= self.tracks.len() { continue; }
            let x = self.beat_to_x(clip.start_beat);
            let w = ((clip.end_beat - clip.start_beat) * self.pixels_per_beat) as f32;
            let y = self.track_to_y(clip.track_index) + 2.0;
            let h = self.track_height - 4.0;

            self.clip_visuals.push(VideoClipVisual {
                rect: Rect::new(x, y, w, h),
                clip_id: clip.clip_id.clone(),
                name: clip.name.clone(),
                track_index: clip.track_index,
                has_video: clip.has_video,
                has_audio: clip.has_audio,
                opacity: clip.opacity,
                speed: clip.speed,
                selected: clip.selected,
                thumbnail_ready: clip.thumbnail_ready,
            });
        }
    }

    /// Hit test for clips.
    pub fn clip_at(&self, x: f32, y: f32) -> Option<&VideoClipVisual> {
        self.clip_visuals.iter().find(|c| c.rect.contains(x, y))
    }
}

/// Video editing tools.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum VideoTool {
    Select,
    Trim,
    Razor,
    Slip,
    Slide,
    Hand,
    Zoom,
}

/// Video track header.
#[derive(Debug, Clone)]
pub struct VideoTrackHeader {
    pub track_id: String,
    pub name: String,
    pub visible: bool,
    pub locked: bool,
    pub blend_mode: String,
    pub opacity: f32,
}

/// Info for video clip placement.
#[derive(Debug, Clone)]
pub struct VideoClipInfo {
    pub clip_id: String,
    pub name: String,
    pub track_index: usize,
    pub start_beat: f64,
    pub end_beat: f64,
    pub has_video: bool,
    pub has_audio: bool,
    pub opacity: f32,
    pub speed: f32,
    pub selected: bool,
    pub thumbnail_ready: bool,
}

/// Visual representation of a video clip.
#[derive(Debug, Clone)]
pub struct VideoClipVisual {
    pub rect: Rect,
    pub clip_id: String,
    pub name: String,
    pub track_index: usize,
    pub has_video: bool,
    pub has_audio: bool,
    pub opacity: f32,
    pub speed: f32,
    pub selected: bool,
    pub thumbnail_ready: bool,
}

// ============================================================================
// Video Preview Player
// ============================================================================

/// State of the video preview window.
#[derive(Debug, Clone)]
pub struct VideoPreviewState {
    /// Preview width
    pub width: u32,
    /// Preview height
    pub height: u32,
    /// Is preview playing
    pub playing: bool,
    /// Current frame number
    pub current_frame: u64,
    /// Total frames
    pub total_frames: u64,
    /// Overlay info (timecode, safe areas)
    pub show_timecode: bool,
    pub show_safe_areas: bool,
    /// Preview quality
    pub quality: PreviewQuality,
    /// Fullscreen
    pub fullscreen: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum PreviewQuality {
    Full,
    Half,
    Quarter,
    Proxy,
}

impl Default for VideoPreviewState {
    fn default() -> Self {
        Self {
            width: 640, height: 360,
            playing: false, current_frame: 0, total_frames: 0,
            show_timecode: true, show_safe_areas: false,
            quality: PreviewQuality::Half, fullscreen: false,
        }
    }
}

// ============================================================================
// Clip Properties Panel
// ============================================================================

/// Video clip properties for the inspector panel.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClipPropertiesState {
    pub clip_id: Option<String>,
    pub name: String,
    pub in_point: f64,
    pub out_point: f64,
    pub duration: f64,
    pub speed: f32,
    pub opacity: f32,
    pub blend_mode: String,
    pub position_x: f32,
    pub position_y: f32,
    pub scale: f32,
    pub rotation: f32,
    pub flip_h: bool,
    pub flip_v: bool,
}

impl Default for ClipPropertiesState {
    fn default() -> Self {
        Self {
            clip_id: None, name: String::new(),
            in_point: 0.0, out_point: 0.0, duration: 0.0,
            speed: 1.0, opacity: 1.0, blend_mode: "Normal".into(),
            position_x: 0.0, position_y: 0.0, scale: 1.0, rotation: 0.0,
            flip_h: false, flip_v: false,
        }
    }
}

// ============================================================================
// Filter Panel
// ============================================================================

/// State of the video filter panel.
#[derive(Debug, Clone)]
pub struct FilterPanelState {
    /// Active filters on the selected clip
    pub filters: Vec<FilterEntry>,
    /// Available filter presets
    pub presets: Vec<String>,
    /// Selected preset name
    pub selected_preset: Option<String>,
    /// Whether the panel is expanded
    pub expanded: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FilterEntry {
    pub filter_type: String,
    pub enabled: bool,
    pub params: Vec<FilterParam>,
    pub expanded: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FilterParam {
    pub name: String,
    pub value: f32,
    pub min: f32,
    pub max: f32,
    pub default: f32,
}

impl Default for FilterPanelState {
    fn default() -> Self {
        Self {
            filters: Vec::new(),
            presets: vec![
                "Blade Runner".into(), "Matrix Green".into(), "Wes Anderson".into(),
                "Film Noir".into(), "Vintage 8mm".into(), "Teal & Orange".into(),
            ],
            selected_preset: None,
            expanded: true,
        }
    }
}

// ============================================================================
// Transition Editor
// ============================================================================

/// Transition editing state.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransitionEditorState {
    pub transition_type: String,
    pub duration_beats: f64,
    pub params: Vec<FilterParam>,
    pub preview_active: bool,
}

impl Default for TransitionEditorState {
    fn default() -> Self {
        Self {
            transition_type: "Crossfade".into(),
            duration_beats: 1.0,
            params: Vec::new(),
            preview_active: false,
        }
    }
}

// ============================================================================
// Multi-Cam View
// ============================================================================

/// Multi-camera view state.
#[derive(Debug, Clone)]
pub struct MultiCamState {
    /// Number of camera angles
    pub camera_count: u32,
    /// Grid layout (rows × cols)
    pub grid_rows: u32,
    pub grid_cols: u32,
    /// Currently selected camera
    pub active_camera: u32,
    /// Camera labels
    pub camera_labels: Vec<String>,
    /// Switch points (beat → camera index)
    pub switch_points: Vec<(f64, u32)>,
    /// Whether multi-cam recording is active
    pub recording_switches: bool,
}

impl Default for MultiCamState {
    fn default() -> Self {
        Self {
            camera_count: 4, grid_rows: 2, grid_cols: 2,
            active_camera: 0,
            camera_labels: vec!["Cam A".into(), "Cam B".into(), "Cam C".into(), "Cam D".into()],
            switch_points: Vec::new(),
            recording_switches: false,
        }
    }
}

impl MultiCamState {
    /// Add a camera switch at a beat position.
    pub fn add_switch(&mut self, beat: f64, camera: u32) {
        self.switch_points.push((beat, camera));
        self.switch_points.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
    }

    /// Get active camera at a beat position.
    pub fn camera_at_beat(&self, beat: f64) -> u32 {
        for &(switch_beat, cam) in self.switch_points.iter().rev() {
            if beat >= switch_beat { return cam; }
        }
        self.active_camera
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_video_timeline_beat_conversion() {
        let state = VideoTimelineState::default();
        let x = state.beat_to_x(2.0);
        let beat = state.x_to_beat(x);
        assert!((beat - 2.0).abs() < 0.001);
    }

    #[test]
    fn test_timecode() {
        let state = VideoTimelineState { frame_rate: 30.0, ..Default::default() };
        // At 120 BPM: beat 4 = 2 seconds = frame 60
        assert_eq!(state.beat_to_timecode(4.0, 120.0), "00:00:02:00");
        // beat 1 = 0.5 seconds = frame 15
        assert_eq!(state.beat_to_timecode(1.0, 120.0), "00:00:00:15");
    }

    #[test]
    fn test_snap_to_frame() {
        let state = VideoTimelineState { frame_rate: 30.0, snap_to_frames: true, ..Default::default() };
        let snapped = state.snap_to_frame(1.0, 120.0);
        // Should be a valid frame boundary
        let seconds = snapped * 60.0 / 120.0;
        let frame_frac = seconds * 30.0;
        assert!((frame_frac - frame_frac.round()).abs() < 0.001);
    }

    #[test]
    fn test_video_clip_hit_test() {
        let mut state = VideoTimelineState::default();
        state.tracks.push(VideoTrackHeader {
            track_id: "v1".into(), name: "Video 1".into(),
            visible: true, locked: false, blend_mode: "Normal".into(), opacity: 1.0,
        });
        let clips = vec![VideoClipInfo {
            clip_id: "vc1".into(), name: "Clip 1".into(), track_index: 0,
            start_beat: 0.0, end_beat: 4.0, has_video: true, has_audio: true,
            opacity: 1.0, speed: 1.0, selected: false, thumbnail_ready: false,
        }];
        state.update_clips(&clips);
        assert!(state.clip_at(30.0, state.track_to_y(0) + 10.0).is_some());
    }

    #[test]
    fn test_multicam() {
        let mut mc = MultiCamState::default();
        mc.add_switch(0.0, 0);
        mc.add_switch(4.0, 1);
        mc.add_switch(8.0, 2);

        assert_eq!(mc.camera_at_beat(2.0), 0);
        assert_eq!(mc.camera_at_beat(5.0), 1);
        assert_eq!(mc.camera_at_beat(10.0), 2);
    }

    #[test]
    fn test_preview_state() {
        let preview = VideoPreviewState::default();
        assert_eq!(preview.width, 640);
        assert!(!preview.fullscreen);
    }
}
