// ============================================================================
// Input Manager — RM11.2: Keyboard Shortcuts & Mouse State
// ============================================================================

use std::collections::HashMap;
use serde::{Deserialize, Serialize};

/// Modifier keys.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default, Serialize, Deserialize)]
pub struct Modifiers {
    pub ctrl: bool,
    pub shift: bool,
    pub alt: bool,
    pub meta: bool, // Super/Win/Cmd
}

/// A keyboard shortcut.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct Shortcut {
    pub key: String,
    pub modifiers: Modifiers,
}

impl Shortcut {
    pub fn new(key: &str) -> Self { Self { key: key.into(), modifiers: Modifiers::default() } }
    pub fn ctrl(key: &str) -> Self { Self { key: key.into(), modifiers: Modifiers { ctrl: true, ..Default::default() } } }
    pub fn ctrl_shift(key: &str) -> Self { Self { key: key.into(), modifiers: Modifiers { ctrl: true, shift: true, ..Default::default() } } }
    pub fn display(&self) -> String {
        let mut s = String::new();
        if self.modifiers.ctrl { s.push_str("Ctrl+"); }
        if self.modifiers.shift { s.push_str("Shift+"); }
        if self.modifiers.alt { s.push_str("Alt+"); }
        if self.modifiers.meta { s.push_str("Super+"); }
        s.push_str(&self.key);
        s
    }
}

/// Actions that can be bound to shortcuts.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Action {
    // File
    NewProject, OpenProject, Save, SaveAs, Export, Quit,
    // Edit
    Undo, Redo, Cut, Copy, Paste, Delete, SelectAll, Deselect, Duplicate,
    // Transport
    Play, Stop, Record, ToggleLoop, Rewind, Forward, GotoStart, GotoEnd,
    // View
    ZoomIn, ZoomOut, ZoomFit, ToggleMixer, ToggleBrowser, TogglePianoRoll, Fullscreen,
    // Tools
    ToolSelect, ToolPencil, ToolEraser, ToolKnife, ToolGlue, ToolMute, ToolZoom, ToolHand,
    // Track
    AddTrack, DeleteTrack, MuteTrack, SoloTrack, ArmTrack,
    // Snap
    ToggleSnap, SnapFiner, SnapCoarser,
    // Custom
    Custom(String),
}

/// Keyboard shortcut manager.
pub struct ShortcutManager {
    pub bindings: HashMap<Shortcut, Action>,
    pub reverse: HashMap<Action, Shortcut>,
}

impl ShortcutManager {
    pub fn new() -> Self {
        let mut mgr = Self { bindings: HashMap::new(), reverse: HashMap::new() };
        mgr.load_defaults();
        mgr
    }

    fn bind(&mut self, shortcut: Shortcut, action: Action) {
        self.reverse.insert(action.clone(), shortcut.clone());
        self.bindings.insert(shortcut, action);
    }

    pub fn load_defaults(&mut self) {
        self.bindings.clear();
        self.reverse.clear();
        // File
        self.bind(Shortcut::ctrl("n"), Action::NewProject);
        self.bind(Shortcut::ctrl("o"), Action::OpenProject);
        self.bind(Shortcut::ctrl("s"), Action::Save);
        self.bind(Shortcut::ctrl_shift("s"), Action::SaveAs);
        self.bind(Shortcut::ctrl_shift("e"), Action::Export);
        self.bind(Shortcut::ctrl("q"), Action::Quit);
        // Edit
        self.bind(Shortcut::ctrl("z"), Action::Undo);
        self.bind(Shortcut::ctrl_shift("z"), Action::Redo);
        self.bind(Shortcut::ctrl("x"), Action::Cut);
        self.bind(Shortcut::ctrl("c"), Action::Copy);
        self.bind(Shortcut::ctrl("v"), Action::Paste);
        self.bind(Shortcut::new("Delete"), Action::Delete);
        self.bind(Shortcut::ctrl("a"), Action::SelectAll);
        self.bind(Shortcut::ctrl("d"), Action::Duplicate);
        // Transport
        self.bind(Shortcut::new("space"), Action::Play);
        self.bind(Shortcut::new("Return"), Action::Stop);
        self.bind(Shortcut::new("r"), Action::Record);
        self.bind(Shortcut::new("l"), Action::ToggleLoop);
        self.bind(Shortcut::new("Home"), Action::GotoStart);
        self.bind(Shortcut::new("End"), Action::GotoEnd);
        // Tools
        self.bind(Shortcut::new("v"), Action::ToolSelect);
        self.bind(Shortcut::new("p"), Action::ToolPencil);
        self.bind(Shortcut::new("e"), Action::ToolEraser);
        self.bind(Shortcut::new("k"), Action::ToolKnife);
        self.bind(Shortcut::new("h"), Action::ToolHand);
        self.bind(Shortcut::new("z"), Action::ToolZoom);
        // View
        self.bind(Shortcut::ctrl("="), Action::ZoomIn);
        self.bind(Shortcut::ctrl("-"), Action::ZoomOut);
        self.bind(Shortcut::ctrl("0"), Action::ZoomFit);
        self.bind(Shortcut::new("F3"), Action::ToggleMixer);
        self.bind(Shortcut::new("F9"), Action::ToggleBrowser);
        self.bind(Shortcut::new("F11"), Action::Fullscreen);
    }

    /// Look up action for a shortcut.
    pub fn lookup(&self, shortcut: &Shortcut) -> Option<&Action> {
        self.bindings.get(shortcut)
    }

    /// Get shortcut display string for an action.
    pub fn shortcut_for(&self, action: &Action) -> Option<String> {
        self.reverse.get(action).map(|s| s.display())
    }
}

/// Mouse button state.
#[derive(Debug, Clone, Copy, Default)]
pub struct MouseState {
    pub x: f32,
    pub y: f32,
    pub left_down: bool,
    pub right_down: bool,
    pub middle_down: bool,
    pub drag_start_x: f32,
    pub drag_start_y: f32,
    pub is_dragging: bool,
    pub scroll_delta: f32,
}

impl MouseState {
    pub fn drag_dx(&self) -> f32 { self.x - self.drag_start_x }
    pub fn drag_dy(&self) -> f32 { self.y - self.drag_start_y }
    pub fn drag_distance(&self) -> f32 {
        (self.drag_dx().powi(2) + self.drag_dy().powi(2)).sqrt()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_shortcut_display() {
        assert_eq!(Shortcut::ctrl("s").display(), "Ctrl+s");
        assert_eq!(Shortcut::ctrl_shift("z").display(), "Ctrl+Shift+z");
        assert_eq!(Shortcut::new("space").display(), "space");
    }

    #[test]
    fn test_shortcut_lookup() {
        let mgr = ShortcutManager::new();
        assert_eq!(mgr.lookup(&Shortcut::ctrl("s")), Some(&Action::Save));
        assert_eq!(mgr.lookup(&Shortcut::new("space")), Some(&Action::Play));
        assert!(mgr.shortcut_for(&Action::Undo).is_some());
    }

    #[test]
    fn test_mouse_drag() {
        let m = MouseState { x: 100.0, y: 50.0, drag_start_x: 80.0, drag_start_y: 40.0, is_dragging: true, ..Default::default() };
        assert_eq!(m.drag_dx(), 20.0);
        assert_eq!(m.drag_dy(), 10.0);
        assert!(m.drag_distance() > 22.0);
    }
}
