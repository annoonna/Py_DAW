// ============================================================================
// Shared Memory Audio Ring — Rust Reader (cpal callback)
// ============================================================================
//
// Zero-copy audio streaming from Python to Rust via /dev/shm/pydaw_audio_ring.
//
// Python writes audio samples into shared memory.
// Rust's cpal callback reads directly — no IPC, no serialization, no copy.
//
// Shared memory layout (same as Python side):
//   Offset 0:   write_pos  (u64 LE, written by Python)
//   Offset 8:   read_pos   (u64 LE, written by Rust)
//   Offset 16:  capacity   (u64 LE, set once)
//   Offset 24:  active     (u8, 1=streaming)
//   Offset 64:  [f32 LE samples...] (capacity * 4 bytes)
//
// v0.0.20.982 (Claude Opus 4.6, 2026-04-04)
// ============================================================================

use std::sync::atomic::{AtomicBool, Ordering};
use std::ptr;
use log::{info, warn};

const SHM_PATH: &str = "/dev/shm/pydaw_audio_ring";
const HEADER_SIZE: usize = 64;

/// Shared memory audio ring buffer reader.
///
/// Maps /dev/shm/pydaw_audio_ring (created by Python) and reads audio
/// samples directly in the cpal callback — zero copy, zero allocation.
pub struct ShmAudioReader {
    /// Pointer to the mmap'd region
    ptr: *mut u8,
    /// Total mapped size
    size: usize,
    /// Capacity in f32 samples
    capacity: usize,
    /// Bitmask for wrapping (capacity - 1)
    mask: usize,
    /// Whether mmap is valid
    mapped: AtomicBool,
}

// Safety: the shared memory is process-shared, and we use atomic operations
// for read/write positions. The data region is SPSC (Python writes, Rust reads).
unsafe impl Send for ShmAudioReader {}
unsafe impl Sync for ShmAudioReader {}

impl ShmAudioReader {
    /// Create an unmapped reader. Call `try_open()` to map the shared memory.
    pub fn new() -> Self {
        Self {
            ptr: ptr::null_mut(),
            size: 0,
            capacity: 0,
            mask: 0,
            mapped: AtomicBool::new(false),
        }
    }

    /// Try to open and mmap the shared memory file.
    /// Returns true if successful (Python has created it).
    pub fn try_open(&mut self) -> bool {
        if self.mapped.load(Ordering::Relaxed) {
            return true;
        }

        unsafe {
            // Open the shared memory file
            let path = std::ffi::CString::new(SHM_PATH).unwrap();
            let fd = libc::open(path.as_ptr(), libc::O_RDWR);
            if fd < 0 {
                return false; // File doesn't exist yet (Python hasn't created it)
            }

            // Get file size
            let mut stat: libc::stat = std::mem::zeroed();
            if libc::fstat(fd, &mut stat) != 0 {
                libc::close(fd);
                return false;
            }
            let size = stat.st_size as usize;
            if size < HEADER_SIZE + 4 {
                libc::close(fd);
                return false;
            }

            // mmap
            let ptr = libc::mmap(
                ptr::null_mut(),
                size,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_SHARED,
                fd,
                0,
            );
            libc::close(fd); // fd can be closed after mmap

            if ptr == libc::MAP_FAILED {
                warn!("[ShmAudio] mmap failed");
                return false;
            }

            // Read capacity from header
            let capacity = *(ptr.add(16) as *const u64) as usize;
            if capacity == 0 || (capacity & (capacity - 1)) != 0 {
                // Not a power of 2 — invalid
                libc::munmap(ptr, size);
                return false;
            }

            self.ptr = ptr as *mut u8;
            self.size = size;
            self.capacity = capacity;
            self.mask = capacity - 1;
            self.mapped.store(true, Ordering::Release);

            info!(
                "[ShmAudio] Mapped shared memory: {} ({} bytes, {} samples capacity)",
                SHM_PATH, size, capacity
            );
            true
        }
    }

    /// Check if shared memory is mapped and active.
    pub fn is_active(&self) -> bool {
        if !self.mapped.load(Ordering::Relaxed) {
            return false;
        }
        unsafe {
            let active = *self.ptr.add(24);
            active != 0
        }
    }

    /// Read samples from the shared memory ring buffer.
    /// Called from the cpal audio callback — must be lock-free.
    ///
    /// Returns number of samples actually read.
    /// Zero-pads output if not enough data available.
    pub fn read(&self, output: &mut [f32]) -> usize {
        if !self.mapped.load(Ordering::Relaxed) {
            output.fill(0.0);
            return 0;
        }

        unsafe {
            let write_pos = *(self.ptr as *const u64) as usize;
            let read_pos = *(self.ptr.add(8) as *const u64) as usize;

            let available = write_pos.wrapping_sub(read_pos);
            let to_read = output.len().min(available);

            if to_read == 0 {
                output.fill(0.0);
                return 0;
            }

            // Read from data area
            let data_base = self.ptr.add(HEADER_SIZE) as *const f32;
            for i in 0..to_read {
                let idx = (read_pos.wrapping_add(i)) & self.mask;
                output[i] = *data_base.add(idx);
            }

            // Zero-pad remainder
            if to_read < output.len() {
                for i in to_read..output.len() {
                    output[i] = 0.0;
                }
            }

            // Update read position
            let new_read = read_pos.wrapping_add(to_read) as u64;
            *(self.ptr.add(8) as *mut u64) = new_read;

            to_read
        }
    }

    /// Whether the shared memory is mapped.
    pub fn is_mapped(&self) -> bool {
        self.mapped.load(Ordering::Relaxed)
    }

    /// Mix shared memory audio INTO existing output buffer (additive).
    ///
    /// Unlike `read()` which overwrites, this ADDs samples to `output`.
    /// Used during playback to mix Python-rendered instruments (SF2, VST2)
    /// into the Rust graph output.
    pub fn read_mix(&self, output: &mut [f32]) -> usize {
        if !self.mapped.load(Ordering::Relaxed) {
            return 0;
        }

        unsafe {
            let write_pos = *(self.ptr as *const u64) as usize;
            let read_pos = *(self.ptr.add(8) as *const u64) as usize;

            let available = write_pos.wrapping_sub(read_pos);
            let to_read = output.len().min(available);

            if to_read == 0 {
                return 0;
            }

            // Mix (add) from data area
            let data_base = self.ptr.add(HEADER_SIZE) as *const f32;
            for i in 0..to_read {
                let idx = (read_pos.wrapping_add(i)) & self.mask;
                output[i] += *data_base.add(idx);
            }

            // Update read position
            let new_read = read_pos.wrapping_add(to_read) as u64;
            *(self.ptr.add(8) as *mut u64) = new_read;

            to_read
        }
    }
}

impl Drop for ShmAudioReader {
    fn drop(&mut self) {
        if self.mapped.load(Ordering::Relaxed) {
            unsafe {
                libc::munmap(self.ptr as *mut libc::c_void, self.size);
            }
            self.mapped.store(false, Ordering::Release);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_new_unmapped() {
        let reader = ShmAudioReader::new();
        assert!(!reader.is_mapped());
        assert!(!reader.is_active());
        let mut buf = [0.0f32; 64];
        assert_eq!(reader.read(&mut buf), 0);
    }
}
