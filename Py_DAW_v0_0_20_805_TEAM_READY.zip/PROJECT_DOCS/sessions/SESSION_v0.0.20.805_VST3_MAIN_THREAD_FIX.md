# Session Log — v0.0.20.805

**Datum:** 2026-03-25
**Kollege:** Claude Opus 4.6
**Arbeitspaket:** P0 Stabilisierung — VST3 Regression + Segfault beim Beenden
**Aufgabe:** VST3 Plugins laden nicht mehr seit v795, Segfault bei Exit

## Root Cause 1: VST3 Main-Thread Regression

**In v0.0.20.795 wurde `_do_deferred_rebuild()` eingeführt**, das die Plugin-Engine-
Erstellung in einen `threading.Thread` verschiebt. Pedalboard's VST3-Loader
erfordert aber zwingend den Main Thread auf Linux.

```python
# v795 BROKEN — Worker Thread:
def _do_deferred_rebuild(self):
    def _worker():
        self._create_vst_instrument_engines(...)  # VST3 braucht Main Thread!
    threading.Thread(target=_worker).start()
```

VST2 (ZynAddSubFX) ging noch, weil pedalboard diese Einschränkung für VST2 nicht hat.
CLAP ging noch, weil es eine eigene ctypes/FFI-Implementierung nutzt.

**Fix:** Synchrone Ausführung auf Main Thread mit `processEvents()` für GUI-Responsiveness.

## Root Cause 2: Segfault beim Beenden

Native Plugin-Threads (CLAP host, VST2 liblo-Server) liefen weiter während Python
seinen Interpreter herunterfuhr. `container.shutdown()` rief nur `audio_engine.stop()`
(Audio-Stream stoppen), aber zerstörte nicht die Plugin-Instances.

**Fix:** Neue Methode `AudioEngine.shutdown_instruments()` — fährt alle Engines
herunter, leert Pull-Sources und SamplerRegistry. Wird in closeEvent() aufgerufen.

## Was wurde erledigt
- [x] VST3 Main-Thread Fix: `_do_deferred_rebuild()` Worker-Thread entfernt
- [x] Segfault Fix: `shutdown_instruments()` für sauberes Plugin-Shutdown
- [x] Wiring in `closeEvent()` und `container.shutdown()`
- [x] Alle Syntax-Checks bestanden (80+ Dateien)

## Geänderte Dateien
- pydaw/audio/audio_engine.py (Main-Thread Fix + shutdown_instruments)
- pydaw/ui/main_window.py (closeEvent: shutdown_instruments vor stop)
- pydaw/services/container.py (shutdown: shutdown_instruments vor stop)
- VERSION, pydaw/version.py → 0.0.20.805

## Test-Anleitung
1. DAW starten
2. Surge XT (VST3) laden → **MUSS jetzt Ton produzieren**
3. ZynAddSubFX (VST2) laden → **Muss weiterhin funktionieren**
4. CLAP Plugin laden → **Muss weiterhin funktionieren**
5. DAW schließen → **Kein Segfault**

## Nächste Aufgabe
Weiter mit der ROADMAP — nächste offene [ ] Checkbox.
