"""Arranger view: track list + scrollable canvas + automation panel.

v0.0.19.7.39:
- Drag&Drop Overlay Clip-Launcher Grid (from Browser Sample drag)
- Overlay accepts drops ONLY while active to avoid collisions with Arranger logic

v0.0.20.86:
- TrackList: Drag&Drop support for cross-project track transfer
  Drag a track from one project tab's TrackList to another tab's ArrangerCanvas.
"""

from __future__ import annotations

import logging

from PyQt6.QtWidgets import (
    QWidget,
    QHBoxLayout,
    QVBoxLayout,
    QListWidget,
    QListWidgetItem,
    QScrollArea,
    QSplitter,
    QLabel,
    QToolButton,
    QComboBox,
    QAbstractItemView,
)
from PyQt6.QtCore import Qt, pyqtSignal, QEvent, QMimeData
from PyQt6.QtGui import QDrag

from pydaw.ui.cross_project_drag import create_track_drag_data

from pydaw.services.project_service import ProjectService
from .arranger_canvas import ArrangerCanvas
from .automation_lanes import AutomationLanePanel
from .clip_launcher_overlay import ClipLauncherOverlay

log = logging.getLogger(__name__)


class TrackList(QWidget):
    track_selected = pyqtSignal(str)
    selected_track_changed = pyqtSignal(str)  # compatibility alias

    def __init__(self, project: ProjectService, parent=None):
        super().__init__(parent)
        self.project = project
        self._tab_service = None  # v0.0.20.86: for cross-project drag
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.list = QListWidget()
        # v0.0.20.86: Enable drag for cross-project track transfer
        self.list.setDragEnabled(True)
        self.list.setDefaultDropAction(Qt.DropAction.CopyAction)
        self.list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.list.setDragDropMode(QAbstractItemView.DragDropMode.DragOnly)
        # Override startDrag to provide custom MIME data
        self.list.startDrag = self._start_drag
        layout.addWidget(self.list, 1)
        self.list.currentItemChanged.connect(self._on_sel)

        self.project.project_updated.connect(self.refresh)
        self.refresh()

    # --- v0.0.20.86: Cross-Project Drag Support ---

    def set_tab_service(self, tab_service) -> None:
        """Wire the ProjectTabService for cross-project drag data."""
        self._tab_service = tab_service

    def _start_drag(self, supported_actions) -> None:
        """Custom startDrag: creates cross-project MIME data for selected tracks."""
        try:
            selected_items = self.list.selectedItems()
            if not selected_items:
                return

            track_ids = []
            track_names = []
            for item in selected_items:
                tid = str(item.data(Qt.ItemDataRole.UserRole) or "")
                if tid:
                    track_ids.append(tid)
                    trk = next((t for t in self.project.ctx.project.tracks if t.id == tid), None)
                    if trk:
                        track_names.append(trk.name)

            if not track_ids:
                return

            # Determine source tab index (default 0 if no tab service)
            src_idx = 0
            if self._tab_service:
                src_idx = self._tab_service.active_index

            mime = create_track_drag_data(
                source_tab_index=src_idx,
                track_ids=track_ids,
                include_clips=True,
                include_device_chains=True,
            )

            drag = QDrag(self.list)
            drag.setMimeData(mime)

            log.info("TrackList: starting cross-project drag with %d track(s)",
                     len(track_ids))

            drag.exec(Qt.DropAction.CopyAction)
        except Exception:
            log.exception("TrackList._start_drag failed")

    def refresh(self) -> None:
        cur_id = self.selected_track_id()
        self.list.clear()
        for t in self.project.ctx.project.tracks:
            it = QListWidgetItem()
            it.setData(Qt.ItemDataRole.UserRole, t.id)
            # custom row widget with M/S/R controls
            row = QWidget()
            lay = QHBoxLayout(row)
            lay.setContentsMargins(6, 2, 6, 2)
            lay.setSpacing(6)

            lbl = QLabel(t.name)
            lbl.setMinimumWidth(90)
            lbl.setStyleSheet("color: #e6e6e6;")
            lay.addWidget(lbl, 1)

            # Input/Monitoring controls (JACK-first): show for audio/bus tracks.
            if t.kind in ("audio", "bus"):
                try:
                    import os

                    in_ch = int(os.environ.get("PYDAW_JACK_IN", "2"))
                    out_ch = int(os.environ.get("PYDAW_JACK_OUT", "2"))
                except Exception:
                    in_ch, out_ch = 2, 2

                in_pairs = max(1, in_ch // 2)
                out_pairs = max(1, out_ch // 2)

                cb_in = QComboBox()
                for i in range(1, in_pairs + 1):
                    cb_in.addItem(f"Stereo {i}")
                cur_in = max(1, int(getattr(t, "input_pair", 1)))
                cb_in.setCurrentIndex(max(0, min(in_pairs - 1, cur_in - 1)))
                cb_in.setToolTip("Input (Stereo-Paar) für Monitoring/Recording")
                cb_in.currentIndexChanged.connect(lambda idx, tid=t.id: self.project.set_track_input_pair(tid, idx + 1))
                cb_in.setFixedWidth(90)

                cb_out = QComboBox()
                for i in range(1, out_pairs + 1):
                    cb_out.addItem(f"Out {i}")
                cur_out = max(1, int(getattr(t, "output_pair", 1)))
                cb_out.setCurrentIndex(max(0, min(out_pairs - 1, cur_out - 1)))
                cb_out.setToolTip("Output (Stereo-Paar) – vorbereitet für Submix/Click")
                cb_out.currentIndexChanged.connect(lambda idx, tid=t.id: self.project.set_track_output_pair(tid, idx + 1))
                cb_out.setFixedWidth(76)

                btn_i = QToolButton()
                btn_i.setText("I")
                btn_i.setCheckable(True)
                btn_i.setChecked(bool(getattr(t, "monitor", False)))
                btn_i.setToolTip("Input Monitoring")
                btn_i.clicked.connect(lambda _=False, tid=t.id: self.project.set_track_monitor(tid, not self._track_mon(tid)))
                btn_i.setFixedWidth(26)
                btn_i.setAutoRaise(True)

                lay.addWidget(cb_in)
                lay.addWidget(cb_out)
                lay.addWidget(btn_i)

            btn_m = QToolButton()
            btn_m.setText("M")
            btn_m.setCheckable(True)
            btn_m.setChecked(bool(getattr(t, "muted", False)))
            btn_m.setToolTip("Mute")
            btn_m.clicked.connect(lambda _=False, tid=t.id: self.project.set_track_muted(tid, not self._track_muted(tid)))

            btn_s = QToolButton()
            btn_s.setText("S")
            btn_s.setCheckable(True)
            btn_s.setChecked(bool(getattr(t, "solo", False)))
            btn_s.setToolTip("Solo")
            btn_s.clicked.connect(lambda _=False, tid=t.id: self.project.set_track_solo(tid, not self._track_solo(tid)))

            btn_r = QToolButton()
            btn_r.setText("R")
            btn_r.setCheckable(True)
            btn_r.setChecked(bool(getattr(t, "record_arm", False)))
            btn_r.setToolTip("Record Arm")
            btn_r.clicked.connect(lambda _=False, tid=t.id: self.project.set_track_record_arm(tid, not self._track_arm(tid)))

            for b in (btn_m, btn_s, btn_r):
                b.setFixedWidth(26)
                b.setAutoRaise(True)

            lay.addWidget(btn_m)
            lay.addWidget(btn_s)
            lay.addWidget(btn_r)

            it.setSizeHint(row.sizeHint())
            self.list.addItem(it)
            self.list.setItemWidget(it, row)
            if cur_id and t.id == cur_id:
                self.list.setCurrentItem(it)

    def _track_muted(self, track_id: str) -> bool:
        trk = next((t for t in self.project.ctx.project.tracks if t.id == track_id), None)
        return bool(getattr(trk, "muted", False))

    def _track_solo(self, track_id: str) -> bool:
        trk = next((t for t in self.project.ctx.project.tracks if t.id == track_id), None)
        return bool(getattr(trk, "solo", False))

    def _track_arm(self, track_id: str) -> bool:
        trk = next((t for t in self.project.ctx.project.tracks if t.id == track_id), None)
        return bool(getattr(trk, "record_arm", False))

    def _track_mon(self, track_id: str) -> bool:
        trk = next((t for t in self.project.ctx.project.tracks if t.id == track_id), None)
        return bool(getattr(trk, "monitor", False))

    def _on_sel(self, cur, prev):  # noqa: ANN001
        if not cur:
            self.track_selected.emit("")
            return
        tid = str(cur.data(Qt.ItemDataRole.UserRole) or "")
        self.track_selected.emit(tid)
        self.selected_track_changed.emit(tid)

    def selected_track_id(self) -> str:
        it = self.list.currentItem()
        if not it:
            return ""
        return str(it.data(Qt.ItemDataRole.UserRole) or "")


class ArrangerView(QWidget):
    clip_activated = pyqtSignal(str)
    clip_selected = pyqtSignal(str)
    request_rename_clip = pyqtSignal(str)
    request_duplicate_clip = pyqtSignal(str)
    request_delete_clip = pyqtSignal(str)
    status_message = pyqtSignal(str, int)  # (message, timeout_ms) - v0.0.19.7.0
    view_range_changed = pyqtSignal(float, float)  # start_beat, end_beat

    # Drag&Drop Overlay import: (file_path, track_id, start_beats, slot_key)
    request_import_audio_file = pyqtSignal(str, str, float, str)

    def __init__(self, project: ProjectService, parent=None):
        super().__init__(parent)
        self.project = project
        self._transport = None

        # Outer layout hosts a *horizontal splitter* so the user can resize/collapse
        # the TrackList and the Arranger view (Pro-DAW-like). This fixes the UX issue
        # where the left track area was not resizable at all.
        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        hsplit = QSplitter(Qt.Orientation.Horizontal)
        hsplit.setChildrenCollapsible(True)
        try:
            hsplit.setHandleWidth(6)
        except Exception:
            pass

        # Left side: Tracklist (collapsible)
        left_panel = QVBoxLayout()
        left_panel.setContentsMargins(0, 0, 0, 0)
        left_panel.setSpacing(4)

        self.tracks = TrackList(project)
        # Allow shrinking almost to zero (user requested)
        try:
            self.tracks.setMinimumWidth(0)
        except Exception:
            pass
        left_panel.addWidget(self.tracks, 1)

        left_container = QWidget()
        left_container.setLayout(left_panel)
        try:
            left_container.setMinimumWidth(0)
        except Exception:
            pass

        # Right side: canvas (scrollable) + automation panel in a vertical splitter
        right = QSplitter(Qt.Orientation.Vertical)

        self.canvas = ArrangerCanvas(project)
        self.canvas.clip_activated.connect(self.clip_activated.emit)
        self.canvas.clip_selected.connect(self.clip_selected.emit)
        self.canvas.request_rename_clip.connect(self.request_rename_clip.emit)
        self.canvas.request_duplicate_clip.connect(self.request_duplicate_clip.emit)
        self.canvas.request_delete_clip.connect(self.request_delete_clip.emit)
        self.canvas.status_message.connect(self.status_message.emit)  # Keyboard shortcuts (v0.0.19.7.0)

        self.scroll = QScrollArea()
        # Canvas liefert eine dynamische Mindestgröße; dadurch können
        # horizontale/vertikale Scrollbars zuverlässig erscheinen.
        self.scroll.setWidgetResizable(False)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll.setWidget(self.canvas)

        # Clip-Launcher Overlay (shown during Browser drag)
        self.clip_overlay = ClipLauncherOverlay(self.project, transport=None, parent=self.scroll.viewport())
        self.clip_overlay.setGeometry(self.scroll.viewport().rect())
        self.clip_overlay.request_import_audio.connect(self.request_import_audio_file.emit)
        self.scroll.viewport().installEventFilter(self)

        right.addWidget(self.scroll)

        # sync view range (scroll/zoom) to downstream editors (automation, etc.)
        try:
            self.scroll.horizontalScrollBar().valueChanged.connect(lambda _v: self._emit_view_range())
            self.canvas.zoom_changed.connect(lambda _ppb: self._emit_view_range())
        except Exception:
            pass

        self.automation = AutomationLanePanel(project)
        right.addWidget(self.automation)
        right.setStretchFactor(0, 4)
        right.setStretchFactor(1, 1)

        # Assemble horizontal splitter
        hsplit.addWidget(left_container)
        hsplit.addWidget(right)
        hsplit.setStretchFactor(0, 0)
        hsplit.setStretchFactor(1, 1)
        try:
            hsplit.setCollapsible(0, True)
            hsplit.setCollapsible(1, False)
        except Exception:
            pass
        try:
            # Default: readable TrackList, big arranger
            hsplit.setSizes([240, 1200])
        except Exception:
            pass

        outer.addWidget(hsplit, 1)
        self._emit_view_range()

    # ---- overlay helpers

    def set_transport(self, transport) -> None:
        self._transport = transport
        try:
            self.clip_overlay.set_transport(transport)
        except Exception:
            pass

    def set_tab_service(self, tab_service) -> None:
        """Wire ProjectTabService to canvas + track list for cross-project D&D."""
        try:
            self.canvas.set_tab_service(tab_service)
        except Exception:
            pass
        try:
            self.tracks.set_tab_service(tab_service)
        except Exception:
            pass

    def activate_clip_overlay(self, drag_label: str = "") -> None:
        try:
            self.clip_overlay.setGeometry(self.scroll.viewport().rect())
            self.clip_overlay.activate(str(drag_label or ""))
        except Exception:
            pass

    def deactivate_clip_overlay(self) -> None:
        try:
            self.clip_overlay.deactivate()
        except Exception:
            pass

    def eventFilter(self, obj, event):  # noqa: ANN001
        if obj is self.scroll.viewport() and event.type() == QEvent.Type.Resize:
            try:
                self.clip_overlay.setGeometry(self.scroll.viewport().rect())
            except Exception:
                pass
        return super().eventFilter(obj, event)

    # ---- view range

    def visible_range_beats(self) -> tuple[float, float]:
        try:
            ppb = float(getattr(self.canvas, "pixels_per_beat", 80.0)) or 80.0
            x0 = float(self.scroll.horizontalScrollBar().value())
            w = float(self.scroll.viewport().width())
            start = max(0.0, x0 / ppb)
            end = max(start + 0.25, (x0 + w) / ppb)
            return (start, end)
        except Exception:
            return (0.0, 0.0)

    def _emit_view_range(self) -> None:
        """Emit currently visible beat range based on scroll position + zoom."""
        try:
            a, b = self.visible_range_beats()
            self.view_range_changed.emit(a, b)
        except Exception:
            pass

    def resizeEvent(self, event):  # noqa: ANN001
        super().resizeEvent(event)
        self._emit_view_range()

    def set_automation_visible(self, visible: bool) -> None:
        self.automation.setVisible(bool(visible))

    def set_snap_division(self, division: str) -> None:
        # map division string to beats (quarter-beat unit)
        div = str(division)
        mapping = {
            "1/4": 1.0,
            "1/8": 0.5,
            "1/16": 0.25,
            "1/32": 0.125,
            "1/64": 0.0625,
        }
        self.canvas.snap_beats = mapping.get(div, 0.25)
        self.canvas.update()
