v0.0.20.85

- Projekt → „Projekt vergleichen…“: Diff & Summary zwischen zwei offenen Projekt-Tabs (read-only).
- Diff ist stabil (sort_keys) und kann Zeitstempel optional ignorieren.
