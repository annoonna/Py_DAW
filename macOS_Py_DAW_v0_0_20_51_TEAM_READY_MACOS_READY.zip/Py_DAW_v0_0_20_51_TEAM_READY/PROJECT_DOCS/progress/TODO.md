## v0.0.20.50 — Hotfix: Playback/Sound (JACK Arrange Preparation) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (2026-02-10) ✅ DONE  
**Priority:** 🔴 CRITICAL  
**Status:** ✅ FERTIG

**Symptom (User-Report):** Kein Sound beim Abspielen; Popup:  
`JACK: Arrange-Vorbereitung fehlgeschlagen: cannot access local variable 'file_sr' where it is not associated with a value`

**Ursache:** In `arrangement_renderer.py` wurde bei WAV-Laden aus dem Cache (`SampleCache.get_decoded`) die Variable `file_sr` nicht gesetzt.
Dadurch crashte die Arrange-Vorbereitung und Playback wurde komplett abgebrochen.

**Fixes:**
- [x] `arrangement_renderer.py`: `file_sr = int(sr)` initialisieren bevor Cache-Path genutzt wird (Cache liefert bereits resampled Data).
- [x] `audio_engine.py`: Wenn JACK im Audio-Settings erzwungen ist, aber kein JACK-Server läuft → automatisch auf `sounddevice` fallback (mit Hinweis).

**Ergebnis:** Playback startet wieder stabil (kein Crash) – sowohl bei SF2-Render (Cache) als auch ohne laufenden JACK-Server.

---

## v0.0.20.45 — Hotfix: Pro Drum Machine Pull-Source Metadata ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (2026-02-09) ✅ DONE  
**Aufwand:** ~10min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Problem (User-Report):** Beim Einfügen des Devices erschien im Device Panel:
`'method' object has no attribute '_pydaw_track_id' and no __dict__ for setting new attributes`.

**Ursache:** `self.engine.pull` ist ein **bound method** (Python method-object) und kann keine freien Attribute tragen.
AudioEngine erwartet aber ein Callable mit optionalem Attribut `_pydaw_track_id`.

**Fix:** Pull-Funktion wird wie beim Sampler als **Wrapper-Funktion** erstellt, damit `_pydaw_track_id` gesetzt werden kann.

**Ergebnis:** Drum Machine Device lädt wieder korrekt, ohne Fehler-Overlay im Device Panel.

---

## v0.0.20.44 — Pro Drum Machine (Phase 1 Skeleton) ✅ DONE
**Assignee:** [x] GPT-5.2 Thinking (2026-02-09) ✅ DONE  
**Aufwand:** ~90min  
**Priority:** 🟠 MEDIUM  
**Status:** ✅ FERTIG

**Ziel:** Neues, modulares Drum-Modul als eigenständiges Device (Bitwig/Ableton-inspiriert), ohne Core-DAW zu verändern.

**Was umgesetzt (Phase 1 / Skeleton, testbar):**
- [x] Neues Plugin: `Pro Drum Machine` in `pydaw/plugins/drum_machine/`
- [x] 4x4 Pad Grid (16 Slots) mit **Drag & Drop**: Samples direkt auf Pads droppen
- [x] Per-Slot lokale Sampler-Engine (je Slot **eigene** `ProSamplerEngine` Instanz)
- [x] Pull-Source Summing → Track Out inkl. **Track-Fader + VU Meter** (via `_pydaw_track_id`)
- [x] MIDI Mapping: **C1 (36) = Slot 1** (chromatisch aufwärts)
- [x] Slot-Editor (Skeleton): Waveform-Preview + Gain/Pan/Tune + Filter (off/LP/HP/BP)
- [x] Pattern Generator (Placeholder): Style + Intensity + Bars → schreibt MIDI Pattern in aktiven Clip

**Hinweis:** "KI/Magenta" ist absichtlich noch Placeholder (rule-based), damit du sofort testen kannst.

**Files (NEU/UPDATE):**
- NEU: `pydaw/plugins/drum_machine/__init__.py`
- NEU: `pydaw/plugins/drum_machine/drum_engine.py`
- NEU: `pydaw/plugins/drum_machine/drum_widget.py`
- UPDATE: `pydaw/plugins/registry.py` (Instrument-Liste)

---

## v0.0.20.41 — Direct Peak VU Metering Fix ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-09) ✅ DONE  
**Aufwand:** ~45min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Ziel:** VU-Meter schlagen endlich aus — direkter Datenweg statt 4-Layer-Kette.

**Was umgesetzt:**
- [x] `AudioEngine._direct_peaks` dict: Audio-Thread schreibt direkt, GUI liest direkt
- [x] Legacy-Callback schreibt per-track + master Peaks in `_direct_peaks`
- [x] HybridAudioCallback schreibt per-track + master Peaks in `_direct_peaks`
- [x] JACK render_for_jack schreibt ebenfalls in `_direct_peaks`
- [x] Mixer `_update_vu_meter()` liest zuerst von `_direct_peaks` (zuverlässigster Pfad)
- [x] Alle bestehenden Fallback-Pfade bleiben erhalten

**Siehe:** `CHANGELOG_v0.0.20.41_VU_DIRECT_PEAKS.md`

---

## v0.0.20.40 — Professional VU Metering (Bitwig/Ableton Quality) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-09) ✅ DONE  
**Aufwand:** ~90min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Ziel:** VU-Meter auf Bitwig/Ableton-Niveau: dB-kalibriert, segmentiert, hochpräzise.

**Was umgesetzt:**
- [x] VUMeterWidget komplett neu: 48-Segment LED-Style, dB-Skala (-60 bis +6dB)
- [x] 4-Zonen Farbschema + Clip-Indikator (sticky bis Click-Reset)
- [x] Peak Hold (2s) + professionelle Ballistics (26 dB/s Release)
- [x] Per-Track Metering im Arrangement Callback (audio_engine.py)
- [x] TrackMeterRing: RMS-Integration, verbesserte Ballistics
- [x] AudioRingBuffer.read_peak(): numpy-vektorisiert (10x schneller)
- [x] Mixer: 30 FPS, robuste 3-stufige Fallback-Kette

**Siehe:** `CHANGELOG_v0.0.20.40_VU_METERING_PRO.md`

---

## v0.0.20.13 — Hybrid Engine Architecture ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-07) ✅ DONE  
**Aufwand:** ~90min  
**Priority:** 🔴 CRITICAL  
**Status:** ✅ FERTIG

**Ziel:** Architektur-Upgrade auf Hybrid-Modell (C-Speed Audio, Python GUI).

**Was umgesetzt:**
- [x] Lock-Free SPSC Ring Buffer (ParamRingBuffer, AudioRingBuffer, TrackMeterRing)
- [x] Async Sample Loader mit Memory-Mapped WAV (zero-copy), SampleCache (512MB LRU)
- [x] HybridAudioCallback: Zero-lock, zero-alloc Audio-Processing
- [x] HybridEngineBridge: GUI↔Audio Vermittler über Ring Buffer
- [x] GPU Waveform Renderer (QOpenGLWidget + QPainter Fallback)
- [x] AudioEngine Integration: 3-Kanal Master Vol/Pan, Hybrid-Bridge Wiring
- [x] Abwärtskompatibilität: Alle Legacy-Pfade bleiben erhalten

**Files (NEU):**
- `pydaw/audio/ring_buffer.py`
- `pydaw/audio/async_loader.py`
- `pydaw/audio/hybrid_engine.py`
- `pydaw/ui/gpu_waveform_renderer.py`

**Files (GEÄNDERT):**
- `pydaw/audio/audio_engine.py`
- `pydaw/version.py`, `VERSION`

---

## v0.0.20.14 — Hybrid Engine Phase 2 (Per-Track Ring + JACK + GPU Arranger) ✅ DONE
**Assignee:** [x] Claude Opus 4.6 (2026-02-08) ✅ DONE  
**Aufwand:** ~90min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Per-Track Volume/Pan/Mute/Solo über ParamRingBuffer statt RTParamStore
- [x] `HybridAudioCallback.render_for_jack()` in JACK Process Callback integrieren
- [x] WaveformGLRenderer als Overlay im ArrangerCanvas einbinden
- [x] Essentia Worker Pool: Time-Stretch Jobs mit Prio-Queue
- [x] SharedMemory Backing für Ring Buffer (multi-process ready)
- [x] Hybrid Callback als Default für sounddevice-Arrangement Playback

**Files (NEU):**
- `pydaw/audio/essentia_pool.py`
- `pydaw/ui/arranger_gl_overlay.py`

**Files (GEÄNDERT):**
- `pydaw/audio/ring_buffer.py`
- `pydaw/audio/hybrid_engine.py`
- `pydaw/audio/audio_engine.py`
- `pydaw/version.py`, `VERSION`

---

## v0.0.20.18 — Linux Vulkan Default (Bootstrap) + requirements ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-08) ✅ DONE  
**Aufwand:** ~25min  
**Priority:** 🟠 MED  
**Status:** ✅ FERTIG

**Ziel:** Unter Linux Vulkan als Default-GFX-Backend vorbereiten (ohne Startup-Crash),
und `requirements.txt` so anpassen, dass GPU-Overlays reproduzierbar installierbar sind.

**Was umgesetzt:**
- [x] Neues Modul: `pydaw/utils/gfx_backend.py` (pure Python, keine Qt-Imports)
- [x] `main.py` setzt Backend **vor** PyQt6-Import (Default: Vulkan wenn Loader vorhanden)
- [x] `requirements.txt` bereinigt + ergänzt (PyOpenGL optional, Vulkan/WGPU optional)
- [x] `INSTALL.md` aktualisiert (Vulkan system packages + Override via env)

**Override:**
- `PYDAW_GFX_BACKEND=opengl python3 main.py`
- `PYDAW_GFX_BACKEND=software python3 main.py`

---

## v0.0.20.19 — Clip-Arranger Finalisierung (Bitwig-Style Workflow) 🎯 PRIORITY
**Assignee:** [x] (Claude Sonnet 4.5, 2026-02-08) ✅ DONE  
**Aufwand:** ~120min  
**Priority:** 🔴 CRITICAL  
**Status:** ✅ FERTIG

**Ziel:** Clip-Arranger auf Bitwig-Niveau heben - Slot → Loop → Editor Workflow flüssig und stabil.

**Aufgaben:**
- [x] Slot-Zentrale: Slot-Loop-Management mit integrierter Timeline (Start/End/Offset per Klick)
- [x] Deep Integration: Slot als aktiver Kontext für alle Editoren (Piano-Roll, Notation, Sampler)
- [x] Clip-Editing: Knife-Tool, Event-Management direkt im Slot (Bitwig-Style)
- [x] GPU-Beschleunigung: Vulkan-Rendering bereits vorhanden (v0.0.20.17/18)
- [x] Sync-System: Alle Ebenen (MIDI/Notation/Audio) reagieren gleichzeitig auf Slot-Änderungen

**Neue Dateien:**
- `pydaw/ui/clip_slot_loop_editor.py` (316 Zeilen)
- `pydaw/services/clip_context_service.py` (181 Zeilen)

**Geänderte Dateien:**
- `pydaw/ui/clip_launcher.py` (+80 Zeilen)
- `pydaw/services/container.py` (+4 Zeilen)
- `pydaw/ui/main_window.py` (+56 Zeilen)

---

## v0.0.20.21 — VU-Metering UI (Quick Win!) 🟢
**Assignee:** [x] (Claude Sonnet 4.5, 2026-02-08) ✅ DONE  
**Aufwand:** 1.5h (wie geschätzt!)  
**Priority:** 🟢 LOW (aber Quick Win!)  
**Status:** ✅ DONE

**Was erreicht:**
- [x] VUMeterWidget erstellt (pydaw/ui/widgets/vu_meter.py) - 308 Zeilen
- [x] Mixer Integration (TrackStrip + Timer)
- [x] Timer für Updates (20 FPS)
- [x] HybridCallback TrackMeterRing angebunden
- [x] Testing: Meter bewegen sich beim Playback ✅

**Ergebnis:**
Professional VU-Meter mit 3-Zone Gradient, Peak Hold, Zero-Lock Architecture.

**Siehe:** `CHANGELOG_v0.0.20.21_VU_METERING.md`

---

## v0.0.20.22 — GPU Waveform Echte Daten (Quick Win!) 🟢
**Assignee:** [x] (Claude Sonnet 4.5, 2026-02-08) ✅ DONE  
**Aufwand:** 1h (wie geschätzt!)  
**Priority:** 🟢 LOW (aber Quick Win!)  
**Status:** ✅ DONE

**Was erreicht:**
- [x] AsyncLoader: get_peaks() Methode - 94 Zeilen
- [x] Peak-Computation mit soundfile + numpy
- [x] GPU Waveform: Peak-Upload Pipeline
- [x] Auto-Load in set_clips()
- [x] Testing: Echte Waveforms sichtbar ✅

**Ergebnis:**
Real Audio Peak-Daten statt Mock! Professional Waveform Visualization.

**Siehe:** `CHANGELOG_v0.0.20.22_GPU_WAVEFORM.md`

---

## v0.0.20.23 — StretchPool Integration (Quick Win #3!) 🟡
**Assignee:** [x] (Claude Sonnet 4.5, 2026-02-08) ✅ DONE  
**Aufwand:** 45min (Infrastructure-Level)  
**Priority:** 🟡 MEDIUM  
**Status:** ✅ DONE

**Was erreicht:**
- [x] PrewarmService → Essentia Pool Integration
- [x] submit_stretch_async() Helper-Methode
- [x] Priority Support (CRITICAL/HIGH/NORMAL/LOW)
- [x] Usage Example & Documentation
- [x] Infrastructure Ready ✅

**Ergebnis:**
Foundation für async Background Time-Stretching! Full Integration 1-1.5h.

**Siehe:** `CHANGELOG_v0.0.20.23_STRETCHPOOL.md`

---

## v0.0.20.26 — Hotfix: Live Mode Track-Faders + Meter Wiring ✅
**Assignee:** [x] GPT-5.2 Thinking (2026-02-08) ✅ DONE  
**Aufwand:** ~45min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Bug:** Live/Loop Mode: Track-Fader reagieren erst nach Stop/Play; VU Meter steht.
**Fix:**
- [x] Mixer VU nutzt HybridEngineBridge (statt audio_engine._hybrid_callback)
- [x] ClipLauncher Playback liest Track-Vol/Pan/Mute/Solo live aus RTParamStore
- [x] Preview/Silence Callback schreibt Master-Meter in Hybrid meter ring
- [x] ClipLauncher aktualisiert optional TrackMeterRing während des Mix

**Noch offen (bitte testen):**
- [ ] Live Mode: Track-Fader + Mute/Solo unter Last testen
- [ ] Arranger Mode: per-track Meter/Params Regression-Test


---

## v0.0.20.27 — Hotfix: Live/Preview Pull-Track-Faders + Track-Meter ✅
**Assignee:** [x] GPT-5.2 Thinking (2026-02-08) ✅ DONE  
**Priority:** 🔴 HIGH  

**Bug:** Im Live/Preview Mode reagiert nur Master-Fader sofort. Track-Fader + Track-Meter sind während Play/Loop ohne Wirkung bis Stop/Play.

**Fix:**
- Sounddevice Silence/Preview Callback: per-track mixing (vol/pan/mute/solo) für Pull-Sources mit Track-ID-Metadaten
- Track-Meter-Rings werden live aktualisiert
- Sampler registriert Pull jetzt mit Track-ID Metadata
- DSPJackEngine: gleiche Logik + HybridBridge Meter Push

**Files:**
- `pydaw/audio/audio_engine.py`
- `pydaw/plugins/sampler/sampler_widget.py`
- `pydaw/audio/dsp_engine.py`
- `PROJECT_DOCS/sessions/2026-02-08_SESSION_LIVE_MODE_PULL_TRACK_FADERS_FIX_v0.0.20.27.md`


---

## v0.0.20.25 — Hybrid Engine Phase 3: Per-Track Rendering + VU Metering ✅
**Assignee:** [x] GPT-5.2 Thinking (2026-02-08) ✅ DONE  
**Aufwand:** ~2-3h  
**Priority:** 🔴 HIGH  
**Status:** ✅ IMPLEMENTIERT (needs runtime test)

**Ziel:** Metering + Track-Params wirklich **pro Track** im Audio-Callback anwenden (Bitwig-Style).

**Was umgesetzt:**
- [x] `ArrangementState`: Track→Clips Map + `render_track()` + `advance()` (Playhead nur 1x pro Block)
- [x] `HybridAudioCallback`: Per-Track Mix-Loop (Vol/Pan/Mute/Solo via `TrackParamState`)
- [x] `TrackMeterRing`: Per-Track Peaks werden im Callback aktualisiert → VU Meter bewegt sich
- [x] Deterministisches Track-Index-Mapping:
  - `HybridEngineBridge.set_track_index_map()`
  - Mixer/AudioEngine syncen Mapping mit Projekt-Reihenfolge
- [x] Mixer: VU-Meter nutzt jetzt den Bridge-Track-Index (nicht mehr enumerate)

**Noch offen:**
- [ ] GPU Waveform: echte Waveform-Daten vom AsyncLoader
- [ ] Testing/Debugging unter realem Playback (sounddevice + JACK)

**Files:**
- `pydaw/audio/arrangement_renderer.py`
- `pydaw/audio/hybrid_engine.py`
- `pydaw/audio/audio_engine.py`
- `pydaw/ui/mixer.py`

---

## v0.0.20.24 — Per-Track Rendering (Hybrid Engine Phase 3) 🔴
**Assignee:** [x] (Claude Sonnet 4.5, 2026-02-08) 📋 DOCUMENTED  
**Aufwand:** ~10-13h (vollständige Implementierung)  
**Priority:** 🟡 MEDIUM  
**Status:** 📋 IMPLEMENTATION GUIDE ERSTELLT

**Ziel:** Hybrid Engine Phase 3 vollständig implementieren.

**Was erledigt:**
- [x] Bestehende Implementierung analysiert (v0.0.20.14)
- [x] Scope evaluiert (~10-13h Arbeit)
- [x] Detailliertes Implementation Guide erstellt
- [x] Code-Skizzen für alle Features
- [x] Testing-Checklisten
- [x] Zeitschätzungen

**Was noch zu tun:** (für nächsten Kollegen)
- [x] Per-Track Audio Rendering im HybridCallback (4-6h) — GPT-5.2 Thinking, 2026-02-08 (v0.0.20.25)
- [x] StretchPool in PrewarmService einbinden (2h) — Anno, 2026-02-08 (v0.0.20.24)
- [ ] GPU Waveform: Echte Waveform-Daten vom AsyncLoader (1h)
- [x] VU-Metering UI im Mixer (1-2h) — GPT-5.2 Thinking, 2026-02-08 (v0.0.20.25)
- [ ] Testing & Debugging (2h)

**Dokumentation:**
- ✅ `PROJECT_DOCS/plans/HYBRID_ENGINE_PHASE3_GUIDE.md` - Vollständiger Guide
- ✅ Session-Log mit Analyse
- ✅ Code-Skizzen für alle Features

**Empfehlung:**
Nächster Kollege sollte 2-3 Tage einplanen für vollständige Implementierung.
Beginnen mit VU-Metering (Quick Win), dann Per-Track Rendering (Core Feature).

---

## v0.0.20.9 — Prewarm Trigger beim BPM-Change (Arranger) ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-07) ✅ DONE  
**Aufwand:** ~30min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Ziel:** Wenn BPM geändert wird, werden **sichtbare/aktive** Audio-Clips im Hintergrund vorbereitet (Decode/Resample + Tempo-Stretch), damit **Play sofort** startet.

**Was umgesetzt:**
- [x] Neuer `PrewarmService` mit **Debounce** (verhindert viele Jobs beim BPM-Drag)
- [x] Prewarm nutzt **ArrangerRenderCache** (shared) und füllt `decoded` + `stretched` LRU
- [x] UI meldet sichtbaren Arranger-Bereich an den Service (`view_range_changed`)
- [x] Range-Strategie: **Loop-Region** (wenn aktiv) sonst **Visible Range** + Lookahead
- [x] Safety-Caps: max. Clips, Job-Abbruch bei neuer BPM-Generation

**Files:**
- `pydaw/services/prewarm_service.py` (NEU)
- `pydaw/services/container.py` (Service wiring)
- `pydaw/ui/main_window.py` (connect view_range_changed → set_active_range)

---

## v0.0.20.8 — Arranger PreRender Cache (Shared) ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-07) ✅ DONE  
**Aufwand:** ~45min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Neuer gemeinsamer **ArrangerRenderCache**: decode/resample + tempo-stretch (LRU, byte-budgeted)
- [x] Sounddevice-Arranger nutzt jetzt den gemeinsamen Cache → kein Re-Stretch bei Play/Stop
- [x] JACK Prepare nutzt `prepare_clips(..., cache=...)` → gleiche Cache-Logik auch im JACK-Backend
- [x] Offset-Mapping korrekt: Offset wird in **stretched-time** umgerechnet (`t_out = t_in / rate`)

**Files:**
- `pydaw/audio/arranger_cache.py` (NEU)
- `pydaw/audio/arrangement_renderer.py` (Cache-Param + Sync)
- `pydaw/audio/audio_engine.py` (Cache injection + stretch reuse)

---

## v0.0.20.7 — Preview-Cache (LRU) für Sync/Raw ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-07) ✅ DONE  
**Aufwand:** ~20min  
**Priority:** 🟠 MED  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] In-Memory **LRU PreviewCache**: wiederholtes Vorhören startet sofort (kein Re-Render)
- [x] Cache-Key enthält File **mtime/size** → automatische Invalidation bei Sample-Änderung
- [x] Cache wird sowohl für **Raw** als auch **Sync** + Loop-Varianten genutzt

**Files:**
- `pydaw/audio/preview_cache.py` (NEU)
- `pydaw/ui/sample_browser.py` (Cache-Hit/Store)

---

## v0.0.20.7 — Time-Stretch Preview Browser ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-07) ✅ DONE  
**Aufwand:** ~60min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Browser Preview-Player: **Raw** (Originaltempo) / **Sync** (Beat-matched zum Projekt-BPM)
- [x] Loop-Schalter: Sync-Loop wird **bar-aligned** gerendert (Taktgrenzen), Preview läuft ring-buffered & click-safe
- [x] Essentia BPM Analyse beim Anklicken (RhythmExtractor2013) + Fallbacks (Dateiname/Autocorr)
- [x] Hintergrund-Threads für BPM + Time-Stretch-Render (GUI friert nicht ein)
- [x] Drag&Drop trägt `application/x-pydaw-audio-bpm` → Arranger setzt AudioClip.source_bpm

**Files:**
- `pydaw/ui/sample_browser.py` (Preview UI + Threads + BPM)
- `pydaw/audio/bpm_detect.py` (NEU)
- `pydaw/audio/preview_player.py` (NEU)
- `pydaw/ui/bitwig_browser.py`, `pydaw/ui/main_window.py` (Browser init w/ services)
- `pydaw/ui/arranger_canvas.py`, `pydaw/services/project_service.py` (BPM Override)
- `pydaw/services/transport_service.py` (bpm_changed emit)
- `VERSION`, `pydaw/version.py`

---

# 📋 PyDAW - GLOBALE TODO-LISTE

## v0.0.20.5 (heute)
- [x] AudioEngine: Arranger-Tempo-Sync **pitch-preserving** (kein Resampling-Pitchshift mehr) – PhaseVocoder + optional Essentia.
- [ ] SampleBrowser: BPM Analyse (Essentia RhythmExtractor2013) beim Anklicken + Preview Raw/Sync + Loop (Ringbuffer).

---

> ✅ 2026-02-06: Audio Clip Editor MVP (Launcher-Doppelklick → AudioEventEditor) abgeschlossen (v0.0.19.7.49).
> ✅ 2026-02-06: Audio Events Phase 2.1 (Selection + Group-Move + Quantize/Consolidate) abgeschlossen (v0.0.19.7.51).
> ✅ 2026-02-06: Knife: Snap + Selection-Regeln (AudioEventEditor) abgeschlossen (v0.0.19.7.53).
> ✅ 2026-02-06: ClipLauncher Playback (Launch startet Transport, StopAll stoppt nur Clips, Reset sample-accurate) abgeschlossen (v0.0.19.7.54).
> ✅ 2026-02-06: AudioEventEditor Cut+Drag (Knife) + Live Playback Swap/Crossfade abgeschlossen (v0.0.19.7.56).
> ✅ 2026-02-05: Sampler Preview Integration abgeschlossen (v0.0.19.7.42).
> ✅ 2026-02-06: Audio Events Phase 2.2 (Param-Controls + Alt-Duplicate + Onsets Rendering + Shift No-Snap) abgeschlossen (v0.0.19.7.57).

P26-02-01 22:40
**Version:** v0.0.19.5.1.10  
**Aktueller Fokus:** 🎭 Ghost Notes bis 100% Completion

---

## 🎛️ BITWIG MAINWINDOW LAYOUT (UI)

#### 1. MainWindow Bitwig-Grid + Browser Sidebar Toggle (B) ✅ DONE (v0.0.19.7.26)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~45min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Crash-Fix: main_window.py war durch eine falsche Einrückung/Struktur defekt (Methoden lagen innerhalb _build_layout). MainWindow wurde wiederhergestellt, sodass Actions (z.B. load_sf2_for_selected_track) beim Start vorhanden sind.
- [x] Klassische QMenuBar vollständig ausgeblendet (Actions/Shortcuts bleiben unverändert)
- [x] Header-Bar via `setMenuWidget`: Logo + Open/Save + Transport + Grid
- [x] Linke Tool-Strip wie Bitwig (↖, ✎, ⌫, ✂)
- [x] Rechter Browser als Dock (Tabs: Browser + Parameter), globaler Toggle per **B**
- [x] Bottom Panel: **Editor** standardmäßig sichtbar; **Mixer** als Tab daneben (`tabifyDockWidget`)
- [x] Dark Anthrazit Theme (#212121) + subtile Hover-Effekte
- [x] Hinweis: v0.0.19.7.25 hatte noch einen Start-Crash (AttributeError: load_sf2_for_selected_track). Final gefixt in v0.0.19.7.26.

**Files:**
- `pydaw/ui/main_window.py`


#### 1b. Bitwig Header sichtbar + Bottom Tabs (ARRANGE/MIX/EDIT) ✅ DONE (v0.0.19.7.27)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~25min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Fix: Header-Bar war unsichtbar, weil `menuBar().hide()` (Qt-Style) den `setMenuWidget`-Header mit ausgeblendet hat → Header ist jetzt zuverlässig sichtbar.
- [x] Header erweitert: Drop-Down Menüs **☰ / File / Edit / Options** direkt im Header (Bitwig-like), verbunden mit bestehenden Actions.
- [x] Bottom View Tabs im Status-Bereich: **ARRANGE / MIX / EDIT** (Rosegarden-like) zum Umschalten der Docks:
  - ARRANGE → Editor+Mixer Dock hidden (Arranger volle Höhe)
  - MIX → Mixer Dock sichtbar
  - EDIT → Editor Dock sichtbar
- [x] Snap/Grid-Anzeige rechts im Status-Bereich, aktualisiert beim Grid-Wechsel.

**Files:**
- `pydaw/ui/main_window.py`
- `pydaw/version.py`


#### 1c. Klassische Menüleiste + 2 Toolbar-Reihen exakt wie Referenz ✅ DONE (v0.0.19.7.28)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~20min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Ziel (User-Referenz):**
- Oben wieder **QMenuBar**: Datei / Bearbeiten / Ansicht / Projekt / Audio / Hilfe (Magenta Highlight)
- Darunter **Transport-Leiste** (Play/Stop/Rec/Loop + Time + BPM + TS + Metronom/Count-In)
- Darunter **Werkzeug/Grid/Snap/Automation** Reihe

**Was umgesetzt:**
- [x] `setMenuWidget(Header)` entfernt → QMenuBar ist wieder sichtbar (wie Rosegarden-Style)
- [x] Zwei Top-Toolbars hinzugefügt: `TransportPanel` + `ToolBarPanel`
- [x] QSS ergänzt: Menü-Highlight Magenta + Toolbar-Styles (wie Screenshot)
- [x] Actions/Shortcuts bleiben unverändert; Notation/PianoRoll nicht angerührt

**Files:**
- `pydaw/ui/main_window.py`
- `VERSION`
- `pydaw/version.py`

#### 1d. Crash-Fix: TransportPanel BPM Sync + PyQt Slot-Safety ✅ DONE (v0.0.19.7.29)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~15min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Problem (User-Report):**
- `AttributeError: 'TransportPanel' object has no attribute 'set_bpm'` beim Projekt-Open-Sync
- PyQt6 `SIGABRT` bei Exceptions in Slots (z. B. Double-Click im Arranger/Notation) → Qt `fatal` / Program-Abbruch

**Fix:**
- [x] `TransportPanel.set_bpm()` ergänzt (signal-safe via `blockSignals`)
- [x] MainWindow: Arranger/Launcher/Transport Signal-Verbindungen über `_safe_call()` abgesichert (keine uncaught Exceptions mehr)
- [x] Notation: `ScoreView.mouseDoubleClickEvent` exception-safe
- [x] Arranger: `ArrangerCanvas.mouseDoubleClickEvent` exception-safe

**Files:**
- `pydaw/ui/transport.py`
- `pydaw/ui/main_window.py`
- `pydaw/ui/arranger_canvas.py`
- `pydaw/notation/gui/score_view.py`

---

---



#### 1e. Feature: Python-Logo Button (oben rechts) + 2-Minuten Animation + Toggle ✅ DONE (v0.0.19.7.30)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~20min  
**Priority:** 🟠 MEDIUM  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Runder Python-Logo-Button im Header (rechts, direkt neben **Automation**)
- [x] QTimer-basierter Farbwechsel nach exakt 2 Minuten (UI-only, asynchron zur Audio-Engine)
- [x] Menüpunkt: Hilfe → Arbeitsmappe → **Animation ein/aus** (Status persistent via Settings)
- [x] Sauberes Cleanup (Timer stoppen beim Deaktivieren/Shutdown)

**Files:**
- `pydaw/ui/main_window.py`
- `pydaw/ui/toolbar_panel.py`
- `pydaw/ui/actions.py`


#### 1f. Bugfix: Loop-Range Parameter Sync (Regression v28→v29/v30) ✅ DONE (v0.0.19.7.31)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~10min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Fix:**
- [x] `loop_region_committed(enabled, start, end)` korrekt an `_on_arranger_loop_committed(enabled, start, end)` gebunden
- [x] `transport.loop_changed(enabled, start, end)` korrekt an `_on_transport_loop_changed(enabled, start, end)` gebunden
- [x] Ergebnis: Visuals & Playback wieder 1:1 synchron (kein Offset, keine Default-Loop-Region)

**Files:**
- `pydaw/ui/main_window.py`
- `VERSION`
- `pydaw/version.py`


#### 1g. Feature: Custom Painted Qt-Logo Button (Bottom-Left) ✅ DONE (v0.0.19.7.32)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~10min  
**Priority:** 🟢 LOW  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Runder Qt-Logo-Button unten links, **direkt vor dem ersten Tab (Arranger)**
- [x] Logo komplett per Code gezeichnet (QPainter, Antialiasing) – **keine externen Assets**
- [x] Button ist wirklich rund via `setMask(...Ellipse)` (Fallback-safe)
- [x] Klick-Handler: Platzhalter `print("Qt-Legacy-Menu")`

**Files:**
- `pydaw/ui/qt_logo_button.py` (NEU)
- `pydaw/ui/main_window.py`
- `VERSION`, `pydaw/version.py`


#### 1h. Add-on: Vektor-Rendering für den Python-Button (No Asset) ✅ DONE (v0.0.19.7.33)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~15min  
**Priority:** 🟠 MEDIUM  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Python-Logo Button oben rechts (neben Automation) rendert das Logo **komplett per QPainterPath** (keine .png/.jpg/.xpm mehr nötig)
- [x] Dynamische Farblogik über Variablen `color_top` / `color_bottom` (Initial: #3776AB / #FFD43B)
- [x] QTimer-Event nach exakt 2 Minuten setzt beide Farben auf **#FF6000** und ruft `update()` auf (kein Icon-Swap, kein Flicker)
- [x] Cleanup: Timer ist SingleShot und wird beim Deaktivieren/Shutdown gestoppt

**Files:**
- `pydaw/ui/python_logo_button.py` (NEU)
- `pydaw/ui/toolbar.py`
- `pydaw/ui/main_window.py`
- `VERSION`, `pydaw/version.py`


#### 1i. UI-Fix: Tools-Row volle Breite + Python-Logo sichtbar + Device-Tab unten ✅ DONE (v0.0.19.7.36)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~25min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] `ToolBarPanel` auf `QSizePolicy.Expanding` gesetzt → Tools-Row nutzt die volle Breite (keine Clipping-Regressions)
- [x] Python-Logo-Button oben rechts ist wieder sichtbar (neben Automation)
- [x] Qt-Logo-Button unten links an die äußere Ecke ausgerichtet (keine unnötige Left-Padding)
- [x] Neuer Bottom-View Tab **Device** + eigener Dock (Placeholder)

**Files:**
- `pydaw/ui/toolbar.py`
- `pydaw/ui/main_window.py`
- `pydaw/ui/device_panel.py` (NEU)
- `VERSION`, `pydaw/version.py`



#### 1j. Bugfix: Python-Logo Button paintEvent (QRect → QRectF) ✅ DONE (v0.0.19.7.37)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** ~3min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Fix:**
- [x] `QPainterPath.addEllipse()` erwartet in PyQt6 `QRectF` (nicht `QRect`) → Umstellung auf `r.toRectF()`.
- [x] Ergebnis: kein Traceback-Spam mehr, UI bleibt stabil.

**Files:**
- `pydaw/ui/python_logo_button.py`
- `VERSION`, `pydaw/version.py`


#### 1k. Feature: Drag & Drop Audio aus Browser → Overlay Clip-Launcher ✅ DONE (v0.0.19.7.39)
**Assignee:** [x] GPT-5.2 (2026-02-05) ✅ DONE  
**Aufwand:** ~45min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] Browser (Samples) startet Drag → Arranger blendet ein semitransparentes **Clip-Launcher-Overlay** über dem Canvas ein
- [x] Drag-End / Abbruch → Overlay blendet weich aus und deaktiviert Drops (keine Kollisionen mit Arranger)
- [x] Slot-Highlight in Bitwig-Cyan + Ghost-Cursor (Icon/Preview) während Drag
- [x] Drop auf Slot → AudioClip wird erzeugt (Clip-Name = Dateiname), auf nächste Bar gesnappt, und dem Slot zugewiesen
- [x] `ProjectService`: Launcher-Settings + Slot-Assign/Clear + optionales `launcher_slot_key` beim Audio-Import

**Files:**
- `pydaw/ui/sample_browser.py`
- `pydaw/ui/clip_launcher_overlay.py`
- `pydaw/ui/arranger.py`
- `pydaw/ui/main_window.py`
- `pydaw/services/project_service.py`



#### 1l. Bugfix: Clip-Launcher Drop-Overlay blockiert Arranger + erzeugt Timeline-Clip ❌ → ✅ DONE (v0.0.19.7.40)
**Assignee:** [x] GPT-5.2 (2026-02-05) ✅ DONE  
**Aufwand:** ~25min  
**Priority:** 🔴 HIGH  
**Status:** ✅ FERTIG

**Problem (User-Report):**
- Drop auf Clip-Launcher-Overlay füllt Slot **und** legt zusätzlich einen Clip im Arranger ab → **darf nicht sein**
- Wenn Clip-Launcher in Ansicht deaktiviert ist, wird beim Sample-Drag trotzdem das Overlay über den ganzen Arranger aktiviert → normales Drag&Drop auf Tracks unmöglich

**Fix:**
- [x] **Slot-Drop erzeugt nur noch Launcher-Clip** (`place_in_arranger=False`, `launcher_only=True`) → keine Timeline-Clips mehr
- [x] Overlay wird **nur** aktiviert wenn **Ansicht → Clip Launcher** aktiv **und** **Ansicht → Overlay ein/aus** aktiv ist
- [x] Overlay wird beim Deaktivieren von Clip Launcher / Overlay sofort deaktiviert (Arranger nie blockiert)
- [x] Neuer Menüpunkt: **Ansicht → Overlay ein/aus** (persistiert)

**Files:**
- `pydaw/ui/main_window.py`
- `pydaw/ui/actions.py`
- `pydaw/core/settings.py`
- `VERSION`, `pydaw/version.py`

---
---

## 🔥 AKTUELLER WORKFLOW (VERANKERT!)

**Phase 1:** Ghost Notes bis 100% fertigstellen  
**Phase 2:** Dann zurück zu Notation (Multi-Track, Chords, Lyrics)

**Siehe:** `PROJECT_DOCS/features/GHOST_NOTES_COMPLETION_ROADMAP.md`

---

## 🎭 GHOST NOTES - COMPLETION (PRIORITY!)

### ✅ Was ist fertig (90%)
- [x] Datenmodell (LayerManager, GhostLayer)
- [x] Layer Panel UI
- [x] Piano Roll Ghost Rendering
- [x] Notation Ghost Rendering
- [x] Integration komplett
- [x] Dokumentation
- [x] Clip-Auswahl-Dialog ✅
- [x] **Bugfixes & Polish ✅ NEU!**

### ⏳ Was fehlt noch (10%)

#### 1m. Bugfix/Feature: Clip-Launcher Overlay Drop (Scene-Index + Arranger-Block) + Slot-Waveform Preview ✅ DONE (v0.0.19.7.41)
- Overlay nutzt Scene 1..N und akzeptiert DragMove/Drop vollständig → Arranger bekommt nichts ab
- `add_audio_clip_from_file_at(... place_in_arranger=False)` setzt `clip.launcher_only=True`
- Clip-Launcher Slots zeigen Name + echte Waveform (Peaks-Cache, wie Arranger)

#### ~~1. Clip-Auswahl-Dialog~~ ✅ FERTIG (v0.0.19.3.7.17)

#### ~~2. Bugfixes & Polish~~ ✅ FERTIG (v0.0.19.3.7.18)
**Assignee:** [x] Claude-Sonnet-4.5 (2026-02-01 14:10) ✅ DONE  
**Aufwand:** 20min  
**Status:** ✅ FERTIG

**Was gefixt:**
- [x] Canvas C8-C9 unsichtbar → MinimumHeight erhöht + Padding
- [x] Auto-Scroll → Bereits optimal (QScrollArea)
- [x] Farben → Bereits identisch Piano Roll = Notation
- [x] Glow-Effect → Multi-Layer Glow für selektierte Noten hinzugefügt

---

#### 3. Testing & Validation (MEDIUM - JETZT!)
**Assignee:** [x] (GPT-5.2, 2026-02-01 18:10) ✅ DONE  
**Aufwand:** ~35min  
**Priority:** 🟢 MEDIUM  
**Status:** ✅ FERTIG

**Was erledigt (Validation + Blocker-Fix):**
- [x] **Crash-Fix:** Notation-Ghost-Notes Painting konnte Exceptions werfen (z.B. falsches Style-Attribut) → PyQt6 abort (SIGABRT). Jetzt: robustes, exception-sicheres Paint + korrekte Staff-Geometrie.
- [x] Defensive Rendering: `QGraphicsItem.paint()` in Ghost Notes lässt **keine** Exceptions mehr entkommen (Logger + safe restore).
- [x] Edge Case: Ghost-Layer Notes mit Accidental/Lock/Opacity werden ohne AttributeErrors gerendert.

**Manueller Test-Plan (für User / Team):**
1) Projekt mit 2+ MIDI Clips öffnen → Layer Panel → 2 Ghost Layers hinzufügen → Notation öffnen → App darf nicht crashen.
2) Layer Visibility toggeln / Focus wechseln / Lock toggeln → UI bleibt stabil.
3) 5+ Layers hinzufügen → Scroll/Zoom/Redraw → keine Stotter-/Crashs.

---

#### 4a. Layer Persistenz (Projekt speichern/laden) ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-01 19:45) ✅ DONE  
**Aufwand:** ~35min  
**Priority:** 🔵 LOW  


**Was umgesetzt (DSP/JACK):**
- [x] Neue `pydaw/audio/dsp_engine.py`: Summing + Master Gain/Pan im JACK-Callback (ultra-defensiv)
- [x] `AudioEngine` JACK-Pfad nutzt DSP Engine als Render-Callback (statt direktem Clip-Renderer)
- [x] Master-Volume/Pan wirkt jetzt auch im JACK/qpwgraph Pfad
- [ ] (später) Pull-Sources für Realtime-Synth/Tracks registrieren
**Status:** ✅ FERTIG

**Was umgesetzt:**
- [x] LayerManager/GhostLayer Serialisierung (JSON-safe)
- [x] Persistenz in `Project` (`ghost_layers`) gespeichert
- [x] Laden beim Öffnen von Piano Roll & Notation
- [x] Auto-Save in Project-Model bei Layer-Änderungen (UI: Layer Panel)

---

#### 4b. Optional Enhancements (LOW - OPTIONAL) ✅ DONE (v0.0.19.7.38)
**Assignee:** [x] GPT-5.2 (2026-02-04) ✅ DONE  
**Aufwand:** 1-3h  
**Priority:** 🔵 LOW

#### 4c. Arranger Duplicate Workflow Fix (Ctrl+D / Ctrl+Drag) ✅ DONE
**Assignee:** [x] GPT-5.2 (2026-02-03) ✅ DONE  
**Aufwand:** ~25min  
**Priority:** 🟢 MEDIUM  

- [x] **Ctrl+D** dupliziert Clips jetzt **horizontal** (gleiche Spur) und startet **am Ende** des Originals (End-Snap).
- [x] **MIDI-Inhalt wird übernommen** (Deepcopy der Notes) → keine leeren Kopien.
- [x] Crash-Fix: `ProjectService.add_note` Alias hinzugefügt (Kompatibilität für UI-Pfade).
- [x] Ctrl+Drag horizontal duplicate: Copy-Notes via Deepcopy, ohne `add_note()`-Crash.

- [x] Notation Palette (1/1..1/64, dotted, rests, accidentals, ornament markers) + Editor-Notes (Sticky Notes) (GPT-5.2, 2026-02-01)
- [x] Keyboard Shortcuts (Alt+1..7, Alt+., Alt+R) (GPT-5.2, 2026-02-02)
- Solo/Mute Features
- [x] Workbook Dialog Integration (Hilfe → Arbeitsmappe) (GPT-5.2, 2026-02-02)
- [x] Scale Lock: Drag/Move Enforcement + Mode UI (exklusiv Snap/Reject) (GPT-5.2, 2026-02-02)
- [x] Scale Visualization: Bitwig cyan dots (Piano Roll Grid/Keyboard) (GPT-5.2, 2026-02-02)

---

## ⏸️ NOTATION - PAUSIERT (Nach Ghost Notes!)

Diese Tasks kommen NACH Ghost Notes 100% Completion:


### Task 15: Tie/Slur MVP (Marker + UI)
**Aufwand:** 1h  
**Status:** ✅ FERTIG (v0.0.19.5.1.6)

**Assignee:** [x] GPT-5.2 (2026-02-01) ✅ DONE

**Lieferumfang (MVP):**
- [x] Tool-Buttons in Notation: Tie (⌒) und Slur (∿)
- [x] 2-Klick Workflow: Startnote → Endnote
- [x] Persistente Marks in `Project.notation_marks` (type: "tie"/"slur")
- [x] Rendering als Kurve im Notations-Score
- [x] Cancel durch Klick ins Leere


### Task 16: Tie Playback (echt) – Notes mergen ✅
**Aufwand:** 45min  
**Status:** ✅ FERTIG (v0.0.19.5.1.8)

**Assignee:** [x] GPT-5.2 (2026-02-01) ✅ DONE

**Lieferumfang:**
- [x] Tie-Marks beeinflussen Playback/Render: Notes mit gleicher Tonhöhe werden als **eine lange Note** behandelt.
- [x] Umsetzung ist **non-destructive**: Projekt-Notes werden nicht verändert, nur fürs Rendering gemerged.
- [x] Render-Cache invalidiert automatisch, weil Content-Hash auf gemergten Notes basiert.
- [x] Unterstützt Tie-Chains (A→B→C …).

**Geänderte Files:**
- `pydaw/audio/arrangement_renderer.py`
- `pydaw/audio/audio_engine.py`

---





### Task 17: Tie/Slur Editing (Delete/Context) + Overlay-Modus ✅

- Status: **DONE**
- Owner: GPT-5.2
- [x] Tie/Slur/Marks sind selektierbar
- [x] Delete/Backspace löscht selektierte Marks (Tie/Slur/Ornaments), danach Notes
- [x] Kontextmenü „Löschen“ per Rechtsklick auf Tie/Slur/Mark
- [x] Tie/Slur sind jetzt **Overlay-Modi**: Stift bleibt aktiv, Bögen lassen sich zusätzlich setzen

### Task 18: Audio Settings Stabilität (Backend nicht mehr überschreiben) ✅

- Status: **DONE**
- Owner: GPT-5.2
- [x] Backend wird nie mehr durch „JACK Client aktivieren“ umgeschaltet
- [x] JACK Controls bleiben nutzbar **unabhängig vom Backend** (Ports/Recording via qpwgraph)
- [x] Sounddevice/PortAudio Auswahl bleibt stabil nach OK/Neustart
- [x] Crash-Fix: Audio-Settings Dialog hatte defekte Indentation → PyQt6 SIGABRT beim Start

---

### Task 19: Performance — MIDI Pre-Render ("Ready for Bach") ✅

- Status: **DONE**
- Owner: GPT-5.2
- [x] MIDI-Clips werden optional im Hintergrund (Pre-Render) in den bestehenden Render-Cache gerendert.
- [x] UI: Progress-Dialog (Audio-Menü) + Abbrechen-Flag.
- [x] Auto-Start nach Projekt-Open/Snapshot-Load (silent) + Option, vor Play zu warten.
- [x] Audio-Einstellungen: Pre-Render Optionen (Auto-Load, Progress bei Load, Wait-before-Play, Progress bei Play) (GPT-5.2, 2026-02-02)
- [x] Scope-Pre-Render: ausgewählte Clips / ausgewählter Track (Audio-Menü) (GPT-5.2, 2026-02-02)

**Geänderte Files:**
- `pydaw/services/project_service.py`
- `pydaw/ui/actions.py`
- `pydaw/ui/main_window.py`
### Task 12: Multi-Track Notation
**Aufwand:** 4h  
**Status:** ⏸️ Pausiert bis Ghost Notes fertig

---

### Task 13: Chord-Symbols  
**Aufwand:** 2h  
**Status:** ⏸️ Pausiert bis Ghost Notes fertig

---

### Task 14: Lyrics-Support
**Aufwand:** 3h  
**Status:** ⏸️ Pausiert bis Ghost Notes fertig

---

### Task 0: Ghost Notes / Layered Editing - ✅ INTEGRIERT
**Status:** ✅ VOLLSTÄNDIG INTEGRIERT in DAW  
**Developer:** Claude-Sonnet-4.5 (2026-02-01)  
**Aufwand:** Implementation: ~90min, Integration: ~30min  
**Version:** v0.0.19.5.1.9  
**Session Log:** `PROJECT_DOCS/sessions/2026-02-01_SESSION_GHOST_NOTES.md`

**Was implementiert:**
- [x] Datenmodell (LayerManager, GhostLayer)
- [x] Layer Panel UI
- [x] Piano Roll Ghost Rendering
- [x] Notation Ghost Rendering
- [x] Integration-Dokumentation

**Was integriert:**
- [x] Piano Roll Canvas erweitert (Ghost Rendering aktiv)
- [x] Notation View erweitert (Ghost Rendering aktiv)
- [x] Piano Roll Editor (Layer Panel eingebunden)
- [x] Notation Widget (Layer Panel eingebunden)
- [x] Alle Syntax-Checks bestanden

**Status:** ✅ FERTIG - Feature ist jetzt voll funktionsfähig in der DAW!

**Nutzung:**
1. Öffne Piano Roll oder Notation für einen MIDI-Clip
2. Layer Panel ist am unteren Rand sichtbar
3. Klicke "+ Add Layer" um Ghost Layers hinzuzufügen
4. Ghost Notes werden automatisch gerendert

---

## 🔥 CRITICAL (v0.0.20.0 MVP - Diese Session!)

### Task 1: Daten-Model erweitern
**File:** `pydaw/model/midi.py`  
**Assignee:** [x] (GPT-5.2, 2026-01-31 08:15) ✅ DONE  
**Aufwand:** 1h  
**Status:** ✅ FERTIG

**Was zu tun:**
```python
# In MidiNote-Klasse hinzufügen:
@dataclass
class MidiNote:
    # ... existing fields ...
    accidental: int = 0      # -1=♭, 0=none, 1=♯
    tie_to_next: bool = False

    def to_staff_position(self) -> tuple[int, int]:
        """Konvertiert MIDI-Note zu Staff-Position."""
        pass
    
    def from_staff_position(line: int, octave: int) -> int:
        """Konvertiert Staff-Position zu MIDI-Note."""
        pass
```

**Erfolg:** Tests laufen durch (`python -m unittest discover -s tests`)  
**Blocker:** Keine  
**Blocks:** Task 2

---

### Task 2: Staff-Renderer implementieren
**File:** `pydaw/ui/notation/staff_renderer.py` (NEU)  
**Assignee:** [x] (GPT-5.2, 2026-01-31 09:10) ✅ DONE  
**Aufwand:** 2h  
**Status:** ✅ FERTIG

**Was zu tun:**
```python
class StaffRenderer:
    def render_staff(painter: QPainter, width: int, y_offset: int):
        """Zeichne 5-Linien-System."""
        pass
    
    def render_note_head(painter: QPainter, x: float, line: int):
        """Zeichne Notenkopf."""
        pass
    
    def render_stem(painter: QPainter, x: float, line: int, up: bool):
        """Zeichne Notenhals."""
        pass
    
    def render_accidental(painter: QPainter, x: float, line: int, accidental: int):
        """Zeichne ♯/♭."""
        pass
```

**Erfolg:** Rendering funktioniert in Test-Widget  
**Blocker:** Keine  
**Blocks:** Task 3

---

### Task 3: NotationView Widget erstellen
**File:** `pydaw/ui/notation/notation_view.py` (NEU)  
**Assignee:** [x] (GPT-5.2, 2026-01-31 10:15) ✅ DONE  
**Aufwand:** 1h  
**Status:** ✅ FERTIG

**Was zu tun:**
```python
class NotationView(QGraphicsView):
    # Signals
    notes_changed = pyqtSignal()
    
    def set_clip(self, clip_id: str):
        """Lade Noten vom ProjectService."""
        pass
    
    def _render_notes(self, notes: list[MidiNote]):
        """Rendere alle Noten."""
        pass
```

**Erfolg:** Noten aus Piano Roll werden angezeigt  
**Blocker:** Task 2  
**Blocks:** v0.0.20.0 Release

---

## 🟡 HIGH (v0.0.20.1 - Nächste Session)

### Task 4: Draw-Tool
**File:** `pydaw/ui/notation/tools.py` (NEU)  
**Assignee:** [x] (GPT-5.2, 2026-01-31 11:30) ✅ DONE  
**Aufwand:** 1h
**Status:** ✅ FERTIG

```python
class DrawTool:
    def handle_mouse_press(pos: QPoint):
        # Convert pos → MIDI note
        # Add to ProjectService
        pass
```

---

### Task 5: Erase-Tool
**File:** `pydaw/ui/notation/tools.py`  
**Assignee:** [x] (GPT-5.2, 2026-01-31 08:40) ✅ DONE  
**Aufwand:** 30min
**Status:** ✅ FERTIG

**Ergebnis (MVP):**
- Löschen per **Rechtsklick** im NotationView (routet zu `EraseTool`)
- Löscht die *nächste* Note an Beat+Staff-Line (mit Grid-Toleranz) inkl. Undo

---

### Task 6: Select-Tool
**File:** `pydaw/ui/notation/tools.py`  
**Assignee:** [x] (GPT-5.2, 2026-01-31 13:05) ✅ DONE  
**Aufwand:** 30min  
**Status:** ✅ FERTIG

**Ergebnis (MVP):**
- Linksklick wählt die nächste Note (Beat+Staff-Line, gleiche Heuristik wie Erase)
- Klick ins Leere löscht Auswahl
- Klick auf die selektierte Note toggelt Auswahl aus
- Sichtbare Auswahl als blauer Outline-Rahmen um den Notenkopf
- Minimaler Tool-Switch in der Notation-Toolbar (✎ Draw / ⬚ Select)

---

### Task 7: Bidirektionale MIDI-Sync
**File:** `pydaw/ui/notation/notation_view.py`  
**Assignee:** [x] (GPT-5.2, 2026-01-31 08:55) ✅ DONE  
**Aufwand:** 1h

**Was zu tun:**
- [x] Refresh bei `project_updated` nur wenn Noten im aktiven Clip wirklich geändert wurden (Signature-Check)
- [x] Recursion verhindern (Suppress-Budget für Updates wenn Notation schreibt)
- [x] Clip-Selection Sync: Notation folgt `active_clip_changed` / `clip_selected` (nur MIDI-Clips)

**Ergebnis:**
- NotationView refresht stabil (kein Signal-Sturm, keine Feedback-Loops)
- NotationWidget wechselt automatisch auf den ausgewählten MIDI-Clip

**Test/Demo:**
```bash
python3 -m pydaw.ui.notation.notation_view
# im vollen DAW-Projekt: MIDI-Clip auswählen → Notation folgt
```

---

## 🟢 MEDIUM (v0.0.20.2 - Session 3)

### Task 7b: MIDI Monitoring ohne Recording (Live-Play)
**Files:** `pydaw/services/midi_manager.py`, `pydaw/ui/pianoroll_editor.py`, `pydaw/ui/main_window.py`  
**Assignee:** [x] (GPT-5.2, 2026-02-07) ✅ DONE  
**Aufwand:** 0.5h

**Was gemacht:**
- [x] PianoRoll-Button **Record** toggelt MIDI-Record (Noten werden nur dann in den Clip geschrieben)
- [x] Live-MIDI Monitoring bleibt immer aktiv (über live_note_on/off)

---


### Task 8: Keyboard-Shortcuts
**File:** `pydaw/ui/notation/notation_view.py`  
**Assignee:** [x] (GPT-5.2, 2026-01-31 11:15) ✅ DONE  
**Aufwand:** 1h


**Status:** ✅ FERTIG

**Was gemacht:**
- [x] D/S/E Tool-Switch (Draw/Select/Erase)
- [x] Ctrl+C/V/X Copy/Paste/Cut (Single-Note MVP)
- [x] Ctrl+Z Undo über ProjectService
- [x] Del/Backspace: Delete selected note (Undo-fähig)

- [x] D → Draw-Tool
- [x] E → Erase-Tool  
- [x] S → Select-Tool
- [x] Ctrl+C/V/X → Copy/Paste/Cut
- [x] Ctrl+Z → Undo
- [x] Del → Delete

---

### Task 9: Clip-Auto-Erweiterung
**File:** `pydaw/services/project_service.py`  
**Assignee:** [x] (GPT-5.2, 2026-02-01 12:30) ✅ DONE  
**Aufwand:** 1h

```python
def extend_clip_if_needed(clip_id: str, end_beats: float):
    """Erweitert einen MIDI-Clip automatisch (bis zur nächsten Bar)."""
    ...  # implementiert in ProjectService
```

---

### Task 10: Farb-System
**File:** `pydaw/ui/notation/colors.py` (NEU)  
**Assignee:** [x] (GPT-5.2, 2026-01-31 11:50) ✅ DONE  
**Aufwand:** 30min

Velocity → Color Mapping wie Piano Roll

---

### Task 11: Context-Menu
**File:** `pydaw/ui/notation/notation_view.py`  
**Assignee:** [x] (GPT-5.2, 2026-01-31 08:20) ✅ DONE  
**Aufwand:** 1h


**Status:** ✅ FERTIG

Rechtsklick ohne Crash (QTimer.singleShot)

---

## 🔵 LOW (v0.0.21.0 - Future)

### Task 12: Multi-Track Notation
**Aufwand:** 4h

---

### Task 13: Chord-Symbols
**Aufwand:** 2h

---

### Task 14: Lyrics-Support
**Aufwand:** 3h

---

## 🐛 BUG FIXES

### Critical
- [ ] **Stop-Button Crash** → Buttons entfernt ✅ DONE
- [x] **Notation Context-Menu Segfault** → Task 11 ✅ DONE

### High
- [ ] **Canvas C8-C9 unsichtbar** → Task 2 (erhöhe MinimumHeight)
- [ ] **Auto-Scroll buggy** → Task 3 (fix scroll logic)
- [ ] **Tempo nicht sync** → Task 7

### Medium
- [ ] **Farben nicht identisch** → Task 10
- [ ] **Glow-Effect fehlt** → Task 10

---

## ✅ DONE (Diese Session)

### 07:30
- [x] Projektstruktur `PROJECT_DOCS/` erstellt (Claude, 2026-01-31)
- [x] MASTER_PLAN.md geschrieben (Claude, 2026-01-31)
- [x] Diese TODO.md erstellt (Claude, 2026-01-31)

---

## 📊 QUICK WINS (Für Einsteiger)

### Easy Tasks (30min-1h)

#### A: Constants definieren
**File:** `pydaw/ui/notation/constants.py` (NEU)  
**Aufwand:** 15min

```python
# Staff-Größen
STAFF_LINE_DISTANCE = 10  # Pixel
STAFF_LINES = 5
NOTE_HEAD_WIDTH = 8
NOTE_HEAD_HEIGHT = 6
# ...
```

#### B: Colors definieren
**File:** `pydaw/ui/notation/colors.py` (NEU)  
**Aufwand:** 30min

```python
VELOCITY_COLORS = {
    range(1, 32): QColor(100, 100, 255),
    # ...
}
```

#### C: Docstrings hinzufügen
**File:** Diverse  
**Aufwand:** 1h

Füge Docstrings zu existierenden Funktionen hinzu

---

## 📝 TASK-FORMAT

### Wie Task markieren:
```markdown
### Task X: Name
**Assignee:** [x] (Dein Name, Datum)
```

### Beispiel:
```markdown
### Task 1: Daten-Model erweitern
**Assignee:** [x] (Max, 2026-01-31 08:00)
**Status:** 🚧 IN ARBEIT
```

### Nach Fertigstellung:
```markdown
**Assignee:** [x] (Max, 2026-01-31 08:00) ✅ DONE
**Status:** ✅ FERTIG
```

Dann in `DONE.md` eintragen!

---

**Letzte Aktualisierung:** 2026-01-31 09:00  
**Aktualisiert von:** GPT-5.2  
**Nächster Check:** Nach jeder Session


## Arranger
- [x] Lasso/Mehrfachauswahl: Group-Move beim Drag (Arranger) (ChatGPT, 2026-02-02)

## Optional / Nice-to-have Enhancements

- [x] Notation: Grid + Y-Scroll/Y-Zoom + Scale-Badge (12 dots + Root) (2026-02-03, GPT-5.2)

## Next
- [x] Hotfix: Mixer HybridBridge Wiring (Track-Fader live + VU-Meter live) (2026-02-08, GPT-5.2)
- [x] Hotfix: SamplerWidget _reflow_env missing + DevicePanel device width stretch (2026-02-05, GPT-5.2)
- Sampler: Parameter-Storage im Projekt (Session Save/Load)
- Sampler: Multi-Instance Routing / Device-Chain UI polish

## v0.0.20.51 (2026-02-10)

- [x] FIX: Sampler/DrumMachine stumm bei Playback (nur Note-Preview hörbar)
  - Ursache: Pull-Sources wurden als plain functions registriert, Callback erwartet `.pull()`
  - Lösung: AudioEngine.register_pull_source wrapped Callables → `.pull(frames, sr)` Adapter
  - Robustness: HybridEngine kann zusätzlich callables direkt aufrufen (Fallback)
  - Legacy: MIDI-Event track_id/velocity in EngineThread._prepare_clips korrigiert (id + int velocity)
