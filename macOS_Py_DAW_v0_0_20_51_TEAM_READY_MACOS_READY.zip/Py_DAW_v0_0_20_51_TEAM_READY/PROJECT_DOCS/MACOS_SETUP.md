# macOS Setup (ChronoScaleStudio / Py_DAW)

## Ziel
- **GUI:** PyQt6/Qt6 (läuft auf macOS nativ; Qt nutzt i.d.R. Metal als bevorzugten Renderpfad)
- **Audio:** CoreAudio via `sounddevice` (PortAudio)
- **SF2/SoundFonts:** FluidSynth (Binary) + optional `pyfluidsynth` für Live-Preview

## 1) Python & venv
Empfohlen (Terminal):

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 install.py
```

## 2) Systempakete (empfohlen)
Viele Python-Pakete kommen als Wheels. Falls bei dir etwas fehlt oder du SF2/MP3 importieren willst:

```bash
brew install ffmpeg fluid-synth
# optional (nur wenn pip Wheels fehlen):
brew install portaudio libsndfile
```

## 3) SoundFont (.sf2)
FluidSynth liefert **keine** GM-SoundFont mit.

- Lade z.B. `FluidR3_GM.sf2` herunter (oder nutze eine andere GM SoundFont)
- Setze dann:

```bash
export PYDAW_DEFAULT_SF2="/Pfad/zu/Deiner/FluidR3_GM.sf2"
```

## 4) Metal/Qt6
Normalerweise ist nichts zu tun.
Wenn du explizit Metal forcieren willst:

```bash
export QSG_RHI_BACKEND=metal
export QT_QUICK_BACKEND=metal
```

## 5) Start
```bash
python3 main.py
```
