"""ChronoScaleStudio / Py_DAW – Installer (cross-platform)

Dieses Script installiert die Python-Abhängigkeiten und gibt auf macOS
zusätzlich Hinweise zu Homebrew-Systempaketen (CoreAudio/Metal Setup).

Usage:
  python3 install.py
  python3 install.py --brew   # versucht (wenn brew vorhanden) fehlende Formeln zu installieren

Hinweis:
- Das Script erstellt **keine** venv automatisch. Empfohlen:
    python3 -m venv .venv && source .venv/bin/activate
    python3 install.py
"""

from __future__ import annotations

import argparse
import os
import platform
import shutil
import subprocess
import sys
from typing import Iterable


ROOT = os.path.abspath(os.path.dirname(__file__))
REQ_FILE = os.path.join(ROOT, "requirements.txt")


def _run(cmd: list[str], check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, check=check)


def _print_header() -> None:
    print("=" * 72)
    print("ChronoScaleStudio / Py_DAW – Install")
    print(f"Python: {sys.version.split()[0]}  ({sys.executable})")
    print(f"OS: {platform.system()} {platform.release()}")
    print("=" * 72)


def _pip_install_requirements() -> None:
    if not os.path.exists(REQ_FILE):
        raise FileNotFoundError(f"requirements.txt nicht gefunden: {REQ_FILE}")

    # pip upgrade ist optional, aber hilft bei Wheels
    try:
        _run([sys.executable, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"], check=False)
    except Exception:
        pass

    print("\n[1/2] Installiere Python-Pakete…")
    _run([sys.executable, "-m", "pip", "install", "-r", REQ_FILE])


def _which(name: str) -> str | None:
    p = shutil.which(name)
    return p if p else None


def _brew_available() -> bool:
    return _which("brew") is not None


def _brew_is_installed(formula: str) -> bool:
    try:
        r = subprocess.run(["brew", "list", "--formula", formula], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return r.returncode == 0
    except Exception:
        return False


def _brew_install(formulas: Iterable[str]) -> None:
    # Install in einem Rutsch
    _run(["brew", "install", *list(formulas)], check=False)


def _macos_hints(auto_brew: bool) -> None:
    print("\n[macOS] Zusatz-Setup (empfohlen)")
    print("- Audio läuft über CoreAudio (sounddevice/PortAudio)")
    print("- UI läuft über Qt6; Metal ist der bevorzugte Backend-Pfad auf macOS")

    need = []

    # ffmpeg: pydub nutzt ffmpeg für mp3/aac/m4a
    if not _which("ffmpeg"):
        need.append("ffmpeg")

    # fluidsynth: SF2 Render/Preview
    if not _which("fluidsynth"):
        need.append("fluid-synth")

    # Diese beiden sind in der Regel via Wheels vorhanden, aber als Fallback hilfreich.
    # (sounddevice -> portaudio, soundfile -> libsndfile)
    # Wir installieren sie nur wenn auto_brew gesetzt ist oder wenn explizit gewünscht.
    if auto_brew:
        if not _brew_is_installed("portaudio"):
            need.append("portaudio")
        if not _brew_is_installed("libsndfile"):
            need.append("libsndfile")

    if not _brew_available():
        print("\nHomebrew ist nicht gefunden.")
        print("Wenn dir ffmpeg/fluidsynth fehlen, installiere Homebrew und dann z.B.:")
        print("  brew install ffmpeg fluid-synth")
        print("(Optional) brew install portaudio libsndfile")
        return

    if need:
        print("\nFehlende Homebrew-Formeln:")
        for f in need:
            print(f"  - {f}")

        print("\nInstall-Befehl:")
        print("  brew install " + " ".join(need))

        if auto_brew:
            print("\n--brew aktiv: versuche Installation…")
            _brew_install(need)
    else:
        print("\nHomebrew-Pakete: OK (oder nicht benötigt)")

    print("\nSoundFont Hinweis:")
    print("- Für SF2 brauchst du eine .sf2 Datei (z.B. FluidR3_GM.sf2).")
    print("- Lege sie irgendwo ab und setze optional:")
    print("    export PYDAW_DEFAULT_SF2=\"/Pfad/zu/Deiner.sf2\"")

    print("\nMetal Hinweis (Qt6):")
    print("- Normalerweise nutzt Qt auf macOS Metal automatisch.")
    print("- Falls du explizit setzen willst:")
    print("    export QSG_RHI_BACKEND=metal")
    print("    export QT_QUICK_BACKEND=metal")


def _linux_hints() -> None:
    print("\n[Linux] Hinweise")
    print("- Audio: sounddevice (PortAudio) oder JACK (optional)")
    print("- Für SF2-Render: fluidsynth + SoundFont (.sf2)")
    print("- Für MP3/AAC Import: ffmpeg")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--brew", action="store_true", help="(macOS) versucht fehlende brew-Formeln zu installieren")
    args = ap.parse_args()

    _print_header()

    try:
        _pip_install_requirements()
    except subprocess.CalledProcessError as e:
        print("\n❌ Pip-Installation fehlgeschlagen:", e)
        return 1

    print("\n[2/2] Platform-Hinweise…")
    sysname = platform.system()
    if sysname == "Darwin":
        _macos_hints(auto_brew=bool(args.brew))
    elif sysname == "Linux":
        _linux_hints()
    else:
        print("\nHinweis: Diese Plattform ist (noch) nicht voll getestet.")

    print("\n✅ Fertig. Start:")
    print("  python3 main.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
