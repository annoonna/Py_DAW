# -*- coding: utf-8 -*-
"""DrumMachineWidget (Bitwig-style Device Panel).

Phase 1 focus:
- Visible, testable skeleton (UI + basic audio wiring)
- 16 pad grid (drag&drop samples onto pads)
- Per-slot local sampler params (Gain/Pan/Tune + basic filter)
- Pattern Generator (rule-based placeholder; later AI/Magenta)

Integration:
- When inserted into a track's device chain, this widget registers a pull-source
  in AudioEngine and tags it with _pydaw_track_id so track faders + VU meters work.
- Note preview from PianoRoll/Notation is routed via existing SamplerRegistry
  by exposing engine.trigger_note().
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QPushButton,
    QLabel,
    QFrame,
    QFileDialog,
    QComboBox,
    QSpinBox,
    QSlider,
)

from pydaw.plugins.sampler.ui_widgets import CompactKnob, WaveformDisplay
from .drum_engine import DrumMachineEngine


AUDIO_EXTS = "Audio Files (*.wav *.flac *.ogg *.mp3 *.aif *.aiff);;All Files (*)"


def _note_name(midi: int) -> str:
    names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
    m = int(midi)
    n = names[m % 12]
    o = (m // 12) - 1  # MIDI standard: C4=60 -> 4
    return f"{n}{o}"


class DrumPadButton(QPushButton):
    """Pad button with drag&drop sample loading."""

    sample_dropped = pyqtSignal(int, str)  # slot_idx, path

    def __init__(self, slot_idx: int, text: str, parent=None):
        super().__init__(text, parent)
        self.slot_idx = int(slot_idx)
        self.setAcceptDrops(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumSize(72, 44)
        self.setMaximumWidth(120)

    def dragEnterEvent(self, e):
        try:
            if e.mimeData().hasUrls():
                e.acceptProposedAction()
                return
        except Exception:
            pass
        e.ignore()

    def dropEvent(self, e):
        try:
            urls = e.mimeData().urls()
            if not urls:
                e.ignore()
                return
            p = Path(urls[0].toLocalFile())
            if not p.exists():
                e.ignore()
                return
            self.sample_dropped.emit(self.slot_idx, str(p))
            e.acceptProposedAction()
        except Exception:
            e.ignore()


@dataclass
class StyleMix:
    style: str
    weight: float


class DrumMachineWidget(QWidget):
    """Drum Machine device widget."""

    def __init__(self, project_service=None, audio_engine=None, parent=None):
        super().__init__(parent)
        self.project_service = project_service
        self.audio_engine = audio_engine

        self.track_id: Optional[str] = None
        self.engine = DrumMachineEngine(slots=16, base_note=36, target_sr=48000)

        # Pull-source wiring
        self._pull_name: Optional[str] = None
        # Wrap pull so we can attach metadata (bound methods can't reliably hold attrs)
        def _pull(frames: int, sr: int, _eng=self.engine):
            return _eng.pull(frames, sr)

        # Tag for track faders/VU (AudioEngine reads this dynamically)
        _pull._pydaw_track_id = lambda: (self.track_id or "")  # type: ignore[attr-defined]
        self._pull_fn = _pull

        self._selected_slot: int = 0

        self._build_ui()
        self._apply_styles()

    # ---------------- Device lifecycle
    def set_track_context(self, track_id: str) -> None:
        self.track_id = str(track_id)
        # Register pull source once we know the track binding
        try:
            if self.audio_engine is not None and self._pull_name is None:
                self._pull_name = f"drum:{self.track_id}:{id(self) & 0xFFFF:04x}"
                self.audio_engine.register_pull_source(self._pull_name, self._pull_fn)
                self.audio_engine.ensure_preview_output()
        except Exception:
            pass

    def shutdown(self) -> None:
        try:
            if self.audio_engine is not None and self._pull_name is not None:
                self.audio_engine.unregister_pull_source(self._pull_name)
        except Exception:
            pass
        self._pull_name = None
        try:
            self.engine.stop_all()
        except Exception:
            pass

    # ---------------- UI
    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)

        top = QHBoxLayout()
        top.setSpacing(10)

        # Pads
        pad_frame = QFrame()
        pad_frame.setObjectName("padFrame")
        pad_layout = QGridLayout(pad_frame)
        pad_layout.setContentsMargins(4, 4, 4, 4)
        pad_layout.setHorizontalSpacing(4)
        pad_layout.setVerticalSpacing(4)

        self.pads: list[DrumPadButton] = []
        for i, slot in enumerate(self.engine.slots):
            note = self.engine.base_note + i
            label = f"{i+1}\n{slot.state.name}\n{_note_name(note)}"
            b = DrumPadButton(i, label)
            b.clicked.connect(lambda _=False, idx=i: self._select_slot(idx))
            b.sample_dropped.connect(self._on_pad_sample_dropped)
            b.pressed.connect(lambda idx=i: self._preview_slot(idx))
            self.pads.append(b)
            r, c = divmod(i, 4)
            pad_layout.addWidget(b, r, c)

        top.addWidget(pad_frame, 0)

        # Editor + AI
        right = QVBoxLayout()
        right.setSpacing(6)

        # --- AI / Pattern generator (skeleton)
        ai_box = QFrame()
        ai_box.setObjectName("aiBox")
        ai_l = QHBoxLayout(ai_box)
        ai_l.setContentsMargins(6, 6, 6, 6)
        ai_l.setSpacing(8)

        self.cmb_style = QComboBox()
        self.cmb_style.addItems([
            "Classic", "80s Pop", "Punk", "Electro", "Electro-Punk",
            "HipHop/R&B", "Gabba", "Speedcore", "Country", "Gottesdienst",
        ])
        self.sld_intensity = QSlider(Qt.Orientation.Horizontal)
        self.sld_intensity.setRange(0, 100)
        self.sld_intensity.setValue(55)
        self.spn_bars = QSpinBox()
        self.spn_bars.setRange(1, 16)
        self.spn_bars.setValue(1)
        self.btn_random = QPushButton("Random")
        self.btn_generate = QPushButton("Generate → Clip")

        self.btn_random.clicked.connect(self._randomize_style)
        self.btn_generate.clicked.connect(self._generate_to_clip)

        ai_l.addWidget(QLabel("Style"))
        ai_l.addWidget(self.cmb_style, 1)
        ai_l.addWidget(QLabel("Intensity"))
        ai_l.addWidget(self.sld_intensity, 1)
        ai_l.addWidget(QLabel("Bars"))
        ai_l.addWidget(self.spn_bars)
        ai_l.addWidget(self.btn_random)
        ai_l.addWidget(self.btn_generate)

        right.addWidget(ai_box)

        # --- Slot editor
        edit_box = QFrame()
        edit_box.setObjectName("editBox")
        edit_l = QVBoxLayout(edit_box)
        edit_l.setContentsMargins(6, 6, 6, 6)
        edit_l.setSpacing(6)

        self.lbl_slot = QLabel("Slot 1")
        self.lbl_file = QLabel("No sample")
        self.lbl_file.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        file_row = QHBoxLayout()
        self.btn_load = QPushButton("Load")
        self.btn_clear = QPushButton("Clear")
        self.btn_load.clicked.connect(self._load_sample_dialog)
        self.btn_clear.clicked.connect(self._clear_sample)
        file_row.addWidget(self.lbl_slot)
        file_row.addSpacing(8)
        file_row.addWidget(self.lbl_file, 1)
        file_row.addWidget(self.btn_load)
        file_row.addWidget(self.btn_clear)

        edit_l.addLayout(file_row)

        self.wave = WaveformDisplay(self.engine.slots[0].engine)
        edit_l.addWidget(self.wave)

        knobs = QHBoxLayout()
        knobs.setSpacing(6)
        self.kn_gain = CompactKnob("Gain", 80)
        self.kn_pan = CompactKnob("Pan", 50)
        self.kn_tune = CompactKnob("Tune", 50)
        self.kn_cut = CompactKnob("Cut", 100)
        self.kn_res = CompactKnob("Res", 20)

        self.cmb_filter = QComboBox()
        self.cmb_filter.addItems(["off", "lowpass", "highpass", "bandpass"])

        knobs.addWidget(self.kn_gain)
        knobs.addWidget(self.kn_pan)
        knobs.addWidget(self.kn_tune)
        knobs.addWidget(self.cmb_filter)
        knobs.addWidget(self.kn_cut)
        knobs.addWidget(self.kn_res)
        knobs.addStretch(1)

        edit_l.addLayout(knobs)

        # Connect knobs
        self.kn_gain.valueChanged.connect(lambda v: self._slot_set_gain(v))
        self.kn_pan.valueChanged.connect(lambda v: self._slot_set_pan(v))
        self.kn_tune.valueChanged.connect(lambda v: self._slot_set_tune(v))
        self.kn_cut.valueChanged.connect(lambda v: self._slot_set_cut(v))
        self.kn_res.valueChanged.connect(lambda v: self._slot_set_res(v))
        self.cmb_filter.currentTextChanged.connect(lambda t: self._slot_set_filter(t))

        right.addWidget(edit_box, 1)

        top.addLayout(right, 1)
        root.addLayout(top)

        self._select_slot(0)

    def _apply_styles(self) -> None:
        self.setStyleSheet(
            """
            #padFrame {background:#141414;border:1px solid #232323;border-radius:6px;}
            #aiBox {background:#101010;border:1px solid #232323;border-radius:6px;}
            #editBox {background:#101010;border:1px solid #232323;border-radius:6px;}
            QPushButton {background:#1a1a1a;border:1px solid #2a2a2a;border-radius:6px;padding:6px;color:#ddd;}
            QPushButton:hover {border:1px solid #3a3a3a;}
            QPushButton:pressed {background:#151515;}
            QLabel {color:#cfcfcf;}
            QComboBox {background:#151515;border:1px solid #2a2a2a;border-radius:4px;padding:2px;color:#ddd;}
            QSpinBox {background:#151515;border:1px solid #2a2a2a;border-radius:4px;padding:2px;color:#ddd;}
            """
        )

    # ---------------- Pad actions
    def _select_slot(self, idx: int) -> None:
        idx = int(max(0, min(15, idx)))
        self._selected_slot = idx
        for i, b in enumerate(self.pads):
            if i == idx:
                b.setStyleSheet("border:2px solid #e060e0;")
            else:
                b.setStyleSheet("")
        self._refresh_slot_editor()

    def _preview_slot(self, idx: int) -> None:
        try:
            pitch = self.engine.base_note + int(idx)
            self.engine.trigger_note(pitch, velocity=110, duration_ms=160)
            if self.audio_engine is not None:
                self.audio_engine.ensure_preview_output()
        except Exception:
            pass

    def _on_pad_sample_dropped(self, idx: int, path: str) -> None:
        idx = int(idx)
        ok = False
        try:
            ok = bool(self.engine.slots[idx].load_sample(path))
        except Exception:
            ok = False
        if ok:
            self._update_pad_text(idx)
            if idx == self._selected_slot:
                self._refresh_slot_editor()
        else:
            self._status(f"Sample konnte nicht geladen werden: {Path(path).name}")

    def _update_pad_text(self, idx: int) -> None:
        slot = self.engine.slots[int(idx)]
        note = self.engine.base_note + int(idx)
        base = f"{idx+1}\n{slot.state.name}\n{_note_name(note)}"
        if slot.state.sample_path:
            base += f"\n{Path(slot.state.sample_path).stem[:10]}"
        self.pads[int(idx)].setText(base)

    # ---------------- Slot editor
    def _current_slot(self):
        return self.engine.slots[int(self._selected_slot)]

    def _refresh_slot_editor(self) -> None:
        slot = self._current_slot()
        self.lbl_slot.setText(f"Slot {slot.state.index+1} — {slot.state.name}  ({_note_name(self.engine.base_note + slot.state.index)})")
        self.lbl_file.setText(Path(slot.state.sample_path).name if slot.state.sample_path else "No sample")

        # Rebind waveform display to selected slot engine
        try:
            self.wave.engine = slot.engine
        except Exception:
            pass
        try:
            if slot.engine.samples is not None:
                self.wave.samples = slot.engine.samples
        except Exception:
            pass

        # Update knobs from engine state
        try:
            st = slot.engine.state
            self.kn_gain.setValue(int(float(getattr(st, "gain", 0.8)) * 100))
            pan = float(getattr(st, "pan", 0.0))
            self.kn_pan.setValue(int((pan + 1.0) * 50))

            # tune knob is semitone offset mapped around 50
            # we store tune in root_note offset concept: compute current ratio -> semitones
            root = int(getattr(slot.engine, "root_note", self.engine.base_note + slot.state.index))
            # ratio is derived at trigger time; here we keep as knob state only.
            self.kn_tune.setValue(int(getattr(self, "_tune_knob_cache", {}).get(slot.state.index, 50)))

            ftype = str(getattr(st, "filter_type", "off"))
            if ftype not in ("off", "lowpass", "highpass", "bandpass"):
                ftype = "off"
            self.cmb_filter.setCurrentText(ftype)

            cutoff = float(getattr(st, "cutoff_hz", 8000.0))
            # map 20..20000 -> 0..100 (log-ish)
            cut01 = (max(20.0, min(20000.0, cutoff)) - 20.0) / (20000.0 - 20.0)
            self.kn_cut.setValue(int(cut01 * 100))

            q = float(getattr(st, "q", 0.707))
            q01 = (max(0.25, min(12.0, q)) - 0.25) / (12.0 - 0.25)
            self.kn_res.setValue(int(q01 * 100))
        except Exception:
            pass

    def _load_sample_dialog(self) -> None:
        slot = self._current_slot()
        path, _ = QFileDialog.getOpenFileName(self, "Load sample", "", AUDIO_EXTS)
        if not path:
            return
        ok = bool(slot.load_sample(path))
        if ok:
            self._update_pad_text(slot.state.index)
            # Avoid double-loading: slot.load_sample already filled engine.samples
            try:
                self.wave.samples = slot.engine.samples
            except Exception:
                pass
            self.lbl_file.setText(Path(path).name)
        else:
            self._status("Sample load failed")

    def _clear_sample(self) -> None:
        slot = self._current_slot()
        slot.clear_sample()
        self._update_pad_text(slot.state.index)
        self._refresh_slot_editor()

    # ---------------- Param setters (selected slot)
    def _slot_set_gain(self, v: int) -> None:
        slot = self._current_slot()
        try:
            slot.engine.set_master(gain=float(v) / 100.0)
        except Exception:
            pass

    def _slot_set_pan(self, v: int) -> None:
        slot = self._current_slot()
        try:
            pan = (float(v) / 50.0) - 1.0
            slot.engine.set_master(pan=pan)
        except Exception:
            pass

    def _slot_set_tune(self, v: int) -> None:
        # Store as semitone offset in [-12..+12]
        slot = self._current_slot()
        semis = int(round(((int(v) - 50) / 50.0) * 12.0))
        base_pitch = self.engine.base_note + slot.state.index
        # For stable mapping, keep root note shifted so pitch-base yields ratio
        try:
            slot.engine.set_root(int(base_pitch - semis))
        except Exception:
            pass
        # Cache for refresh
        cache = getattr(self, "_tune_knob_cache", None)
        if cache is None:
            cache = {}
            setattr(self, "_tune_knob_cache", cache)
        cache[slot.state.index] = int(v)

    def _slot_set_filter(self, ftype: str) -> None:
        slot = self._current_slot()
        try:
            slot.engine.set_filter(ftype=str(ftype))
        except Exception:
            pass

    def _slot_set_cut(self, v: int) -> None:
        slot = self._current_slot()
        try:
            cut = 20.0 + (float(v) / 100.0) * (20000.0 - 20.0)
            slot.engine.set_filter(cutoff_hz=cut)
        except Exception:
            pass

    def _slot_set_res(self, v: int) -> None:
        slot = self._current_slot()
        try:
            q = 0.25 + (float(v) / 100.0) * (12.0 - 0.25)
            slot.engine.set_filter(q=q)
        except Exception:
            pass

    # ---------------- AI Pattern (placeholder)
    def _randomize_style(self) -> None:
        try:
            self.cmb_style.setCurrentIndex(random.randint(0, self.cmb_style.count() - 1))
            self.sld_intensity.setValue(random.randint(25, 95))
            self.spn_bars.setValue(random.choice([1, 1, 2, 4]))
        except Exception:
            pass

    def _generate_to_clip(self) -> None:
        if self.project_service is None:
            self._status("ProjectService fehlt – Pattern nicht möglich.")
            return
        try:
            clip_id = str(self.project_service.active_clip_id() or "")
        except Exception:
            clip_id = ""
        if not clip_id:
            self._status("Kein aktiver MIDI-Clip (Tip: Clip auswählen oder im Launcher doppelklicken).")
            return

        clip = None
        try:
            clip = self.project_service.get_clip(clip_id)
        except Exception:
            clip = None
        if clip is None or str(getattr(clip, "kind", "")) != "midi":
            self._status("Aktiver Clip ist kein MIDI-Clip.")
            return

        bars = int(self.spn_bars.value())
        style = str(self.cmb_style.currentText())
        intensity = float(self.sld_intensity.value()) / 100.0

        notes = self._make_pattern(style=style, intensity=intensity, bars=bars)
        try:
            before = self.project_service.snapshot_midi_notes(clip_id)
        except Exception:
            before = []

        try:
            self.project_service.set_midi_notes(clip_id, notes)
            self.project_service.commit_midi_notes_edit(clip_id, before, f"Drum Pattern: {style}")
            self._status(f"Pattern geschrieben: {style} ({bars} bar)")
        except Exception as e:
            self._status(f"Pattern schreiben fehlgeschlagen: {e}")

    def _make_pattern(self, style: str, intensity: float, bars: int = 1):
        """Return list[MidiNote] for a simple style-driven 16th grid."""
        from pydaw.model.midi import MidiNote

        # Slot mapping (default): 0 Kick, 1 Snare, 2 CHat, 3 OHat, 4 Clap, 5 Tom, 6 Perc
        kick = self.engine.base_note + 0
        snare = self.engine.base_note + 1
        chat = self.engine.base_note + 2
        ohat = self.engine.base_note + 3
        clap = self.engine.base_note + 4
        tom = self.engine.base_note + 5
        perc = self.engine.base_note + 6

        # probabilities & densities
        style_l = style.lower()
        four_floor = 0.6
        offbeat_hats = 0.6
        double_kick = 0.1
        snare_backbeat = 0.9
        hat_density = 0.7
        ghost = 0.2

        if "hip" in style_l:
            four_floor = 0.25
            offbeat_hats = 0.35
            snare_backbeat = 0.75
            hat_density = 0.55
            ghost = 0.35
        if "punk" in style_l:
            four_floor = 0.35
            offbeat_hats = 0.2
            snare_backbeat = 0.95
            hat_density = 0.8
            ghost = 0.15
        if "electro" in style_l:
            four_floor = 0.85
            offbeat_hats = 0.75
            hat_density = 0.9
            ghost = 0.2
        if "gabba" in style_l or "speedcore" in style_l:
            four_floor = 0.95
            offbeat_hats = 0.9
            hat_density = 1.0
            double_kick = 0.65
            snare_backbeat = 0.55
            ghost = 0.45
        if "country" in style_l:
            four_floor = 0.45
            offbeat_hats = 0.35
            snare_backbeat = 0.85
            hat_density = 0.55
            ghost = 0.2
        if "gottesdienst" in style_l:
            four_floor = 0.4
            offbeat_hats = 0.3
            snare_backbeat = 0.9
            hat_density = 0.45
            ghost = 0.1

        # intensity scales
        four_floor = min(1.0, max(0.0, four_floor * (0.5 + intensity)))
        hat_density = min(1.0, max(0.0, hat_density * (0.5 + intensity)))
        double_kick = min(1.0, max(0.0, double_kick * (0.25 + intensity)))
        ghost = min(1.0, max(0.0, ghost * (0.35 + intensity)))

        steps_per_bar = 16
        beat_per_step = 4.0 / steps_per_bar
        notes = []

        rng = random.Random()
        rng.seed(int(random.random() * 1e9))

        for bar in range(int(bars)):
            bar_off = float(bar) * 4.0
            for s in range(steps_per_bar):
                t = bar_off + s * beat_per_step
                # Kick
                if s in (0, 4, 8, 12):
                    if rng.random() < four_floor:
                        notes.append(MidiNote(pitch=kick, start_beats=t, length_beats=0.25, velocity=int(105 + 20 * intensity)).clamp())
                else:
                    if rng.random() < (0.10 + 0.25 * intensity):
                        if rng.random() < 0.35:
                            notes.append(MidiNote(pitch=kick, start_beats=t, length_beats=0.25, velocity=int(75 + 25 * intensity)).clamp())

                # Double kick for extreme styles
                if rng.random() < double_kick and s % 2 == 0:
                    if rng.random() < 0.28:
                        notes.append(MidiNote(pitch=kick, start_beats=t + beat_per_step * 0.5, length_beats=0.25, velocity=int(85 + 30 * intensity)).clamp())

                # Snare / Clap
                if s in (4, 12):
                    if rng.random() < snare_backbeat:
                        notes.append(MidiNote(pitch=snare, start_beats=t, length_beats=0.25, velocity=int(95 + 25 * intensity)).clamp())
                    if rng.random() < (0.25 + 0.30 * intensity):
                        notes.append(MidiNote(pitch=clap, start_beats=t, length_beats=0.25, velocity=int(70 + 40 * intensity)).clamp())
                else:
                    if rng.random() < ghost * 0.10:
                        notes.append(MidiNote(pitch=snare, start_beats=t, length_beats=0.25, velocity=int(35 + 30 * intensity)).clamp())

                # Hats
                if rng.random() < hat_density:
                    if offbeat_hats > 0.5 and s % 2 == 1:
                        notes.append(MidiNote(pitch=ohat, start_beats=t, length_beats=0.25, velocity=int(50 + 35 * intensity)).clamp())
                    else:
                        notes.append(MidiNote(pitch=chat, start_beats=t, length_beats=0.25, velocity=int(45 + 30 * intensity)).clamp())

                # Perc / Tom fills
                if rng.random() < (0.05 + 0.12 * intensity) and s in (14, 15):
                    notes.append(MidiNote(pitch=tom, start_beats=t, length_beats=0.25, velocity=int(60 + 35 * intensity)).clamp())
                if rng.random() < (0.04 + 0.10 * intensity) and s in (6, 10):
                    notes.append(MidiNote(pitch=perc, start_beats=t, length_beats=0.25, velocity=int(55 + 30 * intensity)).clamp())

        return notes

    # ---------------- helpers
    def _status(self, msg: str) -> None:
        # Best-effort: route to ProjectService.status (shows in statusbar)
        try:
            if self.project_service is not None and hasattr(self.project_service, "status"):
                self.project_service.status.emit(str(msg))
                return
        except Exception:
            pass

