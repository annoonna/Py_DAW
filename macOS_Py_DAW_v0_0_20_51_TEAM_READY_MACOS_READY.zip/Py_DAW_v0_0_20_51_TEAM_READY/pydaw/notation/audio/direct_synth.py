# ChronoScaleStudio – direkter Audio-Synth (FluidSynth via Python-Bindings)
#
# Ziel:
# - Linux: PipeWire/PulseAudio driver (pulseaudio)
# - macOS: CoreAudio driver (coreaudio)
# - Keine Hard-Crashs, wenn pyfluidsynth/libfluidsynth fehlt
# - SoundFont-Pfad konfigurierbar (ENV)

from __future__ import annotations

import os
import platform
import time
from typing import Optional


def _clamp(v: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, int(v)))


def _default_sf2_candidates() -> list[str]:
    home = os.path.expanduser("~")
    sysname = platform.system()

    # User override
    env = os.environ.get("PYDAW_DEFAULT_SF2") or os.environ.get("CHRONOSCALE_DEFAULT_SF2")
    candidates: list[str] = []
    if env:
        candidates.append(env)

    # Common locations
    if sysname == "Darwin":
        candidates += [
            "/opt/homebrew/share/sounds/sf2/FluidR3_GM.sf2",  # Apple Silicon Homebrew
            "/usr/local/share/sounds/sf2/FluidR3_GM.sf2",     # Intel Homebrew
            os.path.join(home, "Library", "Application Support", "ChronoScaleStudio", "SoundFonts", "FluidR3_GM.sf2"),
            os.path.join(home, "Library", "Application Support", "PyDAW", "SoundFonts", "FluidR3_GM.sf2"),
        ]
    else:
        candidates += [
            "/usr/share/sounds/sf2/FluidR3_GM.sf2",
            "/usr/share/sounds/sf2/default.sf2",
            os.path.join(home, ".local", "share", "sounds", "sf2", "FluidR3_GM.sf2"),
        ]

    # De-dup
    seen = set()
    out = []
    for p in candidates:
        p = os.path.expanduser(p)
        if p and p not in seen:
            seen.add(p)
            out.append(p)
    return out


def _pick_soundfont_path() -> Optional[str]:
    for p in _default_sf2_candidates():
        if p and os.path.exists(p):
            return p
    return None


def _pick_driver() -> Optional[str]:
    sysname = platform.system()
    if sysname == "Darwin":
        return "coreaudio"
    if sysname == "Linux":
        # PipeWire wird oft über PulseAudio-Kompatibilität genutzt.
        return "pulseaudio"
    # Windows / Other: FluidSynth nutzt hier unterschiedliche Treiber; None versucht Default.
    return None


class _NullSynth:
    """Fallback wenn FluidSynth nicht verfügbar ist."""

    def __init__(self, reason: str = ""):
        self.reason = reason
        self._volume_cc7 = 100

    def available(self) -> bool:
        return False

    def set_channel_volume(self, value: int):
        self._volume_cc7 = _clamp(value, 0, 127)

    def get_channel_volume(self) -> int:
        return int(self._volume_cc7)

    def note_on(self, pitch: int, velocity: int = 90):
        return

    def note_off(self, pitch: int):
        return

    def play_scale(self, intervals_cent, root_midi=60, duration=0.35, on_note=None, velocity: int = 90):
        # Nur UI-Highlighting laufen lassen
        for index, _cent in enumerate(intervals_cent):
            if on_note:
                on_note(index)
            time.sleep(duration)
        if on_note:
            on_note(-1)


class DirectSynth:
    """Lazily-initialized FluidSynth wrapper.

    Wichtig: Keine Initialisierung beim Import, damit macOS/CI nicht crasht,
    wenn libfluidsynth nicht installiert ist.
    """

    def __init__(self):
        self._fs = None
        self._sfid = None
        self._driver = _pick_driver()
        self._soundfont = _pick_soundfont_path()
        self._volume_cc7 = 100
        self._error: str | None = None

        # Optional: Debug
        self._debug = bool(int(os.environ.get("PYDAW_SYNTH_DEBUG", "0") or "0"))

    def available(self) -> bool:
        self._ensure_started()
        return self._fs is not None

    def _ensure_started(self) -> None:
        if self._fs is not None or self._error is not None:
            return

        try:
            import fluidsynth  # pyfluidsynth
        except Exception as e:
            self._error = f"pyfluidsynth nicht verfügbar: {e}"
            if self._debug:
                print("[DirectSynth]", self._error)
            return

        try:
            fs = fluidsynth.Synth()

            # Start audio driver
            try:
                if self._driver:
                    fs.start(driver=self._driver)
                else:
                    fs.start()
            except Exception:
                # Fallback: ohne driver Parameter
                fs.start()

            # Load SoundFont
            if not self._soundfont:
                # Keine SoundFont gefunden -> weiterhin laufen lassen, aber stumm.
                self._error = (
                    "Keine Standard-SoundFont gefunden. "
                    "Setze PYDAW_DEFAULT_SF2=/Pfad/Deiner.sf2"
                )
                if self._debug:
                    print("[DirectSynth]", self._error)
                return

            sfid = fs.sfload(self._soundfont)
            fs.program_select(0, sfid, 0, 0)

            self._fs = fs
            self._sfid = sfid
            self.set_channel_volume(self._volume_cc7)

            if self._debug:
                print(f"[DirectSynth] OK driver={self._driver} sf2={self._soundfont}")

        except Exception as e:
            self._error = f"FluidSynth init fehlgeschlagen: {e}"
            if self._debug:
                print("[DirectSynth]", self._error)
            self._fs = None
            self._sfid = None

    # ---------- Lautstärke ----------
    def set_channel_volume(self, value: int):
        self._volume_cc7 = _clamp(value, 0, 127)
        self._ensure_started()
        if not self._fs:
            return
        try:
            self._fs.cc(0, 7, int(self._volume_cc7))
        except Exception:
            pass

    def get_channel_volume(self) -> int:
        return int(self._volume_cc7)

    # ---------- Note I/O ----------
    def note_on(self, pitch: int, velocity: int = 90):
        self._ensure_started()
        if not self._fs:
            return
        self._fs.noteon(0, _clamp(pitch, 0, 127), _clamp(velocity, 1, 127))

    def note_off(self, pitch: int):
        self._ensure_started()
        if not self._fs:
            return
        self._fs.noteoff(0, _clamp(pitch, 0, 127))

    # ---------- Convenience ----------
    def play_scale(self, intervals_cent, root_midi=60, duration=0.35, on_note=None, velocity: int = 90):
        for index, cent in enumerate(intervals_cent):
            note = root_midi + round(cent / 100)
            if on_note:
                on_note(index)
            self.note_on(note, velocity=velocity)
            time.sleep(duration)
            self.note_off(note)
        if on_note:
            on_note(-1)


# Public singleton
SYNTH = DirectSynth()
