# ChronoScaleStudio – interner Software-Synth (FluidSynth Binary)
#
# Dieses Modul startet optional einen externen `fluidsynth` Prozess.
# Es ist **nicht** zwingend erforderlich, wenn `pyfluidsynth` (direct_synth.py)
# genutzt wird – bleibt aber als Alternative erhalten.
#
# Plattform-spezifisch:
# - Linux: -a pulseaudio / -m alsa_seq
# - macOS: -a coreaudio / -m coremidi
#
# SoundFont:
# - ENV: PYDAW_DEFAULT_SF2 oder CHRONOSCALE_DEFAULT_SF2
#
# Sicherheit:
# - Kein Hard-Crash, wenn fluidsynth fehlt.

from __future__ import annotations

import os
import platform
import subprocess
import shutil
import time
from typing import Optional


def _sf2_candidates() -> list[str]:
    home = os.path.expanduser("~")
    env = os.environ.get("PYDAW_DEFAULT_SF2") or os.environ.get("CHRONOSCALE_DEFAULT_SF2")
    out: list[str] = []
    if env:
        out.append(env)

    if platform.system() == "Darwin":
        out += [
            "/opt/homebrew/share/sounds/sf2/FluidR3_GM.sf2",
            "/usr/local/share/sounds/sf2/FluidR3_GM.sf2",
            os.path.join(home, "Library", "Application Support", "ChronoScaleStudio", "SoundFonts", "FluidR3_GM.sf2"),
        ]
    else:
        out += [
            "/usr/share/sounds/sf2/FluidR3_GM.sf2",
            "/usr/share/sounds/sf2/default.sf2",
            os.path.join(home, ".local", "share", "sounds", "sf2", "FluidR3_GM.sf2"),
        ]

    # De-dup
    seen = set()
    uniq: list[str] = []
    for p in out:
        p = os.path.expanduser(p)
        if p and p not in seen:
            seen.add(p)
            uniq.append(p)
    return uniq


def _pick_sf2() -> Optional[str]:
    for p in _sf2_candidates():
        if os.path.exists(p):
            return p
    return None


class FluidSynthEngine:
    def __init__(self, soundfont: Optional[str] = None):
        self.soundfont = soundfont or _pick_sf2()
        self.process: subprocess.Popen | None = None

    def is_available(self) -> bool:
        return shutil.which("fluidsynth") is not None

    def start(self):
        if not self.is_available():
            raise RuntimeError("FluidSynth ist nicht installiert")

        if self.process:
            return

        if not self.soundfont:
            raise RuntimeError(
                "Keine SoundFont gefunden. Setze PYDAW_DEFAULT_SF2=/Pfad/Deiner.sf2"
            )

        sysname = platform.system()
        if sysname == "Darwin":
            audio_driver = "coreaudio"
            midi_driver = "coremidi"
        elif sysname == "Linux":
            audio_driver = "pulseaudio"  # PipeWire kompatibel
            midi_driver = "alsa_seq"
        else:
            audio_driver = ""  # Default
            midi_driver = ""   # Default

        cmd = ["fluidsynth", "-g", "1.0", self.soundfont]
        if audio_driver:
            cmd = ["fluidsynth", "-a", audio_driver, "-g", "1.0", self.soundfont]
        if midi_driver:
            # -m muss nach -a kommen
            cmd = ["fluidsynth", "-a", audio_driver, "-m", midi_driver, "-g", "1.0", self.soundfont] if audio_driver else ["fluidsynth", "-m", midi_driver, "-g", "1.0", self.soundfont]

        self.process = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        time.sleep(0.7)

    def stop(self):
        if self.process:
            try:
                self.process.terminate()
            except Exception:
                pass
            self.process = None


SYNTH = FluidSynthEngine()
