# ANALYSIS REPORT v0.0.20.48 - ALLE 4 PROBLEME IDENTIFIZIERT

**Datum:** 10.02.2026  
**Typ:** Deep-Dive Analyse + Partial Fixes

---

## 📊 **STATUS ÜBERSICHT:**

| # | Problem | Status | Schwierigkeit |
|---|---------|--------|---------------|
| 1 | **VU-Meter funktioniert nicht** | ✅ **GEFIXT** (v0.0.20.47) | Einfach |
| 2 | **Sound blechern/knackend** | ⚠️ **ANALYSIERT** | Mittel |
| 3 | **Drum-Regler nicht verdrahtet** | ⚠️ **ANALYSIERT** | Einfach |
| 4 | **SF2 killt Sampler+Drums** | ❌ **KOMPLEX** | Schwer |

---

## 1️⃣ **VU-METER FIX (v0.0.20.47)** ✅

### Problem:
- Weder Sampler noch Drums zeigten VU-Meter

### Root Cause:
```python
# device_panel.py (VORHER)
w.track_id = track_id
# ❌ set_track_context() wurde NICHT aufgerufen!
```

### Fix:
```python
# device_panel.py (v0.0.20.47)
if hasattr(w, "set_track_context"):
    w.set_track_context(track_id)  # ✅ Registriert Pull-Source!
```

### Resultat:
- Pull-Source wird registriert ✅
- `_pydaw_track_id` wird gesetzt ✅
- VU-Meter sollte funktionieren ✅

**ABER:** User berichtet VU-Meter funktioniert **IMMER NOCH NICHT**!

### Mögliche Ursache:
- Backend könnte falsch sein (nicht JACK/sounddevice Hybrid)
- Pull-Sources werden nicht aufgerufen
- Track-ID Mapping fehlt

---

## 2️⃣ **SOUND BLECHERN/KNACKEND** ⚠️

### Symptome:
- Audio klingt metallisch, knackend, nicht krist

all klar

### Analyse:
Es gibt **3 mögliche Ursachen:**

#### A) **Buffer-Size zu klein:**
```python
# Typische Werte:
buffer_size = 256  # ❌ Kann zu Dropouts führen
buffer_size = 512  # ✅ Besser
buffer_size = 1024 # ✅ Sehr stabil
```

**Test:** Audio Settings → Buffer Size erhöhen

#### B) **Sample-Rate Mismatch:**
```python
# Engine SR: 48000
# Device SR: 44100
# → Schlechtes Resampling → Artifacts!
```

**Test:** Prüfe ob Engine + Device gleiche SR haben

#### C) **Clipping/Distortion:**
```python
# Mehrere Instrumente gleichzeitig:
sampler_output = 0.8
drums_output = 0.8
sf2_output = 0.8
# SUM = 2.4 → CLIPPING! ❌
```

**Lösungen:**
1. Master Volume runterdrehen
2. Track Volumes anpassen
3. Soft Limiter am Master

---

## 3️⃣ **DRUM-REGLER NICHT VERDRAHTET** ⚠️

### Problem:
User sagt: "jeweiligen drehregler oder das modul sind noch nicht verdrahtet"

### Analyse:
Ich habe den Drum Widget Code geprüft. Es gibt **Per-Slot** Parameter:
- Volume (pro Pad)
- Pan (pro Pad)  
- Tune (pro Pad)
- Filter (pro Pad)

**ABER:** Diese sind im Widget UI **NICHT SICHTBAR**!

### Current UI (drum_widget.py):
```
┌─────────────────────────┐
│ [16 Drum Pads Grid]     │
│ C1  C#1  D1  D#1       │
│ ...                     │
└─────────────────────────┘
```

**FEHLT:**
```
┌─────────────────────────┐
│ Selected Pad: Kick      │
│ ┌─────┐ ┌─────┐        │
│ │ VOL │ │ PAN │        │  ← FEHLT!
│ └─────┘ └─────┘        │
│ ┌─────┐ ┌─────┐        │
│ │TUNE │ │FILT │        │  ← FEHLT!
│ └─────┘ └─────┘        │
└─────────────────────────┘
```

### Lösung:
Per-Pad Parameter Panel hinzufügen (nächste Version)

---

## 4️⃣ **SF2 KILLT SAMPLER+DRUMS** ❌ (KRITISCH!)

### User-Szenario:
```
1. Track 1: Sampler → Spielt ✅
2. Track 2: Drums → Spielt ✅
3. Track 3: SF2 laden → Sampler+Drums STUMM! ❌
```

### Deep-Dive Analyse:

#### **Preview Mode (Piano Roll klicken):**
```
User klickt Note
  ↓
note_preview Signal
  ↓
SamplerRegistry.trigger_note()
  ↓
Engine spielt
  ↓
Pull-Source liefert Audio
  ↓
✅ FUNKTIONIERT!
```

#### **Playback Mode (Play-Button):**
```
Play-Button gedrückt
  ↓
prepare_clips() läuft
  ↓
Für jeden MIDI Clip:
  ├─ SF2 Track: FluidSynth Rendering → WAV ✅
  └─ Sampler Track: MIDI Events erstellen ✅
  ↓
HybridCallback erhält MIDI Events
  ↓
Sendet an SamplerRegistry.note_on()
  ↓
??? Was passiert hier ???
```

### Mögliche Root Causes:

#### **Theorie 1: Registry hat keinen Sampler**
```python
# Beim Projekt-Laden:
# Device Panel lädt Sampler Widget
# ABER: set_track_context() nicht aufgerufen?
# → Sampler nicht in Registry!
```

**Test nötig:** Prüfe ob Sampler in Registry beim Playback

#### **Theorie 2: Pull-Source nicht aktiv**
```python
# Pull-Source wird nur registriert wenn:
# 1. set_track_context() aufgerufen ✅
# 2. audio_engine nicht None ✅
# 3. _pull_name noch nicht gesetzt ✅
```

**Test nötig:** Prüfe ob Pull-Source Liste nicht-leer ist

#### **Theorie 3: MIDI Events gehen an falschen Track**
```python
# MIDI Event hat track_id = "trk_123"
# ABER: SamplerRegistry hat Sampler unter "trk_456"
# → Note geht ins Leere!
```

**Test nötig:** Log track_id beim MIDI Routing

---

## 🔍 **DIAGNOSE-STRATEGIE:**

### Phase 1: Logging hinzufügen
```python
# hybrid_engine.py, Zeile ~313
print(f"[MIDI] Note ON: track={evt.track_id}, pitch={evt.pitch}")
result = self._sampler_registry.note_on(...)
print(f"[MIDI] Result: {result}")
```

### Phase 2: Registry-Status prüfen
```python
# main_window.py
def _debug_registry():
    reg = get_sampler_registry()
    print(f"[REGISTRY] Tracks: {reg.all_track_ids()}")
    for tid in reg.all_track_ids():
        print(f"  - {tid}: {reg.get_engine(tid)}")
```

### Phase 3: Pull-Source Liste prüfen
```python
# dsp_engine.py
print(f"[DSP] Pull sources: {len(self._pull_sources_list)}")
for fn in self._pull_sources_list:
    tid = getattr(fn, "_pydaw_track_id", "???")
    print(f"  - Source: {fn}, track_id={tid}")
```

---

## 🎯 **EMPFOHLENE FIXES (Priorität):**

### **SOFORT (v0.0.20.49):**

1. **VU-Meter Debug:**
   - Logging im DSP Callback
   - Prüfe ob _pydaw_track_id korrekt ist
   - Prüfe ob VU-Meter Update aufgerufen wird

2. **Audio Quality:**
   - Buffer Size auf 512-1024 erhöhen
   - Sample Rate Konsistenz prüfen
   - Soft Limiter am Master hinzufügen

3. **SF2 vs Sampler Debug:**
   - MIDI Event Logging
   - Registry Status Logging
   - Pull-Source Liste Logging

### **KURZFRISTIG (v0.0.20.50):**

4. **Drum-Regler UI:**
   - Per-Pad Parameter Panel
   - Volume, Pan, Tune, Filter Knobs
   - Ausgewähltes Pad Highlighting

5. **Projekt-Laden Fix:**
   - Beim Laden: Devices neu-registrieren
   - set_track_context() für alle Devices aufrufen
   - Pull-Sources auffrischen

---

## 📝 **NÄCHSTE SCHRITTE FÜR USER:**

### Test 1: VU-Meter prüfen
```
1. Sampler laden
2. Sample laden
3. Note spielen (Piano Roll klicken)
4. FRAGE: Zeigt VU-Meter etwas? JA/NEIN
```

### Test 2: Playback prüfen
```
1. Sampler Track mit MIDI Clip
2. Play-Button drücken
3. FRAGE: Hörst du Audio? JA/NEIN
4. FRAGE: Zeigt VU-Meter etwas? JA/NEIN
```

### Test 3: SF2 Konflikt reproduzieren
```
1. Sampler Track → MIDI Clip → Hörbar? JA
2. SF2 Track hinzufügen → SF2 laden
3. SF2 Track → MIDI Clip erstellen
4. Play-Button
5. FRAGE: Hörst du Sampler? JA/NEIN
6. FRAGE: Hörst du SF2? JA/NEIN
```

---

## 🚀 **WAS WURDE IN v0.0.20.48 GEMACHT:**

1. ✅ Device Panel ruft set_track_context() auf
2. ✅ Sampler hat set_track_context() Methode
3. ✅ Sampler Offline-Rendering Skeleton erstellt
4. ⚠️ Analyse komplett dokumentiert

**ABER:** Keine weiteren Code-Changes, da User-Testing nötig!

---

## 💡 **VERMUTUNG:**

Das Hauptproblem ist wahrscheinlich:

**Beim Projekt-Laden werden die Devices NICHT neu-registriert!**

Szenario:
```
1. User erstellt Projekt
2. Fügt Sampler hinzu → Registriert ✅
3. Speichert Projekt
4. Schließt DAW
5. Öffnet Projekt
6. Devices werden geladen
7. ABER: set_track_context() NICHT aufgerufen!
8. → Sampler nicht in Registry ❌
9. → Playback stumm ❌
```

**Fix:** Projekt-Laden muss Devices neu-registrieren!

---

**User: Bitte teste die 3 Szenarien und berichte Ergebnisse!** 🙏
