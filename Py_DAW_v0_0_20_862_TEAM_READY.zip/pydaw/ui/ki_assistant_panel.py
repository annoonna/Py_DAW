"""KI-Kompositions-Assistent — Dock-Panel für Py_DAW (P2A)

v0.0.20.749 — Datei-Analyse: Bilder, JSON, ZIP, Text per Drag&Drop + Upload
Streaming (SSE), Chat-History, Variations-Generator, Clip-Kontext
"""
from __future__ import annotations

import base64
import io
import json
import logging
import os
import re
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from PyQt6.QtCore import QMimeData, QSettings, Qt, QThread, QUrl, pyqtSignal
from PyQt6.QtGui import QColor, QDragEnterEvent, QDropEvent, QFont, QTextCursor
from PyQt6.QtWidgets import (
    QCheckBox, QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit,
    QPlainTextEdit, QPushButton, QScrollArea, QSizePolicy, QSpinBox,
    QTabWidget, QTextEdit, QVBoxLayout, QWidget,
)

log = logging.getLogger(__name__)

_CLAUDE_API_URL = "https://api.anthropic.com/v1/messages"
_CLAUDE_MODEL   = "claude-sonnet-4-6"

_NOTE_NAMES = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]


def _midi_to_name(p: int) -> str:
    return f"{_NOTE_NAMES[p % 12]}{p // 12 - 1}"


def _notes_to_summary(notes: list) -> str:
    if not notes:
        return "(leer)"
    lines = []
    for n in sorted(notes, key=lambda x: float(getattr(x,"start_beats",0)))[:64]:
        lines.append(f"  {_midi_to_name(getattr(n,'pitch',60))} "
                     f"beat={float(getattr(n,'start_beats',0)):.2f} "
                     f"dur={float(getattr(n,'length_beats',0.25)):.2f} "
                     f"vel={int(getattr(n,'velocity',80))}")
    return "\n".join(lines)


QUICK_PROMPTS: List[Dict[str,str]] = [
    {"label":"🥁 Drum Groove",   "prompt":"Schreibe einen 8-Takt-Drum-Groove. Kick 1+3, Snare 2+4, 16tel Hi-Hats, Swing 15%."},
    {"label":"🎹 Akkorde",        "prompt":"Erstelle eine 4-Takt-Akkordfolge passend zur Tonart. Schöne Voicings."},
    {"label":"🎸 Bassline",       "prompt":"_BASSLINE_GEN_"},
    {"label":"🎵 Melodie",        "prompt":"_MELODY_GEN_"},
    {"label":"🤔 Analyse Clip",   "prompt":"_ANALYSE_CLIP_"},
    {"label":"🎲 4×Variation",    "prompt":"_VARIATIONS_4_"},
    {"label":"🎼 Harmonie",       "prompt":"_HARMONY_ANALYSIS_"},
    {"label":"🥁 Rhythmus",       "prompt":"_RHYTHM_ANALYSIS_"},
    {"label":"🎹 ChordProg",      "prompt":"_CHORD_PROGRESSION_"},
    {"label":"🎶 Kontrapunkt",    "prompt":"_COUNTERPOINT_"},
    {"label":"📐 Motiv→8T",       "prompt":"_MOTIF_DEVELOP_"},
    {"label":"🎚 Mix-Check",      "prompt":"_MIX_ANALYSIS_"},
    {"label":"🎭 Genre",          "prompt":"_GENRE_DETECT_"},
    {"label":"📊 Referenz",       "prompt":"_REFERENCE_MATCH_"},
    {"label":"🎛 Preset-Gen",     "prompt":"_PRESET_GEN_"},
    {"label":"🎲 Smart-Rnd",      "prompt":"_SMART_RANDOM_"},
    {"label":"📝 Preset-Info",    "prompt":"_PRESET_DESCRIBE_"},
]

# ── Datei-Analyse Hilfsfunktionen ─────────────────────────────────────────────

_IMG_EXTS  = {".png",".jpg",".jpeg",".webp",".gif"}
_TEXT_EXTS = {".json",".txt",".md",".yaml",".yml",".csv",".pydaw",".xml",".toml"}
_MAX_TEXT_BYTES = 80_000   # max ~80kB Text → Claude Kontext
_MAX_IMG_BYTES  = 4_000_000  # 4 MB Bilder


def _read_file_for_api(path: str) -> Optional[Dict[str,Any]]:
    """
    Liest eine Datei und gibt ein Claude-API-Content-Block-Dict zurück:
      - Bild  → {"type":"image","source":{"type":"base64","media_type":"...","data":"..."}}
      - Text  → {"type":"text","text":"..."}
      - ZIP   → {"type":"text","text":"ZIP-Inhaltsanalyse"}
    Gibt None zurück wenn die Datei nicht unterstützt wird.
    """
    p = Path(path)
    ext = p.suffix.lower()
    try:
        size = p.stat().st_size
    except Exception:
        return None

    # ── Bild ──
    if ext in _IMG_EXTS:
        if size > _MAX_IMG_BYTES:
            return {"type":"text","text":f"[Bild zu groß: {p.name} ({size//1024}kB > 4MB)]"}
        media_map = {".png":"image/png",".jpg":"image/jpeg",".jpeg":"image/jpeg",
                     ".webp":"image/webp",".gif":"image/gif"}
        media_type = media_map.get(ext,"image/png")
        try:
            data = base64.b64encode(p.read_bytes()).decode("ascii")
            return {"type":"image","source":{"type":"base64","media_type":media_type,"data":data}}
        except Exception as e:
            return {"type":"text","text":f"[Bild-Lesefehler: {e}]"}

    # ── ZIP ──
    if ext == ".zip":
        return _analyse_zip(p)

    # ── MIDI (.mid/.midi) ──
    if ext in {".mid", ".midi"}:
        return _read_midi_file(p)

    # ── Text / JSON / etc. ──
    if ext in _TEXT_EXTS or ext in {".log",".ini",".cfg"}:
        try:
            raw = p.read_bytes()
            if len(raw) > _MAX_TEXT_BYTES:
                raw = raw[:_MAX_TEXT_BYTES]
                suffix = f"\n[… abgeschnitten bei {_MAX_TEXT_BYTES//1024}kB]"
            else:
                suffix = ""
            text = raw.decode("utf-8","replace") + suffix
            # JSON hübsch formatieren
            if ext == ".json":
                try:
                    obj = json.loads(text.split("[… abgeschnitten")[0])
                    text = json.dumps(obj, indent=2, ensure_ascii=False)[:_MAX_TEXT_BYTES] + suffix
                except Exception:
                    pass
            label = f"📄 Datei: {p.name}\n{'─'*40}\n{text}"
            return {"type":"text","text":label}
        except Exception as e:
            return {"type":"text","text":f"[Lesefehler {p.name}: {e}]"}

    return {"type":"text","text":f"[Dateityp nicht unterstützt: {p.name}]"}


def _analyse_zip(p: Path) -> Dict[str,Any]:
    """ZIP öffnen → Inhaltsübersicht + alle Text/JSON-Dateien extrahieren."""
    lines = [f"📦 ZIP-Archiv: {p.name}"]
    extracted_texts = []
    extracted_imgs  = []
    try:
        with zipfile.ZipFile(p,"r") as zf:
            infos = zf.infolist()
            lines.append(f"  {len(infos)} Einträge\n")
            for info in infos:
                size_kb = info.file_size // 1024
                lines.append(f"  {'📁' if info.is_dir() else '📄'} {info.filename}  ({size_kb}kB)")

            # Alle JSON/Text-Dateien extrahieren (max 10)
            count = 0
            for info in infos:
                if info.is_dir():
                    continue
                ext = Path(info.filename).suffix.lower()
                if ext in _TEXT_EXTS and count < 10:
                    try:
                        raw = zf.read(info.filename)
                        if len(raw) > _MAX_TEXT_BYTES:
                            raw = raw[:_MAX_TEXT_BYTES]
                        text = raw.decode("utf-8","replace")
                        if ext == ".json":
                            try:
                                text = json.dumps(json.loads(text), indent=2, ensure_ascii=False)[:8000]
                            except Exception:
                                pass
                        extracted_texts.append(
                            f"\n── {info.filename} ──\n{text[:4000]}"
                        )
                        count += 1
                    except Exception as ex:
                        extracted_texts.append(f"\n── {info.filename} ── [Fehler: {ex}]")

                elif ext in _IMG_EXTS and len(extracted_imgs) < 3:
                    try:
                        raw = zf.read(info.filename)
                        if len(raw) <= _MAX_IMG_BYTES:
                            media_map = {".png":"image/png",".jpg":"image/jpeg",
                                         ".jpeg":"image/jpeg",".webp":"image/webp"}
                            mt = media_map.get(ext,"image/png")
                            extracted_imgs.append({
                                "type":"image",
                                "source":{"type":"base64","media_type":mt,
                                          "data":base64.b64encode(raw).decode("ascii")},
                                "_label": info.filename,
                            })
                    except Exception:
                        pass

    except zipfile.BadZipFile:
        return {"type":"text","text":f"[{p.name}: Keine gültige ZIP-Datei]"}
    except Exception as e:
        return {"type":"text","text":f"[ZIP-Fehler: {e}]"}

    summary_text = "\n".join(lines)
    if extracted_texts:
        summary_text += "\n\n" + "\n".join(extracted_texts)

    # Wenn Bilder extrahiert: multi-block zurückgeben (als Liste markiert)
    if extracted_imgs:
        blocks = [{"type":"text","text":summary_text}]
        for img in extracted_imgs:
            label = img.pop("_label","")
            blocks.append({"type":"text","text":f"\n🖼 {label}:"})
            blocks.append(img)
        return {"type":"_multi","blocks":blocks}

    return {"type":"text","text":summary_text}


def _read_midi_file(p: Path) -> Dict[str,Any]:
    """MIDI-Datei (.mid/.midi) lesen und als JSON-Noten für KI-Kontext aufbereiten."""
    try:
        import mido
    except ImportError:
        return {"type":"text","text":f"[MIDI-Import benötigt 'mido': pip install mido]"}
    try:
        mid = mido.MidiFile(str(p))
    except Exception as e:
        return {"type":"text","text":f"[MIDI-Lesefehler {p.name}: {e}]"}

    tpb = mid.ticks_per_beat or 480
    notes_all: list = []
    track_summaries: list = []

    for ti, track in enumerate(mid.tracks):
        track_name = track.name or f"Track {ti}"
        active: dict = {}   # pitch → (start_tick, velocity)
        tick = 0
        track_notes: list = []
        for msg in track:
            tick += msg.time
            if msg.type == "note_on" and msg.velocity > 0:
                active[msg.note] = (tick, msg.velocity)
            elif msg.type in ("note_off", "note_on"):
                if msg.note in active:
                    start_tick, vel = active.pop(msg.note)
                    start_beats = start_tick / tpb
                    length_beats = max(0.01, (tick - start_tick) / tpb)
                    track_notes.append({
                        "pitch": msg.note,
                        "start_beats": round(start_beats, 4),
                        "length_beats": round(length_beats, 4),
                        "velocity": vel,
                    })
        if track_notes:
            notes_all.extend(track_notes)
            pitch_range = f"MIDI {min(n['pitch'] for n in track_notes)}-{max(n['pitch'] for n in track_notes)}"
            track_summaries.append(
                f"  Track {ti} '{track_name}': {len(track_notes)} Noten, {pitch_range}"
            )

    # Zusammenfassung bauen
    lines = [
        f"🎵 MIDI-Datei: {p.name}",
        f"  Format: Type {mid.type}, {len(mid.tracks)} Tracks, {tpb} TPB",
    ]
    lines.extend(track_summaries)

    # Noten als JSON (max 200 für Kontext)
    if notes_all:
        notes_all.sort(key=lambda n: n["start_beats"])
        display = notes_all[:200]
        lines.append(f"\n  Gesamt: {len(notes_all)} Noten")
        if len(notes_all) > 200:
            lines.append(f"  (zeige erste 200 von {len(notes_all)})")
        lines.append("\n```json")
        lines.append(json.dumps({"type": "midi_notes", "notes": display}, indent=1))
        lines.append("```")
    else:
        lines.append("  Keine Noten gefunden.")

    return {"type": "text", "text": "\n".join(lines)}


def _mime_type_for_ext(ext: str) -> str:
    return {".png":"image/png",".jpg":"image/jpeg",
            ".jpeg":"image/jpeg",".webp":"image/webp"}.get(ext,"image/png")


# ── Anhang-Chip-Widget ─────────────────────────────────────────────────────────

class _AttachChip(QWidget):
    """Kleines Chip-Widget für angehängte Datei mit X-Button."""
    remove_requested = pyqtSignal(str)  # path

    def __init__(self, path: str, parent=None):
        super().__init__(parent)
        self._path = path
        lay = QHBoxLayout(self)
        lay.setContentsMargins(4,2,2,2)
        lay.setSpacing(3)
        p = Path(path)
        ext = p.suffix.lower()
        icon = "🖼" if ext in _IMG_EXTS else ("📦" if ext==".zip" else "📄")
        lbl = QLabel(f"{icon} {p.name[:22]}")
        lbl.setStyleSheet("font-size:10px;color:#ccc;")
        lbl.setToolTip(path)
        lay.addWidget(lbl)
        rm = QPushButton("✕")
        rm.setFixedSize(16,16)
        rm.setStyleSheet("border:none;color:#888;font-size:9px;padding:0;")
        rm.clicked.connect(lambda: self.remove_requested.emit(self._path))
        lay.addWidget(rm)
        self.setStyleSheet(
            "QWidget{background:#2a2a3a;border-radius:4px;border:1px solid #444;}"
        )
        self.setFixedHeight(22)


# ── Anhang-Leiste ──────────────────────────────────────────────────────────────

class _AttachmentBar(QWidget):
    """Scroll-Leiste für angehängte Dateien. Unterstützt Drag&Drop."""
    files_changed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self._paths: List[str] = []
        self._chips: Dict[str,"_AttachChip"] = {}

        outer = QHBoxLayout(self)
        outer.setContentsMargins(0,0,0,0)

        # Scroll-Area
        self._scroll = QScrollArea()
        self._scroll.setFixedHeight(28)
        self._scroll.setWidgetResizable(True)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self._scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._scroll.setStyleSheet("background:transparent;border:none;")

        inner = QWidget()
        inner.setStyleSheet("background:transparent;")
        self._chip_lay = QHBoxLayout(inner)
        self._chip_lay.setContentsMargins(2,2,2,2)
        self._chip_lay.setSpacing(4)
        self._chip_lay.addStretch()
        self._scroll.setWidget(inner)
        outer.addWidget(self._scroll, 1)

        # Add-Button
        add_btn = QPushButton("📎")
        add_btn.setFixedSize(26,26)
        add_btn.setToolTip("Datei anhängen (Bild/JSON/ZIP/Text)")
        add_btn.clicked.connect(self._browse_file)
        outer.addWidget(add_btn)

        self._placeholder = QLabel("Dateien hier ablegen oder 📎 klicken")
        self._placeholder.setStyleSheet("color:#555;font-size:10px;")
        self._chip_lay.insertWidget(0, self._placeholder)

    # ── Drag & Drop ────────────────────────────────────────────────────
    def dragEnterEvent(self, e: QDragEnterEvent) -> None:
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e: QDropEvent) -> None:
        for url in e.mimeData().urls():
            path = url.toLocalFile()
            if path:
                self.add_file(path)
        e.acceptProposedAction()

    # ── Datei-Browser ──────────────────────────────────────────────────
    def _browse_file(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Datei anhängen",
            str(Path.home()),
            "Alle unterstützten (*.png *.jpg *.jpeg *.webp *.gif "
            "*.json *.zip *.txt *.md *.yaml *.yml *.csv *.pydaw *.xml *.mid *.midi);;"
            "MIDI (*.mid *.midi);;"
            "Bilder (*.png *.jpg *.jpeg *.webp *.gif);;"
            "Daten (*.json *.zip *.txt *.md *.yaml *.csv *.pydaw *.xml);;"
            "Alle Dateien (*)"
        )
        for p in paths:
            self.add_file(p)

    # ── Chip-Verwaltung ────────────────────────────────────────────────
    def add_file(self, path: str) -> None:
        if path in self._paths:
            return
        self._paths.append(path)
        chip = _AttachChip(path, self)
        chip.remove_requested.connect(self.remove_file)
        # Vor dem Stretch einfügen
        idx = self._chip_lay.count() - 1
        self._chip_lay.insertWidget(idx, chip)
        self._chips[path] = chip
        self._placeholder.setVisible(False)
        self.files_changed.emit()

    def remove_file(self, path: str) -> None:
        if path not in self._paths:
            return
        self._paths.remove(path)
        chip = self._chips.pop(path, None)
        if chip:
            self._chip_lay.removeWidget(chip)
            chip.deleteLater()
        if not self._paths:
            self._placeholder.setVisible(True)
        self.files_changed.emit()

    def get_paths(self) -> List[str]:
        return list(self._paths)

    def clear_files(self) -> None:
        for path in list(self._paths):
            self.remove_file(path)


# ── Streaming-Worker ──────────────────────────────────────────────────────────

class _StreamWorker(QThread):
    chunk_received = pyqtSignal(str)
    result_ready   = pyqtSignal(str)
    error_occurred = pyqtSignal(str)

    def __init__(self, api_key: str, messages: list, system: str,
                 max_tokens: int = 2000, parent=None):
        super().__init__(parent)
        self._api_key  = api_key
        self._messages = messages
        self._system   = system
        self._max_tok  = max_tokens

    def run(self) -> None:  # noqa: C901
        full = ""
        try:
            payload = json.dumps({
                "model": _CLAUDE_MODEL, "max_tokens": self._max_tok,
                "stream": True, "system": self._system,
                "messages": self._messages,
            }).encode()
            req = urllib.request.Request(
                _CLAUDE_API_URL, data=payload,
                headers={"Content-Type":"application/json",
                         "x-api-key":self._api_key,
                         "anthropic-version":"2023-06-01"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=60) as resp:
                for raw in resp:
                    line = raw.decode("utf-8").rstrip()
                    if not line.startswith("data: "):
                        continue
                    data_s = line[6:]
                    if data_s == "[DONE]":
                        break
                    try:
                        ev = json.loads(data_s)
                    except Exception:
                        continue
                    if ev.get("type") == "content_block_delta":
                        delta = ev.get("delta",{})
                        if delta.get("type") == "text_delta":
                            ch = delta.get("text","")
                            full += ch
                            self.chunk_received.emit(ch)
            self.result_ready.emit(full)
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8",errors="replace")
            self.error_occurred.emit(f"HTTP {e.code}: {body[:400]}")
        except Exception as exc:
            self.error_occurred.emit(str(exc))


# ── Variations-Widget ─────────────────────────────────────────────────────────

class _VariationsWidget(QWidget):
    variation_selected = pyqtSignal(list, int)

    def __init__(self, variations: List[Tuple[str,list]], parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0,2,0,0)
        lay.addWidget(QLabel(f"✅ {len(variations)} Variationen — Tab wählen:"))
        tabs = QTabWidget()
        for i,(desc,notes) in enumerate(variations):
            w = QWidget()
            wl = QVBoxLayout(w)
            lbl = QLabel(desc); lbl.setWordWrap(True)
            lbl.setStyleSheet("color:#ccc;font-size:10px;")
            wl.addWidget(lbl)
            wl.addWidget(QLabel(f"{len(notes)} Noten"))
            btn = QPushButton(f"🎹 Variation {i+1} einfügen")
            btn.setStyleSheet("background:#2a5298;color:white;border-radius:3px;padding:3px 8px;")
            btn.clicked.connect(lambda _,vi=i,vn=notes: self.variation_selected.emit(vn,vi+1))
            wl.addWidget(btn); wl.addStretch()
            tabs.addTab(w, f"V{i+1}")
        lay.addWidget(tabs)


# ── Hauptpanel ────────────────────────────────────────────────────────────────

class KiAssistantPanel(QWidget):
    insert_notes_requested = pyqtSignal(list, str)
    status_message         = pyqtSignal(str)

    def __init__(self, services=None, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._services  = services
        self._worker: Optional[_StreamWorker] = None
        self._last_raw  = ""
        self._settings  = QSettings("Py_DAW","KiAssistant")
        self._history:  List[Dict[str,Any]] = []
        self._var_widget: Optional[_VariationsWidget] = None
        self._build_ui()
        self._load_settings()

    # ── UI ────────────────────────────────────────────────────────────────
    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(6,6,6,6)
        root.setSpacing(4)

        # API-Key
        kr = QHBoxLayout()
        kr.addWidget(QLabel("🔑"))
        self._key_edit = QLineEdit()
        self._key_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self._key_edit.setPlaceholderText("Anthropic API-Key  (sk-ant-…)")
        self._key_edit.setFixedHeight(24)
        kr.addWidget(self._key_edit,1)
        sb = QPushButton("💾"); sb.setFixedSize(26,24)
        sb.clicked.connect(self._save_api_key)
        kr.addWidget(sb)
        root.addLayout(kr)

        # Kontext
        cr = QHBoxLayout(); cr.setSpacing(3)
        self._lbl_bpm   = QLabel("—")
        self._lbl_key   = QLabel("—")
        self._lbl_ts    = QLabel("4/4")
        self._lbl_track = QLabel("—")
        self._lbl_clip  = QLabel("kein Clip")
        for lbl in (self._lbl_bpm,self._lbl_key,self._lbl_ts,
                    self._lbl_track,self._lbl_clip):
            lbl.setFrameStyle(QFrame.Shape.StyledPanel)
            lbl.setContentsMargins(2,1,2,1)
            lbl.setStyleSheet("font-size:10px;")
            cr.addWidget(lbl)
        rb = QPushButton("🔄"); rb.setFixedSize(22,20)
        rb.clicked.connect(self.refresh_context)
        cr.addWidget(rb); cr.addStretch()
        root.addLayout(cr)

        # Quick Prompts
        qr = QHBoxLayout(); qr.setSpacing(2)
        for qp in QUICK_PROMPTS:
            btn = QPushButton(qp["label"])
            btn.setFixedHeight(22)
            btn.setStyleSheet("font-size:9px;padding:0 3px;")
            btn.clicked.connect(lambda _,p=qp["prompt"]: self._handle_quick(p))
            qr.addWidget(btn)
        root.addLayout(qr)

        # Chat-Display
        self._chat = QTextEdit()
        self._chat.setReadOnly(True)
        self._chat.setFont(QFont("Monospace",9))
        self._chat.setMinimumHeight(120)
        self._chat.setStyleSheet("background:#0d0d1a;border:1px solid #333;border-radius:4px;")
        root.addWidget(self._chat,1)

        # Variations-Container
        self._var_box = QWidget(); self._var_box.setVisible(False)
        self._var_lay = QVBoxLayout(self._var_box)
        self._var_lay.setContentsMargins(0,0,0,0)
        root.addWidget(self._var_box)

        # ── DATEI-ANHANG-LEISTE ──────────────────────────────────────────
        attach_row = QHBoxLayout()
        attach_label = QLabel("📎 Dateien:")
        attach_label.setStyleSheet("font-size:10px;color:#888;")
        attach_row.addWidget(attach_label)
        self._attach_bar = _AttachmentBar()
        attach_row.addWidget(self._attach_bar,1)
        root.addLayout(attach_row)
        # Separating line
        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("color:#333;")
        root.addWidget(sep)

        # Prompt-Eingabe
        self._prompt_edit = QPlainTextEdit()
        self._prompt_edit.setPlaceholderText(
            "Dein Auftrag…  Dateien oben per Drag&Drop anhängen\n"
            "Enter = senden  |  Shift+Enter = neue Zeile")
        self._prompt_edit.setMaximumHeight(65)
        self._prompt_edit.setFont(QFont("Monospace",9))
        self._prompt_edit.installEventFilter(self)
        root.addWidget(self._prompt_edit)

        # Button-Zeile
        br = QHBoxLayout()
        self._bars_spin = QSpinBox()
        self._bars_spin.setRange(1, 999); self._bars_spin.setValue(8)
        self._bars_spin.setPrefix("🎼 "); self._bars_spin.setSuffix(" Takte")
        self._bars_spin.setFixedWidth(110)
        br.addWidget(self._bars_spin)
        self._auto_ins = QCheckBox("Auto-Insert")
        self._auto_ins.setChecked(True)
        br.addWidget(self._auto_ins)
        br.addStretch()
        clr = QPushButton("🗑 Neu"); clr.setFixedHeight(24)
        clr.clicked.connect(self._clear_chat)
        br.addWidget(clr)
        self._send_btn = QPushButton("✨ Senden")
        self._send_btn.setFixedHeight(24)
        self._send_btn.setStyleSheet(
            "QPushButton{background:#2a5298;color:white;border-radius:4px;padding:0 10px;}"
            "QPushButton:hover{background:#3a63b0;}"
            "QPushButton:disabled{background:#444;color:#666;}"
        )
        self._send_btn.clicked.connect(self._on_send)
        br.addWidget(self._send_btn)
        root.addLayout(br)

        self._status = QLabel("Bereit — Dateien per Drag&Drop anhängen oder 📎 klicken")
        self._status.setStyleSheet("color:#888;font-size:10px;")
        root.addWidget(self._status)

    # ── Event-Filter (Enter) ───────────────────────────────────────────────
    def eventFilter(self, obj, event) -> bool:
        from PyQt6.QtCore import QEvent
        if obj is self._prompt_edit and event.type() == QEvent.Type.KeyPress:
            if (event.key() in (Qt.Key.Key_Return,Qt.Key.Key_Enter)
                    and not (event.modifiers() & Qt.KeyboardModifier.ShiftModifier)):
                self._on_send()
                return True
        return super().eventFilter(obj, event)

    # ── Kontext ────────────────────────────────────────────────────────────
    def refresh_context(self) -> None:
        try:
            ps   = getattr(self._services,"project",None)
            proj = getattr(getattr(ps,"ctx",None),"project",None)
            if not proj:
                return
            self._lbl_bpm.setText(f"♩{int(getattr(proj,'bpm',120) or 120)}")
            self._lbl_ts.setText(str(getattr(proj,"time_signature","4/4") or "4/4"))
            self._lbl_key.setText(str(getattr(proj,"key_signature","C") or "C"))
            cid = ""
            try:
                cid = str(ps.active_clip_id() or "")
            except Exception:
                cid = str(getattr(ps, "_active_clip_id", "") or "")
            if cid:
                clip = next((c for c in getattr(proj,"clips",[]) if c.id==cid),None)
                if clip:
                    self._lbl_clip.setText(f"📎{str(getattr(clip,'label',cid))[:14]}")
                    return
            self._lbl_clip.setText("kein Clip")
        except Exception as exc:
            log.debug("refresh_context: %s", exc)

    def set_selected_track_name(self, name: str) -> None:
        self._lbl_track.setText(str(name or "")[:14])

    def _active_clip_notes(self) -> list:
        try:
            ps   = getattr(self._services,"project",None)
            proj = getattr(getattr(ps,"ctx",None),"project",None)
            cid = ""
            try:
                cid = str(ps.active_clip_id() or "")
            except Exception:
                cid = str(getattr(ps, "_active_clip_id", "") or "")
            if proj and cid:
                return list(getattr(proj,"midi_notes",{}).get(cid,[]) or [])
        except Exception:
            pass
        return []

    # ── Quick Prompts ──────────────────────────────────────────────────────
    def _handle_quick(self, token: str) -> None:
        self.refresh_context()
        if token == "_ANALYSE_CLIP_":
            notes = self._active_clip_notes()
            if notes:
                p = (f"Analysiere dieses MIDI-Pattern:\n```\n"
                     f"{_notes_to_summary(notes)}\n```\n"
                     f"Beschreibe: Rhythmus, Harmonie, Charakter, Genre, Verbesserungsideen.")
            else:
                p = "Erkläre ein typisches MIDI-Pattern für den aktuellen Stil. Was macht es interessant?"
            self._prompt_edit.setPlainText("")
            self._fire(self._key_edit.text().strip(), p, variations=False)
        elif token == "_VARIATIONS_4_":
            self._do_variations()
        elif token == "_HARMONY_ANALYSIS_":
            self._do_harmony_analysis()
        elif token == "_RHYTHM_ANALYSIS_":
            self._do_rhythm_analysis()
        elif token == "_CHORD_PROGRESSION_":
            self._do_chord_progression()
        elif token == "_BASSLINE_GEN_":
            self._do_bassline()
        elif token == "_MELODY_GEN_":
            self._do_melody()
        elif token == "_COUNTERPOINT_":
            self._do_counterpoint()
        elif token == "_MOTIF_DEVELOP_":
            self._do_motif_develop()
        elif token == "_MIX_ANALYSIS_":
            self._do_mix_analysis()
        elif token == "_GENRE_DETECT_":
            self._do_genre_detect()
        elif token == "_REFERENCE_MATCH_":
            self._do_reference_match()
        elif token == "_PRESET_GEN_":
            self._do_preset_gen()
        elif token == "_SMART_RANDOM_":
            self._do_smart_random()
        elif token == "_PRESET_DESCRIBE_":
            self._do_preset_describe()
        else:
            self._prompt_edit.setPlainText(token)
            self._on_send()

    # ── v0.0.20.807: Offline Harmony Analysis (P2B) ──────────────────────

    def _do_harmony_analysis(self) -> None:
        """Offline harmonic analysis — no API key needed."""
        notes = self._active_clip_notes()
        if not notes:
            self._chat_append("system", "⚠ Kein aktiver Clip mit Noten. Wähle einen MIDI-Clip aus.")
            return
        try:
            from pydaw.music.harmony_analysis import analyze_harmony
            note_dicts = [{"pitch": int(getattr(n, 'pitch', 0)),
                           "start": float(getattr(n, 'start_beats', 0)),
                           "duration": float(getattr(n, 'duration', 1)),
                           "velocity": int(getattr(n, 'velocity', 100))}
                          for n in notes]
            report = analyze_harmony(note_dicts)
            lines = ["🎼 **Harmonie-Analyse** (Offline, kein API-Key nötig)\n"]
            lines.append(f"🔑 Tonart: {report.key.full_name} (Konfidenz: {report.key.confidence:.0%})")
            if report.key.all_correlations:
                alt = ", ".join(f"{n} ({c:.0%})" for n, c in report.key.all_correlations[1:4])
                lines.append(f"   Alternativen: {alt}")
            if report.chords:
                chord_names = [c.full_name for c in report.chords]
                lines.append(f"\n🎹 Akkorde: {' | '.join(chord_names)}")
                if report.chord_progression:
                    lines.append(f"📝 Stufen: {report.chord_progression}")
            lines.append(f"\n📊 Komplexität: {report.complexity_score:.0%}")
            lines.append(f"\n{report.description}")
            self._chat_append("assistant", "\n".join(lines))
            self._status.setText("✅ Harmonie-Analyse abgeschlossen")
        except Exception as exc:
            self._chat_append("system", f"⚠ Harmonie-Analyse Fehler: {exc}")

    def _do_rhythm_analysis(self) -> None:
        """Offline rhythmic analysis — no API key needed."""
        notes = self._active_clip_notes()
        if not notes:
            self._chat_append("system", "⚠ Kein aktiver Clip mit Noten. Wähle einen MIDI-Clip aus.")
            return
        try:
            from pydaw.music.rhythm_analysis import analyze_rhythm
            note_dicts = [{"pitch": int(getattr(n, 'pitch', 0)),
                           "start": float(getattr(n, 'start_beats', 0)),
                           "duration": float(getattr(n, 'duration', 1)),
                           "velocity": int(getattr(n, 'velocity', 100))}
                          for n in notes]
            report = analyze_rhythm(note_dicts)
            lines = ["🥁 **Rhythmus-Analyse** (Offline, kein API-Key nötig)\n"]
            lines.append(f"📈 Dichte: {report.density:.1f} Noten/Beat")
            lines.append(f"🎵 Subdivision: {report.dominant_subdivision}")
            lines.append(f"🔄 Swing: {'Ja (' + f'{report.swing_amount:.0%}' + ')' if report.is_swung else 'Nein (straight)'}")
            lines.append(f"⚡ Synkopierung: {report.syncopation:.0%}")
            lines.append(f"🎚 Dynamik: {report.velocity_range:.0%} Range (Ø {report.velocity_mean:.0f})")
            lines.append(f"📊 Komplexität: {report.complexity:.0%}")
            if report.genre_hints:
                lines.append(f"🎸 Genre-Hints: {', '.join(report.genre_hints)}")
            if report.histogram_16th:
                # Simple text histogram
                bar = "".join("█" if h > 0 else "·" for h in report.histogram_16th)
                lines.append(f"\n16tel-Grid: [{bar}]")
            lines.append(f"\n{report.description}")
            self._chat_append("assistant", "\n".join(lines))
            self._status.setText("✅ Rhythmus-Analyse abgeschlossen")
        except Exception as exc:
            self._chat_append("system", f"⚠ Rhythmus-Analyse Fehler: {exc}")

    def _do_chord_progression(self) -> None:
        """Generate chord progression offline — no API key needed.

        Uses algorithmic generation, then optionally sends to Claude for MIDI.
        """
        try:
            from pydaw.music.harmony_analysis import (
                generate_chord_progression, chord_to_midi_notes, NOTE_NAMES,
            )
            import random

            bars = self._bars_spin.value()
            # Detect current key from context or default
            key_root = 0  # C
            mode = "major"
            try:
                key_text = self._lbl_key.text().strip()
                if key_text and key_text != "—":
                    for i, n in enumerate(NOTE_NAMES):
                        if key_text.startswith(n):
                            key_root = i
                            break
                    if "min" in key_text.lower() or "moll" in key_text.lower():
                        mode = "minor"
            except Exception:
                pass

            # Pick a random style
            styles = ["Pop", "Rock", "Jazz", "Blues", "Funk", "R&B", "EDM", "Bossa Nova", "Ambient"]
            style = random.choice(styles)
            seed = random.randint(0, 99999)

            chords = generate_chord_progression(
                key_root=key_root, mode=mode, style=style, bars=bars, seed=seed)

            # Display
            chord_names = [c.full_name for c in chords]
            lines = [f"🎹 **Chord Progression** ({style}, {NOTE_NAMES[key_root]} {mode})\n"]
            lines.append(f"Akkorde: {' | '.join(chord_names)}")
            lines.append(f"Takte: {bars}")

            # Generate MIDI notes for auto-insert
            all_midi = []
            for chord in chords:
                midi_notes = chord_to_midi_notes(chord, octave=4, voicing="close")
                all_midi.extend(midi_notes)

            if all_midi and self._auto_ins.isChecked():
                # Convert to MidiNote objects for insertion
                from pydaw.model.midi import MidiNote
                insert_notes = []
                for md in all_midi:
                    insert_notes.append(MidiNote(
                        pitch=int(md["pitch"]),
                        start_beats=float(md["start"]),
                        duration=float(md["duration"]),
                        velocity=int(md["velocity"]),
                    ))
                lines.append(f"\n✅ {len(insert_notes)} Noten in Clip eingefügt")
                self._chat_append("assistant", "\n".join(lines))
                self.insert_notes_requested.emit(insert_notes, "replace")
            else:
                lines.append("\n(Auto-Insert aus — Noten nur angezeigt)")
                self._chat_append("assistant", "\n".join(lines))

            self._status.setText(f"✅ {style} Chord Progression generiert")
        except Exception as exc:
            self._chat_append("system", f"⚠ Chord Progression Fehler: {exc}")

    # ── v0.0.20.808: Melody/Counterpoint/Motif (P2C) + Mix-Check (P3A) ──

    def _get_key_context(self) -> Tuple[int, str]:
        """Extract key root and scale from UI context."""
        key_root = 0
        scale_name = "major"
        try:
            key_text = self._lbl_key.text().strip()
            if key_text and key_text != "—":
                from pydaw.music.harmony_analysis import NOTE_NAMES
                for i, n in enumerate(NOTE_NAMES):
                    if key_text.startswith(n):
                        key_root = i
                        break
                if "min" in key_text.lower() or "moll" in key_text.lower():
                    scale_name = "minor"
        except Exception:
            pass
        return key_root, scale_name

    def _do_bassline(self) -> None:
        """Generate bassline offline from active clip's harmony."""
        try:
            from pydaw.music.melody_generator import generate_bassline, BasslineStyle
            from pydaw.music.harmony_analysis import recognize_chords_from_notes
            import random

            bars = self._bars_spin.value()
            key_root, scale_name = self._get_key_context()

            # Try to get chords from active clip
            notes = self._active_clip_notes()
            if notes:
                note_dicts = [{"pitch": int(getattr(n, 'pitch', 0)),
                               "start": float(getattr(n, 'start_beats', 0)),
                               "duration": float(getattr(n, 'length_beats', 1)),
                               "velocity": int(getattr(n, 'velocity', 100))} for n in notes]
                chords = recognize_chords_from_notes(note_dicts)
                chord_dicts = [c.to_dict() for c in chords]
            else:
                # Generate default I-IV-V-I
                from pydaw.music.harmony_analysis import generate_chord_progression
                chords = generate_chord_progression(key_root, scale_name, "Pop", bars)
                chord_dicts = [c.to_dict() for c in chords]

            style_name = random.choice(["root", "walking", "syncopated", "arpeggiated"])
            style = BasslineStyle(style=style_name, seed=random.randint(0, 99999))
            bass_notes = generate_bassline(chord_dicts, root_pc=key_root,
                                           scale_name=scale_name, bars=bars, style=style)

            lines = [f"🎸 **Bassline** ({style_name}, {bars} Takte)\n"]
            lines.append(f"{len(bass_notes)} Noten generiert")

            if bass_notes and self._auto_ins.isChecked():
                from pydaw.model.midi import MidiNote
                insert_notes = [MidiNote(pitch=int(n["pitch"]), start_beats=float(n["start"]),
                                         length_beats=float(n["duration"]), velocity=int(n["velocity"]))
                                for n in bass_notes]
                lines.append(f"✅ In Clip eingefügt")
                self._chat_append("assistant", "\n".join(lines))
                self.insert_notes_requested.emit(insert_notes, "replace")
            else:
                self._chat_append("assistant", "\n".join(lines))
            self._status.setText("✅ Bassline generiert")
        except Exception as exc:
            self._chat_append("system", f"⚠ Bassline Fehler: {exc}")

    def _do_melody(self) -> None:
        """Generate melody offline."""
        try:
            from pydaw.music.melody_generator import generate_melody
            import random

            bars = self._bars_spin.value()
            key_root, scale_name = self._get_key_context()
            contour = random.choice(["arch", "ascending", "descending", "wave"])

            mel_notes = generate_melody(root_pc=key_root, scale_name=scale_name,
                                         bars=bars, contour=contour,
                                         seed=random.randint(0, 99999))

            lines = [f"🎵 **Melodie** ({contour}, {bars} Takte)\n"]
            lines.append(f"{len(mel_notes)} Noten generiert")

            if mel_notes and self._auto_ins.isChecked():
                from pydaw.model.midi import MidiNote
                insert_notes = [MidiNote(pitch=int(n["pitch"]), start_beats=float(n["start"]),
                                         length_beats=float(n["duration"]), velocity=int(n["velocity"]))
                                for n in mel_notes]
                lines.append(f"✅ In Clip eingefügt")
                self._chat_append("assistant", "\n".join(lines))
                self.insert_notes_requested.emit(insert_notes, "replace")
            else:
                self._chat_append("assistant", "\n".join(lines))
            self._status.setText("✅ Melodie generiert")
        except Exception as exc:
            self._chat_append("system", f"⚠ Melodie Fehler: {exc}")

    def _do_counterpoint(self) -> None:
        """Generate counterpoint to active clip melody."""
        notes = self._active_clip_notes()
        if not notes:
            self._chat_append("system", "⚠ Kein aktiver Clip. Wähle einen MIDI-Clip mit Melodie.")
            return
        try:
            from pydaw.music.melody_generator import generate_counterpoint
            import random

            key_root, scale_name = self._get_key_context()
            note_dicts = [{"pitch": int(getattr(n, 'pitch', 0)),
                           "start": float(getattr(n, 'start_beats', 0)),
                           "duration": float(getattr(n, 'length_beats', 1)),
                           "velocity": int(getattr(n, 'velocity', 80))} for n in notes]

            motion = random.choice(["contrary", "mixed"])
            cp_notes = generate_counterpoint(note_dicts, root_pc=key_root,
                                              scale_name=scale_name, motion=motion,
                                              seed=random.randint(0, 99999))

            lines = [f"🎶 **Kontrapunkt** ({motion} motion)\n"]
            lines.append(f"{len(cp_notes)} Gegenstimmen-Noten generiert")

            if cp_notes and self._auto_ins.isChecked():
                from pydaw.model.midi import MidiNote
                insert_notes = [MidiNote(pitch=int(n["pitch"]), start_beats=float(n["start"]),
                                         length_beats=float(n["duration"]), velocity=int(n["velocity"]))
                                for n in cp_notes]
                lines.append(f"✅ In Clip eingefügt (zusammen mit Original)")
                self._chat_append("assistant", "\n".join(lines))
                self.insert_notes_requested.emit(insert_notes, "add")
            else:
                self._chat_append("assistant", "\n".join(lines))
            self._status.setText("✅ Kontrapunkt generiert")
        except Exception as exc:
            self._chat_append("system", f"⚠ Kontrapunkt Fehler: {exc}")

    def _do_motif_develop(self) -> None:
        """Develop motif from active clip into 8 bars."""
        notes = self._active_clip_notes()
        if not notes:
            self._chat_append("system", "⚠ Kein aktiver Clip. Wähle einen MIDI-Clip mit 1-2 Takt Motiv.")
            return
        try:
            from pydaw.music.melody_generator import develop_motif

            key_root, scale_name = self._get_key_context()
            note_dicts = [{"pitch": int(getattr(n, 'pitch', 0)),
                           "start": float(getattr(n, 'start_beats', 0)),
                           "duration": float(getattr(n, 'length_beats', 1)),
                           "velocity": int(getattr(n, 'velocity', 80))} for n in notes]

            techniques = ["repetition", "sequence", "inversion", "extension"]
            results = develop_motif(note_dicts, root_pc=key_root,
                                     scale_name=scale_name, techniques=techniques)

            lines = [f"📐 **Motiv-Entwicklung** (4 Techniken)\n"]
            all_notes = list(note_dicts)  # start with original
            for tech, dev_notes in results.items():
                lines.append(f"  {tech}: {len(dev_notes)} Noten")
                all_notes.extend(dev_notes)

            lines.append(f"\n{len(all_notes)} Noten total (Original + Entwicklungen)")

            if all_notes and self._auto_ins.isChecked():
                from pydaw.model.midi import MidiNote
                insert_notes = [MidiNote(pitch=int(n["pitch"]), start_beats=float(n["start"]),
                                         length_beats=float(n["duration"]), velocity=int(n["velocity"]))
                                for n in all_notes]
                lines.append(f"✅ In Clip eingefügt")
                self._chat_append("assistant", "\n".join(lines))
                self.insert_notes_requested.emit(insert_notes, "replace")
            else:
                self._chat_append("assistant", "\n".join(lines))
            self._status.setText("✅ Motiv entwickelt")
        except Exception as exc:
            self._chat_append("system", f"⚠ Motiv-Entwicklung Fehler: {exc}")

    def _do_mix_analysis(self) -> None:
        """Offline mix analysis — analyze all track levels + conflicts."""
        try:
            lines = ["🎚 **Mix-Check** (Offline, kein API-Key nötig)\n"]

            # Try to get track data from services
            svc = self._services
            if svc is None:
                self._chat_append("system", "⚠ Keine Services verfügbar für Mix-Analyse.")
                return

            project = getattr(svc, 'project_service', None) or getattr(svc, 'project', None)
            if project is None:
                self._chat_append("system", "⚠ Kein Projekt geladen.")
                return

            proj = getattr(project, 'project', None)
            if proj is None:
                self._chat_append("system", "⚠ Kein Projekt geladen.")
                return

            tracks = getattr(proj, 'tracks', [])
            if not tracks:
                self._chat_append("system", "⚠ Keine Tracks im Projekt.")
                return

            # Report basic track info without audio (structural analysis)
            lines.append(f"📊 {len(tracks)} Tracks im Projekt:")
            for t in tracks:
                name = getattr(t, 'name', '?')
                kind = getattr(t, 'kind', '?')
                vol = getattr(t, 'volume', 0.8)
                muted = getattr(t, 'muted', False)
                solo = getattr(t, 'solo', False)
                import math
                vol_db = 20.0 * math.log10(max(1e-10, vol))
                status = ""
                if muted:
                    status = " 🔇"
                elif solo:
                    status = " 🎯"
                lines.append(f"  • {name} ({kind}) — {vol_db:+.1f} dB{status}")

            # Check for potential issues
            issues = []
            volumes = [getattr(t, 'volume', 0.8) for t in tracks if not getattr(t, 'muted', False)]
            if volumes:
                avg_vol = sum(volumes) / len(volumes)
                if avg_vol > 0.9:
                    issues.append("⚠ Durchschnittspegel hoch — Headroom prüfen")
                loud = [t for t in tracks if getattr(t, 'volume', 0.8) > 0.95 and not getattr(t, 'muted', False)]
                if loud:
                    names = ", ".join(getattr(t, 'name', '?') for t in loud[:3])
                    issues.append(f"💡 Sehr laute Tracks: {names}")

            # Check sends
            tracks_with_sends = [t for t in tracks if getattr(t, 'sends', [])]
            if tracks_with_sends:
                lines.append(f"\n🔀 {len(tracks_with_sends)} Tracks mit Send-FX")

            # Check FX chains
            fx_count = 0
            for t in tracks:
                chain = getattr(t, 'audio_fx_chain', {})
                devices = chain.get('devices', []) if isinstance(chain, dict) else []
                fx_count += len(devices)
            if fx_count:
                lines.append(f"🎛 {fx_count} FX-Instanzen aktiv")

            if issues:
                lines.append("\n⚠ **Potenzielle Probleme:**")
                for issue in issues:
                    lines.append(f"  {issue}")
            else:
                lines.append("\n✅ Keine offensichtlichen Probleme erkannt")

            lines.append("\n💡 Für detaillierte Audio-Analyse (LUFS, Spektrum, Konflikte):")
            lines.append("   Export → Stems → pydaw.services.smart_mixer.analyze_mix()")

            self._chat_append("assistant", "\n".join(lines))
            self._status.setText("✅ Mix-Check abgeschlossen")
        except Exception as exc:
            self._chat_append("system", f"⚠ Mix-Check Fehler: {exc}")

    # ── v0.0.20.809: Genre Detection (P2B) ────────────────────────────────

    def _do_genre_detect(self) -> None:
        """Offline genre detection — analyze MIDI patterns for genre."""
        try:
            notes = self._active_clip_notes()
            if not notes:
                self._chat_append("system",
                    "⚠ Kein aktiver Clip mit Noten. Wähle einen MIDI-Clip für Genre-Analyse.")
                return

            from pydaw.music.genre_detector import detect_genre_from_midi
            note_dicts = [{"pitch": int(getattr(n, 'pitch', 0)),
                           "start": float(getattr(n, 'start_beats', 0)),
                           "duration": float(getattr(n, 'length_beats', 0.25)),
                           "velocity": int(getattr(n, 'velocity', 80))}
                          for n in notes]

            bpm = 120.0
            try:
                bpm = float(self._lbl_bpm.text().lstrip("♩").strip())
            except Exception:
                pass
            key_name = self._lbl_key.text()

            report = detect_genre_from_midi(note_dicts, bpm=bpm, key_name=key_name)

            lines = ["🎭 **Genre-Erkennung** (Offline, kein API-Key nötig)\n"]
            lines.append(f"📊 {report.note_count} Noten analysiert bei {report.bpm:.0f} BPM\n")

            if report.primary and report.primary.similarity > 0.2:
                p = report.primary
                lines.append(
                    f"🥇 **{p.genre}** — Ähnlichkeit: {p.similarity:.0%} "
                    f"(Konfidenz: {p.confidence})"
                )
                if p.reasons:
                    for r in p.reasons:
                        lines.append(f"   • {r}")
                if p.tags:
                    lines.append(f"   Tags: {', '.join(p.tags)}")

            if report.secondary and report.secondary.similarity > 0.25:
                s = report.secondary
                lines.append(
                    f"\n🥈 **{s.genre}** — Ähnlichkeit: {s.similarity:.0%}"
                )
                if s.tags:
                    lines.append(f"   Tags: {', '.join(s.tags)}")

            # Show top 5
            others = [m for m in report.all_matches[2:5] if m.similarity > 0.2]
            if others:
                lines.append("\n📋 Weitere Kandidaten:")
                for m in others:
                    lines.append(f"   • {m.genre}: {m.similarity:.0%}")

            lines.append(f"\n{report.description}")

            self._chat_append("assistant", "\n".join(lines))
            self._status.setText("✅ Genre-Erkennung abgeschlossen")
        except Exception as exc:
            self._chat_append("system", f"⚠ Genre-Erkennung Fehler: {exc}")

    # ── v0.0.20.809: Reference Track Match (P2B) ─────────────────────────

    def _do_reference_match(self) -> None:
        """Offline reference track analysis — structural comparison."""
        try:
            svc = self._services
            if svc is None:
                self._chat_append("system", "⚠ Keine Services verfügbar.")
                return
            project = getattr(svc, 'project_service', None) or getattr(svc, 'project', None)
            proj = getattr(project, 'project', None) if project else None
            if proj is None:
                self._chat_append("system", "⚠ Kein Projekt geladen.")
                return

            tracks = getattr(proj, 'tracks', [])
            if not tracks:
                self._chat_append("system", "⚠ Keine Tracks im Projekt.")
                return

            lines = ["📊 **Referenz-Vergleich** (Strukturelle Analyse)\n"]
            lines.append("Da kein Referenz-Audio geladen ist, zeige ich eine strukturelle Analyse.\n")
            lines.append(f"📈 **{len(tracks)} Tracks im Projekt:**\n")

            # Structural comparison hints
            import math
            track_types = {}
            total_fx = 0
            for t in tracks:
                kind = getattr(t, 'kind', 'unknown')
                track_types[kind] = track_types.get(kind, 0) + 1
                chain = getattr(t, 'audio_fx_chain', {})
                devices = chain.get('devices', []) if isinstance(chain, dict) else []
                total_fx += len(devices)

            for kind, count in track_types.items():
                lines.append(f"  • {kind}: {count} Track(s)")

            lines.append(f"\n🎛 {total_fx} FX-Instanzen gesamt")

            # Genre-typical recommendations
            recommendations = []
            inst_tracks = sum(1 for t in tracks if getattr(t, 'kind', '') == 'instrument')
            audio_tracks = sum(1 for t in tracks if getattr(t, 'kind', '') == 'audio')
            fx_tracks = sum(1 for t in tracks if getattr(t, 'kind', '') == 'fx')

            if fx_tracks == 0:
                recommendations.append("💡 Kein FX-Return-Track — Send-Reverb/Delay empfohlen")
            if inst_tracks > 0 and audio_tracks == 0:
                recommendations.append("💡 Nur MIDI — Audio-Recording oder Bounce für bessere Kontrolle")
            if total_fx < len(tracks):
                recommendations.append("💡 Wenige FX pro Track — EQ + Kompressor auf jedem Track empfohlen")

            # Volume balance check
            volumes = [(getattr(t, 'name', '?'), getattr(t, 'volume', 0.8))
                       for t in tracks if not getattr(t, 'muted', False)]
            if volumes:
                avg_vol = sum(v for _, v in volumes) / len(volumes)
                avg_db = 20.0 * math.log10(max(1e-10, avg_vol))
                lines.append(f"\n🔊 Durchschnittspegel: {avg_db:+.1f} dB")
                if avg_db > -3:
                    recommendations.append("⚠ Pegel sehr hoch — Headroom für Mastering nötig")
                elif avg_db < -18:
                    recommendations.append("💡 Pegel niedrig — Gain-Staging prüfen")

            if recommendations:
                lines.append("\n🎯 **Empfehlungen:**")
                for r in recommendations:
                    lines.append(f"  {r}")

            lines.append("\n💡 Für Audio-Referenz-Vergleich: WAV exportieren + "
                         "pydaw.services.reference_match nutzen")

            self._chat_append("assistant", "\n".join(lines))
            self._status.setText("✅ Referenz-Analyse abgeschlossen")
        except Exception as exc:
            self._chat_append("system", f"⚠ Referenz-Analyse Fehler: {exc}")

    # ── v0.0.20.809: Preset Generator (P2D) ──────────────────────────────

    def _do_preset_gen(self) -> None:
        """Generate synth preset from description — offline."""
        try:
            from pydaw.services.preset_generator import description_to_preset

            # Use prompt text or default
            desc = self._prompt_edit.toPlainText().strip()
            if not desc or desc.startswith("_"):
                desc = "Warmer Pad mit langem Attack, Chorus und Reverb"
                self._chat_append("system",
                    "💡 Tipp: Schreibe eine Beschreibung ins Eingabefeld, z.B.:\n"
                    "  'Harter 808 Bass mit kurzem Decay'\n"
                    "  'Breiter Supersaw Lead mit Vibrato'\n"
                    "  'Sanftes 80er Pad mit Chorus'\n"
                    "  'Plucky Bell mit langem Reverb'\n\n"
                    f"Verwende Standard-Demo: '{desc}'")

            result = description_to_preset(desc)

            lines = ["🎛 **Preset generiert** (Offline)\n"]
            lines.append(f"🏷 Name: **{result.name}**")
            lines.append(f"📝 {result.description}")
            if result.matched_keywords:
                lines.append(f"🔑 Erkannte Keywords: {', '.join(result.matched_keywords)}")

            # Show description of the generated preset
            from pydaw.services.preset_generator import describe_preset
            preset_desc = describe_preset(result.params, result.name)
            lines.append(f"\n{preset_desc}")

            # Show key params
            lines.append("\n📋 **Parameter (Auszug):**")
            important = ["osc1_waveform", "osc2_waveform", "filter_cutoff",
                         "filter_resonance", "amp_attack", "amp_decay",
                         "amp_sustain", "amp_release", "unison_voices", "chorus_mix",
                         "reverb_mix"]
            for k in important:
                if k in result.params:
                    v = result.params[k]
                    lines.append(f"  • {k}: {v:.3f}" if isinstance(v, float)
                                 else f"  • {k}: {v}")

            self._chat_append("assistant", "\n".join(lines))
            self._prompt_edit.clear()
            self._status.setText("✅ Preset generiert")
        except Exception as exc:
            self._chat_append("system", f"⚠ Preset-Generator Fehler: {exc}")

    # ── v0.0.20.809: Smart Randomize (P2D) ───────────────────────────────

    def _do_smart_random(self) -> None:
        """Smart-randomize a preset — musically aware."""
        try:
            from pydaw.services.preset_generator import smart_randomize, describe_preset

            # Check if user specified character in prompt
            prompt = self._prompt_edit.toPlainText().strip().lower()
            character = "balanced"
            amount = 0.3
            for c in ["timbral", "rhythmic", "gentle", "wild"]:
                if c in prompt:
                    character = c
                    break
            # Amount from prompt
            import re
            m = re.search(r"(\d+)\s*%", prompt)
            if m:
                amount = min(1.0, max(0.05, int(m.group(1)) / 100.0))

            result = smart_randomize(
                amount=amount,
                character=character,
                seed=None,
            )

            lines = ["🎲 **Smart Randomize** (Offline)\n"]
            lines.append(f"🎯 Charakter: {character.capitalize()}, Intensität: {amount:.0%}\n")

            desc = describe_preset(result.params, result.name)
            lines.append(desc)

            lines.append("\n💡 Tipp: Schreibe ins Eingabefeld z.B.:")
            lines.append("  'timbral 50%' — nur Klangfarbe, halbe Intensität")
            lines.append("  'wild 80%' — alles randomisieren, stark")
            lines.append("  'gentle 20%' — sanfte Variationen")

            self._chat_append("assistant", "\n".join(lines))
            self._prompt_edit.clear()
            self._status.setText("✅ Smart Randomize abgeschlossen")
        except Exception as exc:
            self._chat_append("system", f"⚠ Smart-Randomize Fehler: {exc}")

    # ── v0.0.20.809: Preset Description (P2D) ────────────────────────────

    def _do_preset_describe(self) -> None:
        """Describe the current instrument's preset in words."""
        try:
            from pydaw.services.preset_generator import describe_preset

            # Try to get current track's instrument state
            svc = self._services
            project = getattr(svc, 'project_service', None) or getattr(svc, 'project', None)
            proj = getattr(getattr(project, 'ctx', None), 'project', None) if project else None
            if proj is None:
                proj = getattr(project, 'project', None)

            tid = self._selected_track_id()
            trk = None
            if proj and tid:
                trk = next((t for t in getattr(proj, 'tracks', []) if t.id == tid), None)

            if trk is None:
                self._chat_append("system",
                    "⚠ Kein Instrument-Track ausgewählt.\n"
                    "Wähle einen Track mit AETERNA, Fusion oder einem anderen Synth.")
                return

            # Extract params from instrument state
            ist = getattr(trk, 'instrument_state', None) or {}
            name = getattr(trk, 'name', 'Unbekannt')
            ptype = getattr(trk, 'plugin_type', '')

            # Try AETERNA state
            synth_state = (ist.get('aeterna') or ist.get('fusion') or
                           ist.get('synth') or ist)
            if isinstance(synth_state, dict) and synth_state:
                params = {}
                for k, v in synth_state.items():
                    try:
                        params[k] = float(v)
                    except (ValueError, TypeError):
                        pass

                if params:
                    desc = describe_preset(params, f"{name} ({ptype})")
                    lines = [f"📝 **Preset-Beschreibung** für Track '{name}'\n"]
                    lines.append(desc)
                    self._chat_append("assistant", "\n".join(lines))
                    self._status.setText("✅ Preset beschrieben")
                    return

            # Fallback: show basic info
            lines = [f"📝 **Track-Info** für '{name}'\n"]
            lines.append(f"Plugin: {ptype}")
            if ist:
                lines.append(f"State hat {len(ist)} Einträge")
                # Show first few params
                for k in list(ist.keys())[:10]:
                    v = ist[k]
                    lines.append(f"  • {k}: {v}")
            else:
                lines.append("Kein Instrument-State gefunden.")
            lines.append("\n💡 Für detaillierte Beschreibung: AETERNA oder Fusion Synth verwenden")
            self._chat_append("assistant", "\n".join(lines))
            self._status.setText("✅ Track-Info angezeigt")
        except Exception as exc:
            self._chat_append("system", f"⚠ Preset-Beschreibung Fehler: {exc}")

    def _do_variations(self) -> None:
        api_key = self._key_edit.text().strip()
        if not api_key: self._show_no_key(); return
        notes = self._active_clip_notes()
        bars  = self._bars_spin.value()
        if notes:
            prompt = (
                f"Aktives Pattern:\n```\n{_notes_to_summary(notes)}\n```\n\n"
                f"Erstelle exakt 4 Variationen ({bars} Takte je).\n"
                f"Je ein ```json {{\"type\":\"midi_notes\",...}}``` Block:\n"
                f"V1: ruhiger  V2: intensiver  V3: harmonisch reicher  V4: anders"
            )
        else:
            prompt = (
                f"Erstelle 4 verschiedene MIDI-Patterns ({bars} Takte je).\n"
                f"Je ein JSON-Block: V1 ruhig, V2 treibend, V3 komplex, V4 überraschend."
            )
        self._prompt_edit.setPlainText("")
        self._var_box.setVisible(False)
        self._status.setText("⏳ 4 Variationen werden generiert…")
        self._fire(api_key, prompt, variations=True)

    # ── Senden ────────────────────────────────────────────────────────────
    def _on_send(self) -> None:
        api_key = self._key_edit.text().strip()
        if not api_key: self._show_no_key(); return
        prompt = self._prompt_edit.toPlainText().strip()
        if not prompt and not self._attach_bar.get_paths():
            return
        if not prompt:
            prompt = "Analysiere diese Datei(en) für meine Musik-Produktion."
        self._prompt_edit.clear()
        self._fire(api_key, prompt, variations=False)

    def _fire(self, api_key: str, prompt: str, variations: bool) -> None:
        if self._worker and self._worker.isRunning(): return
        if not api_key: self._show_no_key(); return

        # ── Dateien einlesen und Content-Blocks bauen ──
        file_paths = self._attach_bar.get_paths()
        user_content: List[Any] = []

        for path in file_paths:
            block = _read_file_for_api(path)
            if block is None:
                continue
            if block.get("type") == "_multi":
                # ZIP mit Bildern → mehrere Blöcke
                user_content.extend(block["blocks"])
            else:
                user_content.append(block)

        # Text-Prompt als letzten Block
        user_content.append({"type":"text","text":prompt})

        # Wenn nur ein Text-Block → einfacher String (Rückwärts-Kompatibilität History)
        if len(user_content) == 1 and user_content[0]["type"] == "text":
            msg_content: Any = prompt
        else:
            msg_content = user_content

        self._history.append({"role":"user","content": msg_content})

        # Chat-Anzeige: Anhänge anzeigen
        attach_info = ""
        if file_paths:
            names = [Path(p).name for p in file_paths]
            attach_info = f" [📎 {', '.join(names)}]"
        self._chat_append("user", prompt + attach_info)
        self._chat_prefix_assistant()

        # Anhänge für diese Nachricht behalten, dann leeren
        self._attach_bar.clear_files()

        self._send_btn.setEnabled(False)
        self._status.setText(
            f"⏳ KI analysiert" + (f" {len(file_paths)} Datei(en)…" if file_paths else "…")
        )

        self._worker = _StreamWorker(
            api_key, list(self._history),
            self._build_sys(), max_tokens=2000, parent=self)
        self._worker.chunk_received.connect(self._on_chunk)
        self._worker.result_ready.connect(lambda t,v=variations: self._on_done(t,v))
        self._worker.error_occurred.connect(self._on_err)
        self._worker.start()

    # ── Streaming ─────────────────────────────────────────────────────────
    def _on_chunk(self, ch: str) -> None:
        cursor = self._chat.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        fmt = cursor.charFormat()
        fmt.setForeground(QColor("#ddd"))
        cursor.setCharFormat(fmt)
        cursor.insertText(ch)
        self._chat.setTextCursor(cursor)
        self._chat.ensureCursorVisible()

    def _on_done(self, full: str, variations: bool) -> None:
        self._last_raw = full
        self._send_btn.setEnabled(True)
        self._history.append({"role":"assistant","content":full})
        cursor = self._chat.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        cursor.insertText("\n")
        self._chat.setTextCursor(cursor)

        if variations:
            vs = self._parse_vars(full)
            if vs:
                self._show_var_ui(vs)
                self._status.setText(f"✅ {len(vs)} Variationen — Tab wählen und einfügen")
            else:
                self._status.setText("⚠️ Keine Variationen erkannt")
            return

        data = self._parse_midi(full)
        if data:
            n = len(data.get("notes",[]))
            self._status.setText(
                f"✅ {n} Noten" +
                (" — automatisch eingefügt" if self._auto_ins.isChecked() else " — bereit"))
            if self._auto_ins.isChecked():
                self._insert_data(data)
        else:
            self._status.setText("✅ Analyse abgeschlossen")

    def _on_err(self, msg: str) -> None:
        self._send_btn.setEnabled(True)
        self._status.setText(f"❌ {msg[:80]}")
        self._chat_append("error", f"Fehler: {msg}")
        if self._history and self._history[-1]["role"] == "user":
            self._history.pop()

    # ── Chat-Anzeige ───────────────────────────────────────────────────────
    def _chat_append(self, role: str, text: str) -> None:
        colors  = {"user":"#4fc3f7","assistant":"#a5d6a7","error":"#ef9a9a"}
        labels  = {"user":"Du","assistant":"KI","error":"Fehler"}
        color   = colors.get(role,"#ccc")
        label   = labels.get(role,role)
        cursor  = self._chat.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        fmt = cursor.charFormat(); fmt.setForeground(QColor(color))
        cursor.setCharFormat(fmt); cursor.insertText(f"\n[{label}] ")
        fmt2 = cursor.charFormat(); fmt2.setForeground(QColor("#ddd"))
        cursor.setCharFormat(fmt2)
        disp = text if len(text) <= 500 else text[:500]+"…"
        cursor.insertText(disp+"\n")
        self._chat.setTextCursor(cursor)
        self._chat.ensureCursorVisible()

    def _chat_prefix_assistant(self) -> None:
        cursor = self._chat.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        fmt = cursor.charFormat(); fmt.setForeground(QColor("#a5d6a7"))
        cursor.setCharFormat(fmt); cursor.insertText("\n[KI] ")
        fmt2 = cursor.charFormat(); fmt2.setForeground(QColor("#ddd"))
        cursor.setCharFormat(fmt2)
        self._chat.setTextCursor(cursor)

    def _clear_chat(self) -> None:
        self._history.clear(); self._chat.clear()
        self._last_raw = ""; self._var_box.setVisible(False)
        self._attach_bar.clear_files()
        self._status.setText("Chat gelöscht")

    # ── MIDI-Parsing ───────────────────────────────────────────────────────
    def _parse_midi(self, text: str) -> Optional[Dict[str,Any]]:
        # 1. Wrapped format: {"type":"midi_notes","notes":[...]}
        m = re.search(r"```json\s*(\{.*?\})\s*```", text, re.DOTALL)
        if not m:
            m = re.search(r'(\{"type":\s*"midi_notes".*?\})', text, re.DOTALL)
        if m:
            try:
                d = json.loads(m.group(1))
                if d.get("type") == "midi_notes" and "notes" in d:
                    return d
            except Exception:
                pass

        # 2. Loose JSON array of note objects: [{"pitch":38,...},...]
        m2 = re.search(r'```json\s*(\[.*?\])\s*```', text, re.DOTALL)
        if not m2:
            m2 = re.search(r'(\[\s*\{\s*"pitch"\s*:.*?\])', text, re.DOTALL)
        if m2:
            try:
                arr = json.loads(m2.group(1))
                if isinstance(arr, list) and len(arr) > 0 and "pitch" in arr[0]:
                    return {"type": "midi_notes", "notes": arr}
            except Exception:
                pass

        # 3. Scattered note objects: {"pitch":38,"start_beats":...} on separate lines
        note_objs = re.findall(
            r'\{\s*"pitch"\s*:\s*\d+\s*,\s*"start_beats"\s*:\s*[\d.]+\s*,'
            r'\s*"length_beats"\s*:\s*[\d.]+\s*(?:,\s*"velocity"\s*:\s*\d+\s*)?\}',
            text
        )
        if len(note_objs) >= 2:
            notes = []
            for ns in note_objs:
                try:
                    notes.append(json.loads(ns))
                except Exception:
                    pass
            if notes:
                return {"type": "midi_notes", "notes": notes}

        return None

    def _parse_vars(self, text: str) -> List[Tuple[str,list]]:
        blocks = re.findall(r"```json\s*(\{.*?\})\s*```", text, re.DOTALL)
        if not blocks:
            blocks = re.findall(r'(\{"type":\s*"midi_notes".*?\})', text, re.DOTALL)
        result = []
        for b in blocks:
            try:
                d = json.loads(b)
                if d.get("type") == "midi_notes" and "notes" in d:
                    ns = self._build_notes(d["notes"])
                    if ns:
                        result.append((str(d.get("description",f"Variation {len(result)+1}")),ns))
            except Exception: pass
        return result

    def _build_notes(self, raw: list) -> list:
        from pydaw.model.midi import MidiNote
        out = []
        for n in raw:
            try:
                out.append(MidiNote(
                    pitch=int(n["pitch"]),
                    start_beats=float(n["start_beats"]),
                    length_beats=float(n["length_beats"]),
                    velocity=int(n.get("velocity",80)),
                ).clamp())
            except Exception: pass
        return out

    # ── Variations-UI ──────────────────────────────────────────────────────
    def _show_var_ui(self, variations: List[Tuple[str,list]]) -> None:
        if self._var_widget:
            self._var_lay.removeWidget(self._var_widget)
            self._var_widget.deleteLater()
        self._var_widget = _VariationsWidget(variations, self._var_box)
        self._var_widget.variation_selected.connect(self._on_var_selected)
        self._var_lay.addWidget(self._var_widget)
        self._var_box.setVisible(True)

    def _on_var_selected(self, notes: list, idx: int) -> None:
        tid = self._selected_track_id()
        self.insert_notes_requested.emit(notes, tid or "")
        self._status.setText(f"✅ Variation {idx} ({len(notes)} Noten) eingefügt")
        self.status_message.emit(f"KI: Variation {idx} eingefügt")

    # ── Einfügen ───────────────────────────────────────────────────────────
    def _insert_data(self, data: Dict[str,Any]) -> None:
        notes = self._build_notes(data.get("notes",[]))
        if notes:
            tid = self._selected_track_id()
            self.insert_notes_requested.emit(notes, tid or "")
            self.status_message.emit(f"KI: {len(notes)} MIDI-Noten eingefügt")

    def _selected_track_id(self) -> Optional[str]:
        try:
            ps = getattr(self._services,"project",None)
            if not ps: return None
            tid = getattr(ps,"_selected_track_id",None)
            if tid: return str(tid)
            proj = getattr(getattr(ps,"ctx",None),"project",None)
            if proj:
                for t in getattr(proj,"tracks",[]):
                    if getattr(t,"kind","") == "instrument":
                        return t.id
        except Exception: pass
        return None

    # ── System-Prompt ──────────────────────────────────────────────────────
    def _build_sys(self) -> str:
        bpm  = self._lbl_bpm.text().lstrip("♩")
        key  = self._lbl_key.text()
        ts   = self._lbl_ts.text()
        bars = self._bars_spin.value()
        track_ctx = self._get_track_context()
        return (
            f"Du bist KI-Kompositions-Assistent für Py_DAW.\n"
            f"BPM={bpm} Tonart={key} Taktart={ts} Takte={bars}\n\n"
            f"{track_ctx}"
            f"MIDI-Format für Noten-Output:\n"
            f"```json\n"
            f'{{\"type\":\"midi_notes\",\"description\":\"...\",\"notes\":'
            f'[{{\"pitch\":60,\"start_beats\":0.0,\"length_beats\":0.5,\"velocity\":80}}]}}\n'
            f"```\n"
            f"pitch=MIDI 0-127(60=C4), start_beats=Viertelposition, "
            f"length_beats=Dauer, velocity=1-127\n\n"
            f"Du kannst auch Bilder analysieren (Spektrogramme, Screenshots, Waveforms), "
            f"JSON/ZIP/MIDI-Dateien (.mid) lesen und "
            f"konkrete Verbesserungsvorschläge für Musik-Produktion machen.\n"
            f"Antworte auf Deutsch."
        )

    def _get_track_context(self) -> str:
        """Instrument-Kontext für den aktiven Track: Was, wo Noten hingehören."""
        try:
            ps = getattr(self._services, "project", None)
            proj = getattr(getattr(ps, "ctx", None), "project", None)
            if not proj:
                return ""
            tid = self._selected_track_id() or ""
            if not tid:
                return ""
            trk = next((t for t in proj.tracks if t.id == tid), None)
            if not trk:
                return ""

            name = getattr(trk, "name", "") or ""
            kind = getattr(trk, "kind", "") or ""
            ptype = getattr(trk, "plugin_type", "") or ""

            lines = [f"AKTIVER TRACK: \"{name}\" (kind={kind}, plugin={ptype})"]

            # ── Instrument-spezifische Pitch-Hilfe ──
            pt_lower = ptype.lower()
            name_lower = name.lower()
            if "drum" in pt_lower or "drum" in name_lower:
                lines.append(self._read_drum_mapping(trk))
            elif "bass" in name_lower or "bass" in pt_lower:
                lines.append(
                    "BASS: Noten C1-C3 (MIDI 24-48). Root auf starke Zählzeiten."
                )
            elif "pad" in name_lower or "aeterna" in pt_lower:
                lines.append(
                    "PAD/SYNTH: C3-C5 (MIDI 48-72). Lange Noten, Akkorde."
                )
            elif "brrr" in pt_lower:
                lines.append(
                    "BRRR Flutter Synth: C2-C5 (MIDI 36-72). Tiefe Noten klingen am besten."
                )
            elif "orgel" in name_lower or "bach" in pt_lower or "organ" in name_lower:
                lines.append(
                    "ORGEL: C2-C6 (MIDI 36-84). Akkorde, Polyphonie."
                )
            elif "fusion" in pt_lower:
                lines.append(
                    "FUSION Hybrid Synth: C2-C6 (MIDI 36-84). Flexibel für alles."
                )
            elif "sampler" in pt_lower:
                lines.append(
                    "SAMPLER: C4(60)=Root-Note. Bereich je nach Sample."
                )
            elif kind == "instrument":
                lines.append(
                    "INSTRUMENT: C3-C5 (MIDI 48-72). Melodien, Akkorde."
                )

            return "\n".join(lines) + "\n\n"
        except Exception:
            return ""

    def _read_drum_mapping(self, trk) -> str:
        """Echte Pad-Namen aus der Drum Machine lesen, nicht GM-Defaults raten."""
        _DEFAULTS = [
            "Kick", "Snare", "CHat", "OHat",
            "Clap", "Tom", "Perc", "Rim",
            "FX1", "FX2", "Ride", "Crash",
        ]
        base_note = 36  # C2
        pad_names = list(_DEFAULTS)

        # Versuche echte Namen aus instrument_state zu lesen
        try:
            ist = getattr(trk, "instrument_state", None) or {}
            dm_state = ist.get("drum_machine")
            if isinstance(dm_state, dict):
                base_note = int(dm_state.get("base_note", 36))
                for slot in dm_state.get("slots", []):
                    idx = int(slot.get("index", -1))
                    name = str(slot.get("name", ""))
                    if 0 <= idx < 64 and name:
                        while len(pad_names) <= idx:
                            pad_names.append(f"Pad{len(pad_names)+1}")
                        pad_names[idx] = name
        except Exception:
            pass

        # Mapping-Text bauen (nur belegte Pads, max 16 für Kontext)
        lines = ["DRUM-PAD-MAPPING (echte Pad-Namen aus dem Projekt):"]
        for i, pname in enumerate(pad_names[:16]):
            midi = base_note + i
            note_name = _midi_to_name(midi)
            lines.append(f"  {note_name}({midi})={pname}")
        lines.append(
            "WICHTIG: Drum-Noten sind kurz (length_beats=0.25)!\n"
            "Typisch: Kick auf Beat 1+3, Snare auf 2+4, HiHat auf jeden Achtel.\n"
            "Verwende NUR die obigen Pitch-Werte für Drums!"
        )
        return "\n".join(lines)

    # ── Kein-Key ────────────────────────────────────────────────────────────
    def _show_no_key(self) -> None:
        self._chat.setMarkdown(
            "**🔑 API-Key fehlt**\n\n"
            "1. [console.anthropic.com](https://console.anthropic.com)\n"
            "2. API-Key erstellen\n"
            "3. Oben einfügen → 💾\n\n*Lokal gespeichert.*")
        self._key_edit.setFocus()
        self._status.setText("❌ Kein API-Key")

    # ── Settings ────────────────────────────────────────────────────────────
    def _save_api_key(self) -> None:
        self._settings.setValue("api_key", self._key_edit.text().strip())
        self._status.setText("💾 Gespeichert")

    def _load_settings(self) -> None:
        k = self._settings.value("api_key","")
        if k: self._key_edit.setText(str(k))
