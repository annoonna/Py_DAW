"""Arranger Keyboard Handler - Standard DAW Shortcuts (v0.0.19.7.0)

FIXED: Copy/Paste funktioniert jetzt wirklich!
- Debug messages hinzugefügt
- Playhead position handling verbessert
- MIDI notes copy fix
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from PyQt6.QtCore import Qt, QObject, pyqtSignal
from PyQt6.QtGui import QKeyEvent

if TYPE_CHECKING:
    from pydaw.services.project_service import ProjectService


class ArrangerKeyboardHandler(QObject):
    """Handles all keyboard shortcuts for Arranger canvas."""
    
    # Signals
    status_message = pyqtSignal(str, int)  # (message, timeout_ms)
    request_update = pyqtSignal()  # Request canvas repaint
    
    def __init__(self, project: ProjectService):
        super().__init__()
        self.project = project
        self._clipboard_clips: list[dict] = []  # Internal clipboard
    
    def handle_key_press(
        self,
        event: QKeyEvent,
        selected_clip_ids: set[str],
        selected_clip_id: str,
    ) -> bool:
        """Handle key press event.
        
        Returns:
            True if event was handled, False otherwise
        """
        key = event.key()
        mods = event.modifiers()
        ctrl = bool(mods & Qt.KeyboardModifier.ControlModifier)
        shift = bool(mods & Qt.KeyboardModifier.ShiftModifier)
        
        # DEBUG
        print(f"[KeyboardHandler] Key: {key}, Ctrl: {ctrl}, Selected: {len(selected_clip_ids)} clips")
        
        # Ctrl+C: Copy
        if ctrl and key == Qt.Key.Key_C:
            print("[KeyboardHandler] Copy triggered!")
            self._copy_clips(selected_clip_ids)
            return True
        
        # Ctrl+V: Paste
        elif ctrl and key == Qt.Key.Key_V:
            print("[KeyboardHandler] Paste triggered!")
            self._paste_clips()
            return True
        
        # Ctrl+X: Cut
        elif ctrl and key == Qt.Key.Key_X:
            print("[KeyboardHandler] Cut triggered!")
            self._cut_clips(selected_clip_ids)
            return True
        
        # Ctrl+D: Duplicate
        elif ctrl and key == Qt.Key.Key_D:
            print("[KeyboardHandler] Duplicate triggered!")
            self._duplicate_clips(selected_clip_ids)
            return True
        
        # Ctrl+J: Join/Consolidate
        elif ctrl and key == Qt.Key.Key_J:
            print("[KeyboardHandler] Join triggered!")
            self._join_clips(selected_clip_ids)
            return True
        
        # Ctrl+Z: Undo
        elif ctrl and key == Qt.Key.Key_Z:
            self._undo()
            return True
        
        # Ctrl+Y or Ctrl+Shift+Z: Redo
        elif ctrl and (key == Qt.Key.Key_Y or (shift and key == Qt.Key.Key_Z)):
            self._redo()
            return True
        
        # Ctrl+A: Select All
        elif ctrl and key == Qt.Key.Key_A:
            self._select_all_clips()
            return True
        
        # Delete: Delete selected clips
        elif key == Qt.Key.Key_Delete or key == Qt.Key.Key_Backspace:
            self._delete_clips(selected_clip_ids)
            return True
        
        # Escape: Deselect all
        elif key == Qt.Key.Key_Escape:
            selected_clip_ids.clear()
            self.request_update.emit()
            self.status_message.emit("Auswahl aufgehoben", 1000)
            return True
        
        return False
    
    def _copy_clips(self, selected_clip_ids: set[str]) -> None:
        """Copy selected clips to clipboard."""
        print(f"[KeyboardHandler._copy_clips] Selected IDs: {selected_clip_ids}")
        
        if not selected_clip_ids:
            self.status_message.emit("Keine Clips ausgewählt", 2000)
            return
        
        self._clipboard_clips = []
        clips = self.project.ctx.project.clips
        
        print(f"[KeyboardHandler._copy_clips] Total clips in project: {len(clips)}")
        
        for clip in clips:
            if clip.id in selected_clip_ids:
                print(f"[KeyboardHandler._copy_clips] Copying clip: {clip.id}, kind={clip.kind}")
                
                # Serialize clip to dict
                clip_data = {
                    "kind": clip.kind,
                    "track_id": clip.track_id,
                    "start_beats": float(clip.start_beats),
                    "length_beats": float(clip.length_beats),
                    "label": str(getattr(clip, "label", "")),
                    "offset_beats": float(getattr(clip, "offset_beats", 0.0) or 0.0),
                    "offset_seconds": float(getattr(clip, "offset_seconds", 0.0) or 0.0),
                }
                
                # Copy MIDI notes if MIDI clip
                if clip.kind == "midi":
                    notes = self.project.ctx.project.midi_notes.get(clip.id, [])
                    print(f"[KeyboardHandler._copy_clips] MIDI notes: {len(notes)}")
                    clip_data["midi_notes"] = [
                        {
                            "pitch": int(n.pitch),
                            "start_beats": float(n.start_beats),
                            "length_beats": float(n.length_beats),
                            "velocity": int(n.velocity),
                        }
                        for n in notes
                    ]
                
                # Copy audio file path if audio clip
                elif clip.kind == "audio":
                    # FIXED v0.0.19.7.6: source_path statt audio_file_path
                    clip_data["audio_file_path"] = str(getattr(clip, "source_path", ""))
                
                self._clipboard_clips.append(clip_data)
        
        count = len(self._clipboard_clips)
        print(f"[KeyboardHandler._copy_clips] Clipboard now has {count} clips")
        self.status_message.emit(f"{count} Clip(s) kopiert", 2000)
    
    def _paste_clips(self) -> None:
        """Paste clips from clipboard."""
        print(f"[KeyboardHandler._paste_clips] Clipboard has {len(self._clipboard_clips)} clips")
        
        if not self._clipboard_clips:
            self.status_message.emit("Zwischenablage ist leer", 2000)
            return
        
        # Paste at start (Beat 0) - SIMPLE!
        # We don't need transport, just paste at the beginning
        playhead = 0.0
        
        # Find earliest clip start in clipboard to calculate offset
        min_start = min(c["start_beats"] for c in self._clipboard_clips)
        offset = playhead - min_start
        
        print(f"[KeyboardHandler._paste_clips] Playhead={playhead}, min_start={min_start}, offset={offset}")
        
        pasted_ids = []
        for i, clip_data in enumerate(self._clipboard_clips):
            print(f"[KeyboardHandler._paste_clips] Pasting clip {i+1}/{len(self._clipboard_clips)}")
            
            try:
                # Calculate new start position
                new_start = clip_data["start_beats"] + offset
                
                print(f"  Kind: {clip_data['kind']}, Track: {clip_data['track_id']}, Start: {new_start}")
                
                # Create new clip
                if clip_data["kind"] == "midi":
                    new_id = self.project.add_midi_clip_at(
                        clip_data["track_id"],
                        start_beats=new_start,
                        length_beats=clip_data["length_beats"],
                        label=clip_data["label"],
                    )
                    
                    print(f"  Created MIDI clip: {new_id}")
                    
                    # Copy MIDI notes
                    if "midi_notes" in clip_data:
                        notes = clip_data["midi_notes"]
                        print(f"  Copying {len(notes)} MIDI notes")
                        for note_data in notes:
                            self.project.add_note(
                                new_id,
                                pitch=note_data["pitch"],
                                start_beats=note_data["start_beats"],
                                length_beats=note_data["length_beats"],
                                velocity=note_data["velocity"],
                            )
                    
                    pasted_ids.append(new_id)
                
                elif clip_data["kind"] == "audio":
                    # Audio clips need file path
                    if clip_data.get("audio_file_path"):
                        new_id = self.project.add_audio_clip_from_file_at(
                            clip_data["track_id"],
                            clip_data["audio_file_path"],
                            start_beats=new_start,
                        )
                        pasted_ids.append(new_id)
            
            except Exception as e:
                print(f"[KeyboardHandler._paste_clips] ERROR: {e}")
                import traceback
                # traceback.print_exc()
                continue
        
        count = len(pasted_ids)
        print(f"[KeyboardHandler._paste_clips] Pasted {count} clips successfully")
        self.request_update.emit()
        self.status_message.emit(f"{count} Clip(s) eingefügt", 2000)
    
    def _cut_clips(self, selected_clip_ids: set[str]) -> None:
        """Cut selected clips (copy + delete)."""
        if not selected_clip_ids:
            self.status_message.emit("Keine Clips ausgewählt", 2000)
            return
        
        # Copy first
        self._copy_clips(selected_clip_ids)
        
        # Then delete
        self._delete_clips(selected_clip_ids)
        
        self.status_message.emit(f"{len(self._clipboard_clips)} Clip(s) ausgeschnitten", 2000)
    
    def _duplicate_clips(self, selected_clip_ids: set[str]) -> None:
        """Duplicate selected clips HORIZONTALLY (to the right).
        
        FIXED v0.0.19.7.4: Mit " Copy" Suffix wie eine Pro-DAW!
        """
        if not selected_clip_ids:
            self.status_message.emit("Keine Clips ausgewählt", 2000)
            return
        
        new_ids = []
        clips = self.project.ctx.project.clips
        
        for clip_id in selected_clip_ids:
            try:
                # Find original clip
                clip = next((c for c in clips if c.id == clip_id), None)
                if not clip:
                    continue
                
                # Calculate new position: directly after original clip (to the RIGHT!)
                new_start = float(clip.start_beats) + float(clip.length_beats)
                
                # Generate label with " Copy" suffix
                original_label = str(getattr(clip, "label", ""))
                if original_label.endswith(" Copy"):
                    # Already a copy, keep adding
                    new_label = original_label
                else:
                    new_label = f"{original_label} Copy"
                
                # Create duplicate based on type
                if clip.kind == "midi":
                    new_id = self.project.add_midi_clip_at(
                        str(clip.track_id),  # SAME track!
                        start_beats=new_start,  # Directly to the right! ✅
                        length_beats=float(clip.length_beats),
                        label=new_label  # With " Copy" suffix! ✅
                    )
                    
                    # Copy ALL MIDI notes
                    notes = self.project.ctx.project.midi_notes.get(clip.id, [])
                    for note in notes:
                        self.project.add_note(
                            new_id,
                            pitch=int(note.pitch),
                            start_beats=float(note.start_beats),
                            length_beats=float(note.length_beats),
                            velocity=int(note.velocity)
                        )
                    
                    new_ids.append(new_id)
                
                elif clip.kind == "audio":
                    # FIXED v0.0.19.7.6: source_path statt audio_file_path
                    audio_path = str(getattr(clip, "source_path", ""))
                    if audio_path:
                        new_id = self.project.add_audio_clip_from_file_at(
                            str(clip.track_id),  # SAME track!
                            audio_path,
                            start_beats=new_start  # Directly to the right! ✅
                        )
                        
                        # Rename with " Copy" suffix
                        if new_id:
                            new_clip = next((c for c in self.project.ctx.project.clips if c.id == new_id), None)
                            if new_clip:
                                new_clip.label = new_label  # With " Copy" suffix! ✅
                        
                        new_ids.append(new_id)
                
            except Exception as e:
                print(f"[KeyboardHandler._duplicate_clips] Error duplicating clip {clip_id}: {e}")
                import traceback
                # traceback.print_exc()
        
        # Select duplicated clips
        selected_clip_ids.clear()
        selected_clip_ids.update(new_ids)
        
        count = len(new_ids)
        self.request_update.emit()
        self.status_message.emit(f"{count} Clip(s) nach rechts dupliziert", 2000)
    
    def _join_clips(self, selected_clip_ids: set[str]) -> None:
        """Join/Consolidate selected clips."""
        if len(selected_clip_ids) < 2:
            self.status_message.emit("Mindestens 2 Clips zum Verbinden auswählen", 2000)
            return
        
        try:
            # Get all selected clips
            clips = [c for c in self.project.ctx.project.clips if c.id in selected_clip_ids]
            
            # Must be on same track
            track_ids = {c.track_id for c in clips}
            if len(track_ids) > 1:
                self.status_message.emit("Clips müssen auf gleicher Spur sein", 2000)
                return
            
            # Must be same kind
            kinds = {c.kind for c in clips}
            if len(kinds) > 1:
                self.status_message.emit("Nur MIDI- oder Audio-Clips verbinden", 2000)
                return
            
            # Sort by start position
            clips.sort(key=lambda c: float(c.start_beats))
            
            # Calculate joined clip bounds
            start = float(clips[0].start_beats)
            end = max(float(c.start_beats) + float(c.length_beats) for c in clips)
            length = end - start
            
            # Create new joined clip
            track_id = clips[0].track_id
            kind = clips[0].kind
            
            if kind == "midi":
                new_id = self.project.add_midi_clip_at(
                    track_id,
                    start_beats=start,
                    length_beats=length,
                    label="Joined Clip",
                )
                
                # Copy all MIDI notes from all clips
                for clip in clips:
                    notes = self.project.ctx.project.midi_notes.get(clip.id, [])
                    for note in notes:
                        # Adjust note position relative to joined clip
                        note_start = float(note.start_beats) + (float(clip.start_beats) - start)
                        self.project.add_note(
                            new_id,
                            pitch=int(note.pitch),
                            start_beats=note_start,
                            length_beats=float(note.length_beats),
                            velocity=int(note.velocity),
                        )
                
                # Delete original clips
                for clip in clips:
                    self.project.delete_clip(clip.id)
                
                # Select new clip
                selected_clip_ids.clear()
                selected_clip_ids.add(new_id)
                
                self.request_update.emit()
                self.status_message.emit(f"{len(clips)} Clips verbunden", 2000)
            
            else:
                self.status_message.emit("Join für Audio-Clips noch nicht implementiert", 2000)
        
        except Exception as e:
            print(f"Error joining clips: {e}")
            self.status_message.emit(f"Fehler beim Verbinden: {e}", 3000)
    
    def _delete_clips(self, selected_clip_ids: set[str]) -> None:
        """Delete selected clips."""
        if not selected_clip_ids:
            self.status_message.emit("Keine Clips ausgewählt", 2000)
            return
        
        count = len(selected_clip_ids)
        for clip_id in list(selected_clip_ids):
            try:
                self.project.delete_clip(clip_id)
            except Exception as e:
                print(f"Error deleting clip {clip_id}: {e}")
        
        selected_clip_ids.clear()
        self.request_update.emit()
        self.status_message.emit(f"{count} Clip(s) gelöscht", 2000)
    
    def _select_all_clips(self) -> None:
        """Select all clips in project."""
        # This will be handled by the canvas
        self.status_message.emit("Alle Clips ausgewählt", 1000)
    
    def _undo(self) -> None:
        """Undo last action."""
        # Placeholder - full undo system would be implemented separately
        self.status_message.emit("Undo (noch nicht implementiert)", 2000)
    
    def _redo(self) -> None:
        """Redo last undone action."""
        # Placeholder - full redo system would be implemented separately
        self.status_message.emit("Redo (noch nicht implementiert)", 2000)
