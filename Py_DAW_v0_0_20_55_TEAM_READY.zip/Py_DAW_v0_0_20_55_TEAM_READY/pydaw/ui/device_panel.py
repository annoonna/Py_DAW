# -*- coding: utf-8 -*-
"""Device Panel — per-track device chain (Pro-DAW-Style).

v0.0.19.7.55:
- Per-track device binding: each track has its own device chain
- show_track(track_id): hides all, shows only selected track devices
- add_instrument_to_track(track_id, plugin_id): binds device to track
- Widgets hidden/shown (not destroyed) for state preservation
- Single view: only one track's devices visible at a time
"""
from __future__ import annotations

from typing import Dict, List, Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QWidget, QLabel, QVBoxLayout, QHBoxLayout, QScrollArea,
    QFrame, QSizePolicy, QPushButton,
)

from pydaw.plugins.registry import get_instruments


class _DeviceBox(QFrame):
    """Container for a single device widget with title bar and close button."""
    def __init__(self, title: str, inner: QWidget, on_close=None, parent=None):
        super().__init__(parent)
        self.setObjectName("deviceBox")
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumWidth(400)
        self.setMaximumWidth(1400)
        self.inner_widget = inner

        outer = QVBoxLayout(self)
        outer.setContentsMargins(6, 4, 6, 6)
        outer.setSpacing(4)

        top = QHBoxLayout()
        lab = QLabel(title)
        lab.setObjectName("deviceBoxTitle")
        lab.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        btn = QPushButton("✕")
        btn.setFixedWidth(28)
        btn.setFixedHeight(20)
        btn.setToolTip("Remove device")
        btn.clicked.connect(lambda: on_close() if callable(on_close) else None)
        top.addWidget(lab, 1)
        top.addWidget(btn, 0)

        outer.addLayout(top)
        outer.addWidget(inner, 1)


class DevicePanel(QWidget):
    """Bottom device view — per-track device chain (Pro-DAW-Style)."""

    def __init__(self, services=None, parent=None):
        super().__init__(parent)
        self.setObjectName("devicePanel")
        self._services = services

        # Per-track device storage: {track_id: [{"box": _DeviceBox, "widget": QWidget, "plugin_id": str}]}
        self._track_chains: Dict[str, List[dict]] = {}
        self._current_track: str = ""

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 8, 12, 8)
        layout.setSpacing(6)

        title = QLabel("Device")
        title.setObjectName("devicePanelTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFrameShadow(QFrame.Shadow.Sunken)

        # Scroll area for horizontal device chain
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)

        self.chain_host = QWidget()
        self.chain_host.setObjectName("deviceChainHost")
        self.chain_host.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        self.chain = QHBoxLayout(self.chain_host)
        self.chain.setContentsMargins(0, 0, 0, 0)
        self.chain.setSpacing(8)

        self.empty_label = QLabel("Kein Device geladen.\nBrowser → Instruments → 'Add to Device'.")
        self.empty_label.setObjectName("devicePanelEmpty")
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.empty_label.setStyleSheet("color:#9a9a9a;")

        self.chain.addWidget(self.empty_label)
        self.chain.addStretch(1)
        self.scroll.setWidget(self.chain_host)

        layout.addWidget(title)
        layout.addWidget(sep)
        layout.addWidget(self.scroll, 1)

    # ---- Public API

    def show_track(self, track_id: str) -> None:
        """Switch device panel to show only the given track's devices."""
        track_id = str(track_id or "")
        self._current_track = track_id

        # Hide all device boxes from all tracks
        for tid, chain in self._track_chains.items():
            for entry in chain:
                try:
                    entry["box"].setVisible(tid == track_id)
                except Exception:
                    pass

        self._refresh_empty_state()

    def add_instrument_to_track(self, track_id: str, plugin_id: str) -> bool:
        """Add an instrument device to a specific track's chain."""
        track_id = str(track_id or "")
        plugin_id = (plugin_id or "").strip()
        if not plugin_id or not track_id:
            return False

        instruments = {i.plugin_id: i for i in get_instruments()}
        spec = instruments.get(plugin_id)
        if spec is None:
            return False

        project = getattr(self._services, "project", None) if self._services else None
        audio_engine = getattr(self._services, "audio_engine", None) if self._services else None

        try:
            w = spec.factory(project_service=project, audio_engine=audio_engine)
        except Exception as e:
            w = QLabel(f"Fehler: {e}")

        w.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        # Set track_id on widget if supported
        if hasattr(w, "track_id"):
            w.track_id = track_id
        
        # v0.0.20.46: Call set_track_context for proper pull-source registration
        if hasattr(w, "set_track_context"):
            try:
                w.set_track_context(track_id)
            except Exception:
                pass

        entry = {"widget": w, "plugin_id": plugin_id, "box": None}

        def _remove():
            try:
                if hasattr(w, "shutdown"):
                    w.shutdown()
            except Exception:
                pass
            try:
                entry["box"].setParent(None)
                entry["box"].deleteLater()
            except Exception:
                pass
            try:
                chain = self._track_chains.get(track_id, [])
                if entry in chain:
                    chain.remove(entry)
            except Exception:
                pass
            self._refresh_empty_state()

        box = _DeviceBox(spec.name, w, on_close=_remove)
        entry["box"] = box

        # Add to track chain
        if track_id not in self._track_chains:
            self._track_chains[track_id] = []
        self._track_chains[track_id].append(entry)

        # Insert into layout (before stretch)
        self.chain.insertWidget(max(0, self.chain.count() - 1), box, 1)

        # Show only if this is the current track
        box.setVisible(track_id == self._current_track)
        self._refresh_empty_state()
        return True

    def has_device_for_track(self, track_id: str) -> bool:
        """Check if a track already has devices."""
        return len(self._track_chains.get(str(track_id), [])) > 0

    def get_track_devices(self, track_id: str) -> list:
        """Return device widgets for a track."""
        return [e["widget"] for e in self._track_chains.get(str(track_id), [])]

    def remove_track_devices(self, track_id: str) -> None:
        """Remove all devices for a track (on track deletion)."""
        track_id = str(track_id)
        chain = self._track_chains.pop(track_id, [])
        for entry in chain:
            try:
                w = entry["widget"]
                if hasattr(w, "shutdown"):
                    w.shutdown()
            except Exception:
                pass
            try:
                entry["box"].setParent(None)
                entry["box"].deleteLater()
            except Exception:
                pass
        self._refresh_empty_state()

    # Legacy compat: add_instrument without track_id uses current track
    def add_instrument(self, plugin_id: str) -> bool:
        tid = self._current_track
        if not tid:
            return False
        return self.add_instrument_to_track(tid, plugin_id)

    # ---- Internal

    def _refresh_empty_state(self) -> None:
        has_visible = False
        for entry in self._track_chains.get(self._current_track, []):
            try:
                if entry["box"].isVisible():
                    has_visible = True
                    break
            except Exception:
                pass
        try:
            self.empty_label.setVisible(not has_visible)
        except Exception:
            pass
