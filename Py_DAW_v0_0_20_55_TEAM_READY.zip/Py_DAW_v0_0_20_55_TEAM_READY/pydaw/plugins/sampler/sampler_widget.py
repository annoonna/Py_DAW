# -*- coding: utf-8 -*-
"""Pro Audio Sampler — compact Pro-DAW-Style device widget (PyQt6).

v0.0.19.7.55 — Complete rewrite:
- Compact horizontal layout matching Pro-DAW device panel height (~200-240px)
- Per-track binding via track_id property
- Multi-format audio: WAV, MP3, FLAC, OGG, AIFF, M4A, WV
- QPainter knobs (no QDial, smaller footprint)
- Waveform strip 40-60px
- All controls visible without scrolling
"""
from __future__ import annotations

from pathlib import Path
import uuid

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QGroupBox, QComboBox,
    QSlider, QMessageBox, QFileDialog, QCheckBox,
    QSizePolicy, QFrame,
)

from .sampler_engine import ProSamplerEngine
from .ui_widgets import CompactKnob, WaveformDisplay
from .audio_io import SUPPORTED_EXTENSIONS

_AUDIO_FILTER = "Audio files ({});;All files (*)".format(
    " ".join(f"*{e}" for e in sorted(SUPPORTED_EXTENSIONS))
)


class SamplerWidget(QWidget):
    """Compact Pro-DAW-Style sampler device."""

    # Emitted when this sampler wants to signal something to the device panel
    status_message = pyqtSignal(str)

    def __init__(self, project_service=None, audio_engine=None, parent=None):
        super().__init__(parent)
        self.setObjectName("proAudioSamplerWidget")
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.setMinimumHeight(0)
        self.setAcceptDrops(True)

        self.project_service = project_service
        self.audio_engine = audio_engine
        self._track_id: str = ""

        self.engine = ProSamplerEngine(target_sr=48000)
        self._pull_name = f"sampler:{uuid.uuid4().hex[:8]}"

        self._build_ui()
        self._wire()
        self._register_audio()

    @property
    def track_id(self) -> str:
        return self._track_id

    @track_id.setter
    def track_id(self, tid: str):
        self._track_id = str(tid or "")
        # v0.0.20.43: Auto-register in sampler registry when track_id is assigned
        if self._track_id:
            try:
                from pydaw.plugins.sampler.sampler_registry import get_sampler_registry
                registry = get_sampler_registry()
                if not registry.has_sampler(self._track_id):
                    registry.register(self._track_id, self.engine, self)
            except Exception:
                pass
    
    def set_track_context(self, track_id: str) -> None:
        """v0.0.20.46: Unified API with DrumMachine for pull-source registration."""
        self.track_id = track_id

    # ------------------------------------------------------------------ UI
    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(6, 4, 6, 4)
        root.setSpacing(4)

        # --- Top bar: title + load + play/loop
        top = QHBoxLayout()
        top.setSpacing(6)

        self.lbl_file = QLabel("Drop audio or 'Load Sample'")
        self.lbl_file.setStyleSheet("color:#bdbdbd;font-size:9px;")
        self.lbl_file.setMinimumWidth(80)
        top.addWidget(self.lbl_file, 1)

        self.btn_load = QPushButton("Load Sample")
        self.btn_load.setFixedHeight(22)
        self.btn_load.setMaximumWidth(120)
        top.addWidget(self.btn_load)

        self.btn_play = QPushButton("PLAY")
        self.btn_play.setCheckable(True)
        self.btn_play.setFixedHeight(22)
        self.btn_play.setMaximumWidth(60)
        top.addWidget(self.btn_play)

        self.chk_loop = QCheckBox("LOOP")
        self.chk_loop.setStyleSheet("color:#ccc;font-size:9px;")
        top.addWidget(self.chk_loop)

        root.addLayout(top)

        # --- Waveform strip (40-60px)
        self.wave = WaveformDisplay(self.engine)
        root.addWidget(self.wave)

        # --- Main control row: Pitch | Filters | AHDSR | Output
        row = QHBoxLayout()
        row.setSpacing(8)

        # -- Pitch Modulation section
        row.addWidget(self._make_section("Pitch", [
            ("Glide", 5), ("Speed", 3), ("Repitch", 35),
            ("Cycles", 0), ("Textures", 10), ("Grain", 0),
        ]))

        # -- Filter section
        filt_w = QWidget()
        filt_l = QVBoxLayout(filt_w)
        filt_l.setContentsMargins(4, 2, 4, 2)
        filt_l.setSpacing(2)

        filt_top = QHBoxLayout()
        filt_top.setSpacing(4)
        lbl_ft = QLabel("Filter")
        lbl_ft.setStyleSheet("color:#aaa;font-size:8px;")
        self.cb_filter = QComboBox()
        self.cb_filter.addItems(["Off", "LP", "HP", "BP"])
        self.cb_filter.setFixedHeight(20)
        self.cb_filter.setMaximumWidth(60)
        filt_top.addWidget(lbl_ft)
        filt_top.addWidget(self.cb_filter)
        filt_l.addLayout(filt_top)

        filt_knobs = QHBoxLayout()
        filt_knobs.setSpacing(2)
        self.k_cutoff = CompactKnob("Cutoff", 68)
        self.k_res = CompactKnob("Reso", 60)
        self.k_drive = CompactKnob("Drive", 0)
        for k in (self.k_cutoff, self.k_res, self.k_drive):
            filt_knobs.addWidget(k)
        filt_l.addLayout(filt_knobs)

        fx_knobs = QHBoxLayout()
        fx_knobs.setSpacing(2)
        self.k_chorus = CompactKnob("Chorus", 0)
        self.k_reverb = CompactKnob("Reverb", 0)
        self.k_delay = CompactKnob("Delay", 0)
        self.k_dist = CompactKnob("Dist", 0)
        for k in (self.k_chorus, self.k_reverb, self.k_delay, self.k_dist):
            fx_knobs.addWidget(k)
        filt_l.addLayout(fx_knobs)

        row.addWidget(filt_w)

        # -- AHDSR section
        row.addWidget(self._make_section("AHDSR", [
            ("A", 2), ("H", 0), ("D", 15), ("S", 100), ("R", 20),
        ]))

        # -- Output section
        row.addWidget(self._make_section("Output", [
            ("Vol", 80), ("Pan", 50),
        ]))

        root.addLayout(row)

        # --- Position / Loop sliders (compact)
        sliders = QHBoxLayout()
        sliders.setSpacing(8)
        self.s_pos = self._mini_slider("Position", 0)
        self.s_ls = self._mini_slider("Loop Start", 0)
        self.s_le = self._mini_slider("Loop End", 100)
        sliders.addWidget(QLabel("Position"))
        sliders.addWidget(self.s_pos, 1)
        sliders.addWidget(QLabel("Loop Start"))
        sliders.addWidget(self.s_ls, 1)
        sliders.addWidget(QLabel("Loop End"))
        sliders.addWidget(self.s_le, 1)

        # Style the slider labels
        for w in (sliders.itemAt(i).widget() for i in range(sliders.count()) if sliders.itemAt(i).widget() and isinstance(sliders.itemAt(i).widget(), QLabel)):
            w.setStyleSheet("color:#999;font-size:8px;")

        root.addLayout(sliders)

    def _make_section(self, title: str, knobs: list[tuple[str, int]]) -> QWidget:
        """Create a compact vertical section with title + knob grid."""
        w = QWidget()
        vl = QVBoxLayout(w)
        vl.setContentsMargins(4, 2, 4, 2)
        vl.setSpacing(2)

        lbl = QLabel(title)
        lbl.setStyleSheet("color:#e060e0;font-size:8px;font-weight:bold;")
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        vl.addWidget(lbl)

        # Arrange knobs in rows of 3
        grid = QGridLayout()
        grid.setSpacing(2)
        grid.setContentsMargins(0, 0, 0, 0)
        knob_widgets = []
        for idx, (name, init) in enumerate(knobs):
            k = CompactKnob(name, init)
            grid.addWidget(k, idx // 3, idx % 3)
            knob_widgets.append(k)
            setattr(self, f"k_{name.lower().replace(' ', '_')}", k)
        vl.addLayout(grid)

        return w

    def _mini_slider(self, tooltip: str, init: int) -> QSlider:
        s = QSlider(Qt.Orientation.Horizontal)
        s.setRange(0, 100)
        s.setValue(init)
        s.setToolTip(tooltip)
        s.setFixedHeight(16)
        return s

    # ------------------------------------------------------------------ Wiring
    def _wire(self) -> None:
        self.btn_load.clicked.connect(self._load_dialog)
        self.btn_play.toggled.connect(self._toggle_play)
        self.chk_loop.toggled.connect(self._toggle_loop)

        # Knob → engine mappings
        self.k_vol.valueChanged.connect(lambda v: self.engine.set_master(gain=v / 100.0))
        self.k_pan.valueChanged.connect(lambda v: self.engine.set_master(pan=(v - 50.0) / 50.0))

        self.k_repitch.valueChanged.connect(lambda v: self.engine.set_repitch(0.25 + (v / 100.0) * 3.75))
        self.k_glide.valueChanged.connect(lambda v: self.engine.set_glide(v / 100.0))
        self.k_speed.valueChanged.connect(lambda v: self.engine.set_lfo(rate_hz=0.05 + (v / 100.0) * 19.95))
        self.k_cycles.valueChanged.connect(lambda v: self.engine.set_lfo(depth=(v / 100.0) * 0.20))
        self.k_textures.valueChanged.connect(lambda v: self.engine.set_textures(v / 100.0))
        self.k_grain.valueChanged.connect(lambda v: self.engine.set_grain(v / 100.0))

        self.cb_filter.currentIndexChanged.connect(self._filter_type_changed)
        self.k_cutoff.valueChanged.connect(self._cutoff_changed)
        self.k_res.valueChanged.connect(lambda v: self.engine.set_filter(q=0.25 + (v / 100.0) * 11.75))
        self.k_drive.valueChanged.connect(lambda v: self.engine.set_drive(1.0 + (v / 100.0) * 19.0))

        self.k_chorus.valueChanged.connect(lambda v: self.engine.set_fx(chorus_mix=v / 100.0))
        self.k_delay.valueChanged.connect(lambda v: self.engine.set_fx(delay_mix=v / 100.0))
        self.k_reverb.valueChanged.connect(lambda v: self.engine.set_fx(reverb_mix=v / 100.0))
        self.k_dist.valueChanged.connect(lambda v: self.engine.set_distortion(v / 100.0))

        self.k_a.valueChanged.connect(lambda v: self.engine.set_env(a=0.001 + (v / 100.0) * 4.999))
        self.k_h.valueChanged.connect(lambda v: self.engine.set_env(h=(v / 100.0) * 5.0))
        self.k_d.valueChanged.connect(lambda v: self.engine.set_env(d=0.001 + (v / 100.0) * 4.999))
        self.k_s.valueChanged.connect(lambda v: self.engine.set_env(s=v / 100.0))
        self.k_r.valueChanged.connect(lambda v: self.engine.set_env(r=0.001 + (v / 100.0) * 9.999))

        self.s_pos.valueChanged.connect(self._pos_changed)
        self.s_ls.valueChanged.connect(self._loop_slider_changed)
        self.s_le.valueChanged.connect(self._loop_slider_changed)

        # Note preview from ProjectService
        if self.project_service is not None:
            sig = getattr(self.project_service, "note_preview", None)
            if sig is not None:
                try:
                    sig.connect(self._on_note_preview)
                except Exception:
                    pass

    def _register_audio(self):
        """Register this sampler as a pull-source and tag it with track-id metadata
        so Live/Preview mode can apply track faders (vol/pan/mute/solo) in the engine.
        """
        if self.audio_engine is None:
            return

        try:
            # Wrap pull so we can attach metadata (bound methods can't reliably hold attrs)
            if not hasattr(self, "_pull_fn") or self._pull_fn is None:
                def _pull(frames: int, sr: int, _eng=self.engine):
                    return _eng.pull(frames, sr)

                # Dynamic getter: track_id can be assigned after widget creation
                _pull._pydaw_track_id = (lambda: getattr(self, "_track_id", ""))

                self._pull_fn = _pull

            # Register via modern API when available
            if hasattr(self.audio_engine, "register_pull_source"):
                self.audio_engine.register_pull_source(self._pull_name, self._pull_fn)
            elif hasattr(self.audio_engine, "add_source"):
                # Legacy fallback (no per-track fader support in this path)
                self.audio_engine.add_source(self.engine, name=self._pull_name)

            # Ensure preview output is alive (sounddevice stream)
            try:
                self.audio_engine.ensure_preview_output()
            except Exception:
                pass
        except Exception:
            pass

    # ------------------------------------------------------------------ Interactions
    def _filter_type_changed(self, idx: int):
        mapping = {0: "off", 1: "lp", 2: "hp", 3: "bp"}
        self.engine.set_filter(ftype=mapping.get(idx, "off"))

    def _cutoff_changed(self, v: int):
        cutoff = 20.0 * (1000.0 ** (v / 100.0))
        self.engine.set_filter(cutoff_hz=cutoff)

    def _pos_changed(self, v: int):
        """v0.0.20.42: Position slider sets sample start position (Pro-DAW-like).
        Notes will start playing from this position in the sample."""
        try:
            with self.engine._lock:
                self.engine.state.start_position = float(v / 100.0)
        except Exception:
            pass

    def _loop_slider_changed(self, _=None):
        ls, le = self.s_ls.value() / 100.0, self.s_le.value() / 100.0
        if le <= ls:
            le = min(1.0, ls + 0.01)
            self.s_le.blockSignals(True)
            self.s_le.setValue(int(le * 100))
            self.s_le.blockSignals(False)
        self.engine.set_loop_norm(ls, le)

    def _toggle_loop(self, checked: bool):
        self.engine.set_loop_enabled(bool(checked))
        if checked:
            self._loop_slider_changed()

    def _toggle_play(self, checked: bool):
        try:
            if checked:
                self.engine.toggle_play()
                self.btn_play.setText("STOP")
            else:
                self.engine.stop_play()
                self.btn_play.setText("PLAY")
        except Exception:
            self.btn_play.setChecked(False)
            self.btn_play.setText("PLAY")

    def _load_dialog(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Choose Audio File", str(Path.home()), _AUDIO_FILTER
        )
        if path:
            self._load_file(path)

    def _load_file(self, path: str):
        p = Path(path)
        ext = p.suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS:
            QMessageBox.information(self, "Sampler",
                f"Nicht unterstützt: {ext}\nErlaubt: {', '.join(sorted(SUPPORTED_EXTENSIONS))}")
            return

        ok = self.wave.load_wav_file(str(p))
        if ok:
            self.lbl_file.setText(f"✓ {p.name}")
            self.lbl_file.setToolTip(str(p))
            if self.audio_engine is not None:
                try:
                    self.audio_engine.ensure_preview_output()
                except Exception:
                    pass
        else:
            QMessageBox.warning(self, "Sampler", f"Konnte '{p.name}' nicht laden.")

    def _on_note_preview(self, pitch: int, velocity: int, duration_ms: int):
        """v0.0.20.43: Respond to note_preview regardless of visibility.
        The sampler should play notes even when the Device panel is not shown
        (e.g., when user is in Piano Roll or Notation view).

        Note: The registry path in main_window._on_note_preview_routed is the
        primary routing mechanism. This direct connection is a fallback that
        ensures the sampler plays even if registry wiring fails.
        """
        if self.engine.samples is None:
            return
        # Only respond if this sampler is for the currently selected track
        # (prevents all samplers from playing simultaneously)
        try:
            if self._track_id:
                from pydaw.plugins.sampler.sampler_registry import get_sampler_registry
                registry = get_sampler_registry()
                # If registry knows about us, let it handle routing (avoid double-trigger)
                if registry.has_sampler(self._track_id):
                    return  # Registry path in main_window handles this
        except Exception:
            pass
        # Fallback: direct trigger (no registry)
        self.engine.trigger_note(int(pitch), int(velocity), int(duration_ms))
        if self.audio_engine is not None:
            try:
                self.audio_engine.ensure_preview_output()
            except Exception:
                pass

    # ------------------------------------------------------------------ DnD
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            for u in e.mimeData().urls():
                ext = Path(u.toLocalFile()).suffix.lower()
                if ext in SUPPORTED_EXTENSIONS:
                    e.acceptProposedAction()
                    return
        e.ignore()

    def dropEvent(self, e):
        if not e.mimeData().hasUrls():
            return
        for u in e.mimeData().urls():
            fp = u.toLocalFile()
            if Path(fp).suffix.lower() in SUPPORTED_EXTENSIONS:
                self._load_file(fp)
                break

    # ------------------------------------------------------------------ Lifecycle
    def shutdown(self):
        if self.audio_engine is not None:
            try:
                self.audio_engine.unregister_pull_source(self._pull_name)
            except Exception:
                pass
