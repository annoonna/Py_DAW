"""ProjectService (v0.0.15.8 hotfix).

Ziel dieses Hotfix:
- Stabile, konsistente API für die UI (keine AttributeError-Crashes in Qt-Slots)
- Threaded File-IO (Open/Save/Import/Export) via ThreadPoolService.Worker
- Grundlegende Track/Clip-Operationen + PianoRoll/MIDI Notes Datenstruktur
- Clip Launcher Einstellungen + Slot Mapping

Hinweis: Audio-Playback/Recording ist weiterhin Placeholder.
"""

from __future__ import annotations

import logging

log = logging.getLogger(__name__)

from ..model.project import AudioEvent, new_id
from pathlib import Path
from datetime import datetime
import contextlib
import math
import wave
import re
from typing import Any, Callable, List, Optional

from PyQt6.QtCore import QObject, pyqtSignal

from pydaw.core.settings import SettingsKeys
from pydaw.core.settings_store import set_value as set_setting

from pydaw.core.threading import ThreadPoolService, Worker
from pydaw.model.project import Track, Clip
from pydaw.model.midi import MidiNote

from pydaw.fileio.file_manager import (
    ProjectContext,
    new_project as fm_new_project,
    open_project as fm_open_project,
    save_project_to as fm_save_project_to,
    import_audio_to_project as fm_import_audio,
    import_midi_to_project as fm_import_midi,
    export_audio_from_file as fm_export_audio,
    resolve_loaded_media_paths,  # v0.0.20.75: Fix missing import
)

from pydaw.fileio import project_io

from pydaw.fileio.midi_io import import_midi as midi_parse

from pydaw.commands import UndoStack
from pydaw.commands.midi_notes_edit import MidiNotesEditCommand, MidiSnapshot


class ProjectService(QObject):
    status = pyqtSignal(str)
    error = pyqtSignal(str)
    project_updated = pyqtSignal()
    project_changed = pyqtSignal()
    clip_selected = pyqtSignal(str)
    active_clip_changed = pyqtSignal(str)  # backward compatible alias for pianoroll
    undo_changed = pyqtSignal()
    # Fired after a MIDI edit is committed (Undo step created). This allows
    # other services (e.g. audio) to react without the user needing to stop/play.
    midi_notes_committed = pyqtSignal(str)

    note_preview = pyqtSignal(int, int, int)  # pitch, velocity, duration_ms

    # Lifecycle hook for UI: emitted after new/open/snapshot-load.
    project_opened = pyqtSignal()

    # MIDI pre-render (performance): render MIDI->WAV in the background so
    # playback feels instant even with large SF2 instruments.
    prerender_started = pyqtSignal(int)    # total clips
    prerender_progress = pyqtSignal(int)   # percent 0..100
    prerender_label = pyqtSignal(str)      # short status text
    prerender_finished = pyqtSignal(bool)  # True if completed (not cancelled)

    def __init__(self, threadpool: ThreadPoolService, parent: QObject | None = None):
        super().__init__(parent)
        self.threadpool = threadpool
        self.ctx: ProjectContext = fm_new_project()
        self._selected_track_id: str = ""
        self._active_clip_id: str = ""
        self.undo_stack = UndoStack(max_depth=400)

        # Pre-render state (MIDI->WAV background rendering)
        self._prerender_running: bool = False
        self._prerender_cancel: bool = False

        # Optional service binding: ClipLauncher realtime playback.
        # This is injected by the ServiceContainer.
        self._cliplauncher_playback: Any = None

    # --- wiring

    def bind_cliplauncher_playback(self, playback_service: Any) -> None:
        """Bind a ClipLauncherPlaybackService instance (optional)."""
        self._cliplauncher_playback = playback_service

    # --- ClipLauncher Playback API (called by LauncherService)

    def cliplauncher_launch_immediate(self, slot_key: str, at_beat: float | None = None) -> None:
        """Launch a single launcher slot immediately.

        The slot mapping is stored in Project.clip_launcher (slot_key -> clip_id).
        """
        if self._cliplauncher_playback is None:
            self.status.emit("Launch: Playback-Service fehlt (cliplauncher).")
            return
        try:
            self._cliplauncher_playback.launch_slot(str(slot_key), at_beat=at_beat)
        except Exception:
            self.status.emit("Launch: Playback-Service Fehler (cliplauncher).")

    def cliplauncher_launch_scene_immediate(self, scene_index: int, at_beat: float | None = None) -> None:
        if self._cliplauncher_playback is None:
            self.status.emit("Scene Launch: Playback-Service fehlt (cliplauncher).")
            return
        try:
            self._cliplauncher_playback.launch_scene(int(scene_index), at_beat=at_beat)
        except Exception:
            self.status.emit("Scene Launch: Playback-Service Fehler (cliplauncher).")

    def cliplauncher_stop_all(self) -> None:
        """Stop only ClipLauncher clips (does NOT stop the global transport)."""
        if self._cliplauncher_playback is None:
            return
        try:
            self._cliplauncher_playback.stop_all()
        except Exception:
            pass

    def preview_note(self, pitch: int, velocity: int = 100, duration_ms: int = 140) -> None:
        """Emit a lightweight note-preview event (for Sampler/MIDI preview sync)."""
        try:
            self.note_preview.emit(int(pitch), int(velocity), int(duration_ms))
        except Exception:
            # Keep UI calls safe; preview is best-effort.
            return

    def active_clip_id(self) -> str:
        """Aktuell ausgewählter Clip (für ClipLauncher/PianoRoll/UI)."""
        if self._active_clip_id:
            return self._active_clip_id
        return str(getattr(self.ctx.project, "selected_clip_id", ""))

    @property
    def selected_track_id(self) -> str:
        """Aktuell ausgewählte Spur (UI)."""
        return self._selected_track_id

    @property
    def active_track_id(self) -> str:
        """Backwards-compat Alias für ältere UI-Teile."""
        return self._selected_track_id


    # ---------- helpers ----------
    def display_name(self) -> str:
        p = self.ctx.path
        return p.name if p else self.ctx.project.name

    def set_track_soundfont(self, track_id: str, sf2_path: str, bank: int = 0, preset: int = 0) -> None:
        """Assign a SoundFont (SF2) to an instrument track (Phase 4)."""
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            self.status.emit("Kein Track ausgewählt")
            return
        if trk.kind not in ("instrument", "bus", "master", "audio"):
            pass
        # Store on track (dataclass fields)
        try:
            trk.sf2_path = str(sf2_path)
            trk.sf2_bank = int(bank)
            trk.sf2_preset = int(preset)
        except Exception:
            trk.sf2_path = str(sf2_path)
        self.status.emit(f"SF2 gesetzt für {trk.name}: {Path(sf2_path).name} (Bank {bank}, Preset {preset})")
        self._emit_updated()

    def _emit_updated(self) -> None:
        self.project_updated.emit()

    def _emit_changed(self) -> None:
        self.project_changed.emit()
        self.project_updated.emit()


    # ---------- notation marks / annotations ----------
    def add_notation_mark(self, clip_id: str, *, beat: float, mark_type: str, data: dict | None = None) -> str:
        """Add a notation mark (sticky note, rest, ornament, tie/slur marker).

        Marks are stored on the project model (Project.notation_marks) and are
        persisted in the project JSON when the user saves the project.

        Args:
            clip_id: Target clip id (usually the active MIDI clip).
            beat: Timeline position in beats.
            mark_type: 'comment' | 'rest' | 'ornament' | ...
            data: Additional JSON-safe payload (dict).

        Returns:
            mark_id (str)
        """
        import uuid
        from datetime import datetime
        m = {
            "id": uuid.uuid4().hex,
            "clip_id": str(clip_id),
            "beat": float(beat),
            "type": str(mark_type),
            "data": dict(data or {}),
            "created_utc": datetime.utcnow().isoformat(timespec="seconds"),
        }
        try:
            marks = getattr(self.ctx.project, "notation_marks", None)
            if marks is None:
                self.ctx.project.notation_marks = []
                marks = self.ctx.project.notation_marks
            if isinstance(marks, list):
                marks.append(m)
        except Exception:
            pass
        self._emit_updated()
        return str(m.get("id", ""))

    def remove_notation_mark(self, mark_id: str) -> None:
        """Remove a notation mark by id."""
        try:
            marks = getattr(self.ctx.project, "notation_marks", []) or []
            if not isinstance(marks, list):
                return
            mid = str(mark_id)
            self.ctx.project.notation_marks = [m for m in marks if str(m.get("id", "")) != mid]
        except Exception:
            pass
        self._emit_updated()
    def _submit(self, fn: Callable[[], Any], on_ok: Callable[[Any], None] | None = None, on_err: Callable[[str], None] | None = None) -> None:
        w = Worker(fn)
        if on_ok:
            w.signals.result.connect(on_ok)
        if on_err:
            w.signals.error.connect(on_err)
        self.threadpool.submit(w)

    # ---------- automation playback ----------
    def apply_automation_value(self, track_id: str, param: str, value: float) -> None:
        """Apply an automation value to the live project model.

        This is intentionally lightweight: it updates the in-memory model (Track.volume/Track.pan)
        and notifies the UI via project_updated.

        Audio rendering is still placeholder; when an audio engine exists, it can be hooked here.
        """
        t = next((x for x in self.ctx.project.tracks if x.id == track_id), None)
        if not t:
            return

        if param == "volume":
            t.volume = float(max(0.0, min(1.0, value)))
        elif param == "pan":
            t.pan = float(max(-1.0, min(1.0, value)))
        else:
            return

        # Avoid spamming status; keep it silent.
        self._emit_updated()

    # ---------- project ----------
    def new_project(self, name: str = "Neues Projekt") -> None:
        self.ctx = fm_new_project(name)
        self._selected_track_id = ""
        self.undo_stack.clear()
        self.undo_changed.emit()
        self.status.emit("Neues Projekt erstellt.")
        self._emit_changed()
        self.project_opened.emit()

    def open_project(self, path: Path) -> None:
        def fn():
            return fm_open_project(path)

        def ok(ctx: ProjectContext):
            self.ctx = ctx
            self.undo_stack.clear()
            self.undo_changed.emit()
            try:
                keys = SettingsKeys()
                set_setting(keys.last_project, str(path))
            except Exception:
                pass
            self._selected_track_id = ""
            try:
                keys = SettingsKeys()
                set_setting(keys.last_project, str(path))
            except Exception:
                pass
            self.status.emit(f"Projekt geöffnet: {path}")
            self._emit_changed()
            self.project_opened.emit()

        def err(msg: str):
            self.error.emit(msg)

        self._submit(fn, ok, err)

    def save_project_as(self, path: Path) -> None:
        def fn():
            return fm_save_project_to(path, self.ctx)

        def ok(ctx: ProjectContext):
            self.ctx = ctx
            self.status.emit(f"Projekt gespeichert: {path}")
            self._emit_changed()

        def err(msg: str):
            self.error.emit(msg)

        self._submit(fn, ok, err)

    def save_project(self) -> None:
        """Speichert das Projekt in die aktuelle Projektdatei (falls vorhanden)."""
        if not getattr(self.ctx, "path", None):
            self.error.emit("Projekt ist noch nicht gespeichert. Bitte zuerst 'Speichern unter…' verwenden.")
            return
        self.save_project_as(self.ctx.path)

    def save_snapshot(self, label: str = "") -> None:
        """Erstellt einen Projektstand (Snapshot) in <Projektordner>/stamps/."""
        if not getattr(self.ctx, "path", None):
            self.error.emit("Projekt ist noch nicht gespeichert. Bitte zuerst speichern, dann Snapshot erstellen.")
            return

        def fn():
            root = self.ctx.path.parent
            stamps = root / "stamps"
            stamps.mkdir(parents=True, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe = re.sub(r"[^a-zA-Z0-9._-]+", "_", (label or "snapshot").strip())
            safe = safe.strip("_-") or "snapshot"
            snap_path = stamps / f"{ts}__{safe}.pydaw.json"
            project_io.save_project(snap_path, self.ctx.project)
            return snap_path

        def ok(path: Path):
            self.status.emit(f"Projektstand gespeichert: {path.name}")
            # kein _emit_changed nötig; nur Datei-Operation

        def err(msg: str):
            self.error.emit(msg)

        self._submit(fn, ok, err)

    def load_snapshot(self, snapshot_path: Path) -> None:
        """Lädt einen Snapshot in das aktuelle Projekt (Media-Pfade bleiben unverändert)."""
        if not snapshot_path:
            return

        def fn():
            return project_io.load_project(snapshot_path)

        def ok(project):
            self.ctx.project = project
            try:
                root_dir = (self.ctx.path.parent if self.ctx.path else snapshot_path.parent.parent)
                resolve_loaded_media_paths(self.ctx.project, root_dir)
            except Exception:
                pass
            self.undo_stack.clear()
            self.undo_changed.emit()
            self.status.emit(f"Projektstand geladen: {snapshot_path.name}")
            self._emit_changed()
            self.project_opened.emit()

        def err(msg: str):
            self.error.emit(msg)

        self._submit(fn, ok, err)

    # ---------- settings ----------
    def set_time_signature(self, ts: str) -> None:
        self.ctx.project.time_signature = str(ts or "4/4")
        self.status.emit(f"Taktart: {self.ctx.project.time_signature}")
        self._emit_updated()

    def set_snap_division(self, div: str) -> None:
        self.ctx.project.snap_division = str(div)
        self._emit_updated()

    # ---------- tracks ----------
    def add_track(self, kind: str) -> None:
        name = {"audio": "Audio Track", "instrument": "Instrument Track", "bus": "Bus", "master": "Master"}.get(kind, "Track")
        trk = Track(kind=kind, name=name)

        # keep master at end
        tracks = [t for t in self.ctx.project.tracks if t.kind != "master"]
        master = next((t for t in self.ctx.project.tracks if t.kind == "master"), None)
        tracks.append(trk)
        if master:
            tracks.append(master)
        self.ctx.project.tracks = tracks

        self._selected_track_id = trk.id
        self.status.emit(f"Spur hinzugefügt: {trk.name}")
        self._emit_updated()

    def ensure_audio_track(self) -> str:
        trk = next((t for t in self.ctx.project.tracks if t.kind == "audio"), None)
        if trk:
            return trk.id
        self.add_track("audio")
        trk = next((t for t in self.ctx.project.tracks if t.kind == "audio"), None)
        return trk.id if trk else ""


    def ensure_instrument_track(self) -> str:
        trk = next((t for t in self.ctx.project.tracks if t.kind == "instrument"), None)
        if trk:
            return trk.id
        self.add_track("instrument")
        trk = next((t for t in self.ctx.project.tracks if t.kind == "instrument"), None)
        return trk.id if trk else ""


    def remove_track(self, track_id: str) -> None:
        if not track_id:
            return
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk or trk.kind == "master":
            return
        self.ctx.project.tracks = [t for t in self.ctx.project.tracks if t.id != track_id]
        # remove clips on that track
        removed = [c.id for c in self.ctx.project.clips if c.track_id == track_id]
        self.ctx.project.clips = [c for c in self.ctx.project.clips if c.track_id != track_id]
        for cid in removed:
            self.ctx.project.midi_notes.pop(cid, None)

        if self._selected_track_id == track_id:
            self._selected_track_id = ""
        self.status.emit(f"Spur entfernt: {trk.name}")
        self._emit_updated()

    def rename_track(self, track_id: str, new_name: str) -> None:
        """Rename a track."""
        if not track_id or not new_name:
            return
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        # Don't allow renaming master track
        if trk.kind == "master":
            return
        old_name = trk.name
        trk.name = str(new_name).strip()
        self.status.emit(f"Spur umbenannt: '{old_name}' → '{trk.name}'")
        self._emit_updated()

    # ---------- track state (Mute / Solo / Record Arm) ----------
    def set_track_muted(self, track_id: str, muted: bool) -> None:
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        trk.muted = bool(muted)
        self._emit_updated()

    def set_track_solo(self, track_id: str, solo: bool) -> None:
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        trk.solo = bool(solo)
        self._emit_updated()

    def set_track_record_arm(self, track_id: str, armed: bool) -> None:
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        trk.record_arm = bool(armed)
        self._emit_updated()

    def set_track_input_pair(self, track_id: str, pair: int) -> None:
        """Set stereo input pair (1..N) used for monitoring/recording."""
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk or getattr(trk, "kind", "") == "master":
            return
        try:
            trk.input_pair = max(1, int(pair))
        except Exception:
            trk.input_pair = 1
        self._emit_updated()

    def set_track_output_pair(self, track_id: str, pair: int) -> None:
        """Reserved: stereo output pair (1..N) for future bus/submix routing."""
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk or getattr(trk, "kind", "") == "master":
            return
        try:
            trk.output_pair = max(1, int(pair))
        except Exception:
            trk.output_pair = 1
        self._emit_updated()

    def set_track_monitor(self, track_id: str, enabled: bool) -> None:
        """Enable/disable input monitoring for this track."""
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk or getattr(trk, "kind", "") == "master":
            return
        trk.monitor = bool(enabled)
        self._emit_updated()

    # ---------- clip grouping ----------
    def group_clips(self, clip_ids: List[str]) -> str:
        """Assigns a shared group_id to the given clips.

        Grouping is used by the arranger UI to move multiple clips together.
        """
        ids = [cid for cid in clip_ids if cid]
        if len(ids) < 2:
            return ""
        gid = f"grp_{uuid4().hex[:8]}"
        for c in self.ctx.project.clips:
            if c.id in ids:
                c.group_id = gid
        self.status.emit(f"{len(ids)} Clips gruppiert")
        self._emit_updated()
        return gid

    def ungroup_clips(self, clip_ids: List[str]) -> None:
        ids = [cid for cid in clip_ids if cid]
        if not ids:
            return
        for c in self.ctx.project.clips:
            if c.id in ids:
                c.group_id = ""
        self.status.emit(f"Gruppierung aufgehoben")
        self._emit_updated()

    # ---------- clips ----------
    def select_clip(self, clip_id: str) -> None:
        self.ctx.project.selected_clip_id = str(clip_id)  # dynamic attr for UI
        self._active_clip_id = str(clip_id)
        self.clip_selected.emit(str(clip_id))
        self.active_clip_changed.emit(str(clip_id))
        self._emit_updated()

    def add_placeholder_clip_to_track(self, track_id: str, kind: str = "audio") -> None:
        if not track_id:
            return
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        kind = "midi" if trk.kind == "instrument" else "audio"
        clip = Clip(kind='audio', track_id=track_id, label=f"{kind.upper()} Clip")

        # If this import is meant for the Clip-Launcher, keep it out of the Arranger timeline.
        try:
            clip.launcher_only = not bool(place_in_arranger)
        except Exception:
            pass
        self.ctx.project.clips.append(clip)
        if kind == "midi":
            self.ctx.project.midi_notes[clip.id] = []
        self.status.emit(f"Clip hinzugefügt: {clip.label}")
        if bool(place_in_arranger):
            self.select_clip(clip.id)
        self._emit_updated()

    def delete_clip(self, clip_id: str) -> None:
        self.ctx.project.clips = [c for c in self.ctx.project.clips if c.id != clip_id]
        self.ctx.project.midi_notes.pop(clip_id, None)
        # remove from launcher slots
        self.ctx.project.clip_launcher = {k: v for k, v in self.ctx.project.clip_launcher.items() if v != clip_id}
        if getattr(self.ctx.project, "selected_clip_id", "") == clip_id:
            self.select_clip("")
        self.status.emit("Clip gelöscht.")
        self._emit_updated()

    def rename_clip(self, clip_id: str, name: str) -> None:
        c = next((c for c in self.ctx.project.clips if c.id == clip_id), None)
        if not c:
            return
        c.label = str(name)
        self._emit_updated()

    def duplicate_clip(self, clip_id: str) -> None:
        """Duplicate a clip horizontally (same track), snapped to the end.

        Expected DAW behavior in Arranger:
        - Ctrl+D duplicates the selected clip(s) on the SAME track
        - The new clip starts exactly at the end of the source clip
        - MIDI content is deep-copied (notes preserved)

        Note:
        A previous implementation duplicated *vertically* by creating a new
        track. That broke the documented workflow. Vertical duplication can
        be reintroduced later under a different shortcut.
        """
        c = next((c for c in self.ctx.project.clips if c.id == clip_id), None)
        if not c:
            return

        # Same-track, snapped to end
        try:
            new_start = float(getattr(c, "start_beats", 0.0)) + float(getattr(c, "length_beats", 0.0))
        except Exception:
            new_start = 0.0
        # Reduce floating drift when duplicating many times
        new_start = round(float(new_start), 6)

        base_label = str(getattr(c, "label", ""))
        new_label = base_label if base_label.endswith(" Copy") else (base_label + " Copy")

        dup = Clip(
            kind=c.kind,
            track_id=c.track_id,  # SAME TRACK ✅
            start_beats=new_start,  # END-SNAP ✅
            length_beats=c.length_beats,
            label=new_label,
            media_id=c.media_id,
            source_path=c.source_path,
        )
        self.ctx.project.clips.append(dup)
        
        # Copy MIDI notes with deepcopy (notes preserved)
        if dup.kind == "midi":
            import copy
            original_notes = self.ctx.project.midi_notes.get(c.id, [])
            if original_notes:
                self.ctx.project.midi_notes[dup.id] = [
                    copy.deepcopy(note) 
                    for note in original_notes
                ]
            else:
                self.ctx.project.midi_notes[dup.id] = []
        
        self.select_clip(dup.id)
        self.status.emit("Clip dupliziert (Ctrl+D)")
        self._emit_updated()

    def add_audio_clip_from_clip_events_at(self, source_clip_id: str, event_ids: List[str], target_track_id: str, *, start_beats: float = 0.0) -> Optional[str]:
        """Create a NEW audio clip from selected AudioEvent(s) of an existing audio clip.

        This is the basis for DAW-like workflow:
        - Split a clip in the Audio Editor (Knife)
        - Drag one or more segments (events) into the Arranger
        - A new clip is created on the target track (non-destructive)

        The new clip references the SAME source file and preserves clip-level edits
        (gain/pan/pitch/stretch/reverse/mute/fades, warp markers, clip automation).
        """
        src_id = str(source_clip_id or '').strip()
        if not src_id:
            return None
        try:
            wanted = [str(x) for x in (event_ids or []) if str(x).strip()]
        except Exception:
            wanted = []
        if not wanted:
            return None

        src = next((c for c in (self.ctx.project.clips or []) if str(getattr(c, 'id', '')) == src_id), None)
        if not src or str(getattr(src, 'kind', '')) != 'audio':
            return None

        # Ensure events exist
        try:
            self._ensure_audio_events(src)
        except Exception:
            pass
        try:
            evs = list(getattr(src, 'audio_events', []) or [])
        except Exception:
            evs = []
        if not evs:
            return None

        want_set = set(wanted)
        sel = [e for e in evs if str(getattr(e, 'id', '')) in want_set]
        if not sel:
            return None

        # Selection bounds in clip timeline (UI/Editor timeline)
        def _st(e):
            return float(getattr(e, 'start_beats', 0.0) or 0.0)
        def _en(e):
            return float(getattr(e, 'start_beats', 0.0) or 0.0) + float(getattr(e, 'length_beats', 0.0) or 0.0)

        min_start = min(_st(e) for e in sel)
        max_end = max(_en(e) for e in sel)
        length = max(0.25, float(max_end - min_start))

        # IMPORTANT (v0.0.20.146): The arrangement renderer uses clip.offset_seconds
        # for trimming/offset (NOT offset_beats). If we don't set offset_seconds here,
        # exported slices will always start from the beginning of the file.
        #
        # We compute a stable seconds_per_beat mapping from the source file duration
        # and the *source clip* length_beats: seconds_per_beat = file_secs / src.length_beats.
        # This works for both:
        # - raw audio (length_beats derived from project BPM)
        # - tempo-synced loops (length_beats derived from source BPM)
        # because the renderer scales offset_seconds by effective_rate.
        try:
            src_path = Path(str(getattr(src, 'source_path', '') or ''))
            file_secs = float(self._audio_duration_seconds(src_path))
        except Exception:
            file_secs = 0.0
        try:
            src_len_beats = float(getattr(src, 'length_beats', 0.0) or 0.0)
        except Exception:
            src_len_beats = 0.0
        try:
            proj_bpm = float(getattr(self.ctx.project, 'bpm', 120.0) or 120.0)
        except Exception:
            proj_bpm = 120.0
        if file_secs > 0.0 and src_len_beats > 1e-9:
            seconds_per_beat = float(file_secs) / float(src_len_beats)
        else:
            seconds_per_beat = 60.0 / max(1e-9, float(proj_bpm))

        # Determine the source-start beat for the selection.
        # Prefer AudioEvent.source_offset_beats (actual source position) but fall back
        # to src.offset_beats + selection start if offsets look uninitialized.
        so_vals: list[float] = []
        se_vals: list[float] = []
        try:
            so_vals = [float(getattr(e, 'source_offset_beats', 0.0) or 0.0) for e in sel]
            se_vals = [float(getattr(e, 'source_offset_beats', 0.0) or 0.0) + float(getattr(e, 'length_beats', 0.0) or 0.0) for e in sel]
            src_start_beats = float(min(so_vals)) if so_vals else 0.0
            src_end_beats = float(max(se_vals)) if se_vals else float(src_start_beats + length)
        except Exception:
            src_start_beats = 0.0
            src_end_beats = float(src_start_beats + length)
            so_vals = []
            se_vals = []

        try:
            base_off_beats = float(getattr(src, 'offset_beats', 0.0) or 0.0)
        except Exception:
            base_off_beats = 0.0
        try:
            base_off_secs = float(getattr(src, 'offset_seconds', 0.0) or 0.0)
        except Exception:
            base_off_secs = 0.0

        # Heuristic: if offsets are all ~equal while selection start is not ~0,
        # assume source_offset_beats is missing and derive from clip timeline.
        try:
            if sel:
                if (abs(float(src_end_beats - src_start_beats)) < 1e-6 and float(length) > 1e-3) or (
                    max(so_vals) - min(so_vals) < 1e-6 and float(min_start) > 1e-3
                ):
                    src_start_beats = float(base_off_beats + float(min_start))
                    src_end_beats = float(base_off_beats + float(max_end))
        except Exception:
            pass

        # Final computed offset in *seconds* (source time).
        # Keep base_off_secs for future trim support.
        try:
            delta_beats_from_clip_off = float(src_start_beats - base_off_beats)
        except Exception:
            delta_beats_from_clip_off = float(src_start_beats)
        offset_seconds = float(base_off_secs + (delta_beats_from_clip_off * float(seconds_per_beat)))

        # Build new clip
        from pydaw.model.project import Clip, AudioEvent
        tid = str(target_track_id or src.track_id or self.ensure_audio_track())

        base_label = str(getattr(src, 'label', 'Audio') or 'Audio')
        # Avoid "Slice Slice" when exporting from an already-sliced clip.
        if base_label.strip().lower().endswith(' slice'):
            new_label = base_label
        else:
            new_label = base_label + ' Slice'

        newc = Clip(
            kind='audio',
            track_id=tid,
            start_beats=max(0.0, float(start_beats)),
            length_beats=float(length),
            label=str(new_label),
            media_id=getattr(src, 'media_id', None),
            source_path=getattr(src, 'source_path', None),
            source_bpm=getattr(src, 'source_bpm', None),
        )

        # Copy clip-level edits (safe, explicit)
        for attr in [
            'gain', 'pan', 'pitch', 'formant', 'stretch',
            'reversed', 'muted',
            'fade_in_beats', 'fade_out_beats',
            'group_id',
        ]:
            try:
                if hasattr(src, attr):
                    setattr(newc, attr, getattr(src, attr))
            except Exception:
                pass

        # Offset for playback/rendering (renderer uses offset_seconds today).
        # Keep offset_beats as a legacy/debug value.
        newc.offset_beats = float(src_start_beats)
        newc.offset_seconds = float(max(0.0, float(offset_seconds)))

        # IMPORTANT: Arrangement renderer currently ignores clip.audio_events.
        # To ensure exported slices play the correct segment, store this export as
        # ONE consolidated AudioEvent starting at 0 in the new clip.
        newc.audio_events = [AudioEvent(start_beats=0.0, length_beats=float(length), source_offset_beats=float(src_start_beats))]

        # Derived slices for legacy UI
        try:
            self._sync_slices_from_events(newc)
        except Exception:
            pass

        # Clip automation: crop + shift beats
        try:
            src_auto = dict(getattr(src, 'clip_automation', {}) or {})
        except Exception:
            src_auto = {}
        out_auto: dict = {}
        for pname, pts in (src_auto or {}).items():
            try:
                out_pts = []
                for pt in (pts or []):
                    if not isinstance(pt, dict):
                        continue
                    b = float(pt.get('beat', 0.0) or 0.0) - float(min_start)
                    if b < -1e-6 or b > (float(length) + 1e-6):
                        continue
                    out_pts.append({'beat': max(0.0, min(float(length), float(b))), 'value': float(pt.get('value', 0.0) or 0.0)})
                if out_pts:
                    out_pts.sort(key=lambda x: float(x.get('beat', 0.0) or 0.0))
                    out_auto[str(pname)] = out_pts
            except Exception:
                continue
        newc.clip_automation = out_auto

        # Warp markers: crop + shift (best-effort)
        try:
            raw_markers = list(getattr(src, 'stretch_markers', []) or [])
        except Exception:
            raw_markers = []
        out_markers: list = []
        for mm in raw_markers:
            if not isinstance(mm, dict):
                continue
            try:
                src_b = float(mm.get('src', mm.get('beat', 0.0)) or 0.0)
                dst_b = float(mm.get('dst', mm.get('beat', src_b)) or 0.0)
            except Exception:
                continue
            # keep markers that intersect selection window
            if src_b < (min_start - 1e-6) or src_b > (max_end + 1e-6):
                continue
            out_markers.append({'src': float(src_b - min_start), 'dst': float(dst_b - min_start)})
        out_markers.sort(key=lambda x: float(x.get('src', 0.0) or 0.0))
        newc.stretch_markers = out_markers

        # New clip always lives in Arranger
        newc.launcher_only = False

        self.ctx.project.clips.append(newc)
        try:
            self.select_clip(newc.id)
        except Exception:
            pass
        self.status.emit('Slice als neuer Clip erstellt')
        self._emit_updated()
        return str(newc.id)


    def join_clips(self, clip_ids: list[str]) -> str | None:
        """Join multiple clips into one (Pro-DAW-Style Ctrl+J).
        
        Rules:
        - All clips must be on the same track
        - All clips must be MIDI clips (for now)
        - Creates new clip spanning from first to last clip
        - Combines all MIDI notes with adjusted timing
        - Deletes original clips
        
        Returns:
            New clip ID if successful, None if failed
        """
        if not clip_ids or len(clip_ids) < 2:
            return None
        
        # Get all clips
        clips = [c for c in self.ctx.project.clips if c.id in clip_ids]
        if len(clips) < 2:
            return None
        
        # Check: All on same track
        track_ids = set(c.track_id for c in clips)
        if len(track_ids) > 1:
            return None  # Clips on different tracks
        
        # Check: All MIDI clips
        if not all(c.kind == "midi" for c in clips):
            return None  # Only MIDI clips supported for now
        
        # Sort by start_beats
        clips_sorted = sorted(clips, key=lambda c: float(c.start_beats))
        
        # Calculate new clip bounds
        first_clip = clips_sorted[0]
        last_clip = clips_sorted[-1]
        
        new_start = float(first_clip.start_beats)
        new_end = float(last_clip.start_beats) + float(last_clip.length_beats)
        new_length = new_end - new_start
        
        # Create new joined clip
        joined = Clip(
            kind="midi",
            track_id=first_clip.track_id,
            start_beats=new_start,
            length_beats=new_length,
            label="Joined Clip",
        )
        
        # Combine all MIDI notes
        all_notes = []
        for clip in clips_sorted:
            clip_notes = self.ctx.project.midi_notes.get(clip.id, [])
            clip_offset = float(clip.start_beats) - new_start
            
            for note in clip_notes:
                # Adjust note timing relative to new clip start
                adjusted_note = MidiNote(
                    pitch=note.pitch,
                    velocity=note.velocity,
                    start_beats=float(note.start_beats) + clip_offset,
                    length_beats=float(note.length_beats),
                )
                all_notes.append(adjusted_note.clamp())
        
        # Add joined clip and notes
        self.ctx.project.clips.append(joined)
        self.ctx.project.midi_notes[joined.id] = all_notes
        
        # Delete original clips
        for clip in clips:
            self.ctx.project.clips.remove(clip)
            if clip.id in self.ctx.project.midi_notes:
                del self.ctx.project.midi_notes[clip.id]
        
        # Select new joined clip
        self.select_clip(joined.id)
        self._emit_updated()
        
        return joined.id

    def split_clip(self, clip_id: str, split_beat: float) -> tuple[str, str] | None:
        """Split a clip into two clips at given beat position (Pro-DAW-Style Knife tool).
        
        Args:
            clip_id: Clip to split
            split_beat: Beat position where to split (relative to project, not clip)
        
        Returns:
            Tuple of (left_clip_id, right_clip_id) if successful, None if failed
        """
        clip = next((c for c in self.ctx.project.clips if c.id == clip_id), None)
        if not clip:
            return None
        
        # Split position must be inside the clip
        clip_start = float(clip.start_beats)
        clip_end = clip_start + float(clip.length_beats)
        
        if split_beat <= clip_start or split_beat >= clip_end:
            return None  # Split position outside clip
        
        # Calculate lengths
        left_length = split_beat - clip_start
        right_length = clip_end - split_beat
        
        if left_length < 0.25 or right_length < 0.25:
            return None  # Clips would be too small
        
        # Create right clip
        right_clip = Clip(
            kind=clip.kind,
            track_id=clip.track_id,
            start_beats=split_beat,
            length_beats=right_length,
            label=clip.label,
            media_id=clip.media_id,
            source_path=clip.source_path,
        )
        
        # Adjust left clip length
        clip.length_beats = left_length
        
        # Handle MIDI notes
        if clip.kind == "midi":
            orig_notes = self.ctx.project.midi_notes.get(clip.id, [])
            left_notes = []
            right_notes = []
            
            for note in orig_notes:
                note_start = float(note.start_beats)
                note_end = note_start + float(note.length_beats)
                
                # Note completely in left clip
                if note_end <= left_length:
                    left_notes.append(MidiNote(**note.__dict__).clamp())
                
                # Note completely in right clip
                elif note_start >= left_length:
                    # Adjust timing relative to right clip
                    adjusted_note = MidiNote(
                        pitch=note.pitch,
                        velocity=note.velocity,
                        start_beats=note_start - left_length,
                        length_beats=float(note.length_beats),
                    )
                    right_notes.append(adjusted_note.clamp())
                
                # Note spans split - keep in left, truncate
                else:
                    truncated_note = MidiNote(
                        pitch=note.pitch,
                        velocity=note.velocity,
                        start_beats=note_start,
                        length_beats=left_length - note_start,
                    )
                    left_notes.append(truncated_note.clamp())
            
            self.ctx.project.midi_notes[clip.id] = left_notes
            self.ctx.project.midi_notes[right_clip.id] = right_notes
        
        # Add right clip to project
        self.ctx.project.clips.append(right_clip)
        
        # Select right clip
        self.select_clip(right_clip.id)
        self._emit_updated()
        
        return (clip.id, right_clip.id)

    def move_clip(self, clip_id: str, start_beats: float, snap_beats: float | None = None) -> None:
        c = next((c for c in self.ctx.project.clips if c.id == clip_id), None)
        if not c:
            return
        val = max(0.0, float(start_beats))
        if snap_beats and float(snap_beats) > 0:
            g = float(snap_beats)
            val = round(val / g) * g
        c.start_beats = max(0.0, val)
        self._emit_updated()

    def resize_clip(self, clip_id: str, length_beats: float, snap_beats: float | None = None) -> None:
        c = next((c for c in self.ctx.project.clips if c.id == clip_id), None)
        if not c:
            return
        val = max(0.25, float(length_beats))
        if snap_beats and float(snap_beats) > 0:
            g = float(snap_beats)
            val = max(g, round(val / g) * g)
        c.length_beats = max(0.25, val)
        self._emit_updated()


    def trim_clip_left(
        self,
        clip_id: str,
        start_beats: float,
        length_beats: float,
        offset_beats: float = 0.0,
        offset_seconds: float = 0.0,
        snap_beats: float | None = None,
    ) -> None:
        """Trim/extend the *left* edge of a clip."""
        c = next((c for c in self.ctx.project.clips if c.id == str(clip_id)), None)
        if not c:
            return

        st = max(0.0, float(start_beats))
        ln = max(0.25, float(length_beats))

        if snap_beats and float(snap_beats) > 0:
            g = float(snap_beats)
            st = max(0.0, round(st / g) * g)
            ln = max(g, round(ln / g) * g)

        c.start_beats = st
        c.length_beats = ln
        c.offset_beats = max(0.0, float(offset_beats))
        c.offset_seconds = max(0.0, float(offset_seconds))

        self._emit_updated()

    def move_clip_track(self, clip_id: str, track_id: str) -> None:
        c = next((c for c in self.ctx.project.clips if c.id == clip_id), None)
        if not c:
            return
        c.track_id = str(track_id)
        self._emit_updated()

    # ---------- track editing ----------
    def set_track_kind(self, track_id: str, kind: str) -> None:
        """Change track kind (e.g. audio -> instrument) in a project-safe way."""
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        k = str(kind or "audio")
        if getattr(trk, "kind", "audio") == k:
            return
        trk.kind = k
        self._emit_updated()


    # ---------- clip creation (non-placeholder) ----------
    def add_midi_clip_at(self, track_id: str, start_beats: float, length_beats: float = 4.0, label: str = "") -> str:
        """Create a real MIDI clip (notes editable in PianoRoll) on an instrument track.
        
        FIXED v0.0.19.7.4: Intelligente Label-Generierung wie eine Pro-DAW!
        """
        if not track_id:
            track_id = self.ensure_instrument_track()
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        # If the user draws a MIDI clip on a non-instrument track in the arranger,
        # we convert that track to an instrument track instead of silently creating
        # the clip elsewhere (which looks like "nothing happened" in the UI).
        if trk and getattr(trk, "kind", "audio") != "instrument":
            old_kind = str(getattr(trk, "kind", "audio"))
            trk.kind = "instrument"
            if old_kind == "audio":
                if str(getattr(trk, "name", "")).strip().lower().startswith("audio"):
                    trk.name = "Instrument Track"
        if not trk:
            track_id = self.ensure_instrument_track()
        
        # Generate intelligent label if not provided
        if not label or label == "MIDI Clip":
            label = self._generate_midi_clip_label(track_id)
        
        clip = Clip(kind="midi", track_id=track_id, start_beats=float(start_beats), length_beats=max(0.25, float(length_beats)), label=str(label))
        self.ctx.project.clips.append(clip)
        self.ctx.project.midi_notes.setdefault(clip.id, [])
        self.select_clip(clip.id)
        self.status.emit(f"MIDI-Clip erstellt: {clip.label}")
        self._emit_updated()
        return clip.id

    def _audio_duration_seconds(self, path: Path) -> float:
        """Best-effort duration for common formats. WAV is exact; others optional."""
        p = Path(path)
        try:
            if p.suffix.lower() in (".wav", ".wave"):
                with contextlib.closing(wave.open(str(p), "rb")) as wf:
                    frames = wf.getnframes()
                    rate = wf.getframerate() or 48000
                    return float(frames) / float(rate)
        except Exception:
            pass
        # Optional: pydub (requires ffmpeg for mp3/aac/ogg)
        try:
            from pydub import AudioSegment  # type: ignore
            seg = AudioSegment.from_file(str(p))
            return float(len(seg)) / 1000.0
        except Exception:
            return 0.0

    def _generate_midi_clip_label(self, track_id: str) -> str:
        """Generate intelligent MIDI clip label like 'Track1 MIDI 1'.
        
        FIXED v0.0.19.7.4: Clip Naming wie eine Pro-DAW!
        """
        try:
            # Get track name
            track = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
            track_name = "Track"
            if track:
                name = str(getattr(track, "name", "")).strip()
                if name:
                    track_name = name
            
            # Count existing MIDI clips on this track
            midi_clips_on_track = [
                c for c in self.ctx.project.clips 
                if c.track_id == track_id and c.kind == "midi"
            ]
            clip_number = len(midi_clips_on_track) + 1
            
            # Generate label like "Track1 MIDI 1"
            return f"{track_name} MIDI {clip_number}"
        
        except Exception as e:
            print(f"[ProjectService._generate_midi_clip_label] Error: {e}")
            return "MIDI Clip"



    def add_audio_clip_placeholder_at(self, track_id: str, start_beats: float = 0.0, length_beats: float = 4.0, label: str = "Audio Clip") -> str:
        """Create an empty/placeholder audio clip (no media yet).

        Useful for DAW workflow: Region first, content later (record/import).
        """
        tid = track_id or self.ensure_audio_track()
        clip = Clip(kind="audio", track_id=str(tid), start_beats=max(0.0, float(start_beats)), length_beats=max(0.25, float(length_beats)), label=str(label))
        # Keep source_path/media_id None -> waveform preview shows placeholder text.
        self.ctx.project.clips.append(clip)
        self.select_clip(clip.id)
        self.status.emit(f"Audio-Clip (Platzhalter) erstellt: {clip.label}")
        self._emit_updated()
        return clip.id

    def add_audio_clip_from_file_at(self, track_id: str, path: Path, start_beats: float = 0.0, launcher_slot_key: str | None = None, place_in_arranger: bool = True, source_bpm_override: Optional[float] = None) -> Optional[str]:
        """Import audio into project media and create an audio clip at a specific position."""
        p = Path(path)
        if not p.exists():
            self.error.emit("Audio-Datei nicht gefunden.")
            return None

        def fn():
            return fm_import_audio(p, self.ctx)

        def ok(item):
            try:
                tid = track_id or self.ensure_audio_track()
                project_bpm = float(self.ctx.project.bpm or 120.0)
                secs = self._audio_duration_seconds(Path(item.path))

                # Phase 3: basic sync by detecting a source BPM from the file name.
                # Examples: "loop_150bpm.wav", "Kick (110 BPM).wav"
                source_bpm: Optional[float] = None
                # If caller provides a BPM (e.g. Browser BPM analysis), prefer it.
                if source_bpm_override is not None:
                    try:
                        source_bpm = float(source_bpm_override)
                    except Exception:
                        source_bpm = None

                if source_bpm is None:
                    m = re.search(r"(\d+(?:\.\d+)?)\s*bpm", (p.stem or ""), flags=re.IGNORECASE)
                    if m:
                        try:
                            source_bpm = float(m.group(1))
                        except Exception:
                            source_bpm = None
    
                # If we know the source BPM, we compute the clip length in *beats of the source*,
                # so it will align to the grid after time-stretch.
                if secs > 0:
                    if source_bpm:
                        beats = secs * source_bpm / 60.0
                    else:
                        beats = secs * project_bpm / 60.0
                else:
                    beats = 4.0

                clip = Clip(kind="audio", track_id=tid, label=item.label or p.stem, media_id=item.id, source_path=str(Path(item.path)), source_bpm=source_bpm)
                clip.start_beats = max(0.0, float(start_beats))
                clip.length_beats = max(0.25, float(beats))

                # IMPORTANT: launcher-only clips must not appear in Arranger.
                # ArrangerCanvas filters clips via clip.launcher_only.
                clip.launcher_only = bool(not place_in_arranger)

                self.ctx.project.clips.append(clip)
                # Optional: assign to Clip-Launcher slot (Overlay drop)
                if launcher_slot_key:
                    try:
                        self.ctx.project.clip_launcher[str(launcher_slot_key)] = str(clip.id)
                    except Exception:
                        pass
                self.select_clip(clip.id)
                self.status.emit(f"Audio-Clip erstellt: {clip.label}")
                self._emit_updated()
            except Exception as e:
                self.error.emit(f"Audio-Clip Fehler: {e}")

        def err(msg: str):
            self.error.emit(f"Audio import fehlgeschlagen: {msg}")

        self._submit(fn, ok, err)
        return None

    def import_midi_to_track_at(self, path: Path, track_id: str, start_beats: float = 0.0, length_beats: float = 4.0) -> str:
        """Imports a MIDI file as a new MIDI clip at the given position.

        Phase 2: real parsing (note-on/note-off) into MidiNote events.
        We map MIDI tick-time into *beats* using ticks_per_beat. Tempo changes affect seconds,
        but the grid in the arranger is beat-based, so this mapping is stable.
        """
        p = Path(path)
        if not p.exists():
            self.error.emit("MIDI-Datei nicht gefunden.")
            return ""

        try:
            import mido  # type: ignore
        except Exception:
            self.error.emit("MIDI Import: Abhängigkeit 'mido' fehlt (pip install -r requirements.txt).")
            return ""

        mf = mido.MidiFile(str(p))
        tpb = float(mf.ticks_per_beat or 480)

        # Merge all tracks into one time-ordered stream.
        abs_tick = 0
        active: dict[tuple[int, int], tuple[int, int]] = {}  # (channel,pitch) -> (start_tick, velocity)
        notes: list[MidiNote] = []

        for msg in mido.merge_tracks(mf.tracks):
            abs_tick += int(getattr(msg, "time", 0) or 0)
            if msg.type == "note_on" and int(getattr(msg, "velocity", 0) or 0) > 0:
                key = (int(getattr(msg, "channel", 0) or 0), int(getattr(msg, "note", 0) or 0))
                active[key] = (abs_tick, int(getattr(msg, "velocity", 0) or 0))
            elif msg.type in ("note_off", "note_on"):
                # note_on with velocity 0 is note_off
                vel = int(getattr(msg, "velocity", 0) or 0)
                if msg.type == "note_on" and vel != 0:
                    continue
                key = (int(getattr(msg, "channel", 0) or 0), int(getattr(msg, "note", 0) or 0))
                if key in active:
                    start_tick, start_vel = active.pop(key)
                    end_tick = abs_tick
                    if end_tick <= start_tick:
                        continue
                    start_b = float(start_tick) / tpb
                    len_b = float(end_tick - start_tick) / tpb
                    notes.append(MidiNote(pitch=key[1], start_beats=start_b + float(start_beats), length_beats=max(0.05, len_b), velocity=start_vel))

        # Compute clip length from notes if available.
        max_end = max((n.start_beats + n.length_beats for n in notes), default=float(start_beats) + float(length_beats))
        clip_len = max(float(length_beats), max_end - float(start_beats))
        clip_len = max(0.25, clip_len)

        clip_id = self.add_midi_clip_at(track_id, start_beats=start_beats, length_beats=clip_len, label=p.stem or "MIDI")
        self.ctx.project.midi_notes[clip_id] = notes
        self.status.emit(f"MIDI importiert: {p.name} ({len(notes)} Noten)")
        self._emit_updated()
        return clip_id

    def import_midi(self, path: Any, track_id: Optional[str] = None, start_beats: float = 0.0) -> str:
        """Import a MIDI file and place it into an instrument track.

        UI-friendly entry point.
        - If `track_id` is given and is an instrument track, it is used.
        - Otherwise the current active track is used if it is an instrument track.
        - Otherwise a new instrument track is created.
        """
        p = Path(str(path))

        # Prefer explicit target track
        tid = track_id or self.active_track_id
        if tid:
            trk = next((t for t in self.ctx.project.tracks if t.id == tid), None)
            if not trk or trk.kind != 'instrument':
                tid = ''

        if not tid:
            tid = self.add_track(kind='instrument', name='Instrument Track').id
            self.set_active_track(tid)

        return self.import_midi_to_track_at(p, track_id=tid, start_beats=float(start_beats), length_beats=16.0)

    # --- Track controls (Phase 2: UI toggles) ---
    def toggle_track_mute(self, track_id: str) -> None:
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        trk.muted = not bool(trk.muted)
        self.status.emit(f"Mute: {trk.name} = {trk.muted}")
        self._emit_updated()

    def toggle_track_solo(self, track_id: str) -> None:
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        trk.solo = not bool(trk.solo)
        self.status.emit(f"Solo: {trk.name} = {trk.solo}")
        self._emit_updated()

    def toggle_track_arm(self, track_id: str) -> None:
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        trk.record_arm = not bool(getattr(trk, "record_arm", False))
        self.status.emit(f"Rec-Arm: {trk.name} = {trk.record_arm}")
        self._emit_updated()

    # --- Clip Launcher (Scenes) ---
    def set_launcher_settings(self, quantize: str, mode: str) -> None:
        """Persist launcher settings on the project model and notify UI.

        Quantize: Off | 1 Beat | 1 Bar
        Mode: Trigger | Toggle | Gate
        """
        q = str(quantize or '1 Bar')
        m = str(mode or 'Trigger')
        if q not in ['Off', '1 Beat', '1 Bar']:
            q = '1 Bar'
        if m not in ['Trigger', 'Toggle', 'Gate']:
            m = 'Trigger'
        try:
            self.ctx.project.launcher_quantize = q
            self.ctx.project.launcher_mode = m
        except Exception:
            pass
        self.status.emit(f'Launcher: Quantize={q}, Mode={m}')
        self._emit_updated()

    def cliplauncher_assign(self, slot_key: str, clip_id: str) -> None:
        """Assign an existing clip to a launcher slot (slot_key -> clip_id).

        Slot keys are stored on the project model (project.clip_launcher).
        """
        key = str(slot_key or '').strip()
        cid = str(clip_id or '').strip()
        if not key or not cid:
            return
        # only assign if clip exists
        if not any(c.id == cid for c in self.ctx.project.clips):
            self.error.emit('ClipLauncher: Clip nicht gefunden.')
            return
        try:
            self.ctx.project.clip_launcher[key] = cid
        except Exception:
            return
        self.status.emit('ClipLauncher: Slot belegt')
        self._emit_updated()

    def cliplauncher_clear(self, slot_key: str) -> None:
        """Clear a launcher slot."""
        key = str(slot_key or '').strip()
        if not key:
            return
        try:
            if key in self.ctx.project.clip_launcher:
                del self.ctx.project.clip_launcher[key]
        except Exception:
            pass
        self.status.emit('ClipLauncher: Slot geleert')
        self._emit_updated()


    # --- Audio Clip Editor integration (AudioEventEditor)
    def update_audio_clip_params(
        self,
        clip_id: str,
        *,
        gain: float | None = None,
        pan: float | None = None,
        pitch: float | None = None,
        formant: float | None = None,
        stretch: float | None = None,
        reversed: bool | None = None,
        muted: bool | None = None,
        fade_in_beats: float | None = None,
        fade_out_beats: float | None = None,
    ) -> None:
        """Update non-destructive audio parameters on a Clip.

        This updates the central Project model (single source of truth) so that:
        - AudioEventEditor reflects changes immediately
        - ClipLauncher slot preview stays in sync (via project.updated refresh)
        """
        cid = str(clip_id or "").strip()
        if not cid:
            return
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or getattr(clip, "kind", "") != "audio":
            return

        changed = False
        if gain is not None:
            try:
                clip.gain = float(gain)
                changed = True
            except Exception:
                pass
        if pan is not None:
            try:
                clip.pan = float(pan)
                changed = True
            except Exception:
                pass
        if pitch is not None:
            try:
                clip.pitch = float(pitch)
                changed = True
            except Exception:
                pass
        if formant is not None:
            try:
                clip.formant = float(formant)
                changed = True
            except Exception:
                pass
        if stretch is not None:
            try:
                clip.stretch = max(0.01, float(stretch))
                changed = True
            except Exception:
                pass
        if reversed is not None:
            try:
                clip.reversed = bool(reversed)
                changed = True
            except Exception:
                pass
        if muted is not None:
            try:
                clip.muted = bool(muted)
                changed = True
            except Exception:
                pass
        if fade_in_beats is not None:
            try:
                clip.fade_in_beats = max(0.0, float(fade_in_beats))
                changed = True
            except Exception:
                pass
        if fade_out_beats is not None:
            try:
                clip.fade_out_beats = max(0.0, float(fade_out_beats))
                changed = True
            except Exception:
                pass

        if changed:
            self._emit_updated()

    
    def set_audio_clip_loop(self, clip_id: str, start_beats: float, end_beats: float) -> None:
        """Set per-clip loop region (beats relative to clip content start)."""
        cid = str(clip_id or "").strip()
        if not cid:
            return
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or getattr(clip, "kind", "") != "audio":
            return
        try:
            s = max(0.0, float(start_beats))
            e = max(0.0, float(end_beats))
            clip.loop_start_beats = s
            clip.loop_end_beats = e
            self._emit_updated()
        except Exception:
            return

    # --- Pro Audio Clip methods (Bitwig/Ableton parity) ----------------------

    def normalize_audio_clip(self, clip_id: str) -> float | None:
        """Normalize clip by analysing peak level and setting gain to reach 0 dBFS.

        Returns the new gain value or None on failure.
        """
        cid = str(clip_id or "").strip()
        if not cid:
            return None
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or getattr(clip, "kind", "") != "audio":
            return None
        path = getattr(clip, "source_path", None)
        if not path:
            return None
        try:
            import os
            if not os.path.exists(str(path)):
                return None
            import soundfile as _sf
            import numpy as _np
            data, _sr = _sf.read(str(path), always_2d=True, dtype="float32")
            if data.size == 0:
                return None
            peak = float(_np.abs(data).max())
            if peak < 1e-10:
                return None
            new_gain = min(4.0, 1.0 / peak)
            clip.gain = new_gain
            self._emit_updated()
            return new_gain
        except Exception:
            return None

    def detect_onsets(self, clip_id: str, *, sensitivity: float = 2.0) -> list[float]:
        """Energy-based onset detection. Returns list of onset positions in beats.

        Uses spectral flux with adaptive threshold.
        sensitivity: threshold = mean + sensitivity*std (lower = more onsets)
        """
        cid = str(clip_id or "").strip()
        if not cid:
            return []
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or getattr(clip, "kind", "") != "audio":
            return []
        path = getattr(clip, "source_path", None)
        if not path:
            return []
        try:
            import os
            if not os.path.exists(str(path)):
                return []
            import soundfile as _sf
            import numpy as _np
            data, sr = _sf.read(str(path), always_2d=True, dtype="float32")
            if data.size == 0:
                return []

            mono = data.mean(axis=1)
            hop = max(1, int(sr * 0.01))  # 10ms hop
            n_frames = max(1, len(mono) // hop)

            # Energy per frame
            energy = _np.array([
                float(_np.sum(mono[i * hop:(i + 1) * hop] ** 2))
                for i in range(n_frames)
            ], dtype=_np.float64)

            # Spectral flux (half-wave rectified difference)
            flux = _np.zeros(n_frames, dtype=_np.float64)
            for i in range(1, n_frames):
                diff = energy[i] - energy[i - 1]
                flux[i] = max(0.0, diff)

            if flux.max() < 1e-12:
                return []

            # Adaptive threshold
            mean_f = float(flux.mean())
            std_f = float(flux.std())
            threshold = max(mean_f + sensitivity * std_f, 0.15 * float(flux.max()))

            # Minimum distance between onsets (50ms)
            min_dist_frames = max(1, int(0.05 * sr / hop))

            bpm = float(getattr(self.ctx.project, 'bpm', 120.0) or 120.0)
            samples_per_beat = sr * 60.0 / bpm

            onsets: list[float] = []
            last_onset = -min_dist_frames - 1
            for i in range(1, n_frames):
                if flux[i] > threshold and (i - last_onset) >= min_dist_frames:
                    sample_pos = i * hop
                    beat_pos = float(sample_pos / samples_per_beat)
                    onsets.append(round(beat_pos, 6))
                    last_onset = i

            clip.onsets = list(onsets)
            self._emit_updated()
            return list(onsets)
        except Exception:
            return []

    def add_onset_at(self, clip_id: str, at_beats: float) -> None:
        """Add a single onset marker at a given beat position."""
        cid = str(clip_id or "").strip()
        if not cid:
            return
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip:
            return
        try:
            b = float(at_beats)
            if not hasattr(clip, 'onsets') or clip.onsets is None:
                clip.onsets = []
            clip.onsets.append(round(b, 6))
            clip.onsets = sorted(set(clip.onsets))
            self._emit_updated()
        except Exception:
            pass

    def clear_onsets(self, clip_id: str) -> None:
        """Remove all onset markers from a clip."""
        cid = str(clip_id or "").strip()
        if not cid:
            return
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip:
            return
        try:
            clip.onsets = []
            self._emit_updated()
        except Exception:
            pass

    def find_zero_crossings(self, clip_id: str, near_beats: float, radius_beats: float = 0.05) -> float:
        """Find nearest zero-crossing to a given position for click-free edits.

        Returns the position in beats of the nearest zero crossing, or the
        original position if no crossing is found.
        """
        cid = str(clip_id or "").strip()
        if not cid:
            return float(near_beats)
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or getattr(clip, "kind", "") != "audio":
            return float(near_beats)
        path = getattr(clip, "source_path", None)
        if not path:
            return float(near_beats)
        try:
            import os
            if not os.path.exists(str(path)):
                return float(near_beats)
            import soundfile as _sf
            import numpy as _np
            data, sr = _sf.read(str(path), always_2d=True, dtype="float32")
            if data.size == 0:
                return float(near_beats)
            mono = data.mean(axis=1)

            bpm = float(getattr(self.ctx.project, 'bpm', 120.0) or 120.0)
            spb = sr * 60.0 / bpm  # samples per beat
            center = int(float(near_beats) * spb)
            radius = max(1, int(float(radius_beats) * spb))
            lo = max(0, center - radius)
            hi = min(len(mono) - 1, center + radius)

            seg = mono[lo:hi + 1]
            if len(seg) < 2:
                return float(near_beats)

            # Find sign changes
            signs = _np.sign(seg)
            crossings = _np.where(_np.diff(signs) != 0)[0]
            if len(crossings) == 0:
                return float(near_beats)

            # Find nearest to center
            center_in_seg = center - lo
            dists = _np.abs(crossings - center_in_seg)
            best_idx = int(crossings[_np.argmin(dists)])
            sample_pos = lo + best_idx
            return round(float(sample_pos / spb), 6)
        except Exception:
            return float(near_beats)

    def slice_at_onsets(self, clip_id: str) -> int:
        """Split audio events at all detected onset positions. Returns count of new splits."""
        cid = str(clip_id or "").strip()
        if not cid:
            return 0
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip:
            return 0
        try:
            onsets = sorted(set(getattr(clip, 'onsets', []) or []))
        except Exception:
            return 0
        if not onsets:
            return 0
        count = 0
        for ob in onsets:
            try:
                t = float(ob)
                if t <= 0.001:
                    continue
                # Find events that contain this onset
                evs = list(getattr(clip, "audio_events", []) or [])
                for e in evs:
                    s = float(getattr(e, "start_beats", 0.0) or 0.0)
                    l = float(getattr(e, "length_beats", 0.0) or 0.0)
                    eid = str(getattr(e, "id", ""))
                    if not eid or l < 0.01:
                        continue
                    if s + 0.001 < t < s + l - 0.001:
                        try:
                            self.split_audio_events_at(cid, t, event_ids=[eid])
                            count += 1
                        except Exception:
                            pass
                        break
            except Exception:
                continue
        return count

    # --- Clip-level automation (per-clip envelopes, Bitwig/Ableton-style) ---

    def add_clip_automation_point(self, clip_id: str, param: str, beat: float, value: float) -> None:
        """Add or update an automation breakpoint for a clip parameter.

        param: "gain", "pan", "pitch", "formant"
        beat: position in beats (relative to clip start)
        value: 0.0..1.0 normalized
        """
        cid = str(clip_id or "").strip()
        if not cid:
            return
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip:
            return
        if not hasattr(clip, 'clip_automation') or clip.clip_automation is None:
            clip.clip_automation = {}
        param = str(param or "").strip().lower()
        if param not in ("gain", "pan", "pitch", "formant"):
            return
        pts = clip.clip_automation.get(param, [])
        # Remove existing point at same beat (within epsilon)
        pts = [p for p in pts if abs(float(p.get("beat", 0)) - float(beat)) > 0.005]
        pts.append({"beat": round(float(beat), 4), "value": round(max(0.0, min(1.0, float(value))), 4)})
        pts.sort(key=lambda p: float(p.get("beat", 0)))
        clip.clip_automation[param] = pts
        self._emit_updated()

    def move_clip_automation_point(self, clip_id: str, param: str, old_beat: float, new_beat: float, value: float | None = None) -> None:
        """Move an existing automation breakpoint (tight tolerance) and optionally update its value.

        This is used by the *Zeiger/Pointer* tool in the AudioEventEditor so that dragging a point
        does not create duplicates.
        """
        cid = str(clip_id or "").strip()
        if not cid:
            return
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or not hasattr(clip, 'clip_automation') or clip.clip_automation is None:
            return
        param = str(param or "").strip().lower()
        if param not in ("gain", "pan", "pitch", "formant"):
            return
        pts = list(clip.clip_automation.get(param, []) or [])
        if not pts:
            return

        ob = float(old_beat)
        nb = float(new_beat)
        # Find nearest point to old_beat (tight tolerance)
        best_i = None
        best_d = 0.05  # beats
        for i, p in enumerate(pts):
            try:
                d = abs(float(p.get('beat', 0.0)) - ob)
            except Exception:
                continue
            if d < best_d:
                best_d = d
                best_i = i
        if best_i is None:
            return

        # Use old value if none provided
        if value is None:
            try:
                value = float(pts[best_i].get('value', 0.5))
            except Exception:
                value = 0.5

        # Remove old + insert new
        try:
            pts.pop(best_i)
        except Exception:
            return

        # Prevent duplicates near new beat
        pts = [p for p in pts if abs(float(p.get('beat', 0.0)) - nb) > 0.01]
        pts.append({'beat': round(float(nb), 4), 'value': round(max(0.0, min(1.0, float(value))), 4)})
        pts.sort(key=lambda p: float(p.get('beat', 0.0)))
        clip.clip_automation[param] = pts
        self._emit_updated()

    def remove_clip_automation_point(self, clip_id: str, param: str, beat: float) -> None:
        """Remove an automation breakpoint near the given beat."""
        cid = str(clip_id or "").strip()
        if not cid:
            return
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or not hasattr(clip, 'clip_automation') or not clip.clip_automation:
            return
        param = str(param or "").strip().lower()
        pts = clip.clip_automation.get(param, [])
        if not pts:
            return
        # Remove point nearest to beat (within tolerance)
        best_i = None
        best_d = 0.2  # tolerance in beats
        for i, p in enumerate(pts):
            d = abs(float(p.get("beat", 0)) - float(beat))
            if d < best_d:
                best_d = d
                best_i = i
        if best_i is not None:
            pts.pop(best_i)
            clip.clip_automation[param] = pts
            self._emit_updated()

    def clear_clip_automation(self, clip_id: str, param: str | None = None) -> None:
        """Clear all automation points for a param (or all params if None)."""
        cid = str(clip_id or "").strip()
        if not cid:
            return
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or not hasattr(clip, 'clip_automation') or not clip.clip_automation:
            return
        if param:
            clip.clip_automation[str(param).lower()] = []
        else:
            clip.clip_automation = {}
        self._emit_updated()

    # --- Stretch / Warp Markers ---

    def add_stretch_marker(self, clip_id: str, beat: float) -> None:
        """Add a warp marker at the given beat position.

        Storage format (JSON-safe): list of dicts:
            {"src": <beat in source space>, "dst": <beat in destination space>}

        For legacy projects where stretch_markers is a list of floats, we auto-upgrade to dicts.
        """
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == str(clip_id)), None)
        if not clip:
            return

        b = float(beat)
        raw = list(getattr(clip, "stretch_markers", None) or [])

        # Coerce legacy float markers into dict markers
        markers: list[dict] = []
        for m in raw:
            if isinstance(m, dict):
                try:
                    src = float(m.get('src', m.get('beat', 0.0)))
                    dst = float(m.get('dst', m.get('beat', src)))
                except Exception:
                    continue
                markers.append({'src': src, 'dst': dst})
            elif isinstance(m, (int, float)):
                fv = float(m)
                markers.append({'src': fv, 'dst': fv})

        # Don't add duplicates near dst
        if any(abs(float(mm.get('dst', 0.0)) - b) < 0.02 for mm in markers):
            return

        markers.append({'src': b, 'dst': b})
        markers.sort(key=lambda mm: float(mm.get('src', 0.0)))
        clip.stretch_markers = markers
        self._emit_updated()

    def remove_stretch_marker(self, clip_id: str, beat: float) -> None:
        """Remove the warp marker nearest to the given beat position (by dst)."""
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == str(clip_id)), None)
        if not clip:
            return

        raw = list(getattr(clip, "stretch_markers", None) or [])
        if not raw:
            return

        # Coerce legacy float markers into dict markers
        markers: list[dict] = []
        for m in raw:
            if isinstance(m, dict):
                try:
                    src = float(m.get('src', m.get('beat', 0.0)))
                    dst = float(m.get('dst', m.get('beat', src)))
                except Exception:
                    continue
                markers.append({'src': src, 'dst': dst})
            elif isinstance(m, (int, float)):
                fv = float(m)
                markers.append({'src': fv, 'dst': fv})

        if not markers:
            return

        b = float(beat)
        # Find nearest by dst
        nearest_idx = min(range(len(markers)), key=lambda i: abs(float(markers[i].get('dst', 0.0)) - b))
        if abs(float(markers[nearest_idx].get('dst', 0.0)) - b) < 0.5:
            markers.pop(nearest_idx)
            markers.sort(key=lambda mm: float(mm.get('src', 0.0)))
            clip.stretch_markers = markers
            self._emit_updated()

    def move_stretch_marker(self, clip_id: str, old_beat: float, new_beat: float) -> None:
        """Move a warp marker from old_beat to new_beat (updates dst).

        Markers are stored as dicts {src,dst}. We keep src fixed (anchor to source transient)
        and move dst (musical grid position). To prevent crossings, dst is clamped between
        neighbor dst positions in src-order.
        """
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == str(clip_id)), None)
        if not clip:
            return

        raw = list(getattr(clip, "stretch_markers", None) or [])
        if not raw:
            return

        # Coerce legacy float markers into dict markers
        markers: list[dict] = []
        for m in raw:
            if isinstance(m, dict):
                try:
                    src = float(m.get('src', m.get('beat', 0.0)))
                    dst = float(m.get('dst', m.get('beat', src)))
                except Exception:
                    continue
                markers.append({'src': src, 'dst': dst})
            elif isinstance(m, (int, float)):
                fv = float(m)
                markers.append({'src': fv, 'dst': fv})

        if not markers:
            return

        ob = float(old_beat)
        nb = float(new_beat)

        # Find nearest by dst to old_beat (before sorting)
        idx = min(range(len(markers)), key=lambda i: abs(float(markers[i].get('dst', 0.0)) - ob))
        if abs(float(markers[idx].get('dst', 0.0)) - ob) > 0.75:
            return
        src_key = float(markers[idx].get('src', 0.0))

        # Clamp dst between neighbor dst positions (in src order)
        markers.sort(key=lambda mm: float(mm.get('src', 0.0)))
        # Re-find index by src
        idx2 = None
        for i, mm in enumerate(markers):
            if abs(float(mm.get('src', 0.0)) - src_key) < 1e-6:
                idx2 = i
                break
        if idx2 is None:
            return

        lo = 0.0
        hi = float(getattr(clip, 'length_beats', 0.0) or 0.0)
        if hi <= 0.0:
            hi = max(0.0, float(max(float(mm.get('dst', 0.0)) for mm in markers) + 1.0))

        eps = 0.02
        if idx2 > 0:
            try:
                lo = max(lo, float(markers[idx2 - 1].get('dst', 0.0)) + eps)
            except Exception:
                pass
        if idx2 < len(markers) - 1:
            try:
                hi = min(hi, float(markers[idx2 + 1].get('dst', hi)) - eps)
            except Exception:
                pass

        nb = max(lo, min(hi, nb))
        markers[idx2]['dst'] = float(nb)
        clip.stretch_markers = markers
        self._emit_updated()

    # --- Phase 2: Non-destructive AudioEvents (Knife/Merge) -----------------

    def _ensure_audio_events(self, clip) -> None:  # noqa: ANN001
        """Ensure clip.audio_events exists. If missing/empty, derive from slices or full length."""
        try:
            evs = list(getattr(clip, "audio_events", []) or [])
        except Exception:
            evs = []

        # If already has events, keep (but normalize types if dicts slipped in)
        if evs:
            from pydaw.model.project import AudioEvent
            conv = []
            for e in evs:
                if hasattr(e, "start_beats") and hasattr(e, "length_beats"):
                    conv.append(e)
                elif isinstance(e, dict):
                    try:
                        conv.append(AudioEvent(**e))
                    except Exception:
                        continue
            clip.audio_events = conv
            # keep slices in sync for legacy UI
            self._sync_slices_from_events(clip)
            return

        from pydaw.model.project import AudioEvent

        length = float(getattr(clip, "length_beats", 0.0) or 0.0)
        length = max(0.0, length)
        base_off = float(getattr(clip, "offset_beats", 0.0) or 0.0)

        # Build boundaries from slices (if any)
        try:
            slices = sorted(float(x) for x in (getattr(clip, "audio_slices", []) or []) if isinstance(x, (int, float)))
        except Exception:
            slices = []
        # keep only inside (0, length)
        eps = 1e-6
        slices = [s for s in slices if eps < s < (length - eps)]
        bounds = [0.0] + slices + [length]
        evs2 = []
        for i in range(len(bounds) - 1):
            a = float(bounds[i]); b = float(bounds[i+1])
            if b <= a + eps:
                continue
            evs2.append(AudioEvent(start_beats=a, length_beats=(b - a), source_offset_beats=base_off + a))
        if not evs2:
            evs2 = [AudioEvent(start_beats=0.0, length_beats=length, source_offset_beats=base_off)]
        clip.audio_events = evs2
        self._sync_slices_from_events(clip)

    def _sync_slices_from_events(self, clip) -> None:  # noqa: ANN001
        """Legacy compatibility: store event boundaries as clip.audio_slices."""
        try:
            evs = list(getattr(clip, "audio_events", []) or [])
        except Exception:
            evs = []
        cuts = []
        for e in evs:
            try:
                s = float(getattr(e, "start_beats", 0.0) or 0.0)
            except Exception:
                continue
            if s > 1e-6:
                cuts.append(s)
        cuts = sorted(set(round(x, 6) for x in cuts))
        clip.audio_slices = cuts

    def split_audio_event(self, clip_id: str, at_beats: float) -> None:
        """Knife: split the AudioEvent that contains at_beats into two events (non-destructive)."""
        # Backward-compatible wrapper.
        # NOTE: Newer UI code can call split_audio_events_at(..., event_ids=[...])
        # to enforce selection rules.
        self.split_audio_events_at(clip_id, at_beats, event_ids=None)

    def split_audio_events_at(self, clip_id: str, at_beats: float, event_ids: List[str] | None = None) -> List[str]:
        """Knife: split one or multiple AudioEvents at the same clip-local time (non-destructive).

        Args:
            clip_id: target clip id
            at_beats: clip-local split time in beats
            event_ids: if provided, only these events are eligible and *all* that contain at_beats
                       will be split. If None, the first containing event is split (legacy behavior).

        Returns:
            List of event ids that should be selected after the operation.
            When a split happens, contains the two new ids (left/right). If multiple splits happen,
            the list contains all new ids.
        """
        cid = str(clip_id or "").strip()
        if not cid:
            return []
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or getattr(clip, "kind", "") != "audio":
            return []

        try:
            t = float(at_beats)
        except Exception:
            return []
        length = max(0.0, float(getattr(clip, "length_beats", 0.0) or 0.0))
        t = max(0.0, min(length, t))

        self._ensure_audio_events(clip)
        evs = list(getattr(clip, "audio_events", []) or [])
        if not evs:
            return []

        wanted: set[str] | None = None
        if event_ids is not None:
            try:
                wanted = set(str(x) for x in event_ids if str(x).strip())
            except Exception:
                wanted = None

        from pydaw.model.project import AudioEvent

        eps = 1e-4
        out: List[AudioEvent] = []
        new_selected: List[str] = []
        did_any_split = False

        # In legacy mode (wanted is None), we split only the first containing event.
        legacy_done = False

        for e in evs:
            try:
                eid = str(getattr(e, "id", ""))
                s = float(getattr(e, "start_beats", 0.0) or 0.0)
                l = float(getattr(e, "length_beats", 0.0) or 0.0)
                base_off = float(getattr(e, "source_offset_beats", 0.0) or 0.0)
            except Exception:
                out.append(e)
                continue

            if l <= eps:
                out.append(e)
                continue

            eend = s + l
            contains = (s - eps) <= t <= (eend + eps)

            eligible = contains
            if wanted is not None:
                eligible = contains and (eid in wanted)

            if eligible and not legacy_done:
                # avoid splitting at boundaries
                if abs(t - s) < eps or abs(t - eend) < eps:
                    out.append(e)
                    if wanted is not None and eid in wanted:
                        new_selected.append(eid)
                    continue

                left_len = t - s
                right_len = eend - t
                if left_len <= eps or right_len <= eps:
                    out.append(e)
                    if wanted is not None and eid in wanted:
                        new_selected.append(eid)
                    continue

                left = AudioEvent(start_beats=s, length_beats=left_len, source_offset_beats=base_off)
                right = AudioEvent(start_beats=t, length_beats=right_len, source_offset_beats=base_off + left_len)
                out.extend([left, right])
                new_selected.extend([left.id, right.id])
                did_any_split = True

                if wanted is None:
                    legacy_done = True
                continue

            out.append(e)
            if wanted is not None and eid in wanted:
                new_selected.append(eid)

        if not did_any_split:
            return []

        out.sort(key=lambda x: float(getattr(x, "start_beats", 0.0) or 0.0))
        clip.audio_events = out
        self._sync_slices_from_events(clip)
        self._emit_updated()
        return new_selected

    def merge_audio_events_near(self, clip_id: str, at_beats: float, *, tolerance_beats: float = 0.05) -> None:
        """Eraser: merge two neighboring events by clicking near their boundary."""
        cid = str(clip_id or "").strip()
        if not cid:
            return
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or getattr(clip, "kind", "") != "audio":
            return
        try:
            t = float(at_beats)
        except Exception:
            return
        tol = max(0.0, float(tolerance_beats))

        self._ensure_audio_events(clip)
        evs = list(getattr(clip, "audio_events", []) or [])
        if len(evs) < 2:
            return

        # boundaries are start positions of events (excluding first at 0)
        best_i = None
        best_d = None
        for i in range(1, len(evs)):
            b = float(getattr(evs[i], "start_beats", 0.0) or 0.0)
            d = abs(b - t)
            if best_d is None or d < best_d:
                best_d = d
                best_i = i
        if best_i is None or best_d is None or best_d > tol:
            return

        prev = evs[best_i - 1]
        cur = evs[best_i]
        s0 = float(getattr(prev, "start_beats", 0.0) or 0.0)
        l0 = float(getattr(prev, "length_beats", 0.0) or 0.0)
        l1 = float(getattr(cur, "length_beats", 0.0) or 0.0)
        off0 = float(getattr(prev, "source_offset_beats", 0.0) or 0.0)

        from pydaw.model.project import AudioEvent
        merged = AudioEvent(start_beats=s0, length_beats=(l0 + l1), source_offset_beats=off0)

        new_list = evs[:best_i-1] + [merged] + evs[best_i+1:]
        new_list.sort(key=lambda x: float(getattr(x, "start_beats", 0.0) or 0.0))
        clip.audio_events = new_list
        self._sync_slices_from_events(clip)
        self._emit_updated()


    # --- Phase 2.1: AudioEvent selection / move / quantize / consolidate -----

    def snap_quantum_beats(self, division: str | None = None) -> float:
        """Return grid snap quantum in beats (quarter-note beats).

        - For '1/16' -> 0.25 beats (because whole note = 4 beats).
        - For '1/4'  -> 1.0 beat.
        """
        div = (division or getattr(self.ctx.project, "snap_division", "1/16") or "1/16").strip()
        # Allow values like '1/16'
        try:
            if "/" in div:
                num_s, den_s = div.split("/", 1)
                num = float(num_s)
                den = float(den_s)
                if den <= 0:
                    return 0.25
                return max(1e-6, (4.0 * num) / den)
        except Exception:
            pass
        return 0.25

    def move_audio_events(self, clip_id: str, event_ids: List[str], delta_beats: float) -> None:
        """Move selected AudioEvents by delta_beats, clamped to clip bounds.

        Notes:
        - Non-destructive: source_offset_beats stays unchanged (slip editing is a separate feature).
        - Overlaps are currently allowed (Phase 2.2 can add collision handling).
        """
        cid = str(clip_id or "").strip()
        if not cid:
            return
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or getattr(clip, "kind", "") != "audio":
            return
        try:
            d = float(delta_beats)
        except Exception:
            return
        if abs(d) < 1e-9:
            return

        self._ensure_audio_events(clip)
        evs = list(getattr(clip, "audio_events", []) or [])
        if not evs:
            return

        wanted = {str(x) for x in (event_ids or []) if str(x)}
        if not wanted:
            return

        # collect items
        sel = []
        for e in evs:
            try:
                if str(getattr(e, "id", "")) in wanted:
                    sel.append(e)
            except Exception:
                continue
        if not sel:
            return

        length = max(0.0, float(getattr(clip, "length_beats", 0.0) or 0.0))

        min_start = None
        max_end = None
        for e in sel:
            s = float(getattr(e, "start_beats", 0.0) or 0.0)
            l = float(getattr(e, "length_beats", 0.0) or 0.0)
            if min_start is None or s < min_start:
                min_start = s
            if max_end is None or (s + l) > max_end:
                max_end = s + l
        if min_start is None or max_end is None:
            return

        # clamp delta to stay inside [0, length]
        d_min = -min_start
        d_max = length - max_end
        if d < d_min:
            d = d_min
        if d > d_max:
            d = d_max

        for e in sel:
            e.start_beats = float(getattr(e, "start_beats", 0.0) or 0.0) + d

        evs.sort(key=lambda x: float(getattr(x, "start_beats", 0.0) or 0.0))
        clip.audio_events = evs
        self._sync_slices_from_events(clip)
        self._emit_updated()

    
    def duplicate_audio_events(self, clip_id: str, event_ids: List[str], delta_beats: float = 0.0, *, emit_updated: bool = True) -> dict[str, str]:
        """Duplicate selected AudioEvents and return a mapping old_id -> new_id.

        Used by AudioEventEditor for Pro-DAW-like Alt=Duplicate drag.
        Non-destructive: duplicates reference the same source file via source_offset_beats.
        """

        cid = str(clip_id or "").strip()
        if not cid:
            return {}
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or getattr(clip, "kind", "") != "audio":
            return {}

        self._ensure_audio_events(clip)
        evs = list(getattr(clip, "audio_events", []) or [])
        if not evs:
            return {}

        wanted = {str(x) for x in (event_ids or []) if str(x)}
        if not wanted:
            return {}

        try:
            d = float(delta_beats)
        except Exception:
            d = 0.0

        length = max(0.0, float(getattr(clip, "length_beats", 0.0) or 0.0))
        out_map: dict[str, str] = {}
        new_events: list[AudioEvent] = []

        for e in evs:
            try:
                oid = str(getattr(e, "id", ""))
                if oid not in wanted:
                    continue
                start = float(getattr(e, "start_beats", 0.0) or 0.0) + d
                l = float(getattr(e, "length_beats", 0.0) or 0.0)
                # clamp within clip bounds
                start = max(0.0, min(start, max(0.0, length - max(0.0, l))))
                nid = new_id("aev")
                out_map[oid] = nid
                new_events.append(
                    AudioEvent(
                        id=nid,
                        start_beats=float(start),
                        length_beats=float(l),
                        source_offset_beats=float(getattr(e, "source_offset_beats", 0.0) or 0.0),
                    )
                )
            except Exception:
                continue

        if not new_events:
            return {}

        evs.extend(new_events)
        try:
            evs.sort(key=lambda x: float(getattr(x, "start_beats", 0.0) or 0.0))
        except Exception:
            pass
        clip.audio_events = evs
        self._sync_slices_from_events(clip)

        if emit_updated:
            self._emit_updated()
        return out_map

    def quantize_audio_events(self, clip_id: str, event_ids: List[str], division: str | None = None) -> None:
        """Quantize selected AudioEvents to the current snap grid (start_beats)."""
        cid = str(clip_id or "").strip()
        if not cid:
            return
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or getattr(clip, "kind", "") != "audio":
            return

        self._ensure_audio_events(clip)
        evs = list(getattr(clip, "audio_events", []) or [])
        if not evs:
            return

        wanted = {str(x) for x in (event_ids or []) if str(x)}
        if not wanted:
            return

        q = self.snap_quantum_beats(division)
        length = max(0.0, float(getattr(clip, "length_beats", 0.0) or 0.0))

        for e in evs:
            try:
                if str(getattr(e, "id", "")) not in wanted:
                    continue
                s = float(getattr(e, "start_beats", 0.0) or 0.0)
                l = float(getattr(e, "length_beats", 0.0) or 0.0)
                snapped = round(s / q) * q
                snapped = max(0.0, min(snapped, max(0.0, length - l)))
                e.start_beats = float(snapped)
            except Exception:
                continue

        evs.sort(key=lambda x: float(getattr(x, "start_beats", 0.0) or 0.0))
        clip.audio_events = evs
        self._sync_slices_from_events(clip)
        self._emit_updated()

    def consolidate_audio_events(self, clip_id: str, event_ids: List[str]) -> None:
        """Consolidate selected AudioEvents into one, but only if they form a contiguous, source-aligned chain.

        Requirements for merge:
        - Events are contiguous in clip timeline (end == next.start)
        - And contiguous in source timeline (next.source_offset == prev.source_offset + prev.length)
        """
        cid = str(clip_id or "").strip()
        if not cid:
            return
        clip = next((c for c in self.ctx.project.clips if getattr(c, "id", "") == cid), None)
        if not clip or getattr(clip, "kind", "") != "audio":
            return

        self._ensure_audio_events(clip)
        evs = list(getattr(clip, "audio_events", []) or [])
        if len(evs) < 2:
            return

        wanted = {str(x) for x in (event_ids or []) if str(x)}
        if not wanted:
            return

        sel = [e for e in evs if str(getattr(e, "id", "")) in wanted]
        if len(sel) < 2:
            return
        sel.sort(key=lambda x: float(getattr(x, "start_beats", 0.0) or 0.0))

        eps = 1e-4
        ok = True
        for a, b in zip(sel, sel[1:]):
            a_s = float(getattr(a, "start_beats", 0.0) or 0.0)
            a_l = float(getattr(a, "length_beats", 0.0) or 0.0)
            a_o = float(getattr(a, "source_offset_beats", 0.0) or 0.0)
            b_s = float(getattr(b, "start_beats", 0.0) or 0.0)
            b_o = float(getattr(b, "source_offset_beats", 0.0) or 0.0)
            if abs((a_s + a_l) - b_s) > eps:
                ok = False
                break
            if abs((a_o + a_l) - b_o) > eps:
                ok = False
                break
        if not ok:
            return

        from pydaw.model.project import AudioEvent
        first = sel[0]
        start = float(getattr(first, "start_beats", 0.0) or 0.0)
        off = float(getattr(first, "source_offset_beats", 0.0) or 0.0)
        total = sum(float(getattr(e, "length_beats", 0.0) or 0.0) for e in sel)
        merged = AudioEvent(start_beats=start, length_beats=total, source_offset_beats=off, id=str(getattr(first, "id", "")))

        # rebuild list: remove selected ids, insert merged
        new_list = [e for e in evs if str(getattr(e, "id", "")) not in wanted]
        new_list.append(merged)
        new_list.sort(key=lambda x: float(getattr(x, "start_beats", 0.0) or 0.0))
        clip.audio_events = new_list
        self._sync_slices_from_events(clip)
        self._emit_updated()

    # --- Legacy wrappers (Phase 1 API) -----------------

    def add_audio_slice(self, clip_id: str, at_beats: float) -> None:
        """Legacy: Knife marker. Now implemented as AudioEvent split."""
        self.split_audio_event(clip_id, at_beats)

    def remove_audio_slice_near(self, clip_id: str, at_beats: float, *, tolerance_beats: float = 0.05) -> None:
        """Legacy: remove slice marker. Now implemented as AudioEvent merge."""
        self.merge_audio_events_near(clip_id, at_beats, tolerance_beats=tolerance_beats)
# --- Clip grouping (Phase 2) ---
    def group_clips(self, clip_ids: List[str]) -> str:
        ids = [cid for cid in clip_ids if cid]
        if len(ids) < 2:
            return ""
        gid = f"grp_{uuid.uuid4().hex[:8]}"
        for c in self.ctx.project.clips:
            if c.id in ids:
                c.group_id = gid
        self.status.emit(f"Gruppe erstellt: {gid} ({len(ids)} Clips)")
        self._emit_updated()
        return gid

    def ungroup_clips(self, clip_ids: List[str]) -> None:
        ids = [cid for cid in clip_ids if cid]
        for c in self.ctx.project.clips:
            if c.id in ids:
                c.group_id = ""
        self.status.emit("Gruppe aufgelöst")
        self._emit_updated()

    # ---------- audio import/export (UI compatibility) ----------
    def import_audio(self, path: Path) -> str:
        """Imports audio into the active/first audio track (legacy UI entry point).

        Note: audio import is threaded; the created clip is committed asynchronously.
        This function returns an empty string for compatibility.
        """
        tid = self.active_track_id
        if not tid:
            tid = next((t.id for t in self.ctx.project.tracks if t.kind == 'audio'), '')
        if not tid:
            tid = self.ensure_audio_track()
        try:
            self.add_audio_clip_from_file_at(tid, Path(path), start_beats=0.0)
        except Exception as e:
            self.error.emit(f"Audio import fehlgeschlagen: {e}")
        return ''

    def import_audio_to_project(self, track_id: str, path: Path, label: str = "") -> tuple:
        """Import an audio file into <project>/media/ and return (abs_path, media_id).

        This is the primary API for instrument plugins (Sampler, DrumMachine)
        to ensure samples are stored inside the project folder — Bitwig/Ableton-style.

        Returns:
            (str, str): (absolute_load_path, media_id)
        """
        p = Path(path)
        if not p.exists():
            return (str(p), "")
        try:
            item = fm_import_audio(p, self.ctx)
            return (str(item.path), str(item.id))
        except Exception as exc:
            log.warning("import_audio_to_project failed: %s", exc)
            return (str(p), "")

    def import_audio_to_track_at(self, path: Path, track_id: str, start_beats: float = 0.0, length_beats: float = 4.0) -> str:
        """Legacy signature: import an audio file and place it at the given position.

        `length_beats` is ignored because the clip length is derived from the file duration.
        Import is threaded; this returns an empty string for compatibility.
        """
        try:
            self.add_audio_clip_from_file_at(str(track_id), Path(path), start_beats=float(start_beats))
        except Exception as e:
            self.error.emit(f"Audio import fehlgeschlagen: {e}")
        return ''

    
    # ---------- Undo / Redo (Command Pattern) ----------
    def snapshot_midi_notes(self, clip_id: str) -> MidiSnapshot:
        """Create a lightweight snapshot of a clip's MIDI notes."""
        snap: MidiSnapshot = []
        notes = self.ctx.project.midi_notes.get(str(clip_id), []) or []
        for n in notes:
            try:
                snap.append(
                    {
                        "pitch": int(getattr(n, "pitch", 60)),
                        "start_beats": float(getattr(n, "start_beats", 0.0)),
                        "length_beats": float(getattr(n, "length_beats", 1.0)),
                        "velocity": int(getattr(n, "velocity", 100)),
                    }
                )
            except Exception:
                continue
        return snap

    def _apply_midi_snapshot(self, clip_id: str, snap: MidiSnapshot) -> None:
        from pydaw.model.midi import MidiNote
        notes = []
        for d in (snap or []):
            try:
                notes.append(
                    MidiNote(
                        pitch=int(d.get("pitch", 60)),
                        start_beats=float(d.get("start_beats", 0.0)),
                        length_beats=float(d.get("length_beats", 1.0)),
                        velocity=int(d.get("velocity", 100)),
                    ).clamp()
                )
            except Exception:
                continue
        self.set_midi_notes(str(clip_id), notes)

    def commit_midi_notes_edit(self, clip_id: str, before: MidiSnapshot, label: str) -> None:
        """Register an undo step for edits already applied to the model."""
        after = self.snapshot_midi_notes(str(clip_id))
        if before == after:
            return
        cmd = MidiNotesEditCommand(
            clip_id=str(clip_id),
            before=list(before or []),
            after=list(after or []),
            label=str(label or "Edit MIDI"),
            apply_snapshot=self._apply_midi_snapshot,
        )
        self.undo_stack.push(cmd, already_done=True)
        self.undo_changed.emit()
        # Ensure UI/services observe the final state.
        try:
            self._emit_updated()
        except Exception:
            pass
        try:
            self.midi_notes_committed.emit(str(clip_id))
        except Exception:
            pass

    def can_undo(self) -> bool:
        return self.undo_stack.can_undo()

    def can_redo(self) -> bool:
        return self.undo_stack.can_redo()

    def undo_label(self) -> str:
        return self.undo_stack.undo_label()

    def redo_label(self) -> str:
        return self.undo_stack.redo_label()

    def undo(self) -> None:
        if not self.undo_stack.can_undo():
            return
        self.undo_stack.undo()
        self.undo_changed.emit()

    def redo(self) -> None:
        if not self.undo_stack.can_redo():
            return
        self.undo_stack.redo()
        self.undo_changed.emit()


    # ---------- MIDI notes backing store (Piano Roll) ----------
    def get_midi_notes(self, clip_id: str):
        return list(self.ctx.project.midi_notes.get(clip_id, []))

    def set_midi_notes(self, clip_id: str, notes):
        self.ctx.project.midi_notes[clip_id] = list(notes)
        # Auto-extend to cover farthest note end
        try:
            nl = self.ctx.project.midi_notes.get(str(clip_id), []) or []
            if nl:
                end_b = max(float(getattr(n, 'start_beats', 0.0)) + float(getattr(n, 'length_beats', 0.0)) for n in nl)
                if self.extend_clip_if_needed(str(clip_id), float(end_b), snap_to_bar=True):
                    return
        except Exception:
            pass
        self._emit_updated()

    def add_midi_note(
        self,
        clip_id: str,
        note=None,
        *,
        pitch: int | None = None,
        start_beats: float | None = None,
        length_beats: float | None = None,
        velocity: int = 100,
    ):
        """Add a MIDI note to a clip.

        The UI calls this in two variants:
        - add_midi_note(clip_id, MidiNote(...))
        - add_midi_note(clip_id, pitch=..., start_beats=..., length_beats=...)
        """
        from pydaw.model.midi import MidiNote

        if note is None:
            if pitch is None or start_beats is None or length_beats is None:
                return
            note = MidiNote(
                pitch=int(pitch),
                start_beats=float(start_beats),
                length_beats=float(length_beats),
                velocity=int(velocity),
            )
        elif isinstance(note, dict):
            # Convenience: accept dict-like notes
            note = MidiNote(
                pitch=int(note.get("pitch", 60)),
                start_beats=float(note.get("start_beats", 0.0)),
                length_beats=float(note.get("length_beats", 1.0)),
                velocity=int(note.get("velocity", 100)),
            )

        notes = self.ctx.project.midi_notes.setdefault(clip_id, [])
        notes.append(note)
        try:
            end_b = float(getattr(note, 'start_beats', 0.0)) + float(getattr(note, 'length_beats', 0.0))
            if self.extend_clip_if_needed(str(clip_id), float(end_b), snap_to_bar=True):
                return
        except Exception:
            pass
        self._emit_updated()

    # Backwards-compat alias used by some UI code paths
    def add_note(
        self,
        clip_id: str,
        note=None,
        *,
        pitch: int | None = None,
        start_beats: float | None = None,
        length_beats: float | None = None,
        velocity: int = 100,
    ):
        """Alias for add_midi_note.

        Some older UI paths (Arranger ctrl-drag duplicate) call `add_note()`.
        Keep this wrapper to avoid hard crashes.
        """
        return self.add_midi_note(
            clip_id,
            note,
            pitch=pitch,
            start_beats=start_beats,
            length_beats=length_beats,
            velocity=velocity,
        )

    def delete_midi_note_at(self, clip_id: str, idx_or_pitch: int, start_beats: float | None = None):
        """Delete a MIDI note.

        Supported call variants (for UI compatibility):
        - delete_midi_note_at(clip_id, idx)
        - delete_midi_note_at(clip_id, pitch, start_beats)
        """
        notes = self.ctx.project.midi_notes.get(clip_id, [])
        if start_beats is None:
            # Treat 2nd arg as index
            idx = int(idx_or_pitch)
            if 0 <= idx < len(notes):
                notes.pop(idx)
                self._emit_updated()
            return

        # Treat 2nd/3rd arg as (pitch, start_beats)
        pitch = int(idx_or_pitch)
        sb = float(start_beats)
        for i, n in enumerate(list(notes)):
            try:
                if int(getattr(n, "pitch", -1)) == pitch and abs(float(getattr(n, "start_beats", -999)) - sb) < 1e-6:
                    notes.pop(i)
                    self._emit_updated()
                    return
            except Exception:
                continue

    def move_midi_note(self, clip_id: str, idx: int, new_start: float, new_pitch: int):
        notes = self.ctx.project.midi_notes.get(clip_id, [])
        if 0 <= idx < len(notes):
            n = notes[idx]
            try:
                n.start_beats = max(0.0, float(new_start))
                n.pitch = int(new_pitch)
            except Exception:
                pass
            try:
                end_b = float(getattr(n, 'start_beats', 0.0)) + float(getattr(n, 'length_beats', 0.0))
                if self.extend_clip_if_needed(str(clip_id), float(end_b), snap_to_bar=True):
                    return
            except Exception:
                pass
            self._emit_updated()

    def move_midi_notes_batch(self, clip_id: str, updates: list[tuple[int, float, int]]) -> None:
        """Move multiple MIDI notes and emit a single project_updated.

        This is used for multi-selection dragging in the PianoRoll to avoid
        excessive signal emissions while the mouse is moving.

        Args:
            clip_id: MIDI clip id
            updates: list of (idx, new_start_beats, new_pitch)
        """
        notes = self.ctx.project.midi_notes.get(clip_id, [])
        changed = False
        for idx, new_start, new_pitch in updates:
            try:
                i = int(idx)
            except Exception:
                continue
            if not (0 <= i < len(notes)):
                continue
            n = notes[i]
            try:
                n.start_beats = max(0.0, float(new_start))
                n.pitch = int(new_pitch)
                changed = True
            except Exception:
                continue
        if changed:
            try:
                max_end = 0.0
                for n in notes:
                    try:
                        max_end = max(max_end, float(getattr(n, 'start_beats', 0.0)) + float(getattr(n, 'length_beats', 0.0)))
                    except Exception:
                        continue
                if max_end > 0 and self.extend_clip_if_needed(str(clip_id), float(max_end), snap_to_bar=True):
                    return
            except Exception:
                pass
            self._emit_updated()

    def resize_midi_note_length(self, clip_id: str, idx: int, new_length: float):
        notes = self.ctx.project.midi_notes.get(clip_id, [])
        if 0 <= idx < len(notes):
            n = notes[idx]
            try:
                n.length_beats = max(0.25, float(new_length))
            except Exception:
                pass
            try:
                end_b = float(getattr(n, 'start_beats', 0.0)) + float(getattr(n, 'length_beats', 0.0))
                if self.extend_clip_if_needed(str(clip_id), float(end_b), snap_to_bar=True):
                    return
            except Exception:
                pass
            self._emit_updated()


    # ---------- MIDI clip length helpers ----------
    def _beats_per_bar(self) -> float:
        """Return the current bar length in beats based on the project's time signature.

        Beats are quarter-note beats (i.e. 4/4 => 4.0 beats per bar).
        """
        ts = str(getattr(self.ctx.project, 'time_signature', '4/4') or '4/4')
        m = re.match(r'^\s*(\d+)\s*/\s*(\d+)\s*$', ts)
        if not m:
            return 4.0
        try:
            num = float(m.group(1))
            den = float(m.group(2))
            if den <= 0:
                return 4.0
            # Whole note = 4 beats (quarter-note beats)
            return max(0.25, float(num) * (4.0 / float(den)))
        except Exception:
            return 4.0

    def _snap_division_beats(self) -> float:
        """Convert project snap division to beats.

        Examples:
            '1/16' -> 0.25 beats
            '1/8'  -> 0.5 beats
            '1/4'  -> 1.0 beat
            '1 Bar' -> beats_per_bar
            '1 Beat' -> 1.0
        """
        div = str(getattr(self.ctx.project, 'snap_division', '1/16') or '1/16')
        d = div.strip().lower()
        if 'bar' in d:
            return float(self._beats_per_bar())
        if 'beat' in d:
            return 1.0
        m = re.match(r'^\s*1\s*/\s*(\d+)\s*$', div)
        if m:
            try:
                den = float(m.group(1))
                if den > 0:
                    return max(1.0 / 64.0, 4.0 / den)
            except Exception:
                pass
        # fallback: 1/16
        return 0.25

    def extend_clip_if_needed(self, clip_id: str, end_beats: float, *, snap_to_bar: bool = True) -> bool:
        """Auto-extend a MIDI clip if note content exceeds its current end.

        This is the canonical implementation for Task 9.

        Args:
            clip_id: target clip id
            end_beats: clip-local end position of content (start+length)
            snap_to_bar: if True, extend to the next full bar.

        Returns:
            True if the clip length changed.
        """
        try:
            cid = str(clip_id)
            end_b = max(0.0, float(end_beats))
        except Exception:
            return False

        clip = next((c for c in self.ctx.project.clips if str(getattr(c, 'id', '')) == cid), None)
        if not clip:
            return False
        if str(getattr(clip, 'kind', '')) != 'midi':
            return False

        try:
            cur_len = float(getattr(clip, 'length_beats', 4.0) or 0.0)
        except Exception:
            cur_len = 4.0

        if end_b <= cur_len + 1e-9:
            return False

        if snap_to_bar:
            bar = float(self._beats_per_bar())
            bar = max(1.0 / 64.0, bar)
            new_len = math.ceil(end_b / bar) * bar
        else:
            g = float(self._snap_division_beats())
            g = max(1.0 / 64.0, g)
            new_len = math.ceil(end_b / g) * g

        try:
            clip.length_beats = float(max(cur_len, new_len))
        except Exception:
            return False

        self._emit_updated()
        return True

    def ensure_midi_clip_length(self, clip_id: str, end_beats: float) -> None:
        """Backward compatible alias for older UI code."""
        try:
            self.extend_clip_if_needed(str(clip_id), float(end_beats), snap_to_bar=True)
        except Exception:
            return

    # ---------------------------------------------------------------------
    # UI compatibility API (Undo/Redo) - required by main_window.py
    # ---------------------------------------------------------------------
    def can_undo(self) -> bool:
        """Prüfe ob Undo möglich ist."""
        try:
            return bool(self.undo_stack.can_undo())
        except Exception:
            return False

    def can_redo(self) -> bool:
        """Prüfe ob Redo möglich ist."""
        try:
            return bool(self.undo_stack.can_redo())
        except Exception:
            return False

    def undo_label(self) -> str:
        """Hole Undo-Label."""
        try:
            return self.undo_stack.undo_label() or "Undo"
        except Exception:
            return "Undo"

    def redo_label(self) -> str:
        """Hole Redo-Label."""
        try:
            return self.undo_stack.redo_label() or "Redo"
        except Exception:
            return "Redo"

    def undo(self):
        """Führe Undo aus."""
        try:
            self.undo_stack.undo()
            self._emit_updated()
        except Exception as e:
            print(f"Undo failed: {e}")

    def redo(self):
        """Führe Redo aus."""
        try:
            self.undo_stack.redo()
            self._emit_updated()
        except Exception as e:
            print(f"Redo failed: {e}")

    # ---------------------------------------------------------------------
    # Performance: MIDI pre-render (render MIDI->WAV caches in background)
    # ---------------------------------------------------------------------

    def cancel_prerender(self) -> None:
        """Request cancellation of a running pre-render job."""
        self._prerender_cancel = True

    def _collect_midi_prerender_jobs(self, clip_ids: list[str] | None = None, track_id: str | None = None):
        """Return a list of (clip, track) pairs for MIDI clips that can be rendered.

        Optional filters:
            clip_ids: only include these clip IDs
            track_id: only include clips belonging to this track
        """
        jobs = []
        try:
            proj = self.ctx.project
            tracks = list(getattr(proj, "tracks", []) or [])
            clips = list(getattr(proj, "clips", []) or [])
            track_by_id = {str(getattr(t, "id", "")): t for t in tracks}
            clip_id_set = set(str(x) for x in (clip_ids or []) if str(x)) if clip_ids else None
            track_filter = str(track_id) if track_id else None
            for c in clips:
                try:
                    if str(getattr(c, "kind", "")) != "midi":
                        continue
                    tid = str(getattr(c, "track_id", ""))
                    if track_filter and tid != track_filter:
                        continue
                    if clip_id_set is not None:
                        cid = str(getattr(c, "id", ""))
                        if not cid or cid not in clip_id_set:
                            continue
                    t = track_by_id.get(tid)
                    if t is None:
                        continue
                    sf2_path = getattr(t, "sf2_path", None)
                    if not sf2_path:
                        continue
                    jobs.append((c, t))
                except Exception:
                    continue
        except Exception:
            return []
        return jobs

    def midi_prerender_job_count(self, clip_ids: list[str] | None = None, track_id: str | None = None) -> int:
        try:
            return len(self._collect_midi_prerender_jobs(clip_ids=clip_ids, track_id=track_id))
        except Exception:
            return 0

    def prerender_midi_clips(self, *, reason: str = "manual", clip_ids: list[str] | None = None, track_id: str | None = None) -> None:
        """Render MIDI clips (via FluidSynth) in a worker thread.

        This warms the MIDI->WAV cache so starting playback does not stutter.
        """
        if self._prerender_running:
            return

        jobs = self._collect_midi_prerender_jobs(clip_ids=clip_ids, track_id=track_id)
        total = len(jobs)
        if total <= 0:
            # Nothing to do
            self.prerender_finished.emit(True)
            return

        # Snapshot the project so background rendering does not touch live model objects.
        try:
            proj_dict = self.ctx.project.to_dict()
        except Exception:
            proj_dict = None

        self._prerender_running = True
        self._prerender_cancel = False
        self.prerender_started.emit(int(total))
        self.prerender_progress.emit(0)
        self.prerender_label.emit(f"Pre-Render: {total} MIDI Clips…")

        def _work(progress_emit, label_emit, cancel_flag):
            # Local imports (keeps import time low for normal startup)
            from pydaw.model.project import Project
            from pydaw.core.settings import SettingsStore, SettingsKeys
            from pydaw.audio.midi_render import RenderKey, ensure_rendered_wav
            from pydaw.audio.arrangement_renderer import _apply_ties_to_notes, _midi_notes_content_hash

            # Rebuild a detached project instance from dict snapshot.
            project = Project.from_dict(proj_dict) if isinstance(proj_dict, dict) else self.ctx.project

            settings = SettingsStore()
            try:
                sr = int(settings.get_value(SettingsKeys.sample_rate, 48000) or 48000)
            except Exception:
                sr = 48000

            bpm = float(getattr(project, "bpm", 120.0) or 120.0)
            clips = list(getattr(project, "clips", []) or [])
            tracks = list(getattr(project, "tracks", []) or [])
            track_by_id = {str(getattr(t, "id", "")): t for t in tracks}
            midi_notes_map = getattr(project, "midi_notes", {}) or {}

            # Rebuild job list inside worker from detached project (apply same filters).
            worker_jobs = []
            clip_id_set = set(str(x) for x in (clip_ids or []) if str(x)) if clip_ids else None
            track_filter = str(track_id) if track_id else None
            for c in clips:
                if str(getattr(c, "kind", "")) != "midi":
                    continue
                tid = str(getattr(c, "track_id", ""))
                if track_filter and tid != track_filter:
                    continue
                if clip_id_set is not None:
                    cid = str(getattr(c, "id", ""))
                    if not cid or cid not in clip_id_set:
                        continue
                t = track_by_id.get(tid)
                if t is None:
                    continue
                if not getattr(t, "sf2_path", None):
                    continue
                worker_jobs.append((c, t))

            total_local = len(worker_jobs) or 0
            if total_local <= 0:
                return True

            for i, (clip, track) in enumerate(worker_jobs):
                if bool(cancel_flag.get("cancel", False)):
                    return False

                cid = str(getattr(clip, "id", ""))
                nm = getattr(clip, "name", "") or cid
                label_emit(f"{i+1}/{total_local}: {nm}")

                # Collect notes + apply ties
                notes_raw = list(midi_notes_map.get(cid, []) or [])
                try:
                    notes = list(_apply_ties_to_notes(project, cid, notes_raw) or [])
                except Exception:
                    notes = list(notes_raw or [])

                clip_len_beats = float(getattr(clip, "length_beats", 4.0) or 4.0)
                try:
                    if notes:
                        note_end = max(float(getattr(n, "start_beats", 0.0)) + float(getattr(n, "length_beats", 0.0)) for n in notes)
                        clip_len_beats = max(clip_len_beats, float(note_end))
                except Exception:
                    pass

                content_hash = _midi_notes_content_hash(notes)
                key = RenderKey(
                    clip_id=cid,
                    sf2_path=str(getattr(track, "sf2_path", "")),
                    sf2_bank=int(getattr(track, "sf2_bank", 0) or 0),
                    sf2_preset=int(getattr(track, "sf2_preset", 0) or 0),
                    bpm=float(bpm),
                    samplerate=int(sr),
                    clip_length_beats=float(clip_len_beats),
                    content_hash=str(content_hash),
                )

                # FIXED v0.0.19.7.13: Progress VORHER emiten, damit User sieht dass etwas passiert!
                pct = int(round(((i) / float(total_local)) * 100.0))  # i statt i+1!
                progress_emit(max(0, min(100, pct)))
                label_emit(f"Rendering Clip {i+1}/{total_local}...")
                
                # Main work: create/refresh the cached WAV if needed.
                try:
                    ensure_rendered_wav(
                        key=key,
                        midi_notes=notes,
                        clip_start_beats=float(getattr(clip, "start_beats", 0.0)),
                        clip_length_beats=float(clip_len_beats),
                    )
                except Exception as e:
                    # FIXED: Falls ensure_rendered_wav hängt, wenigstens einen Fehler zeigen!
                    label_emit(f"Fehler bei Clip {i+1}: {str(e)[:50]}")
                    # Weitermachen mit nächstem Clip
                    continue

            return True

        # Thread-safe cancellation flag passed to worker
        cancel_flag = {"cancel": False}

        def _on_cancel():
            cancel_flag["cancel"] = True

        # allow UI to cancel
        self._prerender_cancel = False

        def _progress(p):
            try:
                self.prerender_progress.emit(int(p))
            except Exception:
                pass

        def _label(t):
            try:
                self.prerender_label.emit(str(t))
            except Exception:
                pass

        worker = Worker(_work, _progress, _label, cancel_flag)

        # Handle cancellation requests from outside
        def _sync_cancel():
            if self._prerender_cancel:
                cancel_flag["cancel"] = True

        # Error/finish handlers
        def _done():
            self._prerender_running = False
            _sync_cancel()
            ok = not bool(cancel_flag.get("cancel", False))
            self.prerender_progress.emit(100 if ok else 0)
            self.prerender_label.emit("Pre-Render fertig" if ok else "Pre-Render abgebrochen")
            self.prerender_finished.emit(bool(ok))

        def _err(msg: str):
            self._prerender_running = False
            try:
                self.error.emit(f"Pre-Render Fehler: {msg}")
            except Exception:
                pass
            self.prerender_finished.emit(False)

        worker.signals.finished.connect(_done)
        worker.signals.error.connect(_err)

        self.threadpool.run(worker)
