# -*- coding: utf-8 -*-
"""Device Panel — per-track device chain (Pro-DAW-Style).

v0.0.20.130 — DevicePanel UX (Mini-Legende/Popover im Header, UI-only)\n- Neuer kompakter Header-Button „?" öffnet eine Mini-Legende/Popover direkt im DevicePanel (Batch-Icons + Bedienung).\n- Rein visuell / UI-only; keine Audio/DSP/DnD/Projektmodell-Änderungen.\n\nv0.0.20.128 — DevicePanel UX (Reset-Button als kompaktes Icon, UI-only)
- Reset-Button im DevicePanel-Header als kompaktes Icon (↺) statt Textbutton, gleiche Funktion/Tooltip.
- Nur aktiv bei DevicePanel/Kind-Fokus; keine Audio/DSP/DnD/Projektmodell-Änderungen.

v0.0.20.124 — DevicePanel UX (Collapsed Mini-Cards compact width polish, UI-only)
- Header-Batchbuttons erhalten bessere Entdeckbarkeit: Hinweiszeile + Hover-Hinweise + aktiver Fokusmodus (N/I/A/◎) markiert.
- Rein visuell/UI-only; keine Änderungen an Audio/DSP/DnD/Reorder/Projektmodell.

v0.0.20.122 — DevicePanel UX (Zone-Fokus + kompaktere Collapsed-Cards, UI-only)
- Neue Header-Aktionen „N / I / A“: nur NOTE-FX / nur INSTRUMENT / nur AUDIO-FX offen (UI-only Zonenfokus).
- Eingeklappte Device-Cards schrumpfen nun sichtbar auf Kopfzeilen-Breite statt die alte Card-Breite zu blockieren.
- UI-only: keine Änderungen an Audio/DSP/DnD/Reorder/Projektmodell.

v0.0.20.121 — DevicePanel UX (Focus Collapse / Nur Fokus offen, UI-only)
- Neue Header-Aktion „Fokus“: klappt alle Device-Cards ein und lässt nur die fokussierte Card offen.
- Falls keine FX-Card fokussiert ist, bleibt automatisch der Instrument-Anchor offen (sicherer Fallback).
- UI-only: keine Änderungen an Audio/DSP/DnD/Reorder/Projektmodell.

v0.0.20.120 — DevicePanel UX (Batch Actions compact icons + Collapse All)
- Header-Batchaktionen als kompakte Icon-Buttons mit Tooltips (ruhiger/platzsparender).
- Neue UI-only Aktion: „Alle einklappen“ für schnelle Übersicht in langen Chains.
- Keine Änderungen an Audio/DnD/Reorder/Projektmodell.

v0.0.20.119 — DevicePanel UX (Header-Line Polish: Elide + spacing)
- Device-Card header line unified (consistent icon spacing, title elide/tooltip on overflow).
- UI-only, no DnD/Reorder/Audio changes.

v0.0.20.118 — DevicePanel UX (Batch Collapse / Expand Actions)
- Header-Aktionen für schnelle Übersicht in langen Chains:
  * Alle ausklappen
  * Inaktive einklappen (deaktivierte Devices)
- UI-only, keine Änderungen an DnD/Reorder/Audio/Projektmodell.

v0.0.20.116 — DevicePanel UX (Collapsible Device-Cards / Kompaktmodus)
- Device-Cards (Note-FX / Instrument / Audio-FX) können pro Card ein-/ausgeklappt werden (UI-only).
- Zustand wird nur UI-seitig pro Card/Track gehalten (keine Projekt-/Audio-Änderung).
- DnD/Reorder/Insert-Indizes bleiben unverändert, da nur inneres Widget sichtbar/unsichtbar geschaltet wird.

v0.0.20.114 — DevicePanel UX (Subtile Zonen-Hintergründe)
- Optionale halbtransparente Hintergrundflächen für Note-FX / Instrument / Audio-FX (rein visuell).
- Umsetzung weiterhin als Overlay im chain_host (DnD-/Reorder-Indizes bleiben stabil).

v0.0.20.113 — DevicePanel UX (Visuelle Gruppierung Note-FX | Instrument | Audio-FX)
- Device-Chain zeigt jetzt Gruppen-Badges + Divider für Note-FX / Instrument / Audio-FX.
- Rein visuell (Overlay in chain_host), ohne DnD-/Reorder-Indizes zu verändern.

v0.0.20.109 — DevicePanel UX (Visible Scrollbar + Card Focus)
- Horizontal scrollbar styled for better visibility in dark theme.
- Clicking / changing FX keeps a visual card selection (highlight).
- Newly added/reordered FX is auto-scrolled into view (no more lost device in long chains).

v0.0.20.108 — DevicePanel UX (Horizontal Scroll + no card squeezing)
- Device-Chain uses real horizontal scrolling when many devices are loaded.
- Cards keep their preferred width (instrument/FX UIs stay readable instead of being squashed).
- Chain host size is synced to content width so scrollbar appears reliably.

v0.0.20.81 — Device-Drop "Insert at position"
- Dropping Note-FX / Audio-FX now inserts at the cursor position instead of always appending.
- A vertical drop indicator (cyan line) shows the insertion gap between device cards during drag.
- Indicator follows cursor in real-time, snapping between card boundaries (center-based detection).
- add_note_fx_to_track / add_audio_fx_to_track accept optional `insert_index` keyword argument.
- DragLeave cleans up the indicator. Drop captures the calculated position before hiding.

v0.0.20.80 — Instrument Power/Bypass
- Instrument anchor cards now have a working Power button (toggle on/off).
- When bypassed: no MIDI dispatch, no SF2 render, no pull-source audio.
- Track stays visible; FX chain stays intact.
- State persists in Track.instrument_enabled (saved with project).

v0.0.20.65 — Device Chain MVP + Hotfixes (Ableton/Bitwig UX)
- Browser entries are templates; adding creates a NEW instance in the chain.
- Chain order is strict:
    [Note-FX] -> [Instrument (Anchor, fixed)] -> [Audio-FX]
- Drag&Drop is bulletproof: a DropForwardHost + event-filter forwards drops from child widgets.
- Per Device-Card: Up/Down + Power (enable/disable) + Remove.
- AudioEngine.rebuild_fx_maps() is called after Audio-FX add/remove/reorder/enable/disable.
- All Qt slots are wrapped in try/except to avoid fatal Qt crashes (SIGABRT) on exceptions.

v0.0.20.64 Hotfix:
- Legacy playback: fix beats_to_samples signature mismatch (no more "takes 1 positional arg but 3 were given").
- SF2 instrument anchor: show a minimal SF2 UI instead of "Instrument failed to load".

v0.0.20.65 Hotfix:
- Pro Sampler / Pro Drum Machine: target sample-rate is derived from AudioEngine settings
  (no more silent output when the user runs 44.1k instead of 48k).
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional, Tuple

from PyQt6.QtCore import Qt, QObject, QEvent, QSize, QTimer
from PyQt6.QtGui import QFontMetrics, QKeySequence, QShortcut
from PyQt6.QtWidgets import (
    QWidget,
    QLabel,
    QVBoxLayout,
    QHBoxLayout,
    QScrollArea,
    QFrame,
    QSizePolicy,
    QToolButton,
    QSpinBox,
    QFileDialog,
    QLayout,
    QMenu,
)

from pydaw.model.project import new_id
from pydaw.plugins.registry import get_instruments

from .chrono_icons import icon as chrono_icon
from .fx_device_widgets import make_audio_fx_widget, make_note_fx_widget


_MIME = "application/x-pydaw-plugin"


def _parse_payload(event) -> Optional[dict]:  # noqa: ANN001
    try:
        md = event.mimeData()
        if md is None or not md.hasFormat(_MIME):
            return None
        raw = bytes(md.data(_MIME))
        payload = json.loads(raw.decode("utf-8", "ignore"))
        if not isinstance(payload, dict):
            return None
        return payload
    except Exception:
        return None


def _find_track(project_obj: Any, track_id: str):
    try:
        for t in getattr(project_obj, "tracks", []) or []:
            if str(getattr(t, "id", "")) == str(track_id):
                return t
    except Exception:
        pass
    return None


class _DropForwardFilter(QObject):
    """Forwards drag/drop events from arbitrary child widgets to the DevicePanel."""
    def __init__(self, panel: "DevicePanel"):
        super().__init__(panel)
        self._panel = panel
    def _zone_focus_target_kind(self) -> Optional[str]:
        mode = str(getattr(self, "_batch_action_mode", "") or "")
        if mode == "zone:note_fx":
            return "note_fx"
        if mode == "zone:instrument":
            return "instrument"
        if mode == "zone:audio_fx":
            return "audio_fx"
        return None

    def _zone_focus_is_active(self) -> bool:
        return self._zone_focus_target_kind() is not None

    def _batch_legend_lines(self) -> List[str]:
        mode = str(getattr(self, "_batch_action_mode", "") or "")
        mode_map = {
            "": "NORMAL",
            "focus_card": "FOKUS ◎",
            "zone:note_fx": "ZONE N",
            "zone:instrument": "ZONE I",
            "zone:audio_fx": "ZONE A",
            "collapsed_all": "ALLE ZU",
            "expanded_all": "ALLE AUF",
            "collapsed_inactive": "INAKTIV ZU",
        }
        return [
            f"Status: {mode_map.get(mode, 'NORMAL')} (UI-only)",
            "",
            "◪  Inaktive Devices einklappen",
            "▾▾  Alle Device-Cards einklappen",
            "▸▸  Alle Device-Cards ausklappen",
            "◎  Fokusansicht (nur fokussierte Card offen)",
            "N   Nur NOTE-FX offen",
            "I   Nur INSTRUMENT offen",
            "A   Nur AUDIO-FX offen",
            "↺   Reset / Normalansicht",
            "?   Diese Kurzhilfe",
            "",
            "Esc  Reset (wie ↺)",
            "Doppelklick auf Card = Ein/Ausklappen",
            "▾/▸ im Card-Header = Ein/Ausklappen",
            "Hinweis: N/I/A/◎/↺/? sind Header-Buttons, keine globalen Kürzel.",
        ]

    def _show_batch_legend_popup(self) -> None:
        """Kompakte UI-Legende direkt im DevicePanel-Header (Popover via QMenu)."""
        try:
            btn = getattr(self, "_btn_batch_help", None)
            if btn is None:
                return
            menu = QMenu(self)
            try:
                menu.setObjectName("devicePanelBatchLegendMenu")
                menu.setStyleSheet(
                    "QMenu#devicePanelBatchLegendMenu { background:#23262e; color:#dde4f5; border:1px solid rgba(255,255,255,0.10); }"
                    "QMenu#devicePanelBatchLegendMenu::item { padding: 4px 12px; }"
                    "QMenu#devicePanelBatchLegendMenu::item:selected { background: rgba(129,163,255,0.16); }"
                )
            except Exception:
                pass
            try:
                menu.addSection("DevicePanel • Kurzhilfe")
            except Exception:
                pass
            for line in self._batch_legend_lines():
                if line == "":
                    try:
                        menu.addSeparator()
                    except Exception:
                        pass
                    continue
                act = menu.addAction(line)
                try:
                    act.setEnabled(False)
                except Exception:
                    pass
            try:
                menu.addSeparator()
                a = menu.addAction("OK")
                a.setEnabled(True)
            except Exception:
                pass
            pos = btn.mapToGlobal(btn.rect().bottomLeft())
            menu.exec(pos)
        except Exception:
            pass

    def eventFilter(self, obj, event):  # noqa: N802, ANN001
        try:
            t = event.type()
            if t == QEvent.Type.DragLeave:
                try:
                    self._panel._hide_drop_indicator()
                except Exception:
                    pass
                return False
            if t in (QEvent.Type.DragEnter, QEvent.Type.DragMove, QEvent.Type.Drop):
                # Only handle our custom plugin mime.
                payload = _parse_payload(event)
                if payload and payload.get("kind") in ("instrument", "note_fx", "audio_fx"):
                    return self._panel._forward_drag_event(event)
        except Exception:
            return False
        return False


class _DropIndicator(QFrame):
    """Thin vertical line shown between device cards during drag to indicate insertion position."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(3)
        self.setMinimumHeight(40)
        self.setStyleSheet("background-color: #4fc3f7; border-radius: 1px;")
        self.hide()


class _DropForwardHost(QWidget):
    """Host widget inside the scroll area. Receives drops and forwards them."""
    def __init__(self, panel: "DevicePanel", parent=None):
        super().__init__(parent)
        self._panel = panel
        try:
            self.setAcceptDrops(True)
        except Exception:
            pass

    def dragEnterEvent(self, event):  # noqa: N802, ANN001
        self._panel._forward_drag_event(event)

    def dragMoveEvent(self, event):  # noqa: N802, ANN001
        self._panel._forward_drag_event(event)

    def dropEvent(self, event):  # noqa: N802, ANN001
        self._panel._forward_drag_event(event)

    def dragLeaveEvent(self, event):  # noqa: N802, ANN001
        try:
            self._panel._hide_drop_indicator()
        except Exception:
            pass


class _ToolBtn(QToolButton):
    def __init__(self, icon_name: str, tooltip: str, parent=None, *, checkable: bool = False):
        super().__init__(parent)
        self.setAutoRaise(True)
        self.setToolTip(tooltip)
        self.setIcon(chrono_icon(icon_name, 16))
        self.setIconSize(QSize(16, 16))
        self.setCheckable(bool(checkable))
        self.setFixedSize(QSize(22, 22))


_INTERNAL_MIME = "application/x-pydaw-fx-reorder"


class _DeviceCard(QFrame):
    """A single device card with controls + inner widget.
    v107: Reduced minWidth, drag handle for reorder, better styling.
    v116: Collapsible inner UI (Kompaktmodus, UI-only)."""
    def __init__(
        self,
        title: str,
        inner: QWidget,
        *,
        enabled: bool = True,
        can_up: bool = False,
        can_down: bool = False,
        on_up=None,
        on_down=None,
        on_power=None,
        on_remove=None,
        on_focus=None,
        on_toggle_collapse=None,
        collapsed: bool = False,
        collapsible: bool = True,
        device_id: str = "",
        fx_kind: str = "",
        parent=None,
    ):
        super().__init__(parent)
        self.device_id = device_id
        self.fx_kind = fx_kind  # "audio_fx" or "note_fx" for drag
        self._on_focus_cb = on_focus
        self._on_toggle_collapse_cb = on_toggle_collapse
        # separate from drag metadata: collapse state also exists for instrument anchor
        self._collapse_state_kind = str(fx_kind or "")
        self._collapse_state_device_id = str(device_id or "")
        self._ui_enabled = bool(enabled)
        self._ui_selected = False
        self._ui_collapsed = False
        self._expanded_min_width: Optional[int] = None
        self._expanded_max_width: Optional[int] = None
        self._collapsed_fixed_width: Optional[int] = None
        self.setObjectName("deviceCard")
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        try:
            _hint_w = int(inner.sizeHint().width()) if inner is not None else 0
        except Exception:
            _hint_w = 0
        _card_min_w = max(220, min(640, (_hint_w + 28) if _hint_w > 0 else 240))
        self.setMinimumWidth(_card_min_w)
        self.setMaximumWidth(900)
        try:
            self.setCursor(Qt.CursorShape.OpenHandCursor)
        except Exception:
            pass

        outer = QVBoxLayout(self)
        outer.setContentsMargins(6, 4, 6, 6)
        outer.setSpacing(4)

        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.setSpacing(2)

        self._btn_collapse = QToolButton(self)
        self._btn_collapse.setAutoRaise(True)
        self._btn_collapse.setToolTip("Expand/Collapse device UI")
        self._btn_collapse.setFixedSize(QSize(20, 20))
        self._btn_collapse.setStyleSheet("QToolButton{padding:0px; margin:0px;} ")
        try:
            self._btn_collapse.clicked.connect(self._toggle_collapsed)
        except Exception:
            pass
        self._btn_collapse.setVisible(bool(collapsible))
        self._btn_collapse.setEnabled(bool(collapsible))

        self._full_title = str(title or "")
        self.lab = QLabel(self._full_title)
        self.lab.setObjectName("deviceCardTitle")
        self.lab.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.lab.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.lab.setMinimumWidth(0)
        self.lab.setStyleSheet("font-size:11px; font-weight:bold; padding-right:2px;")

        btn_up = _ToolBtn("up", "Move Left  (Ctrl+←)", self)
        btn_dn = _ToolBtn("down", "Move Right (Ctrl+→)", self)
        btn_pw = _ToolBtn("power", "Enable/Disable", self, checkable=True)
        btn_rm = _ToolBtn("close", "Remove device", self)
        self._btn_up = btn_up
        self._btn_dn = btn_dn
        self._btn_pw = btn_pw
        self._btn_rm = btn_rm

        btn_up.setEnabled(bool(can_up) and callable(on_up))
        btn_dn.setEnabled(bool(can_down) and callable(on_down))
        btn_pw.setEnabled(callable(on_power))
        btn_rm.setEnabled(callable(on_remove))

        if callable(on_up):
            btn_up.clicked.connect(lambda _=False: on_up())
        if callable(on_down):
            btn_dn.clicked.connect(lambda _=False: on_down())
        if callable(on_power):
            btn_pw.clicked.connect(lambda _=False: on_power(btn_pw.isChecked()))
        if callable(on_remove):
            btn_rm.clicked.connect(lambda _=False: on_remove())

        btn_pw.setChecked(bool(enabled))

        top.addWidget(self._btn_collapse, 0)
        top.addWidget(self.lab, 1)
        top.addWidget(btn_up, 0)
        top.addWidget(btn_dn, 0)
        top.addWidget(btn_pw, 0)
        top.addWidget(btn_rm, 0)

        outer.addLayout(top)
        self.inner_widget = inner
        outer.addWidget(inner, 1)

        self.set_enabled_visual(bool(enabled))
        self.set_collapsed(bool(collapsed), notify=False)
        try:
            QTimer.singleShot(0, self._update_title_elide)
        except Exception:
            pass

    def _title_buttons(self):
        return [
            getattr(self, "_btn_collapse", None),
            getattr(self, "_btn_up", None),
            getattr(self, "_btn_dn", None),
            getattr(self, "_btn_pw", None),
            getattr(self, "_btn_rm", None),
        ]

    def _capture_expanded_width_bounds(self) -> None:
        try:
            if bool(getattr(self, "_ui_collapsed", False)):
                return
            self._expanded_min_width = max(0, int(QFrame.minimumWidth(self)))
            self._expanded_max_width = max(0, int(QFrame.maximumWidth(self)))
        except Exception:
            pass

    def _compute_collapsed_width(self) -> int:
        """Stable compact width for collapsed cards.

        Do not derive the value from the *current* header width. The title label expands
        with the card and can otherwise keep the collapsed card nearly full-width.
        """
        try:
            try:
                fm = QFontMetrics(self.lab.font()) if getattr(self, "lab", None) is not None else None
                title = str(getattr(self, "_full_title", "") or "")
                title_w = int(fm.horizontalAdvance(title)) if (fm is not None and title) else 0
            except Exception:
                title_w = 0
            # Hard cap for compact mode so long titles do not dominate width.
            title_w = max(48, min(108, int(title_w) + 8))

            btn_w = 0
            visible_btns = 0
            for btn in self._title_buttons():
                if btn is None or not btn.isVisible():
                    continue
                visible_btns += 1
                try:
                    btn_w += int(max(btn.minimumSizeHint().width(), btn.sizeHint().width(), btn.width(), 20))
                except Exception:
                    btn_w += 22

            try:
                outer_layout = self.layout()
                if outer_layout is not None:
                    m = outer_layout.contentsMargins()
                    outer_pad = int(m.left()) + int(m.right())
                else:
                    outer_pad = 0
            except Exception:
                outer_pad = 0

            spacing = 2 * max(0, visible_btns - 1)
            frame_pad = int(max(0, self.frameWidth()) * 2)
            w = int(frame_pad + outer_pad + btn_w + spacing + title_w + 10)
            return max(112, min(196, w))
        except Exception:
            return 140

    def setMinimumWidth(self, minw: int) -> None:  # noqa: N802
        try:
            self._expanded_min_width = int(minw)
        except Exception:
            pass
        if bool(getattr(self, "_ui_collapsed", False)):
            try:
                w = int(getattr(self, "_collapsed_fixed_width", 0) or self._compute_collapsed_width())
                self._collapsed_fixed_width = w
                return QFrame.setMinimumWidth(self, w)
            except Exception:
                pass
        return QFrame.setMinimumWidth(self, int(minw))

    def setMaximumWidth(self, maxw: int) -> None:  # noqa: N802
        try:
            self._expanded_max_width = int(maxw)
        except Exception:
            pass
        if bool(getattr(self, "_ui_collapsed", False)):
            try:
                w = int(getattr(self, "_collapsed_fixed_width", 0) or self._compute_collapsed_width())
                self._collapsed_fixed_width = w
                return QFrame.setMaximumWidth(self, w)
            except Exception:
                pass
        return QFrame.setMaximumWidth(self, int(maxw))

    def _update_title_elide(self) -> None:
        try:
            lab = getattr(self, "lab", None)
            if lab is None:
                return
            full = str(getattr(self, "_full_title", "") or "")
            if not full:
                lab.setText("")
                lab.setToolTip("")
                return
            avail = int(lab.width())
            if avail <= 8:
                avail = max(48, int(self.width()) - 120)
            fm = QFontMetrics(lab.font())
            txt = fm.elidedText(full, Qt.TextElideMode.ElideRight, max(48, avail))
            lab.setText(txt)
            lab.setToolTip(full if txt != full else "")
        except Exception:
            pass

    def _apply_card_style(self) -> None:
        try:
            selected = bool(getattr(self, "_ui_selected", False))
            enabled = bool(getattr(self, "_ui_enabled", True))
            if enabled:
                title_css = "font-size:11px; font-weight:bold; padding-right:2px;"
            else:
                title_css = "font-size:11px; font-weight:bold; color:#7a7a7a; padding-right:2px;"
            if selected and enabled:
                frame_css = (
                    "background-color: rgba(65, 205, 82, 0.06);"
                    "border:1px solid rgba(65, 205, 82, 0.75);"
                    "border-radius:4px;"
                )
                title_css += " color:#e8fbe8;"
            elif selected and not enabled:
                frame_css = (
                    "background-color: rgba(120,120,120,0.06);"
                    "border:1px solid rgba(150,150,150,0.45);"
                    "border-radius:4px;"
                )
            elif not enabled:
                frame_css = "background-color: rgba(255,255,255,0.02); border-radius:4px;"
            else:
                frame_css = ""
            self.lab.setStyleSheet(title_css)
            self.setStyleSheet(frame_css)
            self._update_title_elide()
        except Exception:
            pass

    def set_enabled_visual(self, enabled: bool) -> None:
        self._ui_enabled = bool(enabled)
        self._apply_card_style()

    def set_selected_visual(self, selected: bool) -> None:
        self._ui_selected = bool(selected)
        self._apply_card_style()

    def _update_collapse_button(self) -> None:
        try:
            if getattr(self, "_btn_collapse", None) is None or not self._btn_collapse.isVisible():
                return
            self._btn_collapse.setText("▸" if self._ui_collapsed else "▾")
            self._btn_collapse.setToolTip("Expand device UI" if self._ui_collapsed else "Collapse device UI")
        except Exception:
            pass

    def _toggle_collapsed(self) -> None:
        try:
            self.set_collapsed(not bool(getattr(self, "_ui_collapsed", False)), notify=True)
        except Exception:
            pass

    def set_collapsed(self, collapsed: bool, *, notify: bool = False) -> None:
        prev = bool(getattr(self, "_ui_collapsed", False))
        target = bool(collapsed)
        if (not prev) and target:
            try:
                self._capture_expanded_width_bounds()
            except Exception:
                pass
        self._ui_collapsed = target
        try:
            if getattr(self, "inner_widget", None) is not None:
                self.inner_widget.setVisible(not self._ui_collapsed)
        except Exception:
            pass
        try:
            if self._ui_collapsed:
                w = int(self._compute_collapsed_width())
                self._collapsed_fixed_width = w
                QFrame.setMinimumWidth(self, w)
                QFrame.setMaximumWidth(self, w)
                self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
            else:
                mn = int(getattr(self, "_expanded_min_width", 0) or 0)
                mx = int(getattr(self, "_expanded_max_width", 900) or 900)
                QFrame.setMinimumWidth(self, mn)
                QFrame.setMaximumWidth(self, mx)
                self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        except Exception:
            pass
        try:
            self._update_collapse_button()
        except Exception:
            pass
        try:
            if bool(self._ui_collapsed):
                self.lab.setMaximumWidth(112)
                self.lab.setMinimumWidth(28)
                self.lab.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
            else:
                self.lab.setMaximumWidth(16777215)
                self.lab.setMinimumWidth(0)
                self.lab.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        except Exception:
            pass
        try:
            self._update_title_elide()
        except Exception:
            pass
        try:
            self.updateGeometry()
            if self.parentWidget() is not None:
                self.parentWidget().updateGeometry()
        except Exception:
            pass
        if notify:
            try:
                cb = getattr(self, "_on_toggle_collapse_cb", None)
                if callable(cb):
                    cb(bool(self._ui_collapsed))
            except Exception:
                pass

    def is_collapsed(self) -> bool:
        return bool(getattr(self, "_ui_collapsed", False))

    def resizeEvent(self, event):
        try:
            super().resizeEvent(event)
        finally:
            try:
                self._update_title_elide()
            except Exception:
                pass

    # ---- Drag support for reordering within chain ----
    def mousePressEvent(self, event):
        try:
            if event.button() == Qt.MouseButton.LeftButton:
                try:
                    if callable(getattr(self, "_on_focus_cb", None)):
                        self._on_focus_cb()
                except Exception:
                    pass
                self._drag_start_pos = event.pos()
        except Exception:
            pass
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event):
        try:
            if event.button() == Qt.MouseButton.LeftButton and getattr(self, "_btn_collapse", None) is not None and self._btn_collapse.isVisible():
                self._toggle_collapsed()
                event.accept()
                return
        except Exception:
            pass
        super().mouseDoubleClickEvent(event)

    def mouseMoveEvent(self, event):
        try:
            if not (event.buttons() & Qt.MouseButton.LeftButton):
                return super().mouseMoveEvent(event)
            if not hasattr(self, '_drag_start_pos'):
                return super().mouseMoveEvent(event)
            if (event.pos() - self._drag_start_pos).manhattanLength() < 20:
                return super().mouseMoveEvent(event)
            if not self.device_id or not self.fx_kind:
                return super().mouseMoveEvent(event)
            # Start internal drag for reorder
            from PyQt6.QtCore import QMimeData
            from PyQt6.QtGui import QDrag
            drag = QDrag(self)
            mime = QMimeData()
            payload = json.dumps({"kind": self.fx_kind, "device_id": self.device_id, "reorder": True})
            mime.setData(_INTERNAL_MIME, payload.encode("utf-8"))
            # Also set the standard plugin mime so the drop filter accepts it
            mime.setData(_MIME, payload.encode("utf-8"))
            drag.setMimeData(mime)
            drag.exec(Qt.DropAction.MoveAction)
        except Exception:
            pass


class _Sf2InstrumentWidget(QWidget):
    """Minimal SF2 anchor UI.

    Wichtig: SF2 ist (noch) kein Qt-Instrument-Plugin in der Registry,
    aber wird von der Engine über Offline-Render (FluidSynth) unterstützt.
    Track.plugin_type == "sf2" ist daher ein valider Instrument-Anker.
    """

    def __init__(self, panel: "DevicePanel", track_id: str, *, sf2_path: str = "", bank: int = 0, preset: int = 0, parent=None):
        super().__init__(parent)
        self._panel = panel
        self._track_id = str(track_id or "")

        self._path = str(sf2_path or "")
        self._apply_pending = False  # avoid UI rebuild during spinbox events

        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(8)

        row = QHBoxLayout()
        row.setSpacing(6)

        self._path_lab = QLabel()
        self._path_lab.setWordWrap(True)
        self._path_lab.setStyleSheet("color:#bdbdbd;")

        self._btn_load = _ToolBtn("plus", "Load SF2 (SoundFont)", self)
        self._btn_load.clicked.connect(self._on_load)

        row.addWidget(self._path_lab, 1)
        row.addWidget(self._btn_load, 0)
        root.addLayout(row)

        row2 = QHBoxLayout()
        row2.setSpacing(10)

        lab_bank = QLabel("Bank")
        lab_bank.setStyleSheet("color:#9a9a9a;")
        self._bank = QSpinBox()
        self._bank.setRange(0, 127)
        self._bank.setValue(int(bank) if bank is not None else 0)
        self._bank.valueChanged.connect(self._on_bank_preset)

        lab_preset = QLabel("Preset")
        lab_preset.setStyleSheet("color:#9a9a9a;")
        self._preset = QSpinBox()
        self._preset.setRange(0, 127)
        self._preset.setValue(int(preset) if preset is not None else 0)
        self._preset.valueChanged.connect(self._on_bank_preset)

        row2.addWidget(lab_bank)
        row2.addWidget(self._bank)
        row2.addSpacing(8)
        row2.addWidget(lab_preset)
        row2.addWidget(self._preset)
        row2.addStretch(1)

        root.addLayout(row2)

        hint = QLabel("SF2 wird beim Playback gerendert. Tipp: Wenn du gerade abspielst, stop/start erneut für sofortigen Wechsel.")
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#7f7f7f; font-size:11px;")
        root.addWidget(hint)

        self._refresh_label()

    def _refresh_label(self) -> None:
        try:
            if self._path:
                name = os.path.basename(self._path)
                self._path_lab.setText(f"SF2: {name}")
            else:
                self._path_lab.setText("No SF2 loaded. Click + to load a SoundFont.")
        except Exception:
            pass

    def _on_load(self) -> None:
        try:
            path, _ = QFileDialog.getOpenFileName(
                self,
                "SoundFont (SF2) auswählen",
                "",
                "SoundFont (*.sf2);;Alle Dateien (*)",
            )
            if not path:
                return
            self._path = str(path)
            self._schedule_apply_sf2()
        except Exception:
            return

    def _schedule_apply_sf2(self) -> None:
        """Defer SF2 apply to next event-loop tick.

        Hintergrund: set_track_soundfont() emittiert project_updated, was das DevicePanel
        neu rendert. Wenn das während eines QSpinBox-Mouse-Events passiert (Bank/Preset),
        kann Qt den SpinBox-Widget-Zustand invalidieren -> SIGSEGV in QAbstractSpinBox::stepBy.
        """
        try:
            if getattr(self, "_apply_pending", False):
                return
            self._apply_pending = True
            QTimer.singleShot(0, self._apply_sf2_deferred)
        except Exception:
            try:
                self._apply_pending = False
            except Exception:
                pass
            try:
                self._apply_sf2()
            except Exception:
                pass

    def _apply_sf2_deferred(self) -> None:
        try:
            self._apply_pending = False
            # if no file selected, just refresh label (do not touch project)
            if not getattr(self, "_path", ""):
                try:
                    self._refresh_label()
                except Exception:
                    pass
                return
            self._apply_sf2()
        except RuntimeError:
            # Qt wrapper deleted (track switched / panel rerendered)
            return
        except Exception:
            try:
                self._apply_pending = False
            except Exception:
                pass
            return

    def _on_bank_preset(self, _=None) -> None:
        # allow setting bank/preset before picking a file
        if not self._path:
            try:
                self._refresh_label()
            except Exception:
                pass
            return
        self._schedule_apply_sf2()

    def _apply_sf2(self) -> None:
        """Write SF2 settings into track model + emit updates."""
        if not self._track_id:
            return
        try:
            proj, project_obj, trk = self._panel._get_project_track(self._track_id)
            if trk is None:
                return

            # Ensure routing mode
            try:
                trk.plugin_type = "sf2"
            except Exception:
                pass

            try:
                trk.sf2_path = str(self._path)
                trk.sf2_bank = int(self._bank.value())
                trk.sf2_preset = int(self._preset.value())
            except Exception:
                pass

            # Prefer service API (emits status/project_updated)
            try:
                if proj is not None and hasattr(proj, "set_track_soundfont"):
                    proj.set_track_soundfont(self._track_id, str(self._path), bank=int(self._bank.value()), preset=int(self._preset.value()))
            except Exception:
                pass

            self._refresh_label()
            self._panel._restart_if_playing()
        except Exception:
            return


class DevicePanel(QWidget):
    """Bottom device view — per-track strict device chain."""

    def __init__(self, services=None, parent=None):
        super().__init__(parent)
        self.setObjectName("devicePanel")
        self._services = services
        self._current_track: str = ""
        self._selected_fx_kind: str = ""
        self._selected_fx_device_id: str = ""
        self._pending_focus_kind: str = ""
        self._pending_focus_device_id: str = ""
        self._rendered_fx_cards: Dict[Tuple[str, str], QWidget] = {}
        self._zone_badges: Dict[str, QLabel] = {}
        self._zone_dividers: Dict[str, QFrame] = {}
        self._zone_backdrops: Dict[str, QFrame] = {}
        self._zone_layout_meta: Dict[str, Any] = {}
        self._card_collapse_state: Dict[str, bool] = {}
        self._batch_action_mode: str = ""
        self._batch_hover_hints: Dict[QObject, str] = {}


        # Keep instrument widgets alive per track (state preservation).
        self._track_instruments: Dict[str, dict] = {}  # track_id -> {plugin_id, widget}

        self._drop_filter = _DropForwardFilter(self)

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 8, 12, 8)
        root.setSpacing(6)

        title = QLabel("Device")
        title.setObjectName("devicePanelTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        self._btn_collapse_inactive = QToolButton(self)
        self._btn_collapse_inactive.setText("◪")
        self._btn_collapse_inactive.setToolTip("Inaktive einklappen (deaktivierte Devices, UI-only)")
        self._btn_collapse_inactive.setAutoRaise(True)
        self._btn_collapse_inactive.setFixedSize(QSize(24, 24))
        try:
            self._btn_collapse_inactive.clicked.connect(self._collapse_inactive_device_cards)
        except Exception:
            pass

        self._btn_collapse_all = QToolButton(self)
        self._btn_collapse_all.setText("▾▾")
        self._btn_collapse_all.setToolTip("Alle Device-Cards einklappen (UI-only)")
        self._btn_collapse_all.setAutoRaise(True)
        self._btn_collapse_all.setFixedSize(QSize(28, 24))
        try:
            self._btn_collapse_all.clicked.connect(self._collapse_all_device_cards)
        except Exception:
            pass

        self._btn_expand_all = QToolButton(self)
        self._btn_expand_all.setText("▸▸")
        self._btn_expand_all.setToolTip("Alle Device-Cards ausklappen (UI-only)")
        self._btn_expand_all.setAutoRaise(True)
        self._btn_expand_all.setFixedSize(QSize(28, 24))
        try:
            self._btn_expand_all.clicked.connect(self._expand_all_device_cards)
        except Exception:
            pass

        self._btn_focus_only = QToolButton(self)
        self._btn_focus_only.setText("◎")
        self._btn_focus_only.setToolTip("Fokusansicht: nur fokussierte Card offen lassen (Fallback: Instrument)")
        self._btn_focus_only.setAutoRaise(True)
        self._btn_focus_only.setFixedSize(QSize(24, 24))
        self._btn_focus_only.setCheckable(True)
        try:
            self._btn_focus_only.clicked.connect(self._collapse_focus_device_cards)
        except Exception:
            pass

        self._btn_focus_note_zone = QToolButton(self)
        self._btn_focus_note_zone.setText("N")
        self._btn_focus_note_zone.setToolTip("Nur NOTE-FX offen lassen (UI-only Zonenfokus)")
        self._btn_focus_note_zone.setAutoRaise(True)
        self._btn_focus_note_zone.setFixedSize(QSize(22, 24))
        self._btn_focus_note_zone.setCheckable(True)
        try:
            self._btn_focus_note_zone.clicked.connect(lambda _=False: self._focus_only_zone_device_cards("note_fx"))
        except Exception:
            pass

        self._btn_focus_instrument_zone = QToolButton(self)
        self._btn_focus_instrument_zone.setText("I")
        self._btn_focus_instrument_zone.setToolTip("Nur INSTRUMENT offen lassen (UI-only Zonenfokus)")
        self._btn_focus_instrument_zone.setAutoRaise(True)
        self._btn_focus_instrument_zone.setFixedSize(QSize(22, 24))
        self._btn_focus_instrument_zone.setCheckable(True)
        try:
            self._btn_focus_instrument_zone.clicked.connect(lambda _=False: self._focus_only_zone_device_cards("instrument"))
        except Exception:
            pass

        self._btn_focus_audio_zone = QToolButton(self)
        self._btn_focus_audio_zone.setText("A")
        self._btn_focus_audio_zone.setToolTip("Nur AUDIO-FX offen lassen (UI-only Zonenfokus)")
        self._btn_focus_audio_zone.setAutoRaise(True)
        self._btn_focus_audio_zone.setFixedSize(QSize(22, 24))
        self._btn_focus_audio_zone.setCheckable(True)
        try:
            self._btn_focus_audio_zone.clicked.connect(lambda _=False: self._focus_only_zone_device_cards("audio_fx"))
        except Exception:
            pass

        self._btn_reset_view = QToolButton(self)
        self._btn_reset_view.setObjectName("deviceResetViewButton")
        self._btn_reset_view.setText("↺")
        self._btn_reset_view.setToolTip("↺ Reset: Alle Zonen normal / alle Device-Cards ausklappen (UI-only, Esc)")
        self._btn_reset_view.setAutoRaise(True)
        self._btn_reset_view.setFixedSize(QSize(24, 24))
        try:
            self._btn_reset_view.clicked.connect(self._reset_normal_device_view)
        except Exception:
            pass

        self._btn_batch_help = QToolButton(self)
        self._btn_batch_help.setObjectName("deviceBatchHelpButton")
        self._btn_batch_help.setText("?")
        self._btn_batch_help.setToolTip("Kurzhilfe: DevicePanel-Icons / Fokus / Collapse (UI-only)")
        self._btn_batch_help.setAutoRaise(True)
        self._btn_batch_help.setFixedSize(QSize(22, 24))
        try:
            self._btn_batch_help.clicked.connect(self._show_batch_legend_popup)
        except Exception:
            pass


        for _btn in (
            self._btn_collapse_inactive,
            self._btn_collapse_all,
            self._btn_expand_all,
            self._btn_focus_only,
            self._btn_focus_note_zone,
            self._btn_focus_instrument_zone,
            self._btn_focus_audio_zone,
            self._btn_reset_view,
            self._btn_batch_help,
        ):
            try:
                _btn.setCursor(Qt.CursorShape.PointingHandCursor)
                _btn.setStyleSheet(
                    "QToolButton { color:#d7d7de; border:1px solid rgba(255,255,255,0.08); "
                    "border-radius:6px; background: rgba(255,255,255,0.02); padding:0px; }"
                    "QToolButton:hover { background: rgba(255,255,255,0.06); border-color: rgba(255,255,255,0.16); }"
                    "QToolButton:checked { color:#f2f5ff; background: rgba(129,163,255,0.14); border-color: rgba(129,163,255,0.42); }"
                    "QToolButton:disabled { color:#777; border-color: rgba(255,255,255,0.04); background: rgba(255,255,255,0.01); }"
                    "QToolButton#deviceResetViewButton { color:#dfe8ff; border-color: rgba(129,163,255,0.22); }"
                    "QToolButton#deviceResetViewButton:hover { background: rgba(129,163,255,0.08); border-color: rgba(129,163,255,0.34); }"
                    "QToolButton#deviceBatchHelpButton { color:#d7deef; border-color: rgba(255,255,255,0.14); }"
                    "QToolButton#deviceBatchHelpButton:hover { background: rgba(255,255,255,0.07); border-color: rgba(255,255,255,0.22); }"
                )
            except Exception:
                pass

        self._batch_mode_badge = QLabel("NORMAL", self)
        try:
            self._batch_mode_badge.setObjectName("deviceBatchModeBadge")
            self._batch_mode_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self._batch_mode_badge.setMinimumWidth(62)
            self._batch_mode_badge.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        except Exception:
            pass

        self._batch_hint_label = QLabel(self._default_batch_hint_text(), self)
        try:
            self._batch_hint_label.setObjectName("deviceBatchHintLabel")
            self._batch_hint_label.setMinimumWidth(0)
            self._batch_hint_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
            self._batch_hint_label.setStyleSheet(
                "QLabel#deviceBatchHintLabel { color:#8c90a6; font-size: 11px; padding-left: 4px; }"
            )
            self._batch_hint_label.setToolTip(
                "Batch-Hinweis: Hover über Header-Buttons zeigt die Aktion. N/I/A = Zonenfokus (UI-only), ↺/Esc = Reset, ? = Kurzhilfe-Popup."
            )
        except Exception:
            pass

        self._batch_hover_hints = {
            self._btn_collapse_inactive: "◪ Inaktive einklappen (nur deaktivierte Devices, UI-only)",
            self._btn_collapse_all: "▾▾ Alle Device-Cards einklappen (UI-only)",
            self._btn_expand_all: "▸▸ Alle Device-Cards ausklappen (UI-only)",
            self._btn_focus_only: "◎ Fokusansicht: nur fokussierte Card offen (Fallback: Instrument)",
            self._btn_focus_note_zone: "N = Nur NOTE-FX offen (Zonenfokus, UI-only)",
            self._btn_focus_instrument_zone: "I = Nur INSTRUMENT offen (Zonenfokus, UI-only)",
            self._btn_focus_audio_zone: "A = Nur AUDIO-FX offen (Zonenfokus, UI-only)",
            self._btn_reset_view: "↺ Reset = Alle Zonen normal / alle Cards offen (UI-only, Esc)",
            self._btn_batch_help: "? Kurzhilfe: Legende/Bedienung für Header-Icons (UI-only)",
        }
        try:
            for _btn in self._batch_hover_hints.keys():
                _btn.installEventFilter(self)
        except Exception:
            pass

        header = QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(6)
        header.addWidget(title, 0)
        header.addWidget(self._batch_mode_badge, 0)
        header.addWidget(self._batch_hint_label, 1)
        header.addWidget(self._btn_collapse_inactive, 0)
        header.addWidget(self._btn_collapse_all, 0)
        header.addWidget(self._btn_expand_all, 0)
        header.addWidget(self._btn_focus_only, 0)
        header.addSpacing(4)
        header.addWidget(self._btn_focus_note_zone, 0)
        header.addWidget(self._btn_focus_instrument_zone, 0)
        header.addWidget(self._btn_focus_audio_zone, 0)
        header.addSpacing(4)
        header.addWidget(self._btn_reset_view, 0)
        header.addWidget(self._btn_batch_help, 0)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFrameShadow(QFrame.Shadow.Sunken)

        self.scroll = QScrollArea()
        # v108 UX: chain soll horizontal scrollen statt alle Device-Cards zusammenzuquetschen.
        # WidgetResizable=False + explizite Host-Größe → echte Scrollbar bei vielen Devices.
        self.scroll.setWidgetResizable(False)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        try:
            self.scroll.horizontalScrollBar().setSingleStep(48)
            self.scroll.horizontalScrollBar().setPageStep(240)
        except Exception:
            pass
        # v109 UX: Dark-Theme Scrollbar sichtbar machen (war oft optisch kaum erkennbar).
        try:
            self.scroll.setStyleSheet(
                """
                QScrollBar:horizontal {
                    height: 14px;
                    margin: 0px 2px 0px 2px;
                    background: rgba(255,255,255,0.03);
                    border: 1px solid rgba(255,255,255,0.06);
                    border-radius: 6px;
                }
                QScrollBar::handle:horizontal {
                    min-width: 28px;
                    background: rgba(120,120,140,0.85);
                    border: 1px solid rgba(255,255,255,0.12);
                    border-radius: 6px;
                }
                QScrollBar::handle:horizontal:hover {
                    background: rgba(150,150,180,0.95);
                }
                QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
                    width: 0px;
                    height: 0px;
                    background: transparent;
                    border: none;
                }
                QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
                    background: transparent;
                }
                """
            )
        except Exception:
            pass

        self.chain_host = _DropForwardHost(self)
        self.chain_host.setObjectName("deviceChainHost")
        self.chain_host.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        self.chain = QHBoxLayout(self.chain_host)
        # v113: kleine Kopfzeile für Gruppen-Badges (Note-FX | Instrument | Audio-FX)
        # ohne zusätzliche Layout-Widgets in der Chain (DnD-Indizes bleiben stabil).
        self.chain.setContentsMargins(0, 22, 0, 0)
        self.chain.setSpacing(8)
        try:
            self.chain.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
        except Exception:
            pass

        self.empty_label = QLabel("Track auswählen.\\nDann Devices aus dem Browser hierher ziehen oder doppelklicken.")
        self.empty_label.setObjectName("devicePanelEmpty")
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.empty_label.setStyleSheet("color:#9a9a9a;")
        self.chain.addWidget(self.empty_label)
        self.chain.addStretch(1)

        self.scroll.setWidget(self.chain_host)
        try:
            self.chain_host.setMinimumSize(1, 1)
        except Exception:
            pass

        # v113: visuelle Gruppierungs-Overlays (absolut positioniert, nicht im Layout).
        try:
            self._ensure_zone_visuals()
            self._hide_zone_visuals()
        except Exception:
            pass

        # Drop indicator for insert-at-position
        self._drop_indicator = _DropIndicator(self.chain_host)
        self._drop_insert_kind: str = ""      # "note_fx" | "audio_fx"
        self._drop_insert_index: int = -1     # -1 = append

        root.addLayout(header)
        root.addWidget(sep)
        root.addWidget(self.scroll, 1)

        try:
            self._shortcut_reset_escape = QShortcut(QKeySequence("Esc"), self)
            self._shortcut_reset_escape.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
            self._shortcut_reset_escape.setAutoRepeat(False)
            self._shortcut_reset_escape.activated.connect(self._handle_escape_reset_shortcut)
        except Exception:
            self._shortcut_reset_escape = None

        try:
            self.setAcceptDrops(True)
        except Exception:
            pass

        # project updated -> refresh (SAFE)
        try:
            proj = getattr(self._services, "project", None) if self._services else None
            if proj is not None and hasattr(proj, "project_updated"):
                proj.project_updated.connect(self._safe_render_current_track)
        except Exception:
            pass

        try:
            self._set_batch_action_mode("")
            self._update_batch_hint_visibility()
        except Exception:
            pass

    def _update_batch_action_button_state(self) -> None:
        try:
            cards = self._iter_device_cards()
            has_cards = bool(cards)
            has_inactive = any(not bool(getattr(c, "_ui_enabled", True)) for c in cards)
            has_collapsed = any(bool(c.is_collapsed()) for c in cards)
            has_expanded = any(not bool(c.is_collapsed()) for c in cards)
            if getattr(self, "_btn_collapse_inactive", None) is not None:
                self._btn_collapse_inactive.setEnabled(bool(has_cards and has_inactive))
            if getattr(self, "_btn_collapse_all", None) is not None:
                self._btn_collapse_all.setEnabled(bool(has_cards and has_expanded))
            if getattr(self, "_btn_expand_all", None) is not None:
                self._btn_expand_all.setEnabled(bool(has_cards and has_collapsed))
            if getattr(self, "_btn_focus_only", None) is not None:
                self._btn_focus_only.setEnabled(bool(has_cards and len(cards) > 1))
            zone_counts = {"note_fx": 0, "instrument": 0, "audio_fx": 0}
            for c in cards:
                k = str(getattr(c, "_collapse_state_kind", "") or "")
                if k in zone_counts:
                    zone_counts[k] += 1
            if getattr(self, "_btn_focus_note_zone", None) is not None:
                self._btn_focus_note_zone.setEnabled(bool(zone_counts.get("note_fx", 0)))
            if getattr(self, "_btn_focus_instrument_zone", None) is not None:
                self._btn_focus_instrument_zone.setEnabled(bool(zone_counts.get("instrument", 0)))
            if getattr(self, "_btn_focus_audio_zone", None) is not None:
                self._btn_focus_audio_zone.setEnabled(bool(zone_counts.get("audio_fx", 0)))

            mode = str(getattr(self, "_batch_action_mode", "") or "")
            has_focus_mode = bool(mode == "focus_card" or mode.startswith("zone:"))
            if getattr(self, "_btn_reset_view", None) is not None:
                self._btn_reset_view.setEnabled(bool(has_cards and (has_collapsed or has_focus_mode)))
            if not has_cards:
                self._set_batch_action_mode("")
            elif mode == "focus_card" and not bool(has_cards and len(cards) > 1):
                self._set_batch_action_mode("")
            elif mode == "zone:note_fx" and not bool(zone_counts.get("note_fx", 0)):
                self._set_batch_action_mode("")
            elif mode == "zone:instrument" and not bool(zone_counts.get("instrument", 0)):
                self._set_batch_action_mode("")
            elif mode == "zone:audio_fx" and not bool(zone_counts.get("audio_fx", 0)):
                self._set_batch_action_mode("")
        except Exception:
            pass

    def _default_batch_hint_text(self) -> str:
        return "Batch: ◪ inaktiv | ▾▾ zu | ▸▸ auf | ◎ Fokus | N/I/A Zonen | ↺/Esc Reset | ? Hilfe"

    def _restore_batch_hint_text(self) -> None:
        try:
            mode = str(getattr(self, "_batch_action_mode", "") or "")
            if mode == "focus_card":
                txt = "Ansicht: ◎ Fokus-Card offen (UI-only)"
            elif mode == "zone:note_fx":
                txt = "Ansicht: N / nur NOTE-FX offen (UI-only)"
            elif mode == "zone:instrument":
                txt = "Ansicht: I / nur INSTRUMENT offen (UI-only)"
            elif mode == "zone:audio_fx":
                txt = "Ansicht: A / nur AUDIO-FX offen (UI-only)"
            elif mode == "collapsed_all":
                txt = "Ansicht: alle Device-Cards eingeklappt (UI-only)"
            elif mode == "expanded_all":
                txt = "Ansicht: alle Device-Cards ausgeklappt (UI-only)"
            elif mode == "collapsed_inactive":
                txt = "Ansicht: inaktive Devices eingeklappt (UI-only)"
            else:
                txt = self._default_batch_hint_text()
            if getattr(self, "_batch_hint_label", None) is not None:
                self._batch_hint_label.setText(txt)
        except Exception:
            pass

    def _update_batch_mode_badge(self) -> None:
        try:
            lbl = getattr(self, "_batch_mode_badge", None)
            if lbl is None:
                return
            mode = str(getattr(self, "_batch_action_mode", "") or "")
            text = "NORMAL"
            style = (
                "QLabel#deviceBatchModeBadge { color:#c9cedf; background: rgba(255,255,255,0.03); "
                "border:1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 2px 8px; font-size: 10px; font-weight: 600; }"
            )
            if mode == "focus_card":
                text = "FOKUS ◎"
                style = (
                    "QLabel#deviceBatchModeBadge { color:#eef3ff; background: rgba(129,163,255,0.16); "
                    "border:1px solid rgba(129,163,255,0.45); border-radius: 8px; padding: 2px 8px; font-size: 10px; font-weight: 700; }"
                )
            elif mode == "zone:note_fx":
                text = "ZONE N"
                style = (
                    "QLabel#deviceBatchModeBadge { color:#dff3ff; background: rgba(84,184,255,0.13); "
                    "border:1px solid rgba(84,184,255,0.35); border-radius: 8px; padding: 2px 8px; font-size: 10px; font-weight: 700; }"
                )
            elif mode == "zone:instrument":
                text = "ZONE I"
                style = (
                    "QLabel#deviceBatchModeBadge { color:#ebf0ff; background: rgba(117,132,255,0.14); "
                    "border:1px solid rgba(117,132,255,0.34); border-radius: 8px; padding: 2px 8px; font-size: 10px; font-weight: 700; }"
                )
            elif mode == "zone:audio_fx":
                text = "ZONE A"
                style = (
                    "QLabel#deviceBatchModeBadge { color:#e5ffe9; background: rgba(70,200,110,0.12); "
                    "border:1px solid rgba(70,200,110,0.34); border-radius: 8px; padding: 2px 8px; font-size: 10px; font-weight: 700; }"
                )
            elif mode == "collapsed_all":
                text = "ALLE ZU"
            elif mode == "expanded_all":
                text = "ALLE AUF"
            elif mode == "collapsed_inactive":
                text = "INAKTIV ZU"
            lbl.setText(text)
            lbl.setToolTip(f"Aktuelle Device-Ansicht: {text} (UI-only)")
            lbl.setStyleSheet(style)
            try:
                lbl.adjustSize()
            except Exception:
                pass
        except Exception:
            pass

    def _set_batch_action_mode(self, mode: str) -> None:
        try:
            self._batch_action_mode = str(mode or "")
            mode = self._batch_action_mode
            if getattr(self, "_btn_focus_only", None) is not None:
                self._btn_focus_only.setChecked(mode == "focus_card")
            if getattr(self, "_btn_focus_note_zone", None) is not None:
                self._btn_focus_note_zone.setChecked(mode == "zone:note_fx")
            if getattr(self, "_btn_focus_instrument_zone", None) is not None:
                self._btn_focus_instrument_zone.setChecked(mode == "zone:instrument")
            if getattr(self, "_btn_focus_audio_zone", None) is not None:
                self._btn_focus_audio_zone.setChecked(mode == "zone:audio_fx")
        except Exception:
            pass
        try:
            self._update_batch_mode_badge()
        except Exception:
            pass
        try:
            self._restore_batch_hint_text()
        except Exception:
            pass

    def eventFilter(self, obj, event):  # noqa: N802, ANN001
        try:
            hints = getattr(self, "_batch_hover_hints", {}) or {}
            if obj in hints:
                et = event.type() if event is not None else None
                if et in (QEvent.Type.Enter, QEvent.Type.HoverEnter):
                    if getattr(self, "_batch_hint_label", None) is not None:
                        self._batch_hint_label.setText(str(hints.get(obj, "") or self._default_batch_hint_text()))
                elif et in (QEvent.Type.Leave, QEvent.Type.HoverLeave):
                    self._restore_batch_hint_text()
        except Exception:
            pass
        try:
            return super().eventFilter(obj, event)
        except Exception:
            return False

    def _update_batch_hint_visibility(self) -> None:
        try:
            lbl = getattr(self, "_batch_hint_label", None)
            if lbl is None:
                return
            # Auf kleineren Breiten lieber Platz für Buttons lassen.
            lbl.setVisible(self.width() >= 1280)
        except Exception:
            pass

    def resizeEvent(self, event):  # noqa: N802, ANN001
        try:
            super().resizeEvent(event)
        finally:
            try:
                self._sync_chain_host_size()
            except Exception:
                pass
            try:
                self._update_zone_visuals()
            except Exception:
                pass
            try:
                self._update_batch_hint_visibility()
            except Exception:
                pass

    def _ensure_zone_visuals(self) -> None:
        try:
            if getattr(self, "chain_host", None) is None:
                return
            for key, label_text in (("note_fx", "NOTE-FX"), ("instrument", "INSTRUMENT"), ("audio_fx", "AUDIO-FX")):
                if key not in self._zone_backdrops:
                    bg = QFrame(self.chain_host)
                    bg.setObjectName(f"deviceZoneBackdrop_{key}")
                    try:
                        bg.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
                    except Exception:
                        pass
                    if key == "instrument":
                        bg_style = (
                            "QFrame {"
                            " background: rgba(255, 170, 40, 0.045);"
                            " border: 1px solid rgba(255, 170, 40, 0.16);"
                            " border-radius: 10px;"
                            "}"
                        )
                    elif key == "note_fx":
                        bg_style = (
                            "QFrame {"
                            " background: rgba(90, 140, 255, 0.035);"
                            " border: 1px solid rgba(90, 140, 255, 0.10);"
                            " border-radius: 10px;"
                            "}"
                        )
                    else:
                        bg_style = (
                            "QFrame {"
                            " background: rgba(120, 230, 200, 0.028);"
                            " border: 1px solid rgba(120, 230, 200, 0.09);"
                            " border-radius: 10px;"
                            "}"
                        )
                    bg.setStyleSheet(bg_style)
                    bg.hide()
                    self._zone_backdrops[key] = bg
                if key not in self._zone_badges:
                    lab = QLabel(label_text, self.chain_host)
                    lab.setObjectName(f"deviceZoneBadge_{key}")
                    try:
                        lab.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
                    except Exception:
                        pass
                    lab.setStyleSheet(
                        "QLabel {"
                        " color:#c8d7ff;"
                        " background: rgba(80, 120, 255, 0.10);"
                        " border: 1px solid rgba(120, 170, 255, 0.28);"
                        " border-radius: 8px;"
                        " padding: 1px 8px;"
                        " font-size: 10px;"
                        " font-weight: 700;"
                        " letter-spacing: 0.5px;"
                        "}"
                    )
                    lab.hide()
                    self._zone_badges[key] = lab
                if key != "audio_fx" and key not in self._zone_dividers:
                    ln = QFrame(self.chain_host)
                    ln.setObjectName(f"deviceZoneDivider_{key}")
                    try:
                        ln.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
                    except Exception:
                        pass
                    ln.setStyleSheet(
                        "QFrame {"
                        " background: rgba(190, 198, 216, 0.16);"
                        " border: none;"
                        "}"
                    )
                    ln.setFixedWidth(1)
                    ln.hide()
                    self._zone_dividers[key] = ln
        except Exception:
            pass

    def _hide_zone_visuals(self) -> None:
        try:
            for w in (self._zone_backdrops or {}).values():
                try:
                    w.hide()
                except Exception:
                    pass
            for w in (self._zone_badges or {}).values():
                try:
                    w.hide()
                except Exception:
                    pass
            for w in (self._zone_dividers or {}).values():
                try:
                    w.hide()
                except Exception:
                    pass
        except Exception:
            pass

    def _update_zone_visuals(self) -> None:
        """Update group badges/dividers without touching layout indices (UI-only)."""
        try:
            self._ensure_zone_visuals()
            self._hide_zone_visuals()
            meta = self._zone_layout_meta if isinstance(getattr(self, '_zone_layout_meta', None), dict) else {}
            if not meta or not self._current_track:
                return

            n_note = int(meta.get('n_note', 0) or 0)
            n_audio = int(meta.get('n_audio', 0) or 0)
            inst_card = meta.get('inst_card')
            if inst_card is None or inst_card.parent() is None:
                return

            # Anchor geometry
            ix = int(inst_card.x())
            iw = int(inst_card.width())
            if iw <= 0:
                return

            gap = int(self.chain.spacing()) if self.chain is not None else 8
            host_w = int(self.chain_host.width()) if self.chain_host is not None else 0
            host_h = int(self.chain_host.height()) if self.chain_host is not None else 0
            if host_w <= 0 or host_h <= 0:
                return

            row_y = 2
            # v117 UX-Polish: Divider nur im Kopfbereich (nicht durch Device-Widgets)
            line_top = 4
            line_h = 12

            note_start = 4
            note_end = max(note_start + 32, ix - gap // 2)
            inst_start = max(4, ix)
            inst_end = min(host_w - 4, ix + iw)
            audio_start = min(host_w - 4, ix + iw + gap // 2)

            if n_audio > 0:
                # Last audio card gives a better visual end for the divider span.
                start_idx = n_note + 1
                last_item = self.chain.itemAt(start_idx + n_audio - 1) if self.chain is not None else None
                if last_item and last_item.widget():
                    lw = last_item.widget()
                    audio_end = max(audio_start + 64, int(lw.x()) + int(lw.width()))
                else:
                    audio_end = max(audio_start + 64, host_w - 8)
            else:
                audio_end = max(audio_start + 96, host_w - 12)
            audio_end = min(host_w - 8, audio_end)

            zones = {
                'note_fx': (note_start, max(0, note_end - note_start)),
                'instrument': (inst_start, max(0, inst_end - inst_start)),
                'audio_fx': (audio_start, max(0, audio_end - audio_start)),
            }

            # Zone-Fokus-Overlay kompakter darstellen (v125, UI-only):
            # Nicht fokussierte Zonen werden als schmale Rails um ihre
            # eingeklappten Cards gezeichnet, statt über die volle Zonenbreite.
            focus_zone = self._zone_focus_target_kind()
            if focus_zone:
                visible_cards = [w for w in self.chain_host.findChildren(_DeviceCard) if w.isVisible()]
                zone_cards = {"note_fx": [], "instrument": [], "audio_fx": []}
                for c in visible_cards:
                    try:
                        zk = str(getattr(c, '_zone_kind', '') or '')
                    except Exception:
                        zk = ''
                    if zk in zone_cards:
                        zone_cards[zk].append(c)

                def _card_span(cards_list):
                    if not cards_list:
                        return None
                    xs = []
                    xe = []
                    for c in cards_list:
                        try:
                            g = c.geometry()
                            if not g.isValid():
                                continue
                            xs.append(int(g.x()))
                            xe.append(int(g.x()) + max(1, int(g.width())))
                        except Exception:
                            continue
                    if not xs or not xe:
                        return None
                    return (min(xs), max(xe))

                def _to_rail(kind, zx, zw):
                    span = _card_span(zone_cards.get(kind) or [])
                    rail_min = 22
                    rail_max = 52
                    pad = 6
                    if span is not None:
                        sx0, sx1 = span
                        sx0 = max(2, sx0 - pad)
                        sx1 = min(host_w - 2, sx1 + pad)
                        width = max(rail_min, min(rail_max, sx1 - sx0))
                        cx = (sx0 + sx1) // 2
                        rx = max(2, min(host_w - width - 2, cx - width // 2))
                        return (rx, width)
                    width = rail_min
                    if kind == 'audio_fx':
                        rx = max(2, min(host_w - width - 2, zx + max(0, zw - width)))
                    else:
                        rx = max(2, min(host_w - width - 2, zx))
                    return (rx, width)

                for key in ("note_fx", "instrument", "audio_fx"):
                    if key == focus_zone:
                        continue
                    zx, zw = zones.get(key, (0, 0))
                    if zw <= 0:
                        continue
                    zones[key] = _to_rail(key, int(zx), int(zw))

            # Subtile Hintergründe (v114+, UI-only)
            # Instrument immer zeigen; Note-/Audio-Zonen nur wenn dort Devices existieren.
            focus_zone = self._zone_focus_target_kind()
            for key, (zx, zw) in zones.items():
                bg = (self._zone_backdrops or {}).get(key)
                if bg is None:
                    continue
                has_devices = (key == 'instrument') or (key == 'note_fx' and n_note > 0) or (key == 'audio_fx' and n_audio > 0)
                min_zone_w = 18 if (focus_zone and key != focus_zone) else 70
                min_draw_w = 14 if (focus_zone and key != focus_zone) else 40
                if (not has_devices) or zw < min_zone_w:
                    continue
                try:
                    bx = max(2, int(zx))
                    bw = max(0, min(host_w - 4, int(zw)) - (bx - int(zx)))
                    by = 18
                    bh = max(20, host_h - by - 6)
                    if bw >= min_draw_w and bh >= 16:
                        try:
                            if focus_zone and key != focus_zone:
                                bg.setStyleSheet("QFrame { background: rgba(90, 108, 145, 0.05); border: 1px solid rgba(120, 150, 210, 0.16); border-radius: 8px; }")
                            else:
                                bg.setStyleSheet("QFrame { background: rgba(120, 138, 175, 0.08); border: 1px solid rgba(120, 150, 210, 0.22); border-radius: 10px; }")
                        except Exception:
                            pass
                        bg.setGeometry(bx, by, bw, bh)
                        bg.show()
                        bg.lower()
                except Exception:
                    pass

            # Badges
            focus_zone = self._zone_focus_target_kind()
            for key, (zx, zw) in zones.items():
                lab = (self._zone_badges or {}).get(key)
                if lab is None:
                    continue
                if focus_zone and key != focus_zone:
                    # Bei Zonenfokus Rails bewusst ohne Badge lassen – wirkt ruhiger
                    # und suggeriert nicht mehr fälschlich eine breite geöffnete Zone.
                    continue
                if zw < 80:
                    continue
                try:
                    lab.adjustSize()
                    lw = int(lab.sizeHint().width())
                    lh = int(lab.sizeHint().height())
                    tx = max(zx + 4, min(zx + zw - lw - 4, zx + 10))
                    if key == 'instrument' and zw > (lw + 24):
                        tx = zx + (zw - lw) // 2
                    lab.setGeometry(int(tx), row_y, max(lw, 10), max(lh, 14))
                    lab.show()
                    lab.raise_()
                except Exception:
                    pass

            # Dividers after NOTE-FX and after INSTRUMENT
            focus_zone = self._zone_focus_target_kind()
            div_note = (self._zone_dividers or {}).get('note_fx')
            if div_note is not None and not focus_zone and n_note > 0 and note_end < host_w - 8:
                try:
                    div_note.setGeometry(int(note_end), line_top, 1, line_h)
                    div_note.show()
                    div_note.raise_()
                except Exception:
                    pass
            div_inst = (self._zone_dividers or {}).get('instrument')
            if div_inst is not None and not focus_zone and n_audio > 0 and inst_end < host_w - 8:
                try:
                    div_inst.setGeometry(int(inst_end + gap // 2), line_top, 1, line_h)
                    div_inst.show()
                    div_inst.raise_()
                except Exception:
                    pass
        except Exception:
            pass

    def _set_pending_fx_focus(self, kind: str, device_id: str) -> None:
        try:
            self._pending_focus_kind = str(kind or "")
            self._pending_focus_device_id = str(device_id or "")
        except Exception:
            self._pending_focus_kind = ""
            self._pending_focus_device_id = ""

    def _focus_fx_card(self, kind: str, device_id: str, *, ensure_visible: bool = False) -> None:
        kind = str(kind or "")
        device_id = str(device_id or "")
        if not kind or not device_id:
            return
        self._selected_fx_kind = kind
        self._selected_fx_device_id = device_id
        for (k, did), card in (self._rendered_fx_cards or {}).items():
            try:
                if hasattr(card, "set_selected_visual"):
                    card.set_selected_visual(bool(k == kind and did == device_id))
            except Exception:
                pass
        if ensure_visible:
            card = (self._rendered_fx_cards or {}).get((kind, device_id))
            if card is not None:
                self._queue_scroll_card_into_view(card)

    def _queue_scroll_card_into_view(self, card: QWidget) -> None:
        try:
            QTimer.singleShot(0, lambda c=card: self._scroll_card_into_view(c))
        except Exception:
            pass

    def _scroll_card_into_view(self, card: QWidget) -> None:
        try:
            if card is None or self.scroll is None:
                return
            sb = self.scroll.horizontalScrollBar()
            if sb is None:
                return
            x = int(card.x())
            w = int(card.width())
            vp_w = int(self.scroll.viewport().width()) if self.scroll.viewport() is not None else 0
            if vp_w <= 0:
                return
            left_margin = 16
            right_margin = 24
            cur = int(sb.value())
            if x < cur + left_margin:
                sb.setValue(max(0, x - left_margin))
                return
            if (x + w) > (cur + vp_w - right_margin):
                # center-ish when possible so parameter knobs are directly visible
                target = x - max(0, (vp_w - w) // 2)
                sb.setValue(max(0, target))
        except Exception:
            pass

    def _card_state_key(self, kind: str, device_id: str) -> str:
        try:
            return f"{str(kind or '').strip()}::{str(device_id or '').strip()}"
        except Exception:
            return ""

    def _is_card_collapsed(self, kind: str, device_id: str) -> bool:
        key = self._card_state_key(kind, device_id)
        if not key:
            return False
        return bool((self._card_collapse_state or {}).get(key, False))

    def _set_card_collapsed_state(self, kind: str, device_id: str, collapsed: bool) -> None:
        key = self._card_state_key(kind, device_id)
        if not key:
            return
        try:
            self._card_collapse_state[key] = bool(collapsed)
        except Exception:
            pass

    def _make_card_collapse_callback(self, kind: str, device_id: str):
        def _cb(collapsed: bool) -> None:
            try:
                self._set_card_collapsed_state(kind, device_id, bool(collapsed))
            except Exception:
                pass
            try:
                card = (self._rendered_fx_cards or {}).get((str(kind or ''), str(device_id or '')))
                if card is not None:
                    self._queue_scroll_card_into_view(card)
            except Exception:
                pass
            try:
                self._sync_chain_host_size()
                self._update_zone_visuals()
                self._update_batch_action_button_state()
            except Exception:
                pass
        return _cb

    def _iter_device_cards(self) -> List[_DeviceCard]:
        cards: List[_DeviceCard] = []
        try:
            if getattr(self, "chain", None) is None:
                return cards
            for i in range(self.chain.count()):
                item = self.chain.itemAt(i)
                if item is None:
                    continue
                w = item.widget()
                if isinstance(w, _DeviceCard):
                    cards.append(w)
        except Exception:
            return cards
        return cards

    def _apply_batch_collapse(self, *, collapse_inactive_only: bool = False, expand_all: bool = False, collapse_all: bool = False) -> None:
        changed = False
        try:
            for card in self._iter_device_cards():
                if card is None:
                    continue
                target = None
                if expand_all:
                    target = False
                elif collapse_all:
                    target = True
                elif collapse_inactive_only:
                    is_enabled = bool(getattr(card, "_ui_enabled", True))
                    if not is_enabled:
                        target = True
                if target is None:
                    continue
                if bool(card.is_collapsed()) == bool(target):
                    continue
                try:
                    c_kind = str(getattr(card, "_collapse_state_kind", "") or "")
                    c_dev = str(getattr(card, "_collapse_state_device_id", "") or "")
                    if c_kind and c_dev:
                        self._set_card_collapsed_state(c_kind, c_dev, bool(target))
                except Exception:
                    pass
                try:
                    card.set_collapsed(bool(target), notify=False)
                    changed = True
                except Exception:
                    pass
        except Exception:
            pass
        if changed:
            try:
                self._sync_chain_host_size()
                self._update_zone_visuals()
            except Exception:
                pass
        try:
            if expand_all:
                self._set_batch_action_mode("expanded_all")
            elif collapse_all:
                self._set_batch_action_mode("collapsed_all")
            elif collapse_inactive_only:
                self._set_batch_action_mode("collapsed_inactive")
        except Exception:
            pass
        try:
            self._update_batch_action_button_state()
        except Exception:
            pass

    def _resolve_focus_card_for_batch_action(self) -> Optional[_DeviceCard]:
        """Return target card for focus batch action.

        Priority:
        1) currently selected FX card (note/audio)
        2) instrument anchor card (safe fallback)
        3) first visible device card
        """
        try:
            kind = str(getattr(self, "_selected_fx_kind", "") or "")
            did = str(getattr(self, "_selected_fx_device_id", "") or "")
            if kind and did:
                card = (self._rendered_fx_cards or {}).get((kind, did))
                if isinstance(card, _DeviceCard):
                    return card
        except Exception:
            pass
        try:
            inst = (self._zone_layout_meta or {}).get("inst_card")
            if isinstance(inst, _DeviceCard):
                return inst
        except Exception:
            pass
        try:
            cards = self._iter_device_cards()
            return cards[0] if cards else None
        except Exception:
            return None

    def _collapse_focus_device_cards(self) -> None:
        """UI-only focus view: keep one card expanded, collapse the rest."""
        target_card = self._resolve_focus_card_for_batch_action()
        if target_card is None:
            try:
                self._update_batch_action_button_state()
            except Exception:
                pass
            return
        changed = False
        try:
            for card in self._iter_device_cards():
                if card is None:
                    continue
                want_collapsed = bool(card is not target_card)
                if bool(card.is_collapsed()) == want_collapsed:
                    continue
                try:
                    c_kind = str(getattr(card, "_collapse_state_kind", "") or "")
                    c_dev = str(getattr(card, "_collapse_state_device_id", "") or "")
                    if c_kind and c_dev:
                        self._set_card_collapsed_state(c_kind, c_dev, want_collapsed)
                except Exception:
                    pass
                try:
                    card.set_collapsed(want_collapsed, notify=False)
                    changed = True
                except Exception:
                    pass
        except Exception:
            pass
        try:
            if changed:
                self._sync_chain_host_size()
                self._update_zone_visuals()
            self._queue_scroll_card_into_view(target_card)
        except Exception:
            pass
        try:
            self._set_batch_action_mode("focus_card")
        except Exception:
            pass
        try:
            self._update_batch_action_button_state()
        except Exception:
            pass

    def _focus_only_zone_device_cards(self, zone_kind: str) -> None:
        """UI-only: collapse all cards except one zone (note_fx / instrument / audio_fx)."""
        try:
            zone_kind = str(zone_kind or "")
            if zone_kind not in ("note_fx", "instrument", "audio_fx"):
                return
            cards = self._iter_device_cards()
            if not cards:
                return
            zone_cards = [c for c in cards if str(getattr(c, "_collapse_state_kind", "") or "") == zone_kind]
            if not zone_cards:
                return
            target_card = getattr(self, "_focused_card", None)
            if target_card not in zone_cards:
                target_card = zone_cards[0]
            changed = False
            for card in cards:
                if card is None:
                    continue
                want_collapsed = bool(card not in zone_cards)
                if bool(card.is_collapsed()) == want_collapsed:
                    continue
                try:
                    c_kind = str(getattr(card, "_collapse_state_kind", "") or "")
                    c_dev = str(getattr(card, "_collapse_state_device_id", "") or "")
                    if c_kind and c_dev:
                        self._set_card_collapsed_state(c_kind, c_dev, want_collapsed)
                except Exception:
                    pass
                try:
                    card.set_collapsed(want_collapsed, notify=False)
                    changed = True
                except Exception:
                    pass
            try:
                if target_card is not None:
                    self._focused_card = target_card
            except Exception:
                pass
            try:
                if changed:
                    self._sync_chain_host_size()
                    self._update_zone_visuals()
                if target_card is not None:
                    self._queue_scroll_card_into_view(target_card)
            except Exception:
                pass
            try:
                self._set_batch_action_mode(f"zone:{zone_kind}")
            except Exception:
                pass
            try:
                self._update_batch_action_button_state()
            except Exception:
                pass
        except Exception:
            pass

    def _handle_escape_reset_shortcut(self) -> None:
        """UI-only comfort shortcut: Esc resets focus/zone/collapse view to normal."""
        try:
            cards = self._iter_device_cards()
            if not cards:
                return
            has_collapsed = any(bool(c.is_collapsed()) for c in cards)
            mode = str(getattr(self, "_batch_action_mode", "") or "")
            has_focus_mode = bool(mode == "focus_card" or mode.startswith("zone:"))
            if not (has_collapsed or has_focus_mode):
                return
        except Exception:
            return
        try:
            self._reset_normal_device_view()
        except Exception:
            pass
    def _reset_normal_device_view(self) -> None:
        """UI-only reset: all zones visible, all rendered cards expanded."""
        changed = False
        try:
            for card in self._iter_device_cards():
                if card is None:
                    continue
                if not bool(card.is_collapsed()):
                    continue
                try:
                    c_kind = str(getattr(card, "_collapse_state_kind", "") or "")
                    c_dev = str(getattr(card, "_collapse_state_device_id", "") or "")
                    if c_kind and c_dev:
                        self._set_card_collapsed_state(c_kind, c_dev, False)
                except Exception:
                    pass
                try:
                    card.set_collapsed(False, notify=False)
                    changed = True
                except Exception:
                    pass
        except Exception:
            pass
        try:
            if changed:
                self._sync_chain_host_size()
                self._update_zone_visuals()
        except Exception:
            pass
        try:
            self._set_batch_action_mode("")
        except Exception:
            pass
        try:
            self._update_batch_action_button_state()
        except Exception:
            pass

    def _collapse_inactive_device_cards(self) -> None:
        self._apply_batch_collapse(collapse_inactive_only=True)

    def _collapse_all_device_cards(self) -> None:
        self._apply_batch_collapse(collapse_all=True)

    def _expand_all_device_cards(self) -> None:
        self._apply_batch_collapse(expand_all=True)

    def _sync_chain_host_size(self) -> None:
        """Keep device-chain host at content width so horizontal scrolling works.

        Without this, Qt shrinks all cards into the viewport width and the UI becomes
        unreadable when many FX are chained.
        """
        try:
            if not hasattr(self, 'scroll') or not hasattr(self, 'chain_host'):
                return
            vp = self.scroll.viewport().size() if self.scroll.viewport() is not None else QSize(0, 0)
            layout_hint = self.chain.sizeHint() if self.chain is not None else QSize(0, 0)
            host_hint = self.chain_host.sizeHint()
            content_w = max(int(layout_hint.width()), int(host_hint.width()), 1)
            content_h = max(int(layout_hint.height()), int(host_hint.height()), 1)
            target_w = max(content_w, int(vp.width()))
            target_h = max(content_h, int(vp.height()))
            self.chain_host.resize(target_w, target_h)
            self.chain_host.setMinimumSize(content_w, target_h)
            self.chain_host.updateGeometry()
        except Exception:
            pass

    # ----------------- public API -----------------

    def show_track(self, track_id: str) -> None:
        self._current_track = str(track_id or "")
        self._safe_render_current_track()

    def has_device_for_track(self, track_id: str) -> bool:
        return bool(self._track_instruments.get(str(track_id or "")))

    def get_track_devices(self, track_id: str) -> list:
        """Return instrument widgets for this track (used by mixer routing / VU)."""
        tid = str(track_id or "")
        ent = self._track_instruments.get(tid)
        if ent and ent.get("widget") is not None:
            return [ent["widget"]]
        return []

    def remove_track_devices(self, track_id: str) -> None:
        tid = str(track_id or "")
        try:
            self._remove_instrument(tid)
        except Exception:
            pass

    def add_instrument(self, plugin_id: str) -> bool:
        """Add instrument to CURRENT track (compat helper)."""
        if not self._current_track:
            return False
        return self.add_instrument_to_track(self._current_track, plugin_id)

    def add_instrument_to_track(self, track_id: str, plugin_id: str) -> bool:
        track_id = str(track_id or "")
        plugin_id = (plugin_id or "").strip()
        if not track_id or not plugin_id:
            return False

        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return False

        instruments = {i.plugin_id: i for i in get_instruments()}
        spec = instruments.get(plugin_id)
        if spec is None:
            return False

        # Update model
        try:
            trk.plugin_type = plugin_id
            # If we switch away from SF2 routing, clear any lingering SF2 metadata
            # so the anchor doesn't show stale soundfont info.
            if hasattr(trk, "sf2_path"):
                trk.sf2_path = ""
            if hasattr(trk, "sf2_bank"):
                trk.sf2_bank = 0
            if hasattr(trk, "sf2_preset"):
                trk.sf2_preset = 0
        except Exception:
            pass

        # Build/replace widget
        self._create_or_replace_instrument_widget(track_id, plugin_id, spec)

        self._emit_project_updated()
        return True

    # ---- FX API (called by DnD and by Browser "Add")

    def add_note_fx_to_track(self, track_id: str, plugin_id: str, *, insert_index: int = -1) -> bool:
        track_id = str(track_id or "")
        plugin_id = str(plugin_id or "").strip()
        if not track_id or not plugin_id:
            return False

        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return False

        chain = getattr(trk, "note_fx_chain", None)
        if not isinstance(chain, dict):
            trk.note_fx_chain = {"devices": []}
            chain = trk.note_fx_chain

        dev_id = new_id("nfx")
        defaults = {}
        try:
            from .fx_specs import get_note_fx
            spec = next((s for s in get_note_fx() if s.plugin_id == plugin_id), None)
            if spec is not None:
                defaults = dict(spec.defaults)
        except Exception:
            defaults = {}

        new_dev = {
            "id": dev_id,
            "plugin_id": plugin_id,
            "name": plugin_id.split(".")[-1],
            "enabled": True,
            "params": defaults,
        }

        chain.setdefault("devices", [])
        devs = chain["devices"]
        if 0 <= insert_index <= len(devs):
            devs.insert(insert_index, new_dev)
        else:
            devs.append(new_dev)

        self._set_pending_fx_focus("note_fx", dev_id)

        # (Optional) re-trigger playback for immediate effect.
        self._restart_if_playing()
        self._emit_project_updated()
        return True

    def add_audio_fx_to_track(self, track_id: str, plugin_id: str, *, insert_index: int = -1) -> bool:
        track_id = str(track_id or "")
        plugin_id = str(plugin_id or "").strip()
        if not track_id or not plugin_id:
            return False

        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return False

        chain = getattr(trk, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            trk.audio_fx_chain = {"type": "chain", "mix": 1.0, "wet_gain": 1.0, "devices": []}
            chain = trk.audio_fx_chain

        dev_id = new_id("afx")
        defaults = {}
        try:
            from .fx_specs import get_audio_fx
            spec = next((s for s in get_audio_fx() if s.plugin_id == plugin_id), None)
            if spec is not None:
                defaults = dict(spec.defaults)
        except Exception:
            defaults = {}

        new_dev = {
            "id": dev_id,
            "plugin_id": plugin_id,
            "name": plugin_id.split(".")[-1],
            "enabled": True,
            "params": defaults,
        }

        chain.setdefault("devices", [])
        devs = chain["devices"]
        if 0 <= insert_index <= len(devs):
            devs.insert(insert_index, new_dev)
        else:
            devs.append(new_dev)

        self._set_pending_fx_focus("audio_fx", dev_id)
        self._rebuild_audio_fx(project_obj)
        self._restart_if_playing()
        self._emit_project_updated()
        return True

    def remove_note_fx_device(self, track_id: str, device_id: str) -> None:
        track_id = str(track_id or "")
        device_id = str(device_id or "")
        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or trk is None:
            return
        chain = getattr(trk, "note_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        chain["devices"] = [d for d in devs if not (isinstance(d, dict) and str(d.get("id","")) == device_id)]
        if self._selected_fx_kind == "note_fx" and self._selected_fx_device_id == device_id:
            self._selected_fx_kind = ""
            self._selected_fx_device_id = ""
        self._restart_if_playing()
        self._emit_project_updated()

    def remove_audio_fx_device(self, track_id: str, device_id: str) -> None:
        track_id = str(track_id or "")
        device_id = str(device_id or "")
        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return
        chain = getattr(trk, "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        chain["devices"] = [d for d in devs if not (isinstance(d, dict) and str(d.get("id","")) == device_id)]
        if self._selected_fx_kind == "audio_fx" and self._selected_fx_device_id == device_id:
            self._selected_fx_kind = ""
            self._selected_fx_device_id = ""
        self._rebuild_audio_fx(project_obj)
        self._restart_if_playing()
        self._emit_project_updated()

    # ----------------- DnD plumbing -----------------

    def _forward_drag_event(self, event) -> bool:  # noqa: ANN001
        """Forwarded from host or child widgets. Calculates insertion position.
        v107: Also handles internal reorder (drag within chain)."""
        try:
            payload = _parse_payload(event)
            if payload is None:
                event.ignore()
                return True
            kind = str(payload.get("kind") or "")
            is_reorder = bool(payload.get("reorder", False))
            if kind not in ("instrument", "note_fx", "audio_fx"):
                event.ignore()
                return True

            if event.type() in (QEvent.Type.DragEnter, QEvent.Type.DragMove):
                event.setDropAction(Qt.DropAction.MoveAction if is_reorder else Qt.DropAction.CopyAction)
                event.accept()
                # Calculate and show insertion indicator
                if kind in ("note_fx", "audio_fx"):
                    try:
                        self._update_drop_indicator(event, kind)
                    except Exception:
                        pass
                return True

            if event.type() == QEvent.Type.Drop:
                event.setDropAction(Qt.DropAction.MoveAction if is_reorder else Qt.DropAction.CopyAction)
                event.accept()
                if not self._current_track:
                    self._hide_drop_indicator()
                    return True

                # Capture insert position before hiding indicator
                insert_kind = self._drop_insert_kind
                insert_index = self._drop_insert_index
                self._hide_drop_indicator()

                if is_reorder:
                    # Internal reorder: move device to new position
                    device_id = str(payload.get("device_id") or "")
                    if device_id and insert_kind == kind:
                        self._reorder_fx_to(self._current_track, kind, device_id, insert_index)
                    return True

                plugin_id = str(payload.get("plugin_id") or "")
                if kind == "instrument":
                    self.add_instrument_to_track(self._current_track, plugin_id)
                elif kind == "note_fx":
                    idx = insert_index if insert_kind == "note_fx" else -1
                    self.add_note_fx_to_track(self._current_track, plugin_id, insert_index=idx)
                elif kind == "audio_fx":
                    idx = insert_index if insert_kind == "audio_fx" else -1
                    self.add_audio_fx_to_track(self._current_track, plugin_id, insert_index=idx)
                return True
        except Exception:
            try:
                self._hide_drop_indicator()
            except Exception:
                pass
            try:
                event.ignore()
            except Exception:
                pass
            return True

        return False

    def _update_drop_indicator(self, event, kind: str) -> None:
        """Calculate which slot the cursor is over and show the drop indicator there.

        The chain layout is: [Note-FX cards...] [Instrument anchor] [Audio-FX cards...] [stretch]
        We find all cards of the matching kind and determine which gap the cursor falls into.
        """
        try:
            # Map event position to chain_host coordinates
            pos = event.position() if hasattr(event, 'position') else event.posF()
            source_widget = None
            try:
                # The event comes from different widgets; we need to map to chain_host
                source_widget = event.source() if hasattr(event, 'source') else None
            except Exception:
                pass

            # Get global position and map to chain_host
            try:
                if hasattr(event, 'position'):
                    local_pos = event.position()
                else:
                    local_pos = event.posF()
                # Map from the widget that received the event to chain_host
                # We use globalPosition for reliable mapping
                if hasattr(event, 'globalPosition'):
                    global_pos = event.globalPosition().toPoint()
                elif hasattr(event, 'globalPos'):
                    global_pos = event.globalPos()
                else:
                    global_pos = self.chain_host.mapToGlobal(local_pos.toPoint())
                host_pos = self.chain_host.mapFromGlobal(global_pos)
                cursor_x = host_pos.x()
            except Exception:
                cursor_x = int(pos.x()) if pos else 0

            # Collect cards of the matching kind with their positions
            cards_info = self._get_chain_card_positions(kind)

            if not cards_info:
                # No existing cards: show indicator at the zone's start position
                zone_x = self._get_zone_start_x(kind)
                self._show_drop_indicator_at(zone_x)
                self._drop_insert_kind = kind
                self._drop_insert_index = 0
                return

            # Find which gap the cursor falls into
            # Gaps: [before card 0] [card 0] [between 0 and 1] [card 1] ... [after last card]
            insert_idx = len(cards_info)  # default: append
            for i, (card_x, card_w) in enumerate(cards_info):
                card_center = card_x + card_w // 2
                if cursor_x < card_center:
                    insert_idx = i
                    break

            # Position the indicator
            if insert_idx == 0:
                indicator_x = cards_info[0][0] - 4
            elif insert_idx < len(cards_info):
                prev_right = cards_info[insert_idx - 1][0] + cards_info[insert_idx - 1][1]
                next_left = cards_info[insert_idx][0]
                indicator_x = (prev_right + next_left) // 2
            else:
                last_right = cards_info[-1][0] + cards_info[-1][1]
                indicator_x = last_right + 4

            self._show_drop_indicator_at(indicator_x)
            self._drop_insert_kind = kind
            self._drop_insert_index = insert_idx

        except Exception:
            self._hide_drop_indicator()

    def _get_chain_card_positions(self, kind: str) -> List[Tuple[int, int]]:
        """Return list of (x_pos, width) for all device cards of the given kind in chain_host coords.

        Chain layout: [Note-FX 0..N] [Instrument anchor] [Audio-FX 0..M] [stretch]
        """
        result = []
        try:
            if not self._current_track:
                return result
            _, project_obj, trk = self._get_project_track(self._current_track)
            if trk is None:
                return result

            # Count devices to know which layout items belong to which zone
            note_chain = getattr(trk, "note_fx_chain", None)
            note_devs = note_chain.get("devices", []) if isinstance(note_chain, dict) else []
            note_devs = [d for d in (note_devs or []) if isinstance(d, dict)]
            n_note = len(note_devs)

            audio_chain = getattr(trk, "audio_fx_chain", None)
            audio_devs = audio_chain.get("devices", []) if isinstance(audio_chain, dict) else []
            audio_devs = [d for d in (audio_devs or []) if isinstance(d, dict)]
            n_audio = len(audio_devs)

            # Layout items: [note_fx cards (0..n_note-1)] [instrument card (n_note)] [audio_fx cards (n_note+1..n_note+n_audio)] [stretch]
            if kind == "note_fx":
                for i in range(n_note):
                    item = self.chain.itemAt(i)
                    if item and item.widget():
                        w = item.widget()
                        result.append((w.x(), w.width()))
            elif kind == "audio_fx":
                start = n_note + 1  # skip note-fx cards + instrument anchor
                for i in range(n_audio):
                    item = self.chain.itemAt(start + i)
                    if item and item.widget():
                        w = item.widget()
                        result.append((w.x(), w.width()))
        except Exception:
            pass
        return result

    def _get_zone_start_x(self, kind: str) -> int:
        """Get the x coordinate where new cards of this kind should start."""
        try:
            if kind == "note_fx":
                return 0
            elif kind == "audio_fx":
                # Right after the instrument anchor card
                _, _, trk = self._get_project_track(self._current_track)
                if trk is None:
                    return 0
                note_chain = getattr(trk, "note_fx_chain", None)
                note_devs = note_chain.get("devices", []) if isinstance(note_chain, dict) else []
                note_devs = [d for d in (note_devs or []) if isinstance(d, dict)]
                anchor_idx = len(note_devs)  # instrument anchor is right after note-fx
                item = self.chain.itemAt(anchor_idx)
                if item and item.widget():
                    w = item.widget()
                    return w.x() + w.width() + 8
        except Exception:
            pass
        return 0

    def _show_drop_indicator_at(self, x: int) -> None:
        """Show the vertical drop indicator line at the given x position."""
        try:
            self._drop_indicator.setParent(self.chain_host)
            self._drop_indicator.setFixedHeight(max(self.chain_host.height() - 8, 40))
            self._drop_indicator.move(max(0, x - 1), 4)
            self._drop_indicator.show()
            self._drop_indicator.raise_()
        except Exception:
            pass

    def _hide_drop_indicator(self) -> None:
        """Hide the drop indicator and reset state."""
        try:
            self._drop_indicator.hide()
        except Exception:
            pass
        self._drop_insert_kind = ""
        self._drop_insert_index = -1

    def dragEnterEvent(self, event):  # noqa: N802, ANN001
        self._forward_drag_event(event)

    def dragMoveEvent(self, event):  # noqa: N802, ANN001
        self._forward_drag_event(event)

    def dropEvent(self, event):  # noqa: N802, ANN001
        self._forward_drag_event(event)

    def dragLeaveEvent(self, event):  # noqa: N802, ANN001
        try:
            self._hide_drop_indicator()
        except Exception:
            pass

    # ---- internal drag reorder (v107) ----

    def _reorder_fx_to(self, track_id: str, kind: str, device_id: str, target_index: int) -> None:
        """Move *device_id* of *kind* to *target_index* in the chain.

        This is invoked when the user drags an FX card to a new position within
        the same FX zone (note_fx or audio_fx).
        """
        track_id = str(track_id or "")
        device_id = str(device_id or "")
        target_index = int(target_index)
        if not track_id or not device_id:
            return
        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return

        chain_attr = "note_fx_chain" if kind == "note_fx" else "audio_fx_chain"
        chain = getattr(trk, chain_attr, None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        devs = [d for d in devs if isinstance(d, dict)]

        # Find current position
        src_idx = next((i for i, d in enumerate(devs) if str(d.get("id", "")) == device_id), None)
        if src_idx is None:
            return

        # Nothing to do if already at target
        if src_idx == target_index or (src_idx + 1 == target_index):
            # target_index is the *insertion* index (gap index), so
            # dropping right after the same card means no move.
            return

        device = devs.pop(src_idx)
        # Adjust target after removal
        ins = target_index if target_index <= src_idx else target_index - 1
        ins = max(0, min(ins, len(devs)))
        devs.insert(ins, device)
        chain["devices"] = devs

        if kind == "audio_fx":
            self._rebuild_audio_fx(project_obj)

        self._set_pending_fx_focus(kind, device_id)
        self._emit_project_updated()

    # ----------------- render -----------------

    def _safe_render_current_track(self) -> None:
        try:
            self._render_current_track()
        except Exception:
            # never crash Qt thread
            return

    def _render_current_track(self) -> None:
        # clear layout
        self._clear_chain()
        self._rendered_fx_cards = {}

        if not self._current_track:
            self.chain.addWidget(self.empty_label)
            self.chain.addStretch(1)
            self._zone_layout_meta = {}
            self._sync_chain_host_size()
            self._hide_zone_visuals()
            self._update_batch_action_button_state()
            return

        proj, project_obj, trk = self._get_project_track(self._current_track)
        if proj is None or project_obj is None or trk is None:
            self.chain.addWidget(self.empty_label)
            self.chain.addStretch(1)
            self._zone_layout_meta = {}
            self._sync_chain_host_size()
            self._hide_zone_visuals()
            self._update_batch_action_button_state()
            return

        # NOTE-FX (left)
        note_chain = getattr(trk, "note_fx_chain", None)
        note_devs = note_chain.get("devices", []) if isinstance(note_chain, dict) else []
        note_devs = [d for d in (note_devs or []) if isinstance(d, dict)]

        for i, dev in enumerate(note_devs):
            did = str(dev.get("id") or "")
            title = str(dev.get("name") or dev.get("plugin_id") or "Note-FX")
            enabled = bool(dev.get("enabled", True))
            inner = make_note_fx_widget(self._services, self._current_track, dev) or QLabel("No UI")
            self._install_drop_filter(inner)

            card = _DeviceCard(
                title,
                inner,
                enabled=enabled,
                can_up=i > 0,
                can_down=i < (len(note_devs) - 1),
                on_up=lambda tid=self._current_track, d=did: self._move_fx(tid, "note_fx", d, -1),
                on_down=lambda tid=self._current_track, d=did: self._move_fx(tid, "note_fx", d, +1),
                on_power=lambda checked, tid=self._current_track, d=did: self._set_fx_enabled(tid, "note_fx", d, bool(checked)),
                on_remove=lambda tid=self._current_track, d=did: self.remove_note_fx_device(tid, d),
                on_focus=lambda k="note_fx", d=did: self._focus_fx_card(k, d, ensure_visible=False),
                on_toggle_collapse=self._make_card_collapse_callback("note_fx", did),
                collapsed=self._is_card_collapsed("note_fx", did),
                collapsible=True,
                device_id=did,
                fx_kind="note_fx",
            )
            try:
                card._collapse_state_kind = "note_fx"
                card._collapse_state_device_id = did
            except Exception:
                pass
            self._install_drop_filter(card)
            self.chain.addWidget(card)
            self._rendered_fx_cards[("note_fx", did)] = card
            if self._selected_fx_kind == "note_fx" and self._selected_fx_device_id == did:
                self._focus_fx_card("note_fx", did, ensure_visible=False)
            if self._pending_focus_kind == "note_fx" and self._pending_focus_device_id == did:
                self._focus_fx_card("note_fx", did, ensure_visible=True)
                self._pending_focus_kind = ""
                self._pending_focus_device_id = ""

        # INSTRUMENT (anchor, fixed)
        inst_card = self._make_instrument_anchor_card(project_obj, trk)
        self._install_drop_filter(inst_card)
        self.chain.addWidget(inst_card)
        self._zone_layout_meta = {"n_note": len(note_devs), "n_audio": 0, "inst_card": inst_card}

        # AUDIO-FX (right)
        audio_chain = getattr(trk, "audio_fx_chain", None)
        audio_devs = audio_chain.get("devices", []) if isinstance(audio_chain, dict) else []
        audio_devs = [d for d in (audio_devs or []) if isinstance(d, dict)]

        for i, dev in enumerate(audio_devs):
            did = str(dev.get("id") or "")
            title = str(dev.get("name") or dev.get("plugin_id") or "Audio-FX")
            enabled = bool(dev.get("enabled", True))
            inner = make_audio_fx_widget(self._services, self._current_track, dev) or QLabel("No UI")
            self._install_drop_filter(inner)

            card = _DeviceCard(
                title,
                inner,
                enabled=enabled,
                can_up=i > 0,
                can_down=i < (len(audio_devs) - 1),
                on_up=lambda tid=self._current_track, d=did: self._move_fx(tid, "audio_fx", d, -1),
                on_down=lambda tid=self._current_track, d=did: self._move_fx(tid, "audio_fx", d, +1),
                on_power=lambda checked, tid=self._current_track, d=did: self._set_fx_enabled(tid, "audio_fx", d, bool(checked)),
                on_remove=lambda tid=self._current_track, d=did: self.remove_audio_fx_device(tid, d),
                on_focus=lambda k="audio_fx", d=did: self._focus_fx_card(k, d, ensure_visible=False),
                on_toggle_collapse=self._make_card_collapse_callback("audio_fx", did),
                collapsed=self._is_card_collapsed("audio_fx", did),
                collapsible=True,
                device_id=did,
                fx_kind="audio_fx",
            )
            try:
                card._collapse_state_kind = "audio_fx"
                card._collapse_state_device_id = did
            except Exception:
                pass
            self._install_drop_filter(card)
            self.chain.addWidget(card)
            self._rendered_fx_cards[("audio_fx", did)] = card
            if self._selected_fx_kind == "audio_fx" and self._selected_fx_device_id == did:
                self._focus_fx_card("audio_fx", did, ensure_visible=False)
            if self._pending_focus_kind == "audio_fx" and self._pending_focus_device_id == did:
                self._focus_fx_card("audio_fx", did, ensure_visible=True)
                self._pending_focus_kind = ""
                self._pending_focus_device_id = ""

        self.chain.addStretch(1)
        try:
            self._zone_layout_meta = {"n_note": len(note_devs), "n_audio": len(audio_devs), "inst_card": inst_card}
        except Exception:
            self._zone_layout_meta = {}
        self._sync_chain_host_size()
        try:
            QTimer.singleShot(0, self._update_zone_visuals)
        except Exception:
            self._update_zone_visuals()
        self._update_batch_action_button_state()

    def _make_instrument_anchor_card(self, project_obj: Any, trk: Any) -> QWidget:
        tid = str(getattr(trk, "id", "") or "")
        plugin_id = str(getattr(trk, "plugin_type", "") or "")

        # legacy SF2 info
        sf2_path = str(getattr(trk, "sf2_path", "") or "")
        sf2_bank = getattr(trk, "sf2_bank", 0)
        sf2_preset = getattr(trk, "sf2_preset", 0)

        # SF2 ist aktuell kein Qt-Instrument-Plugin aus der Registry.
        # Trotzdem ist plugin_type == "sf2" ein valider Instrument-Anker (Engine render...)
        if plugin_id == "sf2" or (not plugin_id and sf2_path):
            w = _Sf2InstrumentWidget(self, tid, sf2_path=sf2_path, bank=int(sf2_bank or 0), preset=int(sf2_preset or 0))
            self._install_drop_filter(w)
            inst_enabled = bool(getattr(trk, "instrument_enabled", True))
            card = _DeviceCard(
                "Instrument — SF2",
                w,
                enabled=inst_enabled,
                can_up=False,
                can_down=False,
                on_up=None,
                on_down=None,
                on_power=lambda checked, tid=tid: self._set_instrument_enabled(tid, bool(checked)),
                on_remove=lambda tid=tid: self._remove_instrument(tid),
                on_toggle_collapse=self._make_card_collapse_callback("instrument", tid),
                collapsed=self._is_card_collapsed("instrument", tid),
                collapsible=True,
            )
            try:
                card._collapse_state_kind = "instrument"
                card._collapse_state_device_id = tid
            except Exception:
                pass
            try:
                card.setMinimumWidth(max(card.minimumWidth(), 340))
            except Exception:
                pass
            return card

        if plugin_id:
            # Ensure widget exists for this plugin id
            if tid not in self._track_instruments or self._track_instruments[tid].get("plugin_id") != plugin_id:
                instruments = {i.plugin_id: i for i in get_instruments()}
                spec = instruments.get(plugin_id)
                if spec is not None:
                    self._create_or_replace_instrument_widget(tid, plugin_id, spec)

            w = self._track_instruments.get(tid, {}).get("widget")
            if w is None:
                w = QLabel("Instrument failed to load.")
            else:
                # ensure track context
                try:
                    if hasattr(w, "set_track_context"):
                        w.set_track_context(tid)
                except Exception:
                    pass

            self._install_drop_filter(w)
            inst_enabled = bool(getattr(trk, "instrument_enabled", True))
            card = _DeviceCard(
                f"Instrument — {plugin_id.split('.')[-1]}",
                w,
                enabled=inst_enabled,
                can_up=False,
                can_down=False,
                on_up=None,
                on_down=None,
                on_power=lambda checked, tid=tid: self._set_instrument_enabled(tid, bool(checked)),
                on_remove=lambda tid=tid: self._remove_instrument(tid),
                on_toggle_collapse=self._make_card_collapse_callback("instrument", tid),
                collapsed=self._is_card_collapsed("instrument", tid),
                collapsible=True,
            )
            try:
                card._collapse_state_kind = "instrument"
                card._collapse_state_device_id = tid
            except Exception:
                pass
            try:
                card.setMinimumWidth(max(card.minimumWidth(), 340))
                # Breite aus Instrument-Widget ableiten (z. B. Bachs Orgel mit mehreren Sektionen),
                # damit die UI nicht unleserlich zusammengequetscht wird.
                _iw_hint = 0
                try:
                    _iw_hint = int(w.minimumSizeHint().width()) if hasattr(w, 'minimumSizeHint') else 0
                except Exception:
                    _iw_hint = 0
                if _iw_hint <= 0:
                    try:
                        _iw_hint = int(w.sizeHint().width()) if hasattr(w, 'sizeHint') else 0
                    except Exception:
                        _iw_hint = 0
                if _iw_hint > 0:
                    _desired = max(340, min(2200, _iw_hint + 48))
                    card.setMinimumWidth(max(card.minimumWidth(), _desired))
                    card.setMaximumWidth(max(int(card.maximumWidth()), _desired))
            except Exception:
                pass
            return card

        # No plugin instrument: show placeholder (anchor)
        lab = QLabel("Instrument (Anchor)\nDrop an Instrument here or double‑click in Browser.")
        lab.setStyleSheet("color:#9a9a9a;")
        lab.setWordWrap(True)

        if sf2_path:
            try:
                import os
                name = os.path.basename(sf2_path)
            except Exception:
                name = sf2_path
            lab.setText(
                f"Instrument (Anchor)\nSF2: {name} (Bank {sf2_bank}, Preset {sf2_preset})\n"
                "Drop an Instrument plugin here to replace."
            )

        card = _DeviceCard(
            "Instrument — (empty)",
            lab,
            enabled=True,
            can_up=False,
            can_down=False,
            on_up=None,
            on_down=None,
            on_power=None,
            on_remove=None,
            on_toggle_collapse=self._make_card_collapse_callback("instrument", tid or self._current_track),
            collapsed=self._is_card_collapsed("instrument", tid or self._current_track),
            collapsible=True,
        )
        try:
            card.setMinimumWidth(max(card.minimumWidth(), 340))
        except Exception:
            pass
        return card

    # ----------------- model mutations -----------------

    def _move_fx(self, track_id: str, kind: str, device_id: str, delta: int) -> None:
        track_id = str(track_id or "")
        device_id = str(device_id or "")
        delta = int(delta)
        if not track_id or not device_id or delta == 0:
            return
        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return

        chain = getattr(trk, "note_fx_chain" if kind == "note_fx" else "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        devs = [d for d in devs if isinstance(d, dict)]
        idx = next((i for i, d in enumerate(devs) if str(d.get("id","")) == device_id), None)
        if idx is None:
            return
        j = idx + delta
        if j < 0 or j >= len(devs):
            return
        devs[idx], devs[j] = devs[j], devs[idx]
        chain["devices"] = devs

        if kind == "audio_fx":
            self._rebuild_audio_fx(project_obj)

        self._set_pending_fx_focus(kind, device_id)
        self._emit_project_updated()

    def _set_fx_enabled(self, track_id: str, kind: str, device_id: str, enabled: bool) -> None:
        track_id = str(track_id or "")
        device_id = str(device_id or "")
        enabled = bool(enabled)
        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return
        chain = getattr(trk, "note_fx_chain" if kind == "note_fx" else "audio_fx_chain", None)
        if not isinstance(chain, dict):
            return
        devs = chain.get("devices", []) or []
        for d in devs:
            if isinstance(d, dict) and str(d.get("id","")) == device_id:
                d["enabled"] = bool(enabled)
                break
        if kind == "audio_fx":
            self._rebuild_audio_fx(project_obj)
        self._set_pending_fx_focus(kind, device_id)
        self._emit_project_updated()

    def _set_instrument_enabled(self, track_id: str, enabled: bool) -> None:
        """Toggle Instrument Power/Bypass for a track.

        When disabled (bypassed):
        - No MIDI events are dispatched to the instrument engine
        - No SF2 rendering occurs
        - Pull-sources for this track are silenced
        The track remains visible and its FX chain stays intact.
        """
        track_id = str(track_id or "")
        enabled = bool(enabled)
        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or project_obj is None or trk is None:
            return
        try:
            trk.instrument_enabled = enabled
        except Exception:
            return
        self._restart_if_playing()
        self._emit_project_updated()

    def _remove_instrument(self, track_id: str) -> None:
        track_id = str(track_id or "")
        proj, project_obj, trk = self._get_project_track(track_id)
        if proj is None or trk is None:
            return
        try:
            trk.plugin_type = None
        except Exception:
            pass
        # SF2 cleanup (falls Track zuvor als SF2-Instrument geroutet war)
        try:
            if hasattr(trk, "sf2_path"):
                trk.sf2_path = ""
            if hasattr(trk, "sf2_bank"):
                trk.sf2_bank = 0
            if hasattr(trk, "sf2_preset"):
                trk.sf2_preset = 0
        except Exception:
            pass
        ent = self._track_instruments.pop(track_id, None)
        if ent and ent.get("widget") is not None:
            try:
                ent["widget"].setParent(None)
            except Exception:
                pass
        self._emit_project_updated()

    def _create_or_replace_instrument_widget(self, track_id: str, plugin_id: str, spec) -> None:  # noqa: ANN001
        track_id = str(track_id or "")
        if not track_id:
            return
        proj = getattr(self._services, "project", None) if self._services else None
        ae = getattr(self._services, "audio_engine", None) if self._services else None

        # Remove old widget if any
        old = self._track_instruments.get(track_id)
        if old and old.get("widget") is not None:
            try:
                old["widget"].setParent(None)
            except Exception:
                pass
        am = getattr(self._services, "automation_manager", None) if self._services else None

        try:
            w = spec.factory(project_service=proj, audio_engine=ae, automation_manager=am)
        except Exception as e:
            w = QLabel(f"Instrument error: {e}")

        try:
            w.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        except Exception:
            pass

        # Track context (important for pull-source routing)
        try:
            if hasattr(w, "set_track_context"):
                w.set_track_context(track_id)
        except Exception:
            pass
        try:
            if hasattr(w, "track_id"):
                w.track_id = track_id
        except Exception:
            pass

        self._install_drop_filter(w)
        self._track_instruments[track_id] = {"plugin_id": plugin_id, "widget": w}

    # ----------------- helpers -----------------

    def _install_drop_filter(self, w: QWidget) -> None:
        try:
            if w is None:
                return
            w.installEventFilter(self._drop_filter)
            # Also install for children to avoid drops "verpuffen"
            for ch in w.findChildren(QWidget):
                try:
                    ch.installEventFilter(self._drop_filter)
                except Exception:
                    pass
        except Exception:
            pass

    def _clear_chain(self) -> None:
        try:
            self._hide_drop_indicator()
        except Exception:
            pass
        try:
            self._zone_layout_meta = {}
            self._hide_zone_visuals()
        except Exception:
            pass
        try:
            persistent = set()
            try:
                for ent in (self._track_instruments or {}).values():
                    w0 = ent.get("widget") if isinstance(ent, dict) else None
                    if w0 is not None:
                        persistent.add(w0)
            except Exception:
                persistent = set()

            while self.chain.count():
                it = self.chain.takeAt(0)
                w = it.widget()
                if w is None:
                    continue

                # If this is a card wrapping a persistent instrument widget, detach it first.
                try:
                    inner = getattr(w, "inner_widget", None)
                    if inner is not None and inner in persistent:
                        inner.setParent(None)
                except Exception:
                    pass

                w.setParent(None)
        except Exception:
            pass

    def _emit_project_updated(self) -> None:
        try:
            proj = getattr(self._services, "project", None) if self._services else None
            if proj is not None and hasattr(proj, "project_updated"):
                proj.project_updated.emit()
        except Exception:
            pass

    def _get_project_track(self, track_id: str) -> Tuple[Any, Any, Any]:
        proj = getattr(self._services, "project", None) if self._services else None
        if proj is None:
            return None, None, None
        ctx = getattr(proj, "ctx", None)
        project_obj = getattr(ctx, "project", None) if ctx is not None else None
        if project_obj is None:
            return proj, None, None
        trk = _find_track(project_obj, track_id)
        return proj, project_obj, trk

    def _rebuild_audio_fx(self, project_obj: Any) -> None:
        ae = getattr(self._services, "audio_engine", None) if self._services else None
        try:
            if ae is not None and hasattr(ae, "rebuild_fx_maps"):
                ae.rebuild_fx_maps(project_obj)
        except Exception:
            pass

    def _restart_if_playing(self) -> None:
        try:
            transport = getattr(self._services, "transport", None) if self._services else None
            ae = getattr(self._services, "audio_engine", None) if self._services else None
            if transport is None or ae is None:
                return
            playing = bool(getattr(transport, "is_playing", False) or getattr(transport, "playing", False))
            if not playing:
                return
            try:
                ae.stop()
            except Exception:
                pass
            try:
                ae.start_arrangement_playback()
            except Exception:
                pass
        except Exception:
            pass
