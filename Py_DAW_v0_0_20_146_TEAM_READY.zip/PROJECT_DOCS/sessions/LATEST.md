v0.0.20.146
- Audio Editor → Arranger Slice-Export: Drag erzeugt jetzt **das korrekte Segment** (nicht mehr den Sample-Anfang).
  - Root Cause: Renderer nutzt `offset_seconds` → Export setzt jetzt `offset_seconds` stabil über `file_secs / src.length_beats`.
  - Export speichert einen konsolidierten Slice-Event (Start 0, Länge = Slice) und bleibt zukunftssicher.

Vorher (v0.0.20.145):
- Audio Editor: Knife/Split erzeugt nun deutlich sichtbare Slice-Linien (Events → Slices), damit Cutpoints klar erkennbar sind.
- Audio Editor → Arranger: AudioEvent-Slices können jetzt DAW-like nach oben in den Arranger gezogen werden (Drag&Drop).
  - Workflow: Knife schneiden → Arrow auswählen/Segment markieren → nach oben aus dem Editor ziehen → im Arranger droppen.
- Arranger: Drop von Audio-Editor-Slices erstellt einen NEUEN Audio-Clip (non-destructive) auf der Zielspur.
  - Clip übernimmt Gain/Pan/Pitch/Formant/Stretch/Reverse/Mute/Fades sowie Warp-Marker & Clip-Automation (best-effort, gecroppt + verschoben).

Vorher (v0.0.20.144):
- Arranger: Audio-Waveform Preview ist jetzt deutlich besser lesbar (visuelles Normalizing, mehr Kontrast)
- Arranger: Waveform-Preview funktioniert auch bei kleinen Track-Höhen (dynamische Preview-Area)
- Arranger: Multi-Format Waveform-Decode: soundfile → optional pydub/ffmpeg Fallback (MP3/M4A/MP4 u.a.)
