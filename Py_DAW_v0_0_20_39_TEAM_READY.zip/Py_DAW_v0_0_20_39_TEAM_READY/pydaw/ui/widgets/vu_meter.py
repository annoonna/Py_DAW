"""VU Meter Widget - Professional Audio Level Metering.

Features:
- 3-Zone color scheme (Green/Yellow/Red)
- Peak hold markers with decay
- dB scale reference marks
- Stereo L/R channels
- 20 FPS update rate (50ms)
- Smooth decay animation
"""

from __future__ import annotations

from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import Qt, QRectF, QTimer
from PyQt6.QtGui import QPainter, QPen, QBrush, QColor, QLinearGradient
import math


def _linear_to_db(linear: float) -> float:
    """Convert linear amplitude (0-1) to dB."""
    if linear <= 0.0:
        return -60.0
    return 20.0 * math.log10(linear)


class VUMeterWidget(QWidget):
    """Professional VU Meter Widget.
    
    Displays stereo audio levels with:
    - Green zone: 0 to -6dB (0.0 to 0.5)
    - Yellow zone: -6dB to -3dB (0.5 to 0.7)
    - Orange zone: -3dB to -1dB (0.7 to 0.9)
    - Red zone: -1dB to 0dB (0.9 to 1.0)
    - Peak hold markers
    """
    
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        
        # Size
        self.setFixedWidth(40)  # Wide enough for L/R channels
        self.setMinimumHeight(80)
        
        # Levels (0.0 to 1.0)
        self._level_l = 0.0
        self._level_r = 0.0
        
        # Peak hold
        self._peak_l = 0.0
        self._peak_r = 0.0
        self._peak_hold_time_l = 0
        self._peak_hold_time_r = 0
        
        # Decay parameters
        self._decay_rate = 0.95  # Multiplier per frame
        self._peak_hold_frames = 30  # Hold peak for ~1.5 seconds at 20 FPS
        
        # Style
        self._bg_color = QColor(20, 20, 20)
        self._border_color = QColor(60, 60, 60)
        
    def set_levels(self, l: float, r: float) -> None:
        """Update meter levels (0.0 to 1.0).
        
        Args:
            l: Left channel level (linear, 0.0 to 1.0)
            r: Right channel level (linear, 0.0 to 1.0)
        """
        # Clamp to valid range
        l = max(0.0, min(1.0, float(l)))
        r = max(0.0, min(1.0, float(r)))
        
        # Update levels
        self._level_l = l
        self._level_r = r
        
        # Update peaks
        if l > self._peak_l:
            self._peak_l = l
            self._peak_hold_time_l = self._peak_hold_frames
        else:
            if self._peak_hold_time_l > 0:
                self._peak_hold_time_l -= 1
            else:
                self._peak_l *= self._decay_rate
        
        if r > self._peak_r:
            self._peak_r = r
            self._peak_hold_time_r = self._peak_hold_frames
        else:
            if self._peak_hold_time_r > 0:
                self._peak_hold_time_r -= 1
            else:
                self._peak_r *= self._decay_rate
        
        # Trigger repaint
        self.update()
    
    def reset(self) -> None:
        """Reset all levels to zero."""
        self._level_l = 0.0
        self._level_r = 0.0
        self._peak_l = 0.0
        self._peak_r = 0.0
        self._peak_hold_time_l = 0
        self._peak_hold_time_r = 0
        self.update()
    
    def paintEvent(self, event) -> None:  # noqa: ANN001
        """Draw the VU meter."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Background
        painter.fillRect(self.rect(), self._bg_color)
        
        # Dimensions
        w = self.width()
        h = self.height()
        
        # Channel width (with 2px spacing in middle)
        channel_w = (w - 6) // 2  # 2px margin on each side + 2px middle spacing
        margin = 2
        spacing = 2
        
        # Left channel rect
        left_rect = QRectF(margin, margin, channel_w, h - 2 * margin)
        
        # Right channel rect
        right_rect = QRectF(margin + channel_w + spacing, margin, channel_w, h - 2 * margin)
        
        # Draw channels
        self._draw_channel(painter, left_rect, self._level_l, self._peak_l)
        self._draw_channel(painter, right_rect, self._level_r, self._peak_r)
        
        # Border
        painter.setPen(QPen(self._border_color, 1))
        painter.drawRect(self.rect().adjusted(0, 0, -1, -1))
    
    def _draw_channel(self, painter: QPainter, rect: QRectF, level: float, peak: float) -> None:
        """Draw a single channel meter."""
        # Background (dark gray)
        painter.fillRect(rect, QColor(30, 30, 30))
        
        # Calculate level height
        level_h = rect.height() * level
        
        # Draw level bar (from bottom up)
        if level_h > 0:
            level_rect = QRectF(
                rect.left(),
                rect.bottom() - level_h,
                rect.width(),
                level_h
            )
            
            # Gradient based on level
            gradient = QLinearGradient(
                rect.left(), rect.bottom(),
                rect.left(), rect.top()
            )
            
            # Color zones (from bottom to top)
            # Green: 0 to 0.5 (0dB to -6dB)
            # Yellow: 0.5 to 0.7 (-6dB to -3dB)
            # Orange: 0.7 to 0.9 (-3dB to -1dB)
            # Red: 0.9 to 1.0 (-1dB to 0dB)
            
            gradient.setColorAt(0.0, QColor(0, 200, 0))      # Green at bottom
            gradient.setColorAt(0.5, QColor(0, 200, 0))      # Green
            gradient.setColorAt(0.7, QColor(220, 220, 0))    # Yellow
            gradient.setColorAt(0.9, QColor(255, 140, 0))    # Orange
            gradient.setColorAt(1.0, QColor(255, 0, 0))      # Red at top
            
            painter.fillRect(level_rect, QBrush(gradient))
        
        # Draw peak hold marker
        if peak > 0.01:
            peak_y = rect.bottom() - (rect.height() * peak)
            
            # Peak color based on level
            if peak > 0.9:
                peak_color = QColor(255, 0, 0)      # Red
            elif peak > 0.7:
                peak_color = QColor(255, 140, 0)    # Orange
            elif peak > 0.5:
                peak_color = QColor(220, 220, 0)    # Yellow
            else:
                peak_color = QColor(0, 255, 0)      # Green
            
            painter.setPen(QPen(peak_color, 2))
            painter.drawLine(
                int(rect.left()),
                int(peak_y),
                int(rect.right()),
                int(peak_y)
            )
        
        # dB reference marks (optional - subtle)
        painter.setPen(QPen(QColor(80, 80, 80), 1))
        
        # -3dB mark (0.7)
        y_3db = rect.bottom() - (rect.height() * 0.7)
        painter.drawLine(
            int(rect.left()), int(y_3db),
            int(rect.left() + 3), int(y_3db)
        )
        
        # -6dB mark (0.5)
        y_6db = rect.bottom() - (rect.height() * 0.5)
        painter.drawLine(
            int(rect.left()), int(y_6db),
            int(rect.left() + 3), int(y_6db)
        )


class VUMeterWithLabel(QWidget):
    """VU Meter with optional label (L/R or track name)."""
    
    def __init__(self, label: str = "", parent: QWidget | None = None):
        super().__init__(parent)
        
        from PyQt6.QtWidgets import QVBoxLayout, QLabel
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        
        if label:
            lbl = QLabel(label)
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lbl.setStyleSheet("font-size: 9px; color: #888;")
            layout.addWidget(lbl)
        
        self.meter = VUMeterWidget()
        layout.addWidget(self.meter, 1)
    
    def set_levels(self, l: float, r: float) -> None:
        self.meter.set_levels(l, r)
    
    def reset(self) -> None:
        self.meter.reset()


# Quick test
if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication, QMainWindow, QHBoxLayout, QWidget
    from PyQt6.QtCore import QTimer
    import random
    
    app = QApplication(sys.argv)
    
    window = QMainWindow()
    window.setWindowTitle("VU Meter Test")
    
    central = QWidget()
    layout = QHBoxLayout(central)
    
    # Create 4 meters
    meters = []
    for i in range(4):
        meter = VUMeterWithLabel(f"T{i+1}")
        layout.addWidget(meter)
        meters.append(meter)
    
    window.setCentralWidget(central)
    window.resize(200, 300)
    window.show()
    
    # Animate with random levels
    def update_meters():
        for meter in meters:
            l = random.random() * 0.8
            r = random.random() * 0.8
            meter.set_levels(l, r)
    
    timer = QTimer()
    timer.timeout.connect(update_meters)
    timer.start(50)  # 20 FPS
    
    sys.exit(app.exec())
