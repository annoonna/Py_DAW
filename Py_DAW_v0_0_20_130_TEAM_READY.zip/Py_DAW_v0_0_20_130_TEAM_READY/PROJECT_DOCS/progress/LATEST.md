v0.0.20.130
- DevicePanel Header: ?-Kurzhilfe/Popover direkt im UI ergänzt (Batch-Icons, Esc-Reset, Collapse-Hinweise), UI-only
