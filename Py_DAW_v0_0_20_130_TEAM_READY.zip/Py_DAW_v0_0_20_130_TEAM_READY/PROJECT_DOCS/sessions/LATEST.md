v0.0.20.130
- DevicePanel: kompakter ?-Button mit Mini-Legende/Popover direkt im Header (Batch-Icons/Fokus/Reset/Collapse), UI-only
