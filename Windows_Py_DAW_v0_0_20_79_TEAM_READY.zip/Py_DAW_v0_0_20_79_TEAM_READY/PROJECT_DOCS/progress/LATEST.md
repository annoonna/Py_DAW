v0.0.20.72

- Help: Arbeitsmappe Dialog finalisiert (Tabs + Ordner/Datei öffnen + robustes Session-Resolve).
- Sampler/DrumMachine: Sample-Persistenz über media/ + Restore
- Fix: Sampler lädt Sample wieder in Engine (Ton)
- Snapshot-Load: media-Pfade werden aufgelöst

- Fix: PyQt6 SIGABRT bei Drag&Drop / QAction (Unhandled Python exception) — defensive try/except in Qt Overrides + _wire_actions über _safe_call.

Nächster Schritt: Re-test Drag&Drop (Samples/Clips/Devices) + Menü-Aktionen (kein SIGABRT mehr) + ggf. Sample-Rate Edge-Cases (44100/48000).
