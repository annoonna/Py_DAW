"""sounddevice (PortAudio) helpers.

Goal:
- Provide stable device selection across platforms.
- On Windows: prefer WASAPI (and optionally exclusive mode).

Env variables:
- PYDAW_SD_HOSTAPI: prefer host API (e.g. 'wasapi', 'asio', 'directsound', 'mme')
- PYDAW_WASAPI_EXCLUSIVE: '1' enables exclusive mode (WASAPI only)
- PYDAW_SD_DEVICE_OUT / PYDAW_SD_DEVICE_IN: explicit device index override
"""

from __future__ import annotations

import os
import platform
from typing import Optional, Tuple


def _is_windows() -> bool:
    try:
        return platform.system().lower() == "windows"
    except Exception:
        return False


def _pref_hostapis() -> list[str]:
    env = str(os.environ.get("PYDAW_SD_HOSTAPI", "")).strip().lower()
    if env:
        return [env]
    if _is_windows():
        return ["wasapi", "asio", "directsound", "mme"]
    return []


def _pick_from_hostapi(kind: str, *, hostapis: list[dict], devices: list[dict], token: str) -> Tuple[Optional[int], Optional[str]]:
    token = (token or "").strip().lower()
    if not token:
        return None, None

    # hostapi name typically: "Windows WASAPI", "Windows DirectSound", ...
    for h in hostapis:
        try:
            hname = str(h.get("name", "")).strip().lower()
        except Exception:
            continue
        if token not in hname:
            continue

        key = "default_output_device" if kind == "output" else "default_input_device"
        try:
            dflt = int(h.get(key, -1))
        except Exception:
            dflt = -1

        if dflt is not None and dflt >= 0:
            return dflt, hname

        # fallback: first device in that hostapi with channels
        try:
            idxs = list(h.get("devices", []) or [])
        except Exception:
            idxs = []
        for di in idxs:
            try:
                di = int(di)
                d = devices[di]
                if kind == "output" and int(d.get("max_output_channels", 0)) > 0:
                    return di, hname
                if kind == "input" and int(d.get("max_input_channels", 0)) > 0:
                    return di, hname
            except Exception:
                continue

    return None, None


def pick_device(kind: str) -> Tuple[Optional[int], Optional[str]]:
    """Return (device_index, hostapi_name) for kind in {'output','input'}.

    Returns (None, None) if no explicit preference can be resolved.
    """
    kind = "output" if str(kind).lower().startswith("out") else "input"

    # Explicit override
    override_key = "PYDAW_SD_DEVICE_OUT" if kind == "output" else "PYDAW_SD_DEVICE_IN"
    ov = str(os.environ.get(override_key, "")).strip()
    if ov:
        try:
            return int(ov), None
        except Exception:
            pass

    try:
        import sounddevice as sd  # type: ignore
        hostapis = list(sd.query_hostapis() or [])
        devices = list(sd.query_devices() or [])
    except Exception:
        return None, None

    # Try preferred hostapis
    for token in _pref_hostapis():
        dev, hname = _pick_from_hostapi(kind, hostapis=hostapis, devices=devices, token=token)
        if dev is not None:
            return dev, hname

    return None, None



def hostapi_name_for_device(device_index: int | None) -> str | None:
    """Return host API name (lowered) for a given device index."""
    if device_index is None:
        return None
    try:
        import sounddevice as sd  # type: ignore
        d = sd.query_devices(int(device_index))
        hi = int(d.get("hostapi", -1))
        if hi < 0:
            return None
        h = sd.query_hostapis(hi)
        return str(h.get("name", "")).strip().lower()
    except Exception:
        return None

def make_extra_settings(hostapi_name: Optional[str]) -> object | None:
    """Return PortAudio 'extra_settings' for the chosen host API (if any)."""
    # WASAPI exclusive mode (optional)
    try:
        if not hostapi_name:
            return None
        hn = str(hostapi_name).lower()
        if "wasapi" not in hn:
            return None
        if str(os.environ.get("PYDAW_WASAPI_EXCLUSIVE", "0")).strip() not in ("1", "true", "yes", "on"):
            return None
        import sounddevice as sd  # type: ignore
        if hasattr(sd, "WasapiSettings"):
            return sd.WasapiSettings(exclusive=True)  # type: ignore
    except Exception:
        return None
    return None
