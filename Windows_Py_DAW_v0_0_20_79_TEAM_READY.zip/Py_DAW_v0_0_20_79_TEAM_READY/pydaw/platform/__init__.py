# platform helpers (Windows/Linux)
