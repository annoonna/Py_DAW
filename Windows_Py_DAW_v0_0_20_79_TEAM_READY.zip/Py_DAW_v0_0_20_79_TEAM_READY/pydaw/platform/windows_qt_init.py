"""Windows Qt initialization (must run BEFORE importing PyQt6).

Why:
- On Windows, forcing ANGLE (Direct3D) often avoids OpenGL driver issues and
  random crashes (especially on older GPUs / VM setups).
- We also set sensible defaults for audio host API (WASAPI) used via PortAudio.

Env overrides:
- PYDAW_QT_OPENGL: 'angle' (default), 'desktop', 'software'
- PYDAW_QT_ANGLE_PLATFORM: 'd3d11' (default), 'd3d9', 'warp'
- PYDAW_SD_HOSTAPI: 'wasapi' (default on Windows), or 'asio'/'directsound'/'mme'
- PYDAW_WASAPI_EXCLUSIVE: '1' to enable exclusive mode (lower latency, but can
  break other system audio while running)
"""

from __future__ import annotations

import os
import platform


def configure_windows_qt() -> None:
    if platform.system().lower() != "windows":
        return

    # --- Qt / Rendering defaults
    qt_opengl = str(os.environ.get("PYDAW_QT_OPENGL", "")).strip().lower()
    if not qt_opengl:
        qt_opengl = "angle"  # safest default on Windows

    # Qt6: QT_OPENGL influences the OpenGL implementation choice.
    # 'angle' routes via Direct3D; 'desktop' uses native OpenGL.
    os.environ.setdefault("QT_OPENGL", qt_opengl)

    if qt_opengl == "angle":
        # Prefer D3D11 (good driver coverage). WARP is a software fallback.
        angle_platform = str(os.environ.get("PYDAW_QT_ANGLE_PLATFORM", "")).strip().lower() or "d3d11"
        os.environ.setdefault("QT_ANGLE_PLATFORM", angle_platform)

    # --- Audio defaults (PortAudio via sounddevice)
    os.environ.setdefault("PYDAW_SD_HOSTAPI", "wasapi")
