# -*- coding: utf-8 -*-
"""Plugin namespace for PyDAW/ChronoScaleStudio.

Plugins are optional UI+DSP modules loaded by panels such as DevicePanel.
"""
