"""Recording service for PipeWire and JACK audio backends.

Handles audio recording from system inputs through PipeWire or JACK.
"""

from __future__ import annotations

import os
import queue
import threading
import wave
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    pass


class RecordingService:
    """Service for recording audio through PipeWire/JACK.
    
    Supports:
    - PipeWire native recording
    - JACK recording (via python-jack-client or pw-jack)
    - Sounddevice fallback
    """
    
    def __init__(self):
        self._recording = False
        self._record_thread: threading.Thread | None = None
        self._audio_queue: queue.Queue = queue.Queue()
        self._backend = "sounddevice"  # default
        self._sample_rate = 48000
        self._channels = 2
        self._output_path: Path | None = None
        self._recorded_frames: list[np.ndarray] = []
        
        # Detect available backends
        self._detect_backend()
    
    def _detect_backend(self) -> None:
        """Detect which audio backend is available."""
        # Check for JACK
        try:
            import jack
            self._backend = "jack"
            return
        except ImportError:
            pass
        
        # Check for PipeWire via sounddevice
        try:
            import sounddevice as sd
            # PipeWire should show up in device list
            devices = sd.query_devices()
            for dev in devices:
                if dev.get('name', '').lower().find('pipewire') >= 0:
                    self._backend = "pipewire"
                    return
        except Exception:
            pass
        
        # Fallback to sounddevice
        self._backend = "sounddevice"
    
    def get_backend(self) -> str:
        """Get current recording backend."""
        return self._backend
    
    def is_recording(self) -> bool:
        """Check if currently recording."""
        return self._recording
    
    def start_recording(self, output_path: str | Path, sample_rate: int = 48000, channels: int = 2) -> bool:
        """Start recording audio.
        
        Args:
            output_path: Path where to save the WAV file
            sample_rate: Sample rate in Hz
            channels: Number of audio channels
            
        Returns:
            True if recording started successfully
        """
        if self._recording:
            return False
        
        self._output_path = Path(output_path)
        self._sample_rate = sample_rate
        self._channels = channels
        self._recorded_frames = []
        
        # Start recording thread based on backend
        if self._backend == "jack":
            success = self._start_jack_recording()
        elif self._backend == "pipewire":
            success = self._start_pipewire_recording()
        else:
            success = self._start_sounddevice_recording()
        
        if success:
            self._recording = True
        
        return success
    
    def stop_recording(self) -> Path | None:
        """Stop recording and save the audio file.
        
        Returns:
            Path to the saved file, or None if recording failed
        """
        if not self._recording:
            return None
        
        self._recording = False
        
        # Wait for recording thread to finish
        if self._record_thread and self._record_thread.is_alive():
            self._record_thread.join(timeout=2.0)
        
        # Save recorded audio to WAV file
        if self._recorded_frames and self._output_path:
            try:
                return self._save_wav()
            except Exception as e:
                print(f"Error saving recording: {e}")
                return None
        
        return None
    
    def _start_jack_recording(self) -> bool:
        """Start JACK recording."""
        try:
            import jack
            
            def record_callback(frames):
                if not self._recording:
                    raise jack.CallbackExit
                # Store audio frames
                self._recorded_frames.append(frames.copy())
            
            self._jack_client = jack.Client("PyDAW_Recorder")
            self._jack_client.set_process_callback(record_callback)
            
            # Create input ports
            self._jack_ports = []
            for i in range(self._channels):
                port = self._jack_client.inports.register(f"input_{i+1}")
                self._jack_ports.append(port)
            
            # Start JACK client
            self._jack_client.activate()
            
            # Auto-connect to system capture ports
            capture_ports = self._jack_client.get_ports(
                is_physical=True, is_output=True, is_audio=True
            )
            for i, port in enumerate(self._jack_ports):
                if i < len(capture_ports):
                    self._jack_client.connect(capture_ports[i], port)
            
            return True
            
        except Exception as e:
            print(f"JACK recording failed: {e}")
            return False
    
    def _start_pipewire_recording(self) -> bool:
        """Start PipeWire recording via sounddevice."""
        return self._start_sounddevice_recording()
    
    def _start_sounddevice_recording(self) -> bool:
        """Start sounddevice recording (works with PipeWire too)."""
        try:
            import sounddevice as sd
            
            def audio_callback(indata, frames, time, status):
                if status:
                    print(f"Recording status: {status}")
                if self._recording:
                    self._recorded_frames.append(indata.copy())
            
            # Windows-friendly device selection (prefer WASAPI)
            device = None
            extra_settings = None
            try:
                from pydaw.utils.sounddevice_config import pick_device, make_extra_settings
                picked, hostapi_name = pick_device("input")
                if picked is not None:
                    device = int(picked)
                extra_settings = make_extra_settings(hostapi_name)
            except Exception:
                device = None
                extra_settings = None

            # Start recording stream
            self._sd_stream = sd.InputStream(
                samplerate=self._sample_rate,
                channels=self._channels,
                device=device,
                extra_settings=extra_settings,
                callback=audio_callback,
                dtype='float32'
            )
            self._sd_stream.start()
            
            return True
            
        except Exception as e:
            print(f"Sounddevice recording failed: {e}")
            return False
    
    def _save_wav(self) -> Path:
        """Save recorded frames to WAV file."""
        if not self._output_path:
            raise ValueError("No output path set")
        
        # Ensure parent directory exists
        self._output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Concatenate all recorded frames
        audio_data = np.concatenate(self._recorded_frames, axis=0)
        
        # Convert float32 to int16 for WAV
        audio_int16 = (audio_data * 32767).astype(np.int16)
        
        # Save as WAV
        with wave.open(str(self._output_path), 'wb') as wf:
            wf.setnchannels(self._channels)
            wf.setsampwidth(2)  # 16-bit
            wf.setframerate(self._sample_rate)
            wf.writeframes(audio_int16.tobytes())
        
        return self._output_path
    
    def cleanup(self) -> None:
        """Clean up resources."""
        if self._recording:
            self.stop_recording()
        
        # Close JACK client if active
        if hasattr(self, '_jack_client'):
            try:
                self._jack_client.deactivate()
                self._jack_client.close()
            except Exception:
                pass
        
        # Close sounddevice stream if active
        if hasattr(self, '_sd_stream'):
            try:
                self._sd_stream.stop()
                self._sd_stream.close()
            except Exception:
                pass
