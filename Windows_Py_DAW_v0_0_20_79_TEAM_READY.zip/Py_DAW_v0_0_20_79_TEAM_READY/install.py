"""Installer helper for ChronoScaleStudio / Py_DAW (Windows-first).

Run:
    python install.py

It will:
- warn if you're not inside a virtual environment
- upgrade pip/setuptools/wheel
- install requirements.txt

Windows notes:
- Qt: this ZIP forces ANGLE (Direct3D) by default to avoid OpenGL driver issues.
- Audio: sounddevice (PortAudio) prefers WASAPI automatically.
- Optional (low latency): set PYDAW_WASAPI_EXCLUSIVE=1

FluidSynth (SF2 offline render):
- If you want SF2 rendering via the `fluidsynth` binary, install FluidSynth and make
  sure `fluidsynth.exe` is on PATH, or set:
      FLUIDSYNTH_PATH=C:\\path\\to\\fluidsynth.exe
"""

from __future__ import annotations

import os
import platform
import subprocess
import sys
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def _venv_hint() -> str:
    if platform.system().lower() == "windows":
        return "py -m venv .venv && .venv\\Scripts\\activate"
    return "python3 -m venv .venv && source .venv/bin/activate"


def main() -> int:
    here = Path(__file__).resolve().parent
    req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        print("      Empfehlung:", _venv_hint())

    py = sys.executable

    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    _run([py, "-m", "pip", "install", "-r", str(req)])

    print("\nOK. Start:")
    if platform.system().lower() == "windows":
        print("  python main.py")
        print("\nTipps:")
        print("  - Anderen Audio-HostAPI testen: set PYDAW_SD_HOSTAPI=asio (oder wasapi/directsound/mme)")
        print("  - Low latency (WASAPI): set PYDAW_WASAPI_EXCLUSIVE=1")
        print("  - FluidSynth (SF2 render): set FLUIDSYNTH_PATH=C:\\...\\fluidsynth.exe")
    else:
        print("  python3 main.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
