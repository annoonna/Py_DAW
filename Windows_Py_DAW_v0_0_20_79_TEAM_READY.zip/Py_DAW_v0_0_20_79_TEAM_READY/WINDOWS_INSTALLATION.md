# Windows Setup (ChronoScaleStudio / Py_DAW)

Diese ZIP ist **Windows-first** vorbereitet.

## 1) Python + Virtualenv
Empfohlen: Python 3.13 (oder 3.12 falls du Probleme mit Wheels hast).

```bat
cd Py_DAW_v0_0_20_79_TEAM_READY
py -m venv .venv
.venv\Scripts\activate
python install.py
python main.py
```

## 2) Rendering (Qt / ANGLE)
Standard in dieser ZIP:
- `QT_OPENGL=angle` (Direct3D via ANGLE)

Override (falls du testen willst):
```bat
set PYDAW_QT_OPENGL=desktop
python main.py
```

## 3) Audio (sounddevice / PortAudio)
Standard:
- bevorzugt **WASAPI** (PYDAW_SD_HOSTAPI=wasapi)

Optional:
- Low latency (WASAPI exclusive):
```bat
set PYDAW_WASAPI_EXCLUSIVE=1
python main.py
```

Andere Host-APIs testen:
```bat
set PYDAW_SD_HOSTAPI=asio
python main.py
```

## 4) SF2 / FluidSynth (MIDI→Audio Render)
Für SF2 Offline-Rendering nutzt Py_DAW das `fluidsynth` Binary.
Option A: `fluidsynth.exe` in PATH
Option B: Pfad setzen:

```bat
set FLUIDSYNTH_PATH=C:\\Path\\to\\fluidsynth.exe
```

Hinweis: Alternativ kann `pyfluidsynth` genutzt werden (optional), aber das
Binary ist aktuell der robusteste Weg fürs Rendern.

## 5) Troubleshooting
- Kein Sound: anderes Output Device/HostAPI testen (WASAPI/DirectSound/MME/ASIO).
- Knacksen: Buffer erhöhen (z.B. 512/1024), Exclusive deaktivieren.
- Rendering Crash: `PYDAW_QT_OPENGL=desktop` oder `PYDAW_QT_OPENGL=software` testen.
