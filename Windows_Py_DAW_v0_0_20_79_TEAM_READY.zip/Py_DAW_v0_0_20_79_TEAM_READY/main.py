"""Entry point for Py DAW."""
import faulthandler
import signal
faulthandler.enable(all_threads=True)
try:
    faulthandler.register(signal.SIGABRT, all_threads=True)
except Exception:
    pass

# --- Windows early init (must happen BEFORE importing PyQt6)
try:
    import platform
    if platform.system().lower() == "windows":
        from pydaw.platform.windows_qt_init import configure_windows_qt
        configure_windows_qt()
except Exception:
    pass

# --- Graphics backend selection (must happen BEFORE importing PyQt6)
# Linux default: Vulkan (when available). Override via:
#   PYDAW_GFX_BACKEND=opengl python3 main.py
try:
    from pydaw.utils.gfx_backend import configure_graphics_backend

    configure_graphics_backend()
except Exception:
    # Never block startup.
    pass

from pydaw.app import run

if __name__ == "__main__":
    run()