v0.0.20.130
- DevicePanel Header: ?-Kurzhilfe/Popover direkt im UI ergänzt (Batch-Icons, Esc-Reset, Collapse-Hinweise), UI-only

- 2026-02-22: Windows-Port Anpassungen für v0.0.20.132 → siehe `PROJECT_DOCS/sessions/2026-02-22_SESSION_v0.0.20.132_WINDOWS_PORT.md`
