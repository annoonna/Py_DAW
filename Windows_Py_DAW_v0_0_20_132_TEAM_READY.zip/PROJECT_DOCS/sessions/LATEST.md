v0.0.20.130
- DevicePanel: kompakter ?-Button mit Mini-Legende/Popover direkt im Header (Batch-Icons/Fokus/Reset/Collapse), UI-only

- 2026-02-22: Windows-Port Anpassungen für v0.0.20.132 → siehe `PROJECT_DOCS/sessions/2026-02-22_SESSION_v0.0.20.132_WINDOWS_PORT.md`
