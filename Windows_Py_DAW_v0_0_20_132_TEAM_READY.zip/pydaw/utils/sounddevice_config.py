"""sounddevice / PortAudio helper utilities with Windows-friendly defaults."""

from __future__ import annotations

import os
import platform
from typing import Any, Optional


def is_windows() -> bool:
    try:
        return platform.system().lower() == "windows"
    except Exception:
        return False


def preferred_hostapi_env() -> str:
    default = "wasapi" if is_windows() else ""
    return str(os.environ.get("PYDAW_SD_HOSTAPI", default)).strip().lower()


def _hostapi_name(sd: Any, hostapi_index: Any) -> str:
    try:
        idx = int(hostapi_index)
        info = sd.query_hostapis(idx)
        return str(info.get("name", "")).strip().lower()
    except Exception:
        return ""


def _device_hostapi_name(sd: Any, dev: Any) -> str:
    try:
        return _hostapi_name(sd, dev.get("hostapi"))
    except Exception:
        return ""


def _matches_hostapi(name: str, preferred: str) -> bool:
    if not preferred:
        return True
    name = (name or "").lower()
    preferred = preferred.lower()
    aliases = {
        "wasapi": ["wasapi", "windows wasapi"],
        "asio": ["asio"],
        "directsound": ["directsound", "direct sound"],
        "mme": ["mme", "windows mme"],
        "wdm-ks": ["wdm-ks", "wdm ks"],
    }.get(preferred, [preferred])
    return any(a in name for a in aliases)


def choose_output_device(sd: Any, configured_device: Any = None) -> Any:
    if configured_device not in (None, "", "None"):
        return int(configured_device)
    preferred = preferred_hostapi_env()
    try:
        devs = sd.query_devices()
    except Exception:
        return None
    best_any = None
    for idx, dev in enumerate(devs):
        try:
            if int(dev.get("max_output_channels", 0) or 0) < 1:
                continue
            name = _device_hostapi_name(sd, dev)
            if best_any is None:
                best_any = idx
            if _matches_hostapi(name, preferred):
                return idx
        except Exception:
            continue
    return best_any


def choose_input_device(sd: Any, configured_device: Any = None) -> Any:
    if configured_device not in (None, "", "None"):
        return int(configured_device)
    preferred = preferred_hostapi_env()
    try:
        devs = sd.query_devices()
    except Exception:
        return None
    best_any = None
    for idx, dev in enumerate(devs):
        try:
            if int(dev.get("max_input_channels", 0) or 0) < 1:
                continue
            name = _device_hostapi_name(sd, dev)
            if best_any is None:
                best_any = idx
            if _matches_hostapi(name, preferred):
                return idx
        except Exception:
            continue
    return best_any


def stream_extra_settings(sd: Any, *, input_stream: bool = False):
    """Return PortAudio extra_settings for WASAPI exclusive mode if requested."""
    if not is_windows():
        return None
    if str(os.environ.get("PYDAW_WASAPI_EXCLUSIVE", "0")).strip().lower() not in ("1", "true", "yes", "on"):
        return None
    try:
        WasapiSettings = getattr(sd, "WasapiSettings", None)
        if WasapiSettings is None:
            return None
        return WasapiSettings(exclusive=True)
    except Exception:
        return None
