"""Windows Qt startup defaults (safe ANGLE/D3D11).

Must be imported/called BEFORE importing PyQt6 modules.
"""

from __future__ import annotations

import os
import platform


def is_windows() -> bool:
    try:
        return platform.system().lower() == "windows"
    except Exception:
        return False


def configure_windows_qt_defaults() -> bool:
    """Set safe Qt rendering env defaults on Windows.

    Returns True when settings were applied (Windows), otherwise False.
    Users can override by setting env vars explicitly before startup.
    """
    if not is_windows():
        return False

    # QWidget + Qt Quick safe defaults for many Windows GPU/driver combinations
    os.environ.setdefault("QT_OPENGL", "angle")
    os.environ.setdefault("QT_ANGLE_PLATFORM", "d3d11")
    os.environ.setdefault("QSG_RHI_BACKEND", "d3d11")
    os.environ.setdefault("PYDAW_QT_OPENGL_EFFECTIVE", os.environ.get("QT_OPENGL", "angle"))
    return True
