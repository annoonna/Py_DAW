# Py_DAW Windows Installation (TEAM_READY)

Diese ZIP ist für Windows vorbereitet (Qt/ANGLE + WASAPI-Defaults).

## Schnellstart
1. Python 3.10-3.12 installieren (3.13 geht, aber numba/llvmlite sind optional/deaktiviert).
2. Im Projektordner öffnen (PowerShell oder CMD).
3. Virtuelle Umgebung:
   - `py -m venv .venv`
   - PowerShell: `.\.venv\Scripts\Activate.ps1`
   - CMD: `.venv\Scripts\activate.bat`
4. Installer starten:
   - `py install.py`
5. Start:
   - `py main.py`

## Audio (WASAPI)
Standardmäßig wird auf Windows `PYDAW_SD_HOSTAPI=wasapi` bevorzugt.

Optional:
- Exclusive Mode: `set PYDAW_WASAPI_EXCLUSIVE=1`
- Andere HostAPI: `set PYDAW_SD_HOSTAPI=asio` (oder `directsound`, `mme`)

## SF2 / FluidSynth
Für MIDI→Audio-Render sollte `fluidsynth.exe` verfügbar sein.

Möglichkeiten:
- `fluidsynth.exe` im PATH
- oder `FLUIDSYNTH_PATH` setzen

Beispiel:
- `set FLUIDSYNTH_PATH=C:\tools\fluidsynth\bin\fluidsynth.exe`

## Qt Rendering Fallback
Falls es Grafikprobleme gibt:
- `set QT_OPENGL=desktop`
- oder `set QT_OPENGL=software`
