"""Installer helper for Py_DAW (cross-platform, Windows-friendly).

Usage:
    python install.py

It will:
- warn if you're not inside a virtual environment
- install/upgrade pip basics
- install requirements (Windows uses requirements_windows.txt when present)
- print platform-specific post-install hints
"""

from __future__ import annotations

import os
import sys
import subprocess
import platform
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def _is_windows() -> bool:
    try:
        return platform.system().lower() == "windows"
    except Exception:
        return False


def _venv_hint() -> str:
    if _is_windows():
        return "py -m venv .venv && .\.venv\Scripts\activate"
    return "python3 -m venv .venv && source .venv/bin/activate"


def _print_post_install_hints() -> None:
    print()
    if _is_windows():
        print("OK. Start danach mit: py main.py  (oder: python main.py)")
        print("\nWindows Hinweise (Audio/Qt):")
        print("- Default Audio HostAPI ist WASAPI (automatisch gesetzt).")
        print("- Optional Exclusive Mode:  set PYDAW_WASAPI_EXCLUSIVE=1")
        print("- HostAPI wechseln:        set PYDAW_SD_HOSTAPI=asio  (oder wasapi/directsound/mme)")
        print("- Qt Rendering (Fallback): set PYDAW_QT_OPENGL=desktop  / set QT_OPENGL=desktop")
        print("\nSF2 / FluidSynth (optional aber empfohlen für MIDI→Audio Render):")
        print("- fluidsynth installieren (fluidsynth.exe im PATH)")
        print("- oder FLUIDSYNTH_PATH setzen, z. B.: set FLUIDSYNTH_PATH=C:\\tools\\fluidsynth\\bin\\fluidsynth.exe")
    else:
        print("OK. Starte danach mit: python3 main.py")
        print("Optional: Audio/MIDI Abhängigkeiten können Systempakete erfordern (PipeWire-JACK/JACK/qpwgraph).")


def main() -> int:
    here = Path(__file__).resolve().parent
    req_default = here / "requirements.txt"
    req_windows = here / "requirements_windows.txt"

    req = req_windows if (_is_windows() and req_windows.exists()) else req_default
    if not req.exists():
        print(f"{req.name} not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        print(f"      Empfehlung: {_venv_hint()}")

    py = sys.executable
    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    try:
        _run([py, "-m", "pip", "install", "-r", str(req)])
    except subprocess.CalledProcessError as exc:
        print("\nFEHLER beim Installieren der Python-Pakete.")
        print("Tipp: Prüfe Python-Version (3.10-3.12 empfohlen; 3.13 mit eingeschränktem numba/llvmlite-Support).")
        print("Installiertes requirements-File:", req.name)
        return int(exc.returncode or 1)

    _print_post_install_hints()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
