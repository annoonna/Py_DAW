# 🎭 GHOST NOTES - ANLEITUNG (FIX v0.0.19.3.7.19)

**Problem gelöst:** Dialog findet jetzt MIDI-Clips korrekt!

---

## 🐛 WAS WAR DAS PROBLEM?

**Symptom:** 
- Dialog zeigte "No MIDI clips available in project"
- Obwohl MIDI-Clips im Projekt vorhanden waren

**Ursache:**
- Dialog prüfte `hasattr(clip, 'midi_notes')` ❌
- MIDI-Clips haben aber `clip.kind == "midi"` ✅

**Fix:**
```python
# Vorher (falsch):
if not hasattr(clip, 'midi_notes'):
    continue

# Nachher (richtig):
clip_kind = str(getattr(clip, 'kind', '')).lower()
if clip_kind != 'midi':
    continue
```

---

## 🎯 WIE ES JETZT FUNKTIONIERT

### Schritt 1: MIDI-Clips erstellen
```
1. Erstelle 2-3 Instrument-Tracks
2. Füge MIDI-Clips hinzu (mit verschiedenen Noten)
3. Beispiel:
   - Track "Piano" → Clip mit Akkorden
   - Track "Bass" → Clip mit Basslinie
   - Track "Strings" → Clip mit langen Noten
```

### Schritt 2: Piano Roll öffnen
```
1. Doppelklick auf einen MIDI-Clip (z.B. Piano)
2. Piano Roll öffnet sich
3. Du siehst deine Noten
4. Am unteren Rand: "Ghost Layers" Panel
```

### Schritt 3: Ghost Layer hinzufügen
```
1. Im Ghost Layers Panel: Klicke "+ Add Layer"
2. Dialog öffnet sich: "Select MIDI Clip for Ghost Layer"
3. Du siehst ALLE MIDI-Clips aus dem Projekt:
   ✅ Bass / Bassline
   ✅ Strings / String Pad
   (Aktueller Clip "Piano" ist ausgefiltert)
4. Wähle einen Clip (z.B. "Bass / Bassline")
5. Klicke "Add as Ghost Layer"
```

### Schritt 4: Ergebnis
```
✅ Bass-Noten erscheinen TRANSPARENT im Piano Roll!
✅ Opacity: 30% (einstellbar)
✅ Farbe: Automatisch zugewiesen
✅ Lock: 🔒 (nur sichtbar, nicht editierbar)
✅ Piano-Noten bleiben normal (100% Opacity)
```

---

## 🎨 WIE IN Pro-DAW VS. PYDAW

### Pro-DAW
```
1. Rechtsklick → "Show layers from other clips"
2. Clips werden im Context-Menu angezeigt
3. Auswahl → Sofort sichtbar
```

### PyDAW (jetzt)
```
1. Klick "+ Add Layer" Button
2. Dialog mit Liste aller MIDI-Clips
3. Filter-Funktion (type to search)
4. Auswahl → Clip als Ghost Layer hinzugefügt
```

**Unterschied:**
- Pro-DAW: Rechtsklick Context-Menu
- PyDAW: Dedizierter Dialog + Layer Panel

**Vorteil PyDAW:**
- Bessere Übersicht über alle Clips
- Filter-Funktion
- Clip-Info (Note-Count, Length)
- Layer Management UI (Opacity, Color, Lock)

---

## 🎛️ LAYER PANEL CONTROLS

### Pro Layer:
```
✎  Focus Button    → Nur dieser Layer ist editierbar
👁  Visibility      → Layer zeigen/verstecken
🔒  Lock/Unlock     → Layer sperren/entsperren
🎨  Color Picker    → Layer-Farbe ändern
📊  Opacity Slider  → Transparenz einstellen (0-100%)
```

### Global:
```
+ Add Layer         → Neuen Ghost Layer hinzufügen
- Remove Layer      → Selektierten Layer entfernen
```

---

## 📝 WORKFLOW-BEISPIEL

**Szenario:** Bassline zu Akkorden schreiben

```
1. Erstelle Track "Chords" mit MIDI-Clip (Akkorde)
2. Erstelle Track "Bass" mit leerem MIDI-Clip
3. Öffne Piano Roll für "Bass" Clip
4. Klicke "+ Add Layer" im Ghost Layers Panel
5. Wähle "Chords" Clip aus Dialog
6. ✅ Akkorde erscheinen transparent im Bass Piano Roll!
7. Schreibe Basslinie passend zu den Akkorden
8. Fokus bleibt auf "Bass" Layer (✎)
9. Chords sind nur sichtbar, nicht editierbar (🔒)
```

**Resultat:** Du siehst die Akkorde transparent, während du die Bassline schreibst!

---

## 🔧 DEBUGGING (Falls Clips nicht erscheinen)

### Check 1: Sind es MIDI-Clips?
```python
# Im Python Terminal:
project = your_project_service.ctx.project
for clip in project.clips:
    print(f"Clip {clip.id}: kind={clip.kind}")
    
# Sollte zeigen: kind=midi für MIDI-Clips
```

### Check 2: Console Output
```bash
# Beim Öffnen des Dialogs sollte erscheinen:
[ClipSelectionDialog] Found 3 MIDI clips

# Falls 0 Clips:
[ClipSelectionDialog] Found 0 MIDI clips
# → Prüfe ob Clips wirklich kind="midi" haben
```

### Check 3: Tracks vorhanden?
```python
# Clips brauchen einen Track:
for clip in project.clips:
    track = next((t for t in project.tracks if t.id == clip.track_id), None)
    print(f"Clip {clip.id}: track={track.name if track else 'NONE'}")
```

---

## 🎉 WAS IST NEU IN v0.0.19.3.7.19?

### Fixes:
✅ MIDI-Clip Erkennung korrigiert (`kind == "midi"`)  
✅ Debug Output hinzugefügt  
✅ Besseres Error Handling  
✅ Verbesserter Info-Text im Dialog  
✅ Pro-DAW-ähnliche Beschreibung

### Status:
- Ghost Notes: 90% → 91% (Clip-Finder Fix)
- Nächster Schritt: Testing (GN-3)

---

## 📖 WEITERES

**Tutorial-Video (simuliert):**
```
1. Projekt öffnen
2. 2 MIDI-Clips erstellen
3. Piano Roll öffnen
4. "+ Add Layer" klicken
5. ✅ Dialog zeigt Clips!
6. Clip auswählen
7. ✅ Ghost Notes erscheinen!
```

**Siehe auch:**
- `INTEGRATION_KOMPLETT.md` - Vollständige Dokumentation
- `FEATURE_ZUSAMMENFASSUNG_DE.md` - Feature-Übersicht
- `TODO.md` - Was noch zu tun ist

---

**Problem gelöst! Der Dialog findet jetzt deine MIDI-Clips!** ✅
