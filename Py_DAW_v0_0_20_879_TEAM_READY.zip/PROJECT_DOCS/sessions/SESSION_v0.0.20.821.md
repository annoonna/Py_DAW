# Session Log — v0.0.20.821

**Datum:** 2026-03-26
**Kollege:** Claude Opus 4.6
**Basis:** v0.0.20.820
**Aufgabe:** CLAP Editor Freeze Fix (Staged GUI), Samplerate Init Fix

## Bestätigter Erfolg aus v0.0.20.820

- ✅ **Dexed VST2**: Lädt, spielt Audio, Editor öffnet
- ✅ **Surge XT VST3**: Deferred Main-Thread Load funktioniert
- ✅ **Surge XT CLAP**: Engine erstellt, 775 Parameter
- ✅ **Engine Reuse**: Funktioniert korrekt

## Was wurde erledigt

### CLAP Editor Freeze → Staged GUI Creation ✅

**Root Cause:** Native CLAP GUI-Calls blockieren den Qt Main-Thread.
JUCE-basierte Plugins (Surge XT) unter XWayland brauchen X11 Event-Loop
zwischen den GUI-Bootstrap-Schritten → Deadlock.

**Fix — 3-Stufen-Ansatz:**
- `gui_stage1_create()` → QTimer 50ms → `gui_stage2_set_parent()` → QTimer 50ms → `gui_stage3_show()`
- Zwischen den Stages läuft der Qt Event Loop → X11 Events werden verarbeitet
- Legacy-Fallback für Plugins ohne staged API

### Samplerate Init Fix ✅

`_load_pedalboard_plugin()`: reset=True zuerst, Fallback reset=False.

## Geänderte Dateien

- pydaw/audio/clap_host.py — 3 staged GUI methods + process_events Callback
- pydaw/ui/fx_device_widgets.py — Staged _open_editor_deferred + Legacy Fallback  
- pydaw/audio/vst3_host.py — SR reset=True/False Fallback
- VERSION → 0.0.20.821, pydaw/version.py → 0.0.20.821

## Nächste Schritte

- Anno: CLAP Editor testen (Surge XT) — Log zeigt Stage 1/2/3
