# Session Log — v0.0.20.857

**Datum:** 2026-03-28
**Kollege:** Claude Opus 4.6
**Basis:** v0.0.20.856
**Session-Umfang:** v0.0.20.856 → v0.0.20.857

## Erledigt

### v0.0.20.856 — Collab Module Complete Repair
- websockets v16 API fix (async with serve())
- Host-Chat Broadcast fix (broadcast_from_host())
- Sauberer Client-Disconnect (ws.close() vor loop.stop())
- Port-Einstellung, Passwort-Schutz, Disconnect-Button
- 13 E2E Tests bestanden

### v0.0.20.857 — Thread-Leak Fix (KRITISCH)
- **ROOT CAUSE:** Jeder Klick auf "Verbinden" startete neuen Thread, alte liefen mit Auto-Reconnect weiter
- `connect()` ruft jetzt `_stop_background()` auf → alter Thread wird IMMER gestoppt
- Auto-Reconnect nur nach erfolgreicher Erstverbindung (`_ever_connected` Flag)
- Reconnect-Sleep in 0.5s Intervallen unterbrechbar
- Panel: Button disabled waehrend Verbindungsversuch, alter Client immer erst cleanup
- 16 E2E Tests bestanden (inkl. T14-T16 Thread-Leak-Tests)

## Geaenderte Dateien
- pydaw/services/collab_service.py
- pydaw/ui/collab_panel.py

## Naechste Schritte
- LAN-Test: Session starten, von anderem Rechner verbinden
- Cursor-Sharing visuell im Arranger
- Weitere Operation-Typen synchronisieren
