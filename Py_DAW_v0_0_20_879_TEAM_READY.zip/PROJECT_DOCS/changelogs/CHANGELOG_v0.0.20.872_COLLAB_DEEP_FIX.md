# CHANGELOG v0.0.20.872 — Collaboration Deep Fix

**Datum:** 2026-03-28
**Autor:** Claude Opus 4.6

## Zusammenfassung

Tiefgreifende Bugfixes für die Echtzeit-Kollaboration. Betrifft BPM-Sync,
Playhead-Sync, Plugin-Instanziierung beim Remote, Loop-UI-Sync und
Audio-Clip-Transfer.

## Fixes

### 1. BPM-Sync bidirektional (ROOT CAUSE FIX)
- **Problem:** Wenn Host BPM auf 130 stellt, sieht Client weiterhin 120 (und umgekehrt)
- **Ursache:** `_on_remote_operation` → `transport_bpm` aktualisierte den TransportService,
  aber NICHT die TransportPanel UI-Spinbox
- **Fix:** `main_win.transport.set_bpm(bpm)` wird jetzt zusätzlich aufgerufen
  (blockSignals=True verhindert Echo-Loop)

### 2. Playhead (rote Linie) Sync — NEU
- **Problem:** Playhead-Position wurde nie synchronisiert (kein Protokoll dafür)
- **Lösung:** Neuer Op-Typ `transport_seek` im Collab-Protokoll:
  - `_on_local_playhead_changed()`: throttled ~8Hz Broadcasting (≥0.5 Beat Δ)
  - Seek-Klicks (nicht playing) werden sofort gesendet
  - Server-seitig als Passthrough registriert
  - Client-seitig via `transport.seek(beat)` angewendet

### 3. Plugin-Instanziierung beim Remote (ROOT CAUSE FIX)
- **Problem:** CLAP/VST3-Plugins (Nekobi, Dexed etc.) werden beim Remote nicht geladen
- **Ursache 1:** `rebuild_fx_maps()` hat eine Fingerprint-Cache (`_instrument_fingerprint`)
  die den Slow-Path (Plugin-Instanziierung) überspringt wenn sich der Fingerprint nicht ändert
- **Ursache 2:** `DevicePanel.show_track()` wurde nur aufgerufen wenn der Track gerade
  aktiv angezeigt wurde
- **Fix:** `_instrument_fingerprint = ""` vor jedem `rebuild_fx_maps()` in:
  - `_apply_remote_device_sync()` 
  - `_apply_remote_structural_op()` (track_add)
  - `_apply_full_sync()` (Late-Joiner)
- **Fix:** `show_track(tid)` wird jetzt IMMER aufgerufen (nicht nur when viewing)

### 4. Loop-Checkbox UI-Sync
- **Problem:** Loop-Checkbox im TransportPanel wurde bei Remote-Loop-Änderung nicht aktualisiert
- **Fix:** `chk_loop.setChecked()` mit blockSignals in `_on_remote_operation` → `transport_loop`

### 5. Audio-Clip Cooldown reduziert  
- **Problem:** Zweites Audio-Sample auf Audio-Spur wird nicht zum Remote übertragen
- **Ursache:** `OFFER_COOLDOWN_S = 30.0` in MediaSyncService blockiert wiederholte Offers
- **Fix:** Cooldown auf 3.0 Sekunden reduziert

### 6. Full-Sync (Late-Joiner) verbessert
- TransportPanel UI wird beim Full-Sync aktualisiert (BPM Spinbox)
- Engine-Fingerprint wird nach Full-Sync invalidiert → Plugins werden geladen

## Geänderte Dateien

| Datei | Änderung |
|-------|----------|
| `pydaw/ui/collab_panel.py` | BPM/Loop UI-Sync, Playhead-Sync, Plugin-Fingerprint-Fix, Full-Sync-Fix |
| `pydaw/services/collab_service.py` | `transport_seek` Passthrough im Server |
| `pydaw/services/media_sync_service.py` | Cooldown 30s → 3s |
| `pydaw/version.py` | → 0.0.20.872 |
| `VERSION` | → 0.0.20.872 |

## Bekannte verbleibende Einschränkungen

- Nekobi VST3 wird vom Plugin-Probe als "crashed" blacklisted (assertion failure in DPF);
  CLAP-Version von Nekobi funktioniert
- Built-in Instrumente (Bach Orgel, AETERNA etc.) werden nur geladen wenn das
  `instrument_state`-Dict korrekte Pfade enthält; bei Remote ist der Pfad ggf. ungültig
  → `request_instrument_samples` + MediaSync sollte das beheben
- Transport-Position-Sync hat ~125ms Latenz (8Hz throttling)
