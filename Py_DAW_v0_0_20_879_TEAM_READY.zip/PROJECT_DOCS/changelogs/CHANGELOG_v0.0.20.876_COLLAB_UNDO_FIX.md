# CHANGELOG v0.0.20.876 — Collab Undo/Redo Fix

**Datum:** 2026-03-29
**Kollege:** Claude Opus 4.6

## 🟠 FIX: Collab Undo/Redo — war komplett tot

### Root Cause (3 Probleme)
1. `_record_for_undo()` wurde **nirgendwo aufgerufen** — kein Op wurde jemals aufgezeichnet
2. `_on_collab_undo()` sendete den Inverse-Op nur ans Netzwerk, wendete ihn aber
   **lokal nicht an** — der Server excluded den Sender vom Broadcast, also sah
   der lokale Client seine eigene Undo-Aktion nie
3. Kein Value-Cache — ohne alte Werte kann kein Inverse-Op gebaut werden

### Fix
- **`_push_undo(op_payload, inverse_payload)`** — neuer Helper, akzeptiert
  direkt die Payloads statt CollabMessage
- **`_undo_mixer_cache`** — Value-Cache für Mixer-Werte (Volume/Pan/Mute/Solo),
  initialisiert beim Collab-Start aus dem Projektmodell
- **`send_mixer_change()`** — recordet jetzt Undo mit altem Wert aus Cache
- **`_on_collab_undo()`** — FIXED: wendet Inverse jetzt auch lokal an via
  `_apply_undo_redo_locally()` → `_on_remote_operation()` mit suppress flag
- **`_on_collab_redo()`** — FIXED: gleiches Problem behoben
- **`_init_undo_mixer_cache()`** — populiert Cache beim Collab-Start
- **`_cleanup_collab_state()`** — räumt Cache auf bei Disconnect

### Unterstützte Undo-Ops
- Mixer: Volume, Pan, Mute, Solo (pro Track)

### Betroffene Dateien
- `pydaw/ui/collab_panel.py` — Undo/Redo komplett überarbeitet
