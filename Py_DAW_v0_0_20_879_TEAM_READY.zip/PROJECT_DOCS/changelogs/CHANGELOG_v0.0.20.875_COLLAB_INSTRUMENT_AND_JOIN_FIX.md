# CHANGELOG v0.0.20.875 — Collab Instrument + Ctrl+J Fix

**Datum:** 2026-03-29
**Kollege:** Claude Opus 4.6

## 🔴 CRITICAL FIX: Instrumente bei Kollaboration

### Root Cause
Die Methode `set_instrument_on_track()` wurde in `collab_panel.py` an 4 Stellen
aufgerufen, **existierte aber nirgendwo im gesamten Projekt**. Alle Aufrufe waren
mit `hasattr()` geschützt und versagten deshalb **still und leise** — ohne jede
Fehlermeldung. Kein einziges Instrument (weder intern noch extern: Bach Orgel,
Pro Audio Sampler, Pro Drum Machine, VST2, VST3, CLAP, LV2, DSSI, LADSPA)
wurde jemals auf dem Remote-Client instanziiert.

### Fix
- **track_add Handler:** `set_instrument_on_track(tid, plugin_type)` →
  `show_track(tid)` — die tatsächlich existierende DevicePanel-Methode, die
  `_make_instrument_anchor_card()` → `_create_or_replace_instrument_widget()`
  triggert und damit Widget + Engine-Instanz erstellt.
- **full_sync Late-Joiner:** Gleicher Fix — Loop über alle Tracks mit plugin_type
  ruft jetzt `show_track(tid)` statt der nicht-existierenden Methode auf.
- Beide Stellen arbeiten zusammen mit dem bereits vorhandenen
  `ae._instrument_fingerprint = ""` + `ae.rebuild_fx_maps(proj)` für die
  Audio-Engine-Seite (VST3/CLAP/SF2 Engine-Instanzen).

### Betroffene Dateien
- `pydaw/ui/collab_panel.py` — 2 Fixes (track_add + full_sync)

---

## 🔴 CRITICAL FIX: Strg+J (Clip Join/Consolidate) bei Kollaboration

### Root Cause — MIDI Join
1. `add_midi_clip_at()` sendet `clip_add_midi` → leerer Clip auf Remote ✓
2. `add_midi_note()` × N hat **keinen Collab-Hook** ✗
3. `delete_clip()` × N sendet `clip_remove` → Originale gelöscht ✓
**Ergebnis:** Remote sieht leeren neuen Clip + gelöschte Originale = Clips "verschwinden"

### Fix — MIDI Join
- Nach dem Kopieren aller Noten wird jetzt explizit `midi_notes_sync` mit dem
  vollständigen Noten-Snapshot des neuen Clips gesendet.

### Root Cause — Audio Consolidate
1. `consolidate_audio_clips_bounce()` rendert Audio lokal
2. `proj.clips.append(newc)` hat **keinen Collab-Hook** ✗
3. `delete_clip()` × N sendet `clip_remove` → Originale gelöscht ✓
**Ergebnis:** Remote sieht nur Löschungen, der neue konsolidierte Clip fehlt

### Fix — Audio Consolidate
- Nach `proj.clips.append(newc)` wird jetzt `clip_add_audio` mit allen
  relevanten Clip-Eigenschaften (offset_beats, gain, pan, file_name) gesendet.
- Die gerenderte WAV wird via `_media_sync_hook` angeboten, damit der Remote
  die Datei herunterladen und abspielen kann.
- Der `clip_add_audio` Remote-Handler setzt jetzt auch `offset_beats`, `gain`
  und `pan` aus dem Payload (nötig für Consolidate-Clips mit Pre-Handle-Offset).

### Betroffene Dateien
- `pydaw/ui/arranger_keyboard.py` — MIDI Join Collab-Sync
- `pydaw/services/project_service.py` — Audio Consolidate Collab-Hook + MediaSync
- `pydaw/ui/collab_panel.py` — clip_add_audio Handler erweitert

---

## 🟠 NEU: Track-Verschieben bei Kollaboration

### Implementierung
- **Helper:** `_notify_track_reorder()` sendet die komplette Track-ID-Reihenfolge
- **Hooks in:** `move_track()`, `move_group_block()`, `move_tracks_block()`
- **Remote-Handler:** `_apply_remote_track_reorder()` — sortiert `proj.tracks` nach
  empfangener Reihenfolge
- **Server-Passthrough:** `track_reorder` in collab_service.py registriert

### Betroffene Dateien
- `pydaw/services/project_service.py` — 3 Hooks + Helper
- `pydaw/ui/collab_panel.py` — Router + Handler
- `pydaw/services/collab_service.py` — Passthrough

---

## 🟠 NEU: Track-Gruppieren/Entgruppieren bei Kollaboration

### Implementierung
- **group_tracks()** sendet `track_group` mit group_id, group_name, track_ids, order
- **ungroup_tracks()** sendet `track_ungroup` mit track_ids, order
- **Remote track_group:** Erstellt Group-Bus-Track mit gleicher ID, weist Kinder zu,
  sortiert nach empfangener Reihenfolge
- **Remote track_ungroup:** Entfernt Gruppenzuordnung, löscht leere Group-Tracks
- **Server-Passthrough:** `track_group` + `track_ungroup` registriert

### Betroffene Dateien
- `pydaw/services/project_service.py` — 2 Hooks
- `pydaw/ui/collab_panel.py` — Router + 2 Handler
- `pydaw/services/collab_service.py` — Passthrough

---

## ⚠️ OFFEN: Collab Undo/Redo

`_record_for_undo()` existiert, wird aber nirgendwo aufgerufen. Braucht
architektonische Arbeit: Vor jedem Remote-Op müssen die alten Werte gecaptured
werden, bevor sie überschrieben werden. → Eigene Session.

---

## 🟠 NEU: Alt+Drag Stretch (Content Scaling) bei Kollaboration

### Root Cause
- **MIDI:** Noten wurden via `midi_notes_sync` synchronisiert, aber die Clip-Längenänderung
  wurde nie gesendet → Remote sah den alten Clip-Rahmen mit neuen Noten-Positionen
- **Audio:** Weder `clip.length_beats` noch `clip.stretch` wurden synchronisiert →
  Remote sah gar nichts von der Stretch-Änderung

### Fix
- Nach dem Release von Alt+Drag wird jetzt `clip_scale` gesendet mit:
  `clip_id`, `start_beats`, `length_beats` und bei Audio zusätzlich `stretch`
- Remote-Handler `_apply_remote_clip_scale()` setzt alle Werte am Clip-Objekt
- Server-Passthrough für `clip_scale` in collab_service.py

### Betroffene Dateien
- `pydaw/ui/arranger_canvas.py` — Collab-Hook nach mouseRelease
- `pydaw/ui/collab_panel.py` — Router + Handler
- `pydaw/services/collab_service.py` — Passthrough
