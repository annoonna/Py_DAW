# CHANGELOG v0.0.20.877 — CRITICAL: Instrument Collab Attribut-Tippfehler

**Datum:** 2026-03-29
**Kollege:** Claude Opus 4.6

## 🔴 CRITICAL FIX: Instrumente bei Kollaboration — FALSCHER ATTRIBUTNAME

### Root Cause
In `collab_panel.py` wurde an **4 Stellen** `main_win._device_panel` (mit Unterstrich)
referenziert, aber in `main_window.py` heißt das Attribut `self.device_panel` (OHNE
Unterstrich). `hasattr(main_win, '_device_panel')` gab **immer False** zurück →
der komplette `if`-Block wurde übersprungen → `dp.show_track(tid)` wurde **NIE
aufgerufen** → kein Instrument-Widget wurde jemals auf dem Remote erstellt.

Gleiche Bug-Klasse wie die Ghost-Method `set_instrument_on_track()` in v875 —
alles mit `hasattr()` geschützt, versagt still und leise ohne Fehlermeldung.

### Betroffene Stellen (alle 4 gefixt)
1. **track_add Handler** (Zeile 1415-1416) — Instrument bei Track-Erstellung
2. **device_sync Handler** (Zeile 1678-1679) — Instrument bei Plugin-Änderung
3. **_on_instrument_sample_ready** (Zeile 2302) — Refresh nach Sample-Transfer
4. **full_sync Late-Joiner** (Zeile 2444-2445) — Instrumente bei Late-Join

### Fix
```
_device_panel → device_panel (4× in collab_panel.py)
```

### Betroffene Dateien
- `pydaw/ui/collab_panel.py` — 4 Attribut-Referenzen korrigiert

---

## 🔴 CRITICAL FIX: show_track() → add_instrument_to_track()

### Root Cause
`show_track()` wechselt die Ansicht im DevicePanel auf den angegebenen Track
und rendert ihn. Aber `_safe_render_current_track()` schluckt **alle**
Exceptions via `except Exception: return`. Wenn irgendwas schiefgeht
(Timing, Plugin-Registry nicht bereit, etc.) passiert einfach gar nichts.

### Fix
Alle 3 Stellen (track_add, device_sync, full_sync) verwenden jetzt
`dp.add_instrument_to_track(tid, plugin_type)` statt `dp.show_track(tid)`.

`add_instrument_to_track()` ist die korrekte API:
1. Validiert plugin_id in der Registry
2. Erstellt das Widget via `_create_or_replace_instrument_widget()`
3. Speichert es in `_track_instruments[tid]`
4. Emittiert `project_updated`

Das Widget wird im Hintergrund erstellt, unabhängig davon welchen Track
der User gerade betrachtet. Wenn der User dann auf den Track klickt,
ist das Widget schon bereit.

### Logging
Alle Instrumenten-Aktionen in der Kollaboration loggen jetzt auf INFO-Level:
- `[COLLAB] device_sync received: track=... plugin=...`
- `[COLLAB] add_instrument_to_track(...) → True/False`
- `[COLLAB] track_add instrument: ... → ...`
- `[COLLAB] full_sync instrument: ... → ...`
