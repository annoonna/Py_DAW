# CHANGELOG v0.0.20.874 — Collab Arranger Ops + Instrument Sync + VST3 Spam Fix

**Datum:** 2026-03-28
**Autor:** Claude Opus 4.6

## Zusammenfassung

Alle fehlenden Arranger-Operationen werden jetzt über Collab synchronisiert:
Clip Move, Resize, Trim, Rename, Content Scale, Ctrl+Drag Copy, Track Rename.
**Instrumente werden jetzt auf Remote-Seite instanziiert** — das größte offene
Collab-Problem. Nekobi VST3 Log-Spam gestoppt. MediaSync Hash-Dedup.

## CRITICAL FIX: Instrument-Instanziierung auf Remote (collab_panel.py)

**Root Cause:** Bei `track_add` wurden alle Model-Felder (plugin_type,
instrument_state, audio_fx_chain) korrekt gesetzt, aber KEIN Code rief
`set_instrument_on_track()` auf dem Remote auf. Das Ergebnis: Spuren
erschienen, aber ohne Instrument — "spuren ohne instrument".

**Fix:** Nach dem Setzen aller Model-Felder wird jetzt:
1. `dp.set_instrument_on_track(tid, plugin_type)` aufgerufen → erstellt
   Instrument-Widget UND Audio-Engine
2. `ae._instrument_fingerprint = ""` invalidiert → erzwingt Slow Path
3. `ae.rebuild_fx_maps()` aufgerufen → VST3/CLAP/SF2 Engines werden erstellt

**Gleicher Fix für Late-Joiner (full_sync):** Nach dem vollständigen
Projekt-Sync werden ALLE Tracks mit plugin_type durchlaufen und
`set_instrument_on_track()` für jeden aufgerufen.

## Neue Collab-Sync Hooks (project_service.py)

| Operation | Op-Type | Daten |
|-----------|---------|-------|
| Clip verschieben | `clip_move` | start_beats, track_id |
| Clip Resize rechts | `clip_resize` | length_beats |
| Clip Trim links | `clip_trim` | start_beats, length_beats, offset_beats, offset_seconds |
| Alt+Resize Content Scale | `midi_notes_sync` | Voller MIDI-Snapshot nach Skalierung |
| Track umbenennen | `track_name` | name |
| Clip umbenennen | `clip_rename` | label |
| Move Clip to Track | `clip_move` | track_id |

## Ctrl+Drag Batch Copy (arranger_canvas.py)

- Neuer Op-Type `clip_copy_batch` mit Array aller kopierten Clips
- Jeder Clip enthält: id, kind, track_id, start_beats, length_beats, label
- MIDI-Clips enthalten zusätzlich `midi_notes` Array
- Remote erstellt Clips mit gleicher ID für konsistente Referenzen

## Remote Handler (collab_panel.py)

- `_apply_remote_clip_trim()` — Left-Trim mit 4 Feldern
- `_apply_remote_clip_rename()` — Label-Update
- `_apply_remote_clip_copy_batch()` — Batch-Erstellung mit MIDI-Notes

## VST3 Nekobi Spam Fix (vst3_host.py)

- Process-Error-Counter mit Max 5 Logs pro Plugin-Instanz
- Nach 5 Fehlern: "Suppressing further process errors" und Stille
- Verhindert den endlosen ~2s Log-Spam bei Mono→Stereo Mismatch

## MediaSync Hash-Dedup (media_sync_service.py)

- `_offered_hashes` Set: gleicher Content wird nie erneut angeboten
- Verhindert die 10+ Wiederholungen von "000_Kick Thick.wav" im Log

## Geänderte Dateien

| Datei | Änderung |
|-------|----------|
| `pydaw/services/project_service.py` | 7 neue collab_notify Hooks |
| `pydaw/services/collab_service.py` | 3 neue Server-Passthroughs |
| `pydaw/ui/collab_panel.py` | 3 neue Remote-Handler + Routing |
| `pydaw/ui/arranger_canvas.py` | Ctrl+Drag → clip_copy_batch Emit |
| `pydaw/audio/vst3_host.py` | Process-Error Rate-Limit |
| `pydaw/services/media_sync_service.py` | Hash-basierte Dedup |
| `VERSION` + `pydaw/version.py` | → 0.0.20.873 |
