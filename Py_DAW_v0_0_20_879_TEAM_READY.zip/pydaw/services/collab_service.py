"""Collaboration Server — WebSocket-based real-time project sync.

v0.0.20.856 — Full rewrite for websockets >=14 (asyncio API)

Architecture:
  - Server runs inside the DAW (host starts it)
  - Clients connect via WebSocket (ws://host:port)
  - Operations are JSON messages with types:
      "sync"     — full project state (initial sync)
      "op"       — incremental operation (track add/remove/modify, clip change, etc.)
      "cursor"   — user cursor position in arranger/piano roll
      "chat"     — text chat between collaborators
      "lock"     — acquire/release edit lock on a track
      "presence" — user joined/left/idle

  - Conflict resolution: Last-Write-Wins with per-track locking
  - All ops are broadcast to all connected clients
  - Server maintains authoritative project state

Transport: asyncio + websockets (new asyncio API, >=14)

Usage (Host):
    server = CollabServer(project_service, port=9742)
    server.start()  # Non-blocking, runs in background thread
    share_url = server.get_share_url()

Usage (Client):
    client = CollabClient()
    client.connect("ws://192.168.1.5:9742", user_name="Bob")
    client.send_op({"type": "track_volume", "track_id": "trk_1", "volume": 0.7})
"""

from __future__ import annotations

import asyncio
import json
import logging
import socket
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Operation types
# ---------------------------------------------------------------------------

OP_SYNC = "sync"
OP_OPERATION = "op"
OP_CURSOR = "cursor"
OP_CHAT = "chat"
OP_LOCK = "lock"
OP_PRESENCE = "presence"
OP_ACK = "ack"
OP_ERROR = "error"

# Operation sub-types
OPS_TRACK = "track"
OPS_CLIP = "clip"
OPS_TRANSPORT = "transport"
OPS_MIXER = "mixer"
OPS_AUTOMATION = "automation"


@dataclass
class CollabUser:
    """Connected collaborator."""
    user_id: str = ""
    name: str = "Anonymous"
    color: str = "#4A9EFF"
    joined_at: str = ""
    cursor_beat: float = 0.0
    cursor_track: str = ""
    is_idle: bool = False
    locked_tracks: List[str] = field(default_factory=list)


@dataclass
class CollabMessage:
    """A message in the collab protocol."""
    type: str = ""
    user_id: str = ""
    user_name: str = ""
    timestamp: float = 0.0
    payload: Dict[str, Any] = field(default_factory=dict)
    seq: int = 0

    def to_json(self) -> str:
        def _json_safe(obj):
            """Fallback handler for non-JSON-serializable types."""
            if isinstance(obj, (set, frozenset)):
                return list(obj)
            if isinstance(obj, bytes):
                import base64
                return base64.b64encode(obj).decode()
            if hasattr(obj, '__dict__'):
                return str(obj)
            return str(obj)
        return json.dumps(asdict(self), ensure_ascii=False, default=_json_safe)

    @classmethod
    def from_json(cls, data: str) -> "CollabMessage":
        d = json.loads(data)
        return cls(
            type=d.get("type", ""),
            user_id=d.get("user_id", ""),
            user_name=d.get("user_name", ""),
            timestamp=d.get("timestamp", 0.0),
            payload=d.get("payload", {}),
            seq=d.get("seq", 0),
        )


# ---------------------------------------------------------------------------
# User colors palette
# ---------------------------------------------------------------------------

_USER_COLORS = [
    "#4A9EFF",  # blue
    "#FF6B4A",  # orange-red
    "#4AFF6B",  # green
    "#FF4AE8",  # pink
    "#FFD74A",  # yellow
    "#4AFFF0",  # cyan
    "#B44AFF",  # purple
    "#FF9E4A",  # orange
]


# ---------------------------------------------------------------------------
# Collaboration Server
# ---------------------------------------------------------------------------

class CollabServer:
    """WebSocket server for real-time collaboration.

    Runs in a background thread with its own asyncio event loop.
    Compatible with websockets >=14 (new asyncio API).
    """

    def __init__(self, project_service=None, port: int = 9742,
                 max_users: int = 8, ssl_cert: str = "", ssl_key: str = ""):
        self._project_service = project_service
        self._port = port
        self._max_users = max(1, int(max_users))
        self._ssl_cert = str(ssl_cert or "")
        self._ssl_key = str(ssl_key or "")
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._server: Any = None
        self._ready_event = threading.Event()

        # Connected clients
        self._users: Dict[str, CollabUser] = {}
        self._connections: Dict[str, Any] = {}
        self._track_locks: Dict[str, str] = {}
        self._op_log: List[CollabMessage] = []
        self._max_op_log = 500
        self._seq = 0

        # Callbacks
        self._on_user_joined: Optional[Callable] = None
        self._on_user_left: Optional[Callable] = None
        self._on_operation: Optional[Callable] = None
        self._on_chat: Optional[Callable] = None
        self._on_cursor: Optional[Callable] = None

        # Session info
        self._session_id = str(uuid.uuid4())[:8]
        self._session_name = "Py_DAW Session"
        self._session_password = ""

        # mDNS / Zeroconf
        self._zeroconf = None
        self._mdns_info = None

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def set_session_name(self, name: str) -> None:
        self._session_name = name

    def set_password(self, password: str) -> None:
        self._session_password = password

    def set_max_users(self, n: int) -> None:
        """Set maximum number of connected users (1-64)."""
        self._max_users = max(1, min(64, int(n)))

    def set_callbacks(self, on_user_joined=None, on_user_left=None,
                      on_operation=None, on_chat=None, on_cursor=None) -> None:
        self._on_user_joined = on_user_joined
        self._on_user_left = on_user_left
        self._on_operation = on_operation
        self._on_chat = on_chat
        self._on_cursor = on_cursor

    # ------------------------------------------------------------------
    # Server lifecycle
    # ------------------------------------------------------------------

    def start(self) -> bool:
        """Start the collaboration server in a background thread."""
        if self._running:
            return True

        try:
            import websockets  # noqa: F401
        except ImportError:
            log.warning("websockets package not installed — collab server unavailable. "
                        "Install with: pip install websockets")
            return False

        self._ready_event.clear()
        self._running = True
        self._thread = threading.Thread(
            target=self._run_server,
            name="CollabServer",
            daemon=True,
        )
        self._thread.start()

        # Wait up to 5s for the server to actually start listening
        if not self._ready_event.wait(timeout=5.0):
            log.error("Collab server failed to start within 5 seconds")
            self._running = False
            return False

        log.info("Collab server started on port %d (session: %s)",
                 self._port, self._session_id)
        self._register_mdns()
        return True

    def stop(self) -> None:
        """Stop the collaboration server."""
        self._running = False
        self._unregister_mdns()
        # Close all client websockets so server handler coroutines exit
        if self._loop and not self._loop.is_closed():
            try:
                future = asyncio.run_coroutine_threadsafe(
                    self._close_all_clients(), self._loop
                )
                future.result(timeout=2)
            except Exception:
                pass
        # Wait for the server thread to finish (serve_forever loop exits
        # because _running=False, then async-with cleans up the server)
        if self._thread:
            self._thread.join(timeout=5)
        self._connections.clear()
        self._users.clear()
        self._server = None
        self._loop = None
        log.info("Collab server stopped")

    async def _close_all_clients(self) -> None:
        """Close all client websocket connections."""
        for uid, ws in list(self._connections.items()):
            try:
                await ws.close()
            except Exception:
                pass
        self._connections.clear()

    def is_running(self) -> bool:
        return self._running

    def _run_server(self) -> None:
        """Background thread: run asyncio event loop with websocket server."""
        try:
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
            self._loop.run_until_complete(self._serve_forever())
        except Exception as e:
            if self._running:
                log.error("Collab server error: %s", e)
        finally:
            self._running = False
            try:
                if self._loop and not self._loop.is_closed():
                    self._loop.close()
            except Exception:
                pass

    async def _serve_forever(self) -> None:
        """Async: start the websocket server and serve until stopped."""
        import websockets

        # v0.0.20.867: Optional TLS/SSL
        ssl_ctx = None
        if self._ssl_cert and self._ssl_key:
            try:
                import ssl
                ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                ssl_ctx.load_cert_chain(self._ssl_cert, self._ssl_key)
                log.info("Collab server: TLS enabled (cert=%s)", self._ssl_cert)
            except Exception as e:
                log.warning("Collab server: TLS setup failed: %s (falling back to plain)", e)
                ssl_ctx = None

        try:
            async with websockets.serve(
                self._handle_client,
                "0.0.0.0",
                self._port,
                ssl=ssl_ctx,
            ) as server:
                self._server = server
                self._ready_event.set()
                log.info("Collab server listening on port %d", self._port)
                while self._running:
                    await asyncio.sleep(0.5)
        except OSError as e:
            log.error("Collab server bind error on port %d: %s", self._port, e)
            self._ready_event.set()  # unblock start()
            raise

    async def _handle_client(self, websocket) -> None:
        """Handle a single client connection."""
        user_id = ""
        try:
            # Wait for handshake
            raw = await asyncio.wait_for(websocket.recv(), timeout=10)
            msg = CollabMessage.from_json(raw)

            if msg.type != OP_PRESENCE:
                await websocket.send(CollabMessage(
                    type=OP_ERROR,
                    payload={"error": "Expected presence message"},
                ).to_json())
                return

            # Check password
            if self._session_password:
                if msg.payload.get("password") != self._session_password:
                    await websocket.send(CollabMessage(
                        type=OP_ERROR,
                        payload={"error": "Invalid password"},
                    ).to_json())
                    return

            # v0.0.20.867: Max users check
            if len(self._users) >= self._max_users:
                await websocket.send(CollabMessage(
                    type=OP_ERROR,
                    payload={"error": f"Session ist voll ({self._max_users} max)"},
                ).to_json())
                log.info("Collab: rejected user (session full, %d/%d)",
                         len(self._users), self._max_users)
                return

            # Register user
            user_id = msg.user_id or str(uuid.uuid4())[:8]
            user_name = msg.user_name or "Anonymous"
            color_idx = len(self._users) % len(_USER_COLORS)
            user = CollabUser(
                user_id=user_id,
                name=user_name,
                color=_USER_COLORS[color_idx],
                joined_at=datetime.utcnow().isoformat(),
            )
            self._users[user_id] = user
            self._connections[user_id] = websocket

            # Send initial sync
            await self._send_initial_sync(websocket, user)

            # Notify others
            await self._broadcast(CollabMessage(
                type=OP_PRESENCE,
                user_id=user_id,
                user_name=user_name,
                payload={"action": "joined", "color": user.color},
            ), exclude=user_id)

            if self._on_user_joined:
                try:
                    self._on_user_joined(user)
                except Exception:
                    pass

            log.info("User '%s' (%s) joined collab session", user_name, user_id)

            # Main message loop
            async for raw in websocket:
                try:
                    msg = CollabMessage.from_json(raw)
                    msg.user_id = user_id
                    msg.user_name = user_name
                    await self._process_message(msg, user_id)
                except json.JSONDecodeError:
                    pass
                except Exception as e:
                    log.warning("Collab message error from %s: %s", user_id, e)

        except asyncio.TimeoutError:
            log.debug("Collab client handshake timeout")
        except Exception as e:
            log.debug("Collab client disconnected: %s", e)
        finally:
            if user_id:
                self._connections.pop(user_id, None)
                user = self._users.pop(user_id, None)
                self._track_locks = {
                    tid: uid for tid, uid in self._track_locks.items()
                    if uid != user_id
                }
                try:
                    await self._broadcast(CollabMessage(
                        type=OP_PRESENCE,
                        user_id=user_id,
                        user_name=user.name if user else "?",
                        payload={"action": "left"},
                    ), exclude=user_id)
                except Exception:
                    pass

                if self._on_user_left and user:
                    try:
                        self._on_user_left(user)
                    except Exception:
                        pass
                log.info("User '%s' left collab session", user_id)

    async def _send_initial_sync(self, websocket, user: CollabUser) -> None:
        """Send full project state + user list to a newly connected client."""
        project_data = {}
        if self._project_service:
            try:
                proj = getattr(getattr(self._project_service, 'ctx', None),
                               'project', None)
                if proj and hasattr(proj, 'to_dict'):
                    project_data = proj.to_dict()
            except Exception:
                pass

        users_list = [asdict(u) for u in self._users.values()]

        await websocket.send(CollabMessage(
            type=OP_SYNC,
            user_id="server",
            payload={
                "project": project_data,
                "users": users_list,
                "your_user": asdict(user),
                "session_id": self._session_id,
                "session_name": self._session_name,
                "track_locks": dict(self._track_locks),
            },
        ).to_json())

    async def _process_message(self, msg: CollabMessage, sender_id: str) -> None:
        """Process an incoming message from a client."""
        if msg.type == OP_OPERATION:
            track_id = msg.payload.get("track_id", "")
            if track_id and track_id in self._track_locks:
                lock_owner = self._track_locks[track_id]
                if lock_owner != sender_id:
                    await self._send_to(sender_id, CollabMessage(
                        type=OP_ERROR,
                        payload={"error": f"Track locked by {self._users.get(lock_owner, CollabUser()).name}"},
                    ))
                    return

            self._apply_operation(msg)

            self._seq += 1
            msg.seq = self._seq
            msg.timestamp = time.time()
            self._op_log.append(msg)
            if len(self._op_log) > self._max_op_log:
                self._op_log = self._op_log[-self._max_op_log:]

            await self._broadcast(msg, exclude=sender_id)

            if self._on_operation:
                op = msg.payload.get("op_type", "?") if isinstance(msg.payload, dict) else "?"
                log.debug("[COLLAB-SRV] firing _on_operation callback for op=%s from=%s",
                          op, sender_id)
                try:
                    self._on_operation(msg)
                except Exception as e:
                    log.warning("[COLLAB-SRV] _on_operation callback error: %s", e)
            else:
                op = msg.payload.get("op_type", "?") if isinstance(msg.payload, dict) else "?"
                log.warning("[COLLAB-SRV] no _on_operation callback for op=%s", op)

        elif msg.type == OP_CURSOR:
            user = self._users.get(sender_id)
            if user:
                user.cursor_beat = float(msg.payload.get("beat", 0))
                user.cursor_track = str(msg.payload.get("track_id", ""))
            await self._broadcast(msg, exclude=sender_id)
            if self._on_cursor:
                try:
                    self._on_cursor(msg)
                except Exception:
                    pass

        elif msg.type == OP_CHAT:
            msg.timestamp = time.time()
            # Broadcast to all EXCEPT sender (sender shows locally)
            await self._broadcast(msg, exclude=sender_id)
            if self._on_chat:
                try:
                    self._on_chat(msg)
                except Exception:
                    pass

        elif msg.type == OP_LOCK:
            action = msg.payload.get("action", "")
            track_id = msg.payload.get("track_id", "")
            if action == "acquire" and track_id:
                if track_id not in self._track_locks:
                    self._track_locks[track_id] = sender_id
                    await self._broadcast(CollabMessage(
                        type=OP_LOCK,
                        user_id=sender_id,
                        user_name=msg.user_name,
                        payload={"action": "acquired", "track_id": track_id},
                    ))
                else:
                    owner = self._track_locks[track_id]
                    await self._send_to(sender_id, CollabMessage(
                        type=OP_ERROR,
                        payload={"error": f"Track already locked by {self._users.get(owner, CollabUser()).name}"},
                    ))
            elif action == "release" and track_id:
                if self._track_locks.get(track_id) == sender_id:
                    del self._track_locks[track_id]
                    await self._broadcast(CollabMessage(
                        type=OP_LOCK,
                        user_id=sender_id,
                        payload={"action": "released", "track_id": track_id},
                    ))

        elif msg.type == OP_PRESENCE:
            action = msg.payload.get("action", "")
            user = self._users.get(sender_id)
            if action == "idle" and user:
                user.is_idle = True
            elif action == "active" and user:
                user.is_idle = False
            await self._broadcast(msg, exclude=sender_id)

    def _apply_operation(self, msg: CollabMessage) -> None:
        """Apply an operation to the host's project (server-side)."""
        if not self._project_service:
            return
        try:
            payload = msg.payload
            op_type = payload.get("op_type", "")

            ctx = getattr(self._project_service, 'ctx', None)
            if not ctx:
                return
            project = getattr(ctx, 'project', None)
            if not project:
                return

            if op_type == "track_volume":
                tid = payload.get("track_id", "")
                vol = float(payload.get("volume", 0.8))
                for t in (project.tracks or []):
                    if str(getattr(t, 'id', '')) == tid:
                        t.volume = vol
                        break

            elif op_type == "track_pan":
                tid = payload.get("track_id", "")
                pan = float(payload.get("pan", 0.0))
                for t in (project.tracks or []):
                    if str(getattr(t, 'id', '')) == tid:
                        t.pan = pan
                        break

            elif op_type == "track_mute":
                tid = payload.get("track_id", "")
                muted = bool(payload.get("muted", False))
                for t in (project.tracks or []):
                    if str(getattr(t, 'id', '')) == tid:
                        t.muted = muted
                        break

            elif op_type == "track_solo":
                tid = payload.get("track_id", "")
                solo = bool(payload.get("solo", False))
                for t in (project.tracks or []):
                    if str(getattr(t, 'id', '')) == tid:
                        t.solo = solo
                        break

            elif op_type == "transport_bpm":
                bpm = float(payload.get("bpm", 120.0))
                project.bpm = bpm

            elif op_type == "clip_move":
                cid = payload.get("clip_id", "")
                start = float(payload.get("start_beats", 0))
                new_track = payload.get("track_id", "")
                for c in (project.clips or []):
                    if str(getattr(c, 'id', '')) == cid:
                        c.start_beats = start
                        if new_track:
                            c.track_id = str(new_track)
                        break

            elif op_type == "track_name":
                tid = payload.get("track_id", "")
                name = str(payload.get("name", ""))
                for t in (project.tracks or []):
                    if str(getattr(t, 'id', '')) == tid:
                        t.name = name
                        break

            elif op_type == "track_color":
                tid = payload.get("track_id", "")
                color = str(payload.get("color", ""))
                for t in (project.tracks or []):
                    if str(getattr(t, 'id', '')) == tid:
                        t.color = color
                        break

            elif op_type == "track_record_arm":
                tid = payload.get("track_id", "")
                armed = bool(payload.get("armed", False))
                for t in (project.tracks or []):
                    if str(getattr(t, 'id', '')) == tid:
                        t.record_arm = armed
                        break

            elif op_type == "clip_color":
                cid = payload.get("clip_id", "")
                color = str(payload.get("color", ""))
                for c in (project.clips or []):
                    if str(getattr(c, 'id', '')) == cid:
                        c.color = color
                        break

            elif op_type == "clip_resize":
                cid = payload.get("clip_id", "")
                length = float(payload.get("length_beats", 0))
                for c in (project.clips or []):
                    if str(getattr(c, 'id', '')) == cid:
                        if length > 0:
                            c.length_beats = length
                        break

            elif op_type == "clip_mute":
                cid = payload.get("clip_id", "")
                muted = bool(payload.get("muted", False))
                for c in (project.clips or []):
                    if str(getattr(c, 'id', '')) == cid:
                        c.muted = muted
                        break

            # Transport ops — server stores state, clients apply locally
            elif op_type == "transport_play":
                pass  # clients handle via _on_remote_operation

            elif op_type == "transport_stop":
                pass  # clients handle via _on_remote_operation

            elif op_type == "transport_loop":
                pass  # clients handle via _on_remote_operation

            elif op_type == "transport_seek":
                pass  # v0.0.20.872: playhead position sync — clients handle

            # Structural ops — pass through to clients (server doesn't modify model)
            elif op_type in ("track_add", "track_remove",
                             "clip_add_midi", "clip_add_audio", "clip_remove"):
                pass  # clients handle via _on_remote_operation

            # MIDI notes + Automation — pass through (full snapshot sync)
            elif op_type in ("midi_notes_sync", "automation_sync"):
                pass  # clients handle via _on_remote_operation

            # Plugin/FX, Clip duplicate, Send routing — pass through
            elif op_type in ("device_sync", "clip_duplicate",
                             "send_add", "send_remove"):
                pass  # clients handle via _on_remote_operation

            # v0.0.20.873: Additional arranger ops — pass through
            elif op_type in ("clip_trim", "clip_rename", "clip_copy_batch"):
                pass  # clients handle via _on_remote_operation

            # v0.0.20.875: Track reorder + group/ungroup + clip scale — pass through
            elif op_type in ("track_reorder", "track_group", "track_ungroup", "clip_scale"):
                pass  # clients handle via _on_remote_operation

            # Media file streaming — pass through (chunked data)
            elif op_type.startswith("media_"):
                pass  # clients handle via MediaSyncService

        except Exception as e:
            log.warning("Failed to apply collab operation: %s", e)

    async def _broadcast(self, msg: CollabMessage, exclude: str = "") -> None:
        """Send message to all connected clients."""
        data = msg.to_json()
        disconnected = []
        n_sent = 0
        for uid, ws in list(self._connections.items()):
            if uid == exclude:
                continue
            try:
                await ws.send(data)
                n_sent += 1
            except Exception as e:
                log.warning("[COLLAB] broadcast send error to %s: %s", uid, e)
                disconnected.append(uid)
        for uid in disconnected:
            self._connections.pop(uid, None)
            self._users.pop(uid, None)
        if n_sent == 0 and not exclude:
            op = msg.payload.get("op_type", msg.type) if hasattr(msg, 'payload') else msg.type
            log.warning("[COLLAB] broadcast: 0 clients received op=%s (conns=%d, exclude=%s)",
                        op, len(self._connections), exclude)

    async def _send_to(self, user_id: str, msg: CollabMessage) -> None:
        """Send message to a specific client."""
        ws = self._connections.get(user_id)
        if ws:
            try:
                await ws.send(msg.to_json())
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Thread-safe broadcast from host (main thread -> event loop thread)
    # ------------------------------------------------------------------

    def broadcast_from_host(self, msg: CollabMessage) -> None:
        """Thread-safe: schedule a broadcast on the server's event loop.

        Use this to send messages from the main/GUI thread (e.g. host chat).
        """
        loop = self._loop
        if not loop or loop.is_closed() or not self._running:
            log.warning("[COLLAB-HOST] broadcast_from_host: no event loop or not running")
            return
        try:
            n_conns = len(self._connections)
            op = msg.payload.get("op_type", msg.type) if hasattr(msg, 'payload') else msg.type
            log.debug("[COLLAB-HOST] broadcast_from_host: op=%s to %d client(s)", op, n_conns)
            asyncio.run_coroutine_threadsafe(
                self._broadcast(msg), loop
            )
        except Exception as e:
            log.warning("[COLLAB-HOST] broadcast_from_host error: %s", e)

    # ------------------------------------------------------------------
    # mDNS / Zeroconf
    # ------------------------------------------------------------------

    def _register_mdns(self) -> None:
        """Register the collab session via mDNS so LAN peers can find it."""
        try:
            from zeroconf import Zeroconf, ServiceInfo
            import socket as _sock
            ip = self._get_local_ip()
            self._zeroconf = Zeroconf()
            self._mdns_info = ServiceInfo(
                "_pydaw._tcp.local.",
                f"{self._session_name}._pydaw._tcp.local.",
                addresses=[_sock.inet_aton(ip)],
                port=self._port,
                properties={
                    "session_id": self._session_id,
                    "name": self._session_name,
                    "password": "1" if self._session_password else "0",
                },
            )
            self._zeroconf.register_service(self._mdns_info)
            log.info("mDNS: registered '%s' on %s:%d",
                     self._session_name, ip, self._port)
        except ImportError:
            log.debug("zeroconf not installed — mDNS disabled")
        except Exception as e:
            log.warning("mDNS registration failed: %s", e)

    def _unregister_mdns(self) -> None:
        """Unregister the mDNS service."""
        try:
            if self._zeroconf and self._mdns_info:
                self._zeroconf.unregister_service(self._mdns_info)
            if self._zeroconf:
                self._zeroconf.close()
        except Exception:
            pass
        self._zeroconf = None
        self._mdns_info = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_share_url(self) -> str:
        """Get the WebSocket URL for clients to connect."""
        hostname = self._get_local_ip()
        scheme = "wss" if self._ssl_cert else "ws"
        return f"{scheme}://{hostname}:{self._port}"

    def get_connected_users(self) -> List[CollabUser]:
        """Get list of connected users."""
        return list(self._users.values())

    def get_session_info(self) -> Dict[str, Any]:
        """Get session metadata."""
        return {
            "session_id": self._session_id,
            "session_name": self._session_name,
            "port": self._port,
            "url": self.get_share_url(),
            "users": len(self._users),
            "max_users": self._max_users,
            "has_password": bool(self._session_password),
            "tls": bool(self._ssl_cert),
        }

    def _get_local_ip(self) -> str:
        """Get the local network IP address."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(2)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"


# ---------------------------------------------------------------------------
# Collaboration Client
# ---------------------------------------------------------------------------

class CollabClient:
    """WebSocket client for connecting to a collaboration session.

    Runs in a background thread. Receives operations and applies
    them to the local project. Supports auto-reconnect.
    """

    def __init__(self):
        self._url: str = ""
        self._user_id: str = str(uuid.uuid4())[:8]
        self._user_name: str = "User"
        self._password: str = ""
        self._connected: bool = False
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._websocket: Any = None
        self._should_reconnect: bool = False
        self._ever_connected: bool = False
        self._reconnect_delay: float = 2.0
        self._max_reconnect_delay: float = 30.0
        self._ready_event = threading.Event()

        # Session state
        self._session_info: Dict[str, Any] = {}
        self._remote_users: Dict[str, CollabUser] = {}

        # Callbacks
        self._on_connected: Optional[Callable] = None
        self._on_disconnected: Optional[Callable] = None
        self._on_sync: Optional[Callable] = None
        self._on_operation: Optional[Callable] = None
        self._on_cursor: Optional[Callable] = None
        self._on_chat: Optional[Callable] = None
        self._on_presence: Optional[Callable] = None
        self._on_lock: Optional[Callable] = None
        self._on_error: Optional[Callable] = None

    def set_callbacks(self, **kwargs) -> None:
        """Set callback functions for events."""
        for key, val in kwargs.items():
            attr = f"_on_{key}"
            if hasattr(self, attr):
                setattr(self, attr, val)

    def connect(self, url: str, user_name: str = "User",
                password: str = "", auto_reconnect: bool = True) -> bool:
        """Connect to a collaboration server."""
        try:
            import websockets  # noqa: F401
        except ImportError:
            log.warning("websockets package not installed")
            return False

        # Always kill any existing background thread first (prevents thread leak)
        self._stop_background()
        self._connected = False

        self._url = url
        self._user_name = user_name
        self._password = password
        self._should_reconnect = auto_reconnect
        self._ever_connected = False  # only reconnect after first success

        self._ready_event.clear()
        self._thread = threading.Thread(
            target=self._run_client,
            name="CollabClient",
            daemon=True,
        )
        self._thread.start()

        self._ready_event.wait(timeout=5.0)
        return self._connected

    def _stop_background(self) -> None:
        """Stop any running background thread (without calling callbacks)."""
        self._should_reconnect = False
        if self._loop and not self._loop.is_closed():
            if self._websocket:
                try:
                    asyncio.run_coroutine_threadsafe(
                        self._close_websocket(), self._loop
                    ).result(timeout=2)
                except Exception:
                    pass
            try:
                self._loop.call_soon_threadsafe(self._loop.stop)
            except Exception:
                pass
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=3)
        self._websocket = None
        self._loop = None
        self._thread = None

    def disconnect(self) -> None:
        """Disconnect from the collaboration server."""
        self._stop_background()
        self._connected = False
        if self._on_disconnected:
            try:
                self._on_disconnected()
            except Exception:
                pass

    async def _close_websocket(self) -> None:
        """Properly close the websocket connection."""
        ws = self._websocket
        if ws:
            try:
                await ws.close()
            except Exception:
                pass

    def is_connected(self) -> bool:
        return self._connected

    def _run_client(self) -> None:
        """Background thread: connect and receive messages."""
        try:
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
            self._loop.run_until_complete(self._connect_with_retry())
        except Exception as e:
            if self._should_reconnect:
                log.error("Collab client error: %s", e)
        finally:
            was_connected = self._connected
            self._connected = False
            self._ready_event.set()
            try:
                if self._loop and not self._loop.is_closed():
                    self._loop.close()
            except Exception:
                pass
            if was_connected and self._on_disconnected:
                try:
                    self._on_disconnected()
                except Exception:
                    pass

    async def _connect_with_retry(self) -> None:
        """Connect with auto-reconnect support.

        Auto-reconnect only activates AFTER a successful first connection.
        If the first attempt fails, we give up immediately.
        """
        delay = self._reconnect_delay
        first_attempt = True
        while True:
            try:
                await self._connect_and_listen()
                # If we reach here, connection was established and then lost
                self._ever_connected = True
            except Exception as e:
                log.debug("Collab client connection lost: %s", e)

            self._connected = False
            if first_attempt:
                self._ready_event.set()  # unblock connect() call
                first_attempt = False
                # If we never connected, don't retry
                if not self._ever_connected:
                    log.info("Collab client: initial connection failed, not retrying")
                    break

            if not self._should_reconnect:
                break

            log.info("Collab client reconnecting in %.1fs...", delay)
            # Sleep in small increments so we can be interrupted
            waited = 0.0
            while waited < delay and self._should_reconnect:
                await asyncio.sleep(0.5)
                waited += 0.5
            if not self._should_reconnect:
                break
            delay = min(delay * 1.5, self._max_reconnect_delay)

    async def _connect_and_listen(self) -> None:
        """Async: connect, handshake, listen for messages."""
        import websockets

        # v0.0.20.867: SSL for wss:// URLs
        connect_kwargs = {}
        if self._url.startswith("wss://"):
            try:
                import ssl
                ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
                ssl_ctx.check_hostname = False
                ssl_ctx.verify_mode = ssl.CERT_NONE  # LAN self-signed OK
                connect_kwargs["ssl"] = ssl_ctx
            except Exception:
                pass

        async with websockets.connect(self._url, **connect_kwargs) as ws:
            self._websocket = ws

            handshake = CollabMessage(
                type=OP_PRESENCE,
                user_id=self._user_id,
                user_name=self._user_name,
                payload={
                    "action": "join",
                    "password": self._password,
                },
            )
            await ws.send(handshake.to_json())

            self._connected = True
            self._ready_event.set()

            if self._on_connected:
                try:
                    self._on_connected()
                except Exception:
                    pass

            log.info("Collab client connected to %s", self._url)

            async for raw in ws:
                try:
                    msg = CollabMessage.from_json(raw)
                    self._handle_message(msg)
                except json.JSONDecodeError:
                    pass
                except Exception as e:
                    log.warning("Collab message handling error: %s", e)

    def _handle_message(self, msg: CollabMessage) -> None:
        """Process a message from the server."""
        if msg.type == OP_SYNC:
            self._session_info = msg.payload
            users_list = msg.payload.get("users", [])
            for u_data in users_list:
                uid = u_data.get("user_id", "")
                if uid and uid != self._user_id:
                    self._remote_users[uid] = CollabUser(
                        user_id=uid,
                        name=u_data.get("name", "?"),
                        color=u_data.get("color", "#4A9EFF"),
                    )
            if self._on_sync:
                try:
                    self._on_sync(msg.payload)
                except Exception:
                    pass

        elif msg.type == OP_OPERATION:
            op = msg.payload.get("op_type", "?") if isinstance(msg.payload, dict) else "?"
            log.debug("[COLLAB-CLIENT] received op=%s from=%s", op, msg.user_name)
            if self._on_operation:
                try:
                    self._on_operation(msg)
                except Exception as e:
                    log.warning("[COLLAB-CLIENT] _on_operation error for %s: %s", op, e)

        elif msg.type == OP_CURSOR:
            if self._on_cursor:
                try:
                    self._on_cursor(msg)
                except Exception:
                    pass

        elif msg.type == OP_CHAT:
            if self._on_chat:
                try:
                    self._on_chat(msg)
                except Exception:
                    pass

        elif msg.type == OP_PRESENCE:
            action = msg.payload.get("action", "")
            if action == "joined":
                self._remote_users[msg.user_id] = CollabUser(
                    user_id=msg.user_id,
                    name=msg.user_name,
                    color=msg.payload.get("color", "#4A9EFF"),
                )
            elif action == "left":
                self._remote_users.pop(msg.user_id, None)
            if self._on_presence:
                try:
                    self._on_presence(msg)
                except Exception:
                    pass

        elif msg.type == OP_LOCK:
            if self._on_lock:
                try:
                    self._on_lock(msg)
                except Exception:
                    pass

        elif msg.type == OP_ERROR:
            if self._on_error:
                try:
                    self._on_error(msg.payload.get("error", "Unknown error"))
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # Send operations (thread-safe via asyncio)
    # ------------------------------------------------------------------

    def send_op(self, payload: Dict[str, Any]) -> None:
        """Send an operation to the server."""
        if not self._connected or not self._websocket:
            return
        msg = CollabMessage(
            type=OP_OPERATION,
            user_id=self._user_id,
            user_name=self._user_name,
            timestamp=time.time(),
            payload=payload,
        )
        self._send_async(msg)

    def send_cursor(self, beat: float, track_id: str = "") -> None:
        """Send cursor position update."""
        if not self._connected or not self._websocket:
            return
        msg = CollabMessage(
            type=OP_CURSOR,
            user_id=self._user_id,
            payload={"beat": beat, "track_id": track_id},
        )
        self._send_async(msg)

    def send_chat(self, text: str) -> None:
        """Send a chat message."""
        if not self._connected or not self._websocket:
            return
        msg = CollabMessage(
            type=OP_CHAT,
            user_id=self._user_id,
            user_name=self._user_name,
            timestamp=time.time(),
            payload={"text": text},
        )
        self._send_async(msg)

    def request_lock(self, track_id: str) -> None:
        """Request an edit lock on a track."""
        if not self._connected or not self._websocket:
            return
        msg = CollabMessage(
            type=OP_LOCK,
            user_id=self._user_id,
            payload={"action": "acquire", "track_id": track_id},
        )
        self._send_async(msg)

    def release_lock(self, track_id: str) -> None:
        """Release an edit lock on a track."""
        if not self._connected or not self._websocket:
            return
        msg = CollabMessage(
            type=OP_LOCK,
            user_id=self._user_id,
            payload={"action": "release", "track_id": track_id},
        )
        self._send_async(msg)

    def _send_async(self, msg: CollabMessage) -> None:
        """Thread-safe send via asyncio."""
        loop = self._loop
        ws = self._websocket
        if loop and ws and not loop.is_closed():
            try:
                asyncio.run_coroutine_threadsafe(
                    ws.send(msg.to_json()),
                    loop,
                )
            except Exception:
                pass

    def get_remote_users(self) -> List[CollabUser]:
        """Get list of other connected users."""
        return list(self._remote_users.values())


# ---------------------------------------------------------------------------
# mDNS Session Discovery
# ---------------------------------------------------------------------------

@dataclass
class DiscoveredSession:
    """A Py_DAW collab session found on the local network."""
    name: str = ""
    host: str = ""
    port: int = 9742
    session_id: str = ""
    has_password: bool = False
    url: str = ""


class CollabDiscovery:
    """Browse the LAN for Py_DAW collab sessions via mDNS/Zeroconf.

    Usage:
        discovery = CollabDiscovery()
        discovery.start(on_found=callback, on_lost=callback)
        sessions = discovery.get_sessions()
        discovery.stop()
    """

    def __init__(self):
        self._zeroconf = None
        self._browser = None
        self._sessions: Dict[str, DiscoveredSession] = {}
        self._on_found: Optional[Callable] = None
        self._on_lost: Optional[Callable] = None

    def start(self, on_found: Callable = None,
              on_lost: Callable = None) -> bool:
        """Start browsing for sessions."""
        try:
            from zeroconf import Zeroconf, ServiceBrowser
        except ImportError:
            log.debug("zeroconf not installed — discovery unavailable")
            return False

        self._on_found = on_found
        self._on_lost = on_lost
        try:
            self._zeroconf = Zeroconf()
            self._browser = ServiceBrowser(
                self._zeroconf, "_pydaw._tcp.local.", self
            )
            log.info("mDNS discovery started")
            return True
        except Exception as e:
            log.warning("mDNS discovery failed: %s", e)
            return False

    def stop(self) -> None:
        """Stop browsing."""
        try:
            if self._zeroconf:
                self._zeroconf.close()
        except Exception:
            pass
        self._zeroconf = None
        self._browser = None
        self._sessions.clear()

    def get_sessions(self) -> List[DiscoveredSession]:
        """Get all currently visible sessions."""
        return list(self._sessions.values())

    # ServiceBrowser callbacks (called from zeroconf thread)
    def add_service(self, zc, type_: str, name: str) -> None:
        try:
            from zeroconf import Zeroconf
            info = zc.get_service_info(type_, name)
            if not info:
                return
            host = info.parsed_addresses()[0] if info.parsed_addresses() else "?"
            props = {}
            if info.properties:
                props = {k.decode(): v.decode() if isinstance(v, bytes) else str(v)
                         for k, v in info.properties.items()}
            session = DiscoveredSession(
                name=props.get("name", name.split(".")[0]),
                host=host,
                port=info.port,
                session_id=props.get("session_id", ""),
                has_password=props.get("password", "0") == "1",
                url=f"ws://{host}:{info.port}",
            )
            self._sessions[name] = session
            if self._on_found:
                try:
                    self._on_found(session)
                except Exception:
                    pass
            log.info("mDNS: found session '%s' at %s", session.name, session.url)
        except Exception as e:
            log.debug("mDNS add_service error: %s", e)

    def remove_service(self, zc, type_: str, name: str) -> None:
        session = self._sessions.pop(name, None)
        if session and self._on_lost:
            try:
                self._on_lost(session)
            except Exception:
                pass

    def update_service(self, zc, type_: str, name: str) -> None:
        # Re-add to update properties
        self.add_service(zc, type_, name)


# ---------------------------------------------------------------------------
# Conflict Detection
# ---------------------------------------------------------------------------

@dataclass
class EditConflict:
    """A detected edit conflict between two users."""
    track_id: str = ""
    param: str = ""
    user_a: str = ""
    user_b: str = ""
    value_a: str = ""
    value_b: str = ""
    timestamp: float = 0.0


class ConflictDetector:
    """Detect when two users edit the same parameter within a short time window.

    Usage:
        detector = ConflictDetector(window_ms=2000)
        conflict = detector.record_edit(user_id, track_id, param, value)
        if conflict:
            show_conflict_dialog(conflict)
    """

    def __init__(self, window_ms: int = 2000):
        self._window = float(window_ms) / 1000.0
        # Key: (track_id, param) → (user_id, value, timestamp)
        self._last_edits: Dict[tuple, tuple] = {}

    def record_edit(self, user_id: str, track_id: str,
                    param: str, value) -> Optional[EditConflict]:
        """Record an edit and return a conflict if detected.

        A conflict is detected when a different user edits the same
        (track_id, param) within the time window.
        """
        key = (track_id, param)
        now = time.time()

        prev = self._last_edits.get(key)
        conflict = None
        if prev:
            prev_user, prev_value, prev_time = prev
            if (prev_user != user_id
                    and (now - prev_time) < self._window
                    and str(prev_value) != str(value)):
                conflict = EditConflict(
                    track_id=track_id,
                    param=param,
                    user_a=prev_user,
                    user_b=user_id,
                    value_a=str(prev_value),
                    value_b=str(value),
                    timestamp=now,
                )

        self._last_edits[key] = (user_id, value, now)
        # Prune old entries (>10s)
        cutoff = now - 10.0
        self._last_edits = {k: v for k, v in self._last_edits.items()
                            if v[2] > cutoff}
        return conflict

    def clear(self) -> None:
        self._last_edits.clear()


# ---------------------------------------------------------------------------
# Collab Undo/Redo Log
# ---------------------------------------------------------------------------

@dataclass
class UndoEntry:
    """A single undoable operation."""
    seq: int = 0
    user_id: str = ""
    user_name: str = ""
    timestamp: float = 0.0
    op_type: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)
    # Inverse operation (what to do to undo this)
    inverse_payload: Dict[str, Any] = field(default_factory=dict)


class CollabUndoLog:
    """Undo/Redo log for collaborative editing.

    Tracks operations with their inverse and allows per-user or global undo.

    Usage:
        undo_log = CollabUndoLog()
        undo_log.push(msg, inverse_payload)
        entry = undo_log.undo(user_id)  # returns inverse op to apply
        entry = undo_log.redo(user_id)
    """

    def __init__(self, max_entries: int = 200):
        self._max = max_entries
        self._log: List[UndoEntry] = []
        self._redo_stack: List[UndoEntry] = []
        self._seq = 0

    def push(self, msg: CollabMessage, inverse_payload: Dict[str, Any]) -> None:
        """Record an operation with its inverse."""
        self._seq += 1
        entry = UndoEntry(
            seq=self._seq,
            user_id=msg.user_id,
            user_name=msg.user_name,
            timestamp=msg.timestamp or time.time(),
            op_type=msg.payload.get("op_type", ""),
            payload=dict(msg.payload),
            inverse_payload=dict(inverse_payload),
        )
        self._log.append(entry)
        if len(self._log) > self._max:
            self._log = self._log[-self._max:]
        # Clear redo stack on new operation
        self._redo_stack.clear()

    def undo(self, user_id: str = "") -> Optional[UndoEntry]:
        """Undo the last operation (optionally filtered by user).

        Returns the entry whose inverse_payload should be applied,
        or None if nothing to undo.
        """
        if not self._log:
            return None
        if user_id:
            # Find last entry by this user
            for i in range(len(self._log) - 1, -1, -1):
                if self._log[i].user_id == user_id:
                    entry = self._log.pop(i)
                    self._redo_stack.append(entry)
                    return entry
            return None
        else:
            entry = self._log.pop()
            self._redo_stack.append(entry)
            return entry

    def redo(self, user_id: str = "") -> Optional[UndoEntry]:
        """Redo the last undone operation.

        Returns the entry whose original payload should be re-applied,
        or None if nothing to redo.
        """
        if not self._redo_stack:
            return None
        if user_id:
            for i in range(len(self._redo_stack) - 1, -1, -1):
                if self._redo_stack[i].user_id == user_id:
                    entry = self._redo_stack.pop(i)
                    self._log.append(entry)
                    return entry
            return None
        else:
            entry = self._redo_stack.pop()
            self._log.append(entry)
            return entry

    def get_history(self, last_n: int = 20) -> List[UndoEntry]:
        """Get last N operations."""
        return list(self._log[-last_n:])

    def clear(self) -> None:
        self._log.clear()
        self._redo_stack.clear()
