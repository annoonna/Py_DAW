"""Collaboration Panel — Dock-Widget für Py_DAW (Phase 5A)

v0.0.20.797 — Echtzeit-Kollaboration, Git-Integration, Review-Mode

Tabs:
  🔀 Git     — Branch, Commit, History, Push/Pull
  👥 Collab  — Server starten/verbinden, User-Liste, Chat
  📝 Review  — Kommentare, Marker, Tasks
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from PyQt6.QtCore import QSettings, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QCheckBox, QComboBox, QDockWidget, QFrame, QGroupBox, QHBoxLayout, QInputDialog,
    QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox,
    QPlainTextEdit, QPushButton, QSizePolicy, QSpinBox, QSplitter,
    QTabWidget, QTextEdit, QVBoxLayout, QWidget,
)

log = logging.getLogger(__name__)


class CollabPanel(QWidget):
    """Main collaboration panel with Git / Collab / Review tabs."""

    status_message = pyqtSignal(str, int)  # message, timeout_ms

    # v0.0.20.861: Thread-safe signals for asyncio→Qt communication
    _sig_chat = pyqtSignal(object)       # CollabMessage
    _sig_cursor = pyqtSignal(object)     # CollabMessage
    _sig_operation = pyqtSignal(object)  # CollabMessage
    _sig_presence = pyqtSignal(object)   # CollabMessage
    _sig_users_changed = pyqtSignal()    # refresh user list
    _sig_connected = pyqtSignal()        # client connected
    _sig_disconnected = pyqtSignal()     # client disconnected
    _sig_user_left = pyqtSignal(object)  # CollabUser (host-side)
    _sig_lan_found = pyqtSignal(object)  # DiscoveredSession
    _sig_lan_lost = pyqtSignal(object)   # DiscoveredSession
    _sig_media_progress = pyqtSignal(str, int, str)  # hash, pct, label
    _sig_full_sync = pyqtSignal(object)  # project dict payload from server
    _sig_instrument_sample_ready = pyqtSignal(str)  # track_id — sample file received

    def __init__(self, parent=None, project_service=None):
        super().__init__(parent)
        self._project_service = project_service
        self._git_service = None
        self._collab_server = None
        self._collab_client = None
        self._review_service = None
        self._arranger_canvas = None  # v0.0.20.858: for cursor sharing
        self._transport = None        # v0.0.20.859: for transport sync
        self._last_cursor_beat = -1.0  # throttle cursor sends
        self._suppress_transport_ops = False  # prevent echo loops
        self._media_sync = None  # v0.0.20.866: MediaSyncService

        # v0.0.20.861: Connect signals to slots (thread-safe)
        self._sig_chat.connect(self._append_chat)
        self._sig_cursor.connect(self._on_remote_cursor)
        self._sig_operation.connect(self._on_remote_operation)
        self._sig_presence.connect(self._on_remote_presence)
        self._sig_users_changed.connect(self._refresh_users)
        self._sig_connected.connect(lambda: self._update_client_status(True))
        self._sig_disconnected.connect(lambda: self._update_client_status(False))
        self._sig_user_left.connect(self._host_user_left)
        self._sig_lan_found.connect(self._add_lan_session)
        self._sig_lan_lost.connect(self._remove_lan_session)
        self._sig_media_progress.connect(self._update_transfer_progress)
        self._sig_full_sync.connect(self._apply_full_sync)
        self._sig_instrument_sample_ready.connect(self._on_instrument_sample_ready)

        self._init_ui()

    def set_services(self, git_service=None, collab_server=None,
                     collab_client=None, review_service=None) -> None:
        """Wire up backend services."""
        self._git_service = git_service
        self._collab_server = collab_server
        self._collab_client = collab_client
        self._review_service = review_service

    # ------------------------------------------------------------------
    # UI Setup
    # ------------------------------------------------------------------

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)

        self._tabs = QTabWidget()
        self._tabs.setTabPosition(QTabWidget.TabPosition.North)

        # Tab 1: Git
        self._git_tab = self._create_git_tab()
        self._tabs.addTab(self._git_tab, "🔀 Git")

        # Tab 2: Collaboration
        self._collab_tab = self._create_collab_tab()
        self._tabs.addTab(self._collab_tab, "👥 Collab")

        # Tab 3: Review
        self._review_tab = self._create_review_tab()
        self._tabs.addTab(self._review_tab, "📝 Review")

        layout.addWidget(self._tabs)

    # ------------------------------------------------------------------
    # Git Tab
    # ------------------------------------------------------------------

    def _create_git_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(6)

        # Status bar
        status_frame = QFrame()
        status_frame.setFrameShape(QFrame.Shape.StyledPanel)
        sl = QHBoxLayout(status_frame)
        sl.setContentsMargins(6, 4, 6, 4)
        self._git_status_label = QLabel("Git: nicht initialisiert")
        self._git_status_label.setStyleSheet("font-weight: bold;")
        sl.addWidget(self._git_status_label)
        sl.addStretch()
        self._git_branch_label = QLabel("")
        self._git_branch_label.setStyleSheet("color: #4A9EFF;")
        sl.addWidget(self._git_branch_label)
        layout.addWidget(status_frame)

        # Init / Branch row
        row1 = QHBoxLayout()
        self._btn_git_init = QPushButton("🔧 Git Init")
        self._btn_git_init.setToolTip("Git-Repository im Projektordner initialisieren")
        self._btn_git_init.clicked.connect(self._on_git_init)
        row1.addWidget(self._btn_git_init)

        self._branch_combo = QComboBox()
        self._branch_combo.setMinimumWidth(120)
        self._branch_combo.currentTextChanged.connect(self._on_branch_changed)
        row1.addWidget(QLabel("Branch:"))
        row1.addWidget(self._branch_combo)

        self._btn_new_branch = QPushButton("+ Branch")
        self._btn_new_branch.clicked.connect(self._on_new_branch)
        row1.addWidget(self._btn_new_branch)
        layout.addLayout(row1)

        # Commit row
        row2 = QHBoxLayout()
        self._commit_msg = QLineEdit()
        self._commit_msg.setPlaceholderText("Commit-Nachricht (leer = auto)")
        row2.addWidget(self._commit_msg)
        self._btn_commit = QPushButton("💾 Commit")
        self._btn_commit.clicked.connect(self._on_commit)
        self._btn_commit.setStyleSheet("background-color: #2D5A27; color: white;")
        row2.addWidget(self._btn_commit)
        layout.addLayout(row2)

        # Push / Pull row
        row3 = QHBoxLayout()
        self._btn_push = QPushButton("⬆️ Push")
        self._btn_push.clicked.connect(self._on_push)
        row3.addWidget(self._btn_push)
        self._btn_pull = QPushButton("⬇️ Pull")
        self._btn_pull.clicked.connect(self._on_pull)
        row3.addWidget(self._btn_pull)
        self._btn_merge = QPushButton("🔀 Merge")
        self._btn_merge.clicked.connect(self._on_merge)
        row3.addWidget(self._btn_merge)
        self._btn_stash = QPushButton("📦 Stash")
        self._btn_stash.clicked.connect(self._on_stash)
        row3.addWidget(self._btn_stash)
        layout.addLayout(row3)

        # History list
        layout.addWidget(QLabel("Commit-History:"))
        self._git_history = QListWidget()
        self._git_history.setMaximumHeight(200)
        self._git_history.setAlternatingRowColors(True)
        layout.addWidget(self._git_history)

        # Remote setup
        remote_group = QGroupBox("Remote (GitHub/GitLab)")
        rl = QHBoxLayout(remote_group)
        self._remote_url = QLineEdit()
        self._remote_url.setPlaceholderText("https://github.com/user/project.git")
        rl.addWidget(self._remote_url)
        self._btn_add_remote = QPushButton("Hinzufügen")
        self._btn_add_remote.clicked.connect(self._on_add_remote)
        rl.addWidget(self._btn_add_remote)
        layout.addWidget(remote_group)

        layout.addStretch()
        return w

    # ------------------------------------------------------------------
    # Collab Tab
    # ------------------------------------------------------------------

    def _create_collab_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(6)

        # Host / Join
        host_group = QGroupBox("Session")
        hl = QVBoxLayout(host_group)

        row_host = QHBoxLayout()
        self._btn_host = QPushButton("🌐 Session starten")
        self._btn_host.clicked.connect(self._on_host_session)
        self._btn_host.setStyleSheet("background-color: #1A5276; color: white;")
        row_host.addWidget(self._btn_host)
        row_host.addWidget(QLabel("Port:"))
        self._port_spin = QSpinBox()
        self._port_spin.setRange(1024, 65535)
        self._port_spin.setValue(9742)
        self._port_spin.setMaximumWidth(80)
        row_host.addWidget(self._port_spin)
        self._btn_stop_host = QPushButton("⏹️ Stoppen")
        self._btn_stop_host.clicked.connect(self._on_stop_session)
        self._btn_stop_host.setEnabled(False)
        row_host.addWidget(self._btn_stop_host)
        hl.addLayout(row_host)

        # Password (optional) + Max Users
        row_pw = QHBoxLayout()
        row_pw.addWidget(QLabel("Passwort:"))
        self._session_password = QLineEdit()
        self._session_password.setPlaceholderText("(optional)")
        self._session_password.setEchoMode(QLineEdit.EchoMode.Password)
        self._session_password.setMaximumWidth(120)
        row_pw.addWidget(self._session_password)
        row_pw.addWidget(QLabel("Max:"))
        self._max_users_spin = QSpinBox()
        self._max_users_spin.setRange(2, 64)
        self._max_users_spin.setValue(8)
        self._max_users_spin.setMaximumWidth(50)
        self._max_users_spin.setToolTip("Maximale Anzahl Teilnehmer")
        row_pw.addWidget(self._max_users_spin)
        row_pw.addStretch()
        hl.addLayout(row_pw)

        row_join = QHBoxLayout()
        self._join_url = QLineEdit()
        self._join_url.setPlaceholderText("ws://192.168.1.5:9742")
        row_join.addWidget(self._join_url)
        self._btn_join = QPushButton("🔗 Verbinden")
        self._btn_join.clicked.connect(self._on_join_session)
        row_join.addWidget(self._btn_join)
        self._btn_disconnect = QPushButton("❌ Trennen")
        self._btn_disconnect.clicked.connect(self._on_disconnect_client)
        self._btn_disconnect.setEnabled(False)
        row_join.addWidget(self._btn_disconnect)
        hl.addLayout(row_join)

        self._collab_status = QLabel("Nicht verbunden")
        self._collab_status.setStyleSheet("color: #888;")
        hl.addWidget(self._collab_status)
        self._share_url_label = QLabel("")
        self._share_url_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse)
        hl.addWidget(self._share_url_label)

        layout.addWidget(host_group)

        # Connected users
        layout.addWidget(QLabel("👥 Verbundene User:"))
        self._user_list = QListWidget()
        self._user_list.setMaximumHeight(120)
        layout.addWidget(self._user_list)

        # v0.0.20.868: Transport Sync option
        row_sync = QHBoxLayout()
        self._chk_transport_sync = QCheckBox("🔗 Transport Sync (Play/Stop)")
        self._chk_transport_sync.setChecked(False)
        self._chk_transport_sync.setToolTip(
            "Wenn aktiv: Play/Stop wird zwischen allen Teilnehmern synchronisiert.\n"
            "Wenn deaktiviert: Jeder steuert seinen eigenen Transport (empfohlen für Live).\n"
            "BPM wird immer synchronisiert.")
        row_sync.addWidget(self._chk_transport_sync)
        row_sync.addStretch()
        layout.addLayout(row_sync)

        # Chat
        layout.addWidget(QLabel("💬 Chat:"))
        self._chat_display = QTextEdit()
        self._chat_display.setReadOnly(True)
        self._chat_display.setMaximumHeight(150)
        self._chat_display.setStyleSheet("background-color: #1E1E1E; color: #DDD;")
        layout.addWidget(self._chat_display)

        row_chat = QHBoxLayout()
        self._chat_input = QLineEdit()
        self._chat_input.setPlaceholderText("Nachricht eingeben...")
        self._chat_input.returnPressed.connect(self._on_send_chat)
        row_chat.addWidget(self._chat_input)
        self._btn_send_chat = QPushButton("Senden")
        self._btn_send_chat.clicked.connect(self._on_send_chat)
        row_chat.addWidget(self._btn_send_chat)
        layout.addLayout(row_chat)

        # v0.0.20.860: LAN Session Discovery
        discovery_group = QGroupBox("🔍 Sessions im LAN")
        dl = QVBoxLayout(discovery_group)
        self._lan_sessions = QListWidget()
        self._lan_sessions.setMaximumHeight(80)
        self._lan_sessions.setAlternatingRowColors(True)
        self._lan_sessions.itemDoubleClicked.connect(self._on_lan_session_double_click)
        dl.addWidget(self._lan_sessions)
        row_discovery = QHBoxLayout()
        self._btn_browse = QPushButton("🔍 Suchen")
        self._btn_browse.clicked.connect(self._on_browse_lan)
        row_discovery.addWidget(self._btn_browse)
        self._btn_browse_stop = QPushButton("⏹️")
        self._btn_browse_stop.clicked.connect(self._on_stop_browse)
        self._btn_browse_stop.setEnabled(False)
        self._btn_browse_stop.setMaximumWidth(40)
        row_discovery.addWidget(self._btn_browse_stop)
        dl.addLayout(row_discovery)
        layout.addWidget(discovery_group)

        # v0.0.20.860: Undo/Redo
        row_undo = QHBoxLayout()
        self._btn_undo = QPushButton("↩ Undo")
        self._btn_undo.clicked.connect(self._on_collab_undo)
        self._btn_undo.setEnabled(False)
        row_undo.addWidget(self._btn_undo)
        self._btn_redo = QPushButton("↪ Redo")
        self._btn_redo.clicked.connect(self._on_collab_redo)
        self._btn_redo.setEnabled(False)
        row_undo.addWidget(self._btn_redo)
        layout.addLayout(row_undo)

        # v0.0.20.866: File transfer progress
        self._transfer_label = QLabel("")
        self._transfer_label.setStyleSheet("color: #4AFFF0; font-size: 11px;")
        self._transfer_label.setWordWrap(True)
        layout.addWidget(self._transfer_label)

        # Periodic status refresh
        self._collab_timer = QTimer(self)
        self._collab_timer.timeout.connect(self._periodic_collab_refresh)
        self._collab_timer.start(3000)  # every 3s

        # Internal state for discovery, conflict, undo
        self._discovery = None
        self._conflict_detector = None
        self._undo_log = None

        layout.addStretch()
        return w

    # ------------------------------------------------------------------
    # Review Tab
    # ------------------------------------------------------------------

    def _create_review_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(6)

        # Stats
        self._review_stats = QLabel("Keine Review-Daten")
        self._review_stats.setStyleSheet("font-weight: bold;")
        layout.addWidget(self._review_stats)

        # Add comment
        comment_group = QGroupBox("💬 Kommentar hinzufügen")
        cl = QVBoxLayout(comment_group)
        self._comment_text = QLineEdit()
        self._comment_text.setPlaceholderText("Kommentar eingeben...")
        cl.addWidget(self._comment_text)
        row_comment = QHBoxLayout()
        row_comment.addWidget(QLabel("Beat:"))
        self._comment_beat = QSpinBox()
        self._comment_beat.setRange(-1, 9999)
        self._comment_beat.setValue(-1)
        self._comment_beat.setSpecialValueText("Allgemein")
        row_comment.addWidget(self._comment_beat)
        self._btn_add_comment = QPushButton("➕ Kommentar")
        self._btn_add_comment.clicked.connect(self._on_add_comment)
        row_comment.addWidget(self._btn_add_comment)
        cl.addLayout(row_comment)
        layout.addWidget(comment_group)

        # Add task
        task_group = QGroupBox("✅ Aufgabe hinzufügen")
        tl = QHBoxLayout(task_group)
        self._task_text = QLineEdit()
        self._task_text.setPlaceholderText("Aufgabe beschreiben...")
        tl.addWidget(self._task_text)
        self._task_assignee = QLineEdit()
        self._task_assignee.setPlaceholderText("Zuweisen an...")
        self._task_assignee.setMaximumWidth(120)
        tl.addWidget(self._task_assignee)
        self._btn_add_task = QPushButton("➕")
        self._btn_add_task.clicked.connect(self._on_add_task)
        tl.addWidget(self._btn_add_task)
        layout.addWidget(task_group)

        # Comments list
        layout.addWidget(QLabel("Offene Kommentare:"))
        self._comment_list = QListWidget()
        self._comment_list.setMaximumHeight(150)
        self._comment_list.setAlternatingRowColors(True)
        layout.addWidget(self._comment_list)

        # Actions
        row_actions = QHBoxLayout()
        self._btn_resolve = QPushButton("✅ Lösen")
        self._btn_resolve.clicked.connect(self._on_resolve_comment)
        row_actions.addWidget(self._btn_resolve)
        self._btn_export_review = QPushButton("📋 Export")
        self._btn_export_review.clicked.connect(self._on_export_review)
        row_actions.addWidget(self._btn_export_review)
        self._btn_clear_resolved = QPushButton("🗑️ Gelöste entfernen")
        self._btn_clear_resolved.clicked.connect(self._on_clear_resolved)
        row_actions.addWidget(self._btn_clear_resolved)
        layout.addLayout(row_actions)

        layout.addStretch()
        return w

    # ------------------------------------------------------------------
    # Git Actions
    # ------------------------------------------------------------------

    def _on_git_init(self) -> None:
        gs = self._git_service
        if not gs:
            self.status_message.emit("Git Service nicht verfügbar", 3000)
            return
        if gs.init():
            self.status_message.emit("Git Repository initialisiert ✅", 3000)
            self.refresh_git()
        else:
            self.status_message.emit("Git Init fehlgeschlagen", 3000)

    def _on_commit(self) -> None:
        gs = self._git_service
        if not gs:
            return
        msg = self._commit_msg.text().strip()
        result = gs.commit(message=msg)
        if result:
            self.status_message.emit(
                f"Commit: {result.hash_short} — {result.message[:40]}", 3000)
            self._commit_msg.clear()
            self.refresh_git()
        else:
            self.status_message.emit("Nichts zu committen", 2000)

    def _on_branch_changed(self, name: str) -> None:
        gs = self._git_service
        if not gs or not name:
            return
        current = gs.current_branch()
        if name != current:
            gs.switch_branch(name)
            self.refresh_git()

    def _on_new_branch(self) -> None:
        gs = self._git_service
        if not gs:
            return
        name, ok = QInputDialog.getText(self, "Neuer Branch",
                                         "Branch-Name:", QLineEdit.EchoMode.Normal)
        if ok and name.strip():
            if gs.create_branch(name.strip()):
                self.status_message.emit(f"Branch '{name}' erstellt", 3000)
                self.refresh_git()

    def _on_push(self) -> None:
        gs = self._git_service
        if not gs:
            return
        ok, msg = gs.push(set_upstream=True)
        self.status_message.emit(msg, 3000)

    def _on_pull(self) -> None:
        gs = self._git_service
        if not gs:
            return
        ok, msg = gs.pull()
        self.status_message.emit(msg, 3000)
        if ok:
            self.refresh_git()

    def _on_merge(self) -> None:
        gs = self._git_service
        if not gs:
            return
        branches = gs.list_branches()
        current = gs.current_branch()
        other = [b.name for b in branches if b.name != current]
        if not other:
            self.status_message.emit("Kein anderer Branch zum Mergen", 2000)
            return
        name, ok = QInputDialog.getItem(
            self, "Branch mergen", "Branch auswählen:", other, 0, False)
        if ok and name:
            result = gs.merge_branch(name)
            if result.success:
                self.status_message.emit(f"✅ {result.message}", 3000)
            else:
                self.status_message.emit(f"⚠️ {result.message}", 5000)
            self.refresh_git()

    def _on_stash(self) -> None:
        gs = self._git_service
        if not gs:
            return
        stashes = gs.stash_list()
        if stashes:
            ok, msg = gs.stash_pop()
            self.status_message.emit(msg, 3000)
        else:
            gs.stash("Quick stash")
            self.status_message.emit("Changes stashed 📦", 2000)

    def _on_add_remote(self) -> None:
        gs = self._git_service
        if not gs:
            return
        url = self._remote_url.text().strip()
        if url:
            if gs.add_remote(url):
                self.status_message.emit(f"Remote hinzugefügt: {url}", 3000)
            else:
                self.status_message.emit("Remote hinzufügen fehlgeschlagen", 3000)

    # ------------------------------------------------------------------
    # Collab Actions
    # ------------------------------------------------------------------

    def _on_host_session(self) -> None:
        if not self._collab_server:
            from pydaw.services.collab_service import CollabServer
            port = self._port_spin.value()
            max_users = self._max_users_spin.value()
            self._collab_server = CollabServer(
                project_service=self._project_service,
                port=port,
                max_users=max_users,
            )
        server = self._collab_server
        # Apply password if set
        pw = self._session_password.text().strip()
        if pw:
            server.set_password(pw)
        server.set_callbacks(
            on_user_joined=lambda u: self._sig_users_changed.emit(),
            on_user_left=lambda u: self._sig_user_left.emit(u),
            on_chat=lambda m: self._sig_chat.emit(m) if not (self._collab_client and self._collab_client.is_connected()) else None,
            on_cursor=lambda m: self._sig_cursor.emit(m) if not (self._collab_client and self._collab_client.is_connected()) else None,
            on_operation=lambda m: self._sig_operation.emit(m) if not (self._collab_client and self._collab_client.is_connected()) else None,
        )
        if server.start():
            url = server.get_share_url()
            self._collab_status.setText(f"🟢 Session aktiv auf Port {server._port}")
            self._collab_status.setStyleSheet("color: #4AFF6B; font-weight: bold;")
            self._share_url_label.setText(f"Share-URL: {url}")
            self._btn_host.setEnabled(False)
            self._btn_stop_host.setEnabled(True)
            self._port_spin.setEnabled(False)
            self.status_message.emit(f"Collab Session gestartet: {url}", 5000)
            self._activate_mixer_hook()
        else:
            self.status_message.emit(
                "Collab Server Fehler — pip install websockets?", 5000)

    def _on_stop_session(self) -> None:
        self._deactivate_mixer_hook()
        if self._collab_server:
            self._collab_server.stop()
            self._collab_server = None  # allow re-creation with new port
        self._collab_status.setText("Nicht verbunden")
        self._collab_status.setStyleSheet("color: #888;")
        self._share_url_label.setText("")
        self._btn_host.setEnabled(True)
        self._btn_stop_host.setEnabled(False)
        self._port_spin.setEnabled(True)
        self._user_list.clear()
        # v0.0.20.858: Clear remote cursors from arranger
        if self._arranger_canvas:
            try:
                self._arranger_canvas.clear_collab_cursors()
            except Exception:
                pass
        # v0.0.20.860: Reset undo/conflict state
        self._cleanup_collab_state()

    def _on_join_session(self) -> None:
        url = self._join_url.text().strip()
        if not url:
            return
        name, ok = QInputDialog.getText(self, "Dein Name", "Name:", text="User")
        if not ok:
            return

        # Always clean up any old client first (prevents thread leak!)
        if self._collab_client:
            try:
                self._collab_client.disconnect()
            except Exception:
                pass
            self._collab_client = None

        from pydaw.services.collab_service import CollabClient
        self._collab_client = CollabClient()
        client = self._collab_client
        client.set_callbacks(
            connected=lambda: self._sig_connected.emit(),
            disconnected=lambda: self._sig_disconnected.emit(),
            chat=lambda m: self._sig_chat.emit(m),
            cursor=lambda m: self._sig_cursor.emit(m),
            presence=lambda m: self._sig_presence.emit(m),
            sync=lambda payload: self._sig_full_sync.emit(payload),
            operation=lambda m: self._sig_operation.emit(m),
        )

        pw = self._session_password.text().strip()
        self._collab_status.setText("⏳ Verbinde...")
        self._collab_status.setStyleSheet("color: #FFD74A;")
        self._btn_join.setEnabled(False)  # prevent double-click

        if client.connect(url, user_name=name or "User", password=pw):
            self._collab_status.setText(f"🟢 Verbunden mit {url}")
            self._collab_status.setStyleSheet("color: #4AFF6B; font-weight: bold;")
            self._btn_disconnect.setEnabled(True)
            self.status_message.emit(f"Verbunden mit {url}", 3000)
            self._activate_mixer_hook()
        else:
            self._collab_status.setText("🔴 Verbindung fehlgeschlagen")
            self._collab_status.setStyleSheet("color: #FF4444;")
            self._btn_join.setEnabled(True)  # re-enable for retry
            self.status_message.emit("Verbindung fehlgeschlagen", 3000)

    def _on_disconnect_client(self) -> None:
        """Disconnect from remote collab session."""
        self._deactivate_mixer_hook()
        if self._collab_client:
            self._collab_client.disconnect()
            self._collab_client = None
        self._collab_status.setText("Nicht verbunden")
        self._collab_status.setStyleSheet("color: #888;")
        self._btn_join.setEnabled(True)
        self._btn_disconnect.setEnabled(False)
        self._user_list.clear()
        # v0.0.20.858: Clear remote cursors from arranger
        if self._arranger_canvas:
            try:
                self._arranger_canvas.clear_collab_cursors()
            except Exception:
                pass
        # v0.0.20.860: Reset undo/conflict state
        self._cleanup_collab_state()
        self.status_message.emit("Collab-Verbindung getrennt", 2000)

    def _update_client_status(self, connected: bool) -> None:
        """Update UI after client connect/disconnect (must run on GUI thread)."""
        try:
            if connected:
                self._collab_status.setText("🟢 Verbunden")
                self._collab_status.setStyleSheet("color: #4AFF6B; font-weight: bold;")
                self._btn_join.setEnabled(False)
                self._btn_disconnect.setEnabled(True)
            else:
                self._collab_status.setText("🔴 Getrennt")
                self._collab_status.setStyleSheet("color: #FF4444;")
                self._btn_join.setEnabled(True)
                self._btn_disconnect.setEnabled(False)
                self._user_list.clear()
        except Exception:
            pass

    def _periodic_collab_refresh(self) -> None:
        """Periodically update user list and connection status."""
        try:
            # Update server status
            if self._collab_server:
                if self._collab_server.is_running():
                    users = self._collab_server.get_connected_users()
                    self._update_user_list(users)
                else:
                    # Server died unexpectedly
                    self._on_stop_session()

            # Update client status
            elif self._collab_client:
                if self._collab_client.is_connected():
                    users = self._collab_client.get_remote_users()
                    self._update_user_list(users)
                elif self._btn_disconnect.isEnabled():
                    # Was connected but lost connection
                    self._update_client_status(False)
        except Exception:
            pass

    def _update_user_list(self, users) -> None:
        """Update the user list widget."""
        self._user_list.clear()
        for u in users:
            idle_str = " (idle)" if getattr(u, 'is_idle', False) else ""
            item = QListWidgetItem(f"● {u.name}{idle_str}")
            item.setForeground(QColor(u.color))
            self._user_list.addItem(item)

    def _on_send_chat(self) -> None:
        text = self._chat_input.text().strip()
        if not text:
            return
        if self._collab_client and self._collab_client.is_connected():
            self._collab_client.send_chat(text)
            # Show own message locally (client doesn't echo back to sender for chat)
            from pydaw.services.collab_service import CollabMessage, OP_CHAT
            import time as _time
            own_msg = CollabMessage(type=OP_CHAT, user_id="self",
                                   user_name=self._collab_client._user_name,
                                   timestamp=_time.time(),
                                   payload={"text": text})
            self._append_chat(own_msg)
        elif self._collab_server and self._collab_server.is_running():
            # Host sends to all connected clients AND shows locally
            from pydaw.services.collab_service import CollabMessage, OP_CHAT
            import time as _time
            msg = CollabMessage(type=OP_CHAT, user_id="host",
                                user_name="Host", timestamp=_time.time(),
                                payload={"text": text})
            self._collab_server.broadcast_from_host(msg)
            self._append_chat(msg)
        self._chat_input.clear()

    def _append_chat(self, msg) -> None:
        try:
            text = msg.payload.get("text", "") if hasattr(msg, 'payload') else str(msg)
            name = getattr(msg, 'user_name', '?')
            self._chat_display.append(f"<b>{name}:</b> {text}")
        except Exception:
            pass

    def _refresh_users(self) -> None:
        users = []
        if self._collab_server and self._collab_server.is_running():
            users = self._collab_server.get_connected_users()
        elif self._collab_client and self._collab_client.is_connected():
            users = self._collab_client.get_remote_users()
        self._update_user_list(users)

    # ------------------------------------------------------------------
    # v0.0.20.858: Cursor Sharing
    # ------------------------------------------------------------------

    def set_arranger_canvas(self, canvas) -> None:
        """Wire arranger canvas for cursor sharing."""
        self._arranger_canvas = canvas

    def send_local_cursor(self, beat: float, track_id: str = "") -> None:
        """Send local cursor position to remote collaborators (throttled)."""
        try:
            # Throttle: skip if moved less than 0.25 beats
            if abs(beat - self._last_cursor_beat) < 0.25:
                return
            self._last_cursor_beat = beat
            if self._collab_client and self._collab_client.is_connected():
                self._collab_client.send_cursor(beat, track_id)
            elif self._collab_server and self._collab_server.is_running():
                from pydaw.services.collab_service import CollabMessage, OP_CURSOR
                import time as _time
                msg = CollabMessage(
                    type=OP_CURSOR, user_id="host",
                    payload={"beat": beat, "track_id": track_id},
                )
                self._collab_server.broadcast_from_host(msg)
        except Exception:
            pass

    def _on_remote_cursor(self, msg) -> None:
        """Apply remote cursor to arranger canvas."""
        canvas = self._arranger_canvas
        if not canvas:
            return
        try:
            beat = float(msg.payload.get("beat", 0))
            track_id = str(msg.payload.get("track_id", ""))
            user_id = str(msg.user_id)
            user_name = str(msg.user_name or user_id[:6])
            # Look up color from server/client user list
            color = "#4A9EFF"
            if self._collab_server and self._collab_server.is_running():
                for u in self._collab_server.get_connected_users():
                    if u.user_id == user_id:
                        color = u.color
                        user_name = u.name
                        break
            elif self._collab_client:
                for u in self._collab_client.get_remote_users():
                    if u.user_id == user_id:
                        color = u.color
                        user_name = u.name
                        break
            canvas.update_collab_cursor(user_id, beat, track_id, user_name, color)
        except Exception:
            pass

    def _on_remote_presence(self, msg) -> None:
        """Handle user join/leave — clean up cursors on leave."""
        self._refresh_users()
        canvas = self._arranger_canvas
        if not canvas:
            return
        try:
            action = msg.payload.get("action", "")
            user_id = str(msg.user_id)
            if action == "left":
                canvas.remove_collab_cursor(user_id)
        except Exception:
            pass

    def _host_user_left(self, user) -> None:
        """Handle user leave on host side."""
        self._refresh_users()
        canvas = self._arranger_canvas
        if canvas and user:
            try:
                canvas.remove_collab_cursor(user.user_id)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # v0.0.20.859: Transport Sync
    # ------------------------------------------------------------------

    def set_transport(self, transport) -> None:
        """Wire transport service for play/stop/bpm/loop sync."""
        self._transport = transport
        if not transport:
            return
        try:
            transport.playing_changed.connect(self._on_local_playing_changed)
            transport.bpm_changed.connect(self._on_local_bpm_changed)
            transport.loop_changed.connect(self._on_local_loop_changed)
        except Exception:
            pass
        # v0.0.20.872: Playhead position sync — throttled to ~8Hz
        try:
            self._last_playhead_broadcast = 0.0
            self._last_playhead_beat = -1.0
            transport.playhead_changed.connect(self._on_local_playhead_changed)
        except Exception:
            pass

    def _is_collab_active(self) -> bool:
        """Check if we're in an active collab session (host or client)."""
        if self._collab_client and self._collab_client.is_connected():
            return True
        if self._collab_server and self._collab_server.is_running():
            return True
        return False

    def _send_collab_op(self, payload: dict) -> None:
        """Send an operation to the collab session (host or client)."""
        if not self._is_collab_active():
            return
        op_type = payload.get("op_type", "?")
        try:
            if self._collab_client and self._collab_client.is_connected():
                log.info("[COLLAB-SEND] via client: %s", op_type)
                self._collab_client.send_op(payload)
            elif self._collab_server and self._collab_server.is_running():
                from pydaw.services.collab_service import CollabMessage, OP_OPERATION
                import time as _time
                msg = CollabMessage(
                    type=OP_OPERATION, user_id="host",
                    user_name="Host", timestamp=_time.time(),
                    payload=payload,
                )
                log.info("[COLLAB-SEND] via server broadcast: %s", op_type)
                self._collab_server.broadcast_from_host(msg)
            else:
                log.warning("[COLLAB-SEND] no route for op: %s", op_type)
        except Exception as e:
            log.warning("[COLLAB-SEND] error sending %s: %s", op_type, e)

    def _on_local_playing_changed(self, playing: bool) -> None:
        """Local transport play/stop → broadcast to collab."""
        if self._suppress_transport_ops:
            return
        # v0.0.20.868: Only sync play/stop if checkbox is checked
        if not self._chk_transport_sync.isChecked():
            return
        self._send_collab_op({
            "op_type": "transport_play" if playing else "transport_stop",
        })

    def _on_local_bpm_changed(self, bpm: float) -> None:
        """Local BPM change → broadcast to collab."""
        if self._suppress_transport_ops:
            return
        self._send_collab_op({
            "op_type": "transport_bpm",
            "bpm": float(bpm),
        })

    def _on_local_loop_changed(self, enabled: bool, start: float, end: float) -> None:
        """Local loop change → broadcast to collab."""
        if self._suppress_transport_ops:
            return
        self._send_collab_op({
            "op_type": "transport_loop",
            "enabled": bool(enabled),
            "start": float(start),
            "end": float(end),
        })

    def _on_local_playhead_changed(self, beat: float) -> None:
        """Local playhead position → broadcast to collab (throttled ~8Hz).

        v0.0.20.872: Sync the red playhead line between collaborators.
        Only sends when playing and when position changed by ≥0.5 beats.
        Non-playing seeks (click in ruler) are also sent immediately.
        """
        if self._suppress_transport_ops:
            return
        if not self._is_collab_active():
            return
        transport = self._transport
        if not transport:
            return
        import time as _time
        now = _time.time()
        is_playing = getattr(transport, 'playing', False)
        delta_beat = abs(beat - self._last_playhead_beat)

        if is_playing:
            # During playback: throttle to ~8Hz and ≥0.5 beat change
            if (now - self._last_playhead_broadcast) < 0.125:
                return
            if delta_beat < 0.5:
                return
        else:
            # When stopped (seek): send immediately if moved ≥0.1 beats
            if delta_beat < 0.1:
                return

        self._last_playhead_broadcast = now
        self._last_playhead_beat = beat
        self._send_collab_op({
            "op_type": "transport_seek",
            "beat": float(beat),
            "playing": bool(is_playing),
        })

    def _on_remote_operation(self, msg) -> None:
        """Apply a remote operation to local state."""
        try:
            payload = msg.payload if hasattr(msg, 'payload') else {}
            op_type = payload.get("op_type", "")
            transport = self._transport
            log.info("[COLLAB-RECV] op=%s from=%s",
                     op_type, getattr(msg, 'user_name', '?'))

            # v0.0.20.860: Conflict detection
            self._check_conflict(msg)

            if op_type == "transport_play" and transport:
                # v0.0.20.868: Only apply if transport sync is enabled
                if not self._chk_transport_sync.isChecked():
                    pass  # ignore
                else:
                    self._suppress_transport_ops = True
                    try:
                        if not transport.playing:
                            transport.set_playing(True)
                    finally:
                        self._suppress_transport_ops = False

            elif op_type == "transport_stop" and transport:
                # v0.0.20.868: Only apply if transport sync is enabled
                if not self._chk_transport_sync.isChecked():
                    pass  # ignore
                else:
                    self._suppress_transport_ops = True
                    try:
                        if transport.playing:
                            transport.set_playing(False)
                    finally:
                        self._suppress_transport_ops = False

            elif op_type == "transport_bpm" and transport:
                bpm = float(payload.get("bpm", 120))
                self._suppress_transport_ops = True
                try:
                    transport.set_bpm(bpm)
                    # v0.0.20.872: Update TransportPanel UI spinbox
                    try:
                        main_win = self.window()
                        if main_win and hasattr(main_win, 'transport'):
                            main_win.transport.set_bpm(bpm)
                    except Exception:
                        pass
                    # v0.0.20.868: Also update project model + UI
                    ps = self._project_service
                    if ps:
                        try:
                            ps.ctx.project.bpm = float(bpm)
                            ps.project_updated.emit()
                        except Exception:
                            pass
                finally:
                    self._suppress_transport_ops = False

            elif op_type == "transport_loop" and transport:
                enabled = bool(payload.get("enabled", False))
                start = float(payload.get("start", 0))
                end = float(payload.get("end", 16))
                self._suppress_transport_ops = True
                try:
                    transport.set_loop(enabled)
                    transport.set_loop_region(start, end)
                    # v0.0.20.872: Update loop checkbox in TransportPanel UI
                    try:
                        main_win = self.window()
                        if main_win and hasattr(main_win, 'transport'):
                            tp = main_win.transport
                            if hasattr(tp, 'chk_loop'):
                                tp.chk_loop.blockSignals(True)
                                tp.chk_loop.setChecked(enabled)
                                tp.chk_loop.blockSignals(False)
                    except Exception:
                        pass
                finally:
                    self._suppress_transport_ops = False

            elif op_type == "transport_seek" and transport:
                # v0.0.20.872: Playhead position sync
                beat = float(payload.get("beat", 0))
                self._suppress_transport_ops = True
                try:
                    transport.seek(beat)
                finally:
                    self._suppress_transport_ops = False

            elif op_type in ("track_volume", "track_pan", "track_mute",
                             "track_solo", "track_name", "track_color",
                             "track_record_arm"):
                self._apply_remote_track_op(payload)

            elif op_type in ("clip_move", "clip_resize", "clip_mute",
                             "clip_color"):
                self._apply_remote_clip_op(payload)

            # v0.0.20.863: Structural ops (track/clip add-remove)
            elif op_type in ("track_add", "track_remove",
                             "clip_add_midi", "clip_add_audio", "clip_remove"):
                self._apply_remote_structural_op(payload)

            # v0.0.20.864: MIDI notes + Automation sync
            elif op_type == "midi_notes_sync":
                self._apply_remote_midi_notes(payload)

            elif op_type == "automation_sync":
                self._apply_remote_automation(payload)

            # v0.0.20.865: Plugin/FX, Clip duplicate, Send routing
            elif op_type == "device_sync":
                self._apply_remote_device_sync(payload)

            elif op_type == "clip_duplicate":
                self._apply_remote_clip_duplicate(payload)

            elif op_type in ("send_add", "send_remove"):
                self._apply_remote_send_op(payload)

            # v0.0.20.873: Additional arranger ops
            elif op_type == "clip_trim":
                self._apply_remote_clip_trim(payload)

            elif op_type == "clip_rename":
                self._apply_remote_clip_rename(payload)

            elif op_type == "clip_copy_batch":
                self._apply_remote_clip_copy_batch(payload)

            elif op_type == "track_name":
                self._apply_remote_track_op(payload)

            # v0.0.20.875: Clip scale (Alt+Drag stretch)
            elif op_type == "clip_scale":
                self._apply_remote_clip_scale(payload)

            # v0.0.20.875: Track reorder + group/ungroup
            elif op_type == "track_reorder":
                self._apply_remote_track_reorder(payload)

            elif op_type == "track_group":
                self._apply_remote_track_group(payload)

            elif op_type == "track_ungroup":
                self._apply_remote_track_ungroup(payload)

            # v0.0.20.866: Media file streaming
            elif op_type.startswith("media_"):
                if self._media_sync:
                    self._media_sync.handle_op(payload)

            # v0.0.20.869: Late-joiner requests all instrument samples
            elif op_type == "request_instrument_samples":
                self._offer_all_instrument_samples()

            else:
                log.debug("[COLLAB-RECV] unhandled op_type: %s", op_type)

        except Exception as e:
            log.warning("[COLLAB-RECV] error handling op=%s: %s",
                        payload.get("op_type", "?"), e)

    def _apply_remote_track_op(self, payload: dict) -> None:
        """Apply a remote track operation to local project model."""
        try:
            ps = self._project_service
            if not ps:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            tid = payload.get("track_id", "")
            op = payload.get("op_type", "")
            for t in (proj.tracks or []):
                if str(getattr(t, 'id', '')) != tid:
                    continue
                if op == "track_volume":
                    t.volume = float(payload.get("volume", 0.8))
                elif op == "track_pan":
                    t.pan = float(payload.get("pan", 0.0))
                elif op == "track_mute":
                    t.muted = bool(payload.get("muted", False))
                elif op == "track_solo":
                    t.solo = bool(payload.get("solo", False))
                elif op == "track_name":
                    t.name = str(payload.get("name", ""))
                elif op == "track_color":
                    t.color = str(payload.get("color", ""))
                elif op == "track_record_arm":
                    t.record_arm = bool(payload.get("armed", False))
                break
            # Refresh mixer UI
            try:
                ps.project_updated.emit()
            except Exception:
                pass
        except Exception:
            pass

    # ------------------------------------------------------------------
    # v0.0.20.875: Track Reorder + Group/Ungroup
    # ------------------------------------------------------------------

    def _apply_remote_track_reorder(self, payload: dict) -> None:
        """Apply a remote track reorder to local project model."""
        try:
            ps = self._project_service
            if not ps:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj or not proj.tracks:
                return
            order = payload.get("order", [])
            if not order:
                return
            order_map = {str(tid): i for i, tid in enumerate(order)}
            # Sort tracks to match remote order; unknown tracks go to end
            from pydaw.services.project_service import ProjectService
            ProjectService._suppress_collab_notify = True
            try:
                proj.tracks.sort(
                    key=lambda t: order_map.get(str(getattr(t, 'id', '')), 99999))
            finally:
                ProjectService._suppress_collab_notify = False
            try:
                ps.project_updated.emit()
            except Exception:
                pass
        except Exception:
            pass

    def _apply_remote_track_group(self, payload: dict) -> None:
        """Apply a remote track group creation."""
        try:
            ps = self._project_service
            if not ps:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            group_id = str(payload.get("group_id", ""))
            group_name = str(payload.get("group_name", "Group"))
            track_ids = [str(x) for x in (payload.get("track_ids") or [])]
            order = payload.get("order", [])
            if not group_id or not track_ids:
                return

            from pydaw.services.project_service import ProjectService
            from pydaw.model.project import Track
            ProjectService._suppress_collab_notify = True
            try:
                tracks = proj.tracks or []
                # Check if group track already exists
                existing = any(str(getattr(t, 'id', '')) == group_id for t in tracks)
                if not existing:
                    # Create group-bus track with same ID as remote
                    group_track = Track(id=group_id, kind="group", name=group_name)
                    # Insert before first child
                    first_idx = len(tracks)
                    for i, t in enumerate(tracks):
                        if str(getattr(t, 'id', '')) in track_ids:
                            first_idx = min(first_idx, i)
                    tracks.insert(first_idx, group_track)
                # Assign children to group
                for t in tracks:
                    if str(getattr(t, 'id', '')) in track_ids:
                        t.track_group_id = group_id
                        t.track_group_name = group_name
                # Apply order if provided
                if order:
                    order_map = {str(tid): i for i, tid in enumerate(order)}
                    proj.tracks.sort(
                        key=lambda t: order_map.get(str(getattr(t, 'id', '')), 99999))
            finally:
                ProjectService._suppress_collab_notify = False
            try:
                ps.project_updated.emit()
            except Exception:
                pass
        except Exception:
            pass

    def _apply_remote_track_ungroup(self, payload: dict) -> None:
        """Apply a remote track ungroup operation."""
        try:
            ps = self._project_service
            if not ps:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            track_ids = [str(x) for x in (payload.get("track_ids") or [])]
            order = payload.get("order", [])
            if not track_ids:
                return

            from pydaw.services.project_service import ProjectService
            ProjectService._suppress_collab_notify = True
            try:
                tracks = proj.tracks or []
                group_ids_touched = set()
                for t in tracks:
                    if str(getattr(t, 'id', '')) in track_ids:
                        gid = str(getattr(t, 'track_group_id', '') or '')
                        if gid:
                            group_ids_touched.add(gid)
                        t.track_group_id = ''
                        t.track_group_name = ''
                # Remove empty group-bus tracks
                for gid in group_ids_touched:
                    still_has = any(
                        str(getattr(t, 'track_group_id', '') or '') == gid
                        for t in tracks
                        if str(getattr(t, 'kind', '')) != 'group'
                    )
                    if not still_has:
                        tracks[:] = [
                            t for t in tracks
                            if not (str(getattr(t, 'id', '')) == gid
                                    and str(getattr(t, 'kind', '')) == 'group')
                        ]
                # Apply order if provided
                if order:
                    order_map = {str(tid): i for i, tid in enumerate(order)}
                    proj.tracks.sort(
                        key=lambda t: order_map.get(str(getattr(t, 'id', '')), 99999))
            finally:
                ProjectService._suppress_collab_notify = False
            try:
                ps.project_updated.emit()
            except Exception:
                pass
        except Exception:
            pass

    def _apply_remote_clip_scale(self, payload: dict) -> None:
        """v0.0.20.875: Apply remote Alt+Drag clip scale (resize + stretch)."""
        try:
            ps = self._project_service
            if not ps:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            cid = str(payload.get("clip_id", ""))
            for c in (proj.clips or []):
                if str(getattr(c, 'id', '')) != cid:
                    continue
                if "start_beats" in payload:
                    c.start_beats = float(payload["start_beats"])
                if "length_beats" in payload:
                    c.length_beats = float(payload["length_beats"])
                if "stretch" in payload:
                    c.stretch = float(payload["stretch"])
                break
            try:
                ps.project_updated.emit()
            except Exception:
                pass
        except Exception:
            pass

    def _apply_remote_clip_op(self, payload: dict) -> None:
        """Apply a remote clip operation to local project model."""
        try:
            ps = self._project_service
            if not ps:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            cid = payload.get("clip_id", "")
            op = payload.get("op_type", "")
            for c in (proj.clips or []):
                if str(getattr(c, 'id', '')) != cid:
                    continue
                if op == "clip_move":
                    c.start_beats = float(payload.get("start_beats", 0))
                    new_track = payload.get("track_id", "")
                    if new_track:
                        c.track_id = str(new_track)
                elif op == "clip_resize":
                    length = float(payload.get("length_beats", 0))
                    if length > 0:
                        c.length_beats = length
                elif op == "clip_mute":
                    c.muted = bool(payload.get("muted", False))
                elif op == "clip_color":
                    c.color = str(payload.get("color", ""))
                break
            try:
                ps.project_updated.emit()
            except Exception:
                pass
        except Exception:
            pass

    def _apply_remote_structural_op(self, payload: dict) -> None:
        """Apply a remote track/clip add-remove operation."""
        try:
            ps = self._project_service
            if not ps:
                return
            op = payload.get("op_type", "")

            # Suppress our own collab_notify to avoid echo loop
            from pydaw.services.project_service import ProjectService
            ProjectService._suppress_collab_notify = True
            try:
                if op == "track_add":
                    kind = str(payload.get("kind", "audio"))
                    name = str(payload.get("name", "Track"))
                    idx = payload.get("index")
                    remote_id = payload.get("id") or payload.get("track_id", "")
                    trk = ps.add_track(kind, name,
                                 insert_index=int(idx) if idx is not None else None)
                    # v0.0.20.868: Apply full track state (plugin_type, instrument_state, etc.)
                    if trk:
                        # CRITICAL: Use the SAME track ID as the remote so clips/ops match
                        if remote_id:
                            # Update all references to the old ID
                            old_id = trk.id
                            trk.id = str(remote_id)
                            # Fix any clips that were auto-created with old ID
                            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
                            if proj:
                                for c in (proj.clips or []):
                                    if getattr(c, 'track_id', '') == old_id:
                                        c.track_id = str(remote_id)
                        for field in ("plugin_type", "instrument_enabled", "instrument_state",
                                      "audio_fx_chain", "note_fx_chain", "sf2_path", "sf2_bank",
                                      "sf2_preset", "sends", "sidechain_source_id",
                                      "channel_config", "output_target_id", "volume", "pan",
                                      "muted", "solo", "record_arm", "midi_input",
                                      "midi_channel_filter", "mpe_config"):
                            if field in payload and field not in ("op_type", "index"):
                                try:
                                    setattr(trk, field, payload[field])
                                except Exception:
                                    pass

                        # v0.0.20.873: INSTRUMENT INSTANTIATION on remote
                        # Without this, tracks appear but no instrument loads.
                        # v0.0.20.877: Use add_instrument_to_track() instead of show_track().
                        # show_track() only renders if user views that track, and silently
                        # swallows exceptions. add_instrument_to_track() creates the widget
                        # in the background regardless.
                        tid = str(trk.id)
                        plugin_type = str(getattr(trk, 'plugin_type', '') or '')
                        if plugin_type:
                            try:
                                main_win = self.window()
                                if main_win and hasattr(main_win, 'device_panel'):
                                    dp = main_win.device_panel
                                    from pydaw.ui.device_panel import DevicePanel
                                    DevicePanel._suppress_collab_hook = True
                                    try:
                                        ok = dp.add_instrument_to_track(tid, plugin_type)
                                        log.info("[COLLAB] track_add instrument: %s → %s (%s)",
                                                 tid[:8], plugin_type, ok)
                                    finally:
                                        DevicePanel._suppress_collab_hook = False
                            except Exception as e:
                                log.warning("[COLLAB] track_add instrument error: %s", e)

                        # Invalidate engine fingerprint + rebuild for ext plugins
                        try:
                            main_win = self.window()
                            ae = None
                            if main_win:
                                ae = getattr(getattr(main_win, 'services', None),
                                             'audio_engine', None)
                            if ae is None:
                                svc = getattr(ps, '_services', None)
                                if svc:
                                    ae = getattr(svc, 'audio_engine', None)
                            if ae:
                                ae._instrument_fingerprint = ""
                                proj2 = getattr(getattr(ps, 'ctx', None), 'project', None)
                                if proj2 and hasattr(ae, 'rebuild_fx_maps'):
                                    ae.rebuild_fx_maps(proj2)
                        except Exception:
                            pass

                elif op == "track_remove":
                    tid = str(payload.get("track_id", ""))
                    if tid:
                        ps.remove_track(tid)

                elif op == "clip_add_midi":
                    tid = str(payload.get("track_id", ""))
                    start = float(payload.get("start_beats", 0))
                    length = float(payload.get("length_beats", 4))
                    label = str(payload.get("label", "MIDI Clip"))
                    remote_clip_id = str(payload.get("clip_id", ""))
                    new_cid = ps.add_midi_clip_at(tid, start, length, label)
                    # v0.0.20.868: Use same clip ID so MIDI notes sync matches
                    if new_cid and remote_clip_id:
                        proj = getattr(getattr(ps, 'ctx', None), 'project', None)
                        if proj:
                            for c in (proj.clips or []):
                                if c.id == new_cid:
                                    old_cid = c.id
                                    c.id = remote_clip_id
                                    # Move midi_notes to new ID
                                    if old_cid in (proj.midi_notes or {}):
                                        proj.midi_notes[remote_clip_id] = proj.midi_notes.pop(old_cid, [])
                                    break

                elif op == "clip_add_audio":
                    # v0.0.20.871: Audio clip sync — create Clip directly
                    # (can't use add_audio_clip_from_file_at because it's async)
                    tid = str(payload.get("track_id", ""))
                    start = float(payload.get("start_beats", 0))
                    length = float(payload.get("length_beats", 4))
                    label = str(payload.get("label", "Audio Clip"))
                    remote_clip_id = str(payload.get("clip_id", ""))
                    file_name = str(payload.get("file_name", ""))
                    source_bpm = payload.get("source_bpm")
                    source_path_remote = str(payload.get("source_path", ""))

                    # Resolve local path from media dir
                    local_path = ""
                    proj = getattr(getattr(ps, 'ctx', None), 'project', None)
                    if proj and file_name:
                        media_dir = ""
                        ctx = getattr(ps, 'ctx', None)
                        if ctx and hasattr(ctx, 'resolve_media_dir'):
                            media_dir = ctx.resolve_media_dir()
                        if media_dir:
                            from pathlib import Path as P
                            candidate = P(media_dir) / file_name
                            if candidate.exists():
                                local_path = str(candidate)

                    if tid and proj:
                        from pydaw.model.project import Clip as ClipModel
                        clip = ClipModel(
                            kind="audio",
                            track_id=tid,
                            label=label,
                            source_path=local_path or source_path_remote,
                            source_bpm=source_bpm,
                        )
                        if remote_clip_id:
                            clip.id = remote_clip_id
                        clip.start_beats = max(0.0, start)
                        clip.length_beats = max(0.25, length)
                        # v0.0.20.875: Apply additional clip properties from payload
                        # (needed for consolidated clips with offset/gain/pan)
                        for attr in ("offset_beats", "gain", "pan"):
                            if attr in payload:
                                try:
                                    setattr(clip, attr, float(payload[attr]))
                                except Exception:
                                    pass
                        proj.clips.append(clip)
                        try:
                            ps.project_updated.emit()
                        except Exception:
                            pass

                elif op == "clip_remove":
                    cid = str(payload.get("clip_id", ""))
                    if cid:
                        ps.delete_clip(cid)
            finally:
                ProjectService._suppress_collab_notify = False

            # v0.0.20.872: Trigger audio engine rebuild after structural changes
            # Invalidate fingerprint to force slow path (plugin instantiation)
            try:
                proj = getattr(getattr(ps, 'ctx', None), 'project', None)
                main_win = self.window()
                if main_win and proj:
                    ae = getattr(getattr(main_win, 'services', None), 'audio_engine', None)
                    if ae and hasattr(ae, 'rebuild_fx_maps'):
                        ae._instrument_fingerprint = ""
                        ae.rebuild_fx_maps(proj)
            except Exception:
                pass

        except Exception as e:
            log.warning("[COLLAB] _apply_remote_structural_op error: op=%s %s",
                        payload.get("op_type", "?"), e)

    def _apply_remote_midi_notes(self, payload: dict) -> None:
        """Apply remote MIDI notes to a local clip."""
        try:
            ps = self._project_service
            if not ps:
                return
            clip_id = str(payload.get("clip_id", ""))
            notes = payload.get("notes", [])
            if not clip_id or not isinstance(notes, list):
                return
            # Suppress our own collab_notify to avoid echo
            from pydaw.services.project_service import ProjectService
            ProjectService._suppress_collab_notify = True
            try:
                ps._apply_midi_snapshot(clip_id, notes)
            finally:
                ProjectService._suppress_collab_notify = False
            try:
                ps.project_updated.emit()
            except Exception:
                pass
        except Exception:
            pass

    def _apply_remote_automation(self, payload: dict) -> None:
        """Apply remote automation breakpoints to local project."""
        try:
            ps = self._project_service
            if not ps:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            track_id = str(payload.get("track_id", ""))
            param = str(payload.get("param", ""))
            points = payload.get("points", [])
            if not track_id or not param:
                return
            lanes = getattr(proj, 'automation_lanes', {}) or {}
            tlanes = dict(lanes.get(track_id, {}) if track_id in lanes else {})
            tlanes[param] = list(points)
            lanes[track_id] = tlanes
            proj.automation_lanes = lanes
            try:
                ps.project_updated.emit()
            except Exception:
                pass
        except Exception:
            pass

    def send_automation_change(self, track_id: str, param: str, points: list) -> None:
        """Called by automation curve editor when breakpoints change."""
        if not self._is_collab_active():
            return
        self._send_collab_op({
            "op_type": "automation_sync",
            "track_id": str(track_id),
            "param": str(param),
            "points": list(points),
        })

    def send_device_change(self, track_id: str, device_data: dict) -> None:
        """Called by DevicePanel when plugin/FX chain changes."""
        if not self._is_collab_active():
            return
        pt = str(device_data.get("plugin_type", "") or "")
        log.info("[COLLAB-SEND] device_sync: track=%s plugin=%s",
                 str(track_id)[:8], pt or "(none)")
        self._send_collab_op({
            "op_type": "device_sync",
            "track_id": str(track_id),
            **device_data,
        })
        # v0.0.20.869: Offer instrument sample files via MediaSync
        if self._media_sync:
            ist = device_data.get("instrument_state")
            if isinstance(ist, dict):
                try:
                    self._media_sync.offer_instrument_samples(
                        str(track_id), ist)
                except Exception:
                    pass

    def _apply_remote_device_sync(self, payload: dict) -> None:
        """Apply remote plugin/FX chain changes to local track.

        v0.0.20.877: Use add_instrument_to_track() instead of show_track().
        show_track() only renders if the user is viewing that track, and
        _safe_render_current_track() silently swallows all exceptions.
        add_instrument_to_track() creates the widget in the background
        regardless of which track is currently displayed.
        """
        try:
            ps = self._project_service
            if not ps:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            tid = str(payload.get("track_id", ""))
            plugin_type = str(payload.get("plugin_type", "") or "")
            log.info("[COLLAB] device_sync received: track=%s plugin=%s",
                     tid[:8] if tid else "?", plugin_type or "(none)")

            # v0.0.20.870: Suppress all collab hooks during remote apply
            from pydaw.services.project_service import ProjectService
            from pydaw.ui.device_panel import DevicePanel
            ProjectService._suppress_collab_notify = True
            DevicePanel._suppress_collab_hook = True
            try:
                for t in (proj.tracks or []):
                    if str(getattr(t, 'id', '')) != tid:
                        continue
                    if "plugin_type" in payload:
                        t.plugin_type = payload["plugin_type"]
                    if "instrument_enabled" in payload:
                        t.instrument_enabled = bool(payload["instrument_enabled"])
                    if "instrument_state" in payload:
                        t.instrument_state = dict(payload["instrument_state"]) if isinstance(payload["instrument_state"], dict) else {}
                    if "audio_fx_chain" in payload:
                        t.audio_fx_chain = payload["audio_fx_chain"]
                    if "note_fx_chain" in payload:
                        t.note_fx_chain = payload["note_fx_chain"]
                    if "sf2_path" in payload:
                        t.sf2_path = payload.get("sf2_path", "")
                        t.sf2_bank = int(payload.get("sf2_bank", 0))
                        t.sf2_preset = int(payload.get("sf2_preset", 0))
                    break

                # v0.0.20.877: Use add_instrument_to_track() for INTERNAL instruments
                # (Registry plugins like bach_orgel, pro_audio_sampler, etc.)
                if plugin_type:
                    try:
                        main_win = self.window()
                        if main_win and hasattr(main_win, 'device_panel'):
                            dp = main_win.device_panel
                            if dp and hasattr(dp, 'add_instrument_to_track'):
                                ok = dp.add_instrument_to_track(tid, plugin_type)
                                log.info("[COLLAB] add_instrument_to_track(%s, %s) → %s",
                                         tid[:8], plugin_type, ok)
                    except Exception as e:
                        log.warning("[COLLAB] add_instrument_to_track failed: %s", e)

                # v0.0.20.878: ALWAYS force show_track() for EXTERNAL plugins
                # (VST2/VST3/CLAP/LV2 instruments live in audio_fx_chain, not
                # plugin_type). show_track() re-renders the FX chain widgets.
                # Without this, external instrument tracks show "Instrument — (empty)"
                # with no FX device cards on the remote.
                try:
                    main_win = self.window()
                    if main_win and hasattr(main_win, 'device_panel'):
                        dp = main_win.device_panel
                        if dp and hasattr(dp, 'show_track'):
                            dp.show_track(tid)
                            log.info("[COLLAB] show_track(%s) for FX chain refresh", tid[:8])
                except Exception as e:
                    log.warning("[COLLAB] show_track failed: %s", e)

                # Trigger full UI refresh
                try:
                    ps.project_updated.emit()
                except Exception:
                    pass
            finally:
                ProjectService._suppress_collab_notify = False
                DevicePanel._suppress_collab_hook = False

            # Invalidate engine fingerprint + rebuild
            try:
                main_win = self.window()
                ae = None
                if main_win:
                    ae = getattr(getattr(main_win, 'services', None),
                                 'audio_engine', None)
                if ae is None:
                    svc = getattr(self._project_service, '_services', None)
                    if svc:
                        ae = getattr(svc, 'audio_engine', None)
                if ae:
                    ae._instrument_fingerprint = ""
                    if hasattr(ae, 'rebuild_fx_maps'):
                        ae.rebuild_fx_maps(proj)
            except Exception:
                pass
        except Exception as e:
            log.warning("[COLLAB] _apply_remote_device_sync error: %s", e)

    def _apply_remote_clip_duplicate(self, payload: dict) -> None:
        """Apply a remote clip duplication."""
        try:
            ps = self._project_service
            if not ps:
                return
            from pydaw.services.project_service import ProjectService
            ProjectService._suppress_collab_notify = True
            try:
                # Create a new clip directly (don't call duplicate_clip to avoid re-notify)
                from pydaw.model.project import Clip
                clip = Clip(
                    kind=str(payload.get("kind", "midi")),
                    track_id=str(payload.get("track_id", "")),
                    start_beats=float(payload.get("start_beats", 0)),
                    length_beats=float(payload.get("length_beats", 4)),
                    label=str(payload.get("label", "Clip Copy")),
                )
                proj = getattr(getattr(ps, 'ctx', None), 'project', None)
                if proj:
                    proj.clips.append(clip)
                    # Copy MIDI notes from source if available
                    src_id = str(payload.get("source_clip_id", ""))
                    if clip.kind == "midi" and src_id:
                        import copy
                        src_notes = proj.midi_notes.get(src_id, [])
                        proj.midi_notes[clip.id] = [copy.deepcopy(n) for n in src_notes] if src_notes else []
                    try:
                        ps.project_updated.emit()
                    except Exception:
                        pass
            finally:
                ProjectService._suppress_collab_notify = False
        except Exception:
            pass

    def _apply_remote_send_op(self, payload: dict) -> None:
        """Apply remote send routing changes."""
        try:
            ps = self._project_service
            if not ps:
                return
            from pydaw.services.project_service import ProjectService
            ProjectService._suppress_collab_notify = True
            try:
                op = payload.get("op_type", "")
                src_id = str(payload.get("source_track_id", ""))
                tgt_id = str(payload.get("target_track_id", ""))
                if op == "send_add":
                    amount = float(payload.get("amount", 0.5))
                    pre = bool(payload.get("pre_fader", False))
                    ps.add_send(src_id, tgt_id, amount, pre)
                elif op == "send_remove":
                    ps.remove_send(src_id, tgt_id)
            finally:
                ProjectService._suppress_collab_notify = False
        except Exception:
            pass

    def _apply_remote_clip_trim(self, payload: dict) -> None:
        """v0.0.20.873: Apply remote clip left-trim."""
        try:
            ps = self._project_service
            if not ps:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            cid = str(payload.get("clip_id", ""))
            from pydaw.services.project_service import ProjectService
            ProjectService._suppress_collab_notify = True
            try:
                for c in (proj.clips or []):
                    if str(getattr(c, 'id', '')) != cid:
                        continue
                    c.start_beats = float(payload.get("start_beats", 0))
                    c.length_beats = max(0.25, float(payload.get("length_beats", 4)))
                    c.offset_beats = max(0.0, float(payload.get("offset_beats", 0)))
                    c.offset_seconds = max(0.0, float(payload.get("offset_seconds", 0)))
                    break
                ps.project_updated.emit()
            finally:
                ProjectService._suppress_collab_notify = False
        except Exception:
            pass

    def _apply_remote_clip_rename(self, payload: dict) -> None:
        """v0.0.20.873: Apply remote clip rename."""
        try:
            ps = self._project_service
            if not ps:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            cid = str(payload.get("clip_id", ""))
            label = str(payload.get("label", ""))
            from pydaw.services.project_service import ProjectService
            ProjectService._suppress_collab_notify = True
            try:
                for c in (proj.clips or []):
                    if str(getattr(c, 'id', '')) == cid:
                        c.label = label
                        break
                ps.project_updated.emit()
            finally:
                ProjectService._suppress_collab_notify = False
        except Exception:
            pass

    def _apply_remote_clip_copy_batch(self, payload: dict) -> None:
        """v0.0.20.873: Apply remote Ctrl+Drag batch copy."""
        try:
            ps = self._project_service
            if not ps:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            clips_data = payload.get("clips", [])
            if not isinstance(clips_data, list):
                return
            from pydaw.services.project_service import ProjectService
            from pydaw.model.project import Clip as ClipModel
            import copy
            ProjectService._suppress_collab_notify = True
            try:
                for cd in clips_data:
                    if not isinstance(cd, dict):
                        continue
                    clip = ClipModel(
                        kind=str(cd.get("kind", "midi")),
                        track_id=str(cd.get("track_id", "")),
                        label=str(cd.get("label", "Clip Copy")),
                    )
                    # Use remote ID so subsequent ops match
                    remote_id = str(cd.get("id", ""))
                    if remote_id:
                        clip.id = remote_id
                    clip.start_beats = max(0.0, float(cd.get("start_beats", 0)))
                    clip.length_beats = max(0.25, float(cd.get("length_beats", 4)))
                    # Copy optional fields
                    for f in ("source_path", "source_bpm", "stretch", "stretch_mode",
                              "offset_beats", "offset_seconds", "color", "muted"):
                        if f in cd:
                            try:
                                setattr(clip, f, cd[f])
                            except Exception:
                                pass
                    proj.clips.append(clip)
                    # Copy MIDI notes if provided
                    midi_notes = cd.get("midi_notes")
                    if isinstance(midi_notes, list) and clip.kind == "midi":
                        try:
                            ps._apply_midi_snapshot(str(clip.id), midi_notes)
                        except Exception:
                            proj.midi_notes[str(clip.id)] = []
                ps.project_updated.emit()
            finally:
                ProjectService._suppress_collab_notify = False
        except Exception:
            pass

    # ------------------------------------------------------------------
    # v0.0.20.859: Mixer Live Sync Hook
    # ------------------------------------------------------------------

    def send_mixer_change(self, track_id: str, param: str, value) -> None:
        """Called by mixer strip when fader/pan/mute/solo changes.

        Args:
            track_id: Track ID
            param: "volume" | "pan" | "mute" | "solo"
            value: float for volume/pan, bool for mute/solo
        """
        if not self._is_collab_active():
            return
        op_map = {
            "volume": ("track_volume", "volume"),
            "pan": ("track_pan", "pan"),
            "mute": ("track_mute", "muted"),
            "solo": ("track_solo", "solo"),
        }
        entry = op_map.get(param)
        if not entry:
            return
        op_payload = {
            "op_type": entry[0],
            "track_id": str(track_id),
            entry[1]: value,
        }
        # v0.0.20.876: Record for undo before sending
        cache_key = (str(track_id), entry[1])
        if not hasattr(self, '_undo_mixer_cache'):
            self._undo_mixer_cache = {}
        old_value = self._undo_mixer_cache.get(cache_key)
        if old_value is not None:
            inverse = dict(op_payload)
            inverse[entry[1]] = old_value
            self._push_undo(op_payload, inverse)
        self._undo_mixer_cache[cache_key] = value
        self._send_collab_op(op_payload)

    def _activate_mixer_hook(self) -> None:
        """Install collab hooks into mixer strips, project service, and automation."""
        try:
            from pydaw.ui.mixer import _MixerStrip
            _MixerStrip._collab_hook = self.send_mixer_change
        except Exception:
            pass
        # v0.0.20.876: Initialize undo mixer cache from current model
        self._init_undo_mixer_cache()
        # v0.0.20.863: Project service hook for track/clip add/remove + MIDI notes
        try:
            from pydaw.services.project_service import ProjectService
            ProjectService._collab_notify = self._on_local_project_change
        except Exception:
            pass
        # v0.0.20.864: Automation curve editor hook
        try:
            from pydaw.ui.automation_lanes import _AutomationCurveEditor
            _AutomationCurveEditor._collab_hook = self.send_automation_change
        except Exception:
            pass
        # v0.0.20.865: DevicePanel hook for plugin/FX chain sync
        try:
            from pydaw.ui.device_panel import DevicePanel
            DevicePanel._collab_hook = self.send_device_change
        except Exception:
            pass
        # v0.0.20.866: Media sync service for audio file streaming
        try:
            from pydaw.services.media_sync_service import MediaSyncService
            from pydaw.services.project_service import ProjectService as _PS2
            self._media_sync = MediaSyncService(
                project_service=self._project_service,
                send_op=self._send_collab_op,
                on_progress=lambda h, p, l: self._sig_media_progress.emit(h, p, l),
                on_instrument_sample_ready=lambda tid: self._sig_instrument_sample_ready.emit(tid),
            )
            self._media_sync.scan_project_media()
            _PS2._media_sync_hook = self._media_sync.offer_file
        except Exception:
            pass

    def _deactivate_mixer_hook(self) -> None:
        """Remove all collab hooks."""
        try:
            from pydaw.ui.mixer import _MixerStrip
            _MixerStrip._collab_hook = None
        except Exception:
            pass
        try:
            from pydaw.services.project_service import ProjectService
            ProjectService._collab_notify = None
            ProjectService._media_sync_hook = None
        except Exception:
            pass
        try:
            from pydaw.ui.automation_lanes import _AutomationCurveEditor
            _AutomationCurveEditor._collab_hook = None
        except Exception:
            pass
        try:
            from pydaw.ui.device_panel import DevicePanel
            DevicePanel._collab_hook = None
        except Exception:
            pass
        # v0.0.20.866: Shutdown media sync
        if self._media_sync:
            try:
                self._media_sync.shutdown()
            except Exception:
                pass
            self._media_sync = None
        self._transfer_label.setText("")

    def _on_local_project_change(self, op_type: str, data: dict) -> None:
        """Called by ProjectService when a track/clip is added or removed."""
        log.debug("[COLLAB-HOOK] _on_local_project_change: op=%s", op_type)
        self._send_collab_op({"op_type": op_type, **data})
        # v0.0.20.869: Offer instrument samples when a track with samples is added
        if op_type == "track_add" and self._media_sync:
            ist = data.get("instrument_state")
            if isinstance(ist, dict):
                track_id = str(data.get("id") or data.get("track_id", ""))
                if track_id:
                    try:
                        self._media_sync.offer_instrument_samples(track_id, ist)
                    except Exception:
                        pass

    # ------------------------------------------------------------------
    # v0.0.20.860: LAN Session Discovery
    # ------------------------------------------------------------------

    def _on_browse_lan(self) -> None:
        """Start mDNS discovery for Py_DAW sessions."""
        try:
            from pydaw.services.collab_service import CollabDiscovery
            if self._discovery:
                self._discovery.stop()
            self._discovery = CollabDiscovery()
            ok = self._discovery.start(
                on_found=lambda s: self._sig_lan_found.emit(s),
                on_lost=lambda s: self._sig_lan_lost.emit(s),
            )
            if ok:
                self._btn_browse.setEnabled(False)
                self._btn_browse_stop.setEnabled(True)
                self._lan_sessions.clear()
                self.status_message.emit("🔍 Suche Sessions im LAN...", 3000)
            else:
                self.status_message.emit(
                    "mDNS nicht verfügbar — pip install zeroconf", 5000)
        except Exception:
            pass

    def _on_stop_browse(self) -> None:
        """Stop mDNS discovery."""
        if self._discovery:
            self._discovery.stop()
            self._discovery = None
        self._btn_browse.setEnabled(True)
        self._btn_browse_stop.setEnabled(False)

    def _add_lan_session(self, session) -> None:
        """Add a discovered session to the list."""
        try:
            pw_icon = "🔒 " if session.has_password else ""
            text = f"{pw_icon}{session.name} — {session.url}"
            item = QListWidgetItem(text)
            item.setData(Qt.ItemDataRole.UserRole, session.url)
            self._lan_sessions.addItem(item)
        except Exception:
            pass

    def _remove_lan_session(self, session) -> None:
        """Remove a session from the list."""
        try:
            for i in range(self._lan_sessions.count()):
                item = self._lan_sessions.item(i)
                if item and item.data(Qt.ItemDataRole.UserRole) == session.url:
                    self._lan_sessions.takeItem(i)
                    break
        except Exception:
            pass

    def _on_lan_session_double_click(self, item) -> None:
        """Double-click a discovered session to connect."""
        try:
            url = item.data(Qt.ItemDataRole.UserRole)
            if url:
                self._join_url.setText(url)
                self._on_join_session()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # v0.0.20.860: Conflict Detection
    # ------------------------------------------------------------------

    def _ensure_conflict_detector(self) -> None:
        """Create conflict detector if not exists."""
        if self._conflict_detector is None:
            try:
                from pydaw.services.collab_service import ConflictDetector
                self._conflict_detector = ConflictDetector(window_ms=2000)
            except Exception:
                pass

    def _check_conflict(self, msg) -> None:
        """Check an incoming operation for conflicts and show warning."""
        try:
            self._ensure_conflict_detector()
            if not self._conflict_detector:
                return
            payload = msg.payload if hasattr(msg, 'payload') else {}
            op_type = payload.get("op_type", "")
            track_id = payload.get("track_id", "")
            user_id = getattr(msg, 'user_id', '')
            if not track_id or not user_id:
                return

            # Extract the value being set
            value = ""
            if "volume" in payload:
                value = payload["volume"]
            elif "pan" in payload:
                value = payload["pan"]
            elif "muted" in payload:
                value = payload["muted"]
            elif "solo" in payload:
                value = payload["solo"]
            elif "name" in payload:
                value = payload["name"]
            else:
                return

            conflict = self._conflict_detector.record_edit(
                user_id, track_id, op_type, value
            )
            if conflict:
                self._show_conflict_warning(conflict)
        except Exception:
            pass

    def _show_conflict_warning(self, conflict) -> None:
        """Show a non-blocking conflict warning in the status bar."""
        try:
            self.status_message.emit(
                f"⚠️ Konflikt: {conflict.user_a} und {conflict.user_b} "
                f"bearbeiten gleichzeitig {conflict.param} "
                f"(Track {conflict.track_id[:8]}…)",
                5000
            )
            # Also show in chat
            self._chat_display.append(
                f"<i style='color:#FF6B4A;'>⚠️ Konflikt: "
                f"{conflict.user_a} ↔ {conflict.user_b} "
                f"bei {conflict.param}</i>"
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    # v0.0.20.860: Undo/Redo
    # ------------------------------------------------------------------

    def _ensure_undo_log(self) -> None:
        """Create undo log if not exists."""
        if self._undo_log is None:
            try:
                from pydaw.services.collab_service import CollabUndoLog
                self._undo_log = CollabUndoLog()
            except Exception:
                pass

    def _push_undo(self, op_payload: dict, inverse_payload: dict) -> None:
        """v0.0.20.876: Record a local operation for undo.

        Args:
            op_payload: The operation that was sent (forward)
            inverse_payload: The operation that would reverse it
        """
        try:
            self._ensure_undo_log()
            if not self._undo_log:
                return
            if not op_payload.get("op_type") or not inverse_payload.get("op_type"):
                return
            from pydaw.services.collab_service import CollabMessage
            import time as _time
            msg = CollabMessage(
                type="operation",
                user_id="local",
                user_name="Local",
                timestamp=_time.time(),
                payload=dict(op_payload),
            )
            self._undo_log.push(msg, dict(inverse_payload))
            self._btn_undo.setEnabled(True)
        except Exception:
            pass

    def _on_collab_undo(self) -> None:
        """Undo the last collab operation.

        v0.0.20.876: Fixed — now also applies the inverse locally.
        Previously it only sent to the network but the local client
        never received it back (server excludes sender from broadcast).
        """
        try:
            self._ensure_undo_log()
            if not self._undo_log:
                return
            entry = self._undo_log.undo()
            if entry:
                # Send inverse to other clients via network
                self._send_collab_op(entry.inverse_payload)
                # Apply inverse locally (server excludes sender)
                self._apply_undo_redo_locally(entry.inverse_payload)
                self._btn_redo.setEnabled(True)
                self.status_message.emit(
                    f"↩ Undo: {entry.op_type}", 3000)
            else:
                self.status_message.emit("Nichts zum Rückgängig machen", 2000)
            if not self._undo_log._log:
                self._btn_undo.setEnabled(False)
        except Exception:
            pass

    def _on_collab_redo(self) -> None:
        """Redo the last undone operation.

        v0.0.20.876: Fixed — now also applies the original locally.
        """
        try:
            self._ensure_undo_log()
            if not self._undo_log:
                return
            entry = self._undo_log.redo()
            if entry:
                # Send original op to other clients
                self._send_collab_op(entry.payload)
                # Apply original locally
                self._apply_undo_redo_locally(entry.payload)
                self._btn_undo.setEnabled(True)
                self.status_message.emit(
                    f"↪ Redo: {entry.op_type}", 3000)
            else:
                self.status_message.emit("Nichts zum Wiederherstellen", 2000)
            if not self._undo_log._redo_stack:
                self._btn_redo.setEnabled(False)
        except Exception:
            pass

    def _apply_undo_redo_locally(self, payload: dict) -> None:
        """v0.0.20.876: Apply an undo/redo op to the local model + UI.

        Uses the same handlers as remote operations but with suppress
        flags to prevent re-sending to the network.
        """
        try:
            from pydaw.services.project_service import ProjectService
            ProjectService._suppress_collab_notify = True
            try:
                self._on_remote_operation(payload)
            finally:
                ProjectService._suppress_collab_notify = False
        except Exception:
            pass

    def _cleanup_collab_state(self) -> None:
        """Reset all collab-related state (discovery, conflict, undo)."""
        if self._conflict_detector:
            self._conflict_detector.clear()
        if self._undo_log:
            self._undo_log.clear()
        self._btn_undo.setEnabled(False)
        self._btn_redo.setEnabled(False)
        # v0.0.20.876: Clear undo mixer cache
        self._undo_mixer_cache = {}

    def _init_undo_mixer_cache(self) -> None:
        """v0.0.20.876: Populate undo cache from current project model.

        This must be called when the collab session starts so that the
        first change to any mixer param has an old value to record.
        """
        self._undo_mixer_cache = {}
        try:
            ps = self._project_service
            if not ps:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            for t in (proj.tracks or []):
                tid = str(getattr(t, 'id', ''))
                if not tid:
                    continue
                self._undo_mixer_cache[(tid, "volume")] = float(getattr(t, 'volume', 0.8))
                self._undo_mixer_cache[(tid, "pan")] = float(getattr(t, 'pan', 0.0))
                self._undo_mixer_cache[(tid, "muted")] = bool(getattr(t, 'muted', False))
                self._undo_mixer_cache[(tid, "solo")] = bool(getattr(t, 'solo', False))
        except Exception:
            pass

    def _update_transfer_progress(self, file_hash: str, pct: int, label: str) -> None:
        """Update the file transfer progress label (called via signal, GUI-safe)."""
        try:
            if pct >= 100 or pct < 0:
                # Clear after 3 seconds
                QTimer.singleShot(3000, lambda: self._transfer_label.setText(""))
            self._transfer_label.setText(label if pct < 100 else f"✅ {label}")
        except Exception:
            pass

    def _on_instrument_sample_ready(self, track_id: str) -> None:
        """Refresh DevicePanel after an instrument sample file was received.

        v0.0.20.869: When a sample file transfer completes and the local
        instrument_state path has been rewritten, force the DevicePanel
        to re-render so the instrument picks up the new local file.
        """
        try:
            main_win = self.window()
            if not main_win:
                return
            dp = getattr(main_win, 'device_panel', None)
            if dp and hasattr(dp, 'show_track'):
                # Only re-render if currently viewing this track
                current = str(getattr(dp, '_current_track', ''))
                if current == track_id:
                    dp.show_track(track_id)
            # Also trigger audio engine rebuild for the track
            ps = self._project_service
            if ps:
                proj = getattr(getattr(ps, 'ctx', None), 'project', None)
                if proj:
                    ae = getattr(getattr(main_win, 'services', None),
                                 'audio_engine', None)
                    if ae and hasattr(ae, 'rebuild_fx_maps'):
                        ae.rebuild_fx_maps(proj)
        except Exception:
            pass

    def _offer_all_instrument_samples(self) -> None:
        """Offer all instrument sample files to the requesting participant.

        v0.0.20.869: Called on the host when a late-joiner sends
        'request_instrument_samples'. Scans all tracks for samples
        and offers them via MediaSync.
        """
        if not self._media_sync:
            return
        try:
            ps = self._project_service
            if not ps:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            for trk in (proj.tracks or []):
                ist = getattr(trk, 'instrument_state', None)
                if isinstance(ist, dict) and ist:
                    tid = str(getattr(trk, 'id', ''))
                    if tid:
                        self._media_sync.offer_instrument_samples(tid, ist)
        except Exception:
            pass

    def _apply_full_sync(self, payload) -> None:
        """Apply full project state from server on late-join.

        v0.0.20.867: When a client joins, the server sends the complete
        project dict. We apply it to the local project model so the
        late-joiner sees the current state of the session.
        """
        try:
            ps = self._project_service
            if not ps:
                return
            project_data = payload.get("project", {}) if isinstance(payload, dict) else {}
            if not project_data or not isinstance(project_data, dict):
                # No project data — just refresh users
                self._refresh_users()
                return

            # Apply the full project state
            ctx = getattr(ps, 'ctx', None)
            if not ctx:
                self._refresh_users()
                return
            proj = getattr(ctx, 'project', None)
            if not proj or not hasattr(proj, 'from_dict'):
                self._refresh_users()
                return

            # Suppress collab notifications during sync (prevent echo)
            from pydaw.services.project_service import ProjectService
            ProjectService._suppress_collab_notify = True
            try:
                # Use from_dict to rebuild the project from the server state
                new_proj = type(proj).from_dict(project_data)
                if new_proj:
                    # Preserve local-only state
                    old_media_dir = getattr(ctx, '_media_dir', None)
                    old_project_file = getattr(ctx, '_project_file', None)

                    # Replace project data
                    ctx.project = new_proj

                    # Restore local paths
                    if old_media_dir:
                        ctx._media_dir = old_media_dir
                    if old_project_file:
                        ctx._project_file = old_project_file

                    log.info("Full sync applied: %d tracks, %d clips",
                             len(getattr(new_proj, 'tracks', []) or []),
                             len(getattr(new_proj, 'clips', []) or []))
            finally:
                ProjectService._suppress_collab_notify = False

            # Refresh everything
            try:
                ps.project_updated.emit()
            except Exception:
                pass
            # v0.0.20.872: Sync transport BPM from received project + update UI
            try:
                new_bpm = float(getattr(new_proj, 'bpm', 120.0) or 120.0)
                if self._transport and new_bpm > 0:
                    self._suppress_transport_ops = True
                    try:
                        self._transport.set_bpm(new_bpm)
                        # Update TransportPanel UI spinbox
                        main_win = self.window()
                        if main_win and hasattr(main_win, 'transport'):
                            main_win.transport.set_bpm(new_bpm)
                        log.info("Full sync: BPM set to %.1f", new_bpm)
                    finally:
                        self._suppress_transport_ops = False
            except Exception:
                pass
            # Also load automation if available
            try:
                if hasattr(ps, 'load_automation_manager_from_project'):
                    ps.load_automation_manager_from_project()
            except Exception:
                pass
            # v0.0.20.872: Force audio engine rebuild with invalidated fingerprint
            try:
                main_win = self.window()
                if main_win:
                    ae = getattr(getattr(main_win, 'services', None),
                                 'audio_engine', None)
                    new_proj_ref = getattr(getattr(ps, 'ctx', None), 'project', None)
                    if ae and new_proj_ref and hasattr(ae, 'rebuild_fx_maps'):
                        ae._instrument_fingerprint = ""
                        ae.rebuild_fx_maps(new_proj_ref)
            except Exception:
                pass

            # v0.0.20.877: Instantiate instruments on ALL tracks after full sync.
            # Use add_instrument_to_track() which creates widgets in the background.
            try:
                main_win = self.window()
                if main_win and hasattr(main_win, 'device_panel'):
                    dp = main_win.device_panel
                    new_proj_ref = getattr(getattr(ps, 'ctx', None), 'project', None)
                    if dp and new_proj_ref:
                        from pydaw.ui.device_panel import DevicePanel
                        DevicePanel._suppress_collab_hook = True
                        try:
                            for t in (getattr(new_proj_ref, 'tracks', []) or []):
                                pt = str(getattr(t, 'plugin_type', '') or '')
                                if pt:
                                    try:
                                        ok = dp.add_instrument_to_track(str(t.id), pt)
                                        log.info("[COLLAB] full_sync instrument: %s → %s (%s)",
                                                 str(t.id)[:8], pt, ok)
                                    except Exception as e:
                                        log.warning("[COLLAB] full_sync instrument error: %s", e)
                        finally:
                            DevicePanel._suppress_collab_hook = False
            except Exception:
                pass

            self._refresh_users()
            self.status_message.emit(
                "📥 Projekt-State synchronisiert", 3000)

            # v0.0.20.869: Request instrument samples from the host
            # After full sync, sample paths are from the remote machine.
            # Ask host to offer all instrument samples so we can download them.
            try:
                self._send_collab_op({
                    "op_type": "request_instrument_samples",
                })
            except Exception:
                pass

        except Exception as e:
            log.warning("Full sync failed: %s", e)
            self._refresh_users()

    # ------------------------------------------------------------------
    # Review Actions
    # ------------------------------------------------------------------

    def _on_add_comment(self) -> None:
        rs = self._review_service
        if not rs:
            return
        text = self._comment_text.text().strip()
        if not text:
            return
        beat = float(self._comment_beat.value())
        rs.add_comment(text=text, beat=beat)
        self._comment_text.clear()
        self.refresh_review()

    def _on_add_task(self) -> None:
        rs = self._review_service
        if not rs:
            return
        text = self._task_text.text().strip()
        if not text:
            return
        assignee = self._task_assignee.text().strip()
        rs.add_task(text=text, assignee=assignee)
        self._task_text.clear()
        self.refresh_review()

    def _on_resolve_comment(self) -> None:
        rs = self._review_service
        if not rs:
            return
        item = self._comment_list.currentItem()
        if not item:
            return
        comment_id = item.data(Qt.ItemDataRole.UserRole)
        if comment_id:
            rs.resolve_comment(comment_id)
            self.refresh_review()

    def _on_export_review(self) -> None:
        rs = self._review_service
        if not rs:
            return
        summary = rs.export_summary()
        # Show in a dialog
        dlg = QMessageBox(self)
        dlg.setWindowTitle("Review Summary")
        dlg.setText(summary[:500])
        dlg.setDetailedText(summary)
        dlg.exec()

    def _on_clear_resolved(self) -> None:
        rs = self._review_service
        if not rs:
            return
        rs.clear_resolved()
        self.refresh_review()

    # ------------------------------------------------------------------
    # Refresh methods
    # ------------------------------------------------------------------

    def refresh_git(self) -> None:
        """Update Git tab UI from current state."""
        gs = self._git_service
        if not gs or not gs.is_repo_initialized():
            self._git_status_label.setText("Git: nicht initialisiert")
            self._git_branch_label.setText("")
            self._git_history.clear()
            return

        status = gs.get_status()
        clean = "✅ clean" if status.is_clean else f"⚠️ {len(status.modified)} geändert"
        self._git_status_label.setText(f"Git: {clean}")
        self._git_branch_label.setText(f"🔀 {status.branch}")

        # Update branch combo
        branches = gs.list_branches()
        self._branch_combo.blockSignals(True)
        self._branch_combo.clear()
        for b in branches:
            self._branch_combo.addItem(b.name)
            if b.is_current:
                self._branch_combo.setCurrentText(b.name)
        self._branch_combo.blockSignals(False)

        # Update history
        self._git_history.clear()
        commits = gs.get_log(max_count=20)
        for c in commits:
            self._git_history.addItem(
                f"{c.hash_short}  {c.date[:10]}  {c.message[:50]}")

        # Remote
        if status.has_remote:
            self._remote_url.setText(status.remote_url)

    def refresh_review(self) -> None:
        """Update Review tab UI from current state."""
        rs = self._review_service
        if not rs:
            return

        stats = rs.get_stats()
        self._review_stats.setText(
            f"💬 {stats['comments_open']} offen  "
            f"✅ {stats['comments_resolved']} gelöst  "
            f"📋 {stats['tasks_open']} Tasks  "
            f"🏁 {stats['markers']} Marker"
        )

        # Comments
        self._comment_list.clear()
        for c in rs.get_comments(status="open"):
            pos = f"Beat {c.beat:.0f}" if c.beat >= 0 else "📌"
            item = QListWidgetItem(f"{pos} — {c.text[:60]}  [{c.author}]")
            item.setData(Qt.ItemDataRole.UserRole, c.id)
            self._comment_list.addItem(item)

    def shutdown(self) -> None:
        """Clean shutdown — stop discovery, server, client, media sync.

        v0.0.20.869: Must be called from MainWindow.closeEvent BEFORE
        SandboxProcessManager.shutdown() to prevent zeroconf segfault.
        """
        try:
            if self._discovery:
                self._discovery.stop()
                self._discovery = None
        except Exception:
            pass
        try:
            self._deactivate_mixer_hook()
        except Exception:
            pass
        try:
            if self._collab_client:
                self._collab_client.disconnect()
                self._collab_client = None
        except Exception:
            pass
        try:
            if self._collab_server:
                self._collab_server.stop()
                self._collab_server = None
        except Exception:
            pass

    def refresh_all(self) -> None:
        """Refresh all tabs."""
        try:
            self.refresh_git()
        except Exception:
            pass
        try:
            self.refresh_review()
        except Exception:
            pass
