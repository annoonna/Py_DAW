# Session Log — v0.0.20.803

**Datum:** 2026-03-25
**Kollege:** Claude Opus 4.6
**Arbeitspaket:** P0 Stabilisierung — Externe Plugins verstummen nach erstem Ton
**Aufgabe:** VST2/VST3/CLAP/LV2 Plugins geben auf Arch Linux nur kurz Ton

## Root Cause

**Der Audio-Stream wird bei JEDEM neuen Plugin komplett neu gestartet.**

In `_create_vst_instrument_engines()` (Zeile ~3023):
```python
if n_new > 0:
    self.stop()                    # ← KILLT den gesamten Audio-Stream!
    time.sleep(0.1)
    self.ensure_preview_output()   # ← Neuer Stream, arrangement_state=None
```

Das passiert bei:
- Jedem Track-Wechsel → Worker-Thread scannt → findet "neues" Plugin → RESTART
- Jedem Plugin-Laden → n_new > 0 → RESTART
- Sogar beim Zurückwechseln zu einem bestehenden Track → RESTART

Ergebnis:
1. Plugin bekommt erste Note → spielt kurz
2. Worker-Thread: stop() → Audio-Stream stirbt
3. 100ms Stille
4. Neuer Stream → arrangement_state=None → keine MIDI-Events mehr
5. Plugin wartet auf Noten die nie kommen → Stille

Auf Debian überlebt es zufällig weil:
- PipeWire-Timing ist toleranter (größere Buffer-Margins)
- Stream-Restart ist schneller
- Arrangement-State wird schneller wiederhergestellt

Auf Arch mit straffem PipeWire-Timing manifestiert sich der Bug sofort.

## Fix

**Nur noch beim ersten Plugin-Laden den Stream neu starten (1024→8192 Buffer).**
Danach NIE WIEDER. Neue Pull-Sources werden dynamisch via `register_pull_source()`
registriert und vom nächsten Audio-Callback automatisch abgeholt.

```python
current_bs = self._config.get('buffer_size', 0)
if current_bs >= 8192:
    # Stream OK — kein Restart! Pull-Sources wurden schon registriert.
    print("Stream OK, no restart")
    self.hot_swap_arrangement()  # Nur MIDI-Events aktualisieren
elif n_new > 0:
    # Erster Plugin-Load: Buffer muss von 1024 auf 8192 wachsen
    self.stop()
    self.ensure_preview_output()
    self.hot_swap_arrangement()
```

## Was wurde erledigt
- Root Cause: Audio-Stream wird bei jedem Plugin-Load komplett neugestartet
- Fix: Nur Restart wenn Buffer-Size wachsen muss (einmalig 1024→8192)
- Danach: Pull-Sources werden dynamisch hinzugefügt ohne Stream-Unterbrechung
- hot_swap_arrangement() stellt MIDI-Events + Loop-State sicher

## Geänderte Dateien
- pydaw/audio/audio_engine.py (_create_vst_instrument_engines: smart restart)
- VERSION, pydaw/version.py

## Test-Anleitung (Arch Linux)
1. DAW starten
2. ZynAddSubFX (oder Surge XT, Dexed, Helm) auf Track 1 laden
3. MIDI-Clip mit Noten platzieren
4. Play drücken
5. **ERWARTET:** Ton spielt durchgehend, auch wenn du auf einen anderen Track klickst
6. Weiteres Plugin auf Track 2 laden (während Track 1 spielt)
7. **ERWARTET:** Track 1 spielt weiter ohne Unterbrechung
8. Log zeigt: "Stream OK (buffer=8192), 1 new engine(s) — no restart"
