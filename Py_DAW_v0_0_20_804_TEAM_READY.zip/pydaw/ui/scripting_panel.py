"""Scripting Panel — Live Python Console for Py_DAW (Phase 6A).

v0.0.20.798 — Python-Scripting direkt in der DAW

Features:
  - REPL-style console: type Python → immediate effect
  - Syntax highlighting (basic)
  - Command history (Up/Down arrows)
  - Output display with error highlighting
  - Script library with built-in examples
  - Quick-action buttons for common operations
"""
from __future__ import annotations

import logging
from typing import Any, Optional

from PyQt6.QtCore import QSettings, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QTextCharFormat, QTextCursor
from PyQt6.QtWidgets import (
    QComboBox, QDockWidget, QFrame, QGroupBox, QHBoxLayout,
    QLabel, QLineEdit, QListWidget, QListWidgetItem, QPlainTextEdit,
    QPushButton, QSizePolicy, QSplitter, QTabWidget, QTextEdit,
    QVBoxLayout, QWidget,
)

log = logging.getLogger(__name__)


class ScriptingPanel(QWidget):
    """Live Python scripting console panel."""

    status_message = pyqtSignal(str, int)

    def __init__(self, parent=None, scripting_service=None, macro_service=None):
        super().__init__(parent)
        self._scripting = scripting_service
        self._macro = macro_service
        self._history_index = -1
        self._init_ui()

    def set_scripting_service(self, service) -> None:
        self._scripting = service

    def set_macro_service(self, service) -> None:
        self._macro = service

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        tabs = QTabWidget()

        # Tab 1: Console
        console_tab = self._create_console_tab()
        tabs.addTab(console_tab, "🐍 Console")

        # Tab 2: Scripts Library
        library_tab = self._create_library_tab()
        tabs.addTab(library_tab, "📚 Scripts")

        # Tab 3: Macro Recording
        macro_tab = self._create_macro_tab()
        tabs.addTab(macro_tab, "🔴 Macro")

        layout.addWidget(tabs)

    def _create_console_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        # Header
        header = QHBoxLayout()
        lbl = QLabel("🐍 Py_DAW Scripting Console")
        lbl.setStyleSheet("font-weight: bold; font-size: 13px;")
        header.addWidget(lbl)
        header.addStretch()
        btn_help = QPushButton("❓ API Help")
        btn_help.setMaximumWidth(90)
        btn_help.clicked.connect(self._on_help)
        header.addWidget(btn_help)
        btn_clear = QPushButton("🗑️ Clear")
        btn_clear.setMaximumWidth(70)
        btn_clear.clicked.connect(self._on_clear)
        header.addWidget(btn_clear)
        layout.addLayout(header)

        # Output area
        self._output = QTextEdit()
        self._output.setReadOnly(True)
        self._output.setFont(QFont("Monospace", 10))
        self._output.setStyleSheet(
            "background-color: #1A1A2E; color: #E0E0E0; "
            "selection-background-color: #3A3A5E;"
        )
        self._output.setPlaceholderText(
            "🎵 Py_DAW Scripting Console\n"
            "Tippe Python-Code unten ein.\n"
            "Beispiel: project.bpm = 140\n"
            "Hilfe: help()"
        )
        layout.addWidget(self._output)

        # Input area
        input_frame = QFrame()
        input_frame.setFrameShape(QFrame.Shape.StyledPanel)
        il = QHBoxLayout(input_frame)
        il.setContentsMargins(4, 2, 4, 2)

        prompt = QLabel(">>>")
        prompt.setFont(QFont("Monospace", 10, QFont.Weight.Bold))
        prompt.setStyleSheet("color: #4AFF6B;")
        il.addWidget(prompt)

        self._input = QLineEdit()
        self._input.setFont(QFont("Monospace", 10))
        self._input.setStyleSheet(
            "background-color: #1E1E3E; color: #E0E0E0; "
            "border: 1px solid #3A3A5E; padding: 4px;"
        )
        self._input.setPlaceholderText("Python-Code eingeben...")
        self._input.returnPressed.connect(self._on_execute)
        il.addWidget(self._input)

        btn_run = QPushButton("▶ Run")
        btn_run.setStyleSheet("background-color: #2D5A27; color: white; padding: 4px 12px;")
        btn_run.clicked.connect(self._on_execute)
        il.addWidget(btn_run)
        layout.addWidget(input_frame)

        # Multi-line editor (for longer scripts)
        self._editor = QPlainTextEdit()
        self._editor.setFont(QFont("Monospace", 10))
        self._editor.setStyleSheet(
            "background-color: #1A1A2E; color: #E0E0E0; "
            "selection-background-color: #3A3A5E;"
        )
        self._editor.setPlaceholderText(
            "# Mehrzeiliges Script hier schreiben...\n"
            "for t in tracks:\n"
            "    t.volume = 0.7\n"
            "    print(t.name, t.volume)"
        )
        self._editor.setMaximumHeight(120)
        layout.addWidget(self._editor)

        editor_btns = QHBoxLayout()
        btn_run_editor = QPushButton("▶ Script ausführen")
        btn_run_editor.setStyleSheet("background-color: #2D5A27; color: white;")
        btn_run_editor.clicked.connect(self._on_run_editor)
        editor_btns.addWidget(btn_run_editor)
        editor_btns.addStretch()
        layout.addLayout(editor_btns)

        # Quick actions
        quick = QGroupBox("⚡ Quick Actions")
        ql = QHBoxLayout(quick)
        quick_actions = [
            ("📊 Info", "print(project)\nprint(mixer)"),
            ("🔇 Unmute", "mixer.unmute_all()"),
            ("🔊 0.75", "for t in tracks:\n    if t.kind != 'master': t.volume = 0.75"),
            ("⏹ Stop", "transport.stop()"),
            ("💾 Save", "project.save()"),
        ]
        for label, code in quick_actions:
            btn = QPushButton(label)
            btn.setMaximumWidth(80)
            btn.clicked.connect(lambda checked=False, c=code: self._execute_code(c))
            ql.addWidget(btn)
        layout.addWidget(quick)

        return w

    def _create_library_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(4, 4, 4, 4)

        layout.addWidget(QLabel("📚 Script-Bibliothek:"))

        self._script_list = QListWidget()
        self._script_list.setAlternatingRowColors(True)
        self._script_list.itemDoubleClicked.connect(self._on_load_script)
        layout.addWidget(self._script_list)

        btns = QHBoxLayout()
        btn_load = QPushButton("📂 Laden")
        btn_load.clicked.connect(self._on_load_selected)
        btns.addWidget(btn_load)
        btn_run = QPushButton("▶ Ausführen")
        btn_run.clicked.connect(self._on_run_selected)
        btns.addWidget(btn_run)
        btn_refresh = QPushButton("🔄")
        btn_refresh.clicked.connect(self._refresh_library)
        btns.addWidget(btn_refresh)
        btns.addStretch()
        layout.addLayout(btns)

        # Preview
        layout.addWidget(QLabel("Vorschau:"))
        self._script_preview = QPlainTextEdit()
        self._script_preview.setReadOnly(True)
        self._script_preview.setFont(QFont("Monospace", 9))
        self._script_preview.setMaximumHeight(100)
        self._script_preview.setStyleSheet("background-color: #1A1A2E; color: #CCC;")
        layout.addWidget(self._script_preview)

        self._script_list.currentItemChanged.connect(self._on_script_selected)

        # Load built-in scripts
        QTimer.singleShot(100, self._refresh_library)

        return w

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def _on_execute(self) -> None:
        code = self._input.text().strip()
        if not code:
            return
        self._input.clear()
        self._execute_code(code)

    def _on_run_editor(self) -> None:
        code = self._editor.toPlainText().strip()
        if not code:
            return
        self._execute_code(code)

    def _execute_code(self, code: str) -> None:
        if not self._scripting:
            self._append_output("⚠️ Scripting Service nicht verfügbar", error=True)
            return

        # Show input
        for line in code.splitlines():
            self._append_output(f">>> {line}", prompt=True)

        # Execute
        result = self._scripting.execute(code)

        if result.output:
            self._append_output(result.output)
        if result.error:
            self._append_output(result.error, error=True)
        if result.success and not result.output and not result.error:
            pass  # Silent success (assignments, etc.)

        # Timing
        if result.duration_ms > 100:
            self._append_output(f"⏱ {result.duration_ms:.0f}ms", dim=True)

    def _on_help(self) -> None:
        if self._scripting:
            result = self._scripting.execute("help_api()")
            if result.output:
                self._append_output(result.output)

    def _on_clear(self) -> None:
        self._output.clear()

    def _append_output(self, text: str, error: bool = False,
                       prompt: bool = False, dim: bool = False) -> None:
        cursor = self._output.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)

        fmt = QTextCharFormat()
        if error:
            fmt.setForeground(QColor("#FF6B6B"))
        elif prompt:
            fmt.setForeground(QColor("#4AFF6B"))
        elif dim:
            fmt.setForeground(QColor("#888"))
        else:
            fmt.setForeground(QColor("#E0E0E0"))

        cursor.insertText(text + "\n", fmt)
        self._output.setTextCursor(cursor)
        self._output.ensureCursorVisible()

    # ------------------------------------------------------------------
    # Library
    # ------------------------------------------------------------------

    def _refresh_library(self) -> None:
        self._script_list.clear()
        if not self._scripting:
            return

        # Built-in scripts
        for s in self._scripting.get_builtin_scripts():
            item = QListWidgetItem(f"📦 {s.name}")
            item.setData(Qt.ItemDataRole.UserRole, s)
            item.setToolTip(s.description)
            self._script_list.addItem(item)

        # User scripts
        for s in self._scripting.get_scripts():
            item = QListWidgetItem(f"📝 {s.name}")
            item.setData(Qt.ItemDataRole.UserRole, s)
            item.setToolTip(s.description)
            self._script_list.addItem(item)

    def _on_script_selected(self, item, _prev=None) -> None:
        if not item:
            return
        script = item.data(Qt.ItemDataRole.UserRole)
        if script:
            self._script_preview.setPlainText(script.code)

    def _on_load_script(self, item) -> None:
        if not item:
            return
        script = item.data(Qt.ItemDataRole.UserRole)
        if script:
            self._editor.setPlainText(script.code)

    def _on_load_selected(self) -> None:
        item = self._script_list.currentItem()
        if item:
            self._on_load_script(item)

    def _on_run_selected(self) -> None:
        item = self._script_list.currentItem()
        if not item:
            return
        script = item.data(Qt.ItemDataRole.UserRole)
        if script:
            self._execute_code(script.code)

    # ------------------------------------------------------------------
    # Macro Tab
    # ------------------------------------------------------------------

    def _create_macro_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(6)

        # Record controls
        rec_row = QHBoxLayout()
        self._btn_macro_record = QPushButton("🔴 Aufnahme starten")
        self._btn_macro_record.setStyleSheet("background-color: #8B0000; color: white;")
        self._btn_macro_record.clicked.connect(self._on_macro_toggle)
        rec_row.addWidget(self._btn_macro_record)
        self._macro_status = QLabel("Bereit")
        self._macro_status.setStyleSheet("color: #888;")
        rec_row.addWidget(self._macro_status)
        rec_row.addStretch()
        layout.addLayout(rec_row)

        # Macro name
        name_row = QHBoxLayout()
        name_row.addWidget(QLabel("Name:"))
        self._macro_name = QLineEdit()
        self._macro_name.setPlaceholderText("Macro-Name (optional)")
        name_row.addWidget(self._macro_name)
        layout.addLayout(name_row)

        # History
        layout.addWidget(QLabel("📼 Aufgezeichnete Macros:"))
        self._macro_list = QListWidget()
        self._macro_list.setAlternatingRowColors(True)
        self._macro_list.currentRowChanged.connect(self._on_macro_selected)
        layout.addWidget(self._macro_list)

        # Preview
        layout.addWidget(QLabel("Generiertes Script:"))
        self._macro_preview = QPlainTextEdit()
        self._macro_preview.setReadOnly(True)
        self._macro_preview.setFont(QFont("Monospace", 9))
        self._macro_preview.setMaximumHeight(120)
        self._macro_preview.setStyleSheet("background-color: #1A1A2E; color: #CCC;")
        layout.addWidget(self._macro_preview)

        # Actions
        btn_row = QHBoxLayout()
        self._btn_macro_run = QPushButton("▶ Ausführen")
        self._btn_macro_run.clicked.connect(self._on_macro_run)
        btn_row.addWidget(self._btn_macro_run)
        self._btn_macro_to_editor = QPushButton("📝 In Editor laden")
        self._btn_macro_to_editor.clicked.connect(self._on_macro_to_editor)
        btn_row.addWidget(self._btn_macro_to_editor)
        self._btn_macro_to_lib = QPushButton("📚 In Bibliothek speichern")
        self._btn_macro_to_lib.clicked.connect(self._on_macro_save_to_lib)
        btn_row.addWidget(self._btn_macro_to_lib)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        layout.addStretch()
        return w

    def _on_macro_toggle(self) -> None:
        if not self._macro:
            self.status_message.emit("Macro-Service nicht verfügbar", 3000)
            return
        if self._macro.is_recording():
            rec = self._macro.stop_recording()
            self._btn_macro_record.setText("🔴 Aufnahme starten")
            self._btn_macro_record.setStyleSheet("background-color: #8B0000; color: white;")
            if rec:
                self._macro_status.setText(
                    f"✅ {rec.action_count} Aktionen aufgezeichnet ({rec.duration_seconds:.1f}s)")
                self._macro_status.setStyleSheet("color: #4AFF6B;")
            self._refresh_macro_list()
        else:
            name = self._macro_name.text().strip() or ""
            self._macro.start_recording(name=name)
            self._btn_macro_record.setText("⏹ Aufnahme stoppen")
            self._btn_macro_record.setStyleSheet("background-color: #FF0000; color: white;")
            self._macro_status.setText("🔴 Aufnahme läuft...")
            self._macro_status.setStyleSheet("color: #FF4444; font-weight: bold;")

    def _refresh_macro_list(self) -> None:
        self._macro_list.clear()
        if not self._macro:
            return
        for i, rec in enumerate(self._macro.get_history()):
            item = QListWidgetItem(
                f"📼 {rec.name} ({rec.action_count} Aktionen, {rec.duration_seconds:.1f}s)")
            item.setData(Qt.ItemDataRole.UserRole, i)
            self._macro_list.addItem(item)

    def _on_macro_selected(self, row: int) -> None:
        if not self._macro or row < 0:
            self._macro_preview.clear()
            return
        history = self._macro.get_history()
        if row < len(history):
            script = self._macro.export_script(recording=history[row])
            self._macro_preview.setPlainText(script)

    def _on_macro_run(self) -> None:
        script = self._macro_preview.toPlainText().strip()
        if script and self._scripting:
            self._execute_code(script)

    def _on_macro_to_editor(self) -> None:
        script = self._macro_preview.toPlainText().strip()
        if script:
            self._editor.setPlainText(script)

    def _on_macro_save_to_lib(self) -> None:
        if not self._macro or not self._scripting:
            return
        row = self._macro_list.currentRow()
        history = self._macro.get_history()
        if row < 0 or row >= len(history):
            return
        rec = history[row]
        script_code = self._macro.export_script(recording=rec)
        self._scripting.save_script(
            name=rec.name or f"Macro {row + 1}",
            code=script_code,
            description=f"Macro recording ({rec.action_count} actions)",
            category="macro",
        )
        self.status_message.emit(f"Macro '{rec.name}' in Bibliothek gespeichert", 3000)
        self._refresh_library()

    def keyPressEvent(self, event):
        """Handle Up/Down for command history."""
        if self._input.hasFocus() and self._scripting:
            history = self._scripting.get_history()
            if event.key() == Qt.Key.Key_Up and history:
                self._history_index = max(0, self._history_index - 1) if self._history_index >= 0 else len(history) - 1
                if 0 <= self._history_index < len(history):
                    self._input.setText(history[self._history_index])
                return
            elif event.key() == Qt.Key.Key_Down and history:
                self._history_index += 1
                if self._history_index >= len(history):
                    self._history_index = -1
                    self._input.clear()
                elif 0 <= self._history_index < len(history):
                    self._input.setText(history[self._history_index])
                return
        super().keyPressEvent(event)
