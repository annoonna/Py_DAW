"""Macro Recording Service — Record UI actions → Export as Python scripts.

v0.0.20.801 — Phase 6A: Macro-System

Records user interactions (track changes, clip edits, transport actions, etc.)
as a structured action log. The log can be exported as a Python script that
replays the same operations via the Scripting API.

Architecture:
  - MainWindow and other UI widgets call macro_service.record(action)
  - Each action is a dict with type, target, params
  - The service maintains a list of recorded actions
  - export_script() converts the action list to Python code
  - The exported script is compatible with the ScriptingService API

Usage:
    macro = MacroRecordingService()
    macro.start_recording()

    # ... user interacts with the DAW ...
    macro.record({"type": "track_volume", "track": "Bass", "value": 0.6})
    macro.record({"type": "bpm", "value": 140})
    macro.record({"type": "track_mute", "track": "FX", "muted": True})

    macro.stop_recording()
    script = macro.export_script(name="My Macro")
    print(script)
    # Output:
    #   # Py_DAW Macro: My Macro
    #   tracks["Bass"].volume = 0.6
    #   project.bpm = 140
    #   tracks["FX"].muted = True
"""

from __future__ import annotations

import logging
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


@dataclass
class MacroAction:
    """A single recorded UI action."""
    type: str = ""           # action type (see _ACTION_MAP)
    timestamp: float = 0.0   # when it happened (time.time())
    params: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class MacroRecording:
    """A complete macro recording."""
    name: str = "Unnamed Macro"
    started_at: str = ""
    ended_at: str = ""
    actions: List[MacroAction] = field(default_factory=list)
    description: str = ""

    @property
    def duration_seconds(self) -> float:
        if not self.actions:
            return 0.0
        return self.actions[-1].timestamp - self.actions[0].timestamp

    @property
    def action_count(self) -> int:
        return len(self.actions)


# ---------------------------------------------------------------------------
# Action → Script code mapping
# ---------------------------------------------------------------------------

def _action_to_script(action: MacroAction) -> str:
    """Convert a single action to Python script code."""
    t = action.type
    p = action.params

    if t == "bpm":
        return f"project.bpm = {float(p.get('value', 120))}"

    elif t == "time_signature":
        return f'project.time_signature = "{p.get("value", "4/4")}"'

    elif t == "project_name":
        return f'project.name = "{p.get("value", "")}"'

    elif t == "project_save":
        return "project.save()"

    elif t == "track_volume":
        name = p.get("track", "")
        val = float(p.get("value", 0.8))
        return f'tracks["{name}"].volume = {val:.3f}'

    elif t == "track_pan":
        name = p.get("track", "")
        val = float(p.get("value", 0.0))
        return f'tracks["{name}"].pan = {val:.3f}'

    elif t == "track_mute":
        name = p.get("track", "")
        muted = bool(p.get("muted", False))
        return f'tracks["{name}"].muted = {muted}'

    elif t == "track_solo":
        name = p.get("track", "")
        solo = bool(p.get("solo", False))
        return f'tracks["{name}"].solo = {solo}'

    elif t == "track_name":
        old = p.get("old_name", "")
        new = p.get("new_name", "")
        return f'tracks["{old}"].name = "{new}"'

    elif t == "track_add":
        name = p.get("name", "New Track")
        kind = p.get("kind", "audio")
        return f'add_track("{name}", kind="{kind}")'

    elif t == "track_remove":
        name = p.get("name", "")
        return f'remove_track("{name}")'

    elif t == "track_record_arm":
        name = p.get("track", "")
        armed = bool(p.get("armed", False))
        return f'tracks["{name}"].record_arm = {armed}'

    elif t == "clip_move":
        label = p.get("label", "Clip")
        start = float(p.get("start_beats", 0))
        return f'# Move clip "{label}" to beat {start:.1f}'

    elif t == "clip_mute":
        label = p.get("label", "Clip")
        muted = bool(p.get("muted", False))
        return f'# Clip "{label}" muted = {muted}'

    elif t == "transport_play":
        return "transport.play()"

    elif t == "transport_stop":
        return "transport.stop()"

    elif t == "transport_seek":
        beat = float(p.get("beat", 0))
        return f"transport.position = {beat:.1f}"

    elif t == "mixer_solo":
        name = p.get("track", "")
        return f'mixer.solo("{name}")'

    elif t == "mixer_unsolo_all":
        return "mixer.unsolo_all()"

    elif t == "mixer_unmute_all":
        return "mixer.unmute_all()"

    elif t == "mixer_set_all_volume":
        val = float(p.get("value", 0.75))
        return f"mixer.set_all_volume({val:.3f})"

    elif t == "comment":
        text = p.get("text", "")
        return f"# {text}"

    elif t == "sleep":
        sec = float(p.get("seconds", 1.0))
        return f"sleep({sec:.1f})"

    else:
        # Unknown action → comment
        return f"# Unknown action: {t} {p}"


# ---------------------------------------------------------------------------
# Core Macro Recording Service
# ---------------------------------------------------------------------------

class MacroRecordingService:
    """Records UI actions and exports them as Python scripts.

    Thread-safe: record() can be called from any thread.
    """

    def __init__(self):
        self._recording = False
        self._current: Optional[MacroRecording] = None
        self._history: List[MacroRecording] = []
        self._max_history = 20
        # Deduplication: don't record repeated identical actions within 100ms
        self._last_action_type = ""
        self._last_action_time = 0.0
        self._dedup_interval = 0.1  # seconds

    # ------------------------------------------------------------------
    # Recording control
    # ------------------------------------------------------------------

    def start_recording(self, name: str = "") -> None:
        """Start recording a new macro."""
        if self._recording:
            self.stop_recording()

        self._current = MacroRecording(
            name=name or f"Macro {len(self._history) + 1}",
            started_at=datetime.utcnow().isoformat(),
        )
        self._recording = True
        self._last_action_type = ""
        self._last_action_time = 0.0
        log.info("Macro recording started: %s", self._current.name)

    def stop_recording(self) -> Optional[MacroRecording]:
        """Stop recording and return the completed macro."""
        if not self._recording or self._current is None:
            return None

        self._recording = False
        self._current.ended_at = datetime.utcnow().isoformat()

        # Save to history
        result = self._current
        self._history.append(result)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

        self._current = None
        log.info("Macro recording stopped: %s (%d actions, %.1fs)",
                 result.name, result.action_count, result.duration_seconds)
        return result

    def is_recording(self) -> bool:
        return self._recording

    def get_current_action_count(self) -> int:
        if self._current:
            return len(self._current.actions)
        return 0

    # ------------------------------------------------------------------
    # Record actions
    # ------------------------------------------------------------------

    def record(self, action_dict: Dict[str, Any]) -> None:
        """Record a single action.

        Args:
            action_dict: Dict with at least "type" key, plus params.
                Example: {"type": "track_volume", "track": "Bass", "value": 0.6}
        """
        if not self._recording or self._current is None:
            return

        now = time.time()
        action_type = str(action_dict.get("type", ""))

        # Deduplication: skip if same type within dedup_interval
        # (prevents 100 volume events from a single fader drag)
        if (action_type == self._last_action_type and
                now - self._last_action_time < self._dedup_interval and
                action_type in ("track_volume", "track_pan", "transport_seek")):
            # Update the last action's value instead of adding a new one
            if self._current.actions:
                last = self._current.actions[-1]
                last.params.update({k: v for k, v in action_dict.items() if k != "type"})
                last.timestamp = now
                self._last_action_time = now
                return

        # Create action
        params = {k: v for k, v in action_dict.items() if k != "type"}
        action = MacroAction(
            type=action_type,
            timestamp=now,
            params=params,
        )
        self._current.actions.append(action)
        self._last_action_type = action_type
        self._last_action_time = now

    def record_simple(self, action_type: str, **kwargs) -> None:
        """Convenience: record an action with keyword arguments.

        Example: macro.record_simple("track_volume", track="Bass", value=0.6)
        """
        self.record({"type": action_type, **kwargs})

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export_script(self, recording: Optional[MacroRecording] = None,
                      include_timing: bool = False,
                      include_header: bool = True) -> str:
        """Convert a recording to a Python script.

        Args:
            recording: The recording to export (default: last recording).
            include_timing: If True, add sleep() calls between actions.
            include_header: If True, add header comment.

        Returns:
            Python script as a string.
        """
        rec = recording or (self._history[-1] if self._history else None)
        if not rec or not rec.actions:
            return "# Empty macro — no actions recorded"

        lines = []

        if include_header:
            lines.append(f"# 🎵 Py_DAW Macro: {rec.name}")
            lines.append(f"# Recorded: {rec.started_at[:19]}")
            lines.append(f"# Actions: {rec.action_count}")
            lines.append(f"# Duration: {rec.duration_seconds:.1f}s")
            lines.append("")

        prev_time = rec.actions[0].timestamp if rec.actions else 0

        for action in rec.actions:
            # Optional timing
            if include_timing and action.timestamp > prev_time + 0.5:
                delay = action.timestamp - prev_time
                if delay < 10.0:
                    lines.append(f"sleep({delay:.1f})")
            prev_time = action.timestamp

            # Convert action to script code
            code = _action_to_script(action)
            if code:
                lines.append(code)

        lines.append("")
        lines.append(f'print("Macro \\"{rec.name}\\" ausgeführt — {rec.action_count} Aktionen")')

        return "\n".join(lines)

    def export_last(self, include_timing: bool = False) -> str:
        """Export the most recent recording as a script."""
        return self.export_script(include_timing=include_timing)

    # ------------------------------------------------------------------
    # History
    # ------------------------------------------------------------------

    def get_history(self) -> List[MacroRecording]:
        """Get all recorded macros."""
        return list(self._history)

    def get_last(self) -> Optional[MacroRecording]:
        """Get the most recent recording."""
        return self._history[-1] if self._history else None

    def clear_history(self) -> None:
        """Clear all recorded macros."""
        self._history.clear()

    def delete_recording(self, index: int) -> bool:
        """Delete a recording by index."""
        if 0 <= index < len(self._history):
            self._history.pop(index)
            return True
        return False
