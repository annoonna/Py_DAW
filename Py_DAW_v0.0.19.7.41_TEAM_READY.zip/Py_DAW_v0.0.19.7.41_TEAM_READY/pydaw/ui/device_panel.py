from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QWidget, QLabel, QVBoxLayout, QFrame


class DevicePanel(QWidget):
    """Bottom 'Device' view (Bitwig-style) – placeholder.

    This panel is intentionally lightweight and UI-only for now. It will become
    the future device chain / device inspector.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("devicePanel")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(10)

        title = QLabel("Device")
        title.setObjectName("devicePanelTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        hint = QLabel(
            "Platzhalter (v0.0.19.7.37):\n"
            "Hier kommt später die Device-Chain (Plugins, Instrumente, FX) – \n"
            "Bitwig-like unten als eigener View-Tab."
        )
        hint.setWordWrap(True)
        hint.setObjectName("devicePanelHint")

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFrameShadow(QFrame.Shadow.Sunken)
        sep.setObjectName("devicePanelSep")

        empty = QLabel("(Noch keine Devices geladen)")
        empty.setObjectName("devicePanelEmpty")
        empty.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)

        layout.addWidget(title)
        layout.addWidget(hint)
        layout.addWidget(sep)
        layout.addWidget(empty, 1)
