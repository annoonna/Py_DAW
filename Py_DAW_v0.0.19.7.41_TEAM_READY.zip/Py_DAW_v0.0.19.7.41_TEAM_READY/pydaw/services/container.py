"""Service container wiring (v0.0.15.8 + fix11)."""

from __future__ import annotations

from dataclasses import dataclass
import os

from pydaw.core.threading import ThreadPoolService
from pydaw.services.project_service import ProjectService
from pydaw.audio.audio_engine import AudioEngine
from pydaw.services.transport_service import TransportService
from pydaw.services.launcher_service import LauncherService
from pydaw.services.metronome_service import MetronomeService
from pydaw.services.midi_service import MidiService
from pydaw.services.jack_client_service import JackClientService
from pydaw.services.recording_service import RecordingService
from pydaw.services.fluidsynth_service import FluidSynthService
from pydaw.utils.logging_setup import get_logger

from pydaw.core.settings_store import get_value
from pydaw.core.settings import SettingsKeys
from pydaw.services.midi_mapping_service import MidiMappingService
from pydaw.services.automation_playback import AutomationPlaybackService

log = get_logger(__name__)


@dataclass
class ServiceContainer:
    threadpool: ThreadPoolService
    project: ProjectService
    audio_engine: AudioEngine
    transport: TransportService
    launcher: LauncherService
    metronome: MetronomeService
    midi: MidiService
    midi_mapping: MidiMappingService
    jack: JackClientService
    automation_playback: AutomationPlaybackService
    recording: RecordingService
    fluidsynth: FluidSynthService

    @classmethod
    def create_default(cls) -> "ServiceContainer":
        threadpool = ThreadPoolService.create_default()
        project = ProjectService(threadpool=threadpool)

        audio_engine = AudioEngine()
        # forward engine status to the app status bus
        try:
            audio_engine.status.connect(lambda m: project.status.emit(m))
            audio_engine.error.connect(lambda m: project.error.emit(m))
        except Exception:
            pass
        transport = TransportService(
            bpm=project.ctx.project.bpm,
            time_signature=getattr(project.ctx.project, "time_signature", "4/4"),
        )

        # Binde AudioEngine an Project/Transport und starte/stopp-e
        # Arrangement-Playback, wenn der Transport spielt.
        try:
            audio_engine.bind_transport(project, transport)
            transport.playing_changed.connect(
                lambda playing: audio_engine.start_arrangement_playback() if playing else audio_engine.stop()
            )
        except Exception:
            # Fallback: AudioEngine bleibt im "none"/"silence"-Modus.
            pass
        launcher = LauncherService(project=project, transport=transport)

        # Automation playback (read mode -> applies volume/pan curves while playing)
        automation_playback = AutomationPlaybackService(project=project, transport=transport)

        metronome = MetronomeService(on_status=lambda m: project.status.emit(m))
        midi = MidiService(status_cb=lambda m: project.status.emit(m))
        jack = JackClientService(status_cb=lambda m: project.status.emit(m))
        try:
            audio_engine.bind_jack(jack)
        except Exception:
            pass

        midi_mapping = MidiMappingService(
            project=project,
            transport=transport,
            status_cb=lambda m: project.status.emit(m),
        )
        try:
            midi.message_obj.connect(midi_mapping.handle_mido_message)
        except Exception:
            pass

        # Try to register a visible JACK/PipeWire client (non-fatal if unavailable)
        # NOTE: This is intentionally independent from the engine backend.
        # Many users want sounddevice (PortAudio) for playback, but still want a JACK
        # client so PyDAW is visible in qpwgraph for routing/recording.
        keys = SettingsKeys()
        enable_jack = os.environ.get("PYDAW_ENABLE_JACK", "0") in ("1", "true", "True", "yes", "on")
        if enable_jack and JackClientService.probe_available():
            try:
                jack.start_async(
                    in_ports=get_value(keys.jack_in_ports, 2),
                    out_ports=get_value(keys.jack_out_ports, 2),
                    monitor_inputs_to_outputs=get_value(keys.jack_input_monitor, False),
                )
            except Exception:
                pass
        elif enable_jack and (not JackClientService.probe_available()):
            log.warning(
                "JACK client enabled, but JACK server is not reachable. "
                "Tip: start via 'pw-jack python3 main.py' or ensure PipeWire-JACK/JACK is active."
            )

        # Initialize recording service (PipeWire/JACK support)
        recording = RecordingService()
        log.info("Recording service initialized (backend: %s)", recording.get_backend())
        
        # Initialize FluidSynth service (optional - won't crash if unavailable)
        fluidsynth = FluidSynthService()
        try:
            fluidsynth.error.connect(lambda m: project.error.emit(m))
            fluidsynth.status.connect(lambda m: project.status.emit(m))
        except Exception:
            pass
        
        if fluidsynth.is_available():
            log.info("FluidSynth service initialized")
        else:
            log.warning("FluidSynth service not available (optional feature)")

        return cls(
            threadpool=threadpool,
            project=project,
            audio_engine=audio_engine,
            transport=transport,
            launcher=launcher,
            metronome=metronome,
            midi=midi,
            midi_mapping=midi_mapping,
            jack=jack,
            automation_playback=automation_playback,
            recording=recording,
            fluidsynth=fluidsynth,
        )


    def shutdown(self) -> None:
        """Best-effort shutdown for background audio/jack/transport resources."""
        # Stop recording if active
        try:
            if self.recording.is_recording():
                self.recording.stop_recording()
            self.recording.cleanup()
        except Exception:
            pass
        # Cleanup FluidSynth
        try:
            self.fluidsynth.cleanup()
        except Exception:
            pass
        # Stop transport timer first (it can trigger callbacks into other services).
        try:
            self.transport.stop()
        except Exception:
            pass
        # Stop launcher watchers.
        try:
            self.launcher.stop()
        except Exception:
            pass
        # Stop JACK client thread (if enabled).
        try:
            self.jack.stop()
        except Exception:
            pass
        # Stop audio engine stream.
        try:
            self.audio_engine.stop()
        except Exception:
            pass
        # Stop background workers.
        try:
            self.threadpool.shutdown()
        except Exception:
            pass
