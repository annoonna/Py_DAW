"""MIDI I/O service (v0.0.14).

Goals:
- List available MIDI input/output ports (best effort).
- Connect to an input port and forward messages to the app without blocking the GUI.

Implementation:
- Uses mido if available (typically with python-rtmidi backend).
- If mido is missing, behaves as a no-op with a clear status message.
"""

from __future__ import annotations

import threading
import time
from typing import Callable, Optional, List

from PyQt6.QtCore import QObject, pyqtSignal

try:
    import mido  # type: ignore
except Exception:  # noqa: BLE001
    mido = None  # type: ignore


class MidiService(QObject):
    message_received = pyqtSignal(str)  # short text for status/monitor

    def __init__(self, status_cb: Callable[[str], None] | None = None):
        super().__init__()
        self._status = status_cb or (lambda _m: None)

        self._lock = threading.Lock()
        self._stop = False
        self._thread: Optional[threading.Thread] = None

        self._in_name: str = ""
        self._in_port = None

    def list_inputs(self) -> List[str]:
        if mido is None:
            return []
        try:
            return list(mido.get_input_names())
        except Exception:  # noqa: BLE001
            return []

    def list_outputs(self) -> List[str]:
        if mido is None:
            return []
        try:
            return list(mido.get_output_names())
        except Exception:  # noqa: BLE001
            return []

    def current_input(self) -> str:
        return self._in_name

    def connect_input(self, name: str) -> bool:
        if mido is None:
            self._status("MIDI: mido nicht verfügbar (pip install mido python-rtmidi).")
            return False

        self.disconnect_input()

        try:
            port = mido.open_input(name)
        except Exception as exc:  # noqa: BLE001
            self._status(f"MIDI: Input konnte nicht geöffnet werden: {exc}")
            return False

        with self._lock:
            self._in_port = port
            self._in_name = name
            self._stop = False

        self._status(f"MIDI: Input verbunden: {name}")
        self._start_thread()
        return True

    def disconnect_input(self) -> None:
        with self._lock:
            self._stop = True
            port = self._in_port
            self._in_port = None
            self._in_name = ""

        if port is not None:
            try:
                port.close()
            except Exception:
                pass

        if self._thread is not None:
            try:
                self._thread.join(timeout=0.5)
            except Exception:
                pass
            self._thread = None

    def shutdown(self) -> None:
        self.disconnect_input()

    # --- internal

    def _start_thread(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        # Poll the input port. mido ports are iterable; polling avoids blocking shutdown.
        while True:
            with self._lock:
                if self._stop:
                    return
                port = self._in_port
            if port is None:
                return

            try:
                # get pending messages (if backend supports)
                for msg in port.iter_pending():
                    text = f"MIDI: {msg.type} {msg}"
                    self.message_received.emit(text)
            except Exception as exc:  # noqa: BLE001
                self._status(f"MIDI: Fehler beim Lesen: {exc}")
                time.sleep(0.2)

            time.sleep(0.01)
