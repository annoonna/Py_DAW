// ==========================================================================
// AETERNA Synth Module — Subtractive/FM/Morphing Synthesizer
// ==========================================================================
// v0.0.20.683 — Phase R8A (Oscillators)
//
// AETERNA is an advanced synthesizer with:
//   - R8A: Oscillators (Sine, Saw, Square, Triangle, Noise, PolyBLEP, FM, Unison)
//   - R8B: Voice + Filter (planned)
//   - R8C: Modulation Matrix (planned)
//   - R8D: Parameter Sync + Presets (planned)
//
// Rules:
//   ✅ All DSP is zero-alloc in process()
//   ✅ Voice pool is pre-allocated
//   ❌ NO allocations in audio thread
// ==========================================================================

pub mod oscillator;

// Re-exports
#[allow(unused_imports)]
pub use oscillator::{
    OscillatorState, Waveform,
    gen_sine, gen_saw_polyblep, gen_square_polyblep, gen_triangle,
    gen_morphed, white_noise, pink_noise, polyblep,
    MAX_UNISON,
};
