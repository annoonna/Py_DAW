"""
Optimized Realtime DSP + JACK bridge engine.
Focus: Zero-allocation and pre-cached lookups to fix crackling/Xruns.
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Callable, Optional, Dict, Any

# Wir importieren math einmal global, nicht im Loop
import math

def _pan_gains_fast(gain: float, pan: float) -> tuple[float, float]:
    pan = float(max(-1.0, min(1.0, pan)))
    x = (pan + 1.0) * 0.5
    # Nutze math direkt für Speed
    l = math.cos(x * 1.5707963267948966) * gain # pi/2 pre-calculated
    r = math.sin(x * 1.5707963267948966) * gain
    return float(l), float(r)

MasterGetter = Callable[[], tuple[float, float]]
PullSource = Callable[[int, int], Optional[np.ndarray]]

class DSPJackEngine:
    def __init__(self) -> None:
        # State-Management
        self.arrangement_state = None
        self.transport_ref = None
        self.master_getter = None
        
        # Pre-cached List für schnelleren Loop ohne Dictionary-Overhead
        self._pull_sources_dict: Dict[str, PullSource] = {}
        self._pull_sources_list: list[PullSource] = []
        
        # Pre-allocated Buffer (verhindert Memory Allocation im Callback)
        self._mix_buf = np.zeros((8192, 2), dtype=np.float32)
        
        # Performance-Flags
        self._has_transport_playhead = False

    # ----- Konfiguration (Nicht-Echtzeit, darf langsam sein)

    def set_arrangement_state(self, st: Any) -> None:
        self.arrangement_state = st

    def set_transport_ref(self, transport: Any) -> None:
        self.transport_ref = transport
        self._has_transport_playhead = hasattr(transport, "_set_external_playhead_samples")

    def set_master_getter(self, getter: Optional[MasterGetter]) -> None:
        self.master_getter = getter

    def register_pull_source(self, name: str, fn: PullSource) -> None:
        self._pull_sources_dict[name] = fn
        self._update_cache()

    def unregister_pull_source(self, name: str) -> None:
        self._pull_sources_dict.pop(name, None)
        self._update_cache()

    def _update_cache(self) -> None:
        # Wir wandeln das Dict in eine Liste um, damit der Callback 
        # nicht über das langsame Dictionary iterieren muss.
        self._pull_sources_list = list(self._pull_sources_dict.values())

    # ----- ECHTZEIT CALLBACK (Muss extrem schnell sein)

    def render_callback(self, frames: int, in_bufs, out_bufs, sr: int) -> bool:
        try:
            # 1. Vorbereitung (Keine Zuweisung neuer Objekte!)
            mix = self._mix_buf[:frames]
            mix.fill(0.0) # Schneller als mix[:] = 0.0

            # 2. Arrangement Render (Der Haupt-Sound)
            st = self.arrangement_state
            if st is not None:
                buf = st.render(frames)
                if buf is not None:
                    # In-place Addition ist schneller und spart Speicher
                    mix += buf
                    
                    # Playhead Update (nur wenn nötig)
                    if self._has_transport_playhead:
                        # Wir greifen direkt auf Attribute zu statt getattr()
                        self.transport_ref._set_external_playhead_samples(int(st.playhead), float(sr))

            # 3. Zusätzliche Quellen (SF2, Synths etc.)
            # Wir nutzen die pre-cached Liste statt .items()!
            for fn in self._pull_sources_list:
                b = fn(frames, sr)
                if b is not None:
                    mix += b

            # 4. Master Volume & Pan (LIVE)
            mg = self.master_getter
            if mg is not None:
                vol, pan = mg()
                
                # Nur rechnen, wenn nötig (spart CPU-Zyklen)
                if vol != 1.0:
                    mix *= vol
                
                if pan != 0.0:
                    gl, gr = _pan_gains_fast(1.0, pan)
                    mix[:, 0] *= gl
                    mix[:, 1] *= gr

            # 5. Limiter / Clipping (Verhindert digitale Verzerrung)
            np.clip(mix, -1.0, 1.0, out=mix)

            # 6. Output an die Soundkarte (JACK)
            if out_bufs:
                out_bufs[0][:frames] = mix[:, 0]
                out_bufs[1][:frames] = mix[:, 1]

            return True
        except Exception:
            # Im absoluten Notfall Stille liefern statt Absturz
            return False

