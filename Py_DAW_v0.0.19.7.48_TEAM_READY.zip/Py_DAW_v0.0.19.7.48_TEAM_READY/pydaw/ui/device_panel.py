# -*- coding: utf-8 -*-
"""Device Panel (Bottom) — hosts device widgets (chain).

v0.0.19.7.45
- Device chain is now dynamic (no auto-embedded sampler).
- Devices are added from Browser → Instruments.
- Horizontal scroll if chain gets wider than the screen.
"""

from __future__ import annotations

from typing import Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QWidget,
    QLabel,
    QVBoxLayout,
    QHBoxLayout,
    QScrollArea,
    QFrame,
    QSizePolicy,
    QPushButton,
)

from pydaw.plugins.registry import get_instruments


class _DeviceBox(QFrame):
    def __init__(self, title: str, inner: QWidget, on_close=None, parent=None):
        super().__init__(parent)
        self.setObjectName("deviceBox")
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        # Make devices usable by default: not too narrow, not absurdly wide
        self.setMinimumWidth(560)
        self.setMaximumWidth(1200)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 8, 10, 10)
        outer.setSpacing(6)

        top = QHBoxLayout()
        lab = QLabel(title)
        lab.setObjectName("deviceBoxTitle")
        lab.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        btn = QPushButton("✕")
        btn.setFixedWidth(34)
        btn.setToolTip("Remove device")
        btn.clicked.connect(lambda: on_close() if callable(on_close) else None)

        top.addWidget(lab, 1)
        top.addWidget(btn, 0)

        outer.addLayout(top)
        outer.addWidget(inner, 1)


class DevicePanel(QWidget):
    """Bottom 'Device' view (Bitwig-style)."""

    def __init__(self, services=None, parent=None):
        super().__init__(parent)
        self.setObjectName("devicePanel")
        self._services = services
        self._device_boxes: list[_DeviceBox] = []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(8)

        title = QLabel("Device")
        title.setObjectName("devicePanelTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFrameShadow(QFrame.Shadow.Sunken)
        sep.setObjectName("devicePanelSep")

        # ---- Device chain scroll area (horizontal)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)

        self.chain_host = QWidget()
        self.chain_host.setObjectName("deviceChainHost")
        self.chain_host.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        self.chain = QHBoxLayout(self.chain_host)
        self.chain.setContentsMargins(0, 0, 0, 0)
        self.chain.setSpacing(12)

        self.empty_label = QLabel("Kein Device geladen.\nBrowser → Instruments → 'Add to Device'.")
        self.empty_label.setObjectName("devicePanelEmpty")
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.empty_label.setStyleSheet("color:#9a9a9a;")

        self.chain.addWidget(self.empty_label)
        self.chain.addStretch(1)
        self._spacer_index = self.chain.count() - 1
        self.scroll.setWidget(self.chain_host)

        layout.addWidget(title)
        layout.addWidget(sep)
        layout.addWidget(self.scroll, 1)

    def _refresh_empty_state(self) -> None:
        has_devices = len(self._device_boxes) > 0
        try:
            self.empty_label.setVisible(not has_devices)
        except Exception:
            pass


    def _apply_chain_stretches(self) -> None:
        """Ensure device boxes can expand horizontally (no 'too narrow' devices)."""
        try:
            # Give each device box stretch=1 so it can take available width.
            for idx in range(self.chain.count()):
                it = self.chain.itemAt(idx)
                w = it.widget() if it is not None else None
                if isinstance(w, _DeviceBox):
                    self.chain.setStretch(idx, 1)
                else:
                    self.chain.setStretch(idx, 0)

            # Spacer item is used only in empty state to push hint label left.
            spacer_idx = None
            for idx in range(self.chain.count() - 1, -1, -1):
                it = self.chain.itemAt(idx)
                if it is not None and it.spacerItem() is not None:
                    spacer_idx = idx
                    break
            if spacer_idx is not None:
                self.chain.setStretch(spacer_idx, 0 if self._device_boxes else 1)
        except Exception:
            pass

    def add_instrument(self, plugin_id: str) -> bool:
        plugin_id = (plugin_id or "").strip()
        if not plugin_id:
            return False

        instruments = {i.plugin_id: i for i in get_instruments()}
        spec = instruments.get(plugin_id)
        if spec is None:
            return False

        project = getattr(self._services, "project", None) if self._services is not None else None
        audio_engine = getattr(self._services, "audio_engine", None) if self._services is not None else None

        try:
            w = spec.factory(project_service=project, audio_engine=audio_engine)
        except Exception as e:
            err = QLabel(f"Fehler beim Laden: {e}")
            w = err

        w.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        def _remove():
            try:
                # allow device to cleanup
                if hasattr(w, "shutdown"):
                    w.shutdown()
            except Exception:
                pass
            try:
                box.setParent(None)
                box.deleteLater()
            except Exception:
                pass
            try:
                self._device_boxes.remove(box)
            except Exception:
                pass
            self._refresh_empty_state()
            self._apply_chain_stretches()

        box = _DeviceBox(spec.name, w, on_close=_remove)
        # keep sane default width (box itself has min/max)
        box.setMinimumWidth(560)
        self._device_boxes.append(box)

        # Insert before stretch
        # Remove existing stretch and add again at end
        # (QHBoxLayout doesn't provide direct access, so rebuild small)
        self.chain.insertWidget(max(0, self.chain.count() - 1), box, 1)
        self._apply_chain_stretches()
        self._refresh_empty_state()
        return True