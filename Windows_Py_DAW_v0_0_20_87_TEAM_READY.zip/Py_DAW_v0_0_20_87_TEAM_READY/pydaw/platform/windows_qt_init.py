"""Windows-specific Qt bootstrap.

Goal:
- Prefer Direct3D rendering where possible.
  * For Qt Widgets + QOpenGLWidget, the most reliable path is ANGLE -> D3D11.
  * For Qt Quick / SceneGraph (if used), QSG_RHI_BACKEND can be set to d3d11/d3d12.

This file is imported *before* PyQt6 is imported (see main.py).
"""

from __future__ import annotations

import os
import sys


def init_windows_rendering(prefer: str = "d3d11") -> None:
    """Set environment variables to steer Qt towards Direct3D on Windows."""
    if not sys.platform.startswith("win"):
        return

    prefer = (prefer or "d3d11").lower().strip()

    # Power-user override for troubleshooting rendering issues.
    # Options: angle (default), desktop, software
    ogl_mode = os.environ.get("PYDAW_QT_OPENGL", "angle").strip().lower()

    # Route OpenGL calls through ANGLE (Direct3D on Windows) by default.
    # This is the most robust for PyQt6 Widgets apps, and helps QOpenGLWidget.
    if ogl_mode in ("desktop", "opengl", "native"):
        os.environ.setdefault("QT_OPENGL", "desktop")
    elif ogl_mode in ("software", "sw"):
        os.environ.setdefault("QT_OPENGL", "software")
    else:
        os.environ.setdefault("QT_OPENGL", "angle")

    # Tell Qt/ANGLE to prefer D3D11.
    os.environ.setdefault("QT_ANGLE_PLATFORM", "d3d11")

    # If the app uses any Qt Quick / SceneGraph, this selects the RHI backend.
    # d3d12 can be faster on modern GPUs, but d3d11 is the safe default.
    if prefer in ("d3d12", "12"):
        os.environ.setdefault("QSG_RHI_BACKEND", "d3d12")
    else:
        os.environ.setdefault("QSG_RHI_BACKEND", "d3d11")

    # QoL / scaling.
    os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
