"""Platform-specific helpers.

This package exists so we can keep OS-specific bootstraps isolated.
"""
