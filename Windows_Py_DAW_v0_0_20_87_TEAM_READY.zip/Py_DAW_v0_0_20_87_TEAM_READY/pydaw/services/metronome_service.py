"""MetronomeService (v0.0.13).

Plays a simple click on metronome ticks without blocking the GUI.

Implementation strategy:
- Prefer sounddevice OutputStream (PortAudio) if available.
- If unavailable or fails, falls back to a no-op with status messages.

This is placeholder-quality audio, sufficient for a first "real DAW" step.
"""

from __future__ import annotations

import os
import sys

import math
import threading
from dataclasses import dataclass
from typing import Optional, Callable

import numpy as np

try:
    import sounddevice as sd  # type: ignore
except Exception:  # noqa: BLE001
    sd = None  # type: ignore

# --- Windows: prefer WASAPI output for sounddevice
def _sd_find_hostapi_index(sd_mod, preferred_names: list[str]) -> int | None:
    try:
        hostapis = sd_mod.query_hostapis()
    except Exception:
        return None
    for i, api in enumerate(hostapis):
        name = str(api.get('name', '')).lower()
        if any(p.lower() in name for p in preferred_names):
            return i
    return None


def _sd_pick_default_output_for_hostapi(sd_mod, hostapi_index: int) -> int | None:
    try:
        api = sd_mod.query_hostapis(hostapi_index)
    except Exception:
        return None
    dev = api.get('default_output_device')
    if dev is None:
        return None
    try:
        return int(dev)
    except Exception:
        return None


def _sd_pick_preferred_output_device(sd_mod, preferred: str | None) -> int | None:
    if not sys.platform.startswith('win'):
        return None
    pref = (preferred or 'wasapi').strip().lower()
    if pref in ('a','asio'):
        pref_names = ['asio']
    elif pref in ('d','directsound'):
        pref_names = ['directsound']
    elif pref in ('m','mme'):
        pref_names = ['mme']
    else:
        pref_names = ['wasapi']
    chain=[]
    seen=set()
    for x in pref_names + ['asio','wasapi','directsound','mme']:
        if x not in seen:
            chain.append(x); seen.add(x)
    idx = _sd_find_hostapi_index(sd_mod, chain)
    if idx is None:
        return None
    return _sd_pick_default_output_for_hostapi(sd_mod, idx)


def _sd_wasapi_extra_settings(sd_mod):
    if not sys.platform.startswith('win'):
        return None
    try:
        exclusive = os.environ.get('PYDAW_WASAPI_EXCLUSIVE', '0') in ('1','true','True','yes','on')
        if not exclusive:
            return None
        return sd_mod.WasapiSettings(exclusive=True)
    except Exception:
        return None




@dataclass
class MetronomeConfig:
    samplerate: int = 48000
    device: Optional[int] = None
    volume: float = 0.35


class MetronomeService:
    def __init__(self, on_status: Callable[[str], None] | None = None):
        self.cfg = MetronomeConfig()
        self._lock = threading.Lock()
        self._enabled = True
        self._stream = None
        self._queue: list[np.ndarray] = []
        self._on_status = on_status or (lambda _m: None)

    def configure(self, samplerate: int | None = None, device: int | None = None, volume: float | None = None) -> None:
        with self._lock:
            if samplerate is not None:
                self.cfg.samplerate = int(samplerate)
            if device is not None:
                self.cfg.device = int(device)
            if volume is not None:
                self.cfg.volume = float(volume)
        self._restart_stream()

    def set_enabled(self, enabled: bool) -> None:
        self._enabled = bool(enabled)

    def shutdown(self) -> None:
        with self._lock:
            self._queue.clear()
            if self._stream is not None:
                try:
                    self._stream.stop()
                    self._stream.close()
                except Exception:
                    pass
                self._stream = None

    def play_click(self, accent: bool = False) -> None:
        if not self._enabled:
            return
        if sd is None:
            return

        # create a short click (noise burst + decay)
        sr = int(self.cfg.samplerate)
        length_ms = 18 if accent else 12
        n = max(1, int(sr * length_ms / 1000.0))
        t = np.linspace(0.0, 1.0, n, endpoint=False, dtype=np.float32)
        env = np.exp(-t * (18.0 if accent else 22.0)).astype(np.float32)
        noise = (np.random.uniform(-1.0, 1.0, n).astype(np.float32) * env)
        click = (noise * float(self.cfg.volume) * (1.35 if accent else 1.0)).astype(np.float32)
        stereo = np.column_stack([click, click])

        with self._lock:
            self._queue.append(stereo)
        self._ensure_stream()

    # --- internal

    def _ensure_stream(self) -> None:
        if sd is None:
            return
        with self._lock:
            if self._stream is not None:
                return
        self._restart_stream()

    def _restart_stream(self) -> None:
        if sd is None:
            return
        with self._lock:
            # close old
            if self._stream is not None:
                try:
                    self._stream.stop()
                    self._stream.close()
                except Exception:
                    pass
                self._stream = None

            try:


                dev = self.cfg.device


                extra = None


                if sys.platform.startswith('win'):


                    try:


                        if dev is None:


                            dev = _sd_pick_preferred_output_device(sd, os.environ.get('PYDAW_SD_HOSTAPI', 'wasapi'))


                    except Exception:


                        dev = self.cfg.device


                    try:


                        extra = _sd_wasapi_extra_settings(sd)


                    except Exception:


                        extra = None
                self._stream = sd.OutputStream(
                    samplerate=int(self.cfg.samplerate),
                    channels=2,
                    dtype="float32",
                    device=dev,
                    extra_settings=extra,
                    callback=self._callback,
                    blocksize=0,
                )
                self._stream.start()
                self._on_status("Metronom Audio: OutputStream aktiv.")
            except Exception as exc:  # noqa: BLE001
                self._stream = None
                self._on_status(f"Metronom Audio deaktiviert: {exc}")

    def _callback(self, outdata, frames, time, status):  # noqa: ANN001
        # Called from PortAudio thread.
        outdata[:] = 0.0
        if status:
            # don't spam
            pass
        with self._lock:
            if not self._queue:
                return
            buf = self._queue[0]
            take = min(frames, buf.shape[0])
            outdata[:take, :] = buf[:take, :]
            if take < buf.shape[0]:
                self._queue[0] = buf[take:, :]
            else:
                self._queue.pop(0)
