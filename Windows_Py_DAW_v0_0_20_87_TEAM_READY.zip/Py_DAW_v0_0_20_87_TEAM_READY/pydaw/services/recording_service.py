"""Recording service for PipeWire and JACK audio backends.

Handles audio recording from system inputs through PipeWire or JACK.
"""

from __future__ import annotations

import os
import sys
import queue
import threading
import wave
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    pass


# --- Windows: prefer WASAPI/ASIO input device for sounddevice (PortAudio)
def _sd_find_hostapi_index(sd_mod, preferred_names: list[str]) -> int | None:
    try:
        hostapis = sd_mod.query_hostapis()
    except Exception:
        return None
    for i, api in enumerate(hostapis):
        name = str(api.get('name', '')).lower()
        if any(p.lower() in name for p in preferred_names):
            return i
    return None


def _sd_pick_default_input_for_hostapi(sd_mod, hostapi_index: int) -> int | None:
    try:
        api = sd_mod.query_hostapis(hostapi_index)
    except Exception:
        return None
    dev = api.get('default_input_device')
    if dev is None:
        return None
    try:
        return int(dev)
    except Exception:
        return None


def _sd_pick_preferred_input_device(sd_mod, preferred: str | None) -> int | None:
    if not sys.platform.startswith('win'):
        return None
    pref = (preferred or 'wasapi').strip().lower()
    if pref in ('a','asio'):
        pref_names = ['asio']
    elif pref in ('d','directsound'):
        pref_names = ['directsound']
    elif pref in ('m','mme'):
        pref_names = ['mme']
    else:
        pref_names = ['wasapi']
    chain=[]
    seen=set()
    for x in pref_names + ['asio','wasapi','directsound','mme']:
        if x not in seen:
            chain.append(x); seen.add(x)
    idx = _sd_find_hostapi_index(sd_mod, chain)
    if idx is None:
        return None
    return _sd_pick_default_input_for_hostapi(sd_mod, idx)


def _sd_wasapi_extra_settings(sd_mod):
    if not sys.platform.startswith('win'):
        return None
    try:
        exclusive = os.environ.get('PYDAW_WASAPI_EXCLUSIVE', '0') in ('1','true','True','yes','on')
        if not exclusive:
            return None
        return sd_mod.WasapiSettings(exclusive=True)
    except Exception:
        return None


class RecordingService:
    """Service for recording audio through PipeWire/JACK.
    
    Supports:
    - PipeWire native recording
    - JACK recording (via python-jack-client or pw-jack)
    - Sounddevice fallback
    """
    
    def __init__(self):
        self._recording = False
        self._record_thread: threading.Thread | None = None
        self._audio_queue: queue.Queue = queue.Queue()
        self._backend = "sounddevice"  # default
        self._sample_rate = 48000
        self._channels = 2
        self._output_path: Path | None = None
        self._recorded_frames: list[np.ndarray] = []
        
        # Detect available backends
        self._detect_backend()
    
    def _detect_backend(self) -> None:
        """Detect which audio backend is available."""
        # Check for JACK
        try:
            import jack
            self._backend = "jack"
            return
        except ImportError:
            pass
        
        # Check for PipeWire via sounddevice
        try:
            import sounddevice as sd
            # PipeWire should show up in device list
            devices = sd.query_devices()
            for dev in devices:
                if dev.get('name', '').lower().find('pipewire') >= 0:
                    self._backend = "pipewire"
                    return
        except Exception:
            pass
        
        # Fallback to sounddevice
        self._backend = "sounddevice"
    
    def get_backend(self) -> str:
        """Get current recording backend."""
        return self._backend
    
    def is_recording(self) -> bool:
        """Check if currently recording."""
        return self._recording
    
    def start_recording(self, output_path: str | Path, sample_rate: int = 48000, channels: int = 2) -> bool:
        """Start recording audio.
        
        Args:
            output_path: Path where to save the WAV file
            sample_rate: Sample rate in Hz
            channels: Number of audio channels
            
        Returns:
            True if recording started successfully
        """
        if self._recording:
            return False
        
        self._output_path = Path(output_path)
        self._sample_rate = sample_rate
        self._channels = channels
        self._recorded_frames = []
        
        # Start recording thread based on backend
        if self._backend == "jack":
            success = self._start_jack_recording()
        elif self._backend == "pipewire":
            success = self._start_pipewire_recording()
        else:
            success = self._start_sounddevice_recording()
        
        if success:
            self._recording = True
        
        return success
    
    def stop_recording(self) -> Path | None:
        """Stop recording and save the audio file.
        
        Returns:
            Path to the saved file, or None if recording failed
        """
        if not self._recording:
            return None
        
        self._recording = False
        
        # Wait for recording thread to finish
        if self._record_thread and self._record_thread.is_alive():
            self._record_thread.join(timeout=2.0)
        
        # Save recorded audio to WAV file
        if self._recorded_frames and self._output_path:
            try:
                return self._save_wav()
            except Exception as e:
                print(f"Error saving recording: {e}")
                return None
        
        return None
    
    def _start_jack_recording(self) -> bool:
        """Start JACK recording."""
        try:
            import jack
            
            def record_callback(frames):
                if not self._recording:
                    raise jack.CallbackExit
                # Store audio frames
                self._recorded_frames.append(frames.copy())
            
            self._jack_client = jack.Client("PyDAW_Recorder")
            self._jack_client.set_process_callback(record_callback)
            
            # Create input ports
            self._jack_ports = []
            for i in range(self._channels):
                port = self._jack_client.inports.register(f"input_{i+1}")
                self._jack_ports.append(port)
            
            # Start JACK client
            self._jack_client.activate()
            
            # Auto-connect to system capture ports
            capture_ports = self._jack_client.get_ports(
                is_physical=True, is_output=True, is_audio=True
            )
            for i, port in enumerate(self._jack_ports):
                if i < len(capture_ports):
                    self._jack_client.connect(capture_ports[i], port)
            
            return True
            
        except Exception as e:
            print(f"JACK recording failed: {e}")
            return False
    
    def _start_pipewire_recording(self) -> bool:
        """Start PipeWire recording via sounddevice."""
        return self._start_sounddevice_recording()
    
    def _start_sounddevice_recording(self) -> bool:
        """Start sounddevice recording (works with PipeWire too)."""
        try:
            import sounddevice as sd
            
            def audio_callback(indata, frames, time, status):
                if status:
                    print(f"Recording status: {status}")
                if self._recording:
                    self._recorded_frames.append(indata.copy())
            
            # Pick a good Windows host API (WASAPI preferred)
            dev = None
            extra = None
            if sys.platform.startswith('win'):
                try:
                    dev = _sd_pick_preferred_input_device(sd, os.environ.get('PYDAW_SD_HOSTAPI', 'wasapi'))
                except Exception:
                    dev = None
                try:
                    extra = _sd_wasapi_extra_settings(sd)
                except Exception:
                    extra = None

            # Start recording stream
            self._sd_stream = sd.InputStream(
                samplerate=self._sample_rate,
                channels=self._channels,
                callback=audio_callback,
                dtype="float32",
                device=dev,
                extra_settings=extra,
            )
            self._sd_stream.start()
            
            return True
            
        except Exception as e:
            print(f"Sounddevice recording failed: {e}")
            return False
    
    def _save_wav(self) -> Path:
        """Save recorded frames to WAV file."""
        if not self._output_path:
            raise ValueError("No output path set")
        
        # Ensure parent directory exists
        self._output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Concatenate all recorded frames
        audio_data = np.concatenate(self._recorded_frames, axis=0)
        
        # Convert float32 to int16 for WAV
        audio_int16 = (audio_data * 32767).astype(np.int16)
        
        # Save as WAV
        with wave.open(str(self._output_path), 'wb') as wf:
            wf.setnchannels(self._channels)
            wf.setsampwidth(2)  # 16-bit
            wf.setframerate(self._sample_rate)
            wf.writeframes(audio_int16.tobytes())
        
        return self._output_path
    
    def cleanup(self) -> None:
        """Clean up resources."""
        if self._recording:
            self.stop_recording()
        
        # Close JACK client if active
        if hasattr(self, '_jack_client'):
            try:
                self._jack_client.deactivate()
                self._jack_client.close()
            except Exception:
                pass
        
        # Close sounddevice stream if active
        if hasattr(self, '_sd_stream'):
            try:
                self._sd_stream.stop()
                self._sd_stream.close()
            except Exception:
                pass
