# -*- coding: utf-8 -*-
"""Note-FX Chain (MIDI vor Instrument).

Engine-first MVP:
- JSON-safe chain spec lives in Track.note_fx_chain
- prepare_clips() applies Note-FX to MIDI notes before:
  - SF2 pre-render
  - MIDI event stream for Sampler/Drum plugins
- UI uses the same helpers for preview routing.

Spec (Track.note_fx_chain):
{
  "devices": [
     {"plugin_id":"chrono.note_fx.transpose","id":"nfx_xxx","enabled":true,"params":{"semitones":0}},
     ...
  ]
}
"""
from __future__ import annotations

import json
import hashlib
import random
from dataclasses import replace
from typing import Any, Iterable, List, Tuple


def _clamp_midi(v: int) -> int:
    return max(0, min(127, int(v)))

# --- Note-FX helpers (MVP set)

_SCALE_PATTERNS = {
    "major":       [0, 2, 4, 5, 7, 9, 11],
    "minor":       [0, 2, 3, 5, 7, 8, 10],
    "dorian":      [0, 2, 3, 5, 7, 9, 10],
    "phrygian":    [0, 1, 3, 5, 7, 8, 10],
    "lydian":      [0, 2, 4, 6, 7, 9, 11],
    "mixolydian":  [0, 2, 4, 5, 7, 9, 10],
    "locrian":     [0, 1, 3, 5, 6, 8, 10],
    "pentatonic":  [0, 2, 4, 7, 9],
    "chromatic":   list(range(12)),
}

_CHORD_INTERVALS = {
    "maj":   [0, 4, 7],
    "min":   [0, 3, 7],
    "power": [0, 7],
    "maj7":  [0, 4, 7, 11],
    "min7":  [0, 3, 7, 10],
    "dim":   [0, 3, 6],
    "aug":   [0, 4, 8],
}

def _stable_seed_int(s: str) -> int:
    d = hashlib.md5(s.encode("utf-8")).digest()
    return int.from_bytes(d[:8], "little", signed=False)

def _snap_pitch_to_scale(pitch: int, root: int, scale: str, mode: str = "nearest") -> int:
    pitch = int(_clamp_midi(pitch))
    root = int(root) % 12
    patt = _SCALE_PATTERNS.get(str(scale or "major"), _SCALE_PATTERNS["major"])
    allowed_pcs = { (root + int(x)) % 12 for x in patt }

    # generate candidates around pitch (±12 semitones)
    candidates = []
    for oct_shift in (-12, 0, 12):
        base = pitch + oct_shift
        base_oct = (base // 12) * 12
        for pc in allowed_pcs:
            cand = base_oct + pc
            if 0 <= cand <= 127:
                candidates.append(cand)
    if not candidates:
        return pitch

    if mode == "down":
        cands = [c for c in candidates if c <= pitch]
        return max(cands) if cands else min(candidates)
    if mode == "up":
        cands = [c for c in candidates if c >= pitch]
        return min(cands) if cands else max(candidates)

    # nearest
    candidates.sort(key=lambda c: (abs(c - pitch), c))
    return int(candidates[0])


def note_fx_chain_signature(chain: Any) -> str:
    """Stable signature string used for cache keys.

    If the chain changes, rendered SF2 WAV cache must be invalidated.
    """
    try:
        return json.dumps(chain or {}, sort_keys=True, ensure_ascii=False)
    except Exception:
        try:
            return str(chain)
        except Exception:
            return ""


def apply_note_fx_chain_to_pitch_velocity(pitch: int, velocity: int, chain: Any) -> List[Tuple[int, int]]:
    """Apply Note-FX chain to a single (pitch, velocity) pair.

    Returns a list because future Note-FX (arp/chord) can expand events.
    """
    out: List[Tuple[int, int]] = [(_clamp_midi(pitch), _clamp_midi(velocity))]
    devices = []
    if isinstance(chain, dict):
        devices = chain.get("devices", []) or []
    elif isinstance(chain, list):
        devices = chain
    for dev in devices:
        if not isinstance(dev, dict):
            continue
        if dev.get("enabled", True) is False:
            continue
        pid = (dev.get("plugin_id") or dev.get("type") or "").strip()
        params = dev.get("params", {}) if isinstance(dev.get("params", {}), dict) else {}
        if pid in ("chrono.note_fx.transpose", "transpose", "TransposeFx"):
            semis = int(params.get("semitones", 0) or 0)
            out = [(_clamp_midi(p + semis), v) for (p, v) in out]
        elif pid in ("chrono.note_fx.velocity_scale", "velocity_scale", "VelocityScaleFx"):
            scale = float(params.get("scale", 1.0) or 1.0)
            out = [(p, _clamp_midi(int(round(v * scale)))) for (p, v) in out]
        else:
            # Unknown device: ignore (forward compatible)
            continue
    return out


def apply_note_fx_chain_to_notes(notes: Iterable[Any], chain: Any) -> List[Any]:
    """
    Applies Note-FX devices to a list of note-like objects (expects .clone(), .pitch, .velocity, .start_beats, .length_beats).
    Supported (MVP): Transpose, VelScale, ScaleSnap, Chord, Random, Arp.
    """
    try:
        devices = []
        if isinstance(chain, dict):
            devices = chain.get("devices", []) or []
        if not devices:
            return list(notes)

        out_notes: List[Any] = list(notes)

        def _apply_arp(in_notes: List[Any], params: dict, dev_id: str) -> List[Any]:
            step = float(params.get("step_beats", 0.5) or 0.5)
            mode = str(params.get("mode", "up") or "up")
            octaves = int(params.get("octaves", 1) or 1)
            gate = float(params.get("gate", 0.9) or 0.9)

            step = float(max(0.0625, min(4.0, step)))
            octaves = int(max(1, min(4, octaves)))
            gate = float(max(0.1, min(1.0, gate)))

            # group by start_beats (exact match, with tolerance)
            groups = {}
            for n in in_notes:
                try:
                    key = round(float(getattr(n, "start_beats", 0.0)), 6)
                except Exception:
                    key = 0.0
                groups.setdefault(key, []).append(n)

            result: List[Any] = []
            for key in sorted(groups.keys()):
                g = groups[key]
                if not g:
                    continue

                # collect chord pitches/velocities
                pitches = [int(getattr(n, "pitch", 60) or 60) for n in g]
                velocities = [int(getattr(n, "velocity", 100) or 100) for n in g]
                base_vel = int(_clamp(max(velocities) if velocities else 100, 1, 127))

                pitches_sorted = sorted(set(pitches))
                # extend across octaves
                seq = []
                for o in range(octaves):
                    for p in pitches_sorted:
                        pp = p + 12 * o
                        if 0 <= pp <= 127:
                            seq.append(pp)
                if not seq:
                    seq = pitches_sorted

                if mode == "down":
                    seq = list(reversed(seq))
                elif mode == "updown":
                    if len(seq) > 1:
                        seq = seq + list(reversed(seq[1:-1]))
                elif mode == "random":
                    seed = _stable_seed_int(f"{dev_id}|{key}|{len(seq)}")
                    rnd = random.Random(seed)
                    rnd.shuffle(seq)

                # duration of the group
                try:
                    group_end = max(float(getattr(n, "start_beats", 0.0)) + float(getattr(n, "length_beats", 0.125)) for n in g)
                except Exception:
                    group_end = float(key) + 0.5

                group_start = float(key)
                total_len = max(0.125, group_end - group_start)
                count = max(1, int(total_len / step + 1e-9))

                template = g[0].clone()
                for i in range(count):
                    nn = template.clone()
                    nn.start_beats = float(group_start + i * step)
                    nn.length_beats = float(max(0.125, step * gate))
                    nn.pitch = int(_clamp_midi(seq[i % len(seq)]))
                    nn.velocity = int(base_vel)
                    result.append(nn)

            # keep stable ordering
            try:
                result.sort(key=lambda n: (float(getattr(n, "start_beats", 0.0)), int(getattr(n, "pitch", 0))))
            except Exception:
                pass
            return result

        # Apply devices in chain order
        for dev in devices:
            if not isinstance(dev, dict):
                continue
            if dev.get("enabled", True) is False:
                continue

            pid = str(dev.get("plugin_id") or dev.get("type") or "")
            params = dev.get("params") if isinstance(dev.get("params"), dict) else {}
            dev_id = str(dev.get("id") or pid)

            if pid == "chrono.note_fx.arp":
                out_notes = _apply_arp(out_notes, params, dev_id)
                continue

            # per-note transforms (can expand notes)
            next_notes: List[Any] = []
            for n in out_notes:
                try:
                    base_p = int(getattr(n, "pitch", 60) or 60)
                    base_v = int(getattr(n, "velocity", 100) or 100)
                    pairs = [(base_p, base_v)]

                    if pid == "chrono.note_fx.transpose":
                        semi = int(params.get("semitones", 0) or 0)
                        pairs = [(int(_clamp_midi(p + semi)), v) for p, v in pairs]

                    elif pid == "chrono.note_fx.velocity_scale":
                        sc = float(params.get("scale", 1.0) or 1.0)
                        pairs = [(p, int(_clamp(v * sc, 0, 127))) for p, v in pairs]

                    elif pid == "chrono.note_fx.scale_snap":
                        root = int(params.get("root", 0) or 0)
                        scale = str(params.get("scale", "major") or "major")
                        mode = str(params.get("mode", "nearest") or "nearest")
                        pairs = [(_snap_pitch_to_scale(p, root, scale, mode), v) for p, v in pairs]

                    elif pid == "chrono.note_fx.chord":
                        chord = str(params.get("chord", "maj") or "maj")
                        intervals = _CHORD_INTERVALS.get(chord, _CHORD_INTERVALS["maj"])
                        expanded = []
                        for p, v in pairs:
                            for itv in intervals:
                                expanded.append((int(_clamp_midi(int(p) + int(itv))), int(v)))
                        pairs = expanded

                    elif pid == "chrono.note_fx.random":
                        pr = int(params.get("pitch_range", 0) or 0)
                        vr = int(params.get("vel_range", 0) or 0)
                        prob = float(params.get("prob", 1.0) or 1.0)
                        pr = int(_clamp(pr, 0, 24))
                        vr = int(_clamp(vr, 0, 127))
                        prob = float(_clamp(prob, 0.0, 1.0))

                        seed = _stable_seed_int(f"{dev_id}|{getattr(n, 'start_beats', 0.0)}|{base_p}|{base_v}")
                        rnd = random.Random(seed)
                        if rnd.random() <= prob:
                            if pr:
                                base_p2 = int(_clamp_midi(base_p + rnd.randint(-pr, pr)))
                            else:
                                base_p2 = base_p
                            if vr:
                                base_v2 = int(_clamp(base_v + rnd.randint(-vr, vr), 0, 127))
                            else:
                                base_v2 = base_v
                            pairs = [(base_p2, base_v2)]

                    # emit notes for each pair
                    for p, v in pairs:
                        nn = n.clone()
                        nn.pitch = int(_clamp_midi(int(p)))
                        nn.velocity = int(_clamp(int(v), 0, 127))
                        next_notes.append(nn)
                except Exception:
                    # fallback: keep original note
                    next_notes.append(n)

            out_notes = next_notes

        return out_notes
    except Exception:
        return list(notes)
