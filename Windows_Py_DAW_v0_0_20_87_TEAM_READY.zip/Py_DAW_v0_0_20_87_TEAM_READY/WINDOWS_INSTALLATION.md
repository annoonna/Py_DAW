# Py_DAW – Windows Setup (TEAM_READY)

## 1) Virtuelle Umgebung

PowerShell:

```powershell
cd Py_DAW_v0_0_20_87_TEAM_READY
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python install.py
python main.py
```

CMD:

```bat
cd Py_DAW_v0_0_20_87_TEAM_READY
python -m venv .venv
.venv\Scripts\activate
python install.py
python main.py
```

## 2) Audio (PortAudio / sounddevice)

Standardmäßig setzt `main.py` auf Windows automatisch:
- `PYDAW_SD_HOSTAPI=wasapi`

Optional:
- `set PYDAW_SD_HOSTAPI=asio` (wenn du ein ASIO-Device installiert hast)
- `set PYDAW_SD_HOSTAPI=directsound` (Fallback)
- `set PYDAW_WASAPI_EXCLUSIVE=1` (Exclusive Mode – kann andere Apps blockieren)

## 3) Grafik / Rendering

Standardmäßig nutzt Windows die sichere Option:
- Qt Widgets: `QT_OPENGL=angle` (ANGLE -> D3D11)

Optional:
- `set PYDAW_QT_OPENGL=desktop` (native OpenGL – nur wenn Treiber stabil)
- `set PYDAW_QT_OPENGL=software` (Notfallmodus)

## 4) SF2 / Instrumente (FluidSynth)

Das Instrument-Rendering (SF2) läuft über **FluidSynth**.

Empfohlen (einfach):
- FluidSynth installieren und sicherstellen, dass `fluidsynth.exe` im `PATH` ist.

Alternative:
- `set FLUIDSYNTH_PATH=C:\\Programme\\FluidSynth\\bin\\fluidsynth.exe`

Wenn FluidSynth nicht gefunden wird, läuft die DAW trotzdem, aber SF2-Render zeigt eine Fehlermeldung.
