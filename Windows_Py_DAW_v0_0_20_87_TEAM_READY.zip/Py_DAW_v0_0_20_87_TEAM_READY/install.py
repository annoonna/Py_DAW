"""Installer helper for Py_DAW (Windows-friendly).

Usage:
    python install.py

It will:
- warn if you're not inside a virtual environment
- install/upgrade pip tooling
- install requirements.txt

Notes:
- Linux: JACK/PipeWire system components are NOT installed here (distro packages).
- Windows: Audio runs via PortAudio (sounddevice), default host API is WASAPI.
- SF2 / Instrument rendering uses FluidSynth. On Windows you likely need either:
    (A) FluidSynth CLI (fluidsynth.exe) in PATH, or
    (B) set FLUIDSYNTH_PATH=C:\\path\\to\\fluidsynth.exe
  If neither is present, the DAW can still run, but SF2 rendering will show an error.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def _print_venv_hint() -> None:
    sysname = platform.system().lower()
    if sysname.startswith("win"):
        print("      Empfehlung (Windows):")
        print("        python -m venv .venv")
        print(r"        .venv\Scripts\activate")
    else:
        print("      Empfehlung (Linux/macOS):")
        print("        python3 -m venv .venv && source .venv/bin/activate")


def main() -> int:
    here = Path(__file__).resolve().parent
    req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        _print_venv_hint()

    py = sys.executable

    # Upgrade core packaging tools
    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    # Install requirements
    _run([py, "-m", "pip", "install", "-r", str(req)])

    # Windows-only helpful hints
    if platform.system().lower().startswith("win"):
        print("\nWindows Hinweise:")
        print("- Rendering: Standard ist ANGLE->D3D11. Override: set PYDAW_QT_OPENGL=desktop (oder software).")
        print("- Audio: Standard-HostAPI ist WASAPI. Override: set PYDAW_SD_HOSTAPI=asio/directsound/mme")
        print("- Optional: set PYDAW_WASAPI_EXCLUSIVE=1 für Exclusive Mode (kann andere Apps blockieren).")

        exe = (os.environ.get("FLUIDSYNTH_PATH") or os.environ.get("PYDAW_FLUIDSYNTH_PATH") or "").strip()
        if exe:
            ok = Path(exe).exists()
        else:
            ok = bool(shutil.which("fluidsynth")) or bool(shutil.which("fluidsynth.exe"))

        if not ok:
            print("\nSF2 (Instrumente) Hinweis:")
            print("- FluidSynth CLI nicht gefunden. Für SF2-Rendering bitte FluidSynth installieren")
            print(r"  und sicherstellen, dass 'fluidsynth.exe' im PATH ist, oder set FLUIDSYNTH_PATH=C:\\...\\fluidsynth.exe")

    sysname = platform.system().lower()
    if sysname.startswith("win"):
        print("\nOK. Starte danach mit: python main.py")
    else:
        print("\nOK. Starte danach mit: python3 main.py")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
