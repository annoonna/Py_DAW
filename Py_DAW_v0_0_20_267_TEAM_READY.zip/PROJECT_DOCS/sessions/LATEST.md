Latest session: SESSION_v0.0.20.263_LADSPA_AUTOMATION_UI_LIVE_SYNC_FIX_2026-03-06.md


- v0.0.20.264: SF2 MPE program/channel initialization fixed; render cache invalidation added.

Latest session: SESSION_v0.0.20.265_MIDI_EXPR_SAFE_JOIN_SPLIT_AND_PIANOROLL_SYNC_2026-03-06.md

- v0.0.20.265: PianoRoll local clip sync fixed; Note Expression Lane refresh improved; MIDI join/split now preserve micropitch/expressions.
