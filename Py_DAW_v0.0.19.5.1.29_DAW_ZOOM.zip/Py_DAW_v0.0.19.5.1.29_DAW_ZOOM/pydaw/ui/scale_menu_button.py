"""Bitwig-like Scale selector button (minimal).

This is intentionally small but practical:

- Shows the *currently selected* scale (e.g. "C Major")
- Provides a menu to select:
    - enable/disable scale constraint
    - root note (C..B)
    - scale (grouped by category)
    - mode: Snap or Reject

The selection is persisted via :mod:`pydaw.core.settings_store`.
"""

from __future__ import annotations

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtGui import QAction, QActionGroup
from PyQt6.QtWidgets import QMenu, QToolButton

from pydaw.core.settings import SettingsKeys
from pydaw.core.settings_store import get_value, set_value
from pydaw.music.scales import (
    list_scale_categories,
    list_scales_in_category,
    pc_name,
)


class ScaleMenuButton(QToolButton):
    """A small toolbar button showing current scale, with dropdown menu."""

    changed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._keys = SettingsKeys()

        self.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.setToolTip("Skalen-Menü (Scale Lock)")

        # Bitwig-ish visual hint (cyan accent, dark background)
        self.setStyleSheet(
            "QToolButton{padding:4px 8px;border-radius:6px;"
            "background:#1f252b;color:#e8f8ff;border:1px solid #2c3942;}"
            "QToolButton:hover{border:1px solid #00bcd4;color:#00e5ff;}"
        )

        self._rebuild_menu()
        self._refresh_text()

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------
    def refresh(self) -> None:
        self._refresh_text()
        self._rebuild_menu()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    def _defaults(self) -> None:
        if get_value(self._keys.scale_root_pc, None) is None:
            set_value(self._keys.scale_root_pc, 0)
        if get_value(self._keys.scale_category, None) is None:
            set_value(self._keys.scale_category, "Keine Einschränkung")
        if get_value(self._keys.scale_name, None) is None:
            set_value(self._keys.scale_name, "Alle Noten")
        if get_value(self._keys.scale_mode, None) is None:
            set_value(self._keys.scale_mode, "snap")
        if get_value(self._keys.scale_enabled, None) is None:
            set_value(self._keys.scale_enabled, False)
        if get_value(self._keys.scale_visualize, None) is None:
            set_value(self._keys.scale_visualize, True)

    def _current_label(self) -> str:
        self._defaults()
        enabled = bool(get_value(self._keys.scale_enabled, False))
        cat = str(get_value(self._keys.scale_category, "Keine Einschränkung"))
        name = str(get_value(self._keys.scale_name, "Alle Noten"))
        root = int(get_value(self._keys.scale_root_pc, 0) or 0)
        mode = str(get_value(self._keys.scale_mode, "snap") or "snap")
        if not enabled or cat == "Keine Einschränkung":
            return "Scale: Off"
        mm = "Snap" if mode.lower().strip() != "reject" else "Reject"
        return f"{pc_name(root)} {name} ({mm})"

    def _refresh_text(self) -> None:
        self.setText(self._current_label())

    def _set_and_emit(self, **kv) -> None:
        for k, v in kv.items():
            set_value(k, v)
        self._refresh_text()
        # Ensure checkmarks update immediately (Mode/Root/Scale).
        # Without this, Qt may keep the previous checked-state until the menu
        # is opened again, which looks like both Snap/Reject are active.
        try:
            self._rebuild_menu()
        except Exception:
            pass
        self.changed.emit()

    def _rebuild_menu(self) -> None:
        self._defaults()

        m = QMenu(self)

        # Enable toggle
        enabled = bool(get_value(self._keys.scale_enabled, False))
        act_enable = QAction("Scale Lock aktiv", self)
        act_enable.setCheckable(True)
        act_enable.setChecked(enabled)
        act_enable.triggered.connect(lambda chk: self._set_and_emit(**{self._keys.scale_enabled: bool(chk)}))
        m.addAction(act_enable)

        # Visual hints (Bitwig-like cyan dots)
        act_vis = QAction("Scale-Hints (Cyan Dots)", self)
        act_vis.setCheckable(True)
        act_vis.setChecked(bool(get_value(self._keys.scale_visualize, True)))
        act_vis.triggered.connect(lambda chk: self._set_and_emit(**{self._keys.scale_visualize: bool(chk)}))
        m.addAction(act_vis)


        # Mode
        m.addSeparator()
        mode_menu = m.addMenu("Mode")
        cur_mode = str(get_value(self._keys.scale_mode, "snap") or "snap").lower().strip()

        # Exclusive action group to avoid both being checked at once.
        g_mode = QActionGroup(self)
        g_mode.setExclusive(True)

        act_snap = QAction("Snap (zur nächstgelegenen Note)", self)
        act_snap.setCheckable(True)
        act_snap.setChecked(cur_mode != "reject")
        act_snap.setActionGroup(g_mode)
        act_snap.triggered.connect(lambda: self._set_and_emit(**{self._keys.scale_mode: "snap"}))

        act_rej = QAction("Reject (nur erlaubte Noten)", self)
        act_rej.setCheckable(True)
        act_rej.setChecked(cur_mode == "reject")
        act_rej.setActionGroup(g_mode)
        act_rej.triggered.connect(lambda: self._set_and_emit(**{self._keys.scale_mode: "reject"}))

        mode_menu.addAction(act_snap)
        mode_menu.addAction(act_rej)

        # Root note
        m.addSeparator()
        root_menu = m.addMenu("Root")
        cur_root = int(get_value(self._keys.scale_root_pc, 0) or 0)
        for pc in range(12):
            a = QAction(pc_name(pc), self)
            a.setCheckable(True)
            a.setChecked(pc == (cur_root % 12))
            a.triggered.connect(lambda _=False, pc=pc: self._set_and_emit(**{self._keys.scale_root_pc: int(pc)}))
            root_menu.addAction(a)

        # Scales grouped by category
        m.addSeparator()
        cur_cat = str(get_value(self._keys.scale_category, "Keine Einschränkung"))
        cur_name = str(get_value(self._keys.scale_name, "Alle Noten"))

        scales_menu = m.addMenu("Scale")
        for cat in list_scale_categories():
            sub = scales_menu.addMenu(str(cat))
            for name in list_scales_in_category(str(cat)):
                a = QAction(str(name), self)
                a.setCheckable(True)
                a.setChecked((str(cat) == cur_cat) and (str(name) == cur_name))
                a.triggered.connect(
                    lambda _=False, cat=str(cat), name=str(name): self._set_and_emit(
                        **{self._keys.scale_category: cat, self._keys.scale_name: name}
                    )
                )
                sub.addAction(a)

        self.setMenu(m)
