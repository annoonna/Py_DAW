"""Workbook dialog: shows TEAM docs inside the app.

Menu: Hilfe -> Arbeitsmappe

The workbook is a simple, read-only viewer for the files in PROJECT_DOCS.
It keeps the team workflow discoverable for new contributors.

This module is intentionally defensive: missing files are handled gracefully.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)


def _safe_read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return f"(Konnte Datei nicht lesen: {path}\n{e})"


def _find_project_docs() -> Optional[Path]:
    """Try hard to locate PROJECT_DOCS.

    Priority:
    1) current working directory
    2) repository root (relative to this file)
    """
    try:
        cwd = Path.cwd()
        if (cwd / "PROJECT_DOCS").is_dir():
            return cwd / "PROJECT_DOCS"
    except Exception:
        pass

    try:
        # pydaw/ui/workbook_dialog.py -> pydaw/ui -> pydaw -> project root
        root = Path(__file__).resolve().parents[2]
        if (root / "PROJECT_DOCS").is_dir():
            return root / "PROJECT_DOCS"
    except Exception:
        pass

    return None


def _latest_session_file(sessions_dir: Path) -> Optional[Path]:
    try:
        files = [p for p in sessions_dir.glob("*.md") if p.is_file()]
        if not files:
            return None
        files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        return files[0]
    except Exception:
        return None


def _extract_next_steps(todo_text: str, max_lines: int = 60) -> str:
    """Extract a compact list of AVAILABLE tasks from TODO.md.

    This is intentionally heuristic (Markdown formatting differs over time).
    """
    lines = (todo_text or "").splitlines()
    out: list[str] = []
    current: list[str] = []

    def flush() -> None:
        nonlocal current
        if not current:
            return
        block = "\n".join(current).strip()
        if block and ("Assignee:" in block and "[ ] AVAILABLE" in block):
            out.append(block)
        current = []

    for ln in lines:
        if ln.strip().startswith("### "):
            flush()
            current = [ln]
        elif current:
            current.append(ln)
        if len(out) >= 8:
            break

    flush()

    if not out:
        # fallback: first lines
        return "\n".join(lines[:max_lines])

    header = "# Nächste Schritte (AVAILABLE Tasks)\n\n"
    return header + "\n\n---\n\n".join(out)


@dataclass
class _Tab:
    title: str
    widget: QWidget
    refresh: callable


class WorkbookDialog(QDialog):
    """QDialog that shows the team's project workbook."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Arbeitsmappe")
        self.setMinimumSize(980, 700)

        self._docs = _find_project_docs()

        top = QHBoxLayout()
        self._lbl_path = QLabel()
        self._lbl_path.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        top.addWidget(self._lbl_path, 1)

        btn_refresh = QPushButton("↻ Aktualisieren")
        btn_refresh.clicked.connect(self.refresh_all)
        top.addWidget(btn_refresh)

        self._tabs = QTabWidget()

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(10)
        root.addLayout(top)
        root.addWidget(self._tabs, 1)

        self._tab_defs: list[_Tab] = []
        self._build_tabs()
        self.refresh_all()

    def _build_tabs(self) -> None:
        def mk_text_tab(title: str) -> tuple[QWidget, QTextEdit]:
            w = QWidget()
            lay = QVBoxLayout(w)
            lay.setContentsMargins(8, 8, 8, 8)
            lay.setSpacing(6)
            te = QTextEdit()
            te.setReadOnly(True)
            te.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
            lay.addWidget(te, 1)
            self._tabs.addTab(w, title)
            return w, te

        # TODO
        w_todo, te_todo = mk_text_tab("TODO")

        def refresh_todo() -> None:
            if not self._docs:
                te_todo.setPlainText("PROJECT_DOCS nicht gefunden.\nStarte die App bitte im Projektordner.")
                return
            path = self._docs / "progress" / "TODO.md"
            te_todo.setPlainText(_safe_read_text(path))

        self._tab_defs.append(_Tab("TODO", w_todo, refresh_todo))

        # DONE
        w_done, te_done = mk_text_tab("DONE")

        def refresh_done() -> None:
            if not self._docs:
                te_done.setPlainText("PROJECT_DOCS nicht gefunden.")
                return
            path = self._docs / "progress" / "DONE.md"
            te_done.setPlainText(_safe_read_text(path))

        self._tab_defs.append(_Tab("DONE", w_done, refresh_done))

        # Latest session
        w_sess, te_sess = mk_text_tab("Letzte Session")

        def refresh_sess() -> None:
            if not self._docs:
                te_sess.setPlainText("PROJECT_DOCS nicht gefunden.")
                return
            sessions = self._docs / "sessions"
            latest = _latest_session_file(sessions)
            if not latest:
                te_sess.setPlainText("Keine Session-Logs gefunden in PROJECT_DOCS/sessions.")
                return
            te_sess.setPlainText(_safe_read_text(latest))

        self._tab_defs.append(_Tab("Letzte Session", w_sess, refresh_sess))

        # Next steps (extracted)
        w_next, te_next = mk_text_tab("Nächste Schritte")

        def refresh_next() -> None:
            if not self._docs:
                te_next.setPlainText("PROJECT_DOCS nicht gefunden.")
                return
            todo_path = self._docs / "progress" / "TODO.md"
            txt = _safe_read_text(todo_path)
            te_next.setPlainText(_extract_next_steps(txt))

        self._tab_defs.append(_Tab("Nächste Schritte", w_next, refresh_next))

    def refresh_all(self) -> None:
        if self._docs:
            self._lbl_path.setText(f"PROJECT_DOCS: {self._docs}")
        else:
            self._lbl_path.setText("PROJECT_DOCS: (nicht gefunden) – starte die App bitte im Projektordner")

        for t in self._tab_defs:
            try:
                t.refresh()
            except Exception:
                pass


def build_workbook_action(parent, on_triggered) -> QAction:
    a = QAction("Arbeitsmappe…", parent)
    a.setShortcut("F1")
    a.triggered.connect(on_triggered)
    return a
