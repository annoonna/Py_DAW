# LATEST

Aktuellste Session: **2026-02-02_SESSION_SCALE_CYAN_DOTS.md** (v0.0.19.5.1.19)

Kurz:
- Bitwig-style cyan dots: erlaubte Skalentöne im **Piano Roll Grid** und im **Keyboard links** markiert.
- UI Toggle: "Scale-Hints (Cyan Dots)" im Scale-Menü (persistiert).
