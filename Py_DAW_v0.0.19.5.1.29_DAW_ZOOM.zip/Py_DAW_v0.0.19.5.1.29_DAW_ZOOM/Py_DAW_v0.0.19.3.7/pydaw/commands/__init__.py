"""Command system (Undo/Redo).

This package provides a lightweight Command Pattern implementation.
It is intentionally UI-agnostic so it can be reused across PianoRoll,
Arranger, Automation, Mixer, etc.
"""

from .undo_stack import Command, UndoStack
from .midi_notes_edit import MidiNotesEditCommand

__all__ = ["Command", "UndoStack", "MidiNotesEditCommand"]
