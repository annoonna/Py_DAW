"""ProjectService (v0.0.15.8 hotfix).

Ziel dieses Hotfix:
- Stabile, konsistente API für die UI (keine AttributeError-Crashes in Qt-Slots)
- Threaded File-IO (Open/Save/Import/Export) via ThreadPoolService.Worker
- Grundlegende Track/Clip-Operationen + PianoRoll/MIDI Notes Datenstruktur
- Clip Launcher Einstellungen + Slot Mapping

Hinweis: Audio-Playback/Recording ist weiterhin Placeholder.
"""

from __future__ import annotations

from pathlib import Path
from datetime import datetime
import contextlib
import math
import wave
import re
from typing import Any, Callable, List, Optional

from PyQt6.QtCore import QObject, pyqtSignal

from pydaw.core.settings import SettingsKeys
from pydaw.core.settings_store import set_value as set_setting

from pydaw.core.threading import ThreadPoolService, Worker
from pydaw.model.project import Track, Clip
from pydaw.model.midi import MidiNote

from pydaw.fileio.file_manager import (
    ProjectContext,
    new_project as fm_new_project,
    open_project as fm_open_project,
    save_project_to as fm_save_project_to,
    import_audio_to_project as fm_import_audio,
    import_midi_to_project as fm_import_midi,
    export_audio_from_file as fm_export_audio,
)

from pydaw.fileio import project_io

from pydaw.fileio.midi_io import import_midi as midi_parse

from pydaw.commands import UndoStack
from pydaw.commands.midi_notes_edit import MidiNotesEditCommand, MidiSnapshot


class ProjectService(QObject):
    status = pyqtSignal(str)
    error = pyqtSignal(str)
    project_updated = pyqtSignal()
    project_changed = pyqtSignal()
    clip_selected = pyqtSignal(str)
    active_clip_changed = pyqtSignal(str)  # backward compatible alias for pianoroll
    undo_changed = pyqtSignal()
    # Fired after a MIDI edit is committed (Undo step created). This allows
    # other services (e.g. audio) to react without the user needing to stop/play.
    midi_notes_committed = pyqtSignal(str)

    def __init__(self, threadpool: ThreadPoolService, parent: QObject | None = None):
        super().__init__(parent)
        self.threadpool = threadpool
        self.ctx: ProjectContext = fm_new_project()
        self._selected_track_id: str = ""
        self._active_clip_id: str = ""
        self.undo_stack = UndoStack(max_depth=400)


    @property
    def active_clip_id(self) -> str:
        """Aktuell ausgewählter Clip (für ClipLauncher/PianoRoll/UI)."""
        if self._active_clip_id:
            return self._active_clip_id
        return str(getattr(self.ctx.project, "selected_clip_id", ""))

    @property
    def selected_track_id(self) -> str:
        """Aktuell ausgewählte Spur (UI)."""
        return self._selected_track_id

    @property
    def active_track_id(self) -> str:
        """Backwards-compat Alias für ältere UI-Teile."""
        return self._selected_track_id


    # ---------- helpers ----------
    def display_name(self) -> str:
        p = self.ctx.path
        return p.name if p else self.ctx.project.name

    def set_track_soundfont(self, track_id: str, sf2_path: str, bank: int = 0, preset: int = 0) -> None:
        """Assign a SoundFont (SF2) to an instrument track (Phase 4)."""
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            self.status.emit("Kein Track ausgewählt")
            return
        if trk.kind not in ("instrument", "bus", "master", "audio"):
            pass
        # Store on track (dataclass fields)
        try:
            trk.sf2_path = str(sf2_path)
            trk.sf2_bank = int(bank)
            trk.sf2_preset = int(preset)
        except Exception:
            trk.sf2_path = str(sf2_path)
        self.status.emit(f"SF2 gesetzt für {trk.name}: {Path(sf2_path).name} (Bank {bank}, Preset {preset})")
        self._emit_updated()

    def _emit_updated(self) -> None:
        self.project_updated.emit()

    def _emit_changed(self) -> None:
        self.project_changed.emit()
        self.project_updated.emit()

    def _submit(self, fn: Callable[[], Any], on_ok: Callable[[Any], None] | None = None, on_err: Callable[[str], None] | None = None) -> None:
        w = Worker(fn)
        if on_ok:
            w.signals.result.connect(on_ok)
        if on_err:
            w.signals.error.connect(on_err)
        self.threadpool.submit(w)

    # ---------- automation playback ----------
    def apply_automation_value(self, track_id: str, param: str, value: float) -> None:
        """Apply an automation value to the live project model.

        This is intentionally lightweight: it updates the in-memory model (Track.volume/Track.pan)
        and notifies the UI via project_updated.

        Audio rendering is still placeholder; when an audio engine exists, it can be hooked here.
        """
        t = next((x for x in self.ctx.project.tracks if x.id == track_id), None)
        if not t:
            return

        if param == "volume":
            t.volume = float(max(0.0, min(1.0, value)))
        elif param == "pan":
            t.pan = float(max(-1.0, min(1.0, value)))
        else:
            return

        # Avoid spamming status; keep it silent.
        self._emit_updated()

    # ---------- project ----------
    def new_project(self, name: str = "Neues Projekt") -> None:
        self.ctx = fm_new_project(name)
        self._selected_track_id = ""
        self.undo_stack.clear()
        self.undo_changed.emit()
        self.status.emit("Neues Projekt erstellt.")
        self._emit_changed()

    def open_project(self, path: Path) -> None:
        def fn():
            return fm_open_project(path)

        def ok(ctx: ProjectContext):
            self.ctx = ctx
            self.undo_stack.clear()
            self.undo_changed.emit()
            try:
                keys = SettingsKeys()
                set_setting(keys.last_project, str(path))
            except Exception:
                pass
            self._selected_track_id = ""
            try:
                keys = SettingsKeys()
                set_setting(keys.last_project, str(path))
            except Exception:
                pass
            self.status.emit(f"Projekt geöffnet: {path}")
            self._emit_changed()

        def err(msg: str):
            self.error.emit(msg)

        self._submit(fn, ok, err)

    def save_project_as(self, path: Path) -> None:
        def fn():
            return fm_save_project_to(path, self.ctx)

        def ok(ctx: ProjectContext):
            self.ctx = ctx
            self.status.emit(f"Projekt gespeichert: {path}")
            self._emit_changed()

        def err(msg: str):
            self.error.emit(msg)

        self._submit(fn, ok, err)

    def save_project(self) -> None:
        """Speichert das Projekt in die aktuelle Projektdatei (falls vorhanden)."""
        if not getattr(self.ctx, "path", None):
            self.error.emit("Projekt ist noch nicht gespeichert. Bitte zuerst 'Speichern unter…' verwenden.")
            return
        self.save_project_as(self.ctx.path)

    def save_snapshot(self, label: str = "") -> None:
        """Erstellt einen Projektstand (Snapshot) in <Projektordner>/stamps/."""
        if not getattr(self.ctx, "path", None):
            self.error.emit("Projekt ist noch nicht gespeichert. Bitte zuerst speichern, dann Snapshot erstellen.")
            return

        def fn():
            root = self.ctx.path.parent
            stamps = root / "stamps"
            stamps.mkdir(parents=True, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe = re.sub(r"[^a-zA-Z0-9._-]+", "_", (label or "snapshot").strip())
            safe = safe.strip("_-") or "snapshot"
            snap_path = stamps / f"{ts}__{safe}.pydaw.json"
            project_io.save_project(snap_path, self.ctx.project)
            return snap_path

        def ok(path: Path):
            self.status.emit(f"Projektstand gespeichert: {path.name}")
            # kein _emit_changed nötig; nur Datei-Operation

        def err(msg: str):
            self.error.emit(msg)

        self._submit(fn, ok, err)

    def load_snapshot(self, snapshot_path: Path) -> None:
        """Lädt einen Snapshot in das aktuelle Projekt (Media-Pfade bleiben unverändert)."""
        if not snapshot_path:
            return

        def fn():
            return project_io.load_project(snapshot_path)

        def ok(project):
            self.ctx.project = project
            self.undo_stack.clear()
            self.undo_changed.emit()
            self.status.emit(f"Projektstand geladen: {snapshot_path.name}")
            self._emit_changed()

        def err(msg: str):
            self.error.emit(msg)

        self._submit(fn, ok, err)

    # ---------- settings ----------
    def set_time_signature(self, ts: str) -> None:
        self.ctx.project.time_signature = str(ts or "4/4")
        self.status.emit(f"Taktart: {self.ctx.project.time_signature}")
        self._emit_updated()

    def set_snap_division(self, div: str) -> None:
        self.ctx.project.snap_division = str(div)
        self._emit_updated()

    # ---------- tracks ----------
    def add_track(self, kind: str) -> None:
        name = {"audio": "Audio Track", "instrument": "Instrument Track", "bus": "Bus", "master": "Master"}.get(kind, "Track")
        trk = Track(kind=kind, name=name)

        # keep master at end
        tracks = [t for t in self.ctx.project.tracks if t.kind != "master"]
        master = next((t for t in self.ctx.project.tracks if t.kind == "master"), None)
        tracks.append(trk)
        if master:
            tracks.append(master)
        self.ctx.project.tracks = tracks

        self._selected_track_id = trk.id
        self.status.emit(f"Spur hinzugefügt: {trk.name}")
        self._emit_updated()

    def ensure_audio_track(self) -> str:
        trk = next((t for t in self.ctx.project.tracks if t.kind == "audio"), None)
        if trk:
            return trk.id
        self.add_track("audio")
        trk = next((t for t in self.ctx.project.tracks if t.kind == "audio"), None)
        return trk.id if trk else ""


    def ensure_instrument_track(self) -> str:
        trk = next((t for t in self.ctx.project.tracks if t.kind == "instrument"), None)
        if trk:
            return trk.id
        self.add_track("instrument")
        trk = next((t for t in self.ctx.project.tracks if t.kind == "instrument"), None)
        return trk.id if trk else ""


    def remove_track(self, track_id: str) -> None:
        if not track_id:
            return
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk or trk.kind == "master":
            return
        self.ctx.project.tracks = [t for t in self.ctx.project.tracks if t.id != track_id]
        # remove clips on that track
        removed = [c.id for c in self.ctx.project.clips if c.track_id == track_id]
        self.ctx.project.clips = [c for c in self.ctx.project.clips if c.track_id != track_id]
        for cid in removed:
            self.ctx.project.midi_notes.pop(cid, None)

        if self._selected_track_id == track_id:
            self._selected_track_id = ""
        self.status.emit(f"Spur entfernt: {trk.name}")
        self._emit_updated()

    # ---------- track state (Mute / Solo / Record Arm) ----------
    def set_track_muted(self, track_id: str, muted: bool) -> None:
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        trk.muted = bool(muted)
        self._emit_updated()

    def set_track_solo(self, track_id: str, solo: bool) -> None:
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        trk.solo = bool(solo)
        self._emit_updated()

    def set_track_record_arm(self, track_id: str, armed: bool) -> None:
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        trk.record_arm = bool(armed)
        self._emit_updated()

    def set_track_input_pair(self, track_id: str, pair: int) -> None:
        """Set stereo input pair (1..N) used for monitoring/recording."""
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk or getattr(trk, "kind", "") == "master":
            return
        try:
            trk.input_pair = max(1, int(pair))
        except Exception:
            trk.input_pair = 1
        self._emit_updated()

    def set_track_output_pair(self, track_id: str, pair: int) -> None:
        """Reserved: stereo output pair (1..N) for future bus/submix routing."""
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk or getattr(trk, "kind", "") == "master":
            return
        try:
            trk.output_pair = max(1, int(pair))
        except Exception:
            trk.output_pair = 1
        self._emit_updated()

    def set_track_monitor(self, track_id: str, enabled: bool) -> None:
        """Enable/disable input monitoring for this track."""
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk or getattr(trk, "kind", "") == "master":
            return
        trk.monitor = bool(enabled)
        self._emit_updated()

    # ---------- clip grouping ----------
    def group_clips(self, clip_ids: List[str]) -> str:
        """Assigns a shared group_id to the given clips.

        Grouping is used by the arranger UI to move multiple clips together.
        """
        ids = [cid for cid in clip_ids if cid]
        if len(ids) < 2:
            return ""
        gid = f"grp_{uuid4().hex[:8]}"
        for c in self.ctx.project.clips:
            if c.id in ids:
                c.group_id = gid
        self.status.emit(f"{len(ids)} Clips gruppiert")
        self._emit_updated()
        return gid

    def ungroup_clips(self, clip_ids: List[str]) -> None:
        ids = [cid for cid in clip_ids if cid]
        if not ids:
            return
        for c in self.ctx.project.clips:
            if c.id in ids:
                c.group_id = ""
        self.status.emit(f"Gruppierung aufgehoben")
        self._emit_updated()

    # ---------- clips ----------
    def select_clip(self, clip_id: str) -> None:
        self.ctx.project.selected_clip_id = str(clip_id)  # dynamic attr for UI
        self._active_clip_id = str(clip_id)
        self.clip_selected.emit(str(clip_id))
        self.active_clip_changed.emit(str(clip_id))
        self._emit_updated()

    def add_placeholder_clip_to_track(self, track_id: str, kind: str = "audio") -> None:
        if not track_id:
            return
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        kind = "midi" if trk.kind == "instrument" else "audio"
        clip = Clip(kind='audio', track_id=track_id, label=f"{kind.upper()} Clip")
        self.ctx.project.clips.append(clip)
        if kind == "midi":
            self.ctx.project.midi_notes[clip.id] = []
        self.status.emit(f"Clip hinzugefügt: {clip.label}")
        self.select_clip(clip.id)
        self._emit_updated()

    def delete_clip(self, clip_id: str) -> None:
        self.ctx.project.clips = [c for c in self.ctx.project.clips if c.id != clip_id]
        self.ctx.project.midi_notes.pop(clip_id, None)
        # remove from launcher slots
        self.ctx.project.clip_launcher = {k: v for k, v in self.ctx.project.clip_launcher.items() if v != clip_id}
        if getattr(self.ctx.project, "selected_clip_id", "") == clip_id:
            self.select_clip("")
        self.status.emit("Clip gelöscht.")
        self._emit_updated()

    def rename_clip(self, clip_id: str, name: str) -> None:
        c = next((c for c in self.ctx.project.clips if c.id == clip_id), None)
        if not c:
            return
        c.label = str(name)
        self._emit_updated()

    def duplicate_clip(self, clip_id: str) -> None:
        c = next((c for c in self.ctx.project.clips if c.id == clip_id), None)
        if not c:
            return
        dup = Clip(kind=c.kind, track_id=c.track_id, start_beats=c.start_beats + c.length_beats, length_beats=c.length_beats, label=c.label + " Copy", media_id=c.media_id, source_path=c.source_path)
        self.ctx.project.clips.append(dup)
        if dup.kind == "midi":
            self.ctx.project.midi_notes[dup.id] = [MidiNote(**n.__dict__).clamp() for n in self.ctx.project.midi_notes.get(c.id, [])]
        self.select_clip(dup.id)
        self._emit_updated()

    def move_clip(self, clip_id: str, start_beats: float, snap_beats: float | None = None) -> None:
        c = next((c for c in self.ctx.project.clips if c.id == clip_id), None)
        if not c:
            return
        val = max(0.0, float(start_beats))
        if snap_beats and float(snap_beats) > 0:
            g = float(snap_beats)
            val = round(val / g) * g
        c.start_beats = max(0.0, val)
        self._emit_updated()

    def resize_clip(self, clip_id: str, length_beats: float, snap_beats: float | None = None) -> None:
        c = next((c for c in self.ctx.project.clips if c.id == clip_id), None)
        if not c:
            return
        val = max(0.25, float(length_beats))
        if snap_beats and float(snap_beats) > 0:
            g = float(snap_beats)
            val = max(g, round(val / g) * g)
        c.length_beats = max(0.25, val)
        self._emit_updated()


    def trim_clip_left(
        self,
        clip_id: str,
        start_beats: float,
        length_beats: float,
        offset_beats: float = 0.0,
        offset_seconds: float = 0.0,
        snap_beats: float | None = None,
    ) -> None:
        """Trim/extend the *left* edge of a clip."""
        c = next((c for c in self.ctx.project.clips if c.id == str(clip_id)), None)
        if not c:
            return

        st = max(0.0, float(start_beats))
        ln = max(0.25, float(length_beats))

        if snap_beats and float(snap_beats) > 0:
            g = float(snap_beats)
            st = max(0.0, round(st / g) * g)
            ln = max(g, round(ln / g) * g)

        c.start_beats = st
        c.length_beats = ln
        c.offset_beats = max(0.0, float(offset_beats))
        c.offset_seconds = max(0.0, float(offset_seconds))

        self._emit_updated()

    def move_clip_track(self, clip_id: str, track_id: str) -> None:
        c = next((c for c in self.ctx.project.clips if c.id == clip_id), None)
        if not c:
            return
        c.track_id = str(track_id)
        self._emit_updated()

    # ---------- track editing ----------
    def set_track_kind(self, track_id: str, kind: str) -> None:
        """Change track kind (e.g. audio -> instrument) in a project-safe way."""
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        k = str(kind or "audio")
        if getattr(trk, "kind", "audio") == k:
            return
        trk.kind = k
        self._emit_updated()


    # ---------- clip creation (non-placeholder) ----------
    def add_midi_clip_at(self, track_id: str, start_beats: float, length_beats: float = 4.0, label: str = "MIDI Clip") -> str:
        """Create a real MIDI clip (notes editable in PianoRoll) on an instrument track."""
        if not track_id:
            track_id = self.ensure_instrument_track()
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        # If the user draws a MIDI clip on a non-instrument track in the arranger,
        # we convert that track to an instrument track instead of silently creating
        # the clip elsewhere (which looks like "nothing happened" in the UI).
        if trk and getattr(trk, "kind", "audio") != "instrument":
            old_kind = str(getattr(trk, "kind", "audio"))
            trk.kind = "instrument"
            if old_kind == "audio":
                if str(getattr(trk, "name", "")).strip().lower().startswith("audio"):
                    trk.name = "Instrument Track"
        if not trk:
            track_id = self.ensure_instrument_track()
        clip = Clip(kind="midi", track_id=track_id, start_beats=float(start_beats), length_beats=max(0.25, float(length_beats)), label=str(label))
        self.ctx.project.clips.append(clip)
        self.ctx.project.midi_notes.setdefault(clip.id, [])
        self.select_clip(clip.id)
        self.status.emit(f"MIDI-Clip erstellt: {clip.label}")
        self._emit_updated()
        return clip.id

    def _audio_duration_seconds(self, path: Path) -> float:
        """Best-effort duration for common formats. WAV is exact; others optional."""
        p = Path(path)
        try:
            if p.suffix.lower() in (".wav", ".wave"):
                with contextlib.closing(wave.open(str(p), "rb")) as wf:
                    frames = wf.getnframes()
                    rate = wf.getframerate() or 48000
                    return float(frames) / float(rate)
        except Exception:
            pass
        # Optional: pydub (requires ffmpeg for mp3/aac/ogg)
        try:
            from pydub import AudioSegment  # type: ignore
            seg = AudioSegment.from_file(str(p))
            return float(len(seg)) / 1000.0
        except Exception:
            return 0.0


    def add_audio_clip_placeholder_at(self, track_id: str, start_beats: float = 0.0, length_beats: float = 4.0, label: str = "Audio Clip") -> str:
        """Create an empty/placeholder audio clip (no media yet).

        Useful for DAW workflow: Region first, content later (record/import).
        """
        tid = track_id or self.ensure_audio_track()
        clip = Clip(kind="audio", track_id=str(tid), start_beats=max(0.0, float(start_beats)), length_beats=max(0.25, float(length_beats)), label=str(label))
        # Keep source_path/media_id None -> waveform preview shows placeholder text.
        self.ctx.project.clips.append(clip)
        self.select_clip(clip.id)
        self.status.emit(f"Audio-Clip (Platzhalter) erstellt: {clip.label}")
        self._emit_updated()
        return clip.id

    def add_audio_clip_from_file_at(self, track_id: str, path: Path, start_beats: float = 0.0) -> Optional[str]:
        """Import audio into project media and create an audio clip at a specific position."""
        p = Path(path)
        if not p.exists():
            self.error.emit("Audio-Datei nicht gefunden.")
            return None

        def fn():
            return fm_import_audio(p, self.ctx)

        def ok(item):
            try:
                tid = track_id or self.ensure_audio_track()
                project_bpm = float(self.ctx.project.bpm or 120.0)
                secs = self._audio_duration_seconds(Path(item.path))

                # Phase 3: basic sync by detecting a source BPM from the file name.
                # Examples: "loop_150bpm.wav", "Kick (110 BPM).wav"
                source_bpm: Optional[float] = None
                m = re.search(r"(\d+(?:\.\d+)?)\s*bpm", (p.stem or ""), flags=re.IGNORECASE)
                if m:
                    try:
                        source_bpm = float(m.group(1))
                    except Exception:
                        source_bpm = None

                # If we know the source BPM, we compute the clip length in *beats of the source*,
                # so it will align to the grid after time-stretch.
                if secs > 0:
                    if source_bpm:
                        beats = secs * source_bpm / 60.0
                    else:
                        beats = secs * project_bpm / 60.0
                else:
                    beats = 4.0

                clip = Clip(kind="audio", track_id=tid, label=item.label or p.stem, media_id=item.id, source_path=str(Path(item.path)), source_bpm=source_bpm)
                clip.start_beats = max(0.0, float(start_beats))
                clip.length_beats = max(0.25, float(beats))
                self.ctx.project.clips.append(clip)
                self.select_clip(clip.id)
                self.status.emit(f"Audio-Clip erstellt: {clip.label}")
                self._emit_updated()
            except Exception as e:
                self.error.emit(f"Audio-Clip Fehler: {e}")

        def err(msg: str):
            self.error.emit(f"Audio import fehlgeschlagen: {msg}")

        self._submit(fn, ok, err)
        return None

    def import_midi_to_track_at(self, path: Path, track_id: str, start_beats: float = 0.0, length_beats: float = 4.0) -> str:
        """Imports a MIDI file as a new MIDI clip at the given position.

        Phase 2: real parsing (note-on/note-off) into MidiNote events.
        We map MIDI tick-time into *beats* using ticks_per_beat. Tempo changes affect seconds,
        but the grid in the arranger is beat-based, so this mapping is stable.
        """
        p = Path(path)
        if not p.exists():
            self.error.emit("MIDI-Datei nicht gefunden.")
            return ""

        try:
            import mido  # type: ignore
        except Exception:
            self.error.emit("MIDI Import: Abhängigkeit 'mido' fehlt (pip install -r requirements.txt).")
            return ""

        mf = mido.MidiFile(str(p))
        tpb = float(mf.ticks_per_beat or 480)

        # Merge all tracks into one time-ordered stream.
        abs_tick = 0
        active: dict[tuple[int, int], tuple[int, int]] = {}  # (channel,pitch) -> (start_tick, velocity)
        notes: list[MidiNote] = []

        for msg in mido.merge_tracks(mf.tracks):
            abs_tick += int(getattr(msg, "time", 0) or 0)
            if msg.type == "note_on" and int(getattr(msg, "velocity", 0) or 0) > 0:
                key = (int(getattr(msg, "channel", 0) or 0), int(getattr(msg, "note", 0) or 0))
                active[key] = (abs_tick, int(getattr(msg, "velocity", 0) or 0))
            elif msg.type in ("note_off", "note_on"):
                # note_on with velocity 0 is note_off
                vel = int(getattr(msg, "velocity", 0) or 0)
                if msg.type == "note_on" and vel != 0:
                    continue
                key = (int(getattr(msg, "channel", 0) or 0), int(getattr(msg, "note", 0) or 0))
                if key in active:
                    start_tick, start_vel = active.pop(key)
                    end_tick = abs_tick
                    if end_tick <= start_tick:
                        continue
                    start_b = float(start_tick) / tpb
                    len_b = float(end_tick - start_tick) / tpb
                    notes.append(MidiNote(pitch=key[1], start_beats=start_b + float(start_beats), length_beats=max(0.05, len_b), velocity=start_vel))

        # Compute clip length from notes if available.
        max_end = max((n.start_beats + n.length_beats for n in notes), default=float(start_beats) + float(length_beats))
        clip_len = max(float(length_beats), max_end - float(start_beats))
        clip_len = max(0.25, clip_len)

        clip_id = self.add_midi_clip_at(track_id, start_beats=start_beats, length_beats=clip_len, label=p.stem or "MIDI")
        self.ctx.project.midi_notes[clip_id] = notes
        self.status.emit(f"MIDI importiert: {p.name} ({len(notes)} Noten)")
        self._emit_updated()
        return clip_id

    def import_midi(self, path: Any, track_id: Optional[str] = None, start_beats: float = 0.0) -> str:
        """Import a MIDI file and place it into an instrument track.

        UI-friendly entry point.
        - If `track_id` is given and is an instrument track, it is used.
        - Otherwise the current active track is used if it is an instrument track.
        - Otherwise a new instrument track is created.
        """
        p = Path(str(path))

        # Prefer explicit target track
        tid = track_id or self.active_track_id
        if tid:
            trk = next((t for t in self.ctx.project.tracks if t.id == tid), None)
            if not trk or trk.kind != 'instrument':
                tid = ''

        if not tid:
            tid = self.add_track(kind='instrument', name='Instrument Track').id
            self.set_active_track(tid)

        return self.import_midi_to_track_at(p, track_id=tid, start_beats=float(start_beats), length_beats=16.0)

    # --- Track controls (Phase 2: UI toggles) ---
    def toggle_track_mute(self, track_id: str) -> None:
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        trk.muted = not bool(trk.muted)
        self.status.emit(f"Mute: {trk.name} = {trk.muted}")
        self._emit_updated()

    def toggle_track_solo(self, track_id: str) -> None:
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        trk.solo = not bool(trk.solo)
        self.status.emit(f"Solo: {trk.name} = {trk.solo}")
        self._emit_updated()

    def toggle_track_arm(self, track_id: str) -> None:
        trk = next((t for t in self.ctx.project.tracks if t.id == track_id), None)
        if not trk:
            return
        trk.record_arm = not bool(getattr(trk, "record_arm", False))
        self.status.emit(f"Rec-Arm: {trk.name} = {trk.record_arm}")
        self._emit_updated()

    # --- Clip grouping (Phase 2) ---
    def group_clips(self, clip_ids: List[str]) -> str:
        ids = [cid for cid in clip_ids if cid]
        if len(ids) < 2:
            return ""
        gid = f"grp_{uuid.uuid4().hex[:8]}"
        for c in self.ctx.project.clips:
            if c.id in ids:
                c.group_id = gid
        self.status.emit(f"Gruppe erstellt: {gid} ({len(ids)} Clips)")
        self._emit_updated()
        return gid

    def ungroup_clips(self, clip_ids: List[str]) -> None:
        ids = [cid for cid in clip_ids if cid]
        for c in self.ctx.project.clips:
            if c.id in ids:
                c.group_id = ""
        self.status.emit("Gruppe aufgelöst")
        self._emit_updated()

    # ---------- audio import/export (UI compatibility) ----------
    def import_audio(self, path: Path) -> str:
        """Imports audio into the active/first audio track (legacy UI entry point).

        Note: audio import is threaded; the created clip is committed asynchronously.
        This function returns an empty string for compatibility.
        """
        tid = self.active_track_id
        if not tid:
            tid = next((t.id for t in self.ctx.project.tracks if t.kind == 'audio'), '')
        if not tid:
            tid = self.ensure_audio_track()
        try:
            self.add_audio_clip_from_file_at(tid, Path(path), start_beats=0.0)
        except Exception as e:
            self.error.emit(f"Audio import fehlgeschlagen: {e}")
        return ''

    def import_audio_to_track_at(self, path: Path, track_id: str, start_beats: float = 0.0, length_beats: float = 4.0) -> str:
        """Legacy signature: import an audio file and place it at the given position.

        `length_beats` is ignored because the clip length is derived from the file duration.
        Import is threaded; this returns an empty string for compatibility.
        """
        try:
            self.add_audio_clip_from_file_at(str(track_id), Path(path), start_beats=float(start_beats))
        except Exception as e:
            self.error.emit(f"Audio import fehlgeschlagen: {e}")
        return ''

    
    # ---------- Undo / Redo (Command Pattern) ----------
    def snapshot_midi_notes(self, clip_id: str) -> MidiSnapshot:
        """Create a lightweight snapshot of a clip's MIDI notes."""
        snap: MidiSnapshot = []
        notes = self.ctx.project.midi_notes.get(str(clip_id), []) or []
        for n in notes:
            try:
                snap.append(
                    {
                        "pitch": int(getattr(n, "pitch", 60)),
                        "start_beats": float(getattr(n, "start_beats", 0.0)),
                        "length_beats": float(getattr(n, "length_beats", 1.0)),
                        "velocity": int(getattr(n, "velocity", 100)),
                    }
                )
            except Exception:
                continue
        return snap

    def _apply_midi_snapshot(self, clip_id: str, snap: MidiSnapshot) -> None:
        from pydaw.model.midi import MidiNote
        notes = []
        for d in (snap or []):
            try:
                notes.append(
                    MidiNote(
                        pitch=int(d.get("pitch", 60)),
                        start_beats=float(d.get("start_beats", 0.0)),
                        length_beats=float(d.get("length_beats", 1.0)),
                        velocity=int(d.get("velocity", 100)),
                    ).clamp()
                )
            except Exception:
                continue
        self.set_midi_notes(str(clip_id), notes)

    def commit_midi_notes_edit(self, clip_id: str, before: MidiSnapshot, label: str) -> None:
        """Register an undo step for edits already applied to the model."""
        after = self.snapshot_midi_notes(str(clip_id))
        if before == after:
            return
        cmd = MidiNotesEditCommand(
            clip_id=str(clip_id),
            before=list(before or []),
            after=list(after or []),
            label=str(label or "Edit MIDI"),
            apply_snapshot=self._apply_midi_snapshot,
        )
        self.undo_stack.push(cmd, already_done=True)
        self.undo_changed.emit()
        # Ensure UI/services observe the final state.
        try:
            self._emit_updated()
        except Exception:
            pass
        try:
            self.midi_notes_committed.emit(str(clip_id))
        except Exception:
            pass

    def can_undo(self) -> bool:
        return self.undo_stack.can_undo()

    def can_redo(self) -> bool:
        return self.undo_stack.can_redo()

    def undo_label(self) -> str:
        return self.undo_stack.undo_label()

    def redo_label(self) -> str:
        return self.undo_stack.redo_label()

    def undo(self) -> None:
        if not self.undo_stack.can_undo():
            return
        self.undo_stack.undo()
        self.undo_changed.emit()

    def redo(self) -> None:
        if not self.undo_stack.can_redo():
            return
        self.undo_stack.redo()
        self.undo_changed.emit()


    # ---------- MIDI notes backing store (Piano Roll) ----------
    def get_midi_notes(self, clip_id: str):
        return list(self.ctx.project.midi_notes.get(clip_id, []))

    def set_midi_notes(self, clip_id: str, notes):
        self.ctx.project.midi_notes[clip_id] = list(notes)
        # Auto-extend to cover farthest note end
        try:
            nl = self.ctx.project.midi_notes.get(str(clip_id), []) or []
            if nl:
                end_b = max(float(getattr(n, 'start_beats', 0.0)) + float(getattr(n, 'length_beats', 0.0)) for n in nl)
                if self.extend_clip_if_needed(str(clip_id), float(end_b), snap_to_bar=True):
                    return
        except Exception:
            pass
        self._emit_updated()

    def add_midi_note(
        self,
        clip_id: str,
        note=None,
        *,
        pitch: int | None = None,
        start_beats: float | None = None,
        length_beats: float | None = None,
        velocity: int = 100,
    ):
        """Add a MIDI note to a clip.

        The UI calls this in two variants:
        - add_midi_note(clip_id, MidiNote(...))
        - add_midi_note(clip_id, pitch=..., start_beats=..., length_beats=...)
        """
        from pydaw.model.midi import MidiNote

        if note is None:
            if pitch is None or start_beats is None or length_beats is None:
                return
            note = MidiNote(
                pitch=int(pitch),
                start_beats=float(start_beats),
                length_beats=float(length_beats),
                velocity=int(velocity),
            )
        elif isinstance(note, dict):
            # Convenience: accept dict-like notes
            note = MidiNote(
                pitch=int(note.get("pitch", 60)),
                start_beats=float(note.get("start_beats", 0.0)),
                length_beats=float(note.get("length_beats", 1.0)),
                velocity=int(note.get("velocity", 100)),
            )

        notes = self.ctx.project.midi_notes.setdefault(clip_id, [])
        notes.append(note)
        try:
            end_b = float(getattr(note, 'start_beats', 0.0)) + float(getattr(note, 'length_beats', 0.0))
            if self.extend_clip_if_needed(str(clip_id), float(end_b), snap_to_bar=True):
                return
        except Exception:
            pass
        self._emit_updated()

    def delete_midi_note_at(self, clip_id: str, idx_or_pitch: int, start_beats: float | None = None):
        """Delete a MIDI note.

        Supported call variants (for UI compatibility):
        - delete_midi_note_at(clip_id, idx)
        - delete_midi_note_at(clip_id, pitch, start_beats)
        """
        notes = self.ctx.project.midi_notes.get(clip_id, [])
        if start_beats is None:
            # Treat 2nd arg as index
            idx = int(idx_or_pitch)
            if 0 <= idx < len(notes):
                notes.pop(idx)
                self._emit_updated()
            return

        # Treat 2nd/3rd arg as (pitch, start_beats)
        pitch = int(idx_or_pitch)
        sb = float(start_beats)
        for i, n in enumerate(list(notes)):
            try:
                if int(getattr(n, "pitch", -1)) == pitch and abs(float(getattr(n, "start_beats", -999)) - sb) < 1e-6:
                    notes.pop(i)
                    self._emit_updated()
                    return
            except Exception:
                continue

    def move_midi_note(self, clip_id: str, idx: int, new_start: float, new_pitch: int):
        notes = self.ctx.project.midi_notes.get(clip_id, [])
        if 0 <= idx < len(notes):
            n = notes[idx]
            try:
                n.start_beats = max(0.0, float(new_start))
                n.pitch = int(new_pitch)
            except Exception:
                pass
            try:
                end_b = float(getattr(n, 'start_beats', 0.0)) + float(getattr(n, 'length_beats', 0.0))
                if self.extend_clip_if_needed(str(clip_id), float(end_b), snap_to_bar=True):
                    return
            except Exception:
                pass
            self._emit_updated()

    def move_midi_notes_batch(self, clip_id: str, updates: list[tuple[int, float, int]]) -> None:
        """Move multiple MIDI notes and emit a single project_updated.

        This is used for multi-selection dragging in the PianoRoll to avoid
        excessive signal emissions while the mouse is moving.

        Args:
            clip_id: MIDI clip id
            updates: list of (idx, new_start_beats, new_pitch)
        """
        notes = self.ctx.project.midi_notes.get(clip_id, [])
        changed = False
        for idx, new_start, new_pitch in updates:
            try:
                i = int(idx)
            except Exception:
                continue
            if not (0 <= i < len(notes)):
                continue
            n = notes[i]
            try:
                n.start_beats = max(0.0, float(new_start))
                n.pitch = int(new_pitch)
                changed = True
            except Exception:
                continue
        if changed:
            try:
                max_end = 0.0
                for n in notes:
                    try:
                        max_end = max(max_end, float(getattr(n, 'start_beats', 0.0)) + float(getattr(n, 'length_beats', 0.0)))
                    except Exception:
                        continue
                if max_end > 0 and self.extend_clip_if_needed(str(clip_id), float(max_end), snap_to_bar=True):
                    return
            except Exception:
                pass
            self._emit_updated()

    def resize_midi_note_length(self, clip_id: str, idx: int, new_length: float):
        notes = self.ctx.project.midi_notes.get(clip_id, [])
        if 0 <= idx < len(notes):
            n = notes[idx]
            try:
                n.length_beats = max(0.25, float(new_length))
            except Exception:
                pass
            try:
                end_b = float(getattr(n, 'start_beats', 0.0)) + float(getattr(n, 'length_beats', 0.0))
                if self.extend_clip_if_needed(str(clip_id), float(end_b), snap_to_bar=True):
                    return
            except Exception:
                pass
            self._emit_updated()


    # ---------- MIDI clip length helpers ----------
    def _beats_per_bar(self) -> float:
        """Return the current bar length in beats based on the project's time signature.

        Beats are quarter-note beats (i.e. 4/4 => 4.0 beats per bar).
        """
        ts = str(getattr(self.ctx.project, 'time_signature', '4/4') or '4/4')
        m = re.match(r'^\s*(\d+)\s*/\s*(\d+)\s*$', ts)
        if not m:
            return 4.0
        try:
            num = float(m.group(1))
            den = float(m.group(2))
            if den <= 0:
                return 4.0
            # Whole note = 4 beats (quarter-note beats)
            return max(0.25, float(num) * (4.0 / float(den)))
        except Exception:
            return 4.0

    def _snap_division_beats(self) -> float:
        """Convert project snap division to beats.

        Examples:
            '1/16' -> 0.25 beats
            '1/8'  -> 0.5 beats
            '1/4'  -> 1.0 beat
            '1 Bar' -> beats_per_bar
            '1 Beat' -> 1.0
        """
        div = str(getattr(self.ctx.project, 'snap_division', '1/16') or '1/16')
        d = div.strip().lower()
        if 'bar' in d:
            return float(self._beats_per_bar())
        if 'beat' in d:
            return 1.0
        m = re.match(r'^\s*1\s*/\s*(\d+)\s*$', div)
        if m:
            try:
                den = float(m.group(1))
                if den > 0:
                    return max(1.0 / 64.0, 4.0 / den)
            except Exception:
                pass
        # fallback: 1/16
        return 0.25

    def extend_clip_if_needed(self, clip_id: str, end_beats: float, *, snap_to_bar: bool = True) -> bool:
        """Auto-extend a MIDI clip if note content exceeds its current end.

        This is the canonical implementation for Task 9.

        Args:
            clip_id: target clip id
            end_beats: clip-local end position of content (start+length)
            snap_to_bar: if True, extend to the next full bar.

        Returns:
            True if the clip length changed.
        """
        try:
            cid = str(clip_id)
            end_b = max(0.0, float(end_beats))
        except Exception:
            return False

        clip = next((c for c in self.ctx.project.clips if str(getattr(c, 'id', '')) == cid), None)
        if not clip:
            return False
        if str(getattr(clip, 'kind', '')) != 'midi':
            return False

        try:
            cur_len = float(getattr(clip, 'length_beats', 4.0) or 0.0)
        except Exception:
            cur_len = 4.0

        if end_b <= cur_len + 1e-9:
            return False

        if snap_to_bar:
            bar = float(self._beats_per_bar())
            bar = max(1.0 / 64.0, bar)
            new_len = math.ceil(end_b / bar) * bar
        else:
            g = float(self._snap_division_beats())
            g = max(1.0 / 64.0, g)
            new_len = math.ceil(end_b / g) * g

        try:
            clip.length_beats = float(max(cur_len, new_len))
        except Exception:
            return False

        self._emit_updated()
        return True

    def ensure_midi_clip_length(self, clip_id: str, end_beats: float) -> None:
        """Backward compatible alias for older UI code."""
        try:
            self.extend_clip_if_needed(str(clip_id), float(end_beats), snap_to_bar=True)
        except Exception:
            return

    # ---------------------------------------------------------------------
    # UI compatibility API (Undo/Redo) - required by main_window.py
    # ---------------------------------------------------------------------
    def can_undo(self) -> bool:
        """Prüfe ob Undo möglich ist."""
        try:
            return bool(self.undo_stack.can_undo())
        except Exception:
            return False

    def can_redo(self) -> bool:
        """Prüfe ob Redo möglich ist."""
        try:
            return bool(self.undo_stack.can_redo())
        except Exception:
            return False

    def undo_label(self) -> str:
        """Hole Undo-Label."""
        try:
            return self.undo_stack.undo_label() or "Undo"
        except Exception:
            return "Undo"

    def redo_label(self) -> str:
        """Hole Redo-Label."""
        try:
            return self.undo_stack.redo_label() or "Redo"
        except Exception:
            return "Redo"

    def undo(self):
        """Führe Undo aus."""
        try:
            self.undo_stack.undo()
            self._emit_updated()
        except Exception as e:
            print(f"Undo failed: {e}")

    def redo(self):
        """Führe Redo aus."""
        try:
            self.undo_stack.redo()
            self._emit_updated()
        except Exception as e:
            print(f"Redo failed: {e}")
