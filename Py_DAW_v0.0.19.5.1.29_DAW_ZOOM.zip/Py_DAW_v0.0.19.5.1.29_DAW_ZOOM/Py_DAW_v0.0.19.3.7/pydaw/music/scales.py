from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import json

NOTE_NAMES = ["C","C#","D","Eb","E","F","F#","G","Ab","A","Bb","B"]

def note_to_pc(name: str) -> int:
    s = str(name).strip()
    if not s:
        return 0
    # normalize flats
    mapping = {"Db":"C#","D#":"Eb","Gb":"F#","G#":"Ab","A#":"Bb"}
    s = mapping.get(s, s)
    if s in NOTE_NAMES:
        return NOTE_NAMES.index(s)
    # allow lowercase
    s2 = s[0].upper() + s[1:]
    if s2 in NOTE_NAMES:
        return NOTE_NAMES.index(s2)
    return 0

@dataclass(frozen=True)
class ScaleDef:
    id: str
    name: str
    intervals: Tuple[int, ...]
    category_id: str
    category_name: str

    def pitch_classes(self, root_pc: int) -> Set[int]:
        r = int(root_pc) % 12
        return { (r + int(i)) % 12 for i in self.intervals }

def _default_scales_json_path() -> Path:
    # .../pydaw/music/scales.py -> .../pydaw/data/scales/scales.json
    return Path(__file__).resolve().parent.parent / "data" / "scales" / "scales.json"

class ScaleDB:
    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else _default_scales_json_path()
        self._by_id: Dict[str, ScaleDef] = {}
        self._cats: List[Tuple[str,str,List[str]]] = []  # (cat_id, cat_name, scale_ids)
        self._loaded = False

    def load(self) -> None:
        if self._loaded:
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            data = {"categories": []}
        cats = []
        by_id = {}
        for cat in data.get("categories", []):
            cid = str(cat.get("id","")).strip() or "misc"
            cname = str(cat.get("name","Misc")).strip() or "Misc"
            ids = []
            for sc in cat.get("scales", []):
                sid = str(sc.get("id","")).strip()
                sname = str(sc.get("name",sid)).strip() or sid
                intervals = tuple(int(x) % 12 for x in (sc.get("intervals") or []))
                if not sid or not intervals:
                    continue
                if sid in by_id:
                    # keep first
                    continue
                by_id[sid] = ScaleDef(id=sid, name=sname, intervals=intervals, category_id=cid, category_name=cname)
                ids.append(sid)
            if ids:
                cats.append((cid, cname, ids))
        # Always ensure "major" exists
        if "major" not in by_id:
            by_id["major"] = ScaleDef(id="major", name="Major (Ionian)", intervals=(0,2,4,5,7,9,11), category_id="basic", category_name="Basic (12-TET)")
            cats.insert(0, ("basic","Basic (12-TET)", ["major"]))
        self._by_id = by_id
        self._cats = cats
        self._loaded = True

    def categories(self) -> List[Tuple[str,str,List[ScaleDef]]]:
        self.load()
        out=[]
        for cid,cname,ids in self._cats:
            out.append((cid,cname,[self._by_id[i] for i in ids if i in self._by_id]))
        return out

    def get(self, scale_id: str) -> Optional[ScaleDef]:
        self.load()
        return self._by_id.get(str(scale_id))

    def all(self) -> List[ScaleDef]:
        self.load()
        return list(self._by_id.values())

_GLOBAL_DB: Optional[ScaleDB] = None

def get_scale_db() -> ScaleDB:
    global _GLOBAL_DB
    if _GLOBAL_DB is None:
        _GLOBAL_DB = ScaleDB()
    return _GLOBAL_DB

def nearest_allowed_pitch(pitch: int, allowed_pcs: Set[int]) -> int:
    """Return nearest MIDI pitch whose pitch class is allowed.
    If already allowed, returns pitch.
    Ties: prefer upward.
    """
    p = int(pitch)
    if (p % 12) in allowed_pcs:
        return p
    # search within +/- 12 semitones
    best = p
    best_dist = 999
    for dist in range(1, 13):
        up = p + dist
        dn = p - dist
        if (up % 12) in allowed_pcs:
            best = up
            best_dist = dist
            break
        if (dn % 12) in allowed_pcs:
            best = dn
            best_dist = dist
            break
    return best
