"""Centralized QAction creation (v0.0.7)."""

from __future__ import annotations

from dataclasses import dataclass

from PyQt6.QtGui import QAction, QKeySequence
from PyQt6.QtCore import QObject


@dataclass
class AppActions:
    # File
    file_new: QAction
    file_open: QAction
    file_save: QAction
    file_save_as: QAction
    file_import_audio: QAction
    file_import_midi: QAction
    file_export: QAction
    file_exit: QAction

    # Edit
    edit_undo: QAction
    edit_redo: QAction
    edit_cut: QAction
    edit_copy: QAction
    edit_paste: QAction
    edit_select_all: QAction

    # View
    view_dummy: QAction
    view_toggle_pianoroll: QAction
    view_toggle_notation: QAction
    view_toggle_cliplauncher: QAction
    view_toggle_automation: QAction

    # Project / Tracks
    project_add_audio_track: QAction
    project_add_instrument_track: QAction
    project_add_bus_track: QAction
    project_add_placeholder_clip: QAction
    project_remove_selected_track: QAction
    project_time_signature: QAction
    project_settings: QAction

    project_save_snapshot: QAction
    project_load_snapshot: QAction

    project_load_sf2: QAction
    # Audio
    audio_settings: QAction
    midi_settings: QAction
    midi_mapping: QAction


def build_actions(parent: QObject) -> AppActions:
    # File
    a_new = QAction("Neu", parent)
    a_new.setShortcut(QKeySequence.StandardKey.New)

    a_open = QAction("Öffnen…", parent)
    a_open.setShortcut(QKeySequence.StandardKey.Open)

    a_save = QAction("Speichern", parent)
    a_save.setShortcut(QKeySequence.StandardKey.Save)

    a_save_as = QAction("Speichern unter…", parent)
    a_save_as.setShortcut(QKeySequence.StandardKey.SaveAs)

    a_imp_a = QAction("Audio importieren…", parent)
    a_imp_m = QAction("MIDI importieren…", parent)

    a_export = QAction("Exportieren…", parent)
    a_exit = QAction("Beenden", parent)
    a_exit.setShortcut(QKeySequence.StandardKey.Quit)

    # Edit
    a_undo = QAction("Rückgängig", parent)
    a_undo.setShortcut(QKeySequence.StandardKey.Undo)

    a_redo = QAction("Wiederholen", parent)
    # Bitwig-style: both Ctrl+Shift+Z and Ctrl+Y.
    a_redo.setShortcuts([QKeySequence("Ctrl+Shift+Z"), QKeySequence("Ctrl+Y")])

    a_cut = QAction("Ausschneiden", parent)
    a_cut.setShortcut(QKeySequence.StandardKey.Cut)

    a_copy = QAction("Kopieren", parent)
    a_copy.setShortcut(QKeySequence.StandardKey.Copy)

    a_paste = QAction("Einfügen", parent)
    a_paste.setShortcut(QKeySequence.StandardKey.Paste)

    a_sel_all = QAction("Alles auswählen", parent)
    a_sel_all.setShortcut(QKeySequence.StandardKey.SelectAll)

    # View
    a_view = QAction("Ansicht (Platzhalter)", parent)

    a_toggle_pr = QAction("Piano Roll", parent)
    a_toggle_pr.setCheckable(True)

    a_toggle_notation = QAction("Notation (WIP)", parent)
    a_toggle_notation.setCheckable(True)

    a_toggle_cl = QAction("Clip Launcher", parent)
    a_toggle_cl.setCheckable(True)

    a_toggle_auto = QAction("Automation Lanes", parent)
    a_toggle_auto.setCheckable(True)
    a_toggle_auto.setShortcut(QKeySequence("Ctrl+Shift+A"))

    # Project / Tracks
    a_add_audio = QAction("Audio-Track hinzufügen", parent)
    a_add_inst = QAction("Instrument-Track hinzufügen", parent)
    a_add_bus = QAction("Bus/Master-Track hinzufügen", parent)

    a_add_clip = QAction("Clip hinzufügen (Platzhalter)", parent)
    a_rm_track = QAction("Ausgewählten Track entfernen", parent)

    a_time_sig = QAction("Taktart…", parent)
    a_time_sig.setShortcut(QKeySequence("Ctrl+T"))

    a_proj_settings = QAction("Project Settings…", parent)
    a_load_sf2 = QAction("SoundFont (SF2) laden…", parent, triggered=parent.load_sf2_for_selected_track)
    a_proj_settings.setShortcut(QKeySequence("Ctrl+P"))

    a_snap_save = QAction("Projektstand speichern…", parent)
    a_snap_save.setShortcut(QKeySequence("Ctrl+Alt+S"))

    a_snap_load = QAction("Projektstand laden…", parent)
    a_snap_load.setShortcut(QKeySequence("Ctrl+Alt+L"))

    # Audio
    a_audio = QAction("Audio-Einstellungen…", parent)
    a_midi_settings = QAction("MIDI Settings…", parent)
    a_midi_settings.setShortcut(QKeySequence("Ctrl+M"))

    a_midi_mapping = QAction("MIDI Mapping…", parent)
    a_midi_mapping.setShortcut(QKeySequence("Ctrl+K"))

    return AppActions(
        file_new=a_new,
        file_open=a_open,
        file_save=a_save,
        file_save_as=a_save_as,
        file_import_audio=a_imp_a,
        file_import_midi=a_imp_m,
        file_export=a_export,
        file_exit=a_exit,
        edit_undo=a_undo,
        edit_redo=a_redo,
        edit_cut=a_cut,
        edit_copy=a_copy,
        edit_paste=a_paste,
        edit_select_all=a_sel_all,
        view_dummy=a_view,
        view_toggle_pianoroll=a_toggle_pr,
        view_toggle_notation=a_toggle_notation,
        view_toggle_cliplauncher=a_toggle_cl,
        view_toggle_automation=a_toggle_auto,
        project_add_audio_track=a_add_audio,
        project_add_instrument_track=a_add_inst,
        project_add_bus_track=a_add_bus,
        project_add_placeholder_clip=a_add_clip,
        project_remove_selected_track=a_rm_track,
        project_time_signature=a_time_sig,
        project_settings=a_proj_settings,
        project_save_snapshot=a_snap_save,
        project_load_snapshot=a_snap_load,
        project_load_sf2=a_load_sf2,
        audio_settings=a_audio,
        midi_settings=a_midi_settings,
        midi_mapping=a_midi_mapping,
    )