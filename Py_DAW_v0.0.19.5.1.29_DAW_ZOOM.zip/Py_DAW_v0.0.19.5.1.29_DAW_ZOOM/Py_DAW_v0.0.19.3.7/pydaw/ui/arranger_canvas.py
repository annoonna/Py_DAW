"""Arranger canvas (v0.0.19.2.2)

Additions in v0.0.19.2.0 (Arranger focus):
- Default mouse-wheel zoom (like many DAWs); Shift+Wheel = track-height zoom; Alt+Wheel passthrough
- Zoom +/- actions in context menu (and API hooks used by ArrangerView buttons)
- Clip handles on BOTH sides (right: resize/extend, left: trim/extend with content offset)
- Audio waveform preview (threaded peak-cache) + MIDI mini-preview
- Track volume influences waveform height (dB curve mapping) + shown as dB text
- Right-click menu includes Snap toggle + Grid division (1/1..1/64)

Notes:
- Playback uses existing audio engine fields (offset_seconds already supported via getattr in AudioEngine).
- Clip model now supports offset_beats/offset_seconds; older projects load fine (defaults = 0).
"""

from __future__ import annotations

from dataclasses import dataclass
import math
import os
from pathlib import Path

from PyQt6.QtWidgets import QWidget, QMenu
from PyQt6.QtGui import QPainter, QPen, QBrush, QDrag, QColor
from PyQt6.QtCore import Qt, QRectF, pyqtSignal, QPointF, QMimeData

from pydaw.services.project_service import ProjectService
from pydaw.services.transport_service import TransportService

try:
    import numpy as np  # type: ignore
except Exception:  # pragma: no cover
    np = None  # type: ignore

try:
    import soundfile as sf  # type: ignore
except Exception:  # pragma: no cover
    sf = None  # type: ignore


@dataclass
class _DragMove:
    clip_id: str
    dx_beats: float


@dataclass
class _DragResizeRight:
    clip_id: str
    origin_len: float
    origin_x: float


@dataclass
class _DragResizeLeft:
    clip_id: str
    origin_start: float
    origin_len: float
    origin_x: float
    origin_offset_beats: float
    origin_offset_seconds: float


@dataclass
class _DragLoop:
    mode: str  # "new" | "start" | "end"
    origin_beat: float


@dataclass
class _DragNewClip:
    """Drag-create a new MIDI clip in empty arranger space."""

    track_id: str
    start_beat: float
    cur_beat: float


@dataclass
class _PeaksData:
    mtime_ns: int
    block_size: int
    samplerate: int
    peaks: "np.ndarray"  # type: ignore

    @property
    def peaks_per_second(self) -> float:
        return float(self.samplerate) / float(max(1, self.block_size))


class ArrangerCanvas(QWidget):
    zoom_changed = pyqtSignal(float)  # pixels_per_beat
    clip_activated = pyqtSignal(str)
    clip_selected = pyqtSignal(str)
    request_rename_clip = pyqtSignal(str)
    request_duplicate_clip = pyqtSignal(str)
    request_delete_clip = pyqtSignal(str)
    request_import_audio = pyqtSignal(str, float)  # track_id, start_beats

    loop_region_committed = pyqtSignal(bool, float, float)

    def __init__(self, project: ProjectService, parent=None):
        super().__init__(parent)
        self.project = project
        self.transport: TransportService | None = None

        self.setAcceptDrops(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        self.pixels_per_beat = 80.0
        self.track_height = 70
        self.ruler_height = 28

        self.playhead_beat = 0.0
        self.loop_enabled = False
        self.loop_start = 0.0
        self.loop_end = 16.0

        self.snap_beats = 0.25

        self.selected_clip_ids: set[str] = set()
        self.selected_clip_id: str = ""

        self._drag_move: _DragMove | None = None
        self._drag_resize_r: _DragResizeRight | None = None
        self._drag_resize_l: _DragResizeLeft | None = None
        self._drag_loop: _DragLoop | None = None
        self._drag_new_clip: _DragNewClip | None = None

        self._dnd_drag_start: QPointF | None = None
        self._dnd_clip_id: str = ""

        # Auto-loop extension
        self._pending_auto_loop_end: float | None = None

        # Waveform cache
        self._peaks_cache: dict[str, _PeaksData] = {}
        self._peaks_pending: set[str] = set()

        self.project.project_updated.connect(self._on_project_updated)
        self._update_minimum_size()

    # --- external setters

    def set_transport(self, transport: TransportService | None) -> None:
        self.transport = transport

    def set_playhead(self, beat: float) -> None:
        self.playhead_beat = max(0.0, float(beat))
        self.update()

    def set_loop_region(self, enabled: bool, start: float, end: float) -> None:
        self.loop_enabled = bool(enabled)
        self.loop_start = max(0.0, float(start))
        self.loop_end = max(self.loop_start + self.snap_beats, float(end))
        self.update()

    def set_snap_division(self, div: str) -> None:
        """Set snap/grid division and update snap_beats."""
        # Beat unit is quarter = 1.0
        div = str(div or "1/16")
        mapping = {
            "1/1": 4.0,
            "1/2": 2.0,
            "1/4": 1.0,
            "1/8": 0.5,
            "1/16": 0.25,
            "1/32": 0.125,
            "1/64": 0.0625,
        }
        self.snap_beats = float(mapping.get(div, 0.25))

    # --- zoom helpers (used by ArrangerView buttons + context menu)

    def _zoom_by_factor(self, factor: float) -> None:
        self.pixels_per_beat = max(20.0, min(320.0, float(self.pixels_per_beat) * float(factor)))
        self._update_minimum_size()
        self.update()
        self.zoom_changed.emit(float(self.pixels_per_beat))

    def zoom_in(self) -> None:
        self._zoom_by_factor(1.1)

    def zoom_out(self) -> None:
        self._zoom_by_factor(0.9)

    # --- model helpers

    def _beats_per_bar(self) -> float:
        """Return beats per bar based on Project.time_signature (num/den)."""
        ts = getattr(self.project.ctx.project, "time_signature", "4/4") or "4/4"
        try:
            num_s, den_s = str(ts).split("/")
            num = float(num_s)
            den = float(den_s)
            return float(num) * (4.0 / max(1.0, den))
        except Exception:
            return 4.0

    def _tracks(self):
        return list(self.project.ctx.project.tracks)

    def _track_at_y(self, y: float):
        tracks = self._tracks()
        if y <= self.ruler_height:
            return None
        idx = int((y - self.ruler_height) // self.track_height)
        if idx < 0 or idx >= len(tracks):
            return None
        return tracks[idx]

    def _clip_rects(self):
        tracks = self._tracks()
        rects = []
        for clip in self.project.ctx.project.clips:
            track_idx = next((i for i, t in enumerate(tracks) if t.id == clip.track_id), None)
            if track_idx is None:
                continue
            x = float(clip.start_beats) * self.pixels_per_beat
            w = max(10.0, float(clip.length_beats) * self.pixels_per_beat)
            y = self.ruler_height + track_idx * self.track_height + 8
            h = self.track_height - 16
            rects.append((clip.id, QRectF(x, y, w, h), clip))
        return rects

    def _clip_at_pos(self, pos: QPointF) -> str:
        for cid, r, _clip in self._clip_rects():
            if r.contains(pos):
                return cid
        return ""

    def _clip_rect(self, clip_id: str):
        for cid, r, clip in self._clip_rects():
            if cid == clip_id:
                return r, clip
        return None, None

    def _hit_resize_handle_right(self, rect: QRectF, pos: QPointF) -> bool:
        handle = QRectF(rect.right() - 6, rect.top(), 12, rect.height())
        return handle.contains(pos)

    def _hit_resize_handle_left(self, rect: QRectF, pos: QPointF) -> bool:
        handle = QRectF(rect.left() - 6, rect.top(), 12, rect.height())
        return handle.contains(pos)

    def _hit_loop_handle(self, pos: QPointF) -> str:
        if pos.y() > self.ruler_height:
            return ""
        x = pos.x()
        x1 = self.loop_start * self.pixels_per_beat
        x2 = self.loop_end * self.pixels_per_beat
        if abs(x - x1) <= 6:
            return "start"
        if abs(x - x2) <= 6:
            return "end"
        return ""

    def _x_to_beats(self, x: float) -> float:
        return max(0.0, float(x) / float(self.pixels_per_beat))

    def _snap(self, beat: float) -> float:
        g = float(self.snap_beats)
        if g <= 0.0:
            return max(0.0, float(beat))
        return max(0.0, round(float(beat) / g) * g)

    def _beats_to_seconds(self, beats: float) -> float:
        bpm = float(getattr(self.project.ctx.project, "bpm", 120.0) or 120.0)
        return (float(beats) * 60.0) / max(1e-6, bpm)

    # --- auto-loop extension

    def _mark_auto_loop_end_for_clip(self, clip_id: str) -> None:
        if not self.loop_enabled:
            return
        _r, c = self._clip_rect(clip_id)
        if not c:
            return
        end = float(c.start_beats) + float(c.length_beats)
        if end > float(self.loop_end):
            self._pending_auto_loop_end = float(end)

    def _commit_auto_loop_end(self) -> None:
        if self._pending_auto_loop_end is None:
            return
        new_end = float(self._pending_auto_loop_end)
        self._pending_auto_loop_end = None
        if new_end <= float(self.loop_end):
            return
        self.loop_end = self._snap(new_end)
        self.loop_enabled = True
        self.loop_region_committed.emit(True, float(self.loop_start), float(self.loop_end))
        # also push to transport if available
        if self.transport is not None:
            try:
                self.transport.set_loop(True, float(self.loop_start), float(self.loop_end))
            except Exception:
                pass
        self.update()

    def _disable_loop(self) -> None:
        self.loop_enabled = False
        self.loop_region_committed.emit(False, float(self.loop_start), float(self.loop_end))
        if self.transport is not None:
            try:
                self.transport.set_loop(False, float(self.loop_start), float(self.loop_end))
            except Exception:
                pass
        self.update()

    # --- waveform cache

    def _volume_to_db(self, vol: float) -> float:
        """Visual-only mapping: fader position -> dB."""
        v = float(vol)
        if v <= 0.0:
            return -120.0
        if v <= 1.0:
            return -60.0 + (60.0 * v)
        v = min(v, 2.0)
        return 6.0 * (v - 1.0)

    def _db_to_gain(self, db: float) -> float:
        if db <= -120.0:
            return 0.0
        return float(10.0 ** (float(db) / 20.0))

    def _display_gain_for_volume(self, vol: float) -> tuple[float, float]:
        db = self._volume_to_db(float(vol))
        return (self._db_to_gain(db), db)

    def _get_peaks_for_path(self, path_str: str) -> _PeaksData | None:
        if sf is None or np is None:
            return None
        if not path_str:
            return None
        try:
            p = os.path.abspath(path_str)
            st = os.stat(p)
            mtime = int(st.st_mtime_ns)
        except Exception:
            return None

        cached = self._peaks_cache.get(p)
        if cached and int(cached.mtime_ns) == mtime:
            return cached

        if p not in self._peaks_pending:
            self._peaks_pending.add(p)
            self._submit_peaks_compute(p, mtime)
        return None

    def _submit_peaks_compute(self, abs_path: str, mtime_ns: int) -> None:
        def fn():
            return self._compute_peaks(abs_path)

        def ok(res):
            try:
                if res is None:
                    return
                peaks_arr, sr, bs = res
                self._peaks_cache[str(abs_path)] = _PeaksData(
                    mtime_ns=int(mtime_ns),
                    block_size=int(bs),
                    samplerate=int(sr),
                    peaks=peaks_arr,
                )
            finally:
                self._peaks_pending.discard(str(abs_path))
                self.update()

        def err(_msg: str):
            self._peaks_pending.discard(str(abs_path))

        try:
            self.project._submit(fn, ok, err)  # type: ignore[attr-defined]
        except Exception:
            try:
                res = self._compute_peaks(abs_path)
                if res is not None:
                    peaks_arr, sr, bs = res
                    self._peaks_cache[str(abs_path)] = _PeaksData(
                        mtime_ns=int(mtime_ns),
                        block_size=int(bs),
                        samplerate=int(sr),
                        peaks=peaks_arr,
                    )
            finally:
                self._peaks_pending.discard(str(abs_path))
                self.update()

    def _compute_peaks(self, abs_path: str):
        if sf is None or np is None:
            return None
        try:
            f = sf.SoundFile(abs_path)
        except Exception:
            return None

        block_size = 2048
        sr = int(getattr(f, "samplerate", 48000) or 48000)
        peaks_list = []
        try:
            for block in f.blocks(blocksize=block_size, dtype="float32", always_2d=True):
                if block is None or block.shape[0] == 0:
                    continue
                a = np.max(np.abs(block), axis=1)
                peaks_list.append(float(np.max(a)))
        except Exception:
            try:
                data = f.read(dtype="float32", always_2d=True)
                if data is None or data.shape[0] == 0:
                    return None
                a = np.max(np.abs(data), axis=1)
                n = int(a.shape[0])
                n_chunks = (n + block_size - 1) // block_size
                for i in range(n_chunks):
                    s = i * block_size
                    e = min(n, (i + 1) * block_size)
                    peaks_list.append(float(np.max(a[s:e])))
            except Exception:
                return None
        finally:
            try:
                f.close()
            except Exception:
                pass

        if not peaks_list:
            return None
        arr = np.asarray(peaks_list, dtype="float32")
        arr = np.clip(arr, 0.0, 1.0)
        return arr, sr, block_size

    # --- drawing helpers

    def _draw_handle_strips(self, p: QPainter, rect: QRectF, is_sel: bool) -> None:
        w = 6.0
        col = self.palette().highlight().color() if is_sel else self.palette().dark().color()
        p.fillRect(QRectF(rect.left(), rect.top(), w, rect.height()), QBrush(col))
        p.fillRect(QRectF(rect.right() - w, rect.top(), w, rect.height()), QBrush(col))

    def _draw_audio_waveform(self, p: QPainter, rect: QRectF, clip, track_volume: float) -> None:
        peaks = self._get_peaks_for_path(str(getattr(clip, "source_path", "") or ""))
        if peaks is None or np is None:
            p.setPen(QPen(self.palette().mid().color()))
            p.drawText(rect.adjusted(6, 2, -6, -2), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, "Waveform…")
            return

        beats_to_sec = self._beats_to_seconds(1.0)
        offset_sec = float(getattr(clip, "offset_seconds", 0.0) or 0.0)
        length_sec = float(getattr(clip, "length_beats", 0.0) or 0.0) * beats_to_sec
        if length_sec <= 0.0:
            return

        start_i = int(max(0.0, offset_sec * peaks.peaks_per_second))
        end_i = int(max(start_i + 1, (offset_sec + length_sec) * peaks.peaks_per_second))
        seg = peaks.peaks[start_i:min(end_i, len(peaks.peaks))]
        if seg.size == 0:
            return

        n = max(8, int(rect.width()))
        if seg.size != n:
            x_old = np.linspace(0.0, 1.0, num=int(seg.size), dtype=np.float32)
            x_new = np.linspace(0.0, 1.0, num=int(n), dtype=np.float32)
            seg = np.interp(x_new, x_old, seg).astype(np.float32)

        gain, _db = self._display_gain_for_volume(track_volume)
        seg = np.clip(seg * float(gain), 0.0, 1.0)

        mid_y = rect.center().y()
        amp_h = rect.height() * 0.45

        p.setPen(QPen(self.palette().text().color()))
        x0 = int(rect.left())
        top = rect.top()
        bottom = rect.bottom()
        for i, a in enumerate(seg):
            if float(a) <= 0.0005:
                continue
            x = x0 + i
            dy = float(a) * amp_h
            y1 = max(top, mid_y - dy)
            y2 = min(bottom, mid_y + dy)
            p.drawLine(int(x), int(y1), int(x), int(y2))

    def _draw_midi_preview(self, p: QPainter, rect: QRectF, clip) -> None:
        notes = []
        try:
            notes = list(self.project.ctx.project.midi_notes.get(clip.id, []))
        except Exception:
            notes = []
        if not notes:
            p.setPen(QPen(self.palette().mid().color()))
            p.drawText(rect.adjusted(6, 2, -6, -2), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, "MIDI…")
            return

        off_beats = float(getattr(clip, "offset_beats", 0.0) or 0.0)
        clip_len = max(1e-6, float(getattr(clip, "length_beats", 1.0) or 1.0))

        vis = []
        for n in notes:
            st = float(getattr(n, "start_beats", 0.0) or 0.0) - off_beats
            en = st + float(getattr(n, "length_beats", 0.0) or 0.0)
            if en < 0.0 or st > clip_len:
                continue
            vis.append(n)
        if not vis:
            p.setPen(QPen(self.palette().mid().color()))
            p.drawText(rect.adjusted(6, 2, -6, -2), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, "MIDI…")
            return

        pitches = [int(getattr(n, "pitch", 60) or 60) for n in vis]
        pmin = min(pitches)
        pmax = max(pitches)
        if pmax <= pmin:
            pmax = pmin + 1

        def y_for_pitch(pitch: int) -> float:
            t = (pitch - pmin) / float(pmax - pmin)
            return rect.bottom() - (t * rect.height())

        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(self.palette().highlight().color()))
        for n in vis:
            st = float(getattr(n, "start_beats", 0.0) or 0.0) - off_beats
            ln = float(getattr(n, "length_beats", 0.0) or 0.0)
            pitch = int(getattr(n, "pitch", 60) or 60)
            x1 = rect.left() + (st / clip_len) * rect.width()
            x2 = rect.left() + ((st + ln) / clip_len) * rect.width()
            y = y_for_pitch(pitch)
            h = max(3.0, rect.height() / 12.0)
            r = QRectF(x1, y - h, max(2.0, x2 - x1), h)
            p.drawRect(r)

    # --- Drag&Drop (Arranger target + source)

    def _start_clip_drag(self, clip_id: str) -> None:
        drag = QDrag(self)
        md = QMimeData()
        md.setData("application/x-pydaw-clipid", clip_id.encode("utf-8"))
        drag.setMimeData(md)
        drag.exec(Qt.DropAction.CopyAction)

    def dragEnterEvent(self, event):  # noqa: ANN001
        if event.mimeData().hasFormat("application/x-pydaw-clipid"):
            event.acceptProposedAction()
            return
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            return
        super().dragEnterEvent(event)

    def dropEvent(self, event):  # noqa: ANN001
        # external files (audio/midi)
        if event.mimeData().hasUrls() and not event.mimeData().hasFormat("application/x-pydaw-clipid"):
            urls = event.mimeData().urls()
            if not urls:
                return
            pth = urls[0].toLocalFile()
            if not pth:
                return
            path = Path(pth)
            pos = event.position()
            trk = self._track_at_y(pos.y())
            if not trk:
                return
            beat = self._snap(self._x_to_beats(pos.x()))
            ext = path.suffix.lower()
            if ext in (".mid", ".midi"):
                self.project.import_midi_to_track_at(trk.id, path, start_beats=beat)
            else:
                self.project.add_audio_clip_from_file_at(trk.id, path, start_beats=beat)
            event.acceptProposedAction()
            return

        # internal clip drag (copy)
        if not event.mimeData().hasFormat("application/x-pydaw-clipid"):
            return
        clip_id = bytes(event.mimeData().data("application/x-pydaw-clipid")).decode("utf-8")
        src = next((c for c in self.project.ctx.project.clips if c.id == clip_id), None)
        if not src:
            return

        pos = event.position()
        trk = self._track_at_y(pos.y())
        if not trk:
            return

        beat = self._snap(self._x_to_beats(pos.x()))
        self.project.duplicate_clip(clip_id)
        dup_id = self.project.ctx.project.clips[-1].id
        self.project.move_clip(dup_id, beat, snap_beats=self.snap_beats)
        self.project.move_clip_track(dup_id, trk.id)
        self.selected_clip_ids = {dup_id}
        self.selected_clip_id = dup_id
        self.clip_selected.emit(dup_id)
        self._mark_auto_loop_end_for_clip(dup_id)
        self.update()
        event.acceptProposedAction()

    # --- interactions

    def contextMenuEvent(self, event):  # noqa: ANN001
        pos = QPointF(event.pos())

        def add_grid_menu(menu: QMenu) -> None:
            menu.addSeparator()
            a_snap = menu.addAction("Snap")
            a_snap.setCheckable(True)
            a_snap.setChecked(bool(self.snap_beats and self.snap_beats > 0))

            sub = menu.addMenu("Grid")
            current = str(getattr(self.project.ctx.project, "snap_division", "1/16") or "1/16")
            for d in ["1/1", "1/2", "1/4", "1/8", "1/16", "1/32", "1/64"]:
                a = sub.addAction(d)
                a.setCheckable(True)
                a.setChecked(d == current)

            menu.addSeparator()
            a_zi = menu.addAction("Zoom +")
            a_zo = menu.addAction("Zoom -")

            return a_snap, sub, a_zi, a_zo

        # Ruler
        if pos.y() <= self.ruler_height:
            menu = QMenu(self)
            a_off = menu.addAction("Loop Off")
            a_off.setShortcut("Ctrl+L")
            a_snap, sub, a_zi, a_zo = add_grid_menu(menu)
            act = menu.exec(event.globalPos())
            if act == a_off:
                self._disable_loop()
                return
            if act == a_snap:
                if self.snap_beats and self.snap_beats > 0:
                    self.snap_beats = 0.0
                else:
                    self.set_snap_division(str(getattr(self.project.ctx.project, "snap_division", "1/16") or "1/16"))
                self.update()
                return
            if act in sub.actions():
                div = act.text()
                try:
                    self.project.set_snap_division(div)
                except Exception:
                    setattr(self.project.ctx.project, "snap_division", div)
                self.set_snap_division(div)
                self.update()
                return
            if act == a_zi:
                self.zoom_in()
                return
            if act == a_zo:
                self.zoom_out()
                return
            return

        # Clip
        cid = self._clip_at_pos(pos)
        if cid:
            self.selected_clip_ids = {cid}
            self.selected_clip_id = cid
            self.clip_selected.emit(cid)
            self.update()

            menu = QMenu(self)
            a_rename = menu.addAction("Umbenennen…")
            a_dup = menu.addAction("Duplizieren")
            menu.addSeparator()
            a_del = menu.addAction("Löschen")
            a_snap, sub, a_zi, a_zo = add_grid_menu(menu)
            act = menu.exec(event.globalPos())

            if act == a_rename:
                self.request_rename_clip.emit(cid)
                return
            if act == a_dup:
                self.request_duplicate_clip.emit(cid)
                return
            if act == a_del:
                self.request_delete_clip.emit(cid)
                return
            if act == a_snap:
                if self.snap_beats and self.snap_beats > 0:
                    self.snap_beats = 0.0
                else:
                    self.set_snap_division(str(getattr(self.project.ctx.project, "snap_division", "1/16") or "1/16"))
                self.update()
                return
            if act in sub.actions():
                div = act.text()
                try:
                    self.project.set_snap_division(div)
                except Exception:
                    setattr(self.project.ctx.project, "snap_division", div)
                self.set_snap_division(div)
                self.update()
                return
            if act == a_zi:
                self.zoom_in()
                return
            if act == a_zo:
                self.zoom_out()
                return
            return

        # Empty area: just grid/zoom
        menu = QMenu(self)
        a_snap, sub, a_zi, a_zo = add_grid_menu(menu)
        act = menu.exec(event.globalPos())
        if act == a_snap:
            if self.snap_beats and self.snap_beats > 0:
                self.snap_beats = 0.0
            else:
                self.set_snap_division(str(getattr(self.project.ctx.project, "snap_division", "1/16") or "1/16"))
            self.update()
            return
        if act in sub.actions():
            div = act.text()
            try:
                self.project.set_snap_division(div)
            except Exception:
                setattr(self.project.ctx.project, "snap_division", div)
            self.set_snap_division(div)
            self.update()
            return
        if act == a_zi:
            self.zoom_in()
            return
        if act == a_zo:
            self.zoom_out()
            return

    def wheelEvent(self, event):  # noqa: ANN001
        mods = event.modifiers()
        delta = event.angleDelta().y()

        if mods & Qt.KeyboardModifier.AltModifier:
            super().wheelEvent(event)
            return

        if mods & Qt.KeyboardModifier.ShiftModifier:
            factor = 1.1 if delta > 0 else 0.9
            self.track_height = int(max(40, min(140, self.track_height * factor)))
            self._update_minimum_size()
            self.update()
            event.accept()
            return

        factor = 1.1 if delta > 0 else 0.9
        self._zoom_by_factor(factor)
        event.accept()

    def mousePressEvent(self, event):  # noqa: ANN001
        pos = event.position()
        cid = self._clip_at_pos(pos)

        if event.button() == Qt.MouseButton.LeftButton:
            self.setFocus(Qt.FocusReason.MouseFocusReason)

            # Loop editing in ruler
            if pos.y() <= self.ruler_height:
                handle = self._hit_loop_handle(pos)
                b = self._snap(self._x_to_beats(pos.x()))
                if handle:
                    self._drag_loop = _DragLoop(mode=handle, origin_beat=b)
                else:
                    self._drag_loop = _DragLoop(mode="new", origin_beat=b)
                    self.loop_enabled = True
                    self.loop_start = b
                    self.loop_end = b + max(self.snap_beats, 1.0)
                self.update()
                return

            # Selection (Shift toggles multi-select)
            if cid:
                if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                    if cid in self.selected_clip_ids:
                        self.selected_clip_ids.remove(cid)
                    else:
                        self.selected_clip_ids.add(cid)
                else:
                    self.selected_clip_ids = {cid}
            else:
                if not (event.modifiers() & Qt.KeyboardModifier.ShiftModifier):
                    self.selected_clip_ids = set()

            self.selected_clip_id = cid
            self.clip_selected.emit(cid)
            self.update()

            # --- Create new clip by dragging in empty space (DAW-style)
            # We create MIDI clips (editable in PianoRoll). If the user drags
            # on an audio track, we auto-convert it to an instrument track when
            # the clip is committed (ProjectService.add_midi_clip_at handles it).
            if (not cid) and pos.y() > self.ruler_height:
                trk = self._track_at_y(pos.y())
                mods = event.modifiers()
                if trk and not (mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier)):
                    if str(getattr(trk, "kind", "")) not in ("master", "bus"):
                        b = self._snap(self._x_to_beats(pos.x()))
                        self._drag_new_clip = _DragNewClip(track_id=str(trk.id), start_beat=float(b), cur_beat=float(b))
                        self.update()
                        return

            # DnD start
            self._dnd_drag_start = pos
            self._dnd_clip_id = cid

            # Ctrl-copy duplicates before move (DAW-style)
            if cid and (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
                self.project.duplicate_clip(cid)
                cid = self.project.ctx.project.clips[-1].id
                self.selected_clip_ids = {cid}
                self.selected_clip_id = cid
                self.clip_selected.emit(cid)
                self._mark_auto_loop_end_for_clip(cid)

            if cid:
                rect, clip = self._clip_rect(cid)
                if rect and clip:
                    if self._hit_resize_handle_right(rect, pos):
                        self._drag_resize_r = _DragResizeRight(clip_id=cid, origin_len=float(clip.length_beats), origin_x=pos.x())
                        self._drag_resize_l = None
                        self._drag_move = None
                    elif self._hit_resize_handle_left(rect, pos):
                        self._drag_resize_l = _DragResizeLeft(
                            clip_id=cid,
                            origin_start=float(clip.start_beats),
                            origin_len=float(clip.length_beats),
                            origin_x=pos.x(),
                            origin_offset_beats=float(getattr(clip, "offset_beats", 0.0) or 0.0),
                            origin_offset_seconds=float(getattr(clip, "offset_seconds", 0.0) or 0.0),
                        )
                        self._drag_resize_r = None
                        self._drag_move = None
                    else:
                        beat = self._x_to_beats(pos.x())
                        self._drag_move = _DragMove(clip_id=cid, dx_beats=beat - float(clip.start_beats))
                        self._drag_resize_r = None
                        self._drag_resize_l = None

            super().mousePressEvent(event)
            return

        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):  # noqa: ANN001
        pos = event.position()

        if self._drag_new_clip is not None:
            b = self._snap(self._x_to_beats(pos.x()))
            self._drag_new_clip.cur_beat = float(b)
            self.update()
            return

        if self._drag_loop is not None:
            b = self._snap(self._x_to_beats(pos.x()))
            if self._drag_loop.mode == "new":
                s = min(self._drag_loop.origin_beat, b)
                e = max(self._drag_loop.origin_beat, b)
                self.loop_start = s
                self.loop_end = max(s + self.snap_beats, e)
                self.loop_enabled = True
            elif self._drag_loop.mode == "start":
                self.loop_start = min(b, self.loop_end - self.snap_beats)
            elif self._drag_loop.mode == "end":
                self.loop_end = max(b, self.loop_start + self.snap_beats)
            self.update()
            return

        # Alt+DnD drag source from arranger
        if self._dnd_drag_start is not None and self._dnd_clip_id and (event.modifiers() & Qt.KeyboardModifier.AltModifier):
            dist = (pos - self._dnd_drag_start).manhattanLength()
            if dist >= 8:
                self._drag_move = None
                self._drag_resize_r = None
                self._drag_resize_l = None
                cid = self._dnd_clip_id
                self._dnd_drag_start = None
                self._dnd_clip_id = ""
                self._start_clip_drag(cid)
                return

        if self._drag_resize_r is not None:
            _rect, clip = self._clip_rect(self._drag_resize_r.clip_id)
            if not clip:
                return
            dx = pos.x() - self._drag_resize_r.origin_x
            dbeats = dx / self.pixels_per_beat
            new_len = max(self.snap_beats, self._drag_resize_r.origin_len + dbeats)
            self.project.resize_clip(self._drag_resize_r.clip_id, new_len, snap_beats=self.snap_beats)
            self._mark_auto_loop_end_for_clip(self._drag_resize_r.clip_id)
            return

        if self._drag_resize_l is not None:
            _rect, clip = self._clip_rect(self._drag_resize_l.clip_id)
            if not clip:
                return
            dx = pos.x() - self._drag_resize_l.origin_x
            dbeats = dx / self.pixels_per_beat

            new_start = self._snap(self._drag_resize_l.origin_start + dbeats)
            delta = float(new_start) - float(self._drag_resize_l.origin_start)
            new_len = float(self._drag_resize_l.origin_len) - delta

            min_len = max(self.snap_beats, 0.25)
            if new_len < min_len:
                new_len = min_len
                # recompute start to keep right edge stable
                new_start = float(self._drag_resize_l.origin_start) + (float(self._drag_resize_l.origin_len) - new_len)
                new_start = self._snap(new_start)
                delta = float(new_start) - float(self._drag_resize_l.origin_start)

            # Content offset (beats + seconds)
            off_beats = max(0.0, float(self._drag_resize_l.origin_offset_beats) + delta)
            off_secs = max(0.0, float(self._drag_resize_l.origin_offset_seconds) + self._beats_to_seconds(delta))
            self.project.trim_clip_left(self._drag_resize_l.clip_id, new_start, new_len, off_beats, off_secs, snap_beats=self.snap_beats)
            self._mark_auto_loop_end_for_clip(self._drag_resize_l.clip_id)
            return

        if self._drag_move is not None:
            _rect, clip = self._clip_rect(self._drag_move.clip_id)
            if not clip:
                return
            beat = self._snap(self._x_to_beats(pos.x()) - self._drag_move.dx_beats)
            self.project.move_clip(self._drag_move.clip_id, beat, snap_beats=self.snap_beats)

            trk = self._track_at_y(pos.y())
            if trk and trk.id != clip.track_id:
                self.project.move_clip_track(self._drag_move.clip_id, trk.id)
            self._mark_auto_loop_end_for_clip(self._drag_move.clip_id)
            return

        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):  # noqa: ANN001
        if self._drag_new_clip is not None:
            try:
                d = self._drag_new_clip
                start = float(min(d.start_beat, d.cur_beat))
                end = float(max(d.start_beat, d.cur_beat))
                length = float(end - start)

                # If the user just clicked (tiny drag), create one bar by default.
                if length < float(self.snap_beats) * 1.5:
                    length = float(self._beats_per_bar())
                length = max(float(self.snap_beats), float(self._snap(length)))

                trk = next((t for t in self.project.ctx.project.tracks if t.id == str(d.track_id)), None)
                if trk and str(getattr(trk, "kind", "audio")) == "audio":
                    # On audio tracks we import an audio file at the position instead of creating a MIDI clip.
                    self.request_import_audio.emit(str(d.track_id), float(start))
                    self.update()
                    return

                new_id = self.project.add_midi_clip_at(d.track_id, start_beats=start, length_beats=length, label="MIDI Clip")
                self.selected_clip_ids = {new_id}
                self.selected_clip_id = new_id
                self.clip_selected.emit(new_id)
                self._mark_auto_loop_end_for_clip(new_id)
                self.update()
                # Open the created clip immediately.
                self.clip_activated.emit(new_id)
            finally:
                self._drag_new_clip = None
            return

        if self._drag_loop is not None:
            self._drag_loop = None
            self.loop_region_committed.emit(bool(self.loop_enabled), float(self.loop_start), float(self.loop_end))
            self.update()
            return

        self._commit_auto_loop_end()

        self._drag_move = None
        self._drag_resize_r = None
        self._drag_resize_l = None
        self._dnd_drag_start = None
        self._dnd_clip_id = ""

        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):  # noqa: ANN001
        pos = event.position()
        cid = self._clip_at_pos(pos)
        if cid:
            self.clip_activated.emit(cid)
            super().mouseDoubleClickEvent(event)
            return

        # Double-click empty space -> create a 1-bar clip on that track (Region-first workflow).
        try:
            if pos.y() > self.ruler_height:
                trk = self._track_at_y(pos.y())
                if trk and str(getattr(trk, "kind", "")) != "master":
                    start = float(self._snap(self._x_to_beats(pos.x())))
                    length = float(self._beats_per_bar())

                    if str(getattr(trk, "kind", "audio")) == "instrument":
                        new_id = self.project.add_midi_clip_at(str(trk.id), start_beats=start, length_beats=length, label="MIDI Clip")
                        self.selected_clip_ids = {new_id}
                        self.selected_clip_id = new_id
                        self.clip_selected.emit(new_id)
                        self._mark_auto_loop_end_for_clip(new_id)
                        self.update()
                        # Open immediately (PianoRoll)
                        self.clip_activated.emit(new_id)
                    else:
                        # audio/bus: create placeholder clip (no import dialog)
                        new_id = self.project.add_audio_clip_placeholder_at(str(trk.id), start_beats=start, length_beats=length, label="Audio Clip")
                        self.selected_clip_ids = {new_id}
                        self.selected_clip_id = new_id
                        self.clip_selected.emit(new_id)
                        self._mark_auto_loop_end_for_clip(new_id)
                        self.update()
        except Exception:
            pass

        super().mouseDoubleClickEvent(event)

    # --- painting

    def paintEvent(self, event):  # noqa: ANN001
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.fillRect(self.rect(), self.palette().base())

        bpb = max(0.5, float(self._beats_per_bar()))

        # Loop shading
        if self.loop_enabled:
            x1 = int(self.loop_start * self.pixels_per_beat)
            x2 = int(self.loop_end * self.pixels_per_beat)
            p.fillRect(QRectF(x1, 0, max(0, x2 - x1), self.height()), QBrush(self.palette().alternateBase()))

        # Ruler background
        p.fillRect(0, 0, self.width(), self.ruler_height, self.palette().window())

        # Loop handles in ruler
        if self.loop_enabled:
            pen = QPen(self.palette().highlight().color())
            pen.setWidth(2)
            p.setPen(pen)
            x1 = int(self.loop_start * self.pixels_per_beat)
            x2 = int(self.loop_end * self.pixels_per_beat)
            p.drawLine(x1, 0, x1, self.ruler_height)
            p.drawLine(x2, 0, x2, self.ruler_height)
            p.drawText(min(x1, x2) + 6, 18, "LOOP")
        else:
            p.setPen(QPen(self.palette().mid().color()))
            p.drawText(8, 18, "Loop: Off (Rechtsklick im Ruler oder Ctrl+L)")

        # Grid (Bar / Beat / Snap subdivisions)
        width_beats = self.width() / self.pixels_per_beat
        bpb = float(self._beats_per_bar())
        beat_count = int(math.ceil(width_beats)) + 1
        bar_count = int(math.ceil(width_beats / bpb)) + 2

        # Contrast-tuned grid colors (match PianoRoll readability)
        grid_sub = QColor(70, 74, 84, 140)   # ~55% alpha
        grid_beat = QColor(92, 96, 110, 180) # ~70% alpha
        grid_bar = QColor(130, 134, 152, 220)

        # Alternate bar shading for easier placement
        shade = QColor(255, 255, 255, 0)
        try:
            shade = QColor(self.palette().alternateBase().color())
        except Exception:
            pass
        for k in range(bar_count):
            if k % 2 == 1:
                x = int(k * bpb * self.pixels_per_beat)
                w = int(bpb * self.pixels_per_beat)
                p.setOpacity(0.12)  # stronger than before
                p.fillRect(QRectF(x, self.ruler_height, w, self.height() - self.ruler_height), QBrush(shade))
                p.setOpacity(1.0)

        # Snap subdivision lines (e.g. 1/16)
        snap = float(self.snap_beats or 1.0)
        if 0.0 < snap < 1.0:
            pen_sub = QPen(grid_sub)
            pen_sub.setStyle(Qt.PenStyle.SolidLine)
            pen_sub.setWidth(1)
            p.setPen(pen_sub)
            sub_count = int(math.ceil(width_beats / snap)) + 1
            for i in range(sub_count):
                beat = i * snap
                # Skip full beats (handled by beat lines)
                if abs((beat % 1.0)) < 1e-6:
                    continue
                x = int(beat * self.pixels_per_beat)
                p.drawLine(x, self.ruler_height, x, self.height())

        # Beat lines (stronger)
        pen_beat = QPen(grid_beat)
        pen_beat.setStyle(Qt.PenStyle.SolidLine)
        pen_beat.setWidth(1)
        p.setPen(pen_beat)
        for b in range(beat_count):
            x = int(b * self.pixels_per_beat)
            p.drawLine(x, self.ruler_height, x, self.height())

        # Bar lines + labels
        pen_bar = QPen(grid_bar)
        pen_bar.setWidth(2)
        p.setPen(pen_bar)
        for k in range(bar_count):
            beat = k * bpb
            x = int(beat * self.pixels_per_beat)
            p.drawLine(x, 0, x, self.height())
            p.drawText(x + 4, 18, f"Bar {k}")

        # Track lanes
        p.setPen(QPen(self.palette().dark().color()))
        tracks = self._tracks()
        for i, _ in enumerate(tracks):
            y = self.ruler_height + i * self.track_height
            p.drawLine(0, y, self.width(), y)

        # New-clip ghost (while drag-creating)
        if self._drag_new_clip is not None:
            try:
                d = self._drag_new_clip
                idx = next((i for i, t in enumerate(tracks) if getattr(t, "id", "") == d.track_id), -1)
                if idx >= 0:
                    s = float(min(d.start_beat, d.cur_beat))
                    e = float(max(d.start_beat, d.cur_beat))
                    ln = float(e - s)
                    if ln < float(self.snap_beats) * 1.5:
                        ln = float(self._beats_per_bar())
                    x = s * self.pixels_per_beat
                    y = self.ruler_height + idx * self.track_height + 2
                    w = max(16.0, ln * self.pixels_per_beat)
                    h = float(self.track_height) - 4.0
                    ghost = QRectF(x, y, w, h)
                    p.setPen(QPen(self.palette().highlight().color()))
                    p.setBrush(QBrush(self.palette().alternateBase().color()))
                    p.setOpacity(0.55)
                    p.drawRect(ghost)
                    p.setOpacity(1.0)
            except Exception:
                p.setOpacity(1.0)

        # Clips
        for cid, rect, clip in self._clip_rects():
            is_sel = cid in self.selected_clip_ids if self.selected_clip_ids else (cid == self.selected_clip_id)

            base = self.palette().alternateBase() if clip.kind == "audio" else self.palette().window()
            p.fillRect(rect, QBrush(base))
            p.setPen(QPen(self.palette().text().color()))
            p.drawRect(rect)

            # Handles
            self._draw_handle_strips(p, rect, is_sel)

            # Preview region
            inner = rect.adjusted(8, 18, -8, -6)
            if inner.width() > 20 and inner.height() > 10:
                if clip.kind == "audio":
                    trk = next((t for t in tracks if t.id == clip.track_id), None)
                    vol = float(getattr(trk, "volume", 1.0) or 1.0) if trk else 1.0
                    self._draw_audio_waveform(p, inner, clip, vol)
                else:
                    self._draw_midi_preview(p, inner, clip)

            # Title + volume
            kind_tag = "AUDIO" if clip.kind == "audio" else "MIDI"
            label = str(getattr(clip, "label", "") or kind_tag)
            trk = next((t for t in tracks if t.id == clip.track_id), None)
            vol = float(getattr(trk, "volume", 1.0) or 1.0) if trk else 1.0
            _gain, db = self._display_gain_for_volume(vol)

            p.setPen(QPen(self.palette().text().color()))
            p.drawText(rect.adjusted(10, 2, -10, -2), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop, f"[ {kind_tag}: {label} ]")
            p.setPen(QPen(self.palette().mid().color()))
            p.drawText(rect.adjusted(10, 2, -10, -2), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop, f"VOL: {db:+.1f} dB")

            if is_sel:
                pen_sel = QPen(self.palette().highlight().color())
                pen_sel.setWidth(3)
                p.setPen(pen_sel)
                p.drawRect(rect.adjusted(1, 1, -1, -1))

        # Playline
        x = int(self.playhead_beat * self.pixels_per_beat)
        pen_play = QPen(Qt.GlobalColor.red)
        pen_play.setWidth(2)
        p.setPen(pen_play)
        p.drawLine(x, 0, x, self.height())
        p.end()

    # --- canvas size management

    def _update_minimum_size(self) -> None:
        tracks = self._tracks()
        width_beats = 0.0
        for c in self.project.ctx.project.clips:
            width_beats = max(width_beats, float(c.start_beats) + float(c.length_beats) + 4.0)
        # Also ensure loop end is visible
        width_beats = max(width_beats, float(self.loop_end) + 2.0)
        w = int(max(640, width_beats * self.pixels_per_beat))
        h = int(max(320, self.ruler_height + len(tracks) * self.track_height + 20))
        self.setMinimumSize(w, h)

    def _on_project_updated(self) -> None:
        # Keep snap division in sync with project (if present)
        try:
            div = str(getattr(self.project.ctx.project, "snap_division", "1/16") or "1/16")
            self.set_snap_division(div)
        except Exception:
            pass
        self._update_minimum_size()
        self.update()
