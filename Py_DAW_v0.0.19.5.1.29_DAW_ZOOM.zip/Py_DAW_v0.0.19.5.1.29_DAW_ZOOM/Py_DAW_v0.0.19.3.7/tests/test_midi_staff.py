import unittest

from pydaw.model.midi import MidiNote


class TestMidiStaffConversion(unittest.TestCase):
    def test_roundtrip_all_pitches(self):
        """Pitch -> staff -> pitch should roundtrip using the derived accidental."""
        for p in range(128):
            n = MidiNote(pitch=p, start_beats=0.0, length_beats=1.0, velocity=100)
            line, octave = n.to_staff_position()
            p2 = MidiNote.from_staff_position(line, octave, n.accidental)
            self.assertEqual(p, p2)

    def test_known_mappings(self):
        # C4
        n = MidiNote(pitch=60, start_beats=0.0, length_beats=1.0)
        line, octave = n.to_staff_position()
        self.assertEqual((line, octave, n.accidental), (0, 4, 0))

        # C#4
        n = MidiNote(pitch=61, start_beats=0.0, length_beats=1.0)
        line, octave = n.to_staff_position()
        self.assertEqual((line, octave, n.accidental), (0, 4, 1))

        # F#3 (54)
        n = MidiNote(pitch=54, start_beats=0.0, length_beats=1.0)
        line, octave = n.to_staff_position()
        self.assertEqual((line, octave, n.accidental), (3, 3, 1))

    def test_invalid_line_raises(self):
        with self.assertRaises(ValueError):
            MidiNote.from_staff_position(7, 4)


if __name__ == "__main__":
    unittest.main()
