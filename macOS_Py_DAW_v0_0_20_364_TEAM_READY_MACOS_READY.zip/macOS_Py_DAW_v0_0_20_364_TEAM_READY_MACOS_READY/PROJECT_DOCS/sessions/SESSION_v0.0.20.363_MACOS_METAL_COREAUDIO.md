# Session-Log: v0.0.20.363 — macOS Metal + CoreAudio Packaging

**Datum**: 2026-03-09
**Bearbeiter**: GPT-5
**Aufgabe**: macOS Build/Packaging hardenen (Metal + CoreAudio), ohne DAW-Core zu verändern
**Ausgangsversion**: v0.0.20.362 (ZIP), VERSION-Datei war noch 0.0.20.361
**Ergebnisversion**: 0.0.20.363

## Ziele

1) macOS soll out-of-the-box mit **CoreAudio** laufen (sounddevice/PortAudio)
2) `PYDAW_GFX_BACKEND=auto` soll auf macOS **Metal** wählen (Qt RHI), Fallback OpenGL
3) pip-Install darf auf macOS nicht an JACK/py3.13 Details scheitern
4) Crash-Guard: `add_track(name=...)` muss auch in AltProjectService ausgeschlossen sein
5) Plugin-Setup-Doku für macOS bereitstellen

## Umgesetzte Änderungen (safe)

### Graphics (Metal)
- `pydaw/utils/gfx_backend.py`
  - neues Backend `metal`
  - `auto` ⇒ macOS: `metal`, Linux: `vulkan` wenn Loader vorhanden, sonst `opengl`
  - setzt `QT_QUICK_BACKEND=rhi` + `QSG_RHI_BACKEND=metal|vulkan|opengl`

### Audio (CoreAudio)
- `pydaw/audio/audio_engine.py`
  - best-effort HostAPI Auswahl auf macOS: **CoreAudio**
  - Validierung: gespeicherte `output_device` ID wird geprüft → sonst Fallback `None`

### Installer / Requirements
- `requirements.txt`
  - `JACK-Client` nur noch `platform_system=="Linux"`
  - `audioop-lts` nur noch `python_version>=3.13`
- `install.py`
  - macOS: optionales Homebrew Setup (best-effort) für `portaudio`, `libsndfile`, `fluidsynth` + optional LV2 Tooling

### Crash-Guard
- `pydaw/services/altproject_service.py`
  - `add_track(...)-> Track` + `return trk`

### Dokumentation
- `docs/macOS_Audio_Plugins_Setup.md`

## Tests

- ✅ `python -m py_compile` für modifizierte Dateien

## Nächste sichere Schritte

- [ ] UI-only: Hinweis im Audio Settings Dialog, wenn macOS/CoreAudio aktiv ist.
