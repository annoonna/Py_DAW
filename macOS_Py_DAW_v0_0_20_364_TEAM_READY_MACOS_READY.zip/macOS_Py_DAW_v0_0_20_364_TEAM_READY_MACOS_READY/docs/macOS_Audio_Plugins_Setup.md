# macOS: LV2 / LADSPA / DSSI Plugins sauber installieren (Apple Silicon & Intel)

Stand: 2026-03-09  
Format: Markdown – basierend auf dem bisherigen Projekt-/Chatverlauf, bereinigt in eine saubere Reihenfolge.

---

## Ziel

Diese Anleitung zeigt, wie man auf macOS Audio-Plugins im **Linux-nativen Plugin-Umfeld** installiert, prüft und für ChronoScaleStudio / Py_DAW sichtbar macht.

Schwerpunkte:

- Homebrew auf macOS
- Apple Silicon (M1 / M2 / M3 / M4) als bevorzugte Zielplattform
- stabile LV2-Installation + praktikable Plugin-Sammlungen
- typische Stolperfallen (ARM vs Intel, Rosetta, Gatekeeper)

---

## Kurzfazit

### Was auf macOS zuverlässig funktioniert

- **LV2 Basis über Homebrew**
- **mda-lv2** über Homebrew (kleine, stabile LV2-Sammlung)
- große Plugin-Sammlungen als **DISTRHO / PawPaw** Installer
- Symlinks in die Standardpfade:
  - `~/Library/Audio/Plug-Ins/LV2`
  - `/Library/Audio/Plug-Ins/LV2`

### Was auf macOS oft problematisch ist

- **LADSPA**: historisch Linux-zentriert; Homebrew-Formeln sind häufig Linux-only
- alte Linux-Audio-Taps, die Intel-Flags (z.B. `-msse`) voraussetzen → scheitert auf ARM

**Merke:** Wenn du viele klassische Linux-Plugins willst, ist der praktikable Weg:

1) `lv2` + `mda-lv2` via Homebrew
2) große Sammlungen via **PawPaw / DISTRHO**
3) Pfade + Symlinks setzen → DAW neu scannen

---

## Begriffe kurz erklärt

### LADSPA
Sehr alter Linux-Standard. Auf modernen Macs kaum noch komfortabel.

### DSSI
Erweiterung von LADSPA, ebenfalls historisch.

### LV2
Moderner Nachfolger. Auf macOS die sinnvollste Wahl, wenn man Linux-nahe Plugin-Formate nutzen möchte.

---

## Standard-Verzeichnisse

| Format | Endung | Systemweiter Pfad | Benutzer-Pfad |
| :--- | :--- | :--- | :--- |
| **LV2** | `.lv2` | `/Library/Audio/Plug-Ins/LV2` | `~/Library/Audio/Plug-Ins/LV2` |
| **VST3** | `.vst3` | `/Library/Audio/Plug-Ins/VST3` | `~/Library/Audio/Plug-Ins/VST3` |
| **VST2** | `.vst` | `/Library/Audio/Plug-Ins/VST` | `~/Library/Audio/Plug-Ins/VST` |
| **LADSPA** | `.so`/`.dylib` | `/Library/Audio/Plug-Ins/LADSPA` | `~/.ladspa` |
| **DSSI** | `.so` | `/Library/Audio/Plug-Ins/DSSI` | `~/.dssi` |

> Hinweis: Py_DAW fokussiert aktuell primär auf LV2/LADSPA Hosting im Linux-Kontext.
> Auf macOS ist LV2 der robuste Weg.

---

## Apple Silicon: Vorab-Check (Rosetta vermeiden)

```bash
uname -m
sysctl -in sysctl.proc_translated 2>/dev/null || echo 0
```

- `uname -m` sollte `arm64` sein.
- `proc_translated` sollte `0` sein (bei `1` läuft das Terminal unter Rosetta).

**Wichtig:** Python-Architektur und Brew-Architektur sollten zusammenpassen.

- Apple Silicon Brew: `/opt/homebrew`
- Intel Brew: `/usr/local`

---

## Installation via Homebrew (LV2 Basis)

### 1) Ordner anlegen

```bash
mkdir -p ~/Library/Audio/Plug-Ins/LV2
sudo mkdir -p /Library/Audio/Plug-Ins/LV2
```

### 2) LV2 Basis + MDA Plugins installieren

```bash
brew install lv2
brew install mda-lv2
```

Prüfen:

```bash
brew info lv2
brew info mda-lv2
brew list lv2
brew list mda-lv2
brew --prefix mda-lv2
ls -l "$(brew --prefix mda-lv2)/lib/lv2"
```

### 3) Homebrew LV2 Bundles verlinken

Apple Silicon:

```bash
ln -snf /opt/homebrew/lib/lv2/* ~/Library/Audio/Plug-Ins/LV2/
sudo ln -snf /opt/homebrew/lib/lv2/* /Library/Audio/Plug-Ins/LV2/
```

Intel:

```bash
ln -snf /usr/local/lib/lv2/* ~/Library/Audio/Plug-Ins/LV2/
sudo ln -snf /usr/local/lib/lv2/* /Library/Audio/Plug-Ins/LV2/
```

Prüfen:

```bash
ls -F ~/Library/Audio/Plug-Ins/LV2/
ls -F /Library/Audio/Plug-Ins/LV2/
```

---

## Umgebungsvariablen (optional, aber hilfreich)

In `~/.zshrc` (nutzt automatisch dein Brew-Prefix):

```bash
BREW_PREFIX="$(brew --prefix)"

# LV2 Pfade
export LV2_PATH="$LV2_PATH:$BREW_PREFIX/lib/lv2:$HOME/Library/Audio/Plug-Ins/LV2:/Library/Audio/Plug-Ins/LV2"

# LADSPA Pfade (nur falls du wirklich LADSPA-Bundles nutzt)
export LADSPA_PATH="$LADSPA_PATH:$BREW_PREFIX/lib/ladspa:$HOME/.ladspa:/Library/Audio/Plug-Ins/LADSPA"
```

Aktivieren:

```bash
source ~/.zshrc
```

---

## Große Plugin-Sammlungen: DISTRHO / PawPaw

Viele Linux-zentrierte Plugins bauen auf Apple Silicon nicht sauber via Homebrew.
Daher ist der **robuste Weg**: fertige macOS Installer.

Release-Seite:

- https://github.com/DISTRHO/PawPaw/releases

Empfohlen:

- `PawPaw-macOS-universal-*.pkg`

Installation:

```bash
cd ~/Downloads
ls PawPaw*
sudo installer -pkg PawPaw-macOS-universal-v1.1.0.pkg -target /
```

Danach prüfen:

```bash
ls /Library/Audio/Plug-Ins/LV2 | wc -l
ln -snf /Library/Audio/Plug-Ins/LV2/* ~/Library/Audio/Plug-Ins/LV2/
ls ~/Library/Audio/Plug-Ins/LV2 | wc -l
```

---

## Gatekeeper / Quarantäne (Problembehandlung)

macOS blockiert manchmal Plugins, die nicht “notarized” sind.

1) Plugin installieren/kopieren
2) DAW starten (Scan kann fehlschlagen)
3) **Systemeinstellungen → Datenschutz & Sicherheit**
4) Unten bei **Sicherheit**: „Dennoch öffnen“
5) DAW neu starten / Rescan

Optional kann das Entfernen des Quarantäne-Flags helfen (nur wenn du der Quelle vertraust):

```bash
xattr -dr com.apple.quarantine "/Library/Audio/Plug-Ins/LV2/DEIN_PLUGIN.lv2"
```

---

## Nützliche Befehle

### Py_DAW LV2 Probe Cache löschen

```bash
rm -f ~/.cache/ChronoScaleStudio/lv2_probe_cache.json
```

### GitHub Verbindung testen (falls brew tap hängt)

```bash
curl -I https://github.com
```

---

## Empfehlung zum Schluss

**Empfohlener Hauptweg (Apple Silicon):**

- `brew install lv2 mda-lv2`
- Symlinks in `~/Library/Audio/Plug-Ins/LV2` und `/Library/Audio/Plug-Ins/LV2`
- große Sammlungen via **PawPaw / DISTRHO**
- DAW neu starten + Plugin-Rescan

Diese Doku bildet bewusst den **praktisch getesteten** Verlauf ab – inklusive Stolperfallen,
damit man dieselben Sackgassen nicht erneut durchläuft.
