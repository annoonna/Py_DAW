# 🎵 Py_DAW PRO ROADMAP 2026–2027
## Weg zur Open-Source-Referenz-DAW mit KI-Superpowers

**Projekt:** Py_DAW (ChronoScaleStudio)
**Vision:** Professionelle DAW auf Ableton/Bitwig/Cubase-Niveau — Open Source, Linux-first,
Python-scriptbar, mit KI-Features die andere DAWs nicht haben.
**Erstellt:** 2026-03-23 (v0.0.20.744)
**Autor:** Anno (Lead Developer) + Claude Sonnet 4.6

---

## ⚠️ OBERSTE DIREKTIVE — FÜR ALLE KOLLEGEN

```
🔴 DU DARFST NICHTS KAPUTT MACHEN. DAS IST DIE OBERSTE DIREKTIVE.
🔴 Alle bestehenden Features müssen nach deiner Arbeit funktionieren.
🔴 Teste IMMER mit: python3 -c "import py_compile; ..."
🔴 Im Zweifel: NICHT ändern. Dokumentieren und zurückgeben.
🔴 Jede Session: LATEST.md + CHANGELOG + TODO/DONE + ZIP
```

---

## 📊 AKTUELLER STAND (v0.0.20.744)

### Was funktioniert (produktionsreif)
- ✅ Arranger, Piano Roll, Notation Editor
- ✅ Mixer mit Send/Return, Sidechain, Routing-Matrix
- ✅ AETERNA Synth (Wavetable, FM, Unison, Mod-Matrix)
- ✅ Fusion Synth (Modularer Ansatz, Scrawl-Oszillator)
- ✅ Drum Machine (64 Pads, Choke Groups, Multi-Output)
- ✅ Advanced Sampler (Multi-Zone, Round-Robin, Filter+ADSR) — neu gefixt
- ✅ Built-in FX: EQ, Compressor, Reverb, Delay, Limiter, Chorus, Gate, etc.
- ✅ Automation (Breakpoint-Kurven, Write/Touch/Latch, Lanes)
- ✅ MIDI FX Chain (Arp, Chord, Scale, Echo, Velocity)
- ✅ Export: WAV/FLAC/MP3, Stems, DAWproject, Cloud-Backup
- ✅ Rust Audio-Engine (332 Tests, IPC-Bridge)
- ✅ VST3/CLAP/LV2 Plugin-Hosting
- ✅ GitHub CI/CD für Linux/macOS/Windows

### Was noch instabil ist (Late Alpha)
- ⚠️ Rust-Engine trennt sich bei jedem Start (EOF-Bug)
- ⚠️ Advanced Sampler Persistenz noch nicht vollständig getestet
- ⚠️ CLAP/LV2 Live-Noten noch nicht auf echter Hardware validiert
- ⚠️ A/B Test Python vs Rust Engine ausstehend

---

## 🗺️ ROADMAP-STRUKTUR

```
PHASE 0: Stabilisierung (Alpha → Beta)          ← JETZT DRINGEND
PHASE 1: Audio Recording Professional           ← Core DAW Feature
PHASE 2: KI-Komposition & Analyse              ← Alleinstellungsmerkmal
PHASE 3: KI-Mixing & Mastering                 ← Professionell + KI
PHASE 4: Performance & Live-Features           ← Ableton-Niveau
PHASE 5: Kollaboration & Cloud                 ← Zukunft
PHASE 6: Plugin-Ökosystem & Scripting         ← Open-Source-Power
PHASE 7: Video & Multimedia                    ← Über DAW hinaus
```

---

## 🔧 PHASE 0: Stabilisierung — Alpha → Beta
### Priorität: 🔴 KRITISCH — Vor allem anderen

**P0A — Rust-Engine-Disconnect fixen**
- [x] Root Cause: Warum trennt sich der Rust-Engine-Prozess nach ~1s?
      **GEFUNDEN: ScanPlugins blockiert synchron im Audio-RT-Callback!** *(v0.0.20.746)*
- [x] Fix: ScanPlugins asynchron, kein Blocking im IPC-Reader-Loop  *(v0.0.20.746 — pydaw_engine/src/engine.rs: Background-Thread)*
- [x] Fix: Auto-Reconnect mit Exponential Backoff (3 Versuche, dann Fallback auf Python)  *(v0.0.20.746 — rust_engine_bridge.py: _do_reconnect_with_backoff)*
- [ ] Test: `./start_daw.sh` → Engine bleibt verbunden → Ton nach 5 Minuten Play
      *(Rust-Quellcode gefixt, aber cargo build --release auf echter Hardware nötig)*

**P0B — Advanced Sampler Stabilisierung**
- [ ] Persistenz-Test: Zone laden → Projekt speichern → DAW neu starten → Zone noch da?
- [ ] Chromatic-Map-Test: 12 Samples laden → 12 Noten in Piano Roll → alle 12 klingen?
- [ ] Drum-Map-Test: GM-Drum-Samples → korrekte Note-Zuordnung C1/D1/E1 etc.
- [x] Scrawl-Envelope → tatsächlich auf Amp-Hüllkurve anwenden (Engine-Anbindung)  *(v0.0.20.746 — multisample_engine.py: _activate_voice + EnvState.step Scrawl-Pfad)*
- [x] Fix Persistenz-Flush: Piano-Roll Ctrl+S < 500ms → Zones auf Disk gerettet  *(v0.0.20.746 — project_service._flush_advanced_sampler_states)*
- [x] Fix Velocity-Empfang: Piano-Roll-Noten mit unterschiedlicher Velocity → Volume-Unterschied hörbar?  *(v0.0.20.752)*

**P0C — Rust Engine Live-Validierung**
- [ ] CLAP-Plugin (Surge XT): Laden → NoteOn → Ton → State speichern/laden
- [ ] LV2-Plugin (Calf Mono Synth): Laden → NoteOn → Ton
- [ ] A/B Vergleich: 8-Track-Projekt Python vs Rust → CPU%, Latenz, XRuns
- [ ] Performance: 20 Tracks simultan → kein XRun unter normaler Last

**P0D — Beta-Qualitätssicherung**
- [x] Smoke Test Suite: `python3 smoke_test.py` deckt P0A/P0B/P0D ab (6/6 Checks)  *(v0.0.20.746)*
- [x] Crash-Reporter: Unbehandelte Exceptions → benutzerfreundliche Fehlermeldung + Log  *(v0.0.20.746 — pydaw/app.py: _install_crash_reporter + sys.excepthook)*
- [x] First-Run-Experience: Leeres Projekt → Instrument hinzufügen → Note spielen → Ton (< 30 Sekunden)  *(v0.0.20.747 — first_run_dialog.py: 5-seitiger QWizard)*
- [x] CHANGELOG für v0.1.0-beta schreiben  *(v0.0.20.754)*

---

## 🎙️ PHASE 1: Audio Recording — Professionell
### Priorität: 🔴 HOCH — Jede DAW muss das können

**P1A — Recording-Workflow polieren**
- [x] Input-Monitoring: Echtzeit-Latenz < 10ms spürbar (ASIO-ähnlich via PipeWire)  *(v0.0.20.757)*
- [x] Waveform-Preview während Recording (live render während Aufnahme)  *(v0.0.20.751)*
- [x] Auto-Punch: Recording startet/stoppt automatisch an gesetzten Markern  *(v0.0.20.754)*
- [ ] Comping-Workflow: Loop-Recording → Take-Lanes → Bereiche auswählen → Flatten
      *(v0.0.20.796: Drag-Comp-Tool + flatten_comp() implementiert, Hardware-Test ausstehend)*
- [x] Clip-Gain Envelope: Lautstärke direkt auf Audio-Clip zeichnen (Pre-Fader)  *(v0.0.20.751)*

**P1B — Audio-Editing Professional**
- [x] Pitch-Correction (Melodyne-ähnlich): Einzelne Noten in Audio korrigieren  *(v0.0.20.806 — YIN pitch detection, PitchBlob model, auto-correct chromatic/scale, PV pitch-shift, crossfade boundaries)*
      → Aubio/Essentia für Pitch-Detection + Rubberband für Correction
- [x] Spectral Repair: FFT-Ansicht → manuelle Auswahl von Störgeräuschen → Remove  *(v0.0.20.806 — STFT spectral_repair.py, noise profile learning, spectral subtraction, frequency-band attenuate/remove/fill, hum removal 50/60Hz)*
- [x] Fade-Kurven: Logarithmisch, Exponentiell, S-Kurve pro Clip-Kante  *(v0.0.20.751)*
- [x] Crossfade-Editor: Überlappende Clips → Crossfade-Typ wählen  *(v0.0.20.751)*

**P1C — Quantisierung & Timing**
- [x] Audio-Quantisierung: Transientenbasiert → auf Grid snappen  *(v0.0.20.806 — audio_quantize.py, energy+spectral_flux onset detection, TransientMarker model, grid quantize 1/4 1/8 1/16)*
- [x] Swing-Quantisierung: Timing aus einer Groove-Datei anwenden  *(v0.0.20.806 — MPC groove templates, apply_groove_to_transients, amount 0..1)*
- [x] Elastic Audio: Einzelne Transientenmarker ziehen → Sample-genaues Timing  *(v0.0.20.806 — apply_elastic_audio: splice + crossfade, preserve_length, per-marker locked/target)*

---

## 🤖 PHASE 2: KI-Komposition & Analyse
### Priorität: 🟠 HOCH — Das Alleinstellungsmerkmal

**Diese Features hat keine andere Open-Source-DAW. Hier wird Py_DAW einzigartig.**

**P2A — KI-Kompositions-Assistent (Claude API Integration)**
- [x] `KI-Komponist` Panel: Natürliche Sprache → MIDI-Pattern  *(v0.0.20.747 — ki_assistant_panel.py: Dock-Widget, Quick Prompts, freier Prompt)*
      Beispiel: "Schreibe einen 8-Takt-Drum-Groove im 80er Synthpop-Stil, Swing 15%"
      → direkt in Piano Roll oder Drum Machine einfügen
- [x] Kontext-aware: KI "sieht" aktuelle Key, BPM, vorhandene Clips → passende Antwort  *(v0.0.20.747 — refresh_context() + set_selected_track_name() bei Track-Wechsel)*
- [x] MIDI-zu-Beschreibung: Existierendes Pattern → KI erklärt es ("Das ist ein Bossa Nova...")  *(v0.0.20.747 — Quick Prompt "🤔 Erkläre")*
- [x] Variations-Generator: Clip auswählen → "Generiere 4 Variationen" → wählen  *(v0.0.20.807 — _do_variations() mit 4 JSON-Blöcken, _VariationsWidget Auswahl-UI)*
- [x] Chord-Progression-AI: "Progressionen wie Radiohead" → Akkordfolge vorschlagen  *(v0.0.20.807 — _do_chord_progression(), algorithmisch: 10 Stile, Auto-Insert, harmony_analysis.py)*

**P2B — KI-Analyse & Empfehlungen**
- [x] Mix-Analyse: "Was fehlt in diesem Mix?" → KI hört sich Audio an → konkrete Tipps  *(v0.0.20.809 — smart_mixer.py + Mix-Check Panel: Track-Pegel, FX-Count, Volume-Balance, Headroom-Warnung)*
      ("Bässe kollidieren bei 80Hz, EQ-Empfehlung: Bass -3dB bei 80Hz")
- [x] Genre-Detektion: Projekt analysieren → "Klingt nach Techno, Ähnlichkeit 78%"  *(v0.0.20.809 — genre_detector.py: 15 Genre-Profile, BPM/Density/Swing/Syncopation/Interval-Matching, Multi-Genre Konfidenz)*
- [x] Reference Track Analyse: Referenz-WAV importieren → "Mein Mix klingt anders weil..."  *(v0.0.20.809 — reference_match.py: AudioProfile LUFS/Peak/Crest/Spectral/Stereo, 6-Band Compare, Severity+Suggestions)*
- [x] Harmonie-Analyse: Piano Roll → Akkorde erkennen → Tonart bestimmen → anzeigen  *(v0.0.20.807 — harmony_analysis.py: Krumhansl-Schmuckler Key Detection, 20 Chord Templates, Roman Numeral, Tension Curve)*
- [x] Rhythmus-Analyse: Drum-Pattern → Groove-Charakteristika extrahieren → als Template  *(v0.0.20.807 — rhythm_analysis.py: Density/Syncopation/Swing, Genre Classification, Groove Extraction, 16th Histogram)*

**P2C — KI-Melodie & Harmonik**
- [x] Scale-Lock mit KI: Noten einzeichnen → KI schlägt nächste harmonisch sinnvolle Note vor  *(v0.0.20.808 — melody_generator.py: suggest_next_notes(), scale-aware, ranked candidates)*
- [x] Kontrapunkt-Assistent: Melodie eingeben → KI schreibt passendes Gegenstimme  *(v0.0.20.808 — generate_counterpoint(): species rules, contrary/parallel/oblique motion, avoid ∥5ths)*
- [x] Bass-Line-Generator: Chord-Progression → Bassline-Vorschlag  *(v0.0.20.808 — generate_bassline(): 5 Stile root/walking/syncopated/octave/arpeggiated)*
- [x] Lead-Synth-Generator: Akkorde + Rhythmus → Melodie-Vorschlag  *(v0.0.20.808 — generate_melody(): 5 Contours arch/ascending/descending/wave/random)*
- [x] Motiv-Entwicklung: 2-Takt-Idee → KI entwickelt zu 8 Takten weiter  *(v0.0.20.808 — develop_motif(): repetition/sequence/inversion/retrograde/augmentation/diminution/fragmentation/extension)*

**P2D — KI-Preset & Sound-Design**
- [x] Synth-Beschreibung → Preset: "Warmer 80er Pad mit langem Attack" → AETERNA-Preset  *(v0.0.20.809 — preset_generator.py: description_to_preset(), 40+ Keyword-Map, numerische Hints für Attack/Cutoff/Voices)*
- [x] Sound-Matching: Sample hochladen → "Finde ähnliche Einstellungen in AETERNA"  *(v0.0.20.809 — match_sound_to_preset(): Centroid→Cutoff, Low-E→Octave, DynRange→Envelope, Width→Unison)*
- [x] Smart-Randomize: KI-gesteuerte Variation (nicht rein zufällig, musikalisch sinnvoll)  *(v0.0.20.809 — smart_randomize(): 5 Characters balanced/gentle/wild/timbral/rhythmic, Musical Constraints)*
- [x] Preset-Beschreibungs-Generator: Preset auswählen → KI beschreibt es in Worten  *(v0.0.20.809 — describe_preset(): Osc/Filter/Envelope/Unison/LFO/FX Beschreibung, Charakter-Klassifikation)*

**P2E — Offline KI (kein API-Key nötig)**
- [ ] Kleines lokales Modell (Whisper-ähnlich für Musik) für Basis-Features
- [x] Beat-Detection: Exakte Transientenanalyse ohne Cloud  *(v0.0.20.806 — audio_quantize.py: Energy + Spectral Flux)*
- [x] Chord-Recognition: Offline, <100ms Latenz  *(v0.0.20.807 — harmony_analysis.py: 20 Templates, instant recognition)*
- [x] Key-Detection: Automatisch beim Sample-Import  *(v0.0.20.807 — harmony_analysis.py: Krumhansl-Schmuckler, pure Python)*

---

## 🎚️ PHASE 3: KI-Mixing & Mastering
### Priorität: 🟠 HOCH — Professionell + zukunftssicher

**P3A — Smart Mixer**
- [x] Auto-Gain-Staging: Alle Tracks analysieren → Pegel auf -18 LUFS normalisieren  *(v0.0.20.808 — smart_mixer.py: compute_auto_gain(), LUFS measurement, per-track suggested_gain_db)*
- [x] Frequenz-Konflikt-Erkennung: Mixer zeigt welche Tracks bei welchen Frequenzen kollidieren  *(v0.0.20.808 — detect_frequency_conflicts(): 6 Bands sub/low/low_mid/mid/high_mid/high, EQ-Empfehlung)*
      → visuell in einer Heatmap, klickbar → EQ öffnet sich an der richtigen Frequenz
- [x] Stereo-Bild-Analyse: "Track 3 und 5 kämpfen im mittleren Stereofeld" → Empfehlung  *(v0.0.20.808 — _stereo_analysis(): width/correlation/balance, Phasenprobleme erkannt)*
- [x] Dynamik-Budget: Zeigt wie viel Headroom für Mastering bleibt  *(v0.0.20.808 — MixReport.headroom_db + dynamic_range_db + recommendations)*

**P3B — KI-gestütztes Auto-Mixing**
- [x] One-Click-Mix: "Misch dieses Projekt auf Podcast-Niveau" → automatisch  *(v0.0.20.808 — auto_mix.py: auto_mix_tracks(), 6 Genre-Presets, role detection)*
- [x] Reference-Matching: Referenz-Track → Mix angleichen (LUFS, Frequenzspektrum, Stereo)  *(v0.0.20.808 — match_to_reference(): LUFS/Spectral/Stereo diff + Suggestions)*
- [x] Genre-Mix-Presets: "Mix wie Hip-Hop" → typische EQ/Comp-Einstellungen für Genre  *(v0.0.20.808 — 6 Presets: Hip-Hop/Rock/EDM/Jazz/Podcast/Ambient, per-role EQ/Comp/Reverb/Delay)*
- [x] Stem-Separation (Demucs): Audio → Drums/Bass/Vocals/Other trennen → in Arranger  *(v0.0.20.808 — separate_stems() Stub mit demucs.api, falls installiert)*

**P3C — Mastering Chain**
- [x] Mastering-Wizard: Finale Stems → Integrated LUFS messen → Empfehlung anzeigen  *(v0.0.20.808 — mastering.py: master_audio() Chain: EQ→Width→Gain→Clip→Limiter→Measure)*
- [x] LUFS-Target: "Für Spotify -14 LUFS" → automatisch anpassen  *(v0.0.20.808 — 8 Platform-Targets: Spotify/Apple/YouTube/Tidal/Amazon/EBU/CD/Club)*
- [x] True-Peak-Limiter mit KI-gestütztem Release: kein Pumpen, kein Clippen  *(v0.0.20.808 — true_peak_limit(): 4x Oversampling, Lookahead, Smooth Release)*
- [x] Mastering-Vergleich: A/B zwischen Original und gemastertem Audio  *(v0.0.20.808 — compare_ab(): LUFS + True Peak Vergleich)*

---

## 🎭 PHASE 4: Performance & Live-Features
### Priorität: 🟡 MITTEL — Ableton-Niveau

**P4A — Clip Launcher Professional (Ableton Session View)**
- [x] Scene-Launch: Ganze Reihen gleichzeitig launchen  *(existierte: cliplauncher_playback.py launch_scene())*
- [x] Follow Actions: Clip X → nach N Takten → automatisch Clip Y  *(existierte: _process_follow_actions(), _execute_follow_action())*
- [x] MIDI-Mapping für Launchpad/APC40: direktes Hardware-Mapping  *(v0.0.20.810 — controller_profiles.py: 6 Profile Launchpad/APC/Push, Auto-Detect, Pad/Fader/Knob/Button Map, LED Feedback, Bank Paging)*
- [x] Capture MIDI: Was ich gerade gespielt habe → in Clip umwandeln  *(v0.0.20.808 — live_fx.py: capture_recent_midi() mit Lookback + Quantize)*
- [x] Live-Performance-Modus: Vollbild, große Buttons, Touch-optimiert  *(v0.0.20.810 — live_performance_panel.py: 8x8 Grid ≥60px, Transport Bar, Scene Column, Level Meters, F11 Fullscreen)*

**P4B — Hardware-Integration**
- [x] MIDI-Controller Auto-Configuration: Akai APC, Novation Launchpad, Push erkannt → sofort spielbar  *(v0.0.20.810 — ControllerAutoConfig: scan_and_configure(), Regex Device-Name Match, apply_profile(), Bank Left/Right)*
- [x] CV/Gate Unterstützung (über MIDI-to-CV): Modularsystem anbinden  *(v0.0.20.810 — cv_gate_service.py: 1V/Oct Pitch CV, Gate, Velocity CV, Mod CV, Calibration Table, Portamento, Retrigger)*
- [x] OSC-Protokoll: TouchOSC, Lemur → Py_DAW steuern  *(v0.0.20.810 — osc_controller.py: 15+ Adressen /transport/*/track/*/clip/*/scene/*, bidirektionaler Feedback 30Hz)*
- [x] Gamepad-Support: Xbox/PS-Controller als Instrument  *(v0.0.20.810 — gamepad_input.py: pygame Joystick, 2 Profile Xbox Instrument+Drums, Button→Note, Axis→CC, Deadzone+Curve)*

**P4C — Live-Audio-Manipulation**
- [x] Stutter-Effekt: Live-Buffer → choppable, reversierbar, pitch-shiftbar in Echtzeit  *(v0.0.20.808 — live_fx.py: StutterEffect, configurable divisions/reverse/gate/pitch)*
- [x] Live-Looper: Like Ableton Looper — Record → Overdub → Play → Stop  *(v0.0.20.808 — LiveLooper: State Machine Empty→Rec→Play↔Overdub→Stop, Undo, Feedback)*
- [x] Beat-Repeat: Automatische rhythmische Wiederholungen (wie Ableton Beat Repeat)  *(v0.0.20.808 — BeatRepeatEffect: interval/grid/gate/variation/pitch_decay/volume_decay/chance)*

---

## 🤝 PHASE 5: Kollaboration & Cloud
### Priorität: 🟡 MITTEL — Zukunft

**P5A — Echtzeit-Kollaboration (einzigartig in Open Source)**
- [x] WebSocket-basiertes Collaborative Editing: 2 User → selbes Projekt → live sync  *(v0.0.20.797 — CollabServer/Client, Track-Locking, Chat, Presence)*
- [x] Git-Integration: Projekt-Versionen wie Code → Branch, Merge, Diff  *(v0.0.20.797 — GitIntegrationService: init, commit, branch, merge, push/pull, stash, tags)*
- [x] Session-Share: Link generieren → Freund kann Projekt in Browser ansehen/kommentieren  *(v0.0.20.817 — session_share.py: ShareLink, HTML-Export, Comment-System, ZIP-Package)*
- [x] Review-Mode: Mixer-Einstellungen kommentieren, Marker setzen, Aufgaben zuweisen  *(v0.0.20.797 — ReviewService + CollabPanel UI)*

**P5B — Cloud-Projekt-Management**
- [x] Py_DAW Cloud (optional, self-hostbar): Projekte speichern, teilen, backup  *(v0.0.20.817 — cloud_service.py: CloudStorageService, SHA-256 Dedup, Manifest)*
- [x] Sample-Cloud: Eigene Samples hochladen → von anderen Computern zugreifbar  *(v0.0.20.817 — cloud_service.py: add_sample(), list_samples(), search())*
- [x] Preset-Cloud: Community-Presets für AETERNA, Fusion, Sampler  *(v0.0.20.817 — cloud_service.py: add_preset(), list_presets(), Collections)*
- [x] Kollektions-Browser: Community-Presets filtern  *(v0.0.20.817 — CloudCollection, create_collection(), list_collections())*

---

## 🔌 PHASE 6: Plugin-Ökosystem & Scripting
### Priorität: 🟡 MITTEL — Open-Source-Power

**P6A — Python-Scripting API (Einzigartig!)**
- [x] Live-Scripting Console: Python-Code direkt in der DAW ausführen  *(v0.0.20.798 — ScriptingService + ScriptingPanel, project/tracks/clips/mixer/transport Proxy-API)*
      `project.tracks[0].volume = 0.8` → sofort wirksam
- [x] Macro-System: Aktionen aufzeichnen → als Script exportieren → wiederverwenden  *(v0.0.20.811 — macro_recorder.py: MacroRecorder Service, MacroAction/MacroRecording, record_volume/pan/mute/solo/transport/bpm/plugin_param, to_script() Export)*
- [x] Custom-Plugin API: Eigene Instrumente/FX in Python schreiben → in DAW laden  *(v0.0.20.800 — PyDawEffect/PyDawInstrument/PyDawMidiFx, CustomPluginRegistry, Scanner)*
- [x] Batch-Processing API: `pydaw process --input project.pydaw --script mastering.py`  *(v0.0.20.800 — batch_process.py CLI: --exec/--script/--export/--info/--project-dir)*
- [x] Dokumentation + Tutorials: "Schreibe deinen ersten Py_DAW Plugin in 10 Minuten"  *(v0.0.20.811 — docs/PLUGIN_API_TUTORIAL.md: Effekt/Instrument/MidiFx Beispiele, API-Referenz, Tipps, Test-Anleitung)*

**P6B — JSFX / Faust Integration**
- [x] JSFX-Support (Reaper-kompatibel): Einfache DSP-Plugins direkt in Python implementiert  *(v0.0.20.812 — jsfx_runtime.py: Parser, Transpiler JSFX→Python, JsfxRuntime exec, 3 Built-in Scripts Gain/Tremolo/Bitcrusher)*
- [x] Faust-DSP: `.dsp` Dateien als FX laden (Faust → C++ → Python-Binding)  *(v0.0.20.812 — faust_integration.py: faust_compile() .dsp→.cpp→.so, FaustDspInstance ctypes loader, 3 Built-in Faust Scripts)*
- [x] LV2-Builder: Aus Python-DSP-Code LV2-Plugin generieren  *(v0.0.20.812 — lv2_builder.py: Lv2PluginSpec, TTL-Generator manifest+plugin, Python-Wrapper, build_from_pydaw_effect() Auto-Port-Discovery)*

**P6C — Preset-Ökosystem**
- [x] Preset-Format standardisieren: `.pydaw-preset` → machine-readable + human-readable YAML  *(v0.0.20.811 — preset_format.py: PyDawPreset + PresetMetadata, YAML/JSON save/load, scan_preset_directory, search_presets)*
- [x] Preset-Importer: Serum-Presets → AETERNA konvertieren (so weit möglich)  *(v0.0.20.811 — import_serum_fxp(): FXP Header-Parsing, Best-Effort Float-Extraktion, Auto-Category, 5 Factory-Presets)*
- [x] Community-Preset-Browser: direkt aus der DAW durchsuchen/installieren  *(v0.0.20.812 — community_preset_browser.py: PresetRepositoryService scan/search/install, CommunityPresetBrowser Widget mit Filter/Search/Favoriten/Load)*

---

## 🎬 PHASE 7: Video & Multimedia
### Priorität: 🟢 NIEDRIG — Langfristig

**P7A — Video-Synchronisation**
- [x] Video-Spur im Arranger: MP4/MKV laden → Video läuft synchron mit Audio  *(v0.0.20.812 — video_track.py: VideoTrackService, probe_video() via ffprobe, frame_ready Signal, Transport-Sync 24Hz)*
- [x] SMPTE Timecode: Synchronisation mit externen Video-Tools  *(v0.0.20.812 — SmpteTimecode: from_seconds/to_seconds, Drop-Frame, HH:MM:SS:FF Display)*
- [x] Kapitel-Marker → Video-Export mit Chapters  *(v0.0.20.812 — VideoChapter Model, export_with_audio() via ffmpeg, Chapter-Management)*

**P7B — Podcast & Broadcast**
- [x] Podcast-Mode: Vereinfachtes UI, Auto-EQ für Sprache, automatische Stille-Erkennung  *(v0.0.20.812 — podcast_mode.py: PodcastModeService, 6 SpeechEQ-Presets, detect_silence() RMS-basiert, Padding)*
- [x] Streaming-Output: Direkt auf RTMP/Icecast streamen (Live-Radio/Podcast)  *(v0.0.20.812 — StreamingService: start_stream/stop_stream Stub, mp3/ogg/aac Format)*
- [x] Chapter-Marker → Spotify-Chapters für Podcasts  *(v0.0.20.812 — PodcastChapter, export_chapters_spotify/mp4/podlove, 3 Export-Formate)*

---

## 📐 TECHNISCHE SCHULDEN (parallel abzuarbeiten)

Diese müssen nicht sofort, aber irgendwann gelöst werden:

- [ ] **Rust-Engine als Default**: `should_use_rust()` → `True` wenn alle Tests grüne
- [x] **main_window.py aufteilen**: 8494 → 5246 Zeilen (-38%) via 4 Mixin-Extraktionen  *(v0.0.20.816 — SmartDropMixin 2624Z, ProjectTabsMixin 287Z, ScreenLayoutMixin 270Z, chrono_theme_css 145Z)*
- [x] **Kein `print()` in Production**: Alle `print(..., file=sys.stderr)` → `logging.getLogger()`  *(v0.0.20.814 — Audit: 0 print() in echtem Code, nur in Docstrings/Tool-Scripts. Codebase bereits sauber.)*
- [x] **Unit-Tests für Python-Code**: Analog zu 332 Rust-Tests → PyTest für kritische Module  *(v0.0.20.813 — tests/test_core.py: 37 Tests, 12 Module, Harmony/Rhythm/Genre/Melody/Preset/JSFX/LV2/Scales/SMPTE/Podcast/Controller/Theme)*
- [x] **Dokumentation**: User-Manual + API-Referenz + Video-Tutorials  *(v0.0.20.813 — docs/USER_MANUAL.md: 16 Kapitel, Tastaturkürzel, Fehlerbehebung, alle Features dokumentiert)*
- [x] **Accessibility**: Screen-Reader-Support, Keyboard-Navigation vollständig  *(v0.0.20.814 — accessibility.py: AccessibilityService+Config, label_widget(), ShortcutRegistry 20+ Shortcuts, FocusNavigator, Focus-Ring/Reduced-Motion/Large-Text CSS, announce())*
- [x] **Theming-System**: Hell/Dunkel + benutzerdefinierte Farbschemata per YAML  *(v0.0.20.813 — theme_manager.py: 5 Themes Dark/Light/Midnight/Solarized/HighContrast, ThemePalette 30+ Farben, YAML Load/Save, Live-Switching, Qt-Stylesheet-Generator)*

---

## 🎯 MEILENSTEINE

| Meilenstein | Was | Wann (Schätzung) |
|------------|-----|-----------------|
| **v0.1.0 Beta** | Phase 0 komplett + stabiler Ton aus Advanced Sampler | 2–3 Sessions |
| **v0.2.0** | Phase 1 (Recording Professional) | 5–8 Sessions |
| **v0.3.0** | Phase 2A+2B (KI-Kompositions-Assistent Basic) | 8–12 Sessions |
| **v0.4.0** | Phase 3 (KI-Mixing) + Phase 4 (Live) | 10–15 Sessions |
| **v0.5.0** | Phase 2 komplett (alle KI-Features) | 5–8 Sessions |
| **v0.6.0** | Phase 5+6 (Kollaboration + Scripting) | 10–15 Sessions |
| **v1.0.0** | Alle Phasen + stabil + dokumentiert | ~60 Sessions total |

---

## 🤖 KI-INTEGRATION ARCHITEKTUR (Technisch)

```
┌─────────────────────────────────────────┐
│  Py_DAW GUI (PyQt6)                     │
│  - KI-Panel (neues Dock-Widget)         │
│  - Inline-Vorschläge im Piano Roll      │
│  - Mix-Analyse-Overlay im Mixer         │
└──────────────┬──────────────────────────┘
               │
       ┌───────▼────────┐
       │  KI-Service     │  pydaw/services/ai_service.py
       │  (Singleton)    │
       └───┬─────────┬───┘
           │         │
   ┌───────▼──┐  ┌───▼──────────────┐
   │ Claude   │  │ Lokale Modelle   │
   │ API      │  │ (Essentia, Aubio,│
   │ (online) │  │  Demucs, etc.)   │
   └──────────┘  └──────────────────┘

Datenfluss:
  User-Anfrage → ai_service.py → API/Lokal → strukturierte Antwort
  → Piano Roll einfügen / Mixer anpassen / Preset laden
```

---

## 📋 FÜR DEN NÄCHSTEN KOLLEGEN

### So startest du

```bash
# 1. ZIP entpacken, orientieren
ls pydaw/  # muss existieren
cat VERSION  # aktueller Stand
cat PROJECT_DOCS/PRO_ROADMAP_2026.md  # dieser Plan
cat PROJECT_DOCS/sessions/LATEST.md   # letzte Session

# 2. Nächste offene Aufgabe finden
# → Erste [ ] Checkbox in PHASE 0 (immer zuerst!)
# → Dann PHASE 1, PHASE 2 etc.

# 3. Arbeiten, testen, dokumentieren
python3 -c "import py_compile; py_compile.compile('pydaw/DATEI.py', doraise=True)"

# 4. ZIP bauen
echo -n "0.0.20.XXX" > VERSION
zip -r Output.zip pydaw pydaw_engine PROJECT_DOCS docs *.py *.md *.txt VERSION *.sh \
  -x "*.pyc" "*__pycache__*" "*.egg-info*" "*/.git/*" "*/node_modules/*" "*/target/*"
```

### Prioritätsregel

```
IMMER zuerst PHASE 0 (Stabilisierung) vollständig abschließen
DANN PHASE 1 (Recording)
DANN PHASE 2 (KI) — hier liegt die Zukunft
DANN PHASE 3–7
```

### Was du zurückgibst

1. Neue ZIP mit aktualisierten Checkboxen
2. CHANGELOG_vX.X.X.md
3. PROJECT_DOCS/sessions/LATEST.md (was gemacht, was als nächstes)
4. Kurze Übergabe-Nachricht

---

## 💡 WARUM PY_DAW EINZIGARTIG WERDEN KANN

**Was Ableton/Bitwig/Cubase haben:** Professionelle Audio-Engine, VST-Support, Arranger, Mixer.
→ Das haben wir jetzt auch.

**Was die anderen NICHT haben:**
1. **Python-Scripting direkt in der DAW** — Ableton hat Max for Live, aber Python ist mächtiger
2. **KI-Kompositions-Assistent integriert** — kein anderer DAW-Hersteller hat das nativ
3. **Open Source + Community-Presets** — keine Lizenzkosten, keine Vendor-Lock-ins
4. **Rust-Performance + Python-Flexibilität** — beste beider Welten
5. **KI-Mix-Analyse in Echtzeit** — "dein Mix klingt so weil..." als Lernwerkzeug
6. **Offline-KI für Datenschutz** — Musik-Projekte bleiben lokal, KI läuft lokal
7. **DAWproject-Interoperabilität** — Projekte zwischen DAWs austauschen
8. **Self-hosted Kollaboration** — kein Cloud-Abo nötig

**Das macht Py_DAW zur ersten DAW die gleichzeitig:**
- Professional genug für Studioproduktionen
- Transparent genug für Lernende ("zeig mir warum dieser Mix funktioniert")
- Skriptierbar genug für Automatisierung
- KI-unterstützt genug für kreative Arbeit
- Open Source genug für Community-Beiträge

---

*Dieser Plan wird mit jeder Phase aktualisiert.*
*Stand: v0.0.20.744 — 2026-03-23*
*Nächste offene Aufgabe: PHASE 0 → P0A (Rust-Engine-Disconnect)*
