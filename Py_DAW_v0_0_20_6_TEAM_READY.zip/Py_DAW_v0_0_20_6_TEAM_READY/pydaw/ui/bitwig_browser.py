"""Bitwig-Style Browser with Tabs for PyDAW.

Tabs:
- Samples (functional)
- Instruments (internal Python instruments)
- Effects (placeholder)
- Plugins (placeholder)
- Presets (placeholder)
"""

from __future__ import annotations

from typing import Callable, Optional

from PyQt6.QtWidgets import QWidget, QVBoxLayout, QTabWidget, QLabel

from .sample_browser import SampleBrowserWidget
from .instrument_browser import InstrumentBrowserWidget


class BitwigStyleBrowser(QWidget):
    def __init__(self, on_add_instrument: Optional[Callable[[str], None]] = None, audio_engine=None, transport=None, project_service=None, parent=None):
        super().__init__(parent)
        self._on_add_instrument = on_add_instrument
        self._audio_engine = audio_engine
        self._transport = transport
        self._project_service = project_service
        self._build_ui()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.TabPosition.North)

        # Samples
        self.samples_tab = SampleBrowserWidget(audio_engine=self._audio_engine, transport=self._transport, project_service=self._project_service)
        self.tabs.addTab(self.samples_tab, "🎵 Samples")

        # Instruments
        self.instruments_tab = InstrumentBrowserWidget(on_add_instrument=self._on_add_instrument)
        self.tabs.addTab(self.instruments_tab, "🎹 Instruments")

        # Effects placeholder
        self.effects_tab = self._placeholder(
            "🎚️ Eigene entwickelte Effects\n\n"
            "Hier kommen später:\n"
            "• Audio → Audio DSP\n"
            "• Real-time Processing\n"
            "• Modulare Effects\n"
            "• Parameter UI\n\n"
            "Status: PLACEHOLDER - Bereit für Entwicklung! 🚀"
        )
        self.tabs.addTab(self.effects_tab, "🎚️ Effects")

        # Plugins placeholder
        self.plugins_tab = self._placeholder(
            "🔌 VST/LV2 Plugins\n\n"
            "Später: Plugin-Scanner, Blacklist, Favorites, Kategorien.\n\n"
            "Status: PLACEHOLDER"
        )
        self.tabs.addTab(self.plugins_tab, "🔌 Plugins")

        # Presets placeholder
        self.presets_tab = self._placeholder(
            "📦 Presets\n\n"
            "Später: Preset-Browser für Devices/Instruments/FX.\n\n"
            "Status: PLACEHOLDER"
        )
        self.tabs.addTab(self.presets_tab, "📦 Presets")

        layout.addWidget(self.tabs)

    def _placeholder(self, text: str) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lab = QLabel(text)
        lab.setWordWrap(True)
        lay.addWidget(lab)
        lay.addStretch(1)
        return w
