"""Transport panel widgets."""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QWidget,
    QHBoxLayout,
    QPushButton,
    QLabel,
    QCheckBox,
    QSpinBox,
    QComboBox,
)
from PyQt6.QtCore import pyqtSignal, Qt


class TransportPanel(QWidget):
    bpm_changed = pyqtSignal(float)

    play_clicked = pyqtSignal()
    stop_clicked = pyqtSignal()
    rew_clicked = pyqtSignal()
    ff_clicked = pyqtSignal()
    record_clicked = pyqtSignal(bool)

    loop_toggled = pyqtSignal(bool)

    time_signature_changed = pyqtSignal(str)
    metronome_toggled = pyqtSignal(bool)
    count_in_changed = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(8)

        self.btn_rew = QPushButton("⏮")
        self.btn_ff = QPushButton("⏭")
        self.btn_play = QPushButton("▶")
        self.btn_stop = QPushButton("■")
        self.btn_rec = QPushButton("●")
        self.btn_loop = QPushButton("⟲")

        for b in (self.btn_rew, self.btn_ff, self.btn_play, self.btn_stop, self.btn_rec, self.btn_loop):
            b.setFixedWidth(44)

        layout.addWidget(self.btn_rew)
        layout.addWidget(self.btn_play)
        layout.addWidget(self.btn_stop)
        layout.addWidget(self.btn_rec)
        layout.addWidget(self.btn_loop)
        layout.addWidget(self.btn_ff)

        layout.addSpacing(10)

        self.lbl_time = QLabel("00:00.000 | Beat 0.00")
        self.lbl_time.setMinimumWidth(220)
        layout.addWidget(self.lbl_time)

        layout.addSpacing(10)

        self.bpm = QSpinBox()
        self.bpm.setRange(20, 300)
        self.bpm.setValue(120)
        self.bpm.setSuffix(" BPM")
        self.bpm.setFixedWidth(110)
        layout.addWidget(self.bpm)

        layout.addWidget(QLabel("TS:"))
        self.cmb_ts = QComboBox()
        self.cmb_ts.setEditable(True)
        self.cmb_ts.addItems(["4/4", "3/4", "2/4", "6/8", "5/4", "7/8"])
        self.cmb_ts.setCurrentText("4/4")
        self.cmb_ts.setFixedWidth(90)
        layout.addWidget(self.cmb_ts)

        self.chk_loop = QCheckBox("Loop")
        layout.addWidget(self.chk_loop)

        self.chk_met = QCheckBox("Metronom")
        layout.addWidget(self.chk_met)

        layout.addWidget(QLabel("Count-In:"))
        self.spin_countin = QSpinBox()
        self.spin_countin.setRange(0, 8)
        self.spin_countin.setValue(0)
        self.spin_countin.setSuffix(" Bars")
        self.spin_countin.setFixedWidth(110)
        layout.addWidget(self.spin_countin)

        layout.addStretch(1)

        # wiring
        self.bpm.valueChanged.connect(lambda v: self.bpm_changed.emit(float(v)))
        self.cmb_ts.currentTextChanged.connect(lambda t: self.time_signature_changed.emit(str(t)))
        self.chk_loop.toggled.connect(self.loop_toggled.emit)
        self.chk_met.toggled.connect(self.metronome_toggled.emit)
        self.spin_countin.valueChanged.connect(lambda v: self.count_in_changed.emit(int(v)))

        self.btn_play.clicked.connect(self.play_clicked.emit)
        self.btn_stop.clicked.connect(self.stop_clicked.emit)
        self.btn_rew.clicked.connect(self.rew_clicked.emit)
        self.btn_ff.clicked.connect(self.ff_clicked.emit)

        self._rec_on = False
        self.btn_rec.setCheckable(True)
        self.btn_rec.toggled.connect(self.record_clicked.emit)

    def set_time(self, beat: float, bpm: float) -> None:
        # placeholder conversion of beats to seconds
        secs = float(beat) * 60.0 / max(1.0, float(bpm))
        mm = int(secs // 60)
        ss = secs - mm * 60
        self.lbl_time.setText(f"{mm:02d}:{ss:06.3f} | Beat {beat:0.2f}")

    def set_time_signature(self, ts: str) -> None:
        ts = str(ts or "4/4")
        if self.cmb_ts.currentText() != ts:
            self.cmb_ts.blockSignals(True)
            self.cmb_ts.setCurrentText(ts)
            self.cmb_ts.blockSignals(False)

    def set_bpm(self, bpm: float | int) -> None:
        """Update BPM UI without emitting bpm_changed.

        PyQt6 is configured to abort the whole process on uncaught slot
        exceptions on some setups. We therefore avoid AttributeErrors by
        providing a stable API used by MainWindow (project open sync).
        """
        try:
            v = int(round(float(bpm)))
        except Exception:
            v = 120
        v = max(20, min(300, v))
        if int(self.bpm.value()) != int(v):
            self.bpm.blockSignals(True)
            self.bpm.setValue(int(v))
            self.bpm.blockSignals(False)
