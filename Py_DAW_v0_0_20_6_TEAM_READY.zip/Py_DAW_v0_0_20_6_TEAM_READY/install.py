"""Installer helper for Py_DAW.

Usage:
    python3 install.py

It will:
- warn if you're not inside a virtual environment
- install/upgrade pip
- install requirements.txt

Note:
- JACK/PipeWire system components are not installed here (distro packages).
"""

from __future__ import annotations

import os
import sys
import subprocess
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def main() -> int:
    here = Path(__file__).resolve().parent
    req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        print("      Empfehlung: python3 -m venv myenv && source myenv/bin/activate")

    py = sys.executable
    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    _run([py, "-m", "pip", "install", "-r", str(req)])

    print("\nOK. Starte danach mit: python3 main.py")
    print("Optional: Audio/MIDI Abhängigkeiten können Systempakete erfordern (PipeWire-JACK/JACK/qpwgraph).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
