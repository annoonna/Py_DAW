"""Installer helper for Py_DAW (Cross-Platform).

Usage:
    python install.py

It will:
- warn if you're not inside a virtual environment
- install/upgrade pip tooling
- install requirements (Windows prefers requirements_windows.txt if present)

Notes:
- System-level audio components are NOT installed here.
  * Linux: PipeWire-JACK/JACK packages are distro packages.
  * Windows: sounddevice/soundfile wheels usually include what you need.
- Optional SF2/MIDI rendering uses FluidSynth (fluidsynth.exe).
"""

from __future__ import annotations

import os
import platform
import subprocess
import sys
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def _in_venv() -> bool:
    return (
        (hasattr(sys, "base_prefix") and sys.prefix != getattr(sys, "base_prefix", sys.prefix))
        or bool(os.environ.get("VIRTUAL_ENV"))
    )


def _print_venv_help() -> None:
    if platform.system().lower() == "windows":
        print("Empfehlung (Windows):")
        print("  py -m venv .venv")
        print("  .venv\\Scripts\\activate")
    else:
        print("Empfehlung (Linux/macOS):")
        print("  python3 -m venv .venv")
        print("  source .venv/bin/activate")


def main() -> int:
    here = Path(__file__).resolve().parent
    is_windows = platform.system().lower() == "windows"

    req_default = here / "requirements.txt"
    req_win = here / "requirements_windows.txt"
    req = req_win if (is_windows and req_win.exists()) else req_default

    if not req.exists():
        print("requirements file not found:", req)
        return 2

    if not _in_venv():
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        _print_venv_help()
        print()

    py = sys.executable

    # Upgrade pip tooling (best-effort)
    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    # Install requirements
    _run([py, "-m", "pip", "install", "-r", str(req)])

    print("\nOK.")
    if is_windows:
        print("Starte danach mit: python main.py")
        print("Tipps (Windows Audio):")
        print("  - WASAPI bevorzugt: set PYDAW_SD_HOSTAPI=wasapi")
        print("  - Exclusive Mode (optional): set PYDAW_WASAPI_EXCLUSIVE=1")
        print("Tipps (Qt Rendering):")
        print("  - Falls schwarzes Fenster: set PYDAW_QT_OPENGL=angle")
        print("Optional (FluidSynth Render):")
        print("  - Falls fluidsynth.exe nicht im PATH ist: set FLUIDSYNTH_PATH=C:\\Pfad\\zu\\fluidsynth.exe")
    else:
        print("Starte danach mit: python3 main.py")
        print("Optional: Linux Audio kann PipeWire-JACK/JACK Systempakete erfordern (qpwgraph/pipewire-jack).")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
