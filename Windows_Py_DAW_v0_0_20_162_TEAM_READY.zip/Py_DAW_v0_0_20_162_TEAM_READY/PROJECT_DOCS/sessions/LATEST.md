# Session: v0.0.20.162 — Audio Editor: Ctrl+J = "Clip aus Auswahl" (Events bleiben 1:1)

**Datum:** 2026-03-01  
**Assignee:** GPT-5.2 Thinking (ChatGPT)  
**Status:** ✅ FERTIG  

---

## User-Report

- Im Audio Editor werden mehrere markierte AudioEvents (z.B. 9 Hits) via **Ctrl+J** zu **nur 1 Sample/Event**.
- Erwartung: **Glue/Consolidate to Clip** → ein Clip von z.B. **2 Bars**, aber **Events bleiben erhalten**.

---

## Umsetzung (safe, non-destructive)

1) Neuer ProjectService-Call: `join_audio_events_to_new_clip(...)`
   - erstellt **NEUEN** Clip aus selektierten Events
   - Clip-Länge wird **bar-genau** aus der Auswahl abgeleitet
   - Events werden **1:1 kopiert** (Anzahl bleibt identisch)
   - Clip-Launcher Slot wird (falls betroffen) auf neuen Clip umgebogen (alter Clip bleibt im Projekt)

2) AudioEventEditor: Ctrl+J mapped auf Join-Call (Fallback auf altes Merge-Verhalten)

---

## Geänderte Dateien

- `pydaw/services/project_service.py`
- `pydaw/ui/audio_editor/audio_event_editor.py`
- `VERSION`, `pydaw/version.py`, `pydaw/model/project.py`

