# Py_DAW – Windows Setup (TEAM_READY)

## 1) Voraussetzungen
- Windows 10/11
- Python (empfohlen: aktuelles 64‑bit Python 3.11–3.13)
- Optional (für SF2 Rendering / MIDI->Audio Render):
  - FluidSynth (fluidsynth.exe) + eine SF2 SoundFont

## 2) Installation (PowerShell)
```powershell
cd <DEIN_ORDNER>\Py_DAW_v0_0_20_162_TEAM_READY
py -m venv .venv
.venv\Scripts\activate
py install.py
```

## 3) Start
```powershell
py main.py
```

## 4) Audio Tipps (WASAPI)
- WASAPI bevorzugen (Default):
  - `set PYDAW_SD_HOSTAPI=wasapi`
- Optional Exclusive Mode:
  - `set PYDAW_WASAPI_EXCLUSIVE=1`

## 5) Qt Rendering Tipps (falls schwarzes Fenster / Crash)
- Standard ist ANGLE/D3D11.
- Falls nötig:
  - `set PYDAW_QT_OPENGL=angle`
  - `set PYDAW_QT_RHI=d3d11`

## 6) FluidSynth (optional)
- Wenn `fluidsynth.exe` nicht im PATH ist:
  - `set FLUIDSYNTH_PATH=C:\Pfad\zu\fluidsynth.exe`
