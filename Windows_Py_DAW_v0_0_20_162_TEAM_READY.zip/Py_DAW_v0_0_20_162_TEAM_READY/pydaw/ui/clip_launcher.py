"""Clip Launcher (v0.0.11).

v0.0.10:
- Quantized launch via LauncherService

v0.0.11:
- Quantize also applies to Slot DnD ("arm + launch"):
  drop a clip onto a slot -> assign + (quantized) launch
- Stop All optional playhead reset (checkbox)
"""

from __future__ import annotations

from dataclasses import dataclass
import os

try:
    import numpy as np  # type: ignore
except Exception:  # pragma: no cover
    np = None  # type: ignore

try:
    import soundfile as sf  # type: ignore
except Exception:  # pragma: no cover
    sf = None  # type: ignore

from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QSpinBox,
    QScrollArea,
    QGridLayout,
    QPushButton,
    QMenu,
    QComboBox,
    QToolButton,
    QCheckBox,
    QStyle,
    QStyleOptionButton,
)
from PyQt6.QtCore import Qt, pyqtSignal, QPoint, QRect, QRectF, QTimer
from PyQt6.QtGui import QDrag, QPainter, QPen, QColor, QKeySequence, QShortcut
from PyQt6.QtCore import QMimeData

from pydaw.services.project_service import ProjectService
from pydaw.services.launcher_service import LauncherService
from pydaw.core.settings_store import get_value, set_value
from pydaw.core.settings import SettingsKeys


@dataclass
class _PeaksData:
    mtime_ns: int
    block_size: int
    samplerate: int
    peaks: 'np.ndarray'  # type: ignore

    @property
    def peaks_per_second(self) -> float:
        return float(self.samplerate) / float(max(1, self.block_size))

class SlotButton(QPushButton):
    """A slot button that supports drop + (Alt) drag + double-click for loop editor."""

    double_clicked = pyqtSignal()  # NEU: Doppelklick Signal

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self._drag_start: QPoint | None = None

    def mouseDoubleClickEvent(self, event):  # noqa: ANN001
        """Handle Doppelklick -> Loop-Editor öffnen."""
        if event.button() == Qt.MouseButton.LeftButton:
            self.double_clicked.emit()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def dragEnterEvent(self, event):  # noqa: ANN001
        # IMPORTANT: Never let exceptions escape from Qt virtual overrides.
        # PyQt6 + SIP can turn this into a Qt fatal (SIGABRT).
        try:
            if event.mimeData().hasFormat("application/x-pydaw-clipid"):
                event.acceptProposedAction()
                return
        except Exception:
            pass
        try:
            super().dragEnterEvent(event)
        except Exception:
            pass

    def dropEvent(self, event):  # noqa: ANN001
        # IMPORTANT: Never let exceptions escape from Qt virtual overrides.
        # PyQt6 + SIP can turn this into a Qt fatal (SIGABRT).
        try:
            if event.mimeData().hasFormat("application/x-pydaw-clipid"):
                try:
                    self.parent().slot_drop_requested.emit(self, event)  # type: ignore[attr-defined]
                    event.acceptProposedAction()
                except Exception:
                    try:
                        event.ignore()
                    except Exception:
                        pass
                return
        except Exception:
            try:
                event.ignore()
            except Exception:
                pass
            return
        try:
            super().dropEvent(event)
        except Exception:
            pass

    def mousePressEvent(self, event):  # noqa: ANN001
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_start = event.pos()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):  # noqa: ANN001
        # Alt+Drag: existing behavior (drag the clip-id)
        # Ctrl+Drag: duplicate-on-drop behavior (Bitwig/Ableton style)
        mods = event.modifiers()
        if (
            self._drag_start is not None
            and (event.buttons() & Qt.MouseButton.LeftButton)
            and (mods & (Qt.KeyboardModifier.AltModifier | Qt.KeyboardModifier.ControlModifier))
        ):
            if (event.pos() - self._drag_start).manhattanLength() >= 8:
                clip_id = str(self.property("clip_id") or "")
                if clip_id:
                    drag = QDrag(self)
                    md = QMimeData()
                    md.setData("application/x-pydaw-clipid", clip_id.encode("utf-8"))
                    # Mark as 'duplicate on drop' if Ctrl is pressed.
                    if mods & Qt.KeyboardModifier.ControlModifier:
                        md.setData("application/x-pydaw-clipid-dup", b"1")
                    drag.setMimeData(md)
                    drag.exec(Qt.DropAction.CopyAction)
                self._drag_start = None
                return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):  # noqa: ANN001
        self._drag_start = None
        super().mouseReleaseEvent(event)


class SlotWaveButton(SlotButton):
    """Slot button with in-slot audio waveform preview (Arranger-like).

    UX-Ziel (Bitwig/Ableton):
    - Single click: auswählen + im Editor öffnen (NICHT abspielen)
    - Kleiner ▶-Button im Slot: Clip launchen
    """

    def __init__(self, panel: 'ClipLauncherPanel', parent: QWidget | None = None):
        super().__init__(parent or panel)
        self._panel = panel
        self._hover = False
        self._suppress_click = False
        try:
            self.setMouseTracking(True)
        except Exception:
            pass

    def enterEvent(self, event):  # noqa: ANN001
        self._hover = True
        try:
            self.update()
        except Exception:
            pass
        try:
            super().enterEvent(event)
        except Exception:
            pass

    def leaveEvent(self, event):  # noqa: ANN001
        self._hover = False
        try:
            self.update()
        except Exception:
            pass
        try:
            super().leaveEvent(event)
        except Exception:
            pass

    def _play_button_rect(self) -> 'QRect':
        """Return the clickable play-button rect inside the slot (top-right)."""
        opt = QStyleOptionButton()
        self.initStyleOption(opt)
        content = self.style().subElementRect(QStyle.SubElement.SE_PushButtonContents, opt, self)
        # small square in the top-right of the slot
        sz = 18
        pad = 3
        return QRect(int(content.right() - sz - pad), int(content.top() + pad), int(sz), int(sz))

    def mousePressEvent(self, event):  # noqa: ANN001
        # Click on the small ▶ hotzone launches the clip (without triggering the button 'clicked').
        try:
            if event.button() == Qt.MouseButton.LeftButton:
                r = self._play_button_rect()
                if r.contains(event.pos()):
                    slot_key = str(self.property('slot_key') or '')
                    cid = str(self.property('clip_id') or '')
                    if slot_key and cid:
                        try:
                            # selection for deterministic shortcuts
                            self._panel._set_selected_slot(slot_key)
                        except Exception:
                            pass
                        try:
                            self._panel._launch(slot_key)
                        except Exception:
                            pass
                        self._suppress_click = True
                        event.accept()
                        return
        except Exception:
            pass
        try:
            super().mousePressEvent(event)
        except Exception:
            pass

    def mouseReleaseEvent(self, event):  # noqa: ANN001
        # Suppress QPushButton.clicked when we handled the play-button ourselves.
        if getattr(self, '_suppress_click', False):
            self._suppress_click = False
            try:
                event.accept()
            except Exception:
                pass
            return
        try:
            super().mouseReleaseEvent(event)
        except Exception:
            pass



    def mouseDoubleClickEvent(self, event):  # noqa: ANN001
        # Dedicated editor open on double click (Pro-DAW-like).
        if event.button() == Qt.MouseButton.LeftButton:
            cid = str(self.property("clip_id") or "")
            if cid:
                try:
                    self._panel.clip_edit_requested.emit(cid)
                except Exception:
                    pass
                event.accept()
                return
        super().mouseDoubleClickEvent(event)
    def paintEvent(self, event):  # noqa: ANN001
        # Draw normal button chrome but render our own contents (text + waveform).
        opt = QStyleOptionButton()
        self.initStyleOption(opt)
        opt.text = ''

        p = QPainter(self)
        try:
            self.style().drawControl(QStyle.ControlElement.CE_PushButton, opt, p, self)
            content = self.style().subElementRect(QStyle.SubElement.SE_PushButtonContents, opt, self)

            cid = str(self.property('clip_id') or '')
            if not cid:
                p.setPen(self.palette().mid().color())
                p.drawText(content, Qt.AlignmentFlag.AlignCenter, 'Empty')
                return

            clip = self._panel._get_clip(cid)
            if clip is None:
                p.setPen(self.palette().mid().color())
                p.drawText(content, Qt.AlignmentFlag.AlignCenter, 'Missing')
                return

            label = str(getattr(clip, 'label', '') or 'Clip')

            # Countdown text for queued (quantized) launch
            slot_key = str(self.property('slot_key') or '')
            countdown = ''
            try:
                countdown = str(getattr(self._panel, 'get_slot_countdown_text')(slot_key) or '')
            except Exception:
                countdown = ''




            # Queued-state indicator (Bitwig-style): dashed yellow border if this slot is queued (quantized)
            try:
                slot_key = str(self.property('slot_key') or '')
                if slot_key and not bool(getattr(self._panel, 'is_slot_playing')(slot_key)) and bool(getattr(self._panel, 'is_slot_queued')(slot_key)):
                    qcol = QColor(255, 176, 0)
                    qcol.setAlpha(220)
                    p.save()
                    pen = QPen(qcol, 2, Qt.PenStyle.DashLine)
                    p.setPen(pen)
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.drawRect(content.adjusted(2, 2, -3, -3))
                    # Small queued triangle outline (top-left)
                    from PyQt6.QtGui import QPolygon
                    from PyQt6.QtCore import QPoint
                    tri = QPolygon([
                        QPoint(int(content.left() + 10), int(content.top() + 7)),
                        QPoint(int(content.left() + 10), int(content.top() + 19)),
                        QPoint(int(content.left() + 20), int(content.top() + 13)),
                    ])
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.setPen(QPen(qcol, 2, Qt.PenStyle.SolidLine))
                    p.drawPolygon(tri)
                    p.restore()
            except Exception:
                pass

            # Play-state indicator (Bitwig-style): highlight if this slot is currently playing
            try:
                slot_key = str(self.property('slot_key') or '')
                if slot_key and bool(getattr(self._panel, 'is_slot_playing')(slot_key)):
                    hl = QColor(self.palette().highlight().color())
                    hl.setAlpha(210)
                    p.save()
                    p.setPen(QPen(hl, 2))
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.drawRect(content.adjusted(1, 1, -2, -2))

                    # Small play triangle (top-left)
                    tri = [
                        (int(content.left() + 10), int(content.top() + 7)),
                        (int(content.left() + 10), int(content.top() + 19)),
                        (int(content.left() + 20), int(content.top() + 13)),
                    ]
                    p.setPen(Qt.PenStyle.NoPen)
                    p.setBrush(hl)
                    from PyQt6.QtGui import QPolygon
                    from PyQt6.QtCore import QPoint
                    p.drawPolygon(QPolygon([QPoint(x, y) for x, y in tri]))
                    p.restore()
            except Exception:
                pass

            # Selected-slot indicator (UI-only): subtle border so Ctrl+C/V/Del feel deterministic
            try:
                slot_key = str(self.property('slot_key') or '')
                if slot_key and bool(getattr(self._panel, 'is_slot_selected')(slot_key)):
                    # Don't override playing/queued styling; draw an inner, subtle border.
                    sel = QColor(self.palette().mid().color())
                    sel.setAlpha(220)
                    p.save()
                    p.setPen(QPen(sel, 1, Qt.PenStyle.DashDotLine))
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.drawRect(content.adjusted(4, 4, -5, -5))
                    p.restore()
            except Exception:
                pass


            # Small in-slot launch button (Bitwig/Ableton-style): top-right ▶
            # (Clickable hotzone handled in mousePressEvent)
            try:
                r = self._play_button_rect()
                # Background
                bg = QColor(self.palette().window().color())
                bg.setAlpha(170 if self._hover else 110)
                p.save()
                p.setPen(QPen(self.palette().mid().color(), 1))
                p.setBrush(bg)
                p.drawRoundedRect(r, 3, 3)

                # Triangle icon
                ico = QColor(self.palette().text().color())
                ico.setAlpha(245 if self._hover else 170)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(ico)
                from PyQt6.QtGui import QPolygon
                from PyQt6.QtCore import QPoint
                cx = int(r.center().x())
                cy = int(r.center().y())
                tri = QPolygon([
                    QPoint(cx - 3, cy - 5),
                    QPoint(cx - 3, cy + 5),
                    QPoint(cx + 5, cy),
                ])
                p.drawPolygon(tri)
                p.restore()
            except Exception:
                pass

            # Layout: small label row + waveform area
            label_rect = QRectF(content.left() + 4, content.top() + 2, content.width() - 8, 12)
            wave_rect = QRectF(content.left() + 4, content.top() + 16, content.width() - 8, content.height() - 20)

            # Waveform (audio only)
            if float(wave_rect.height()) >= 8.0 and str(getattr(clip, 'kind', '')) == 'audio' and getattr(clip, 'source_path', None):
                track_vol = self._panel._get_track_volume(str(getattr(clip, 'track_id', '') or ''))
                p.save()
                p.setClipRect(wave_rect)
                self._panel._draw_audio_waveform(p, wave_rect, clip, track_vol)
                p.restore()

            # Label on top
            p.setPen(self.palette().text().color())
                        # Label (+ queued countdown on the right, Bitwig-style)
            if countdown:
                try:
                    # reserve a small right area for the countdown
                    cw = min(76.0, float(label_rect.width()) * 0.55)
                    c_rect = QRectF(label_rect.right() - cw, label_rect.top(), cw, label_rect.height())
                    l_rect = QRectF(label_rect.left(), label_rect.top(), max(8.0, label_rect.width() - cw - 4.0), label_rect.height())

                    p.setPen(self.palette().text().color())
                    p.drawText(l_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, label)

                    qcol = QColor(255, 176, 0)
                    qcol.setAlpha(235)
                    p.setPen(qcol)
                    p.drawText(c_rect, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, countdown)
                except Exception:
                    p.setPen(self.palette().text().color())
                    p.drawText(label_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, label)
            else:
                p.setPen(self.palette().text().color())
                p.drawText(label_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, label)

        finally:
            p.end()

class ClipLauncherPanel(QWidget):
    clip_activated = pyqtSignal(str)  # clip_id
    clip_edit_requested = pyqtSignal(str)  # clip_id (double click)
    slot_drop_requested = pyqtSignal(object, object)  # (SlotButton, QDropEvent)

    def __init__(
        self,
        project: ProjectService,
        launcher: LauncherService,
        clip_context: 'ClipContextService | None' = None,
        parent=None
    ):
        super().__init__(parent)
        self.project = project
        self.launcher = launcher
        self.clip_context = clip_context  # NEU: ClipContextService
        self.scene_count = 8

        # UI persistence (QSettings)
        self._settings_keys = SettingsKeys()
        self._inspector_last_width: int = 320
        self._inspector_visible: bool = True

        # Allow the right dock group (Browser/Clip Launcher) to be shrunk
        # "almost closed" without being blocked by minimum-size hints.
        try:
            from PyQt6.QtWidgets import QSizePolicy
            self.setMinimumSize(0, 0)
            self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        except Exception:
            pass

        # waveform cache (shared across slot widgets)
        self._peaks_cache: dict[str, _PeaksData] = {}
        self._peaks_pending: set[str] = set()
        self._clip_index: dict[str, object] = {}
        self._track_index: dict[str, object] = {}

        # UI-only play-state cache: set of slot_keys currently playing (from ClipLauncherPlaybackService)
        self._active_slots: set[str] = set()

        # UI-only queued-state cache: set of slot_keys/scenes queued via quantize (from LauncherService)
        self._queued_slots: set[str] = set()
        self._queued_scenes: set[int] = set()
        self._scene_headers: dict[int, QWidget] = {}

        # Queued countdown meta (UI-only): slot_key -> (at_beat, quantize), scene -> (at_beat, quantize)
        self._queued_slot_meta: dict[str, tuple[float, str]] = {}
        self._queued_scene_meta: dict[int, tuple[float, str]] = {}
        self._scene_countdown_labels: dict[int, QLabel] = {}

        # Slot selection + clipboard (DAW-like shortcuts for the launcher grid)
        self._selected_slot_key: str = ''
        self._slot_buttons: dict[str, SlotWaveButton] = {}
        self._slot_clipboard_clip_id: str = ''
        self._slot_clipboard_source_slot_key: str = ''
        self._shortcuts: list[QShortcut] = []

        # Timer for queued countdown repaint (only active when something is queued)
        self._queue_timer = QTimer(self)
        self._queue_timer.setInterval(60)
        self._queue_timer.timeout.connect(self._on_queue_timer_tick)

        self._build_ui()
        self._wire()
        self.refresh()

        # Apply persisted inspector state after the widget hierarchy exists.
        self._load_inspector_prefs()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Top header bar ──
        header = QHBoxLayout()
        header.setContentsMargins(8, 4, 8, 4)

        header.addWidget(QLabel("Clip Launcher"))

        # Toggle the left "ZELLE" inspector (Bitwig-style).
        self.btn_toggle_inspector = QToolButton()
        self.btn_toggle_inspector.setCheckable(True)
        self.btn_toggle_inspector.setChecked(True)
        self.btn_toggle_inspector.setAutoRaise(True)
        self.btn_toggle_inspector.setToolTip("ZELLE Inspector ein-/ausblenden")
        try:
            self.btn_toggle_inspector.setArrowType(Qt.ArrowType.LeftArrow)
        except Exception:
            pass
        header.addWidget(self.btn_toggle_inspector)

        header.addWidget(QLabel("Scenes:"))
        self.spin_scenes = QSpinBox()
        self.spin_scenes.setRange(1, 64)
        self.spin_scenes.setValue(self.scene_count)
        header.addWidget(self.spin_scenes)

        header.addSpacing(12)
        header.addWidget(QLabel("Quantize:"))
        self.cmb_quant = QComboBox()
        self.cmb_quant.addItems(["Off", "1 Beat", "1 Bar"])
        header.addWidget(self.cmb_quant)

        header.addSpacing(6)
        header.addWidget(QLabel("Mode:"))
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["Trigger", "Toggle", "Gate"])
        header.addWidget(self.cmb_mode)

        header.addSpacing(12)
        self.chk_reset = QCheckBox("Reset Playhead")
        self.chk_reset.setToolTip("Beim Stop All wird der Playhead auf 0 gesetzt.")
        header.addWidget(self.chk_reset)

        self.btn_stop_all = QPushButton("Stop All")
        header.addWidget(self.btn_stop_all)

        header.addStretch(1)

        self.lbl_sel = QLabel("Ausgewählter Clip: —")
        header.addWidget(self.lbl_sel)

        layout.addLayout(header)

        # ── Main area: Inspector (left) + Grid (right) ──
        from PyQt6.QtWidgets import QSplitter

        self.main_splitter = QSplitter(Qt.Orientation.Horizontal)
        try:
            from PyQt6.QtWidgets import QSizePolicy
            self.main_splitter.setMinimumSize(0, 0)
            self.main_splitter.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Expanding)
        except Exception:
            pass
        layout.addWidget(self.main_splitter, 1)

        # ── Left: Bitwig-Style ZELLE Inspector ──
        try:
            from pydaw.ui.clip_launcher_inspector import ClipLauncherInspector
            self.inspector = ClipLauncherInspector(
                self.project,
                clip_context=self.clip_context,
                parent=self.main_splitter,
            )
            # IMPORTANT (User UX): the inspector must be resizable.
            # Do NOT clamp it to a tiny max width, otherwise the UI feels "broken".
            self.inspector.setMinimumWidth(220)
            try:
                self.inspector.setMaximumWidth(8192)
            except Exception:
                pass
            self.main_splitter.addWidget(self.inspector)
        except Exception as e:
            # Fallback: no inspector if import fails
            self.inspector = None
            import logging
            logging.getLogger(__name__).warning("ClipLauncherInspector not available: %s", e)

        # ── Right: Grid (existing) ──
        grid_container = QWidget()
        grid_layout = QVBoxLayout(grid_container)
        grid_layout.setContentsMargins(0, 0, 0, 0)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        try:
            from PyQt6.QtWidgets import QSizePolicy
            self.scroll.setMinimumSize(0, 0)
            self.scroll.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Expanding)
        except Exception:
            pass
        grid_layout.addWidget(self.scroll, 1)

        self.inner = QWidget()
        self.grid = QGridLayout(self.inner)
        self.grid.setContentsMargins(6, 6, 6, 6)
        self.grid.setHorizontalSpacing(6)
        self.grid.setVerticalSpacing(6)

        self.scroll.setWidget(self.inner)
        self.main_splitter.addWidget(grid_container)

        # Splitter proportions: default inspector width, grid gets the rest.
        try:
            self.main_splitter.setSizes([self._inspector_last_width, 1000])
        except Exception:
            pass

    def _wire(self) -> None:
        self.spin_scenes.valueChanged.connect(self._scenes_changed)
        self.project.project_updated.connect(self.refresh)
        self.project.active_clip_changed.connect(self._active_clip_changed)
        self.slot_drop_requested.connect(self._handle_slot_drop)

        self.cmb_quant.currentTextChanged.connect(self._launcher_settings_changed)
        self.cmb_mode.currentTextChanged.connect(self._launcher_settings_changed)

        self.btn_stop_all.clicked.connect(lambda: self.launcher.stop_all(reset_playhead=self.chk_reset.isChecked()))

        # Play-state indicator updates (UI-only)
        try:
            sig = getattr(self.project, 'cliplauncher_active_slots_changed', None)
            if sig is not None:
                sig.connect(self._on_active_slots_changed)
        except Exception:
            pass

        # Queued-state indicator updates (UI-only)
        try:
            psig = getattr(self.launcher, 'pending_changed', None)
            if psig is not None:
                psig.connect(self._on_pending_changed)
        except Exception:
            pass

        # UI: inspector collapse + width persistence
        try:
            self.btn_toggle_inspector.clicked.connect(self._toggle_inspector)
        except Exception:
            pass
        try:
            self.main_splitter.splitterMoved.connect(self._on_splitter_moved)
        except Exception:
            pass

        # DAW-like launcher shortcuts (grid-level): Ctrl+C/V/X, Del, Ctrl+D, Esc
        try:
            self._install_shortcuts()
        except Exception:
            pass

    def _read_bool_setting(self, key: str, default: bool) -> bool:
        try:
            raw = get_value(key, default)
        except Exception:
            return bool(default)
        if isinstance(raw, str):
            return raw.strip().lower() in ("true", "1", "yes", "on")
        return bool(raw)

    def _load_inspector_prefs(self) -> None:
        # Called after build() so widgets exist.
        try:
            self._inspector_visible = self._read_bool_setting(
                self._settings_keys.ui_cliplauncher_inspector_visible,
                True,
            )
        except Exception:
            self._inspector_visible = True

        try:
            w = get_value(self._settings_keys.ui_cliplauncher_inspector_width, self._inspector_last_width)
            if isinstance(w, str):
                w = int(float(w))
            self._inspector_last_width = max(160, min(1200, int(w)))
        except Exception:
            pass

        self._apply_inspector_visible(self._inspector_visible, restore_width=True)

    def _apply_inspector_visible(self, visible: bool, restore_width: bool = False) -> None:
        if getattr(self, 'inspector', None) is None:
            return

        self._inspector_visible = bool(visible)
        try:
            set_value(self._settings_keys.ui_cliplauncher_inspector_visible, bool(self._inspector_visible))
        except Exception:
            pass

        try:
            self.btn_toggle_inspector.blockSignals(True)
            self.btn_toggle_inspector.setChecked(bool(self._inspector_visible))
        finally:
            try:
                self.btn_toggle_inspector.blockSignals(False)
            except Exception:
                pass

        try:
            self.inspector.setVisible(bool(self._inspector_visible))
        except Exception:
            pass

        try:
            # Arrow points towards the direction you can collapse to.
            self.btn_toggle_inspector.setArrowType(
                Qt.ArrowType.LeftArrow if self._inspector_visible else Qt.ArrowType.RightArrow
            )
        except Exception:
            pass

        if restore_width and self._inspector_visible:
            try:
                self.main_splitter.setSizes([int(self._inspector_last_width), 1000])
            except Exception:
                pass
        elif not self._inspector_visible:
            # collapse (keep grid visible)
            try:
                self.main_splitter.setSizes([0, 1000])
            except Exception:
                pass

    def _toggle_inspector(self) -> None:
        if getattr(self, 'inspector', None) is None:
            return
        if self._inspector_visible:
            # Remember width before hiding.
            try:
                sizes = self.main_splitter.sizes()
                if sizes and sizes[0] > 0:
                    self._inspector_last_width = int(sizes[0])
                    set_value(self._settings_keys.ui_cliplauncher_inspector_width, int(self._inspector_last_width))
            except Exception:
                pass
            self._apply_inspector_visible(False)
        else:
            self._apply_inspector_visible(True, restore_width=True)

    def _on_splitter_moved(self, _pos: int, _index: int) -> None:
        # Persist only when inspector is visible and has meaningful size.
        if not self._inspector_visible:
            return
        try:
            sizes = self.main_splitter.sizes()
            if not sizes:
                return
            w = int(sizes[0])
            if w < 80:
                return
            self._inspector_last_width = w
            set_value(self._settings_keys.ui_cliplauncher_inspector_width, int(w))
        except Exception:
            pass

    def _launcher_settings_changed(self) -> None:
        fn = getattr(self.project, 'set_launcher_settings', None)
        if callable(fn):
            fn(self.cmb_quant.currentText(), self.cmb_mode.currentText())
        else:
            # Fallback: persist directly on project model
            try:
                setattr(self.project.ctx.project, 'launcher_quantize', self.cmb_quant.currentText())
                setattr(self.project.ctx.project, 'launcher_mode', self.cmb_mode.currentText())
                self.project.project_updated.emit()
            except Exception:
                pass

    def _active_clip_changed(self, clip_id: str) -> None:
        if not clip_id:
            self.lbl_sel.setText("Ausgewählter Clip: —")
            return
        clip = next((c for c in self.project.ctx.project.clips if c.id == clip_id), None)
        self.lbl_sel.setText(f"Ausgewählter Clip: {clip.label}" if clip else "Ausgewählter Clip: —")

    def _scenes_changed(self, v: int) -> None:
        self.scene_count = int(v)
        self.refresh()

    def _slot_key(self, scene_index: int, track_id: str) -> str:
        return f"scene:{scene_index}:track:{track_id}"

    def _tracks(self):
        return [t for t in self.project.ctx.project.tracks if t.kind != 'master']


    # --- DAW-like grid shortcuts (UI-only) ---

    def _install_shortcuts(self) -> None:
        """Install standard DAW shortcuts for the Clip Launcher grid.

        Requested (Bitwig/Ableton style):
        - Ctrl+C / Ctrl+X / Ctrl+V
        - Delete / Backspace
        - Ctrl+D (duplicate to the right)
        - Esc (deselect)
        """
        # Prevent duplicates if refresh/rebuild calls this again.
        try:
            for sc in getattr(self, '_shortcuts', []) or []:
                try:
                    sc.setEnabled(False)
                    sc.deleteLater()
                except Exception:
                    pass
        except Exception:
            pass
        self._shortcuts = []

        def _mk(seq: QKeySequence, fn) -> None:  # noqa: ANN001
            sc = QShortcut(seq, self)
            sc.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
            sc.activated.connect(fn)
            self._shortcuts.append(sc)

        _mk(QKeySequence.StandardKey.Copy, self._copy_selected_slot)
        _mk(QKeySequence.StandardKey.Cut, self._cut_selected_slot)
        _mk(QKeySequence.StandardKey.Paste, self._paste_to_selected_slot)
        _mk(QKeySequence.StandardKey.Delete, self._delete_selected_slot)
        _mk(QKeySequence(Qt.Key.Key_Backspace), self._delete_selected_slot)
        _mk(QKeySequence("Ctrl+D"), self._duplicate_selected_slot_right)
        _mk(QKeySequence(Qt.Key.Key_Escape), self._deselect_slot)

    def _parse_slot_key(self, slot_key: str) -> tuple[int, str] | None:
        key = str(slot_key or '').strip()
        if not key:
            return None
        parts = key.split(':')
        if len(parts) == 4 and parts[0] == 'scene' and parts[2] == 'track':
            try:
                return int(parts[1]), str(parts[3])
            except Exception:
                return None
        return None

    def is_slot_selected(self, slot_key: str) -> bool:
        return str(slot_key) and str(slot_key) == str(getattr(self, '_selected_slot_key', '') or '')

    def _set_selected_slot(self, slot_key: str) -> None:
        self._selected_slot_key = str(slot_key or '')
        # Update inspector selection (fast, safe)
        try:
            cid = self.project.ctx.project.clip_launcher.get(self._selected_slot_key, '')
            if cid and self.inspector:
                try:
                    self.inspector.set_clip(cid)
                except Exception:
                    pass
        except Exception:
            pass
        self._apply_selected_slot_state()

    def _apply_selected_slot_state(self) -> None:
        # Repaint only (selection is drawn inside SlotWaveButton.paintEvent)
        try:
            for k, b in (getattr(self, '_slot_buttons', {}) or {}).items():
                try:
                    # Store as dynamic property for potential stylesheet use later.
                    b.setProperty('selected', bool(self.is_slot_selected(str(k))))
                    b.update()
                except Exception:
                    pass
        except Exception:
            pass

    def _deselect_slot(self) -> None:
        self._selected_slot_key = ''
        self._apply_selected_slot_state()

    def _copy_selected_slot(self) -> None:
        key = str(getattr(self, '_selected_slot_key', '') or '')
        if not key:
            return
        cid = str(self.project.ctx.project.clip_launcher.get(key, '') or '')
        if not cid:
            return
        self._slot_clipboard_clip_id = cid
        self._slot_clipboard_source_slot_key = key
        try:
            self.project.status.emit('ClipLauncher: Slot kopiert (Ctrl+C)')
        except Exception:
            pass

    def _cut_selected_slot(self) -> None:
        # Cut = Copy + Clear
        self._copy_selected_slot()
        self._delete_selected_slot()

    def _paste_to_selected_slot(self) -> None:
        target_key = str(getattr(self, '_selected_slot_key', '') or '')
        src_cid = str(getattr(self, '_slot_clipboard_clip_id', '') or '')
        if not target_key or not src_cid:
            return
        parsed = self._parse_slot_key(target_key)
        if not parsed:
            return
        _scene, track_id = parsed

        # DAW semantics: Paste creates a NEW clip instance (deep copy) assigned to the target slot.
        new_cid = None
        try:
            fn = getattr(self.project, 'clone_clip_for_launcher', None)
            if callable(fn):
                new_cid = fn(src_cid, target_track_id=track_id)
        except Exception:
            new_cid = None

        # Fallback: assign the same clip-id (keeps it non-destructive but linked)
        if not new_cid:
            new_cid = src_cid

        try:
            self.project.cliplauncher_assign(target_key, str(new_cid))
        except Exception:
            pass

        # Keep selection and inspector consistent
        try:
            self._set_selected_slot(target_key)
        except Exception:
            pass
        try:
            self.project.status.emit('ClipLauncher: Slot eingefügt (Ctrl+V)')
        except Exception:
            pass

    def _delete_selected_slot(self) -> None:
        key = str(getattr(self, '_selected_slot_key', '') or '')
        if not key:
            return
        try:
            self.project.cliplauncher_clear(key)
            self.project.status.emit('ClipLauncher: Slot geleert (Del)')
        except Exception:
            pass

    def _duplicate_selected_slot_right(self) -> None:
        """Duplicate the selected slot to the next empty slot on the right (same track)."""
        src_key = str(getattr(self, '_selected_slot_key', '') or '')
        if not src_key:
            return
        src_cid = str(self.project.ctx.project.clip_launcher.get(src_key, '') or '')
        if not src_cid:
            return
        parsed = self._parse_slot_key(src_key)
        if not parsed:
            return
        scene, track_id = parsed

        # Find next empty slot in the same row (track) to the right
        tgt_key = ''
        try:
            for s in range(int(scene) + 1, int(getattr(self, 'scene_count', 8)) + 1):
                k = self._slot_key(int(s), str(track_id))
                if not str(self.project.ctx.project.clip_launcher.get(k, '') or ''):
                    tgt_key = k
                    break
        except Exception:
            tgt_key = ''
        if not tgt_key:
            return

        # Clone + assign
        new_cid = None
        try:
            fn = getattr(self.project, 'clone_clip_for_launcher', None)
            if callable(fn):
                new_cid = fn(src_cid, target_track_id=track_id)
        except Exception:
            new_cid = None
        if not new_cid:
            new_cid = src_cid
        try:
            self.project.cliplauncher_assign(tgt_key, str(new_cid))
        except Exception:
            return

        # Select the new slot
        try:
            self._set_selected_slot(tgt_key)
        except Exception:
            pass


    # --- Bitwig-style helpers (UI-only) ---

    def is_slot_playing(self, slot_key: str) -> bool:
        return str(slot_key) in getattr(self, '_active_slots', set())

    def is_slot_queued(self, slot_key: str) -> bool:
        return str(slot_key) in getattr(self, '_queued_slots', set())


    def _beats_per_bar_ui(self) -> float:
        ts = str(getattr(self.project.ctx.project, 'time_signature', '4/4') or '4/4')
        try:
            num_s, den_s = ts.split('/', 1)
            num = max(1, int(num_s.strip()))
            den = max(1, int(den_s.strip()))
            return float(num) * (4.0 / float(den))
        except Exception:
            return 4.0

    def _format_countdown(self, remaining_beats: float, quantize: str) -> str:
        rem = max(0.0, float(remaining_beats))
        q = str(quantize or 'Off')
        if q == '1 Bar':
            bpb = float(self._beats_per_bar_ui() or 4.0)
            if bpb <= 0.0:
                bpb = 4.0
            bars = rem / bpb
            return f"{bars:.1f} Bar"
        if q == '1 Beat':
            return f"{rem:.1f} Beat"
        # fallback
        if rem >= 1.0:
            bpb = float(self._beats_per_bar_ui() or 4.0)
            if bpb > 0.0:
                bars = rem / bpb
                if bars >= 0.2:
                    return f"{bars:.1f} Bar"
        return f"{rem:.1f} Beat"

    def get_slot_countdown_text(self, slot_key: str) -> str:
        """UI: small queued countdown text for a slot (e.g. '0.5 Bar' / '0.2 Beat')."""
        meta = (getattr(self, '_queued_slot_meta', {}) or {}).get(str(slot_key))
        if not meta:
            return ''
        try:
            at_beat, q = meta
            cur = float(getattr(getattr(self.launcher, 'transport', None), 'current_beat', 0.0) or 0.0)
            rem = float(at_beat) - cur
            if rem <= 0.0:
                rem = 0.0
            return self._format_countdown(rem, str(q))
        except Exception:
            return ''

    def get_scene_countdown_text(self, scene_index: int) -> str:
        meta = (getattr(self, '_queued_scene_meta', {}) or {}).get(int(scene_index))
        if not meta:
            return ''
        try:
            at_beat, q = meta
            cur = float(getattr(getattr(self.launcher, 'transport', None), 'current_beat', 0.0) or 0.0)
            rem = float(at_beat) - cur
            if rem <= 0.0:
                rem = 0.0
            return self._format_countdown(rem, str(q))
        except Exception:
            return ''

    def _update_scene_countdowns(self) -> None:
        # Update right-aligned countdown labels in the scene headers
        try:
            labels = getattr(self, '_scene_countdown_labels', {}) or {}
            for idx, lab in labels.items():
                txt = self.get_scene_countdown_text(int(idx))
                try:
                    lab.setText(txt)
                except Exception:
                    pass
        except Exception:
            pass

    def _on_queue_timer_tick(self) -> None:
        # Only repaint while there are queued launches
        try:
            if not (self._queued_slot_meta or self._queued_scene_meta):
                if self._queue_timer.isActive():
                    self._queue_timer.stop()
                return
        except Exception:
            return
        try:
            self._update_scene_countdowns()
        except Exception:
            pass
        try:
            self.inner.update()
        except Exception:
            pass
        try:
            self.update()
        except Exception:
            pass

    def _on_active_slots_changed(self, slot_keys) -> None:  # noqa: ANN001
        try:
            self._active_slots = set(str(k) for k in (slot_keys or []))
        except Exception:
            self._active_slots = set()
        try:
            self.inner.update()
        except Exception:
            pass
        try:
            self.update()
        except Exception:
            pass

    def _on_pending_changed(self, pending) -> None:  # noqa: ANN001
        """Receive LauncherService pending launches to render queued-state indicators.

        pending is a list of dicts: {kind:'slot'|'scene', key:str, at_beat:float, quantize:str}
        """
        q_slots: set[str] = set()
        q_scenes: set[int] = set()
        slot_meta: dict[str, tuple[float, str]] = {}
        scene_meta: dict[int, tuple[float, str]] = {}

        try:
            for it in (pending or []):
                if isinstance(it, dict):
                    kind = str(it.get('kind', '') or '')
                    key = str(it.get('key', '') or '')
                    at_beat = float(it.get('at_beat', 0.0) or 0.0)
                    q = str(it.get('quantize', 'Off') or 'Off')
                else:
                    kind = str(getattr(it, 'kind', '') or '')
                    key = str(getattr(it, 'key', '') or '')
                    at_beat = float(getattr(it, 'at_beat', 0.0) or 0.0)
                    q = str(getattr(it, 'quantize', 'Off') or 'Off')

                if not key:
                    continue

                if kind == 'slot':
                    q_slots.add(key)
                    slot_meta[key] = (float(at_beat), str(q))
                elif kind == 'scene':
                    try:
                        si = int(key)
                        q_scenes.add(si)
                        scene_meta[si] = (float(at_beat), str(q))
                    except Exception:
                        pass
        except Exception:
            pass

        self._queued_slots = q_slots
        self._queued_scenes = q_scenes
        self._queued_slot_meta = slot_meta
        self._queued_scene_meta = scene_meta

        # Scene headers: dashed yellow border when scene launch is queued
        try:
            for idx, w in (getattr(self, '_scene_headers', {}) or {}).items():
                if int(idx) in self._queued_scenes:
                    w.setStyleSheet('border: 2px dashed rgb(255,176,0);')
                else:
                    w.setStyleSheet('')
        except Exception:
            pass

        # Start/stop countdown timer
        try:
            if self._queued_slot_meta or self._queued_scene_meta:
                if not self._queue_timer.isActive():
                    self._queue_timer.start()
            else:
                if self._queue_timer.isActive():
                    self._queue_timer.stop()
        except Exception:
            pass

        # Immediate countdown label update
        try:
            self._update_scene_countdowns()
        except Exception:
            pass

        try:
            self.inner.update()
        except Exception:
            pass
        try:
            self.update()
        except Exception:
            pass

    def _make_track_header(self, trk) -> QWidget:  # noqa: ANN001
        # Left-side track header inside the launcher grid
        w = QWidget()
        w.setFixedHeight(44)
        try:
            w.setMinimumWidth(180)
        except Exception:
            pass

        lay = QHBoxLayout(w)
        lay.setContentsMargins(4, 0, 4, 0)
        lay.setSpacing(2)

        lbl = QLabel(str(getattr(trk, 'name', 'Track')))
        lbl.setToolTip(str(getattr(trk, 'name', 'Track')))
        lbl.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
        lay.addWidget(lbl, 1)

        def _try_call(fn_name: str, *args) -> None:
            try:
                fn = getattr(self.project, fn_name, None)
                if callable(fn):
                    fn(*args)
            except Exception:
                pass

        btn_m = QToolButton(); btn_m.setText('M'); btn_m.setCheckable(True)
        btn_m.setChecked(bool(getattr(trk, 'muted', False)))
        btn_m.setToolTip('Mute'); btn_m.setAutoRaise(True); btn_m.setFixedSize(22, 22)
        btn_m.clicked.connect(lambda _=False, tid=str(getattr(trk, 'id', '')), b=btn_m: _try_call('set_track_mute', tid, b.isChecked()))
        lay.addWidget(btn_m)

        btn_s = QToolButton(); btn_s.setText('S'); btn_s.setCheckable(True)
        btn_s.setChecked(bool(getattr(trk, 'solo', False)))
        btn_s.setToolTip('Solo'); btn_s.setAutoRaise(True); btn_s.setFixedSize(22, 22)
        btn_s.clicked.connect(lambda _=False, tid=str(getattr(trk, 'id', '')), b=btn_s: _try_call('set_track_solo', tid, b.isChecked()))
        lay.addWidget(btn_s)

        btn_r = QToolButton(); btn_r.setText('R'); btn_r.setCheckable(True)
        btn_r.setChecked(bool(getattr(trk, 'record_arm', False)))
        btn_r.setToolTip('Record Arm'); btn_r.setAutoRaise(True); btn_r.setFixedSize(22, 22)
        btn_r.clicked.connect(lambda _=False, tid=str(getattr(trk, 'id', '')), b=btn_r: _try_call('set_track_record_arm', tid, b.isChecked()))
        lay.addWidget(btn_r)

        return w

    def _make_scene_header(self, scene_index: int) -> QWidget:
        # Top scene header inside the launcher grid
        w = QWidget()
        w.setFixedHeight(28)
        lay = QHBoxLayout(w)
        lay.setContentsMargins(2, 0, 2, 0)
        lay.setSpacing(4)

        btn = QToolButton()
        btn.setText('▶')
        btn.setToolTip('Scene starten (Quantize via Transport)')
        btn.setAutoRaise(True)
        btn.setFixedSize(22, 22)
        btn.clicked.connect(lambda _=False, s=int(scene_index): self.launcher.launch_scene(s))
        lay.addWidget(btn, 0)

        lbl = QLabel(f"Scene {int(scene_index)}")
        lbl.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
        lay.addWidget(lbl, 1)

        # Queued countdown (right-aligned)
        lbl_q = QLabel("")
        lbl_q.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight)
        lbl_q.setFixedWidth(84)
        try:
            lbl_q.setStyleSheet("color: rgb(255,176,0);")
        except Exception:
            pass
        lay.addWidget(lbl_q, 0)
        try:
            self._scene_countdown_labels[int(scene_index)] = lbl_q
        except Exception:
            pass

        return w

    def _beats_to_seconds(self, beats: float) -> float:
        bpm = float(getattr(self.project.ctx.project, 'bpm', 120.0) or 120.0)
        return (float(beats) * 60.0) / max(1e-6, bpm)

    def _volume_to_db(self, vol: float) -> float:
        v = float(vol)
        if v <= 0.0:
            return -120.0
        if v <= 1.0:
            return -60.0 + (60.0 * v)
        v = min(v, 2.0)
        return 6.0 * (v - 1.0)

    def _db_to_gain(self, db: float) -> float:
        if db <= -120.0:
            return 0.0
        return float(10.0 ** (float(db) / 20.0))

    def _display_gain_for_volume(self, vol: float) -> tuple[float, float]:
        db = self._volume_to_db(float(vol))
        return (self._db_to_gain(db), db)

    def _get_clip(self, clip_id: str):
        return self._clip_index.get(str(clip_id))

    def _get_track_volume(self, track_id: str) -> float:
        trk = self._track_index.get(str(track_id))
        try:
            return float(getattr(trk, 'volume', 0.8) or 0.8)
        except Exception:
            return 0.8

    # --- waveform cache (ported from ArrangerCanvas)

    def _get_peaks_for_path(self, path_str: str) -> _PeaksData | None:
        if sf is None or np is None:
            return None
        if not path_str:
            return None
        try:
            p = os.path.abspath(path_str)
            st = os.stat(p)
            mtime = int(st.st_mtime_ns)
        except Exception:
            return None

        cached = self._peaks_cache.get(p)
        if cached and int(cached.mtime_ns) == mtime:
            return cached

        if p not in self._peaks_pending:
            self._peaks_pending.add(p)
            self._submit_peaks_compute(p, mtime)
        return None

    def _submit_peaks_compute(self, abs_path: str, mtime_ns: int) -> None:
        def fn():
            return self._compute_peaks(abs_path)

        def ok(res):
            try:
                if res is None:
                    return
                peaks_arr, sr, bs = res
                self._peaks_cache[str(abs_path)] = _PeaksData(
                    mtime_ns=int(mtime_ns),
                    block_size=int(bs),
                    samplerate=int(sr),
                    peaks=peaks_arr,
                )
            finally:
                self._peaks_pending.discard(str(abs_path))
                try:
                    self.inner.update()
                except Exception:
                    pass
                self.update()

        def err(_msg: str):
            self._peaks_pending.discard(str(abs_path))

        try:
            self.project._submit(fn, ok, err)  # type: ignore[attr-defined]
        except Exception:
            try:
                res = self._compute_peaks(abs_path)
                if res is not None:
                    peaks_arr, sr, bs = res
                    self._peaks_cache[str(abs_path)] = _PeaksData(
                        mtime_ns=int(mtime_ns),
                        block_size=int(bs),
                        samplerate=int(sr),
                        peaks=peaks_arr,
                    )
            finally:
                self._peaks_pending.discard(str(abs_path))
                try:
                    self.inner.update()
                except Exception:
                    pass
                self.update()

    def _compute_peaks(self, abs_path: str):
        if sf is None or np is None:
            return None
        try:
            f = sf.SoundFile(abs_path)
        except Exception:
            return None

        block_size = 2048
        sr = int(getattr(f, 'samplerate', 48000) or 48000)
        peaks_list = []
        try:
            for block in f.blocks(blocksize=block_size, dtype='float32', always_2d=True):
                if block is None or block.shape[0] == 0:
                    continue
                a = np.max(np.abs(block), axis=1)
                peaks_list.append(float(np.max(a)))
        except Exception:
            try:
                data = f.read(dtype='float32', always_2d=True)
                if data is None or data.shape[0] == 0:
                    return None
                a = np.max(np.abs(data), axis=1)
                n = int(a.shape[0])
                n_chunks = (n + block_size - 1) // block_size
                for i in range(n_chunks):
                    s = i * block_size
                    e = min(n, (i + 1) * block_size)
                    peaks_list.append(float(np.max(a[s:e])))
            except Exception:
                return None
        finally:
            try:
                f.close()
            except Exception:
                pass

        if not peaks_list:
            return None
        arr = np.asarray(peaks_list, dtype='float32')
        arr = np.clip(arr, 0.0, 1.0)
        return arr, sr, block_size

    def _draw_audio_waveform(self, p: QPainter, rect: QRectF, clip, track_volume: float) -> None:
        peaks = self._get_peaks_for_path(str(getattr(clip, 'source_path', '') or ''))
        if peaks is None or np is None:
            p.setPen(QPen(self.palette().mid().color()))
            p.drawText(rect.adjusted(4, 0, -4, 0), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, 'Waveform…')
            return

        beats_to_sec = self._beats_to_seconds(1.0)
        offset_sec = float(getattr(clip, 'offset_seconds', 0.0) or 0.0)
        length_sec = float(getattr(clip, 'length_beats', 0.0) or 0.0) * beats_to_sec
        if length_sec <= 0.0:
            return

        start_i = int(max(0.0, offset_sec * peaks.peaks_per_second))
        end_i = int(max(start_i + 1, (offset_sec + length_sec) * peaks.peaks_per_second))
        seg = peaks.peaks[start_i:min(end_i, len(peaks.peaks))]
        if seg.size == 0:
            return

        n = max(8, int(rect.width()))
        if seg.size != n:
            x_old = np.linspace(0.0, 1.0, num=int(seg.size), dtype=np.float32)
            x_new = np.linspace(0.0, 1.0, num=int(n), dtype=np.float32)
            seg = np.interp(x_new, x_old, seg).astype(np.float32)

        gain, _db = self._display_gain_for_volume(track_volume)
        seg = np.clip(seg * float(gain), 0.0, 1.0)

        mid_y = rect.center().y()
        amp_h = rect.height() * 0.45

        p.setPen(QPen(self.palette().text().color()))
        x0 = int(rect.left())
        top = rect.top()
        bottom = rect.bottom()
        for i, a in enumerate(seg):
            if float(a) <= 0.0005:
                continue
            x = x0 + i
            dy = float(a) * amp_h
            y1 = max(top, mid_y - dy)
            y2 = min(bottom, mid_y + dy)
            p.drawLine(int(x), int(y1), int(x), int(y2))


    def _clear_grid(self) -> None:
        while self.grid.count():
            it = self.grid.takeAt(0)
            w = it.widget()
            if w:
                w.deleteLater()

    def refresh(self) -> None:
        self._clear_grid()
        self._slot_buttons = {}

        q = getattr(self.project.ctx.project, "launcher_quantize", "1 Bar")
        m = getattr(self.project.ctx.project, "launcher_mode", "Trigger")
        self.cmb_quant.setCurrentText(q if q in ["Off", "1 Beat", "1 Bar"] else "1 Bar")
        self.cmb_mode.setCurrentText(m if m in ["Trigger", "Toggle", "Gate"] else "Trigger")

        tracks = self._tracks()

        # index for fast lookup in slot paintEvent
        try:
            self._clip_index = {str(c.id): c for c in (self.project.ctx.project.clips or [])}
        except Exception:
            self._clip_index = {}
        try:
            self._track_index = {str(t.id): t for t in (self.project.ctx.project.tracks or [])}
        except Exception:
            self._track_index = {}

        # Active play-state snapshot (UI-only)
        try:
            fn = getattr(self.project, 'cliplauncher_active_slots', None)
            self._active_slots = set(str(k) for k in (fn() if callable(fn) else []))
        except Exception:
            self._active_slots = set()

        # Queued-state snapshot (UI-only)
        try:
            ps = getattr(self.launcher, 'pending_snapshot', None)
            pending = ps() if callable(ps) else []
            self._on_pending_changed(pending)
        except Exception:
            pass

        # Bitwig-style: columns = scenes, rows = tracks
        self._scene_headers = {}
        self._scene_countdown_labels = {}
        self.grid.addWidget(QLabel("Track"), 0, 0)

        for col, scene_idx in enumerate(range(1, self.scene_count + 1), start=1):
            sh = self._make_scene_header(scene_idx)
            try:
                self._scene_headers[int(scene_idx)] = sh
            except Exception:
                pass
            self.grid.addWidget(sh, 0, col)

        for row, trk in enumerate(tracks, start=1):
            try:
                self.grid.addWidget(self._make_track_header(trk), row, 0)
            except Exception:
                lbl = QLabel(str(getattr(trk, 'name', 'Track')))
                lbl.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
                self.grid.addWidget(lbl, row, 0)

            for col, scene_idx in enumerate(range(1, self.scene_count + 1), start=1):
                key = self._slot_key(scene_idx, trk.id)
                btn = SlotWaveButton(self)
                btn.setMinimumHeight(44)
                btn.setProperty("slot_key", key)

                cid = self.project.ctx.project.clip_launcher.get(key, "")
                btn.setProperty("clip_id", cid)

                if cid:
                    clip = next((c for c in self.project.ctx.project.clips if c.id == cid), None)
                    btn.setText(clip.label if clip else "Missing")
                else:
                    btn.setText("Empty")

                btn.clicked.connect(lambda _=False, k=key: self._slot_clicked(k))
                btn.double_clicked.connect(lambda k=key: self._slot_double_click(k))
                btn.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
                btn.customContextMenuRequested.connect(lambda _pos, b=btn: self._slot_menu(b))

                try:
                    self._slot_buttons[str(key)] = btn
                except Exception:
                    pass

                self.grid.addWidget(btn, row, col)

        self.grid.setRowStretch(len(tracks) + 1, 1)
        # Restore selection visuals after a full rebuild
        try:
            self._apply_selected_slot_state()
        except Exception:
            pass


    def _handle_slot_drop(self, btn: SlotButton, event) -> None:  # noqa: ANN001
        key = str(btn.property("slot_key") or "")
        if not key:
            return
        clip_id = bytes(event.mimeData().data("application/x-pydaw-clipid")).decode("utf-8")
        if clip_id:
            # v0.0.11: arm + launch
            # v0.0.20.154: Ctrl+Drag duplicates the clip (creates a new clip instance) before assigning.
            do_duplicate = False
            try:
                if event.mimeData().hasFormat("application/x-pydaw-clipid-dup"):
                    do_duplicate = True
            except Exception:
                pass
            try:
                if bool(event.keyboardModifiers() & Qt.KeyboardModifier.ControlModifier):
                    do_duplicate = True
            except Exception:
                pass

            assign_cid = str(clip_id)
            if do_duplicate:
                try:
                    parsed = self._parse_slot_key(key)
                    if parsed:
                        _scene, track_id = parsed
                        fn = getattr(self.project, 'clone_clip_for_launcher', None)
                        if callable(fn):
                            new_id = fn(str(clip_id), target_track_id=str(track_id))
                            if new_id:
                                assign_cid = str(new_id)
                except Exception:
                    pass

            self.project.cliplauncher_assign(key, assign_cid)
            self.launcher.launch_slot(key)

    def _slot_clicked(self, slot_key: str) -> None:
        """Left click on a slot: select it + open it in the editor (NO auto-play).

        Bitwig/Ableton UX:
        - single click selects + focuses the editor
        - launching happens via the small ▶ button inside the slot
        """
        try:
            self._set_selected_slot(str(slot_key))
        except Exception:
            pass

        cid = self.project.ctx.project.clip_launcher.get(str(slot_key), "")
        if cid:
            # Open editor (MainWindow handles this via _on_clip_activated)
            try:
                self.clip_activated.emit(str(cid))
            except Exception:
                pass

            # Inspector direkt updaten (schneller als über ClipContext)
            if self.inspector:
                try:
                    self.inspector.set_clip(str(cid))
                except Exception:
                    pass

            # ClipContextService benachrichtigen (Pro-DAW-Style)
            if self.clip_context:
                parts = str(slot_key).split(":")
                if len(parts) == 4 and parts[0] == "scene" and parts[2] == "track":
                    try:
                        scene_idx = int(parts[1])
                        track_id = parts[3]
                        self.clip_context.set_active_slot(scene_idx, track_id, str(cid))
                    except Exception:
                        pass


    def _launch(self, slot_key: str) -> None:
        """Slot launchen und ClipContextService + Inspector benachrichtigen."""
        self.launcher.launch_slot(slot_key)
        cid = self.project.ctx.project.clip_launcher.get(slot_key, "")
        if cid:
            self.clip_activated.emit(cid)
            
            # Inspector direkt updaten (schneller als über ClipContext)
            if self.inspector:
                try:
                    self.inspector.set_clip(cid)
                except Exception:
                    pass
            
            # ClipContextService benachrichtigen (Pro-DAW-Style)
            if self.clip_context:
                # slot_key Format: "scene:X:track:Y"
                parts = slot_key.split(":")
                if len(parts) == 4 and parts[0] == "scene" and parts[2] == "track":
                    try:
                        scene_idx = int(parts[1])
                        track_id = parts[3]
                        self.clip_context.set_active_slot(scene_idx, track_id, cid)
                    except Exception:
                        pass

    def _slot_double_click(self, slot_key: str) -> None:
        """Doppelklick auf Slot -> Loop-Editor oder Audio Event Editor öffnen."""
        cid = self.project.ctx.project.clip_launcher.get(slot_key, "")
        if not cid or not self.clip_context:
            return
            
        clip = self.project.get_clip(cid)
        if not clip:
            return
            
        # Audio Clip -> Audio Event Editor (wie in v0.0.19.7.49 implementiert)
        if str(getattr(clip, 'kind', '')) == 'audio':
            try:
                from pydaw.ui.audio_event_editor import AudioEventEditor
                dialog = AudioEventEditor(clip, self.project, parent=self)
                dialog.exec()
            except Exception as e:
                self.project.error.emit(f"Fehler beim Öffnen des Event Editors: {e}")
        else:
            # MIDI/andere -> Loop-Editor
            self.clip_context.open_loop_editor(cid)

    def _slot_menu(self, btn: SlotButton) -> None:
        key = str(btn.property("slot_key") or "")
        if not key:
            return

        # Remember selection for Ctrl+C/V/Del on the grid
        try:
            self._set_selected_slot(key)
        except Exception:
            pass

        cid = self.project.ctx.project.clip_launcher.get(key, "")
        
        menu = QMenu(self)
        a_assign = menu.addAction("Ausgewählten Clip zuweisen")
        a_select = menu.addAction("Clip auswählen")
        
        # NEU: Loop-Editor nur wenn Clip zugewiesen ist
        a_loop_editor = None
        if cid and self.clip_context:
            menu.addSeparator()
            a_loop_editor = menu.addAction("Loop-Editor öffnen...")
        
        menu.addSeparator()
        a_clear = menu.addAction("Slot leeren")

        act = menu.exec(btn.mapToGlobal(btn.rect().center()))
        if act == a_assign:
            active_cid = self.project.active_clip_id
            if active_cid:
                self.project.cliplauncher_assign(key, active_cid)
        elif act == a_clear:
            self.project.cliplauncher_clear(key)
        elif act == a_select:
            if cid:
                self.project.select_clip(cid)
                self.clip_activated.emit(cid)
        elif a_loop_editor and act == a_loop_editor:
            # Loop-Editor öffnen
            if self.clip_context:
                self.clip_context.open_loop_editor(cid)