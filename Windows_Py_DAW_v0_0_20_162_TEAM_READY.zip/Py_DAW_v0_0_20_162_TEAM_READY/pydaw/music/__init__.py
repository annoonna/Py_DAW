"""Music helpers (scales, theory utilities).

This package is intentionally small.

Current focus: *Scale constraint* shared by Piano Roll and Notation.
"""
