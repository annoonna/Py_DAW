"""Windows-specific Qt initialization (must run BEFORE importing PyQt6).

We use conservative defaults to avoid common crash/black-screen issues on
Windows when the GPU/driver stack is unstable.

Configurable via env:
  - PYDAW_QT_OPENGL: "angle" (default on Windows), "desktop", "software"
  - PYDAW_QT_RHI: "d3d11" (default), "opengl", "software"
"""

from __future__ import annotations

import os
import platform


def configure_windows_qt() -> None:
    if platform.system().lower() != "windows":
        return

    # Audio defaults (safe)
    os.environ.setdefault("PYDAW_SD_HOSTAPI", "wasapi")

    qt_opengl = (os.environ.get("PYDAW_QT_OPENGL", "") or "angle").strip().lower()
    qt_rhi = (os.environ.get("PYDAW_QT_RHI", "") or "d3d11").strip().lower()

    # Qt widgets (OpenGL) backend
    if qt_opengl == "angle":
        os.environ.setdefault("QT_OPENGL", "angle")
        os.environ.setdefault("QT_ANGLE_PLATFORM", "d3d11")
    elif qt_opengl == "software":
        os.environ.setdefault("QT_OPENGL", "software")
    else:
        os.environ.setdefault("QT_OPENGL", "desktop")

    # Qt Quick / RHI backend (future-proof)
    if qt_rhi:
        os.environ.setdefault("QSG_RHI_BACKEND", qt_rhi)
