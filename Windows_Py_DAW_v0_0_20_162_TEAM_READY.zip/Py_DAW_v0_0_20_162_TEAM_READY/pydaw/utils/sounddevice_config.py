"""sounddevice (PortAudio) configuration helpers.

Goals:
- Prefer WASAPI on Windows (stable + low-latency)
- Best-effort automatic device selection for output/input
- Optional WASAPI Exclusive Mode via env: PYDAW_WASAPI_EXCLUSIVE=1

This module stays safe to import even if sounddevice isn't installed.
Functions take the imported `sounddevice` module as an argument.
"""

from __future__ import annotations

import os
import platform
from typing import Any, Optional


def _is_windows() -> bool:
    try:
        return platform.system().lower() == "windows"
    except Exception:
        return False


def preferred_hostapi() -> str | None:
    v = os.environ.get("PYDAW_SD_HOSTAPI", "").strip().lower()
    if v:
        return v
    return "wasapi" if _is_windows() else None


def _find_hostapi_index(sd: Any, name: str) -> Optional[int]:
    try:
        hostapis = sd.query_hostapis()
        for i, ha in enumerate(hostapis):
            ha_name = str(ha.get("name", "")).lower()
            if name.lower() in ha_name:
                return i
    except Exception:
        return None
    return None


def resolve_output_device(sd: Any) -> Optional[int]:
    """Return a PortAudio device index for output, best-effort."""
    pref = preferred_hostapi()
    try:
        if pref:
            ha_idx = _find_hostapi_index(sd, pref)
            if ha_idx is not None:
                ha = sd.query_hostapis(ha_idx)
                devs = ha.get("devices", []) or []

                default_out = ha.get("default_output_device", None)
                if isinstance(default_out, int) and default_out >= 0:
                    return int(default_out)

                for d in devs:
                    try:
                        info = sd.query_devices(d)
                        if int(info.get("max_output_channels", 0)) > 0:
                            return int(d)
                    except Exception:
                        continue
    except Exception:
        pass

    # Fallback: global default output device
    try:
        d = sd.default.device
        if isinstance(d, (tuple, list)) and len(d) == 2:
            return int(d[1]) if d[1] is not None else None
    except Exception:
        pass
    return None


def resolve_input_device(sd: Any) -> Optional[int]:
    """Return a PortAudio device index for input, best-effort."""
    pref = preferred_hostapi()
    try:
        if pref:
            ha_idx = _find_hostapi_index(sd, pref)
            if ha_idx is not None:
                ha = sd.query_hostapis(ha_idx)
                devs = ha.get("devices", []) or []

                default_in = ha.get("default_input_device", None)
                if isinstance(default_in, int) and default_in >= 0:
                    return int(default_in)

                for d in devs:
                    try:
                        info = sd.query_devices(d)
                        if int(info.get("max_input_channels", 0)) > 0:
                            return int(d)
                    except Exception:
                        continue
    except Exception:
        pass

    # Fallback: global default input device
    try:
        d = sd.default.device
        if isinstance(d, (tuple, list)) and len(d) == 2:
            return int(d[0]) if d[0] is not None else None
    except Exception:
        pass
    return None


def resolve_extra_settings(sd: Any) -> Any | None:
    """Return sounddevice extra_settings, e.g. WASAPI exclusive mode."""
    if not _is_windows():
        return None
    if os.environ.get("PYDAW_WASAPI_EXCLUSIVE", "0").strip().lower() not in ("1", "true", "yes", "on"):
        return None
    try:
        return sd.WasapiSettings(exclusive=True)
    except Exception:
        return None
