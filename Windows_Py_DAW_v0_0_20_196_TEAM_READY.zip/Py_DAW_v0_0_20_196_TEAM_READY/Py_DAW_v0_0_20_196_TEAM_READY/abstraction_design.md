# Abstraction Design (Plattform-Schicht) — Linux ↔ Windows

**Datum:** 2026-03-02  
**Ziel:** Windows support additiv, ohne Linux zu verändern.  
**Prinzip:** *Strikte Schichtentrennung* — Call-Sites werden schrittweise auf die Abstraktion umgestellt.

---

## 1) Paket-Struktur (Vorschlag)

Wir verwenden **`pydaw/platform/`** (bewusst NICHT `platform/`, um stdlib-shadowing zu vermeiden).

```
pydaw/platform/
├── __init__.py
├── system.py      # OS-Erkennung + Tags
├── paths.py       # config/data/cache via platformdirs (+ fallback)
├── audio.py       # optional: sounddevice env (ASIO), default backend decisions
└── restart.py     # restart strategy (posix exec vs windows spawn)
```

✅ Diese Struktur wurde bereits als Skeleton hinzugefügt (noch ohne harte Verkabelung im restlichen Code).

---

## 2) Abstraktions-Ziele

### 2.1 Paths (High Priority)
Problem: aktuell existieren `~/.cache/...` Strings und `/run/user/1000/...` im Code.

**API:**
- `paths.cache_dir(app_name) -> Path`
- `paths.config_dir(app_name) -> Path`
- `paths.data_dir(app_name) -> Path`
- `paths.ensure_dir(path) -> Path`

**Migration-Plan (safe):**
- Phase 1: nur neue Helper + optionales Logging/Prefs lenken
- Phase 2: an jeder Stelle:
  - *lesen*: erst neuer Pfad, dann fallback auf alten Pfad (Backward Compat)
  - *schreiben*: neuer Pfad

### 2.2 Audio (Medium Priority)
Ziel: Windows soll sauber `sounddevice` nutzen, optional ASIO.

**API:**
- `audio.configure_sounddevice_for_windows()`
  - setzt (opt-in) `SD_ENABLE_ASIO=1` **vor** dem ersten `import sounddevice`
  - aktivierbar via env `PYDAW_ENABLE_ASIO=1`

Hinweis: Sounddevice/PortAudio installiert auf Windows die DLLs mit pip automatisch; ASIO ist optional. citeturn1view3

### 2.3 Restart (Low/Medium Priority)
Linux nutzt `execvpe()` um das Terminal „zu behalten“.  
Windows ist oft stabiler mit `subprocess.Popen + exit`.

**API:**
- `restart.restart_self(argv=None, env=None)`

---

## 3) Synth / SF2 / Rendering Abstraktion (später)

Wir haben derzeit 2 Wege:

1) **Render-to-WAV** (MIDI→WAV) via CLI `fluidsynth` (`pydaw/audio/midi_render.py`)
2) **Live Synth** via pyfluidsynth (`pydaw/notation/audio/direct_synth.py`)

Später sollten beide über ein Interface laufen:

```
class Sf2Renderer(Protocol):
    def is_available(self) -> bool
    def render_midi_to_wav(sf2_path, midi_path, wav_path, sr) -> None
```

- Linux: CLI `fluidsynth` ist ok (bewährt)
- Windows: CLI oder Binding (je nach Installation)  
  (FluidSynth kennt Windows Treiber wie `wasapi`/`dsound`). citeturn3search6turn3search1

---

## 4) Umsetzung in Phasen (Team-safe)

### Phase 0 (JETZT, done)
- platform_audit.md erstellt
- requirements: Linux-only Marker für JACK-Client
- Boot-Safety: Notation DirectSynth crasht nicht mehr ohne pyfluidsynth/SF2
- pydaw/platform Skeleton + Tests

### Phase 1 (nächste Iteration)
- `fluidsynth_service.py`: PipeWire detect ohne hard-coded UID
- `logging_setup.py` + `device_prefs.py` → platformdirs (mit fallback auf alte Pfade)
- Optional: Windows Restart helper in MainWindow nutzen

### Phase 2
- `midi_render.py` abstrahieren (CLI vs Binding)
- Audio Settings Dialog: hostapi/device labeling (WASAPI/MME/ASIO) verbessern

---

## 5) Tests (Minimal, CI-freundlich)

- `tests/test_platform_paths.py`
- `tests/test_audio_defaults.py`

Diese Tests sind bewusst „device-frei“ (keine echten Audio Devices notwendig).

