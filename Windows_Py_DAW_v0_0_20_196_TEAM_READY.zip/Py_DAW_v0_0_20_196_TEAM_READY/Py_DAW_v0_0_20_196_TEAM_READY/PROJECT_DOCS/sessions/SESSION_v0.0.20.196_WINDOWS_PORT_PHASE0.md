# Session: v0.0.20.196 — Windows Port Phase 0 (Audit + Boot‑Safety)

**Datum:** 2026-03-02  
**Assignee:** GPT‑5.2 Thinking (ChatGPT)  
**Direktive:** Nichts kaputt machen (Linux bleibt 1:1).

---

## Ziel
Windows‑Portierung vorbereiten, ohne Linux zu brechen:
1) Plattform-Audit der Codebasis (Audio, Synth, Pfade, Subprocess, Grafik)  
2) Abstraktionsdesign dokumentieren  
3) Sofortige „Boot-Safety“ Fixes, damit Windows nicht schon beim Start crasht

---

## Erledigt (✅)
### 1) Dependencies / Install (Windows-safe)
- `requirements.txt`: `JACK-Client` auf Linux-only Marker gesetzt.
- `platformdirs` hinzugefügt (noch nicht überall wired).
- `requirements_windows.txt`: Wrapper + optionale Extras dokumentiert.
- `install.py`: nutzt unter Windows automatisch `requirements_windows.txt` (falls vorhanden).

### 2) Boot-Safety: Notation Synth (pyfluidsynth optional)
- `pydaw/notation/audio/direct_synth.py`
  - vorher: unbedingtes `import fluidsynth` + `pulseaudio` + harter `/usr/share` SF2 → Crash-Risiko
  - jetzt: try/except + `DummySynth` fallback (silent)
  - OS‑Treiberwahl: win (`wasapi/dsound/...`), mac (`coreaudio`), linux (`pulseaudio/jack/alsa`)
  - SF2 via `PYDAW_SF2_PATH`

### 3) Docs + Plattform-Schicht Skeleton
- `platform_audit.md` (Fundstellen + Risiken + nächste Schritte)
- `abstraction_design.md` (pydaw/platform Struktur + Migration in Phasen)
- Neues Paket: `pydaw/platform/*`
- Tests: `tests/test_platform_paths.py`, `tests/test_audio_defaults.py`

### 4) Backups (Vorher/Nachher)
- `PROJECT_DOCS/backups/v0.0.20.195_to_196/*` enthält Kopien aller geänderten Dateien.

---

## Geänderte Dateien (Liste)
- requirements.txt
- requirements_windows.txt
- install.py
- pydaw/notation/audio/direct_synth.py
- pydaw/platform/__init__.py
- pydaw/platform/system.py
- pydaw/platform/paths.py
- pydaw/platform/audio.py
- pydaw/platform/restart.py
- tests/__init__.py
- tests/test_platform_paths.py
- tests/test_audio_defaults.py
- platform_audit.md
- abstraction_design.md
- PROJECT_DOCS/progress/TODO.md
- PROJECT_DOCS/progress/DONE.md

---

## Nächste Schritte (für v0.0.20.197+)
1) `fluidsynth_service.py`: PipeWire detect ohne hard-coded UID (`/run/user/1000/...`)
2) Pfade: `logging_setup.py` / `device_prefs.py` / recordings cache → `platformdirs` + Backward‑Compat
3) Optional: Windows Restart via `pydaw.platform.restart` (nur wenn benötigt)
4) MIDI Render: `midi_render.py` abstrahieren (CLI vs Binding)

