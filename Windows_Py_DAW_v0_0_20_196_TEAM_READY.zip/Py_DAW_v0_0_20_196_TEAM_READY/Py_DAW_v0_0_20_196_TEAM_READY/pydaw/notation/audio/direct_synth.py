# ChronoScaleStudio – direkter Audio-Synth (FluidSynth via Python-Bindings)
# Fokus: stabile Wiedergabe + Lautstärkeregelung (CC7) für UI-Drehregler & Automation.
#
# IMPORTANT (Portability):
# - This module must NEVER hard-crash the whole app on import.
# - FluidSynth/pyfluidsynth is OPTIONAL.
# - On Windows, audio driver names differ (wasapi/dsound).
#
# Result:
# - If FluidSynth or a SoundFont is missing, we provide a silent DummySynth.
#   The rest of the DAW remains fully usable (no feature removed).

from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from typing import Optional

try:
    import fluidsynth  # pyfluidsynth bindings
    _FS_OK = True
    _FS_ERR = ""
except Exception as e:  # pragma: no cover
    fluidsynth = None  # type: ignore
    _FS_OK = False
    _FS_ERR = str(e)


def _clamp(v: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, int(v)))


def _default_soundfont_path() -> Optional[Path]:
    """Best-effort SF2 lookup.

    Priority:
    1) PYDAW_SF2_PATH env var (absolute or relative to project root)
    2) Linux distro default: /usr/share/sounds/sf2/FluidR3_GM.sf2
    3) Project-local: ./soundfonts/FluidR3_GM.sf2 (user may add it manually)
    """
    env = os.environ.get("PYDAW_SF2_PATH")
    if env:
        p = Path(env)
        if not p.is_absolute():
            # try relative to repo root (../../.. from this file)
            try:
                repo = Path(__file__).resolve()
                # pydaw/notation/audio/direct_synth.py -> repo root = parents[4]
                root = repo.parents[4]
                p2 = (root / p).resolve()
                if p2.exists():
                    return p2
            except Exception:
                pass
        if p.exists():
            return p

    linux_default = Path("/usr/share/sounds/sf2/FluidR3_GM.sf2")
    if linux_default.exists():
        return linux_default

    try:
        repo = Path(__file__).resolve().parents[4]
        local = repo / "soundfonts" / "FluidR3_GM.sf2"
        if local.exists():
            return local
    except Exception:
        pass

    return None


def _candidate_drivers() -> list[str]:
    """Return preferred FluidSynth audio drivers for the current OS."""
    if sys.platform == "win32":
        # FluidSynth supports these on Windows (depending on build).
        return ["wasapi", "dsound", "portaudio", "waveout"]
    if sys.platform == "darwin":
        return ["coreaudio"]
    # Linux / BSD: PipeWire often exposes PulseAudio compatibility
    return ["pulseaudio", "jack", "alsa", "oss"]


class DummySynth:
    """Silent fallback used when FluidSynth is unavailable."""

    available = False

    def __init__(self, reason: str = "") -> None:
        self.reason = reason or "FluidSynth nicht verfügbar"

    # API compatible methods (no-ops)
    def set_channel_volume(self, value: int) -> None:
        return

    def get_channel_volume(self) -> int:
        return 0

    def note_on(self, pitch: int, velocity: int = 90) -> None:
        return

    def note_off(self, pitch: int) -> None:
        return

    def play_scale(self, intervals_cent, root_midi=60, duration=0.35, on_note=None, velocity: int = 90):  # noqa: ANN001
        # still calls callbacks so UI can animate
        if on_note:
            for idx in range(len(intervals_cent or [])):
                on_note(idx)
                time.sleep(duration)
            on_note(-1)


class DirectSynth:
    def __init__(self):
        if not _FS_OK:
            raise RuntimeError(f"pyfluidsynth import failed: {_FS_ERR}")

        sf2 = _default_soundfont_path()
        if not sf2 or not sf2.exists():
            raise RuntimeError(
                "Kein SF2 SoundFont gefunden. Setze PYDAW_SF2_PATH auf eine .sf2 Datei "
                "(z.B. FluidR3_GM.sf2)."
            )

        self._sf2_path = sf2
        self.fs = fluidsynth.Synth()  # type: ignore[attr-defined]

        # Pick an audio driver that works on this OS.
        last_err = None
        for drv in _candidate_drivers():
            try:
                # pyfluidsynth uses start(driver=...)
                self.fs.start(driver=drv)
                last_err = None
                break
            except Exception as e:  # pragma: no cover
                last_err = e
                continue
        if last_err is not None:
            raise RuntimeError(f"FluidSynth start failed (drivers={_candidate_drivers()}): {last_err}")

        # Load soundfont + select program 0
        try:
            self.sfid = self.fs.sfload(str(self._sf2_path))
            self.fs.program_select(0, self.sfid, 0, 0)
        except Exception as e:
            raise RuntimeError(f"SoundFont laden fehlgeschlagen: {self._sf2_path}: {e}") from e

        self._volume_cc7 = 100  # 0..127
        self.available = True
        self.set_channel_volume(self._volume_cc7)

    # ---------- Lautstärke ----------
    def set_channel_volume(self, value: int):
        """Setzt MIDI-Channel-Volume (CC7)."""
        value = _clamp(value, 0, 127)
        self._volume_cc7 = value
        # CC: 7 = Channel Volume
        try:
            self.fs.cc(0, 7, value)
        except Exception:
            pass

    def get_channel_volume(self) -> int:
        return int(getattr(self, "_volume_cc7", 0))

    # ---------- Note I/O ----------
    def note_on(self, pitch: int, velocity: int = 90):
        try:
            self.fs.noteon(0, _clamp(pitch, 0, 127), _clamp(velocity, 1, 127))
        except Exception:
            pass

    def note_off(self, pitch: int):
        try:
            self.fs.noteoff(0, _clamp(pitch, 0, 127))
        except Exception:
            pass

    # ---------- Convenience ----------
    def play_scale(self, intervals_cent, root_midi=60, duration=0.35, on_note=None, velocity: int = 90):  # noqa: ANN001
        for index, cent in enumerate(intervals_cent or []):
            note = root_midi + round(float(cent) / 100.0)

            if on_note:
                on_note(index)

            self.note_on(note, velocity=velocity)
            time.sleep(duration)
            self.note_off(note)

        if on_note:
            on_note(-1)


# Global singleton (used by notation playback worker)
try:
    SYNTH = DirectSynth()
except Exception as e:  # pragma: no cover
    SYNTH = DummySynth(reason=str(e))
