# Platform Audit (Linux → Windows) — v0.0.20.195 → v0.0.20.196

**Datum:** 2026-03-02  
**Oberste Direktive:** *Nichts kaputt machen* (Linux bleibt 1:1 funktional).  
**Scope dieses Audits:** Fundstellen mit plattformspezifischen Annahmen (Audio, Synth, Pfade, Subprocess, Grafik).

---

## 1) Audio-Subsystem (Playback/Record/Routing)

### 1.1 Backends im Code (Bestandsaufnahme)

**Primär / Realtime Playback**
- `pydaw/audio/audio_engine.py`
  - Unterstützt bereits **`sounddevice` (PortAudio)** und optional **`jack`** (PipeWire‑JACK).  
  - `Backend = ["jack", "sounddevice", "none"]`

**JACK Integration (Routing in qpwgraph)**
- `pydaw/services/jack_client_service.py`
  - JACK client ist **standardmäßig aus** (env: `PYDAW_ENABLE_JACK=1` aktiviert).
  - `import jack` passiert **lazy** (in Methoden), d.h. fehlender JACK‑Support crasht nicht beim Import.

**Recording**
- `pydaw/services/recording_service.py`
  - Backend‑Autodetect: versucht `import jack` → sonst `sounddevice` (PipeWire kann als Device erscheinen).

### 1.2 Windows-Risiken / Annahmen

- **`JACK-Client` (Python Paket)**
  - benötigt native JACK‑Library; auf Windows typischerweise **nicht** als Standard vorhanden.
  - Daher muss das Paket unter Windows *nicht automatisch installiert werden*.

✅ Fix umgesetzt: `JACK-Client` wurde in `requirements.txt` auf **Linux-only** per Marker gesetzt.

---

## 2) MIDI / SoundFont (SF2) / Synth

### 2.1 Render-to-WAV via fluidsynth CLI (Subprocess)

- `pydaw/audio/midi_render.py`
  - nutzt externes Binary **`fluidsynth`** (Subprocess) zum Rendern von MIDI → WAV.
  - Fundstelle: cmd enthält `"fluidsynth"` (z.B. um Zeile ~197).

**Windows-Risiko:** `fluidsynth` ist nicht automatisch vorhanden; Pfad/Installation muss dokumentiert werden.

### 2.2 Live Synth für Notation (pyfluidsynth)

- `pydaw/notation/audio/playback_worker.py`
  - importiert `SYNTH` aus `pydaw/notation/audio/direct_synth.py` **beim Import**.

- `pydaw/notation/audio/direct_synth.py`
  - war vorher kritisch: **unbedingtes** `import fluidsynth` + `start(driver="pulseaudio")` + harter SF2‑Pfad `/usr/share/...`
  - **Windows-Risiko:** fehlendes pyfluidsynth oder falscher Treiber hätte die ganze DAW beim Start crashen können.

✅ Fix umgesetzt (boot-safe, additive):
- `direct_synth.py` ist jetzt **optional**:
  - Wenn `pyfluidsynth` oder SF2 fehlt → **DummySynth (silent)** statt Crash.
  - Treiber-Auswahl nach OS (Windows: `wasapi/dsound/...`, macOS: `coreaudio`, Linux: `pulseaudio/jack/alsa`).
  - SF2 über `PYDAW_SF2_PATH` konfigurierbar.

### 2.3 Fluidsynth Prozess (Legacy)

- `pydaw/notation/audio/synth.py`
  - Startet `fluidsynth` mit Linux‑Treibern:
    - `"-a", "pulseaudio"`
    - `"-m", "alsa_seq"`
  - Default SF2: `/usr/share/sounds/sf2/FluidR3_GM.sf2`

**Windows-Risiko:** diese Flags sind Linux‑spezifisch (ALSA/Pulse).

---

## 3) Grafik / Rendering

### 3.1 Qt/Widgets
- PyQt6 QPainter/QWidgets sind grundsätzlich plattformunabhängig.

### 3.2 Frühe Backend-Selection (Linux Vulkan default)
- `pydaw/utils/gfx_backend.py` (wird aus `main.py` vor Qt importiert)
  - Linux: Vulkan wenn Loader vorhanden, sonst OpenGL.
  - Nicht-Linux: default OpenGL (safe).

---

## 4) Pfade / Filesystem

### 4.1 Hardcodierte / Linux-typische Pfade (Fundstellen)

- `pydaw/services/fluidsynth_service.py`
  - Fixer Pfad `/run/user/1000/pipewire-0` (Zeile ~91)
  - **Problem:** UID ist hart 1000 → falsch für viele Systeme & nicht Windows-kompatibel.

- `pydaw/utils/logging_setup.py`
  - Logdir: `~/.cache/<AppName>` (Zeile ~57)

- `pydaw/ui/device_prefs.py`
  - Prefs: `~/.cache/ChronoScaleStudio/device_prefs.json`

- `pydaw/ui/main_window.py`
  - Recordings cache: `~/.cache/Py_DAW/recordings`

**Empfehlung (Design):** `platformdirs` (cross-platform) für cache/config/data, mit Backward‑Compat Fallback.

✅ Fix vorbereitet: `platformdirs` ist jetzt Dependency (noch nicht überall wired).

---

## 5) Subprocess / OS-Commands

### 5.1 `pw-jack` Restart Pfad (Linux-only)

- `pydaw/app.py`
  - Auto‑Restart via `pw-jack` wenn Backend=JACK gewählt und kein Server erreichbar.

- `pydaw/ui/main_window.py`
  - `_restart_app(via_pw_jack=True)` nutzt `os.execvpe("pw-jack", ...)`

**Windows-Risiko:** `pw-jack` existiert nicht → aktuell ist es safe, weil `which("pw-jack")` auf Windows i.d.R. None liefert und der Codepath nicht ausgeführt wird.

---

## 6) requirements / Dependencies Audit

### 6.1 requirements.txt (wichtigste Punkte)
- `sounddevice` (PortAudio) ist cross-platform.  
  - pip installiert PortAudio DLLs auf Windows automatisch; ASIO ist optional über Env‑Flag. citeturn1view3
- `JACK-Client` ist Linux-only (Marker gesetzt).
- `PyOpenGL-accelerate`, `vulkan`, `wgpu` sind bereits Linux-only (Marker vorhanden).

### 6.2 Python 3.13 / Wheels (Windows-Relevanz)
- `llvmlite` hat cp313 Wheels für Windows (Beispiel: `cp313-win_amd64.whl`). citeturn1view2
- Numba/llvmlite Release-Pair erwähnte Python 3.13 Support. citeturn0search17
- PyQt6 aktuelle Releases sind auf PyPI verfügbar (abi3, Requires Python >=3.9). citeturn2view0

---

## 7) Konkrete ToDo-Nächste Schritte (aus Audit abgeleitet)

1) **Pfade**: `~/.cache` → `platformdirs` (mit Backward-Compat lesen)  
2) **PipeWire Detect**: `/run/user/1000/...` ersetzen durch dynamische UID / env / platform check  
3) **Fluidsynth**:
   - Windows: optional `pyfluidsynth` + `PYDAW_SF2_PATH`
   - Render: `midi_render.py` später auf abstrakte Render-API umstellen (CLI vs Binding)
4) **Restart-Mechanik**:
   - Windows: ggf. `spawn + quit` statt `execvpe` (nur falls nötig)

