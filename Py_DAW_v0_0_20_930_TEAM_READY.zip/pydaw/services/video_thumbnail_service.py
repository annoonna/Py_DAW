"""video_thumbnail_service.py — VP2: Video Thumbnail Extraction + Cache (v0.0.20.924).

Extracts video frames via ffmpeg subprocess and caches them as QPixmap.
Used by ArrangerCanvas to show real video frames inside clips instead of
filmstrip patterns.

Architecture:
    - Lazy extraction: only generate thumbnails when clip becomes visible
    - In-memory LRU cache (QPixmap per frame)
    - SQLite BLOB cache (optional, for persistence across sessions)
    - Background thread extraction (non-blocking UI)

Usage:
    from pydaw.services.video_thumbnail_service import VideoThumbnailService
    
    svc = VideoThumbnailService.instance()
    pixmap = svc.get_frame(video_path, time_seconds, width=120, height=68)
    if pixmap is None:
        # Not yet extracted — will be ready on next paint
        svc.request_frames(video_path, [0.0, 1.0, 2.0], width=120, height=68)
"""

from __future__ import annotations

import hashlib
import logging
import os
import subprocess
import tempfile
import threading
from pathlib import Path
from typing import Dict, List, Optional, Tuple

log = logging.getLogger(__name__)

# Lazy Qt imports — only when actually used
_QPixmap = None
_QImage = None
_pyqtSignal = None
_QObject = None


def _ensure_qt():
    """Import Qt classes lazily to avoid import errors in headless/test environments."""
    global _QPixmap, _QImage, _pyqtSignal, _QObject
    if _QPixmap is None:
        try:
            from PyQt6.QtGui import QPixmap, QImage
            from PyQt6.QtCore import pyqtSignal, QObject
            _QPixmap = QPixmap
            _QImage = QImage
            _pyqtSignal = pyqtSignal
            _QObject = QObject
        except ImportError:
            pass


class VideoThumbnailService:
    """Singleton service for extracting and caching video thumbnails.
    
    Thread-safe: extraction happens in background threads.
    Paint calls get_frame() which returns immediately (cached or None).
    """

    _instance: Optional[VideoThumbnailService] = None

    @classmethod
    def instance(cls) -> VideoThumbnailService:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        # Cache: (video_path, time_s, w, h) → QPixmap
        self._cache: Dict[Tuple[str, float, int, int], object] = {}
        # Set of keys currently being extracted (prevent duplicate requests)
        self._pending: set = set()
        # Lock for thread safety
        self._lock = threading.Lock()
        # Max cache entries (LRU-ish: just cap total size)
        self._max_cache = 2000
        # Callbacks for when frames are ready (widget.update())
        self._on_ready_callbacks: List = []
        # ffmpeg availability check (cached)
        self._ffmpeg_available: Optional[bool] = None
        # Temp dir for frame extraction
        self._tmp_dir = os.path.join(tempfile.gettempdir(), "pydaw_thumbs")
        os.makedirs(self._tmp_dir, exist_ok=True)

    def register_on_ready(self, callback) -> None:
        """Register a callback (e.g. widget.update) called when new frames are ready."""
        if callback not in self._on_ready_callbacks:
            self._on_ready_callbacks.append(callback)

    def _check_ffmpeg(self) -> bool:
        """Check if ffmpeg is available."""
        if self._ffmpeg_available is not None:
            return self._ffmpeg_available
        try:
            result = subprocess.run(
                ["ffmpeg", "-version"],
                capture_output=True, timeout=5,
            )
            self._ffmpeg_available = (result.returncode == 0)
        except Exception:
            self._ffmpeg_available = False
        if not self._ffmpeg_available:
            log.warning("[VideoThumbs] ffmpeg not available — thumbnails disabled")
        return self._ffmpeg_available

    def get_frame(self, video_path: str, time_seconds: float,
                  width: int = 120, height: int = 68) -> Optional[object]:
        """Get a cached thumbnail frame. Returns QPixmap or None.

        Non-blocking: if frame is not cached, returns None.
        Call request_frames() to trigger background extraction.

        v0.0.20.930: Cache stores raw JPEG bytes. Conversion to QPixmap
        happens here (on the main/GUI thread) to avoid Qt6 thread crashes.
        """
        _ensure_qt()
        key = (video_path, round(time_seconds, 2), width, height)
        with self._lock:
            data = self._cache.get(key)
        if data is None:
            return None
        # Already a QPixmap (previously converted)?
        if _QPixmap is not None and isinstance(data, _QPixmap):
            return data
        # Raw bytes → QPixmap (main thread conversion)
        if isinstance(data, (bytes, bytearray)) and _QPixmap is not None:
            try:
                pix = _QPixmap()
                if pix.loadFromData(bytes(data)):
                    # Replace bytes with QPixmap in cache for next time
                    with self._lock:
                        self._cache[key] = pix
                    return pix
            except Exception:
                pass
        return None

    def get_frames_strip(self, video_path: str, start_s: float, end_s: float,
                         n_frames: int, width: int = 120,
                         height: int = 68) -> List[Optional[object]]:
        """Get a strip of N evenly-spaced frames between start and end seconds.
        
        Returns list of QPixmap|None (one per frame slot).
        """
        if n_frames <= 0 or end_s <= start_s:
            return []
        step = (end_s - start_s) / max(1, n_frames)
        frames = []
        for i in range(n_frames):
            t = start_s + i * step
            frames.append(self.get_frame(video_path, t, width, height))
        return frames

    def request_frames(self, video_path: str, times: List[float],
                       width: int = 120, height: int = 68) -> None:
        """Request extraction of frames at given times (background thread).
        
        Skips already-cached or already-pending frames.
        """
        if not self._check_ffmpeg():
            return
        if not video_path or not os.path.isfile(video_path):
            return

        to_extract = []
        with self._lock:
            for t in times:
                key = (video_path, round(t, 2), width, height)
                if key not in self._cache and key not in self._pending:
                    self._pending.add(key)
                    to_extract.append((key, round(t, 2)))

        if not to_extract:
            return

        # Background extraction thread
        thread = threading.Thread(
            target=self._extract_batch,
            args=(video_path, to_extract, width, height),
            daemon=True,
        )
        thread.start()

    def _extract_batch(self, video_path: str,
                       items: List[Tuple[tuple, float]],
                       width: int, height: int) -> None:
        """Extract multiple frames in a background thread."""
        _ensure_qt()
        if _QPixmap is None:
            return

        for key, time_s in items:
            try:
                pixmap = self._extract_single_frame(video_path, time_s, width, height)
                with self._lock:
                    if pixmap is not None:
                        # Evict oldest if cache full
                        if len(self._cache) >= self._max_cache:
                            # Remove ~10% oldest entries
                            remove_keys = list(self._cache.keys())[:self._max_cache // 10]
                            for rk in remove_keys:
                                del self._cache[rk]
                        self._cache[key] = pixmap
                    self._pending.discard(key)
            except Exception as e:
                log.debug("[VideoThumbs] extract error: %s", e)
                with self._lock:
                    self._pending.discard(key)

        # Notify registered widgets to repaint
        for cb in self._on_ready_callbacks:
            try:
                cb()
            except Exception:
                pass

    def _extract_single_frame(self, video_path: str, time_s: float,
                              width: int, height: int) -> Optional[object]:
        """Extract a single frame from video using ffmpeg.

        v0.0.20.930: Stores raw image bytes instead of QPixmap.
        QPixmap cannot be created from background threads in Qt6.
        Conversion to QPixmap happens lazily on first access from main thread.
        """
        # Build unique temp filename
        vhash = hashlib.md5(video_path.encode()).hexdigest()[:8]
        fname = f"thumb_{vhash}_{time_s:.2f}_{width}x{height}.jpg"
        out_path = os.path.join(self._tmp_dir, fname)

        try:
            cmd = [
                "ffmpeg", "-y",
                "-ss", f"{time_s:.3f}",
                "-i", video_path,
                "-vframes", "1",
                "-vf", f"scale={width}:{height}:force_original_aspect_ratio=decrease,pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:color=black",
                "-q:v", "8",
                out_path,
            ]
            result = subprocess.run(
                cmd,
                capture_output=True, timeout=10,
                stdin=subprocess.DEVNULL,
            )

            if result.returncode == 0 and os.path.isfile(out_path):
                # Read raw bytes — thread-safe, no Qt GUI objects
                with open(out_path, "rb") as f:
                    jpg_bytes = f.read()
                try:
                    os.unlink(out_path)
                except Exception:
                    pass
                if jpg_bytes:
                    return jpg_bytes  # raw JPEG bytes — converted to QPixmap on main thread
            else:
                log.debug("[VideoThumbs] ffmpeg failed for %s @%.2fs: %s",
                          video_path, time_s,
                          result.stderr.decode(errors="replace")[:200])
        except subprocess.TimeoutExpired:
            log.debug("[VideoThumbs] ffmpeg timeout for %s @%.2fs", video_path, time_s)
        except Exception as e:
            log.debug("[VideoThumbs] extraction error: %s", e)

        return None

    def invalidate(self, video_path: str = "") -> None:
        """Clear cache for a specific video, or all if empty."""
        with self._lock:
            if not video_path:
                self._cache.clear()
                self._pending.clear()
            else:
                keys_to_remove = [k for k in self._cache if k[0] == video_path]
                for k in keys_to_remove:
                    del self._cache[k]
                self._pending = {k for k in self._pending if k[0] != video_path}

    def cache_stats(self) -> dict:
        """Return cache statistics (for debugging)."""
        with self._lock:
            return {
                "cached_frames": len(self._cache),
                "pending": len(self._pending),
                "max_cache": self._max_cache,
            }
