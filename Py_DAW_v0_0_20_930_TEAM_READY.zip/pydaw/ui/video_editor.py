"""video_editor.py — Video-Editor (v0.0.20.930).

VE1: The FIRST DAW with an integrated NLE-style video editor in the
     clip editor panel — alongside Piano Roll, Audio Editor, Notation.

Features:
  - Visual timeline with real video frame thumbnails (filmstrip)
  - Beat grid overlay synced to DAW transport
  - Tools: Select, Knife (split), Trim (drag edges), Slip (shift content)
  - SMPTE timecode display (frame-accurate)
  - Scene markers from Video-KI analysis
  - Transport cursor (playhead) synced to DAW
  - Clip properties: opacity, speed, label
  - Keyboard shortcuts: S=split at playhead, Del=delete, Z=undo

What NO other DAW has:
  - Video editing INSIDE the same editor panel as MIDI/Audio
  - Beat-synced video cuts (snap to bar/beat grid)
  - AI scene markers integrated into the video timeline
  - Frame-accurate editing with SMPTE in a music DAW

Usage:
    editor = VideoEditor(project_service, transport=transport)
    editor.set_clip(clip_id)  # loads the video clip for editing
"""

from __future__ import annotations

import logging
import math
import os
import threading
from typing import Any, Dict, List, Optional, Tuple

from PyQt6.QtCore import (
    Qt, pyqtSignal, QTimer, QRectF, QPointF, QSizeF,
)
from PyQt6.QtGui import (
    QBrush, QColor, QFont, QImage, QPainter, QPen, QPixmap,
    QWheelEvent, QMouseEvent, QKeyEvent,
)
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QToolButton, QSplitter, QScrollBar, QComboBox, QDoubleSpinBox,
    QFrame, QSizePolicy, QToolBar,
)

log = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════

_HEADER_HEIGHT = 28       # ruler / time header
_TRACK_HEIGHT = 80        # clip lane height (shows frames)
_TRACK_MIN_HEIGHT = 48
_TRACK_MAX_HEIGHT = 200
_FRAME_THUMB_W = 120      # thumbnail width inside clips
_SCROLL_SPEED = 30
_DEFAULT_PX_PER_BEAT = 40

# Colors
_CLR_BG = QColor(18, 18, 28)
_CLR_HEADER = QColor(28, 28, 42)
_CLR_GRID_BAR = QColor(60, 60, 80)
_CLR_GRID_BEAT = QColor(40, 40, 55)
_CLR_PLAYHEAD = QColor(255, 80, 80)
_CLR_CLIP_BG = QColor(22, 50, 60)
_CLR_CLIP_BORDER = QColor(60, 140, 160)
_CLR_CLIP_SELECTED = QColor(100, 200, 220)
_CLR_SCENE_MARKER = QColor(255, 200, 60, 120)
_CLR_TRIM_HANDLE = QColor(255, 255, 100, 200)
_CLR_KNIFE = QColor(255, 100, 100)
_CLR_TEXT = QColor(200, 200, 216)
_CLR_SMPTE = QColor(79, 195, 247)

# Tool IDs
TOOL_SELECT = "select"
TOOL_KNIFE = "knife"
TOOL_TRIM = "trim"
TOOL_SLIP = "slip"


# ═══════════════════════════════════════════════════════════════
# Video Editor Canvas
# ═══════════════════════════════════════════════════════════════

class VideoEditorCanvas(QWidget):
    """Custom-painted video timeline canvas.

    Renders video clips as filmstrip thumbnails on a beat-synced timeline.
    All painting is done in paintEvent (no QGraphicsScene overhead).
    """

    status_message = pyqtSignal(str)
    clip_split = pyqtSignal(str, float)        # clip_id, beat_position
    clip_trimmed = pyqtSignal(str, float, str)  # clip_id, new_value, "start"|"end"

    def __init__(self, project_service, transport=None, parent=None):
        super().__init__(parent)
        self._ps = project_service
        self._transport = transport
        self._bpm = 120.0

        # View state
        self._px_per_beat = _DEFAULT_PX_PER_BEAT
        self._scroll_x = 0.0   # beats
        self._track_height = _TRACK_HEIGHT

        # Video clip state
        self._clip_id: Optional[str] = None
        self._clip = None       # reference to Clip object
        self._video_path = ""
        self._video_duration = 0.0
        self._clip_start_beats = 0.0
        self._clip_length_beats = 0.0

        # Tool state
        self._tool = TOOL_SELECT
        self._mouse_pos = QPointF(0, 0)
        self._dragging = False
        self._drag_start = QPointF(0, 0)
        self._drag_edge: Optional[str] = None  # "start" or "end" for trim
        self._selected = True

        # Scene markers from Video-KI
        self._scene_markers: List[Dict] = []

        # Thumbnail cache (reuse VideoThumbnailService)
        self._thumb_svc = None

        # Playhead timer
        self._playhead_timer = QTimer(self)
        self._playhead_timer.setInterval(33)  # ~30fps cursor
        self._playhead_timer.timeout.connect(self.update)
        self._playhead_timer.start()

        # Widget setup
        self.setMinimumHeight(140)
        self.setMinimumWidth(300)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    # ─────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────

    def set_clip(self, clip_id: Optional[str]) -> None:
        """Load a video clip for editing."""
        self._clip_id = clip_id
        self._clip = None
        self._video_path = ""
        self._video_duration = 0.0
        self._scene_markers = []

        if not clip_id:
            self.update()
            return

        try:
            proj = self._get_project()
            if not proj:
                return
            for c in proj.clips or []:
                if str(getattr(c, 'id', '')) == str(clip_id):
                    self._clip = c
                    break
            if not self._clip or str(getattr(self._clip, 'kind', '')) != 'video':
                self._clip = None
                self.update()
                return

            self._video_path = str(getattr(self._clip, 'source_path', '') or '')
            self._clip_start_beats = float(getattr(self._clip, 'start_beats', 0))
            self._clip_length_beats = float(getattr(self._clip, 'length_beats', 0))
            self._bpm = self._get_bpm()
            self._video_duration = self._clip_length_beats * 60.0 / max(1, self._bpm)

            # Center view on clip
            self._scroll_x = max(0, self._clip_start_beats - 2)

            # Request thumbnails
            self._ensure_thumb_service()

        except Exception as e:
            log.debug("[VideoEditor] set_clip: %s", e)

        self.update()

    def set_tool(self, tool: str) -> None:
        """Set the active editing tool."""
        self._tool = tool
        self.setCursor(
            Qt.CursorShape.CrossCursor if tool == TOOL_KNIFE
            else Qt.CursorShape.SizeHorCursor if tool == TOOL_TRIM
            else Qt.CursorShape.ArrowCursor
        )
        self.update()

    def set_scene_markers(self, markers: List[Dict]) -> None:
        """Set scene markers from Video-KI analysis."""
        self._scene_markers = list(markers) if markers else []
        self.update()

    def split_at_playhead(self) -> None:
        """Split the clip at the current playhead position."""
        if not self._clip:
            return
        beat = self._get_playhead_beat()
        cs = self._clip_start_beats
        ce = cs + self._clip_length_beats
        if cs < beat < ce:
            self.clip_split.emit(str(self._clip_id), beat)
            try:
                self.status_message.emit(f"✂ Video gesplittet bei Beat {beat:.1f}")
            except Exception:
                pass

    # ─────────────────────────────────────────────────────
    # Internal helpers
    # ─────────────────────────────────────────────────────

    def _get_project(self):
        try:
            proj = getattr(self._ps, 'project', None)
            if proj is None:
                ctx = getattr(self._ps, 'ctx', None)
                proj = getattr(ctx, 'project', None) if ctx else None
            return proj
        except Exception:
            return None

    def _get_bpm(self) -> float:
        try:
            if self._transport:
                return float(getattr(self._transport, 'bpm', 120.0) or 120.0)
            proj = self._get_project()
            if proj:
                return float(getattr(proj, 'bpm', 120.0) or 120.0)
        except Exception:
            pass
        return 120.0

    def _get_playhead_beat(self) -> float:
        try:
            if self._transport:
                return float(getattr(self._transport, 'current_beat', 0.0))
        except Exception:
            pass
        return 0.0

    def _beats_to_x(self, beat: float) -> float:
        return (beat - self._scroll_x) * self._px_per_beat

    def _x_to_beats(self, x: float) -> float:
        return x / self._px_per_beat + self._scroll_x

    def _snap_beat(self, beat: float, grid: float = 1.0) -> float:
        return round(beat / grid) * grid

    def _ensure_thumb_service(self) -> None:
        if self._thumb_svc is None:
            try:
                from pydaw.services.video_thumbnail_service import VideoThumbnailService
                self._thumb_svc = VideoThumbnailService.instance()
                self._thumb_svc.register_on_ready(self.update)
            except Exception:
                pass

    def _beat_to_video_seconds(self, beat: float) -> float:
        """Convert a beat position to seconds within the video file."""
        offset_s = float(getattr(self._clip, 'offset_seconds', 0) or 0) if self._clip else 0
        clip_start = self._clip_start_beats
        return (beat - clip_start) * 60.0 / max(1, self._bpm) + offset_s

    # ─────────────────────────────────────────────────────
    # Paint
    # ─────────────────────────────────────────────────────

    def paintEvent(self, event) -> None:
        w = self.width()
        h = self.height()
        if w < 10 or h < 10:
            return

        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)

        # Background
        p.fillRect(0, 0, w, h, _CLR_BG)

        bpm = self._get_bpm()
        self._bpm = bpm

        # Draw components
        self._draw_grid(p, w, h)
        self._draw_scene_markers(p, w, h)
        self._draw_clip(p, w, h)
        self._draw_header(p, w)
        self._draw_playhead(p, w, h)
        self._draw_tool_overlay(p, w, h)
        self._draw_info_bar(p, w, h)

        p.end()

    def _draw_header(self, p: QPainter, w: int) -> None:
        """Draw time ruler at top."""
        p.fillRect(0, 0, w, _HEADER_HEIGHT, _CLR_HEADER)

        font = QFont("Monospace", 8)
        p.setFont(font)

        # Draw bar numbers
        start_beat = max(0, self._scroll_x)
        end_beat = self._x_to_beats(w)

        bar_start = int(start_beat / 4)
        bar_end = int(end_beat / 4) + 2

        for bar in range(bar_start, bar_end):
            beat = bar * 4.0
            x = self._beats_to_x(beat)
            if x < -20 or x > w + 20:
                continue

            # Bar line
            p.setPen(QPen(_CLR_GRID_BAR, 1))
            p.drawLine(int(x), 0, int(x), _HEADER_HEIGHT)

            # Bar number
            p.setPen(_CLR_TEXT)
            p.drawText(int(x) + 3, _HEADER_HEIGHT - 6, f"Bar {bar + 1}")

            # SMPTE time
            secs = beat * 60.0 / max(1, self._bpm)
            m = int(secs) // 60
            s = int(secs) % 60
            f = int((secs - int(secs)) * 24)
            p.setPen(_CLR_SMPTE)
            p.drawText(int(x) + 3, 11, f"{m:02d}:{s:02d}:{f:02d}")

        # Bottom line
        p.setPen(QPen(QColor(60, 60, 80), 1))
        p.drawLine(0, _HEADER_HEIGHT - 1, w, _HEADER_HEIGHT - 1)

    def _draw_grid(self, p: QPainter, w: int, h: int) -> None:
        """Draw beat/bar grid lines."""
        start_beat = max(0, self._scroll_x)
        end_beat = self._x_to_beats(w)

        # Beat lines
        beat_start = int(start_beat)
        beat_end = int(end_beat) + 2
        for beat in range(beat_start, beat_end):
            x = int(self._beats_to_x(beat))
            if x < 0 or x > w:
                continue
            if beat % 4 == 0:
                p.setPen(QPen(_CLR_GRID_BAR, 1))
            else:
                p.setPen(QPen(_CLR_GRID_BEAT, 1, Qt.PenStyle.DotLine))
            p.drawLine(x, _HEADER_HEIGHT, x, h)

    def _draw_scene_markers(self, p: QPainter, w: int, h: int) -> None:
        """Draw Video-KI scene markers as colored vertical bands."""
        if not self._scene_markers:
            return

        for marker in self._scene_markers:
            beat = float(marker.get("beat", 0))
            x = int(self._beats_to_x(beat))
            if x < -10 or x > w + 10:
                continue

            color_str = marker.get("color", "#ffcc44")
            try:
                clr = QColor(color_str)
                clr.setAlpha(60)
            except Exception:
                clr = _CLR_SCENE_MARKER

            # Vertical line
            p.setPen(QPen(QColor(color_str), 2))
            p.drawLine(x, _HEADER_HEIGHT, x, h)

            # Label
            label = marker.get("label", "")
            if label:
                p.setPen(QColor(color_str))
                p.setFont(QFont("Monospace", 7))
                p.drawText(x + 3, _HEADER_HEIGHT + 12, label[:30])

    def _draw_clip(self, p: QPainter, w: int, h: int) -> None:
        """Draw the video clip as a filmstrip with real thumbnails."""
        if not self._clip:
            # No clip loaded — show hint
            p.setPen(_CLR_TEXT)
            p.setFont(QFont("Sans-Serif", 11))
            p.drawText(
                QRectF(0, _HEADER_HEIGHT, w, h - _HEADER_HEIGHT),
                Qt.AlignmentFlag.AlignCenter,
                "🎬 Kein Video-Clip ausgewählt\n\n"
                "Klicke auf einen Video-Clip im Arranger\n"
                "oder ziehe ein Video auf die Timeline"
            )
            return

        cs = self._clip_start_beats
        ce = cs + self._clip_length_beats

        x1 = self._beats_to_x(cs)
        x2 = self._beats_to_x(ce)

        if x2 < 0 or x1 > w:
            return

        clip_x = max(0, x1)
        clip_w = min(w, x2) - clip_x
        if clip_w < 2:
            return

        y = _HEADER_HEIGHT + 4
        ch = self._track_height

        clip_rect = QRectF(clip_x, y, clip_w, ch)

        # Clip background
        bg = _CLR_CLIP_BG
        p.fillRect(clip_rect, QBrush(bg))

        # Draw real frame thumbnails
        self._draw_filmstrip(p, clip_rect, x1, x2)

        # Clip border
        border_color = _CLR_CLIP_SELECTED if self._selected else _CLR_CLIP_BORDER
        p.setPen(QPen(border_color, 2 if self._selected else 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRect(clip_rect)

        # Trim handles (when selected)
        if self._selected:
            handle_w = 6
            # Left handle
            p.fillRect(QRectF(clip_x, y, handle_w, ch), QBrush(_CLR_TRIM_HANDLE))
            # Right handle
            p.fillRect(QRectF(clip_x + clip_w - handle_w, y, handle_w, ch),
                        QBrush(_CLR_TRIM_HANDLE))

        # Clip label
        p.setPen(_CLR_TEXT)
        p.setFont(QFont("Sans-Serif", 9, QFont.Weight.Bold))
        label = str(getattr(self._clip, 'label', '') or os.path.basename(self._video_path))
        p.drawText(int(clip_x) + 8, int(y) + 14, f"🎬 {label}")

        # Duration info
        dur_s = self._clip_length_beats * 60.0 / max(1, self._bpm)
        p.setFont(QFont("Monospace", 7))
        p.setPen(QColor(160, 200, 220))
        p.drawText(int(clip_x) + 8, int(y + ch) - 6,
                   f"{dur_s:.1f}s | {self._clip_length_beats:.1f} beats | "
                   f"{self._bpm:.0f} BPM")

    def _draw_filmstrip(self, p: QPainter, rect: QRectF, x1: float, x2: float) -> None:
        """Draw real video frame thumbnails inside the clip rectangle."""
        if not self._video_path or not os.path.isfile(self._video_path):
            return

        self._ensure_thumb_service()
        svc = self._thumb_svc
        if not svc:
            return

        x0 = rect.x()
        y0 = rect.y() + 20  # below label
        cw = rect.width()
        ch = rect.height() - 26  # leave room for label + info

        if ch < 16 or cw < 16:
            return

        thumb_h = max(16, int(ch))
        thumb_w = max(16, int(thumb_h * 16 / 9))
        n_frames = max(1, int(cw / max(8, thumb_w)))
        frame_w = cw / max(1, n_frames)

        clip_len_s = self._clip_length_beats * 60.0 / max(1, self._bpm)
        offset_s = float(getattr(self._clip, 'offset_seconds', 0) or 0) if self._clip else 0
        step_s = clip_len_s / max(1, n_frames)

        times = [offset_s + i * step_s for i in range(n_frames)]
        missing = []

        for i, t in enumerate(times):
            fx = x0 + i * frame_w
            if fx + frame_w < 0 or fx > self.width():
                continue

            pixmap = svc.get_frame(self._video_path, t, thumb_w, thumb_h)
            if pixmap is not None:
                target = QRectF(fx, y0, frame_w, ch)
                p.drawPixmap(target.toRect(), pixmap)
            else:
                # Placeholder
                p.fillRect(QRectF(fx, y0, frame_w, ch), QBrush(QColor(25, 50, 60)))
                missing.append(t)

            # Frame divider
            if i > 0:
                p.setPen(QPen(QColor(0, 0, 0, 100), 1))
                p.drawLine(int(fx), int(y0), int(fx), int(y0 + ch))

        # Request missing frames (non-blocking)
        if missing:
            svc.request_frames(self._video_path, missing, thumb_w, thumb_h)

    def _draw_playhead(self, p: QPainter, w: int, h: int) -> None:
        """Draw the transport playhead cursor."""
        beat = self._get_playhead_beat()
        x = int(self._beats_to_x(beat))
        if x < 0 or x > w:
            return

        p.setPen(QPen(_CLR_PLAYHEAD, 2))
        p.drawLine(x, 0, x, h)

        # Playhead triangle at top
        p.setBrush(QBrush(_CLR_PLAYHEAD))
        p.setPen(Qt.PenStyle.NoPen)
        from PyQt6.QtGui import QPolygonF
        tri = QPolygonF([
            QPointF(x - 5, 0),
            QPointF(x + 5, 0),
            QPointF(x, 8),
        ])
        p.drawPolygon(tri)

    def _draw_tool_overlay(self, p: QPainter, w: int, h: int) -> None:
        """Draw tool-specific overlays (knife line, etc)."""
        if self._tool == TOOL_KNIFE and self._clip:
            mx = self._mouse_pos.x()
            if 0 <= mx <= w:
                p.setPen(QPen(_CLR_KNIFE, 1, Qt.PenStyle.DashLine))
                p.drawLine(int(mx), _HEADER_HEIGHT, int(mx), h)

                # Show beat position
                beat = self._x_to_beats(mx)
                p.setPen(_CLR_KNIFE)
                p.setFont(QFont("Monospace", 8))
                p.drawText(int(mx) + 4, h - 8, f"Beat {beat:.2f}")

    def _draw_info_bar(self, p: QPainter, w: int, h: int) -> None:
        """Draw info bar at bottom."""
        bar_h = 20
        y = h - bar_h
        p.fillRect(0, y, w, bar_h, QColor(25, 25, 40))

        p.setFont(QFont("Monospace", 8))
        p.setPen(_CLR_TEXT)

        info = f"Tool: {self._tool.upper()}"
        if self._clip:
            info += f"  |  Clip: {self._clip_start_beats:.1f}–{self._clip_start_beats + self._clip_length_beats:.1f} beats"
        info += f"  |  Zoom: {self._px_per_beat:.0f}px/beat"
        info += f"  |  BPM: {self._bpm:.0f}"

        beat = self._x_to_beats(self._mouse_pos.x())
        secs = beat * 60.0 / max(1, self._bpm)
        info += f"  |  Cursor: Beat {beat:.2f} ({secs:.1f}s)"

        p.drawText(4, y + 14, info)

    # ─────────────────────────────────────────────────────
    # Mouse Events
    # ─────────────────────────────────────────────────────

    def mousePressEvent(self, event: QMouseEvent) -> None:
        self._mouse_pos = event.position()
        beat = self._x_to_beats(event.position().x())

        if event.button() == Qt.MouseButton.LeftButton:
            if self._tool == TOOL_KNIFE and self._clip:
                # Split at click position
                snapped = self._snap_beat(beat)
                cs = self._clip_start_beats
                ce = cs + self._clip_length_beats
                if cs < snapped < ce:
                    self.clip_split.emit(str(self._clip_id), snapped)
                    try:
                        self.status_message.emit(f"✂ Split bei Beat {snapped:.1f}")
                    except Exception:
                        pass
                return

            if self._tool == TOOL_TRIM and self._clip:
                cs = self._clip_start_beats
                ce = cs + self._clip_length_beats
                x_start = self._beats_to_x(cs)
                x_end = self._beats_to_x(ce)
                mx = event.position().x()
                if abs(mx - x_start) < 10:
                    self._drag_edge = "start"
                    self._dragging = True
                elif abs(mx - x_end) < 10:
                    self._drag_edge = "end"
                    self._dragging = True
                return

            if self._tool == TOOL_SELECT:
                # Click to move playhead
                if self._transport and hasattr(self._transport, 'set_position'):
                    try:
                        self._transport.set_position(beat)
                    except Exception:
                        pass

        elif event.button() == Qt.MouseButton.MiddleButton:
            self._dragging = True
            self._drag_start = event.position()
            self._drag_edge = None

        self.update()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        self._mouse_pos = event.position()

        if self._dragging:
            if event.buttons() & Qt.MouseButton.MiddleButton:
                # Pan view
                dx = event.position().x() - self._drag_start.x()
                self._scroll_x -= dx / self._px_per_beat
                self._scroll_x = max(0, self._scroll_x)
                self._drag_start = event.position()

            elif self._drag_edge and self._clip:
                beat = self._snap_beat(self._x_to_beats(event.position().x()))
                if self._drag_edge == "start":
                    new_start = max(0, beat)
                    if new_start < self._clip_start_beats + self._clip_length_beats - 0.25:
                        diff = new_start - self._clip_start_beats
                        self._clip_start_beats = new_start
                        self._clip_length_beats -= diff
                elif self._drag_edge == "end":
                    new_end = max(self._clip_start_beats + 0.25, beat)
                    self._clip_length_beats = new_end - self._clip_start_beats

        # Cursor shape based on position
        if self._tool == TOOL_SELECT and self._clip:
            cs = self._clip_start_beats
            ce = cs + self._clip_length_beats
            x_start = self._beats_to_x(cs)
            x_end = self._beats_to_x(ce)
            mx = event.position().x()
            if abs(mx - x_start) < 8 or abs(mx - x_end) < 8:
                self.setCursor(Qt.CursorShape.SizeHorCursor)
            else:
                self.setCursor(Qt.CursorShape.ArrowCursor)

        self.update()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if self._dragging and self._drag_edge and self._clip:
            # Apply trim to clip model
            try:
                self._clip.start_beats = self._clip_start_beats
                self._clip.length_beats = self._clip_length_beats
                self.clip_trimmed.emit(
                    str(self._clip_id),
                    self._clip_start_beats if self._drag_edge == "start"
                    else self._clip_length_beats,
                    self._drag_edge,
                )
                try:
                    self.status_message.emit(
                        f"✂ Trimmed {self._drag_edge}: {self._clip_start_beats:.1f}–"
                        f"{self._clip_start_beats + self._clip_length_beats:.1f}")
                except Exception:
                    pass
                # Emit project change
                if hasattr(self._ps, '_emit_updated'):
                    self._ps._emit_updated()
                elif hasattr(self._ps, '_emit_changed'):
                    self._ps._emit_changed()
            except Exception as e:
                log.debug("[VideoEditor] trim apply: %s", e)

        self._dragging = False
        self._drag_edge = None
        self.update()

    def wheelEvent(self, event: QWheelEvent) -> None:
        delta = event.angleDelta().y()
        if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            # Zoom
            factor = 1.15 if delta > 0 else 0.87
            self._px_per_beat = max(10, min(200, self._px_per_beat * factor))
        else:
            # Scroll
            self._scroll_x -= delta / 120.0 * 2
            self._scroll_x = max(0, self._scroll_x)
        self.update()

    def keyPressEvent(self, event: QKeyEvent) -> None:
        key = event.key()
        if key == Qt.Key.Key_S:
            self.split_at_playhead()
        elif key == Qt.Key.Key_1:
            self.set_tool(TOOL_SELECT)
        elif key == Qt.Key.Key_2:
            self.set_tool(TOOL_KNIFE)
        elif key == Qt.Key.Key_3:
            self.set_tool(TOOL_TRIM)
        elif key == Qt.Key.Key_4:
            self.set_tool(TOOL_SLIP)
        elif key == Qt.Key.Key_Plus or key == Qt.Key.Key_Equal:
            self._px_per_beat = min(200, self._px_per_beat * 1.2)
            self.update()
        elif key == Qt.Key.Key_Minus:
            self._px_per_beat = max(10, self._px_per_beat / 1.2)
            self.update()
        elif key == Qt.Key.Key_Home:
            self._scroll_x = 0
            self.update()
        else:
            super().keyPressEvent(event)


# ═══════════════════════════════════════════════════════════════
# Video Editor Widget (wraps Canvas + Toolbar)
# ═══════════════════════════════════════════════════════════════

class VideoEditor(QWidget):
    """Complete Video Editor widget with toolbar + canvas.

    Drop-in replacement for PianoRollEditor in EditorTabs.
    """

    status_message = pyqtSignal(str)

    def __init__(self, project_service, transport=None,
                 editor_timeline=None, parent=None):
        super().__init__(parent)
        self._ps = project_service
        self._transport = transport

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # ── Toolbar ──
        toolbar = QHBoxLayout()
        toolbar.setContentsMargins(4, 2, 4, 2)
        toolbar.setSpacing(4)

        lbl = QLabel("🎬 Video-Editor")
        lbl.setStyleSheet("font-weight: bold; color: #e0e0e0; font-size: 12px;")
        toolbar.addWidget(lbl)

        toolbar.addSpacing(8)

        # Tool buttons
        self._tool_btns = {}
        for tool_id, icon, tip in [
            (TOOL_SELECT, "👆", "Auswahl (1)"),
            (TOOL_KNIFE, "✂", "Messer / Split (2)"),
            (TOOL_TRIM, "↔", "Trimmen (3)"),
            (TOOL_SLIP, "⇄", "Slip / Verschieben (4)"),
        ]:
            btn = QToolButton()
            btn.setText(icon)
            btn.setToolTip(tip)
            btn.setCheckable(True)
            btn.setFixedSize(28, 24)
            btn.setStyleSheet(
                "QToolButton { background: #2a2a3a; border: 1px solid #444; "
                "border-radius: 3px; color: #ddd; font-size: 13px; }"
                "QToolButton:checked { background: #3a5a7a; border-color: #6aa; }"
                "QToolButton:hover { background: #3a3a4a; }"
            )
            btn.clicked.connect(lambda checked, t=tool_id: self._on_tool_click(t))
            toolbar.addWidget(btn)
            self._tool_btns[tool_id] = btn

        self._tool_btns[TOOL_SELECT].setChecked(True)

        toolbar.addSpacing(12)

        # Split at playhead button
        btn_split = QPushButton("✂ Split (S)")
        btn_split.setFixedHeight(24)
        btn_split.setStyleSheet(
            "QPushButton { background: #3a2a2a; border: 1px solid #804a4a; "
            "border-radius: 3px; color: #ddd; font-size: 11px; padding: 0 8px; }"
            "QPushButton:hover { background: #4a3a3a; }"
        )
        btn_split.clicked.connect(self._on_split)
        toolbar.addWidget(btn_split)

        toolbar.addStretch(1)

        # SMPTE display
        self._lbl_smpte = QLabel("00:00:00:00")
        self._lbl_smpte.setStyleSheet(
            "font-family: 'Courier New', monospace; font-size: 13px; "
            "font-weight: bold; color: #4fc3f7; background: #0a0a14; "
            "border: 1px solid #333; border-radius: 3px; padding: 2px 6px;"
        )
        toolbar.addWidget(self._lbl_smpte)

        toolbar_w = QWidget()
        toolbar_w.setLayout(toolbar)
        toolbar_w.setFixedHeight(32)
        toolbar_w.setStyleSheet("background: #1e1e2e; border-bottom: 1px solid #333;")
        lay.addWidget(toolbar_w)

        # ── Canvas ──
        self._canvas = VideoEditorCanvas(project_service, transport=transport,
                                          parent=self)
        self._canvas.status_message.connect(self.status_message)
        self._canvas.clip_split.connect(self._do_split)
        lay.addWidget(self._canvas, 1)

        # SMPTE update timer
        self._smpte_timer = QTimer(self)
        self._smpte_timer.setInterval(100)
        self._smpte_timer.timeout.connect(self._update_smpte)
        self._smpte_timer.start()

    def set_clip(self, clip_id: Optional[str]) -> None:
        """Load a video clip for editing."""
        # Only handle video clips
        if clip_id:
            try:
                proj = None
                ps = self._ps
                proj = getattr(ps, 'project', None)
                if proj is None:
                    ctx = getattr(ps, 'ctx', None)
                    proj = getattr(ctx, 'project', None) if ctx else None
                if proj:
                    for c in proj.clips or []:
                        if str(getattr(c, 'id', '')) == str(clip_id):
                            if str(getattr(c, 'kind', '')) != 'video':
                                return  # Not a video clip — ignore
                            break
            except Exception:
                pass

        self._canvas.set_clip(clip_id)

        # Try to get scene markers from VideoConnector
        try:
            from pydaw.services.video_connector import VideoConnector
            vc = VideoConnector.instance()
            vki = getattr(vc, '_video_ki_panel', None)
            if vki:
                vki_svc = getattr(vki, '_vki', None)
                if vki_svc and hasattr(vki_svc, 'scenes'):
                    bpm = self._canvas._bpm
                    markers = []
                    for scene in vki_svc.scenes:
                        beat = scene.start_seconds * bpm / 60.0
                        r, g, b = scene.dominant_color
                        markers.append({
                            "beat": beat,
                            "color": f"#{r:02x}{g:02x}{b:02x}",
                            "label": f"Szene {scene.index + 1}",
                        })
                    self._canvas.set_scene_markers(markers)
        except Exception:
            pass

    def _on_tool_click(self, tool: str) -> None:
        for t, btn in self._tool_btns.items():
            btn.setChecked(t == tool)
        self._canvas.set_tool(tool)

    def _on_split(self) -> None:
        self._canvas.split_at_playhead()

    def _do_split(self, clip_id: str, beat: float) -> None:
        """Perform the actual clip split in the project model."""
        try:
            ps = self._ps
            proj = getattr(ps, 'project', None)
            if proj is None:
                ctx = getattr(ps, 'ctx', None)
                proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                return

            # Find clip
            src = None
            for c in proj.clips:
                if str(getattr(c, 'id', '')) == str(clip_id):
                    src = c
                    break
            if not src:
                return

            cs = float(getattr(src, 'start_beats', 0))
            cl = float(getattr(src, 'length_beats', 0))
            ce = cs + cl
            if beat <= cs or beat >= ce:
                return

            from pydaw.model.project import Clip

            # Shorten original clip
            src.length_beats = beat - cs

            # Create new clip after split point
            new_clip = Clip(
                kind="video",
                track_id=str(getattr(src, 'track_id', '')),
                label=str(getattr(src, 'label', '')) + " (B)",
                source_path=str(getattr(src, 'source_path', '')),
                start_beats=beat,
                length_beats=ce - beat,
                offset_seconds=float(getattr(src, 'offset_seconds', 0) or 0)
                    + (beat - cs) * 60.0 / max(1, self._canvas._bpm),
            )
            proj.clips.append(new_clip)

            # Emit changes
            if hasattr(ps, '_emit_updated'):
                ps._emit_updated()
            elif hasattr(ps, '_emit_changed'):
                ps._emit_changed()

            # Reload clip in editor
            self._canvas.set_clip(str(clip_id))

        except Exception as e:
            log.error("[VideoEditor] split: %s", e, exc_info=True)

    def _update_smpte(self) -> None:
        try:
            if not self._transport:
                return
            beat = float(getattr(self._transport, 'current_beat', 0.0))
            bpm = float(getattr(self._transport, 'bpm', 120.0) or 120.0)
            secs = beat * 60.0 / max(1, bpm)
            h = int(secs) // 3600
            m = (int(secs) % 3600) // 60
            s = int(secs) % 60
            f = int((secs - int(secs)) * 24)
            self._lbl_smpte.setText(f"{h:02d}:{m:02d}:{s:02d}:{f:02d}")
        except Exception:
            pass
