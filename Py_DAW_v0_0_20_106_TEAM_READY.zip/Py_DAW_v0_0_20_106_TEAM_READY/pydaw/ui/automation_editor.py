"""Enhanced Automation Lane Editor (v0.0.20.89).

Replaces the basic _AutomationCurveEditor with a production-grade editor:
- Bezier curves with draggable control points
- Multiple curve types: Linear, Bezier, Step, Smooth (S-curve)
- FX parameter selection (Volume, Pan, + all registered FX params)
- Arranger-synced view (horizontal scroll/zoom linked to ArrangerCanvas)
- Grid overlay with beat/bar markers
- Playhead indicator
- Undo-friendly: all changes go through AutomationManager

Usage:
    editor = EnhancedAutomationEditor(automation_manager, project_service)
    editor.set_parameter("trk:abc:vol")
    editor.set_view_range(0.0, 32.0)
"""
from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Tuple

from PyQt6.QtCore import Qt, QPointF, QRectF, QTimer, pyqtSignal, QRect
from PyQt6.QtGui import (
    QPainter, QPen, QBrush, QColor, QPainterPath,
    QLinearGradient, QFont,
)
from PyQt6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QLabel,
    QComboBox, QToolButton, QMenu, QListWidget, QListWidgetItem,
    QSizePolicy, QLineEdit, QCompleter,
)

from pydaw.ui.widgets.ruler_zoom_handle import paint_magnifier

from pydaw.audio.automatable_parameter import (
    AutomationManager, AutomationLane, BreakPoint, CurveType,
)


# ─── Color palette ───────────────────────────────────────────────────────

COL_BG = QColor(30, 30, 35)
COL_GRID_MAJOR = QColor(60, 60, 65)
COL_GRID_MINOR = QColor(45, 45, 50)
COL_BORDER = QColor(80, 80, 85)
COL_CURVE = QColor(0, 191, 255)          # deep sky blue
COL_CURVE_DISABLED = QColor(80, 80, 90)
COL_POINT = QColor(255, 255, 255)
COL_POINT_SELECTED = QColor(255, 200, 0)
COL_POINT_HOVER = QColor(100, 200, 255)
COL_BEZIER_CTRL = QColor(255, 140, 0, 180)
COL_BEZIER_LINE = QColor(255, 140, 0, 80)
COL_PLAYHEAD = QColor(255, 60, 60)
COL_ZERO_LINE = QColor(80, 80, 90)
COL_TEXT = QColor(160, 160, 165)
COL_VALUE_BG = QColor(20, 20, 25, 200)


# ─── Snap helper ──────────────────────────────────────────────────────────

def _snap_beats(beat: float, division: str) -> float:
    mapping = {"1/4": 1.0, "1/8": 0.5, "1/16": 0.25, "1/32": 0.125, "1/64": 0.0625}
    snap = mapping.get(str(division), 0.25)
    if snap > 0:
        return round(beat / snap) * snap
    return beat


# ─── Enhanced Curve Editor Widget ─────────────────────────────────────────

class EnhancedAutomationEditor(QWidget):
    """Professional automation curve editor with Bezier support.

    X-axis: beats (synced with arranger view range)
    Y-axis: 0..1 normalized parameter value
    """

    # Emitted when lane data changes (for project dirty-state)
    lane_changed = pyqtSignal(str)  # parameter_id

    POINT_RADIUS = 5.0
    CTRL_RADIUS = 4.0
    HIT_RADIUS = 8.0
    MARGIN = 10

    def __init__(self, automation_manager: AutomationManager, project: Any = None, parent=None):
        super().__init__(parent)
        self._mgr = automation_manager
        self._project = project
        self._parameter_id: str = ""

        # View range (beats) — synced with arranger
        self._view_start = 0.0
        self._view_end = 32.0

        # Playhead
        self._playhead_beat = 0.0

        # Interaction state
        self._drag_point_idx: Optional[int] = None
        self._drag_ctrl: bool = False  # dragging Bezier control point
        self._hover_idx: Optional[int] = None
        self._selected_idx: Optional[int] = None
        self._current_curve_type = CurveType.LINEAR

        # Snap
        self._snap_division = "1/16"

        self.setMinimumHeight(100)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        # Ruler zoom handle (magnifier)
        self._zoom_handle_rect = QRect(6, 6, 16, 16)
        self._zoom_drag = False
        self._zoom_origin_y = 0.0
        self._zoom_origin_start = float(self._view_start)
        self._zoom_origin_end = float(self._view_end)
        self._zoom_anchor_x = 0.0
        self._zoom_anchor_beat = 0.0
        self._default_view_span = float(self._view_end - self._view_start) if (self._view_end > self._view_start) else 32.0

    # ─── Public API ───

    def set_parameter(self, parameter_id: str) -> None:
        """Set which parameter's automation lane to edit."""
        self._parameter_id = parameter_id
        self._selected_idx = None
        self._drag_point_idx = None
        self.update()

    def set_view_range(self, start_beat: float, end_beat: float) -> None:
        s, e = float(start_beat), float(end_beat)
        if e <= s:
            return
        self._view_start = max(0.0, s)
        self._view_end = max(self._view_start + 0.25, e)
        self.update()

    def set_playhead(self, beat: float) -> None:
        self._playhead_beat = float(beat)
        self.update()

    def set_snap_division(self, div: str) -> None:
        self._snap_division = str(div)

    def set_curve_type(self, ct: CurveType) -> None:
        """Set curve type for new points and selected point."""
        self._current_curve_type = ct
        lane = self._get_lane()
        if lane and self._selected_idx is not None and 0 <= self._selected_idx < len(lane.points):
            lane.points[self._selected_idx].curve_type = ct
            self._emit_change()
            self.update()

    # ─── Lane access ───

    def _get_lane(self) -> Optional[AutomationLane]:
        if not self._parameter_id:
            return None
        return self._mgr.get_lane(self._parameter_id)

    def _get_or_create_lane(self) -> AutomationLane:
        param = self._mgr.get_parameter(self._parameter_id)
        return self._mgr.get_or_create_lane(
            self._parameter_id,
            track_id=param.track_id if param else "",
            param_name=param.name if param else self._parameter_id,
        )

    def _emit_change(self) -> None:
        self.lane_changed.emit(self._parameter_id)

    # ─── Coordinate mapping ───

    def _px_to_beat(self, x: float) -> float:
        w = max(1.0, float(self.width() - 2 * self.MARGIN))
        span = max(1e-9, self._view_end - self._view_start)
        return self._view_start + ((x - self.MARGIN) / w) * span

    def _beat_to_px(self, beat: float) -> float:
        w = max(1.0, float(self.width() - 2 * self.MARGIN))
        span = max(1e-9, self._view_end - self._view_start)
        return self.MARGIN + ((beat - self._view_start) / span) * w

    def _px_to_value(self, y: float) -> float:
        h = max(1.0, float(self.height() - 2 * self.MARGIN))
        return 1.0 - max(0.0, min(1.0, (y - self.MARGIN) / h))

    def _value_to_px(self, value: float) -> float:
        h = max(1.0, float(self.height() - 2 * self.MARGIN))
        return self.MARGIN + (1.0 - max(0.0, min(1.0, value))) * h

    # ─── Hit testing ───

    def _hit_test_point(self, pos: QPointF, pts: List[BreakPoint]) -> Optional[int]:
        for i, pt in enumerate(pts):
            px = self._beat_to_px(pt.beat)
            py = self._value_to_px(pt.value)
            if (pos.x() - px) ** 2 + (pos.y() - py) ** 2 < self.HIT_RADIUS ** 2:
                return i
        return None

    def _hit_test_ctrl(self, pos: QPointF, pts: List[BreakPoint]) -> Optional[int]:
        """Hit test Bezier control points."""
        for i in range(len(pts) - 1):
            if pts[i].curve_type != CurveType.BEZIER:
                continue
            # Control point is at relative position within segment
            p0, p1 = pts[i], pts[i + 1]
            cx = self._beat_to_px(p0.beat + p0.bezier_cx * (p1.beat - p0.beat))
            cy = self._value_to_px(p0.value + p0.bezier_cy * (p1.value - p0.value))
            if (pos.x() - cx) ** 2 + (pos.y() - cy) ** 2 < self.HIT_RADIUS ** 2:
                return i
        return None

    # ─── Mouse events ───

    def _apply_view_span(self, new_span: float, anchor_beat: float, anchor_x: float) -> None:
        """Apply zoom by changing view span (beats) while keeping anchor stable."""
        try:
            new_span = float(max(0.5, min(512.0, new_span)))
            w = max(1.0, float(self.width() - 2 * self.MARGIN))
            t = max(0.0, min(1.0, (float(anchor_x) - float(self.MARGIN)) / w))
            new_start = max(0.0, float(anchor_beat) - t * new_span)
            self.set_view_range(new_start, new_start + new_span)
        except Exception:
            pass

    def mousePressEvent(self, event) -> None:
        if not self._parameter_id:
            return
        pos = event.position()

        # Zoom handle drag start (magnifier in top-left)
        try:
            if event.button() == Qt.MouseButton.LeftButton and self._zoom_handle_rect.contains(int(pos.x()), int(pos.y())):
                self._zoom_drag = True
                self._zoom_origin_y = float(pos.y())
                self._zoom_origin_start = float(self._view_start)
                self._zoom_origin_end = float(self._view_end)
                self._zoom_anchor_x = float(pos.x())
                self._zoom_anchor_beat = float(self._px_to_beat(pos.x()))
                self.setCursor(Qt.CursorShape.SizeVerCursor)
                event.accept()
                return
        except Exception:
            pass

        lane = self._get_lane()
        pts = lane.points if lane else []

        if event.button() == Qt.MouseButton.RightButton:
            # Delete nearest point
            idx = self._hit_test_point(pos, pts)
            if idx is not None and lane:
                lane.points.pop(idx)
                lane.sort_points()
                self._selected_idx = None
                self._emit_change()
                self.update()
            return

        if event.button() == Qt.MouseButton.LeftButton:
            # Check Bezier control point first
            ctrl_idx = self._hit_test_ctrl(pos, pts)
            if ctrl_idx is not None:
                self._drag_point_idx = ctrl_idx
                self._drag_ctrl = True
                return

            # Check regular point
            idx = self._hit_test_point(pos, pts)
            if idx is not None:
                self._drag_point_idx = idx
                self._drag_ctrl = False
                self._selected_idx = idx
                self.update()
                return

            # Add new point
            beat = _snap_beats(self._px_to_beat(pos.x()), self._snap_division)
            value = self._px_to_value(pos.y())
            value = max(0.0, min(1.0, value))

            lane = self._get_or_create_lane()
            bp = BreakPoint(beat=beat, value=value, curve_type=self._current_curve_type)
            lane.points.append(bp)
            lane.sort_points()
            # Select the newly added point
            self._selected_idx = next(
                (i for i, p in enumerate(lane.points) if abs(p.beat - beat) < 1e-6),
                None,
            )
            self._emit_change()
            self.update()

    def mouseMoveEvent(self, event) -> None:
        pos = event.position()

        # Zoom drag in progress
        if getattr(self, '_zoom_drag', False):
            try:
                dy = float(pos.y()) - float(self._zoom_origin_y)
                span0 = max(1e-6, float(self._zoom_origin_end) - float(self._zoom_origin_start))
                factor = 1.0 + (dy / 160.0)  # drag down -> zoom out (bigger span)
                factor = max(0.25, min(4.0, factor))
                new_span = span0 * factor
                self._apply_view_span(new_span, float(self._zoom_anchor_beat), float(self._zoom_anchor_x))
                event.accept()
                return
            except Exception:
                pass

        lane = self._get_lane()

        if self._drag_point_idx is not None and lane:
            pts = lane.points
            idx = self._drag_point_idx

            if self._drag_ctrl and 0 <= idx < len(pts) - 1:
                # Move Bezier control point
                p0 = pts[idx]
                p1 = pts[idx + 1]
                beat_span = p1.beat - p0.beat
                val_span = p1.value - p0.value

                beat = self._px_to_beat(pos.x())
                value = self._px_to_value(pos.y())

                if beat_span != 0:
                    p0.bezier_cx = max(0.0, min(1.0, (beat - p0.beat) / beat_span))
                if val_span != 0:
                    p0.bezier_cy = max(-0.5, min(1.5, (value - p0.value) / val_span))
                else:
                    p0.bezier_cy = 0.5

                self._emit_change()
                self.update()
                return

            if 0 <= idx < len(pts):
                beat = _snap_beats(self._px_to_beat(pos.x()), self._snap_division)
                value = max(0.0, min(1.0, self._px_to_value(pos.y())))
                pts[idx].beat = beat
                pts[idx].value = value
                lane.sort_points()
                self._emit_change()
                self.update()
            return

        # Hover detection
        if lane:
            old_hover = self._hover_idx
            self._hover_idx = self._hit_test_point(pos, lane.points)
            if self._hover_idx != old_hover:
                self.update()

    def mouseReleaseEvent(self, event) -> None:
        if getattr(self, '_zoom_drag', False):
            self._zoom_drag = False
            try:
                self.unsetCursor()
            except Exception:
                pass
            event.accept()
            return

        self._drag_point_idx = None
        self._drag_ctrl = False

    def mouseDoubleClickEvent(self, event) -> None:
        """Double-click magnifier resets the view span."""
        try:
            pos = event.position()
            if self._zoom_handle_rect.contains(int(pos.x()), int(pos.y())):
                anchor_x = float(pos.x())
                anchor_beat = float(self._px_to_beat(pos.x()))
                new_span = float(getattr(self, '_default_view_span', 32.0) or 32.0)
                self._apply_view_span(new_span, anchor_beat, anchor_x)
                event.accept()
                return
        except Exception:
            pass
        super().mouseDoubleClickEvent(event)

    def wheelEvent(self, event) -> None:
        """Wheel on magnifier = horizontal zoom in/out."""
        try:
            pos = event.position()
            if self._zoom_handle_rect.contains(int(pos.x()), int(pos.y())):
                dy = float(event.angleDelta().y())
                factor = 1.15 if dy > 0 else 1.0 / 1.15
                span = max(1e-6, float(self._view_end) - float(self._view_start))
                new_span = span / factor
                self._apply_view_span(new_span, float(self._px_to_beat(pos.x())), float(pos.x()))
                event.accept()
                return
        except Exception:
            pass
        super().wheelEvent(event)

    def keyPressEvent(self, event) -> None:
        """Delete selected point with Del/Backspace."""
        if event.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            lane = self._get_lane()
            if lane and self._selected_idx is not None and 0 <= self._selected_idx < len(lane.points):
                lane.points.pop(self._selected_idx)
                self._selected_idx = None
                self._emit_change()
                self.update()
                event.accept()
                return
        super().keyPressEvent(event)

    # ─── Paint ───
    # ─── Paint ───

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, h = self.width(), self.height()

        # Background
        p.fillRect(self.rect(), COL_BG)

        # Grid
        self._draw_grid(p, w, h)

        # Zoom handle icon (magnifier)
        try:
            paint_magnifier(p, self._zoom_handle_rect, color=COL_TEXT)
        except Exception:
            pass

        # Border
        p.setPen(QPen(COL_BORDER, 1))
        p.drawRect(self.rect().adjusted(0, 0, -1, -1))

        lane = self._get_lane()
        pts = lane.points if lane else []
        enabled = lane.enabled if lane else False

        if not self._parameter_id:
            p.setPen(QPen(COL_TEXT))
            p.drawText(self.MARGIN + 4, self.MARGIN + 14, "Kein Parameter ausgewählt")
            p.end()
            return

        if not pts:
            p.setPen(QPen(COL_TEXT))
            p.drawText(self.MARGIN + 4, self.MARGIN + 14, "Klick = Punkt setzen | Rechtsklick = löschen")
            p.end()
            return

        curve_color = COL_CURVE if enabled else COL_CURVE_DISABLED

        # Draw curve segments
        self._draw_curve(p, pts, curve_color)

        # Draw Bezier control points + helper lines
        self._draw_bezier_controls(p, pts)

        # Draw points
        self._draw_points(p, pts)

        # Playhead
        ph_x = self._beat_to_px(self._playhead_beat)
        if self.MARGIN <= ph_x <= w - self.MARGIN:
            p.setPen(QPen(COL_PLAYHEAD, 1.5))
            p.drawLine(QPointF(ph_x, self.MARGIN), QPointF(ph_x, h - self.MARGIN))

        # Value readout for hovered point
        if self._hover_idx is not None and 0 <= self._hover_idx < len(pts):
            pt = pts[self._hover_idx]
            self._draw_tooltip(p, pt)

        p.end()

    def _draw_grid(self, p: QPainter, w: int, h: int) -> None:
        """Draw beat/bar grid lines."""
        span = max(1e-6, self._view_end - self._view_start)
        beats_per_bar = 4.0  # TODO: from time signature

        # Determine grid density
        pixels_per_beat = (w - 2 * self.MARGIN) / span
        if pixels_per_beat < 5:
            step = beats_per_bar * 4  # every 4 bars
        elif pixels_per_beat < 15:
            step = beats_per_bar  # every bar
        elif pixels_per_beat < 40:
            step = 1.0  # every beat
        else:
            step = 0.25  # every 16th

        # Vertical grid lines
        b = math.floor(self._view_start / step) * step
        while b <= self._view_end:
            x = self._beat_to_px(b)
            if self.MARGIN <= x <= w - self.MARGIN:
                is_bar = abs(b % beats_per_bar) < 0.001
                p.setPen(QPen(COL_GRID_MAJOR if is_bar else COL_GRID_MINOR, 1))
                p.drawLine(int(x), self.MARGIN, int(x), h - self.MARGIN)

                # Bar number
                if is_bar and pixels_per_beat >= 8:
                    bar_num = int(b / beats_per_bar) + 1
                    p.setPen(QPen(COL_TEXT))
                    font = p.font()
                    font.setPointSize(7)
                    p.setFont(font)
                    tx = int(x) + 2
                    try:
                        if self._zoom_handle_rect.intersects(QRect(tx, self.MARGIN, 18, 14)):
                            tx = self._zoom_handle_rect.right() + 6
                    except Exception:
                        pass
                    p.drawText(tx, self.MARGIN + 10, str(bar_num))
            b += step

        # Horizontal grid: 0%, 25%, 50%, 75%, 100%
        for frac in [0.0, 0.25, 0.5, 0.75, 1.0]:
            y = self._value_to_px(frac)
            p.setPen(QPen(COL_GRID_MAJOR if frac == 0.5 else COL_GRID_MINOR, 1))
            p.drawLine(self.MARGIN, int(y), w - self.MARGIN, int(y))

    def _draw_curve(self, p: QPainter, pts: List[BreakPoint], color: QColor) -> None:
        """Draw the automation curve with proper interpolation visualization."""
        if len(pts) < 2:
            if pts:
                # Single point: draw horizontal line
                y = self._value_to_px(pts[0].value)
                p.setPen(QPen(color, 2))
                p.drawLine(self.MARGIN, int(y), self.width() - self.MARGIN, int(y))
            return

        p.setPen(QPen(color, 2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))

        for i in range(len(pts) - 1):
            p0, p1 = pts[i], pts[i + 1]
            x0, y0 = self._beat_to_px(p0.beat), self._value_to_px(p0.value)
            x1, y1 = self._beat_to_px(p1.beat), self._value_to_px(p1.value)

            if p0.curve_type == CurveType.STEP:
                # Horizontal then vertical
                p.drawLine(QPointF(x0, y0), QPointF(x1, y0))
                p.drawLine(QPointF(x1, y0), QPointF(x1, y1))

            elif p0.curve_type == CurveType.BEZIER:
                # QPainterPath quadratic Bezier
                cx_rel = p0.bezier_cx
                cy_rel = p0.bezier_cy
                ctrl_x = x0 + cx_rel * (x1 - x0)
                ctrl_y = self._value_to_px(p0.value + cy_rel * (p1.value - p0.value))

                path = QPainterPath()
                path.moveTo(x0, y0)
                path.quadTo(ctrl_x, ctrl_y, x1, y1)
                p.drawPath(path)

            elif p0.curve_type == CurveType.SMOOTH:
                # Approximate S-curve with many line segments
                path = QPainterPath()
                path.moveTo(x0, y0)
                steps = max(8, int(abs(x1 - x0) / 3))
                for s in range(1, steps + 1):
                    t = s / steps
                    # Cubic ease-in-out
                    t_smooth = t * t * (3.0 - 2.0 * t)
                    bx = x0 + t * (x1 - x0)
                    bv = p0.value + t_smooth * (p1.value - p0.value)
                    by = self._value_to_px(bv)
                    path.lineTo(bx, by)
                p.drawPath(path)

            else:
                # LINEAR
                p.drawLine(QPointF(x0, y0), QPointF(x1, y1))

        # Extend from first point to left edge
        if pts:
            y_first = self._value_to_px(pts[0].value)
            x_first = self._beat_to_px(pts[0].beat)
            old_pen = p.pen()
            p.setPen(QPen(color.darker(150), 1, Qt.PenStyle.DashLine))
            p.drawLine(self.MARGIN, int(y_first), int(x_first), int(y_first))
            # Extend from last point to right edge
            y_last = self._value_to_px(pts[-1].value)
            x_last = self._beat_to_px(pts[-1].beat)
            p.drawLine(int(x_last), int(y_last), self.width() - self.MARGIN, int(y_last))
            p.setPen(old_pen)

    def _draw_bezier_controls(self, p: QPainter, pts: List[BreakPoint]) -> None:
        """Draw Bezier control points and helper lines."""
        for i in range(len(pts) - 1):
            if pts[i].curve_type != CurveType.BEZIER:
                continue
            p0, p1 = pts[i], pts[i + 1]
            x0, y0 = self._beat_to_px(p0.beat), self._value_to_px(p0.value)
            x1, y1 = self._beat_to_px(p1.beat), self._value_to_px(p1.value)

            cx = x0 + p0.bezier_cx * (x1 - x0)
            cy = self._value_to_px(p0.value + p0.bezier_cy * (p1.value - p0.value))

            # Helper lines
            p.setPen(QPen(COL_BEZIER_LINE, 1, Qt.PenStyle.DotLine))
            p.drawLine(QPointF(x0, y0), QPointF(cx, cy))
            p.drawLine(QPointF(cx, cy), QPointF(x1, y1))

            # Control point diamond
            p.setPen(QPen(COL_BEZIER_CTRL, 1))
            p.setBrush(QBrush(COL_BEZIER_CTRL))
            diamond = QPainterPath()
            r = self.CTRL_RADIUS
            diamond.moveTo(cx, cy - r)
            diamond.lineTo(cx + r, cy)
            diamond.lineTo(cx, cy + r)
            diamond.lineTo(cx - r, cy)
            diamond.closeSubpath()
            p.drawPath(diamond)

    def _draw_points(self, p: QPainter, pts: List[BreakPoint]) -> None:
        """Draw automation breakpoints."""
        for i, pt in enumerate(pts):
            x = self._beat_to_px(pt.beat)
            y = self._value_to_px(pt.value)

            if i == self._selected_idx:
                color = COL_POINT_SELECTED
                radius = self.POINT_RADIUS + 1
            elif i == self._hover_idx:
                color = COL_POINT_HOVER
                radius = self.POINT_RADIUS + 1
            else:
                color = COL_POINT
                radius = self.POINT_RADIUS

            p.setPen(QPen(color, 1.5))
            p.setBrush(QBrush(color))
            p.drawEllipse(QPointF(x, y), radius, radius)

            # Curve type indicator
            if pt.curve_type == CurveType.BEZIER:
                p.setPen(QPen(COL_BEZIER_CTRL, 1))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(QPointF(x, y), radius + 3, radius + 3)

    def _draw_tooltip(self, p: QPainter, pt: BreakPoint) -> None:
        """Draw value tooltip near hovered point."""
        x = self._beat_to_px(pt.beat)
        y = self._value_to_px(pt.value)

        text = f"Beat: {pt.beat:.2f}  Value: {pt.value:.3f}  [{pt.curve_type.value}]"
        font = p.font()
        font.setPointSize(8)
        p.setFont(font)
        fm = p.fontMetrics()
        tw = fm.horizontalAdvance(text) + 8
        th = fm.height() + 4

        tx = min(x + 10, self.width() - tw - 4)
        ty = max(y - th - 8, 4)

        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(COL_VALUE_BG))
        p.drawRoundedRect(QRectF(tx, ty, tw, th), 3, 3)

        p.setPen(QPen(COL_TEXT))
        p.drawText(QRectF(tx + 4, ty + 2, tw - 8, th - 4), Qt.AlignmentFlag.AlignLeft, text)


# ─── Enhanced Automation Lane Panel ───────────────────────────────────────

class EnhancedAutomationLanePanel(QWidget):
    """Full automation panel with track/parameter selection + curve editor.

    Replaces the old AutomationLanePanel with:
    - All registered parameters in a searchable ComboBox
    - Curve type selector (Linear/Bezier/Step/Smooth)
    - Mode selector (Off/Read/Write)
    - Integrated EnhancedAutomationEditor
    """

    def __init__(self, automation_manager: AutomationManager, project: Any = None, parent=None):
        super().__init__(parent)
        self._mgr = automation_manager
        self._project = project

        self._build_ui()
        self._connect_signals()

        # React to external "show automation" requests
        self._mgr.request_show_automation.connect(self._on_show_request)

        if self._project:
            try:
                self._project.project_updated.connect(self._refresh_tracks)
            except Exception:
                pass
        self._refresh_tracks()

    def _build_ui(self) -> None:
        layout = QHBoxLayout(self)
        layout.setContentsMargins(6, 4, 6, 4)
        layout.setSpacing(8)

        # Left: Track + Parameter selection
        left = QVBoxLayout()
        left.setSpacing(4)

        left.addWidget(QLabel("Track:"))
        self.cmb_track = QComboBox()
        self.cmb_track.setMaximumWidth(200)
        left.addWidget(self.cmb_track)

        left.addWidget(QLabel("Parameter:"))
        self.cmb_param = QComboBox()
        self.cmb_param.setEditable(True)  # searchable
        self.cmb_param.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        self.cmb_param.setMaximumWidth(200)
        left.addWidget(self.cmb_param)

        left.addWidget(QLabel("Mode:"))
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["off", "read", "write"])
        self.cmb_mode.setMaximumWidth(200)
        left.addWidget(self.cmb_mode)

        left.addWidget(QLabel("Curve:"))
        self.cmb_curve = QComboBox()
        self.cmb_curve.addItems(["linear", "bezier", "step", "smooth"])
        self.cmb_curve.setMaximumWidth(200)
        left.addWidget(self.cmb_curve)

        # Actions
        self.btn_actions = QToolButton()
        self.btn_actions.setText("⋯")
        self.btn_actions.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        actions_menu = QMenu(self.btn_actions)
        self._a_clear = actions_menu.addAction("🗑 Lane leeren")
        self._a_enable = actions_menu.addAction("✅ Lane aktiv")
        self._a_enable.setCheckable(True)
        self._a_enable.setChecked(True)
        self.btn_actions.setMenu(actions_menu)
        left.addWidget(self.btn_actions)

        left.addStretch(1)
        layout.addLayout(left, 0)

        # Right: Curve editor
        self.editor = EnhancedAutomationEditor(self._mgr, self._project)
        layout.addWidget(self.editor, 1)

    def _connect_signals(self) -> None:
        self.cmb_track.currentIndexChanged.connect(self._on_track_changed)
        self.cmb_param.currentIndexChanged.connect(self._on_param_changed)
        self.cmb_mode.currentTextChanged.connect(self._on_mode_changed)
        self.cmb_curve.currentTextChanged.connect(self._on_curve_changed)
        self._a_clear.triggered.connect(self._on_clear_lane)
        self._a_enable.triggered.connect(self._on_toggle_enable)

    # ─── Track/Param refresh ───

    def _refresh_tracks(self) -> None:
        """Populate track combobox from project."""
        old_tid = self.cmb_track.currentData()
        self.cmb_track.blockSignals(True)
        self.cmb_track.clear()

        if self._project:
            proj = getattr(self._project, "ctx", None)
            if proj:
                proj = getattr(proj, "project", None)
            if not proj:
                proj = getattr(self._project, "project", None)
            if proj:
                for t in getattr(proj, "tracks", []):
                    label = f"{getattr(t, 'name', '?')} [{getattr(t, 'kind', '?')}]"
                    self.cmb_track.addItem(label, getattr(t, "id", ""))

        # Restore selection
        if old_tid:
            idx = self.cmb_track.findData(old_tid)
            if idx >= 0:
                self.cmb_track.setCurrentIndex(idx)

        self.cmb_track.blockSignals(False)
        self._refresh_params()

    def _refresh_params(self) -> None:
        """Populate parameter combobox for selected track."""
        tid = self.cmb_track.currentData() or ""
        old_pid = self.cmb_param.currentData()

        self.cmb_param.blockSignals(True)
        self.cmb_param.clear()

        # Always show Volume + Pan
        self.cmb_param.addItem("Volume", f"trk:{tid}:volume")
        self.cmb_param.addItem("Pan", f"trk:{tid}:pan")

        # Add registered FX parameters for this track
        for param in self._mgr.get_parameters_for_track(tid):
            pid = param.parameter_id
            # Skip already-added volume/pan
            if pid.endswith(":volume") or pid.endswith(":pan"):
                continue
            self.cmb_param.addItem(f"🎛 {param.name}", pid)

        # Restore selection
        if old_pid:
            idx = self.cmb_param.findData(old_pid)
            if idx >= 0:
                self.cmb_param.setCurrentIndex(idx)

        self.cmb_param.blockSignals(False)
        self._on_param_changed()

    # ─── Slots ───

    def _on_track_changed(self, index: int) -> None:
        self._refresh_params()
        tid = self.cmb_track.currentData() or ""
        # Update mode combobox
        if self._project:
            proj = getattr(self._project, "ctx", None)
            if proj:
                proj = getattr(proj, "project", None)
            if not proj:
                proj = getattr(self._project, "project", None)
            if proj:
                trk = next((t for t in getattr(proj, "tracks", []) if getattr(t, "id", "") == tid), None)
                if trk:
                    self.cmb_mode.blockSignals(True)
                    self.cmb_mode.setCurrentText(getattr(trk, "automation_mode", "off"))
                    self.cmb_mode.blockSignals(False)

    def _on_param_changed(self, index: int = 0) -> None:
        pid = self.cmb_param.currentData() or ""
        self.editor.set_parameter(pid)

        # Update enable checkbox
        lane = self._mgr.get_lane(pid)
        self._a_enable.setChecked(lane.enabled if lane else True)

    def _on_mode_changed(self, mode: str) -> None:
        tid = self.cmb_track.currentData() or ""
        if not tid or not self._project:
            return
        proj = getattr(self._project, "ctx", None)
        if proj:
            proj = getattr(proj, "project", None)
        if not proj:
            proj = getattr(self._project, "project", None)
        if proj:
            trk = next((t for t in getattr(proj, "tracks", []) if getattr(t, "id", "") == tid), None)
            if trk:
                trk.automation_mode = str(mode)
                try:
                    self._project.project_updated.emit()
                except Exception:
                    pass

    def _on_curve_changed(self, curve_text: str) -> None:
        ct_map = {
            "linear": CurveType.LINEAR,
            "bezier": CurveType.BEZIER,
            "step": CurveType.STEP,
            "smooth": CurveType.SMOOTH,
        }
        ct = ct_map.get(curve_text, CurveType.LINEAR)
        self.editor.set_curve_type(ct)

    def _on_clear_lane(self) -> None:
        pid = self.cmb_param.currentData() or ""
        if pid:
            lane = self._mgr.get_lane(pid)
            if lane:
                lane.points.clear()
                self.editor.update()

    def _on_toggle_enable(self, checked: bool) -> None:
        pid = self.cmb_param.currentData() or ""
        if pid:
            lane = self._mgr.get_lane(pid)
            if lane:
                lane.enabled = checked
                self.editor.update()

    def _on_show_request(self, parameter_id: str) -> None:
        """Handle request from a widget to show its automation."""
        # Find the track
        param = self._mgr.get_parameter(parameter_id)
        if param and param.track_id:
            idx = self.cmb_track.findData(param.track_id)
            if idx >= 0:
                self.cmb_track.setCurrentIndex(idx)

        # Find the parameter
        self._refresh_params()
        idx = self.cmb_param.findData(parameter_id)
        if idx >= 0:
            self.cmb_param.setCurrentIndex(idx)
        else:
            # Auto-register the lane
            self._mgr.get_or_create_lane(parameter_id)
            self._refresh_params()
            idx = self.cmb_param.findData(parameter_id)
            if idx >= 0:
                self.cmb_param.setCurrentIndex(idx)

        # Ensure mode is at least "read"
        if self.cmb_mode.currentText() == "off":
            self.cmb_mode.setCurrentText("read")

    # ─── External sync ───

    def set_playhead(self, beat: float) -> None:
        self.editor.set_playhead(float(beat))

    def set_view_range(self, start_beat: float, end_beat: float) -> None:
        self.editor.set_view_range(float(start_beat), float(end_beat))

    def set_snap_division(self, div: str) -> None:
        self.editor.set_snap_division(div)
