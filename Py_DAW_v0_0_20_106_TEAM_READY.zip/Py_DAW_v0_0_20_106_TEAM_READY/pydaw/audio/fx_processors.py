# -*- coding: utf-8 -*-
"""Audio-FX DSP Processors (v0.0.20.106).

Numpy-basierte Echtzeit-Prozessoren für alle Bitwig-Style Effekte.
Jeder Prozessor erbt von AudioFxBase (fx_chain.py) und wird über
ChainFx._compile_devices() in die Audio-Pipeline eingehängt.

RT-Safety:
- Scratch-Buffer werden in __init__ vorallokiert
- process_inplace() macht keine Heap-Allokationen
- Parameter kommen aus dem RTParamStore (lock-free)

Kein Eingriff in bestehende Effekte (GainFx, DistortionFx).
"""
from __future__ import annotations

import math
from typing import Any

try:
    import numpy as np
except ImportError:
    np = None  # type: ignore

# Import base from fx_chain
try:
    from pydaw.audio.fx_chain import AudioFxBase
except ImportError:
    class AudioFxBase:
        def process_inplace(self, buf, frames: int, sr: int) -> None:
            raise NotImplementedError


# ───────────────────────────────────────────────────────────
#  Helpers
# ───────────────────────────────────────────────────────────

def _c01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


def _rtg(rt, key: str, default: float = 0.0) -> float:
    """Read RT param (tolerant across API versions)."""
    try:
        if rt is None:
            return float(default)
        for attr in ("get_smooth", "get_param", "get_target"):
            fn = getattr(rt, attr, None)
            if fn is not None:
                return float(fn(key, default))
    except Exception:
        pass
    return float(default)


def _biquad_coeffs(ftype: int, fc: float, q: float, sr: float):
    """Biquad LP/HP/BP/Notch/Peak(4) Koeffizienten."""
    fc = max(20.0, min(fc, sr * 0.45))
    q = max(0.1, min(q, 20.0))
    w0 = 2.0 * math.pi * fc / sr
    sin_w0 = math.sin(w0)
    cos_w0 = math.cos(w0)
    alpha = sin_w0 / (2.0 * q)
    if ftype == 1:       # HP
        b0, b1, b2 = (1 + cos_w0) / 2, -(1 + cos_w0), (1 + cos_w0) / 2
    elif ftype == 2:     # BP
        b0, b1, b2 = alpha, 0.0, -alpha
    elif ftype == 3:     # Notch
        b0, b1, b2 = 1.0, -2 * cos_w0, 1.0
    else:                # LP (default)
        b0, b1, b2 = (1 - cos_w0) / 2, 1 - cos_w0, (1 - cos_w0) / 2
    a0 = 1 + alpha
    return b0 / a0, b1 / a0, b2 / a0, (-2 * cos_w0) / a0, (1 - alpha) / a0


def _bq_stereo(buf, frames, b0, b1, b2, a1, a2, st):
    """Apply biquad to stereo buf in-place. st = [z1l, z2l, z1r, z2r]."""
    for ch in range(2):
        z1, z2 = st[ch * 2], st[ch * 2 + 1]
        for i in range(frames):
            xi = float(buf[i, ch])
            yi = b0 * xi + z1
            z1 = b1 * xi - a1 * yi + z2
            z2 = b2 * xi - a2 * yi
            buf[i, ch] = yi
        st[ch * 2], st[ch * 2 + 1] = z1, z2


# ═══════════════════════════════════════════════════════════
#  1.  EQ-5  —  5-Band Parametric EQ
# ═══════════════════════════════════════════════════════════

class EQ5Fx(AudioFxBase):
    _FREQ_DEFAULTS = [80.0, 400.0, 1310.0, 3600.0, 12000.0]

    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix
        self.states = [[0.0] * 4 for _ in range(5)]

    def process_inplace(self, buf, frames, sr):
        if np is None:
            return
        try:
            for i in range(5):
                g_db = _rtg(self.rt, f"{self.p}:b{i}_g", 0.0)
                if abs(g_db) < 0.1:
                    continue
                freq = max(20, min(20000, _rtg(self.rt, f"{self.p}:b{i}_f", self._FREQ_DEFAULTS[i])))
                q = max(0.1, min(18, _rtg(self.rt, f"{self.p}:b{i}_q", 0.71)))
                # Peak EQ
                A = 10.0 ** (g_db / 40.0)
                w0 = 2.0 * math.pi * freq / sr
                alpha = math.sin(w0) / (2.0 * q)
                cos_w0 = math.cos(w0)
                a0 = 1 + alpha / A
                _bq_stereo(buf[:frames], frames,
                           (1 + alpha * A) / a0, (-2 * cos_w0) / a0,
                           (1 - alpha * A) / a0, (-2 * cos_w0) / a0,
                           (1 - alpha / A) / a0, self.states[i])
            out_db = _rtg(self.rt, f"{self.p}:output", 0.0)
            if abs(out_db) > 0.05:
                np.multiply(buf[:frames], 10.0 ** (out_db / 20.0), out=buf[:frames])
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  2.  DELAY-2  —  Stereo Delay
# ═══════════════════════════════════════════════════════════

class Delay2Fx(AudioFxBase):
    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix
        self._maxd = 48000 * 4
        if np is not None:
            self._bl = np.zeros(self._maxd, dtype=np.float32)
            self._br = np.zeros(self._maxd, dtype=np.float32)
        else:
            self._bl = self._br = None
        self._pl = self._pr = 0

    def process_inplace(self, buf, frames, sr):
        if np is None or self._bl is None:
            return
        try:
            tl = max(0.001, min(4.0, _rtg(self.rt, f"{self.p}:time_l", 1.0)))
            tr = max(0.001, min(4.0, _rtg(self.rt, f"{self.p}:time_r", 1.0)))
            fbl = _c01(_rtg(self.rt, f"{self.p}:fb_l", 30) / 100)
            fbr = _c01(_rtg(self.rt, f"{self.p}:fb_r", 30) / 100)
            cfl = _c01(_rtg(self.rt, f"{self.p}:cf_l", 0) / 100)
            cfr = _c01(_rtg(self.rt, f"{self.p}:cf_r", 0) / 100)
            mix = _c01(_rtg(self.rt, f"{self.p}:mix", 30) / 100)
            dl = min(int(tl * sr), self._maxd - 1)
            dr = min(int(tr * sr), self._maxd - 1)
            M = self._maxd
            for i in range(frames):
                ol = float(self._bl[(self._pl - dl) % M])
                orr = float(self._br[(self._pr - dr) % M])
                il_ = float(buf[i, 0])
                ir_ = float(buf[i, 1])
                self._bl[self._pl] = il_ + ol * fbl + orr * cfl
                self._br[self._pr] = ir_ + orr * fbr + ol * cfr
                self._pl = (self._pl + 1) % M
                self._pr = (self._pr + 1) % M
                buf[i, 0] = il_ * (1 - mix) + ol * mix
                buf[i, 1] = ir_ * (1 - mix) + orr * mix
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  3.  REVERB  —  Schroeder 4-Comb + 2-Allpass
# ═══════════════════════════════════════════════════════════

class ReverbFx(AudioFxBase):
    _CD = [1557, 1617, 1491, 1422]
    _AD = [225, 556]

    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix
        if np is not None:
            self._cb = [np.zeros(d + 4800, dtype=np.float32) for d in self._CD]
            self._ab = [np.zeros(d + 600, dtype=np.float32) for d in self._AD]
        else:
            self._cb = self._ab = None
        self._cp = [0] * 4
        self._ap = [0] * 2

    def process_inplace(self, buf, frames, sr):
        if np is None or self._cb is None:
            return
        try:
            decay = max(0.01, min(5.0, _rtg(self.rt, f"{self.p}:decay", 126) / 100.0))
            mix = _c01(_rtg(self.rt, f"{self.p}:mix", 50) / 100)
            diff = _c01(_rtg(self.rt, f"{self.p}:diffusion", 50) / 100)
            fb = 0.5 + 0.45 * min(1.0, decay)
            ag = 0.3 + 0.4 * diff
            for i in range(frames):
                mono = (float(buf[i, 0]) + float(buf[i, 1])) * 0.5
                cs = 0.0
                for c in range(4):
                    bl = len(self._cb[c])
                    rd = (self._cp[c] - self._CD[c]) % bl
                    oc = float(self._cb[c][rd])
                    self._cb[c][self._cp[c] % bl] = mono + oc * fb
                    self._cp[c] = (self._cp[c] + 1) % bl
                    cs += oc
                x = cs * 0.25
                for a in range(2):
                    bl = len(self._ab[a])
                    rd = (self._ap[a] - self._AD[a]) % bl
                    dl = float(self._ab[a][rd])
                    oa = dl - ag * x
                    self._ab[a][self._ap[a] % bl] = x + ag * dl
                    self._ap[a] = (self._ap[a] + 1) % bl
                    x = oa
                buf[i, 0] = float(buf[i, 0]) * (1 - mix) + x * mix
                buf[i, 1] = float(buf[i, 1]) * (1 - mix) + x * mix
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  4.  COMB Filter
# ═══════════════════════════════════════════════════════════

class CombFx(AudioFxBase):
    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix
        self._maxd = 4800
        if np is not None:
            self._dl = np.zeros((self._maxd, 2), dtype=np.float32)
        else:
            self._dl = None
        self._pos = 0

    def process_inplace(self, buf, frames, sr):
        if np is None or self._dl is None:
            return
        try:
            freq = max(20, min(2000, _rtg(self.rt, f"{self.p}:freq", 267)))
            fb = max(-1, min(1, _rtg(self.rt, f"{self.p}:feedback", 0) / 100))
            mix = _c01(_rtg(self.rt, f"{self.p}:mix", 50) / 100)
            ds = max(1, min(self._maxd - 1, int(sr / freq)))
            M = self._maxd
            for i in range(frames):
                rd = (self._pos - ds) % M
                for ch in range(2):
                    d = float(self._dl[rd, ch])
                    inp = float(buf[i, ch])
                    self._dl[self._pos, ch] = inp + d * fb
                    buf[i, ch] = inp * (1 - mix) + d * mix
                self._pos = (self._pos + 1) % M
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  5.  COMPRESSOR
# ═══════════════════════════════════════════════════════════

class CompressorFx(AudioFxBase):
    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix
        self._env = 0.0

    def process_inplace(self, buf, frames, sr):
        if np is None:
            return
        try:
            th_db = _rtg(self.rt, f"{self.p}:thresh", -200) / 10.0
            ratio = max(1.0, _rtg(self.rt, f"{self.p}:ratio", 40) / 10.0)
            att_ms = max(0.1, _rtg(self.rt, f"{self.p}:attack", 10))
            rel_ms = max(1.0, _rtg(self.rt, f"{self.p}:release", 200))
            in_db = _rtg(self.rt, f"{self.p}:input", 0) / 10.0
            out_db = _rtg(self.rt, f"{self.p}:output", 0) / 10.0
            makeup = bool(_rtg(self.rt, f"{self.p}:makeup", 0))
            th_lin = 10 ** (th_db / 20)
            ig = 10 ** (in_db / 20)
            og = 10 ** (out_db / 20)
            ac = math.exp(-1 / (att_ms * 0.001 * sr)) if att_ms > 0 else 0
            rc = math.exp(-1 / (rel_ms * 0.001 * sr)) if rel_ms > 0 else 0
            if makeup and ratio > 1:
                og *= 10 ** ((-th_db * (1 - 1 / ratio)) / 20)
            if abs(ig - 1) > 0.001:
                np.multiply(buf[:frames], ig, out=buf[:frames])
            env = self._env
            for i in range(frames):
                pk = max(abs(float(buf[i, 0])), abs(float(buf[i, 1])))
                env = ac * env + (1 - ac) * pk if pk > env else rc * env + (1 - rc) * pk
                if env > th_lin and env > 1e-10:
                    gr = 10 ** (-(20 * math.log10(env / th_lin) * (1 - 1 / ratio)) / 20)
                else:
                    gr = 1.0
                buf[i, 0] *= gr
                buf[i, 1] *= gr
            self._env = env
            if abs(og - 1) > 0.001:
                np.multiply(buf[:frames], og, out=buf[:frames])
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  6.  FILTER+
# ═══════════════════════════════════════════════════════════

class FilterPlusFx(AudioFxBase):
    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix
        self._st = [0.0] * 4
        self._lfo_ph = 0.0

    def process_inplace(self, buf, frames, sr):
        if np is None:
            return
        try:
            drv_db = _rtg(self.rt, f"{self.p}:drive_db", 8)
            freq = max(20, min(20000, _rtg(self.rt, f"{self.p}:freq", 1050)))
            res = max(0.1, min(18, _rtg(self.rt, f"{self.p}:res", 25) * 0.18))
            mix = _c01(_rtg(self.rt, f"{self.p}:mix", 100) / 100)
            lfo_r = max(0.01, _rtg(self.rt, f"{self.p}:lfo_rate", 1.0))
            if abs(drv_db) > 0.1:
                np.multiply(buf[:frames], 10 ** (drv_db / 20), out=buf[:frames])
            inc = lfo_r / sr
            ph = self._lfo_ph
            for i in range(frames):
                mod = math.sin(2 * math.pi * ph) * freq * 0.3
                fc = max(20, min(sr * 0.45, freq + mod))
                b0, b1, b2, a1, a2 = _biquad_coeffs(0, fc, max(0.1, res), sr)
                for ch in range(2):
                    xi = float(buf[i, ch])
                    z1, z2 = self._st[ch * 2], self._st[ch * 2 + 1]
                    yi = b0 * xi + z1
                    z1 = b1 * xi - a1 * yi + z2
                    z2 = b2 * xi - a2 * yi
                    self._st[ch * 2], self._st[ch * 2 + 1] = z1, z2
                    buf[i, ch] = xi * (1 - mix) + yi * mix
                ph = (ph + inc) % 1.0
            self._lfo_ph = ph
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  7.  DISTORTION+
# ═══════════════════════════════════════════════════════════

class DistortionPlusFx(AudioFxBase):
    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix

    def process_inplace(self, buf, frames, sr):
        if np is None:
            return
        try:
            drive = _c01(_rtg(self.rt, f"{self.p}:drive", 25) / 100)
            symm = _rtg(self.rt, f"{self.p}:symm", 0) / 100
            mix = _c01(_rtg(self.rt, f"{self.p}:mix", 100) / 100)
            if drive < 0.001 or mix < 0.001:
                return
            k = 1 + 30 * drive
            for i in range(frames):
                for ch in range(2):
                    x = float(buf[i, ch])
                    wet = math.tanh((x + symm * 0.5) * k)
                    buf[i, ch] = x * (1 - mix) + wet * mix
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  8.  DYNAMICS
# ═══════════════════════════════════════════════════════════

class DynamicsFx(AudioFxBase):
    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix
        self._env = 0.0

    def process_inplace(self, buf, frames, sr):
        if np is None:
            return
        try:
            hi_db = _rtg(self.rt, f"{self.p}:hi_thresh", -100) / 10
            hi_r = max(1.0, _rtg(self.rt, f"{self.p}:hi_ratio", 10) / 10)
            att_ms = max(0.1, _rtg(self.rt, f"{self.p}:attack", 10))
            rel_ms = max(1.0, _rtg(self.rt, f"{self.p}:release", 200))
            out_db = _rtg(self.rt, f"{self.p}:output", 0) / 10
            hi_lin = 10 ** (hi_db / 20)
            ac = math.exp(-1 / (att_ms * 0.001 * sr)) if att_ms > 0 else 0
            rc = math.exp(-1 / (rel_ms * 0.001 * sr)) if rel_ms > 0 else 0
            og = 10 ** (out_db / 20)
            env = self._env
            for i in range(frames):
                pk = max(abs(float(buf[i, 0])), abs(float(buf[i, 1])))
                env = ac * env + (1 - ac) * pk if pk > env else rc * env + (1 - rc) * pk
                if env > hi_lin and env > 1e-10:
                    gr = 10 ** (-(20 * math.log10(env / hi_lin) * (1 - 1 / hi_r)) / 20)
                else:
                    gr = 1.0
                buf[i, 0] *= gr
                buf[i, 1] *= gr
            self._env = env
            if abs(og - 1) > 0.001:
                np.multiply(buf[:frames], og, out=buf[:frames])
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  9.  FLANGER
# ═══════════════════════════════════════════════════════════

class FlangerFx(AudioFxBase):
    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix
        self._maxd = 2400
        if np is not None:
            self._dl = np.zeros((self._maxd, 2), dtype=np.float32)
        else:
            self._dl = None
        self._pos = 0
        self._ph = 0.0

    def process_inplace(self, buf, frames, sr):
        if np is None or self._dl is None:
            return
        try:
            rate = max(0.01, _rtg(self.rt, f"{self.p}:rate", 0.44))
            tp = _c01(_rtg(self.rt, f"{self.p}:time", 50) / 100)
            fb = max(-1, min(1, _rtg(self.rt, f"{self.p}:feedback", 0) / 100))
            mix = _c01(_rtg(self.rt, f"{self.p}:mix", 50) / 100)
            bd = max(1, int(tp * 0.01 * sr))
            ld = bd * 0.8
            inc = rate / sr
            M = self._maxd
            ph = self._ph
            for i in range(frames):
                lfo = math.sin(2 * math.pi * ph)
                ds = max(1, min(M - 1, int(bd + lfo * ld)))
                rd = (self._pos - ds) % M
                for ch in range(2):
                    d = float(self._dl[rd, ch])
                    inp = float(buf[i, ch])
                    self._dl[self._pos, ch] = inp + d * fb
                    buf[i, ch] = inp * (1 - mix) + d * mix
                self._pos = (self._pos + 1) % M
                ph = (ph + inc) % 1.0
            self._ph = ph
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  10.  PITCH SHIFTER (Simple Granular)
# ═══════════════════════════════════════════════════════════

class PitchShifterFx(AudioFxBase):
    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix
        self._blen = 8192
        if np is not None:
            self._rb = np.zeros((self._blen, 2), dtype=np.float32)
        else:
            self._rb = None
        self._wp = 0
        self._rp = 0.0

    def process_inplace(self, buf, frames, sr):
        if np is None or self._rb is None:
            return
        try:
            semi = _rtg(self.rt, f"{self.p}:semi", 0)
            mix = _c01(_rtg(self.rt, f"{self.p}:mix", 100) / 100)
            if abs(semi) < 0.01 or mix < 0.001:
                return
            ratio = 2.0 ** (semi / 12.0)
            B = self._blen
            for i in range(frames):
                for ch in range(2):
                    self._rb[self._wp, ch] = float(buf[i, ch])
                self._wp = (self._wp + 1) % B
                ri = int(self._rp) % B
                for ch in range(2):
                    w = float(self._rb[ri, ch])
                    buf[i, ch] = float(buf[i, ch]) * (1 - mix) + w * mix
                self._rp = (self._rp + ratio) % B
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  11.  TREMOLO
# ═══════════════════════════════════════════════════════════

class TremoloFx(AudioFxBase):
    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix
        self._ph = 0.0

    def process_inplace(self, buf, frames, sr):
        if np is None:
            return
        try:
            rate = max(0.01, _rtg(self.rt, f"{self.p}:rate", 316) / 100)
            depth = _c01(_rtg(self.rt, f"{self.p}:depth", 50) / 100)
            if depth < 0.001:
                return
            inc = rate / sr
            ph = self._ph
            for i in range(frames):
                lfo = 0.5 + 0.5 * math.sin(2 * math.pi * ph)
                g = 1 - depth * (1 - lfo)
                buf[i, 0] *= g
                buf[i, 1] *= g
                ph = (ph + inc) % 1.0
            self._ph = ph
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  12.  PEAK LIMITER
# ═══════════════════════════════════════════════════════════

class PeakLimiterFx(AudioFxBase):
    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix
        self._env = 0.0

    def process_inplace(self, buf, frames, sr):
        if np is None:
            return
        try:
            in_db = _rtg(self.rt, f"{self.p}:input", 0) / 10
            rel_ms = max(1.0, _rtg(self.rt, f"{self.p}:release", 300))
            ceil_db = min(0, _rtg(self.rt, f"{self.p}:ceiling", 0) / 10)
            ig = 10 ** (in_db / 20)
            ceil = 10 ** (ceil_db / 20)
            rc = math.exp(-1 / (rel_ms * 0.001 * sr)) if rel_ms > 0 else 0
            if abs(ig - 1) > 0.001:
                np.multiply(buf[:frames], ig, out=buf[:frames])
            env = self._env
            for i in range(frames):
                pk = max(abs(float(buf[i, 0])), abs(float(buf[i, 1])))
                env = pk if pk > env else rc * env + (1 - rc) * pk
                if env > ceil and env > 1e-10:
                    gr = ceil / env
                    buf[i, 0] *= gr
                    buf[i, 1] *= gr
            self._env = env
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  13.  CHORUS
# ═══════════════════════════════════════════════════════════

class ChorusFx(AudioFxBase):
    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix
        self._maxd = 4800
        if np is not None:
            self._dl = np.zeros((self._maxd, 2), dtype=np.float32)
        else:
            self._dl = None
        self._pos = 0
        self._ph = 0.0

    def process_inplace(self, buf, frames, sr):
        if np is None or self._dl is None:
            return
        try:
            dms = max(0.1, _rtg(self.rt, f"{self.p}:delay", 14.5))
            rate = max(0.01, _rtg(self.rt, f"{self.p}:rate", 31) / 100)
            mix = _c01(_rtg(self.rt, f"{self.p}:mix", 50) / 100)
            width = _c01(_rtg(self.rt, f"{self.p}:width", 50) / 100)
            bd = max(1, min(self._maxd - 1, int(dms * 0.001 * sr)))
            md = bd * 0.3
            inc = rate / sr
            M = self._maxd
            ph = self._ph
            for i in range(frames):
                ll = math.sin(2 * math.pi * ph)
                lr = math.sin(2 * math.pi * (ph + width * 0.5))
                dl = max(1, min(M - 1, int(bd + ll * md)))
                dr = max(1, min(M - 1, int(bd + lr * md)))
                rl = (self._pos - dl) % M
                rr = (self._pos - dr) % M
                for ch in range(2):
                    self._dl[self._pos, ch] = float(buf[i, ch])
                wl = float(self._dl[rl, 0])
                wr = float(self._dl[rr, 1])
                buf[i, 0] = float(buf[i, 0]) * (1 - mix) + wl * mix
                buf[i, 1] = float(buf[i, 1]) * (1 - mix) + wr * mix
                self._pos = (self._pos + 1) % M
                ph = (ph + inc) % 1.0
            self._ph = ph
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  14.  XY FX (Gain/Width Morph)
# ═══════════════════════════════════════════════════════════

class XYFxFx(AudioFxBase):
    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix

    def process_inplace(self, buf, frames, sr):
        if np is None:
            return
        try:
            x = _c01(_rtg(self.rt, f"{self.p}:x", 50) / 100)
            y = _c01(_rtg(self.rt, f"{self.p}:y", 50) / 100)
            wg = max(0, _rtg(self.rt, f"{self.p}:wet_gain", 100) / 100)
            mix = _c01(_rtg(self.rt, f"{self.p}:mix", 100) / 100)
            g = (0.5 + 0.5 * y) * wg
            if abs(g - 1) > 0.001 or abs(mix - 1) > 0.001:
                mid = (buf[:frames, 0] + buf[:frames, 1]) * 0.5
                side = (buf[:frames, 0] - buf[:frames, 1]) * 0.5 * x
                wl = (mid + side) * g
                wr = (mid - side) * g
                buf[:frames, 0] = buf[:frames, 0] * (1 - mix) + wl * mix
                buf[:frames, 1] = buf[:frames, 1] * (1 - mix) + wr * mix
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  15.  DE-ESSER
# ═══════════════════════════════════════════════════════════

class DeEsserFx(AudioFxBase):
    def __init__(self, prefix, rt, params, **kw):
        self.rt, self.p = rt, prefix
        self._env = 0.0
        self._fst = [0.0, 0.0]

    def process_inplace(self, buf, frames, sr):
        if np is None:
            return
        try:
            freq = max(200, min(16000, _rtg(self.rt, f"{self.p}:freq", 4980)))
            amt = _c01(_rtg(self.rt, f"{self.p}:amount", 50) / 100)
            if amt < 0.01:
                return
            b0, b1, b2, a1, a2 = _biquad_coeffs(1, freq, 1.0, sr)
            ac = math.exp(-1 / (0.001 * sr))
            rc = math.exp(-1 / (0.05 * sr))
            env = self._env
            for i in range(frames):
                mono = (float(buf[i, 0]) + float(buf[i, 1])) * 0.5
                z1, z2 = self._fst
                hp = b0 * mono + z1
                z1 = b1 * mono - a1 * hp + z2
                z2 = b2 * mono - a2 * hp
                self._fst[0], self._fst[1] = z1, z2
                lv = abs(hp)
                env = ac * env + (1 - ac) * lv if lv > env else rc * env + (1 - rc) * lv
                gr = max(1 - amt * env * 10, 0.1) if env > 0.01 else 1.0
                buf[i, 0] *= gr
                buf[i, 1] *= gr
            self._env = env
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════
#  FACTORY
# ═══════════════════════════════════════════════════════════

FX_PROCESSOR_MAP = {
    "chrono.fx.eq5": EQ5Fx,
    "chrono.fx.delay2": Delay2Fx,
    "chrono.fx.reverb": ReverbFx,
    "chrono.fx.comb": CombFx,
    "chrono.fx.compressor": CompressorFx,
    "chrono.fx.filter_plus": FilterPlusFx,
    "chrono.fx.distortion_plus": DistortionPlusFx,
    "chrono.fx.dynamics": DynamicsFx,
    "chrono.fx.flanger": FlangerFx,
    "chrono.fx.pitch_shifter": PitchShifterFx,
    "chrono.fx.tremolo": TremoloFx,
    "chrono.fx.peak_limiter": PeakLimiterFx,
    "chrono.fx.chorus": ChorusFx,
    "chrono.fx.xy_fx": XYFxFx,
    "chrono.fx.de_esser": DeEsserFx,
}


def create_fx_processor(plugin_id: str, prefix: str, rt_params: Any,
                        params: dict, max_frames: int = 8192):
    """Factory: DSP-Processor für ein Plugin erzeugen.

    Returns AudioFxBase instance oder None.
    """
    cls = FX_PROCESSOR_MAP.get(plugin_id)
    if cls is None:
        return None
    try:
        return cls(prefix=prefix, rt=rt_params, params=params, max_frames=max_frames)
    except Exception:
        return None
