# Letzter Stand: v0.0.20.568 (2026-03-17)

## Session-Zusammenfassung: 42 Versionen (v527→v568)

### Neue Feature-Systeme:
1. **Send/Return System** (v527–v529) — Pre/Post Toggle, Send-Automation, MIDI Learn
2. **Device-Container System** (v530–v534) — FX Layer (parallel), Chain (seriell), Instrument Layer (Stack)
3. **Instrument Layer System** (v536–v568) — Bitwig-Level Feature-Paritaet:
   - Datenmodell + UI + Instrument-Picker (alle Formate)
   - Multi-Engine MIDI-Dispatch + Bitwig-Style Audio-Summierung
   - Velocity-Split, Key-Range, Crossfade
   - Built-in + SF2 + VST3/VST2/CLAP/LV2 Instrumente
   - Container Preset Save/Load
   - **Bitwig-Style Layer-Zoom** mit Breadcrumb-Navigation (alle 3 Container)
   - Instrument-Widget mit Engine-Verbindung (Knobs wirken!)
   - FX-Chain: Add (ALLE Formate!), Reorder, Enable/Disable, Remove
   - SF2-Widget mit Bank/Preset-Selector
   - Einheitliche Widget-Groesse (volle Breite)
4. **Rechtsklick-Menue fuer ALLE Plugins** (v568):
   - 2 Audio-FX (Gain, Distortion) hatten bereits volles Menue
   - 13 Audio-FX (EQ-5 bis De-Esser) bekamen MIDI Learn
   - 6 Note-FX (Transpose bis Random) bekamen vollstaendiges Menue
   - Einheitliche Menue-Texte in allen 3 Codepfaden

### Sonstige Fixes:
- Notation: Playhead Click-to-Seek + Follow (v535)
- NotationView __init__ Critical Bugfix (v544)
- Stuck Notes Fix (v557)
- ProSampler Import Fix (v564)
- FX-Menue ohne 80-Item-Limit (v566)

### Naechste empfohlene Tasks:
1. **MIDI Learn fuer Layer-Knobs** — CC-Mapping mit Layer-Kontext
2. **Automation-Lanes fuer Layer-Parameter** — RT-Key-Mapping (groesserer Umbau)
3. **Sidechain-Input von FX-Track**
4. **CLAP Preset Browser**
5. **CLAP Note Expressions**

### Statistik:
- 42 Versionen in einer Session
- ~6000+ neue Zeilen Code
- 0 Regressionen ("nichts kaputt machen" Direktive eingehalten)
