#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════
#  🎵 Py_DAW — ChronoScaleStudio
#  Ein Befehl. Alles automatisch.
#
#  Nutzung:  ./start_daw.sh
#
#  Was passiert automatisch:
#  1. Python venv erstellen (falls nötig)
#  2. Python-Pakete installieren (falls nötig)
#  3. C-Extensions kompilieren (falls gcc vorhanden)
#  4. Rust-Engine starten (falls gebaut)
#  5. DAW starten
#
#  Optionen:
#    USE_RUST_ENGINE=0 ./start_daw.sh   # Ohne Rust-Engine
#    ./start_daw.sh --rebuild           # Alles neu bauen
#    ./start_daw.sh --native            # Native Rust/Qt6 UI (Phase 2)
#    ./start_daw.sh --both              # Beide UIs parallel (Debug)
#
#  v0.0.21.139
# ═══════════════════════════════════════════════════════════

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

REBUILD=0
UI_MODE="python"   # python | native | both
LAUNCH_VISUAL=0    # v0.0.21.308.1.0: Engine wird IMMER gebaut; --visual öffnet nur zusätzlich das Fenster
for arg in "$@"; do
    case "$arg" in
        --rebuild) REBUILD=1 ;;
        --native)  UI_MODE="native" ;;
        --both)    UI_MODE="both" ;;
        --visual)  LAUNCH_VISUAL=1 ;;
    esac
done

echo ""
echo "════════════════════════════════════════"
echo "  🎵 Py_DAW — ChronoScaleStudio"
echo "  Version: $(cat VERSION 2>/dev/null || echo '?')"
echo "════════════════════════════════════════"
echo ""

# ═══════════════════════════════════════════════════════════
#  0. Distro-Erkennung + System-Abhängigkeiten
# ═══════════════════════════════════════════════════════════

_detect_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        case "$ID" in
            arch|manjaro|endeavouros|garuda|cachyos)
                echo "arch"
                return ;;
            steamos)
                echo "steamos"
                return ;;
        esac
        case "$ID_LIKE" in
            *arch*)
                echo "arch"
                return ;;
            *debian*)
                echo "debian"
                return ;;
        esac
    fi
    if command -v pacman &>/dev/null; then
        echo "arch"
    elif command -v apt-get &>/dev/null; then
        echo "debian"
    else
        echo "unknown"
    fi
}

DISTRO="$(_detect_distro)"

_install_arch_deps() {
    # System-Pakete für Arch Linux / SteamOS
    # pipewire-jack: JACK-Kompatibilitätsschicht (PipeWire)
    # pipewire-alsa: ALSA → PipeWire Bridge (für sounddevice/PortAudio)
    # portaudio: C-Bibliothek für sounddevice Python-Paket
    # python-pyqt6: Qt6 Bindings
    # lilv: LV2 Plugin-Hosting
    # fluidsynth: SF2 Soundfont Support
    # base-devel: gcc für C-Extensions
    local NEEDED_PKGS=""
    local CHECK_PKGS=(
        "pipewire-jack"
        "pipewire-alsa"
        "portaudio"
        "lilv"
        "fluidsynth"
        "ffmpeg"
        "libx11"
        "libxcb"
    )

    for pkg in "${CHECK_PKGS[@]}"; do
        if ! pacman -Qi "$pkg" &>/dev/null; then
            NEEDED_PKGS="$NEEDED_PKGS $pkg"
        fi
    done

    # base-devel für gcc (C-Extensions)
    if ! command -v gcc &>/dev/null; then
        NEEDED_PKGS="$NEEDED_PKGS base-devel"
    fi

    if [ -n "$NEEDED_PKGS" ]; then
        echo "📦 Arch/SteamOS: Installiere System-Abhängigkeiten..."
        echo "   Pakete:$NEEDED_PKGS"
        if command -v sudo &>/dev/null; then
            sudo pacman -S --needed --noconfirm $NEEDED_PKGS 2>&1 | tail -5 || {
                echo "  ⚠️  Einige Pakete konnten nicht installiert werden."
                echo "  Manuell: sudo pacman -S$NEEDED_PKGS"
            }
        else
            echo "  ⚠️  sudo nicht gefunden. Bitte manuell installieren:"
            echo "  pacman -S$NEEDED_PKGS"
        fi
    else
        echo "  ✅ System-Abhängigkeiten OK (Arch)"
    fi
}

_install_debian_deps() {
    # Bestehende Debian-Logik
    local NEEDED_PKGS=""
    local CHECK_PKGS=(
        "python3-venv"
        "python3-pip"
        "python3-dev"
        "libjack-jackd2-dev"
        "libportaudio2"
        "python3-lilv"
        "lilv-utils"
        "libfluidsynth3"
        "ffmpeg"
        "libx11-dev"
        "libxcb1-dev"
    )

    for pkg in "${CHECK_PKGS[@]}"; do
        if ! dpkg -s "$pkg" &>/dev/null 2>&1; then
            NEEDED_PKGS="$NEEDED_PKGS $pkg"
        fi
    done

    if [ -n "$NEEDED_PKGS" ]; then
        echo "📦 Debian/Ubuntu: Installiere System-Abhängigkeiten..."
        echo "   Pakete:$NEEDED_PKGS"
        if command -v sudo &>/dev/null; then
            sudo apt-get update -qq 2>/dev/null
            sudo apt-get install -y $NEEDED_PKGS 2>&1 | tail -5 || {
                echo "  ⚠️  Einige Pakete konnten nicht installiert werden."
                echo "  Manuell: sudo apt install$NEEDED_PKGS"
            }
        fi
    else
        echo "  ✅ System-Abhängigkeiten OK (Debian)"
    fi
}

case "$DISTRO" in
    arch|steamos)
        echo "🐧 Erkannt: Arch Linux / SteamOS ($DISTRO)"
        _install_arch_deps
        ;;
    debian)
        echo "🐧 Erkannt: Debian / Ubuntu / Kali"
        _install_debian_deps
        ;;
    *)
        echo "🐧 Distro: unbekannt (Abhängigkeiten manuell installieren)"
        ;;
esac

# ═══════════════════════════════════════════════════════════
#  1. Python venv — automatisch erstellen wenn nötig
# ═══════════════════════════════════════════════════════════

VENV_DIR="$DIR/myenv"

activate_venv() {
    if [ -n "$VIRTUAL_ENV" ]; then
        return 0
    fi
    if [ -f "$VENV_DIR/bin/activate" ]; then
        . "$VENV_DIR/bin/activate"
        return 0
    fi
    if [ -f "$HOME/myenv/bin/activate" ]; then
        . "$HOME/myenv/bin/activate"
        return 0
    fi
    return 1
}

if ! activate_venv; then
    echo "📦 Erstelle Python Virtual Environment..."
    PYTHON_CMD=""
    for p in python3.13 python3.12 python3.11 python3; do
        if command -v "$p" &>/dev/null; then
            PYTHON_CMD="$p"
            break
        fi
    done

    if [ -z "$PYTHON_CMD" ]; then
        echo "❌ Python3 nicht gefunden. Bitte installieren:"
        echo "   sudo apt install python3 python3-venv python3-pip"
        exit 1
    fi

    $PYTHON_CMD -m venv "$VENV_DIR" 2>/dev/null || {
        echo "⚠️  python3-venv fehlt. Versuche Installation..."
        if [ "$DISTRO" = "arch" ] || [ "$DISTRO" = "steamos" ]; then
            sudo pacman -S --needed --noconfirm python 2>/dev/null || true
        else
            sudo apt-get install -y python3-venv 2>/dev/null || true
        fi
        $PYTHON_CMD -m venv "$VENV_DIR" || {
            echo "❌ Konnte kein venv erstellen."
            if [ "$DISTRO" = "arch" ] || [ "$DISTRO" = "steamos" ]; then
                echo "   sudo pacman -S python"
            else
                echo "   sudo apt install python3-venv"
            fi
            exit 1
        }
    }
    . "$VENV_DIR/bin/activate"
    echo "  ✅ venv erstellt"
    REBUILD=1  # Erstmalig → alles installieren
fi

echo "🐍 Python: $(python3 --version 2>&1)"

# ═══════════════════════════════════════════════════════════
#  2. Python-Pakete — nur installieren wenn nötig
# ═══════════════════════════════════════════════════════════

_check_packages() {
    python3 -c "
import sys
try:
    import PyQt6.QtWidgets
    import numpy
    import sounddevice
    import fluidsynth
    sys.exit(0)
except ImportError:
    sys.exit(1)
" 2>/dev/null
}

if [ "$REBUILD" = "1" ] || ! _check_packages; then
    echo "📦 Installiere Python-Pakete..."
    pip install --quiet --upgrade pip 2>/dev/null || true
    if [ -f "$DIR/requirements.txt" ]; then
        pip install --quiet -r "$DIR/requirements.txt" 2>&1 | tail -2 && \
            echo "  ✅ Pakete installiert" || \
            echo "  ⚠️  Einige Pakete fehlgeschlagen (DAW startet trotzdem)"
    fi
else
    echo "  ✅ Python-Pakete OK"
fi

# v0.0.20.862: Auto-install optional packages if missing (won't trigger full reinstall)
_install_if_missing() {
    python3 -c "import $1" 2>/dev/null || {
        pip install --quiet "$2" 2>/dev/null && echo "  ✅ $2 nachinstalliert" || true
    }
}
_install_if_missing websockets websockets
_install_if_missing zeroconf zeroconf

# v0.0.20.952: Whisper für Video Text-Editing (VE11)
python3 -c "
try:
    import faster_whisper
except ImportError:
    try:
        import whisper
    except ImportError:
        import sys; sys.exit(1)
" 2>/dev/null || {
    echo "  🎤 Installiere openai-whisper (Video-Transkription)..."
    pip install --quiet openai-whisper 2>/dev/null && echo "  ✅ openai-whisper installiert" || {
        echo "  ℹ️  Whisper nicht installiert (optional — Video-Transkription deaktiviert)"
        echo "     Manuell: pip install openai-whisper  ODER  pip install faster-whisper"
    }
}

# v0.0.20.925: Video-Integration Pro dependencies
_install_if_missing cv2 opencv-python-headless
_install_if_missing msgpack msgpack

# v0.0.20.989: KI-Komposition Dokument-Import (KK6)
_install_if_missing fitz pymupdf
_install_if_missing docx python-docx
# v0.0.21.024: KI-Audio-Codec (EnCodec + PyTorch)
_install_if_missing encodec encodec
_install_if_missing torch torch
_install_if_missing torchaudio torchaudio

# v0.0.20.925: Check ffmpeg system binary (needed for video features)
if ! command -v ffmpeg &>/dev/null; then
    echo "  ⚠️  ffmpeg nicht gefunden — Video-Features eingeschränkt"
    echo "     Installieren: sudo apt install ffmpeg  (oder: sudo pacman -S ffmpeg)"
fi

# ═══════════════════════════════════════════════════════════
#  3. C-Extensions — automatisch kompilieren (silent)
# ═══════════════════════════════════════════════════════════

AUDIO_DIR="$DIR/pydaw/audio"
C_BUILT=0

_build_c_ext() {
    local name="$1"
    local c_file="$AUDIO_DIR/$name.c"
    local so_file="$AUDIO_DIR/$name.so"

    [ -f "$c_file" ] || return 0

    # Nur neu bauen wenn .c neuer als .so oder .so fehlt oder --rebuild
    if [ "$REBUILD" = "1" ] || [ ! -f "$so_file" ] || [ "$c_file" -nt "$so_file" ]; then
        if gcc -O3 -march=native -ffast-math -shared -fPIC -o "$so_file" "$c_file" -lm 2>/dev/null; then
            C_BUILT=$((C_BUILT + 1))
        fi
    fi
}

if command -v gcc &>/dev/null; then
    _build_c_ext "fast_filters"
    _build_c_ext "fast_builtin_fx"
    if [ "$C_BUILT" -gt 0 ]; then
        echo "  ⚡ $C_BUILT C-Extension(s) kompiliert (DSP-Turbo aktiv)"
    else
        echo "  ⚡ C-Extensions aktuell"
    fi
else
    if [ -f "$AUDIO_DIR/fast_filters.so" ] && [ -f "$AUDIO_DIR/fast_builtin_fx.so" ]; then
        echo "  ⚡ C-Extensions vorhanden (vorkompiliert)"
    else
        echo "  ℹ️  Optionaler Turbo: sudo apt install build-essential"
    fi
fi

# ═══════════════════════════════════════════════════════════
#  4. Rust-Toolchain + Engine (optional, automatisch)
# ═══════════════════════════════════════════════════════════

[ -f "$HOME/.cargo/env" ] && . "$HOME/.cargo/env"
[ -d "$HOME/.cargo/bin" ] && export PATH="$HOME/.cargo/bin:$PATH"

# v0.0.21.165: Workspace-Layout (zentrales target/release/) bevorzugt,
# Per-Crate-Layout als Fallback. So bleiben bestehende Builds funktional.
RUST_ENGINE_WS="$DIR/target/release/pydaw_engine"
RUST_ENGINE_PER="$DIR/pydaw_engine/target/release/pydaw_engine"
if [ -f "$RUST_ENGINE_WS" ]; then
    RUST_ENGINE="$RUST_ENGINE_WS"
else
    RUST_ENGINE="$RUST_ENGINE_PER"
fi
CARGO_TOML="$DIR/pydaw_engine/Cargo.toml"
RUST_OK=0

# v0.0.21.045: Auto-rebuild if any .rs source is newer than the binary
NEED_BUILD=0
if [ ! -f "$RUST_ENGINE" ]; then
    NEED_BUILD=1
elif [ -d "$DIR/pydaw_engine/src" ]; then
    NEWER=$(find "$DIR/pydaw_engine/src" -name "*.rs" -newer "$RUST_ENGINE" 2>/dev/null | head -1)
    if [ -n "$NEWER" ]; then
        NEED_BUILD=1
        echo "  🦀 Rust-Quellen geändert — baue neu..."
    fi
fi

if [ "$NEED_BUILD" = "0" ] && [ -f "$RUST_ENGINE" ]; then
    echo "  🦀 Rust-Engine: bereit"
    RUST_OK=1
elif command -v cargo &>/dev/null && [ -f "$CARGO_TOML" ]; then
    echo "  🦀 Baue Rust Audio-Engine (einmalig, 1-3 Min.)..."
    # v0.0.21.165: Wenn Workspace-Cargo.toml existiert, baue per Workspace
    # (-> target/release/), sonst per-crate (-> pydaw_engine/target/release/).
    if [ -f "$DIR/Cargo.toml" ] && grep -q "^\[workspace\]" "$DIR/Cargo.toml" 2>/dev/null; then
        BUILD_CMD=(cargo build --release --manifest-path "$DIR/Cargo.toml" -p pydaw_engine)
        RUST_ENGINE="$RUST_ENGINE_WS"
    else
        BUILD_CMD=(cargo build --release --manifest-path "$CARGO_TOML")
        RUST_ENGINE="$RUST_ENGINE_PER"
    fi
    if "${BUILD_CMD[@]}" 2>&1 | tail -20; then
        [ -f "$RUST_ENGINE" ] && RUST_OK=1 && echo "  🦀 Rust-Engine: ✅ gebaut"
    else
        echo "  🦀 ⚠️  Build fehlgeschlagen (Python-Fallback aktiv)"
    fi
else
    echo "  🐍 Audio: Python-Engine (Rust optional)"
fi

# ═══════════════════════════════════════════════════════════
#  4b. VST2 Editor Helper (pydaw_vst2_editor)
# ═══════════════════════════════════════════════════════════

# v0.0.21.165: Workspace-bevorzugt, Per-Crate-Fallback
VST2_EDITOR_WS="$DIR/target/release/pydaw_vst2_editor"
VST2_EDITOR_PER="$DIR/pydaw_vst2_editor/target/release/pydaw_vst2_editor"
if [ -f "$VST2_EDITOR_WS" ]; then VST2_EDITOR="$VST2_EDITOR_WS"; else VST2_EDITOR="$VST2_EDITOR_PER"; fi
VST2_EDITOR_TOML="$DIR/pydaw_vst2_editor/Cargo.toml"
if [ -f "$VST2_EDITOR_TOML" ] && command -v cargo &>/dev/null; then
    if [ ! -f "$VST2_EDITOR" ] || [ -n "$(find "$DIR/pydaw_vst2_editor/src" -name '*.rs' -newer "$VST2_EDITOR" 2>/dev/null | head -1)" ]; then
        echo "  🎹 Baue VST2 Editor Helper..."
        if [ -f "$DIR/Cargo.toml" ] && grep -q "^\[workspace\]" "$DIR/Cargo.toml" 2>/dev/null; then
            VST2_BUILD=(cargo build --release --manifest-path "$DIR/Cargo.toml" -p pydaw_vst2_editor)
            VST2_EDITOR="$VST2_EDITOR_WS"
        else
            VST2_BUILD=(cargo build --release --manifest-path "$VST2_EDITOR_TOML")
            VST2_EDITOR="$VST2_EDITOR_PER"
        fi
        if "${VST2_BUILD[@]}" 2>&1 | tail -5; then
            [ -f "$VST2_EDITOR" ] && echo "  🎹 VST2 Editor: ✅ gebaut"
        else
            echo "  🎹 ⚠️  VST2 Editor Build fehlgeschlagen (nicht kritisch)"
        fi
    else
        echo "  🎹 VST2 Editor: ✅ aktuell"
    fi
fi

# ═══════════════════════════════════════════════════════════
#  4c. VST3 Editor Helper (pydaw_vst3_editor)       v0.0.21.154
# ═══════════════════════════════════════════════════════════

# v0.0.21.165: Workspace-bevorzugt, Per-Crate-Fallback
VST3_EDITOR_WS="$DIR/target/release/pydaw_vst3_editor"
VST3_EDITOR_PER="$DIR/pydaw_vst3_editor/target/release/pydaw_vst3_editor"
if [ -f "$VST3_EDITOR_WS" ]; then VST3_EDITOR="$VST3_EDITOR_WS"; else VST3_EDITOR="$VST3_EDITOR_PER"; fi
VST3_EDITOR_TOML="$DIR/pydaw_vst3_editor/Cargo.toml"
if [ -f "$VST3_EDITOR_TOML" ] && command -v cargo &>/dev/null; then
    if [ ! -f "$VST3_EDITOR" ] || [ -n "$(find "$DIR/pydaw_vst3_editor/src" -name '*.rs' -newer "$VST3_EDITOR" 2>/dev/null | head -1)" ]; then
        echo "  🎹 Baue VST3 Editor Helper..."
        if [ -f "$DIR/Cargo.toml" ] && grep -q "^\[workspace\]" "$DIR/Cargo.toml" 2>/dev/null; then
            VST3_BUILD=(cargo build --release --manifest-path "$DIR/Cargo.toml" -p pydaw_vst3_editor)
            VST3_EDITOR="$VST3_EDITOR_WS"
        else
            VST3_BUILD=(cargo build --release --manifest-path "$VST3_EDITOR_TOML")
            VST3_EDITOR="$VST3_EDITOR_PER"
        fi
        if "${VST3_BUILD[@]}" 2>&1 | tail -5; then
            [ -f "$VST3_EDITOR" ] && echo "  🎹 VST3 Editor: ✅ gebaut"
        else
            echo "  🎹 ⚠️  VST3 Editor Build fehlgeschlagen (nicht kritisch)"
        fi
    else
        echo "  🎹 VST3 Editor: ✅ aktuell"
    fi
fi

# ═══════════════════════════════════════════════════════════
#  4d. CLAP Editor Helper (pydaw_clap_editor)       v0.0.21.154
# ═══════════════════════════════════════════════════════════

# v0.0.21.165: Workspace-bevorzugt, Per-Crate-Fallback
CLAP_EDITOR_WS="$DIR/target/release/pydaw_clap_editor"
CLAP_EDITOR_PER="$DIR/pydaw_clap_editor/target/release/pydaw_clap_editor"
if [ -f "$CLAP_EDITOR_WS" ]; then CLAP_EDITOR="$CLAP_EDITOR_WS"; else CLAP_EDITOR="$CLAP_EDITOR_PER"; fi
CLAP_EDITOR_TOML="$DIR/pydaw_clap_editor/Cargo.toml"
if [ -f "$CLAP_EDITOR_TOML" ] && command -v cargo &>/dev/null; then
    if [ ! -f "$CLAP_EDITOR" ] || [ -n "$(find "$DIR/pydaw_clap_editor/src" -name '*.rs' -newer "$CLAP_EDITOR" 2>/dev/null | head -1)" ]; then
        echo "  🎹 Baue CLAP Editor Helper..."
        if [ -f "$DIR/Cargo.toml" ] && grep -q "^\[workspace\]" "$DIR/Cargo.toml" 2>/dev/null; then
            CLAP_BUILD=(cargo build --release --manifest-path "$DIR/Cargo.toml" -p pydaw_clap_editor)
            CLAP_EDITOR="$CLAP_EDITOR_WS"
        else
            CLAP_BUILD=(cargo build --release --manifest-path "$CLAP_EDITOR_TOML")
            CLAP_EDITOR="$CLAP_EDITOR_PER"
        fi
        if "${CLAP_BUILD[@]}" 2>&1 | tail -5; then
            [ -f "$CLAP_EDITOR" ] && echo "  🎹 CLAP Editor: ✅ gebaut"
        else
            echo "  🎹 ⚠️  CLAP Editor Build fehlgeschlagen (nicht kritisch)"
        fi
    else
        echo "  🎹 CLAP Editor: ✅ aktuell"
    fi
fi

# ═══════════════════════════════════════════════════════════
#  4d-bis. FLUX Visual-Engine (ADR-001)               v0.0.21.308
# ═══════════════════════════════════════════════════════════
# v0.0.21.308.1.0 (Anno-Auftrag): Die Visual-Engine wird jetzt IMMER beim
# normalen `./start_daw.sh` mitgebaut — exakt wie die VST/CLAP-Editoren.
# `--visual` ist nur noch das OPTIONALE Auto-Öffnen des Fensters (+ Smoke).
#
# NICHTS KAPUTT bleibt gewahrt:
#   • Eigener Prozess (wgpu+winit), getrennt von Audio.
#   • Crate ist NICHT in default-members → `cargo build --release` (ohne -p)
#     baut es nicht; ein wgpu-Fehler kann den Audio-/Editor-Build nie brechen.
#   • Hier bauen wir es bewusst EXPLIZIT (-p pydaw_visual_engine) und fangen
#     einen Fehlschlag ab (nicht kritisch) — der DAW-Start läuft weiter.
#   • Benötigt rustc >= 1.76 (wgpu 0.19); bei Fehlschlag Hinweis + weiter.
#
# v0.0.21.308.6.0 (Baldr-Pixel Slice 3/4): Die Visual-Engine wird jetzt MIT
# `--features camera` gebaut, damit `--camera-selftest` / `--camera-window`
# und die Live-Kamera-Kette (camera.pd) ohne Extra-Build sofort funktionieren.
#   • Das Kamera-Feature ist in Cargo.toml weiterhin DEFAULT AUS (ADR-001-
#     Vertrag); wir aktivieren es hier explizit beim Bauen.
#   • NICHTS KAPUTT: schlägt der Kamera-Build fehl (z. B. libv4l-Header fehlen),
#     bauen wir AUTOMATISCH ohne `--features camera` weiter — die DAW bekommt
#     dann ein voll funktionsfähiges (kamera-loses) Visual-Binary statt gar
#     keins. Der Kamera-Build berührt Audio/Editoren ohnehin nicht (eigener
#     Prozess, eigener Dependency-Tree).
VIS_WS="$DIR/target/release/pydaw_visual_engine"
VIS_PER="$DIR/pydaw_visual_engine/target/release/pydaw_visual_engine"
if [ -f "$VIS_WS" ]; then VIS_BIN="$VIS_WS"; else VIS_BIN="$VIS_PER"; fi
VIS_TOML="$DIR/pydaw_visual_engine/Cargo.toml"
if [ -f "$VIS_TOML" ] && command -v cargo &>/dev/null; then
    if [ ! -f "$VIS_BIN" ] || [ -n "$(find "$DIR/pydaw_visual_engine/src" -name '*.rs' -newer "$VIS_BIN" 2>/dev/null | head -1)" ]; then
        echo "  🎨 Baue FLUX Visual-Engine mit Kamera-Feature (einmalig, einige Min.)..."
        # Workspace- vs. Standalone-Build: Manifest + Zielbinary bestimmen.
        if [ -f "$DIR/Cargo.toml" ] && grep -q "^\[workspace\]" "$DIR/Cargo.toml" 2>/dev/null; then
            VIS_MANIFEST=(--manifest-path "$DIR/Cargo.toml" -p pydaw_visual_engine)
            VIS_BIN="$VIS_WS"
        else
            VIS_MANIFEST=(--manifest-path "$VIS_TOML")
            VIS_BIN="$VIS_PER"
        fi
        # 1. Versuch: MIT Kamera-Feature (v4l). Live-Bild sofort verfügbar.
        if cargo build --release "${VIS_MANIFEST[@]}" --features camera 2>&1 | tail -8; then
            [ -f "$VIS_BIN" ] && echo "  🎨 FLUX Visual-Engine: ✅ gebaut (Kamera aktiv)"
        else
            # 2. Fallback: OHNE Kamera-Feature, damit die DAW trotzdem ein
            #    lauffähiges Visual-Binary erhält (NICHTS KAPUTT).
            echo "  🎨 ⚠️  Kamera-Build fehlgeschlagen — baue ohne Kamera-Feature weiter."
            echo "      (Live-Kamera braucht libv4l-dev: 'sudo apt install libv4l-dev')"
            if cargo build --release "${VIS_MANIFEST[@]}" 2>&1 | tail -6; then
                [ -f "$VIS_BIN" ] && echo "  🎨 FLUX Visual-Engine: ✅ gebaut (ohne Kamera)"
            else
                echo "  🎨 ⚠️  Visual-Engine Build fehlgeschlagen (nicht kritisch — DAW startet weiter)."
                echo "      Hinweis: wgpu 0.19 braucht rustc >= 1.76 → 'rustup update stable'."
                echo "      Siehe PROJECT_DOCS/adr/ADR-001-flux-visual-engine.md"
            fi
        fi
    else
        echo "  🎨 FLUX Visual-Engine: ✅ aktuell"
    fi
else
    echo "  🎨 ⚠️  cargo fehlt — Visual-Engine wird übersprungen (nicht kritisch)."
fi

# --visual: OPTIONAL das Fenster gleich mit-öffnen (+ Headless-Smoke-PNG).
# Das Fenster lässt sich jederzeit auch im Menü „Ansicht → 🎨 FLUX-Visual
# öffnen…" starten — dann mit der aktuellen FLUX-Render-Kette als Graph.
if [ "$LAUNCH_VISUAL" = "1" ] && [ -f "$VIS_BIN" ]; then
    echo "  🎨 Smoke-Test (headless → /tmp/flux_v0.png)..."
    "$VIS_BIN" --headless --out /tmp/flux_v0.png 2>&1 | tail -3 || true
    echo "  🎨 Starte FLUX Visual-Fenster..."
    "$VIS_BIN" &
    FLUX_VISUAL_PID=$!
    echo "  🎨 FLUX Visual-Fenster PID: $FLUX_VISUAL_PID"
fi

# ═══════════════════════════════════════════════════════════
#  4e. py_daw_app — zentrales Launcher-Binary       v0.0.21.165
# ═══════════════════════════════════════════════════════════
# WAECHTER-Stil: nach `cargo build --release` liegt py_daw_app unter
# target/release/py_daw_app und kann die ganze App starten:
#   ./target/release/py_daw_app run
# Wenn nicht gebaut, ist das nicht kritisch — start_daw.sh selbst startet
# weiterhin die DAW. py_daw_app ist OPT-IN für Distros / Desktop-Files.
PY_DAW_APP_WS="$DIR/target/release/py_daw_app"
PY_DAW_APP_PER="$DIR/py_daw_app/target/release/py_daw_app"
if [ -f "$PY_DAW_APP_WS" ]; then PY_DAW_APP_BIN="$PY_DAW_APP_WS"; else PY_DAW_APP_BIN="$PY_DAW_APP_PER"; fi
PY_DAW_APP_TOML="$DIR/py_daw_app/Cargo.toml"
if [ -f "$PY_DAW_APP_TOML" ] && command -v cargo &>/dev/null; then
    if [ ! -f "$PY_DAW_APP_BIN" ] || [ -n "$(find "$DIR/py_daw_app/src" -name '*.rs' -newer "$PY_DAW_APP_BIN" 2>/dev/null | head -1)" ]; then
        echo "  📦 Baue py_daw_app (zentraler Launcher)..."
        if [ -f "$DIR/Cargo.toml" ] && grep -q "^\[workspace\]" "$DIR/Cargo.toml" 2>/dev/null; then
            APP_BUILD=(cargo build --release --manifest-path "$DIR/Cargo.toml" -p py_daw_app)
            PY_DAW_APP_BIN="$PY_DAW_APP_WS"
        else
            APP_BUILD=(cargo build --release --manifest-path "$PY_DAW_APP_TOML")
            PY_DAW_APP_BIN="$PY_DAW_APP_PER"
        fi
        if "${APP_BUILD[@]}" 2>&1 | tail -5; then
            [ -f "$PY_DAW_APP_BIN" ] && echo "  📦 py_daw_app: ✅ gebaut → $PY_DAW_APP_BIN"
        else
            echo "  📦 ⚠️  py_daw_app Build fehlgeschlagen (nicht kritisch — start_daw.sh übernimmt)"
        fi
    else
        echo "  📦 py_daw_app: ✅ aktuell"
    fi
fi

# ═══════════════════════════════════════════════════════════
#  4b. PyO3 Native DSP Module (pydaw_native) — NS1
# ═══════════════════════════════════════════════════════════

NATIVE_TOML="$SCRIPT_DIR/pydaw_native/Cargo.toml"
if [ -f "$NATIVE_TOML" ]; then
    if command -v maturin &>/dev/null; then
        echo "  🔧 Baue pydaw_native (PyO3 DSP-Modul)..."
        if (cd "$SCRIPT_DIR/pydaw_native" && maturin develop --release 2>&1 | tail -3); then
            echo "  🔧 pydaw_native: ✅ gebaut"
        else
            echo "  🔧 ⚠️  pydaw_native Build fehlgeschlagen (Python-Fallback aktiv)"
        fi
    else
        echo "  🔧 pydaw_native: maturin nicht installiert (pip install maturin)"
        echo "      Python-Fallback für Waveform/FFT/Metering aktiv"
    fi
fi

# ═══════════════════════════════════════════════════════════
#  5. Starten!
# ═══════════════════════════════════════════════════════════

echo ""
echo "════════════════════════════════════════"
echo "  🚀 Starte Py_DAW..."
if [ "$RUST_OK" = "1" ]; then
    echo "  🦀 Rust-Engine wird von der DAW automatisch gestartet"
fi
echo "════════════════════════════════════════"
echo ""

# v0.0.20.793: Engine wird NICHT mehr hier gestartet.
# Die Python-Bridge (RustEngineBridge) startet die Engine selbst als
# Subprocess. Das verhindert den Disconnect-Loop der entsteht wenn
# ZWEI Prozesse sich um denselben Socket streiten.
#
# Alt (kaputt):  start_daw.sh startet Engine → Python verbindet sich
#                → Socket-Konflik → Disconnect → Reconnect-Loop
#
# Neu (stabil):  start_daw.sh baut nur die Engine
#                Python startet + verbindet sich selbst → stabile Verbindung

# Stale socket aufräumen (falls vorhanden von vorherigem Absturz)
rm -f /tmp/pydaw_engine.sock

# v0.0.21.040: Remove stale engine binaries from venv/PATH to prevent
# the bridge from using an old IPC-only engine without cpal audio output.
for stale in "$VENV_DIR/bin/pydaw_engine" "$HOME/myenv/bin/pydaw_engine"; do
    if [ -f "$stale" ] && [ "$stale" != "$RUST_ENGINE" ]; then
        echo "  🧹 Entferne veraltete Engine: $stale"
        rm -f "$stale"
    fi
done

# DAW starten — v0.0.21.127: UI-Mode Support
NATIVE_UI="$SCRIPT_DIR/pydaw_native_ui/target/release/pydaw_native_ui"

case "$UI_MODE" in
    native)
        if [ -f "$NATIVE_UI" ]; then
            echo "  🦀 Starte Native Rust/Qt6 UI..."
            "$NATIVE_UI" &
            NATIVE_PID=$!
            wait $NATIVE_PID
            EXIT_CODE=$?
        else
            echo ""
            echo "  ❌ Native UI noch nicht gebaut!"
            echo "     Die native Rust/Qt6 UI ist in Entwicklung (Phase 2)."
            echo "     Starte stattdessen die Python-UI..."
            echo ""
            python3 main.py
            EXIT_CODE=$?
        fi
        ;;
    both)
        echo "  🔀 Starte BEIDE UIs (Debug-Modus)..."
        python3 main.py &
        PYTHON_PID=$!
        if [ -f "$NATIVE_UI" ]; then
            sleep 2  # Python-UI muss Engine zuerst starten
            "$NATIVE_UI" &
            NATIVE_PID=$!
            echo "  ✅ Python-UI (PID=$PYTHON_PID) + Native-UI (PID=$NATIVE_PID)"
            wait $PYTHON_PID
        else
            echo ""
            echo "  ⚠️  Native UI noch nicht verfügbar — nur Python-UI läuft."
            echo "     (Phase 2 Schritt 1 muss zuerst gebaut werden)"
            echo ""
            wait $PYTHON_PID
        fi
        EXIT_CODE=$?
        ;;
    *)
        python3 main.py
        EXIT_CODE=$?
        ;;
esac

# ═══════════════════════════════════════════════════════════
#  6. Aufräumen
# ═══════════════════════════════════════════════════════════

# Socket aufräumen falls übrig
rm -f /tmp/pydaw_engine.sock

echo "👋 Py_DAW beendet."
exit $EXIT_CODE
