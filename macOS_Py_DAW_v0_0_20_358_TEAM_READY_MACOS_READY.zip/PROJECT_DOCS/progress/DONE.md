## v0.0.20.358 — macOS Metal + CoreAudio Setup (safe) + Plugin-Doku

- **macOS-safe requirements**: `JACK-Client` ist **Linux-only**, `audioop-lts` nur für **Python ≥ 3.13**.
- **install.py macOS Homebrew (best-effort)** ergänzt: `portaudio`, `libsndfile`, `fluidsynth` (+ optional `lilv`, `suil`, `lv2`, `ladspa-sdk`, `mda-lv2`).
- **Metal Default** auf macOS: `PYDAW_GFX_BACKEND=auto` wählt jetzt `metal` (`pydaw/utils/gfx_backend.py`).
- **CoreAudio Default**: `AudioEngine.detect_best_backend()` bevorzugt auf macOS `sounddevice` (PortAudio/CoreAudio).
- **Track-Add API Safety**: `AltProjectService.add_track()` gibt jetzt den erzeugten Track zurück (kompatibel zu Callsites mit `.id`).
- Neue Doku: **docs/macOS_Audio_Plugins_Setup.md** (Pfade, brew, Umgebungsvariablen, Gatekeeper, Cache-Clear).

## v0.0.20.357 — Echter Group-Bus mit eigener Device-Chain (Bitwig-Style)

- **Echte Gruppenspur** mit `kind="group"` und eigener `audio_fx_chain` implementiert.
- **Group-Bus-Routing** im Audio-Callback: Kind-Audio wird summiert, durch Gruppen-FX verarbeitet, dann erst in den Master gemischt.
- **Pull-Sources** (Sampler/Drum/SF2) fließen ebenfalls durch den Group-Bus.
- **Group-Header-Klick** wählt den Group-Track aus → DevicePanel zeigt Gruppen-Chain.
- **Effects auf Gruppe** landen auf der Gruppen-FX-Chain, nicht auf der kick-Spur.
- Alte Projekte ohne Group-Tracks → kein Routing → Audio unverändert.
- 8 Dateien geändert: hybrid_engine, audio_engine, project_service (2×), arranger (2×), version, model.

## v0.0.20.356 — Kritischer Bugfix: Collapsed-Group Clip-Track-Zuordnung

- **Clip-Track-Korruption bei Drag in eingeklappter Gruppe** behoben: Clips wurden beim Drag auf `members[0]` umgehängt, sodass alle Instrumente gleichzeitig spielten.
- Neue Helper-Methode `_is_same_collapsed_group()` schützt alle drei Drag-Pfade (Single/Multi/Copy).
- **Track-Lookup Fallback** für collapsed Groups: Volume-Anzeige für Non-First-Members korrigiert.
- **Spur-Name-Prefix** in Clip-Labels bei eingeklappter Gruppe (🔹kick: ..., 🔹open hi: ...) für bessere Unterscheidbarkeit.
- Rein UI/Canvas-Fix, kein Eingriff in Audio-Engine, Routing oder Projektformat.

## v0.0.20.355 — Browser Scope-Badges + Distortion Automation Guard

- Browser/Add-Flow zeigt jetzt kleine **Scope-Badges** direkt neben den Add-Buttons in **Instruments**, **Effects**, **Favorites** und **Recents**.
- Die Badges nennen klar das aktuelle Ziel der normalen Browser-Aktion: **aktive Spur**, nicht die ganze Gruppe.
- Bei Gruppenspuren bleibt damit vor dem Add sichtbarer, dass **normales Add / Doppelklick / Drag&Drop** weiter nur auf die aktive Einzelspur wirkt.
- Die Scope-Badges aktualisieren sich sicher beim Spurwechsel über `DeviceBrowser.set_selected_track(...)`.
- Zusätzlich wurde ein sicherer Guard im **DistortionFxWidget** ergänzt, damit Automation-Callbacks nicht mehr auf bereits gelöschte Qt-Slider/Spinboxen zugreifen.

## v0.0.20.354 — DevicePanel Gruppen-/Spur-Zieltrennung klarer

- DevicePanel erhielt eine zusätzliche **Aktive Spur-Ziel**-Hinweisbox direkt oberhalb der sichtbaren Device-Kette.
- Die Box erklärt jetzt klar, dass die **sichtbare Device-Kette unten nur zur aktiven Spur** gehört.
- Für Gruppenspuren werden **NOTE→Gruppe** und **AUDIO→Gruppe** als getrennte Gruppen-Aktionen klar ausgewiesen.
- Die bisherige Gruppenleiste wurde sprachlich auf **Gruppen-Aktionen** geschärft und nennt ausdrücklich, dass hier noch **kein gemeinsamer Gruppenbus** existiert.
- Umsetzung blieb vollständig **UI-only** in `pydaw/ui/device_panel.py`.

## v0.0.20.353 — TrackList Drop-Markierung beim Maus-Reorder

- Linke Arranger-TrackList zeigt beim lokalen Maus-Reorder jetzt eine **sichtbare cyanfarbene Drop-Markierung** direkt an der Einfügeposition.
- Die Markierung folgt **oben/unten pro Zielzeile** und zeigt auch **Drop am Listenende** korrekt an.
- Die Lösung greift nur bei internem **TrackList-Reorder-MIME**; bestehender **Cross-Project-Track-Drag** bleibt unangetastet.
- Keine Änderung an Routing, Mixer, DSP, Playback oder Projekt-Audiodaten.

## v0.0.20.352 — Gruppenkopf-Mausdrag + Doppelklick-Umbenennen

- Gruppenköpfe lassen sich im linken Arranger jetzt **direkt per Maus-Drag als kompletter Block** verschieben.
- Das nutzt weiterhin den bestehenden sicheren Drag-Weg: **Cross-Project-Track-Drag bleibt erhalten**, lokal kommt nur derselbe Reorder-Mechanismus für Gruppenmitglieder zum Einsatz.
- **Doppelklick auf Track-Namen** öffnet jetzt direkt den sicheren Umbenennen-Dialog; **Doppelklick auf Gruppenkopf** öffnet den Gruppen-Umbenennen-Dialog.
- DevicePanel-Gruppenstreifen zeigt jetzt deutlicher an: **Track-FX = nur aktive Spur**, **N→G / A→G = ganze Gruppe**.

## v0.0.20.351 — Arranger Maus-Reorder in TrackList

- Spuren lassen sich im linken Arranger-Bereich jetzt **mit der Maus neu anordnen**.
- Mehrfachauswahl wird als **zusammenhängender Block** verschoben, statt Spur für Spur.
- Der bestehende **Cross-Project-Track-Drag** bleibt erhalten; lokales Reorder nutzt nur ein zusätzliches internes MIME und greift ausschließlich bei **same-widget Drops**.
- Umsetzung bleibt bewusst **UI-/Projektordnungs-safe**: kein Eingriff in Audio-Routing, Mixer, DSP oder Playback-Core.

## v0.0.20.350 — Arranger Gruppen-Alignment / Move Buttons

- ArrangerCanvas zeigt jetzt **ausgeklappte Gruppen mit Gruppenkopf + allen Mitgliedsspuren** synchron zur linken TrackList.
- Das behebt die sichtbare Fehlzuordnung, bei der in ausgeklappten Gruppen nicht alle Instrument-/Audio-/Busspuren korrekt erschienen.
- Direkt sichtbare **▲/▼-Buttons** in Track-/Gruppenzeilen ergänzt.
- **Gruppen als Block verschiebbar** gemacht.

## v0.0.20.349 — Gruppen-Fold-State + Arranger-Gruppen-Lane + Track-Reorder

- Arranger speichert jetzt den **Gruppen-Einklappstatus** direkt im Projekt (`arranger_collapsed_group_ids`), sodass Gruppen nach dem erneuten Laden in ihrem letzten Fold-Zustand wieder erscheinen.
- Eingeklappte Gruppen werden jetzt nicht nur links in der TrackList, sondern auch **rechts im Arranger-Canvas als eine gemeinsame Spur/Lane** dargestellt; die Clips der Gruppenmitglieder werden sicher auf diese Gruppen-Lane abgebildet.
- Arranger-Track-Menüs können Spuren jetzt **nach oben/unten verschieben**, ohne Master-Position oder Audio-Core anzufassen.
- Über Gruppenkopf- und Track-Menüs lassen sich neue **Instrument-/Audio-/Busspuren direkt in die bestehende Gruppe einfügen**, statt nur unterhalb der Gruppe am Listenende zu landen.
- Umsetzung bleibt bewusst **UI-/Projektmodell-safe**: kein Bus-Routing-Umbau, kein Mixer-Core-Redesign, keine DSP-Änderung.

## v0.0.20.348 — Master-FX hörbar + globales Projekt-Undo + reparierte Track-Menüs

- Master-Audio-FX werden jetzt im Summenpfad wirklich verarbeitet und sind hörbar, ohne Routing-/Bus-Core-Umbau.
- Globaler Projekt-Undo-Fallback ergänzt: modellweite Änderungen mit `project_updated` werden jetzt zusätzlich als sichere Snapshot-Undo-Schritte erfasst.
- Ctrl+Z / Ctrl+Shift+Z / Ctrl+Y als globale Application-Shortcuts verdrahtet, damit Undo/Redo auch bei Fokus in Unterwidgets greift.
- Track-Kontextmenüs im Arranger erweitert/repariert: **Umbenennen**, **Track löschen**, **Instrument-/Audio-/Bus-Spur hinzufügen**.
- Gruppenköpfe im Arranger sind jetzt wirklich **einklappbar** und bieten ein passendes Gruppenmenü.
- Track-Löschen aus dem Kontextmenü ist wieder funktionsfähig; Umbenennen läuft jetzt sicher per Dialog statt instabiler Inline-Editierung.

## v0.0.20.347 — Arranger Track-/Gruppen-Flow + Gruppen-Sektion im DevicePanel

- Arranger-Clipauswahl synchronisiert jetzt sicher die zugehörige Spur mit, sodass beim Klick auf einen MIDI-/Audio-Clip auch die Instrument-/Track-Zeile aktiv wird.
- Direktes Rechtsklick-Menü auf Track-Zeilen im Arranger ergänzt; Gruppierungsfunktionen sind jetzt dort auffindbar statt nur über Tastenkürzel oder den kleinen ▾-Button.
- Gruppierte Spuren werden im Arranger als sichtbare **Gruppen-Sektion** mit Gruppenkopf und eingerückten Mitgliedern dargestellt.
- DevicePanel zeigt für gruppierte Spuren jetzt eine lokale **Gruppen-Sektion** mit Mitgliederliste und sicheren Batch-Aktionen **N→G** / **A→G**, um NOTE-FX oder AUDIO-FX auf die komplette aktive Gruppe anzuwenden.
- Umsetzung bleibt bewusst **UI-/Projektmodell-first**: kein Eingriff in Playback-Core, Mixer-Engine, Transport oder Audio-Routing.

## v0.0.20.339 — AETERNA Knob-Mini-Meter / aktive Mod-Badges direkt an Synth-Knobs

- AETERNA zeigt jetzt kleine **Mini-Meter direkt an wichtigen Synth-Knobs** im lokalen Synth Panel (Filter, Voice, AEG, FEG, Layer, Noise, Timbre, Drive).
- Die Meter nennen kompakt **aktuellen Wert + kleine Balkenanzeige**; darunter erscheinen **aktive Mod-Badges pro Ziel-Knob** wie z. B. **A+20** oder **B−18**, falls Web A/B gerade wirklich auf diesen Knob zielen.
- Die bestehenden **Knob-Tooltips** wurden passend erweitert: neben Automation-Hinweis und gespeichertem Mod-Profil nennen sie jetzt auch **Mini-Meter** und **aktive Mod-Badges**.
- Reiner Widget-/State-Schritt in `aeterna_widget.py`; kein Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport, Playback-Core oder AETERNA-DSP.

## v0.0.20.338 — AETERNA Live ARP via bestehendem Note-FX-Arp

- AETERNA **Arp A** hat jetzt einen sicheren **Live-ARP-ON/OFF**-Weg: Das Widget pflegt lokal auf der aktuellen Spur ein eigenes **Track Note-FX Arp** (markiert als `aeterna_owner=arp_a`) und schaltet dieses per **ARP Live** an/aus.
- Damit bleibt der Eingriff **außerhalb des Playback-Cores** und nutzt die bereits vorhandene projektweite **Note-FX-Kette** statt eines riskanten neuen Echtzeit-Arp-Cores in AETERNA.
- Die AETERNA-Arp-Stepdaten wirken jetzt nicht mehr nur beim **ARP→MIDI**-Weg, sondern auch für den sicheren **Live-ARP**: **Transpose / Skip / Velocity / Gate / Shuffle / Note Type** werden im bestehenden `chrono.note_fx.arp` berücksichtigt.
- AETERNA zeigt den Zustand jetzt klarer als **ARP Live** vs. **ARP→MIDI**; zusätzlich wurden Card-/Hint-Schriften lokal leicht vergrößert, damit die Screens auf kleineren Höhen lesbarer bleiben.
- Weiterhin keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

## v0.0.20.328 — AETERNA Mod Rack / Flow + Collapsible UI

- AETERNA lokal um ein **MOD RACK / FLOW (LOCAL SAFE)** erweitert.
- Neue lokale **Drag-&-Drop-Quellen**: **LFO1**, **LFO2**, **MSEG**, **Chaos**, **ENV**, **VEL**.
- Drop auf stabile Ziele (**Morph, Tone, Gain, Release, Space, Motion, Cathedral, Drift, Chaos**) weist die Quelle sicher einem der realen Slots **Web A/B** zu.
- Zusätzliche lokale Slot-Helfer: **Drop-Slot Auto/A/B**, **Swap A/B**, **Clear A**, **Clear B**.
- Alle großen AETERNA-Bereiche sind jetzt **einklappbar** (Dreiecks-Header), damit das Instrument kompakter bleibt.
- Neue lokale **Signalfluss-Karte** erklärt den AETERNA-Aufbau kompakt.
- Kleine echte Engine-Erweiterung nur innerhalb AETERNA: **ENV**- und **VEL**-Modulationsquellen können jetzt in den beiden Web-Slots genutzt werden.
- Keine Änderungen an Arranger-Core, Playback-Core, Mixer-Engine, Transport oder anderen Instrumenten.

## v0.0.20.324 — AETERNA staged Init / sanfteres Laden

- AETERNA lädt jetzt lokal **sanfter und flüssiger**: beim Restore werden UI-Signale geblockt und Widget-Updates gebündelt, damit nicht dutzende Komfort-Callbacks gleichzeitig im GUI-Thread anlaufen.
- Komfort-/Lesbarkeitsbereiche (**Formel-Info, Web-/Snapshot-Karte, Composer-Zusammenfassung, Preset-Kurzliste, Phase-3a-Summary**) werden jetzt **gestaffelt per Deferred Refresh** aufgebaut, sodass das Grund-Widget früher sichtbar wird.
- Lokale Button-Neubindung für Preset-/Snapshot-Schnellaufrufe auf **gezieltes Rebind statt blindem disconnect()** umgestellt; das vermeidet überflüssige Qt-Hardening-Fehlermeldungen beim Refresh.
- Weiterhin nur **AETERNA-Widget**, kein Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.

## v0.0.20.321 — AETERNA Preset-/Snapshot-Schnellaufrufe lokal

- AETERNA zeigt jetzt kleine lokale **Preset-/Snapshot-Schnellaufrufe** direkt im Widget: gefüllte Snapshot-Slots werden als kompakte Recall-Buttons sichtbar, ergänzt um Preset-Schnellaufrufe aus der bestehenden Kurzliste.
- Die neue Schnellaufruf-Zeile leitet alles rein lokal aus bereits vorhandenen **Snapshot-Daten**, **Preset-Metadaten** und **Formel/Web-Kombitipps** ab; Tooltips nennen kompakt **Hörbild**, **Formel** und **Web-Startweg**.
- Keine neue Engine- oder State-Logik: reiner Widget-/Komfortschritt in AETERNA ohne Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.

---

## v0.0.20.320 — AETERNA Formel-/Web-Kombitipps direkt an Presets

- AETERNA zeigt jetzt lokale **Preset→Startweg**-Hinweise direkt im Widget: pro Preset wird ein kompakter Tipp für **Formel + Web-Vorlage/Intensität** sichtbar.
- Die **Preset-Kurzliste** nennt diese Startwege jetzt direkt in der Textzeile; Schnellpreset-Tooltips zeigen zusätzlich **Hörbild**, **Formelidee** und **Web-Startweg** zusammen an.
- Der kompakte **Preset-Fokus** des aktuell gewählten Presets enthält jetzt ebenfalls den lokalen **Startweg**.
- Rein lokale Ableitung aus bereits vorhandenen Preset-Metadaten, Formelideen und Web-Vorlagen; **kein** neuer Core-State und kein Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.

---

## v0.0.20.319 — AETERNA Preset-Kurzliste mit Direktmarkern

- AETERNA-Preset-Kurzliste zeigt jetzt lokale **Direktmarker** für **Kategorie** und **Charakter**.
- Die sichtbaren Kurzlisten-Einträge werden kompakter als Marker dargestellt, z. B. **Sakral • Hell** oder **Ambient • Weich**.
- Tooltips der Schnell-Presets zeigen zusätzlich den Direktmarker neben Hörbild und Presetnamen.
- Der Aktiv-Status der Kurzliste enthält jetzt ebenfalls den aktuellen **Kategorie/Charakter-Marker**.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.

---

## v0.0.20.318 — AETERNA Snapshot-Slots mit Farbbadges/Statusmarkern

- AETERNA lokal um kleine **Farbbadges/Statusmarker** direkt an den Snapshot-Slots **A/B/C** erweitert: **leer**, **gefüllt** und **aktiv** werden jetzt sofort sichtbar.
- Zusätzlicher kleiner **Hörbild-Marker** pro Slot (z. B. sakral, klar, getragen, belebt) wird rein lokal aus den bereits vorhandenen Snapshot-Daten abgeleitet.
- **Recall** ist für leere Slots lokal deaktiviert; Tooltips von **Store/Recall** zeigen jetzt kompakt den aktuellen Snapshot-Inhalt an.
- Reiner Widget-/Darstellungsschritt auf Basis vorhandener lokaler Snapshot-Daten; **kein** Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport, Playback-Core oder Projektstruktur.

## v0.0.20.317 — AETERNA Preset-Bibliothek kompakt nach Kategorie/Charakter

- AETERNA lokal um eine kompakte **Preset-Bibliotheksansicht** erweitert: sichtbare Zusammenfassung der lokalen Presets nach **Kategorie** und **Charakter** direkt im Widget.
- Neue **Fokuszeile** für das aktive Preset: zeigt **Kategorie / Charakter / Favorit / Tags / Hörbild** kompakt an.
- Die bestehende **Preset-Kurzliste** zeigt jetzt zusätzlich **Kategorie/Charakter** direkt in der Textzeile sowie im Tooltip der Schnellwahl-Buttons.
- Reiner Widget-/Darstellungsschritt auf Basis vorhandener lokaler Preset-Metadaten; **kein** Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport, Playback-Core oder Projektstruktur.

## v0.0.20.316 — AETERNA lokaler Automation-Schnellzugriff

- AETERNA lokal um einen **Automation-Schnellzugriff** erweitert: alle bereits stabil freigegebenen Ziele (**Morph, Tone, Gain, Release, Space, Motion, Cathedral, Drift, Chaos, LFO1 Rate, LFO2 Rate, MSEG Rate, Web A, Web B**) können jetzt direkt aus dem Widget in die passende Automation-Lane geöffnet werden.
- Bestehende AETERNA-Knobs zeigen lokal klarere **Automation-ready-Tooltips** mit einer kleinen musikalischen Einordnung (z. B. Sweeps, sakrale Weite, Schwebung, Web-Tiefe).
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport, Playback-Core oder Projektstruktur.

- 2026-03-07 v0.0.20.315: AETERNA Formel-/Preset-Vorschläge um lokale Hörhinweise ergänzt (z. B. sakral, klar, getragen, belebt, kristallin, dunkel) – nur im Widget.
- 2026-03-07 v0.0.20.314: AETERNA Snapshot-Karte kompakter und musikalischer lesbar gemacht (Preset, Stimmung, Formelhinweis, Web).
- 2026-03-07 v0.0.20.312: AETERNA Web-Vorlagen um „Basis wiederherstellen“ erweitert; aktive Web-Vorlage und Intensität werden lokal gespeichert/geladen.
## v0.0.20.311 — AETERNA Web-Vorlagen mit Intensitätsstufen

- AETERNA lokal um sichere **Intensitätsstufen** für Web-A/Web-B-Startvorlagen erweitert: **Sanft**, **Mittel**, **Präsent**.
- Intensität skaliert nur lokale **Amount-/Rate-Werte** der Web-Vorlagen und greift nicht in den DAW-Core ein.
- Die gewählte Intensität wird sauber im **Instrument-State** mitgespeichert und beim Projektladen wiederhergestellt.
- Web-Karte zeigt jetzt kompakt: **aktive Vorlage + Intensität + Web A/B**.
- Weiterhin nur **AETERNA-Widget**, kein Eingriff in Arranger, Audio Editor, Clip Launcher, Mixer, Transport oder Playback-Core.

## v0.0.20.309 — AETERNA Macro-A/B-Feinsteuerung lesbarer

- AETERNA lokal um eine kompakte **Macro-A/B-Karte** erweitert.
- Zeigt jetzt lesbar: **Quelle → Ziel → Amount** für **Web A** und **Web B**.
- Zusätzliche Kurz-Hinweise im Widget ordnen die aktuelle Modulationsidee ein, z. B. eher **Sweep**, **gezeichneter Verlauf**, **organische Bewegung** oder **spielabhängige Dynamik**.
- Fokus bleibt lokal auf sicheren Makro-Wege: **Source/Target/Amount** statt roher interner Zustände.
- Weiterhin nur **AETERNA-Widget**, kein Core-Eingriff.

## v0.0.20.308 — AETERNA Formel-/Preset-Verknüpfung sichtbar

- Lokale **Preset→Formel-Hinweiszeile** direkt im AETERNA-Formelbereich ergänzt.
- Zeigt jetzt, welche **Formelidee** zum aktuellen Preset passt (z. B. Sakral, Organisch, Drone, Chaos, Warm Start).
- Zusätzlicher Button **„… laden“**, um die vorgeschlagene Formelidee nur lokal ins Formelfeld zu übernehmen.
- Status unterscheidet: passende Idee bereit / im Feld / angewendet / eigene Formel.
- Weiterhin **nur AETERNA-Widget**, kein Core-Eingriff.

## v0.0.20.307 — AETERNA Preset-Kurzliste mit lokalem Filter

- AETERNA lokal um einen sicheren Filter für die Preset-Kurzliste erweitert: **Alle**, **Sakral**, **Kristall**, **Drone** und **Favoriten**.
- Die vier Schnellwahl-Buttons passen sich jetzt lokal dem gewählten Filter an.
- Hilft beim schnellen Finden von sakralen, gläsernen oder ruhigen Startpresets, ohne Eingriff in den DAW-Core.

## v0.0.20.306 — AETERNA Preset-Kurzliste lokal

- kompakte lokale Preset-Kurzliste direkt im AETERNA-Widget ergänzt
- Schnellwahl-Buttons für: Kristall Bach, Bach Glas, Kathedrale, Celesta Chapel
- lokale Statuszeile zeigt aktives Preset, Favorit und Tag-Vorschau
- nur AETERNA-Widget angepasst, keine Core-Änderungen

## v0.0.20.304
- AETERNA lokal um weitere kuratierte **Formel-Startbeispiele** erweitert: **Organisch** und **Drone**.
- Lokales **AETERNA-Voicing** in der Engine entschärft und verfeinert: weniger chipig/kratzig, mehr klarer, luftiger, orgeliger Grundcharakter.
- Bestehende sakrale/organartige Presets lokal nachgeschärft und neues Preset **Kristall Bach** ergänzt.
- Lokalen Bugfix ergänzt: `AeternaEngine.get_formula_status()` nachgezogen, damit die Formelstatus-Anzeige im Widget keinen AttributeError mehr wirft.
- Weiterhin nur **AETERNA** geändert; keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

## v0.0.20.303
- AETERNA lokal um eine **Formel-Infozeile** erweitert.
- Die Infozeile zeigt jetzt klar: **Beispiel im Feld**, **manuell geändert**, **angewendet** oder **noch nicht angewendet**.
- Der Status bleibt rein lokal im AETERNA-Widget und wird mit dem lokalen Instrument-State mitgespeichert.

## v0.0.20.302

- AETERNA lokal um eine klare **"Jetzt lokal freigegeben"-Karte** für stabile Automationsziele erweitert.
- Freigegeben und sichtbar gruppiert: **Direkt auf Knobs**, **Modulations-Rates** und **Depth/Amounts**.
- Die bereits vorhandene sichere Anbindung an das DAW-Automationssystem wird jetzt im Widget klar erklärt: **Rechtsklick auf einen AETERNA-Knob → Show Automation in Arranger**.
- Knob-Tooltips weisen lokal zusätzlich auf die Automationsnutzung hin.
- Keine Änderungen am globalen DAW-Core, Playback-Core, Arranger, Clip Launcher, Audio Editor, Mixer oder Transport.

---

## v0.0.20.301

- AETERNA lokal um eine kompakte **Automation-Zielkarte** erweitert.
- Spätere sichere Ziele jetzt lesbar gruppiert: **Klang**, **Raum/Bewegung**, **Modulation**, **Web**.
- Zusätzlicher Hinweis im Widget: später vorzugsweise **Knobs/Rates/Amounts** automatisieren, nicht flüchtige UI- oder rohe Phasen-Zustände.
- Keine Änderungen am globalen DAW-Core.

---

## v0.0.20.300 — AETERNA kompakte Badge-/Kurzansicht für Preset-Metadaten

- Lokale **Badge-/Kurzansicht** direkt im AETERNA-Widget ergänzt.
- Zeigt kompakt **Favorit**, **Kategorie**, **Charakter**, **Tags** und eine gekürzte **Notiz** an.
- Badge-Ansicht aktualisiert sich bei Änderungen der lokalen Preset-Metadaten sofort.
- Weiterhin nur **AETERNA** geändert, ohne Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.
---

## v0.0.20.299 — AETERNA lokale Preset-Metadaten mit Tags/Favorit

- Lokale **Preset-Metadaten** in AETERNA um **Tags** und **Favorit** erweitert.
- Tags werden lokal als kurze Liste normalisiert und dedupliziert.
- Favorit-Status läuft lokal in **AETERNA-State** und **Preset-Snapshot** mit.
- Phase-3a-Metadaten-Zeile zeigt jetzt zusätzlich **Favorit** und **Tags** lesbar an.
- State-Schema auf **Version 5**, Preset-Schema auf **Version 3** angehoben.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.
---

## v0.0.20.298 — AETERNA Formel-Startkarte / Onboarding-Hilfe

- Lokale **Formel-Startkarte** direkt im AETERNA-Formelbereich ergänzt.
- Vier sichere lokale **Startbeispiele** eingebaut: **Warm Start**, **Sakral**, **Chaos** und **Glitch**.
- Beispiele schreiben nur das **Formelfeld lokal vor**; der Klang ändert sich weiterhin erst nach **"Formel anwenden"**.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

---

## v0.0.20.297 — AETERNA Formel-Editor-Fix + lokale Preset-Metadaten

- Das AETERNA-Formelfeld ist jetzt wieder **praktisch beschreibbar**: statt einer knappen Ein-Zeile wird ein **mehrzeiliges lokales Edit-Feld** verwendet.
- Token-Einfügen per **Klick** und **Drag&Drop** funktioniert weiter im mehrzeiligen Formelbereich.
- Lokale **Preset-Metadaten** ergänzt: **Kategorie**, **Charakter** und **Notiz** direkt im AETERNA-Widget.
- Preset-Metadaten werden lokal in **AETERNA-State** und **Preset-Snapshot** mitgeführt.
- State-Schema auf **Version 4**, Preset-Schema auf **Version 2** angehoben.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

---

## v0.0.20.295 — AETERNA Formel-Aliase + sichtbare Formel-Mod-Slots

- Lokale sichere Formel-Aliase ergänzt: **$VEL**, **$NOTE**, **$T_REM**, **$T_REMAINING**, **$GLITCH**.
- Sichere lokale Formel-Funktionen ergänzt: **rand(t)** und **random()**.
- Formelbereich zeigt jetzt lesbar die **aktiven Formelquellen** und eine kurze **Alias-Ansicht**.
- UI-State-Schema auf **Version 4** angehoben.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

---


## v0.0.20.293 — AETERNA Phase 3a Preset A/B + lesbare Automation-Zielsektionen

- Lokale **Preset-A/B**-Aktionen ergänzt: **Store A**, **Store B**, **Recall A**, **Recall B**, **Compare A/B**.
- Phase-3a-Bereich zeigt lokale Automation-Ziele jetzt lesbarer in vier Gruppen: **Klang**, **Raum/Bewegung**, **Modulation**, **Web**.
- Preset-A/B-Zustände werden lokal im AETERNA-Instrumentzustand mitgespeichert.
- UI-State-Schema auf **Version 3** angehoben.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

---

## v0.0.20.294 — AETERNA Phase 3a Formel-Modulationshilfen

- Lokales **Formel-Insert-System** ergänzt: **LFO1**, **LFO2**, **MSEG**, **CHAOS**, **ENV** und **VEL** können per **Klick** oder **Drag&Drop** in die Formel eingefügt werden.
- Neue **Quick-Snippets** für typische Modulationsideen direkt im Formelbereich.
- Formel-Engine akzeptiert jetzt zusätzlich die lokalen Formelquellen **lfo1**, **lfo2**, **mseg** und **chaos_src**.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.


---

## v0.0.20.305 — AETERNA Klang-/Preset-Pack safe

- AETERNA lokal um vier neue kuratierte Startpresets erweitert: **Bach Glas**, **Celesta Chapel**, **Choral Crystal** und **Abendmanual**.
- Bestehende sakrale/kristalline Richtung weiter geschärft, weiterhin nur in **AETERNA**.
- Lokale Voicing-Mischung vorsichtig geglättet, damit spektrale/formelbasierte Klänge weniger chipig und klarer/kristalliner wirken.
- Preset-Metadaten für die neuen AETERNA-Presets ergänzt (Kategorie, Charakter, Notiz, Tags/Favorit lokal).
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

---

## v0.0.20.310 — AETERNA Web-A/Web-B-Startvorlagen

- Neue lokale **Web-Startvorlagen** direkt im Bereich **THE WEB (LOCAL SAFE)**: **Langsam**, **Lebendig**, **Organisch**, **Sakral**.
- Vorlagen setzen nur sichere lokale AETERNA-Werte für **mod1/mod2 source**, **target**, **amount** sowie **LFO/MSEG-Rates**.
- Neue kompakte **Web-Vorlagen-Karte** zeigt aktive Vorlage plus Kurzansicht von **Web A** und **Web B**.
- Manuelle Abweichungen werden lokal als **Eigen** erkannt.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.


## v0.0.20.313 — AETERNA lokale Snapshot-Karte

- Neue lokale Snapshot-Karte in AETERNA für **Klang / Formel / Web** mit drei Slots: **A / B / C**.
- Pro Slot gibt es **Store** und **Recall**, nur lokal im AETERNA-Widget.
- Snapshot speichert nur sichere AETERNA-Zustände: Preset, Formel, Web-Template/Intensität, Web A/B, wichtige Klang- und Rate-Knobs.
- Snapshot-Slots werden im **Instrument-State** mit dem Projekt gespeichert und beim Laden wiederhergestellt.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.

---

## v0.0.20.322 — AETERNA Snapshot-Last-Action-Hinweis

- Lokale Snapshot-Karte in AETERNA um eine kompakte **„Zuletzt: Store/Recall …“**-Hinweiszeile erweitert.
- Die Zeile zeigt direkt **Aktion**, **Slot**, **Preset**, **Hörbild**, **Formelhinweis** und **Web-Startweg/Intensität**.
- Hinweis bleibt rein lokal im AETERNA-Widget und wird mit dem lokalen Instrument-State im Projekt gespeichert und beim Laden wiederhergestellt.
- Zusätzlich wird die Hinweiszeile bei Snapshot-Store/Recall automatisch mit der bestehenden Snapshot-Karte synchronisiert.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.

## v0.0.20.323 — AETERNA Composer + Snapshot-Slot-Kurznamen

- Lokalen **AETERNA Composer (LOCAL SAFE)** direkt im Widget ergänzt.
- Neuer **Dreiecks-/Menü-Button** erzeugt MIDI-Clips direkt auf der aktuellen **AETERNA-Spur** oder überschreibt den aktiven Clip dieser Spur.
- Breiter lokaler **Weltstil-Katalog** mit freier Eingabe ergänzt; zwei Stile können gemischt werden (**Style A × Style B**).
- Mathematische/deterministische Seed-Logik via Hash/PRNG ergänzt; **Seed**, **Style-Mix**, **Bars**, **Grid**, **Swing**, **Dichte** und **Mix** bleiben lokal im AETERNA-State gespeichert.
- Neue Voice-Schalter nur für **Bass**, **Melodie**, **Lead**, **Pad** und **Arp**; ausdrücklich **keine Drums**.
- Umsetzung nutzt nur bestehende sichere Projekt-APIs für **MIDI-Clip-Erzeugung** und **MIDI-Noten-Schreiben**; kein Eingriff in Playback-Core, Arranger, Clip Launcher, Audio Editor, Mixer oder Transport.
- Lokale **Snapshot-Slot-Kurznamen** ergänzt und zusätzlich in Schnellaufrufen sichtbar gemacht.



## v0.0.20.325 — AETERNA sichtbare Ladezeit + feinere Composer-Profile

- Lokale **Ladeprofil-Anzeige** direkt im AETERNA-Widget ergänzt.
- Sichtbar gemacht werden **Build**, **Restore** und der letzte **staged UI refresh**; alles rein lokal als Widget-/Restore-Messung.
- AETERNA Composer lokal um **Phrasenprofile** erweitert: **Sehr getragen**, **Getragen**, **Ausgewogen**, **Belebt**, **Sehr belebt**.
- AETERNA Composer lokal um **Dichteprofile** erweitert: **Luftig**, **Offen**, **Mittel**, **Dicht**, **Schimmernd**.
- Die neuen Profile wirken nur lokal auf **Notendichte**, **Notenlängen** und **Arp-/Lead-/Pad-Verhalten** für **Bass / Melodie / Lead / Pad / Arp**.
- Neue Composer-Profile werden im lokalen **AETERNA-State** gespeichert und beim Projektladen wiederhergestellt.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder Playback-Core.


## v0.0.20.326 — Bounce in Place / Freeze Track (erste sichere Workflow-Stufe)

- Erste sichere **Bounce-in-Place**-Stufe ergänzt: Im Arranger-Kontextmenü können ausgewählte Clips jetzt auf **eine neue Audiospur** gebounced werden (**+FX**, **Dry**, optional **Quelle stummschalten**).
- Erste sichere **Freeze-Track**-Stufe ergänzt: Im Track-Kontextmenü können Spuren jetzt als **Audio-Proxy** auf eine neue Audiospur gebounced und die Quellspur(en) dabei **stumm/Instrument aus** geschaltet werden.
- Wenn eine Spur bereits zu einer **Track-Gruppe** gehört, ist zusätzlich ein erster **Gruppe einfrieren**-Eintrag im Track-Kontextmenü verfügbar.
- Für Freeze-Proxys gibt es einen ersten **Auftauen-/Reaktivieren**-Weg: **Freeze-Quellen wieder aktivieren** im Track-Kontextmenü der Proxy-Spur.
- Umsetzung bleibt projekt-/UI-seitig: neue Offline-Render-Helfer in `ProjectService`, neue Arranger-/Track-Kontextmenü-Einträge; **kein** Umbau von Arranger-Core, Playback-Core, Mixer oder Transport.
- AETERNA lokal zusätzlich um **breitere mathematische Formel-/Random-Familien** in Hilfe und Randomizer ergänzt (z. B. env/coherent/cloud/logistic/brown-artige Startideen), weiterhin nur im Widget.


## v0.0.20.327 — Bounce/Freeze-Dialoge + sichtbare Freeze-Marker + breitere AETERNA-Math-Familien

- Neue kleine **Bounce/Freeze-Dialoge** für Clip-Bounce, Track-Freeze/Bounce und Group-Freeze ergänzt.
- Dialoge erlauben jetzt lokal/gezielt: **Label**, **+FX/Dry** sowie optional **Quelle stummschalten/deaktivieren**.
- **TrackList** zeigt jetzt sichtbare **Freeze-Marker** für **Proxy-Spuren** und **Freeze-Quellspuren** inklusive Tooltip.
- Laufzeitfehler in der ersten Bounce-Stufe lokal behoben: sichere Label-Verwendung für neu erzeugte Audio-Clips bei Clip-/Track-Bounce.
- AETERNA lokal um weitere **Math-/Random-Familien** in Formelhilfen, Onboarding und Randomizer erweitert (z. B. harmonic lattice, pink bloom, lorenz breath, sample hold veil, tent lattice, modal drift).
- Keine Änderungen an Playback-Core, Mixer-Engine, Transport oder globaler Audio-Architektur.

## v0.0.20.329 — AETERNA Mod-Rack Amount/Polarität + Signalfluss-Karte

- AETERNA **Web A / Web B** lokal um echte **Polaritätsumschaltung (+ / −)** erweitert; bleibt vollständig auf das interne Instrument begrenzt.
- Mod-Rack-Karte zeigt pro Slot jetzt **Amount + Polarität + kleine Balkenanzeige**.
- Neue lokale **Signalfluss-Linienansicht** ergänzt, die aktive Wege wie **Quelle → Web A/B → Ziel** direkt sichtbar macht.
- Polarity bleibt im lokalen AETERNA-State gespeichert und wird beim Projektladen wiederhergestellt.
- Zusätzlich ein sicherer **Stufenplan** für die größere gewünschte AETERNA-Synth-Erweiterung dokumentiert: erst UI-/Stage-Plan, dann Filter, dann weitere Wunschfamilien wie Unison/Sub/Shape/Noise/Glide/Drive — ausdrücklich **nicht alles in einem riskanten Schritt**.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

## v0.0.20.330 — AETERNA Synth Panel Stage 1 (safe UI grouping)

- Neuer lokaler Bereich **AETERNA SYNTH PANEL (STAGE 1 SAFE)** direkt im Widget.
- Vorhandene stabile Parameter werden dort lesbarer gruppiert in **Core Voice**, **Space / Motion** und **Mod / Web**.
- Kleine Navigations-Buttons öffnen direkt die bereits vorhandenen Bereiche **ENGINE**, **MORPHOGENETIC CONTROLS**, **THE WEB** und **MOD RACK / FLOW**.
- Neue kompakte Statuskarten zeigen die aktuellen Werte der bereits vorhandenen stabilen AETERNA-Parameter inklusive **Web A / Web B**-Kurzansicht.
- Zusätzlich wurden bewusst deaktivierte **Preview-/Platzhalterfelder** für spätere sichere Ausbaustufen ergänzt (z. B. **Filter Type**, **Envelope**, **Layer**, **Unison/Sub/Noise**), damit die UI-Richtung klar ist ohne neue Audio-Engine-Risiken.
- Keine Änderungen an Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalem Playback-Core.

## v0.0.20.331 — AETERNA Filter Stage 2 (größerer sicherer Ausbau)

- Echter lokaler **AETERNA-Filterblock** ergänzt: **Cutoff**, **Resonance** und **Type** (**LP 12 / LP 24 / HP 12 / BP / Notch / Comb+**).
- Filter sitzt vollständig **innerhalb von AETERNA**; kein Eingriff in Arranger, Clip Launcher, Audio Editor, Mixer, Transport oder globalen Playback-Core.
- Neue echte Filter-Bedienung im **AETERNA SYNTH PANEL** statt nur Preview-Platzhalter.
- **Filter Cutoff** und **Filter Resonance** sind jetzt als stabile **Automation-Ziele** sichtbar und direkt über die vorhandenen Automation-Wege nutzbar.
- **Web A / Web B** können jetzt lokal auch auf **Filter Cutoff** und **Filter Resonance** zielen.
- Neue Filter-Zustände werden mit dem **AETERNA-State** gespeichert und beim Projektladen wiederhergestellt; Snapshot-/Randomize-Pfade wurden lokal mitgezogen.
- Signalfluss-/Synth-Panel-Hinweise wurden lokal erweitert, damit die größere Ausbau-Richtung sichtbarer wird.



## v0.0.20.332 — AETERNA Voice Family + AEG/FEG ADSR (größerer Familien-Block)

- Größeren lokalen **Voice-Block** in AETERNA ergänzt: **Pan**, **Glide**, **Stereo-Spread** und **Retrig**.
- **Pan / Glide / Stereo-Spread** sind als stabile **Automation-Ziele** und lokale **Mod-Rack-Ziele** innerhalb von AETERNA verfügbar; **Retrig** bleibt in dieser sicheren Stufe als lokaler Schalter umgesetzt.
- Größeren lokalen **Envelope-Block** ergänzt: **AEG ADSR** und **FEG ADSR** inklusive **FEG Amount**.
- AEG steuert jetzt lokal die Amplituden-Hüllkurve, FEG formt lokal den Filterverlauf (Cutoff/Resonance) – alles innerhalb von AETERNA ohne Eingriff in DAW-Core, Arranger, Mixer oder Transport.
- Neue Familien wurden im **AETERNA SYNTH PANEL** sichtbar gruppiert, inklusive Statuskarten, erklärender Hinweise und weiterhin einklappbarer Struktur.
- Save/Load, Snapshot und Randomize lokal mitgezogen; bestehende AETERNA-Zustände bleiben kompatibel durch konservative Defaults.
- Zusätzlich eine kleine lokale Runtime-Lücke in der aktuellen AETERNA-Engine geschlossen: fehlende interne **LFO-/MSEG-Helfer** ergänzt, damit der reine Engine-Pull-Pfad wieder lokal ausführbar ist.

## v0.0.20.333 — AETERNA Unison / Sub / Noise (größerer Familien-Block)

- Größeren lokalen **Layer-Block** in AETERNA ergänzt: **Unison / Sub / Noise**.
- Neue echte Klangparameter: **Unison Mix**, **Unison Detune**, **Sub Level**, **Noise Level**, **Noise Color**.
- Neue lokale Comboboxen: **Unison Voices** (**1 / 2 / 4 / 6**) und **Sub Oktave** (**-1 / -2**).
- Stabile kontinuierliche Ziele **Unison Mix / Unison Detune / Sub Level / Noise Level / Noise Color** sind jetzt im AETERNA-Kontext als Automation-/Mod-Rack-Ziele verfügbar.
- Umsetzung bleibt vollständig lokal in **AETERNA Engine + Widget**; kein Eingriff in Arranger, Mixer, Transport oder globalen Playback-Core.
- Save/Load, Snapshot und Randomize für die neue Familie lokal mitgezogen.
- Engine-Smoketest ohne GUI lief sauber für **note_on() / pull() / note_off()** mit aktivem Unison/Sub/Noise-Block.



## v0.0.20.334 — AETERNA Pitch/Shape/Pulse Width + Drive/Feedback (größerer Familien-Block)

- Größeren lokalen **Pitch/Timbre-Block** in AETERNA ergänzt: **Pitch**, **Shape** und **Pulse Width**.
- **Pitch** wirkt jetzt lokal als musikalische globale Tonhöhen-Verschiebung (zentriert um 50%), bleibt aber vollständig innerhalb von AETERNA.
- **Shape** morpht lokal die Wellenform zwischen eher **sine/triangle** und **saw/square**-artigen Verläufen.
- **Pulse Width** steuert lokal die Pulsbreite des Rechteckanteils und damit den Vokal-/Nasalcharakter.
- Größeren lokalen **Drive/Feedback-Block** ergänzt: **Drive** und **Feedback** mit echter Audio-Wirkung innerhalb von AETERNA.
- **Drive** erweitert lokal die Sättigung/Bissigkeit, **Feedback** fügt kontrollierte interne Rückkopplung hinzu — ohne den DAW-Core, Mixer oder Transport anzutasten.
- Neue kontinuierliche Ziele **Pitch / Shape / Pulse Width / Drive / Feedback** sind jetzt im AETERNA-Kontext als stabile **Automation-** und **Mod-Rack-Ziele** verfügbar.
- Familien wurden direkt im **AETERNA SYNTH PANEL** sichtbar ergänzt, inklusive neuer Statuskarten und erweitertem Automation-Schnellzugriff.
- Save/Load, Snapshot und Randomize lokal mitgezogen; bestehende AETERNA-Zustände bleiben kompatibel durch konservative Defaults.
- Engine-Smoketest ohne GUI lief sauber mit den neuen Familien (**note_on / pull / note_off**).

## v0.0.20.335 — AETERNA Visual Polish + sichtbare Familienkarten

- Größeren lokalen **AETERNA-Polish-Block** umgesetzt: deutlichere **Farbtrennung** zwischen Core, Filter, Voice, AEG, FEG, Layer, Timbre und Drive.
- Neue kleine **Familien-Legende** direkt im **AETERNA SYNTH PANEL**, damit die großen Familien schneller lesbar und farblich unterscheidbar sind.
- Neue kleine **grafische Signalfluss-Ansicht** im Bereich **MOD RACK / FLOW**: Audio-Pfad und Mod-Pfad werden jetzt als lokale Linien-/Kartenübersicht sichtbar dargestellt.
- Bestehende Zusammenfassungs-Karten (**Overview, Core, Space, Mod, Future, Filter, Voice, AEG, FEG, Unison/Sub, Noise/Color**) farblich getönt und klarer getrennt.
- Bisher im State/Update schon angelegte Familien **Pitch / Shape / Pulse Width** sowie **Drive / Feedback** jetzt auch als echte **sichtbare Karten mit Knobs** im **AETERNA SYNTH PANEL** ergänzt.
- Umsetzung bleibt vollständig lokal in **pydaw/plugins/aeterna/aeterna_widget.py**; kein Eingriff in Arranger, Playback-Core, Mixer, Transport oder andere Instrumente.


## v0.0.20.336 — AETERNA Layer-Toggles + Mod-Badges/Mini-Meter

- Irreführende Vorschau-Checkboxen im **AETERNA SYNTH PANEL** für **Unison / Sub / Noise** in echte lokale **Layer-Schnellschalter** umgebaut.
- Die drei Schalter greifen jetzt direkt auf die realen Layer-Level **Unison Mix / Sub Level / Noise Level** zu und schalten diese sicher an/aus, ohne Playback-Core oder andere Instrumente anzufassen.
- Letzter sinnvoller Layer-Wert wird lokal gemerkt, sodass ein erneutes Einschalten nicht hart bei 0 startet.
- **Familienkarten** im Synth-Panel zeigen jetzt zusätzlich kompakte **Mini-Meter** und **aktive Mod-Ziel-Badges** pro Familie (z. B. Web A/B auf Filter-, Voice-, Layer- oder Drive-Ziele).
- Umsetzung bleibt vollständig lokal in `pydaw/plugins/aeterna/aeterna_widget.py`.


## v0.0.20.337 — AETERNA Arp A + Per-Knob Mod-Menüs + Readability

- Lokalen **AETERNA Arp A (LOCAL SAFE)** ergänzt: als **sicherer Clip-Arpeggiator** für die aktuelle AETERNA-Spur, ohne Playback-Core-Umbau.
- Arp A bietet jetzt **Pattern** (u. a. up/down/chords/random/flow/blossom/low&up/hi&down), **Rate** (1/1 bis 1/64), **Straight/Dotted/Triplets** und **16 editierbare Steps**.
- Pro Step vorhanden: **Transpose**, **Skip**, **Velocity** und **Gate Length 0–400%**.
- Lokale **Shuffle**-Option für Arp A ergänzt, inklusive Anzahl der betroffenen Steps.
- Arp A kann direkt als **neuen MIDI-Clip** auf der aktuellen AETERNA-Spur schreiben oder den **aktiven Clip überschreiben**.
- Rechtsklick-Kontextmenü auf **allen AETERNA-Knobs** erweitert: **Show Automation in Arranger** plus **Add Modulator** direkt auf den angeklickten Ziel-Knob.
- Neue lokale **Per-Knob-Mod-Profile** eingeführt: jeder AETERNA-Knob kann seinen eigenen gespeicherten Modulator-Zustand behalten, statt einen gemeinsamen Platzhalterzustand zu teilen.
- Lesbarkeit in AETERNA lokal verbessert: **größere Karten-/Hint-Schriften**, **größere Controls** und **deutlichere Signalfluss-Karten**.
- Umsetzung bleibt vollständig lokal in `pydaw/plugins/aeterna/aeterna_widget.py`; kein Eingriff in Arranger, Mixer, Transport, Audio Editor oder globalen Playback-Core.


## v0.0.20.340 — AETERNA Layer-Visibility + Qt Selection Guard

- **Layer-/Noise-Familienkarten** in AETERNA zeigen jetzt **Unison Voices** und **Sub Oktave** klarer direkt in den Karten und im Preview-Hinweis.
- **AETERNA Live-ARP Refresh** wurde lokal koalesziert, damit Checkbox-Klicks nicht mehrere direkte verschachtelte Refresh-Wellen durch die UI jagen.
- **ARP-Live-Sync** besitzt jetzt einen lokalen **Reentrancy-Guard** und emittiert Projekt-Refresh nur noch bei echten State-Änderungen.
- **TrackList**, **Arranger-TrackList** und **Automation-Lanes** wurden um kleine **Refresh-/Signalguards** ergänzt, damit `QListWidget`-Selektionen während Refresh/Restore nicht rekursiv `setCurrentRow`/`setCurrentItem` auslösen.
- Umsetzung bleibt vollständig lokal in AETERNA/UI; kein Eingriff in Playback-Core, Mixer, Transport oder Arranger-Engine.
