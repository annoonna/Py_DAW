# LATEST — v0.0.20.358

Stand: **macOS-Setup (Metal + CoreAudio) wurde safe gehärtet**, ohne in Routing/DSP einzugreifen.

Umgesetzt:
- **Metal Default auf macOS**: `PYDAW_GFX_BACKEND=auto` → `metal` (Fallback bleibt `opengl`).
- **CoreAudio Default**: Backend-Auto-Detect bevorzugt auf macOS **sounddevice/PortAudio (CoreAudio)**.
- **requirements.txt macOS-safe**: `JACK-Client` ist Linux-only; `audioop-lts` nur für Python ≥ 3.13.
- **install.py macOS best-effort**: Homebrew-Deps für Audio + optional LV2/LADSPA Toolchain.
- **Track-Add API Safety**: AltProjectService.add_track() gibt Track zurück (Callsites mit `.id` sind safe).
- **Neue Doku**: `docs/macOS_Audio_Plugins_Setup.md` (Pfade, brew, Env, Gatekeeper).

Nächster sinnvoller Schritt (wenn du willst):
- **macOS Audio Settings Dialog**: HostAPI/Device-Auswahl noch klarer labeln (CoreAudio), rein UI.
- oder zurück zum Feature-Track: **Group-Fader im Mixer** (TODO v0.0.20.357).
