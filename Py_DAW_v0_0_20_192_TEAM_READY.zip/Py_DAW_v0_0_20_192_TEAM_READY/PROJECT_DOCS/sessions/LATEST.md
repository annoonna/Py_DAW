# Session: v0.0.20.192 — Fix: AI Composer UI Freeze + Scroll/Visibility

Siehe:
- `PROJECT_DOCS/sessions/SESSION_v0.0.20.192_AI_COMPOSER_UI_FREEZE_SCROLL_FIX.md`
