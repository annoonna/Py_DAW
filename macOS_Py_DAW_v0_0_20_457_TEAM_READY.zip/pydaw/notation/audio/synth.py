# ChronoScale – interner Software-Synth
# PipeWire Audio + ALSA MIDI (Linux), CoreAudio + CoreMIDI (macOS)

import os
import sys
import subprocess
import shutil
import time


def _find_default_sf2() -> str:
    """Find a GM SoundFont on the system (cross-platform).

    v0.0.20.457: searches macOS Homebrew paths + Linux standard paths.
    """
    candidates = []
    if sys.platform == "darwin":
        # macOS: Homebrew (Apple Silicon + Intel)
        candidates += [
            "/opt/homebrew/share/soundfonts/FluidR3_GM.sf2",
            "/opt/homebrew/share/soundfonts/default.sf2",
            "/usr/local/share/soundfonts/FluidR3_GM.sf2",
            "/usr/local/share/soundfonts/default.sf2",
            "/opt/homebrew/share/fluid-synth/sf2/FluidR3_GM.sf2",
            "/usr/local/share/fluid-synth/sf2/FluidR3_GM.sf2",
            os.path.expanduser("~/Library/Audio/Sounds/Banks/FluidR3_GM.sf2"),
        ]
    else:
        # Linux
        candidates += [
            "/usr/share/sounds/sf2/FluidR3_GM.sf2",
            "/usr/share/soundfonts/FluidR3_GM.sf2",
            "/usr/share/soundfonts/default.sf2",
            "/usr/local/share/soundfonts/FluidR3_GM.sf2",
        ]
    for p in candidates:
        if os.path.isfile(p):
            return p
    # Fallback: return first candidate (will fail gracefully in FluidSynth)
    return candidates[0] if candidates else "/usr/share/sounds/sf2/FluidR3_GM.sf2"


DEFAULT_SF2 = _find_default_sf2()


def _fluidsynth_audio_driver() -> str:
    """Return the best FluidSynth audio driver for the current platform."""
    if sys.platform == "darwin":
        return "coreaudio"
    return "pulseaudio"  # Linux (PipeWire compatible)


def _fluidsynth_midi_driver() -> str:
    """Return the best FluidSynth MIDI driver for the current platform."""
    if sys.platform == "darwin":
        return "coremidi"
    return "alsa_seq"  # Linux

class FluidSynthEngine:
    def __init__(self, soundfont=DEFAULT_SF2):
        self.soundfont = soundfont
        self.process = None

    def is_available(self):
        return shutil.which("fluidsynth") is not None

    def start(self):
        if not self.is_available():
            raise RuntimeError("FluidSynth ist nicht installiert")

        if self.process:
            return

        self.process = subprocess.Popen(
            [
                "fluidsynth",
                "-a", _fluidsynth_audio_driver(),   # v0.0.20.457: cross-platform
                "-m", _fluidsynth_midi_driver(),     # v0.0.20.457: cross-platform
                "-g", "1.0",
                self.soundfont
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        time.sleep(0.7)

    def stop(self):
        if self.process:
            self.process.terminate()
            self.process = None

SYNTH = FluidSynthEngine()
