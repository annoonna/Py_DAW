"""Version information for PyDAW."""
__version__ = "0.0.20.13"
