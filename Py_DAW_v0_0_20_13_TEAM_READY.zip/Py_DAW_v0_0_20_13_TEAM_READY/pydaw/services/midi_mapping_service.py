"""MIDI Mapping service (v0.0.15).

- Maintains a mapping list (persisted in Project.midi_mappings).
- Supports "MIDI Learn": next incoming CC assigns to a target (track_id, param).
- Applies mapped CC messages to track placeholders (volume/pan) and (optionally) writes automation.

This is intentionally modular and safe: it never blocks the GUI thread.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional, Dict, Any, List

from PyQt6.QtCore import QObject, pyqtSignal

from pydaw.services.project_service import ProjectService
from pydaw.services.transport_service import TransportService


@dataclass
class MappingTarget:
    track_id: str
    param: str  # "volume" | "pan"


class MidiMappingService(QObject):
    status = pyqtSignal(str)

    def __init__(
        self,
        project: ProjectService,
        transport: TransportService,
        status_cb: Callable[[str], None] | None = None,
    ):
        super().__init__()
        self.project = project
        self.transport = transport
        self._status = status_cb or (lambda _m: None)

        self._learn_target: Optional[MappingTarget] = None

    # --- mapping list (persisted)

    def mappings(self) -> List[Dict[str, Any]]:
        return list(self.project.ctx.project.midi_mappings or [])

    def add_mapping(self, channel: int, control: int, target: MappingTarget) -> None:
        m = {
            "type": "cc",
            "channel": int(channel),
            "control": int(control),
            "track_id": str(target.track_id),
            "param": str(target.param),
        }
        lst = self.project.ctx.project.midi_mappings or []
        # prevent duplicates
        lst = [x for x in lst if not (x.get("type")=="cc" and x.get("channel")==m["channel"] and x.get("control")==m["control"] and x.get("track_id")==m["track_id"] and x.get("param")==m["param"])]
        lst.append(m)
        self.project.ctx.project.midi_mappings = lst
        self.project.project_updated.emit()
        self._status(f"MIDI Mapping hinzugefügt: CC{control} -> {target.param}")

    def remove_mapping(self, idx: int) -> None:
        lst = self.project.ctx.project.midi_mappings or []
        if 0 <= idx < len(lst):
            removed = lst.pop(idx)
            self.project.ctx.project.midi_mappings = lst
            self.project.project_updated.emit()
            self._status(f"MIDI Mapping entfernt: {removed}")

    # --- learn

    def start_learn(self, target: MappingTarget) -> None:
        self._learn_target = target
        self._status(f"MIDI Learn aktiv: bewege einen Controller für {target.param}")

    def cancel_learn(self) -> None:
        self._learn_target = None
        self._status("MIDI Learn beendet.")

    def is_learning(self) -> bool:
        return self._learn_target is not None

    # --- apply incoming message

    def handle_mido_message(self, msg) -> None:  # noqa: ANN001
        # Only supports CC for now
        try:
            mtype = getattr(msg, "type", "")
        except Exception:
            return
        if mtype != "control_change":
            return

        ch = int(getattr(msg, "channel", 0))
        cc = int(getattr(msg, "control", 0))
        val = int(getattr(msg, "value", 0))

        # learn mode
        if self._learn_target is not None:
            tgt = self._learn_target
            self._learn_target = None
            self.add_mapping(ch, cc, tgt)
            return

        # apply mappings
        mapped = False
        for m in (self.project.ctx.project.midi_mappings or []):
            if m.get("type") != "cc":
                continue
            if int(m.get("channel", -1)) != ch:
                continue
            if int(m.get("control", -1)) != cc:
                continue
            track_id = str(m.get("track_id", ""))
            param = str(m.get("param", ""))
            if not track_id or param not in ("volume", "pan"):
                continue

            # normalize value
            if param == "volume":
                f = max(0.0, min(1.0, val / 127.0))
            else:  # pan
                f = max(-1.0, min(1.0, (val / 63.5) - 1.0))

            # set track placeholder value
            trk = next((t for t in self.project.ctx.project.tracks if t.id == track_id), None)
            if not trk:
                continue

            setattr(trk, param, float(f))
            mapped = True

            # write automation if track mode is write
            if getattr(trk, "automation_mode", "off") == "write":
                self._write_automation_point(track_id, param, float(f))

        if mapped:
            self.project.project_updated.emit()

    def _write_automation_point(self, track_id: str, param: str, value: float) -> None:
        beat = float(getattr(self.transport, "current_beat", 0.0))
        lanes = self.project.ctx.project.automation_lanes or {}
        tlanes = lanes.get(track_id, {})
        points = list(tlanes.get(param, []))
        points.append({"beat": beat, "value": float(value)})
        # keep ordered and lightly dedupe
        points.sort(key=lambda p: float(p.get("beat", 0.0)))
        # cap size
        if len(points) > 2000:
            points = points[-2000:]
        tlanes[param] = points
        lanes[track_id] = tlanes
        self.project.ctx.project.automation_lanes = lanes
        self._status(f"Automation Write: {param} @ beat {beat:.2f} = {value:.2f}")
