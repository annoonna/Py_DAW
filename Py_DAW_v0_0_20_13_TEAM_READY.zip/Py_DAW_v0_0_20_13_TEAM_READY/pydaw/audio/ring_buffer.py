"""Lock-Free Ring Buffer for DAW-grade Audio↔GUI Communication (v0.0.20.13).

Design:
- Uses numpy arrays backed by contiguous memory (mmap-friendly)
- Single-producer / single-consumer (SPSC) — NO LOCKS EVER
- Audio thread writes, GUI thread reads (or vice versa)
- Atomic index updates via Python GIL (int read/write is atomic under CPython)
- Zero allocations after init
- Supports both float32 parameter rings and stereo audio rings

Architecture:
    ┌─────────────┐     Ring Buffer      ┌──────────────┐
    │  GUI Thread  │ ──── params ──────▶ │ Audio Thread  │
    │  (PyQt6)     │ ◀── metering ────── │ (sounddevice) │
    └─────────────┘                      └──────────────┘

Usage:
    # Parameter ring (GUI → Audio)
    ring = ParamRingBuffer(capacity=64)
    ring.push(param_id=0, value=0.75)     # GUI thread
    for pid, val in ring.drain():          # Audio thread
        apply_param(pid, val)

    # Audio ring (Audio → GUI, for metering/waveform display)
    audio_ring = AudioRingBuffer(capacity=8192, channels=2)
    audio_ring.write(block)               # Audio thread
    data = audio_ring.read_available()     # GUI thread (VU meter)
"""
from __future__ import annotations

from typing import List, Tuple, Optional, Iterator
import struct

try:
    import numpy as np
except Exception:
    np = None


# ---------------------------------------------------------------------------
# SPSC Parameter Ring (GUI → Audio)
# ---------------------------------------------------------------------------

class ParamRingBuffer:
    """Lock-free SPSC ring for parameter updates.

    Each entry: (param_id: uint16, value: float32) = 6 bytes
    Uses power-of-2 capacity for fast modulo via bitmask.

    Thread safety:
    - push() from GUI thread only
    - drain() from audio thread only
    - No locks, no CAS — relies on CPython GIL atomicity of int assignment
    """

    __slots__ = ("_capacity", "_mask", "_buf_id", "_buf_val",
                 "_write_pos", "_read_pos")

    def __init__(self, capacity: int = 256):
        # Round up to power of 2
        cap = 1
        while cap < max(16, int(capacity)):
            cap <<= 1
        self._capacity = cap
        self._mask = cap - 1

        if np is not None:
            self._buf_id = np.zeros(cap, dtype=np.uint16)
            self._buf_val = np.zeros(cap, dtype=np.float32)
        else:
            self._buf_id = [0] * cap
            self._buf_val = [0.0] * cap

        # Atomic indices (int read/write is atomic under CPython GIL)
        self._write_pos: int = 0
        self._read_pos: int = 0

    def push(self, param_id: int, value: float) -> bool:
        """Push a parameter update (GUI thread). Returns False if full."""
        w = self._write_pos
        r = self._read_pos
        if ((w + 1) & self._mask) == (r & self._mask):
            return False  # Full — drop oldest or caller retries
        idx = w & self._mask
        self._buf_id[idx] = int(param_id) & 0xFFFF
        self._buf_val[idx] = float(value)
        # CRITICAL: write data BEFORE advancing write_pos
        # Python GIL ensures this ordering for simple int assignment
        self._write_pos = w + 1
        return True

    def drain(self) -> Iterator[Tuple[int, float]]:
        """Drain all pending updates (audio thread). Yields (param_id, value)."""
        r = self._read_pos
        w = self._write_pos
        while r != w:
            idx = r & self._mask
            pid = int(self._buf_id[idx])
            val = float(self._buf_val[idx])
            r += 1
            yield pid, val
        # Batch-update read position (single atomic write)
        self._read_pos = r

    def available(self) -> int:
        """Number of pending items."""
        return self._write_pos - self._read_pos

    def clear(self) -> None:
        """Reset ring (call when both threads are idle)."""
        self._read_pos = self._write_pos


# ---------------------------------------------------------------------------
# SPSC Audio Ring (Audio → GUI, for metering / waveform preview)
# ---------------------------------------------------------------------------

class AudioRingBuffer:
    """Lock-free SPSC ring buffer for audio sample data.

    Audio thread writes blocks, GUI thread reads for VU metering
    or waveform display. If GUI falls behind, oldest data is silently
    overwritten (acceptable for metering).

    Memory layout: contiguous float32 array [capacity × channels]
    """

    __slots__ = ("_capacity", "_mask", "_channels", "_buf",
                 "_write_pos", "_read_pos")

    def __init__(self, capacity: int = 8192, channels: int = 2):
        cap = 1
        while cap < max(256, int(capacity)):
            cap <<= 1
        self._capacity = cap
        self._mask = cap - 1
        self._channels = int(channels)

        if np is not None:
            self._buf = np.zeros((cap, self._channels), dtype=np.float32)
        else:
            self._buf = [[0.0] * self._channels for _ in range(cap)]

        self._write_pos: int = 0
        self._read_pos: int = 0

    def write(self, block) -> int:
        """Write an audio block (audio thread). Returns frames written.

        If the ring is full, oldest data is overwritten (suitable for metering).
        """
        if np is None or block is None:
            return 0
        try:
            b = np.asarray(block, dtype=np.float32)
            if b.ndim == 1:
                b = b.reshape(-1, 1)
            frames = b.shape[0]
            ch = min(b.shape[1], self._channels)

            w = self._write_pos
            for i in range(frames):
                idx = (w + i) & self._mask
                self._buf[idx, :ch] = b[i, :ch]

            self._write_pos = w + frames
            return frames
        except Exception:
            return 0

    def read_available(self, max_frames: int = 0) -> Optional["np.ndarray"]:
        """Read available audio data (GUI thread). Non-blocking.

        Returns numpy array (frames, channels) or None if empty.
        """
        if np is None:
            return None
        r = self._read_pos
        w = self._write_pos
        avail = w - r
        if avail <= 0:
            return None

        if max_frames > 0:
            avail = min(avail, max_frames)

        # Cap to one full ring traversal
        if avail > self._capacity:
            # GUI fell behind — skip to most recent data
            r = w - self._capacity
            avail = self._capacity

        out = np.empty((avail, self._channels), dtype=np.float32)
        for i in range(avail):
            idx = (r + i) & self._mask
            out[i] = self._buf[idx]

        self._read_pos = r + avail
        return out

    def read_peak(self, frames: int = 0) -> Tuple[float, float]:
        """Read peak levels from recent audio (GUI thread).

        Returns (peak_left, peak_right) for VU metering.
        More efficient than read_available() for simple metering.
        """
        if np is None:
            return (0.0, 0.0)
        r = self._read_pos
        w = self._write_pos
        avail = w - r
        if avail <= 0:
            return (0.0, 0.0)

        n = min(avail, max(frames, 256), self._capacity)
        start = w - n

        peak_l = 0.0
        peak_r = 0.0
        for i in range(n):
            idx = (start + i) & self._mask
            v = self._buf[idx]
            al = abs(float(v[0]))
            if al > peak_l:
                peak_l = al
            if self._channels >= 2:
                ar = abs(float(v[1]))
                if ar > peak_r:
                    peak_r = ar

        self._read_pos = w
        return (peak_l, peak_r)

    def clear(self) -> None:
        self._read_pos = self._write_pos


# ---------------------------------------------------------------------------
# Convenience: Track Meter Ring (one per mixer strip)
# ---------------------------------------------------------------------------

class TrackMeterRing:
    """Lightweight per-track metering ring.

    Audio callback writes peak values per block, GUI reads for VU display.
    Uses a simple atomic float pair (no ring needed for peak metering).
    """

    __slots__ = ("peak_l", "peak_r", "_decay")

    def __init__(self, decay: float = 0.92):
        self.peak_l: float = 0.0
        self.peak_r: float = 0.0
        self._decay = float(decay)

    def update_from_block(self, block, gain_l: float = 1.0,
                          gain_r: float = 1.0) -> None:
        """Update peaks from an audio block (audio thread)."""
        if np is None or block is None:
            return
        try:
            b = np.asarray(block, dtype=np.float32)
            if b.ndim == 1:
                b = b.reshape(-1, 1)
            if b.shape[0] == 0:
                return
            pl = float(np.max(np.abs(b[:, 0]))) * abs(gain_l)
            pr = float(np.max(np.abs(b[:, min(1, b.shape[1] - 1)]))) * abs(gain_r)
            # Atomic float writes (CPython GIL)
            self.peak_l = max(self.peak_l * self._decay, pl)
            self.peak_r = max(self.peak_r * self._decay, pr)
        except Exception:
            pass

    def read_and_decay(self) -> Tuple[float, float]:
        """Read current peaks and apply decay (GUI thread)."""
        l, r = self.peak_l, self.peak_r
        self.peak_l *= self._decay
        self.peak_r *= self._decay
        return (l, r)
