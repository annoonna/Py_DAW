use std::sync::Arc;

use crossbeam_channel::{Receiver, Sender};
use log::{error, info, trace, warn};
use parking_lot::Mutex;

use crate::audio_graph::AudioGraph;
use crate::audio_output::{AudioOutput, AudioOutputConfig};
use crate::clip_renderer::{ArrangementRenderer, ArrangementSnapshot, AudioClipData, ClipStore, PlacedClip};
use crate::ipc::{Command, Event, TrackMeterLevel};
use crate::lock_free::ParamRing;
use crate::transport::Transport;

/// v0.0.21.031: Load any audio format (WAV/FLAC/MP3/OGG/AAC/AIFF) as SampleData.
/// Uses symphonia for universal format support, falls back to hound for WAV.
fn load_sample_any(path: &str, target_sr: u32) -> Result<crate::sample::SampleData, String> {
    // Try symphonia first (supports all formats)
    match crate::audio_decode::decode_audio(path, Some(target_sr)) {
        Ok(decoded) => {
            let name = std::path::Path::new(path)
                .file_stem()
                .and_then(|s| s.to_str())
                .unwrap_or("sample")
                .to_string();
            // v0.0.21.043: Convert mono to interleaved stereo.
            // drum_machine.rs assumes data[idx*2] / data[idx*2+1] (stereo).
            // Without this, mono samples cause index-out-of-bounds panic
            // on the cpal audio thread, killing all audio output.
            let (samples, channels) = if decoded.channels == 1 {
                let mut stereo = Vec::with_capacity(decoded.samples.len() * 2);
                for &s in &decoded.samples {
                    stereo.push(s);
                    stereo.push(s);
                }
                (stereo, 2u16)
            } else {
                (decoded.samples, decoded.channels)
            };
            Ok(crate::sample::SampleData::from_raw(
                samples,
                channels,
                decoded.sample_rate,
                name,
            ))
        }
        Err(_) => {
            // Fallback to hound for WAV
            crate::sample::SampleData::load_wav(path)
        }
    }
}

// ============================================================================
// Engine — The core audio engine coordinator
// ============================================================================
//
// Ownership model:
//   - Engine owns AudioGraph + Transport + ClipStore + ArrangementRenderer
//   - Audio callback borrows via Arc (lock-free reads)
//   - IPC handler sends Commands via crossbeam channel
//   - ParamRing: GUI writes, Audio thread drains (lock-free SPSC)
//
// Thread model:
//   - Main thread: IPC server
//   - Audio thread: cpal callback → drain params → render clips → process graph → output
//   - GUI thread: Python (separate process, connected via IPC)
// ============================================================================

/// Shared engine state, accessible from both IPC handler and audio callback.
pub struct EngineState {
    pub graph: Arc<Mutex<AudioGraph>>,
    pub transport: Arc<Transport>,
    pub command_rx: Receiver<Command>,
    pub event_tx: Sender<Event>,
    pub running: std::sync::atomic::AtomicBool,

    /// Lock-free parameter ring (GUI → Audio thread).
    pub param_ring: Arc<ParamRing>,

    /// Audio clip data store (RwLock-protected, shared with renderer).
    pub clip_store: Arc<ClipStore>,

    /// Arrangement renderer (reads clips, writes into track buffers).
    pub renderer: ArrangementRenderer,

    /// v0.0.20.725: Beat-accurate MIDI clip scheduler.
    /// Dispatches NoteOn/NoteOff from arrangement MIDI clips to instruments.
    pub midi_scheduler: Arc<Mutex<crate::midi_scheduler::MidiScheduler>>,

    /// Meter update counter — only send meter events every N process cycles (~30Hz).
    meter_counter: std::sync::atomic::AtomicU32,
    /// XRun counter.
    xrun_count: std::sync::atomic::AtomicU32,
    /// Last process_audio render time in microseconds (for Pong cpu_load).
    last_render_us: std::sync::atomic::AtomicU32,
    /// Buffer budget in microseconds (sample_rate / buffer_size based).
    budget_us: std::sync::atomic::AtomicU32,

    /// v0.0.20.959: Rust audio output (cpal).
    pub audio_output: Mutex<AudioOutput>,
    /// v0.0.20.959: Test sine flag (for AudioTestSine command).
    pub test_sine: Arc<std::sync::atomic::AtomicBool>,
    /// v0.0.20.980: Python→Rust audio ring buffer for streaming mode.
    pub py_audio_ring: Arc<crate::audio_bridge::PythonToRustRing>,
    /// v0.0.20.982: Shared memory audio reader (zero-copy, replaces IPC for audio data).
    pub shm_reader: Arc<parking_lot::Mutex<crate::shm_audio::ShmAudioReader>>,
    /// v0.0.21.058: LADSPA plugin host manager.
    pub ladspa_host: parking_lot::Mutex<crate::ladspa_host::LadspaHostManager>,
    /// PH-5.2 v0.0.21.091: Persistent plugin blacklist (crash tracking).
    pub plugin_blacklist: parking_lot::Mutex<crate::plugin_host::PluginBlacklist>,
}

impl EngineState {
    pub fn new(
        sample_rate: u32,
        buffer_size: u32,
        bpm: f64,
        command_rx: Receiver<Command>,
        event_tx: Sender<Event>,
    ) -> Self {
        let clip_store = Arc::new(ClipStore::new());
        let renderer = ArrangementRenderer::new(Arc::clone(&clip_store));
        Self {
            graph: Arc::new(Mutex::new(AudioGraph::new(buffer_size as usize, sample_rate))),
            transport: Arc::new(Transport::new(sample_rate, bpm)),
            command_rx,
            event_tx,
            running: std::sync::atomic::AtomicBool::new(true),
            param_ring: Arc::new(ParamRing::new()),
            clip_store,
            renderer,
            midi_scheduler: Arc::new(Mutex::new(crate::midi_scheduler::MidiScheduler::new())),
            meter_counter: std::sync::atomic::AtomicU32::new(0),
            xrun_count: std::sync::atomic::AtomicU32::new(0),
            last_render_us: std::sync::atomic::AtomicU32::new(0),
            budget_us: std::sync::atomic::AtomicU32::new(
                ((buffer_size as f64 / sample_rate as f64) * 1_000_000.0) as u32
            ),
            audio_output: Mutex::new(AudioOutput::new()),
            test_sine: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            py_audio_ring: Arc::new(crate::audio_bridge::PythonToRustRing::new(sample_rate, 2, 500)),
            shm_reader: Arc::new(parking_lot::Mutex::new(crate::shm_audio::ShmAudioReader::new())),
            ladspa_host: parking_lot::Mutex::new(crate::ladspa_host::LadspaHostManager::new()),
            plugin_blacklist: parking_lot::Mutex::new(crate::plugin_host::PluginBlacklist::new()),
        }
    }

    /// Process all pending commands from the IPC queue.
    /// Called at the start of each audio callback — MUST be fast.
    pub fn drain_commands(&self) {
        // Drain up to 64 commands per callback to prevent starvation
        for _ in 0..64 {
            match self.command_rx.try_recv() {
                Ok(cmd) => self.handle_command(cmd),
                Err(_) => break,
            }
        }
    }

    /// Handle a single command.
    fn handle_command(&self, cmd: Command) {
        match cmd {
            Command::Play => {
                let beat = self.transport.position_beats();
                let loop_on = self.transport.loop_enabled.load(std::sync::atomic::Ordering::Relaxed);
                info!("Play: starting playback at beat {:.2}, loop={}, bpm={:.1}", beat, loop_on, self.transport.bpm());
                self.transport.playing.store(true, std::sync::atomic::Ordering::Release);
                let _ = self.event_tx.try_send(Event::TransportState {
                    is_playing: true,
                    beat: self.transport.position_beats(),
                });
            }
            Command::Stop => {
                info!("Stop: stopping playback, resetting to beat 0");
                self.transport.playing.store(false, std::sync::atomic::Ordering::Release);
                self.transport.seek_to_sample(0);
                // v0.0.20.725: Reset MIDI scheduler + send AllNotesOff to prevent stuck notes
                self.midi_scheduler.lock().reset();
                {
                    let mut graph = self.graph.lock();
                    let indices = graph.track_indices();
                    for idx in indices {
                        if let Some(track) = graph.get_track_mut(idx) {
                            if let Some(ref mut inst) = track.instrument {
                                inst.push_midi(crate::instruments::MidiEvent::AllNotesOff);
                            }
                        }
                    }
                }
                let _ = self.event_tx.try_send(Event::TransportState {
                    is_playing: false,
                    beat: 0.0,
                });
            }
            Command::Pause => {
                self.transport.playing.store(false, std::sync::atomic::Ordering::Release);
                let _ = self.event_tx.try_send(Event::TransportState {
                    is_playing: false,
                    beat: self.transport.position_beats(),
                });
            }
            Command::Seek { beat } => {
                self.transport.seek_to_beat(beat);
                // v0.0.20.725: Reset scheduler scan position + kill lingering notes
                self.midi_scheduler.lock().reset();
                {
                    let mut graph = self.graph.lock();
                    let indices = graph.track_indices();
                    for idx in indices {
                        if let Some(track) = graph.get_track_mut(idx) {
                            if let Some(ref mut inst) = track.instrument {
                                inst.push_midi(crate::instruments::MidiEvent::AllNotesOff);
                            }
                        }
                    }
                }
            }
            Command::SetTempo { bpm } => {
                self.transport.set_bpm(bpm);
            }
            Command::SetTimeSignature {
                numerator,
                denominator,
            } => {
                self.transport.set_time_signature(numerator, denominator);
            }
            Command::SetLoop {
                enabled,
                start_beat,
                end_beat,
            } => {
                info!("SetLoop: enabled={}, start={:.2}, end={:.2}", enabled, start_beat, end_beat);
                self.transport.set_loop(enabled, start_beat, end_beat);
                // v0.0.20.736: keep MidiScheduler in sync so it knows the loop region
                // for correct dual-range scheduling at the wrap boundary.
                self.midi_scheduler.lock().set_loop(enabled, start_beat, end_beat);
            }
            Command::AddTrack {
                track_id,
                track_index,
                kind,
            } => {
                let tk = crate::audio_graph::TrackKind::from_str(&kind);
                let mut graph = self.graph.lock();
                graph.add_track(track_id, track_index, tk);
            }
            Command::RemoveTrack { track_id } => {
                let mut graph = self.graph.lock();
                graph.remove_track(&track_id);
            }
            Command::SetTrackParam {
                track_index,
                param,
                value,
            } => {
                let graph = self.graph.lock();
                if let Some(track) = graph.get_track(track_index) {
                    track.set_param(param, value);
                }
            }
            Command::SetMasterParam { param, value } => {
                let graph = self.graph.lock();
                if let Some(master_idx) = graph.master_index() {
                    if let Some(track) = graph.get_track(master_idx) {
                        track.set_param(param, value);
                    }
                }
            }
            Command::SetGroupRouting {
                child_track_index,
                group_track_index,
            } => {
                let mut graph = self.graph.lock();
                graph.set_group_routing(child_track_index, group_track_index);
            }
            Command::Configure {
                sample_rate,
                buffer_size,
                device,
            } => {
                info!(
                    "Configure: sr={}, buf={}, dev='{}'",
                    sample_rate, buffer_size, device
                );
                self.transport.set_sample_rate(sample_rate);
                let mut graph = self.graph.lock();
                graph.sample_rate = sample_rate;
                graph.resize_buffers(buffer_size as usize);
                drop(graph); // Release lock before starting audio

                // v0.0.20.959: Auto-start cpal audio output on Configure
                // This makes Rust audio available immediately when the DAW starts.
                if !self.audio_output.lock().is_running() {
                    info!("Auto-starting cpal audio output...");
                    let config = AudioOutputConfig {
                        sample_rate,
                        buffer_size,
                        device_name: device.clone(),
                        channels: 2,
                    };
                    let test_sine = Arc::clone(&self.test_sine);
                    let py_ring = Arc::clone(&self.py_audio_ring);
                    let shm = Arc::clone(&self.shm_reader);
                    let channels: u16 = 2;
                    let sr_f = sample_rate as f64;
                    let mut sine_phase: f64 = 0.0;

                    // v0.0.21.034: Graph rendering + transport advance
                    let graph_arc = Arc::clone(&self.graph);
                    let transport_arc = Arc::clone(&self.transport);
                    let midi_sched_arc = Arc::clone(&self.midi_scheduler);
                    let renderer_arc = self.renderer.clone();
                    let event_tx_clone = self.event_tx.clone();
                    let meter_divisor: u32 = (sample_rate / buffer_size).max(1);
                    let mut meter_tick: u32 = 0;

                    let mut debug_counter: u32 = 0;
                    let debug_interval: u32 = (sample_rate / buffer_size).max(1); // ~1Hz

                    let render_fn = move |data: &mut [f32]| {
                        let is_playing = transport_arc.playing.load(std::sync::atomic::Ordering::Relaxed);

                        if is_playing {
                            let frames = data.len() / channels as usize;
                            let beat_start = transport_arc.position_beats();
                            // v0.0.21.043: Read BPM atomically each callback (was captured once at start)
                            let current_bpm = transport_arc.bpm();
                            let beats_per_frame = current_bpm / 60.0 / sr_f;
                            let beat_end = beat_start + (frames as f64 * beats_per_frame);

                            if let Some(mut g) = graph_arc.try_lock() {
                                // Dispatch MIDI
                                let mut midi_count = 0u32;
                                let mut sched_locked = false;
                                if let Some(mut sched) = midi_sched_arc.try_lock() {
                                    sched_locked = true;
                                    let events: Vec<_> = sched.schedule_for_buffer(beat_start, beat_end, true).copied().collect();
                                    midi_count = events.len() as u32;
                                    for evt in events {
                                        if let Some(track) = g.tracks.get_mut(&evt.track_index) {
                                            if let Some(ref mut inst) = track.instrument {
                                                if evt.is_note_on {
                                                    inst.push_midi(crate::instruments::MidiEvent::NoteOn {
                                                        note: evt.pitch,
                                                        velocity: evt.velocity,
                                                    });
                                                } else {
                                                    inst.push_midi(crate::instruments::MidiEvent::NoteOff {
                                                        note: evt.pitch,
                                                    });
                                                }
                                            }
                                            // PH-3: Route arrangement MIDI to external instrument plugins
                                            for slot in &mut track.plugin_slots {
                                                if evt.is_note_on {
                                                    slot.midi_note_on(evt.pitch, (evt.velocity * 127.0).clamp(0.0, 127.0) as u8);
                                                } else {
                                                    slot.midi_note_off(evt.pitch);
                                                }
                                            }
                                        }
                                    }
                                }
                                // v0.0.21.045: Render audio clips into track buffers
                                let position = transport_arc.position_samples();
                                renderer_arc.render_all_tracks(&mut g, position, frames, sample_rate);

                                crate::render::render_graph_to_output(&mut g, data, channels as usize);

                                // v0.0.21.130 FIX: Mix Python-rendered audio (SF2/VST2) into output.
                                // Previously SharedMemory was only read when NOT playing,
                                // so Python-rendered instruments were completely silent during playback.
                                let mut shm_read = 0usize;
                                let mut shm_active = false;
                                if let Some(reader) = shm.try_lock() {
                                    shm_active = reader.is_active();
                                    if shm_active {
                                        shm_read = reader.read_mix(data);
                                    }
                                }
                                let py_active = py_ring.is_active();
                                let mut py_read = 0usize;
                                if py_active {
                                    py_read = py_ring.read_mix(data);
                                }

                                // v0.0.21.045: Debug logging (~1Hz)
                                debug_counter += 1;
                                if debug_counter % debug_interval == 0 {
                                    let peak = data.iter().map(|s| s.abs()).fold(0.0f32, f32::max);
                                    let track_count = g.tracks.len();
                                    let has_instruments = g.tracks.values().any(|t| t.instrument.is_some());
                                    log::info!(
                                        "[RENDER-DBG] beat={:.2} midi={} peak={:.6} tracks={} has_inst={} sched_lock={} frames={} shm={}/{} pyring={}/{}",
                                        beat_start, midi_count, peak, track_count, has_instruments, sched_locked, frames,
                                        shm_active, shm_read, py_active, py_read
                                    );
                                }

                                meter_tick = meter_tick.wrapping_add(1);
                                if meter_tick % meter_divisor == 0 {
                                    crate::render::send_meter_events(&g, &transport_arc, &event_tx_clone);
                                }
                            } else {
                                data.fill(0.0);
                                debug_counter += 1;
                                if debug_counter % debug_interval == 0 {
                                    log::warn!("[RENDER-DBG] graph lock FAILED — outputting silence");
                                }
                            }
                            transport_arc.advance(frames);
                        } else {
                            // Not playing: passthrough or silence
                            let mut got_audio = false;
                            if let Some(reader) = shm.try_lock() {
                                if reader.is_active() { reader.read(data); got_audio = true; }
                            }
                            if !got_audio && py_ring.is_active() { py_ring.read(data); got_audio = true; }
                            if !got_audio && test_sine.load(std::sync::atomic::Ordering::Relaxed) {
                                crate::render::render_test_sine(data, channels as usize, sr_f, &mut sine_phase);
                            } else if !got_audio {
                                data.fill(0.0);
                            }
                        }
                    };

                    let mut audio_out = self.audio_output.lock();
                    match audio_out.start(config, render_fn) {
                        Ok(()) => {
                            let stats = audio_out.stats();
                            info!(
                                "cpal audio auto-started: {} @ {}Hz, buf={}",
                                stats.device_name, stats.actual_sample_rate,
                                stats.actual_buffer_size,
                            );
                        }
                        Err(e) => {
                            warn!("cpal audio auto-start failed (non-fatal): {}", e);
                        }
                    }
                }

                let _ = self.event_tx.try_send(Event::Ready {
                    sample_rate,
                    buffer_size,
                    device_name: device,
                });
            }

            // -- v0.0.20.711: RA2 Extended Instrument Data ----------------

            Command::LoadSF2 {
                track_id,
                sf2_path,
                bank,
                preset,
            } => {
                // SF2 loading requires FluidSynth FFI (R11B).
                // For now: store the path and program info for when
                // the FluidSynth integration is ready.
                info!(
                    "LoadSF2: track={}, path={}, bank={}, preset={}",
                    track_id, sf2_path, bank, preset
                );
                // TODO (R11B): fluidsynth::load_soundfont(&sf2_path)
                // TODO: fluidsynth::program_select(bank, preset)
                let _ = self.event_tx.try_send(Event::Error {
                    code: 100,
                    message: format!(
                        "LoadSF2 received but FluidSynth FFI not yet implemented (track={})",
                        track_id
                    ),
                });
            }

            Command::LoadWavetable {
                track_id,
                table_name,
                frame_size,
                num_frames,
                data_b64,
            } => {
                // Decode wavetable frames from Base64.
                // Store in the instrument node for the AETERNA synth.
                info!(
                    "LoadWavetable: track={}, table='{}', {}×{} frames",
                    track_id, table_name, num_frames, frame_size
                );
                match crate::clip_renderer::base64_decode(&data_b64) {
                    Ok(raw) => {
                        let expected = (frame_size * num_frames * 4) as usize; // f32 = 4 bytes
                        if raw.len() >= expected {
                            info!(
                                "LoadWavetable: decoded {} bytes (expected {})",
                                raw.len(),
                                expected
                            );
                            // TODO (R9): Store in AeternaInstrument wavetable bank
                        } else {
                            warn!(
                                "LoadWavetable: short data ({} < {})",
                                raw.len(),
                                expected
                            );
                        }
                    }
                    Err(e) => {
                        warn!("LoadWavetable: base64 decode error: {}", e);
                    }
                }
            }

            Command::MapSampleZone {
                track_id,
                clip_id,
                key_lo,
                key_hi,
                vel_lo,
                vel_hi,
                root_key,
                rr_group,
            } => {
                // Map a pre-loaded clip (already in ClipStore via LoadAudioClip)
                // to a sample zone on a multi-sample instrument.
                info!(
                    "MapSampleZone: track={}, clip={}, keys={}-{}, vel={}-{}, root={}, rr={}",
                    track_id, clip_id, key_lo, key_hi, vel_lo, vel_hi, root_key, rr_group
                );
                // Verify clip exists in ClipStore
                if self.clip_store.get(&clip_id).is_some() {
                    info!("MapSampleZone: clip '{}' found in ClipStore", clip_id);
                    // TODO (R6B): Add zone to MultiSampleInstrument on track
                } else {
                    warn!(
                        "MapSampleZone: clip '{}' not found in ClipStore — \
                         send LoadAudioClip first!",
                        clip_id
                    );
                }
            }
            Command::Ping { seq } => {
                // Read render time from audio output callback (actual CPU measurement)
                let render_us = {
                    let ao = self.audio_output.lock();
                    ao.shared().render_time_us.load(std::sync::atomic::Ordering::Relaxed)
                };
                // Fallback to engine's own measurement if audio output hasn't reported
                let render_us = if render_us > 0 {
                    render_us
                } else {
                    self.last_render_us.load(std::sync::atomic::Ordering::Relaxed)
                };
                let budget = self.budget_us.load(std::sync::atomic::Ordering::Relaxed);
                let cpu_load = if budget > 0 {
                    render_us as f32 / budget as f32
                } else {
                    0.0
                };
                let _ = self.event_tx.try_send(Event::Pong {
                    seq,
                    cpu_load,
                    xrun_count: self
                        .xrun_count
                        .load(std::sync::atomic::Ordering::Relaxed),
                    render_time_us: render_us,
                });
            }
            // -- LADSPA Plugin Hosting (P3.2, v0.0.21.058) --------------------
            Command::LoadLadspaPlugin { track_id, slot_index, path, plugin_index } => {
                let sr = self.transport.sample_rate() as u32;
                let p = std::path::Path::new(&path);
                match self.ladspa_host.lock().load_plugin(
                    &track_id, slot_index as usize, p, plugin_index as usize, sr,
                ) {
                    Ok(()) => info!("LADSPA loaded: {} slot {} from {}", track_id, slot_index, path),
                    Err(e) => warn!("LADSPA load failed: {}", e),
                }
            }
            Command::SetLadspaParam { track_id, slot_index, port_index, value } => {
                self.ladspa_host.lock().set_param(
                    &track_id, slot_index as usize, port_index as usize, value as f32,
                );
            }
            Command::UnloadLadspaPlugin { track_id, slot_index } => {
                self.ladspa_host.lock().unload_plugin(&track_id, slot_index as usize);
            }

            Command::Shutdown => {
                info!("Shutdown command received");
                // Stop audio output before shutting down
                self.audio_output.lock().stop();
                self.running
                    .store(false, std::sync::atomic::Ordering::Release);
                let _ = self.event_tx.try_send(Event::ShuttingDown);
            }

            // -- Rust Audio Output (Phase RA1.3, v0.0.20.959) ----------------

            Command::AudioStart {
                device,
                sample_rate: sr,
                buffer_size: buf,
            } => {
                info!("AudioStart: dev='{}', sr={}, buf={}", device, sr, buf);

                let config = AudioOutputConfig {
                    sample_rate: sr,
                    buffer_size: buf,
                    device_name: device.clone(),
                    channels: 2,
                };

                // Update transport and graph to match the audio config
                self.transport.set_sample_rate(sr);
                {
                    let mut graph = self.graph.lock();
                    graph.sample_rate = sr;
                    graph.resize_buffers(buf as usize);
                }

                // Build render callback
                let test_sine = Arc::clone(&self.test_sine);
                let py_ring = Arc::clone(&self.py_audio_ring);
                let shm = Arc::clone(&self.shm_reader);
                let mut sine_phase: f64 = 0.0;
                let channels: u16 = 2;
                let sample_rate_f = sr as f64;

                // v0.0.21.034: Graph rendering + transport advance + playhead events
                let graph_arc = Arc::clone(&self.graph);
                let transport_arc = Arc::clone(&self.transport);
                let midi_sched_arc = Arc::clone(&self.midi_scheduler);
                let renderer_arc = self.renderer.clone();
                let event_tx_clone = self.event_tx.clone();
                let meter_divisor: u32 = (sr / buf).max(1); // ~30Hz at typical rates
                let mut meter_tick: u32 = 0;
                let mut debug_counter: u32 = 0;
                let debug_interval: u32 = (sr / buf).max(1); // ~1Hz

                let render_fn = move |data: &mut [f32]| {
                    let is_playing = transport_arc.playing.load(std::sync::atomic::Ordering::Relaxed);

                    if is_playing {
                        // v0.0.21.038: Full Rust rendering pipeline
                        let frames = data.len() / channels as usize;
                        let beat_start = transport_arc.position_beats();
                        // v0.0.21.044: Read BPM atomically each callback (was captured once at start)
                        let current_bpm = transport_arc.bpm();
                        let beats_per_frame = current_bpm / 60.0 / sample_rate_f;
                        let beat_end = beat_start + (frames as f64 * beats_per_frame);

                        if let Some(mut g) = graph_arc.try_lock() {
                            // 1. Dispatch MIDI events from scheduler to instruments
                            let mut midi_count = 0u32;
                            if let Some(mut sched) = midi_sched_arc.try_lock() {
                                let iter = sched.schedule_for_buffer(beat_start, beat_end, true);
                                let events: Vec<_> = iter.copied().collect();
                                midi_count = events.len() as u32;
                                for evt in events {
                                    if let Some(track) = g.tracks.get_mut(&evt.track_index) {
                                        if let Some(ref mut inst) = track.instrument {
                                            if evt.is_note_on {
                                                inst.push_midi(crate::instruments::MidiEvent::NoteOn {
                                                    note: evt.pitch,
                                                    velocity: evt.velocity,
                                                });
                                            } else {
                                                inst.push_midi(crate::instruments::MidiEvent::NoteOff {
                                                    note: evt.pitch,
                                                });
                                            }
                                        }
                                        // PH-3: Route arrangement MIDI to external instrument plugins
                                        for slot in &mut track.plugin_slots {
                                            if evt.is_note_on {
                                                slot.midi_note_on(evt.pitch, (evt.velocity * 127.0).clamp(0.0, 127.0) as u8);
                                            } else {
                                                slot.midi_note_off(evt.pitch);
                                            }
                                        }
                                    }
                                }
                            }

                            // 2. Render audio clips into track buffers
                            let position = transport_arc.position_samples();
                            renderer_arc.render_all_tracks(&mut g, position, frames, sr);

                            // 3. Render the audio graph
                            crate::render::render_graph_to_output(&mut g, data, channels as usize);

                            // v0.0.21.130 FIX: Mix Python-rendered audio (SF2/VST2) into output.
                            let mut shm_read2 = 0usize;
                            let mut shm_active2 = false;
                            if let Some(reader) = shm.try_lock() {
                                shm_active2 = reader.is_active();
                                if shm_active2 {
                                    shm_read2 = reader.read_mix(data);
                                }
                            }
                            let py_active2 = py_ring.is_active();
                            let mut py_read2 = 0usize;
                            if py_active2 {
                                py_read2 = py_ring.read_mix(data);
                            }

                            // v0.0.21.045: Debug logging (~1Hz)
                            debug_counter += 1;
                            if debug_counter % debug_interval == 0 {
                                let peak = data.iter().map(|s| s.abs()).fold(0.0f32, f32::max);
                                let track_count = g.tracks.len();
                                let has_instruments = g.tracks.values().any(|t| t.instrument.is_some());
                                log::info!(
                                    "[RENDER-DBG] beat={:.2} midi={} peak={:.6} tracks={} has_inst={} frames={} shm={}/{} pyring={}/{}",
                                    beat_start, midi_count, peak, track_count, has_instruments, frames,
                                    shm_active2, shm_read2, py_active2, py_read2
                                );
                            }

                            // 3. Send playhead + meters at ~30Hz
                            meter_tick = meter_tick.wrapping_add(1);
                            if meter_tick % meter_divisor == 0 {
                                crate::render::send_meter_events(&g, &transport_arc, &event_tx_clone);
                            }
                        } else {
                            data.fill(0.0);
                        }

                        // 4. Advance transport
                        transport_arc.advance(frames);
                    } else {
                        // Not playing: passthrough from Python or silence
                        let mut got_audio = false;
                        if let Some(reader) = shm.try_lock() {
                            if reader.is_active() { reader.read(data); got_audio = true; }
                        }
                        if !got_audio && py_ring.is_active() { py_ring.read(data); got_audio = true; }
                        if !got_audio && test_sine.load(std::sync::atomic::Ordering::Relaxed) {
                            crate::render::render_test_sine(data, channels as usize, sample_rate_f, &mut sine_phase);
                        } else if !got_audio {
                            data.fill(0.0);
                        }
                    }
                };

                let mut audio_out = self.audio_output.lock();
                match audio_out.start(config, render_fn) {
                    Ok(()) => {
                        let stats = audio_out.stats();
                        let latency_ms = stats.actual_buffer_size as f32
                            / stats.actual_sample_rate as f32
                            * 1000.0;
                        let _ = self.event_tx.try_send(Event::AudioStarted {
                            device_name: stats.device_name,
                            sample_rate: stats.actual_sample_rate,
                            buffer_size: stats.actual_buffer_size,
                            latency_ms,
                        });
                    }
                    Err(e) => {
                        error!("AudioStart failed: {}", e);
                        let _ = self.event_tx.try_send(Event::AudioError {
                            message: e,
                        });
                    }
                }
            }

            Command::AudioStop => {
                info!("AudioStop: stopping Rust audio output");
                self.audio_output.lock().stop();
                self.test_sine.store(false, std::sync::atomic::Ordering::Release);
                let _ = self.event_tx.try_send(Event::AudioStopped);
            }

            Command::AudioTestSine { enabled } => {
                info!("AudioTestSine: enabled={}", enabled);
                self.test_sine.store(enabled, std::sync::atomic::Ordering::Release);

                // If audio is not running, auto-start with defaults
                if enabled && !self.audio_output.lock().is_running() {
                    info!("Auto-starting audio output for test sine...");
                    let config = AudioOutputConfig::default();
                    let test_sine = Arc::clone(&self.test_sine);
                    let py_ring = Arc::clone(&self.py_audio_ring);
                    let shm = Arc::clone(&self.shm_reader);
                    let channels: u16 = 2;
                    let sr_f = config.sample_rate as f64;
                    let mut sine_phase: f64 = 0.0;

                    let render_fn = move |data: &mut [f32]| {
                        if let Some(reader) = shm.try_lock() {
                            if reader.is_active() { reader.read(data); return; }
                        }
                        if py_ring.is_active() { py_ring.read(data); return; }
                        if test_sine.load(std::sync::atomic::Ordering::Relaxed) {
                            crate::render::render_test_sine(
                                data, channels as usize, sr_f, &mut sine_phase,
                            );
                        } else {
                            data.fill(0.0);
                        }
                    };

                    let mut audio_out = self.audio_output.lock();
                    match audio_out.start(config, render_fn) {
                        Ok(()) => {
                            let stats = audio_out.stats();
                            let _ = self.event_tx.try_send(Event::AudioStarted {
                                device_name: stats.device_name,
                                sample_rate: stats.actual_sample_rate,
                                buffer_size: stats.actual_buffer_size,
                                latency_ms: stats.actual_buffer_size as f32
                                    / stats.actual_sample_rate as f32
                                    * 1000.0,
                            });
                        }
                        Err(e) => {
                            error!("Auto-start audio for test sine failed: {}", e);
                            let _ = self.event_tx.try_send(Event::AudioError { message: e });
                        }
                    }
                }
            }

            Command::EnumerateAudioDevices => {
                info!("Enumerating audio output devices...");
                let devices = AudioOutput::enumerate_devices();
                let entries: Vec<crate::ipc::AudioDeviceEntry> = devices
                    .into_iter()
                    .map(|d| crate::ipc::AudioDeviceEntry {
                        name: d.name,
                        is_default: d.is_default,
                        sample_rates: d.sample_rates,
                        max_channels: d.max_channels,
                    })
                    .collect();
                info!("Found {} audio devices", entries.len());
                let _ = self.event_tx.try_send(Event::AudioDeviceList { devices: entries });
            }

            Command::AudioStatus => {
                let audio_out = self.audio_output.lock();
                let stats = audio_out.stats();
                // Read render time from audio callback (actual CPU measurement)
                let cb_render_us = audio_out.shared().render_time_us
                    .load(std::sync::atomic::Ordering::Relaxed);
                let render_us = if cb_render_us > 0 {
                    cb_render_us
                } else {
                    self.last_render_us.load(std::sync::atomic::Ordering::Relaxed)
                };
                let budget = self.budget_us.load(std::sync::atomic::Ordering::Relaxed);
                let cpu_load = if budget > 0 {
                    render_us as f32 / budget as f32
                } else {
                    0.0
                };
                let _ = self.event_tx.try_send(Event::AudioStatusReport {
                    is_active: stats.is_running,
                    device_name: stats.device_name,
                    sample_rate: stats.actual_sample_rate,
                    buffer_size: stats.actual_buffer_size,
                    xrun_count: stats.xrun_count,
                    render_time_us: render_us,
                    cpu_load,
                    test_sine_active: self.test_sine.load(std::sync::atomic::Ordering::Relaxed),
                });
            }
            // -- v0.0.20.980: Python → Rust audio streaming -------------------
            Command::AudioData { raw } => {
                // Convert raw little-endian f32 bytes to samples
                // Each f32 = 4 bytes, so len/4 = number of samples
                let sample_count = raw.len() / 4;
                if sample_count == 0 { return; }
                // Safety: f32 is 4 bytes, alignment is handled by Vec
                let samples: &[f32] = unsafe {
                    std::slice::from_raw_parts(raw.as_ptr() as *const f32, sample_count)
                };
                let written = self.py_audio_ring.write(samples);
                if written < sample_count {
                    trace!("AudioData: ring full, dropped {} samples", sample_count - written);
                }
            }
            Command::AudioStreamMode { enabled } => {
                info!("AudioStreamMode: enabled={}", enabled);
                self.py_audio_ring.set_active(enabled);
                if enabled {
                    // Try to open shared memory (Python creates it before enabling streaming)
                    if let Some(mut reader) = self.shm_reader.try_lock() {
                        if !reader.is_mapped() {
                            if reader.try_open() {
                                info!("Shared memory audio bridge opened — zero-copy mode active");
                            }
                        }
                    }
                    // Disable test sine when streaming
                    self.test_sine.store(false, std::sync::atomic::Ordering::Release);
                    // Ensure audio output is running
                    if !self.audio_output.lock().is_running() {
                        info!("Auto-starting audio output for streaming mode...");
                        let config = AudioOutputConfig {
                            sample_rate: self.transport.sample_rate() as u32,
                            buffer_size: 1024,
                            device_name: String::new(),
                            channels: 2,
                        };
                        let test_sine = Arc::clone(&self.test_sine);
                        let py_ring = Arc::clone(&self.py_audio_ring);
                        let shm = Arc::clone(&self.shm_reader);
                        let channels: u16 = 2;
                        let sr_f = config.sample_rate as f64;
                        let mut sine_phase: f64 = 0.0;

                        let render_fn = move |data: &mut [f32]| {
                            if let Some(reader) = shm.try_lock() {
                                if reader.is_active() { reader.read(data); return; }
                            }
                            if py_ring.is_active() { py_ring.read(data); return; }
                            if test_sine.load(std::sync::atomic::Ordering::Relaxed) {
                                crate::render::render_test_sine(
                                    data, channels as usize, sr_f, &mut sine_phase,
                                );
                            } else {
                                data.fill(0.0);
                            }
                        };

                        let mut audio_out = self.audio_output.lock();
                        if let Err(e) = audio_out.start(config, render_fn) {
                            warn!("Failed to start audio for streaming: {}", e);
                        }
                    }
                }
            }
            // -- Audio Data (Phase 1B) ------------------------------------
            Command::LoadAudioClip {
                clip_id,
                channels,
                sample_rate,
                audio_b64,
            } => {
                match AudioClipData::from_base64(clip_id.clone(), channels, sample_rate, &audio_b64)
                {
                    Ok(clip) => {
                        info!(
                            "Loaded audio clip '{}': {}ch, {}Hz, {} frames",
                            clip_id, channels, sample_rate, clip.frame_count
                        );
                        self.clip_store.insert(clip);
                    }
                    Err(e) => {
                        error!("Failed to decode audio clip '{}': {}", clip_id, e);
                        let _ = self.event_tx.try_send(Event::Error {
                            code: 100,
                            message: format!("LoadAudioClip failed: {}", e),
                        });
                    }
                }
            }
            Command::SetArrangement { clips } => {
                let bpm = self.transport.bpm();
                let sr = self.transport.sample_rate() as u32;
                let placed: Vec<PlacedClip> = clips
                    .iter()
                    .map(|c| PlacedClip::from_ipc(c, sr, bpm))
                    .collect();
                let snapshot = ArrangementSnapshot::new(placed);
                info!(
                    "Arrangement updated: {} clips on {} tracks",
                    snapshot.clips.len(),
                    snapshot.clips_by_track.len()
                );
                self.renderer.set_arrangement(snapshot);
            }

            // v0.0.20.984: NS2 — Symphonia audio decode (background thread)
            Command::DecodeAudio { request_id, path, target_sr } => {
                info!("[DecodeAudio] Request '{}': {}", request_id, path);
                let event_tx = self.event_tx.clone();
                let rid = request_id.clone();
                let p = path.clone();
                let tsr = if target_sr > 0 { Some(target_sr) } else { None };

                std::thread::Builder::new()
                    .name("audio-decode".into())
                    .spawn(move || {
                        match crate::audio_decode::decode_audio(&p, tsr) {
                            Ok(decoded) => {
                                // Encode samples as base64 f32 LE
                                let bytes: Vec<u8> = decoded.samples.iter()
                                    .flat_map(|s| s.to_le_bytes())
                                    .collect();
                                let b64 = crate::clip_renderer::base64_encode(&bytes);

                                let _ = event_tx.try_send(Event::AudioDecoded {
                                    request_id: rid,
                                    sample_rate: decoded.sample_rate,
                                    channels: decoded.channels,
                                    duration_secs: decoded.duration_secs,
                                    num_frames: decoded.num_frames,
                                    codec: decoded.codec,
                                    audio_b64: b64,
                                });
                            }
                            Err(e) => {
                                let _ = event_tx.try_send(Event::AudioDecodeError {
                                    request_id: rid,
                                    error: e,
                                });
                            }
                        }
                    })
                    .ok();
            }
            // -- External Plugin Hosting (Phase P7) ----------------------------
            // v0.0.20.746 P0A FIX: ScanPlugins now runs in a background thread.
            // Previously it ran synchronously inside drain_commands() which is
            // called from the real-time audio callback (process_audio). Blocking
            // the audio callback for the seconds-long scan caused the cpal stream
            // to time-out / produce XRuns, which disconnected the IPC socket.
            Command::ScanPlugins => {
                info!("ScanPlugins: spawning background scan thread (non-blocking)...");
                // Clone the event sender so the background thread can send results.
                let event_tx_bg = self.event_tx.clone();
                std::thread::Builder::new()
                    .name("pydaw-plugin-scan".to_string())
                    .spawn(move || {
                        let scan_start = std::time::Instant::now();
                        let mut all_plugins: Vec<crate::ipc::ScannedPlugin> = Vec::new();
                        let mut all_errors: Vec<String> = Vec::new();

                        // v0.0.21.032: VST3 + CLAP scans use subprocess probing.
                        // Each plugin bundle is probed via --probe-plugin in a child
                        // process so that segfaults in dlopen don't kill the engine.
                        let engine_exe = std::env::current_exe().unwrap_or_default();

                        // VST3 — subprocess probe per bundle
                        let vst3_dirs = crate::vst3_host::vst3_search_paths();
                        let mut vst3_count = 0usize;
                        for dir in &vst3_dirs {
                            if !dir.exists() { continue; }
                            for bundle in find_bundles_recursive(dir, "vst3") {
                                match std::process::Command::new(&engine_exe)
                                    .arg("--probe-plugin").arg("vst3")
                                    .arg(bundle.to_string_lossy().as_ref())
                                    .stdout(std::process::Stdio::piped())
                                    .stderr(std::process::Stdio::null())
                                    .output()
                                {
                                    Ok(output) if output.status.success() => {
                                        let json = String::from_utf8_lossy(&output.stdout);
                                        parse_probe_json_vst3(&json, &bundle, &mut all_plugins);
                                        vst3_count += 1;
                                    }
                                    Ok(output) => {
                                        all_errors.push(format!(
                                            "VST3 probe crashed: {} (exit={})",
                                            bundle.display(), output.status
                                        ));
                                    }
                                    Err(e) => {
                                        all_errors.push(format!(
                                            "VST3 probe spawn error: {} — {}", bundle.display(), e
                                        ));
                                    }
                                }
                            }
                        }

                        // CLAP — subprocess probe per .clap file
                        let clap_dirs = crate::clap_host::clap_search_paths();
                        let mut clap_count = 0usize;
                        for dir in &clap_dirs {
                            if !dir.exists() { continue; }
                            for clap_file in find_files_recursive(dir, "clap") {
                                match std::process::Command::new(&engine_exe)
                                    .arg("--probe-plugin").arg("clap")
                                    .arg(clap_file.to_string_lossy().as_ref())
                                    .stdout(std::process::Stdio::piped())
                                    .stderr(std::process::Stdio::null())
                                    .output()
                                {
                                    Ok(output) if output.status.success() => {
                                        let json = String::from_utf8_lossy(&output.stdout);
                                        parse_probe_json_clap(&json, &clap_file, &mut all_plugins);
                                        clap_count += 1;
                                    }
                                    Ok(output) => {
                                        all_errors.push(format!(
                                            "CLAP probe crashed: {} (exit={})",
                                            clap_file.display(), output.status
                                        ));
                                    }
                                    Err(e) => {
                                        all_errors.push(format!(
                                            "CLAP probe spawn error: {} — {}", clap_file.display(), e
                                        ));
                                    }
                                }
                            }
                        }

                        // LV2 — in-process (uses lilv, generally safe)
                        let lv2 = std::panic::catch_unwind(|| {
                            crate::lv2_host::scan_lv2_plugins()
                        });
                        match lv2 {
                            Ok(lv2) => {
                                for p in &lv2.plugins {
                                    all_plugins.push(crate::ipc::ScannedPlugin {
                                        format: "lv2".to_string(),
                                        name: p.name.clone(),
                                        vendor: p.author.clone(),
                                        plugin_id: p.uri.clone(),
                                        path: String::new(),
                                        category: String::new(),
                                        audio_inputs: p.audio_inputs,
                                        audio_outputs: p.audio_outputs,
                                    });
                                }
                                all_errors.extend(lv2.errors);
                            }
                            Err(_) => {
                                all_errors.push("LV2 scan panicked".to_string());
                            }
                        }

                        let scan_ms = scan_start.elapsed().as_millis() as u64;
                        info!(
                            "ScanPlugins complete: {} VST3 bundles, {} CLAP files, ({} total plugins) in {}ms",
                            vst3_count, clap_count, all_plugins.len(), scan_ms
                        );
                        let _ = event_tx_bg.try_send(Event::PluginScanResult {
                            plugins: all_plugins,
                            scan_time_ms: scan_ms,
                            errors: all_errors,
                        });
                    })
                    .ok(); // If spawn fails, silently skip — non-critical
            }

            Command::LoadPlugin {
                track_id, slot_index, plugin_path, plugin_format, plugin_id,
                is_instrument,
            } => {
                // PH-5.2 v0.0.21.091: Check blacklist before attempting to load
                let plugin_ident = format!("{}:{}", plugin_format, if plugin_id.is_empty() { &plugin_path } else { &plugin_id });
                if self.plugin_blacklist.lock().is_blacklisted(&plugin_ident) {
                    warn!("LoadPlugin BLOCKED — '{}' is blacklisted (crashed 3+ times)", plugin_ident);
                    let _ = self.event_tx.try_send(Event::Error {
                        code: 201,
                        message: format!("Plugin blocked (blacklisted): {}", plugin_ident),
                    });
                    // Skip loading, don't continue to the load logic
                    return;
                }

                let mut graph = self.graph.lock();

                // v0.0.21.144 FIX: Guard against double-loading same plugin
                // into same slot. R5 sync can re-send LoadPlugin for plugins
                // that MIDI-FIX already preserved across SyncProject rebuilds.
                // Double-loading VST2 plugins (e.g. ZynAddSubFX) crashes because
                // the old instance's FFI resources (OSC servers, threads) conflict.
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track(idx) {
                        if let Some(slot) = track.plugin_slots.get(slot_index as usize) {
                            if slot.plugin.is_some() && slot.plugin_identity == plugin_ident {
                                info!(
                                    "LoadPlugin SKIP — '{}' already loaded on track '{}' slot {} (MIDI-FIX preserved)",
                                    plugin_ident, track_id, slot_index
                                );
                                // Send PluginLoaded event so Python knows it's ready
                                let pname = slot.plugin.as_ref()
                                    .map(|p| p.name().to_string())
                                    .unwrap_or_default();
                                let pcount = slot.plugin.as_ref()
                                    .map(|p| p.parameter_count())
                                    .unwrap_or(0);
                                let latency = slot.plugin.as_ref()
                                    .map(|p| p.latency_samples())
                                    .unwrap_or(0);
                                let _ = self.event_tx.try_send(Event::PluginLoaded {
                                    track_id, slot_index,
                                    plugin_name: pname,
                                    plugin_format,
                                    param_count: pcount,
                                    latency_samples: latency,
                                    is_instrument,
                                });
                                return;
                            }
                        }
                    }
                }

                let sr = graph.sample_rate as f64;
                let bs = graph.buffer_size() as u32;

                let result: Result<Box<dyn crate::plugin_host::AudioPlugin>, String> = {
                    let pp = plugin_path.clone();
                    let pid = plugin_id.clone();
                    let pf = plugin_format.clone();
                    // PH-5.2 v0.0.21.144: catch_unwind prevents plugin FFI panics
                    // from crashing the entire engine process.
                    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                        match pf.as_str() {
                            "vst3" => {
                                let cid = if pid.is_empty() { None } else { Some(pid.as_str()) };
                                crate::vst3_host::load_vst3(
                                    std::path::Path::new(&pp), cid, sr, bs,
                                ).map(|i| Box::new(i) as Box<dyn crate::plugin_host::AudioPlugin>)
                            }
                            "clap" => {
                                crate::clap_host::load_clap(
                                    std::path::Path::new(&pp), &pid, sr, bs,
                                ).map(|i| Box::new(i) as Box<dyn crate::plugin_host::AudioPlugin>)
                            }
                            "lv2" => {
                                crate::lv2_host::Lv2Instance::load(&pid, sr, bs)
                                    .map(|i| Box::new(i) as Box<dyn crate::plugin_host::AudioPlugin>)
                            }
                            "ladspa" => {
                                let pidx = pid.parse::<usize>().unwrap_or(0);
                                crate::ladspa_host::load_ladspa(
                                    std::path::Path::new(&pp), pidx, sr, bs,
                                ).map(|i| Box::new(i) as Box<dyn crate::plugin_host::AudioPlugin>)
                            }
                            "vst2" => {
                                crate::vst2_host::load_vst2(
                                    std::path::Path::new(&pp), sr, bs,
                                ).map(|i| Box::new(i) as Box<dyn crate::plugin_host::AudioPlugin>)
                            }
                            _ => Err(format!("Unknown plugin format: {}", pf)),
                        }
                    })) {
                        Ok(r) => r,
                        Err(e) => {
                            let msg = if let Some(s) = e.downcast_ref::<String>() {
                                s.clone()
                            } else if let Some(s) = e.downcast_ref::<&str>() {
                                s.to_string()
                            } else {
                                "unknown panic in plugin loading".to_string()
                            };
                            error!("LoadPlugin PANIC caught ({}): {}", plugin_format, msg);
                            Err(format!("Plugin panicked: {}", msg))
                        }
                    }
                };

                match result {
                    Ok(plugin) => {
                        let pname = plugin.name().to_string();
                        let pcount = plugin.parameter_count();
                        let latency = plugin.latency_samples();

                        if let Some(idx) = graph.find_track_index(&track_id) {
                            if let Some(track) = graph.get_track_mut(idx) {
                                // Ensure we have enough slots
                                while track.plugin_slots.len() <= slot_index as usize {
                                    let si = track.plugin_slots.len() as u8;
                                    track.plugin_slots.push(
                                        crate::plugin_host::PluginSlot::new(si)
                                    );
                                }
                                let slot = &mut track.plugin_slots[slot_index as usize];
                                slot.plugin = Some(plugin);
                                slot.enabled = true;
                                // PH-1.7: Mark as instrument for MIDI routing
                                slot.is_instrument = is_instrument;
                                // PH-5.2: Track identity for blacklist
                                slot.plugin_identity = plugin_ident.clone();

                                info!(
                                    "Loaded {} {} '{}' on track '{}' slot {} ({} params, {} lat)",
                                    plugin_format,
                                    if is_instrument { "instrument" } else { "effect" },
                                    pname, track_id, slot_index, pcount, latency
                                );
                                let _ = self.event_tx.try_send(Event::PluginLoaded {
                                    track_id, slot_index,
                                    plugin_name: pname,
                                    plugin_format,
                                    param_count: pcount,
                                    latency_samples: latency,
                                    is_instrument,
                                });

                                // PH-5.3 v0.0.21.142: Recompute PDC after plugin load
                                graph.recompute_pdc();
                            }
                        } else {
                            warn!("LoadPlugin: track '{}' not found", track_id);
                        }
                    }
                    Err(e) => {
                        error!("LoadPlugin failed ({}): {}", plugin_format, e);
                        let _ = self.event_tx.try_send(Event::Error {
                            code: 200,
                            message: format!("LoadPlugin failed: {}", e),
                        });
                    }
                }
            }

            Command::UnloadPlugin { track_id, slot_index } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(slot) = track.plugin_slots.get_mut(slot_index as usize) {
                            if let Some(ref plugin) = slot.plugin {
                                info!("Unloading plugin '{}' from track '{}' slot {}",
                                      plugin.name(), track_id, slot_index);
                            }
                            slot.plugin = None;
                            slot.enabled = false;
                        }
                    }
                }
                // PH-5.3 v0.0.21.142: Recompute PDC after plugin removal
                graph.recompute_pdc();
            }

            // PH-1.16: Enable/disable external plugin slot
            Command::SetPluginSlotEnabled { track_id, slot_index, enabled } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(slot) = track.plugin_slots.get_mut(slot_index as usize) {
                            slot.enabled = enabled;
                            info!("Plugin slot {} on track '{}' {}", slot_index, track_id,
                                  if enabled { "enabled" } else { "disabled" });
                        }
                    }
                }
            }

            // PH-3.6: Map MIDI CC → plugin parameter
            Command::MidiCCParamMap { track_id, slot_index, cc, param_index } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(slot) = track.plugin_slots.get_mut(slot_index as usize) {
                            slot.cc_param_map.insert(cc, param_index);
                            info!("MIDI CC{} → param {} on track '{}' slot {}",
                                  cc, param_index, track_id, slot_index);
                        }
                    }
                }
            }

            // PH-3.6: Clear all CC mappings for a slot
            Command::ClearMidiCCParamMap { track_id, slot_index } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(slot) = track.plugin_slots.get_mut(slot_index as usize) {
                            slot.cc_param_map.clear();
                        }
                    }
                }
            }

            Command::SetPluginParam { track_id, slot_index, param_index, value } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(slot) = track.plugin_slots.get_mut(slot_index as usize) {
                            if let Some(ref mut plugin) = slot.plugin {
                                plugin.set_parameter(param_index, value);
                            }
                        }
                    }
                }
            }

            // v0.0.21.088 PH-1.9: Load external plugin into FX chain
            Command::LoadPluginFx {
                track_id, slot_id, plugin_path, plugin_format, plugin_id, position,
                is_instrument,
            } => {
                let mut graph = self.graph.lock();

                // v0.0.21.144 FIX: Guard against double-loading FX plugins.
                // MIDI-FIX preserves FX slots across SyncProject, then R4 resends
                // the same LoadPluginFx. Skip if already loaded at same slot_id.
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track(idx) {
                        if track.fx_chain.find_slot(&slot_id).is_some() {
                            info!("LoadPluginFx SKIP — slot '{}' already has FX on track '{}' (MIDI-FIX preserved)",
                                  slot_id, track_id);
                            return;
                        }
                    }
                }

                let sr = graph.sample_rate as f64;
                let bs = graph.buffer_size() as u32;

                let result: Result<Box<dyn crate::plugin_host::AudioPlugin>, String> = {
                    let pp = plugin_path.clone();
                    let pid = plugin_id.clone();
                    let pf = plugin_format.clone();
                    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                        match pf.as_str() {
                            "vst3" => {
                                let cid = if pid.is_empty() { None } else { Some(pid.as_str()) };
                                crate::vst3_host::load_vst3(
                                    std::path::Path::new(&pp), cid, sr, bs,
                                ).map(|i| Box::new(i) as Box<dyn crate::plugin_host::AudioPlugin>)
                            }
                            "clap" => {
                                crate::clap_host::load_clap(
                                    std::path::Path::new(&pp), &pid, sr, bs,
                                ).map(|i| Box::new(i) as Box<dyn crate::plugin_host::AudioPlugin>)
                            }
                            "lv2" => {
                                crate::lv2_host::Lv2Instance::load(&pid, sr, bs)
                                    .map(|i| Box::new(i) as Box<dyn crate::plugin_host::AudioPlugin>)
                            }
                            "ladspa" => {
                                let pidx = pid.parse::<usize>().unwrap_or(0);
                                crate::ladspa_host::load_ladspa(
                                    std::path::Path::new(&pp), pidx, sr, bs,
                                ).map(|i| Box::new(i) as Box<dyn crate::plugin_host::AudioPlugin>)
                            }
                            "vst2" => {
                                crate::vst2_host::load_vst2(
                                    std::path::Path::new(&pp), sr, bs,
                                ).map(|i| Box::new(i) as Box<dyn crate::plugin_host::AudioPlugin>)
                            }
                            _ => Err(format!("Unknown plugin format for FX: {}", pf)),
                        }
                    })) {
                        Ok(r) => r,
                        Err(e) => {
                            let msg = if let Some(s) = e.downcast_ref::<String>() {
                                s.clone()
                            } else if let Some(s) = e.downcast_ref::<&str>() {
                                s.to_string()
                            } else {
                                "unknown panic in FX plugin loading".to_string()
                            };
                            error!("LoadPluginFx PANIC caught ({}): {}", plugin_format, msg);
                            Err(format!("Plugin panicked: {}", msg))
                        }
                    }
                };

                match result {
                    Ok(plugin) => {
                        let pname = plugin.name().to_string();
                        if is_instrument {
                            // PH-1.8: Instrument → track instrument_plugin slot
                            if let Some(tidx) = graph.find_track_index(&track_id) {
                                if let Some(track) = graph.get_track_mut(tidx) {
                                    let mut slot = crate::plugin_host::PluginSlot::new(0);
                                    slot.plugin = Some(plugin);
                                    slot.is_instrument = true;
                                    slot.enabled = true;
                                    // Insert as first plugin_slot (instrument position)
                                    track.plugin_slots.insert(0, slot);
                                    info!("Loaded {} instrument '{}' on track '{}' (slot={})",
                                          plugin_format, pname, track_id, slot_id);
                                }
                            }
                        } else {
                            // PH-1.9: Effect → FX chain adapter
                            let adapter = crate::fx::chain::PluginFxAdapter::new(plugin, &plugin_format);
                            if let Some(tidx) = graph.find_track_index(&track_id) {
                                if let Some(track) = graph.get_track_mut(tidx) {
                                    let fx_node: Box<dyn crate::fx::chain::AudioFxNode> = Box::new(adapter);
                                    if let Some(pos) = position {
                                        track.fx_chain.insert_fx(pos as usize, fx_node, slot_id.clone());
                                    } else {
                                        track.fx_chain.add_fx(fx_node, slot_id.clone());
                                    }
                                    info!("Loaded {} FX plugin '{}' on track '{}' (slot={})",
                                          plugin_format, pname, track_id, slot_id);
                                }
                            }
                        }
                    }
                    Err(e) => {
                        warn!("Failed to load {} {} plugin: {}", plugin_format,
                              if is_instrument { "instrument" } else { "FX" }, e);
                    }
                }
            }

            Command::SavePluginState { track_id, slot_index } => {
                let graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track(idx) {
                        if let Some(slot) = track.plugin_slots.get(slot_index as usize) {
                            if let Some(ref plugin) = slot.plugin {
                                let state = plugin.save_state();
                                let encoded = crate::clip_renderer::base64_encode(&state);
                                let _ = self.event_tx.try_send(Event::PluginState {
                                    track_id,
                                    slot_index,
                                    state_b64: encoded,
                                });
                            }
                        }
                    }
                }
            }

            Command::LoadPluginState { track_id, slot_index, state_b64 } => {
                match crate::clip_renderer::base64_decode(&state_b64) {
                    Ok(data) => {
                        let mut graph = self.graph.lock();
                        if let Some(idx) = graph.find_track_index(&track_id) {
                            if let Some(track) = graph.get_track_mut(idx) {
                                if let Some(slot) = track.plugin_slots.get_mut(slot_index as usize) {
                                    if let Some(ref mut plugin) = slot.plugin {
                                        if let Err(e) = plugin.load_state(&data) {
                                            warn!("LoadPluginState: {}", e);
                                        } else {
                                            info!("Loaded plugin state on track '{}' slot {}",
                                                  track_id, slot_index);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Err(e) => {
                        warn!("LoadPluginState: base64 decode error: {}", e);
                    }
                }
            }
            // PH-1.10: Return plugin parameter list to Python
            Command::GetPluginParams { track_id, slot_index } => {
                let graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track(idx) {
                        if let Some(slot) = track.plugin_slots.get(slot_index as usize) {
                            if let Some(ref plugin) = slot.plugin {
                                let count = plugin.parameter_count();
                                let mut params = Vec::with_capacity(count as usize);
                                for i in 0..count {
                                    params.push(crate::ipc::PluginParamInfo {
                                        index: i,
                                        name: plugin.parameter_name(i),
                                        value: plugin.get_parameter(i),
                                        default_value: plugin.parameter_default(i),
                                        min_value: plugin.parameter_min(i),
                                        max_value: plugin.parameter_max(i),
                                    });
                                }
                                let _ = self.event_tx.try_send(Event::PluginParams {
                                    track_id, slot_index, params,
                                });
                            }
                        }
                    }
                }
            }
            Command::MidiNoteOn { track_id, note, velocity, .. } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        // Built-in instrument
                        if let Some(ref mut inst) = track.instrument {
                            inst.push_midi(crate::instruments::MidiEvent::NoteOn { note, velocity });
                        }
                        // PH-3: External instrument plugins
                        for slot in &mut track.plugin_slots {
                            slot.midi_note_on(note, (velocity * 127.0).clamp(0.0, 127.0) as u8);
                        }
                    }
                }
            }
            Command::MidiNoteOff { track_id, note, .. } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            inst.push_midi(crate::instruments::MidiEvent::NoteOff { note });
                        }
                        // PH-3: External instrument plugins
                        for slot in &mut track.plugin_slots {
                            slot.midi_note_off(note);
                        }
                    }
                }
            }
            Command::MidiCC { track_id, cc, value, .. } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            inst.push_midi(crate::instruments::MidiEvent::CC { cc, value });
                        }
                        // PH-3: External instrument plugins
                        for slot in &mut track.plugin_slots {
                            slot.midi_cc(cc, (value * 127.0).clamp(0.0, 127.0) as u8);
                        }
                    }
                }
            }
            // -- Instruments (Phase R6) ----------------------------------------
            Command::LoadInstrument { track_id, instrument_type, instrument_id } => {
                let mut graph = self.graph.lock();
                let sr = graph.sample_rate;
                let buf_size = graph.buffer_size();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    let inst_id = if instrument_id.is_empty() {
                        format!("inst_{}", track_id)
                    } else {
                        instrument_id.clone()
                    };
                    if let Some(itype) = crate::instruments::InstrumentType::from_str(&instrument_type) {
                        if let Some(inst) = itype.create(inst_id.clone(), sr, buf_size) {
                            if let Some(track) = graph.get_track_mut(idx) {
                                track.instrument = Some(inst);
                                info!("Loaded instrument '{}' (type={}) on track '{}'", inst_id, instrument_type, track_id);
                            }
                        } else {
                            warn!("Failed to create instrument type '{}'", instrument_type);
                        }
                    } else {
                        warn!("Unknown instrument type: '{}'", instrument_type);
                    }
                }
            }
            Command::UnloadInstrument { track_id } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if track.instrument.is_some() {
                            track.instrument = None;
                            info!("Unloaded instrument from track '{}'", track_id);
                        }
                    }
                }
            }
            Command::LoadSample { track_id, wav_path, root_note, fine_tune } => {
                // Load sample data on this thread (non-audio-safe, but command thread is OK)
                match load_sample_any(&wav_path, self.transport.sample_rate() as u32) {
                    Ok(mut sample_data) => {
                        sample_data.root_note = root_note;
                        sample_data.fine_tune = fine_tune;
                        let mut graph = self.graph.lock();
                        if let Some(idx) = graph.find_track_index(&track_id) {
                            if let Some(track) = graph.get_track_mut(idx) {
                                if let Some(ref mut inst) = track.instrument {
                                    // Send sample via command channel for audio-thread-safe delivery
                                    // For ProSampler, we downcast or use InstrumentNode trait
                                    // Simple approach: push_midi is for MIDI, we need a different path
                                    // For now, set directly (we hold the mutex, audio thread is blocked)
                                    // This is safe because the mutex serializes access
                                    use crate::instruments::sampler::ProSamplerInstrument;
                                    // Use the command sender
                                    let any = inst.as_any_mut();
                                    if let Some(sampler) = any.downcast_mut::<ProSamplerInstrument>() {
                                        sampler.set_sample(sample_data);
                                        info!("Loaded sample '{}' (root={}, tune={}) on track '{}'",
                                              wav_path, root_note, fine_tune, track_id);
                                    } else {
                                        warn!("Track '{}' instrument is not a ProSampler", track_id);
                                    }
                                } else {
                                    warn!("Track '{}' has no instrument loaded", track_id);
                                }
                            }
                        }
                    }
                    Err(e) => {
                        warn!("Failed to load sample '{}': {}", wav_path, e);
                    }
                }
            }
            Command::ClearSample { track_id } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            // Send AllSoundOff + clear
                            inst.push_midi(crate::instruments::MidiEvent::AllSoundOff);
                            info!("Cleared sample on track '{}'", track_id);
                        }
                    }
                }
            }
            Command::SetInstrumentParam { track_id, param_name, value } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            // R-I1.2: Generic param dispatch via trait method.
                            // All instruments implement set_param() — no more
                            // hardcoded downcast per instrument type.
                            inst.set_param(&param_name, value);
                        }
                    }
                }
            }
            Command::GetInstrumentParam { track_id, param_name } => {
                let graph = self.graph.lock();
                let mut val: Option<f64> = None;
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track(idx) {
                        if let Some(ref inst) = track.instrument {
                            val = inst.get_param(&param_name);
                        }
                    }
                }
                let _ = self.event_tx.try_send(Event::InstrumentParamValue {
                    track_id,
                    param_name,
                    value: val,
                });
            }

            // v0.0.21.082 EFX-2: Set FX parameter by name on a specific slot
            Command::SetFxParam { track_id, slot_index, param_name, value } => {
                log::info!("SetFxParam: track={}, slot={}, param={}, value={:.4}",
                           track_id, slot_index, param_name, value);
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        track.fx_chain.set_fx_param(slot_index as usize, &param_name, value);
                    }
                }
            }
            Command::GetInstrumentParamDump { track_id } => {
                let graph = self.graph.lock();
                let mut params = std::collections::HashMap::<String, f64>::new();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track(idx) {
                        if let Some(ref inst) = track.instrument {
                            for name in inst.param_names() {
                                if let Some(v) = inst.get_param(name) {
                                    params.insert(name.to_string(), v);
                                }
                            }
                        }
                    }
                }
                let json = serde_json::to_string(&params).unwrap_or_default();
                let _ = self.event_tx.try_send(Event::InstrumentParamDump {
                    track_id,
                    params_json: json,
                });
            }
            // -- Built-in FX Chain (Phase R4) ---------------------------------
            Command::AddFx {
                track_id,
                fx_type,
                slot_id,
                position,
            } => {
                let mut graph = self.graph.lock();
                let sr = graph.sample_rate as f32;
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(fx) = crate::fx::chain::create_fx(&fx_type, sr) {
                        if let Some(track) = graph.get_track_mut(idx) {
                            if let Some(pos) = position {
                                track.fx_chain.insert_fx(pos as usize, fx, slot_id.clone());
                            } else {
                                track.fx_chain.add_fx(fx, slot_id.clone());
                            }
                            info!("Added FX '{}' (type={}) to track '{}'", slot_id, fx_type, track_id);
                        }
                    } else {
                        warn!("Unknown FX type '{}' for AddFx", fx_type);
                    }
                }
            }
            Command::RemoveFx {
                track_id,
                slot_index,
            } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        track.fx_chain.remove_fx(slot_index as usize);
                    }
                }
            }
            Command::SetFxBypass {
                track_id,
                slot_index,
                bypass,
            } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        track.fx_chain.set_bypass(slot_index as usize, bypass);
                    }
                }
            }
            Command::SetFxEnabled {
                track_id,
                slot_index,
                enabled,
            } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        track.fx_chain.set_enabled(slot_index as usize, enabled);
                    }
                }
            }
            Command::ReorderFx {
                track_id,
                from_index,
                to_index,
            } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        track.fx_chain.reorder(from_index as usize, to_index as usize);
                    }
                }
            }
            Command::SetFxChainMix {
                track_id,
                mix,
            } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        track.fx_chain.set_mix(mix as f32);
                    }
                }
            }

            // -- MultiSample Instrument (Phase R6B) ---------------------------
            Command::AddSampleZone {
                track_id, wav_path, root_note, key_lo, key_hi,
                vel_lo, vel_hi, gain, pan, tune_semitones, tune_cents, rr_group,
            } => {
                match load_sample_any(&wav_path, self.transport.sample_rate() as u32) {
                    Ok(mut sample_data) => {
                        sample_data.root_note = root_note;
                        let mut graph = self.graph.lock();
                        if let Some(idx) = graph.find_track_index(&track_id) {
                            if let Some(track) = graph.get_track_mut(idx) {
                                if let Some(ref mut inst) = track.instrument {
                                    use crate::instruments::multisample::{MultiSampleInstrument, MultiSampleCommand};
                                    let any = inst.as_any_mut();
                                    if let Some(ms) = any.downcast_mut::<MultiSampleInstrument>() {
                                        ms.apply_command(MultiSampleCommand::AddZone {
                                            key_lo, key_hi, vel_lo, vel_hi, root_note,
                                            gain: gain as f32, pan: pan as f32,
                                            tune_semitones: tune_semitones as f32,
                                            tune_cents: tune_cents as f32,
                                            sample: sample_data, rr_group,
                                        });
                                    }
                                }
                            }
                        }
                    }
                    Err(e) => {
                        warn!("Failed to load sample zone '{}': {}", wav_path, e);
                    }
                }
            }
            Command::RemoveSampleZone { track_id, zone_id } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            use crate::instruments::multisample::{MultiSampleInstrument, MultiSampleCommand};
                            let any = inst.as_any_mut();
                            if let Some(ms) = any.downcast_mut::<MultiSampleInstrument>() {
                                ms.apply_command(MultiSampleCommand::RemoveZone { zone_id });
                            }
                        }
                    }
                }
            }
            Command::ClearAllZones { track_id } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            use crate::instruments::multisample::{MultiSampleInstrument, MultiSampleCommand};
                            let any = inst.as_any_mut();
                            if let Some(ms) = any.downcast_mut::<MultiSampleInstrument>() {
                                ms.apply_command(MultiSampleCommand::ClearAllZones);
                            }
                        }
                    }
                }
            }
            Command::SetZoneFilter {
                track_id, zone_id, filter_type, cutoff_hz, resonance, env_amount,
            } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            use crate::instruments::multisample::{MultiSampleInstrument, MultiSampleCommand, ZoneFilterType};
                            let any = inst.as_any_mut();
                            if let Some(ms) = any.downcast_mut::<MultiSampleInstrument>() {
                                ms.apply_command(MultiSampleCommand::SetZoneFilter {
                                    zone_id,
                                    filter_type: ZoneFilterType::from_str(&filter_type),
                                    cutoff_hz: cutoff_hz as f32,
                                    resonance: resonance as f32,
                                    env_amount: env_amount as f32,
                                });
                            }
                        }
                    }
                }
            }
            Command::SetZoneEnvelope {
                track_id, zone_id, env_type, attack, decay, sustain, release,
            } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            use crate::instruments::multisample::{MultiSampleInstrument, MultiSampleCommand};
                            let any = inst.as_any_mut();
                            if let Some(ms) = any.downcast_mut::<MultiSampleInstrument>() {
                                if env_type == "filter" {
                                    ms.apply_command(MultiSampleCommand::SetZoneFilterEnvelope {
                                        zone_id,
                                        attack: attack as f32,
                                        decay: decay as f32,
                                        sustain: sustain as f32,
                                        release: release as f32,
                                    });
                                } else {
                                    ms.apply_command(MultiSampleCommand::SetZoneAmpEnvelope {
                                        zone_id,
                                        attack: attack as f32,
                                        decay: decay as f32,
                                        sustain: sustain as f32,
                                        release: release as f32,
                                    });
                                }
                            }
                        }
                    }
                }
            }
            Command::SetZoneLfo {
                track_id, zone_id, lfo_index, rate_hz, shape,
            } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            use crate::instruments::multisample::{MultiSampleInstrument, MultiSampleCommand};
                            use crate::dsp::lfo::LfoShape;
                            let any = inst.as_any_mut();
                            if let Some(ms) = any.downcast_mut::<MultiSampleInstrument>() {
                                let lfo_shape = match shape.as_str() {
                                    "triangle" => LfoShape::Triangle,
                                    "square" => LfoShape::Square,
                                    "saw" => LfoShape::SawUp,
                                    "sample_hold" => LfoShape::SampleAndHold,
                                    _ => LfoShape::Sine,
                                };
                                ms.apply_command(MultiSampleCommand::SetZoneLfo {
                                    zone_id, lfo_index, rate_hz: rate_hz as f32, shape: lfo_shape,
                                });
                            }
                        }
                    }
                }
            }
            Command::SetZoneModSlot {
                track_id, zone_id, slot_index, source, destination, amount,
            } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            use crate::instruments::multisample::{MultiSampleInstrument, MultiSampleCommand, ModSource, ModDest};
                            let any = inst.as_any_mut();
                            if let Some(ms) = any.downcast_mut::<MultiSampleInstrument>() {
                                ms.apply_command(MultiSampleCommand::SetZoneModSlot {
                                    zone_id, slot_index,
                                    source: ModSource::from_str(&source),
                                    destination: ModDest::from_str(&destination),
                                    amount: amount as f32,
                                });
                            }
                        }
                    }
                }
            }
            Command::AutoMapZones {
                track_id, mode, base_note, wav_paths,
            } => {
                // Load all samples on command thread
                let mut samples = Vec::new();
                for path in &wav_paths {
                    match load_sample_any(path, self.transport.sample_rate() as u32) {
                        Ok(s) => samples.push(s),
                        Err(e) => {
                            warn!("AutoMap: failed to load '{}': {}", path, e);
                        }
                    }
                }
                if !samples.is_empty() {
                    let mut graph = self.graph.lock();
                    if let Some(idx) = graph.find_track_index(&track_id) {
                        if let Some(track) = graph.get_track_mut(idx) {
                            if let Some(ref mut inst) = track.instrument {
                                use crate::instruments::multisample::{MultiSampleInstrument, MultiSampleCommand, AutoMapMode};
                                let any = inst.as_any_mut();
                                if let Some(ms) = any.downcast_mut::<MultiSampleInstrument>() {
                                    ms.apply_command(MultiSampleCommand::AutoMap {
                                        mode: AutoMapMode::from_str(&mode),
                                        base_note,
                                        samples,
                                    });
                                }
                            }
                        }
                    }
                }
            }

            // -- DrumMachine Instrument (Phase R7A) ----------------------------
            Command::LoadDrumPadSample { track_id, pad_index, wav_path } => {
                // v0.0.21.031: Use symphonia (load_any) for all audio formats
                match load_sample_any(&wav_path, self.transport.sample_rate() as u32) {
                    Ok(sample_data) => {
                        let mut graph = self.graph.lock();
                        if let Some(idx) = graph.find_track_index(&track_id) {
                            if let Some(track) = graph.get_track_mut(idx) {
                                if let Some(ref mut inst) = track.instrument {
                                    use crate::instruments::drum_machine::{DrumMachineInstrument, DrumMachineCommand};
                                    let any = inst.as_any_mut();
                                    if let Some(dm) = any.downcast_mut::<DrumMachineInstrument>() {
                                        dm.apply_command(DrumMachineCommand::LoadPadSample {
                                            pad_index, sample: sample_data,
                                        });
                                    }
                                }
                            }
                        }
                    }
                    Err(e) => {
                        warn!("Failed to load drum sample '{}': {}", wav_path, e);
                    }
                }
            }
            Command::ClearDrumPad { track_id, pad_index } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            use crate::instruments::drum_machine::{DrumMachineInstrument, DrumMachineCommand};
                            let any = inst.as_any_mut();
                            if let Some(dm) = any.downcast_mut::<DrumMachineInstrument>() {
                                dm.apply_command(DrumMachineCommand::ClearPad { pad_index });
                            }
                        }
                    }
                }
            }
            Command::SetDrumPadParam { track_id, pad_index, param_name, value } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            use crate::instruments::drum_machine::{DrumMachineInstrument, DrumMachineCommand, PadPlayMode};
                            let any = inst.as_any_mut();
                            if let Some(dm) = any.downcast_mut::<DrumMachineInstrument>() {
                                let cmd = match param_name.as_str() {
                                    "gain" => Some(DrumMachineCommand::SetPadGain { pad_index, gain: value as f32 }),
                                    "pan" => Some(DrumMachineCommand::SetPadPan { pad_index, pan: value as f32 }),
                                    "tune" => Some(DrumMachineCommand::SetPadTune { pad_index, semitones: value as f32 }),
                                    "choke" => Some(DrumMachineCommand::SetPadChoke { pad_index, group: value as u8 }),
                                    "play_mode" => Some(DrumMachineCommand::SetPadPlayMode {
                                        pad_index,
                                        mode: if value > 0.5 { PadPlayMode::Gate } else { PadPlayMode::OneShot },
                                    }),
                                    _ => {
                                        warn!("Unknown drum pad param: '{}'", param_name);
                                        None
                                    }
                                };
                                if let Some(c) = cmd {
                                    dm.apply_command(c);
                                }
                            }
                        }
                    }
                }
            }
            Command::ClearAllDrumPads { track_id } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            use crate::instruments::drum_machine::{DrumMachineInstrument, DrumMachineCommand};
                            let any = inst.as_any_mut();
                            if let Some(dm) = any.downcast_mut::<DrumMachineInstrument>() {
                                dm.apply_command(DrumMachineCommand::ClearAllPads);
                            }
                        }
                    }
                }
            }
            Command::SetDrumBaseNote { track_id, base_note } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            use crate::instruments::drum_machine::{DrumMachineInstrument, DrumMachineCommand};
                            let any = inst.as_any_mut();
                            if let Some(dm) = any.downcast_mut::<DrumMachineInstrument>() {
                                dm.apply_command(DrumMachineCommand::SetBaseNote(base_note));
                            }
                        }
                    }
                }
            }
            Command::SetDrumPadOutput { track_id, pad_index, output_index } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            use crate::instruments::drum_machine::{DrumMachineInstrument, DrumMachineCommand};
                            let any = inst.as_any_mut();
                            if let Some(dm) = any.downcast_mut::<DrumMachineInstrument>() {
                                dm.apply_command(DrumMachineCommand::SetPadOutput { pad_index, output_index });
                            }
                        }
                    }
                }
            }
            Command::SetDrumMultiOutput { track_id, enabled, output_count } => {
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(ref mut inst) = track.instrument {
                            use crate::instruments::drum_machine::{DrumMachineInstrument, DrumMachineCommand};
                            let any = inst.as_any_mut();
                            if let Some(dm) = any.downcast_mut::<DrumMachineInstrument>() {
                                dm.apply_command(DrumMachineCommand::SetMultiOutput { enabled, output_count });
                            }
                        }
                    }
                }
            }

            // -- Project Sync (Phase R12B + RA1 v710) --------------------------
            Command::SyncProject { project_json } => {
                match serde_json::from_str::<crate::audio_bridge::ProjectSync>(&project_json) {
                    Ok(sync) => {
                        info!(
                            "SyncProject received: seq={}, {} tracks, {} clips, {} notes",
                            sync.sync_seq, sync.track_count(), sync.clip_count(), sync.note_count()
                        );

                        // RA1 v0.0.20.710: Actually rebuild the AudioGraph
                        self.apply_project_sync(&sync);

                        let _ = self.event_tx.try_send(Event::SyncProjectAck {
                            sync_seq: sync.sync_seq,
                            track_count: sync.track_count() as u16,
                            clip_count: sync.clip_count() as u16,
                        });
                    }
                    Err(e) => {
                        error!("SyncProject JSON parse error: {}", e);
                        let _ = self.event_tx.try_send(Event::Error {
                            code: 200,
                            message: format!("SyncProject parse failed: {}", e),
                        });
                    }
                }
            }

            // -- Catch-all for newly added commands (RM2-RM9) --
            // Video, DB, MIDI processing, Music AI, File I/O, Services, Collaboration
            // These are handled by their respective modules; the IPC bridge
            // will dispatch them once the full integration is wired up.
            // -- Audio Export (v0.0.21.055: R8) ---------------------------------
            Command::AudioExport { output_path, format, start_beat: _, end_beat: _ } => {
                info!("AudioExport requested: path={}, format={}", output_path, format);
                // TODO: Wire to audio_export module for offline rendering
                let _ = self.event_tx.try_send(Event::AudioExportError {
                    message: "AudioExport not yet fully wired — coming in next version".into(),
                });
            }
            Command::AudioExportCancel => {
                info!("AudioExportCancel received");
            }

            // -- R7.3: Input Monitoring (v0.0.21.056) -------------------------
            Command::SetInputMonitoring { track_id, enabled } => {
                info!("SetInputMonitoring: track={}, enabled={}", track_id, enabled);
                {
                    let mut graph = self.graph.lock();
                    if let Some(track) = graph.get_track_by_id_mut(&track_id) {
                        track.input_monitoring = enabled;
                    }
                }
                let _ = self.event_tx.try_send(Event::InputMonitoringChanged {
                    track_id,
                    enabled,
                });
            }

            // -- R6: Waveform Peaks (v0.0.21.056) ----------------------------
            Command::GenerateWaveformPeaks { clip_id, peaks_per_second } => {
                info!("GenerateWaveformPeaks: clip={}, pps={}", clip_id, peaks_per_second);
                if let Some(clip_data) = self.clip_store.get(&clip_id) {
                    let samples = &clip_data.samples;
                    let channels = clip_data.channels as usize;
                    let sr = clip_data.sample_rate;
                    let total_frames = clip_data.frame_count;
                    let pps = (peaks_per_second as usize).max(1);
                    let samples_per_peak = (sr as usize) / pps;
                    let num_peaks = if samples_per_peak > 0 {
                        (total_frames + samples_per_peak - 1) / samples_per_peak
                    } else { 0 };

                    let mut peak_data: Vec<f32> = Vec::with_capacity(num_peaks * 2);
                    for i in 0..num_peaks {
                        let frame_start = i * samples_per_peak;
                        let frame_end = ((i + 1) * samples_per_peak).min(total_frames);
                        let mut mn: f32 = 1.0;
                        let mut mx: f32 = -1.0;
                        for f in frame_start..frame_end {
                            let mut sum = 0.0f32;
                            for c in 0..channels.max(1) {
                                let idx = f * channels + c;
                                if idx < samples.len() {
                                    sum += samples[idx];
                                }
                            }
                            let mono = sum / channels.max(1) as f32;
                            if mono < mn { mn = mono; }
                            if mono > mx { mx = mono; }
                        }
                        peak_data.push(mn);
                        peak_data.push(mx);
                    }

                    let bytes: Vec<u8> = peak_data.iter()
                        .flat_map(|f| f.to_le_bytes())
                        .collect();
                    let peaks_b64 = crate::clip_renderer::base64_encode(&bytes);

                    let _ = self.event_tx.try_send(Event::WaveformPeaks {
                        clip_id,
                        sample_rate: sr,
                        peaks_per_second,
                        num_peaks: num_peaks as u32,
                        peaks_b64,
                    });
                } else {
                    log::warn!("GenerateWaveformPeaks: clip '{}' not found", clip_id);
                }
            }

            // -- R5.5: Plugin GUI (v0.0.21.056) -------------------------------
            Command::PluginOpenGui { track_id, slot_index, parent_window_id } => {
                info!("PluginOpenGui: track={}, slot={}, parent=0x{:x}",
                      track_id, slot_index, parent_window_id);
                // PH-4 v0.0.21.091: Try to open native plugin editor
                let mut opened = false;
                {
                    let mut graph = self.graph.lock();
                    if let Some(idx) = graph.find_track_index(&track_id) {
                        if let Some(track) = graph.get_track_mut(idx) {
                            let slot_count = track.plugin_slots.len();
                            if let Some(slot) = track.plugin_slots.get_mut(slot_index as usize) {
                                if let Some(ref mut plugin) = slot.plugin {
                                    info!("PluginOpenGui: found plugin '{}', has_editor={}",
                                          plugin.name(), plugin.has_editor());
                                    if plugin.has_editor() {
                                        match plugin.editor_open(parent_window_id) {
                                            Ok((window_id, width, height)) => {
                                                info!(
                                                    "PluginOpenGui: editor opened, window=0x{:x}, {}x{}",
                                                    window_id, width, height
                                                );
                                                let _ = self.event_tx.try_send(Event::PluginGuiOpened {
                                                    track_id: track_id.clone(),
                                                    slot_index,
                                                    window_id,
                                                    width,
                                                    height,
                                                });
                                                opened = true;
                                            }
                                            Err(e) => {
                                                warn!("PluginOpenGui: editor_open failed: {}", e);
                                            }
                                        }
                                    } else {
                                        info!("PluginOpenGui: plugin has no native editor");
                                    }
                                } else {
                                    warn!("PluginOpenGui: slot {} exists but plugin is None", slot_index);
                                }
                            } else {
                                warn!("PluginOpenGui: slot_index {} out of range (track has {} slots)",
                                      slot_index, slot_count);
                            }
                        } else {
                            warn!("PluginOpenGui: track_mut returned None for idx={}", idx);
                        }
                    } else {
                        warn!("PluginOpenGui: track '{}' not found in graph ({} tracks)",
                              track_id, graph.track_count());
                    }
                }
                if !opened {
                    // Fallback: report window_id=0 so Python uses parameter-only view
                    let _ = self.event_tx.try_send(Event::PluginGuiOpened {
                        track_id: track_id.clone(),
                        slot_index,
                        window_id: 0,
                        width: 800,
                        height: 600,
                    });
                }
            }
            Command::PluginCloseGui { track_id, slot_index } => {
                info!("PluginCloseGui: track={}, slot={}", track_id, slot_index);
                // PH-4.6 v0.0.21.091: Close native editor without unloading plugin
                {
                    let mut graph = self.graph.lock();
                    if let Some(idx) = graph.find_track_index(&track_id) {
                        if let Some(track) = graph.get_track_mut(idx) {
                            if let Some(slot) = track.plugin_slots.get_mut(slot_index as usize) {
                                if let Some(ref mut plugin) = slot.plugin {
                                    plugin.editor_close();
                                }
                            }
                        }
                    }
                }
                let _ = self.event_tx.try_send(Event::PluginGuiClosed {
                    track_id,
                    slot_index,
                });
            }
            Command::PluginResizeGui { track_id, slot_index, width, height } => {
                info!("PluginResizeGui: track={}, slot={}, {}x{}", track_id, slot_index, width, height);
                // PH-4.5 v0.0.21.091: Forward resize to plugin editor
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(slot) = track.plugin_slots.get_mut(slot_index as usize) {
                            if let Some(ref mut plugin) = slot.plugin {
                                plugin.editor_resize(width, height);
                            }
                        }
                    }
                }
            }

            // -- PH-4.7: Plugin Editor Idle (v0.0.21.139) ---------------------
            Command::PluginEditorIdle => {
                // Call editor_idle() on every plugin with an open editor.
                // This is called ~30Hz from the GUI thread via IPC.
                let mut graph = self.graph.lock();
                let tc = graph.track_count();
                for track_idx in 0..tc {
                    if let Some(track) = graph.get_track_mut(track_idx as u16) {
                        for slot in track.plugin_slots.iter_mut() {
                            if let Some(ref mut plugin) = slot.plugin {
                                if plugin.has_editor() {
                                    plugin.editor_idle();
                                }
                            }
                        }
                    }
                }
            }

            // -- PH-5.4: Multi-Output Plugin Routing (v0.0.21.139) ------------
            Command::PluginSetMultiOutput {
                track_id, slot_index, output_count, output_targets,
            } => {
                info!("PluginSetMultiOutput: track={}, slot={}, outputs={}, targets={:?}",
                      track_id, slot_index, output_count, output_targets);
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(slot) = track.plugin_slots.get_mut(slot_index as usize) {
                            slot.multi_output_count = output_count;
                            slot.multi_output_targets = output_targets.clone();
                            info!("PluginSetMultiOutput: configured {} outputs for {}:{}",
                                  output_count, track_id, slot_index);
                        }
                    }
                }
            }

            // -- PH-5.5: Sidechain Input Routing (v0.0.21.139) ----------------
            Command::PluginSetSidechainInput {
                track_id, slot_index, source_track_id,
            } => {
                info!("PluginSetSidechainInput: track={}, slot={}, source={}",
                      track_id, slot_index, source_track_id);
                let mut graph = self.graph.lock();
                if let Some(idx) = graph.find_track_index(&track_id) {
                    if let Some(track) = graph.get_track_mut(idx) {
                        if let Some(slot) = track.plugin_slots.get_mut(slot_index as usize) {
                            slot.sidechain_source_track = if source_track_id.is_empty() {
                                None
                            } else {
                                Some(source_track_id.clone())
                            };
                            info!("PluginSetSidechainInput: sidechain {} → {}:{}",
                                  source_track_id, track_id, slot_index);
                        }
                    }
                }
            }

            // -- R9.3: Performance Benchmark (v0.0.21.056) --------------------
            Command::RequestBenchmark => {
                info!("RequestBenchmark received");
                use std::sync::atomic::Ordering::Relaxed;

                let xruns = self.xrun_count.load(Relaxed);
                let graph = self.graph.lock();
                let active_tracks = graph.track_count() as u32;
                let active_plugins = graph.plugin_count() as u32;
                drop(graph);

                // Get render time from audio output
                let ao = self.audio_output.lock();
                let render_us = ao.shared().render_time_us.load(Relaxed) as f64;
                let s = ao.stats();
                let sr = s.actual_sample_rate;
                let bs = s.actual_buffer_size;
                drop(ao);

                let budget = (bs as f64 / sr as f64) * 1_000_000.0;
                let cpu = if budget > 0.0 { render_us / budget } else { 0.0 };

                let _ = self.event_tx.try_send(Event::PerformanceBenchmark {
                    avg_render_us: render_us,
                    p95_render_us: render_us * 1.3,  // estimate
                    p99_render_us: render_us * 1.6,  // estimate
                    cpu_load: cpu,
                    xrun_count: xruns,
                    buffer_size: bs,
                    sample_rate: sr,
                    active_tracks,
                    active_plugins,
                    duration_secs: 0.0,
                });
            }

            _ => {
                log::debug!("Unhandled command variant in engine dispatcher");
            }
        }
    }

    // UF-4 v0.0.21.143: IPC Command Batching — called from decode_command
    pub fn handle_batch(&mut self, commands: Vec<Command>) {
        let count = commands.len();
        log::debug!("BatchCommands: processing {} commands", count);
        for sub_cmd in commands {
            self.handle_command(sub_cmd);
        }
        log::debug!("BatchCommands: {} commands processed", count);
    }

    /// RA1 v0.0.20.710: Rebuild the entire audio engine state from ProjectSync.
    ///
    /// 1. Rebuilds AudioGraph tracks (clears old, creates new with correct params)
    /// 2. Loads audio clips into ClipStore from base64 data
    /// 3. Builds ArrangementSnapshot (clip placements)
    /// 4. Updates transport (BPM, time sig, loop region)
    /// 5. MIDI notes are stored but require instrument nodes for playback
    fn apply_project_sync(&self, sync: &crate::audio_bridge::ProjectSync) {
        use crate::audio_graph::TrackKind;

        let sr = sync.sample_rate;
        let bpm = sync.bpm;

        // --- 1. Update transport ---
        {
            self.transport.set_bpm(bpm);
            self.transport.set_time_signature(sync.time_sig_num, sync.time_sig_den);
            self.transport.set_loop(
                sync.loop_enabled,
                sync.loop_start_beat,
                sync.loop_end_beat,
            );
            // v0.0.20.736: keep MidiScheduler loop state in sync with transport
            self.midi_scheduler.lock().set_loop(
                sync.loop_enabled,
                sync.loop_start_beat,
                sync.loop_end_beat,
            );
        }

        // --- 2. Rebuild AudioGraph tracks ---
        // v0.0.21.091 MIDI-FIX: Preserve plugin_slots, instruments, and
        // fx_chains across SyncProject rebuild. Previously clear_all_tracks()
        // destroyed all loaded plugins — after rebuild MIDI events dispatched
        // to the correct track_index but found no instrument/plugin → midi=0.
        {
            let mut graph = self.graph.lock();

            // v0.0.21.091: SAVE plugin state BEFORE clearing tracks.
            // Key = track_id (stable across rebuilds, unlike track_index
            // which may shift when tracks are added/removed).
            let mut saved_instruments: std::collections::HashMap<
                String,
                Box<dyn crate::instruments::InstrumentNode>,
            > = std::collections::HashMap::new();
            let mut saved_plugin_slots: std::collections::HashMap<
                String,
                Vec<crate::plugin_host::PluginSlot>,
            > = std::collections::HashMap::new();
            let mut saved_fx_chains: std::collections::HashMap<
                String,
                crate::fx::chain::FxChain,
            > = std::collections::HashMap::new();

            // Extract state from each existing track before destruction
            for (_, track) in graph.tracks.iter_mut() {
                let tid = track.track_id.clone();
                // Take instrument (move out of track)
                if let Some(inst) = track.instrument.take() {
                    info!("MIDI-FIX: Preserving instrument on track '{}'", tid);
                    saved_instruments.insert(tid.clone(), inst);
                }
                // Take plugin_slots (swap with empty Vec)
                if !track.plugin_slots.is_empty() {
                    let slots = std::mem::take(&mut track.plugin_slots);
                    let slot_count = slots.len();
                    let has_plugins = slots.iter().any(|s| s.plugin.is_some());
                    if has_plugins {
                        info!(
                            "MIDI-FIX: Preserving {} plugin_slots ({} with plugins) on track '{}'",
                            slot_count,
                            slots.iter().filter(|s| s.plugin.is_some()).count(),
                            tid
                        );
                    }
                    saved_plugin_slots.insert(tid.clone(), slots);
                }
                // Take fx_chain (swap with empty chain)
                if track.fx_chain.len() > 0 {
                    let chain = std::mem::replace(
                        &mut track.fx_chain,
                        crate::fx::chain::FxChain::new(0),
                    );
                    let fx_count = chain.len();
                    info!(
                        "MIDI-FIX: Preserving {} FX slots on track '{}'",
                        fx_count, tid
                    );
                    saved_fx_chains.insert(tid, chain);
                }
            }

            let _preserved_inst = saved_instruments.len();
            let _preserved_slots = saved_plugin_slots.values()
                .flat_map(|v| v.iter())
                .filter(|s| s.plugin.is_some())
                .count();
            let _preserved_fx = saved_fx_chains.values()
                .map(|c| c.len())
                .sum::<usize>();

            // v0.0.21.045: Clear ALL old tracks before rebuilding.
            // Without this, stale tracks from previous SyncProject persist,
            // causing track_index collisions (e.g. audio track at idx=0
            // collides with old master at idx=0 → audio data silenced).
            graph.clear_all_tracks();

            // Add tracks that don't exist yet, update params for existing
            for tc in &sync.tracks {
                let tk = TrackKind::from_str(&tc.kind);
                let idx = tc.track_index;

                // Check if track exists
                if graph.get_track(idx).is_none() {
                    graph.add_track(tc.track_id.clone(), idx, tk);
                    info!("RA1: Added track {} (idx={}, kind={})", tc.track_id, idx, tc.kind);
                }

                // Apply parameters via TrackNode.set_param
                {
                    use crate::ipc::TrackParam;
                    if let Some(tn) = graph.get_track(idx) {
                        tn.set_param(TrackParam::Volume, tc.volume);
                        tn.set_param(TrackParam::Pan, tc.pan);
                        tn.set_param(TrackParam::Mute, if tc.muted { 1.0 } else { 0.0 });
                        tn.set_param(TrackParam::Solo, if tc.soloed { 1.0 } else { 0.0 });
                    }
                }

                // Group routing
                if let Some(gi) = tc.group_index {
                    graph.set_group_routing(idx, Some(gi));
                }
            }

            // v0.0.21.091 MIDI-FIX: RESTORE preserved plugin state to rebuilt tracks.
            // Match by track_id (stable identifier) rather than track_index (may shift).
            let mut restored_inst = 0u32;
            let mut restored_slots = 0u32;
            let mut restored_fx = 0u32;

            for tc in &sync.tracks {
                if let Some(track) = graph.get_track_mut(tc.track_index) {
                    let tid = &tc.track_id;

                    // Restore instrument (only if track doesn't already have one —
                    // step 6 below may also create built-in instruments)
                    if track.instrument.is_none() {
                        if let Some(inst) = saved_instruments.remove(tid.as_str()) {
                            info!(
                                "MIDI-FIX: Restored instrument on track '{}' (idx={})",
                                tid, tc.track_index
                            );
                            track.instrument = Some(inst);
                            restored_inst += 1;
                        }
                    }

                    // Restore plugin_slots
                    if let Some(slots) = saved_plugin_slots.remove(tid.as_str()) {
                        let count = slots.iter().filter(|s| s.plugin.is_some()).count();
                        if count > 0 {
                            info!(
                                "MIDI-FIX: Restored {} plugin_slots on track '{}' (idx={})",
                                count, tid, tc.track_index
                            );
                        }
                        track.plugin_slots = slots;
                        restored_slots += count as u32;
                    }

                    // Restore fx_chain
                    if let Some(mut chain) = saved_fx_chains.remove(tid.as_str()) {
                        let fc = chain.len();
                        if fc > 0 {
                            // v0.0.21.126 FIX: Reset all internal DSP buffers (delay lines,
                            // filter states, etc.) after restoring the FX chain. Without this,
                            // stale samples in delay buffers cause feedback explosions
                            // (gain → infinity → shrill tone).
                            chain.reset();
                            info!(
                                "MIDI-FIX: Restored {} FX slots on track '{}' (idx={}) [buffers reset]",
                                fc, tid, tc.track_index
                            );
                        }
                        track.fx_chain = chain;
                        restored_fx += fc as u32;
                    }
                }
            }

            // Log any orphaned state (track was removed from project)
            for (tid, _) in &saved_instruments {
                warn!("MIDI-FIX: Orphaned instrument (track '{}' no longer in project)", tid);
            }
            for (tid, slots) in &saved_plugin_slots {
                if slots.iter().any(|s| s.plugin.is_some()) {
                    warn!("MIDI-FIX: Orphaned plugin_slots (track '{}' no longer in project)", tid);
                }
            }
            for (tid, chain) in &saved_fx_chains {
                if chain.len() > 0 {
                    warn!("MIDI-FIX: Orphaned FX chain (track '{}' no longer in project)", tid);
                }
            }

            info!(
                "RA1: AudioGraph rebuilt with {} tracks (preserved: {} instruments, {} plugins, {} FX)",
                sync.tracks.len(), restored_inst, restored_slots, restored_fx
            );
        }

        // --- 3. Load audio clips into ClipStore ---
        {
            let mut loaded = 0u32;
            for cc in &sync.clips {
                if cc.kind == "audio" {
                    if let Some(ref b64) = cc.audio_b64 {
                        if !b64.is_empty() {
                            let clip_sr = cc.source_sr.unwrap_or(sr);
                            let clip_ch = cc.source_channels.unwrap_or(2);
                            match crate::clip_renderer::AudioClipData::from_base64(
                                cc.clip_id.clone(),
                                clip_ch,
                                clip_sr,
                                b64,
                            ) {
                                Ok(clip_data) => {
                                    self.clip_store.insert(clip_data);
                                    loaded += 1;
                                }
                                Err(e) => {
                                    warn!("RA1: Failed to decode clip {}: {}", cc.clip_id, e);
                                }
                            }
                        }
                    }
                }
            }
            if loaded > 0 {
                info!("RA1: Loaded {} audio clips into ClipStore", loaded);
            }
        }

        // --- 4. Build ArrangementSnapshot from clips ---
        {
            use crate::clip_renderer::{PlacedClip, ArrangementSnapshot};

            let sr_f = sr as f64;
            let beat_to_samples = |beat: f64| -> i64 {
                (beat * sr_f * 60.0 / bpm) as i64
            };

            let mut placed: Vec<PlacedClip> = Vec::new();
            for cc in &sync.clips {
                // Find track_index from track_id
                let track_index = sync.tracks.iter()
                    .find(|t| t.track_id == cc.track_id)
                    .map(|t| t.track_index)
                    .unwrap_or(0);

                let start = beat_to_samples(cc.start_beats);
                let end = beat_to_samples(cc.start_beats + cc.length_beats);
                let offset = beat_to_samples(cc.offset_beats);

                placed.push(PlacedClip {
                    clip_id: cc.clip_id.clone(),
                    track_index,
                    start_sample: start,
                    end_sample: end,
                    clip_offset_samples: offset,
                    gain: cc.gain as f32,
                    muted: false,
                });
            }

            let snapshot = ArrangementSnapshot::new(placed);
            self.renderer.set_arrangement(snapshot);
            info!("RA1: ArrangementSnapshot set with {} clips", sync.clips.len());
        }

        // --- 5. Load MIDI notes into scheduler (v0.0.20.725) ---
        // This is THE crucial step: MIDI notes from the arrangement get loaded
        // into the MidiScheduler which will dispatch NoteOn/NoteOff events
        // to the correct instrument nodes during process_audio().
        {
            let mut sched = self.midi_scheduler.lock();
            sched.load_from_sync(&sync.clips, &sync.midi_notes, &sync.tracks);
            if sched.event_count() > 0 {
                info!("RA1: MidiScheduler loaded {} events from {} MIDI notes",
                      sched.event_count(), sync.midi_notes.len());
            }
        }

        // --- 6. Load instruments for tracks that have instrument_type ---
        for tc in &sync.tracks {
            if let Some(ref itype_str) = tc.instrument_type {
                if itype_str.is_empty() {
                    continue;
                }
                let inst_id = tc.instrument_id.clone().unwrap_or_default();
                let inst_id = if inst_id.is_empty() {
                    format!("inst_{}", tc.track_id)
                } else {
                    inst_id
                };
                if let Some(itype) = crate::instruments::InstrumentType::from_str(itype_str) {
                    let mut graph = self.graph.lock();
                    let buf_size = graph.buffer_size();
                    if let Some(track) = graph.get_track_mut(tc.track_index) {
                        // Only create if not already loaded
                        if track.instrument.is_none() {
                            if let Some(inst) = itype.create(inst_id.clone(), sr, buf_size) {
                                track.instrument = Some(inst);
                                info!("RA1: Loaded instrument '{}' (type={}) on track '{}'",
                                      inst_id, itype_str, tc.track_id);
                            }
                        }
                    }
                }
            }
        }

        info!("RA1: ProjectSync applied (seq={}, bpm={}, {} tracks, {} clips)",
              sync.sync_seq, bpm, sync.tracks.len(), sync.clips.len());
    }

    /// Called from the audio callback. Processes the graph and returns output.
    /// The output samples should be written to the audio device.
    pub fn process_audio(&self, output: &mut [f32], frames: usize, channels: usize) {
        let t_start = std::time::Instant::now();

        // 1. Drain pending commands
        self.drain_commands();

        // 2. Drain lock-free parameter ring (GUI → audio thread)
        {
            let graph = self.graph.lock();
            self.param_ring.drain(|param_id, value| {
                // Decode param_id: high 16 bits = track_index, low 16 bits = param type
                let track_idx = (param_id >> 16) as u16;
                let param_type = (param_id & 0xFFFF) as u16;
                if let Some(track) = graph.get_track(track_idx) {
                    match param_type {
                        0 => track.set_param(crate::ipc::TrackParam::Volume, value),
                        1 => track.set_param(crate::ipc::TrackParam::Pan, value),
                        2 => track.set_param(crate::ipc::TrackParam::Mute, value),
                        3 => track.set_param(crate::ipc::TrackParam::Solo, value),
                        _ => {}
                    }
                }
            });
        }

        // 3. Render arrangement clips + MIDI into track buffers
        {
            let mut graph = self.graph.lock();
            graph.silence_all();

            let is_playing = self.transport.playing.load(std::sync::atomic::Ordering::Relaxed);

            // Phase 1B: Render audio clips from ArrangementRenderer
            let position = self.transport.position_samples();
            let sr = graph.sample_rate;
            if is_playing {
                self.renderer.render_all_tracks(&mut graph, position, frames, sr);
            }

            // v0.0.20.725: Dispatch MIDI notes from arrangement clips to instruments.
            // This is the bridge between "MIDI data in project" and "instrument audio output".
            if is_playing {
                let bpm = graph.tempo_bpm as f64;
                let sr_f = sr as f64;
                let beat_start = self.transport.position_beats();
                let beats_per_buffer = if bpm > 0.0 && sr_f > 0.0 {
                    (frames as f64 / sr_f) * (bpm / 60.0)
                } else {
                    0.0
                };
                let beat_end = beat_start + beats_per_buffer;

                let mut sched = self.midi_scheduler.lock();
                for evt in sched.schedule_for_buffer(beat_start, beat_end, true) {
                    if let Some(track) = graph.get_track_mut(evt.track_index) {
                        if let Some(ref mut inst) = track.instrument {
                            if evt.is_note_on {
                                inst.push_midi(crate::instruments::MidiEvent::NoteOn {
                                    note: evt.pitch,
                                    velocity: evt.velocity,
                                });
                            } else {
                                inst.push_midi(crate::instruments::MidiEvent::NoteOff {
                                    note: evt.pitch,
                                });
                            }
                        }
                        // PH-3: Route arrangement MIDI to external instrument plugins
                        for slot in &mut track.plugin_slots {
                            if evt.is_note_on {
                                slot.midi_note_on(evt.pitch, (evt.velocity * 127.0).clamp(0.0, 127.0) as u8);
                            } else {
                                slot.midi_note_off(evt.pitch);
                            }
                        }
                    }
                }
            }

            // 4. Process the audio graph (instruments + FX + volume/pan/mute/solo → master)
            let master_buf = graph.process();

            // 5. Copy master output to device buffer
            let copy_len = (frames * channels).min(output.len()).min(master_buf.data.len());
            output[..copy_len].copy_from_slice(&master_buf.data[..copy_len]);

            // Zero any remaining output samples
            if copy_len < output.len() {
                output[copy_len..].fill(0.0);
            }

            // 4. Send meter levels (~30Hz)
            let counter = self
                .meter_counter
                .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            let sr = self.transport.sample_rate() as u32;
            let meter_interval = if sr > 0 { sr / (frames as u32 * 30).max(1) } else { 50 };

            if counter % meter_interval.max(1) == 0 {
                // Master meters
                let (pl, pr) = master_buf.peak_levels();
                let (rl, rr) = master_buf.rms_levels();
                let _ = self.event_tx.try_send(Event::MasterMeterLevel {
                    peak_l: pl,
                    peak_r: pr,
                    rms_l: rl,
                    rms_r: rr,
                });

                // Track meters
                let track_meters: Vec<TrackMeterLevel> = graph
                    .all_track_meters()
                    .into_iter()
                    .map(|(idx, pl, pr, rl, rr)| TrackMeterLevel {
                        track_index: idx,
                        peak_l: pl,
                        peak_r: pr,
                        rms_l: rl,
                        rms_r: rr,
                    })
                    .collect();

                if !track_meters.is_empty() {
                    let _ = self.event_tx.try_send(Event::MeterLevels {
                        levels: track_meters,
                    });
                }
            }
        }

        // 5. Advance transport
        self.transport.advance(frames);

        // 6. Send playhead position (~30Hz, reuse meter counter)
        let counter = self
            .meter_counter
            .load(std::sync::atomic::Ordering::Relaxed);
        let sr = self.transport.sample_rate() as u32;
        let meter_interval = if sr > 0 {
            sr / (frames as u32 * 30).max(1)
        } else {
            50
        };
        if counter % meter_interval.max(1) == 0 {
            let _ = self.event_tx.try_send(Event::PlayheadPosition {
                beat: self.transport.position_beats(),
                sample_position: self.transport.position_samples(),
                is_playing: self
                    .transport
                    .playing
                    .load(std::sync::atomic::Ordering::Relaxed),
            });
        }

        // 7. Store render time for Pong cpu_load reporting
        let elapsed_us = t_start.elapsed().as_micros() as u32;
        self.last_render_us.store(elapsed_us, std::sync::atomic::Ordering::Relaxed);
    }

    /// Record an xrun.
    pub fn record_xrun(&self) {
        self.xrun_count
            .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    }
}

// v0.0.21.032: Helper functions for subprocess-safe plugin scanning
// -----------------------------------------------------------------

/// Recursively find directories with a given extension (e.g. ".vst3" bundles).
fn find_bundles_recursive(dir: &std::path::Path, ext: &str) -> Vec<std::path::PathBuf> {
    let mut result = Vec::new();
    if let Ok(entries) = std::fs::read_dir(dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_dir() {
                if path.extension().map(|e| e.to_ascii_lowercase() == ext).unwrap_or(false) {
                    result.push(path);
                } else {
                    result.extend(find_bundles_recursive(&path, ext));
                }
            }
        }
    }
    result
}

/// Recursively find files with a given extension (e.g. ".clap").
fn find_files_recursive(dir: &std::path::Path, ext: &str) -> Vec<std::path::PathBuf> {
    let mut result = Vec::new();
    if let Ok(entries) = std::fs::read_dir(dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_dir() {
                result.extend(find_files_recursive(&path, ext));
            } else if path.extension().map(|e| e.to_ascii_lowercase() == ext).unwrap_or(false) {
                result.push(path);
            }
        }
    }
    result
}

/// Parse JSON output from --probe-plugin vst3
fn parse_probe_json_vst3(
    json: &str,
    bundle_path: &std::path::Path,
    out: &mut Vec<crate::ipc::ScannedPlugin>,
) {
    // Minimal JSON parsing — no serde dependency needed
    // Expected: {"plugins":[{"name":"...","vendor":"...","class_id":"...","category":"...","ai":N,"ao":N},...]}
    // or {"error":"..."}
    if json.contains("\"error\"") { return; }
    // Split on },{ to get individual plugin entries
    let plugins_start = match json.find("[{") { Some(i) => i + 1, None => return };
    let plugins_end = match json.rfind("}]") { Some(i) => i + 1, None => return };
    let plugins_str = &json[plugins_start..plugins_end];
    for entry in plugins_str.split("},{") {
        let entry = entry.trim_start_matches('{').trim_end_matches('}');
        let name = extract_json_string(entry, "name").unwrap_or_default();
        let vendor = extract_json_string(entry, "vendor").unwrap_or_default();
        let class_id = extract_json_string(entry, "class_id").unwrap_or_default();
        let category = extract_json_string(entry, "category").unwrap_or_default();
        let ai = extract_json_int(entry, "ai").unwrap_or(1);
        let ao = extract_json_int(entry, "ao").unwrap_or(1);
        out.push(crate::ipc::ScannedPlugin {
            format: "vst3".to_string(),
            name, vendor, plugin_id: class_id,
            path: bundle_path.to_string_lossy().to_string(),
            category, audio_inputs: ai, audio_outputs: ao,
        });
    }
}

/// Parse JSON output from --probe-plugin clap
fn parse_probe_json_clap(
    json: &str,
    file_path: &std::path::Path,
    out: &mut Vec<crate::ipc::ScannedPlugin>,
) {
    if json.contains("\"error\"") { return; }
    let plugins_start = match json.find("[{") { Some(i) => i + 1, None => return };
    let plugins_end = match json.rfind("}]") { Some(i) => i + 1, None => return };
    let plugins_str = &json[plugins_start..plugins_end];
    for entry in plugins_str.split("},{") {
        let entry = entry.trim_start_matches('{').trim_end_matches('}');
        let name = extract_json_string(entry, "name").unwrap_or_default();
        let vendor = extract_json_string(entry, "vendor").unwrap_or_default();
        let plugin_id = extract_json_string(entry, "plugin_id").unwrap_or_default();
        // features array — just use as category
        let features = extract_json_string(entry, "features").unwrap_or_default();
        out.push(crate::ipc::ScannedPlugin {
            format: "clap".to_string(),
            name, vendor, plugin_id,
            path: file_path.to_string_lossy().to_string(),
            category: features,
            audio_inputs: 1, audio_outputs: 1,
        });
    }
}

/// Extract a JSON string value by key (minimal parser, no serde needed).
fn extract_json_string(json: &str, key: &str) -> Option<String> {
    let pattern = format!("\"{}\":\"", key);
    let start = json.find(&pattern)? + pattern.len();
    let rest = &json[start..];
    // Find closing " that isn't escaped
    let mut end = 0;
    let mut escaped = false;
    for (i, c) in rest.char_indices() {
        if escaped { escaped = false; continue; }
        if c == '\\' { escaped = true; continue; }
        if c == '"' { end = i; break; }
    }
    Some(rest[..end].replace("\\\"", "\"").replace("\\\\", "\\"))
}

/// Extract a JSON integer value by key.
fn extract_json_int(json: &str, key: &str) -> Option<u32> {
    let pattern = format!("\"{}\":", key);
    let start = json.find(&pattern)? + pattern.len();
    let rest = json[start..].trim_start();
    let num_end = rest.find(|c: char| !c.is_ascii_digit()).unwrap_or(rest.len());
    rest[..num_end].parse().ok()
}
