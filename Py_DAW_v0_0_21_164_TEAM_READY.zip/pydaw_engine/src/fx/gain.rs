// Gain FX — Simple gain/volume control
// v0.0.21.084

use crate::audio_graph::AudioBuffer;

pub struct Gain {
    gain_linear: f32,
    gain_db: f32,
    sample_rate: f32,
}

impl Gain {
    pub fn new(sample_rate: f32) -> Self {
        Self { gain_linear: 1.0, gain_db: 0.0, sample_rate }
    }

    pub fn set_sample_rate(&mut self, sr: f32) { self.sample_rate = sr; }
    pub fn reset(&mut self) {}

    pub fn process(&mut self, buffer: &mut AudioBuffer) {
        if (self.gain_linear - 1.0).abs() < 0.0001 { return; }
        let g = self.gain_linear;
        for s in buffer.data.iter_mut() { *s *= g; }
    }

    pub fn set_param_by_name(&mut self, name: &str, value: f64) {
        match name {
            "gain_db" => {
                self.gain_db = (value as f32).clamp(-60.0, 24.0);
                self.gain_linear = 10.0f32.powf(self.gain_db / 20.0);
            }
            "gain" => { self.gain_linear = (value as f32).clamp(0.0, 16.0); }
            _ => {}
        }
    }

    pub fn get_param_by_name(&self, name: &str) -> Option<f64> {
        match name {
            "gain_db" => Some(self.gain_db as f64),
            "gain" => Some(self.gain_linear as f64),
            _ => None,
        }
    }

    pub fn param_name_list(&self) -> &[&str] { &["gain_db", "gain"] }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn test_gain_unity() {
        let mut g = Gain::new(48000.0);
        let mut buf = AudioBuffer::new(64, 2);
        buf.data[0] = 0.5;
        g.process(&mut buf);
        assert!((buf.data[0] - 0.5).abs() < 0.001);
    }
    #[test]
    fn test_gain_6db() {
        let mut g = Gain::new(48000.0);
        g.set_param_by_name("gain_db", 6.0);
        let mut buf = AudioBuffer::new(64, 2);
        buf.data[0] = 0.25;
        g.process(&mut buf);
        assert!(buf.data[0] > 0.49); // ~2x
    }
}
