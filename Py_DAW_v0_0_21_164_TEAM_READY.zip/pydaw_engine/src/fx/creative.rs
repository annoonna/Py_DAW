// ============================================================================
// Bitcrusher FX — v0.0.20.972 (RM3.2)
// ============================================================================

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BitcrusherParams {
    pub bit_depth: f32,       // 1..32 (continuously variable)
    pub sample_rate: f32,     // target sample rate for decimation
    pub wet_dry: f32,         // 0..1
}

impl Default for BitcrusherParams {
    fn default() -> Self {
        Self { bit_depth: 8.0, sample_rate: 8000.0, wet_dry: 1.0 }
    }
}

pub struct Bitcrusher {
    params: BitcrusherParams,
    hold_l: f32,
    hold_r: f32,
    counter: f32,
    host_sr: f32,
}

impl Bitcrusher {
    pub fn new(sample_rate: f32) -> Self {
        Self {
            params: BitcrusherParams::default(),
            hold_l: 0.0, hold_r: 0.0,
            counter: 0.0, host_sr: sample_rate,
        }
    }

    pub fn set_params(&mut self, p: BitcrusherParams) { self.params = p; }

    pub fn process_stereo(&mut self, left: &mut [f32], right: &mut [f32]) {
        let step = self.host_sr / self.params.sample_rate.max(100.0);
        let levels = 2.0_f32.powf(self.params.bit_depth.clamp(1.0, 32.0));
        let inv = 1.0 / levels;
        let wet = self.params.wet_dry;
        let dry = 1.0 - wet;

        for i in 0..left.len().min(right.len()) {
            self.counter += 1.0;
            if self.counter >= step {
                self.counter -= step;
                // Quantize to bit depth
                self.hold_l = (left[i] * levels).round() * inv;
                self.hold_r = (right[i] * levels).round() * inv;
            }
            left[i] = left[i] * dry + self.hold_l * wet;
            right[i] = right[i] * dry + self.hold_r * wet;
        }
    }
}

// ============================================================================
// Ring Modulator FX
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RingModParams {
    pub frequency: f32,       // modulator frequency Hz
    pub depth: f32,           // 0..1
    pub waveform: ModWaveform,
    pub wet_dry: f32,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum ModWaveform {
    Sine,
    Square,
    Triangle,
    Saw,
}

impl Default for RingModParams {
    fn default() -> Self {
        Self { frequency: 440.0, depth: 1.0, waveform: ModWaveform::Sine, wet_dry: 1.0 }
    }
}

pub struct RingModulator {
    params: RingModParams,
    phase: f64,
    sample_rate: f64,
}

impl RingModulator {
    pub fn new(sample_rate: f32) -> Self {
        Self {
            params: RingModParams::default(),
            phase: 0.0,
            sample_rate: sample_rate as f64,
        }
    }

    pub fn set_params(&mut self, p: RingModParams) { self.params = p; }

    pub fn process_stereo(&mut self, left: &mut [f32], right: &mut [f32]) {
        let inc = self.params.frequency as f64 / self.sample_rate;
        let depth = self.params.depth;
        let wet = self.params.wet_dry;
        let dry = 1.0 - wet;

        for i in 0..left.len().min(right.len()) {
            let mod_val = self.oscillator() as f32;
            let mod_factor = 1.0 - depth + depth * mod_val;

            left[i] = left[i] * dry + left[i] * mod_factor * wet;
            right[i] = right[i] * dry + right[i] * mod_factor * wet;

            self.phase += inc;
            if self.phase >= 1.0 { self.phase -= 1.0; }
        }
    }

    fn oscillator(&self) -> f64 {
        let p = self.phase;
        match self.params.waveform {
            ModWaveform::Sine => (p * std::f64::consts::TAU).sin(),
            ModWaveform::Square => if p < 0.5 { 1.0 } else { -1.0 },
            ModWaveform::Triangle => {
                if p < 0.25 { p * 4.0 }
                else if p < 0.75 { 2.0 - p * 4.0 }
                else { p * 4.0 - 4.0 }
            }
            ModWaveform::Saw => 2.0 * p - 1.0,
        }
    }
}

// ============================================================================
// Granular Processor — v0.0.20.977 (RM3.2)
// ============================================================================
//
// Granular synthesis-based audio effect. Chops audio into small grains,
// windows them, and reassembles with variable pitch, position, density.

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GranularParams {
    /// Grain size in ms (10–500)
    pub grain_size_ms: f32,
    /// Grain density (grains per second, 1–100)
    pub density: f32,
    /// Pitch shift per grain (semitones, -24 to +24)
    pub pitch_shift: f32,
    /// Position jitter (0 = sequential, 1 = fully random)
    pub position_jitter: f32,
    /// Grain scatter (stereo spread, 0–1)
    pub scatter: f32,
    /// Feedback (0–0.95)
    pub feedback: f32,
    /// Wet/dry mix
    pub wet_dry: f32,
    /// Reverse grains probability (0–1)
    pub reverse_prob: f32,
}

impl Default for GranularParams {
    fn default() -> Self {
        Self {
            grain_size_ms: 80.0, density: 20.0, pitch_shift: 0.0,
            position_jitter: 0.1, scatter: 0.3, feedback: 0.0,
            wet_dry: 0.5, reverse_prob: 0.0,
        }
    }
}

/// A single grain.
struct Grain {
    /// Source position in the buffer (samples)
    source_pos: usize,
    /// Current playback position within the grain
    play_pos: f64,
    /// Playback rate (for pitch shift)
    rate: f64,
    /// Grain length in samples
    length: usize,
    /// Stereo pan (-1..+1)
    pan: f32,
    /// Is this grain active?
    active: bool,
    /// Play in reverse?
    reverse: bool,
    /// Amplitude
    amplitude: f32,
}

impl Grain {
    fn new() -> Self {
        Self {
            source_pos: 0, play_pos: 0.0, rate: 1.0,
            length: 0, pan: 0.0, active: false,
            reverse: false, amplitude: 1.0,
        }
    }

    /// Hanning window at position t (0..1).
    #[inline]
    fn window(t: f32) -> f32 {
        0.5 * (1.0 - (t * std::f32::consts::TAU).cos())
    }
}

pub struct GranularProcessor {
    params: GranularParams,
    /// Circular input buffer
    buffer: Vec<f32>,
    /// Buffer write position
    write_pos: usize,
    /// Buffer capacity (samples, mono)
    capacity: usize,
    /// Pre-allocated grain pool
    grains: Vec<Grain>,
    /// Next grain spawn timer (samples)
    spawn_counter: f32,
    /// Sample rate
    sample_rate: f32,
    /// Simple LCG random state
    rng_state: u32,
}

impl GranularProcessor {
    pub fn new(sample_rate: f32) -> Self {
        let capacity = (sample_rate * 2.0) as usize; // 2 second buffer
        let max_grains = 64;
        Self {
            params: GranularParams::default(),
            buffer: vec![0.0; capacity],
            write_pos: 0,
            capacity,
            grains: (0..max_grains).map(|_| Grain::new()).collect(),
            spawn_counter: 0.0,
            sample_rate,
            rng_state: 12345,
        }
    }

    pub fn set_params(&mut self, p: GranularParams) { self.params = p; }

    /// Simple LCG random (0.0–1.0).
    fn rand(&mut self) -> f32 {
        self.rng_state = self.rng_state.wrapping_mul(1664525).wrapping_add(1013904223);
        (self.rng_state >> 8) as f32 / 16777216.0
    }

    fn spawn_grain(&mut self) {
        // Pre-calculate random values before borrowing grains
        let grain_samples = (self.params.grain_size_ms * self.sample_rate / 1000.0) as usize;
        let r1 = self.rand();
        let r2 = self.rand();
        let r3 = self.rand();
        let r4 = self.rand();
        let jitter = (r1 * self.params.position_jitter * self.capacity as f32) as usize;
        let source = if self.write_pos >= jitter { self.write_pos - jitter } else { self.capacity - jitter + self.write_pos };
        let pan = (r2 * 2.0 - 1.0) * self.params.scatter;
        let reverse = r3 < self.params.reverse_prob;
        let amplitude = 0.7 + r4 * 0.3;
        let rate = 2.0_f64.powf(self.params.pitch_shift as f64 / 12.0);

        // Now borrow grains
        if let Some(grain) = self.grains.iter_mut().find(|g| !g.active) {
            grain.source_pos = source % self.capacity;
            grain.play_pos = 0.0;
            grain.rate = rate;
            grain.length = grain_samples.max(1);
            grain.pan = pan;
            grain.active = true;
            grain.reverse = reverse;
            grain.amplitude = amplitude;
        }
    }

    pub fn process_stereo(&mut self, left: &mut [f32], right: &mut [f32]) {
        let frames = left.len().min(right.len());
        let spawn_interval = self.sample_rate / self.params.density.max(0.5);
        let wet = self.params.wet_dry;
        let dry = 1.0 - wet;

        for i in 0..frames {
            // Write input to circular buffer (mono mix)
            let input_mono = (left[i] + right[i]) * 0.5;
            self.buffer[self.write_pos] = input_mono + self.buffer[self.write_pos] * self.params.feedback.min(0.95);
            self.write_pos = (self.write_pos + 1) % self.capacity;

            // Spawn new grains
            self.spawn_counter += 1.0;
            if self.spawn_counter >= spawn_interval {
                self.spawn_counter -= spawn_interval;
                self.spawn_grain();
            }

            // Sum active grains
            let mut out_l = 0.0f32;
            let mut out_r = 0.0f32;

            for grain in self.grains.iter_mut() {
                if !grain.active { continue; }

                let t = grain.play_pos as f32 / grain.length as f32;
                if t >= 1.0 {
                    grain.active = false;
                    continue;
                }

                let win = Grain::window(t);
                let read_pos = if grain.reverse {
                    (grain.source_pos + grain.length - grain.play_pos as usize) % self.capacity
                } else {
                    (grain.source_pos + grain.play_pos as usize) % self.capacity
                };

                let sample = self.buffer[read_pos] * win * grain.amplitude;
                let pan_l = ((1.0 - grain.pan) * 0.5).sqrt();
                let pan_r = ((1.0 + grain.pan) * 0.5).sqrt();

                out_l += sample * pan_l;
                out_r += sample * pan_r;

                grain.play_pos += grain.rate;
            }

            left[i] = left[i] * dry + out_l * wet;
            right[i] = right[i] * dry + out_r * wet;
        }
    }
}

// ============================================================================
// Glitch/Stutter FX — v0.0.20.977 (RM3.2)
// ============================================================================
//
// Captures audio into a buffer, then replays slices with various mutations:
// stutter (repeat), reverse, half-speed, tape-stop, gate.

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum GlitchMode {
    /// Repeat the current slice
    Stutter,
    /// Play slice in reverse
    Reverse,
    /// Play at half speed
    HalfSpeed,
    /// Tape-stop effect (slow down to zero)
    TapeStop,
    /// Random gate (chop signal)
    Gate,
    /// Shuffle slice order
    Shuffle,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GlitchParams {
    /// Slice size in beats (1/16, 1/8, 1/4, 1/2, 1)
    pub slice_beats: f32,
    /// Current mode
    pub mode: GlitchMode,
    /// Probability of glitch per slice (0–1)
    pub probability: f32,
    /// Number of stutter repeats (1–16)
    pub repeats: u32,
    /// Wet/dry mix
    pub wet_dry: f32,
    /// Gate width (0.1–1.0, for Gate mode)
    pub gate_width: f32,
}

impl Default for GlitchParams {
    fn default() -> Self {
        Self {
            slice_beats: 0.25, mode: GlitchMode::Stutter,
            probability: 0.5, repeats: 4, wet_dry: 1.0, gate_width: 0.5,
        }
    }
}

pub struct GlitchStutter {
    params: GlitchParams,
    /// Capture buffer (stereo interleaved)
    buffer: Vec<f32>,
    /// Buffer write position
    write_pos: usize,
    /// Slice length in samples
    slice_samples: usize,
    /// Current position within the slice
    slice_pos: usize,
    /// Current repeat counter
    repeat_count: u32,
    /// Whether currently glitching
    glitching: bool,
    /// Tape-stop deceleration position
    tape_pos: f64,
    /// Tape-stop current rate
    tape_rate: f64,
    /// Sample rate
    sample_rate: f32,
    /// BPM for beat-sync
    bpm: f64,
    /// RNG state
    rng_state: u32,
}

impl GlitchStutter {
    pub fn new(sample_rate: f32, bpm: f64) -> Self {
        let slice_samples = (60.0 / bpm * 0.25 * sample_rate as f64) as usize;
        Self {
            params: GlitchParams::default(),
            buffer: vec![0.0; slice_samples * 2 * 4], // 4 slices stereo
            write_pos: 0,
            slice_samples,
            slice_pos: 0,
            repeat_count: 0,
            glitching: false,
            tape_pos: 0.0,
            tape_rate: 1.0,
            sample_rate,
            bpm,
            rng_state: 54321,
        }
    }

    pub fn set_params(&mut self, p: GlitchParams) {
        self.slice_samples = (60.0 / self.bpm * p.slice_beats as f64 * self.sample_rate as f64) as usize;
        self.slice_samples = self.slice_samples.max(64);
        self.params = p;
        // Resize buffer if needed
        let needed = self.slice_samples * 2 * 4;
        if self.buffer.len() < needed {
            self.buffer.resize(needed, 0.0);
        }
    }

    pub fn set_bpm(&mut self, bpm: f64) {
        self.bpm = bpm;
        self.slice_samples = (60.0 / bpm * self.params.slice_beats as f64 * self.sample_rate as f64) as usize;
        self.slice_samples = self.slice_samples.max(64);
    }

    fn rand(&mut self) -> f32 {
        self.rng_state = self.rng_state.wrapping_mul(1664525).wrapping_add(1013904223);
        (self.rng_state >> 8) as f32 / 16777216.0
    }

    pub fn process_stereo(&mut self, left: &mut [f32], right: &mut [f32]) {
        let frames = left.len().min(right.len());
        let wet = self.params.wet_dry;
        let dry = 1.0 - wet;

        for i in 0..frames {
            // Write to capture buffer
            let buf_pos = (self.write_pos % (self.slice_samples * 4)) * 2;
            if buf_pos + 1 < self.buffer.len() {
                self.buffer[buf_pos] = left[i];
                self.buffer[buf_pos + 1] = right[i];
            }
            self.write_pos += 1;

            // Check slice boundary
            self.slice_pos += 1;
            if self.slice_pos >= self.slice_samples {
                self.slice_pos = 0;
                // Decide whether to glitch
                if self.rand() < self.params.probability {
                    self.glitching = true;
                    self.repeat_count = 0;
                    self.tape_pos = 0.0;
                    self.tape_rate = 1.0;
                } else {
                    self.glitching = false;
                }
            }

            if self.glitching {
                let read_idx = match self.params.mode {
                    GlitchMode::Stutter => {
                        self.slice_pos % self.slice_samples
                    }
                    GlitchMode::Reverse => {
                        self.slice_samples.saturating_sub(1 + self.slice_pos)
                    }
                    GlitchMode::HalfSpeed => {
                        (self.slice_pos / 2) % self.slice_samples
                    }
                    GlitchMode::TapeStop => {
                        let idx = self.tape_pos as usize;
                        self.tape_rate *= 0.9997; // decelerate
                        self.tape_pos += self.tape_rate;
                        idx.min(self.slice_samples - 1)
                    }
                    GlitchMode::Gate => {
                        if (self.slice_pos as f32 / self.slice_samples as f32) < self.params.gate_width {
                            self.slice_pos
                        } else {
                            usize::MAX // silence
                        }
                    }
                    GlitchMode::Shuffle => {
                        // Jump to random position within slice
                        let offset = ((self.rand() * 4.0) as usize) * (self.slice_samples / 4);
                        (self.slice_pos + offset) % self.slice_samples
                    }
                };

                if read_idx < self.slice_samples {
                    let buf_read = (read_idx % (self.slice_samples * 4)) * 2;
                    if buf_read + 1 < self.buffer.len() {
                        left[i] = left[i] * dry + self.buffer[buf_read] * wet;
                        right[i] = right[i] * dry + self.buffer[buf_read + 1] * wet;
                    }
                } else {
                    // Gate silence
                    left[i] *= dry;
                    right[i] *= dry;
                }
            }
        }
    }
}

// ============================================================================
// Vocoder FX — v0.0.20.977 (RM3.2)
// ============================================================================
//
// Classic channel vocoder: analyses the spectrum of a modulator (voice)
// and applies it to a carrier (synth), producing the "talking synth" effect.
// Uses a bank of bandpass filters.

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VocoderParams {
    /// Number of frequency bands (4–32)
    pub num_bands: u32,
    /// Lowest frequency (Hz)
    pub low_freq: f32,
    /// Highest frequency (Hz)
    pub high_freq: f32,
    /// Envelope follower attack (ms)
    pub attack_ms: f32,
    /// Envelope follower release (ms)
    pub release_ms: f32,
    /// Band Q factor
    pub q_factor: f32,
    /// Wet/dry mix
    pub wet_dry: f32,
    /// Use internal carrier (noise/saw)
    pub internal_carrier: bool,
    /// Internal carrier type
    pub carrier_type: CarrierType,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum CarrierType {
    WhiteNoise,
    PinkNoise,
    Saw,
    Square,
    Pulse,
}

impl Default for VocoderParams {
    fn default() -> Self {
        Self {
            num_bands: 16, low_freq: 100.0, high_freq: 8000.0,
            attack_ms: 5.0, release_ms: 20.0, q_factor: 5.0,
            wet_dry: 1.0, internal_carrier: false, carrier_type: CarrierType::Saw,
        }
    }
}

/// One vocoder band: bandpass filter + envelope follower.
struct VocoderBand {
    // Analysis (modulator) filter state — biquad DF2T
    a_z1: f32, a_z2: f32,
    // Synthesis (carrier) filter state
    s_z1: f32, s_z2: f32,
    // Biquad coefficients
    b0: f32, b1: f32, b2: f32, a1: f32, a2: f32,
    // Envelope follower
    envelope: f32,
    attack_coeff: f32,
    release_coeff: f32,
    // Band frequency
    center_freq: f32,
}

impl VocoderBand {
    fn new(freq: f32, q: f32, sample_rate: f32, attack_ms: f32, release_ms: f32) -> Self {
        // Bandpass biquad coefficients
        let w0 = std::f32::consts::TAU * freq / sample_rate;
        let alpha = w0.sin() / (2.0 * q);
        let a0_inv = 1.0 / (1.0 + alpha);

        let b0 = alpha * a0_inv;
        let b1 = 0.0;
        let b2 = -alpha * a0_inv;
        let a1 = -2.0 * w0.cos() * a0_inv;
        let a2 = (1.0 - alpha) * a0_inv;

        let attack_coeff = (-1.0 / (attack_ms * sample_rate / 1000.0)).exp();
        let release_coeff = (-1.0 / (release_ms * sample_rate / 1000.0)).exp();

        Self {
            a_z1: 0.0, a_z2: 0.0, s_z1: 0.0, s_z2: 0.0,
            b0, b1, b2, a1, a2,
            envelope: 0.0, attack_coeff, release_coeff,
            center_freq: freq,
        }
    }

    /// Filter one sample through the analysis path and update envelope.
    #[inline]
    fn analyze(&mut self, input: f32) -> f32 {
        let _out = self.b0 * input + self.b1 * self.a_z1 + self.b2 * self.a_z2
                - self.a1 * self.a_z1 - self.a2 * self.a_z2;
        // Simplified: use direct form I for analysis
        let filtered = self.b0 * input + self.a_z1;
        self.a_z1 = self.b1 * input - self.a1 * filtered + self.a_z2;
        self.a_z2 = self.b2 * input - self.a2 * filtered;

        // Envelope follower
        let abs_val = filtered.abs();
        if abs_val > self.envelope {
            self.envelope = self.attack_coeff * self.envelope + (1.0 - self.attack_coeff) * abs_val;
        } else {
            self.envelope = self.release_coeff * self.envelope + (1.0 - self.release_coeff) * abs_val;
        }

        filtered
    }

    /// Filter one sample through the synthesis path and apply envelope.
    #[inline]
    fn synthesize(&mut self, carrier: f32) -> f32 {
        let filtered = self.b0 * carrier + self.s_z1;
        self.s_z1 = self.b1 * carrier - self.a1 * filtered + self.s_z2;
        self.s_z2 = self.b2 * carrier - self.a2 * filtered;

        filtered * self.envelope
    }
}

pub struct Vocoder {
    params: VocoderParams,
    bands: Vec<VocoderBand>,
    sample_rate: f32,
    /// Internal carrier oscillator phase
    carrier_phase: f64,
    /// RNG for noise carrier
    rng_state: u32,
}

impl Vocoder {
    pub fn new(sample_rate: f32) -> Self {
        let params = VocoderParams::default();
        let bands = Self::create_bands(&params, sample_rate);
        Self { params, bands, sample_rate, carrier_phase: 0.0, rng_state: 99999 }
    }

    pub fn set_params(&mut self, p: VocoderParams) {
        self.bands = Self::create_bands(&p, self.sample_rate);
        self.params = p;
    }

    fn create_bands(params: &VocoderParams, sample_rate: f32) -> Vec<VocoderBand> {
        let n = params.num_bands.clamp(4, 32) as usize;
        let log_low = params.low_freq.max(20.0).ln();
        let log_high = params.high_freq.min(sample_rate * 0.45).ln();

        (0..n).map(|i| {
            let t = i as f32 / (n - 1).max(1) as f32;
            let freq = (log_low + t * (log_high - log_low)).exp();
            VocoderBand::new(freq, params.q_factor, sample_rate, params.attack_ms, params.release_ms)
        }).collect()
    }

    fn rand(&mut self) -> f32 {
        self.rng_state = self.rng_state.wrapping_mul(1664525).wrapping_add(1013904223);
        (self.rng_state >> 8) as f32 / 16777216.0 * 2.0 - 1.0
    }

    fn internal_carrier_sample(&mut self, freq: f64) -> f32 {
        let inc = freq / self.sample_rate as f64;
        self.carrier_phase += inc;
        if self.carrier_phase >= 1.0 { self.carrier_phase -= 1.0; }
        let p = self.carrier_phase;

        match self.params.carrier_type {
            CarrierType::WhiteNoise => self.rand(),
            CarrierType::PinkNoise => self.rand() * 0.7, // simplified
            CarrierType::Saw => (2.0 * p - 1.0) as f32,
            CarrierType::Square => if p < 0.5 { 1.0 } else { -1.0 },
            CarrierType::Pulse => if p < 0.25 { 1.0 } else { -1.0 },
        }
    }

    /// Process stereo: left = modulator (voice), right = carrier (synth).
    /// If internal_carrier is true, right input is ignored.
    pub fn process_stereo(&mut self, left: &mut [f32], right: &mut [f32]) {
        let frames = left.len().min(right.len());
        let wet = self.params.wet_dry;
        let dry = 1.0 - wet;

        for i in 0..frames {
            let modulator = left[i];
            let carrier = if self.params.internal_carrier {
                self.internal_carrier_sample(130.81) // C3
            } else {
                right[i]
            };

            let mut out = 0.0f32;
            for band in self.bands.iter_mut() {
                band.analyze(modulator);
                out += band.synthesize(carrier);
            }

            // Normalize by band count
            out /= self.bands.len().max(1) as f32;
            out *= 4.0; // makeup gain

            left[i] = left[i] * dry + out * wet;
            right[i] = right[i] * dry + out * wet;
        }
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_bitcrusher() {
        let mut bc = Bitcrusher::new(44100.0);
        let mut l = vec![0.5f32; 64];
        let mut r = vec![-0.5f32; 64];
        bc.process_stereo(&mut l, &mut r);
        // Should produce quantized output
        assert!(l.iter().any(|&s| s != 0.5));
    }

    #[test]
    fn test_ring_mod() {
        let mut rm = RingModulator::new(44100.0);
        let mut l = vec![1.0f32; 256];
        let mut r = vec![1.0f32; 256];
        rm.process_stereo(&mut l, &mut r);
        assert!(l.iter().any(|&s| s < 1.0)); // modulated
    }

    #[test]
    fn test_granular() {
        let mut gp = GranularProcessor::new(44100.0);
        let mut l: Vec<f32> = (0..2048).map(|i| (i as f32 * 0.01).sin()).collect();
        let mut r = l.clone();
        gp.process_stereo(&mut l, &mut r);
        // Should produce non-zero output
        assert!(l.iter().any(|&s| s.abs() > 0.001));
    }

    #[test]
    fn test_glitch_stutter() {
        let mut gs = GlitchStutter::new(44100.0, 120.0);
        gs.set_params(GlitchParams { probability: 1.0, ..Default::default() });
        let mut l: Vec<f32> = (0..4096).map(|i| (i as f32 * 0.005).sin()).collect();
        let mut r = l.clone();
        gs.process_stereo(&mut l, &mut r);
        // Should produce output (glitched)
        assert!(l.iter().any(|&s| s.abs() > 0.001));
    }

    #[test]
    fn test_vocoder() {
        let mut voc = Vocoder::new(44100.0);
        voc.set_params(VocoderParams {
            internal_carrier: true,
            carrier_type: CarrierType::Saw,
            num_bands: 8,
            ..Default::default()
        });

        // Modulator: simple tone
        let mut l: Vec<f32> = (0..2048).map(|i| (i as f32 * 0.02).sin()).collect();
        let mut r = vec![0.0f32; 2048];
        voc.process_stereo(&mut l, &mut r);
        // Should produce non-zero output
        assert!(l.iter().any(|&s| s.abs() > 0.001));
    }

    #[test]
    fn test_glitch_modes() {
        for mode in [GlitchMode::Stutter, GlitchMode::Reverse, GlitchMode::HalfSpeed,
                     GlitchMode::TapeStop, GlitchMode::Gate, GlitchMode::Shuffle] {
            let mut gs = GlitchStutter::new(44100.0, 120.0);
            gs.set_params(GlitchParams { mode, probability: 1.0, ..Default::default() });
            let mut l = vec![0.5f32; 2048];
            let mut r = vec![0.5f32; 2048];
            gs.process_stereo(&mut l, &mut r); // should not crash
        }
    }
}
