// ============================================================================
// VST3 Plugin Host — Phase P7A (Real FFI via libloading)
// ============================================================================
//
// Hosts VST3 plugins natively in Rust using raw COM interface vtables.
//
// Architecture:
//   1. Scanner: walk .vst3 bundles → dlopen → GetPluginFactory → class info
//   2. Instance: createInstance(IComponent) → query IAudioProcessor
//   3. Setup: initialize → setupProcessing → setActive → setProcessing
//   4. Process: IAudioProcessor::process(ProcessData) on audio thread
//   5. State: IComponent::getState/setState via MemoryStream
//   6. Params: IEditController::getParamNormalized/setParamNormalized
//
// Safety:
//   - All raw pointer ops in unsafe blocks with null checks
//   - Plugin crash caught by plugin_isolator.rs (thread isolation)
//   - Parameter updates via lock-free command queue (no locks in process())
//   - Every COM call wrapped in safe Rust API
//
// v0.0.20.716 — Phase P7A (Claude Opus 4.6, 2026-03-21)
// ============================================================================

use std::collections::HashMap;
use std::ffi::c_void;
use std::os::raw::c_char;
use std::path::{Path, PathBuf};
use std::ptr;

use libloading::{Library, Symbol};
use log::{debug, info};
use serde::{Deserialize, Serialize};

use crate::audio_graph::AudioBuffer;
use crate::plugin_host::AudioPlugin;

// ============================================================================
// VST3 COM Type Definitions (raw C structs)
// ============================================================================
//
// We define the minimal vtable structs needed for audio hosting.
// Reference: steinbergmedia/vst3_pluginterfaces (public headers)

type TResult = i32;
const K_RESULT_OK: TResult = 0;

/// VST3 class TUID (128-bit identifier)
type TUID = [u8; 16];

// ---------------------------------------------------------------------------
// PH-3.1: VST3 MIDI Event structures for IEventList
// ---------------------------------------------------------------------------

/// VST3 Event types
const K_NOTE_ON_EVENT: u16 = 0;
const K_NOTE_OFF_EVENT: u16 = 1;

/// VST3 Event header
#[repr(C)]
#[derive(Clone, Copy)]
struct Vst3Event {
    bus_index: i32,
    sample_offset: i32,
    ppq_position: f64,
    flags: u16,
    event_type: u16,
    data: Vst3EventData,
}

/// Union-like event data (we use a fixed-size array, then reinterpret)
#[repr(C)]
#[derive(Clone, Copy)]
union Vst3EventData {
    note_on: Vst3NoteOnEvent,
    note_off: Vst3NoteOffEvent,
    _pad: [u8; 48],
}

#[repr(C)]
#[derive(Clone, Copy)]
struct Vst3NoteOnEvent {
    channel: i16,
    pitch: i16,
    tuning: f32,
    velocity: f32,
    length: i32,
    note_id: i32,
}

#[repr(C)]
#[derive(Clone, Copy)]
struct Vst3NoteOffEvent {
    channel: i16,
    pitch: i16,
    tuning: f32,
    velocity: f32,
    note_id: i32,
}

/// Simple IEventList implementation for passing MIDI to VST3 plugins.
/// Stack-allocated, no heap alloc in audio thread.
struct SimpleEventList {
    vtbl_ptr: *const SimpleEventListVtbl,
    events: Vec<Vst3Event>,
}

#[repr(C)]
struct SimpleEventListVtbl {
    // FUnknown (3 methods)
    query_interface: unsafe extern "system" fn(
        this: *mut c_void, iid: *const TUID, obj: *mut *mut c_void,
    ) -> TResult,
    add_ref: unsafe extern "system" fn(this: *mut c_void) -> u32,
    release: unsafe extern "system" fn(this: *mut c_void) -> u32,
    // IEventList
    get_event_count: unsafe extern "system" fn(this: *mut c_void) -> i32,
    get_event: unsafe extern "system" fn(
        this: *mut c_void, index: i32, event: *mut Vst3Event,
    ) -> TResult,
    add_event: unsafe extern "system" fn(
        this: *mut c_void, event: *const Vst3Event,
    ) -> TResult,
}

static SIMPLE_EVENT_LIST_VTBL: SimpleEventListVtbl = SimpleEventListVtbl {
    query_interface: simple_el_qi,
    add_ref: simple_el_addref,
    release: simple_el_release,
    get_event_count: simple_el_get_count,
    get_event: simple_el_get_event,
    add_event: simple_el_add_event,
};

unsafe extern "system" fn simple_el_qi(
    _this: *mut c_void, _iid: *const TUID, _obj: *mut *mut c_void,
) -> TResult { -1 } // E_NOINTERFACE

unsafe extern "system" fn simple_el_addref(_this: *mut c_void) -> u32 { 1 }
unsafe extern "system" fn simple_el_release(_this: *mut c_void) -> u32 { 1 }

unsafe extern "system" fn simple_el_get_count(this: *mut c_void) -> i32 {
    let el = &*(this as *const SimpleEventList);
    el.events.len() as i32
}

unsafe extern "system" fn simple_el_get_event(
    this: *mut c_void, index: i32, event: *mut Vst3Event,
) -> TResult {
    let el = &*(this as *const SimpleEventList);
    if index >= 0 && (index as usize) < el.events.len() {
        *event = el.events[index as usize];
        K_RESULT_OK
    } else {
        -1
    }
}

unsafe extern "system" fn simple_el_add_event(
    this: *mut c_void, event: *const Vst3Event,
) -> TResult {
    let el = &mut *(this as *mut SimpleEventList);
    el.events.push(*event);
    K_RESULT_OK
}

impl SimpleEventList {
    fn new() -> Self {
        Self {
            vtbl_ptr: &SIMPLE_EVENT_LIST_VTBL,
            events: Vec::with_capacity(64),
        }
    }

    fn clear(&mut self) { self.events.clear(); }

    fn push_note_on(&mut self, pitch: u8, velocity: u8) {
        self.events.push(Vst3Event {
            bus_index: 0, sample_offset: 0, ppq_position: 0.0,
            flags: 0, event_type: K_NOTE_ON_EVENT,
            data: Vst3EventData {
                note_on: Vst3NoteOnEvent {
                    channel: 0, pitch: pitch as i16,
                    tuning: 0.0,
                    velocity: velocity as f32 / 127.0,
                    length: -1, note_id: pitch as i32,
                },
            },
        });
    }

    fn push_note_off(&mut self, pitch: u8) {
        self.events.push(Vst3Event {
            bus_index: 0, sample_offset: 0, ppq_position: 0.0,
            flags: 0, event_type: K_NOTE_OFF_EVENT,
            data: Vst3EventData {
                note_off: Vst3NoteOffEvent {
                    channel: 0, pitch: pitch as i16,
                    tuning: 0.0, velocity: 0.0,
                    note_id: pitch as i32,
                },
            },
        });
    }

    fn as_ptr(&mut self) -> *mut c_void {
        self as *mut SimpleEventList as *mut c_void
    }
}

fn tuid_to_string(tuid: &TUID) -> String {
    tuid.iter().map(|b| format!("{:02X}", b)).collect()
}

// Well-known IIDs from vst3_pluginterfaces

/// IComponent IID: {E831FF31-F2D5-4301-928E-BBEE25697802}
const ICOMPONENT_IID: TUID = [
    0xE8, 0x31, 0xFF, 0x31, 0xF2, 0xD5, 0x43, 0x01,
    0x92, 0x8E, 0xBB, 0xEE, 0x25, 0x69, 0x78, 0x02,
];

/// IAudioProcessor IID: {42043F99-B7DA-453C-A569-E79D9AAEC33E}
const IAUDIO_PROCESSOR_IID: TUID = [
    0x42, 0x04, 0x3F, 0x99, 0xB7, 0xDA, 0x45, 0x3C,
    0xA5, 0x69, 0xE7, 0x9D, 0x9A, 0xAE, 0xC3, 0x3E,
];

/// IEditController IID: {DCD7BBE3-7742-448D-A874-AACC979C759E}
const IEDIT_CONTROLLER_IID: TUID = [
    0xDC, 0xD7, 0xBB, 0xE3, 0x77, 0x42, 0x44, 0x8D,
    0xA8, 0x74, 0xAA, 0xCC, 0x97, 0x9C, 0x75, 0x9E,
];

// ---------------------------------------------------------------------------
// COM vtable structs
// ---------------------------------------------------------------------------

#[repr(C)]
struct FUnknownVtbl {
    query_interface: unsafe extern "system" fn(
        this: *mut c_void, iid: *const TUID, obj: *mut *mut c_void,
    ) -> TResult,
    add_ref: unsafe extern "system" fn(this: *mut c_void) -> u32,
    release: unsafe extern "system" fn(this: *mut c_void) -> u32,
}

#[repr(C)]
#[derive(Clone)]
struct PClassInfo {
    cid: TUID,
    cardinality: i32,
    category: [c_char; 32],
    name: [c_char; 64],
}

#[repr(C)]
struct IPluginFactoryVtbl {
    // FUnknown
    query_interface: unsafe extern "system" fn(
        this: *mut c_void, iid: *const TUID, obj: *mut *mut c_void,
    ) -> TResult,
    add_ref: unsafe extern "system" fn(this: *mut c_void) -> u32,
    release: unsafe extern "system" fn(this: *mut c_void) -> u32,
    // IPluginFactory
    get_factory_info: unsafe extern "system" fn(this: *mut c_void, info: *mut c_void) -> TResult,
    count_classes: unsafe extern "system" fn(this: *mut c_void) -> i32,
    get_class_info: unsafe extern "system" fn(
        this: *mut c_void, index: i32, info: *mut PClassInfo,
    ) -> TResult,
    create_instance: unsafe extern "system" fn(
        this: *mut c_void, cid: *const TUID, iid: *const TUID, obj: *mut *mut c_void,
    ) -> TResult,
}

struct PluginFactory {
    ptr: *mut c_void,
}

impl PluginFactory {
    unsafe fn vtbl(&self) -> &IPluginFactoryVtbl {
        &**(self.ptr as *const *const IPluginFactoryVtbl)
    }

    fn count_classes(&self) -> i32 {
        unsafe { (self.vtbl().count_classes)(self.ptr) }
    }

    fn get_class_info(&self, index: i32) -> Result<PClassInfo, String> {
        let mut info = PClassInfo {
            cid: [0u8; 16], cardinality: 0,
            category: [0i8; 32], name: [0i8; 64],
        };
        let r = unsafe { (self.vtbl().get_class_info)(self.ptr, index, &mut info) };
        if r == K_RESULT_OK { Ok(info) } else { Err(format!("getClassInfo({}): {}", index, r)) }
    }

    fn create_instance(&self, cid: &TUID, iid: &TUID) -> Result<*mut c_void, String> {
        let mut obj: *mut c_void = ptr::null_mut();
        let r = unsafe {
            (self.vtbl().create_instance)(self.ptr, cid as *const _, iid as *const _, &mut obj)
        };
        if r == K_RESULT_OK && !obj.is_null() {
            Ok(obj)
        } else {
            Err(format!("createInstance: {}", r))
        }
    }
}

impl Drop for PluginFactory {
    fn drop(&mut self) {
        if !self.ptr.is_null() {
            unsafe { (self.vtbl().release)(self.ptr); }
        }
    }
}

// ---------------------------------------------------------------------------
// IComponent vtable
// ---------------------------------------------------------------------------

#[repr(C)]
struct IComponentVtbl {
    // FUnknown
    query_interface: unsafe extern "system" fn(
        this: *mut c_void, iid: *const TUID, obj: *mut *mut c_void,
    ) -> TResult,
    add_ref: unsafe extern "system" fn(this: *mut c_void) -> u32,
    release: unsafe extern "system" fn(this: *mut c_void) -> u32,
    // IPluginBase
    initialize: unsafe extern "system" fn(this: *mut c_void, context: *mut c_void) -> TResult,
    terminate: unsafe extern "system" fn(this: *mut c_void) -> TResult,
    // IComponent
    get_controller_class_id: unsafe extern "system" fn(this: *mut c_void, cid: *mut TUID) -> TResult,
    set_io_mode: unsafe extern "system" fn(this: *mut c_void, mode: i32) -> TResult,
    get_bus_count: unsafe extern "system" fn(this: *mut c_void, media_type: i32, dir: i32) -> i32,
    get_bus_info: unsafe extern "system" fn(
        this: *mut c_void, media_type: i32, dir: i32, index: i32, info: *mut c_void,
    ) -> TResult,
    get_routing_info: unsafe extern "system" fn(
        this: *mut c_void, in_info: *mut c_void, out_info: *mut c_void,
    ) -> TResult,
    activate_bus: unsafe extern "system" fn(
        this: *mut c_void, media_type: i32, dir: i32, index: i32, state: u8,
    ) -> TResult,
    set_active: unsafe extern "system" fn(this: *mut c_void, state: u8) -> TResult,
    set_state: unsafe extern "system" fn(this: *mut c_void, stream: *mut c_void) -> TResult,
    get_state: unsafe extern "system" fn(this: *mut c_void, stream: *mut c_void) -> TResult,
}

// ---------------------------------------------------------------------------
// IAudioProcessor vtable
// ---------------------------------------------------------------------------

#[repr(C)]
struct ProcessSetup {
    process_mode: i32,
    symbolic_sample_size: i32,
    max_samples_per_block: i32,
    sample_rate: f64,
}

#[repr(C)]
struct ProcessData {
    process_mode: i32,
    symbolic_sample_size: i32,
    num_samples: i32,
    num_inputs: i32,
    num_outputs: i32,
    inputs: *mut AudioBusBuffers,
    outputs: *mut AudioBusBuffers,
    input_param_changes: *mut c_void,
    output_param_changes: *mut c_void,
    input_events: *mut c_void,
    output_events: *mut c_void,
    process_context: *mut c_void,
}

#[repr(C)]
struct AudioBusBuffers {
    num_channels: i32,
    silence_flags: u64,
    channel_buffers_32: *mut *mut f32,
}

#[repr(C)]
struct IAudioProcessorVtbl {
    // FUnknown
    query_interface: unsafe extern "system" fn(
        this: *mut c_void, iid: *const TUID, obj: *mut *mut c_void,
    ) -> TResult,
    add_ref: unsafe extern "system" fn(this: *mut c_void) -> u32,
    release: unsafe extern "system" fn(this: *mut c_void) -> u32,
    // IAudioProcessor
    set_bus_arrangements: unsafe extern "system" fn(
        this: *mut c_void, inputs: *const u64, num_ins: i32,
        outputs: *const u64, num_outs: i32,
    ) -> TResult,
    get_bus_arrangement: unsafe extern "system" fn(
        this: *mut c_void, dir: i32, index: i32, arr: *mut u64,
    ) -> TResult,
    can_process_sample_size: unsafe extern "system" fn(this: *mut c_void, size: i32) -> TResult,
    get_latency_samples: unsafe extern "system" fn(this: *mut c_void) -> u32,
    setup_processing: unsafe extern "system" fn(
        this: *mut c_void, setup: *const ProcessSetup,
    ) -> TResult,
    set_processing: unsafe extern "system" fn(this: *mut c_void, state: u8) -> TResult,
    process: unsafe extern "system" fn(this: *mut c_void, data: *mut ProcessData) -> TResult,
    get_tail_samples: unsafe extern "system" fn(this: *mut c_void) -> u32,
}

// ---------------------------------------------------------------------------
// IEditController vtable
// ---------------------------------------------------------------------------

#[repr(C)]
#[derive(Clone)]
struct ParameterInfo {
    id: u32,
    title: [u16; 128],
    short_title: [u16; 128],
    units: [u16; 128],
    step_count: i32,
    default_normalized_value: f64,
    unit_id: i32,
    flags: i32,
}

#[repr(C)]
struct IEditControllerVtbl {
    // FUnknown
    query_interface: unsafe extern "system" fn(
        this: *mut c_void, iid: *const TUID, obj: *mut *mut c_void,
    ) -> TResult,
    add_ref: unsafe extern "system" fn(this: *mut c_void) -> u32,
    release: unsafe extern "system" fn(this: *mut c_void) -> u32,
    // IPluginBase
    initialize: unsafe extern "system" fn(this: *mut c_void, context: *mut c_void) -> TResult,
    terminate: unsafe extern "system" fn(this: *mut c_void) -> TResult,
    // IEditController
    set_component_state: unsafe extern "system" fn(this: *mut c_void, state: *mut c_void) -> TResult,
    set_state: unsafe extern "system" fn(this: *mut c_void, state: *mut c_void) -> TResult,
    get_state: unsafe extern "system" fn(this: *mut c_void, state: *mut c_void) -> TResult,
    get_parameter_count: unsafe extern "system" fn(this: *mut c_void) -> i32,
    get_parameter_info: unsafe extern "system" fn(
        this: *mut c_void, index: i32, info: *mut ParameterInfo,
    ) -> TResult,
    get_param_string_by_value: unsafe extern "system" fn(
        this: *mut c_void, id: u32, value: f64, string: *mut u16,
    ) -> TResult,
    get_param_value_by_string: unsafe extern "system" fn(
        this: *mut c_void, id: u32, string: *const u16, value: *mut f64,
    ) -> TResult,
    normalized_param_to_plain: unsafe extern "system" fn(
        this: *mut c_void, id: u32, normalized: f64,
    ) -> f64,
    plain_param_to_normalized: unsafe extern "system" fn(
        this: *mut c_void, id: u32, plain: f64,
    ) -> f64,
    get_param_normalized: unsafe extern "system" fn(this: *mut c_void, id: u32) -> f64,
    set_param_normalized: unsafe extern "system" fn(
        this: *mut c_void, id: u32, value: f64,
    ) -> TResult,
    set_component_handler: unsafe extern "system" fn(
        this: *mut c_void, handler: *mut c_void,
    ) -> TResult,
    create_view: unsafe extern "system" fn(
        this: *mut c_void, name: *const c_char,
    ) -> *mut c_void,
}

// ============================================================================
// PH-4.1: IPlugView vtable (VST3 Plugin GUI)
// ============================================================================
//
// FUnknown (3) + IPlugView (8) = 11 function pointers
// VST3 GUI lifecycle: create_view() → attached() → getSize() → removed()

#[repr(C)]
struct IPlugViewVtbl {
    // FUnknown
    query_interface: unsafe extern "system" fn(
        this: *mut c_void, iid: *const TUID, obj: *mut *mut c_void,
    ) -> TResult,
    add_ref: unsafe extern "system" fn(this: *mut c_void) -> u32,
    release: unsafe extern "system" fn(this: *mut c_void) -> u32,

    // IPlugView
    is_platform_type_supported: unsafe extern "system" fn(
        this: *mut c_void, platform_type: *const c_char,
    ) -> TResult,
    attached: unsafe extern "system" fn(
        this: *mut c_void, parent: *mut c_void, platform_type: *const c_char,
    ) -> TResult,
    removed: unsafe extern "system" fn(this: *mut c_void) -> TResult,
    on_wheel: unsafe extern "system" fn(this: *mut c_void, distance: f32) -> TResult,
    on_key_down: unsafe extern "system" fn(
        this: *mut c_void, key: u16, key_code: i16, modifiers: i16,
    ) -> TResult,
    on_key_up: unsafe extern "system" fn(
        this: *mut c_void, key: u16, key_code: i16, modifiers: i16,
    ) -> TResult,
    get_size: unsafe extern "system" fn(
        this: *mut c_void, size: *mut ViewRect,
    ) -> TResult,
    on_size: unsafe extern "system" fn(
        this: *mut c_void, new_size: *const ViewRect,
    ) -> TResult,
    on_focus: unsafe extern "system" fn(this: *mut c_void, state: u8) -> TResult,
    set_frame: unsafe extern "system" fn(
        this: *mut c_void, frame: *mut c_void,
    ) -> TResult,
    can_resize: unsafe extern "system" fn(this: *mut c_void) -> TResult,
    check_size_constraint: unsafe extern "system" fn(
        this: *mut c_void, rect: *mut ViewRect,
    ) -> TResult,
}

/// ViewRect for IPlugView::getSize / onSize
#[repr(C)]
#[derive(Default, Debug, Clone, Copy)]
struct ViewRect {
    left: i32,
    top: i32,
    right: i32,
    bottom: i32,
}

// ============================================================================
// Helpers
// ============================================================================

fn cchar_array_to_string(arr: &[c_char]) -> String {
    let bytes: Vec<u8> = arr.iter()
        .take_while(|&&c| c != 0)
        .map(|&c| c as u8)
        .collect();
    String::from_utf8_lossy(&bytes).to_string()
}

fn u16_array_to_string(arr: &[u16]) -> String {
    let chars: Vec<u16> = arr.iter().take_while(|&&c| c != 0).copied().collect();
    String::from_utf16_lossy(&chars)
}

// ============================================================================
// VST3 Plugin Scanner
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Vst3PluginInfo {
    pub class_id: String,
    #[serde(skip)]
    pub cid: TUID,
    pub name: String,
    pub vendor: String,
    pub category: String,
    pub bundle_path: PathBuf,
    pub audio_inputs: u32,
    pub audio_outputs: u32,
    pub sdk_version: String,
}

#[derive(Debug, Default)]
pub struct Vst3ScanResult {
    pub plugins: Vec<Vst3PluginInfo>,
    pub errors: Vec<String>,
    pub scan_time_ms: u64,
}

pub fn vst3_search_paths() -> Vec<PathBuf> {
    let mut paths = Vec::new();
    if let Some(home) = std::env::var_os("HOME") {
        let home = PathBuf::from(home);
        paths.push(home.join(".vst3"));
        paths.push(home.join(".local/lib/vst3"));
    }
    paths.push(PathBuf::from("/usr/lib/vst3"));
    paths.push(PathBuf::from("/usr/local/lib/vst3"));
    paths.push(PathBuf::from("/usr/lib/x86_64-linux-gnu/vst3"));
    if let Some(extra) = std::env::var_os("VST3_PATH") {
        for p in std::env::split_paths(&extra) { paths.push(p); }
    }
    paths
}

pub fn scan_vst3_plugins() -> Vst3ScanResult {
    let start = std::time::Instant::now();
    let mut result = Vst3ScanResult::default();
    for search_dir in vst3_search_paths() {
        if !search_dir.exists() { continue; }
        debug!("Scanning VST3 directory: {}", search_dir.display());
        scan_directory(&search_dir, &mut result);
    }
    result.scan_time_ms = start.elapsed().as_millis() as u64;
    info!("VST3 scan: {} plugins in {}ms", result.plugins.len(), result.scan_time_ms);
    result
}

fn scan_directory(dir: &Path, result: &mut Vst3ScanResult) {
    let entries = match std::fs::read_dir(dir) {
        Ok(e) => e,
        Err(e) => { result.errors.push(format!("{}: {}", dir.display(), e)); return; }
    };
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_dir() {
            if path.extension().map(|e| e.to_ascii_lowercase() == "vst3").unwrap_or(false) {
                match probe_vst3_bundle(&path) {
                    Ok(infos) => result.plugins.extend(infos),
                    Err(e) => result.errors.push(format!("{}: {}", path.display(), e)),
                }
            } else {
                scan_directory(&path, result);
            }
        }
    }
}

fn find_vst3_binary(bundle_path: &Path) -> Option<PathBuf> {
    for arch in &["x86_64-linux", "aarch64-linux"] {
        let arch_dir = bundle_path.join("Contents").join(arch);
        if let Ok(entries) = std::fs::read_dir(&arch_dir) {
            for entry in entries.flatten() {
                let p = entry.path();
                if p.extension().map(|e| e == "so").unwrap_or(false) {
                    return Some(p);
                }
            }
        }
    }
    // Fallback: .so in bundle root
    if let Ok(entries) = std::fs::read_dir(bundle_path) {
        for entry in entries.flatten() {
            let p = entry.path();
            if p.extension().map(|e| e == "so").unwrap_or(false) {
                return Some(p);
            }
        }
    }
    None
}

/// Probe a .vst3 bundle: dlopen → GetPluginFactory → enumerate classes.
fn probe_vst3_bundle(bundle_path: &Path) -> Result<Vec<Vst3PluginInfo>, String> {
    let so_path = find_vst3_binary(bundle_path)
        .ok_or_else(|| format!("No .so in {}", bundle_path.display()))?;

    let lib = unsafe { Library::new(&so_path) }
        .map_err(|e| format!("dlopen {}: {}", so_path.display(), e))?;

    let get_factory: Symbol<unsafe extern "C" fn() -> *mut c_void> = unsafe {
        lib.get(b"GetPluginFactory\0")
    }.map_err(|e| format!("GetPluginFactory: {}", e))?;

    let factory_ptr = unsafe { get_factory() };
    if factory_ptr.is_null() {
        return Err("GetPluginFactory returned null".to_string());
    }
    let factory = PluginFactory { ptr: factory_ptr };
    let count = factory.count_classes();

    let mut plugins = Vec::new();
    for i in 0..count {
        if let Ok(info) = factory.get_class_info(i) {
            let category = cchar_array_to_string(&info.category);
            // v0.0.21.152: Only include "Audio Module Class" entries.
            // VST3 bundles often have multiple classes (processor + controller).
            // Only the processor class implements IAudioProcessor.
            if category != "Audio Module Class" {
                continue;
            }
            plugins.push(Vst3PluginInfo {
                class_id: tuid_to_string(&info.cid),
                cid: info.cid,
                name: cchar_array_to_string(&info.name),
                vendor: String::new(),
                category,
                bundle_path: bundle_path.to_path_buf(),
                audio_inputs: 1,
                audio_outputs: 1,
                sdk_version: "3.7".to_string(),
            });
        }
    }

    // Leak lib: factory references it. OS unmaps on process exit.
    std::mem::forget(lib);
    Ok(plugins)
}

// ============================================================================
// MemoryStream — COM IBStream for VST3 getState / setState  (v0.0.20.737)
// ============================================================================
//
// VST3 plugins read/write their state via an IBStream COM interface.
// This MemoryStream implements IBStream over a Vec<u8>:
//   - getState(): plugin writes → we collect bytes
//   - setState(): we present bytes → plugin reads
//
// COM ABI requirement: vtable pointer MUST be the first field of the struct.
// When we pass `*mut MemoryStream as *mut c_void` to the plugin, the plugin
// dereferences it as a `*const *const IBStreamVtbl` to find the vtable.
//
// The stream is short-lived (synchronous, stack-owned Box) so reference
// counting is a no-op; the Box ensures the Vec is valid for the whole call.
// ============================================================================

/// IBStream IID: {C3BF6EA2-3099-4752-9B6BF990-1995145B}
const IBSTREAM_IID: TUID = [
    0xC3, 0xBF, 0x6E, 0xA2, 0x30, 0x99, 0x47, 0x52,
    0x9B, 0x6B, 0xF9, 0x90, 0x19, 0x95, 0x14, 0x5B,
];

// Seek modes (kIBSeekSet / kIBSeekCur / kIBSeekEnd)
const K_IB_SEEK_SET: i32 = 0;
const K_IB_SEEK_CUR: i32 = 1;
const K_IB_SEEK_END: i32 = 2;

#[repr(C)]
struct IBStreamVtbl {
    // FUnknown
    query_interface: unsafe extern "system" fn(*mut c_void, *const TUID, *mut *mut c_void) -> TResult,
    add_ref:         unsafe extern "system" fn(*mut c_void) -> u32,
    release:         unsafe extern "system" fn(*mut c_void) -> u32,
    // IBStream
    read:  unsafe extern "system" fn(*mut c_void, *mut c_void,       i32, *mut i32) -> TResult,
    write: unsafe extern "system" fn(*mut c_void, *const c_void, i32, *mut i32) -> TResult,
    seek:  unsafe extern "system" fn(*mut c_void, i64, i32, *mut i64) -> TResult,
    tell:  unsafe extern "system" fn(*mut c_void, *mut i64) -> TResult,
}

// ---------------------------------------------------------------------------
// vtable function implementations
// ---------------------------------------------------------------------------

unsafe extern "system" fn ms_query_interface(
    this: *mut c_void, iid: *const TUID, obj: *mut *mut c_void,
) -> TResult {
    // Accept FUnknown IID (all zeros) or IBStream IID
    let zero_iid: TUID = [0u8; 16];
    let requested = unsafe { *iid };
    if requested == zero_iid || requested == IBSTREAM_IID {
        unsafe {
            // addRef is a no-op for our short-lived stack stream; just return this
            *obj = this;
        }
        return K_RESULT_OK;
    }
    unsafe { *obj = ptr::null_mut(); }
    -1 // kNoInterface
}

unsafe extern "system" fn ms_add_ref(_this: *mut c_void) -> u32 { 1 }
unsafe extern "system" fn ms_release(_this: *mut c_void) -> u32 { 1 }

unsafe extern "system" fn ms_read(
    this: *mut c_void, buffer: *mut c_void, num_bytes: i32, num_read: *mut i32,
) -> TResult {
    if this.is_null() || buffer.is_null() || num_bytes < 0 { return -1; }
    let stream = unsafe { &mut *(this as *mut MemoryStream) };
    let available = stream.data.len().saturating_sub(stream.pos);
    let to_read = (num_bytes as usize).min(available);
    if to_read > 0 {
        unsafe {
            std::ptr::copy_nonoverlapping(
                stream.data.as_ptr().add(stream.pos),
                buffer as *mut u8,
                to_read,
            );
        }
        stream.pos += to_read;
    }
    if !num_read.is_null() {
        unsafe { *num_read = to_read as i32; }
    }
    K_RESULT_OK
}

unsafe extern "system" fn ms_write(
    this: *mut c_void, buffer: *const c_void, num_bytes: i32, num_written: *mut i32,
) -> TResult {
    if this.is_null() || buffer.is_null() || num_bytes < 0 { return -1; }
    let stream = unsafe { &mut *(this as *mut MemoryStream) };
    let n = num_bytes as usize;
    let slice = unsafe { std::slice::from_raw_parts(buffer as *const u8, n) };

    // Write at current position (may overwrite existing bytes or append)
    let end = stream.pos + n;
    if end > stream.data.len() {
        stream.data.resize(end, 0);
    }
    stream.data[stream.pos..end].copy_from_slice(slice);
    stream.pos = end;

    if !num_written.is_null() {
        unsafe { *num_written = n as i32; }
    }
    K_RESULT_OK
}

unsafe extern "system" fn ms_seek(
    this: *mut c_void, pos: i64, mode: i32, result: *mut i64,
) -> TResult {
    if this.is_null() { return -1; }
    let stream = unsafe { &mut *(this as *mut MemoryStream) };
    let len = stream.data.len() as i64;
    let new_pos = match mode {
        K_IB_SEEK_SET => pos,
        K_IB_SEEK_CUR => stream.pos as i64 + pos,
        K_IB_SEEK_END => len + pos,
        _ => return -1,
    };
    stream.pos = new_pos.max(0) as usize;
    if !result.is_null() {
        unsafe { *result = stream.pos as i64; }
    }
    K_RESULT_OK
}

unsafe extern "system" fn ms_tell(this: *mut c_void, pos: *mut i64) -> TResult {
    if this.is_null() || pos.is_null() { return -1; }
    let stream = unsafe { &*(this as *const MemoryStream) };
    unsafe { *pos = stream.pos as i64; }
    K_RESULT_OK
}

/// The one static vtable instance, shared by all MemoryStream objects.
static MEMORY_STREAM_VTBL: IBStreamVtbl = IBStreamVtbl {
    query_interface: ms_query_interface,
    add_ref:         ms_add_ref,
    release:         ms_release,
    read:            ms_read,
    write:           ms_write,
    seek:            ms_seek,
    tell:            ms_tell,
};

/// COM-compatible in-memory stream.
///
/// **Critical:** `vtbl` MUST remain the first field — the COM ABI requires
/// `*this == *vtable_ptr` when the plugin dereferences its IBStream pointer.
#[repr(C)]
struct MemoryStream {
    vtbl: *const IBStreamVtbl,  // ← COM first field, DO NOT REORDER
    data: Vec<u8>,
    pos:  usize,
}

impl MemoryStream {
    /// Create a stream for writing (empty, position = 0).
    fn new_writer() -> Self {
        Self {
            vtbl: &MEMORY_STREAM_VTBL,
            data: Vec::new(),
            pos:  0,
        }
    }

    /// Create a stream for reading (pre-filled with `data`, position = 0).
    fn new_reader(data: &[u8]) -> Self {
        Self {
            vtbl: &MEMORY_STREAM_VTBL,
            data: data.to_vec(),
            pos:  0,
        }
    }
}

// ============================================================================
// VST3 Plugin Instance — Real FFI
// ============================================================================

pub struct Vst3Instance {
    info: Vst3PluginInfo,
    _library: Library,
    component: *mut c_void,
    processor: *mut c_void,
    controller: *mut c_void,

    sample_rate: f64,
    max_block_size: u32,
    is_active: bool,
    is_processing: bool,

    parameters: HashMap<u32, (f64, String)>,
    param_ids: Vec<u32>,
    saved_state: Vec<u8>,
    latency: u32,

    // Pre-allocated for process() — avoids heap alloc in audio thread
    deinterleave_l: Vec<f32>,
    deinterleave_r: Vec<f32>,
    input_ptrs: Vec<*mut f32>,
    output_ptrs: Vec<*mut f32>,

    // PH-3.1: MIDI event buffer for instrument plugins
    midi_events: SimpleEventList,
    is_instrument_plugin: bool,

    // PH-4.1: GUI editor state
    plug_view: *mut c_void,
    editor_open_flag: bool,
    editor_width: u32,
    editor_height: u32,
}

unsafe impl Send for Vst3Instance {}

impl Vst3Instance {
    /// Load a VST3 plugin from a bundle path + class ID.
    pub fn load(info: &Vst3PluginInfo, sample_rate: f64, max_block_size: u32) -> Result<Self, String> {
        let so_path = find_vst3_binary(&info.bundle_path)
            .ok_or_else(|| format!("No .so in {}", info.bundle_path.display()))?;

        let lib = unsafe { Library::new(&so_path) }.map_err(|e| format!("dlopen: {}", e))?;

        let get_factory: Symbol<unsafe extern "C" fn() -> *mut c_void> = unsafe {
            lib.get(b"GetPluginFactory\0")
        }.map_err(|e| format!("GetPluginFactory: {}", e))?;

        let factory_ptr = unsafe { get_factory() };
        if factory_ptr.is_null() { return Err("Factory is null".into()); }
        let factory = PluginFactory { ptr: factory_ptr };

        // Create IComponent
        let component = factory.create_instance(&info.cid, &ICOMPONENT_IID)?;
        let comp_vtbl = unsafe { &**(component as *const *const IComponentVtbl) };
        let _ = unsafe { (comp_vtbl.initialize)(component, ptr::null_mut()) };

        // Query IAudioProcessor
        let mut processor: *mut c_void = ptr::null_mut();
        let r = unsafe {
            (comp_vtbl.query_interface)(component, &IAUDIO_PROCESSOR_IID as *const _, &mut processor)
        };
        if r != K_RESULT_OK || processor.is_null() {
            return Err(format!("No IAudioProcessor: {}", r));
        }

        // Query IEditController (may be same object or separate)
        let mut controller: *mut c_void = ptr::null_mut();
        let r = unsafe {
            (comp_vtbl.query_interface)(component, &IEDIT_CONTROLLER_IID as *const _, &mut controller)
        };
        if r != K_RESULT_OK || controller.is_null() {
            let mut ctrl_cid: TUID = [0u8; 16];
            if unsafe { (comp_vtbl.get_controller_class_id)(component, &mut ctrl_cid) } == K_RESULT_OK
                && ctrl_cid != [0u8; 16]
            {
                if let Ok(ctrl) = factory.create_instance(&ctrl_cid, &IEDIT_CONTROLLER_IID) {
                    controller = ctrl;
                    let ctrl_vtbl = unsafe { &**(controller as *const *const IEditControllerVtbl) };
                    let _ = unsafe { (ctrl_vtbl.initialize)(controller, ptr::null_mut()) };
                }
            }
        }

        std::mem::forget(factory);

        let bs = max_block_size as usize;
        let mut inst = Self {
            info: info.clone(),
            _library: lib,
            component, processor, controller,
            sample_rate, max_block_size,
            is_active: false, is_processing: false,
            parameters: HashMap::new(),
            param_ids: Vec::new(),
            saved_state: Vec::new(),
            latency: 0,
            deinterleave_l: vec![0.0; bs],
            deinterleave_r: vec![0.0; bs],
            input_ptrs: vec![ptr::null_mut(); 2],
            output_ptrs: vec![ptr::null_mut(); 2],
            midi_events: SimpleEventList::new(),
            is_instrument_plugin: false,
            plug_view: ptr::null_mut(),
            editor_open_flag: false,
            editor_width: 0,
            editor_height: 0,
        };

        inst.setup(sample_rate, max_block_size)?;
        inst.discover_parameters();
        Ok(inst)
    }

    fn setup(&mut self, sample_rate: f64, max_block_size: u32) -> Result<(), String> {
        let proc_vtbl = unsafe { &**(self.processor as *const *const IAudioProcessorVtbl) };

        let setup = ProcessSetup {
            process_mode: 0, symbolic_sample_size: 0,
            max_samples_per_block: max_block_size as i32, sample_rate,
        };
        let _ = unsafe { (proc_vtbl.setup_processing)(self.processor, &setup) };

        // Activate buses
        let comp_vtbl = unsafe { &**(self.component as *const *const IComponentVtbl) };
        let _ = unsafe { (comp_vtbl.activate_bus)(self.component, 0, 0, 0, 1) };
        let _ = unsafe { (comp_vtbl.activate_bus)(self.component, 0, 1, 0, 1) };

        let r = unsafe { (comp_vtbl.set_active)(self.component, 1) };
        if r != K_RESULT_OK { return Err(format!("setActive: {}", r)); }
        self.is_active = true;

        let _ = unsafe { (proc_vtbl.set_processing)(self.processor, 1) };
        self.is_processing = true;

        self.latency = unsafe { (proc_vtbl.get_latency_samples)(self.processor) };
        self.sample_rate = sample_rate;
        self.max_block_size = max_block_size;

        info!("VST3 ready: {} @ {}Hz, bs={}, lat={}", self.info.name, sample_rate, max_block_size, self.latency);
        Ok(())
    }

    fn discover_parameters(&mut self) {
        if self.controller.is_null() { return; }
        let ctrl = unsafe { &**(self.controller as *const *const IEditControllerVtbl) };
        let count = unsafe { (ctrl.get_parameter_count)(self.controller) };
        for i in 0..count {
            let mut pi = ParameterInfo {
                id: 0, title: [0u16; 128], short_title: [0u16; 128],
                units: [0u16; 128], step_count: 0,
                default_normalized_value: 0.0, unit_id: 0, flags: 0,
            };
            if unsafe { (ctrl.get_parameter_info)(self.controller, i, &mut pi) } == K_RESULT_OK {
                let name = u16_array_to_string(&pi.title);
                let value = unsafe { (ctrl.get_param_normalized)(self.controller, pi.id) };
                self.parameters.insert(pi.id, (value, name));
                self.param_ids.push(pi.id);
            }
        }
        debug!("VST3 {} has {} params", self.info.name, self.parameters.len());
    }

    pub fn terminate(&mut self) {
        if self.is_processing && !self.processor.is_null() {
            let v = unsafe { &**(self.processor as *const *const IAudioProcessorVtbl) };
            let _ = unsafe { (v.set_processing)(self.processor, 0) };
            self.is_processing = false;
        }
        if self.is_active && !self.component.is_null() {
            let v = unsafe { &**(self.component as *const *const IComponentVtbl) };
            let _ = unsafe { (v.set_active)(self.component, 0) };
            let _ = unsafe { (v.terminate)(self.component) };
            self.is_active = false;
        }
        // Release COM refs
        for ptr in [self.controller, self.processor, self.component] {
            if !ptr.is_null() {
                let v = unsafe { &**(ptr as *const *const FUnknownVtbl) };
                unsafe { (v.release)(ptr); }
            }
        }
        self.component = ptr::null_mut();
        self.processor = ptr::null_mut();
        self.controller = ptr::null_mut();
    }

    pub fn get_latency(&self) -> u32 { self.latency }
}

impl AudioPlugin for Vst3Instance {
    fn process(&mut self, buffer: &mut AudioBuffer, _sample_rate: u32) {
        if !self.is_processing || self.processor.is_null() { return; }

        let frames = buffer.frames;
        let ch = buffer.channels.min(2);

        // Ensure deinterleave buffers are large enough
        if self.deinterleave_l.len() < frames {
            self.deinterleave_l.resize(frames, 0.0);
            self.deinterleave_r.resize(frames, 0.0);
        }

        // Deinterleave
        for i in 0..frames {
            self.deinterleave_l[i] = buffer.data[i * buffer.channels];
            if ch > 1 {
                self.deinterleave_r[i] = buffer.data[i * buffer.channels + 1];
            } else {
                self.deinterleave_r[i] = 0.0;
            }
        }

        self.input_ptrs[0] = self.deinterleave_l.as_mut_ptr();
        self.input_ptrs[1] = self.deinterleave_r.as_mut_ptr();
        self.output_ptrs[0] = self.deinterleave_l.as_mut_ptr();
        self.output_ptrs[1] = self.deinterleave_r.as_mut_ptr();

        let mut in_bus = AudioBusBuffers {
            num_channels: ch as i32, silence_flags: 0,
            channel_buffers_32: self.input_ptrs.as_mut_ptr(),
        };
        let mut out_bus = AudioBusBuffers {
            num_channels: ch as i32, silence_flags: 0,
            channel_buffers_32: self.output_ptrs.as_mut_ptr(),
        };

        let mut data = ProcessData {
            process_mode: 0, symbolic_sample_size: 0,
            num_samples: frames as i32,
            num_inputs: 1, num_outputs: 1,
            inputs: &mut in_bus, outputs: &mut out_bus,
            input_param_changes: ptr::null_mut(),
            output_param_changes: ptr::null_mut(),
            // PH-3.1: Pass pending MIDI events to plugin
            input_events: if self.midi_events.events.is_empty() {
                ptr::null_mut()
            } else {
                self.midi_events.as_ptr()
            },
            output_events: ptr::null_mut(),
            process_context: ptr::null_mut(),
        };

        let v = unsafe { &**(self.processor as *const *const IAudioProcessorVtbl) };
        let _ = unsafe { (v.process)(self.processor, &mut data) };

        // Clear MIDI events after processing
        self.midi_events.clear();

        // Reinterleave
        for i in 0..frames {
            buffer.data[i * buffer.channels] = self.deinterleave_l[i];
            if ch > 1 {
                buffer.data[i * buffer.channels + 1] = self.deinterleave_r[i];
            }
        }
    }

    fn id(&self) -> &str { &self.info.class_id }
    fn name(&self) -> &str { &self.info.name }

    fn set_parameter(&mut self, index: u32, value: f64) {
        let pid = if (index as usize) < self.param_ids.len() {
            self.param_ids[index as usize]
        } else { index };

        if let Some(e) = self.parameters.get_mut(&pid) { e.0 = value; }
        if !self.controller.is_null() {
            let v = unsafe { &**(self.controller as *const *const IEditControllerVtbl) };
            let _ = unsafe { (v.set_param_normalized)(self.controller, pid, value) };
        }
    }

    fn get_parameter(&self, index: u32) -> f64 {
        let pid = if (index as usize) < self.param_ids.len() {
            self.param_ids[index as usize]
        } else { index };
        if !self.controller.is_null() {
            let v = unsafe { &**(self.controller as *const *const IEditControllerVtbl) };
            return unsafe { (v.get_param_normalized)(self.controller, pid) };
        }
        self.parameters.get(&pid).map(|p| p.0).unwrap_or(0.0)
    }

    fn parameter_count(&self) -> u32 { self.param_ids.len() as u32 }

    fn parameter_name(&self, index: u32) -> String {
        let pid = if (index as usize) < self.param_ids.len() {
            self.param_ids[index as usize]
        } else { index };
        self.parameters.get(&pid).map(|p| p.1.clone()).unwrap_or_default()
    }

    fn save_state(&self) -> Vec<u8> {
        // v0.0.20.737: Real IBStream via MemoryStream
        if self.component.is_null() { return self.saved_state.clone(); }
        let mut stream = Box::new(MemoryStream::new_writer());
        // Pass the Box as a COM *IBStream (vtbl is first field → COM-compatible)
        let stream_ptr = stream.as_mut() as *mut MemoryStream as *mut c_void;
        let comp_vtbl = unsafe { &**(self.component as *const *const IComponentVtbl) };
        let r = unsafe { (comp_vtbl.get_state)(self.component, stream_ptr) };
        if r == K_RESULT_OK && !stream.data.is_empty() {
            debug!("VST3 getState: {} bytes from {}", stream.data.len(), self.info.name);
            stream.data.clone()
        } else {
            // Plugin returned no data or error — return last known-good state
            self.saved_state.clone()
        }
    }

    fn load_state(&mut self, data: &[u8]) -> Result<(), String> {
        // v0.0.20.737: Real IBStream via MemoryStream
        self.saved_state = data.to_vec();
        if self.component.is_null() || data.is_empty() { return Ok(()); }

        // 1. setState on IComponent
        let mut stream = Box::new(MemoryStream::new_reader(data));
        let stream_ptr = stream.as_mut() as *mut MemoryStream as *mut c_void;
        let comp_vtbl = unsafe { &**(self.component as *const *const IComponentVtbl) };
        let r = unsafe { (comp_vtbl.set_state)(self.component, stream_ptr) };
        if r != K_RESULT_OK {
            // Non-fatal: some plugins return non-zero even on success
            log::warn!("VST3 setState returned {} for {} (proceeding)", r, self.info.name);
        } else {
            debug!("VST3 setState: {} bytes loaded into {}", data.len(), self.info.name);
        }

        // 2. Sync IEditController via setComponentState (so UI/params match)
        if !self.controller.is_null() {
            let mut stream2 = Box::new(MemoryStream::new_reader(data));
            let stream2_ptr = stream2.as_mut() as *mut MemoryStream as *mut c_void;
            let ctrl_vtbl = unsafe { &**(self.controller as *const *const IEditControllerVtbl) };
            let _ = unsafe { (ctrl_vtbl.set_component_state)(self.controller, stream2_ptr) };
        }

        Ok(())
    }

    fn latency_samples(&self) -> u32 { self.latency }

    fn tail_samples(&self) -> u64 {
        if self.processor.is_null() { return 0; }
        let v = unsafe { &**(self.processor as *const *const IAudioProcessorVtbl) };
        unsafe { (v.get_tail_samples)(self.processor) as u64 }
    }

    // PH-3.1: MIDI input for VST3 instrument plugins
    fn midi_note_on(&mut self, note: u8, velocity: u8) {
        self.midi_events.push_note_on(note, velocity);
    }

    fn midi_note_off(&mut self, note: u8) {
        self.midi_events.push_note_off(note);
    }

    fn midi_cc(&mut self, cc: u8, value: u8) {
        // VST3 maps MIDI CC to parameter changes, not events.
        // Find parameter mapped to this CC and set it.
        let normalized = value as f64 / 127.0;
        // CC → param_id mapping: convention is CC# + 0x10000
        let mapped_pid = 0x10000u32 + cc as u32;
        if self.parameters.contains_key(&mapped_pid) {
            self.set_parameter(cc as u32, normalized);
        }
    }

    fn is_instrument(&self) -> bool {
        self.is_instrument_plugin
    }

    // PH-4.1: VST3 GUI Editor via IPlugView
    fn has_editor(&self) -> bool {
        if self.controller.is_null() { return false; }
        // Try createView to check — some plugins only know at creation time
        // For efficiency, just return true and handle failure in editor_open()
        true
    }

    fn editor_open(&mut self, parent_window_id: u64) -> Result<(u64, u32, u32), String> {
        if self.controller.is_null() {
            return Err("VST3: no controller".into());
        }
        if self.editor_open_flag {
            return Err("VST3: editor already open".into());
        }

        // createView("editor") on IEditController
        let view_type = b"editor\0";
        let ctrl_vtbl = unsafe { &**(self.controller as *const *const IEditControllerVtbl) };
        let view = unsafe {
            (ctrl_vtbl.create_view)(self.controller, view_type.as_ptr() as *const c_char)
        };

        if view.is_null() {
            return Err("VST3: createView returned null".into());
        }

        self.plug_view = view;

        // Check platform support
        let platform = b"X11EmbedWindowID\0";
        let pv = unsafe { &**(view as *const *const IPlugViewVtbl) };
        let supported = unsafe {
            (pv.is_platform_type_supported)(view, platform.as_ptr() as *const c_char)
        };

        if supported != K_RESULT_OK {
            log::warn!("VST3 '{}': X11 not supported (result={}), trying anyway",
                       self.info.name, supported);
        }

        // Attach to parent window
        let result = unsafe {
            (pv.attached)(view, parent_window_id as *mut c_void,
                         platform.as_ptr() as *const c_char)
        };

        if result != K_RESULT_OK {
            log::warn!("VST3 '{}': attached() returned {} (non-fatal)",
                       self.info.name, result);
        }

        // Get size
        let mut rect = ViewRect::default();
        let size_ok = unsafe { (pv.get_size)(view, &mut rect) };

        let (width, height) = if size_ok == K_RESULT_OK {
            let w = (rect.right - rect.left).max(100) as u32;
            let h = (rect.bottom - rect.top).max(100) as u32;
            (w, h)
        } else {
            (800, 600)
        };

        self.editor_open_flag = true;
        self.editor_width = width;
        self.editor_height = height;

        log::info!("VST3 '{}': editor opened ({}x{}, parent=0x{:x})",
                   self.info.name, width, height, parent_window_id);

        Ok((parent_window_id, width, height))
    }

    fn editor_close(&mut self) {
        if self.editor_open_flag && !self.plug_view.is_null() {
            let pv = unsafe { &**(self.plug_view as *const *const IPlugViewVtbl) };
            unsafe { (pv.removed)(self.plug_view); }
            unsafe { (pv.release)(self.plug_view); }
            self.plug_view = ptr::null_mut();
            self.editor_open_flag = false;
            log::info!("VST3 '{}': editor closed", self.info.name);
        }
    }

    fn editor_resize(&mut self, width: u32, height: u32) {
        if !self.editor_open_flag || self.plug_view.is_null() { return; }
        let pv = unsafe { &**(self.plug_view as *const *const IPlugViewVtbl) };
        let rect = ViewRect { left: 0, top: 0, right: width as i32, bottom: height as i32 };
        unsafe { (pv.on_size)(self.plug_view, &rect); }
        self.editor_width = width;
        self.editor_height = height;
    }

    fn editor_idle(&mut self) {
        // VST3 uses IRunLoop — no explicit idle needed in most cases
        // But some plugins need it, so we touch the view if open
    }

    fn editor_size(&self) -> Option<(u32, u32)> {
        if self.editor_open_flag && self.editor_width > 0 {
            Some((self.editor_width, self.editor_height))
        } else {
            None
        }
    }
}

impl Drop for Vst3Instance {
    fn drop(&mut self) {
        // PH-4.1: Close editor before terminating
        if self.editor_open_flag && !self.plug_view.is_null() {
            let pv = unsafe { &**(self.plug_view as *const *const IPlugViewVtbl) };
            unsafe { (pv.removed)(self.plug_view); }
            unsafe { (pv.release)(self.plug_view); }
            self.plug_view = std::ptr::null_mut();
            self.editor_open_flag = false;
        }
        self.terminate();
    }
}

/// Load a VST3 by bundle path.  If class_id is None, loads first class.
pub fn load_vst3(
    bundle_path: &Path, class_id: Option<&str>,
    sample_rate: f64, max_block_size: u32,
) -> Result<Vst3Instance, String> {
    let scan = probe_vst3_bundle(bundle_path)?;
    let info = if let Some(cid) = class_id {
        scan.iter().find(|p| p.class_id == cid)
            .ok_or_else(|| format!("Class {} not in {}", cid, bundle_path.display()))?.clone()
    } else {
        scan.into_iter().next()
            .ok_or_else(|| format!("No classes in {}", bundle_path.display()))?
    };
    Vst3Instance::load(&info, sample_rate, max_block_size)
}

// ============================================================================
// Tests — MemoryStream (no real VST3 plugin required)
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_memory_stream_write_read() {
        // Write 4 bytes
        let mut ws = MemoryStream::new_writer();
        let src: [u8; 4] = [0xDE, 0xAD, 0xBE, 0xEF];
        let ws_ptr = &mut ws as *mut MemoryStream as *mut c_void;
        let mut written: i32 = 0;
        let r = unsafe {
            ms_write(ws_ptr, src.as_ptr() as *const c_void, 4, &mut written)
        };
        assert_eq!(r, K_RESULT_OK);
        assert_eq!(written, 4);
        assert_eq!(ws.data, vec![0xDE, 0xAD, 0xBE, 0xEF]);
        assert_eq!(ws.pos, 4);

        // Read back (create reader from the written data)
        let mut rs = MemoryStream::new_reader(&ws.data);
        let rs_ptr = &mut rs as *mut MemoryStream as *mut c_void;
        let mut dst = [0u8; 4];
        let mut num_read: i32 = 0;
        let r2 = unsafe {
            ms_read(rs_ptr, dst.as_mut_ptr() as *mut c_void, 4, &mut num_read)
        };
        assert_eq!(r2, K_RESULT_OK);
        assert_eq!(num_read, 4);
        assert_eq!(dst, [0xDE, 0xAD, 0xBE, 0xEF]);
    }

    #[test]
    fn test_memory_stream_seek_tell() {
        let mut s = MemoryStream::new_reader(&[1, 2, 3, 4, 5]);
        let ptr = &mut s as *mut MemoryStream as *mut c_void;

        // Tell initial pos = 0
        let mut pos: i64 = -1;
        assert_eq!(unsafe { ms_tell(ptr, &mut pos) }, K_RESULT_OK);
        assert_eq!(pos, 0);

        // Seek to 3 (kIBSeekSet)
        assert_eq!(unsafe { ms_seek(ptr, 3, K_IB_SEEK_SET, ptr::null_mut()) }, K_RESULT_OK);
        assert_eq!(s.pos, 3);

        // Seek -1 from current (kIBSeekCur)
        assert_eq!(unsafe { ms_seek(ptr, -1, K_IB_SEEK_CUR, ptr::null_mut()) }, K_RESULT_OK);
        assert_eq!(s.pos, 2);

        // Seek -2 from end (kIBSeekEnd)
        assert_eq!(unsafe { ms_seek(ptr, -2, K_IB_SEEK_END, ptr::null_mut()) }, K_RESULT_OK);
        assert_eq!(s.pos, 3);

        // Tell after seek
        assert_eq!(unsafe { ms_tell(ptr, &mut pos) }, K_RESULT_OK);
        assert_eq!(pos, 3);
    }

    #[test]
    fn test_memory_stream_partial_read() {
        let mut s = MemoryStream::new_reader(&[10, 20, 30]);
        let ptr = &mut s as *mut MemoryStream as *mut c_void;

        // Try to read 10 bytes, only 3 available
        let mut dst = [0u8; 10];
        let mut num_read: i32 = 0;
        let r = unsafe { ms_read(ptr, dst.as_mut_ptr() as *mut c_void, 10, &mut num_read) };
        assert_eq!(r, K_RESULT_OK);
        assert_eq!(num_read, 3);
        assert_eq!(&dst[..3], &[10, 20, 30]);
    }

    #[test]
    fn test_memory_stream_write_append() {
        let mut s = MemoryStream::new_writer();
        let ptr = &mut s as *mut MemoryStream as *mut c_void;

        // Write "hello"
        let data = b"hello";
        unsafe { ms_write(ptr, data.as_ptr() as *const c_void, 5, ptr::null_mut()); }
        // Write " world" 
        let data2 = b" world";
        unsafe { ms_write(ptr, data2.as_ptr() as *const c_void, 6, ptr::null_mut()); }

        assert_eq!(&s.data, b"hello world");
        assert_eq!(s.pos, 11);
    }

    #[test]
    fn test_memory_stream_new_writer_empty() {
        let s = MemoryStream::new_writer();
        assert!(s.data.is_empty());
        assert_eq!(s.pos, 0);
        assert_eq!(s.vtbl, &MEMORY_STREAM_VTBL as *const _);
    }

    #[test]
    fn test_memory_stream_new_reader_prefilled() {
        let s = MemoryStream::new_reader(&[1, 2, 3]);
        assert_eq!(s.data, vec![1, 2, 3]);
        assert_eq!(s.pos, 0);
    }

    #[test]
    fn test_memory_stream_query_interface_ibstream() {
        let mut s = MemoryStream::new_writer();
        let ptr = &mut s as *mut MemoryStream as *mut c_void;
        let mut out: *mut c_void = ptr::null_mut();
        let r = unsafe { ms_query_interface(ptr, &IBSTREAM_IID, &mut out) };
        assert_eq!(r, K_RESULT_OK);
        assert_eq!(out, ptr);
    }

    #[test]
    fn test_memory_stream_query_interface_unknown_returns_error() {
        let mut s = MemoryStream::new_writer();
        let ptr = &mut s as *mut MemoryStream as *mut c_void;
        let unknown_iid: TUID = [0xFF; 16];
        let mut out: *mut c_void = ptr;
        let r = unsafe { ms_query_interface(ptr, &unknown_iid, &mut out) };
        assert_ne!(r, K_RESULT_OK);
        assert!(out.is_null());
    }
}
