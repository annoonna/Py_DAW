// ============================================================================
// LADSPA Plugin Host for Rust Engine
// ============================================================================
//
// Loads and runs LADSPA plugins (.so files) via dlopen/dlsym.
// v0.0.21.058 — P3.1 FULL IMPLEMENTATION (Claude Opus 4.6, 2026-04-09)
// ============================================================================

use std::collections::HashMap;
use std::ffi::{CStr, CString};
use std::os::raw::{c_char, c_int, c_ulong, c_void};
use std::path::{Path, PathBuf};
use std::ptr;

use log::{debug, info};

// ---------------------------------------------------------------------------
// LADSPA C ABI types (from ladspa.h)
// ---------------------------------------------------------------------------

type LadspaData = f32;
type LadspaHandle = *mut c_void;

const LADSPA_PORT_INPUT: c_int = 0x1;
const LADSPA_PORT_OUTPUT: c_int = 0x2;
const LADSPA_PORT_CONTROL: c_int = 0x4;
const LADSPA_PORT_AUDIO: c_int = 0x8;

#[repr(C)]
struct LadspaDescriptor {
    unique_id: c_ulong,
    label: *const c_char,
    properties: c_int,
    name: *const c_char,
    maker: *const c_char,
    copyright: *const c_char,
    port_count: c_ulong,
    port_descriptors: *const c_int,
    port_names: *const *const c_char,
    port_range_hints: *const LadspaPortRangeHint,
    implementation_data: *mut c_void,
    instantiate: Option<unsafe extern "C" fn(*const LadspaDescriptor, c_ulong) -> LadspaHandle>,
    connect_port: Option<unsafe extern "C" fn(LadspaHandle, c_ulong, *mut LadspaData)>,
    activate: Option<unsafe extern "C" fn(LadspaHandle)>,
    run: Option<unsafe extern "C" fn(LadspaHandle, c_ulong)>,
    run_adding: Option<unsafe extern "C" fn(LadspaHandle, c_ulong)>,
    set_run_adding_gain: Option<unsafe extern "C" fn(LadspaHandle, LadspaData)>,
    deactivate: Option<unsafe extern "C" fn(LadspaHandle)>,
    cleanup: Option<unsafe extern "C" fn(LadspaHandle)>,
}

#[repr(C)]
struct LadspaPortRangeHint {
    hint_descriptor: c_int,
    lower_bound: LadspaData,
    upper_bound: LadspaData,
}

type LadspaDescriptorFn = unsafe extern "C" fn(c_ulong) -> *const LadspaDescriptor;

extern "C" {
    fn dlopen(filename: *const c_char, flags: c_int) -> *mut c_void;
    fn dlsym(handle: *mut c_void, symbol: *const c_char) -> *mut c_void;
    fn dlclose(handle: *mut c_void) -> c_int;
    fn dlerror() -> *const c_char;
}

const RTLD_NOW: c_int = 2;

fn get_dlerror() -> String {
    unsafe {
        let err = dlerror();
        if err.is_null() { "unknown".into() } else {
            CStr::from_ptr(err).to_string_lossy().into_owned()
        }
    }
}

// ---------------------------------------------------------------------------
// Port info
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct PortInfo {
    index: usize,
    name: String,
    is_input: bool,
    is_audio: bool,
    is_control: bool,
    default_value: f32,
}

// ---------------------------------------------------------------------------
// LadspaPluginInstance
// ---------------------------------------------------------------------------

pub struct LadspaPluginInstance {
    pub name: String,
    pub library_path: PathBuf,
    pub plugin_index: usize,
    pub sample_rate: u32,
    pub audio_inputs: usize,
    pub audio_outputs: usize,
    pub control_inputs: usize,
    pub active: bool,

    _lib_handle: *mut c_void,
    _descriptor: *const LadspaDescriptor,
    _instance: LadspaHandle,
    ports: Vec<PortInfo>,
    audio_in_ports: Vec<usize>,
    audio_out_ports: Vec<usize>,
    control_in_ports: Vec<usize>,
    control_out_ports: Vec<usize>,
    control_buffers: Vec<f32>,
}

unsafe impl Send for LadspaPluginInstance {}

impl LadspaPluginInstance {
    pub fn load(path: &Path, plugin_index: usize, sample_rate: u32) -> Result<Self, String> {
        if !path.exists() {
            return Err(format!("LADSPA library not found: {}", path.display()));
        }

        let c_path = CString::new(path.to_string_lossy().as_bytes())
            .map_err(|e| format!("Invalid path: {}", e))?;

        unsafe {
            dlerror(); // clear
            let lib = dlopen(c_path.as_ptr(), RTLD_NOW);
            if lib.is_null() {
                return Err(format!("dlopen failed: {}", get_dlerror()));
            }

            let sym_name = CString::new("ladspa_descriptor").unwrap();
            let sym = dlsym(lib, sym_name.as_ptr());
            if sym.is_null() {
                dlclose(lib);
                return Err(format!("dlsym failed: {}", get_dlerror()));
            }

            let desc_fn: LadspaDescriptorFn = std::mem::transmute(sym);
            let descriptor = desc_fn(plugin_index as c_ulong);
            if descriptor.is_null() {
                dlclose(lib);
                return Err(format!("No plugin at index {}", plugin_index));
            }

            let name = if (*descriptor).name.is_null() {
                "unknown".into()
            } else {
                CStr::from_ptr((*descriptor).name).to_string_lossy().into_owned()
            };

            // Scan ports
            let port_count = (*descriptor).port_count as usize;
            let mut ports = Vec::with_capacity(port_count);
            let mut audio_in_ports = Vec::new();
            let mut audio_out_ports = Vec::new();
            let mut control_in_ports = Vec::new();
            let mut control_out_ports = Vec::new();

            for i in 0..port_count {
                let pd = *(*descriptor).port_descriptors.add(i);
                let pname = if (*descriptor).port_names.is_null() {
                    format!("port_{}", i)
                } else {
                    let np = *(*descriptor).port_names.add(i);
                    if np.is_null() { format!("port_{}", i) }
                    else { CStr::from_ptr(np).to_string_lossy().into_owned() }
                };

                let is_input = (pd & LADSPA_PORT_INPUT) != 0;
                let is_output = (pd & LADSPA_PORT_OUTPUT) != 0;
                let is_control = (pd & LADSPA_PORT_CONTROL) != 0;
                let is_audio = (pd & LADSPA_PORT_AUDIO) != 0;

                let default_value = if !(*descriptor).port_range_hints.is_null() {
                    Self::compute_default(&*(*descriptor).port_range_hints.add(i))
                } else { 0.0 };

                if is_audio && is_input { audio_in_ports.push(i); }
                if is_audio && is_output { audio_out_ports.push(i); }
                if is_control && is_input { control_in_ports.push(i); }
                if is_control && is_output { control_out_ports.push(i); }

                ports.push(PortInfo { index: i, name: pname, is_input, is_audio, is_control, default_value });
            }

            // Instantiate
            let inst_fn = (*descriptor).instantiate
                .ok_or("No instantiate function")?;
            let instance = inst_fn(descriptor, sample_rate as c_ulong);
            if instance.is_null() {
                dlclose(lib);
                return Err("instantiate() returned null".into());
            }

            // Control buffers
            let mut control_buffers = vec![0.0f32; port_count];
            for &ci in &control_in_ports {
                control_buffers[ci] = ports[ci].default_value;
            }

            // Connect control ports
            if let Some(connect_fn) = (*descriptor).connect_port {
                for &ci in control_in_ports.iter().chain(control_out_ports.iter()) {
                    connect_fn(instance, ci as c_ulong, &mut control_buffers[ci] as *mut f32);
                }
            }

            info!("[LADSPA] Loaded '{}' ({}in/{}out, {} ctrl) from {}",
                  name, audio_in_ports.len(), audio_out_ports.len(),
                  control_in_ports.len(), path.display());

            Ok(Self {
                name,
                library_path: path.to_path_buf(),
                plugin_index,
                sample_rate,
                audio_inputs: audio_in_ports.len(),
                audio_outputs: audio_out_ports.len(),
                control_inputs: control_in_ports.len(),
                active: false,
                _lib_handle: lib,
                _descriptor: descriptor,
                _instance: instance,
                ports,
                audio_in_ports,
                audio_out_ports,
                control_in_ports,
                control_out_ports,
                control_buffers,
            })
        }
    }

    fn compute_default(hint: &LadspaPortRangeHint) -> f32 {
        let hd = hint.hint_descriptor;
        if (hd & 0x200) != 0 { return 0.0; }   // DEFAULT_0
        if (hd & 0x400) != 0 { return 1.0; }   // DEFAULT_1
        if (hd & 0x40) != 0 { return hint.lower_bound; }  // DEFAULT_LOW
        if (hd & 0x100) != 0 { return hint.upper_bound; } // DEFAULT_HIGH
        if (hd & 0x80) != 0 { return (hint.lower_bound + hint.upper_bound) * 0.5; } // DEFAULT_MID
        0.0
    }

    pub fn set_control(&mut self, port_index: usize, value: f32) {
        if port_index < self.control_buffers.len() {
            self.control_buffers[port_index] = value;
            debug!("[LADSPA] {} port {} = {}", self.name, port_index, value);
        }
    }

    pub fn process(&mut self, input: &[f32], output: &mut [f32], frames: usize) {
        if !self.active || self._instance.is_null() {
            let cl = input.len().min(output.len());
            output[..cl].copy_from_slice(&input[..cl]);
            return;
        }

        unsafe {
            let connect_fn = match (*self._descriptor).connect_port {
                Some(f) => f,
                None => {
                    let cl = input.len().min(output.len());
                    output[..cl].copy_from_slice(&input[..cl]);
                    return;
                }
            };

            if let Some(&p) = self.audio_in_ports.first() {
                connect_fn(self._instance, p as c_ulong, input.as_ptr() as *mut f32);
            }
            if let Some(&p) = self.audio_out_ports.first() {
                connect_fn(self._instance, p as c_ulong, output.as_mut_ptr());
            }

            if let Some(run_fn) = (*self._descriptor).run {
                run_fn(self._instance, frames as c_ulong);
            }
        }
    }

    pub fn activate(&mut self) {
        if !self._instance.is_null() {
            unsafe {
                if let Some(f) = (*self._descriptor).activate { f(self._instance); }
            }
        }
        self.active = true;
        info!("[LADSPA] Activated: {}", self.name);
    }

    pub fn deactivate(&mut self) {
        if self.active && !self._instance.is_null() {
            unsafe {
                if let Some(f) = (*self._descriptor).deactivate { f(self._instance); }
            }
        }
        self.active = false;
    }

    pub fn cleanup(&mut self) {
        if self.active { self.deactivate(); }
        if !self._instance.is_null() {
            unsafe {
                if let Some(f) = (*self._descriptor).cleanup { f(self._instance); }
            }
            self._instance = ptr::null_mut();
        }
        if !self._lib_handle.is_null() {
            unsafe { dlclose(self._lib_handle); }
            self._lib_handle = ptr::null_mut();
        }
        info!("[LADSPA] Cleanup: {}", self.name);
    }

    pub fn get_control_ports(&self) -> Vec<(usize, String, f32)> {
        self.control_in_ports.iter().map(|&i| {
            (i, self.ports[i].name.clone(), self.control_buffers[i])
        }).collect()
    }
}

impl Drop for LadspaPluginInstance {
    fn drop(&mut self) { self.cleanup(); }
}

impl std::fmt::Debug for LadspaPluginInstance {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("LadspaPluginInstance")
            .field("name", &self.name)
            .field("active", &self.active)
            .field("audio_io", &format!("{}in/{}out", self.audio_inputs, self.audio_outputs))
            .finish()
    }
}

// ---------------------------------------------------------------------------
// AudioPlugin trait implementation (v0.0.21.059 — P4 integration)
// ---------------------------------------------------------------------------

impl crate::plugin_host::AudioPlugin for LadspaPluginInstance {
    fn process(&mut self, buffer: &mut crate::audio_graph::AudioBuffer, _sample_rate: u32) {
        if !self.active || self._instance.is_null() {
            return; // pass-through: buffer unchanged
        }

        let frames = buffer.frames;
        let data = &mut buffer.data;

        // LADSPA wants separate mono buffers; we have interleaved stereo.
        // v0.0.21.144 FIX: Connect ALL audio ports before run() — LADSPA spec
        // requires every port to be connected. Plugins like surround_encoder
        // (4in/2out) crashed because ports 2-3 were unconnected → segfault.
        //
        // Strategy: We map our stereo buffer to the first 2 in/out ports.
        // Extra input ports get zero-filled scratch buffers.
        // Extra output ports get scratch buffers (discarded after run).

        unsafe {
            let connect_fn = match (*self._descriptor).connect_port {
                Some(f) => f,
                None => return,
            };

            if self.audio_inputs < 1 || self.audio_outputs < 1 {
                return; // Can't process without at least 1 audio I/O
            }

            // Allocate per-port buffers
            let mut mono_in_l = vec![0.0f32; frames];
            let mut mono_in_r = vec![0.0f32; frames];
            let mut mono_out_l = vec![0.0f32; frames];
            let mut mono_out_r = vec![0.0f32; frames];
            // Scratch buffers for extra ports (zero-filled in, discarded out)
            let mut scratch_in = vec![0.0f32; frames];
            let mut scratch_out = vec![0.0f32; frames];

            // De-interleave stereo input
            for i in 0..frames {
                mono_in_l[i] = data[i * 2];       // left channel
                mono_in_r[i] = data[i * 2 + 1];   // right channel
            }

            // Connect ALL audio input ports
            for (port_idx, &port_num) in self.audio_in_ports.iter().enumerate() {
                let buf_ptr = match port_idx {
                    0 => mono_in_l.as_ptr() as *mut f32,
                    1 => mono_in_r.as_ptr() as *mut f32,
                    _ => scratch_in.as_mut_ptr(), // extra inputs get silence
                };
                connect_fn(self._instance, port_num as c_ulong, buf_ptr);
            }

            // Connect ALL audio output ports
            for (port_idx, &port_num) in self.audio_out_ports.iter().enumerate() {
                let buf_ptr = match port_idx {
                    0 => mono_out_l.as_mut_ptr(),
                    1 => mono_out_r.as_mut_ptr(),
                    _ => scratch_out.as_mut_ptr(), // extra outputs discarded
                };
                connect_fn(self._instance, port_num as c_ulong, buf_ptr);
            }

            // Run the plugin — ALL ports are now connected
            if let Some(run_fn) = (*self._descriptor).run {
                run_fn(self._instance, frames as c_ulong);
            }

            // Re-interleave output
            if self.audio_outputs >= 2 {
                // Stereo output
                for i in 0..frames {
                    data[i * 2] = mono_out_l[i];
                    data[i * 2 + 1] = mono_out_r[i];
                }
            } else {
                // Mono output: copy to both L and R
                for i in 0..frames {
                    data[i * 2] = mono_out_l[i];
                    data[i * 2 + 1] = mono_out_l[i];
                }
            }
        }
    }

    fn id(&self) -> &str { self.library_path.to_str().unwrap_or("ladspa") }
    fn name(&self) -> &str { &self.name }

    fn set_parameter(&mut self, index: u32, value: f64) {
        self.set_control(index as usize, value as f32);
    }

    fn get_parameter(&self, index: u32) -> f64 {
        if (index as usize) < self.control_buffers.len() {
            self.control_buffers[index as usize] as f64
        } else { 0.0 }
    }

    fn parameter_count(&self) -> u32 { self.control_inputs as u32 }

    fn parameter_name(&self, index: u32) -> String {
        self.control_in_ports.iter()
            .find(|&&p| p == index as usize)
            .and_then(|&p| self.ports.get(p))
            .map(|p| p.name.clone())
            .unwrap_or_else(|| format!("param_{}", index))
    }

    fn save_state(&self) -> Vec<u8> {
        // Serialize control values as JSON
        let vals: Vec<(usize, f32)> = self.control_in_ports.iter()
            .map(|&i| (i, self.control_buffers[i]))
            .collect();
        serde_json::to_vec(&vals).unwrap_or_default()
    }

    fn load_state(&mut self, data: &[u8]) -> Result<(), String> {
        let vals: Vec<(usize, f32)> = serde_json::from_slice(data)
            .map_err(|e| format!("LADSPA state: {}", e))?;
        for (idx, val) in vals {
            self.set_control(idx, val);
        }
        Ok(())
    }
}

/// Convenience: load a LADSPA plugin (for use in LoadPlugin handler).
pub fn load_ladspa(
    path: &Path, plugin_index: usize, sample_rate: f64, _max_block_size: u32,
) -> Result<LadspaPluginInstance, String> {
    let mut inst = LadspaPluginInstance::load(path, plugin_index, sample_rate as u32)?;
    inst.activate();
    Ok(inst)
}

// ---------------------------------------------------------------------------
// LadspaHostManager
// ---------------------------------------------------------------------------

#[derive(Default)]
pub struct LadspaHostManager {
    instances: HashMap<String, LadspaPluginInstance>,
}

impl LadspaHostManager {
    pub fn new() -> Self { Self { instances: HashMap::new() } }

    pub fn load_plugin(
        &mut self, track_id: &str, slot_index: usize,
        path: &Path, plugin_index: usize, sample_rate: u32,
    ) -> Result<(), String> {
        let key = format!("{}:{}", track_id, slot_index);
        if let Some(mut old) = self.instances.remove(&key) { old.cleanup(); }

        let mut inst = LadspaPluginInstance::load(path, plugin_index, sample_rate)?;
        inst.activate();
        self.instances.insert(key, inst);
        Ok(())
    }

    pub fn set_param(&mut self, track_id: &str, slot_index: usize,
                     port_index: usize, value: f32) -> bool {
        let key = format!("{}:{}", track_id, slot_index);
        if let Some(inst) = self.instances.get_mut(&key) {
            inst.set_control(port_index, value);
            true
        } else { false }
    }

    pub fn process(&mut self, track_id: &str, slot_index: usize,
                   input: &[f32], output: &mut [f32], frames: usize) -> bool {
        let key = format!("{}:{}", track_id, slot_index);
        if let Some(inst) = self.instances.get_mut(&key) {
            inst.process(input, output, frames);
            true
        } else { false }
    }

    pub fn unload_plugin(&mut self, track_id: &str, slot_index: usize) -> bool {
        let key = format!("{}:{}", track_id, slot_index);
        if let Some(mut inst) = self.instances.remove(&key) {
            inst.cleanup(); true
        } else { false }
    }

    pub fn cleanup_all(&mut self) {
        for (_, mut inst) in self.instances.drain() { inst.cleanup(); }
    }

    pub fn count(&self) -> usize { self.instances.len() }
}
