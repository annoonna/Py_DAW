// ============================================================================
// plugin_sync.rs — Direct Rust-to-Rust Param Sync (v0.0.21.157)
// ============================================================================
//
// Out-of-process plugin editor helpers (pydaw_vst2_editor / pydaw_vst3_editor /
// pydaw_clap_editor) forward parameter changes from their GUI to THIS engine
// directly — no Python detour.
//
// Protocol: Unix Datagram Socket at /tmp/pydaw_plugin_sync.sock
// Wire format: one JSON line per datagram:
//   {"t":"trk_abc123","s":0,"i":42,"v":0.7}
// where:
//   t = track_id (string)
//   s = slot_index (0 = instrument, >0 = FX slot)
//   i = param_index (i32)
//   v = param value (f64, normalized 0..1 for VST3/CLAP, plugin-dep for VST2)
//
// Multiple helpers can write to the same socket (datagram, connectionless).
// Messages that fail to parse are silently dropped.
//
// Author: Claude Opus 4.6
// ============================================================================

use std::os::unix::net::UnixDatagram;
use std::path::Path;
use std::thread;

use crossbeam_channel::Sender;
use log::{info, warn, debug};
use serde::Deserialize;

use crate::ipc::Command;

pub const PLUGIN_SYNC_SOCKET_PATH: &str = "/tmp/pydaw_plugin_sync.sock";

/// Minimal wire format — keys are single chars for compactness (datagram size).
#[derive(Deserialize)]
struct ParamSyncMsg {
    t: String, // track_id
    s: u32,    // slot_index
    i: i32,    // param_index
    v: f64,    // value
}

/// Spawn a background thread that listens for plugin-param updates via
/// Unix Datagram socket and forwards them as `Command::SetPluginParam` into
/// the engine's existing command queue.
///
/// The thread loops forever and is tolerant of parse errors, missing socket
/// permissions, and client disconnects — it can NEVER bring down the engine.
pub fn start_plugin_sync_listener(command_tx: Sender<Command>) {
    thread::Builder::new()
        .name("pydaw-plugin-sync".to_string())
        .spawn(move || {
            plugin_sync_loop(command_tx);
        })
        .expect("Failed to spawn plugin-sync listener thread");
}

fn plugin_sync_loop(command_tx: Sender<Command>) {
    // Clean up any stale socket file from previous run
    let _ = std::fs::remove_file(PLUGIN_SYNC_SOCKET_PATH);

    let socket = match UnixDatagram::bind(PLUGIN_SYNC_SOCKET_PATH) {
        Ok(s) => s,
        Err(e) => {
            warn!("[PLUGIN-SYNC] Failed to bind {}: {} — helper param-sync disabled",
                  PLUGIN_SYNC_SOCKET_PATH, e);
            return;
        }
    };

    // Make socket world-accessible (helpers run as same user, but still safe)
    if let Err(e) = set_socket_permissions(Path::new(PLUGIN_SYNC_SOCKET_PATH)) {
        debug!("[PLUGIN-SYNC] chmod warning: {}", e);
    }

    info!("[PLUGIN-SYNC] Listening for editor-helper param updates at {}",
          PLUGIN_SYNC_SOCKET_PATH);

    let mut buf = [0u8; 4096];
    let mut msg_count: u64 = 0;

    loop {
        match socket.recv(&mut buf) {
            Ok(n) => {
                if n == 0 { continue; }
                let data = &buf[..n];
                match serde_json::from_slice::<ParamSyncMsg>(data) {
                    Ok(msg) => {
                        // v0.0.21.158 type fix: Command::SetPluginParam uses
                        // slot_index: u8, param_index: u32, value: f64. Our
                        // wire format keeps i32/f64 for helper simplicity — cast here.
                        let cmd = Command::SetPluginParam {
                            track_id: msg.t,
                            slot_index: msg.s as u8,
                            param_index: msg.i.max(0) as u32,
                            value: msg.v,
                        };
                        // Non-blocking send — if command queue is full, drop
                        // the message rather than stall the audio thread.
                        let _ = command_tx.try_send(cmd);
                        msg_count = msg_count.wrapping_add(1);
                        if msg_count % 500 == 0 {
                            debug!("[PLUGIN-SYNC] forwarded {} param updates", msg_count);
                        }
                    }
                    Err(e) => {
                        // Parse error — log once per 100 errors, not per-msg
                        debug!("[PLUGIN-SYNC] parse error: {} (len={})", e, n);
                    }
                }
            }
            Err(e) => {
                // Socket errors shouldn't normally happen for datagram sockets.
                // Log and continue the loop.
                warn!("[PLUGIN-SYNC] recv error: {}", e);
                std::thread::sleep(std::time::Duration::from_millis(100));
            }
        }
    }
}

fn set_socket_permissions(path: &Path) -> std::io::Result<()> {
    use std::os::unix::fs::PermissionsExt;
    let mut perms = std::fs::metadata(path)?.permissions();
    perms.set_mode(0o666); // rw for everyone — same-user helpers + engine
    std::fs::set_permissions(path, perms)
}
