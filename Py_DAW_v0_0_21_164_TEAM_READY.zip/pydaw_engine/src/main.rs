// Crate-wide: allow dead_code for stub modules (Phase 1C FFI not yet active)
#![allow(dead_code)]

mod audio_bridge;
mod audio_decode;  // v0.0.20.984: NS2 — Symphonia universal audio decode
mod audio_graph;
mod audio_node;
mod audio_export;    // v0.0.20.972: RM3.5 — Offline render + export
mod audio_output;    // v0.0.20.959: RA1.1 — cpal audio output
mod audio_recording; // v0.0.20.971: RM3.4 — Audio recording
mod clap_host;
mod ladspa_host;
mod clip_renderer;
mod db;             // v0.0.20.970: RM1.2 — SQLite database layer
mod dsp;
mod engine;
mod file_io;        // v0.0.20.973: RM8 — Audio file I/O, project management
mod fx;
mod instruments;
mod integration;
mod ipc;
mod lock_free;
mod lv2_host;
mod midi_scheduler;
mod midi_input;     // v0.0.20.971: RM4.1 — MIDI input (midir)
mod midi_processing; // v0.0.20.972: RM4.2+4.3 — MIDI processing + SMF I/O
mod model;          // v0.0.20.970: RM1.1 — Core data model
mod music_ai;       // v0.0.20.973: RM7 — Music theory + AI generation
mod plugin_host;
mod plugin_isolator;
mod plugin_sync;         // v0.0.21.157 — Direct helper→engine param sync via UnixDatagram
mod render;         // v0.0.20.959: RA1.2 — Audio render loop
mod sample;
mod services;       // v0.0.20.973: RM6 — Time Travel + SENTINEL
mod transport;
mod video;          // v0.0.20.970: RM2 — Video NLE engine
mod gpu;            // v0.0.20.985: NS4 — WGPU GPU rendering (video filters, preview, audio viz)
mod vst3_host;
mod vst2_host;       // PH-2: VST2 native Rust host via raw FFI
mod x11_gui;         // PH-4: X11 GUI helper for plugin window embedding
mod fluidsynth;      // v0.0.21.142: FluidSynth FFI for SF2 soundfont rendering

// v0.0.20.974: RM5.4 + RM6.3-6.5 + RM9
mod plugin_sandbox;      // RM5.4 — Plugin process isolation + shared memory
mod collaboration;       // RM9   — WebSocket collaboration, OT, track locking
mod hardware_controller; // RM6.3 — OSC server, controller profiles, auto-detect
mod preset_system;       // RM6.4 — SQLite preset database, browser, search
mod scripting;           // RM6.5 — Embedded scripting, macro recording

// v0.0.20.975: RM5.1-5.3 + RM2.8 + RM3.1-3.3
mod plugin_hosting;      // RM5.1-5.3 — Full plugin hosting (params, presets, GUI, MIDI, buses)
mod audio_dsp;           // RM3.1-3.3 — Clip fading, mastering meters, creative FX

// v0.0.20.976: RM3.1 + RM10
mod arrangement_engine;  // RM3.1 — Arrangement renderer, time-stretch, pitch-shift, quantize
mod ipc_extended;        // RM10  — Batch commands, streaming, shared memory, hot-reload
mod gui;                 // RM11  — Framework-independent GUI layer (app state, layout, widgets, arranger, mixer, pianoroll)
mod shm_audio;           // v0.0.20.982 — Shared memory audio bridge (zero-copy Python→Rust)

use std::io::{Read, Write};
use std::sync::Arc;

use crossbeam_channel::{bounded, Receiver, Sender};
use log::{error, info, warn};

use crate::engine::EngineState;
use crate::ipc::{Command, Event};

// ============================================================================
// Py_DAW Audio Engine — Entry Point
// ============================================================================
//
// v0.0.20.782: IPC-Only Mode (NO cpal audio output)
//
// The engine runs as a pure IPC server — audio playback is handled entirely
// by the Python GUI via sounddevice/PipeWire.
//
// The Rust engine handles:
//   - Plugin scanning (VST3/CLAP/LV2)
//   - Project state sync (SyncProject)
//   - Audio graph state management
//   - MIDI scheduling
//   - Eventually: offline rendering / audio-buffer export via IPC
//
// v0.0.20.782 FIX: Removed cpal audio output that caused crash-reconnect cycle:
//   1. start_daw.sh started engine with --sr 48000 --buf 1024
//   2. Python sent Configure(sr=44100, buf=512) → graph buffers resized to 512
//   3. cpal callback still called process_audio with 1024 frames
//   4. Buffer overflow → engine crash → EOF → Python reconnect → same crash
//
// The engine now survives client disconnects and waits for reconnection.
// ============================================================================

#[cfg(unix)]
const DEFAULT_SOCKET: &str = "/tmp/pydaw_engine.sock";
#[cfg(windows)]
const DEFAULT_SOCKET: &str = "127.0.0.1:19847";

const DEFAULT_SAMPLE_RATE: u32 = 44100;
const DEFAULT_BUFFER_SIZE: u32 = 512;
const DEFAULT_BPM: f64 = 120.0;

/// Read a length-prefixed MessagePack frame from a stream.
///
/// Frame format: [u32 LE length][msgpack payload]
fn read_frame(stream: &mut impl Read) -> std::io::Result<Vec<u8>> {
    let mut len_buf = [0u8; 4];
    stream.read_exact(&mut len_buf)?;
    let len = u32::from_le_bytes(len_buf) as usize;

    if len > 16 * 1024 * 1024 {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            format!("Frame too large: {} bytes", len),
        ));
    }

    let mut buf = vec![0u8; len];
    stream.read_exact(&mut buf)?;
    Ok(buf)
}

/// Write a length-prefixed MessagePack frame to a stream.
fn write_frame(stream: &mut impl Write, data: &[u8]) -> std::io::Result<()> {
    let len = (data.len() as u32).to_le_bytes();
    stream.write_all(&len)?;
    stream.write_all(data)?;
    stream.flush()?;
    Ok(())
}

/// Decode a Command from MessagePack bytes.
/// UF-4 v0.0.21.143: BatchCommands are decoded here and returned as
/// individual commands via a Vec wrapper.
fn decode_command(data: &[u8]) -> Result<Command, String> {
    rmp_serde::from_slice(data).map_err(|e| format!("Decode error: {}", e))
}

/// Decode a batch-aware command. Returns one or more commands.
/// If the incoming message is a BatchCommands, it deserializes the
/// commands_json field and returns all sub-commands.
fn decode_commands(data: &[u8]) -> Result<Vec<Command>, String> {
    // Try normal single-command decode first
    match rmp_serde::from_slice::<Command>(data) {
        Ok(cmd) => Ok(vec![cmd]),
        Err(e) => {
            // Check if this is a BatchCommands (not in the Command enum)
            if let Ok(val) = rmp_serde::from_slice::<serde_json::Value>(data) {
                if val.get("cmd").and_then(|c| c.as_str()) == Some("BatchCommands") {
                    if let Some(json_str) = val.get("commands_json").and_then(|v| v.as_str()) {
                        match serde_json::from_str::<Vec<Command>>(json_str) {
                            Ok(cmds) => {
                                log::debug!("BatchCommands: decoded {} sub-commands", cmds.len());
                                return Ok(cmds);
                            }
                            Err(je) => {
                                return Err(format!("BatchCommands JSON error: {}", je));
                            }
                        }
                    }
                }
            }
            Err(format!("Decode error: {}", e))
        }
    }
}

/// Encode an Event to MessagePack bytes.
fn encode_event(event: &Event) -> Result<Vec<u8>, String> {
    rmp_serde::to_vec_named(event).map_err(|e| format!("Encode error: {}", e))
}

/// IPC handler thread: reads commands from socket, sends to engine.
fn ipc_reader_thread(
    mut stream: impl Read + Send + 'static,
    command_tx: Sender<Command>,
) {
    info!("IPC reader started");
    loop {
        match read_frame(&mut stream) {
            Ok(frame) => match decode_commands(&frame) {
                Ok(cmds) => {
                    let mut do_shutdown = false;
                    for cmd in cmds {
                        if matches!(cmd, Command::Shutdown) {
                            do_shutdown = true;
                        }
                        if let Err(e) = command_tx.send(cmd) {
                            error!("Failed to send command: {}", e);
                            break;
                        }
                    }
                    if do_shutdown {
                        info!("Shutdown received, closing IPC reader");
                        break;
                    }
                }
                Err(e) => {
                    warn!("Failed to decode command: {}", e);
                }
            },
            Err(e) => {
                if e.kind() == std::io::ErrorKind::UnexpectedEof {
                    info!("Client disconnected (EOF)");
                } else {
                    error!("IPC read error: {}", e);
                }
                break;
            }
        }
    }
}

/// IPC writer thread: reads events from engine, sends to socket.
fn ipc_writer_thread(
    mut stream: impl Write + Send + 'static,
    event_rx: Receiver<Event>,
) {
    info!("IPC writer started");
    loop {
        match event_rx.recv() {
            Ok(event) => {
                let is_shutdown = matches!(event, Event::ShuttingDown);
                match encode_event(&event) {
                    Ok(data) => {
                        if let Err(e) = write_frame(&mut stream, &data) {
                            // Client disconnected — stop writing
                            info!("IPC write: client gone ({}), stopping writer", e);
                            break;
                        }
                    }
                    Err(e) => {
                        warn!("Failed to encode event: {}", e);
                    }
                }
                if is_shutdown {
                    info!("Shutdown event sent, closing IPC writer");
                    break;
                }
            }
            Err(_) => {
                info!("Event channel closed, stopping IPC writer");
                break;
            }
        }
    }
}

/// v0.0.20.782: Command drain ticker thread.
///
/// Since there is no cpal audio callback to call drain_commands(),
/// this thread periodically drains the command queue at ~100Hz.
/// This ensures Configure, ScanPlugins, SyncProject etc. are processed
/// promptly even without an audio callback driving the loop.
fn command_drain_ticker(engine: Arc<EngineState>) {
    info!("Command drain ticker started (~100Hz)");
    while engine.running.load(std::sync::atomic::Ordering::Relaxed) {
        engine.drain_commands();
        std::thread::sleep(std::time::Duration::from_millis(10));
    }
    info!("Command drain ticker stopped");
}

fn main() {
    // Initialize logging
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info"))
        .init();

    info!("Py_DAW Audio Engine v0.1.0 starting (cpal audio output enabled)...");

    // Parse command line args
    let args: Vec<String> = std::env::args().collect();
    let socket_path = args
        .iter()
        .position(|a| a == "--socket")
        .and_then(|i| args.get(i + 1))
        .map(|s| s.as_str())
        .unwrap_or(DEFAULT_SOCKET);

    let sample_rate = args
        .iter()
        .position(|a| a == "--sr")
        .and_then(|i| args.get(i + 1))
        .and_then(|s| s.parse().ok())
        .unwrap_or(DEFAULT_SAMPLE_RATE);

    let buffer_size = args
        .iter()
        .position(|a| a == "--buf")
        .and_then(|i| args.get(i + 1))
        .and_then(|s| s.parse().ok())
        .unwrap_or(DEFAULT_BUFFER_SIZE);

    info!(
        "Config: socket={}, sr={}, buf={}",
        socket_path, sample_rate, buffer_size
    );

    // Remove old socket file if it exists (Unix only)
    #[cfg(unix)]
    let _ = std::fs::remove_file(socket_path);

    // Start listener (Unix socket on Linux/macOS, TCP on Windows)
    #[cfg(unix)]
    let listener = {
        match std::os::unix::net::UnixListener::bind(socket_path) {
            Ok(l) => {
                info!("Listening on {}", socket_path);
                l
            }
            Err(e) => {
                error!("Failed to bind socket {}: {}", socket_path, e);
                std::process::exit(1);
            }
        }
    };

    #[cfg(windows)]
    let listener = {
        match std::net::TcpListener::bind(socket_path) {
            Ok(l) => {
                info!("Listening on {}", socket_path);
                l
            }
            Err(e) => {
                error!("Failed to bind TCP {}: {}", socket_path, e);
                std::process::exit(1);
            }
        }
    };

    // ────────────────────────────────────────────────────────────
    //  v0.0.20.782: Listener loop — survives client disconnects
    //
    //  The engine keeps running and accepts new connections after
    //  a client disconnects. This prevents the reconnect-crash
    //  cycle: Python reconnects to the SAME engine process.
    // ────────────────────────────────────────────────────────────

    let mut global_shutdown = false;

    loop {
        if global_shutdown {
            break;
        }

        info!("Waiting for Python client connection...");

        match listener.accept() {
            Ok((stream, _addr)) => {
                info!("Client connected");

                // Create fresh command/event channels for this connection
                let (command_tx, command_rx) = bounded::<Command>(4096);
                let (event_tx, event_rx) = bounded::<Event>(4096);

                // v0.0.21.157: Start Unix-Datagram listener for direct editor-helper
                // param forwarding. Rust-to-Rust, no Python detour. The listener
                // pushes Command::SetPluginParam into the same command queue that
                // the Python IPC uses, so the existing handler logic in engine.rs
                // handles both sources identically.
                plugin_sync::start_plugin_sync_listener(command_tx.clone());

                // Create engine state (fresh per connection to avoid stale state)
                let engine_state = Arc::new(EngineState::new(
                    sample_rate,
                    buffer_size,
                    DEFAULT_BPM,
                    command_rx,
                    event_tx,
                ));

                // Start command drain ticker thread
                let engine_for_ticker = Arc::clone(&engine_state);
                let ticker_handle = std::thread::Builder::new()
                    .name("pydaw-cmd-tick".to_string())
                    .spawn(move || {
                        command_drain_ticker(engine_for_ticker);
                    })
                    .expect("Failed to spawn ticker thread");

                // Handle client connection (blocking until disconnect)
                {
                    let read_stream = stream.try_clone().expect("Failed to clone socket");
                    let write_stream = stream;

                    // Start IPC reader thread
                    let reader_handle = std::thread::Builder::new()
                        .name("pydaw-ipc-read".to_string())
                        .spawn(move || {
                            ipc_reader_thread(read_stream, command_tx);
                        })
                        .expect("Failed to spawn IPC reader");

                    // Start IPC writer thread
                    let writer_handle = std::thread::Builder::new()
                        .name("pydaw-ipc-write".to_string())
                        .spawn(move || {
                            ipc_writer_thread(write_stream, event_rx);
                        })
                        .expect("Failed to spawn IPC writer");

                    // Wait for both IPC threads to finish
                    let _ = reader_handle.join();
                    let _ = writer_handle.join();
                }

                // Check if Shutdown was received
                let was_shutdown = !engine_state
                    .running
                    .load(std::sync::atomic::Ordering::Relaxed);

                // Stop the ticker thread
                engine_state
                    .running
                    .store(false, std::sync::atomic::Ordering::Release);
                let _ = ticker_handle.join();

                if was_shutdown {
                    info!("Shutdown requested — exiting listener loop");
                    global_shutdown = true;
                } else {
                    info!("Client disconnected — waiting for next connection...");
                    std::thread::sleep(std::time::Duration::from_millis(100));
                }
            }
            Err(e) => {
                error!("Failed to accept connection: {}", e);
                std::thread::sleep(std::time::Duration::from_millis(500));
            }
        }
    }

    // Cleanup
    #[cfg(unix)]
    let _ = std::fs::remove_file(socket_path);

    info!("Py_DAW Audio Engine stopped");
}
