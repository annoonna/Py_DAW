# -*- coding: utf-8 -*-
"""Parameter Throttle — Rate-limited IPC for sliders and knobs.

v0.0.21.144 — UF-2: Knob/Slider Debouncing

Problem:
    Mixer faders/knobs emit valueChanged on EVERY mouse movement pixel.
    Each fires an IPC call to the Rust engine. At 60fps mouse movement,
    this means ~200 IPC calls/sec per slider — 90% are wasted.

Solution:
    ParamThrottle buffers the latest value per parameter and flushes
    at a configurable max rate (default 30Hz = 33ms). The visual slider
    updates instantly (Qt handles that), but the engine/bridge only
    receives the final value at 30Hz intervals.

Usage:
    # In __init__:
    self._throttle = ParamThrottle(interval_ms=33)  # 30Hz

    # In slider handler:
    self._throttle.push("volume", vol, self._flush_volume)

    # Cleanup:
    self._throttle.stop()
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional, Tuple

from PyQt6.QtCore import QTimer

_log = logging.getLogger(__name__)


class ParamThrottle:
    """Rate-limiter for parameter updates (30Hz default).

    Buffers the latest value for each parameter key and flushes
    all dirty parameters at a fixed interval via QTimer.
    """

    def __init__(self, interval_ms: int = 33, parent: Any = None):
        """Create a throttle.

        Args:
            interval_ms: Minimum time between flushes (default 33ms = ~30Hz).
            parent: Optional QObject parent for the timer.
        """
        self._interval = interval_ms
        # key → (value, callback, dirty_flag)
        self._pending: Dict[str, Tuple[Any, Callable, bool]] = {}
        self._timer = QTimer(parent)
        self._timer.setInterval(interval_ms)
        self._timer.timeout.connect(self._flush)
        self._timer.start()

    def push(self, key: str, value: Any, callback: Callable[[Any], None]) -> None:
        """Buffer a parameter update.

        If called multiple times before the next flush, only the LAST
        value is sent. The callback receives the final value.

        Args:
            key: Unique parameter ID (e.g. "track1:volume", "master:pan").
            value: The new parameter value.
            callback: Function to call with the value on flush.
        """
        self._pending[key] = (value, callback, True)

    def _flush(self) -> None:
        """Flush all dirty parameters (called by QTimer)."""
        for key in list(self._pending.keys()):
            val, cb, dirty = self._pending[key]
            if dirty:
                try:
                    cb(val)
                except Exception as e:
                    _log.debug("ParamThrottle flush error [%s]: %s", key, e)
                self._pending[key] = (val, cb, False)

    def flush_now(self) -> None:
        """Force immediate flush of all pending values."""
        self._flush()

    def stop(self) -> None:
        """Stop the timer and flush remaining values."""
        self._timer.stop()
        self._flush()

    def set_interval(self, ms: int) -> None:
        """Change the flush interval."""
        self._interval = ms
        self._timer.setInterval(ms)

    @property
    def pending_count(self) -> int:
        """Number of dirty parameters waiting to be flushed."""
        return sum(1 for _, _, dirty in self._pending.values() if dirty)
