"""Professional Audio Export Dialog (Studio-Style) for PyDAW.

Features:
- Format selection: WAVE, FLAC, OGG, MP3
- Quality/Bit-depth settings
- Track selection (multi-select)
- Time range: Arrangement / Loop-Region
- Sampling rate selection
- Options: Realtime, Dither, Pre-Fader, Open after export
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

from PyQt6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QComboBox,
    QListWidget,
    QListWidgetItem,
    QCheckBox,
    QGroupBox,
    QButtonGroup,
    QRadioButton,
    QFileDialog,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

from pydaw.services.cs2_slice0 import (
    beats_to_legacy_bbs_tick_text,
    time_signature_to_beats_per_bar,
)


log = logging.getLogger(__name__)


class AudioExportDialog(QDialog):
    """Professional audio export dialog like a modern DAW."""
    
    def __init__(self, project_service: Any, parent=None):
        super().__init__(parent)
        self.project = project_service
        self.selected_format = "wav"
        self.selected_quality = "16bit"
        self.export_path: Optional[Path] = None
        
        self.setWindowTitle("Audio exportieren")
        self.setMinimumWidth(700)
        self.setMinimumHeight(500)
        
        self._build_ui()
    
    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        layout.setContentsMargins(16, 16, 16, 16)
        
        # Title
        title = QLabel("Audio exportieren")
        title_font = QFont()
        title_font.setPointSize(14)
        title_font.setBold(True)
        title.setFont(title_font)
        layout.addWidget(title)
        
        # Format Selection Group
        format_group = QGroupBox("Format(e)")
        format_layout = QHBoxLayout(format_group)
        
        self.btn_group_format = QButtonGroup()
        
        self.btn_wav = QPushButton("WAVE")
        self.btn_wav.setCheckable(True)
        self.btn_wav.setChecked(True)
        self.btn_wav.setMinimumHeight(35)
        self.btn_wav.clicked.connect(lambda: self._on_format_changed("wav"))
        self.btn_group_format.addButton(self.btn_wav)
        format_layout.addWidget(self.btn_wav)
        
        self.btn_flac = QPushButton("FLAC")
        self.btn_flac.setCheckable(True)
        self.btn_flac.setMinimumHeight(35)
        self.btn_flac.clicked.connect(lambda: self._on_format_changed("flac"))
        self.btn_group_format.addButton(self.btn_flac)
        format_layout.addWidget(self.btn_flac)
        
        self.btn_ogg = QPushButton("OGG")
        self.btn_ogg.setCheckable(True)
        self.btn_ogg.setMinimumHeight(35)
        self.btn_ogg.clicked.connect(lambda: self._on_format_changed("ogg"))
        self.btn_group_format.addButton(self.btn_ogg)
        format_layout.addWidget(self.btn_ogg)
        
        self.btn_mp3 = QPushButton("MP3")
        self.btn_mp3.setCheckable(True)
        self.btn_mp3.setMinimumHeight(35)
        self.btn_mp3.setStyleSheet("QPushButton:checked { background-color: #ff8800; }")
        self.btn_mp3.clicked.connect(lambda: self._on_format_changed("mp3"))
        self.btn_group_format.addButton(self.btn_mp3)
        format_layout.addWidget(self.btn_mp3)
        
        layout.addWidget(format_group)
        
        # Quality Selection
        quality_layout = QHBoxLayout()
        
        self.cmb_quality = QComboBox()
        self.cmb_quality.addItem("16-bit", "16bit")
        self.cmb_quality.addItem("24-bit", "24bit")
        self.cmb_quality.addItem("32-bit", "32bit")
        self.cmb_quality.setMinimumHeight(30)
        quality_layout.addWidget(self.cmb_quality)
        
        quality_layout.addStretch(1)
        layout.addLayout(quality_layout)
        
        # Main content (Tracks + Time Range + Options)
        content_layout = QHBoxLayout()
        
        # LEFT: Tracks List
        tracks_group = QGroupBox("Spuren")
        tracks_layout = QVBoxLayout(tracks_group)
        
        self.tracks_list = QListWidget()
        self.tracks_list.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
        
        # Add Project Master
        item = QListWidgetItem("🎚️ Project Master")
        item.setData(Qt.ItemDataRole.UserRole, "master")
        self.tracks_list.addItem(item)
        item.setSelected(True)  # Default: Master selected
        
        # Add all tracks from project
        for track in self.project.ctx.project.tracks:
            track_name = getattr(track, "name", "Track")
            track_kind = getattr(track, "kind", "audio")
            
            if track_kind == "audio":
                icon = "🔊"
            elif track_kind == "instrument":
                icon = "🎹"
            elif track_kind == "master":
                continue  # Already added as Project Master
            else:
                icon = "🎚️"
            
            item = QListWidgetItem(f"{icon} {track_name}")
            item.setData(Qt.ItemDataRole.UserRole, track.id)
            self.tracks_list.addItem(item)
            item.setSelected(True)  # Default: All selected
        
        tracks_layout.addWidget(self.tracks_list)
        content_layout.addWidget(tracks_group, 1)
        
        # RIGHT: Time Range + Options
        right_layout = QVBoxLayout()
        
        # Time Range
        time_group = QGroupBox("Zeitabschnitt")
        time_layout = QVBoxLayout(time_group)
        
        # From/To
        from_layout = QHBoxLayout()
        from_layout.addWidget(QLabel("Von"))
        self.lbl_from = QLabel("1.1.1.00")
        self.lbl_from.setStyleSheet("QLabel { color: #00aaff; font-size: 18px; font-weight: bold; }")
        from_layout.addWidget(self.lbl_from)
        from_layout.addStretch(1)
        time_layout.addLayout(from_layout)
        
        to_layout = QHBoxLayout()
        to_layout.addWidget(QLabel("Bis"))
        self.lbl_to = QLabel("49.1.1.00")
        self.lbl_to.setStyleSheet("QLabel { color: #00aaff; font-size: 18px; font-weight: bold; }")
        to_layout.addWidget(self.lbl_to)
        to_layout.addStretch(1)
        time_layout.addLayout(to_layout)
        
        # Arrangement / Loop-Region buttons
        range_buttons = QHBoxLayout()
        self.btn_arrangement = QPushButton("⚙️ Arrangement")
        self.btn_arrangement.setCheckable(True)
        self.btn_arrangement.setChecked(True)
        self.btn_arrangement.clicked.connect(self._on_arrangement_clicked)
        range_buttons.addWidget(self.btn_arrangement)
        
        self.btn_loop = QPushButton("🔁 Loop-Region")
        self.btn_loop.setCheckable(True)
        self.btn_loop.clicked.connect(self._on_loop_clicked)
        range_buttons.addWidget(self.btn_loop)
        
        time_layout.addLayout(range_buttons)
        right_layout.addWidget(time_group)
        
        # Sampling Rate
        sr_group = QGroupBox("Sampling-Rate")
        sr_layout = QVBoxLayout(sr_group)
        
        self.cmb_samplerate = QComboBox()
        self.cmb_samplerate.addItem("Aktuelle", "current")
        self.cmb_samplerate.addItem("44100 Hz", 44100)
        self.cmb_samplerate.addItem("48000 Hz", 48000)
        self.cmb_samplerate.addItem("88200 Hz", 88200)
        self.cmb_samplerate.addItem("96000 Hz", 96000)
        sr_layout.addWidget(self.cmb_samplerate)
        right_layout.addWidget(sr_group)
        
        # Options
        options_group = QGroupBox("Optionen")
        options_layout = QVBoxLayout(options_group)
        
        self.chk_realtime = QCheckBox("Echtzeit")
        self.chk_realtime.setChecked(False)
        self.chk_realtime.setToolTip("Deaktiviert = Schnelles Offline-Rendering (empfohlen)")
        options_layout.addWidget(self.chk_realtime)
        
        self.chk_dither = QCheckBox("Dither (TPDF)")
        self.chk_dither.setChecked(True)
        options_layout.addWidget(self.chk_dither)

        self.cmb_dither_type = QComboBox()
        self.cmb_dither_type.addItem("TPDF (Standard)", "tpdf")
        self.cmb_dither_type.addItem("POW-R Type 1", "pow_r")
        self.cmb_dither_type.addItem("Keines", "none")
        options_layout.addWidget(self.cmb_dither_type)

        self.cmb_normalize = QComboBox()
        self.cmb_normalize.addItem("Keine Normalisierung", "none")
        self.cmb_normalize.addItem("Peak -0.3 dBFS", "peak")
        self.cmb_normalize.addItem("LUFS -14 (Streaming)", "lufs")
        options_layout.addWidget(self.cmb_normalize)

        # v0.0.20.650: Pre-/Post-FX Export (AP10 Phase 10B Task 4)
        self.cmb_fx_mode = QComboBox()
        self.cmb_fx_mode.addItem("Post-FX (mit Effekten)", "post_fx")
        self.cmb_fx_mode.addItem("Pre-FX (Dry / ohne Effekte)", "pre_fx")
        self.cmb_fx_mode.addItem("Beides (Wet + Dry)", "both")
        options_layout.addWidget(self.cmb_fx_mode)

        self.chk_prefader = QCheckBox("Pre-Fader")
        options_layout.addWidget(self.chk_prefader)
        
        self.chk_open_after = QCheckBox("Nach Export Zielordner öffnen")
        self.chk_open_after.setChecked(True)
        options_layout.addWidget(self.chk_open_after)
        
        right_layout.addWidget(options_group)
        right_layout.addStretch(1)
        
        content_layout.addLayout(right_layout, 1)
        layout.addLayout(content_layout)
        
        # Bottom Buttons
        button_layout = QHBoxLayout()
        button_layout.addStretch(1)
        
        self.btn_ok = QPushButton("OK")
        self.btn_ok.setMinimumWidth(100)
        self.btn_ok.setMinimumHeight(35)
        self.btn_ok.clicked.connect(self._on_ok)
        button_layout.addWidget(self.btn_ok)
        
        self.btn_cancel = QPushButton("Abbrechen")
        self.btn_cancel.setMinimumWidth(100)
        self.btn_cancel.setMinimumHeight(35)
        self.btn_cancel.clicked.connect(self.reject)
        button_layout.addWidget(self.btn_cancel)
        
        layout.addLayout(button_layout)
        
        # Update time range from project
        self._update_time_range()
    
    def _on_format_changed(self, format_name: str) -> None:
        """Format button clicked."""
        self.selected_format = format_name
        
        # Update quality options based on format
        self.cmb_quality.clear()
        
        if format_name in ("wav", "flac"):
            # Lossless formats: bit depth
            self.cmb_quality.addItem("16-bit", "16bit")
            self.cmb_quality.addItem("24-bit", "24bit")
            self.cmb_quality.addItem("32-bit", "32bit")
        elif format_name == "mp3":
            # MP3: bitrate
            self.cmb_quality.addItem("128kbit/s", "128k")
            self.cmb_quality.addItem("192kbit/s", "192k")
            self.cmb_quality.addItem("256kbit/s", "256k")
            self.cmb_quality.addItem("320kbit/s (CBR)", "320k")
            self.cmb_quality.setCurrentIndex(3)  # 320k default
        elif format_name == "ogg":
            # OGG: quality
            self.cmb_quality.addItem("Quality 3 (~112kbit/s)", "q3")
            self.cmb_quality.addItem("Quality 5 (~160kbit/s)", "q5")
            self.cmb_quality.addItem("Quality 7 (~224kbit/s)", "q7")
            self.cmb_quality.addItem("Quality 10 (~500kbit/s)", "q10")
            self.cmb_quality.setCurrentIndex(2)  # q7 default
    
    def _on_arrangement_clicked(self) -> None:
        """Arrangement button clicked."""
        if self.btn_arrangement.isChecked():
            self.btn_loop.setChecked(False)
            self._update_time_range()
    
    def _on_loop_clicked(self) -> None:
        """Loop-Region button clicked."""
        if self.btn_loop.isChecked():
            self.btn_arrangement.setChecked(False)
            self._update_time_range_loop()
    
    def _project_beats_per_bar(self) -> float:
        project = getattr(getattr(self.project, "ctx", None), "project", None)
        time_sig = getattr(project, "time_signature", "4/4") if project is not None else "4/4"
        return max(0.25, float(time_signature_to_beats_per_bar(time_sig)))

    def _format_export_bbs_label(self, beats: float) -> str:
        bpb = self._project_beats_per_bar()
        text = beats_to_legacy_bbs_tick_text(beats, beats_per_bar=bpb)
        log.debug("[CS2-Q] AudioExportDialog BBS helper beats=%.6f bpb=%.6f text=%s", float(beats), bpb, text)
        return text

    def _update_time_range(self) -> None:
        """Update time range labels for full arrangement."""
        max_beat = 0.0
        for clip in self.project.ctx.project.clips:
            clip_end = float(getattr(clip, "start_beats", 0.0)) + float(getattr(clip, "length_beats", 0.0))
            max_beat = max(max_beat, clip_end)

        self.lbl_from.setText(self._format_export_bbs_label(0.0))
        self.lbl_to.setText(self._format_export_bbs_label(max_beat))

    def _update_time_range_loop(self) -> None:
        """Update time range labels for loop region."""
        transport = getattr(self.project, "transport", None)
        start_beat = 0.0
        end_beat = 16.0
        try:
            if transport is not None:
                start_beat = float(getattr(transport, "loop_start", 0.0))
                end_beat = float(getattr(transport, "loop_end", 16.0))
                if end_beat <= start_beat:
                    end_beat = max(start_beat, start_beat + self._project_beats_per_bar())
        except Exception as exc:
            log.debug("[CS2-Q] AudioExportDialog loop label fallback active: %s", exc)

        self.lbl_from.setText(self._format_export_bbs_label(start_beat))
        self.lbl_to.setText(self._format_export_bbs_label(end_beat))
    
    def _on_ok(self) -> None:
        """OK button clicked - start export."""
        # Get selected tracks
        selected_tracks = []
        for i in range(self.tracks_list.count()):
            item = self.tracks_list.item(i)
            if item.isSelected():
                track_id = item.data(Qt.ItemDataRole.UserRole)
                selected_tracks.append(track_id)
        
        if not selected_tracks:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Keine Spuren", "Bitte mindestens eine Spur auswählen!")
            return
        
        # Build suggested filename
        try:
            project = self.project.ctx.project
            project_name = str(getattr(project, "name", "Py_DAW") or "Py_DAW")
            bpm = int(float(getattr(project, "bpm", 120.0) or 120.0))
        except Exception:
            project_name = "Py_DAW"
            bpm = 120
        safe_name = "".join(c if c.isalnum() or c in " _-" else "_" for c in project_name).strip()
        
        ext_map = {"wav": "wav", "flac": "flac", "ogg": "ogg", "mp3": "mp3"}
        ext = ext_map.get(self.selected_format, "wav")
        suggested = f"{safe_name}_{bpm}BPM.{ext}"
        
        # Filter string for file dialog
        filter_map = {
            "wav": "WAVE Audio (*.wav)",
            "flac": "FLAC Audio (*.flac)",
            "ogg": "OGG Vorbis (*.ogg)",
            "mp3": "MP3 Audio (*.mp3)",
        }
        file_filter = filter_map.get(self.selected_format, "Audio (*.wav)")
        
        # Ask for output file (with filename!)
        default_path = str(Path.home() / "Musik" / suggested)
        filepath, _ = QFileDialog.getSaveFileName(
            self,
            "Audio exportieren als...",
            default_path,
            file_filter,
        )
        
        if not filepath:
            return  # User cancelled
        
        # Parse filepath into directory + filename base
        export_path = Path(filepath)
        output_dir = str(export_path.parent)
        filename_base = export_path.stem  # without extension
        
        self.export_path = export_path

        # Build export config
        try:
            from pydaw.services.audio_export_service import ExportConfig, export_audio

            format_ext = self.selected_format
            quality_data = self.cmb_quality.currentData()

            # Bit depth
            bit_depth = 24
            if quality_data in ("16bit",):
                bit_depth = 16
            elif quality_data in ("24bit",):
                bit_depth = 24
            elif quality_data in ("32bit",):
                bit_depth = 32

            # MP3 bitrate
            mp3_bitrate = 320
            for br in (128, 192, 256, 320):
                if quality_data == f"{br}k":
                    mp3_bitrate = br

            # OGG quality
            ogg_quality = 7
            for q in (3, 5, 7, 10):
                if quality_data == f"q{q}":
                    ogg_quality = q

            # Sample rate
            sr_data = self.cmb_samplerate.currentData()
            sample_rate = int(sr_data) if isinstance(sr_data, int) else 0

            # Dither
            dither = "none"
            if self.chk_dither.isChecked():
                dither = str(self.cmb_dither_type.currentData() or "tpdf")

            # Normalize
            normalize_mode = str(self.cmb_normalize.currentData() or "none")

            # Project info
            project = self.project.ctx.project
            project_name = str(getattr(project, "name", "Py_DAW") or "Py_DAW")
            bpm = float(getattr(project, "bpm", 120.0) or 120.0)

            # Time range
            start_beat = 0.0
            end_beat = -1.0  # auto-detect
            if self.btn_loop.isChecked():
                try:
                    transport = getattr(self.project, '_transport', None)
                    if transport:
                        start_beat = float(getattr(transport, 'loop_start_beat', 0.0))
                        end_beat = float(getattr(transport, 'loop_end_beat', -1.0))
                except Exception:
                    pass

            # v0.0.20.650: FX Mode (AP10 Phase 10B Task 4)
            fx_mode = str(self.cmb_fx_mode.currentData() or "post_fx")

            config = ExportConfig(
                output_dir=str(output_dir),
                filename_base=filename_base,
                format=format_ext,
                bit_depth=bit_depth,
                mp3_bitrate=mp3_bitrate,
                ogg_quality=ogg_quality,
                sample_rate=sample_rate,
                normalize_mode=normalize_mode,
                normalize_target_db=-0.3,
                normalize_target_lufs=-14.0,
                dither=dither,
                start_beat=start_beat,
                end_beat=end_beat,
                track_ids=selected_tracks,
                stem_export=len(selected_tracks) > 1 and "master" not in selected_tracks,
                project_name=project_name,
                bpm=bpm,
                fx_mode=fx_mode,
            )

            # Create a render function from AudioEngine (v0.0.20.778)
            def _render_func(start_b, end_b, track_ids, sr, include_fx=True):
                try:
                    # v0.0.20.778: Use AudioEngine.render_offline() — the actual backend
                    from pydaw.audio.audio_engine import AudioEngine
                    ae = None
                    # Try to find audio_engine via services
                    try:
                        mw = self.parent()
                        if mw and hasattr(mw, 'services'):
                            ae = getattr(mw.services, 'audio_engine', None)
                    except Exception:
                        pass
                    # Fallback: try project_service reference
                    if ae is None:
                        try:
                            ae = getattr(self.project, '_audio_engine', None)
                        except Exception:
                            pass

                    if ae is not None and hasattr(ae, 'render_offline'):
                        return ae.render_offline(start_b, end_b, track_ids, sr,
                                                  include_fx=include_fx)

                    # Legacy fallback: try old renderer path
                    renderer = getattr(self.project, 'arrangement_renderer', None)
                    if renderer is None:
                        renderer = getattr(self.project, '_renderer', None)
                    if renderer and hasattr(renderer, 'render_offline'):
                        try:
                            return renderer.render_offline(start_b, end_b, track_ids, sr,
                                                           include_fx=include_fx)
                        except TypeError:
                            return renderer.render_offline(start_b, end_b, track_ids, sr)
                except Exception as e:
                    _log_export = logging.getLogger(__name__)
                    _log_export.error("Render function error: %s", e)
                    import traceback, sys
                    traceback.print_exc(file=sys.stderr)
                return None

            # Progress dialog
            from PyQt6.QtWidgets import QProgressDialog, QMessageBox
            from PyQt6.QtCore import QThread, pyqtSignal, QTimer

            progress = QProgressDialog("Audio Export — Rendering...", "Abbrechen", 0, 100, self)
            progress.setWindowTitle("Audio Export")
            progress.setMinimumDuration(0)
            progress.setValue(0)

            # v0.0.20.780: Run export in background thread (realtime capture blocks)
            class _ExportThread(QThread):
                finished = pyqtSignal(list)
                progress_update = pyqtSignal(float, str)

                def __init__(self, cfg, rfunc):
                    super().__init__()
                    self._cfg = cfg
                    self._rfunc = rfunc

                def run(self):
                    def _prog(pct, msg):
                        self.progress_update.emit(pct, msg)
                    result = export_audio(self._cfg, self._rfunc, _prog)
                    self.finished.emit(result)

            export_thread = _ExportThread(config, _render_func)
            exported_result = []

            def _on_progress(pct, msg):
                try:
                    progress.setValue(int(pct * 100))
                    progress.setLabelText(msg)
                except Exception:
                    pass

            def _on_finished(result):
                exported_result.extend(result)
                progress.close()

            export_thread.progress_update.connect(_on_progress)
            export_thread.finished.connect(_on_finished)
            export_thread.start()

            # Block dialog until export finishes (but Qt events keep processing)
            while export_thread.isRunning():
                from PyQt6.QtWidgets import QApplication
                QApplication.processEvents()
                import time
                time.sleep(0.05)
                if progress.wasCanceled():
                    # v0.0.20.783: For offline rendering, we can't easily abort
                    # mid-render. Just wait for the thread to finish naturally.
                    break

            export_thread.wait(5000)
            progress.close()

            if exported_result:
                msg = f"Erfolgreich exportiert:\n\n"
                for f in exported_result:
                    msg += f"• {Path(f).name}\n"
                msg += f"\nZiel: {output_dir}"
                QMessageBox.information(self, "Export Fertig", msg)
            else:
                QMessageBox.warning(
                    self, "Export",
                    f"Export konfiguriert für {format_ext.upper()} "
                    f"({quality_data}).\n\n"
                    f"Renderer konnte keine Audiodaten erzeugen.\n"
                    f"Tipp: Stelle sicher dass Instrumente geladen sind."
                )

        except Exception as e:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Export Fehler", f"Export fehlgeschlagen:\n{e}")
        
        self.accept()
