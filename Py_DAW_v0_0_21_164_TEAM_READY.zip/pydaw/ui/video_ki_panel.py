"""video_ki_panel.py — Video-KI Assistent Panel (v0.0.20.920).

VK8: Zentrale UI für alle Video-KI-Features:
- "🎬 Alles analysieren" → VK1 Szenen + VK2 Dialog + VK3 Stimmung
- Szenen-Liste mit Farb-Indikatoren, Timecode, Mood-Tags
- Dialog-Regionen Liste
- "🔇 Auto-Duck" → Automation-Breakpoints für Musik-Tracks
- Sound-Vorschläge pro Szene → "🎵 Vertonen" Button
- Stimmungs-Details pro Szene (Valence/Energy/Tension/Darkness)

Usage:
    panel = VideoKIPanel(services=self.services, parent=self)
    dock = QDockWidget("🎬 Video-KI", self)
    dock.setWidget(panel)
"""

from __future__ import annotations

import json
import logging
import os
import time
from typing import Any, Dict, List, Optional

from PyQt6.QtCore import Qt, pyqtSignal, QThread, QTimer
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QListWidget, QListWidgetItem, QGroupBox,
    QSpinBox, QDoubleSpinBox, QLineEdit, QTextEdit,
    QMessageBox, QFileDialog, QScrollArea, QFrame,
    QSizePolicy, QProgressBar, QSplitter, QTabWidget,
)

from pydaw.services.cs2_slice0 import beat_to_bar_number, time_signature_to_beats_per_bar

log = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════
# Background Analysis Worker
# ══════════════════════════════════════════════════════════════

class _AnalysisWorker(QThread):
    """Background thread for video analysis (VK1+VK2+VK3)."""

    progress = pyqtSignal(str)       # status message
    finished = pyqtSignal(dict)      # result dict
    error = pyqtSignal(str)

    def __init__(self, video_path: str, scene_threshold: float = 0.35,
                 dialog_threshold_db: float = -35.0, parent=None):
        super().__init__(parent)
        self._video_path = video_path
        self._scene_threshold = scene_threshold
        self._dialog_threshold_db = dialog_threshold_db

    def run(self):
        try:
            from pydaw.services.video_ki_service import VideoKIService
            vki = VideoKIService()

            self.progress.emit("🎬 Szenen werden erkannt…")
            result = vki.analyze_all(
                self._video_path,
                scene_threshold=self._scene_threshold,
                dialog_threshold_db=self._dialog_threshold_db,
            )
            # Attach the service instance so the panel can use it
            result["_service"] = vki
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))


# ══════════════════════════════════════════════════════════════
# Video-KI Panel Widget
# ══════════════════════════════════════════════════════════════

class VideoKIPanel(QWidget):
    """Zentrales Video-KI Panel (VK8).

    Verbindet VK1 (Szenen) + VK2 (Dialog) + VK3 (Stimmung + Sounds)
    in einer bedienbaren Oberfläche.
    """

    status = pyqtSignal(str)

    def __init__(self, services=None, parent=None):
        super().__init__(parent)
        self._services = services
        self._vki = None            # VideoKIService instance
        self._video_path = ""
        self._worker = None
        self._selected_scene_idx = -1

        self._build_ui()

    # ──────────────────────────────────────────────────────────
    # UI Build
    # ──────────────────────────────────────────────────────────

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)

        # ── Header ──
        header = QHBoxLayout()
        title = QLabel("🎬 Video-KI Assistent")
        title.setStyleSheet("font-size: 14px; font-weight: bold; color: #e0e0e0;")
        header.addWidget(title)
        header.addStretch(1)

        self._btn_analyze = QPushButton("🎬 Alles analysieren")
        self._btn_analyze.setStyleSheet(
            "QPushButton { background: #1a3a5a; border: 1px solid #4488cc; "
            "border-radius: 5px; color: #88ccff; font-size: 13px; font-weight: bold; "
            "padding: 8px 16px; }"
            "QPushButton:hover { background: #2a4a6a; }"
            "QPushButton:disabled { color: #555; border-color: #444; }"
        )
        self._btn_analyze.clicked.connect(self._start_analysis)
        header.addWidget(self._btn_analyze)
        root.addLayout(header)

        # ── Video file ──
        file_row = QHBoxLayout()
        self._lbl_video = QLabel("Kein Video geladen")
        self._lbl_video.setStyleSheet("color: #9aa0a6; font-size: 11px;")
        file_row.addWidget(self._lbl_video, 1)
        btn_load = QPushButton("📂")
        btn_load.setFixedSize(28, 28)
        btn_load.setToolTip("Video laden")
        btn_load.clicked.connect(self._load_video)
        file_row.addWidget(btn_load)
        root.addLayout(file_row)

        # ── Progress ──
        self._progress = QProgressBar()
        self._progress.setRange(0, 0)  # indeterminate
        self._progress.setVisible(False)
        self._progress.setFixedHeight(16)
        self._progress.setStyleSheet(
            "QProgressBar { background: #1a1a2e; border: 1px solid #333; border-radius: 3px; }"
            "QProgressBar::chunk { background: #4488cc; }"
        )
        root.addWidget(self._progress)

        self._lbl_progress = QLabel("")
        self._lbl_progress.setStyleSheet("color: #88ccff; font-size: 11px;")
        root.addWidget(self._lbl_progress)

        # ── Tabs ──
        self._tabs = QTabWidget()
        self._tabs.setStyleSheet(
            "QTabWidget::pane { border: 1px solid #444; border-top: none; }"
            "QTabBar::tab { background: #1a1a2e; color: #aaa; padding: 6px 12px; "
            "border: 1px solid #444; border-bottom: none; margin-right: 2px; }"
            "QTabBar::tab:selected { background: #2a2a3e; color: #e0e0e0; }"
        )

        # Tab 1: Szenen
        self._tab_scenes = QWidget()
        self._build_scenes_tab()
        self._tabs.addTab(self._tab_scenes, "🎬 Szenen")

        # Tab 2: Dialog + Duck
        self._tab_dialog = QWidget()
        self._build_dialog_tab()
        self._tabs.addTab(self._tab_dialog, "🗣 Dialog")

        # Tab 3: Vorschläge
        self._tab_suggestions = QWidget()
        self._build_suggestions_tab()
        self._tabs.addTab(self._tab_suggestions, "🎵 Sounds")

        # Tab 4: Extras (VK4+VK5+VK6)
        self._tab_extras = QWidget()
        self._build_extras_tab()
        self._tabs.addTab(self._tab_extras, "📋 Extras")

        root.addWidget(self._tabs, 1)

    def _build_scenes_tab(self) -> None:
        lay = QVBoxLayout(self._tab_scenes)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(4)

        self._lst_scenes = QListWidget()
        self._lst_scenes.setStyleSheet(
            "QListWidget { background: #0e0e1a; color: #d0d0d8; border: none; "
            "font-size: 12px; }"
            "QListWidget::item { padding: 6px 8px; border-bottom: 1px solid #222; }"
            "QListWidget::item:selected { background: #2a3a5a; }"
        )
        self._lst_scenes.currentRowChanged.connect(self._on_scene_selected)
        lay.addWidget(self._lst_scenes, 1)

        # Scene detail
        self._lbl_scene_detail = QLabel("Szene auswählen für Details")
        self._lbl_scene_detail.setStyleSheet(
            "color: #b0b8c0; font-size: 11px; padding: 6px; "
            "background: #12121e; border: 1px solid #333; border-radius: 4px;"
        )
        self._lbl_scene_detail.setWordWrap(True)
        self._lbl_scene_detail.setMinimumHeight(80)
        lay.addWidget(self._lbl_scene_detail)

        # Mood bars
        self._mood_bars = {}
        mood_frame = QFrame()
        mood_frame.setStyleSheet("QFrame { background: #12121e; border: 1px solid #333; border-radius: 4px; }")
        mood_lay = QVBoxLayout(mood_frame)
        mood_lay.setContentsMargins(8, 6, 8, 6)
        mood_lay.setSpacing(3)
        for name, color in [("Valence", "#6bd490"), ("Energy", "#e0c040"),
                            ("Tension", "#e06060"), ("Intimacy", "#a070d0"),
                            ("Darkness", "#607090")]:
            row = QHBoxLayout()
            row.setSpacing(4)
            lbl = QLabel(f"{name}:")
            lbl.setFixedWidth(65)
            lbl.setStyleSheet("color: #999; font-size: 10px;")
            row.addWidget(lbl)
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(50)
            bar.setFixedHeight(12)
            bar.setTextVisible(False)
            bar.setStyleSheet(
                f"QProgressBar {{ background: #1a1a2e; border: none; border-radius: 2px; }}"
                f"QProgressBar::chunk {{ background: {color}; border-radius: 2px; }}"
            )
            row.addWidget(bar, 1)
            val_lbl = QLabel("0.50")
            val_lbl.setFixedWidth(35)
            val_lbl.setStyleSheet("color: #888; font-size: 10px;")
            val_lbl.setAlignment(Qt.AlignmentFlag.AlignRight)
            row.addWidget(val_lbl)
            self._mood_bars[name.lower()] = (bar, val_lbl)
            mood_lay.addLayout(row)
        lay.addWidget(mood_frame)

    def _build_dialog_tab(self) -> None:
        lay = QVBoxLayout(self._tab_dialog)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(6)

        self._lst_dialogs = QListWidget()
        self._lst_dialogs.setStyleSheet(
            "QListWidget { background: #0e0e1a; color: #d0d0d8; border: none; }"
            "QListWidget::item { padding: 4px 8px; border-bottom: 1px solid #222; }"
        )
        lay.addWidget(self._lst_dialogs, 1)

        # Duck controls
        grp = QGroupBox("🔇 Auto-Duck")
        grp.setStyleSheet(
            "QGroupBox { font-weight: bold; color: #c8c8d4; border: 1px solid #444; "
            "border-radius: 6px; margin-top: 8px; padding-top: 16px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }"
        )
        duck_lay = QVBoxLayout(grp)
        duck_lay.setSpacing(4)

        set_row = QHBoxLayout()
        set_row.addWidget(QLabel("Absenkung:"))
        self._spn_duck_db = QSpinBox()
        self._spn_duck_db.setRange(-24, -3)
        self._spn_duck_db.setValue(-8)
        self._spn_duck_db.setSuffix(" dB")
        self._spn_duck_db.setFixedWidth(75)
        set_row.addWidget(self._spn_duck_db)

        set_row.addWidget(QLabel("Fade:"))
        self._spn_duck_fade = QDoubleSpinBox()
        self._spn_duck_fade.setRange(0.05, 2.0)
        self._spn_duck_fade.setValue(0.3)
        self._spn_duck_fade.setSuffix(" s")
        self._spn_duck_fade.setDecimals(2)
        self._spn_duck_fade.setFixedWidth(70)
        set_row.addWidget(self._spn_duck_fade)
        set_row.addStretch(1)
        duck_lay.addLayout(set_row)

        btn_row = QHBoxLayout()
        self._btn_duck = QPushButton("🔇 Musik ducken wo gesprochen wird")
        self._btn_duck.setEnabled(False)
        self._btn_duck.setStyleSheet(
            "QPushButton { background: #2a2a1a; border: 1px solid #aa8844; "
            "border-radius: 4px; color: #d4b070; font-size: 12px; padding: 6px 12px; }"
            "QPushButton:hover { background: #3a3a2a; }"
            "QPushButton:disabled { color: #555; border-color: #444; }"
        )
        self._btn_duck.clicked.connect(self._apply_auto_duck)
        btn_row.addWidget(self._btn_duck)
        btn_row.addStretch(1)
        duck_lay.addLayout(btn_row)

        self._lbl_duck_status = QLabel("")
        self._lbl_duck_status.setStyleSheet("color: #9aa0a6; font-size: 11px;")
        duck_lay.addWidget(self._lbl_duck_status)
        lay.addWidget(grp)

    def _build_suggestions_tab(self) -> None:
        lay = QVBoxLayout(self._tab_suggestions)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(6)

        info = QLabel("Szene im Tab 'Szenen' auswählen → Sound-Vorschläge erscheinen hier\n"
                     "Klicke 'Anwenden' → Track + AETERNA Instrument + MIDI-Noten "
                     "werden an der Szenen-Position erstellt")
        info.setStyleSheet("color: #777; font-size: 11px;")
        info.setWordWrap(True)
        lay.addWidget(info)

        self._lst_suggestions = QListWidget()
        self._lst_suggestions.setStyleSheet(
            "QListWidget { background: #0e0e1a; color: #d0d0d8; border: none; "
            "font-size: 12px; }"
            "QListWidget::item { padding: 8px; border-bottom: 1px solid #222; }"
            "QListWidget::item:selected { background: #2a3a2a; }"
        )
        lay.addWidget(self._lst_suggestions, 1)

        # Vertonen button
        btn_row = QHBoxLayout()
        self._btn_apply_sound = QPushButton("🎵 Ausgewählten Sound auf Spur anwenden")
        self._btn_apply_sound.setEnabled(False)
        self._btn_apply_sound.setStyleSheet(
            "QPushButton { background: #1a3a2a; border: 1px solid #44aa66; "
            "border-radius: 4px; color: #88dd99; font-size: 12px; padding: 6px 12px; }"
            "QPushButton:hover { background: #2a4a3a; }"
            "QPushButton:disabled { color: #555; border-color: #444; }"
        )
        self._btn_apply_sound.clicked.connect(self._apply_selected_sound)
        btn_row.addWidget(self._btn_apply_sound)

        self._btn_apply_all = QPushButton("🎶 Alle Szenen vertonen")
        self._btn_apply_all.setEnabled(False)
        self._btn_apply_all.setToolTip("Für jede Szene den Top-Vorschlag als Instrument-Track erstellen")
        self._btn_apply_all.setStyleSheet(
            "QPushButton { background: #1a2a3a; border: 1px solid #4488aa; "
            "border-radius: 4px; color: #88bbdd; font-size: 11px; padding: 4px 8px; }"
            "QPushButton:hover { background: #2a3a4a; }"
            "QPushButton:disabled { color: #555; border-color: #444; }"
        )
        self._btn_apply_all.clicked.connect(self._apply_all_scenes)
        btn_row.addWidget(self._btn_apply_all)
        btn_row.addStretch(1)
        lay.addLayout(btn_row)

        self._lbl_suggestion_detail = QLabel("")
        self._lbl_suggestion_detail.setStyleSheet(
            "color: #b0b8c0; font-size: 11px; padding: 6px; "
            "background: #12121e; border: 1px solid #333; border-radius: 4px;"
        )
        self._lbl_suggestion_detail.setWordWrap(True)
        lay.addWidget(self._lbl_suggestion_detail)

    def _build_extras_tab(self) -> None:
        lay = QVBoxLayout(self._tab_extras)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(8)

        # ── VK5: Beat-to-Cut ──
        grp_btc = QGroupBox("✂ Beat-to-Cut (VK5)")
        grp_btc.setStyleSheet(self._grp_style())
        btc_lay = QVBoxLayout(grp_btc)
        btc_lay.setSpacing(4)
        self._lst_beat_cuts = QListWidget()
        self._lst_beat_cuts.setMaximumHeight(100)
        self._lst_beat_cuts.setStyleSheet(
            "QListWidget { background: #0e0e1a; color: #d0d0d8; border: none; }"
            "QListWidget::item { padding: 3px 6px; border-bottom: 1px solid #222; }"
        )
        btc_lay.addWidget(self._lst_beat_cuts)
        btn_btc = QPushButton("✂ Beat-to-Cut berechnen")
        btn_btc.setStyleSheet(self._action_btn_style())
        btn_btc.clicked.connect(self._calc_beat_cuts)
        btc_lay.addWidget(btn_btc)
        lay.addWidget(grp_btc)

        # ── VK6: ADR/Foley Cue-Sheet ──
        grp_cue = QGroupBox("📋 ADR/Foley Cue-Sheet (VK6)")
        grp_cue.setStyleSheet(self._grp_style())
        cue_lay = QVBoxLayout(grp_cue)
        cue_lay.setSpacing(4)
        self._lst_cues = QListWidget()
        self._lst_cues.setMaximumHeight(120)
        self._lst_cues.setStyleSheet(
            "QListWidget { background: #0e0e1a; color: #d0d0d8; border: none; }"
            "QListWidget::item { padding: 3px 6px; border-bottom: 1px solid #222; }"
        )
        cue_lay.addWidget(self._lst_cues)
        cue_btn_row = QHBoxLayout()
        btn_gen_cue = QPushButton("📋 Cue-Sheet generieren")
        btn_gen_cue.setStyleSheet(self._action_btn_style())
        btn_gen_cue.clicked.connect(self._gen_cue_sheet)
        cue_btn_row.addWidget(btn_gen_cue)
        btn_export_cue = QPushButton("💾 CSV Export")
        btn_export_cue.setStyleSheet(self._action_btn_style())
        btn_export_cue.clicked.connect(self._export_cue_csv)
        cue_btn_row.addWidget(btn_export_cue)
        cue_btn_row.addStretch(1)
        cue_lay.addLayout(cue_btn_row)
        lay.addWidget(grp_cue)

        # ── VK4: Untertitel ──
        grp_sub = QGroupBox("💬 Untertitel (VK4 — Whisper optional)")
        grp_sub.setStyleSheet(self._grp_style())
        sub_lay = QVBoxLayout(grp_sub)
        sub_lay.setSpacing(4)
        self._lst_subtitles = QListWidget()
        self._lst_subtitles.setMaximumHeight(100)
        self._lst_subtitles.setStyleSheet(
            "QListWidget { background: #0e0e1a; color: #d0d0d8; border: none; }"
            "QListWidget::item { padding: 3px 6px; border-bottom: 1px solid #222; }"
        )
        sub_lay.addWidget(self._lst_subtitles)
        sub_btn_row = QHBoxLayout()
        btn_transcribe = QPushButton("💬 Transkribieren (Whisper)")
        btn_transcribe.setStyleSheet(self._action_btn_style())
        btn_transcribe.clicked.connect(self._transcribe)
        sub_btn_row.addWidget(btn_transcribe)
        btn_export_srt = QPushButton("💾 SRT Export")
        btn_export_srt.setStyleSheet(self._action_btn_style())
        btn_export_srt.clicked.connect(self._export_srt)
        sub_btn_row.addWidget(btn_export_srt)
        sub_btn_row.addStretch(1)
        sub_lay.addLayout(sub_btn_row)
        self._lbl_sub_status = QLabel("Whisper: pip install openai-whisper")
        self._lbl_sub_status.setStyleSheet("color: #777; font-size: 10px;")
        sub_lay.addWidget(self._lbl_sub_status)
        lay.addWidget(grp_sub)

        lay.addStretch(1)

    @staticmethod
    def _grp_style() -> str:
        return (
            "QGroupBox { font-weight: bold; color: #c8c8d4; border: 1px solid #444; "
            "border-radius: 6px; margin-top: 8px; padding-top: 16px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }"
        )

    @staticmethod
    def _action_btn_style() -> str:
        return (
            "QPushButton { background: #1a2a3a; border: 1px solid #4488aa; "
            "border-radius: 4px; color: #88bbdd; font-size: 11px; padding: 4px 10px; }"
            "QPushButton:hover { background: #2a3a4a; }"
            "QPushButton:disabled { color: #555; border-color: #444; }"
        )

    # ── VK5 handlers ──

    def _calc_beat_cuts(self) -> None:
        try:
            if not self._vki or not self._vki.scenes:
                QMessageBox.information(self, "Beat-to-Cut", "Zuerst Video analysieren.")
                return
            bpm = self._get_bpm()
            cuts = self._vki.suggest_beat_cuts_for_scenes(bpm)
            self._lst_beat_cuts.clear()
            for c in cuts:
                self._lst_beat_cuts.addItem(
                    f"Szene {c.scene_index+1}: Schnitt {c.direction} um "
                    f"{c.offset_ms:.0f}ms verschieben → Beat {c.nearest_beat:.0f}"
                )
        except Exception as e:
            log.error("[VK5] beat-to-cut: %s", e)

    # ── VK6 handlers ──

    def _gen_cue_sheet(self) -> None:
        try:
            if not self._vki or not self._vki.scenes:
                QMessageBox.information(self, "Cue-Sheet", "Zuerst Video analysieren.")
                return
            entries = self._vki.generate_cue_sheet_for_video()
            self._lst_cues.clear()
            for e in entries:
                color = {"ADR": "#e08080", "Foley": "#80b0e0", "Ambience": "#80c080"}.get(e.cue_type, "#aaa")
                item = QListWidgetItem(f"[{e.cue_id}] {e.timecode} — {e.cue_type}: {e.description}")
                item.setForeground(QColor(color))
                self._lst_cues.addItem(item)
        except Exception as e:
            log.error("[VK6] cue-sheet: %s", e)

    def _export_cue_csv(self) -> None:
        try:
            if not self._vki or not self._vki.cue_sheet:
                self._gen_cue_sheet()
            if not self._vki or not self._vki.cue_sheet:
                return
            from pydaw.services.video_ki_service import export_cue_sheet_csv
            path, _ = QFileDialog.getSaveFileName(self, "Cue-Sheet Export", "cue_sheet.csv", "CSV (*.csv)")
            if not path:
                return
            with open(path, "w", encoding="utf-8") as f:
                f.write(export_cue_sheet_csv(self._vki.cue_sheet))
            QMessageBox.information(self, "Export", f"✅ Cue-Sheet exportiert: {path}")
        except Exception as e:
            log.error("[VK6] export: %s", e)

    # ── VK4 handlers ──

    def _transcribe(self) -> None:
        try:
            if not self._vki:
                QMessageBox.information(self, "Untertitel", "Zuerst Video analysieren.")
                return
            path = self._video_path or (self._vki._video_path if self._vki else "")
            if not path:
                QMessageBox.information(self, "Untertitel", "Kein Video geladen.")
                return
            try:
                import whisper  # type: ignore  # noqa: F401
            except ImportError:
                QMessageBox.information(self, "Whisper",
                    "Whisper ist nicht installiert.\n\n"
                    "Installieren mit:\n  pip install openai-whisper\n\n"
                    "Modelle: tiny (39MB), base (74MB), small (244MB)")
                return
            self._lbl_sub_status.setText("⏳ Transkribiere… (kann 1-5 Min. dauern)")
            from PyQt6.QtWidgets import QApplication
            QApplication.processEvents()
            segments = self._vki.transcribe(path, model_size="base")
            self._lst_subtitles.clear()
            for seg in segments:
                m_s = int(seg.start_seconds) // 60
                s_s = int(seg.start_seconds) % 60
                self._lst_subtitles.addItem(f"[{m_s}:{s_s:02d}] {seg.text}")
            self._lbl_sub_status.setText(f"✅ {len(segments)} Segmente transkribiert")
            self._lbl_sub_status.setStyleSheet("color: #7bd389; font-size: 10px;")
        except Exception as e:
            self._lbl_sub_status.setText(f"❌ {e}")
            log.error("[VK4] transcribe: %s", e)

    def _export_srt(self) -> None:
        try:
            if not self._vki or not self._vki.subtitles:
                QMessageBox.information(self, "SRT Export", "Zuerst transkribieren.")
                return
            from pydaw.services.video_ki_service import export_subtitles_srt
            path, _ = QFileDialog.getSaveFileName(self, "SRT Export", "subtitles.srt", "SRT (*.srt)")
            if not path:
                return
            with open(path, "w", encoding="utf-8") as f:
                f.write(export_subtitles_srt(self._vki.subtitles))
            QMessageBox.information(self, "Export", f"✅ SRT exportiert: {path}")
        except Exception as e:
            log.error("[VK4] srt export: %s", e)

    # ──────────────────────────────────────────────────────────
    # Video Load
    # ──────────────────────────────────────────────────────────

    def _load_video(self) -> None:
        try:
            path, _ = QFileDialog.getOpenFileName(
                self, "Video laden", "",
                "Video (*.mp4 *.mkv *.avi *.mov *.webm);;Alle (*)",
            )
            if path:
                self.set_video_path(path)
        except Exception as e:
            log.error("[VideoKI] load: %s", e)

    def set_video_path(self, path: str) -> None:
        """Set video path (can be called from VideoPanel or externally)."""
        self._video_path = path
        name = os.path.basename(path)
        self._lbl_video.setText(f"📁 {name}")
        self._lbl_video.setStyleSheet("color: #88ccff; font-size: 11px;")
        self._btn_analyze.setEnabled(True)

    # ──────────────────────────────────────────────────────────
    # Analysis
    # ──────────────────────────────────────────────────────────

    def _start_analysis(self) -> None:
        """Start background analysis (VK1+VK2+VK3)."""
        if not self._video_path:
            # Try to get video from VideoPanel
            try:
                mw = self.window()
                vp = getattr(mw, '_video_panel', None)
                if vp and hasattr(vp, '_video_path') and vp._video_path:
                    self._video_path = vp._video_path
                    self.set_video_path(self._video_path)
            except Exception:
                pass

        if not self._video_path:
            self._load_video()
            if not self._video_path:
                return

        # Check ffmpeg
        try:
            from pydaw.services.video_track import is_ffmpeg_available
            if not is_ffmpeg_available():
                QMessageBox.warning(self, "Video-KI",
                    "ffmpeg nicht gefunden.\n\n"
                    "Installieren mit: sudo apt install ffmpeg")
                return
        except Exception:
            pass

        # Disable button, show progress
        self._btn_analyze.setEnabled(False)
        self._btn_analyze.setText("⏳ Analysiere…")
        self._progress.setVisible(True)
        self._lbl_progress.setText("Szenen werden erkannt…")

        # Clear previous results
        self._lst_scenes.clear()
        self._lst_dialogs.clear()
        self._lst_suggestions.clear()
        self._lbl_scene_detail.setText("Analyse läuft…")
        self._lbl_suggestion_detail.setText("")

        # Start worker
        self._worker = _AnalysisWorker(
            self._video_path,
            scene_threshold=0.35,
            dialog_threshold_db=-35.0,
            parent=self,
        )
        self._worker.progress.connect(self._on_analysis_progress)
        self._worker.finished.connect(self._on_analysis_finished)
        self._worker.error.connect(self._on_analysis_error)
        self._worker.start()

    def _on_analysis_progress(self, msg: str) -> None:
        self._lbl_progress.setText(msg)

    def _on_analysis_finished(self, result: dict) -> None:
        try:
            self._vki = result.get("_service")
            n_scenes = result.get("scenes", 0)
            n_dialogs = result.get("dialog_regions", 0)
            n_sugs = result.get("total_suggestions", 0)

            # Populate scenes list
            if self._vki:
                for scene in self._vki.scenes:
                    tc_s = f"{int(scene.start_seconds)//60}:{int(scene.start_seconds)%60:02d}"
                    tc_e = f"{int(scene.end_seconds)//60}:{int(scene.end_seconds)%60:02d}"
                    tags = ", ".join(scene.mood_tags[:3]) if scene.mood_tags else "—"

                    item = QListWidgetItem()
                    # Color indicator from dominant color
                    r, g, b = scene.dominant_color
                    color_hex = f"#{r:02x}{g:02x}{b:02x}"

                    mood = self._vki.get_mood(scene.index)
                    key_info = ""
                    if mood:
                        key_info = f" → {mood.key_suggestion} {mood.mode_suggestion}, {int(mood.tempo_suggestion)} BPM"

                    item.setText(f"■ Szene {scene.index+1}  [{tc_s}–{tc_e}]  {tags}{key_info}")
                    item.setForeground(QColor(color_hex))
                    item.setData(Qt.ItemDataRole.UserRole, scene.index)
                    self._lst_scenes.addItem(item)

                # Populate dialogs list
                for i, dlg in enumerate(self._vki.dialogs):
                    tc_s = f"{int(dlg.start_seconds)//60}:{int(dlg.start_seconds)%60:02d}"
                    tc_e = f"{int(dlg.end_seconds)//60}:{int(dlg.end_seconds)%60:02d}"
                    item = QListWidgetItem(
                        f"🗣 Dialog {i+1}  [{tc_s}–{tc_e}]  "
                        f"({dlg.duration:.1f}s, {dlg.avg_energy_db:.0f} dB)"
                    )
                    self._lst_dialogs.addItem(item)

            # Enable buttons
            self._btn_duck.setEnabled(n_dialogs > 0)
            self._btn_apply_all.setEnabled(n_sugs > 0)

            # Status
            self._lbl_progress.setText(
                f"✅ {n_scenes} Szenen, {n_dialogs} Dialog-Regionen, {n_sugs} Sound-Vorschläge"
            )
            self._lbl_progress.setStyleSheet("color: #7bd389; font-size: 11px;")
            self._lbl_scene_detail.setText("Szene auswählen für Details + Mood-Analyse")
            self._lbl_duck_status.setText(
                f"{n_dialogs} Dialog-Regionen erkannt — bereit zum Ducken"
                if n_dialogs else "Keine Dialoge erkannt"
            )

            try:
                self.status.emit(f"🎬 Video-KI: {n_scenes} Szenen, {n_dialogs} Dialoge, {n_sugs} Vorschläge")
            except Exception:
                pass

            # v0.0.20.923 VP1: Notify connector (creates scene markers in Arranger)
            try:
                vc = self._get_connector()
                if vc and self._vki:
                    vc.on_analysis_done(self._video_path, self._vki)
            except Exception:
                pass

        except Exception as e:
            log.error("[VideoKI] display results: %s", e, exc_info=True)
        finally:
            self._btn_analyze.setEnabled(True)
            self._btn_analyze.setText("🎬 Alles analysieren")
            self._progress.setVisible(False)

    def _on_analysis_error(self, msg: str) -> None:
        self._lbl_progress.setText(f"❌ Fehler: {msg}")
        self._lbl_progress.setStyleSheet("color: #d49090; font-size: 11px;")
        self._btn_analyze.setEnabled(True)
        self._btn_analyze.setText("🎬 Alles analysieren")
        self._progress.setVisible(False)

    # ──────────────────────────────────────────────────────────
    # Scene Selection → Details + Suggestions
    # ──────────────────────────────────────────────────────────

    def _on_scene_selected(self, row: int) -> None:
        if row < 0 or not self._vki:
            return
        try:
            item = self._lst_scenes.item(row)
            if not item:
                return
            scene_idx = item.data(Qt.ItemDataRole.UserRole)
            self._selected_scene_idx = scene_idx

            scenes = self._vki.scenes
            if scene_idx < 0 or scene_idx >= len(scenes):
                return
            scene = scenes[scene_idx]
            mood = self._vki.get_mood(scene_idx)

            # Update detail label
            r, g, b = scene.dominant_color
            detail = (
                f"Szene {scene_idx+1}: {scene.start_seconds:.1f}s – {scene.end_seconds:.1f}s "
                f"({scene.duration:.1f}s)\n"
                f"Farbe: RGB({r},{g},{b}) | Helligkeit: {scene.brightness:.2f} | "
                f"Kontrast: {scene.contrast:.2f}\n"
                f"Sättigung: {scene.saturation:.2f} | Wärme: {scene.warmth:.2f}\n"
                f"Tags: {', '.join(scene.mood_tags) if scene.mood_tags else '—'}"
            )
            if mood:
                detail += (
                    f"\n\nStimmung: {mood.key_suggestion} {mood.mode_suggestion}, "
                    f"{int(mood.tempo_suggestion)} BPM"
                )
            self._lbl_scene_detail.setText(detail)

            # Update mood bars
            if mood:
                for name, val in [("valence", mood.valence), ("energy", mood.energy),
                                  ("tension", mood.tension), ("intimacy", mood.intimacy),
                                  ("darkness", mood.darkness)]:
                    bar, lbl = self._mood_bars.get(name, (None, None))
                    if bar:
                        bar.setValue(int(val * 100))
                    if lbl:
                        lbl.setText(f"{val:.2f}")

            # Update suggestions list — show scene position + length
            self._lst_suggestions.clear()
            suggestions = self._vki.get_suggestions(scene_idx)

            # Calculate beat position for display
            _bpm = self._get_bpm()
            _beats_per_bar = self._get_beats_per_bar()
            _scene_start_beat = scene.start_seconds * _bpm / 60.0
            _scene_length_beats = scene.duration * _bpm / 60.0
            _scene_end_beat = _scene_start_beat + _scene_length_beats
            _bar_start = beat_to_bar_number(_scene_start_beat, beats_per_bar=_beats_per_bar)
            _bar_end = beat_to_bar_number(_scene_end_beat, beats_per_bar=_beats_per_bar)

            for i, sug in enumerate(suggestions):
                prefix = "⭐" if i == 0 else "  "
                item = QListWidgetItem(
                    f"{prefix} {sug.preset_name} [{sug.key}{sug.mode[0].upper()}]\n"
                    f"    {sug.bpm} BPM, {sug.key} {sug.mode} — {sug.description}"
                )
                item.setData(Qt.ItemDataRole.UserRole, i)
                self._lst_suggestions.addItem(item)

            self._btn_apply_sound.setEnabled(len(suggestions) > 0)
            if suggestions:
                self._lbl_suggestion_detail.setText(
                    f"Top-Vorschlag: {suggestions[0].preset_name}\n"
                    f"{suggestions[0].description}\n"
                    f"Instrument: {suggestions[0].instrument} | "
                    f"Parameter: {len(suggestions[0].preset_params)} Werte generiert\n"
                    f"━━━ Szene {scene_idx+1} ━━━\n"
                    f"Position: Beat {_scene_start_beat:.1f}–{_scene_end_beat:.1f} "
                    f"(Bar {_bar_start}–{_bar_end})\n"
                    f"Länge: {_scene_length_beats:.1f} Beats ({scene.duration:.1f}s)\n"
                    f"→ Track wird an Beat {_scene_start_beat:.1f} erstellt, "
                    f"Länge {_scene_length_beats:.1f} Beats"
                )
            else:
                self._lbl_suggestion_detail.setText("Keine Vorschläge für diese Szene")

            # Switch to suggestions tab when scene selected
            self._tabs.setCurrentIndex(2)

            # v0.0.20.923 VP1+VP4: Cross-module sync via Connector
            try:
                vc = self._get_connector()
                if vc:
                    vc.on_scene_click(scene_idx, scene.start_seconds, scene.end_seconds)
            except Exception:
                pass

        except Exception as e:
            log.error("[VideoKI] scene select: %s", e)

    # ──────────────────────────────────────────────────────────
    # Auto-Duck
    # ──────────────────────────────────────────────────────────

    def _apply_auto_duck(self) -> None:
        """Generate and apply auto-duck automation to all music tracks."""
        if not self._vki or not self._vki.dialogs:
            return
        try:
            from PyQt6.QtWidgets import QApplication
            bpm = self._get_bpm()
            duck_db = self._spn_duck_db.value()
            fade_s = self._spn_duck_fade.value()

            # v0.0.20.954: Progress dialog for auto-duck
            dlg = None
            try:
                from pydaw.ui.video_ki_progress import KIProgressDialog
                n_dialogs = len(self._vki.dialogs)
                dlg = KIProgressDialog(
                    self, total=n_dialogs + 1,
                    title="🔇 Auto-Duck Automation")
                dlg.show()
                dlg.add_log(
                    f"{n_dialogs} Dialog-Regionen erkannt, {duck_db} dB Duck",
                    icon="🗣", color="#4FC3F7")
            except Exception:
                dlg = None

            breakpoints = self._vki.get_duck_automation(
                bpm=bpm, duck_db=float(duck_db)
            )

            if not breakpoints:
                self._lbl_duck_status.setText("⚠ Keine Breakpoints generiert")
                if dlg:
                    dlg.add_log("Keine Breakpoints generiert", icon="⚠", color="#FFA726")
                    dlg.finish()
                    dlg.exec()
                return

            if dlg:
                dlg.update_scene(0, "Breakpoints erzeugt", (79, 195, 247),
                                 preset_name=f"{len(breakpoints)} Punkte",
                                 bpm=int(bpm), key="—", mode="—",
                                 notes_count=len(breakpoints),
                                 beat_pos=0, length_beats=0)

            # Apply to project automation
            ps = self._get_project_service()
            if not ps:
                if dlg:
                    dlg.add_log("Projekt-Service nicht verfügbar", icon="⚠", color="#FFA726")
                    dlg.finish()
                    dlg.exec()
                bp_text = json.dumps(breakpoints[:10], indent=2)
                self._lbl_duck_status.setText(
                    f"✅ {len(breakpoints)} Breakpoints generiert.\n"
                    f"Projekt-Service nicht verfügbar — Breakpoints als JSON:\n{bp_text}"
                )
                return

            proj = self._get_project()
            if not proj:
                self._lbl_duck_status.setText("❌ Kein Projekt geladen")
                if dlg:
                    dlg.finish()
                    dlg.exec()
                return

            # Find all non-master, non-dialog tracks → apply volume automation
            tracks = getattr(proj, 'tracks', []) or []
            applied_count = 0
            for trk in tracks:
                kind = getattr(trk, 'kind', '')
                if kind in ('master', 'bus'):
                    continue

                tid = str(getattr(trk, 'id', ''))
                param_key = f"{tid}:volume"

                am_lanes = getattr(proj, 'automation_manager_lanes', None)
                if am_lanes is None:
                    proj.automation_manager_lanes = {}
                    am_lanes = proj.automation_manager_lanes

                am_lanes[param_key] = {
                    "track_id": tid,
                    "param_name": "volume",
                    "breakpoints": breakpoints,
                    "source": "video_ki_auto_duck",
                }
                applied_count += 1

                if dlg:
                    trk_name = getattr(trk, 'name', f'Track {applied_count}')
                    dlg.add_log(
                        f"Track '{trk_name}': {len(breakpoints)} Automation-Punkte",
                        icon="📈", color="#b0c8d0")
                    QApplication.processEvents()

            # Emit change
            try:
                if hasattr(ps, '_emit_changed'):
                    ps._emit_changed()
            except Exception:
                pass

            n_dlg = len(self._vki.dialogs)
            self._lbl_duck_status.setText(
                f"✅ Auto-Duck: {len(breakpoints)} Breakpoints auf "
                f"{applied_count} Tracks angewendet ({duck_db} dB, {fade_s}s Fade)"
            )
            self._lbl_duck_status.setStyleSheet("color: #7bd389; font-size: 11px;")

            if dlg:
                dlg.add_log(
                    f"Fertig: {len(breakpoints)} Punkte auf {applied_count} Tracks",
                    icon="✅", color="#66BB6A")
                dlg.finish()
                dlg.exec()

            log.info("[VideoKI] Auto-duck applied: %d breakpoints on %d tracks",
                     len(breakpoints), applied_count)

        except Exception as e:
            self._lbl_duck_status.setText(f"❌ Fehler: {e}")
            self._lbl_duck_status.setStyleSheet("color: #d49090; font-size: 11px;")
            log.error("[VideoKI] auto-duck: %s", e, exc_info=True)

    # ──────────────────────────────────────────────────────────
    # Sound Application
    # ──────────────────────────────────────────────────────────

    def _apply_selected_sound(self) -> None:
        """VP5: Apply the selected sound suggestion — create Track + Instrument + MIDI."""
        if not self._vki or self._selected_scene_idx < 0:
            return
        try:
            sug_row = self._lst_suggestions.currentRow()
            if sug_row < 0:
                sug_row = 0  # default to top suggestion

            suggestions = self._vki.get_suggestions(self._selected_scene_idx)
            if sug_row >= len(suggestions):
                return

            sug = suggestions[sug_row]
            scene = self._vki.scenes[self._selected_scene_idx]
            mood = self._vki.get_mood(self._selected_scene_idx)

            # v0.0.20.923 VP5: Use connector for full Track + MIDI creation
            vc = self._get_connector()
            if vc:
                bpm = self._get_bpm()
                tid = vc.create_scene_track_with_midi(scene, mood, sug, bpm)
                if tid:
                    self._lbl_suggestion_detail.setText(
                        f"✅ Track erstellt: 🎬 {sug.preset_name}\n"
                        f"Instrument: AETERNA | {sug.bpm} BPM, {sug.key} {sug.mode}\n"
                        f"MIDI-Clip + Noten an Szene {scene.index+1} Position generiert"
                    )
                    self._lbl_suggestion_detail.setStyleSheet(
                        "color: #7bd389; font-size: 11px; padding: 6px; "
                        "background: #12121e; border: 1px solid #333; border-radius: 4px;"
                    )
                    return

            # Fallback: alte Methode (params auf bestehenden Track)
            self._apply_suggestion_to_track(sug)

        except Exception as e:
            log.error("[VideoKI] apply sound: %s", e)

    def _apply_all_scenes(self) -> None:
        """VP5: Create tracks for ALL scenes — with KI Progress Dialog."""
        if not self._vki:
            return
        try:
            from PyQt6.QtWidgets import QApplication
            vc = self._get_connector()
            if not vc:
                return

            bpm = self._get_bpm()
            scenes = self._vki.scenes
            if not scenes:
                return

            # v0.0.20.953: KI Progress Dialog
            from pydaw.ui.video_ki_progress import KIProgressDialog

            dlg = KIProgressDialog(
                self, total=len(scenes),
                title="🧠 Alle Szenen vertonen")
            dlg.show()
            dlg.add_log(
                f"Starte Vertonung: {len(scenes)} Szenen, {bpm:.0f} BPM",
                icon="🚀", color="#4FC3F7")

            created = 0
            for scene in scenes:
                if dlg.is_cancelled:
                    break

                mood = self._vki.get_mood(scene.index)
                suggestions = self._vki.get_suggestions(scene.index)
                if not mood or not suggestions:
                    dlg.add_log(
                        f"Szene {scene.index + 1}: Keine Vorschläge — übersprungen",
                        icon="⏭", color="#888888")
                    QApplication.processEvents()
                    continue

                sug = suggestions[0]
                r, g, b = scene.dominant_color

                # Create track with MIDI
                tid = vc.create_scene_track_with_midi(
                    scene, mood, sug, bpm)

                if tid:
                    created += 1
                    # Get notes count from project
                    n_notes = 0
                    try:
                        ps = vc._project_service
                        proj = getattr(ps, 'project', None)
                        if proj is None:
                            ctx = getattr(ps, 'ctx', None)
                            proj = getattr(ctx, 'project', None) if ctx else None
                        if proj:
                            for clip in proj.clips:
                                if str(getattr(clip, 'track_id', '')) == tid:
                                    cid = str(getattr(clip, 'id', ''))
                                    notes = proj.midi_notes.get(cid, [])
                                    n_notes = len(notes)
                                    break
                    except Exception:
                        pass

                    scene_start_beat = scene.start_seconds * bpm / 60.0
                    scene_length_beats = scene.duration * bpm / 60.0

                    dlg.update_scene(
                        index=scene.index,
                        scene_name=f"Szene {scene.index + 1}",
                        color_rgb=(r, g, b),
                        bpm=sug.bpm,
                        key=sug.key,
                        mode=sug.mode,
                        notes_count=n_notes,
                        preset_name=sug.preset_name,
                        beat_pos=scene_start_beat,
                        length_beats=scene_length_beats,
                    )

            if dlg.is_cancelled:
                dlg.finish_cancelled()
            else:
                dlg.finish()

            dlg.exec()

            self._lbl_suggestion_detail.setText(
                f"✅ {created} Szenen vertont!\n"
                f"Für jede Szene: Track + AETERNA Instrument + MIDI-Clip + Noten"
            )
            self._lbl_suggestion_detail.setStyleSheet(
                "color: #7bd389; font-size: 11px; padding: 6px; "
                "background: #12121e; border: 1px solid #333; border-radius: 4px;"
            )

        except Exception as e:
            log.error("[VideoKI] apply all: %s", e)

    def _apply_suggestion_to_track(self, sug, scene_label: str = "") -> None:
        """Apply a SoundSuggestion's AETERNA params to the active track's instrument."""
        try:
            ps = self._get_project_service()
            proj = self._get_project()
            if not ps or not proj:
                self._lbl_suggestion_detail.setText(
                    f"ℹ Vorschlag: {sug.preset_name}\n"
                    f"{sug.description}\n"
                    f"(Projekt nicht verfügbar — Preset manuell anwenden)"
                )
                return

            # Find active track
            tid = ""
            try:
                tid = getattr(ps, '_selected_track_id', '') or ''
            except Exception:
                pass
            if not tid:
                for t in getattr(proj, 'tracks', []) or []:
                    if getattr(t, 'kind', '') == 'instrument':
                        tid = str(t.id)
                        break
            if not tid:
                for t in getattr(proj, 'tracks', []) or []:
                    if getattr(t, 'kind', '') not in ('master', 'bus'):
                        tid = str(t.id)
                        break
            if not tid:
                self._lbl_suggestion_detail.setText("❌ Keine Spur verfügbar")
                return

            # Find track and set instrument_state with preset params
            for t in getattr(proj, 'tracks', []) or []:
                if str(getattr(t, 'id', '')) != tid:
                    continue

                # Store preset params in instrument_state
                inst_state = getattr(t, 'instrument_state', None)
                if not isinstance(inst_state, dict):
                    t.instrument_state = {}
                    inst_state = t.instrument_state

                # Set AETERNA params
                for k, v in sug.preset_params.items():
                    inst_state[k] = v

                # Set plugin type to built-in synth if not already set
                if not getattr(t, 'plugin_type', None):
                    t.plugin_type = "aeterna"

                label = scene_label or sug.preset_name
                log.info("[VideoKI] Applied '%s' to track '%s'",
                         sug.preset_name, getattr(t, 'name', tid[:8]))

                self._lbl_suggestion_detail.setText(
                    f"✅ {sug.preset_name} → '{getattr(t, 'name', tid[:8])}'\n"
                    f"{sug.bpm} BPM, {sug.key} {sug.mode}\n"
                    f"{len(sug.preset_params)} Parameter angewendet"
                )
                self._lbl_suggestion_detail.setStyleSheet(
                    "color: #7bd389; font-size: 11px; padding: 6px; "
                    "background: #12121e; border: 1px solid #333; border-radius: 4px;"
                )
                break

            # Refresh UI
            try:
                if hasattr(ps, '_emit_changed'):
                    ps._emit_changed()
                dp = self._get_device_panel()
                if dp:
                    dp.show_track(tid)
            except Exception:
                pass

        except Exception as e:
            self._lbl_suggestion_detail.setText(f"❌ Fehler: {e}")
            log.error("[VideoKI] apply suggestion: %s", e)

    # ──────────────────────────────────────────────────────────
    # Helpers
    # ──────────────────────────────────────────────────────────

    def _get_project_service(self):
        try:
            if self._services:
                return (getattr(self._services, 'project', None)
                        or getattr(self._services, 'project_service', None))
        except Exception:
            pass
        return None

    def _get_project(self):
        try:
            ps = self._get_project_service()
            if ps:
                proj = getattr(ps, 'project', None)
                if proj is None:
                    ctx = getattr(ps, 'ctx', None)
                    proj = getattr(ctx, 'project', None) if ctx else None
                return proj
        except Exception:
            pass
        return None

    def _get_bpm(self) -> float:
        try:
            proj = self._get_project()
            if proj:
                return float(getattr(proj, 'bpm', 120.0) or 120.0)
        except Exception:
            pass
        return 120.0

    def _get_beats_per_bar(self) -> float:
        try:
            proj = self._get_project()
            ts = getattr(proj, 'time_signature', '4/4') if proj is not None else '4/4'
            return max(0.25, float(time_signature_to_beats_per_bar(ts)))
        except Exception:
            return 4.0

    def _get_device_panel(self):
        try:
            mw = self.window()
            return getattr(mw, '_device_panel', None) or getattr(mw, 'device_panel', None)
        except Exception:
            return None

    def _get_connector(self):
        """Get the VideoConnector singleton."""
        try:
            from pydaw.services.video_connector import VideoConnector
            vc = VideoConnector.instance()
            # Auto-register if not done
            if vc._video_ki_panel is None:
                vc.register_video_ki_panel(self)
                # Also register services if available
                if self._services:
                    transport = (getattr(self._services, 'transport', None)
                                 or getattr(self._services, 'transport_service', None))
                    ps = self._get_project_service()
                    if transport:
                        vc.register_transport(transport)
                    if ps:
                        vc.register_project_service(ps)
                    vc.set_bpm(self._get_bpm())
                    # Register other panels if accessible
                    try:
                        mw = self.window()
                        vp = getattr(mw, '_video_panel', None)
                        if vp:
                            vc.register_video_panel(vp)
                        arr = getattr(mw, '_arranger', None) or getattr(mw, 'arranger', None)
                        if arr:
                            vc.register_arranger(arr)
                    except Exception:
                        pass
            return vc
        except Exception:
            return None

    def shutdown(self) -> None:
        try:
            if self._worker and self._worker.isRunning():
                self._worker.quit()
                self._worker.wait(2000)
        except Exception:
            pass
