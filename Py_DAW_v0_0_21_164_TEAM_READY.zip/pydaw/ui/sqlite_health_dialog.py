"""sqlite_health_dialog.py — SQLite DB Status-Dialog für Py_DAW.

v0.0.20.896 — Wird vom SQLite-Badge in der Status-Bar geöffnet.

Zeigt:
- Alle DB-Dateien mit Größe und Status
- Alle Tabellen mit Zeilenanzahl (grün=befüllt, grau=leer)
- Live-Aktualisierung beim Öffnen
- Zugriffspfad zur DB
"""

from __future__ import annotations

import logging
import os
import sqlite3
from pathlib import Path
from typing import List, Tuple

try:
    from PyQt6.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel, QTreeWidget,
        QTreeWidgetItem, QPushButton, QGroupBox, QHeaderView,
    )
    from PyQt6.QtCore import Qt
    from PyQt6.QtGui import QColor, QFont
    _QT = True
except ImportError:
    _QT = False

log = logging.getLogger(__name__)

_DB_DIR = Path.home() / ".config" / "ChronoScaleStudio"

_DB_FILES = [
    ("pydaw.db", "Haupt-Datenbank"),
    ("preset_database.db", "Preset-Datenbank (FTS5)"),
    ("param_registry.db", "Parameter-Registry"),
]


def _file_size_str(path: Path) -> str:
    if not path.exists():
        return "—"
    size = path.stat().st_size
    if size < 1024:
        return f"{size} B"
    elif size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    return f"{size / (1024 * 1024):.2f} MB"


def _scan_db(db_path: Path) -> List[Tuple[str, int]]:
    """Scan a DB file and return [(table_name, row_count), ...]."""
    if not db_path.exists():
        return []
    try:
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        tables = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).fetchall()
        result = []
        for t in tables:
            name = t["name"]
            try:
                row = conn.execute(f"SELECT COUNT(*) as cnt FROM [{name}]").fetchone()
                cnt = int(row["cnt"]) if row else 0
            except Exception:
                cnt = -1
            result.append((name, cnt))
        conn.close()
        return result
    except Exception:
        return []


if _QT:
    class SQLiteHealthDialog(QDialog):
        """Dialog showing SQLite DB health status."""

        def __init__(self, parent=None):
            super().__init__(parent)
            self.setWindowTitle("SQLite Datenbank-Status")
            self.setMinimumSize(520, 480)
            self._build_ui()
            self._refresh()

        def _build_ui(self):
            layout = QVBoxLayout(self)
            layout.setSpacing(10)

            # Header
            hdr = QLabel("🗄️ SQLite Datenbank-Status")
            hdr_font = QFont()
            hdr_font.setPointSize(13)
            hdr_font.setBold(True)
            hdr.setFont(hdr_font)
            layout.addWidget(hdr)

            # Path info
            path_lbl = QLabel(f"Pfad: <code>{_DB_DIR}</code>")
            path_lbl.setTextFormat(Qt.TextFormat.RichText)
            path_lbl.setStyleSheet("color: #888; font-size: 11px;")
            layout.addWidget(path_lbl)

            # Summary group
            self._summary_group = QGroupBox("Übersicht")
            sg_layout = QVBoxLayout(self._summary_group)
            self._lbl_summary = QLabel("")
            self._lbl_summary.setStyleSheet("font-size: 12px;")
            sg_layout.addWidget(self._lbl_summary)
            layout.addWidget(self._summary_group)

            # Table tree
            self._tree = QTreeWidget()
            self._tree.setHeaderLabels(["Tabelle / Datenbank", "Zeilen", "Status"])
            self._tree.setRootIsDecorated(True)
            self._tree.setAlternatingRowColors(True)
            try:
                header = self._tree.header()
                header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
                header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
                header.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
            except Exception:
                pass
            layout.addWidget(self._tree, 1)

            # Info label
            info = QLabel(
                "ℹ️ Alle Werte in der Datenbank sind änderbar.\n"
                "Nichts ist hardcoded — die DB speichert nur deine Einstellungen.\n"
                "Wenn die DB fehlt, werden sichere Defaults verwendet."
            )
            info.setStyleSheet("color: #68a; font-size: 10px; padding: 4px;")
            info.setWordWrap(True)
            layout.addWidget(info)

            # Buttons
            btn_row = QHBoxLayout()
            btn_refresh = QPushButton("🔄 Aktualisieren")
            btn_refresh.clicked.connect(self._refresh)
            btn_check = QPushButton("🔍 Audio-Editor Check")
            btn_check.clicked.connect(self._check_audio_editor_integrity)
            btn_close = QPushButton("Schließen")
            btn_close.clicked.connect(self.close)
            btn_row.addStretch()
            btn_row.addWidget(btn_refresh)
            btn_row.addWidget(btn_check)
            btn_row.addWidget(btn_close)
            layout.addLayout(btn_row)

        def _refresh(self):
            self._tree.clear()

            total_tables = 0
            total_rows = 0
            filled_tables = 0
            total_size = 0
            db_count = 0

            for filename, label in _DB_FILES:
                db_path = _DB_DIR / filename
                exists = db_path.exists()
                size_str = _file_size_str(db_path)

                if exists:
                    total_size += db_path.stat().st_size
                    db_count += 1

                # DB-level item
                db_item = QTreeWidgetItem(self._tree)
                db_item.setText(0, f"📁 {label} ({filename})")
                db_item.setText(1, size_str)
                db_item.setText(2, "✅" if exists else "❌ nicht vorhanden")

                if not exists:
                    db_item.setForeground(0, QColor("#888"))
                    db_item.setForeground(2, QColor("#f44"))
                    continue

                tables = _scan_db(db_path)
                total_tables += len(tables)

                for tname, cnt in tables:
                    t_item = QTreeWidgetItem(db_item)
                    t_item.setText(0, f"  {tname}")
                    if cnt >= 0:
                        t_item.setText(1, str(cnt))
                        total_rows += cnt
                        if cnt > 0:
                            t_item.setText(2, "✅")
                            t_item.setForeground(1, QColor("#4caf50"))
                            filled_tables += 1
                        else:
                            t_item.setText(2, "○ leer")
                            t_item.setForeground(0, QColor("#666"))
                            t_item.setForeground(1, QColor("#666"))
                            t_item.setForeground(2, QColor("#666"))
                    else:
                        t_item.setText(1, "?")
                        t_item.setText(2, "⚠️ Fehler")

                db_item.setExpanded(True)

            # Summary
            size_mb = total_size / (1024 * 1024)
            if filled_tables > 0:
                status_icon = "🟢"
                status_text = "DB funktioniert"
            elif total_tables > 0:
                status_icon = "🟡"
                status_text = "Tabellen angelegt, aber leer — starte die DAW"
            else:
                status_icon = "🔴"
                status_text = "Keine DB gefunden — wird beim Start angelegt"

            self._lbl_summary.setText(
                f"{status_icon} {status_text}\n"
                f"📊 {filled_tables} von {total_tables} Tabellen befüllt  |  "
                f"{total_rows:,} Datensätze  |  {size_mb:.2f} MB"
            )

        def _check_audio_editor_integrity(self):
            """AE13.5: Validate clip_automation fields in the project DB."""
            import json
            db_path = _DB_DIR / "pydaw.db"
            if not db_path.exists():
                self._lbl_summary.setText("🔴 DB nicht gefunden")
                return
            issues = []
            fixed = 0
            try:
                conn = sqlite3.connect(str(db_path))
                rows = conn.execute(
                    "SELECT id, label, extra_json FROM project_clips"
                ).fetchall()
                for row in rows:
                    cid = row[0]
                    label = row[1] or cid
                    try:
                        ex = json.loads(row[2] or '{}')
                    except Exception:
                        issues.append(f"⚠️ {label}: extra_json ungültig")
                        continue
                    auto = ex.get('clip_automation', {})
                    if not isinstance(auto, dict):
                        issues.append(f"⚠️ {label}: clip_automation kein dict")
                        continue
                    for param, pts in auto.items():
                        if param not in ("gain", "pan", "pitch", "formant"):
                            issues.append(f"⚠️ {label}: unbekannter Param '{param}'")
                        if not isinstance(pts, list):
                            issues.append(f"⚠️ {label}: {param} keine Liste")
                            continue
                        for i, bp in enumerate(pts):
                            if not isinstance(bp, dict):
                                issues.append(f"⚠️ {label}: {param}[{i}] kein dict")
                                continue
                            if 'beat' not in bp or 'value' not in bp:
                                issues.append(f"⚠️ {label}: {param}[{i}] beat/value fehlt")
                            cv = bp.get('curve', 'linear')
                            if cv not in ('linear', 'scurve', 'log', 'exp'):
                                # Auto-fix: set to linear
                                bp['curve'] = 'linear'
                                fixed += 1
                    # Validate fade curves
                    for fc_key in ('fade_in_curve', 'fade_out_curve'):
                        fc = ex.get(fc_key, 'linear')
                        if fc and fc not in ('linear', 'log', 'exp', 'scurve'):
                            issues.append(f"⚠️ {label}: {fc_key}='{fc}' ungültig")
                conn.close()
            except Exception as e:
                issues.append(f"🔴 DB-Fehler: {e}")

            if not issues and fixed == 0:
                status = "🟢 Audio-Editor Integrität OK — alle Felder valide"
            elif fixed > 0:
                status = f"🟡 {fixed} Curve-Felder auto-korrigiert → 'linear'"
            else:
                status = f"🔴 {len(issues)} Probleme gefunden"

            detail = "\n".join(issues[:20]) if issues else "Keine Probleme"
            self._lbl_summary.setText(f"{status}\n{detail}")

else:
    class SQLiteHealthDialog:  # type: ignore
        """Fallback when PyQt6 is not available."""
        def __init__(self, *a, **kw):
            pass
        def exec(self):
            pass
