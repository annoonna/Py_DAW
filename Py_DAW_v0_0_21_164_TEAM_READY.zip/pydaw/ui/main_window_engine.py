"""Engine & Rust Mixin — Extracted from main_window.py (v0.0.20.907).

Contains Rust engine toggle, CPU meter, GPU waveforms, engine migration,
Rust badge management, and browser scan trigger.

Self-contained: only references self.services, self.statusBar(),
self.arranger, self.library, SettingsKeys, set_value/get_value,
and engine state attrs — all provided by MainWindow.

~280 lines extracted.
"""

from __future__ import annotations

import logging
import os

from pydaw.core.settings import SettingsKeys
from pydaw.core.settings_store import get_value, set_value
from .perf_monitor import CpuUsageMonitor

log = logging.getLogger(__name__)


class EngineRustMixin:
    """Engine/Rust toggle and CPU/GPU monitoring — mixed into MainWindow."""

    def _init_menu_rust_badge(self, menu_bar=None) -> None:
        """Legacy no-op.

        The Rust badge was moved into the bottom status signature in
        v0.0.20.651. We keep this method so older call-sites remain harmless.
        """
        self._teardown_menu_rust_badge()


    def _teardown_menu_rust_badge(self) -> None:
        """Hide/remove the old menu-row Rust badge if it exists."""
        try:
            badge = getattr(self, "_menu_rust_badge", None)
            if badge is not None:
                try:
                    badge.hide()
                except Exception:
                    pass
                try:
                    badge.setParent(None)
                except Exception:
                    pass
            self._menu_rust_badge = None
        except Exception:
            log.error("Unexpected error", exc_info=True)


    def _reposition_menu_rust_badge(self) -> None:
        """Legacy no-op after moving the badge to the status strip."""
        self._teardown_menu_rust_badge()


    def _on_engine_migration_dialog(self) -> None:
        """Open the Engine Migration Dialog (Rust ↔ Python).

        v0.0.20.665 — Wired from Audio menu action.
        """
        try:
            from pydaw.ui.engine_migration_settings import EngineMigrationDialog
            dlg = EngineMigrationDialog(parent=self)
            dlg.exec()
        except Exception as exc:
            self.statusBar().showMessage(
                f"Engine Migration Dialog konnte nicht geöffnet werden: {exc}", 5000
            )


    def _toggle_gpu_waveforms(self, checked: bool) -> None:
        """Enable/disable the optional GPU waveform overlay in the Arranger.

        Safety: the overlay is opt-in. On some compositors/drivers an OpenGL
        overlay can hide the grid if it paints an opaque background.
        """
        checked = bool(checked)
        try:
            set_value(SettingsKeys.ui_gpu_waveforms_enabled, checked)
        except Exception:
            pass

        # Apply to ArrangerCanvas
        try:
            if hasattr(self, "arranger") and hasattr(self.arranger, "canvas"):
                self.arranger.canvas.set_gpu_waveforms_enabled(checked)
        except Exception:
            pass

        # Visible indicator
        try:
            if getattr(self, "_gpu_status_label", None) is not None:
                self._gpu_status_label.setText("GPU: ON" if checked else "GPU: OFF")
        except Exception:
            pass
        try:
            self.statusBar().showMessage("GPU Waveforms: ON" if checked else "GPU Waveforms: OFF", 2000)
        except Exception:
            pass


    def _toggle_cpu_meter(self, checked: bool) -> None:
        """Enable/disable a tiny CPU indicator in the status bar.

        This is intentionally very cheap:
        - QTimer in GUI thread (default 1000ms)
        - `time.process_time()` deltas / wall deltas
        - No audio-thread involvement

        Default is OFF (opt-in), to keep the UI minimal.
        """
        self._apply_cpu_meter_state(bool(checked), persist=True)


    def _apply_cpu_meter_state(self, enabled: bool, persist: bool = True) -> None:
        enabled = bool(enabled)

        if persist:
            try:
                set_value(SettingsKeys.ui_cpu_meter_enabled, enabled)
            except Exception:
                pass

        # Label visibility
        try:
            if getattr(self, "_cpu_status_label", None) is not None:
                self._cpu_status_label.setVisible(enabled)
                if not enabled:
                    self._cpu_status_label.setText("")
        except Exception:
            pass

        if not enabled:
            try:
                if getattr(self, "_cpu_monitor", None) is not None:
                    self._cpu_monitor.stop()
            except Exception:
                pass
            try:
                self.statusBar().showMessage("CPU Anzeige: OFF", 1500)
            except Exception:
                pass
            return

        # Lazy create monitor
        if getattr(self, "_cpu_monitor", None) is None:
            try:
                self._cpu_monitor = CpuUsageMonitor(interval_ms=1000, parent=self)
                self._cpu_monitor.updated.connect(self._on_cpu_meter_updated)
            except Exception:
                self._cpu_monitor = None

        try:
            if self._cpu_monitor is not None:
                self._cpu_monitor.start()
        except Exception:
            pass

        try:
            self.statusBar().showMessage("CPU Anzeige: ON", 1500)
        except Exception:
            pass


    def _on_cpu_meter_updated(self, pct: float) -> None:
        try:
            if getattr(self, "_cpu_status_label", None) is None:
                return
            # round for stability; avoid flicker
            val = int(round(float(pct)))
            if val < 0:
                val = 0
            # very high values can happen on weird timers; clamp for display
            if val > 999:
                val = 999
            self._cpu_status_label.setText(f"Rust-CPU: {val}%")
        except Exception:
            pass

    # ── v0.0.20.696: Rust Audio-Engine Toggle ──────────────────────────────


    def _toggle_rust_engine(self, checked: bool) -> None:
        """Toggle the Rust Audio-Engine on/off.

        Persists to QSettings AND sets the USE_RUST_ENGINE env var so the
        engine_migration controller and rust_engine_bridge pick it up
        immediately. Takes effect on next playback start.
        """
        self._apply_rust_engine_state(bool(checked), persist=True)


    def _apply_rust_engine_state(self, enabled: bool, persist: bool = True) -> None:
        import os
        enabled = bool(enabled)

        # Persist to QSettings
        if persist:
            try:
                set_value(SettingsKeys.audio_rust_engine_enabled, enabled)
            except Exception:
                pass

        # Set env var for immediate effect
        os.environ["USE_RUST_ENGINE"] = "1" if enabled else "0"

        # Update status label
        try:
            lbl = getattr(self, "_rust_status_label", None)
            if lbl is not None:
                if enabled:
                    lbl.setText("R: ON")
                    lbl.setStyleSheet(
                        "QLabel { color: #ff6e40; font-weight: bold; "
                        "padding: 0 4px; }"
                    )
                else:
                    lbl.setText("R: OFF")
                    lbl.setStyleSheet(
                        "QLabel { color: #666; padding: 0 4px; }"
                    )
        except Exception:
            pass

        # Status bar feedback
        try:
            if enabled:
                self.statusBar().showMessage(
                    "🦀 Rust Audio-Engine: AKTIV — wird beim nächsten Play wirksam", 3000
                )
            else:
                self.statusBar().showMessage(
                    "🐍 Python Audio-Engine — Rust deaktiviert", 3000
                )
        except Exception:
            pass

        # v0.0.20.739: When Rust engine is toggled ON, trigger a background
        # plugin scan so the browser shows Rust-discovered plugins immediately
        # without requiring a manual Rescan click.
        if enabled:
            try:
                from PyQt6.QtCore import QTimer
                QTimer.singleShot(3000, self._trigger_rust_browser_scan)
            except Exception:
                pass

    # ── v0.0.20.701: Plugin Sandbox Toggle ─────────────────────────────────


    def _trigger_rust_browser_scan(self) -> None:
        """v0.0.20.739: Forward Rust plugin scan result to the plugin browser.

        Called 3 s after the Rust engine is toggled ON, giving the engine time
        to start its IPC socket.  Finds the PluginsBrowserWidget inside the
        DeviceBrowser and calls _trigger_rust_scan_if_available() on it —
        fully guarded, nothing breaks if the browser isn't open.
        """
        try:
            library = getattr(self, "library", None)
            if library is None:
                return
            plugins_tab = getattr(library, "plugins_tab", None)
            if plugins_tab is None:
                return
            trigger = getattr(plugins_tab, "_trigger_rust_scan_if_available", None)
            if callable(trigger):
                trigger()
        except Exception:
            pass

    # v0.0.20.979: Auto-start Rust engine on DAW launch when backend is "rust"
    def _auto_start_rust_engine(self) -> None:
        """Start and connect the Rust engine automatically at DAW launch.

        Called via QTimer.singleShot(500) from __init__ when:
        - Backend is set to "rust" in QSettings
        - R: ON is enabled

        v0.0.20.983: NS5.3 — reduced delay (2s→500ms), shows connecting
        state in dashboard, improved status feedback.
        """
        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            bridge = RustEngineBridge.instance()
            if bridge is None:
                return
            if bridge.is_connected:
                return  # Already connected

            import logging
            log = logging.getLogger(__name__)
            log.info("[AutoStart] Starting Rust engine (backend=rust)...")

            # v0.0.20.983: NS5.3 — show connecting state in dashboard
            dashboard = getattr(self, "_rust_dashboard", None)
            if dashboard is not None and hasattr(dashboard, "set_connecting"):
                dashboard.set_connecting()

            sr = 48000
            buf = 1024
            try:
                from pydaw.core.settings import SettingsKeys, get_value
                sr = int(get_value(SettingsKeys.sample_rate, 48000))
                buf = int(get_value(SettingsKeys.buffer_size, 1024))
            except Exception:
                pass

            ok = bridge.start_engine(sample_rate=sr, buffer_size=buf)
            if ok:
                log.info("[AutoStart] Rust engine connected ✅")
                try:
                    self.statusBar().showMessage(
                        "🦀 Rust Audio-Engine automatisch verbunden", 3000
                    )
                except Exception:
                    pass
            else:
                log.warning("[AutoStart] Rust engine failed to start")
                try:
                    self.statusBar().showMessage(
                        "⚠️ Rust Engine konnte nicht verbunden werden — Fallback auf Python",
                        5000,
                    )
                except Exception:
                    pass
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(
                "[AutoStart] Rust engine auto-start failed: %s", e
            )

    # v0.0.20.980: Live Rust status update for statusbar
    def _update_rust_status_label(self) -> None:
        """Update the Rust status label in the statusbar with live connection info."""
        lbl = getattr(self, "_rust_status_label", None)
        if lbl is None:
            return
        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            bridge = RustEngineBridge.instance()
            if bridge is not None and bridge.is_connected:
                # Check if full takeover is active
                takeover = getattr(self, '_rust_takeover', None)
                if takeover is not None and getattr(takeover, '_is_rust_active', False):
                    lbl.setText("R:FULL")
                    lbl.setStyleSheet(
                        "QLabel { color: #00e676; font-weight: bold; padding: 0 4px; }")
                else:
                    lbl.setText("R:ON")
                    lbl.setStyleSheet(
                        "QLabel { color: #ff6e40; font-weight: bold; padding: 0 4px; }")
            else:
                lbl.setText("R:OFF")
                lbl.setStyleSheet("QLabel { color: #666; padding: 0 4px; }")
        except Exception:
            pass

    # v0.0.21.022: Full Rust Audio Takeover — Python stops rendering,
    # Rust handles ALL audio (instruments, FX, mixing, output).
    def _activate_rust_full_audio(self) -> None:
        """Activate full Rust audio rendering.

        Stops Python audio engine, syncs project + samples to Rust,
        and lets Rust handle everything. Python becomes UI-only.

        Safe: falls back to Python if anything fails.
        """
        import logging
        log = logging.getLogger(__name__)
        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            bridge = RustEngineBridge.instance()
            if bridge is None or not bridge.is_connected:
                self.statusBar().showMessage(
                    "⚠️ Rust Engine nicht verbunden — bitte zuerst 🦀 Rust Audio-Engine aktivieren", 4000)
                return

            from pydaw.services.rust_audio_takeover import RustAudioTakeover

            # Get references
            audio_engine = getattr(self, '_audio_engine', None)
            if audio_engine is None:
                try:
                    audio_engine = self.services.audio
                except Exception:
                    pass

            project_svc = getattr(self, '_project_service', None)
            if project_svc is None:
                try:
                    project_svc = self.services.project
                except Exception:
                    pass

            takeover = RustAudioTakeover(
                audio_engine=audio_engine,
                bridge=bridge,
                project_service=project_svc,
            )

            self.statusBar().showMessage("🦀 Rust Audio Takeover — Projekt wird synchronisiert...", 0)

            ok = takeover.activate()

            if ok:
                self._rust_takeover = takeover  # keep reference
                # v0.0.21.052: Set kill switch
                from pydaw.core.audio_backend_switch import audio_switch
                audio_switch.set_rust(True)
                log.info("[TAKEOVER] ✅ Rust Full Audio active — Python audio stopped")
                self.statusBar().showMessage(
                    "🦀 Rust Full Audio AKTIV — Python-Audio deaktiviert, Rust rendert alles", 5000)
                # Update status label
                lbl = getattr(self, "_rust_status_label", None)
                if lbl is not None:
                    lbl.setText("R:FULL")
                    lbl.setStyleSheet(
                        "QLabel { color: #00e676; font-weight: bold; padding: 0 4px; }"
                    )
            else:
                log.warning("[TAKEOVER] ❌ Rust Takeover fehlgeschlagen — Python-Fallback aktiv")
                self.statusBar().showMessage(
                    "⚠️ Rust Takeover fehlgeschlagen — Python-Audio bleibt aktiv", 5000)

        except Exception as e:
            log.error("[TAKEOVER] Error: %s", e)
            self.statusBar().showMessage(f"⚠️ Rust Takeover Fehler: {e}", 5000)

    def _deactivate_rust_full_audio(self) -> None:
        """Switch back to Python audio rendering."""
        import logging
        log = logging.getLogger(__name__)
        takeover = getattr(self, '_rust_takeover', None)
        if takeover is not None:
            try:
                takeover.deactivate()
                log.info("[TAKEOVER] Python audio restored")
            except Exception as e:
                log.warning("[TAKEOVER] Deactivate error: %s", e)
        self._rust_takeover = None
        # v0.0.21.052: Reset kill switch
        from pydaw.core.audio_backend_switch import audio_switch
        audio_switch.set_rust(False)
        self.statusBar().showMessage("🐍 Python Audio-Engine wiederhergestellt", 3000)
        lbl = getattr(self, "_rust_status_label", None)
        if lbl is not None:
            lbl.setText("R:ON")
            lbl.setStyleSheet(
                "QLabel { color: #ff6e40; font-weight: bold; padding: 0 4px; }"
            )
        """Update the Rust status label in the statusbar with live connection info."""
        lbl = getattr(self, "_rust_status_label", None)
        if lbl is None:
            return

        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            bridge = RustEngineBridge.instance()

            if bridge is not None and bridge.is_connected:
                lbl.setText("R:ON")
                lbl.setStyleSheet(
                    "QLabel { color: #ff6e40; font-weight: bold; padding: 0 4px; }"
                )
            else:
                import os
                env = os.environ.get("USE_RUST_ENGINE", "0")
                if env in ("1", "true", "yes"):
                    lbl.setText("R:ON")
                    lbl.setStyleSheet(
                        "QLabel { color: #FFA726; font-weight: bold; padding: 0 4px; }"
                    )
                else:
                    lbl.setText("R:OFF")
                    lbl.setStyleSheet(
                        "QLabel { color: #666; padding: 0 4px; }"
                    )
        except Exception:
            pass

    # v0.0.20.980: Animated Rust Dashboard event handlers
    def _on_rust_dashboard_status(self, status: dict) -> None:
        """Handle Rust audio status report → update dashboard widget.

        v0.0.20.983: Fix — don't set_disconnected when engine is connected
        but audio not actively playing. Show connected-idle with 0% CPU instead.
        """
        dash = getattr(self, "_rust_dashboard", None)
        if dash is None:
            return
        try:
            cpu = status.get("cpu_load", 0.0)
            sr = status.get("sample_rate", 0)
            buf = status.get("buffer_size", 0)
            xruns = status.get("xrun_count", 0)
            dev = status.get("device_name", "default")
            lat_ms = (buf / sr * 1000) if sr > 0 else 0

            # Always show connected if we receive a status report
            # (the bridge IS connected if we get this signal)
            dash.set_connected(True, device=dev, sr=sr, buf=buf)

            if status.get("is_active", False):
                dash.set_metrics(cpu_load=cpu, latency_ms=lat_ms, xruns=xruns)
            else:
                # Connected but idle — show 0% CPU, keep latency estimate
                dash.set_metrics(cpu_load=0.0, latency_ms=lat_ms, xruns=xruns)
        except Exception:
            pass

    def _on_rust_dashboard_started(self, device: str, sr: int,
                                    buf: int, latency_ms: float) -> None:
        """Handle Rust AudioStarted → dashboard connected."""
        dash = getattr(self, "_rust_dashboard", None)
        if dash is not None:
            dash.set_connected(True, device=device, sr=sr, buf=buf)

    def _on_rust_dashboard_stopped(self) -> None:
        """Handle Rust AudioStopped → dashboard offline."""
        dash = getattr(self, "_rust_dashboard", None)
        if dash is not None:
            dash.set_disconnected()


