# -*- coding: utf-8 -*-
"""GUI Performance Optimizations — Waveform LOD Cache, Async Loading, Automation Culling.

v0.0.21.027 — Block E Phases E1.1, E1.3, E3.2–E3.4

Disk-based waveform peak cache, async loading with placeholders,
and automation rendering optimizations.

Usage:
    from pydaw.ui.perf_cache import WaveformDiskCache, AutomationCuller

    # Waveform LOD cache
    cache = WaveformDiskCache()
    peaks = cache.get_or_compute("sample.wav", sr=48000)

    # Automation culling
    culler = AutomationCuller()
    visible = culler.cull_points(points, view_start=10.0, view_end=50.0)
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)

try:
    import numpy as np
    _NP = True
except ImportError:
    _NP = False


class WaveformDiskCache:
    """E1.1: Persistent waveform peak cache on disk.

    Pre-computes 3 LOD levels on first load, saves to disk.
    Subsequent loads are instant (no audio decode needed).

    Cache structure:
        ~/.cache/ChronoScaleStudio/waveform_cache/
            {hash}.peaks.npz  (numpy compressed archive)
    """

    def __init__(self, cache_dir: Optional[str | Path] = None):
        if cache_dir is None:
            cache_dir = Path.home() / ".cache" / "ChronoScaleStudio" / "waveform_cache"
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _hash_path(self, audio_path: str, mtime_ns: int) -> Path:
        """Generate cache key from path + modification time."""
        key = f"{audio_path}:{mtime_ns}"
        h = hashlib.md5(key.encode()).hexdigest()[:16]
        return self.cache_dir / f"{h}.peaks.npz"

    def get(self, audio_path: str) -> Optional[Dict[str, Any]]:
        """Get cached peaks if available."""
        if not _NP:
            return None
        try:
            st = os.stat(audio_path)
            cache_path = self._hash_path(audio_path, st.st_mtime_ns)
            if cache_path.exists():
                data = np.load(str(cache_path), allow_pickle=False)
                return {
                    "peaks_full": data["peaks_full"],
                    "mins_full": data["mins_full"],
                    "maxs_full": data["maxs_full"],
                    "peaks_med": data["peaks_med"],
                    "mins_med": data["mins_med"],
                    "maxs_med": data["maxs_med"],
                    "peaks_low": data["peaks_low"],
                    "mins_low": data["mins_low"],
                    "maxs_low": data["maxs_low"],
                    "sr": int(data["sr"]),
                }
        except Exception:
            pass
        return None

    def store(self, audio_path: str, sr: int,
              peaks: Any, mins: Any, maxs: Any) -> None:
        """Store peaks with 3 LOD levels."""
        if not _NP:
            return
        try:
            st = os.stat(audio_path)
            cache_path = self._hash_path(audio_path, st.st_mtime_ns)

            # Generate LOD levels by downsampling
            n = len(peaks)
            med_n = max(8, n // 2)
            low_n = max(8, n // 4)

            def _downsample(arr, target_n):
                if len(arr) <= target_n:
                    return arr
                x_old = np.linspace(0, 1, len(arr))
                x_new = np.linspace(0, 1, target_n)
                return np.interp(x_new, x_old, arr).astype(np.float32)

            np.savez_compressed(
                str(cache_path),
                peaks_full=peaks, mins_full=mins, maxs_full=maxs,
                peaks_med=_downsample(peaks, med_n),
                mins_med=_downsample(mins, med_n),
                maxs_med=_downsample(maxs, med_n),
                peaks_low=_downsample(peaks, low_n),
                mins_low=_downsample(mins, low_n),
                maxs_low=_downsample(maxs, low_n),
                sr=np.array([sr]),
            )
        except Exception as e:
            log.debug("[WFCACHE] Store failed: %s", e)

    def get_lod(self, audio_path: str, zoom_ppb: float) -> Optional[Tuple[Any, Any, Any, int]]:
        """Get appropriate LOD level based on zoom.

        Returns (peaks, mins, maxs, sr) or None.
        """
        data = self.get(audio_path)
        if data is None:
            return None

        if zoom_ppb > 60:
            suffix = "full"
        elif zoom_ppb > 30:
            suffix = "med"
        else:
            suffix = "low"

        return (
            data[f"peaks_{suffix}"],
            data[f"mins_{suffix}"],
            data[f"maxs_{suffix}"],
            data["sr"],
        )

    def clear(self) -> int:
        """Clear all cached peaks. Returns count removed."""
        count = 0
        for f in self.cache_dir.glob("*.peaks.npz"):
            try:
                f.unlink()
                count += 1
            except Exception:
                pass
        return count

    def stats(self) -> Dict[str, Any]:
        """Cache statistics."""
        files = list(self.cache_dir.glob("*.peaks.npz"))
        total_size = sum(f.stat().st_size for f in files)
        return {
            "files": len(files),
            "size_mb": round(total_size / (1024 * 1024), 1),
            "path": str(self.cache_dir),
        }


class AutomationCuller:
    """E3.2–E3.4: Automation rendering optimizations.

    - Culling: only return points in visible range
    - Preview: reduced resolution during scroll
    - Lazy: defer loading until lane is visible
    """

    def cull_points(self, points: List[Dict[str, float]],
                    view_start: float, view_end: float,
                    margin: float = 1.0) -> List[Dict[str, float]]:
        """E3.2: Return only points visible in the current view.

        Args:
            points: automation points [{"t": beat, "v": value}, ...]
            view_start: visible start beat
            view_end: visible end beat
            margin: extra beats to include beyond edges (for smooth curves)

        Returns:
            Filtered point list (plus 1 point before/after for continuity)
        """
        if not points:
            return []

        start = view_start - margin
        end = view_end + margin

        # Binary search for start index
        lo = 0
        hi = len(points)
        while lo < hi:
            mid = (lo + hi) // 2
            if points[mid]["t"] < start:
                lo = mid + 1
            else:
                hi = mid

        # Include one point before visible range (for line continuity)
        first = max(0, lo - 1)

        # Find end index
        last = first
        for i in range(first, len(points)):
            if points[i]["t"] > end:
                last = i + 1  # include one past end
                break
            last = i + 1

        return points[first:min(last, len(points))]

    def preview_downsample(self, points: List[Dict[str, float]],
                           max_points: int = 50) -> List[Dict[str, float]]:
        """E3.4: Reduced resolution for scroll preview.

        During active scrolling, return fewer points for faster rendering.
        Full resolution restored when scrolling stops.
        """
        if len(points) <= max_points:
            return points

        step = max(1, len(points) // max_points)
        result = points[::step]

        # Always include first and last
        if result[0] != points[0]:
            result.insert(0, points[0])
        if result[-1] != points[-1]:
            result.append(points[-1])

        return result

    def should_load(self, lane_rect_top: float, lane_rect_bottom: float,
                    viewport_top: float, viewport_bottom: float) -> bool:
        """E3.3: Check if an automation lane is visible and should be loaded.

        Returns False if the lane is completely outside the viewport.
        """
        return not (lane_rect_bottom < viewport_top or lane_rect_top > viewport_bottom)


# ── D2.3: Semantic MIDI Compression ─────────────────────────────────────────

def detect_midi_pattern_semantic(notes: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """D2.3: Detect semantic MIDI patterns.

    Recognizes: arpeggio, scale run, chord, octave pattern, tremolo.
    Returns description or None.
    """
    if not notes or len(notes) < 3:
        return None

    sorted_n = sorted(notes, key=lambda n: n.get("start_beats", 0))
    pitches = [n.get("pitch", 60) for n in sorted_n]
    times = [n.get("start_beats", 0) for n in sorted_n]
    lengths = [n.get("length_beats", 0.25) for n in sorted_n]

    # Check for constant time intervals
    if len(times) >= 3:
        intervals = [times[i + 1] - times[i] for i in range(len(times) - 1)]
        avg_interval = sum(intervals) / len(intervals)
        is_regular = all(abs(iv - avg_interval) < 0.01 for iv in intervals) if avg_interval > 0 else False
    else:
        is_regular = False
        avg_interval = 0

    # Tremolo: same pitch repeated
    if len(set(pitches)) == 1 and is_regular:
        return {
            "pattern": "tremolo",
            "pitch": pitches[0],
            "interval_beats": round(avg_interval, 4),
            "count": len(pitches),
            "velocity": sorted_n[0].get("velocity", 100),
        }

    # Arpeggio: ascending or descending with regular intervals
    if is_regular and len(pitches) >= 3:
        diffs = [pitches[i + 1] - pitches[i] for i in range(len(pitches) - 1)]
        if len(set(diffs)) == 1 and diffs[0] != 0:
            direction = "up" if diffs[0] > 0 else "down"
            return {
                "pattern": f"arpeggio_{direction}",
                "start_pitch": pitches[0],
                "interval_semitones": abs(diffs[0]),
                "interval_beats": round(avg_interval, 4),
                "count": len(pitches),
            }

        # Check for arpeggio pattern (repeating pitch sequence)
        if len(pitches) >= 6:
            for period in range(3, len(pitches) // 2 + 1):
                is_periodic = True
                for i in range(period, len(pitches)):
                    if pitches[i] != pitches[i % period]:
                        is_periodic = False
                        break
                if is_periodic:
                    return {
                        "pattern": "arpeggio_cyclic",
                        "pitches": pitches[:period],
                        "interval_beats": round(avg_interval, 4),
                        "cycles": len(pitches) // period,
                    }

    # Scale run: consecutive semitones or whole tones
    if len(pitches) >= 4:
        diffs = [pitches[i + 1] - pitches[i] for i in range(len(pitches) - 1)]
        if all(d == 1 for d in diffs):
            return {"pattern": "chromatic_run_up", "start": pitches[0], "count": len(pitches)}
        if all(d == -1 for d in diffs):
            return {"pattern": "chromatic_run_down", "start": pitches[0], "count": len(pitches)}
        if all(d == 2 for d in diffs):
            return {"pattern": "whole_tone_run_up", "start": pitches[0], "count": len(pitches)}

    # Chord: all notes start at same time
    if len(set(round(t, 3) for t in times)) == 1 and len(pitches) >= 3:
        root = min(pitches)
        intervals = sorted(set(p - root for p in pitches))
        return {
            "pattern": "chord",
            "root": root,
            "intervals": intervals,
            "duration": round(max(lengths), 4),
        }

    # Octave pattern: alternating notes 12 semitones apart
    if len(pitches) >= 4 and is_regular:
        is_octave = all(abs(pitches[i] - pitches[i - 1]) == 12 for i in range(1, len(pitches)))
        if is_octave:
            return {
                "pattern": "octave_alternating",
                "low_pitch": min(pitches),
                "interval_beats": round(avg_interval, 4),
                "count": len(pitches),
            }

    return None
