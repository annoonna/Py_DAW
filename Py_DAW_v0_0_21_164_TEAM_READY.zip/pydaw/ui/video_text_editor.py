"""video_text_editor.py — Interactive Text Editor for VE11 (v0.0.20.950).

Text-based video editing panel integrated alongside the video timeline.
Whisper transcription displayed as editable text where:
  - Clicking a word → seeks to that position
  - Deleting a word → cuts video at that position
  - Strikethrough words = deleted regions
  - Word boundary markers shown on timeline
  - SRT/VTT export from text

What NO other DAW has:
  - Text-based video editing inside a music DAW
  - Delete words → automatic jump cuts
  - Word markers synced to beat grid

Usage:
    panel = VideoTextEditorPanel(project_service, transport)
    panel.set_video_path("/path/to/video.mp4")
    panel.word_clicked.connect(on_word_seek)
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

from PyQt6.QtCore import (
    Qt, pyqtSignal, QTimer, QSize,
)
from PyQt6.QtGui import (
    QColor, QFont, QTextCharFormat, QTextCursor,
    QSyntaxHighlighter, QTextDocument, QPalette, QAction,
)
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTextEdit, QComboBox, QProgressBar, QToolButton,
    QFileDialog, QMenu, QSizePolicy, QFrame,
)

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Word Block — stores mapping from text position to word data
# ═══════════════════════════════════════════════════════════════

class _WordBlock:
    """Maps a text region to a transcript word."""
    __slots__ = ("word_id", "word", "start", "end", "deleted",
                 "confidence", "text_start", "text_end")

    def __init__(self, word_id: str, word: str, start: float, end: float,
                 deleted: bool, confidence: float,
                 text_start: int, text_end: int):
        self.word_id = word_id
        self.word = word
        self.start = start
        self.end = end
        self.deleted = deleted
        self.confidence = confidence
        self.text_start = text_start
        self.text_end = text_end


# ═══════════════════════════════════════════════════════════════
# Transcript Text Highlighter
# ═══════════════════════════════════════════════════════════════

class TranscriptHighlighter(QSyntaxHighlighter):
    """Highlights transcript words based on state.
    
    - Normal words: light text
    - Deleted words: red strikethrough
    - Low confidence: yellow tint
    - Current word (playhead): bright highlight
    """

    def __init__(self, document: QTextDocument):
        super().__init__(document)
        self._word_blocks: List[_WordBlock] = []
        self._current_time: float = 0.0

        # Formats
        self._fmt_normal = QTextCharFormat()
        self._fmt_normal.setForeground(QColor("#e0e0e0"))

        self._fmt_deleted = QTextCharFormat()
        self._fmt_deleted.setForeground(QColor("#ff4444"))
        self._fmt_deleted.setFontStrikeOut(True)
        self._fmt_deleted.setBackground(QColor(255, 0, 0, 30))

        self._fmt_low_conf = QTextCharFormat()
        self._fmt_low_conf.setForeground(QColor("#ffcc00"))

        self._fmt_current = QTextCharFormat()
        self._fmt_current.setBackground(QColor(0, 150, 255, 80))
        self._fmt_current.setForeground(QColor("#ffffff"))
        self._fmt_current.setFontWeight(QFont.Weight.Bold)

        self._fmt_segment_break = QTextCharFormat()
        self._fmt_segment_break.setForeground(QColor("#555555"))

    def set_word_blocks(self, blocks: List[_WordBlock]) -> None:
        self._word_blocks = blocks
        self.rehighlight()

    def set_current_time(self, seconds: float) -> None:
        self._current_time = seconds
        self.rehighlight()

    def highlightBlock(self, text: str) -> None:
        block_start = self.currentBlock().position()
        block_end = block_start + len(text)

        for wb in self._word_blocks:
            if wb.text_end <= block_start or wb.text_start >= block_end:
                continue

            rel_start = max(0, wb.text_start - block_start)
            rel_end = min(len(text), wb.text_end - block_start)
            length = rel_end - rel_start
            if length <= 0:
                continue

            if wb.deleted:
                self.setFormat(rel_start, length, self._fmt_deleted)
            elif (wb.start <= self._current_time <= wb.end):
                self.setFormat(rel_start, length, self._fmt_current)
            elif wb.confidence < 0.5 and wb.confidence > 0:
                self.setFormat(rel_start, length, self._fmt_low_conf)
            else:
                self.setFormat(rel_start, length, self._fmt_normal)


# ═══════════════════════════════════════════════════════════════
# Video Text Editor Panel
# ═══════════════════════════════════════════════════════════════

class VideoTextEditorPanel(QWidget):
    """Text-based video editing panel.
    
    Signals:
        word_clicked(float): Emitted with timestamp when a word is clicked
        words_changed(): Emitted when words are deleted/restored
        word_markers_ready(list): Emitted with word boundary markers
        export_requested(str, str): format, path
    """

    word_clicked = pyqtSignal(float)    # seek to time
    words_changed = pyqtSignal()         # editing happened
    word_markers_ready = pyqtSignal(list)  # markers for timeline

    def __init__(self, project_service=None, transport=None, parent=None):
        super().__init__(parent)
        self._ps = project_service
        self._transport = transport
        self._video_path: Optional[str] = None
        self._word_blocks: List[_WordBlock] = []
        self._read_only = True  # Can't type, only delete/restore

        self._setup_ui()
        self._setup_timers()

    def _setup_ui(self) -> None:
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(4)

        # ── Header ──
        header = QHBoxLayout()
        header.setSpacing(4)

        lbl = QLabel("📝 Text-Editor")
        lbl.setStyleSheet(
            "font-weight: bold; color: #e0e0e0; font-size: 11px;")
        header.addWidget(lbl)

        # Transcribe button
        self._btn_transcribe = QPushButton("🎤 Transkribieren")
        self._btn_transcribe.setFixedHeight(22)
        self._btn_transcribe.setStyleSheet(
            "QPushButton { background: #2a3a4a; border: 1px solid #4a6a8a; "
            "border-radius: 3px; color: #aaddff; font-size: 10px; "
            "padding: 0 8px; }"
            "QPushButton:hover { background: #3a4a5a; }"
            "QPushButton:disabled { background: #222; color: #666; }"
        )
        self._btn_transcribe.clicked.connect(self._on_transcribe)
        header.addWidget(self._btn_transcribe)

        # Model selector
        self._cmb_model = QComboBox()
        self._cmb_model.addItems(["tiny", "base", "small", "medium", "large"])
        self._cmb_model.setCurrentText("base")
        self._cmb_model.setFixedWidth(70)
        self._cmb_model.setFixedHeight(22)
        self._cmb_model.setStyleSheet(
            "QComboBox { background: #2a2a3a; color: #ddd; "
            "border: 1px solid #444; border-radius: 3px; "
            "font-size: 10px; padding: 0 4px; }"
        )
        self._cmb_model.setToolTip("Whisper-Modell (größer = genauer)")
        header.addWidget(self._cmb_model)

        # Language selector
        self._cmb_lang = QComboBox()
        self._cmb_lang.addItems(["Auto", "de", "en", "fr", "es", "it",
                                  "pt", "ja", "zh", "ko", "ru"])
        self._cmb_lang.setFixedWidth(55)
        self._cmb_lang.setFixedHeight(22)
        self._cmb_lang.setStyleSheet(
            "QComboBox { background: #2a2a3a; color: #ddd; "
            "border: 1px solid #444; border-radius: 3px; "
            "font-size: 10px; padding: 0 4px; }"
        )
        self._cmb_lang.setToolTip("Sprache")
        header.addWidget(self._cmb_lang)

        header.addStretch(1)

        # Export menu button
        self._btn_export = QPushButton("💾 Export")
        self._btn_export.setFixedHeight(22)
        self._btn_export.setStyleSheet(
            "QPushButton { background: #2a3a2a; border: 1px solid #4a6a4a; "
            "border-radius: 3px; color: #aaffaa; font-size: 10px; "
            "padding: 0 8px; }"
            "QPushButton:hover { background: #3a4a3a; }"
        )
        self._btn_export.clicked.connect(self._on_export_menu)
        header.addWidget(self._btn_export)

        # Undo button
        btn_undo = QPushButton("↩ Undo")
        btn_undo.setFixedHeight(22)
        btn_undo.setStyleSheet(
            "QPushButton { background: #3a2a3a; border: 1px solid #6a4a6a; "
            "border-radius: 3px; color: #ddaaff; font-size: 10px; "
            "padding: 0 8px; }"
            "QPushButton:hover { background: #4a3a4a; }"
        )
        btn_undo.clicked.connect(self._on_undo_delete)
        btn_undo.setToolTip("Letztes gelöschtes Wort wiederherstellen")
        header.addWidget(btn_undo)

        header_w = QWidget()
        header_w.setLayout(header)
        lay.addWidget(header_w)

        # ── Progress bar ──
        self._progress = QProgressBar()
        self._progress.setFixedHeight(14)
        self._progress.setTextVisible(True)
        self._progress.setFormat("Bereit")
        self._progress.setValue(0)
        self._progress.setStyleSheet(
            "QProgressBar { background: #1a1a2a; border: 1px solid #333; "
            "border-radius: 3px; color: #aaa; font-size: 9px; }"
            "QProgressBar::chunk { background: #3a6a9a; }"
        )
        self._progress.hide()
        lay.addWidget(self._progress)

        # ── Text editor ──
        self._text_edit = QTextEdit()
        self._text_edit.setReadOnly(True)
        self._text_edit.setFont(QFont("Segoe UI", 11))
        self._text_edit.setStyleSheet(
            "QTextEdit { background: #0f0f1a; color: #e0e0e0; "
            "border: 1px solid #333; border-radius: 4px; "
            "padding: 8px; selection-background-color: #3a5a7a; }"
        )
        self._text_edit.setPlaceholderText(
            "Klicke '🎤 Transkribieren' um den Videotext zu erkennen.\n\n"
            "Dann kannst du:\n"
            "  • Auf Wörter klicken → Video springt dorthin\n"
            "  • Wörter löschen → Video wird dort geschnitten\n"
            "  • Untertitel exportieren (SRT, VTT)\n"
        )
        self._text_edit.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu)
        self._text_edit.customContextMenuRequested.connect(
            self._on_context_menu)
        self._text_edit.cursorPositionChanged.connect(
            self._on_cursor_moved)
        self._text_edit.mousePressEvent = self._on_text_click
        lay.addWidget(self._text_edit, 1)

        # ── Status bar ──
        self._lbl_status = QLabel("")
        self._lbl_status.setStyleSheet(
            "color: #888; font-size: 9px; padding: 2px;")
        lay.addWidget(self._lbl_status)

        # ── Highlighter ──
        self._highlighter = TranscriptHighlighter(
            self._text_edit.document())

        # History for undo
        self._delete_history: List[str] = []  # word_ids

        # Styling
        self.setStyleSheet("background: #12121e;")
        self.setMinimumWidth(200)

    def _setup_timers(self) -> None:
        # Update current word highlight every 100ms
        self._highlight_timer = QTimer(self)
        self._highlight_timer.setInterval(100)
        self._highlight_timer.timeout.connect(self._update_highlight)
        self._highlight_timer.start()

    # ── Public API ──

    def set_video_path(self, path: Optional[str]) -> None:
        """Set the video file to work with."""
        self._video_path = path
        if path:
            # Try loading existing transcript
            try:
                from pydaw.services.video_whisper_service import WhisperService
                svc = WhisperService.instance()
                transcript = svc.get_transcript(path)
                if transcript:
                    self._display_transcript(transcript)
                    return
            except Exception as exc:
                log.debug("Transcript load: %s", exc)
            self._text_edit.clear()
            self._word_blocks.clear()
            self._update_status()
        else:
            self._text_edit.clear()
            self._word_blocks.clear()
            self._lbl_status.setText("")

    def get_word_markers(self) -> List[Dict[str, Any]]:
        """Get word boundary markers for the timeline."""
        markers = []
        for wb in self._word_blocks:
            markers.append({
                "word_id": wb.word_id,
                "word": wb.word,
                "start": wb.start,
                "end": wb.end,
                "deleted": wb.deleted,
                "confidence": wb.confidence,
            })
        return markers

    # ── Transcription ──

    def _on_transcribe(self) -> None:
        """Start Whisper transcription."""
        if not self._video_path:
            self._lbl_status.setText("⚠ Kein Video geladen")
            return

        try:
            from pydaw.services.video_whisper_service import WhisperService
        except ImportError:
            self._lbl_status.setText("⚠ WhisperService nicht verfügbar")
            return

        svc = WhisperService.instance()
        if svc.is_busy:
            self._lbl_status.setText("⏳ Transkription läuft bereits...")
            return

        model = self._cmb_model.currentText()
        lang_text = self._cmb_lang.currentText()
        language = None if lang_text == "Auto" else lang_text

        self._btn_transcribe.setEnabled(False)
        self._progress.show()
        self._progress.setFormat("Transkription läuft...")
        self._progress.setRange(0, 0)  # indeterminate

        # Transcription callback (called on worker thread!)
        def _on_done(transcript):
            # Schedule UI update on main thread
            QTimer.singleShot(0, lambda: self._on_transcript_ready(transcript))

        svc.transcribe(self._video_path, model_size=model,
                       language=language, callback=_on_done, force=True)

    def _on_transcript_ready(self, transcript) -> None:
        """Called when transcription is complete."""
        self._btn_transcribe.setEnabled(True)
        self._progress.hide()
        self._display_transcript(transcript)

    def _display_transcript(self, transcript) -> None:
        """Render transcript text with word blocks."""
        self._word_blocks.clear()
        self._delete_history.clear()

        # Build text and word block map
        text_parts = []
        cursor_pos = 0

        for seg_idx, seg in enumerate(transcript.segments):
            if seg_idx > 0:
                text_parts.append("\n\n")
                cursor_pos += 2

            for w_idx, word in enumerate(seg.words):
                if w_idx > 0:
                    text_parts.append(" ")
                    cursor_pos += 1

                word_text = word.word
                text_start = cursor_pos
                text_end = cursor_pos + len(word_text)

                wb = _WordBlock(
                    word_id=word.word_id,
                    word=word_text,
                    start=word.start,
                    end=word.end,
                    deleted=word.deleted,
                    confidence=word.confidence,
                    text_start=text_start,
                    text_end=text_end,
                )
                self._word_blocks.append(wb)

                text_parts.append(word_text)
                cursor_pos = text_end

        full_text = "".join(text_parts)

        # Set text without triggering textChanged
        self._text_edit.blockSignals(True)
        self._text_edit.setPlainText(full_text)
        self._text_edit.blockSignals(False)

        # Update highlighter
        self._highlighter.set_word_blocks(self._word_blocks)

        # Emit markers
        markers = self.get_word_markers()
        self.word_markers_ready.emit(markers)

        self._update_status()

    # ── Word operations ──

    def _word_at_cursor(self, pos: int) -> Optional[_WordBlock]:
        """Find word block at text cursor position."""
        for wb in self._word_blocks:
            if wb.text_start <= pos < wb.text_end:
                return wb
        return None

    def _on_text_click(self, event) -> None:
        """Handle click on text — seek to word position."""
        # Call original handler
        QTextEdit.mousePressEvent(self._text_edit, event)

        cursor = self._text_edit.textCursor()
        pos = cursor.position()
        wb = self._word_at_cursor(pos)

        if wb and not wb.deleted:
            # Seek to word start
            self.word_clicked.emit(wb.start)
            self._lbl_status.setText(
                f"▶ {wb.word} ({wb.start:.2f}s – {wb.end:.2f}s)")

    def _on_cursor_moved(self) -> None:
        """Update status when cursor moves."""
        cursor = self._text_edit.textCursor()
        pos = cursor.position()
        wb = self._word_at_cursor(pos)
        if wb:
            state = "🗑 gelöscht" if wb.deleted else "✓"
            conf = f"{wb.confidence * 100:.0f}%" if wb.confidence > 0 else "—"
            self._lbl_status.setText(
                f"'{wb.word}' | {wb.start:.2f}s–{wb.end:.2f}s | "
                f"Konf: {conf} | {state}")

    def _delete_word_at_cursor(self) -> None:
        """Delete the word at current cursor position."""
        cursor = self._text_edit.textCursor()
        pos = cursor.position()
        wb = self._word_at_cursor(pos)

        if wb and not wb.deleted:
            self._delete_word(wb)

    def _delete_word(self, wb: _WordBlock) -> None:
        """Mark a word as deleted."""
        wb.deleted = True
        self._delete_history.append(wb.word_id)

        # Update in WhisperService
        if self._video_path:
            try:
                from pydaw.services.video_whisper_service import WhisperService
                svc = WhisperService.instance()
                svc.delete_word(self._video_path, wb.word_id)
            except Exception:
                pass

        # Update highlighting
        self._highlighter.set_word_blocks(self._word_blocks)
        self.words_changed.emit()
        self.word_markers_ready.emit(self.get_word_markers())
        self._update_status()

    def _restore_word(self, wb: _WordBlock) -> None:
        """Restore a deleted word."""
        wb.deleted = False

        if self._video_path:
            try:
                from pydaw.services.video_whisper_service import WhisperService
                svc = WhisperService.instance()
                svc.restore_word(self._video_path, wb.word_id)
            except Exception:
                pass

        self._highlighter.set_word_blocks(self._word_blocks)
        self.words_changed.emit()
        self.word_markers_ready.emit(self.get_word_markers())
        self._update_status()

    def _on_undo_delete(self) -> None:
        """Undo last word deletion."""
        if not self._delete_history:
            return
        word_id = self._delete_history.pop()
        for wb in self._word_blocks:
            if wb.word_id == word_id:
                self._restore_word(wb)
                break

    # ── Context menu ──

    def _on_context_menu(self, pos) -> None:
        """Custom context menu for word operations."""
        cursor = self._text_edit.cursorForPosition(pos)
        wb = self._word_at_cursor(cursor.position())

        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu { background: #1e1e2e; color: #ddd; "
            "border: 1px solid #444; }"
            "QMenu::item:selected { background: #3a4a5a; }"
        )

        if wb:
            if wb.deleted:
                act_restore = menu.addAction(
                    f"↩ Wiederherstellen: '{wb.word}'")
                act_restore.triggered.connect(
                    lambda: self._restore_word(wb))
            else:
                act_delete = menu.addAction(f"🗑 Löschen: '{wb.word}'")
                act_delete.triggered.connect(
                    lambda: self._delete_word(wb))

                act_seek = menu.addAction(f"▶ Springe zu {wb.start:.2f}s")
                act_seek.triggered.connect(
                    lambda: self.word_clicked.emit(wb.start))

            menu.addSeparator()

        # Delete selection (multiple words)
        cursor_sel = self._text_edit.textCursor()
        if cursor_sel.hasSelection():
            act_del_sel = menu.addAction("🗑 Auswahl löschen")
            act_del_sel.triggered.connect(self._delete_selection)
            menu.addSeparator()

        # Restore all
        act_restore_all = menu.addAction("↩ Alle wiederherstellen")
        act_restore_all.triggered.connect(self._restore_all)

        menu.addSeparator()

        # Export submenu
        sub_export = menu.addMenu("💾 Exportieren")
        sub_export.addAction("SRT (Untertitel)").triggered.connect(
            lambda: self._export("srt"))
        sub_export.addAction("VTT (WebVTT)").triggered.connect(
            lambda: self._export("vtt"))
        sub_export.addAction("Text (Transkript)").triggered.connect(
            lambda: self._export("txt"))

        menu.exec(self._text_edit.mapToGlobal(pos))

    def _delete_selection(self) -> None:
        """Delete all words in current text selection."""
        cursor = self._text_edit.textCursor()
        if not cursor.hasSelection():
            return

        sel_start = cursor.selectionStart()
        sel_end = cursor.selectionEnd()

        for wb in self._word_blocks:
            if (not wb.deleted and
                    wb.text_start < sel_end and wb.text_end > sel_start):
                wb.deleted = True
                self._delete_history.append(wb.word_id)
                if self._video_path:
                    try:
                        from pydaw.services.video_whisper_service import WhisperService
                        svc = WhisperService.instance()
                        svc.delete_word(self._video_path, wb.word_id)
                    except Exception:
                        pass

        self._highlighter.set_word_blocks(self._word_blocks)
        self.words_changed.emit()
        self.word_markers_ready.emit(self.get_word_markers())
        self._update_status()

    def _restore_all(self) -> None:
        """Restore all deleted words."""
        for wb in self._word_blocks:
            if wb.deleted:
                wb.deleted = False
                if self._video_path:
                    try:
                        from pydaw.services.video_whisper_service import WhisperService
                        svc = WhisperService.instance()
                        svc.restore_word(self._video_path, wb.word_id)
                    except Exception:
                        pass

        self._delete_history.clear()
        self._highlighter.set_word_blocks(self._word_blocks)
        self.words_changed.emit()
        self.word_markers_ready.emit(self.get_word_markers())
        self._update_status()

    # ── Export ──

    def _on_export_menu(self) -> None:
        """Show export format menu."""
        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu { background: #1e1e2e; color: #ddd; "
            "border: 1px solid #444; }"
            "QMenu::item:selected { background: #3a4a5a; }"
        )
        menu.addAction("SRT (Untertitel)").triggered.connect(
            lambda: self._export("srt"))
        menu.addAction("VTT (WebVTT)").triggered.connect(
            lambda: self._export("vtt"))
        menu.addAction("Text (Transkript)").triggered.connect(
            lambda: self._export("txt"))
        menu.exec(self._btn_export.mapToGlobal(
            self._btn_export.rect().bottomLeft()))

    def _export(self, fmt: str) -> None:
        """Export transcript in given format."""
        if not self._video_path:
            return

        try:
            from pydaw.services.video_whisper_service import WhisperService
            svc = WhisperService.instance()
            transcript = svc.get_transcript(self._video_path)
        except Exception:
            transcript = None

        if not transcript:
            self._lbl_status.setText("⚠ Kein Transkript vorhanden")
            return

        # Default filename
        base = os.path.splitext(os.path.basename(self._video_path))[0]
        ext_map = {"srt": ".srt", "vtt": ".vtt", "txt": ".txt"}
        ext = ext_map.get(fmt, ".txt")
        default_name = f"{base}_subtitle{ext}"

        path, _ = QFileDialog.getSaveFileName(
            self, f"Exportieren als {fmt.upper()}",
            default_name,
            f"{fmt.upper()} Dateien (*{ext});;Alle Dateien (*)",
        )
        if not path:
            return

        try:
            from pydaw.services.video_subtitle_export import (
                export_srt, export_vtt, export_plain_text)

            if fmt == "srt":
                ok = export_srt(transcript, path)
            elif fmt == "vtt":
                ok = export_vtt(transcript, path)
            else:
                ok = export_plain_text(transcript, path,
                                        include_timestamps=True)

            if ok:
                self._lbl_status.setText(f"✅ Exportiert: {path}")
            else:
                self._lbl_status.setText(f"❌ Export fehlgeschlagen")
        except Exception as exc:
            self._lbl_status.setText(f"❌ Fehler: {exc}")

    # ── Highlight / playhead ──

    def _update_highlight(self) -> None:
        """Update word highlight based on playhead position."""
        if not self._transport or not self._word_blocks:
            return
        try:
            # Get current playhead time in seconds
            beat = 0.0
            if hasattr(self._transport, 'playhead_beat'):
                beat = self._transport.playhead_beat
            elif hasattr(self._transport, 'position_beats'):
                beat = self._transport.position_beats
            else:
                return

            bpm = 120.0
            if hasattr(self._transport, 'bpm'):
                bpm = self._transport.bpm
            elif hasattr(self._transport, 'get_bpm'):
                bpm = self._transport.get_bpm()

            seconds = beat * 60.0 / bpm if bpm > 0 else 0

            self._highlighter.set_current_time(seconds)
        except Exception:
            pass

    # ── Status ──

    def _update_status(self) -> None:
        """Update status bar."""
        total = len(self._word_blocks)
        deleted = sum(1 for wb in self._word_blocks if wb.deleted)
        active = total - deleted

        if total == 0:
            self._lbl_status.setText("Kein Transkript")
        else:
            self._lbl_status.setText(
                f"📝 {active}/{total} Wörter aktiv "
                f"| 🗑 {deleted} gelöscht")

    # ── Keyboard shortcuts ──

    def keyPressEvent(self, event) -> None:
        key = event.key()
        mods = event.modifiers()

        if key == Qt.Key.Key_Delete or key == Qt.Key.Key_Backspace:
            # Check if selection exists
            cursor = self._text_edit.textCursor()
            if cursor.hasSelection():
                self._delete_selection()
            else:
                self._delete_word_at_cursor()
            return

        if key == Qt.Key.Key_Z and mods & Qt.KeyboardModifier.ControlModifier:
            self._on_undo_delete()
            return

        super().keyPressEvent(event)
