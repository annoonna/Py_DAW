"""video_filter_panel.py — VP6 UI: Video-Filter-Panel (v0.0.20.925).

PyQt6 panel for editing per-clip video filters.
Shows a list of filters with sliders, enable/disable toggles,
preset browser, and real-time ffmpeg preview string.

Usage:
    panel = VideoFilterPanel(parent)
    panel.set_clip_id("clip_123")
    # User interacts with sliders → changes are stored in VideoFilterService
"""

from __future__ import annotations

import logging
from typing import Optional

log = logging.getLogger(__name__)

try:
    from PyQt6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
        QSlider, QCheckBox, QComboBox, QGroupBox, QScrollArea,
        QFrame, QSizePolicy,
    )
    from PyQt6.QtCore import Qt, pyqtSignal
    from PyQt6.QtGui import QColor
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


if _QT_AVAILABLE:

    class VideoFilterPanel(QWidget):
        """VP6 UI: Panel for editing video clip filters.

        Shows filter chain with sliders, presets, and live ffmpeg string.
        """

        filter_changed = pyqtSignal(str)  # clip_id

        def __init__(self, parent=None):
            super().__init__(parent)
            self._clip_id: str = ""
            self._filter_service = None
            self._filter_widgets: list = []
            self._setup_ui()

        def _get_service(self):
            if self._filter_service is None:
                try:
                    from pydaw.services.video_filter_service import VideoFilterService
                    self._filter_service = VideoFilterService.instance()
                except Exception:
                    pass
            return self._filter_service

        def _setup_ui(self) -> None:
            layout = QVBoxLayout(self)
            layout.setContentsMargins(4, 4, 4, 4)
            layout.setSpacing(4)

            # Header
            hdr = QHBoxLayout()
            self._lbl_title = QLabel("🎬 Video-Filter")
            self._lbl_title.setStyleSheet("font-weight: bold; font-size: 13px;")
            hdr.addWidget(self._lbl_title)
            hdr.addStretch()

            # Add filter button
            self._btn_add = QPushButton("+ Filter")
            self._btn_add.setToolTip("Neuen Filter hinzufügen")
            self._btn_add.clicked.connect(self._on_add_filter)
            hdr.addWidget(self._btn_add)

            # Preset combo
            self._cmb_preset = QComboBox()
            self._cmb_preset.addItem("— Preset —")
            self._cmb_preset.addItems([
                "Warm Sunset", "Cool Blue", "Film Noir",
                "Vintage 8mm", "High Contrast", "Soft Dreamy",
            ])
            self._cmb_preset.setToolTip("Vordefiniertes Filter-Set anwenden")
            self._cmb_preset.currentTextChanged.connect(self._on_preset_selected)
            hdr.addWidget(self._cmb_preset)

            layout.addLayout(hdr)

            # Scroll area for filter list
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QFrame.Shape.NoFrame)
            self._scroll_widget = QWidget()
            self._scroll_layout = QVBoxLayout(self._scroll_widget)
            self._scroll_layout.setContentsMargins(0, 0, 0, 0)
            self._scroll_layout.setSpacing(2)
            self._scroll_layout.addStretch()
            scroll.setWidget(self._scroll_widget)
            layout.addWidget(scroll, 1)

            # ffmpeg preview
            self._lbl_ffmpeg = QLabel("")
            self._lbl_ffmpeg.setStyleSheet(
                "color: #888; font-family: monospace; font-size: 10px; "
                "padding: 2px 4px; background: rgba(0,0,0,30); border-radius: 3px;"
            )
            self._lbl_ffmpeg.setWordWrap(True)
            self._lbl_ffmpeg.setToolTip("ffmpeg -vf Filter-String (wird beim Export verwendet)")
            layout.addWidget(self._lbl_ffmpeg)

            # No-clip label
            self._lbl_no_clip = QLabel("Kein Video-Clip ausgewählt")
            self._lbl_no_clip.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self._lbl_no_clip.setStyleSheet("color: #666; font-style: italic;")
            layout.addWidget(self._lbl_no_clip)

            self.setMinimumWidth(260)
            self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)

        def set_clip_id(self, clip_id: str) -> None:
            """Set which clip's filters to display/edit."""
            self._clip_id = clip_id
            self._lbl_no_clip.setVisible(not clip_id)
            self._rebuild_filter_list()

        def _rebuild_filter_list(self) -> None:
            """Rebuild all filter widgets from the service."""
            # Clear existing
            for w in self._filter_widgets:
                try:
                    w.setParent(None)
                    w.deleteLater()
                except Exception:
                    pass
            self._filter_widgets.clear()

            svc = self._get_service()
            if not svc or not self._clip_id:
                self._update_ffmpeg_preview()
                return

            chain = svc.get_chain(self._clip_id)
            for i, f in enumerate(chain.filters):
                widget = self._create_filter_widget(i, f)
                # Insert before the stretch
                self._scroll_layout.insertWidget(
                    self._scroll_layout.count() - 1, widget
                )
                self._filter_widgets.append(widget)

            self._update_ffmpeg_preview()

        def _create_filter_widget(self, index: int, f) -> QWidget:
            """Create a single filter row widget with slider + controls."""
            group = QGroupBox()
            group.setStyleSheet(
                "QGroupBox { border: 1px solid #444; border-radius: 4px; "
                "padding: 4px; margin: 1px; }"
            )
            layout = QVBoxLayout(group)
            layout.setContentsMargins(6, 6, 6, 6)
            layout.setSpacing(3)

            # Top row: enable checkbox + name + remove button
            top = QHBoxLayout()

            chk = QCheckBox()
            chk.setChecked(f.enabled)
            chk.setToolTip("Filter aktivieren/deaktivieren")
            chk.stateChanged.connect(lambda state, idx=index: self._on_toggle(idx, state))
            top.addWidget(chk)

            lbl = QLabel(f.display_name)
            lbl.setStyleSheet("font-weight: bold;")
            top.addWidget(lbl)
            top.addStretch()

            # Value display
            val_lbl = QLabel(f"{f.value:.2f}")
            val_lbl.setStyleSheet("color: #aaa; font-family: monospace;")
            val_lbl.setMinimumWidth(50)
            top.addWidget(val_lbl)

            btn_rm = QPushButton("✕")
            btn_rm.setFixedSize(20, 20)
            btn_rm.setToolTip("Filter entfernen")
            btn_rm.clicked.connect(lambda checked, idx=index: self._on_remove(idx))
            top.addWidget(btn_rm)

            layout.addLayout(top)

            # Slider
            vmin, vmax, step = f.value_range
            slider = QSlider(Qt.Orientation.Horizontal)
            slider.setMinimum(int(vmin * 100))
            slider.setMaximum(int(vmax * 100))
            slider.setValue(int(f.value * 100))
            slider.setTickInterval(int(step * 100) or 1)

            def on_slide(val, idx=index, lbl=val_lbl):
                real_val = val / 100.0
                lbl.setText(f"{real_val:.2f}")
                self._on_value_changed(idx, real_val)

            slider.valueChanged.connect(on_slide)
            layout.addWidget(slider)

            # Reset button
            btn_reset = QPushButton(f"↺ Reset ({f.default_value:.1f})")
            btn_reset.setFixedHeight(18)
            btn_reset.setStyleSheet("font-size: 10px;")
            btn_reset.clicked.connect(
                lambda checked, idx=index, s=slider, dv=f.default_value:
                    s.setValue(int(dv * 100))
            )
            layout.addWidget(btn_reset)

            return group

        def _on_toggle(self, index: int, state: int) -> None:
            """Toggle filter enable/disable."""
            svc = self._get_service()
            if not svc or not self._clip_id:
                return
            try:
                chain = svc.get_chain(self._clip_id)
                if 0 <= index < len(chain.filters):
                    chain.filters[index].enabled = bool(state)
                    self._update_ffmpeg_preview()
                    self.filter_changed.emit(self._clip_id)
                    self._collab_send_filter()
            except Exception:
                pass

        def _on_value_changed(self, index: int, value: float) -> None:
            """Update filter value from slider."""
            svc = self._get_service()
            if not svc or not self._clip_id:
                return
            try:
                chain = svc.get_chain(self._clip_id)
                if 0 <= index < len(chain.filters):
                    chain.filters[index].value = value
                    self._update_ffmpeg_preview()
                    self.filter_changed.emit(self._clip_id)
                    self._collab_send_filter()
            except Exception:
                pass

        def _on_remove(self, index: int) -> None:
            """Remove a filter."""
            svc = self._get_service()
            if svc and self._clip_id:
                svc.remove_filter(self._clip_id, index)
                self._rebuild_filter_list()
                self.filter_changed.emit(self._clip_id)
                self._collab_send_filter()

        def _on_add_filter(self) -> None:
            """Add a new filter — show type picker."""
            if not self._clip_id:
                return
            svc = self._get_service()
            if not svc:
                return

            # Show a popup menu for filter type selection
            try:
                from PyQt6.QtWidgets import QMenu
                from pydaw.services.video_filter_service import VideoFilter

                menu = QMenu(self)
                filter_types = [
                    ("brightness", "🔆 Helligkeit"),
                    ("contrast", "◐ Kontrast"),
                    ("saturation", "🎨 Sättigung"),
                    ("gamma", "γ Gamma"),
                    ("blur", "💨 Weichzeichner"),
                    ("sharpen", "🔪 Schärfe"),
                    ("vignette", "🔲 Vignette"),
                ]

                for kind, label in filter_types:
                    action = menu.addAction(label)
                    action.setData(kind)

                act = menu.exec(self._btn_add.mapToGlobal(
                    self._btn_add.rect().bottomLeft()
                ))
                if act:
                    kind = act.data()
                    f = VideoFilter(kind=kind)
                    f.value = f.default_value
                    svc.add_filter(self._clip_id, f)
                    self._rebuild_filter_list()
                    self.filter_changed.emit(self._clip_id)
            except Exception as e:
                log.debug("[VP6 UI] add filter error: %s", e)

        def _on_preset_selected(self, name: str) -> None:
            """Apply a preset filter chain."""
            if name.startswith("—") or not name:
                return
            svc = self._get_service()
            if svc and self._clip_id:
                if svc.apply_preset(self._clip_id, name):
                    self._rebuild_filter_list()
                    self.filter_changed.emit(self._clip_id)
                    self._collab_send_filter()
            # Reset combo
            self._cmb_preset.setCurrentIndex(0)

        def _collab_send_filter(self) -> None:
            """v0.0.20.948: Send filter chain to collab (safe)."""
            if not self._clip_id:
                return
            try:
                main_win = self.window()
                if not main_win:
                    return
                cp = getattr(main_win, '_collab_panel', None) or getattr(main_win, 'collab_panel', None)
                if not cp:
                    return
                vcs = getattr(cp, '_video_collab', None)
                if not vcs:
                    return
                svc = self._get_service()
                if svc:
                    chain = svc.save_all().get(self._clip_id, {})
                    vcs.send_filter_sync(self._clip_id, chain)
            except Exception:
                pass

        def _update_ffmpeg_preview(self) -> None:
            """Update the ffmpeg filter string preview label."""
            svc = self._get_service()
            if not svc or not self._clip_id:
                self._lbl_ffmpeg.setText("")
                return
            ff = svc.get_ffmpeg_filter_string(self._clip_id)
            self._lbl_ffmpeg.setText(f"-vf \"{ff}\"" if ff else "(keine aktiven Filter)")

else:
    # Fallback when Qt is not available
    class VideoFilterPanel:  # type: ignore[no-redef]
        """Placeholder when PyQt6 is not available."""
        def __init__(self, *a, **kw):
            pass
        def set_clip_id(self, clip_id: str) -> None:
            pass
