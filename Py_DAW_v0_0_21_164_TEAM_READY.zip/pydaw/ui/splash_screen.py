"""splash_screen.py — Startup Splash Screen for Py_DAW (v0.0.20.956).

Professional animated splash screen shown during DAW startup:
  - Py_DAW logo + version
  - Animated progress bar with gradient
  - Live status messages (what's loading)
  - Module checklist (Services, Plugins, Audio, UI)

What NO other DAW has:
  - Live loading messages showing exactly what's being initialized
  - Plugin count + preset count during scan
  - Animated gradient splash (not a static image)

Usage:
    splash = SplashScreen(version="0.0.20.956")
    splash.show()
    splash.set_status("Services initialisieren...")
    splash.set_progress(0.3)
    # ... do work ...
    splash.finish(main_window)
"""

from __future__ import annotations

import time
from typing import Optional

from PyQt6.QtCore import Qt, QTimer, QRect, QSize
from PyQt6.QtGui import (
    QColor, QFont, QPainter, QPen, QBrush, QLinearGradient,
    QRadialGradient, QPaintEvent,
)
from PyQt6.QtWidgets import (
    QSplashScreen, QWidget, QApplication,
)

import logging
log = logging.getLogger(__name__)


class SplashScreen(QWidget):
    """Animated startup splash screen for Py_DAW.
    
    Shows:
      - Title + version
      - Animated gradient progress bar
      - Current loading step
      - Step checklist with timing
    """

    def __init__(self, version: str = "", parent=None):
        super().__init__(parent)
        self._version = version or "0.0.20"
        self._progress = 0.0
        self._status = "Starte..."
        self._steps: list[tuple[str, str, float]] = []  # (icon, text, time)
        self._start_time = time.time()
        self._pulse_offset = 0.0
        self._active = True

        # Window setup
        self.setWindowFlags(
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.SplashScreen)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)
        self.setFixedSize(520, 340)

        # Center on screen
        try:
            screen = QApplication.primaryScreen()
            if screen:
                geo = screen.availableGeometry()
                self.move(
                    geo.x() + (geo.width() - 520) // 2,
                    geo.y() + (geo.height() - 340) // 2)
        except Exception:
            pass

        # Pulse timer
        self._timer = QTimer(self)
        self._timer.setInterval(30)
        self._timer.timeout.connect(self._on_tick)
        self._timer.start()

    def set_progress(self, value: float) -> None:
        """Set progress 0.0–1.0."""
        self._progress = max(0.0, min(1.0, value))
        self.update()
        QApplication.processEvents()

    def set_status(self, text: str, icon: str = "⏳") -> None:
        """Set current loading status text."""
        self._status = text
        elapsed = time.time() - self._start_time
        self._steps.append((icon, text, elapsed))
        # Keep last 6 steps visible
        if len(self._steps) > 6:
            self._steps = self._steps[-6:]
        self.update()
        QApplication.processEvents()

    def finish(self, main_window=None) -> None:
        """Fade out and close splash."""
        self._active = False
        self._timer.stop()
        self._progress = 1.0
        elapsed = time.time() - self._start_time
        self._status = f"Bereit! ({elapsed:.1f}s)"
        self.update()
        QApplication.processEvents()
        QTimer.singleShot(400, self.close)

    def _on_tick(self) -> None:
        self._pulse_offset += 0.025
        if self._pulse_offset > 2.0:
            self._pulse_offset = 0.0
        self.update()

    def paintEvent(self, event: QPaintEvent) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()

        # ── Background ──
        bg = QLinearGradient(0, 0, 0, h)
        bg.setColorAt(0.0, QColor(15, 15, 30))
        bg.setColorAt(0.5, QColor(18, 18, 35))
        bg.setColorAt(1.0, QColor(12, 12, 25))
        p.setBrush(QBrush(bg))
        p.setPen(QPen(QColor(60, 80, 120), 2))
        p.drawRoundedRect(1, 1, w - 2, h - 2, 12, 12)

        # ── Subtle glow at top ──
        glow = QRadialGradient(w / 2, 0, w * 0.6)
        glow.setColorAt(0.0, QColor(79, 195, 247, 30))
        glow.setColorAt(1.0, QColor(79, 195, 247, 0))
        p.setBrush(QBrush(glow))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawRect(0, 0, w, h // 3)

        # ── Logo / Title ──
        p.setPen(QColor(79, 195, 247))
        p.setFont(QFont("Segoe UI", 28, QFont.Weight.Bold))
        p.drawText(QRect(0, 30, w, 45), Qt.AlignmentFlag.AlignCenter,
                   "🎵 Py_DAW")

        p.setPen(QColor(180, 180, 200))
        p.setFont(QFont("Segoe UI", 11))
        p.drawText(QRect(0, 75, w, 20), Qt.AlignmentFlag.AlignCenter,
                   "ChronoScaleStudio")

        p.setPen(QColor(100, 100, 130))
        p.setFont(QFont("Consolas", 9))
        p.drawText(QRect(0, 95, w, 16), Qt.AlignmentFlag.AlignCenter,
                   f"v{self._version}")

        # ── Progress bar ──
        bar_x, bar_y = 40, 125
        bar_w, bar_h = w - 80, 22
        r = 6

        # Bar background
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(25, 25, 40))
        p.drawRoundedRect(bar_x, bar_y, bar_w, bar_h, r, r)

        # Bar border
        p.setPen(QPen(QColor(50, 60, 80), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(bar_x, bar_y, bar_w, bar_h, r, r)

        # Bar fill
        fill_w = int(bar_w * self._progress)
        if fill_w > 3:
            grad = QLinearGradient(bar_x, bar_y, bar_x + fill_w, bar_y)
            grad.setColorAt(0.0, QColor(40, 120, 200))
            grad.setColorAt(0.5, QColor(79, 195, 247))
            grad.setColorAt(1.0, QColor(100, 220, 160))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(grad))
            p.drawRoundedRect(bar_x + 1, bar_y + 1,
                              fill_w - 2, bar_h - 2, r - 1, r - 1)

            # Pulse shine
            if self._active:
                px = int(self._pulse_offset * fill_w) - 50
                if 0 <= px < fill_w:
                    shine = QLinearGradient(bar_x + px, 0,
                                            bar_x + px + 100, 0)
                    shine.setColorAt(0.0, QColor(255, 255, 255, 0))
                    shine.setColorAt(0.5, QColor(255, 255, 255, 45))
                    shine.setColorAt(1.0, QColor(255, 255, 255, 0))
                    p.setBrush(QBrush(shine))
                    p.drawRoundedRect(bar_x + 1, bar_y + 1,
                                      fill_w - 2, bar_h - 2, r - 1, r - 1)

        # Percentage text
        pct = int(self._progress * 100)
        p.setPen(QColor(220, 220, 240))
        p.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        p.drawText(QRect(bar_x, bar_y, bar_w, bar_h),
                   Qt.AlignmentFlag.AlignCenter, f"{pct}%")

        # ── Current status ──
        p.setPen(QColor(160, 200, 240))
        p.setFont(QFont("Segoe UI", 10))
        p.drawText(QRect(bar_x, bar_y + bar_h + 6, bar_w, 20),
                   Qt.AlignmentFlag.AlignCenter, self._status)

        # ── Step log ──
        log_y = bar_y + bar_h + 32
        p.setFont(QFont("Segoe UI", 9))

        for i, (icon, text, elapsed) in enumerate(self._steps):
            y = log_y + i * 18
            if y + 18 > h - 30:
                break

            # Icon
            p.setPen(QColor(100, 180, 220))
            p.drawText(bar_x, y + 13, icon)

            # Text
            is_latest = (i == len(self._steps) - 1)
            color = QColor(180, 200, 220) if is_latest else QColor(100, 110, 130)
            p.setPen(color)
            p.drawText(bar_x + 22, y + 13, text)

            # Time
            p.setPen(QColor(80, 90, 110))
            p.setFont(QFont("Consolas", 8))
            p.drawText(QRect(0, y, w - bar_x, 18),
                       Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                       f"{elapsed:.1f}s")
            p.setFont(QFont("Segoe UI", 9))

        # ── Bottom credits ──
        p.setPen(QColor(60, 65, 80))
        p.setFont(QFont("Segoe UI", 8))
        p.drawText(QRect(0, h - 25, w, 20),
                   Qt.AlignmentFlag.AlignCenter,
                   "Open Source DAW + Video-Editor + KI")

        p.end()
