"""video_ki_progress.py — KI Progress Dialog for Video-KI Operations (v0.0.20.953).

A unique loading dialog that shows live information during KI operations:
  - Animated progress bar with gradient pulse
  - Current scene preview (color swatch from dominant color)
  - Live log: what's being created (track name, BPM, key, notes)
  - Stats: scenes done, tracks created, MIDI notes generated
  - Estimated time remaining

What NO other DAW has:
  - A KI loading bar that shows what the AI is "thinking"
  - Live scene color preview during batch processing
  - Musical info (BPM, key, mode) for each generated track

Usage:
    dlg = KIProgressDialog(parent, total=56, title="Szenen vertonen")
    dlg.show()
    dlg.update_scene(idx, scene_name, color, bpm, key, notes_count)
    dlg.finish()
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from PyQt6.QtCore import (
    Qt, pyqtSignal, QTimer, QThread, QSize, QRect, QPointF,
)
from PyQt6.QtGui import (
    QColor, QFont, QPainter, QPen, QBrush, QLinearGradient,
    QPaintEvent, QCloseEvent,
)
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QWidget, QSizePolicy, QScrollArea, QFrame, QApplication,
)

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Animated KI Progress Bar Widget
# ═══════════════════════════════════════════════════════════════

class KIProgressBar(QWidget):
    """Custom animated progress bar with gradient pulse and scene color."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(32)
        self.setMinimumWidth(300)
        self._progress = 0.0       # 0.0–1.0
        self._scene_color = QColor(79, 195, 247)  # default accent
        self._pulse_offset = 0.0
        self._active = True

        # Pulse animation
        self._pulse_timer = QTimer(self)
        self._pulse_timer.setInterval(30)
        self._pulse_timer.timeout.connect(self._on_pulse)
        self._pulse_timer.start()

    def set_progress(self, value: float) -> None:
        self._progress = max(0.0, min(1.0, value))
        self.update()

    def set_scene_color(self, r: int, g: int, b: int) -> None:
        self._scene_color = QColor(r, g, b)
        self.update()

    def set_active(self, active: bool) -> None:
        self._active = active
        if active:
            self._pulse_timer.start()
        else:
            self._pulse_timer.stop()
        self.update()

    def _on_pulse(self) -> None:
        self._pulse_offset += 0.03
        if self._pulse_offset > 2.0:
            self._pulse_offset = 0.0
        self.update()

    def paintEvent(self, event: QPaintEvent) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        r = 8  # corner radius

        # Background
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(20, 20, 35))
        p.drawRoundedRect(0, 0, w, h, r, r)

        # Border
        p.setPen(QPen(QColor(60, 60, 80), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(0, 0, w, h, r, r)

        # Progress fill
        fill_w = int(w * self._progress)
        if fill_w > 2:
            # Gradient from scene color to accent
            grad = QLinearGradient(0, 0, fill_w, 0)
            sc = self._scene_color
            grad.setColorAt(0.0, QColor(sc.red(), sc.green(), sc.blue(), 200))
            grad.setColorAt(0.7, QColor(79, 195, 247, 220))
            grad.setColorAt(1.0, QColor(100, 220, 140, 240))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(grad))
            p.drawRoundedRect(1, 1, fill_w - 2, h - 2, r - 1, r - 1)

            # Animated pulse shine
            if self._active:
                pulse_x = int(self._pulse_offset * fill_w) - 40
                if 0 <= pulse_x < fill_w:
                    shine = QLinearGradient(pulse_x, 0, pulse_x + 80, 0)
                    shine.setColorAt(0.0, QColor(255, 255, 255, 0))
                    shine.setColorAt(0.5, QColor(255, 255, 255, 60))
                    shine.setColorAt(1.0, QColor(255, 255, 255, 0))
                    p.setBrush(QBrush(shine))
                    p.drawRoundedRect(1, 1, fill_w - 2, h - 2, r - 1, r - 1)

        # Text overlay
        p.setPen(QColor(255, 255, 255, 220))
        p.setFont(QFont("Consolas", 10, QFont.Weight.Bold))
        pct = int(self._progress * 100)
        p.drawText(QRect(0, 0, w, h), Qt.AlignmentFlag.AlignCenter,
                   f"{pct}%")

        p.end()


# ═══════════════════════════════════════════════════════════════
# Scene Color Swatch
# ═══════════════════════════════════════════════════════════════

class SceneColorSwatch(QWidget):
    """Small color swatch showing the current scene's dominant color."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(48, 48)
        self._color = QColor(40, 40, 60)
        self._scene_idx = 0

    def set_color(self, r: int, g: int, b: int, idx: int = 0) -> None:
        self._color = QColor(r, g, b)
        self._scene_idx = idx
        self.update()

    def paintEvent(self, event: QPaintEvent) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        s = min(self.width(), self.height()) - 4

        # Color circle
        p.setPen(QPen(QColor(100, 100, 120), 2))
        p.setBrush(self._color)
        p.drawEllipse(2, 2, s, s)

        # Scene number
        p.setPen(QColor(255, 255, 255, 200))
        p.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        p.drawText(QRect(2, 2, s, s), Qt.AlignmentFlag.AlignCenter,
                   str(self._scene_idx + 1))
        p.end()


# ═══════════════════════════════════════════════════════════════
# Live Log Entry
# ═══════════════════════════════════════════════════════════════

class _LogEntry(QFrame):
    """A single log entry in the live log."""

    def __init__(self, text: str, color: str = "#c0c0c0",
                 icon: str = "🎵", parent=None):
        super().__init__(parent)
        self.setStyleSheet(
            "QFrame { background: transparent; border: none; }")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(4, 1, 4, 1)
        lay.setSpacing(6)

        lbl_icon = QLabel(icon)
        lbl_icon.setFixedWidth(18)
        lbl_icon.setStyleSheet("font-size: 11px;")
        lay.addWidget(lbl_icon)

        lbl_text = QLabel(text)
        lbl_text.setStyleSheet(
            f"color: {color}; font-size: 11px; font-family: 'Segoe UI';")
        lbl_text.setWordWrap(True)
        lay.addWidget(lbl_text, 1)


# ═══════════════════════════════════════════════════════════════
# KI Progress Dialog
# ═══════════════════════════════════════════════════════════════

class KIProgressDialog(QDialog):
    """KI Progress Dialog with animated bar, scene preview, and live log.
    
    Signals:
        cancelled: Emitted when user cancels the operation
    """

    cancelled = pyqtSignal()

    def __init__(self, parent=None, total: int = 1,
                 title: str = "🧠 KI verarbeitet..."):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumSize(520, 420)
        self.setMaximumWidth(600)
        self.setStyleSheet(
            "QDialog { background: #12121e; }"
            "QLabel { color: #d0d0d8; }")
        self.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowStaysOnTopHint)

        self._total = max(1, total)
        self._current = 0
        self._start_time = time.time()
        self._cancelled = False
        self._tracks_created = 0
        self._total_notes = 0
        self._log_entries: List[_LogEntry] = []
        # v0.0.20.980: Store title for customizable completion messages
        self._custom_title = title

        self._build_ui()

    def _build_ui(self) -> None:
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 16, 16, 16)
        lay.setSpacing(10)

        # ── Header ──
        hdr = QHBoxLayout()
        self._lbl_title = QLabel(self._custom_title or "🧠 KI-Vertoner")
        self._lbl_title.setStyleSheet(
            "font-size: 16px; font-weight: bold; color: #4FC3F7;")
        hdr.addWidget(self._lbl_title)
        hdr.addStretch(1)

        self._lbl_count = QLabel(f"0 / {self._total}")
        self._lbl_count.setStyleSheet(
            "font-size: 14px; font-weight: bold; color: #66BB6A; "
            "font-family: Consolas;")
        hdr.addWidget(self._lbl_count)
        lay.addLayout(hdr)

        # ── Progress bar ──
        self._progress_bar = KIProgressBar()
        lay.addWidget(self._progress_bar)

        # ── Current scene info ──
        info_row = QHBoxLayout()
        info_row.setSpacing(10)

        self._swatch = SceneColorSwatch()
        info_row.addWidget(self._swatch)

        info_text = QVBoxLayout()
        info_text.setSpacing(2)

        self._lbl_scene_name = QLabel("Bereit...")
        self._lbl_scene_name.setStyleSheet(
            "font-size: 13px; font-weight: bold; color: #e0e0e0;")
        info_text.addWidget(self._lbl_scene_name)

        self._lbl_scene_detail = QLabel("")
        self._lbl_scene_detail.setStyleSheet(
            "font-size: 11px; color: #aaaaaa;")
        info_text.addWidget(self._lbl_scene_detail)

        self._lbl_time = QLabel("")
        self._lbl_time.setStyleSheet(
            "font-size: 10px; color: #888888;")
        info_text.addWidget(self._lbl_time)

        info_row.addLayout(info_text, 1)
        lay.addLayout(info_row)

        # ── Stats row ──
        stats = QHBoxLayout()
        stats.setSpacing(16)

        self._stat_tracks = self._make_stat("🎹", "0", "Tracks")
        self._stat_notes = self._make_stat("🎵", "0", "MIDI-Noten")
        self._stat_time = self._make_stat("⏱", "0s", "Dauer")

        stats.addWidget(self._stat_tracks)
        stats.addWidget(self._stat_notes)
        stats.addWidget(self._stat_time)
        stats.addStretch(1)
        lay.addLayout(stats)

        # ── Separator ──
        sep = QFrame()
        sep.setFixedHeight(1)
        sep.setStyleSheet("background: #333;")
        lay.addWidget(sep)

        # ── Live log (scrollable) ──
        lbl_log = QLabel("📋 Live-Protokoll")
        lbl_log.setStyleSheet(
            "font-size: 11px; font-weight: bold; color: #888;")
        lay.addWidget(lbl_log)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet(
            "QScrollArea { background: #0a0a14; border: 1px solid #333; "
            "border-radius: 4px; }"
            "QScrollBar:vertical { width: 6px; background: #1a1a2a; }"
            "QScrollBar::handle:vertical { background: #444; border-radius: 3px; }"
        )
        self._log_container = QWidget()
        self._log_layout = QVBoxLayout(self._log_container)
        self._log_layout.setContentsMargins(4, 4, 4, 4)
        self._log_layout.setSpacing(2)
        self._log_layout.addStretch(1)
        scroll.setWidget(self._log_container)
        lay.addWidget(scroll, 1)

        # ── Bottom buttons ──
        btn_row = QHBoxLayout()
        btn_row.addStretch(1)

        self._btn_cancel = QPushButton("❌ Abbrechen")
        self._btn_cancel.setFixedHeight(28)
        self._btn_cancel.setStyleSheet(
            "QPushButton { background: #3a2a2a; border: 1px solid #6a4a4a; "
            "border-radius: 4px; color: #ffaaaa; font-size: 11px; "
            "padding: 0 16px; }"
            "QPushButton:hover { background: #4a3a3a; }")
        self._btn_cancel.clicked.connect(self._on_cancel)
        btn_row.addWidget(self._btn_cancel)

        self._btn_close = QPushButton("✅ Fertig")
        self._btn_close.setFixedHeight(28)
        self._btn_close.setEnabled(False)
        self._btn_close.setStyleSheet(
            "QPushButton { background: #2a3a2a; border: 1px solid #4a8a6a; "
            "border-radius: 4px; color: #aaffcc; font-size: 11px; "
            "padding: 0 16px; }"
            "QPushButton:hover { background: #3a4a3a; }"
            "QPushButton:disabled { color: #555; border-color: #333; }")
        self._btn_close.clicked.connect(self.accept)
        btn_row.addWidget(self._btn_close)

        lay.addLayout(btn_row)

    def _make_stat(self, icon: str, value: str,
                    label: str) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)

        lbl_icon = QLabel(f"{icon} {value}")
        lbl_icon.setStyleSheet(
            "font-size: 16px; font-weight: bold; color: #e0e0e0; "
            "font-family: Consolas;")
        lbl_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(lbl_icon)

        lbl_name = QLabel(label)
        lbl_name.setStyleSheet("font-size: 9px; color: #888;")
        lbl_name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(lbl_name)

        w._value_label = lbl_icon
        w._icon = icon
        return w

    # ── Public API ──

    @property
    def is_cancelled(self) -> bool:
        return self._cancelled

    def update_scene(self, index: int, scene_name: str,
                      color_rgb: tuple = (79, 195, 247),
                      bpm: int = 120, key: str = "C",
                      mode: str = "minor", notes_count: int = 0,
                      preset_name: str = "",
                      beat_pos: float = 0.0,
                      length_beats: float = 0.0) -> None:
        """Update the dialog with current scene being processed."""
        self._current = index + 1
        self._tracks_created += 1
        self._total_notes += notes_count

        # Progress
        progress = self._current / self._total
        self._progress_bar.set_progress(progress)
        self._progress_bar.set_scene_color(*color_rgb)

        # Count
        self._lbl_count.setText(f"{self._current} / {self._total}")

        # Scene info
        self._swatch.set_color(*color_rgb, index)
        self._lbl_scene_name.setText(
            f"Szene {index + 1}: {preset_name or scene_name}")
        self._lbl_scene_detail.setText(
            f"{bpm} BPM, {key} {mode} | {notes_count} Noten | "
            f"Beat {beat_pos:.1f} ({length_beats:.1f} Beats)")

        # Time estimate
        elapsed = time.time() - self._start_time
        if self._current > 0:
            per_scene = elapsed / self._current
            remaining = per_scene * (self._total - self._current)
            self._lbl_time.setText(
                f"⏱ {elapsed:.1f}s vergangen | "
                f"~{remaining:.0f}s verbleibend")
        
        # Stats
        self._stat_tracks._value_label.setText(
            f"{self._stat_tracks._icon} {self._tracks_created}")
        self._stat_notes._value_label.setText(
            f"{self._stat_notes._icon} {self._total_notes}")
        self._stat_time._value_label.setText(
            f"{self._stat_time._icon} {elapsed:.1f}s")

        # Log entry
        r, g, b = color_rgb
        color_hex = f"#{r:02x}{g:02x}{b:02x}"
        log_text = (f"Szene {index + 1}: {preset_name} "
                    f"[{key}{mode[0].upper()}] {bpm} BPM — "
                    f"{notes_count} Noten @ Beat {beat_pos:.1f}")
        entry = _LogEntry(log_text, color="#b0c8d0", icon="🎬")
        self._log_entries.append(entry)
        # Insert before the stretch
        self._log_layout.insertWidget(
            self._log_layout.count() - 1, entry)

        # Auto-scroll to bottom
        scroll = self._log_container.parentWidget()
        if hasattr(scroll, 'verticalScrollBar'):
            QTimer.singleShot(10, lambda: scroll.verticalScrollBar().setValue(
                scroll.verticalScrollBar().maximum()))

        # Process events to keep UI responsive
        QApplication.processEvents()

    def add_log(self, text: str, icon: str = "ℹ",
                color: str = "#aaaaaa") -> None:
        """Add a custom log entry."""
        entry = _LogEntry(text, color=color, icon=icon)
        self._log_entries.append(entry)
        self._log_layout.insertWidget(
            self._log_layout.count() - 1, entry)
        QApplication.processEvents()

    def finish(self) -> None:
        """Mark operation as complete."""
        elapsed = time.time() - self._start_time
        self._progress_bar.set_progress(1.0)
        self._progress_bar.set_active(False)

        self._lbl_title.setText(f"✅ {self._custom_title or 'KI-Vertoner'} — Fertig!")
        self._lbl_title.setStyleSheet(
            "font-size: 16px; font-weight: bold; color: #66BB6A;")
        # v0.0.20.980: Use context-aware completion message
        if "Plugin" in (self._custom_title or ""):
            self._lbl_scene_name.setText("Alle Plugins gescannt!")
        else:
            self._lbl_scene_name.setText("Alle Szenen vertont!")
        self._lbl_scene_detail.setText(
            f"{self._tracks_created} Tracks, "
            f"{self._total_notes} MIDI-Noten in {elapsed:.1f}s")
        self._lbl_time.setText(
            f"✅ Fertig in {elapsed:.1f}s")

        self._stat_time._value_label.setText(
            f"{self._stat_time._icon} {elapsed:.1f}s")

        # Final log
        self.add_log(
            f"Fertig: {self._tracks_created} Tracks, "
            f"{self._total_notes} Noten, {elapsed:.1f}s",
            icon="✅", color="#66BB6A")

        self._btn_cancel.setEnabled(False)
        self._btn_close.setEnabled(True)

        QApplication.processEvents()

    def finish_cancelled(self) -> None:
        """Mark operation as cancelled."""
        elapsed = time.time() - self._start_time
        self._progress_bar.set_active(False)

        self._lbl_title.setText("⚠ Abgebrochen")
        self._lbl_title.setStyleSheet(
            "font-size: 16px; font-weight: bold; color: #FFA726;")
        self._lbl_scene_name.setText(
            f"{self._current} von {self._total} Szenen verarbeitet")

        self.add_log(
            f"Abgebrochen nach {self._current} Szenen ({elapsed:.1f}s)",
            icon="⚠", color="#FFA726")

        self._btn_cancel.setEnabled(False)
        self._btn_close.setEnabled(True)

    def _on_cancel(self) -> None:
        self._cancelled = True
        self.cancelled.emit()
        self._btn_cancel.setText("⏳ Wird abgebrochen...")
        self._btn_cancel.setEnabled(False)

    def closeEvent(self, event: QCloseEvent) -> None:
        if self._btn_close.isEnabled():
            event.accept()
        else:
            self._on_cancel()
            event.ignore()
