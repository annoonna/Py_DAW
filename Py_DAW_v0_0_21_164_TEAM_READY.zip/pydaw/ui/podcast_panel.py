"""podcast_panel.py — Podcast-Modus Panel (v0.0.20.917).

Full podcast production workflow panel:
- Speech-EQ Presets → automatically apply chrono.fx.eq5 on active track
- Chapter markers → add/remove/edit/export (Spotify, MP4, Podlove)
- Silence detection → detect + show results + trim action
- Simplified layout toggle

Usage:
    panel = PodcastPanel(services=self.services, parent=self)
    dock = QDockWidget("🎙 Podcast", self)
    dock.setWidget(panel)
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, List, Optional

from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QListWidget, QListWidgetItem, QGroupBox,
    QSpinBox, QDoubleSpinBox, QLineEdit, QTextEdit,
    QMessageBox, QFileDialog, QSplitter, QScrollArea,
    QSizePolicy, QFrame,
)

log = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════
# EQ Preset → chrono.fx.eq5 parameter mapping
# ══════════════════════════════════════════════════════════════

def _speech_preset_to_eq5_params(preset) -> Dict[str, Any]:
    """Convert a SpeechEqPreset to chrono.fx.eq5 device params.

    Maps the semantic speech-EQ fields to the 5-band parametric EQ:
      Band 0: High-pass filter (low-cut)
      Band 1: Low-shelf (warmth control)
      Band 2: Presence boost (intelligibility)
      Band 3: De-ess reduction
      Band 4: Air / high-shelf
    """
    return {
        # Band 0: High-pass (type 4 = high-pass/low-cut)
        "b0_g10": 0,
        "b0_f": preset.high_pass_freq,
        "b0_q": preset.high_pass_q,
        # Band 1: Low shelf (warmth)
        "b1_g10": int(preset.low_shelf_gain_db * 10),
        "b1_f": preset.low_shelf_freq,
        "b1_q": 0.71,
        # Band 2: Presence peak
        "b2_g10": int(preset.presence_gain_db * 10),
        "b2_f": preset.presence_freq,
        "b2_q": preset.presence_q,
        # Band 3: De-ess
        "b3_g10": int(preset.de_ess_reduction_db * 10),
        "b3_f": preset.de_ess_freq,
        "b3_q": 2.0,
        # Band 4: Air
        "b4_g10": int(preset.air_gain_db * 10),
        "b4_f": preset.air_freq,
        "b4_q": 0.71,
        # Globals
        "amount": 100,
        "shift": 0,
        "output10": 0,
    }


# ══════════════════════════════════════════════════════════════
# Podcast Panel Widget
# ══════════════════════════════════════════════════════════════

class PodcastPanel(QWidget):
    """Full podcast production panel (v0.0.20.917).

    Sections:
    1. Speech-EQ: Preset selector + Apply button
    2. Chapters: List + Add/Remove/Export
    3. Silence Detection: Detect + Results + Trim
    """

    status = pyqtSignal(str)

    def __init__(self, services=None, parent=None):
        super().__init__(parent)
        self._services = services
        self._podcast_service = None
        self._silence_regions: List[Any] = []

        self._init_service()
        self._build_ui()

    def _init_service(self) -> None:
        try:
            from pydaw.services.podcast_mode import PodcastModeService
            self._podcast_service = PodcastModeService(parent=self)
        except Exception as e:
            log.warning("[PodcastPanel] Service init failed: %s", e)

    # ──────────────────────────────────────────────────────────
    # UI Build
    # ──────────────────────────────────────────────────────────

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(8)

        # Title
        title = QLabel("🎙 Podcast-Modus")
        title.setStyleSheet("font-size: 14px; font-weight: bold; color: #e0e0e0;")
        root.addWidget(title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        content = QWidget()
        content_lay = QVBoxLayout(content)
        content_lay.setContentsMargins(0, 0, 0, 0)
        content_lay.setSpacing(10)

        # ── Section 1: Speech-EQ ──
        self._build_eq_section(content_lay)

        # ── Section 2: Chapter Markers ──
        self._build_chapter_section(content_lay)

        # ── Section 3: Silence Detection ──
        self._build_silence_section(content_lay)

        content_lay.addStretch(1)

        # ── Section 4: Vereinfachtes Layout (PO5) ──
        self._build_layout_section(content_lay)

        # ── Section 5: Streaming (PO6) ──
        self._build_streaming_section(content_lay)

        content_lay.addStretch(1)
        scroll.setWidget(content)
        root.addWidget(scroll, 1)

    def _build_eq_section(self, parent_lay) -> None:
        grp = QGroupBox("🎛 Speech-EQ")
        grp.setStyleSheet(
            "QGroupBox { font-weight: bold; color: #c8c8d4; border: 1px solid #444; "
            "border-radius: 6px; margin-top: 8px; padding-top: 16px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }"
        )
        lay = QVBoxLayout(grp)
        lay.setSpacing(6)

        # Preset selector
        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Preset:"))
        self._cmb_eq_preset = QComboBox()
        try:
            from pydaw.services.podcast_mode import SPEECH_EQ_PRESETS
            for key, preset in SPEECH_EQ_PRESETS.items():
                self._cmb_eq_preset.addItem(preset.name, key)
        except Exception:
            self._cmb_eq_preset.addItem("Podcast Standard", "podcast_standard")
        row1.addWidget(self._cmb_eq_preset, 1)
        lay.addLayout(row1)

        # Description
        self._lbl_eq_desc = QLabel("")
        self._lbl_eq_desc.setStyleSheet("color: #9aa0a6; font-size: 11px;")
        self._lbl_eq_desc.setWordWrap(True)
        lay.addWidget(self._lbl_eq_desc)
        self._cmb_eq_preset.currentIndexChanged.connect(self._on_eq_preset_changed)
        self._on_eq_preset_changed()  # initial

        # Apply button
        row2 = QHBoxLayout()
        self._btn_apply_eq = QPushButton("✅ EQ auf aktive Spur anwenden")
        self._btn_apply_eq.setStyleSheet(
            "QPushButton { background: #2a3a2a; border: 1px solid #4a804a; "
            "border-radius: 4px; color: #90d490; font-size: 12px; padding: 6px 12px; }"
            "QPushButton:hover { background: #3a4a3a; }"
        )
        self._btn_apply_eq.clicked.connect(self._apply_eq_to_track)
        row2.addWidget(self._btn_apply_eq)

        self._btn_remove_eq = QPushButton("🗑 Speech-EQ entfernen")
        self._btn_remove_eq.setStyleSheet(
            "QPushButton { background: #3a2a2a; border: 1px solid #804a4a; "
            "border-radius: 4px; color: #d49090; font-size: 11px; padding: 4px 8px; }"
            "QPushButton:hover { background: #4a3a3a; }"
        )
        self._btn_remove_eq.clicked.connect(self._remove_eq_from_track)
        row2.addWidget(self._btn_remove_eq)
        lay.addLayout(row2)

        self._lbl_eq_status = QLabel("")
        self._lbl_eq_status.setStyleSheet("color: #7bd389; font-size: 11px;")
        lay.addWidget(self._lbl_eq_status)

        parent_lay.addWidget(grp)

    def _build_chapter_section(self, parent_lay) -> None:
        grp = QGroupBox("📑 Kapitel-Marker")
        grp.setStyleSheet(
            "QGroupBox { font-weight: bold; color: #c8c8d4; border: 1px solid #444; "
            "border-radius: 6px; margin-top: 8px; padding-top: 16px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }"
        )
        lay = QVBoxLayout(grp)
        lay.setSpacing(6)

        # Chapter list
        self._lst_chapters = QListWidget()
        self._lst_chapters.setMaximumHeight(150)
        self._lst_chapters.setStyleSheet(
            "QListWidget { background: #1a1a2e; color: #d0d0d8; border: 1px solid #333; }"
        )
        lay.addWidget(self._lst_chapters)

        # Add chapter controls
        add_row = QHBoxLayout()
        add_row.addWidget(QLabel("Titel:"))
        self._txt_chapter_title = QLineEdit()
        self._txt_chapter_title.setPlaceholderText("z.B. Einleitung, Interview, Outro")
        add_row.addWidget(self._txt_chapter_title, 1)

        add_row.addWidget(QLabel("Min:"))
        self._spn_chapter_min = QSpinBox()
        self._spn_chapter_min.setRange(0, 999)
        self._spn_chapter_min.setFixedWidth(50)
        add_row.addWidget(self._spn_chapter_min)

        add_row.addWidget(QLabel("Sek:"))
        self._spn_chapter_sec = QSpinBox()
        self._spn_chapter_sec.setRange(0, 59)
        self._spn_chapter_sec.setFixedWidth(50)
        add_row.addWidget(self._spn_chapter_sec)
        lay.addLayout(add_row)

        # Buttons
        btn_row = QHBoxLayout()
        btn_add = QPushButton("➕ Hinzufügen")
        btn_add.clicked.connect(self._add_chapter)
        btn_row.addWidget(btn_add)

        btn_remove = QPushButton("➖ Entfernen")
        btn_remove.clicked.connect(self._remove_chapter)
        btn_row.addWidget(btn_remove)

        btn_row.addStretch(1)

        self._cmb_export_fmt = QComboBox()
        self._cmb_export_fmt.addItems(["Spotify JSON", "MP4 FFMETADATA", "Podlove XML"])
        btn_row.addWidget(self._cmb_export_fmt)

        btn_export = QPushButton("💾 Exportieren")
        btn_export.clicked.connect(self._export_chapters)
        btn_row.addWidget(btn_export)
        lay.addLayout(btn_row)

        # Use current playhead as timestamp
        btn_playhead = QPushButton("⏱ Aktuelle Position als Startzeit")
        btn_playhead.setStyleSheet("font-size: 11px; padding: 3px 8px;")
        btn_playhead.clicked.connect(self._chapter_from_playhead)
        lay.addWidget(btn_playhead)

        parent_lay.addWidget(grp)

    def _build_silence_section(self, parent_lay) -> None:
        grp = QGroupBox("🔇 Stille-Erkennung")
        grp.setStyleSheet(
            "QGroupBox { font-weight: bold; color: #c8c8d4; border: 1px solid #444; "
            "border-radius: 6px; margin-top: 8px; padding-top: 16px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }"
        )
        lay = QVBoxLayout(grp)
        lay.setSpacing(6)

        # Settings
        set_row = QHBoxLayout()
        set_row.addWidget(QLabel("Schwelle:"))
        self._spn_silence_db = QSpinBox()
        self._spn_silence_db.setRange(-80, -10)
        self._spn_silence_db.setValue(-40)
        self._spn_silence_db.setSuffix(" dB")
        self._spn_silence_db.setFixedWidth(80)
        set_row.addWidget(self._spn_silence_db)

        set_row.addWidget(QLabel("Min. Dauer:"))
        self._spn_silence_dur = QSpinBox()
        self._spn_silence_dur.setRange(100, 10000)
        self._spn_silence_dur.setValue(500)
        self._spn_silence_dur.setSuffix(" ms")
        self._spn_silence_dur.setFixedWidth(90)
        set_row.addWidget(self._spn_silence_dur)
        set_row.addStretch(1)
        lay.addLayout(set_row)

        # Detect button
        btn_row = QHBoxLayout()
        self._btn_detect = QPushButton("🔍 Stille erkennen")
        self._btn_detect.setStyleSheet(
            "QPushButton { background: #2a2a3a; border: 1px solid #5555aa; "
            "border-radius: 4px; color: #a0a0d4; font-size: 12px; padding: 6px 12px; }"
            "QPushButton:hover { background: #3a3a4a; }"
        )
        self._btn_detect.clicked.connect(self._detect_silence)
        btn_row.addWidget(self._btn_detect)

        self._btn_trim = QPushButton("✂ Stille trimmen")
        self._btn_trim.setEnabled(False)
        self._btn_trim.setStyleSheet(
            "QPushButton { background: #3a2a1a; border: 1px solid #aa8844; "
            "border-radius: 4px; color: #d4b070; font-size: 11px; padding: 4px 8px; }"
            "QPushButton:hover { background: #4a3a2a; }"
            "QPushButton:disabled { color: #666; border-color: #444; }"
        )
        self._btn_trim.clicked.connect(self._trim_silence)
        btn_row.addWidget(self._btn_trim)
        btn_row.addStretch(1)
        lay.addLayout(btn_row)

        # Results list
        self._lst_silence = QListWidget()
        self._lst_silence.setMaximumHeight(120)
        self._lst_silence.setStyleSheet(
            "QListWidget { background: #1a1a2e; color: #d0d0d8; border: 1px solid #333; }"
        )
        lay.addWidget(self._lst_silence)

        self._lbl_silence_status = QLabel("")
        self._lbl_silence_status.setStyleSheet("color: #9aa0a6; font-size: 11px;")
        lay.addWidget(self._lbl_silence_status)

        parent_lay.addWidget(grp)

    # ──────────────────────────────────────────────────────────
    # EQ Preset Logic
    # ──────────────────────────────────────────────────────────

    def _on_eq_preset_changed(self) -> None:
        try:
            from pydaw.services.podcast_mode import SPEECH_EQ_PRESETS
            key = self._cmb_eq_preset.currentData()
            preset = SPEECH_EQ_PRESETS.get(key)
            if preset:
                self._lbl_eq_desc.setText(preset.description)
        except Exception:
            pass

    def _get_active_track_id(self) -> str:
        """Get the currently selected track ID from project_service."""
        try:
            ps = getattr(self._services, 'project', None) if self._services else None
            if ps is None:
                ps = getattr(self._services, 'project_service', None) if self._services else None
            if ps is None:
                return ""
            tid = getattr(ps, '_selected_track_id', '') or ''
            if not tid:
                # Fallback: first non-master track
                proj = getattr(ps, 'project', None)
                if proj is None:
                    ctx = getattr(ps, 'ctx', None)
                    proj = getattr(ctx, 'project', None) if ctx else None
                if proj:
                    for t in getattr(proj, 'tracks', []) or []:
                        if getattr(t, 'kind', '') != 'master':
                            return str(t.id)
            return tid
        except Exception:
            return ""

    def _get_device_panel(self):
        """Get the DevicePanel from the parent main window."""
        try:
            mw = self.window()
            return getattr(mw, '_device_panel', None) or getattr(mw, 'device_panel', None)
        except Exception:
            return None

    def _apply_eq_to_track(self) -> None:
        """PO2: Apply the selected Speech-EQ preset to the active track as chrono.fx.eq5."""
        try:
            from pydaw.services.podcast_mode import SPEECH_EQ_PRESETS

            preset_key = self._cmb_eq_preset.currentData()
            preset = SPEECH_EQ_PRESETS.get(preset_key)
            if not preset:
                self._lbl_eq_status.setText("❌ Preset nicht gefunden")
                self._lbl_eq_status.setStyleSheet("color: #d49090; font-size: 11px;")
                return

            track_id = self._get_active_track_id()
            if not track_id:
                self._lbl_eq_status.setText("❌ Keine Spur ausgewählt")
                self._lbl_eq_status.setStyleSheet("color: #d49090; font-size: 11px;")
                return

            # Get EQ params
            eq_params = _speech_preset_to_eq5_params(preset)

            # Find or create chrono.fx.eq5 on this track
            dp = self._get_device_panel()
            ps = getattr(self._services, 'project', None) if self._services else None
            if ps is None:
                ps = getattr(self._services, 'project_service', None) if self._services else None

            proj = None
            if ps:
                proj = getattr(ps, 'project', None)
                if proj is None:
                    ctx = getattr(ps, 'ctx', None)
                    proj = getattr(ctx, 'project', None) if ctx else None

            if not proj:
                self._lbl_eq_status.setText("❌ Kein Projekt geladen")
                self._lbl_eq_status.setStyleSheet("color: #d49090; font-size: 11px;")
                return

            # Find track
            trk = None
            for t in getattr(proj, 'tracks', []) or []:
                if str(getattr(t, 'id', '')) == track_id:
                    trk = t
                    break
            if not trk:
                self._lbl_eq_status.setText(f"❌ Track {track_id[:8]} nicht gefunden")
                self._lbl_eq_status.setStyleSheet("color: #d49090; font-size: 11px;")
                return

            # Get or create audio_fx_chain
            chain = getattr(trk, 'audio_fx_chain', None)
            if not isinstance(chain, dict):
                trk.audio_fx_chain = {"type": "chain", "mix": 1.0, "wet_gain": 1.0, "devices": []}
                chain = trk.audio_fx_chain

            devices = chain.get("devices", [])

            # Check if a Speech-EQ (chrono.fx.eq5 with _podcast_eq marker) already exists
            existing_idx = -1
            for i, dev in enumerate(devices):
                if (isinstance(dev, dict)
                        and dev.get("plugin_id") == "chrono.fx.eq5"
                        and dev.get("params", {}).get("_podcast_eq")):
                    existing_idx = i
                    break

            eq_params["_podcast_eq"] = True  # marker so we can find/remove it later

            if existing_idx >= 0:
                # Update existing
                devices[existing_idx]["params"] = eq_params
                devices[existing_idx]["name"] = f"Speech-EQ: {preset.name}"
                action = "aktualisiert"
            else:
                # Insert at position 0 (before other FX)
                from pydaw.model.project import new_id
                dev_entry = {
                    "id": new_id("afx"),
                    "plugin_id": "chrono.fx.eq5",
                    "name": f"Speech-EQ: {preset.name}",
                    "enabled": True,
                    "params": eq_params,
                }
                devices.insert(0, dev_entry)
                action = "hinzugefügt"

            chain["devices"] = devices

            # Trigger UI refresh
            try:
                if dp:
                    dp.show_track(track_id)
                if ps and hasattr(ps, '_emit_changed'):
                    ps._emit_changed()
            except Exception:
                pass

            track_name = getattr(trk, 'name', track_id[:8])
            self._lbl_eq_status.setText(
                f"✅ {preset.name} auf '{track_name}' {action}")
            self._lbl_eq_status.setStyleSheet("color: #7bd389; font-size: 11px;")

            # Persist to DB
            try:
                if self._podcast_service:
                    self._podcast_service.set_eq_preset(preset_key)
            except Exception:
                pass

            log.info("[PodcastPanel] Applied Speech-EQ '%s' to track '%s'",
                     preset.name, track_name)

        except Exception as e:
            self._lbl_eq_status.setText(f"❌ Fehler: {e}")
            self._lbl_eq_status.setStyleSheet("color: #d49090; font-size: 11px;")
            log.error("[PodcastPanel] apply_eq failed: %s", e, exc_info=True)

    def _remove_eq_from_track(self) -> None:
        """Remove the Speech-EQ device from the active track."""
        try:
            track_id = self._get_active_track_id()
            if not track_id:
                return

            ps = getattr(self._services, 'project', None) if self._services else None
            if ps is None:
                ps = getattr(self._services, 'project_service', None) if self._services else None
            proj = None
            if ps:
                proj = getattr(ps, 'project', None)
                if proj is None:
                    ctx = getattr(ps, 'ctx', None)
                    proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                return

            for t in getattr(proj, 'tracks', []) or []:
                if str(getattr(t, 'id', '')) != track_id:
                    continue
                chain = getattr(t, 'audio_fx_chain', None)
                if not isinstance(chain, dict):
                    continue
                devices = chain.get("devices", [])
                new_devices = [
                    d for d in devices
                    if not (isinstance(d, dict)
                            and d.get("plugin_id") == "chrono.fx.eq5"
                            and d.get("params", {}).get("_podcast_eq"))
                ]
                if len(new_devices) < len(devices):
                    chain["devices"] = new_devices
                    dp = self._get_device_panel()
                    if dp:
                        dp.show_track(track_id)
                    if ps and hasattr(ps, '_emit_changed'):
                        ps._emit_changed()
                    self._lbl_eq_status.setText("🗑 Speech-EQ entfernt")
                    self._lbl_eq_status.setStyleSheet("color: #d4b070; font-size: 11px;")
                else:
                    self._lbl_eq_status.setText("ℹ Kein Speech-EQ auf dieser Spur")
                    self._lbl_eq_status.setStyleSheet("color: #9aa0a6; font-size: 11px;")
                break
        except Exception as e:
            log.error("[PodcastPanel] remove_eq failed: %s", e)

    # ──────────────────────────────────────────────────────────
    # Chapter Logic
    # ──────────────────────────────────────────────────────────

    def _add_chapter(self) -> None:
        try:
            title = self._txt_chapter_title.text().strip()
            if not title:
                title = f"Kapitel {self._lst_chapters.count() + 1}"
            minutes = self._spn_chapter_min.value()
            seconds = self._spn_chapter_sec.value()
            start_ms = (minutes * 60 + seconds) * 1000

            if self._podcast_service:
                ch = self._podcast_service.add_chapter(title, start_ms)
                self._refresh_chapter_list()
                self._txt_chapter_title.clear()
                self._spn_chapter_min.setValue(0)
                self._spn_chapter_sec.setValue(0)
        except Exception as e:
            log.error("[PodcastPanel] add_chapter: %s", e)

    def _remove_chapter(self) -> None:
        try:
            row = self._lst_chapters.currentRow()
            if row >= 0 and self._podcast_service:
                self._podcast_service.remove_chapter(row)
                self._refresh_chapter_list()
        except Exception as e:
            log.error("[PodcastPanel] remove_chapter: %s", e)

    def _chapter_from_playhead(self) -> None:
        """Use current transport position as chapter start time."""
        try:
            ps = getattr(self._services, 'project', None) if self._services else None
            if ps is None:
                ps = getattr(self._services, 'project_service', None) if self._services else None
            if not ps:
                return
            proj = getattr(ps, 'project', None)
            if proj is None:
                ctx = getattr(ps, 'ctx', None)
                proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                return

            # Get playhead position in beats, convert to ms
            bpm = float(getattr(proj, 'bpm', 120.0) or 120.0)
            # Try to get current playhead from transport
            ts = getattr(self._services, 'transport', None) if self._services else None
            if ts is None:
                ts = getattr(self._services, 'transport_service', None) if self._services else None
            beat = 0.0
            if ts and hasattr(ts, 'current_beat'):
                beat = float(ts.current_beat)
            elif ts and hasattr(ts, 'playhead_beat'):
                beat = float(ts.playhead_beat)

            ms = int(beat / bpm * 60000)
            minutes = ms // 60000
            seconds = (ms % 60000) // 1000

            self._spn_chapter_min.setValue(minutes)
            self._spn_chapter_sec.setValue(seconds)
        except Exception as e:
            log.debug("[PodcastPanel] chapter_from_playhead: %s", e)

    def _refresh_chapter_list(self) -> None:
        try:
            self._lst_chapters.clear()
            if not self._podcast_service:
                return
            for ch in self._podcast_service.chapters:
                self._lst_chapters.addItem(f"{ch.timecode}  —  {ch.title}")
        except Exception:
            pass

    def _export_chapters(self) -> None:
        try:
            if not self._podcast_service or not self._podcast_service.chapters:
                QMessageBox.information(self, "Export", "Keine Kapitel vorhanden.")
                return

            fmt_idx = self._cmb_export_fmt.currentIndex()
            fmt_map = {0: "spotify", 1: "mp4", 2: "podlove"}
            ext_map = {0: ".json", 1: ".txt", 2: ".xml"}
            fmt = fmt_map.get(fmt_idx, "spotify")
            ext = ext_map.get(fmt_idx, ".json")

            path, _ = QFileDialog.getSaveFileName(
                self, "Kapitel exportieren",
                f"chapters{ext}",
                f"Dateien (*{ext})")
            if not path:
                return

            content = self._podcast_service.export_chapters(fmt)
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)

            QMessageBox.information(self, "Export",
                                    f"✅ {len(self._podcast_service.chapters)} Kapitel "
                                    f"exportiert nach:\n{path}")
        except Exception as e:
            QMessageBox.warning(self, "Export", f"Fehler: {e}")

    # ──────────────────────────────────────────────────────────
    # Silence Detection Logic
    # ──────────────────────────────────────────────────────────

    def _detect_silence(self) -> None:
        """Detect silence in the selected audio clip."""
        try:
            self._lst_silence.clear()
            self._silence_regions = []
            self._btn_trim.setEnabled(False)

            track_id = self._get_active_track_id()
            if not track_id:
                self._lbl_silence_status.setText("Keine Spur ausgewählt")
                return

            ps = getattr(self._services, 'project', None) if self._services else None
            if ps is None:
                ps = getattr(self._services, 'project_service', None) if self._services else None
            proj = None
            if ps:
                proj = getattr(ps, 'project', None)
                if proj is None:
                    ctx = getattr(ps, 'ctx', None)
                    proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                self._lbl_silence_status.setText("Kein Projekt geladen")
                return

            # Find audio clips on this track
            clips = [c for c in getattr(proj, 'clips', []) or []
                     if str(getattr(c, 'track_id', '')) == track_id
                     and getattr(c, 'kind', '') == 'audio'
                     and getattr(c, 'source_path', '')]

            if not clips:
                self._lbl_silence_status.setText("Keine Audio-Clips auf dieser Spur")
                return

            import numpy as np
            from pydaw.services.podcast_mode import detect_silence

            total_regions = []
            for clip in clips:
                src = str(clip.source_path)
                try:
                    import soundfile as sf
                    data, sr = sf.read(src, dtype='float32')
                except Exception:
                    try:
                        import wave
                        with wave.open(src, 'r') as wf:
                            sr = wf.getframerate()
                            frames = wf.readframes(wf.getnframes())
                            data = np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0
                    except Exception as we:
                        self._lbl_silence_status.setText(f"Audio lesen fehlgeschlagen: {we}")
                        return

                regions = detect_silence(
                    data, sr,
                    threshold_db=self._spn_silence_db.value(),
                    min_duration_ms=self._spn_silence_dur.value(),
                )
                for r in regions:
                    total_regions.append(r)

            self._silence_regions = total_regions

            if not total_regions:
                self._lbl_silence_status.setText("✅ Keine Stille erkannt")
                return

            for r in total_regions:
                self._lst_silence.addItem(
                    f"{r.start_seconds:.1f}s – {r.end_seconds:.1f}s  "
                    f"({r.duration_seconds:.1f}s, {r.level_db:.0f} dB)"
                )

            self._btn_trim.setEnabled(True)
            self._lbl_silence_status.setText(
                f"🔇 {len(total_regions)} stille Regionen erkannt "
                f"(gesamt {sum(r.duration_seconds for r in total_regions):.1f}s)"
            )

        except ImportError:
            self._lbl_silence_status.setText(
                "⚠ numpy/soundfile nicht installiert — pip install soundfile")
        except Exception as e:
            self._lbl_silence_status.setText(f"Fehler: {e}")
            log.error("[PodcastPanel] detect_silence: %s", e, exc_info=True)

    def _trim_silence(self) -> None:
        """Inform user about trim — actual trimming requires audio editor integration."""
        try:
            if not self._silence_regions:
                return
            n = len(self._silence_regions)
            total = sum(r.duration_seconds for r in self._silence_regions)
            QMessageBox.information(
                self, "Stille trimmen",
                f"{n} stille Regionen erkannt ({total:.1f}s gesamt).\n\n"
                f"Zum Trimmen: Audio-Clip rechtsklicken → 'Stille entfernen'\n"
                f"oder die Regionen manuell im Arranger schneiden.\n\n"
                f"Die erkannten Regionen sind in der Liste markiert."
            )
        except Exception:
            pass

    # ──────────────────────────────────────────────────────────
    # PO5: Vereinfachtes Layout
    # ──────────────────────────────────────────────────────────

    def _build_layout_section(self, parent_lay) -> None:
        grp = QGroupBox("🖥 Podcast-Layout (PO5)")
        grp.setStyleSheet(
            "QGroupBox { font-weight: bold; color: #c8c8d4; border: 1px solid #444; "
            "border-radius: 6px; margin-top: 8px; padding-top: 16px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }"
        )
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        lbl = QLabel(
            "Podcast-Layout blendet Piano Roll und Clip Launcher aus\n"
            "und zeigt nur Arranger + Mixer + Podcast-Panel."
        )
        lbl.setStyleSheet("color: #9aa0a6; font-size: 11px;")
        lbl.setWordWrap(True)
        lay.addWidget(lbl)

        row = QHBoxLayout()
        self._btn_podcast_layout = QPushButton("🖥 Podcast-Layout aktivieren")
        self._btn_podcast_layout.setStyleSheet(
            "QPushButton { background: #2a2a3a; border: 1px solid #5555aa; "
            "border-radius: 4px; color: #a0a0d4; font-size: 12px; padding: 6px 12px; }"
            "QPushButton:hover { background: #3a3a4a; }"
        )
        self._btn_podcast_layout.clicked.connect(self._toggle_podcast_layout)
        row.addWidget(self._btn_podcast_layout)

        self._btn_restore_layout = QPushButton("↺ Standard-Layout")
        self._btn_restore_layout.setStyleSheet(
            "QPushButton { background: #2a2a2a; border: 1px solid #555; "
            "border-radius: 4px; color: #aaa; font-size: 11px; padding: 4px 8px; }"
            "QPushButton:hover { background: #3a3a3a; }"
        )
        self._btn_restore_layout.clicked.connect(self._restore_standard_layout)
        row.addWidget(self._btn_restore_layout)
        row.addStretch(1)
        lay.addLayout(row)

        parent_lay.addWidget(grp)

    def _toggle_podcast_layout(self) -> None:
        """PO5: Vereinfachtes Podcast-Layout aktivieren."""
        try:
            mw = self.window()
            if not mw:
                return

            # Remember which docks were visible
            self._saved_dock_visibility = {}

            # Hide Piano Roll, Clip Launcher, Notation, Automation
            for dock_name in ['_editor_dock', '_clip_launcher_dock',
                              '_notation_dock', '_automation_dock']:
                dock = getattr(mw, dock_name, None)
                if dock and hasattr(dock, 'isVisible'):
                    self._saved_dock_visibility[dock_name] = dock.isVisible()
                    try:
                        dock.hide()
                    except Exception:
                        pass

            # Show Mixer if hidden
            mixer_dock = getattr(mw, '_mixer_dock', None)
            if mixer_dock and hasattr(mixer_dock, 'show'):
                try:
                    mixer_dock.show()
                except Exception:
                    pass

            self._btn_podcast_layout.setText("✅ Podcast-Layout aktiv")
            self._btn_podcast_layout.setStyleSheet(
                "QPushButton { background: #2a3a2a; border: 1px solid #4a804a; "
                "border-radius: 4px; color: #90d490; font-size: 12px; padding: 6px 12px; }"
            )
            try:
                self.status.emit("🖥 Podcast-Layout aktiviert")
            except Exception:
                pass
        except Exception as e:
            log.error("[PO5] layout toggle: %s", e)

    def _restore_standard_layout(self) -> None:
        """PO5: Standard-Layout wiederherstellen."""
        try:
            mw = self.window()
            if not mw:
                return

            saved = getattr(self, '_saved_dock_visibility', {})
            for dock_name, was_visible in saved.items():
                dock = getattr(mw, dock_name, None)
                if dock and was_visible:
                    try:
                        dock.show()
                    except Exception:
                        pass

            self._btn_podcast_layout.setText("🖥 Podcast-Layout aktivieren")
            self._btn_podcast_layout.setStyleSheet(
                "QPushButton { background: #2a2a3a; border: 1px solid #5555aa; "
                "border-radius: 4px; color: #a0a0d4; font-size: 12px; padding: 6px 12px; }"
                "QPushButton:hover { background: #3a3a4a; }"
            )
            try:
                self.status.emit("🖥 Standard-Layout wiederhergestellt")
            except Exception:
                pass
        except Exception as e:
            log.error("[PO5] restore layout: %s", e)

    # ──────────────────────────────────────────────────────────
    # PO6: Streaming
    # ──────────────────────────────────────────────────────────

    def _build_streaming_section(self, parent_lay) -> None:
        grp = QGroupBox("📡 Live-Streaming (PO6)")
        grp.setStyleSheet(
            "QGroupBox { font-weight: bold; color: #c8c8d4; border: 1px solid #444; "
            "border-radius: 6px; margin-top: 8px; padding-top: 16px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }"
        )
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        # URL input
        url_row = QHBoxLayout()
        url_row.addWidget(QLabel("URL:"))
        self._txt_stream_url = QLineEdit()
        self._txt_stream_url.setPlaceholderText("rtmp://live.example.com/stream/key")
        url_row.addWidget(self._txt_stream_url, 1)
        lay.addLayout(url_row)

        # Format + Bitrate
        fmt_row = QHBoxLayout()
        fmt_row.addWidget(QLabel("Format:"))
        self._cmb_stream_fmt = QComboBox()
        self._cmb_stream_fmt.addItems(["mp3", "aac", "ogg"])
        self._cmb_stream_fmt.setFixedWidth(60)
        fmt_row.addWidget(self._cmb_stream_fmt)

        fmt_row.addWidget(QLabel("Bitrate:"))
        self._spn_stream_bitrate = QSpinBox()
        self._spn_stream_bitrate.setRange(64, 320)
        self._spn_stream_bitrate.setValue(128)
        self._spn_stream_bitrate.setSuffix(" kbps")
        self._spn_stream_bitrate.setFixedWidth(90)
        fmt_row.addWidget(self._spn_stream_bitrate)
        fmt_row.addStretch(1)
        lay.addLayout(fmt_row)

        # Start/Stop
        btn_row = QHBoxLayout()
        self._btn_stream_start = QPushButton("🔴 Stream starten")
        self._btn_stream_start.setStyleSheet(
            "QPushButton { background: #3a1a1a; border: 1px solid #aa4444; "
            "border-radius: 4px; color: #dd8888; font-size: 12px; padding: 6px 12px; }"
            "QPushButton:hover { background: #4a2a2a; }"
        )
        self._btn_stream_start.clicked.connect(self._toggle_streaming)
        btn_row.addWidget(self._btn_stream_start)
        btn_row.addStretch(1)
        lay.addLayout(btn_row)

        self._lbl_stream_status = QLabel("Streaming über ffmpeg an RTMP/Icecast Server")
        self._lbl_stream_status.setStyleSheet("color: #777; font-size: 10px;")
        lay.addWidget(self._lbl_stream_status)

        parent_lay.addWidget(grp)

    def _toggle_streaming(self) -> None:
        """PO6: Start/Stop Live-Streaming via PodcastModeService."""
        try:
            if not self._podcast_service:
                self._init_service()
            if not self._podcast_service:
                return

            streaming = self._podcast_service.streaming
            if streaming.is_streaming:
                streaming.stop_stream()
                self._btn_stream_start.setText("🔴 Stream starten")
                self._btn_stream_start.setStyleSheet(
                    "QPushButton { background: #3a1a1a; border: 1px solid #aa4444; "
                    "border-radius: 4px; color: #dd8888; font-size: 12px; padding: 6px 12px; }"
                    "QPushButton:hover { background: #4a2a2a; }"
                )
                self._lbl_stream_status.setText("⏹ Stream gestoppt")
                self._lbl_stream_status.setStyleSheet("color: #aaa; font-size: 10px;")
            else:
                url = self._txt_stream_url.text().strip()
                if not url:
                    QMessageBox.information(self, "Streaming",
                        "Bitte Stream-URL eingeben.\n\n"
                        "Beispiele:\n"
                        "  rtmp://live.twitch.tv/app/STREAM_KEY\n"
                        "  icecast://user:pass@server:8000/mount")
                    return

                fmt = self._cmb_stream_fmt.currentText()
                bitrate = self._spn_stream_bitrate.value()
                ok = streaming.start_stream(url, fmt, bitrate)
                if ok:
                    self._btn_stream_start.setText("⏹ Stream stoppen")
                    self._btn_stream_start.setStyleSheet(
                        "QPushButton { background: #1a3a1a; border: 1px solid #44aa44; "
                        "border-radius: 4px; color: #88dd88; font-size: 12px; padding: 6px 12px; }"
                        "QPushButton:hover { background: #2a4a2a; }"
                    )
                    self._lbl_stream_status.setText(f"🔴 LIVE: {url} ({fmt} @ {bitrate}kbps)")
                    self._lbl_stream_status.setStyleSheet("color: #dd4444; font-size: 10px; font-weight: bold;")
        except Exception as e:
            self._lbl_stream_status.setText(f"❌ {e}")
            log.error("[PO6] streaming: %s", e)
