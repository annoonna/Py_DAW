"""rust_dashboard_widget.py — Animated Rust Engine Status Dashboard (v0.0.20.980)

A visually distinctive statusbar widget that shows the Rust audio engine
status with real-time animations:

  🦀 ● 0.3ms │ CPU 2% │ XR:0

Features:
  - Pulsing heartbeat dot that throbs with each audio callback
  - Color-coded: green=healthy, orange=warning, red=error, gray=offline
  - Live latency display (ms)
  - Mini CPU bar (fills with load)
  - XRun counter (blinks red on new XRun)
  - Click → opens Audio Settings dialog
  - Tooltip with detailed engine info
  - Smooth animations (QPropertyAnimation)

No other DAW has this in their statusbar.
"""

import time
import math
from typing import Optional

from PyQt6.QtCore import (
    Qt, QTimer, QPropertyAnimation, QEasingCurve,
    pyqtProperty, QRectF, QSize,
)
from PyQt6.QtGui import (
    QPainter, QColor, QPen, QBrush, QFont, QLinearGradient,
    QPainterPath, QRadialGradient,
)
from PyQt6.QtWidgets import QWidget, QToolTip

import logging
log = logging.getLogger(__name__)


class RustDashboardWidget(QWidget):
    """Animated Rust Engine status dashboard for the statusbar."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(22)
        self.setMinimumWidth(220)
        self.setMaximumWidth(320)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        # --- State ---
        self._connected = False
        self._connecting = False  # v0.0.20.983: NS5.3 connecting state
        self._engine_active = False
        self._cpu_load = 0.0        # 0.0–1.0
        self._latency_ms = 0.0
        self._xrun_count = 0
        self._prev_xrun_count = 0
        self._sample_rate = 0
        self._buffer_size = 0
        self._device_name = ""
        self._pw_quantum = 0        # v0.0.20.983: NS5.4 PipeWire actual quantum
        self._pw_rate = 0           # v0.0.20.983: NS5.4 PipeWire actual rate

        # --- Animation state ---
        self._pulse_phase = 0.0     # 0.0–1.0 for heartbeat
        self._pulse_speed = 0.05    # phase increment per tick
        self._glow_intensity = 0.0  # 0.0–1.0
        self._xrun_flash = 0.0     # 1.0 on xrun, decays to 0
        self._wave_phase = 0.0     # for mini waveform

        # --- Colors ---
        self._color_bg = QColor(20, 20, 28)
        self._color_border = QColor(50, 50, 60)
        self._color_text = QColor(180, 180, 190)
        self._color_accent = QColor(255, 110, 64)  # Rust orange
        self._color_green = QColor(76, 175, 80)
        self._color_yellow = QColor(255, 193, 7)
        self._color_red = QColor(244, 67, 54)
        self._color_gray = QColor(100, 100, 110)

        # --- Animation timer ---
        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(33)  # ~30fps
        self._anim_timer.timeout.connect(self._tick)
        self._anim_timer.start()

        # --- Data polling timer ---
        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(500)  # 2Hz
        self._poll_timer.timeout.connect(self._poll_engine)
        self._poll_timer.start()

        self.setToolTip("🦀 Rust Audio Engine — Klick für Details")

    # === Public API ===

    def set_connected(self, connected: bool, device: str = "",
                      sr: int = 0, buf: int = 0):
        self._connected = connected
        self._connecting = False
        self._device_name = device
        self._sample_rate = sr
        self._buffer_size = buf
        if connected:
            self._engine_active = True
            # v0.0.20.983: NS5.4 — query PipeWire quantum on connect
            self._query_pipewire_quantum()
        self.update()

    def set_connecting(self):
        """v0.0.20.983: NS5.3 — show 'connecting' state in dashboard."""
        self._connecting = True
        self._connected = False
        self.setToolTip("🦀 Rust Audio Engine — Verbinde...")
        self.update()

    def set_metrics(self, cpu_load: float, latency_ms: float, xruns: int):
        self._cpu_load = min(1.0, max(0.0, cpu_load))
        self._latency_ms = latency_ms
        if xruns > self._xrun_count:
            self._xrun_flash = 1.0  # trigger flash
        self._xrun_count = xruns
        self._update_tooltip()
        self.update()

    def set_disconnected(self):
        self._connected = False
        self._connecting = False
        self._engine_active = False
        self._cpu_load = 0.0
        self._latency_ms = 0.0
        self.update()

    # === Private ===

    def _query_pipewire_quantum(self):
        """v0.0.20.983: NS5.4 — Query PipeWire actual quantum/rate.

        Runs pw-metadata in a thread to avoid blocking the UI.
        """
        import threading

        def _query():
            try:
                import subprocess
                result = subprocess.run(
                    ["pw-metadata", "-n", "settings", "0"],
                    capture_output=True, text=True, timeout=2,
                )
                if result.returncode == 0:
                    output = result.stdout
                    for line in output.splitlines():
                        if "clock.quantum" in line and "clock.quantum-limit" not in line:
                            # Format: key:'clock.quantum' value:'1024' type:''
                            parts = line.split("value:'")
                            if len(parts) >= 2:
                                val = parts[1].split("'")[0]
                                self._pw_quantum = int(val)
                        elif "clock.rate" in line and "clock.allowed-rates" not in line:
                            parts = line.split("value:'")
                            if len(parts) >= 2:
                                val = parts[1].split("'")[0]
                                self._pw_rate = int(val)
            except FileNotFoundError:
                pass  # pw-metadata not installed (no PipeWire)
            except Exception as e:
                log.debug("PipeWire quantum query failed: %s", e)

        threading.Thread(target=_query, daemon=True, name="pw-quantum").start()

    def _tick(self):
        """Animation tick (~30fps)."""
        # Pulse heartbeat
        if self._connected:
            self._pulse_phase += self._pulse_speed
            if self._pulse_phase > 1.0:
                self._pulse_phase -= 1.0
            # Glow follows pulse
            self._glow_intensity = 0.3 + 0.7 * (math.sin(self._pulse_phase * math.pi * 2) * 0.5 + 0.5)
            # Mini waveform — faster phase for visible animation
            self._wave_phase += 0.12
            if self._wave_phase > math.pi * 2:
                self._wave_phase -= math.pi * 2
        elif self._connecting:
            # v0.0.20.983: NS5.3 — slow pulse while connecting
            self._pulse_phase += 0.03
            if self._pulse_phase > 1.0:
                self._pulse_phase -= 1.0
            self._glow_intensity = 0.2 + 0.5 * (math.sin(self._pulse_phase * math.pi * 2) * 0.5 + 0.5)
        else:
            self._glow_intensity *= 0.95  # fade out
            self._pulse_phase = 0.0

        # XRun flash decay
        if self._xrun_flash > 0:
            self._xrun_flash *= 0.92

        self.update()

    def _poll_engine(self):
        """Poll Rust engine for status — only when audio is running."""
        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            bridge = RustEngineBridge.instance()
            if bridge is None:
                if self._connected:
                    self.set_disconnected()
                return

            if bridge.is_connected:
                if not self._connected:
                    self.set_connected(True)
                # Only poll AudioStatus when engine is connected AND
                # has a known active audio stream (avoids log spam when
                # the Rust binary doesn't support AudioStatus yet)
                if self._engine_active:
                    try:
                        bridge.audio_status()
                    except Exception:
                        pass
            else:
                if self._connected:
                    self.set_disconnected()
        except Exception:
            pass

    def _update_tooltip(self):
        if self._connected:
            # v0.0.20.983: NS5.4 — PipeWire quantum in tooltip
            pw_info = ""
            if self._pw_quantum > 0:
                match = "✅" if self._pw_quantum == self._buffer_size else "⚠️ MISMATCH"
                pw_info = (
                    f"\n── PipeWire ──\n"
                    f"Quantum:    {self._pw_quantum} Samples {match}\n"
                    f"Rate:       {self._pw_rate} Hz\n"
                )
                if self._pw_quantum != self._buffer_size:
                    pw_info += (
                        f"Angefordert: {self._buffer_size} | Tatsächlich: {self._pw_quantum}\n"
                    )
            tip = (
                f"🦀 Rust Audio Engine — VERBUNDEN\n\n"
                f"Device:     {self._device_name or 'default'}\n"
                f"Sample Rate: {self._sample_rate} Hz\n"
                f"Buffer:     {self._buffer_size} Samples\n"
                f"Latenz:     {self._latency_ms:.1f} ms\n"
                f"CPU:        {self._cpu_load * 100:.1f}%\n"
                f"XRuns:      {self._xrun_count}\n"
                f"{pw_info}\n"
                f"Klick → Audio-Einstellungen"
            )
        else:
            tip = "🦀 Rust Audio Engine — OFFLINE\n\nKlick → Audio-Einstellungen"
        self.setToolTip(tip)

    # === Paint ===

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        h = self.height()

        # Background
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(self._color_bg))
        p.drawRoundedRect(0, 0, w, h, 4, 4)

        # Border
        border_color = QColor(self._color_accent) if self._connected else self._color_border
        if self._connected:
            border_color.setAlphaF(0.3 + 0.4 * self._glow_intensity)
        p.setPen(QPen(border_color, 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(0, 0, w - 1, h - 1, 4, 4)

        x = 6  # current X position

        # === Rust Logo (🦀) ===
        p.setFont(QFont("", 11))
        p.setPen(QPen(self._color_accent if self._connected else self._color_gray))
        p.drawText(x, 16, "🦀")
        x += 20

        # === Heartbeat Dot ===
        dot_radius = 4.0
        dot_x = x + dot_radius
        dot_y = h / 2.0

        if self._connected:
            # Pulsing glow
            glow_radius = dot_radius + 3 * self._glow_intensity
            glow = QRadialGradient(dot_x, dot_y, glow_radius)
            dot_color = self._color_green if self._cpu_load < 0.7 else (
                self._color_yellow if self._cpu_load < 0.9 else self._color_red
            )
            glow_color = QColor(dot_color)
            glow_color.setAlphaF(0.4 * self._glow_intensity)
            glow.setColorAt(0, glow_color)
            glow_color2 = QColor(dot_color)
            glow_color2.setAlphaF(0)
            glow.setColorAt(1, glow_color2)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(glow))
            p.drawEllipse(QRectF(dot_x - glow_radius, dot_y - glow_radius,
                                  glow_radius * 2, glow_radius * 2))

            # Solid dot
            p.setBrush(QBrush(dot_color))
            p.drawEllipse(QRectF(dot_x - dot_radius, dot_y - dot_radius,
                                  dot_radius * 2, dot_radius * 2))
        else:
            # Gray dot (or yellow pulsing when connecting)
            p.setPen(Qt.PenStyle.NoPen)
            if self._connecting:
                # v0.0.20.983: NS5.3 — yellow pulse while connecting
                connect_color = QColor(self._color_yellow)
                connect_color.setAlphaF(0.4 + 0.6 * self._glow_intensity)
                p.setBrush(QBrush(connect_color))
            else:
                p.setBrush(QBrush(self._color_gray))
            p.drawEllipse(QRectF(dot_x - dot_radius, dot_y - dot_radius,
                                  dot_radius * 2, dot_radius * 2))

        x += 14

        # === Latency ===
        p.setFont(QFont("Monospace", 8))
        if self._connected:
            lat_text = f"{self._latency_ms:.1f}ms"
            lat_color = self._color_green if self._latency_ms < 10 else (
                self._color_yellow if self._latency_ms < 20 else self._color_red
            )
            p.setPen(QPen(lat_color))
        elif self._connecting:
            lat_text = "Verbinde…"
            p.setPen(QPen(self._color_yellow))
        else:
            lat_text = "—ms"
            p.setPen(QPen(self._color_gray))
        p.drawText(x, 15, lat_text)
        x += 42

        # === Separator ===
        p.setPen(QPen(QColor(60, 60, 70)))
        p.drawLine(x, 4, x, h - 4)
        x += 6

        # === CPU Mini-Bar ===
        p.setFont(QFont("Monospace", 8))
        p.setPen(QPen(self._color_text))
        p.drawText(x, 15, "CPU")
        x += 26

        # CPU bar background
        bar_w = 30
        bar_h = 8
        bar_y = (h - bar_h) / 2
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor(30, 30, 40)))
        p.drawRoundedRect(int(x), int(bar_y), bar_w, bar_h, 2, 2)

        # CPU bar fill
        if self._connected:
            fill_w = int(bar_w * self._cpu_load)
            if fill_w > 0:
                bar_color = self._color_green if self._cpu_load < 0.6 else (
                    self._color_yellow if self._cpu_load < 0.85 else self._color_red
                )
                grad = QLinearGradient(x, 0, x + fill_w, 0)
                grad.setColorAt(0, bar_color)
                darker = QColor(bar_color)
                darker.setAlphaF(0.7)
                grad.setColorAt(1, darker)
                p.setBrush(QBrush(grad))
                p.drawRoundedRect(int(x), int(bar_y), fill_w, bar_h, 2, 2)

        x += bar_w + 3

        # v0.0.20.983: CPU percentage text NEXT TO bar (always visible)
        if self._connected:
            cpu_text = f"{self._cpu_load * 100:.0f}%"
            cpu_color = self._color_green if self._cpu_load < 0.6 else (
                self._color_yellow if self._cpu_load < 0.85 else self._color_red
            )
            if self._cpu_load < 0.01:
                cpu_color = self._color_text  # gray when idle
            p.setPen(QPen(cpu_color))
        else:
            cpu_text = "—%"
            p.setPen(QPen(self._color_gray))
        p.setFont(QFont("Monospace", 8))
        p.drawText(int(x), 15, cpu_text)
        x += 24

        # === Separator ===
        p.setPen(QPen(QColor(60, 60, 70)))
        p.drawLine(x, 4, x, h - 4)
        x += 6

        # === XRun Counter ===
        xr_color = self._color_text
        if self._xrun_flash > 0.1:
            # Flash red on new XRun
            flash_alpha = self._xrun_flash
            xr_color = QColor(
                int(self._color_text.red() * (1 - flash_alpha) + self._color_red.red() * flash_alpha),
                int(self._color_text.green() * (1 - flash_alpha) + self._color_red.green() * flash_alpha),
                int(self._color_text.blue() * (1 - flash_alpha) + self._color_red.blue() * flash_alpha),
            )
        p.setFont(QFont("Monospace", 8))
        p.setPen(QPen(xr_color))
        xr_text = f"XR:{self._xrun_count}" if self._connected else "XR:—"
        p.drawText(x, 15, xr_text)
        x += 36

        # === Mini Waveform (when connected) ===
        if self._connected and x + 20 < w:
            wave_w = min(40, w - x - 4)
            mid_y = h / 2.0
            # Amplitude: reflects engine activity — idle=small, active=full
            base_amp = 2.0
            active_amp = min(6.0, h / 2.0 - 2)
            # Use latency as activity indicator: >0ms = engine processing
            activity = min(1.0, self._latency_ms / 25.0) if self._latency_ms > 0 else 0.3
            amp = base_amp + (active_amp - base_amp) * activity
            # CPU load also modulates frequency
            freq_mult = 1.0 + self._cpu_load * 0.5

            # Build smooth path
            path = QPainterPath()
            first = True
            for i in range(wave_w):
                phase = self._wave_phase + i * 0.25 * freq_mult
                y_off = math.sin(phase) * amp
                px = x + i
                py = mid_y + y_off
                if first:
                    path.moveTo(px, py)
                    first = False
                else:
                    path.lineTo(px, py)

            # Draw with glow effect
            wave_color = QColor(self._color_accent)
            wave_color.setAlphaF(0.25 + 0.35 * self._glow_intensity)
            p.setPen(QPen(wave_color, 2.0))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawPath(path)
            # Brighter core line
            wave_core = QColor(self._color_accent)
            wave_core.setAlphaF(0.6 + 0.4 * self._glow_intensity)
            p.setPen(QPen(wave_core, 1.0))
            p.drawPath(path)

        p.end()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._open_audio_settings()

    def _open_audio_settings(self):
        """Open the Audio Settings dialog."""
        try:
            # Find the main window
            parent = self.parent()
            while parent is not None:
                if hasattr(parent, 'menuBar'):
                    # Try to trigger Audio Settings
                    try:
                        # Find Audio menu → Audio-Einstellungen action
                        for action in parent.menuBar().actions():
                            menu = action.menu()
                            if menu and "Audio" in action.text():
                                for sub in menu.actions():
                                    if "Einstellung" in sub.text() or "Settings" in sub.text():
                                        sub.trigger()
                                        return
                    except Exception:
                        pass
                parent = parent.parent() if hasattr(parent, 'parent') else None
        except Exception:
            pass

    def sizeHint(self):
        return QSize(280, 22)
