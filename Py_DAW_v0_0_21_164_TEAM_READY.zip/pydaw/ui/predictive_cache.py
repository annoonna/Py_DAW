# -*- coding: utf-8 -*-
"""Predictive Caching — Scroll & Edit Prediction.

v0.0.21.028 — Block E Phase E2.1 + E2.2

Rule-based prediction for prefetching waveform data and
anticipating user actions. No ML training needed.

Usage:
    from pydaw.ui.predictive_cache import ScrollPredictor, EditPredictor

    sp = ScrollPredictor()
    sp.on_scroll(position=100.0, direction=1)
    prefetch_range = sp.predict_next()  # → (120.0, 180.0)

    ep = EditPredictor()
    ep.on_track_click(track_id="trk_001")
    actions = ep.predict_next_actions()
    # → [{"action": "load_waveform", "track": "trk_001", "priority": "high"}]
"""
from __future__ import annotations

import time
import logging
from collections import deque
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


class ScrollPredictor:
    """E2.1: Predict scroll direction and prefetch waveform data.

    Tracks scroll velocity and direction to prefetch the next
    2 screen-widths of waveform data before the user gets there.

    Algorithm:
    - Track last N scroll positions + timestamps
    - Compute velocity (beats/second)
    - Predict position in 500ms
    - Return prefetch range (predicted_pos ± screen_width)
    """

    def __init__(self, history_size: int = 10, lookahead_ms: float = 500):
        self._history: deque = deque(maxlen=history_size)
        self._lookahead_s = lookahead_ms / 1000.0
        self._screen_width_beats = 32.0  # will be updated
        self._last_direction = 0  # -1=left, 0=stopped, 1=right

    def set_screen_width(self, beats: float) -> None:
        """Update visible screen width in beats."""
        self._screen_width_beats = max(4.0, beats)

    def on_scroll(self, position_beats: float) -> None:
        """Record a scroll position."""
        now = time.monotonic()
        self._history.append((now, position_beats))

        if len(self._history) >= 2:
            _, prev_pos = self._history[-2]
            diff = position_beats - prev_pos
            self._last_direction = 1 if diff > 0 else (-1 if diff < 0 else 0)

    def predict_next(self) -> Optional[Tuple[float, float]]:
        """Predict the next visible range to prefetch.

        Returns (start_beat, end_beat) or None if insufficient data.
        """
        if len(self._history) < 3:
            return None

        # Compute velocity from last N samples
        times = [h[0] for h in self._history]
        positions = [h[1] for h in self._history]

        dt = times[-1] - times[0]
        if dt < 0.01:
            return None

        velocity = (positions[-1] - positions[0]) / dt  # beats per second

        # Predict position after lookahead
        predicted = positions[-1] + velocity * self._lookahead_s

        # Prefetch range: 2 screen widths around predicted position
        margin = self._screen_width_beats * 2
        start = predicted - margin * 0.5
        end = predicted + margin * 1.5

        return (max(0, start), end)

    def get_velocity(self) -> float:
        """Current scroll velocity in beats/second."""
        if len(self._history) < 2:
            return 0.0
        times = [h[0] for h in self._history]
        positions = [h[1] for h in self._history]
        dt = times[-1] - times[0]
        if dt < 0.01:
            return 0.0
        return (positions[-1] - positions[0]) / dt

    def is_scrolling(self) -> bool:
        """Is the user actively scrolling?"""
        if len(self._history) < 2:
            return False
        now = time.monotonic()
        last_time = self._history[-1][0]
        return (now - last_time) < 0.3  # active if scrolled within 300ms


class EditPredictor:
    """E2.2: Predict next user action and prefetch data.

    Heuristics:
    - Click on track → prefetch that track's waveforms in high-res
    - Open Piano Roll → prefetch MIDI + expression data
    - Select clip → prefetch neighboring clips
    - Open Mixer → prefetch all VU meter data
    """

    def __init__(self):
        self._action_log: deque = deque(maxlen=50)
        self._current_track: Optional[str] = None
        self._current_clip: Optional[str] = None

    def on_track_click(self, track_id: str) -> None:
        self._current_track = track_id
        self._log_action("track_click", {"track": track_id})

    def on_clip_select(self, clip_id: str, track_id: str = "") -> None:
        self._current_clip = clip_id
        self._log_action("clip_select", {"clip": clip_id, "track": track_id})

    def on_view_change(self, view: str) -> None:
        """View switched: arranger, mixer, editor, piano_roll, device."""
        self._log_action("view_change", {"view": view})

    def on_tool_change(self, tool: str) -> None:
        """Tool changed: select, knife, draw, erase."""
        self._log_action("tool_change", {"tool": tool})

    def _log_action(self, action: str, data: Dict[str, Any]) -> None:
        self._action_log.append({
            "time": time.monotonic(),
            "action": action,
            **data,
        })

    def predict_next_actions(self) -> List[Dict[str, Any]]:
        """Predict what data to prefetch based on recent actions.

        Returns list of prefetch recommendations.
        """
        predictions = []

        if not self._action_log:
            return predictions

        last = self._action_log[-1]
        action = last.get("action", "")

        # Track click → prefetch waveforms for that track
        if action == "track_click":
            tid = last.get("track", "")
            if tid:
                predictions.append({
                    "action": "prefetch_waveform",
                    "track": tid,
                    "resolution": "high",
                    "priority": "high",
                })
                # Also prefetch neighboring tracks
                predictions.append({
                    "action": "prefetch_waveform",
                    "track": f"{tid}_neighbors",
                    "resolution": "medium",
                    "priority": "low",
                })

        # Clip select → prefetch clip audio data
        elif action == "clip_select":
            cid = last.get("clip", "")
            if cid:
                predictions.append({
                    "action": "prefetch_clip_audio",
                    "clip": cid,
                    "priority": "high",
                })

        # View change → prefetch view-specific data
        elif action == "view_change":
            view = last.get("view", "")
            if view == "piano_roll":
                predictions.append({
                    "action": "prefetch_midi_data",
                    "priority": "high",
                })
                predictions.append({
                    "action": "prefetch_expression_data",
                    "priority": "medium",
                })
            elif view == "mixer":
                predictions.append({
                    "action": "prefetch_meter_data",
                    "priority": "high",
                })
            elif view == "editor":
                predictions.append({
                    "action": "prefetch_audio_editor_data",
                    "priority": "high",
                })

        # Tool change to knife → user will likely split clips
        elif action == "tool_change":
            tool = last.get("tool", "")
            if tool == "knife":
                predictions.append({
                    "action": "prefetch_transient_data",
                    "priority": "medium",
                })

        return predictions

    def get_action_history(self) -> List[Dict[str, Any]]:
        """Return recent action history for debugging."""
        return list(self._action_log)
