"""video_smart_cut_panel.py — KI Smart Cut Panel for VE12 (v0.0.20.950).

UI panel for automatic video editing:
  - One-click filler word removal
  - Pause/silence detection and shortening
  - Highlight reel generation
  - "Compress to N seconds" slider

Integrates with VideoTextEditorPanel for word deletion.

Usage:
    panel = SmartCutPanel(project_service)
    panel.set_video_path("/path/to/video.mp4")
    panel.cuts_applied.connect(on_cuts)
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QSlider, QSpinBox, QGroupBox, QScrollArea, QCheckBox,
    QProgressBar, QSizePolicy, QFrame,
)

log = logging.getLogger(__name__)


class SmartCutPanel(QWidget):
    """KI Smart Cut control panel.
    
    Signals:
        cuts_applied(): Emitted when cuts are applied
        highlight_ready(list): Emitted with highlight reel regions
    """

    cuts_applied = pyqtSignal()
    highlight_ready = pyqtSignal(list)

    def __init__(self, project_service=None, parent=None):
        super().__init__(parent)
        self._ps = project_service
        self._video_path: Optional[str] = None
        self._result = None  # SmartCutResult
        self._setup_ui()

    def _setup_ui(self) -> None:
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(6)

        # Header
        hdr = QLabel("🤖 KI Smart Cut")
        hdr.setStyleSheet(
            "font-weight: bold; color: #e0e0e0; font-size: 11px;")
        lay.addWidget(hdr)

        # ── Analyze button ──
        self._btn_analyze = QPushButton("🔍 Analysieren")
        self._btn_analyze.setFixedHeight(28)
        self._btn_analyze.setStyleSheet(
            "QPushButton { background: #2a3a4a; border: 1px solid #4a6a8a; "
            "border-radius: 4px; color: #aaddff; font-size: 11px; "
            "font-weight: bold; }"
            "QPushButton:hover { background: #3a5a6a; }"
            "QPushButton:disabled { background: #222; color: #555; }"
        )
        self._btn_analyze.clicked.connect(self._on_analyze)
        lay.addWidget(self._btn_analyze)

        # ── Results summary ──
        self._lbl_summary = QLabel("Noch nicht analysiert")
        self._lbl_summary.setStyleSheet(
            "color: #aaa; font-size: 10px; padding: 4px;")
        self._lbl_summary.setWordWrap(True)
        lay.addWidget(self._lbl_summary)

        # ── Filler words group ──
        grp_fillers = QGroupBox("🗣 Füllwörter")
        grp_fillers.setStyleSheet(
            "QGroupBox { color: #ddd; border: 1px solid #444; "
            "border-radius: 4px; margin-top: 6px; padding-top: 12px; "
            "font-size: 10px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 8px; }"
        )
        fl = QVBoxLayout(grp_fillers)
        fl.setSpacing(4)

        self._lbl_fillers = QLabel("—")
        self._lbl_fillers.setStyleSheet("color: #ccc; font-size: 10px;")
        fl.addWidget(self._lbl_fillers)

        self._btn_remove_fillers = QPushButton("✂ Füllwörter entfernen")
        self._btn_remove_fillers.setFixedHeight(24)
        self._btn_remove_fillers.setEnabled(False)
        self._btn_remove_fillers.setStyleSheet(
            "QPushButton { background: #3a2a2a; border: 1px solid #6a4a4a; "
            "border-radius: 3px; color: #ffaaaa; font-size: 10px; }"
            "QPushButton:hover { background: #4a3a3a; }"
            "QPushButton:disabled { background: #222; color: #555; }"
        )
        self._btn_remove_fillers.clicked.connect(self._on_remove_fillers)
        fl.addWidget(self._btn_remove_fillers)

        lay.addWidget(grp_fillers)

        # ── Pauses group ──
        grp_pauses = QGroupBox("⏸ Pausen")
        grp_pauses.setStyleSheet(grp_fillers.styleSheet())
        pl = QVBoxLayout(grp_pauses)
        pl.setSpacing(4)

        self._lbl_pauses = QLabel("—")
        self._lbl_pauses.setStyleSheet("color: #ccc; font-size: 10px;")
        pl.addWidget(self._lbl_pauses)

        self._btn_shorten_pauses = QPushButton("✂ Pausen kürzen")
        self._btn_shorten_pauses.setFixedHeight(24)
        self._btn_shorten_pauses.setEnabled(False)
        self._btn_shorten_pauses.setStyleSheet(
            self._btn_remove_fillers.styleSheet())
        self._btn_shorten_pauses.clicked.connect(self._on_shorten_pauses)
        pl.addWidget(self._btn_shorten_pauses)

        lay.addWidget(grp_pauses)

        # ── Repetitions group ──
        grp_reps = QGroupBox("🔁 Wiederholungen")
        grp_reps.setStyleSheet(grp_fillers.styleSheet())
        rl = QVBoxLayout(grp_reps)
        rl.setSpacing(4)

        self._lbl_reps = QLabel("—")
        self._lbl_reps.setStyleSheet("color: #ccc; font-size: 10px;")
        rl.addWidget(self._lbl_reps)

        self._btn_remove_reps = QPushButton("✂ Wiederholungen entfernen")
        self._btn_remove_reps.setFixedHeight(24)
        self._btn_remove_reps.setEnabled(False)
        self._btn_remove_reps.setStyleSheet(
            self._btn_remove_fillers.styleSheet())
        self._btn_remove_reps.clicked.connect(self._on_remove_repetitions)
        rl.addWidget(self._btn_remove_reps)

        lay.addWidget(grp_reps)

        # ── Highlight Reel ──
        grp_hl = QGroupBox("⭐ Highlight Reel")
        grp_hl.setStyleSheet(grp_fillers.styleSheet())
        hl = QVBoxLayout(grp_hl)
        hl.setSpacing(4)

        hl_row = QHBoxLayout()
        hl_row.addWidget(QLabel("Zieldauer:"))
        self._spin_hl_dur = QSpinBox()
        self._spin_hl_dur.setRange(5, 300)
        self._spin_hl_dur.setValue(30)
        self._spin_hl_dur.setSuffix(" s")
        self._spin_hl_dur.setFixedWidth(70)
        self._spin_hl_dur.setStyleSheet(
            "QSpinBox { background: #2a2a3a; color: #ddd; "
            "border: 1px solid #444; border-radius: 3px; font-size: 10px; }"
        )
        hl_row.addWidget(self._spin_hl_dur)
        hl_row.addStretch(1)
        hl.addLayout(hl_row)

        self._btn_highlight = QPushButton("⭐ Highlight Reel erstellen")
        self._btn_highlight.setFixedHeight(24)
        self._btn_highlight.setStyleSheet(
            "QPushButton { background: #3a3a2a; border: 1px solid #6a6a4a; "
            "border-radius: 3px; color: #ffddaa; font-size: 10px; }"
            "QPushButton:hover { background: #4a4a3a; }"
        )
        self._btn_highlight.clicked.connect(self._on_highlight)
        hl.addWidget(self._btn_highlight)

        lay.addWidget(grp_hl)

        # ── Compress ──
        grp_comp = QGroupBox("📐 Zusammenfassung")
        grp_comp.setStyleSheet(grp_fillers.styleSheet())
        cl = QVBoxLayout(grp_comp)
        cl.setSpacing(4)

        cl_row = QHBoxLayout()
        cl_row.addWidget(QLabel("Kürze auf:"))
        self._spin_compress = QSpinBox()
        self._spin_compress.setRange(5, 600)
        self._spin_compress.setValue(30)
        self._spin_compress.setSuffix(" s")
        self._spin_compress.setFixedWidth(70)
        self._spin_compress.setStyleSheet(
            self._spin_hl_dur.styleSheet())
        cl_row.addWidget(self._spin_compress)
        cl_row.addStretch(1)
        cl.addLayout(cl_row)

        self._btn_compress = QPushButton("📐 Auf Zieldauer kürzen")
        self._btn_compress.setFixedHeight(24)
        self._btn_compress.setStyleSheet(
            "QPushButton { background: #2a2a3a; border: 1px solid #4a4a6a; "
            "border-radius: 3px; color: #aaaaff; font-size: 10px; }"
            "QPushButton:hover { background: #3a3a4a; }"
        )
        self._btn_compress.clicked.connect(self._on_compress)
        cl.addWidget(self._btn_compress)

        lay.addWidget(grp_comp)

        # ── One-click all ──
        self._btn_auto_all = QPushButton("🚀 Auto-Clean (alles sicher)")
        self._btn_auto_all.setFixedHeight(30)
        self._btn_auto_all.setEnabled(False)
        self._btn_auto_all.setStyleSheet(
            "QPushButton { background: #2a4a3a; border: 1px solid #4a8a6a; "
            "border-radius: 4px; color: #aaffcc; font-size: 11px; "
            "font-weight: bold; }"
            "QPushButton:hover { background: #3a5a4a; }"
            "QPushButton:disabled { background: #222; color: #555; }"
        )
        self._btn_auto_all.clicked.connect(self._on_auto_all)
        lay.addWidget(self._btn_auto_all)

        lay.addStretch(1)
        self.setStyleSheet("background: #12121e;")
        self.setMinimumWidth(200)

    # ── Public API ──

    def set_video_path(self, path: Optional[str]) -> None:
        self._video_path = path
        self._result = None
        self._update_ui()

    # ── Analysis ──

    def _get_transcript(self):
        """Get transcript from WhisperService."""
        if not self._video_path:
            return None
        try:
            from pydaw.services.video_whisper_service import WhisperService
            return WhisperService.instance().get_transcript(self._video_path)
        except Exception:
            return None

    def _on_analyze(self) -> None:
        transcript = self._get_transcript()
        if not transcript:
            self._lbl_summary.setText(
                "⚠ Kein Transkript. Bitte erst transkribieren.")
            return

        try:
            from pydaw.services.video_smart_cut import SmartCutService
            svc = SmartCutService()
            self._result = svc.analyze(transcript)
            self._update_ui()
        except Exception as exc:
            self._lbl_summary.setText(f"❌ Fehler: {exc}")

    def _update_ui(self) -> None:
        r = self._result
        if not r:
            self._lbl_summary.setText("Noch nicht analysiert")
            self._lbl_fillers.setText("—")
            self._lbl_pauses.setText("—")
            self._lbl_reps.setText("—")
            self._btn_remove_fillers.setEnabled(False)
            self._btn_shorten_pauses.setEnabled(False)
            self._btn_remove_reps.setEnabled(False)
            self._btn_auto_all.setEnabled(False)
            return

        self._lbl_summary.setText(r.summary())

        n_f = len(r.fillers)
        d_f = sum(s.duration for s in r.fillers)
        self._lbl_fillers.setText(
            f"{n_f} gefunden ({d_f:.1f}s)" if n_f else "Keine gefunden")
        self._btn_remove_fillers.setEnabled(n_f > 0)

        n_p = len(r.pauses)
        d_p = sum(s.duration for s in r.pauses)
        self._lbl_pauses.setText(
            f"{n_p} gefunden ({d_p:.1f}s)" if n_p else "Keine gefunden")
        self._btn_shorten_pauses.setEnabled(n_p > 0)

        n_r = len(r.repetitions)
        d_r = sum(s.duration for s in r.repetitions)
        self._lbl_reps.setText(
            f"{n_r} gefunden ({d_r:.1f}s)" if n_r else "Keine gefunden")
        self._btn_remove_reps.setEnabled(n_r > 0)

        self._btn_auto_all.setEnabled(len(r.auto_applicable) > 0)

    # ── Actions ──

    def _apply_and_notify(self, suggestions):
        """Apply suggestions and emit signal."""
        transcript = self._get_transcript()
        if not transcript:
            return
        try:
            from pydaw.services.video_smart_cut import SmartCutService
            svc = SmartCutService()
            count = svc.apply_suggestions(transcript, suggestions)

            # Save back
            from pydaw.services.video_whisper_service import WhisperService
            ws = WhisperService.instance()
            ws._save_to_db(self._video_path, transcript)

            self._lbl_summary.setText(f"✅ {count} Wörter entfernt")
            self.cuts_applied.emit()
        except Exception as exc:
            self._lbl_summary.setText(f"❌ Fehler: {exc}")

    def _on_remove_fillers(self) -> None:
        if self._result:
            self._apply_and_notify(self._result.fillers)

    def _on_shorten_pauses(self) -> None:
        if self._result:
            self._apply_and_notify(self._result.pauses)

    def _on_remove_repetitions(self) -> None:
        if self._result:
            self._apply_and_notify(self._result.repetitions)

    def _on_auto_all(self) -> None:
        if self._result:
            self._apply_and_notify(self._result.auto_applicable)

    def _on_highlight(self) -> None:
        transcript = self._get_transcript()
        if not transcript:
            self._lbl_summary.setText(
                "⚠ Kein Transkript vorhanden")
            return
        try:
            from pydaw.services.video_smart_cut import SmartCutService
            svc = SmartCutService()
            target = self._spin_hl_dur.value()
            regions = svc.highlight_reel(transcript, float(target))
            total = sum(e - s for s, e in regions)
            self._lbl_summary.setText(
                f"⭐ Highlight Reel: {len(regions)} Segmente, "
                f"{total:.1f}s")
            self.highlight_ready.emit(regions)
        except Exception as exc:
            self._lbl_summary.setText(f"❌ Fehler: {exc}")

    def _on_compress(self) -> None:
        transcript = self._get_transcript()
        if not transcript:
            return
        try:
            from pydaw.services.video_smart_cut import SmartCutService
            svc = SmartCutService()
            target = self._spin_compress.value()
            word_ids = svc.compress(transcript, float(target))
            if word_ids:
                for wid in word_ids:
                    transcript.delete_word(wid)

                from pydaw.services.video_whisper_service import WhisperService
                ws = WhisperService.instance()
                ws._save_to_db(self._video_path, transcript)

                self._lbl_summary.setText(
                    f"✅ {len(word_ids)} Wörter entfernt "
                    f"(Ziel: {target}s)")
                self.cuts_applied.emit()
            else:
                self._lbl_summary.setText("Video ist bereits kurz genug")
        except Exception as exc:
            self._lbl_summary.setText(f"❌ Fehler: {exc}")
