"""Undoable clip-automation edits (AE2.4).

Stores before/after snapshots of a single clip's automation envelope
for one parameter. Lightweight — only the affected param's breakpoint
list is stored, not the whole project.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


@dataclass
class AutomationEditCommand:
    """Undo/redo a clip-automation change for one parameter."""

    clip_id: str
    param: str  # "gain", "pan", "pitch", "formant"
    before: List[Dict[str, Any]]
    after: List[Dict[str, Any]]
    label: str = ""
    _apply: Callable[[str, str, List[Dict[str, Any]]], None] = field(repr=False, default=lambda c, p, pts: None)

    def do(self) -> None:
        self._apply(self.clip_id, self.param, copy.deepcopy(self.after))

    def undo(self) -> None:
        self._apply(self.clip_id, self.param, copy.deepcopy(self.before))
