# -*- coding: utf-8 -*-
"""KI-Audio-Codec — EnCodec Integration + Background Worker.

v0.0.21.024 — Block C Phase C1.1 + C1.3

Wraps Meta's EnCodec for neural audio compression.
Falls back gracefully when encodec/torch not installed.

Usage:
    from pydaw.audio.ki_audio_codec import KiAudioCodec

    codec = KiAudioCodec()
    if codec.is_available:
        codec.compress_file("input.wav", "output.pdac", bitrate=24)
        codec.decompress_file("output.pdac", "output.wav")
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger(__name__)

# Lazy-loaded — don't import torch/encodec at module level
_ENCODEC_AVAILABLE: Optional[bool] = None


def _check_encodec() -> bool:
    global _ENCODEC_AVAILABLE
    if _ENCODEC_AVAILABLE is not None:
        return _ENCODEC_AVAILABLE
    try:
        import torch  # noqa: F401
        import encodec  # noqa: F401
        _ENCODEC_AVAILABLE = True
        log.info("[KI-CODEC] EnCodec + PyTorch available")
    except ImportError:
        _ENCODEC_AVAILABLE = False
        log.info("[KI-CODEC] EnCodec not available (pip install encodec torch)")
    return _ENCODEC_AVAILABLE


# Bitrate → EnCodec bandwidth mapping
_BITRATE_MAP = {
    3: 1.5,    # 1.5 kbps — Transfer quality
    6: 3.0,    # 3.0 kbps — Draft quality
    12: 6.0,   # 6.0 kbps — Production quality
    24: 24.0,  # 24.0 kbps — Studio quality (transparent)
}


class KiAudioCodec:
    """Neural audio codec wrapper (EnCodec backend).

    Thread-safe: each instance loads its own model.
    """

    def __init__(self, device: str = "auto"):
        self._model = None
        self._device_str = device
        self._device = None

    @property
    def is_available(self) -> bool:
        return _check_encodec()

    def _ensure_model(self):
        if self._model is not None:
            return
        if not _check_encodec():
            raise RuntimeError("EnCodec not installed (pip install encodec torch)")

        import torch
        from encodec import EncodecModel

        if self._device_str == "auto":
            self._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self._device = torch.device(self._device_str)

        self._model = EncodecModel.encodec_model_48khz()
        self._model.set_target_bandwidths([1.5, 3.0, 6.0, 12.0, 24.0])
        self._model = self._model.to(self._device)
        self._model.eval()
        log.info("[KI-CODEC] Model loaded on %s", self._device)

    def encode_audio(self, audio_data, sr: int = 48000,
                     bitrate_kbps: int = 24) -> List[bytes]:
        """Encode audio numpy array to codec frames.

        Args:
            audio_data: numpy array (samples, channels) float32
            sr: sample rate
            bitrate_kbps: target bitrate (3, 6, 12, 24)

        Returns:
            List of encoded frame bytes
        """
        self._ensure_model()
        import torch
        import numpy as np

        # Ensure correct shape: (1, channels, samples)
        if audio_data.ndim == 1:
            audio_data = audio_data.reshape(-1, 1)
        if audio_data.shape[1] > audio_data.shape[0]:
            audio_data = audio_data.T  # transpose if channels > samples

        channels = audio_data.shape[1]
        if channels > 2:
            audio_data = audio_data[:, :2]  # max stereo

        # Convert to tensor
        wav = torch.from_numpy(audio_data.astype(np.float32).T).unsqueeze(0)
        wav = wav.to(self._device)

        # Set bandwidth
        bw = _BITRATE_MAP.get(bitrate_kbps, 24.0)
        self._model.set_target_bandwidths([bw])

        # Encode
        with torch.no_grad():
            encoded = self._model.encode(wav)

        # Serialize frames
        frames = []
        for codes in encoded:
            frame_bytes = codes[0].cpu().numpy().tobytes()
            frames.append(frame_bytes)

        return frames

    def decode_frames(self, frames: List[bytes], channels: int = 2) -> Any:
        """Decode codec frames back to audio numpy array.

        Returns:
            numpy array (samples, channels) float32
        """
        self._ensure_model()
        import torch
        import numpy as np

        decoded_chunks = []
        for frame_bytes in frames:
            # Reconstruct tensor from bytes
            codes_np = np.frombuffer(frame_bytes, dtype=np.int64)
            # Shape depends on bandwidth — reshape dynamically
            n_q = len(codes_np) // (len(frame_bytes) // 8 // max(1, codes_np.size // 1000 + 1) + 1)
            try:
                codes = torch.from_numpy(codes_np).reshape(1, -1, n_q).to(self._device)
            except Exception:
                codes = torch.from_numpy(codes_np).unsqueeze(0).unsqueeze(0).to(self._device)

            with torch.no_grad():
                decoded = self._model.decode([(codes, None)])

            chunk = decoded.squeeze(0).cpu().numpy().T  # (samples, channels)
            decoded_chunks.append(chunk)

        if decoded_chunks:
            return np.concatenate(decoded_chunks, axis=0)
        return np.zeros((0, channels), dtype=np.float32)

    def compress_file(self, input_path: str, output_path: str,
                      bitrate_kbps: int = 24,
                      metadata: Optional[Dict[str, Any]] = None) -> Path:
        """Compress an audio file to PDAC format.

        Args:
            input_path: WAV/FLAC/OGG/MP3 input
            output_path: .pdac output
            bitrate_kbps: target bitrate
            metadata: optional metadata dict

        Returns:
            Path to output file
        """
        import numpy as np

        # Load audio
        try:
            import soundfile as sf
            audio, sr = sf.read(input_path, dtype="float32")
        except Exception:
            # Fallback: try scipy
            from scipy.io import wavfile
            sr, audio = wavfile.read(input_path)
            if audio.dtype != np.float32:
                audio = audio.astype(np.float32) / 32768.0

        if audio.ndim == 1:
            audio = audio.reshape(-1, 1)
        channels = min(2, audio.shape[1])
        audio = audio[:, :channels]

        orig_size = audio.nbytes
        duration_ms = int(len(audio) / sr * 1000)

        # Encode
        frames = self.encode_audio(audio, sr=sr, bitrate_kbps=bitrate_kbps)

        # Write PDAC
        from pydaw.audio.pdac_format import PdacWriter
        writer = PdacWriter(output_path, sr=sr, channels=channels, bitrate=bitrate_kbps)
        writer.set_original_info(orig_size, duration_ms)
        if metadata:
            writer.set_metadata(metadata)
        for frame in frames:
            writer.write_frame(frame)
        return writer.close()

    def decompress_file(self, input_path: str, output_path: str) -> Path:
        """Decompress a PDAC file to WAV.

        Args:
            input_path: .pdac input
            output_path: .wav output

        Returns:
            Path to output file
        """
        from pydaw.audio.pdac_format import PdacReader

        with PdacReader(input_path) as reader:
            frames = reader.read_all_frames()
            channels = reader.header.channels
            sr = reader.header.sample_rate

        audio = self.decode_frames(frames, channels=channels)

        try:
            import soundfile as sf
            sf.write(output_path, audio, sr)
        except Exception:
            from scipy.io import wavfile
            import numpy as np
            wavfile.write(output_path, sr, (audio * 32767).astype(np.int16))

        return Path(output_path)


# ── Background Worker ────────────────────────────────────────────────────────

try:
    from PyQt6.QtCore import QObject, QThread, pyqtSignal, QRunnable, QThreadPool

    class KiCompressWorker(QRunnable):
        """Background worker for KI audio compression.

        Usage:
            worker = KiCompressWorker("input.wav", "output.pdac", bitrate=24)
            worker.signals.finished.connect(on_done)
            worker.signals.error.connect(on_error)
            QThreadPool.globalInstance().start(worker)
        """

        class Signals(QObject):
            finished = pyqtSignal(str)   # output path
            error = pyqtSignal(str)      # error message
            progress = pyqtSignal(int)   # 0-100

        def __init__(self, input_path: str, output_path: str,
                     bitrate: int = 24, metadata: Optional[Dict] = None):
            super().__init__()
            self.input_path = input_path
            self.output_path = output_path
            self.bitrate = bitrate
            self.metadata = metadata
            self.signals = self.Signals()

        def run(self):
            try:
                self.signals.progress.emit(10)
                codec = KiAudioCodec()
                self.signals.progress.emit(30)
                result = codec.compress_file(
                    self.input_path, self.output_path,
                    bitrate_kbps=self.bitrate, metadata=self.metadata)
                self.signals.progress.emit(100)
                self.signals.finished.emit(str(result))
            except Exception as e:
                self.signals.error.emit(str(e))

except ImportError:
    KiCompressWorker = None  # type: ignore
