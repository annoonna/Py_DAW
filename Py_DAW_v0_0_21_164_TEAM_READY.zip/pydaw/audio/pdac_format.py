# -*- coding: utf-8 -*-
"""PDAC — PyDAW Audio Compressed (KI-Codec Container).

v0.0.21.024 — Block C Phase C1.2

File format for neural audio codec compressed audio.
Supports EnCodec, SoundStream, and future custom DAC codecs.

Format:
    Header (64 bytes):
        magic:      4 bytes  "PDAC"
        version:    2 bytes  uint16 (1)
        codec_id:   2 bytes  uint16 (0=encodec, 1=soundstream, 2=dac_custom)
        sample_rate: 4 bytes uint32
        channels:   2 bytes  uint16
        bitrate_kbps: 2 bytes uint16
        num_frames: 4 bytes  uint32 (total codec frames)
        duration_ms: 4 bytes uint32
        orig_size:  4 bytes  uint32 (original PCM bytes)
        flags:      2 bytes  uint16 (bit0=has_metadata)
        reserved:   34 bytes
    Metadata (optional, if flags & 1):
        meta_len:   4 bytes uint32
        meta_json:  meta_len bytes UTF-8 JSON
    Body:
        frame_count frames, each:
            frame_len: 4 bytes uint32
            frame_data: frame_len bytes (codec-specific)
    Footer:
        checksum:   4 bytes uint32 (CRC32 of body)

Usage:
    # Write
    writer = PdacWriter("output.pdac", sr=48000, channels=2, bitrate=24)
    writer.set_metadata({"bpm": 120, "key": "C", "tags": ["vocals"]})
    for frame in encoded_frames:
        writer.write_frame(frame)
    writer.close()

    # Read
    reader = PdacReader("output.pdac")
    print(reader.header)  # PdacHeader(...)
    for frame in reader.frames():
        decoded = codec.decode(frame)
"""
from __future__ import annotations

import json
import logging
import struct
import zlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, BinaryIO, Dict, Iterator, List, Optional

log = logging.getLogger(__name__)

PDAC_MAGIC = b"PDAC"
PDAC_VERSION = 1
HEADER_SIZE = 64

# Codec IDs
CODEC_ENCODEC = 0
CODEC_SOUNDSTREAM = 1
CODEC_DAC_CUSTOM = 2
CODEC_DAC_DRUMS = 3
CODEC_DAC_VOCALS = 4
CODEC_DAC_SYNTH = 5

CODEC_NAMES = {
    CODEC_ENCODEC: "encodec",
    CODEC_SOUNDSTREAM: "soundstream",
    CODEC_DAC_CUSTOM: "dac_custom",
    CODEC_DAC_DRUMS: "dac_drums",
    CODEC_DAC_VOCALS: "dac_vocals",
    CODEC_DAC_SYNTH: "dac_synth",
}

# Quality profiles
QUALITY_STUDIO = 24      # kbps — transparent
QUALITY_PRODUCTION = 12  # kbps — excellent
QUALITY_DRAFT = 6        # kbps — good (demos)
QUALITY_TRANSFER = 3     # kbps — acceptable (collab)


@dataclass
class PdacHeader:
    """PDAC file header."""
    version: int = PDAC_VERSION
    codec_id: int = CODEC_ENCODEC
    sample_rate: int = 48000
    channels: int = 2
    bitrate_kbps: int = QUALITY_STUDIO
    num_frames: int = 0
    duration_ms: int = 0
    orig_size: int = 0
    flags: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def codec_name(self) -> str:
        return CODEC_NAMES.get(self.codec_id, f"unknown({self.codec_id})")

    @property
    def compression_ratio(self) -> float:
        if self.orig_size > 0 and self.num_frames > 0:
            # Estimate compressed size from bitrate
            duration_s = self.duration_ms / 1000.0
            compressed_bytes = (self.bitrate_kbps * 1000 / 8) * duration_s
            return self.orig_size / max(1, compressed_bytes)
        return 0.0

    def to_bytes(self) -> bytes:
        """Serialize header to 64 bytes."""
        buf = struct.pack(
            "<4sHHIHHIIIH",
            PDAC_MAGIC,
            self.version,
            self.codec_id,
            self.sample_rate,
            self.channels,
            self.bitrate_kbps,
            self.num_frames,
            self.duration_ms,
            self.orig_size,
            self.flags,
        )
        # Pad to HEADER_SIZE
        buf += b"\x00" * (HEADER_SIZE - len(buf))
        return buf

    @classmethod
    def from_bytes(cls, data: bytes) -> "PdacHeader":
        """Deserialize header from bytes."""
        if len(data) < HEADER_SIZE:
            raise ValueError(f"Header too short: {len(data)} < {HEADER_SIZE}")
        magic = data[:4]
        if magic != PDAC_MAGIC:
            raise ValueError(f"Invalid PDAC magic: {magic!r}")
        (version, codec_id, sample_rate, channels, bitrate_kbps,
         num_frames, duration_ms, orig_size, flags) = struct.unpack(
            "<HHIHHIBIH",  # skipping magic
            data[4:4 + struct.calcsize("<HHIHHIBIH")]
        )
        # Fix: use correct struct format
        vals = struct.unpack_from("<HH I HH I I I H", data, 4)
        return cls(
            version=vals[0],
            codec_id=vals[1],
            sample_rate=vals[2],
            channels=vals[3],
            bitrate_kbps=vals[4],
            num_frames=vals[5],
            duration_ms=vals[6],
            orig_size=vals[7],
            flags=vals[8],
        )


class PdacWriter:
    """Write PDAC files."""

    def __init__(self, path: str | Path, sr: int = 48000,
                 channels: int = 2, bitrate: int = QUALITY_STUDIO,
                 codec_id: int = CODEC_ENCODEC):
        self.path = Path(path)
        self.header = PdacHeader(
            sample_rate=sr,
            channels=channels,
            bitrate_kbps=bitrate,
            codec_id=codec_id,
        )
        self._frames: List[bytes] = []
        self._metadata: Dict[str, Any] = {}
        self._closed = False

    def set_metadata(self, meta: Dict[str, Any]) -> None:
        self._metadata = dict(meta)
        self.header.flags |= 1  # has_metadata

    def write_frame(self, frame_data: bytes) -> None:
        if self._closed:
            raise RuntimeError("Writer is closed")
        self._frames.append(bytes(frame_data))

    def set_original_info(self, orig_size: int, duration_ms: int) -> None:
        self.header.orig_size = orig_size
        self.header.duration_ms = duration_ms

    def close(self) -> Path:
        if self._closed:
            return self.path
        self._closed = True
        self.header.num_frames = len(self._frames)

        with open(self.path, "wb") as f:
            # Header
            f.write(self.header.to_bytes())

            # Metadata
            if self.header.flags & 1:
                meta_json = json.dumps(self._metadata, separators=(",", ":")).encode("utf-8")
                f.write(struct.pack("<I", len(meta_json)))
                f.write(meta_json)

            # Body
            crc = 0
            for frame in self._frames:
                frame_bytes = bytes(frame)
                f.write(struct.pack("<I", len(frame_bytes)))
                f.write(frame_bytes)
                crc = zlib.crc32(frame_bytes, crc)

            # Footer
            f.write(struct.pack("<I", crc & 0xFFFFFFFF))

        log.info(
            "[PDAC] Written: %s (%d frames, %s, %d kbps, ~%.1fx compression)",
            self.path.name, len(self._frames), self.header.codec_name,
            self.header.bitrate_kbps, self.header.compression_ratio,
        )
        return self.path


class PdacReader:
    """Read PDAC files."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._f: Optional[BinaryIO] = None
        self.header: Optional[PdacHeader] = None
        self.metadata: Dict[str, Any] = {}
        self._body_offset: int = 0
        self._open()

    def _open(self) -> None:
        self._f = open(self.path, "rb")
        # Read header
        hdr_bytes = self._f.read(HEADER_SIZE)
        self.header = PdacHeader.from_bytes(hdr_bytes)

        # Read metadata
        if self.header.flags & 1:
            meta_len = struct.unpack("<I", self._f.read(4))[0]
            meta_json = self._f.read(meta_len)
            self.metadata = json.loads(meta_json.decode("utf-8"))

        self._body_offset = self._f.tell()

    def frames(self) -> Iterator[bytes]:
        """Iterate over codec frames."""
        if self._f is None:
            return
        self._f.seek(self._body_offset)
        for _ in range(self.header.num_frames):
            frame_len = struct.unpack("<I", self._f.read(4))[0]
            yield self._f.read(frame_len)

    def read_all_frames(self) -> List[bytes]:
        return list(self.frames())

    def verify_checksum(self) -> bool:
        """Verify CRC32 checksum."""
        crc = 0
        for frame in self.frames():
            crc = zlib.crc32(frame, crc)
        stored_crc = struct.unpack("<I", self._f.read(4))[0]
        return (crc & 0xFFFFFFFF) == stored_crc

    def close(self) -> None:
        if self._f is not None:
            self._f.close()
            self._f = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __repr__(self) -> str:
        if self.header:
            return (
                f"PdacReader({self.path.name}: {self.header.codec_name}, "
                f"{self.header.sample_rate}Hz, {self.header.channels}ch, "
                f"{self.header.bitrate_kbps}kbps, {self.header.num_frames} frames)"
            )
        return f"PdacReader({self.path.name})"


# ── Convenience ──────────────────────────────────────────────────────────────

def is_pdac_file(path: str | Path) -> bool:
    """Check if a file is a PDAC file."""
    try:
        with open(path, "rb") as f:
            return f.read(4) == PDAC_MAGIC
    except Exception:
        return False
