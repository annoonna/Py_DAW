"""Legacy IPC bridge compatibility shim.

Several older service paths still import ``pydaw.audio.ipc_bridge.send_command``.
Route those calls to the current RustEngineBridge without breaking callers.
"""

from __future__ import annotations

from typing import Any, Mapping


def send_command(command: str, payload: Mapping[str, Any] | None = None) -> bool:
    """Forward a legacy command dict to the active Rust bridge.

    Returns ``False`` when the Rust bridge is unavailable instead of raising,
    so older optional features degrade cleanly in Python-only mode.
    """
    from pydaw.services.rust_engine_bridge import RustEngineBridge

    bridge = RustEngineBridge.instance()
    if bridge is None or not getattr(bridge, "is_connected", False):
        return False

    msg = {"cmd": str(command)}
    if payload:
        msg.update(dict(payload))
    return bool(bridge.send_command(msg))
