# -*- coding: utf-8 -*-
"""Multi-Format PDAC Converter — WAV/FLAC/OGG/MP3/AIFF → PDAC.

v0.0.21.026 — Block C Phase C2.1–C2.7

Converts any supported audio format to KI-compressed PDAC.
Supports batch conversion, quality profiles, and optional backup.

Usage:
    from pydaw.audio.pdac_converter import PdacConverter

    conv = PdacConverter()
    conv.convert("song.wav", "song.pdac", quality="studio")
    conv.batch_convert("/path/to/media/", quality="production", keep_originals=True)
"""
from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)

# Supported input formats
SUPPORTED_EXTENSIONS = {
    ".wav", ".flac", ".ogg", ".mp3", ".aiff", ".aif",
    ".m4a", ".wma", ".opus",
}

# Quality profiles (bitrate kbps)
QUALITY_PROFILES = {
    "studio": 24,       # Transparent, ~10x smaller than WAV
    "production": 12,   # Excellent, ~20x smaller
    "draft": 6,         # Good for demos, ~40x smaller
    "transfer": 3,      # Acceptable for collab, ~80x smaller
}


def is_convertible(path: str | Path) -> bool:
    """Check if a file can be converted to PDAC."""
    return Path(path).suffix.lower() in SUPPORTED_EXTENSIONS


class PdacConverter:
    """Convert audio files to PDAC format."""

    def __init__(self):
        self._codec = None

    def _ensure_codec(self):
        if self._codec is not None:
            return self._codec
        from pydaw.audio.ki_audio_codec import KiAudioCodec
        self._codec = KiAudioCodec()
        if not self._codec.is_available:
            raise RuntimeError(
                "EnCodec nicht verfügbar. Installiere: pip install encodec torch torchaudio"
            )
        return self._codec

    def convert(self, input_path: str | Path, output_path: Optional[str | Path] = None,
                quality: str = "studio", keep_original: bool = True,
                metadata: Optional[Dict[str, Any]] = None) -> Path:
        """Convert a single audio file to PDAC.

        Args:
            input_path: Source audio file (WAV/FLAC/OGG/MP3/AIFF)
            output_path: Output .pdac path (default: same name + .pdac)
            quality: "studio", "production", "draft", "transfer"
            keep_original: If True, keep the original file
            metadata: Optional metadata dict (bpm, key, tags)

        Returns:
            Path to output .pdac file
        """
        input_path = Path(input_path)
        if not input_path.exists():
            raise FileNotFoundError(f"Input not found: {input_path}")

        if input_path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            raise ValueError(f"Unsupported format: {input_path.suffix}")

        if output_path is None:
            output_path = input_path.with_suffix(".pdac")
        output_path = Path(output_path)

        bitrate = QUALITY_PROFILES.get(quality, 24)
        codec = self._ensure_codec()

        # Auto-detect metadata from filename
        if metadata is None:
            metadata = {}
        metadata.setdefault("source_format", input_path.suffix.lower())
        metadata.setdefault("source_name", input_path.name)

        # Try to detect BPM from filename (common pattern: "120bpm" or "120_bpm")
        try:
            import re
            bpm_match = re.search(r"(\d{2,3})\s*bpm", input_path.stem, re.IGNORECASE)
            if bpm_match:
                metadata.setdefault("bpm", int(bpm_match.group(1)))
        except Exception:
            pass

        result = codec.compress_file(
            str(input_path), str(output_path),
            bitrate_kbps=bitrate, metadata=metadata,
        )

        # Backup original
        if not keep_original:
            backup_dir = input_path.parent / ".pdac_originals"
            backup_dir.mkdir(exist_ok=True)
            backup_path = backup_dir / input_path.name
            shutil.move(str(input_path), str(backup_path))
            log.info("[PDAC] Original moved to backup: %s", backup_path)

        log.info(
            "[PDAC] Converted: %s → %s (%s, %d kbps)",
            input_path.name, output_path.name, quality, bitrate,
        )
        return result

    def batch_convert(self, directory: str | Path, quality: str = "studio",
                      keep_originals: bool = True, recursive: bool = True,
                      progress_callback: Optional[Callable[[int, int, str], None]] = None,
                      ) -> List[Tuple[Path, Path]]:
        """Convert all audio files in a directory to PDAC.

        Args:
            directory: Source directory
            quality: Quality profile
            keep_originals: Keep original files
            recursive: Search subdirectories
            progress_callback: fn(current, total, filename) for progress updates

        Returns:
            List of (input_path, output_path) tuples for successful conversions
        """
        directory = Path(directory)
        if not directory.is_dir():
            raise NotADirectoryError(f"Not a directory: {directory}")

        # Collect files
        files = []
        pattern = "**/*" if recursive else "*"
        for p in directory.glob(pattern):
            if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS:
                # Skip if .pdac already exists
                pdac_path = p.with_suffix(".pdac")
                if not pdac_path.exists():
                    files.append(p)

        if not files:
            log.info("[PDAC] No convertible files found in %s", directory)
            return []

        log.info("[PDAC] Batch: %d files to convert in %s", len(files), directory)
        results = []
        for i, f in enumerate(files):
            if progress_callback:
                try:
                    progress_callback(i, len(files), f.name)
                except Exception:
                    pass
            try:
                out = self.convert(f, quality=quality, keep_original=keep_originals)
                results.append((f, out))
            except Exception as e:
                log.warning("[PDAC] Failed: %s — %s", f.name, e)

        if progress_callback:
            try:
                progress_callback(len(files), len(files), "Fertig")
            except Exception:
                pass

        log.info("[PDAC] Batch done: %d/%d converted", len(results), len(files))
        return results

    def estimate_savings(self, directory: str | Path,
                         quality: str = "studio") -> Dict[str, Any]:
        """Estimate how much space would be saved by converting to PDAC.

        Returns:
            {"total_files": int, "total_size_mb": float,
             "estimated_pdac_mb": float, "savings_mb": float, "ratio": float}
        """
        directory = Path(directory)
        bitrate = QUALITY_PROFILES.get(quality, 24)
        total_size = 0
        total_files = 0
        total_duration_s = 0.0

        for p in directory.rglob("*"):
            if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS:
                total_files += 1
                total_size += p.stat().st_size
                # Estimate duration from file size (rough: 48kHz stereo float32)
                est_duration = p.stat().st_size / (48000 * 2 * 4)
                total_duration_s += est_duration

        if total_files == 0:
            return {"total_files": 0, "total_size_mb": 0, "estimated_pdac_mb": 0,
                    "savings_mb": 0, "ratio": 0}

        estimated_pdac = (bitrate * 1000 / 8) * total_duration_s
        total_mb = total_size / (1024 * 1024)
        pdac_mb = estimated_pdac / (1024 * 1024)
        savings = total_mb - pdac_mb
        ratio = total_mb / max(0.001, pdac_mb)

        return {
            "total_files": total_files,
            "total_size_mb": round(total_mb, 1),
            "estimated_pdac_mb": round(pdac_mb, 1),
            "savings_mb": round(savings, 1),
            "ratio": round(ratio, 1),
            "quality": quality,
        }


# ── Qt Worker for batch conversion ──────────────────────────────────────────

try:
    from PyQt6.QtCore import QObject, QRunnable, pyqtSignal, QThreadPool

    class BatchConvertWorker(QRunnable):
        """Background worker for batch PDAC conversion."""

        class Signals(QObject):
            progress = pyqtSignal(int, int, str)  # current, total, filename
            finished = pyqtSignal(int, int)         # converted, total
            error = pyqtSignal(str)

        def __init__(self, directory: str, quality: str = "studio",
                     keep_originals: bool = True):
            super().__init__()
            self.directory = directory
            self.quality = quality
            self.keep_originals = keep_originals
            self.signals = self.Signals()

        def run(self):
            try:
                conv = PdacConverter()
                results = conv.batch_convert(
                    self.directory,
                    quality=self.quality,
                    keep_originals=self.keep_originals,
                    progress_callback=lambda c, t, f: self.signals.progress.emit(c, t, f),
                )
                self.signals.finished.emit(len(results), len(results))
            except Exception as e:
                self.signals.error.emit(str(e))

except ImportError:
    BatchConvertWorker = None  # type: ignore
