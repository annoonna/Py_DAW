"""shared_audio_ring.py — Shared Memory Audio Ring Buffer (v0.0.20.982)

Zero-copy audio streaming from Python to Rust via /dev/shm/.

Layout in shared memory:
  Offset 0:   write_pos  (uint64, atomically updated by Python)
  Offset 8:   read_pos   (uint64, atomically updated by Rust)
  Offset 16:  capacity   (uint64, set once at creation)
  Offset 24:  active     (uint8, 1=streaming, 0=stopped)
  Offset 25:  padding    (39 bytes)
  Offset 64:  [float32 samples...] (capacity * 4 bytes)

Total size: 64 + capacity * 4 bytes

Usage:
  ring = SharedAudioRing.create(sample_rate=48000, channels=2, duration_ms=500)
  ring.set_active(True)
  ring.write(numpy_buffer)   # from render callback
  ring.set_active(False)
  ring.close()
"""

import mmap
import os
import struct
import ctypes
import logging

log = logging.getLogger(__name__)

SHM_PATH = "/dev/shm/pydaw_audio_ring"
HEADER_SIZE = 64  # bytes
HEADER_FMT = "<QQQBxxxI"  # write_pos, read_pos, capacity, active, pad, sample_rate
HEADER_STRUCT_SIZE = struct.calcsize(HEADER_FMT)


class SharedAudioRing:
    """Shared memory SPSC ring buffer — Python writes, Rust reads.

    v0.0.20.984: Singleton pattern — reuses existing ring buffer
    instead of creating a new one each Play/Stop cycle.
    Fixes memory leak (+25-36 MB/min from SENTINEL).
    """

    _instance: "SharedAudioRing | None" = None
    _instance_capacity: int = 0

    def __init__(self, mm: mmap.mmap, fd: int, capacity: int):
        self._mm = mm
        self._fd = fd
        self._capacity = capacity
        self._mask = capacity - 1  # power of 2

    @classmethod
    def create(cls, sample_rate: int = 48000, channels: int = 2,
               duration_ms: int = 500) -> "SharedAudioRing":
        """Create or reuse shared memory ring buffer.

        v0.0.20.984: Singleton — reuses existing ring if capacity matches.
        Fixes memory leak from creating new mmap each Play/Stop cycle.
        
        Returns a SharedAudioRing ready for writing.
        Rust side opens the same file for reading.
        """
        raw_cap = (sample_rate * channels * duration_ms) // 1000
        # Round up to power of 2
        capacity = 1
        while capacity < raw_cap:
            capacity <<= 1
        capacity = max(capacity, 8192)

        # v0.0.20.984: Reuse existing ring if same capacity
        if (cls._instance is not None
                and cls._instance_capacity == capacity
                and cls._instance._mm is not None):
            ring = cls._instance
            ring.reset()
            log.info(
                "[SharedAudioRing] Reused: %s, capacity=%d samples",
                SHM_PATH, capacity,
            )
            return ring

        # Close old instance if exists (different capacity)
        if cls._instance is not None:
            try:
                cls._instance._close_internal()
            except Exception:
                pass
            cls._instance = None

        total_size = HEADER_SIZE + capacity * 4  # 4 bytes per f32

        # Create/open the shared memory file
        fd = os.open(SHM_PATH, os.O_RDWR | os.O_CREAT | os.O_TRUNC, 0o666)
        os.ftruncate(fd, total_size)

        mm = mmap.mmap(fd, total_size, mmap.MAP_SHARED,
                       mmap.PROT_READ | mmap.PROT_WRITE)

        # Write header
        header = struct.pack("<QQQ", 0, 0, capacity)  # write_pos=0, read_pos=0, cap
        mm[0:24] = header
        mm[24] = 0  # active = false
        # Zero the data area
        mm[HEADER_SIZE:total_size] = b'\x00' * (capacity * 4)

        log.info(
            "[SharedAudioRing] Created: %s, capacity=%d samples (%.0fms), size=%d bytes",
            SHM_PATH, capacity, duration_ms, total_size
        )

        ring = cls(mm, fd, capacity)
        cls._instance = ring
        cls._instance_capacity = capacity
        return ring

    @classmethod
    def open_existing(cls) -> "SharedAudioRing":
        """Open an existing shared memory ring (for reconnect)."""
        fd = os.open(SHM_PATH, os.O_RDWR, 0o666)
        size = os.fstat(fd).st_size
        mm = mmap.mmap(fd, size, mmap.MAP_SHARED,
                       mmap.PROT_READ | mmap.PROT_WRITE)
        # Read capacity from header
        capacity = struct.unpack_from("<Q", mm, 16)[0]
        return cls(mm, fd, capacity)

    def _read_write_pos(self) -> int:
        return struct.unpack_from("<Q", self._mm, 0)[0]

    def _write_write_pos(self, pos: int):
        struct.pack_into("<Q", self._mm, 0, pos)

    def _read_read_pos(self) -> int:
        return struct.unpack_from("<Q", self._mm, 8)[0]

    def available(self) -> int:
        w = self._read_write_pos()
        r = self._read_read_pos()
        return (w - r) & 0xFFFFFFFFFFFFFFFF  # wrapping subtract

    def free_space(self) -> int:
        return self._capacity - self.available() - 1

    def write(self, samples) -> int:
        """Write numpy float32 samples into the ring buffer.
        
        Args:
            samples: numpy array (frames, 2) or flat interleaved float32
            
        Returns: number of samples written
        """
        import numpy as np
        if isinstance(samples, np.ndarray):
            if samples.ndim == 2:
                samples = samples.flatten()
            if samples.dtype != np.float32:
                samples = samples.astype(np.float32)
        else:
            samples = np.array(samples, dtype=np.float32)

        n = len(samples)
        free = self.free_space()
        to_write = min(n, free)
        if to_write == 0:
            return 0

        w = self._read_write_pos()
        raw_bytes = samples[:to_write].tobytes()

        # Write in up to 2 chunks (wrap around)
        offset1 = (w & self._mask)
        chunk1 = min(to_write, self._capacity - offset1)
        start1 = HEADER_SIZE + offset1 * 4
        self._mm[start1:start1 + chunk1 * 4] = raw_bytes[:chunk1 * 4]

        if chunk1 < to_write:
            chunk2 = to_write - chunk1
            start2 = HEADER_SIZE
            self._mm[start2:start2 + chunk2 * 4] = raw_bytes[chunk1 * 4:]

        # Update write position (wrapping add)
        new_w = (w + to_write) & 0xFFFFFFFFFFFFFFFF
        self._write_write_pos(new_w)

        return to_write

    def set_active(self, active: bool):
        """Set streaming active flag."""
        if not active:
            # Clear buffer
            self._write_write_pos(0)
            struct.pack_into("<Q", self._mm, 8, 0)  # reset read_pos too
        self._mm[24] = 1 if active else 0

    def is_active(self) -> bool:
        return self._mm[24] != 0

    def close(self):
        """Stop streaming but keep the ring alive for reuse.

        v0.0.20.984: No longer destroys the ring — just deactivates.
        Use cleanup() to fully remove shared memory.
        """
        try:
            self.set_active(False)
        except Exception:
            pass

    def _close_internal(self):
        """Actually close mmap and fd (called when capacity changes)."""
        try:
            self.set_active(False)
            self._mm.close()
            os.close(self._fd)
            self._mm = None
        except Exception:
            pass

    def reset(self):
        """Reset ring pointers for reuse (no reallocation).

        v0.0.20.984: Called by create() when reusing existing ring.
        """
        try:
            self.set_active(False)
            # Reset write and read positions to 0
            struct.pack_into("<Q", self._mm, 0, 0)  # write_pos = 0
            struct.pack_into("<Q", self._mm, 8, 0)  # read_pos = 0
        except Exception:
            pass

    @staticmethod
    def cleanup():
        """Remove the shared memory file."""
        try:
            os.unlink(SHM_PATH)
        except FileNotFoundError:
            pass

    @staticmethod
    def path() -> str:
        return SHM_PATH
