"""variations_generator.py — MIDI Clip Variations Generator.

v0.0.20.909 — C4.2: KI-Kompositions-Feature.

Generates 4 musical variations from an existing MIDI clip:
1. Transposition — shift pitch by interval
2. Rhythm Shift — shift note starts by grid amount
3. Velocity Humanize — randomize velocity within range
4. Inversion — mirror pitches around axis

Usage:
    from pydaw.services.variations_generator import VariationsGenerator

    gen = VariationsGenerator()
    variations = gen.generate(notes, variation_type="all")
    # → {"transpose": [...], "rhythm": [...], "humanize": [...], "invert": [...]}

    # Or specific:
    transposed = gen.transpose(notes, semitones=7)
    rhythmed = gen.rhythm_shift(notes, shift_beats=0.5)
    humanized = gen.humanize_velocity(notes, range_pct=20)
    inverted = gen.invert(notes, axis_pitch=60)
"""

from __future__ import annotations

import copy
import logging
import random
from dataclasses import asdict
from typing import Dict, List, Optional

log = logging.getLogger(__name__)


class VariationsGenerator:
    """Generate musical variations of MIDI note sequences."""

    def __init__(self, seed: Optional[int] = None):
        self._rng = random.Random(seed)

    # ── Main API ────────────────────────────────────────────────────

    def generate_all(
        self,
        notes: list,
        semitones: int = 7,
        shift_beats: float = 0.5,
        velocity_range_pct: int = 20,
        axis_pitch: Optional[int] = None,
    ) -> Dict[str, list]:
        """Generate all 4 variations at once.

        Args:
            notes: List of MidiNote objects (or dicts with pitch, start_beats, etc.)
            semitones: Transpose interval (default: perfect 5th up)
            shift_beats: Rhythm shift amount (default: 0.5 = eighth note)
            velocity_range_pct: Velocity randomization range (±%)
            axis_pitch: Inversion axis (None = auto-detect middle)

        Returns:
            Dict with keys "transpose", "rhythm", "humanize", "invert",
            each containing a list of MidiNote-compatible objects.
        """
        return {
            "transpose": self.transpose(notes, semitones),
            "rhythm": self.rhythm_shift(notes, shift_beats),
            "humanize": self.humanize_velocity(notes, velocity_range_pct),
            "invert": self.invert(notes, axis_pitch),
        }

    def transpose(self, notes: list, semitones: int = 7) -> list:
        """Transpose all notes by a fixed interval.

        Common intervals:
            ±12 = octave, ±7 = perfect 5th, ±5 = perfect 4th,
            ±3/4 = minor/major 3rd, ±2 = whole step
        """
        result = []
        for note in notes:
            n = self._clone(note)
            old_pitch = self._get(n, "pitch", 60)
            new_pitch = max(0, min(127, old_pitch + semitones))
            self._set(n, "pitch", new_pitch)
            result.append(n)
        return result

    def rhythm_shift(self, notes: list, shift_beats: float = 0.5) -> list:
        """Shift all note start times by a fixed amount.

        Can create interesting syncopation. Wraps around if shift
        would make notes go before beat 0.
        """
        result = []
        for note in notes:
            n = self._clone(note)
            old_start = self._get(n, "start_beats", 0.0)
            new_start = max(0.0, old_start + shift_beats)
            self._set(n, "start_beats", new_start)
            result.append(n)
        return result

    def humanize_velocity(self, notes: list, range_pct: int = 20) -> list:
        """Randomize velocity within ±range_pct of original value.

        Creates a more natural, human feel. Preserves relative dynamics.
        """
        result = []
        for note in notes:
            n = self._clone(note)
            vel = self._get(n, "velocity", 100)
            delta_max = max(1, int(vel * range_pct / 100))
            delta = self._rng.randint(-delta_max, delta_max)
            new_vel = max(1, min(127, vel + delta))
            self._set(n, "velocity", new_vel)
            result.append(n)
        return result

    def invert(self, notes: list, axis_pitch: Optional[int] = None) -> list:
        """Mirror all pitches around an axis point.

        If no axis given, uses the midpoint between highest and lowest notes.
        Creates contrary motion — melodies go in opposite direction.
        """
        if not notes:
            return []

        pitches = [self._get(n, "pitch", 60) for n in notes]
        if axis_pitch is None:
            axis_pitch = (min(pitches) + max(pitches)) // 2

        result = []
        for note in notes:
            n = self._clone(note)
            old_pitch = self._get(n, "pitch", 60)
            # Mirror: new = axis - (old - axis) = 2*axis - old
            new_pitch = max(0, min(127, 2 * axis_pitch - old_pitch))
            self._set(n, "pitch", new_pitch)
            result.append(n)
        return result

    # ── Advanced Variations ────────────────────────────────────────

    def retrograde(self, notes: list) -> list:
        """Reverse the order of notes (retrograde).

        Start times are recalculated so the last note becomes the first.
        """
        if not notes:
            return []

        cloned = [self._clone(n) for n in notes]
        # Find total duration
        max_end = max(
            self._get(n, "start_beats", 0.0) + self._get(n, "length_beats", 1.0)
            for n in cloned
        )

        result = []
        for n in cloned:
            old_start = self._get(n, "start_beats", 0.0)
            length = self._get(n, "length_beats", 1.0)
            new_start = max(0.0, max_end - old_start - length)
            self._set(n, "start_beats", new_start)
            result.append(n)

        result.sort(key=lambda x: self._get(x, "start_beats", 0.0))
        return result

    def augmentation(self, notes: list, factor: float = 2.0) -> list:
        """Scale note durations and start times by a factor.

        factor=2.0 → twice as slow (augmentation)
        factor=0.5 → twice as fast (diminution)
        """
        result = []
        for note in notes:
            n = self._clone(note)
            self._set(n, "start_beats",
                       self._get(n, "start_beats", 0.0) * factor)
            self._set(n, "length_beats",
                       max(0.125, self._get(n, "length_beats", 1.0) * factor))
            result.append(n)
        return result

    def shuffle_rhythm(self, notes: list) -> list:
        """Keep pitches but randomize the rhythmic positions.

        Takes existing start_beats values and shuffles them between notes.
        """
        if len(notes) < 2:
            return [self._clone(n) for n in notes]

        cloned = [self._clone(n) for n in notes]
        starts = [self._get(n, "start_beats", 0.0) for n in cloned]
        self._rng.shuffle(starts)

        result = []
        for n, new_start in zip(cloned, starts):
            self._set(n, "start_beats", new_start)
            result.append(n)

        result.sort(key=lambda x: self._get(x, "start_beats", 0.0))
        return result

    # ── Helpers ─────────────────────────────────────────────────────

    def _clone(self, note):
        """Deep copy a note (works with MidiNote dataclass or dict)."""
        if hasattr(note, '__dataclass_fields__'):
            return copy.deepcopy(note)
        elif isinstance(note, dict):
            return dict(note)
        else:
            return copy.deepcopy(note)

    def _get(self, note, attr: str, default):
        """Get attribute from note (dataclass or dict)."""
        if isinstance(note, dict):
            return note.get(attr, default)
        return getattr(note, attr, default)

    def _set(self, note, attr: str, value):
        """Set attribute on note (dataclass or dict)."""
        if isinstance(note, dict):
            note[attr] = value
        else:
            setattr(note, attr, value)
