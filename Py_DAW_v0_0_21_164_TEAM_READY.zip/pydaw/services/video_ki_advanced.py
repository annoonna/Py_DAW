"""video_ki_advanced.py — VP9: Fortgeschrittene Video-KI (v0.0.20.925).

Erweiterte KI-Analyse für Video-Clips:
- Gesichtserkennung → automatische Sprecher-Labels
- Bewegungserkennung → "Action" vs "Dialog" Klassifikation
- Emotionserkennung → feinere Mood-Analyse pro Person
- Style Transfer → filmische Stil-Vorschläge (Hitchcock, Wes Anderson, etc.)
- KI-gesteuerte Schnittreihenfolge (Re-Edit Vorschläge)

Architektur:
    - Nutzt OpenCV (cv2) für Gesichts-/Bewegungserkennung (falls installiert)
    - Fallback auf Frame-Differenz-Analyse wenn OpenCV fehlt
    - Ergebnisse werden in SQLite gecached
    - Alle Funktionen sind optional und degradieren graceful

Usage:
    from pydaw.services.video_ki_advanced import AdvancedVideoKI

    ki = AdvancedVideoKI.instance()
    faces = ki.detect_faces(video_path, scene)
    motion = ki.classify_motion(video_path, scene)
    emotion = ki.analyze_emotion(scene, faces)
    style = ki.suggest_style(scenes)
    reedit = ki.suggest_reedit(scenes, moods)
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import subprocess
import tempfile
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


# ── Data Classes ────────────────────────────────────────────────


@dataclass
class FaceDetection:
    """A detected face in a video frame."""
    frame_time: float = 0.0       # seconds into video
    x: int = 0                     # bounding box
    y: int = 0
    width: int = 0
    height: int = 0
    confidence: float = 0.0
    speaker_label: str = ""        # auto-assigned: "Sprecher A", "Sprecher B"
    face_id: int = -1              # cluster ID for same person across frames

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> FaceDetection:
        return cls(**{k: d[k] for k in cls.__dataclass_fields__ if k in d})


@dataclass
class MotionProfile:
    """Motion classification for a scene."""
    scene_index: int = 0
    motion_level: float = 0.0      # 0.0 (static) .. 1.0 (extreme motion)
    classification: str = "dialog"  # "static", "dialog", "action", "transition"
    avg_optical_flow: float = 0.0
    cut_count: int = 0             # number of cuts within scene
    camera_movement: str = "static"  # "static", "pan", "tilt", "zoom", "tracking"

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> MotionProfile:
        return cls(**{k: d[k] for k in cls.__dataclass_fields__ if k in d})


@dataclass
class EmotionProfile:
    """Emotion classification for a scene (based on color, motion, faces)."""
    scene_index: int = 0
    primary_emotion: str = "neutral"  # "joy", "sadness", "tension", "anger", "fear", "surprise", "neutral"
    intensity: float = 0.5           # 0.0 .. 1.0
    valence: float = 0.0            # -1.0 (negative) .. 1.0 (positive)
    arousal: float = 0.5            # 0.0 (calm) .. 1.0 (excited)
    face_emotions: List[str] = field(default_factory=list)  # per-face if detected

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> EmotionProfile:
        return cls(**{k: d[k] for k in cls.__dataclass_fields__ if k in d})


@dataclass
class StyleSuggestion:
    """Cinematic style suggestion for a scene or project."""
    style_name: str = ""           # "Film Noir", "Wes Anderson", etc.
    description: str = ""
    filter_preset: str = ""        # VP6 preset name to apply
    music_genre: str = ""          # suggested music style
    pacing: str = "moderate"       # "slow", "moderate", "fast", "frenetic"
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ReEditSuggestion:
    """AI suggestion for re-ordering or modifying the edit."""
    suggestion_type: str = ""      # "reorder", "trim", "extend", "cut", "transition"
    description: str = ""
    scene_indices: List[int] = field(default_factory=list)
    new_order: List[int] = field(default_factory=list)  # for reorder
    trim_seconds: float = 0.0      # for trim
    confidence: float = 0.0
    rationale: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


# ── Cinematic Style Database ───────────────────────────────────

CINEMATIC_STYLES = {
    "Film Noir": {
        "description": "Hoher Kontrast, tiefe Schatten, dramatische Beleuchtung",
        "filter_preset": "Film Noir",
        "music_genre": "Jazz / Dark Ambient",
        "pacing": "slow",
        "indicators": {"brightness": "low", "contrast": "high", "saturation": "low",
                       "motion": "low", "emotion": "tension"},
    },
    "Wes Anderson": {
        "description": "Symmetrische Komposition, Pastellfarben, skurriler Humor",
        "filter_preset": "Vintage 8mm",
        "music_genre": "Indie Folk / Baroque Pop",
        "pacing": "moderate",
        "indicators": {"brightness": "medium", "contrast": "medium", "saturation": "high",
                       "motion": "low", "emotion": "neutral"},
    },
    "Hitchcock Suspense": {
        "description": "Langsamer Aufbau, plötzliche Schnitte, unruhige Kamera",
        "filter_preset": "High Contrast",
        "music_genre": "Orchestral Suspense / Strings",
        "pacing": "slow",
        "indicators": {"brightness": "low", "contrast": "high", "saturation": "low",
                       "motion": "medium", "emotion": "tension"},
    },
    "Michael Bay Action": {
        "description": "Schnelle Schnitte, warme Farben, viel Bewegung",
        "filter_preset": "Warm Sunset",
        "music_genre": "Epic Orchestral / EDM",
        "pacing": "frenetic",
        "indicators": {"brightness": "high", "contrast": "high", "saturation": "high",
                       "motion": "high", "emotion": "joy"},
    },
    "Terrence Malick": {
        "description": "Natürliches Licht, poetische Bilder, fließende Kamera",
        "filter_preset": "Soft Dreamy",
        "music_genre": "Classical / Ambient",
        "pacing": "slow",
        "indicators": {"brightness": "high", "contrast": "low", "saturation": "medium",
                       "motion": "low", "emotion": "neutral"},
    },
    "David Fincher": {
        "description": "Kühle Farbpalette, präzise Kameraführung, düster",
        "filter_preset": "Cool Blue",
        "music_genre": "Industrial / Electronic",
        "pacing": "moderate",
        "indicators": {"brightness": "low", "contrast": "medium", "saturation": "low",
                       "motion": "medium", "emotion": "tension"},
    },
    "Wong Kar-Wai": {
        "description": "Gesättigte Farben, Slow-Motion, romantische Stimmung",
        "filter_preset": "Warm Sunset",
        "music_genre": "Lounge / World Music",
        "pacing": "slow",
        "indicators": {"brightness": "medium", "contrast": "medium", "saturation": "high",
                       "motion": "low", "emotion": "sadness"},
    },
    "Edgar Wright": {
        "description": "Schnelle Schnitte, visueller Humor, rhythmische Montage",
        "filter_preset": "High Contrast",
        "music_genre": "Rock / Punk / Pop",
        "pacing": "frenetic",
        "indicators": {"brightness": "high", "contrast": "high", "saturation": "high",
                       "motion": "high", "emotion": "joy"},
    },
}


# ── Main Service ───────────────────────────────────────────────


class AdvancedVideoKI:
    """VP9: Fortgeschrittene Video-KI Service.

    Singleton. Alle Methoden degradieren graceful wenn Abhängigkeiten fehlen.
    """

    _instance: Optional[AdvancedVideoKI] = None

    @classmethod
    def instance(cls) -> AdvancedVideoKI:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._cv2_available: Optional[bool] = None
        self._face_cascade = None
        self._cache: Dict[str, Any] = {}
        self._tmp_dir = os.path.join(tempfile.gettempdir(), "pydaw_vki_adv")
        os.makedirs(self._tmp_dir, exist_ok=True)

    def _check_cv2(self) -> bool:
        """Check if OpenCV is available."""
        if self._cv2_available is not None:
            return self._cv2_available
        try:
            import cv2  # noqa: F401
            self._cv2_available = True
            log.info("[VP9] OpenCV available: %s", cv2.__version__)
        except ImportError:
            self._cv2_available = False
            log.info("[VP9] OpenCV not available — using fallback analysis")
        return self._cv2_available

    def _get_face_cascade(self):
        """Get or create Haar cascade for face detection."""
        if self._face_cascade is not None:
            return self._face_cascade
        try:
            import cv2
            cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
            if os.path.isfile(cascade_path):
                self._face_cascade = cv2.CascadeClassifier(cascade_path)
                return self._face_cascade
        except Exception:
            pass
        return None

    # ── Face Detection ───────────────────────────────────────

    def detect_faces(self, video_path: str, scene=None,
                     sample_interval: float = 1.0) -> List[FaceDetection]:
        """Detect faces in a video scene.

        Args:
            video_path: Path to video file
            scene: VideoScene object (optional, for time range)
            sample_interval: Seconds between sampled frames

        Returns: List of FaceDetection objects
        """
        if not self._check_cv2():
            return self._detect_faces_fallback(video_path, scene)

        try:
            import cv2

            cascade = self._get_face_cascade()
            if cascade is None:
                return []

            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                return []

            fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
            start_s = float(getattr(scene, 'start_seconds', 0)) if scene else 0.0
            end_s = float(getattr(scene, 'end_seconds', 0)) if scene else 0.0
            if end_s <= start_s:
                end_s = cap.get(cv2.CAP_PROP_FRAME_COUNT) / fps

            faces: List[FaceDetection] = []
            t = start_s
            speaker_counter = 0
            seen_faces: Dict[int, str] = {}  # rough face cluster → label

            while t < end_s:
                cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
                ret, frame = cap.read()
                if not ret:
                    break

                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                detected = cascade.detectMultiScale(
                    gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30)
                )

                for (x, y, w, h) in detected:
                    # Simple face clustering by position (rough)
                    cx, cy = x + w // 2, y + h // 2
                    cluster_key = (cx // 80, cy // 80)  # grid-based
                    cluster_id = hash(cluster_key) % 10000

                    if cluster_id not in seen_faces:
                        speaker_counter += 1
                        label = chr(64 + min(speaker_counter, 26))  # A, B, C...
                        seen_faces[cluster_id] = f"Sprecher {label}"

                    faces.append(FaceDetection(
                        frame_time=round(t, 2),
                        x=int(x), y=int(y),
                        width=int(w), height=int(h),
                        confidence=0.8,
                        speaker_label=seen_faces[cluster_id],
                        face_id=cluster_id,
                    ))

                t += sample_interval

            cap.release()
            log.info("[VP9] Detected %d faces in %d samples", len(faces),
                     int((end_s - start_s) / sample_interval))
            return faces

        except Exception as e:
            log.debug("[VP9] Face detection error: %s", e)
            return []

    def _detect_faces_fallback(self, video_path: str, scene=None) -> List[FaceDetection]:
        """Fallback face detection without OpenCV — returns empty (placeholder)."""
        return []

    # ── Motion Classification ────────────────────────────────

    def classify_motion(self, video_path: str, scene=None,
                        sample_interval: float = 0.5) -> MotionProfile:
        """Classify motion level in a scene.

        Uses frame differencing to estimate optical flow.
        """
        scene_idx = int(getattr(scene, 'index', 0)) if scene else 0
        profile = MotionProfile(scene_index=scene_idx)

        if not self._check_cv2():
            return self._classify_motion_fallback(video_path, scene)

        try:
            import cv2
            import numpy as np

            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                return profile

            fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
            start_s = float(getattr(scene, 'start_seconds', 0)) if scene else 0.0
            end_s = float(getattr(scene, 'end_seconds', 0)) if scene else 0.0
            if end_s <= start_s:
                end_s = cap.get(cv2.CAP_PROP_FRAME_COUNT) / fps

            prev_gray = None
            diffs = []
            t = start_s

            while t < end_s:
                cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
                ret, frame = cap.read()
                if not ret:
                    break

                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                gray = cv2.resize(gray, (160, 90))  # low-res for speed

                if prev_gray is not None:
                    diff = cv2.absdiff(prev_gray, gray)
                    mean_diff = float(np.mean(diff)) / 255.0
                    diffs.append(mean_diff)

                prev_gray = gray
                t += sample_interval

            cap.release()

            if diffs:
                import statistics
                avg = statistics.mean(diffs)
                profile.avg_optical_flow = round(avg, 4)
                profile.motion_level = round(min(1.0, avg * 10), 3)

                # Classify
                if avg < 0.01:
                    profile.classification = "static"
                    profile.camera_movement = "static"
                elif avg < 0.03:
                    profile.classification = "dialog"
                    profile.camera_movement = "static"
                elif avg < 0.08:
                    profile.classification = "dialog"
                    profile.camera_movement = "pan"
                elif avg < 0.15:
                    profile.classification = "action"
                    profile.camera_movement = "tracking"
                else:
                    profile.classification = "action"
                    profile.camera_movement = "tracking"

                # Count "cuts" (sudden large changes)
                threshold = max(0.05, avg * 3)
                profile.cut_count = sum(1 for d in diffs if d > threshold)

            log.info("[VP9] Motion: %s (level=%.3f, flow=%.4f, cuts=%d)",
                     profile.classification, profile.motion_level,
                     profile.avg_optical_flow, profile.cut_count)

        except Exception as e:
            log.debug("[VP9] Motion classification error: %s", e)

        return profile

    def _classify_motion_fallback(self, video_path: str, scene=None) -> MotionProfile:
        """Fallback: estimate motion from scene metadata only."""
        scene_idx = int(getattr(scene, 'index', 0)) if scene else 0
        duration = float(getattr(scene, 'duration', 5)) if scene else 5.0
        brightness = float(getattr(scene, 'brightness', 0.5)) if scene else 0.5

        # Heuristic: short scenes tend to be action, long scenes dialog
        if duration < 2.0:
            cls = "transition"
            level = 0.8
        elif duration < 5.0:
            cls = "action"
            level = 0.6
        elif duration > 15.0:
            cls = "static"
            level = 0.15
        else:
            cls = "dialog"
            level = 0.3

        return MotionProfile(
            scene_index=scene_idx,
            motion_level=level,
            classification=cls,
        )

    # ── Emotion Analysis ─────────────────────────────────────

    def analyze_emotion(self, scene=None, faces: List[FaceDetection] = None,
                        motion: MotionProfile = None,
                        mood=None) -> EmotionProfile:
        """Analyze emotional tone of a scene.

        Combines color analysis (from VKI mood), motion profile, and face count.
        """
        scene_idx = int(getattr(scene, 'index', 0)) if scene else 0
        profile = EmotionProfile(scene_index=scene_idx)

        try:
            # Start from VKI mood if available
            if mood:
                brightness = float(getattr(mood, 'brightness', 0.5))
                warmth = float(getattr(mood, 'warmth', 0.5))
                tempo = float(getattr(mood, 'tempo_suggestion', 120))

                # Map color/tempo to valence/arousal
                profile.valence = round((warmth - 0.5) * 2, 3)  # warm = positive
                profile.arousal = round(min(1.0, tempo / 180.0), 3)

            # Modify with motion
            if motion:
                if motion.classification == "action":
                    profile.arousal = min(1.0, profile.arousal + 0.3)
                elif motion.classification == "static":
                    profile.arousal = max(0.0, profile.arousal - 0.2)

            # Classify emotion from valence + arousal (Russell's circumplex)
            v, a = profile.valence, profile.arousal
            if v > 0.3 and a > 0.5:
                profile.primary_emotion = "joy"
            elif v > 0.3 and a <= 0.5:
                profile.primary_emotion = "neutral"
            elif v < -0.3 and a > 0.5:
                profile.primary_emotion = "anger"
            elif v < -0.3 and a <= 0.5:
                profile.primary_emotion = "sadness"
            elif abs(v) <= 0.3 and a > 0.7:
                profile.primary_emotion = "surprise"
            elif abs(v) <= 0.3 and a > 0.4:
                profile.primary_emotion = "tension"
            else:
                profile.primary_emotion = "neutral"

            profile.intensity = round(abs(v) * 0.5 + a * 0.5, 3)

            # Face-based emotion (placeholder — real implementation needs DNN)
            n_faces = len(faces) if faces else 0
            if n_faces > 3:
                profile.face_emotions = ["group interaction"]
            elif n_faces > 0:
                profile.face_emotions = [f"{n_faces} face(s) detected"]

        except Exception as e:
            log.debug("[VP9] Emotion analysis error: %s", e)

        return profile

    # ── Style Suggestion ─────────────────────────────────────

    def suggest_style(self, scenes: list, moods: list = None,
                      motions: List[MotionProfile] = None) -> List[StyleSuggestion]:
        """Suggest cinematic styles based on overall video characteristics.

        Analyzes aggregate color, motion, and mood across all scenes.
        Returns top 3 style matches.
        """
        suggestions = []

        try:
            # Aggregate scene properties
            n = max(1, len(scenes))
            avg_brightness = 0.5
            avg_warmth = 0.5
            avg_motion = 0.3
            dominant_emotion = "neutral"

            if moods:
                brights = [float(getattr(m, 'brightness', 0.5)) for m in moods]
                warms = [float(getattr(m, 'warmth', 0.5)) for m in moods]
                avg_brightness = sum(brights) / len(brights)
                avg_warmth = sum(warms) / len(warms)

            if motions:
                levels = [m.motion_level for m in motions]
                avg_motion = sum(levels) / len(levels)
                # Dominant classification
                cls_counts = {}
                for m in motions:
                    cls_counts[m.classification] = cls_counts.get(m.classification, 0) + 1
                dominant_emotion = max(cls_counts, key=cls_counts.get)

            # Quantize to indicators
            def _level(val):
                if val < 0.33:
                    return "low"
                elif val < 0.66:
                    return "medium"
                return "high"

            brightness_level = _level(avg_brightness)
            contrast_level = "high" if abs(avg_brightness - 0.5) > 0.2 else "medium"
            saturation_level = _level(avg_warmth)
            motion_level = _level(avg_motion)

            # Score each style
            for name, style_info in CINEMATIC_STYLES.items():
                indicators = style_info["indicators"]
                score = 0.0
                total = 0.0

                matches = {
                    "brightness": (brightness_level, indicators.get("brightness", "")),
                    "contrast": (contrast_level, indicators.get("contrast", "")),
                    "saturation": (saturation_level, indicators.get("saturation", "")),
                    "motion": (motion_level, indicators.get("motion", "")),
                }

                for key, (actual, expected) in matches.items():
                    total += 1.0
                    if actual == expected:
                        score += 1.0
                    elif abs(["low", "medium", "high"].index(actual) -
                             ["low", "medium", "high"].index(expected)) == 1:
                        score += 0.4

                confidence = round(score / max(1, total), 3)
                suggestions.append(StyleSuggestion(
                    style_name=name,
                    description=style_info["description"],
                    filter_preset=style_info["filter_preset"],
                    music_genre=style_info["music_genre"],
                    pacing=style_info["pacing"],
                    confidence=confidence,
                ))

            # Sort by confidence
            suggestions.sort(key=lambda s: s.confidence, reverse=True)

            log.info("[VP9] Style suggestions: %s",
                     [(s.style_name, s.confidence) for s in suggestions[:3]])

        except Exception as e:
            log.debug("[VP9] Style suggestion error: %s", e)

        return suggestions[:3]

    # ── Re-Edit Suggestions ──────────────────────────────────

    def suggest_reedit(self, scenes: list, moods: list = None,
                       motions: List[MotionProfile] = None) -> List[ReEditSuggestion]:
        """Suggest editorial improvements based on pacing and flow analysis.

        Analyzes scene order, duration, and emotional arc to suggest:
        - Scene reordering for better narrative flow
        - Trimming of too-long scenes
        - Cutting suggestions for better pacing
        """
        suggestions = []

        try:
            if not scenes or len(scenes) < 2:
                return suggestions

            durations = [float(getattr(s, 'duration', 5)) for s in scenes]
            avg_duration = sum(durations) / len(durations)

            # 1. Find scenes that are too long (>2x average)
            for i, dur in enumerate(durations):
                if dur > avg_duration * 2.5 and dur > 10:
                    suggestions.append(ReEditSuggestion(
                        suggestion_type="trim",
                        description=f"Szene {i+1} ist {dur:.1f}s lang "
                                    f"(Durchschnitt: {avg_duration:.1f}s) — kürzen?",
                        scene_indices=[i],
                        trim_seconds=round(dur - avg_duration * 1.5, 1),
                        confidence=0.7,
                        rationale="Überlange Szenen können das Pacing stören",
                    ))

            # 2. Find scenes that are very short (<1s) — possible flash cuts
            short_streak = []
            for i, dur in enumerate(durations):
                if dur < 1.0:
                    short_streak.append(i)
                else:
                    if len(short_streak) >= 3:
                        suggestions.append(ReEditSuggestion(
                            suggestion_type="trim",
                            description=f"Szenen {short_streak[0]+1}-{short_streak[-1]+1}: "
                                        f"{len(short_streak)} sehr kurze Schnitte — "
                                        f"zu unruhig?",
                            scene_indices=list(short_streak),
                            confidence=0.5,
                            rationale="Viele kurze Schnitte können desorientieren",
                        ))
                    short_streak = []

            # 3. Emotional arc analysis — suggest climax placement
            if moods and len(moods) >= 4:
                tempos = [float(getattr(m, 'tempo_suggestion', 120)) for m in moods]
                max_tempo_idx = tempos.index(max(tempos))
                total = len(tempos)

                # Ideal climax at ~75% (3-act structure)
                ideal_pos = int(total * 0.75)
                if abs(max_tempo_idx - ideal_pos) > total * 0.2:
                    suggestions.append(ReEditSuggestion(
                        suggestion_type="reorder",
                        description=f"Der Höhepunkt (Szene {max_tempo_idx+1}) "
                                    f"liegt bei {max_tempo_idx*100//total}% — "
                                    f"besser bei ~75%?",
                        scene_indices=[max_tempo_idx],
                        confidence=0.4,
                        rationale="3-Akt-Struktur: Höhepunkt im letzten Viertel",
                    ))

            # 4. Motion flow — calm→action→calm is better than random
            if motions and len(motions) >= 3:
                levels = [m.motion_level for m in motions]
                reversals = 0
                for i in range(1, len(levels) - 1):
                    if ((levels[i] > levels[i-1] and levels[i] > levels[i+1]) or
                        (levels[i] < levels[i-1] and levels[i] < levels[i+1])):
                        reversals += 1

                if reversals > len(levels) * 0.6:
                    suggestions.append(ReEditSuggestion(
                        suggestion_type="reorder",
                        description="Bewegungslevel springt stark hin und her — "
                                    "glatteres Pacing durch Sortierung?",
                        scene_indices=list(range(len(levels))),
                        confidence=0.35,
                        rationale="Gleichmäßigeres Pacing verbessert den Flow",
                    ))

            # Sort by confidence
            suggestions.sort(key=lambda s: s.confidence, reverse=True)
            log.info("[VP9] Re-edit suggestions: %d", len(suggestions))

        except Exception as e:
            log.debug("[VP9] Re-edit suggestion error: %s", e)

        return suggestions

    # ── Persistence ──────────────────────────────────────────

    def save_to_db(self, db, video_path: str,
                   faces: List[FaceDetection] = None,
                   motions: List[MotionProfile] = None,
                   emotions: List[EmotionProfile] = None,
                   styles: List[StyleSuggestion] = None) -> None:
        """Save all VP9 analysis results to database."""
        try:
            data = {}
            if faces:
                data["faces"] = [f.to_dict() for f in faces]
            if motions:
                data["motions"] = [m.to_dict() for m in motions]
            if emotions:
                data["emotions"] = [e.to_dict() for e in emotions]
            if styles:
                data["styles"] = [s.to_dict() for s in styles]

            json_str = json.dumps(data)
            key = f"vp9_analysis_{hashlib.md5(video_path.encode()).hexdigest()[:12]}"

            if hasattr(db, 'set_meta'):
                db.set_meta(key, json_str)
            elif hasattr(db, 'execute'):
                db.execute(
                    "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                    (key, json_str),
                )
                db.commit()

            log.info("[VP9] Saved analysis to DB for %s", video_path)
        except Exception as e:
            log.debug("[VP9] save_to_db error: %s", e)

    def load_from_db(self, db, video_path: str) -> dict:
        """Load VP9 analysis from database. Returns dict with keys: faces, motions, emotions, styles."""
        try:
            key = f"vp9_analysis_{hashlib.md5(video_path.encode()).hexdigest()[:12]}"
            json_str = None

            if hasattr(db, 'get_meta'):
                json_str = db.get_meta(key)
            elif hasattr(db, 'execute'):
                row = db.execute(
                    "SELECT value FROM meta WHERE key = ?", (key,),
                ).fetchone()
                if row:
                    json_str = row[0]

            if json_str:
                data = json.loads(json_str)
                result = {}
                if "faces" in data:
                    result["faces"] = [FaceDetection.from_dict(d) for d in data["faces"]]
                if "motions" in data:
                    result["motions"] = [MotionProfile.from_dict(d) for d in data["motions"]]
                if "emotions" in data:
                    result["emotions"] = [EmotionProfile.from_dict(d) for d in data["emotions"]]
                if "styles" in data:
                    result["styles"] = [StyleSuggestion(**d) for d in data["styles"]]
                return result
        except Exception as e:
            log.debug("[VP9] load_from_db error: %s", e)

        return {}

    # ── Full Analysis Pipeline ───────────────────────────────

    def analyze_full(self, video_path: str, scenes: list,
                     moods: list = None) -> dict:
        """Run the complete VP9 analysis pipeline on all scenes.

        Returns: {
            "faces": {scene_idx: [FaceDetection]},
            "motions": [MotionProfile],
            "emotions": [EmotionProfile],
            "styles": [StyleSuggestion],
            "reedit": [ReEditSuggestion],
        }
        """
        result = {
            "faces": {},
            "motions": [],
            "emotions": [],
            "styles": [],
            "reedit": [],
        }

        try:
            # 1. Face detection per scene
            for scene in scenes:
                faces = self.detect_faces(video_path, scene)
                if faces:
                    result["faces"][int(getattr(scene, 'index', 0))] = faces

            # 2. Motion classification per scene
            for scene in scenes:
                motion = self.classify_motion(video_path, scene)
                result["motions"].append(motion)

            # 3. Emotion analysis per scene
            for i, scene in enumerate(scenes):
                mood = moods[i] if moods and i < len(moods) else None
                motion = result["motions"][i] if i < len(result["motions"]) else None
                scene_faces = result["faces"].get(int(getattr(scene, 'index', 0)), [])
                emotion = self.analyze_emotion(scene, scene_faces, motion, mood)
                result["emotions"].append(emotion)

            # 4. Style suggestions (global)
            result["styles"] = self.suggest_style(scenes, moods, result["motions"])

            # 5. Re-edit suggestions
            result["reedit"] = self.suggest_reedit(scenes, moods, result["motions"])

            log.info("[VP9] Full analysis complete: %d scenes, %d faces, "
                     "%d motions, %d styles, %d re-edit suggestions",
                     len(scenes),
                     sum(len(v) for v in result["faces"].values()),
                     len(result["motions"]),
                     len(result["styles"]),
                     len(result["reedit"]))

        except Exception as e:
            log.error("[VP9] Full analysis error: %s", e, exc_info=True)

        return result
