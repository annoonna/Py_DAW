# -*- coding: utf-8 -*-
"""Async Project Sync — Non-blocking Play/Sync for the Rust Engine.

v0.0.21.127 — UF-1: UI Performance Fix

Problem:
    Clicking Play triggered SyncProject + SampleSync SYNCHRONOUSLY on the
    Qt main thread. For a project with 14 tracks, 35 clips, 344 MIDI notes,
    this blocked the UI for 500-2000ms — visible freeze, "Warten" dialog.

Solution:
    Move the entire sync+play chain to a QThread. The Play button responds
    instantly, shows a brief spinner, and playback starts as soon as sync
    completes in the background.

Usage:
    # Replace direct syncer.on_play() with:
    from pydaw.services.async_project_sync import AsyncPlayWorker
    worker = AsyncPlayWorker(bridge, project_service)
    worker.finished.connect(on_play_done)
    worker.start()
"""
from __future__ import annotations

import logging
import time
from typing import Any, Optional

from PyQt6.QtCore import QThread, pyqtSignal, QObject

_log = logging.getLogger(__name__)


class AsyncPlayWorker(QThread):
    """Background thread for SyncProject + SampleSync + Play.
    
    Signals:
        sync_started: Emitted when sync begins (UI can show spinner)
        sync_progress: (step, detail) — progress updates
        play_started: Emitted when engine.play() was sent
        finished_ok: Emitted on success
        finished_error: (error_msg,) — Emitted on failure
    """
    sync_started = pyqtSignal()
    sync_progress = pyqtSignal(str, str)  # step, detail
    play_started = pyqtSignal()
    finished_ok = pyqtSignal()
    finished_error = pyqtSignal(str)

    def __init__(self, bridge: Any, project_service: Any,
                 transport_service: Any = None, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._bridge = bridge
        self._project_svc = project_service
        self._transport_svc = transport_service
        self.setObjectName("AsyncPlayWorker")

    def run(self):
        """Execute sync + play in background thread."""
        t0 = time.monotonic()
        try:
            self.sync_started.emit()

            # Step 1: Serialize + send project state
            self.sync_progress.emit("sync", "Projekt synchronisieren...")
            from pydaw.services.rust_project_sync import (
                RustProjectSyncer, serialize_project_sync
            )
            syncer = RustProjectSyncer(
                self._bridge, self._project_svc,
                transport_service=self._transport_svc
            )
            ok = syncer.sync()
            if not ok:
                self.finished_error.emit("SyncProject fehlgeschlagen")
                return

            # Step 2: Send audio samples
            self.sync_progress.emit("samples", "Audio-Samples laden...")
            try:
                ss = syncer._get_sample_syncer()
                if ss is not None:
                    count = ss.sync_all()
                    _log.info("AsyncPlay: %d samples synced", count)
            except Exception as e:
                _log.warning("AsyncPlay: sample sync failed (non-fatal): %s", e)

            # Step 3: Send Play command
            self.sync_progress.emit("play", "Playback starten...")
            self._bridge.play()
            self.play_started.emit()

            elapsed = time.monotonic() - t0
            _log.info("AsyncPlay: sync+play completed in %.0fms", elapsed * 1000)
            self.finished_ok.emit()

        except Exception as e:
            _log.error("AsyncPlay failed: %s", e)
            self.finished_error.emit(str(e))


class AsyncSyncWorker(QThread):
    """Background thread for SyncProject only (without Play).
    
    Used for periodic background syncs, e.g. after track changes.
    """
    finished = pyqtSignal(bool)  # success

    def __init__(self, bridge: Any, project_service: Any,
                 transport_service: Any = None, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._bridge = bridge
        self._project_svc = project_service
        self._transport_svc = transport_service
        self.setObjectName("AsyncSyncWorker")

    def run(self):
        try:
            from pydaw.services.rust_project_sync import RustProjectSyncer
            syncer = RustProjectSyncer(
                self._bridge, self._project_svc,
                transport_service=self._transport_svc
            )
            ok = syncer.sync()
            self.finished.emit(ok)
        except Exception as e:
            _log.error("AsyncSync failed: %s", e)
            self.finished.emit(False)


class ParameterDebouncer(QObject):
    """UF-2: Debounce parameter updates to max 30Hz.
    
    Instead of sending an IPC command for every mouse-move pixel on a
    slider/knob, this collects updates and sends them at 30Hz intervals.
    
    Usage:
        debouncer = ParameterDebouncer(bridge)
        # Instead of: bridge.set_track_param(idx, "Volume", 0.5)
        debouncer.queue_track_param(idx, "Volume", 0.5)
        # Instead of: bridge.send_command({"cmd": "SetFxParam", ...})
        debouncer.queue_fx_param(track_id, slot, param, value)
    """
    
    def __init__(self, bridge: Any, interval_ms: int = 33, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._bridge = bridge
        self._pending_track: dict = {}   # (track_idx, param) → value
        self._pending_fx: dict = {}      # (track_id, slot, param) → value
        self._pending_inst: dict = {}    # (track_id, param) → value
        
        from PyQt6.QtCore import QTimer
        self._timer = QTimer(self)
        self._timer.setInterval(interval_ms)
        self._timer.timeout.connect(self._flush)
        self._timer.start()
    
    def queue_track_param(self, track_index: int, param: str, value: float):
        """Queue a track parameter update (Volume, Pan, Mute, Solo)."""
        self._pending_track[(track_index, param)] = value
    
    def queue_fx_param(self, track_id: str, slot_index: int,
                       param_name: str, value: float):
        """Queue an FX parameter update."""
        self._pending_fx[(track_id, slot_index, param_name)] = value
    
    def queue_instrument_param(self, track_id: str, param_name: str, value: float):
        """Queue an instrument parameter update."""
        self._pending_inst[(track_id, param_name)] = value
    
    def _flush(self):
        """Send all pending updates (called by timer at 30Hz)."""
        if not self._bridge or not getattr(self._bridge, '_connected', False):
            return
        
        # Flush track params
        if self._pending_track:
            batch = dict(self._pending_track)
            self._pending_track.clear()
            for (idx, param), value in batch.items():
                try:
                    if idx == 65535 or str(param).startswith("master:"):
                        # Master track uses special command
                        pname = str(param).replace("master:", "")
                        self._bridge.send_command({
                            "cmd": "SetMasterParam",
                            "param": pname,
                            "value": float(value),
                        })
                    else:
                        self._bridge.send_command({
                            "cmd": "SetTrackParam",
                            "track_index": int(idx),
                            "param": str(param),
                            "value": float(value),
                        })
                except Exception:
                    pass
        
        # Flush FX params
        if self._pending_fx:
            batch = dict(self._pending_fx)
            self._pending_fx.clear()
            for (tid, slot, pname), value in batch.items():
                try:
                    self._bridge.send_command({
                        "cmd": "SetFxParam",
                        "track_id": tid,
                        "slot_index": slot,
                        "param_name": pname,
                        "value": value,
                    })
                except Exception:
                    pass
        
        # Flush instrument params
        if self._pending_inst:
            batch = dict(self._pending_inst)
            self._pending_inst.clear()
            for (tid, pname), value in batch.items():
                try:
                    self._bridge.send_command({
                        "cmd": "SetInstrumentParam",
                        "track_id": tid,
                        "param_name": pname,
                        "value": value,
                    })
                except Exception:
                    pass
    
    def flush_now(self):
        """Force immediate flush (e.g. before save)."""
        self._flush()
    
    def stop(self):
        """Stop the debounce timer."""
        self._timer.stop()
        self._flush()  # Send any remaining updates
