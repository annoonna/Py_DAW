"""Backward-compatible settings helpers for legacy UI imports.

This shim keeps older import paths alive without forcing eager Qt imports.
"""

from __future__ import annotations

from typing import Any


def _core_module():
    from pydaw.core import settings_store as core_settings_store
    return core_settings_store


def get_settings():
    return _core_module().get_settings()


def get_value(key: str, default: Any = None) -> Any:
    return _core_module().get_value(key, default)


def set_value(key: str, value: Any) -> None:
    _core_module().set_value(key, value)


def get_setting(key: str, default: Any = None) -> Any:
    return get_value(key, default)


def set_setting(key: str, value: Any) -> None:
    set_value(key, value)


__all__ = [
    "get_settings",
    "get_value",
    "set_value",
    "get_setting",
    "set_setting",
]
