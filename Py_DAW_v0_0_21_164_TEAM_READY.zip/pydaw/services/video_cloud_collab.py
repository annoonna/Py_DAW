"""video_cloud_collab.py — Cloud Video Collaboration for VE18 (v0.0.20.951).

Cloud-based multi-user video editing:
  - Multi-user timeline (WebSocket protocol)
  - Proxy video streaming (low-res for remote users)
  - Comment markers (reviewer workflow)
  - Version control for video projects

Architecture:
  VideoCloudService manages remote collaboration for video editing.
  It extends the existing Collab system (collab_panel.py) with
  video-specific operations like proxy streaming and review markers.

What NO other DAW has:
  - Cloud video collaboration inside a music DAW
  - Beat-synced review markers
  - Proxy + original video management in one tool

Usage:
    svc = VideoCloudService()
    svc.create_session("project_123")
    svc.add_comment(10.5, "Cut here please", author="Reviewer A")
    svc.generate_proxy(video_path, quality="720p")
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import tempfile
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Review Comments
# ═══════════════════════════════════════════════════════════════

class CommentPriority(Enum):
    INFO = "info"
    NOTE = "note"
    IMPORTANT = "important"
    CRITICAL = "critical"


@dataclass
class ReviewComment:
    """A timestamped review comment on the video timeline."""
    comment_id: str = ""
    time_start: float = 0.0    # seconds
    time_end: float = 0.0      # seconds (0 = point marker)
    text: str = ""
    author: str = ""
    priority: CommentPriority = CommentPriority.NOTE
    resolved: bool = False
    created_at: float = 0.0
    replies: List[Dict[str, str]] = field(default_factory=list)
    color: str = "#ffaa00"     # marker color

    def __post_init__(self):
        if not self.comment_id:
            self.comment_id = f"cmt_{uuid.uuid4().hex[:8]}"
        if not self.created_at:
            self.created_at = time.time()
        # Auto-assign color by priority
        if self.color == "#ffaa00":
            colors = {
                CommentPriority.INFO: "#4488ff",
                CommentPriority.NOTE: "#ffaa00",
                CommentPriority.IMPORTANT: "#ff6644",
                CommentPriority.CRITICAL: "#ff2222",
            }
            self.color = colors.get(self.priority, "#ffaa00")

    @property
    def is_range(self) -> bool:
        return self.time_end > self.time_start

    def add_reply(self, text: str, author: str) -> None:
        self.replies.append({
            "text": text,
            "author": author,
            "time": time.time(),
        })

    def to_dict(self) -> dict:
        return {
            "comment_id": self.comment_id,
            "time_start": self.time_start,
            "time_end": self.time_end,
            "text": self.text,
            "author": self.author,
            "priority": self.priority.value,
            "resolved": self.resolved,
            "created_at": self.created_at,
            "replies": self.replies,
            "color": self.color,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ReviewComment":
        pri = CommentPriority.NOTE
        for p in CommentPriority:
            if p.value == d.get("priority", "note"):
                pri = p
                break
        return cls(
            comment_id=d.get("comment_id", ""),
            time_start=d.get("time_start", 0.0),
            time_end=d.get("time_end", 0.0),
            text=d.get("text", ""),
            author=d.get("author", ""),
            priority=pri,
            resolved=d.get("resolved", False),
            created_at=d.get("created_at", 0.0),
            replies=d.get("replies", []),
            color=d.get("color", "#ffaa00"),
        )


# ═══════════════════════════════════════════════════════════════
# Proxy Video
# ═══════════════════════════════════════════════════════════════

class ProxyQuality(Enum):
    ULTRA_LOW = "360p"    # 640×360, 500kbps
    LOW = "480p"          # 854×480, 1Mbps
    MEDIUM = "720p"       # 1280×720, 2.5Mbps
    HIGH = "1080p"        # 1920×1080, 5Mbps


_PROXY_SETTINGS: Dict[str, Dict[str, Any]] = {
    "360p": {"width": 640, "height": 360, "bitrate": "500k",
             "fps": 15, "crf": 35},
    "480p": {"width": 854, "height": 480, "bitrate": "1M",
             "fps": 24, "crf": 30},
    "720p": {"width": 1280, "height": 720, "bitrate": "2500k",
             "fps": 24, "crf": 26},
    "1080p": {"width": 1920, "height": 1080, "bitrate": "5M",
              "fps": 30, "crf": 23},
}


def generate_proxy(video_path: str, output_path: str = "",
                    quality: str = "720p") -> Optional[str]:
    """Generate a proxy (low-res) version of a video.
    
    Args:
        video_path: Original high-res video
        output_path: Where to save proxy (auto-generated if empty)
        quality: "360p", "480p", "720p", "1080p"
    
    Returns:
        Path to proxy video, or None on failure
    """
    settings = _PROXY_SETTINGS.get(quality, _PROXY_SETTINGS["720p"])

    if not output_path:
        base = os.path.splitext(video_path)[0]
        output_path = f"{base}_proxy_{quality}.mp4"

    try:
        cmd = [
            "ffmpeg", "-y",
            "-i", video_path,
            "-vf", f"scale={settings['width']}:{settings['height']}",
            "-r", str(settings["fps"]),
            "-c:v", "libx264",
            "-crf", str(settings["crf"]),
            "-preset", "fast",
            "-c:a", "aac",
            "-b:a", "96k",
            "-movflags", "+faststart",
            output_path
        ]
        subprocess.run(cmd, capture_output=True, timeout=300, check=True)
        log.info("Proxy generated: %s (%s)", output_path, quality)
        return output_path
    except Exception as exc:
        log.error("Proxy generation failed: %s", exc)
        return None


# ═══════════════════════════════════════════════════════════════
# Version Control
# ═══════════════════════════════════════════════════════════════

@dataclass
class ProjectVersion:
    """A saved version/snapshot of the video project."""
    version_id: str = ""
    name: str = ""
    description: str = ""
    author: str = ""
    created_at: float = 0.0
    parent_version: str = ""   # previous version
    state_json: str = ""       # serialized project state
    clips_hash: str = ""       # hash of clip arrangement

    def __post_init__(self):
        if not self.version_id:
            self.version_id = f"v_{uuid.uuid4().hex[:8]}"
        if not self.created_at:
            self.created_at = time.time()

    def to_dict(self) -> dict:
        return {
            "version_id": self.version_id,
            "name": self.name,
            "description": self.description,
            "author": self.author,
            "created_at": self.created_at,
            "parent_version": self.parent_version,
            "state_json": self.state_json,
            "clips_hash": self.clips_hash,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ProjectVersion":
        return cls(**{k: v for k, v in d.items()
                      if k in cls.__dataclass_fields__})


# ═══════════════════════════════════════════════════════════════
# Cloud Collab Protocol Messages
# ═══════════════════════════════════════════════════════════════

class CloudMessageType(Enum):
    """WebSocket message types for cloud video collaboration."""
    JOIN = "cloud_join"
    LEAVE = "cloud_leave"
    COMMENT_ADD = "cloud_comment_add"
    COMMENT_RESOLVE = "cloud_comment_resolve"
    COMMENT_REPLY = "cloud_comment_reply"
    VERSION_SAVE = "cloud_version_save"
    VERSION_RESTORE = "cloud_version_restore"
    PLAYHEAD_SYNC = "cloud_playhead_sync"
    PROXY_REQUEST = "cloud_proxy_request"
    PROXY_READY = "cloud_proxy_ready"


def create_cloud_message(msg_type: CloudMessageType,
                          data: dict) -> dict:
    """Create a cloud collaboration message."""
    return {
        "type": msg_type.value,
        "timestamp": time.time(),
        "message_id": uuid.uuid4().hex[:12],
        "data": data,
    }


# ═══════════════════════════════════════════════════════════════
# VideoCloudService
# ═══════════════════════════════════════════════════════════════

class VideoCloudService:
    """Cloud video collaboration service.
    
    Manages review comments, proxy videos, and version control.
    Integrates with the existing collab system for transport.
    """

    def __init__(self):
        self._comments: List[ReviewComment] = []
        self._versions: List[ProjectVersion] = []
        self._proxies: Dict[str, str] = {}  # original → proxy path
        self._session_id: str = ""
        self._participants: List[Dict[str, str]] = []
        self._on_comment: Optional[Callable] = None
        self._on_version: Optional[Callable] = None

    @property
    def session_id(self) -> str:
        return self._session_id

    @property
    def comments(self) -> List[ReviewComment]:
        return self._comments

    @property
    def versions(self) -> List[ProjectVersion]:
        return self._versions

    @property
    def participants(self) -> List[Dict[str, str]]:
        return self._participants

    def set_on_comment(self, callback: Callable) -> None:
        """Set callback for new comments."""
        self._on_comment = callback

    def set_on_version(self, callback: Callable) -> None:
        """Set callback for version changes."""
        self._on_version = callback

    # ── Session management ──

    def create_session(self, project_id: str = "") -> str:
        """Create a new cloud session."""
        self._session_id = project_id or uuid.uuid4().hex[:12]
        self._participants.clear()
        log.info("Cloud session: %s", self._session_id)
        return self._session_id

    def join_session(self, session_id: str,
                      username: str = "Anonymous") -> None:
        """Join an existing cloud session."""
        self._session_id = session_id
        self._participants.append({
            "name": username,
            "joined_at": str(time.time()),
        })

    # ── Comments ──

    def add_comment(self, time_start: float, text: str,
                     author: str = "",
                     time_end: float = 0.0,
                     priority: str = "note") -> ReviewComment:
        """Add a review comment at a timestamp."""
        pri = CommentPriority.NOTE
        for p in CommentPriority:
            if p.value == priority:
                pri = p
                break

        comment = ReviewComment(
            time_start=time_start,
            time_end=time_end,
            text=text,
            author=author,
            priority=pri,
        )
        self._comments.append(comment)
        self._comments.sort(key=lambda c: c.time_start)

        if self._on_comment:
            self._on_comment(comment)

        log.info("Comment added at %.1fs: %s", time_start, text[:50])
        return comment

    def resolve_comment(self, comment_id: str) -> bool:
        """Mark a comment as resolved."""
        for c in self._comments:
            if c.comment_id == comment_id:
                c.resolved = True
                return True
        return False

    def reply_to_comment(self, comment_id: str, text: str,
                          author: str = "") -> bool:
        """Add a reply to a comment."""
        for c in self._comments:
            if c.comment_id == comment_id:
                c.add_reply(text, author)
                return True
        return False

    def get_comments_at(self, time: float,
                         tolerance: float = 0.5
                         ) -> List[ReviewComment]:
        """Get comments near a timestamp."""
        result = []
        for c in self._comments:
            if c.is_range:
                if c.time_start <= time <= c.time_end:
                    result.append(c)
            else:
                if abs(c.time_start - time) <= tolerance:
                    result.append(c)
        return result

    def get_unresolved_comments(self) -> List[ReviewComment]:
        return [c for c in self._comments if not c.resolved]

    def get_comment_markers(self) -> List[Dict[str, Any]]:
        """Get comment markers for timeline display."""
        return [
            {
                "id": c.comment_id,
                "time": c.time_start,
                "end_time": c.time_end,
                "text": c.text[:30],
                "author": c.author,
                "color": c.color,
                "resolved": c.resolved,
                "priority": c.priority.value,
            }
            for c in self._comments
        ]

    # ── Proxy management ──

    def generate_proxy(self, video_path: str,
                        quality: str = "720p") -> Optional[str]:
        """Generate and register a proxy video."""
        proxy_path = generate_proxy(video_path, quality=quality)
        if proxy_path:
            self._proxies[video_path] = proxy_path
        return proxy_path

    def get_proxy(self, video_path: str) -> Optional[str]:
        """Get proxy path for a video file."""
        return self._proxies.get(video_path)

    # ── Version control ──

    def save_version(self, name: str, description: str = "",
                      author: str = "",
                      state: dict = None) -> ProjectVersion:
        """Save a version snapshot of the project."""
        parent = self._versions[-1].version_id if self._versions else ""

        version = ProjectVersion(
            name=name,
            description=description,
            author=author,
            parent_version=parent,
            state_json=json.dumps(state or {}, default=str),
        )
        self._versions.append(version)

        if self._on_version:
            self._on_version(version)

        log.info("Version saved: %s (%s)", version.version_id, name)
        return version

    def get_version(self, version_id: str) -> Optional[ProjectVersion]:
        """Get a specific version."""
        for v in self._versions:
            if v.version_id == version_id:
                return v
        return None

    def version_history(self) -> List[Dict[str, str]]:
        """Get version history summary."""
        return [
            {
                "id": v.version_id,
                "name": v.name,
                "author": v.author,
                "created": str(v.created_at),
                "description": v.description,
            }
            for v in reversed(self._versions)
        ]

    # ── Serialization ──

    def save_to_dict(self) -> dict:
        return {
            "session_id": self._session_id,
            "comments": [c.to_dict() for c in self._comments],
            "versions": [v.to_dict() for v in self._versions],
            "proxies": self._proxies,
        }

    def load_from_dict(self, data: dict) -> None:
        self._session_id = data.get("session_id", "")
        self._comments = [ReviewComment.from_dict(c)
                          for c in data.get("comments", [])]
        self._versions = [ProjectVersion.from_dict(v)
                          for v in data.get("versions", [])]
        self._proxies = data.get("proxies", {})
