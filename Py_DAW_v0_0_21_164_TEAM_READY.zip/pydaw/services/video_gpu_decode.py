"""video_gpu_decode.py — GPU Video Decode Service for VE14 (v0.0.20.951).

Hardware-accelerated video decoding and filtering:
  - Vulkan-based decode via ffmpeg (Linux)
  - VAAPI for Intel/AMD GPUs
  - NVDEC for NVIDIA GPUs
  - 4K/8K real-time preview pipeline
  - GPU-accelerated filters (blur, color grade, scale)

Architecture:
  GPUDecodeService auto-detects available GPU backends,
  selects the best one, and provides a unified API for
  hardware-accelerated decode + filter operations.
  Falls back gracefully to software decode when no GPU available.

What NO other DAW has:
  - GPU video decode inside a music DAW
  - Automatic GPU backend selection
  - Beat-synced GPU filter transitions

Usage:
    svc = GPUDecodeService.instance()
    print(svc.available_backends)   # ['vaapi', 'nvdec', 'vulkan']
    svc.decode_frame(video_path, time_sec, width=1920)
    svc.get_hw_filter("blur", {"sigma": 5.0})
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import tempfile
import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# GPU Backend Detection
# ═══════════════════════════════════════════════════════════════

class GPUBackend(Enum):
    NONE = "none"          # Software decode
    VAAPI = "vaapi"        # Intel/AMD (Linux)
    NVDEC = "nvdec"        # NVIDIA (Linux/Windows)
    VULKAN = "vulkan"      # Universal GPU (Linux)
    CUDA = "cuda"          # NVIDIA CUDA
    VDPAU = "vdpau"        # Legacy NVIDIA (Linux)
    QSV = "qsv"            # Intel Quick Sync Video
    V4L2M2M = "v4l2m2m"    # ARM/embedded (RPi etc.)


@dataclass
class GPUCapability:
    """Describes a detected GPU decode capability."""
    backend: GPUBackend
    device: str = ""          # e.g. /dev/dri/renderD128
    codecs: List[str] = field(default_factory=list)  # h264, hevc, vp9, av1
    max_width: int = 3840     # max decode width
    max_height: int = 2160    # max decode height
    supports_filters: bool = False
    priority: int = 0         # higher = preferred

    def to_dict(self) -> dict:
        return {
            "backend": self.backend.value,
            "device": self.device,
            "codecs": self.codecs,
            "max_width": self.max_width,
            "max_height": self.max_height,
            "supports_filters": self.supports_filters,
            "priority": self.priority,
        }


def _check_ffmpeg_hwaccels() -> List[str]:
    """Get list of supported ffmpeg hardware accelerations."""
    try:
        result = subprocess.run(
            ["ffmpeg", "-hwaccels"],
            capture_output=True, text=True, timeout=5)
        lines = result.stdout.strip().split("\n")
        # Skip header line
        accels = [l.strip() for l in lines[1:] if l.strip()]
        return accels
    except Exception:
        return []


def _check_vaapi() -> Optional[GPUCapability]:
    """Check for VAAPI support (Intel/AMD)."""
    # Check for render device
    devices = ["/dev/dri/renderD128", "/dev/dri/renderD129"]
    device = ""
    for d in devices:
        if os.path.exists(d):
            device = d
            break

    if not device:
        return None

    try:
        # Test VAAPI decode with ffmpeg
        result = subprocess.run(
            ["ffmpeg", "-init_hw_device", f"vaapi=va:{device}",
             "-f", "lavfi", "-i", "nullsrc=s=64x64:d=0.1",
             "-vf", "format=nv12,hwupload",
             "-f", "null", "-"],
            capture_output=True, text=True, timeout=5)

        codecs = ["h264", "hevc"]
        # Check for VP9/AV1 support
        for codec in ["vp9", "av1"]:
            test = subprocess.run(
                ["ffmpeg", "-decoders"],
                capture_output=True, text=True, timeout=5)
            if f"{codec}_vaapi" in test.stdout:
                codecs.append(codec)

        return GPUCapability(
            backend=GPUBackend.VAAPI,
            device=device,
            codecs=codecs,
            max_width=7680,
            max_height=4320,
            supports_filters=True,
            priority=80,
        )
    except Exception:
        return None


def _check_nvdec() -> Optional[GPUCapability]:
    """Check for NVIDIA NVDEC support."""
    try:
        # Check for nvidia-smi
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=5)
        if result.returncode != 0:
            return None

        gpu_name = result.stdout.strip().split("\n")[0]

        return GPUCapability(
            backend=GPUBackend.NVDEC,
            device=gpu_name,
            codecs=["h264", "hevc", "vp9", "av1"],
            max_width=7680,
            max_height=4320,
            supports_filters=True,
            priority=90,  # Prefer NVIDIA when available
        )
    except Exception:
        return None


def _check_vulkan() -> Optional[GPUCapability]:
    """Check for Vulkan video decode support."""
    try:
        # Check if vulkaninfo is available
        result = subprocess.run(
            ["vulkaninfo", "--summary"],
            capture_output=True, text=True, timeout=5)
        if result.returncode != 0:
            return None

        gpu_name = "Vulkan GPU"
        for line in result.stdout.split("\n"):
            if "deviceName" in line:
                gpu_name = line.split("=")[-1].strip()
                break

        return GPUCapability(
            backend=GPUBackend.VULKAN,
            device=gpu_name,
            codecs=["h264", "hevc"],
            max_width=7680,
            max_height=4320,
            supports_filters=False,  # Vulkan filters limited
            priority=60,
        )
    except Exception:
        return None


def detect_gpu_backends() -> List[GPUCapability]:
    """Detect all available GPU decode backends."""
    backends = []
    hw_accels = _check_ffmpeg_hwaccels()

    if "vaapi" in hw_accels:
        cap = _check_vaapi()
        if cap:
            backends.append(cap)

    if "cuda" in hw_accels or "nvdec" in hw_accels:
        cap = _check_nvdec()
        if cap:
            backends.append(cap)

    if "vulkan" in hw_accels:
        cap = _check_vulkan()
        if cap:
            backends.append(cap)

    # Sort by priority (highest first)
    backends.sort(key=lambda b: b.priority, reverse=True)
    return backends


# ═══════════════════════════════════════════════════════════════
# GPU Filter Generation
# ═══════════════════════════════════════════════════════════════

def get_hw_decode_args(backend: GPUBackend,
                        device: str = "") -> List[str]:
    """Get ffmpeg arguments for hardware-accelerated decode."""
    if backend == GPUBackend.VAAPI:
        args = ["-hwaccel", "vaapi", "-hwaccel_output_format", "vaapi"]
        if device:
            args = ["-init_hw_device", f"vaapi=va:{device}",
                    "-hwaccel", "vaapi",
                    "-hwaccel_output_format", "vaapi",
                    "-filter_hw_device", "va"]
        return args

    elif backend == GPUBackend.NVDEC:
        return ["-hwaccel", "cuda",
                "-hwaccel_output_format", "cuda"]

    elif backend == GPUBackend.VULKAN:
        return ["-hwaccel", "vulkan",
                "-hwaccel_output_format", "vulkan"]

    return []  # Software decode


def get_hw_scale_filter(backend: GPUBackend,
                         width: int, height: int = -1) -> str:
    """Get GPU-accelerated scale filter string."""
    if backend == GPUBackend.VAAPI:
        return f"scale_vaapi=w={width}:h={height}"
    elif backend == GPUBackend.NVDEC:
        return f"scale_cuda=w={width}:h={height}"
    elif backend == GPUBackend.VULKAN:
        return f"scale_vulkan=w={width}:h={height}"
    return f"scale={width}:{height}"


def get_hw_filter(backend: GPUBackend,
                   filter_name: str,
                   params: Dict[str, Any] = None) -> str:
    """Get GPU-accelerated filter string.
    
    Supported filters: blur, color_grade, tonemap, overlay, transpose
    """
    params = params or {}

    if filter_name == "blur":
        sigma = params.get("sigma", 5.0)
        if backend == GPUBackend.VAAPI:
            return f"sharpness_vaapi=sharpness=-{int(sigma)}"
        return f"gblur=sigma={sigma}"

    elif filter_name == "color_grade":
        brightness = params.get("brightness", 0.0)
        contrast = params.get("contrast", 1.0)
        saturation = params.get("saturation", 1.0)
        if backend == GPUBackend.VAAPI:
            return (f"procamp_vaapi=b={brightness}:"
                    f"c={contrast}:s={saturation}")
        return (f"eq=brightness={brightness}:"
                f"contrast={contrast}:saturation={saturation}")

    elif filter_name == "tonemap":
        # HDR→SDR tone mapping
        if backend in (GPUBackend.VAAPI, GPUBackend.NVDEC):
            return "tonemap_vaapi=format=nv12" if backend == GPUBackend.VAAPI \
                else "tonemap_cuda=format=nv12"
        return "tonemap=tonemap=hable:desat=0"

    elif filter_name == "transpose":
        angle = params.get("angle", 1)  # 0=90ccw, 1=90cw, 2=180
        if backend == GPUBackend.VAAPI:
            return f"transpose_vaapi=dir={angle}"
        return f"transpose={angle}"

    elif filter_name == "deinterlace":
        if backend == GPUBackend.VAAPI:
            return "deinterlace_vaapi=mode=motion_adaptive"
        elif backend == GPUBackend.NVDEC:
            return "yadif_cuda"
        return "yadif"

    elif filter_name == "denoise":
        strength = params.get("strength", 5)
        if backend == GPUBackend.VAAPI:
            return f"denoise_vaapi=filter_type=auto:strength={strength}"
        return f"nlmeans=s={strength}:p=7:r=15"

    # Fallback: return software filter
    return f"{filter_name}"


def build_preview_pipeline(video_path: str,
                            backend: GPUBackend,
                            device: str = "",
                            preview_width: int = 1280,
                            filters: List[str] = None
                            ) -> List[str]:
    """Build complete ffmpeg preview pipeline command.
    
    Returns list of ffmpeg arguments for real-time preview.
    """
    cmd = ["ffmpeg", "-y"]

    # HW decode args
    cmd.extend(get_hw_decode_args(backend, device))

    # Input
    cmd.extend(["-i", video_path])

    # Build filter chain
    filter_parts = []

    # Scale to preview resolution
    scale = get_hw_scale_filter(backend, preview_width)
    filter_parts.append(scale)

    # Additional filters
    if filters:
        filter_parts.extend(filters)

    # Download from GPU if needed
    if backend in (GPUBackend.VAAPI, GPUBackend.NVDEC, GPUBackend.VULKAN):
        if backend == GPUBackend.VAAPI:
            filter_parts.append("hwdownload")
            filter_parts.append("format=nv12")
        elif backend == GPUBackend.NVDEC:
            filter_parts.append("hwdownload")
            filter_parts.append("format=nv12")

    if filter_parts:
        cmd.extend(["-vf", ",".join(filter_parts)])

    return cmd


# ═══════════════════════════════════════════════════════════════
# GPUDecodeService (Singleton)
# ═══════════════════════════════════════════════════════════════

class GPUDecodeService:
    """Manages GPU-accelerated video decode and filtering.
    
    Singleton — use GPUDecodeService.instance().
    """

    _instance: Optional["GPUDecodeService"] = None
    _lock = threading.Lock()

    def __init__(self):
        self._backends: List[GPUCapability] = []
        self._active_backend: Optional[GPUCapability] = None
        self._detected = False

    @classmethod
    def instance(cls) -> "GPUDecodeService":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def detect(self) -> None:
        """Detect available GPU backends."""
        self._backends = detect_gpu_backends()
        self._active_backend = self._backends[0] if self._backends else None
        self._detected = True

        if self._active_backend:
            log.info("GPU decode: %s (%s)",
                     self._active_backend.backend.value,
                     self._active_backend.device)
        else:
            log.info("GPU decode: none (software fallback)")

    @property
    def available_backends(self) -> List[GPUCapability]:
        if not self._detected:
            self.detect()
        return self._backends

    @property
    def active_backend(self) -> Optional[GPUCapability]:
        if not self._detected:
            self.detect()
        return self._active_backend

    @property
    def backend_type(self) -> GPUBackend:
        if self.active_backend:
            return self.active_backend.backend
        return GPUBackend.NONE

    def set_backend(self, backend_type: GPUBackend) -> bool:
        """Manually select a GPU backend."""
        for b in self.available_backends:
            if b.backend == backend_type:
                self._active_backend = b
                log.info("GPU backend set to: %s", b.backend.value)
                return True
        return False

    def decode_frame(self, video_path: str, time_sec: float,
                      width: int = 1280,
                      output_path: str = "") -> Optional[str]:
        """Decode a single frame using GPU acceleration.
        
        Returns path to decoded frame PNG, or None on failure.
        """
        if not output_path:
            tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
            tmp.close()
            output_path = tmp.name

        cmd = ["ffmpeg", "-y"]

        # Add HW accel if available
        ab = self.active_backend
        if ab:
            cmd.extend(get_hw_decode_args(ab.backend, ab.device))

        cmd.extend([
            "-ss", str(time_sec),
            "-i", video_path,
            "-vframes", "1",
        ])

        # Scale filter
        if ab and ab.supports_filters:
            scale = get_hw_scale_filter(ab.backend, width)
            if ab.backend in (GPUBackend.VAAPI, GPUBackend.NVDEC):
                cmd.extend(["-vf",
                            f"{scale},hwdownload,format=nv12"])
            else:
                cmd.extend(["-vf", f"scale={width}:-1"])
        else:
            cmd.extend(["-vf", f"scale={width}:-1"])

        cmd.append(output_path)

        try:
            subprocess.run(cmd, capture_output=True, timeout=10, check=True)
            return output_path
        except Exception as exc:
            log.debug("GPU decode failed, trying software: %s", exc)
            # Software fallback
            try:
                cmd_sw = [
                    "ffmpeg", "-y",
                    "-ss", str(time_sec),
                    "-i", video_path,
                    "-vframes", "1",
                    "-vf", f"scale={width}:-1",
                    output_path
                ]
                subprocess.run(cmd_sw, capture_output=True,
                               timeout=10, check=True)
                return output_path
            except Exception:
                return None

    def get_filter(self, filter_name: str,
                    params: Dict[str, Any] = None) -> str:
        """Get GPU-accelerated filter string."""
        backend = self.backend_type
        return get_hw_filter(backend, filter_name, params)

    def get_export_args(self, video_path: str,
                         filters: List[str] = None) -> List[str]:
        """Get ffmpeg arguments for GPU-accelerated export."""
        ab = self.active_backend
        if not ab:
            return []
        return build_preview_pipeline(
            video_path, ab.backend, ab.device,
            preview_width=0,  # original resolution
            filters=filters)

    def summary(self) -> str:
        """Human-readable summary of GPU capabilities."""
        if not self._detected:
            self.detect()
        if not self._backends:
            return "Keine GPU-Beschleunigung verfügbar (Software-Decode)"
        lines = [f"GPU Backends: {len(self._backends)}"]
        for b in self._backends:
            active = " ◀ AKTIV" if b == self._active_backend else ""
            lines.append(
                f"  {b.backend.value}: {b.device} "
                f"[{', '.join(b.codecs)}] "
                f"max {b.max_width}×{b.max_height}"
                f"{active}")
        return "\n".join(lines)
