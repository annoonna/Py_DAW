"""settings_database.py — SQLite-backed User Settings with QSettings Fallback.

v0.0.20.889 — Phase 6 der SQLite Migration Roadmap.

Stores all user settings (audio config, UI preferences, MIDI, etc.)
in SQLite instead of QSettings (which uses platform-specific storage).

Benefits:
- Portable: settings travel with the config directory
- Searchable: all settings in one queryable table
- Backupable: just copy pydaw.db
- Debuggable: sqlite3 CLI can inspect settings

Falls back to QSettings if SQLite fails. Migration: reads existing
QSettings values on first run and writes them to SQLite.

Usage:
    from pydaw.services.settings_database import SettingsDatabase
    db = SettingsDatabase.get()
    db.ensure_loaded()

    # Read (checks SQLite first, then QSettings fallback)
    val = db.get("audio/sample_rate", default="48000")

    # Write (writes to both SQLite and QSettings for compatibility)
    db.set("audio/sample_rate", "44100", category="audio")

    # Bulk read
    audio_settings = db.get_by_category("audio")
"""

import sqlite3
import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


class SettingsDatabase:
    """SQLite-backed settings store with QSettings fallback.

    Singleton. All settings cached in RAM dict for fast reads.
    Writes go to both SQLite and QSettings (dual-write for compatibility).
    """

    _instance: Optional["SettingsDatabase"] = None

    @classmethod
    def get(cls) -> "SettingsDatabase":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        self._cache: Dict[str, dict] = {}   # key → {key, value, category, updated_at}
        self._loaded = False
        self._migrated = False

    def ensure_loaded(self) -> None:
        """Create table, migrate from QSettings if needed, load into RAM. Idempotent."""
        if self._loaded:
            return
        try:
            self._init_db()
            self._load_to_ram()
            if not self._migrated:
                self._migrate_from_qsettings()
                self._migrated = True
            self._loaded = True
            log.info("[SettingsDB] Loaded %d settings", len(self._cache))
        except Exception as e:
            log.warning("[SettingsDB] Failed to load: %s", e)

    # ── Public API ──────────────────────────────────────────────

    def get(self, key: str, default: Any = None) -> Any:
        """Get a setting value. Checks SQLite cache first, then QSettings fallback."""
        self.ensure_loaded()
        row = self._cache.get(key)
        if row is not None:
            return row.get("value", default)
        # Fallback to QSettings (direct, NOT via get_value to avoid recursion)
        try:
            from PyQt6.QtCore import QSettings as _QS
            from pydaw.core.settings import SettingsKeys as _SK
            _sk = _SK()
            _qs = _QS(_sk.organization, _sk.application)
            val = _qs.value(key, default)
            if val is not None and val != default:
                # Migrate this key to SQLite for next time
                category = key.split("/")[0] if "/" in key else "general"
                self._write_to_db(key, str(val), category)
                self._cache[key] = {
                    "key": key, "value": str(val),
                    "category": category, "updated_at": ""
                }
            return val
        except Exception:
            return default

    def get_str(self, key: str, default: str = "") -> str:
        """Get a setting as string."""
        val = self.get(key, default)
        return str(val) if val is not None else default

    def get_int(self, key: str, default: int = 0) -> int:
        """Get a setting as integer."""
        val = self.get(key, default)
        try:
            return int(val)
        except (ValueError, TypeError):
            return default

    def get_float(self, key: str, default: float = 0.0) -> float:
        """Get a setting as float."""
        val = self.get(key, default)
        try:
            return float(val)
        except (ValueError, TypeError):
            return default

    def get_bool(self, key: str, default: bool = False) -> bool:
        """Get a setting as boolean."""
        val = self.get(key, default)
        if isinstance(val, bool):
            return val
        s = str(val).strip().lower()
        return s in ("1", "true", "yes", "on")

    def set(self, key: str, value: Any, category: Optional[str] = None) -> None:
        """Set a setting value. Writes to both SQLite and QSettings."""
        self.ensure_loaded()
        str_val = str(value) if value is not None else ""
        if category is None:
            category = key.split("/")[0] if "/" in key else "general"

        # Update RAM cache
        self._cache[key] = {
            "key": key, "value": str_val,
            "category": category, "updated_at": ""
        }

        # Write to SQLite
        self._write_to_db(key, str_val, category)

        # Dual-write to QSettings for compatibility (direct, NOT via set_value to avoid recursion)
        try:
            from PyQt6.QtCore import QSettings as _QS
            from pydaw.core.settings import SettingsKeys as _SK
            _sk = _SK()
            _qs = _QS(_sk.organization, _sk.application)
            _qs.setValue(key, value)
        except Exception:
            pass

    def delete(self, key: str) -> None:
        """Remove a setting."""
        self.ensure_loaded()
        self._cache.pop(key, None)
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute("DELETE FROM settings WHERE key = ?", (key,))
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    def get_by_category(self, category: str) -> Dict[str, str]:
        """Get all settings in a category as {key: value}."""
        self.ensure_loaded()
        result = {}
        for key, row in self._cache.items():
            if row.get("category") == category:
                result[key] = row.get("value", "")
        return result

    def get_all(self) -> Dict[str, str]:
        """Get all settings as {key: value}."""
        self.ensure_loaded()
        return {k: v.get("value", "") for k, v in self._cache.items()}

    def get_categories(self) -> List[str]:
        """Get list of all categories."""
        self.ensure_loaded()
        cats = set()
        for row in self._cache.values():
            cat = row.get("category", "general")
            if cat:
                cats.add(cat)
        return sorted(cats)

    # ── Internal ────────────────────────────────────────────────

    def _init_db(self) -> None:
        """Create settings table if not exists."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.executescript(_SCHEMA_SQL)
            conn.commit()
        finally:
            conn.close()

    def _load_to_ram(self) -> None:
        """Load all settings into RAM cache."""
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute("SELECT * FROM settings").fetchall()
            self._cache.clear()
            for row in rows:
                d = dict(row)
                self._cache[d["key"]] = d
        finally:
            conn.close()

    def _write_to_db(self, key: str, value: str, category: str) -> None:
        """Write a single setting to SQLite."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO settings (key, value, category, updated_at)
                       VALUES (?, ?, ?, datetime('now'))""",
                    (key, value, category)
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[SettingsDB] Write failed for %s: %s", key, e)

    def _migrate_from_qsettings(self) -> None:
        """One-time migration: read all known keys from QSettings into SQLite."""
        if len(self._cache) > 5:
            # Already have settings, skip migration
            return
        try:
            from pydaw.core.settings import SettingsKeys
            from pydaw.core.settings_store import get_value
            keys_obj = SettingsKeys()
            migrated = 0
            for attr in dir(keys_obj):
                if attr.startswith("_"):
                    continue
                if attr in ("organization", "application"):
                    continue
                key = getattr(keys_obj, attr, None)
                if not isinstance(key, str) or "/" not in key:
                    continue
                val = get_value(key)
                if val is not None and str(val).strip():
                    category = key.split("/")[0]
                    str_val = str(val)
                    if key not in self._cache:
                        self._write_to_db(key, str_val, category)
                        self._cache[key] = {
                            "key": key, "value": str_val,
                            "category": category, "updated_at": ""
                        }
                        migrated += 1
            if migrated > 0:
                log.info("[SettingsDB] Migrated %d settings from QSettings", migrated)
        except Exception as e:
            log.debug("[SettingsDB] QSettings migration skipped: %s", e)


# ── Schema ──────────────────────────────────────────────────────

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT,
    category TEXT,
    updated_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_settings_category ON settings(category);
"""
