"""counterpoint_assistant.py — Rule-Based Counterpoint Generator.

v0.0.20.910 — C4.4: KI-Kompositions-Feature.

Generates countermelodies to a given melody using classical counterpoint
rules: parallel thirds/sixths, contrary motion, voice-leading constraints.

No LLM needed — pure music-theory-based algorithmic composition.

Usage:
    from pydaw.services.counterpoint_assistant import CounterpointAssistant

    cp = CounterpointAssistant()

    # Generate countermelody from MIDI notes
    melody = [
        {"pitch": 60, "start": 0.0, "duration": 1.0, "velocity": 100},
        {"pitch": 64, "start": 1.0, "duration": 1.0, "velocity": 100},
        {"pitch": 67, "start": 2.0, "duration": 1.0, "velocity": 100},
        {"pitch": 72, "start": 3.0, "duration": 1.0, "velocity": 100},
    ]

    counter = cp.generate(melody, key="C", scale="major", style="thirds_below")
    # → [{"pitch": 56, "start": 0.0, ...}, ...]

    # Available styles: thirds_below, thirds_above, sixths_below, sixths_above,
    #                   contrary_motion, oblique, free
"""

from __future__ import annotations

import logging
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Scale intervals (semitones from root)
SCALES = {
    "major":           [0, 2, 4, 5, 7, 9, 11],
    "natural_minor":   [0, 2, 3, 5, 7, 8, 10],
    "harmonic_minor":  [0, 2, 3, 5, 7, 8, 11],
    "melodic_minor":   [0, 2, 3, 5, 7, 9, 11],
    "dorian":          [0, 2, 3, 5, 7, 9, 10],
    "mixolydian":      [0, 2, 4, 5, 7, 9, 10],
    "phrygian":        [0, 1, 3, 5, 7, 8, 10],
    "pentatonic":      [0, 2, 4, 7, 9],
    "minor_pentatonic": [0, 3, 5, 7, 10],
    "blues":           [0, 3, 5, 6, 7, 10],
}

# Note name → MIDI offset
NOTE_OFFSETS = {
    "C": 0, "C#": 1, "Db": 1, "D": 2, "D#": 3, "Eb": 3,
    "E": 4, "F": 5, "F#": 6, "Gb": 6, "G": 7, "G#": 8,
    "Ab": 8, "A": 9, "A#": 10, "Bb": 10, "B": 11,
}

# Consonant intervals (semitones) ranked by preference
PERFECT_CONSONANCES = {0, 7, 12}  # unison, fifth, octave
IMPERFECT_CONSONANCES = {3, 4, 8, 9}  # minor/major third, minor/major sixth
DISSONANCES = {1, 2, 5, 6, 10, 11}  # seconds, tritone, sevenths

# Counterpoint styles
STYLES = [
    "thirds_below",
    "thirds_above",
    "sixths_below",
    "sixths_above",
    "contrary_motion",
    "oblique",
    "free",
]


# ---------------------------------------------------------------------------
# Data Classes
# ---------------------------------------------------------------------------

@dataclass
class CounterpointNote:
    """A note in the countermelody."""
    pitch: int = 60
    start: float = 0.0
    duration: float = 1.0
    velocity: int = 80


@dataclass
class CounterpointResult:
    """Result of counterpoint generation."""
    notes: List[Dict] = field(default_factory=list)
    style: str = ""
    key: str = "C"
    scale: str = "major"
    quality_score: float = 0.0  # 0.0-1.0
    warnings: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# CounterpointAssistant
# ---------------------------------------------------------------------------

class CounterpointAssistant:
    """Rule-based counterpoint melody generator.

    Generates countermelodies using classical voice-leading rules
    adapted for contemporary music production.
    """

    def __init__(self):
        self._avoid_parallel_fifths = True
        self._avoid_parallel_octaves = True
        self._max_leap = 12  # Maximum interval leap (semitones)
        self._prefer_stepwise = True

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate(
        self,
        melody: List[Dict],
        key: str = "C",
        scale: str = "major",
        style: str = "thirds_below",
        velocity_offset: int = -10,
    ) -> CounterpointResult:
        """Generate a countermelody for the given melody.

        Args:
            melody: list of note dicts with pitch, start, duration, velocity
            key: musical key (e.g. "C", "D#", "Bb")
            scale: scale name (e.g. "major", "natural_minor", "dorian")
            style: counterpoint style (see STYLES)
            velocity_offset: velocity adjustment for countermelody (-127 to 127)

        Returns:
            CounterpointResult with generated notes and quality assessment
        """
        result = CounterpointResult(key=key, scale=scale, style=style)

        if not melody:
            result.warnings.append("Leere Melodie — keine Gegenstimme möglich")
            return result

        if style not in STYLES:
            result.warnings.append(
                f"Unbekannter Stil '{style}', verwende 'thirds_below'"
            )
            style = "thirds_below"
            result.style = style

        # Get scale tones
        scale_intervals = SCALES.get(scale, SCALES["major"])
        root_offset = NOTE_OFFSETS.get(key, 0)

        # Sort melody by start time
        sorted_melody = sorted(melody, key=lambda n: float(n.get("start", 0)))

        # Generate countermelody based on style
        try:
            if style == "thirds_below":
                notes = self._parallel_interval(
                    sorted_melody, scale_intervals, root_offset,
                    interval_degrees=-2, direction="below"
                )
            elif style == "thirds_above":
                notes = self._parallel_interval(
                    sorted_melody, scale_intervals, root_offset,
                    interval_degrees=2, direction="above"
                )
            elif style == "sixths_below":
                notes = self._parallel_interval(
                    sorted_melody, scale_intervals, root_offset,
                    interval_degrees=-5, direction="below"
                )
            elif style == "sixths_above":
                notes = self._parallel_interval(
                    sorted_melody, scale_intervals, root_offset,
                    interval_degrees=5, direction="above"
                )
            elif style == "contrary_motion":
                notes = self._contrary_motion(
                    sorted_melody, scale_intervals, root_offset
                )
            elif style == "oblique":
                notes = self._oblique_motion(
                    sorted_melody, scale_intervals, root_offset
                )
            elif style == "free":
                notes = self._free_counterpoint(
                    sorted_melody, scale_intervals, root_offset
                )
            else:
                notes = self._parallel_interval(
                    sorted_melody, scale_intervals, root_offset,
                    interval_degrees=-2, direction="below"
                )
        except Exception as e:
            log.warning("Counterpoint generation error: %s", e)
            result.warnings.append(f"Generierungsfehler: {e}")
            return result

        # Apply velocity offset
        for n in notes:
            v = n.get("velocity", 80) + velocity_offset
            n["velocity"] = max(1, min(127, v))

        # Post-process: fix parallel fifths/octaves
        if self._avoid_parallel_fifths or self._avoid_parallel_octaves:
            notes = self._fix_parallels(
                sorted_melody, notes, scale_intervals, root_offset
            )

        result.notes = notes
        result.quality_score = self._assess_quality(sorted_melody, notes)

        return result

    def list_styles(self) -> List[str]:
        """Return available counterpoint styles."""
        return list(STYLES)

    # ------------------------------------------------------------------
    # Internal: Scale Helpers
    # ------------------------------------------------------------------

    def _get_scale_pitches(
        self, scale_intervals: List[int], root_offset: int,
        min_pitch: int = 24, max_pitch: int = 96
    ) -> List[int]:
        """Get all MIDI pitches in the scale within a range."""
        pitches = []
        for octave_midi in range(0, 128, 12):
            for interval in scale_intervals:
                p = octave_midi + root_offset + interval
                if min_pitch <= p <= max_pitch:
                    pitches.append(p)
        return sorted(set(pitches))

    def _snap_to_scale(
        self, pitch: int, scale_intervals: List[int], root_offset: int
    ) -> int:
        """Snap a MIDI pitch to the nearest scale tone."""
        pc = (pitch - root_offset) % 12
        if pc in scale_intervals:
            return pitch
        # Find nearest scale tone
        best_dist = 999
        best_pitch = pitch
        for s in scale_intervals:
            dist = min(abs(pc - s), 12 - abs(pc - s))
            if dist < best_dist:
                best_dist = dist
                best_pitch = pitch + (s - pc)
                if abs(s - pc) > 6:
                    best_pitch = pitch - (12 - abs(s - pc))
        return best_pitch

    def _scale_degree_offset(
        self, pitch: int, degrees: int,
        scale_intervals: List[int], root_offset: int
    ) -> int:
        """Move a pitch by N scale degrees (positive = up, negative = down)."""
        all_pitches = self._get_scale_pitches(
            scale_intervals, root_offset,
            min_pitch=max(0, pitch - 24),
            max_pitch=min(127, pitch + 24)
        )
        if not all_pitches:
            return pitch + degrees * 2  # fallback: whole steps

        # Find current position in scale
        snapped = self._snap_to_scale(pitch, scale_intervals, root_offset)
        try:
            idx = all_pitches.index(snapped)
        except ValueError:
            # Find closest
            idx = min(range(len(all_pitches)),
                      key=lambda i: abs(all_pitches[i] - snapped))

        new_idx = idx + degrees
        new_idx = max(0, min(len(all_pitches) - 1, new_idx))
        return all_pitches[new_idx]

    # ------------------------------------------------------------------
    # Internal: Style Generators
    # ------------------------------------------------------------------

    def _parallel_interval(
        self, melody: List[Dict], scale_intervals: List[int],
        root_offset: int, interval_degrees: int = -2,
        direction: str = "below"
    ) -> List[Dict]:
        """Generate parallel thirds/sixths (diatonic)."""
        notes = []
        for note in melody:
            pitch = int(note.get("pitch", 60))
            cp_pitch = self._scale_degree_offset(
                pitch, interval_degrees, scale_intervals, root_offset
            )
            cp_pitch = self._snap_to_scale(cp_pitch, scale_intervals, root_offset)
            notes.append({
                "pitch": cp_pitch,
                "start": float(note.get("start", 0)),
                "duration": float(note.get("duration", 1.0)),
                "velocity": int(note.get("velocity", 80)),
            })
        return notes

    def _contrary_motion(
        self, melody: List[Dict], scale_intervals: List[int],
        root_offset: int
    ) -> List[Dict]:
        """Generate countermelody that moves opposite to melody."""
        if len(melody) < 2:
            return self._parallel_interval(
                melody, scale_intervals, root_offset, -2
            )

        notes = []
        # Start a sixth below the first note
        first_pitch = int(melody[0].get("pitch", 60))
        cp_pitch = self._scale_degree_offset(
            first_pitch, -5, scale_intervals, root_offset
        )
        prev_melody_pitch = first_pitch

        for i, note in enumerate(melody):
            mel_pitch = int(note.get("pitch", 60))

            if i == 0:
                pass  # Use initial cp_pitch
            else:
                # Move contrary to melody direction
                mel_interval = mel_pitch - prev_melody_pitch
                if mel_interval > 0:
                    # Melody goes up → counter goes down
                    cp_pitch = self._scale_degree_offset(
                        cp_pitch,
                        -max(1, abs(mel_interval) // 3),
                        scale_intervals, root_offset
                    )
                elif mel_interval < 0:
                    # Melody goes down → counter goes up
                    cp_pitch = self._scale_degree_offset(
                        cp_pitch,
                        max(1, abs(mel_interval) // 3),
                        scale_intervals, root_offset
                    )
                # If melody stays same, counter can move slightly
                else:
                    cp_pitch = self._scale_degree_offset(
                        cp_pitch,
                        random.choice([-1, 1]),
                        scale_intervals, root_offset
                    )

            cp_pitch = self._snap_to_scale(cp_pitch, scale_intervals, root_offset)
            # Ensure we don't cross the melody
            if cp_pitch >= mel_pitch:
                cp_pitch = self._scale_degree_offset(
                    mel_pitch, -3, scale_intervals, root_offset
                )

            notes.append({
                "pitch": max(24, min(96, cp_pitch)),
                "start": float(note.get("start", 0)),
                "duration": float(note.get("duration", 1.0)),
                "velocity": int(note.get("velocity", 80)),
            })
            prev_melody_pitch = mel_pitch

        return notes

    def _oblique_motion(
        self, melody: List[Dict], scale_intervals: List[int],
        root_offset: int
    ) -> List[Dict]:
        """Generate countermelody with oblique motion (pedal tone + movement)."""
        notes = []
        if not melody:
            return notes

        # Find the tonic as pedal tone
        first_pitch = int(melody[0].get("pitch", 60))
        pedal_pitch = self._snap_to_scale(
            first_pitch - 12, scale_intervals, root_offset
        )

        for i, note in enumerate(melody):
            mel_pitch = int(note.get("pitch", 60))
            # Alternate between pedal and moving note
            if i % 2 == 0:
                cp_pitch = pedal_pitch
            else:
                # Move to a consonant interval
                cp_pitch = self._scale_degree_offset(
                    mel_pitch, -4, scale_intervals, root_offset
                )
                cp_pitch = self._snap_to_scale(
                    cp_pitch, scale_intervals, root_offset
                )

            notes.append({
                "pitch": max(24, min(96, cp_pitch)),
                "start": float(note.get("start", 0)),
                "duration": float(note.get("duration", 1.0)),
                "velocity": int(note.get("velocity", 80)),
            })

        return notes

    def _free_counterpoint(
        self, melody: List[Dict], scale_intervals: List[int],
        root_offset: int
    ) -> List[Dict]:
        """Generate free counterpoint combining multiple techniques."""
        notes = []
        if not melody:
            return notes

        first_pitch = int(melody[0].get("pitch", 60))
        cp_pitch = self._scale_degree_offset(
            first_pitch, -3, scale_intervals, root_offset
        )
        prev_mel = first_pitch

        for i, note in enumerate(melody):
            mel_pitch = int(note.get("pitch", 60))

            if i == 0:
                pass
            else:
                mel_dir = mel_pitch - prev_mel
                # Choose motion type randomly weighted
                r = random.random()
                if r < 0.35:
                    # Contrary motion
                    step = -1 if mel_dir > 0 else (1 if mel_dir < 0 else random.choice([-1, 1]))
                    cp_pitch = self._scale_degree_offset(
                        cp_pitch, step, scale_intervals, root_offset
                    )
                elif r < 0.6:
                    # Parallel thirds
                    cp_pitch = self._scale_degree_offset(
                        mel_pitch, -2, scale_intervals, root_offset
                    )
                elif r < 0.8:
                    # Oblique (hold)
                    pass  # keep cp_pitch
                else:
                    # Leap to consonance
                    target_intervals = [-3, -5, -7, 4, 5]
                    deg = random.choice(target_intervals)
                    cp_pitch = self._scale_degree_offset(
                        mel_pitch, deg, scale_intervals, root_offset
                    )

            cp_pitch = self._snap_to_scale(cp_pitch, scale_intervals, root_offset)
            cp_pitch = max(24, min(96, cp_pitch))

            notes.append({
                "pitch": cp_pitch,
                "start": float(note.get("start", 0)),
                "duration": float(note.get("duration", 1.0)),
                "velocity": int(note.get("velocity", 80)),
            })
            prev_mel = mel_pitch

        return notes

    # ------------------------------------------------------------------
    # Internal: Voice Leading Fixes
    # ------------------------------------------------------------------

    def _fix_parallels(
        self, melody: List[Dict], counter: List[Dict],
        scale_intervals: List[int], root_offset: int
    ) -> List[Dict]:
        """Fix parallel fifths and octaves (classical rule)."""
        if len(melody) < 2 or len(counter) < 2:
            return counter

        fixed = [dict(counter[0])]
        for i in range(1, min(len(melody), len(counter))):
            mel_prev = int(melody[i-1].get("pitch", 60))
            mel_curr = int(melody[i].get("pitch", 60))
            cp_prev = int(fixed[i-1].get("pitch", 60))
            cp_curr = int(counter[i].get("pitch", 60))

            interval_prev = abs(mel_prev - cp_prev) % 12
            interval_curr = abs(mel_curr - cp_curr) % 12

            needs_fix = False
            if self._avoid_parallel_fifths and interval_prev == 7 and interval_curr == 7:
                needs_fix = True
            if self._avoid_parallel_octaves and interval_prev == 0 and interval_curr == 0:
                needs_fix = True

            if needs_fix:
                # Shift by one scale degree
                cp_curr = self._scale_degree_offset(
                    cp_curr, random.choice([-1, 1]),
                    scale_intervals, root_offset
                )
                cp_curr = self._snap_to_scale(
                    cp_curr, scale_intervals, root_offset
                )

            note = dict(counter[i])
            note["pitch"] = max(24, min(96, cp_curr))
            fixed.append(note)

        return fixed

    # ------------------------------------------------------------------
    # Internal: Quality Assessment
    # ------------------------------------------------------------------

    def _assess_quality(
        self, melody: List[Dict], counter: List[Dict]
    ) -> float:
        """Assess the quality of the countermelody (0.0 to 1.0)."""
        if not melody or not counter:
            return 0.0

        score = 1.0
        n = min(len(melody), len(counter))
        penalties = 0.0

        for i in range(n):
            mel_p = int(melody[i].get("pitch", 60))
            cp_p = int(counter[i].get("pitch", 60))
            interval = abs(mel_p - cp_p) % 12

            # Reward consonances
            if interval in IMPERFECT_CONSONANCES:
                pass  # Best — no penalty
            elif interval in PERFECT_CONSONANCES:
                penalties += 0.02  # Slight penalty for perfect consonances (less interesting)
            elif interval in DISSONANCES:
                penalties += 0.05  # Moderate penalty

            # Check voice crossing
            if cp_p > mel_p + 12:
                penalties += 0.03  # Voice crossing far above melody

        # Check for large leaps in countermelody
        for i in range(1, len(counter)):
            leap = abs(int(counter[i].get("pitch", 60)) - int(counter[i-1].get("pitch", 60)))
            if leap > self._max_leap:
                penalties += 0.05
            elif leap > 7:
                penalties += 0.02

        score = max(0.0, min(1.0, score - penalties))
        return round(score, 2)
