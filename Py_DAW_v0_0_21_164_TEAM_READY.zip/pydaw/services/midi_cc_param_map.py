"""PH-3.6: MIDI CC → Plugin Parameter Mapping Service.

Manages CC-to-parameter mappings for Rust-hosted external plugins.
When a MIDI Learn is completed for an external plugin parameter,
this service forwards the mapping to the Rust engine so that CC
events are applied directly in the audio thread (zero-latency).

v0.0.21.138: Initial implementation.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


@dataclass
class CCParamMapping:
    """A single CC → Plugin Parameter mapping."""
    track_id: str
    slot_index: int
    cc_channel: int
    cc_number: int
    param_name: str
    param_index: int = -1  # -1 = unknown, Rust uses param_name fallback

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "CCParamMapping":
        return cls(
            track_id=str(d.get("track_id", "")),
            slot_index=int(d.get("slot_index", 0)),
            cc_channel=int(d.get("cc_channel", 0)),
            cc_number=int(d.get("cc_number", 0)),
            param_name=str(d.get("param_name", "")),
            param_index=int(d.get("param_index", -1)),
        )


class MidiCCParamMapService:
    """Manages MIDI CC → Plugin Param mappings and forwards to Rust.

    Usage:
        svc = MidiCCParamMapService()
        svc.add_mapping(track_id="t1", slot_index=0,
                        cc_channel=0, cc_number=1, param_name="cutoff")
        svc.sync_all_to_rust()  # call on play or project load
    """

    _instance: Optional["MidiCCParamMapService"] = None

    def __init__(self):
        self._mappings: Dict[Tuple[str, int, int, int], CCParamMapping] = {}
        # key = (track_id, slot_index, cc_channel, cc_number)

    @classmethod
    def instance(cls) -> "MidiCCParamMapService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def add_mapping(
        self,
        track_id: str,
        slot_index: int,
        cc_channel: int,
        cc_number: int,
        param_name: str,
        param_index: int = -1,
    ) -> CCParamMapping:
        """Add or update a CC → Param mapping and forward to Rust."""
        m = CCParamMapping(
            track_id=str(track_id),
            slot_index=int(slot_index),
            cc_channel=int(cc_channel),
            cc_number=int(cc_number),
            param_name=str(param_name),
            param_index=int(param_index),
        )
        key = (m.track_id, m.slot_index, m.cc_channel, m.cc_number)
        self._mappings[key] = m
        log.debug("[PH-3.6] add_mapping track=%s slot=%d ch=%d cc=%d → param=%s idx=%d",
                  m.track_id, m.slot_index, m.cc_channel, m.cc_number,
                  m.param_name, m.param_index)
        self._forward_to_rust(m)
        return m

    def remove_mapping(
        self,
        track_id: str,
        slot_index: int,
        cc_channel: int,
        cc_number: int,
    ) -> None:
        """Remove a mapping and notify Rust."""
        key = (str(track_id), int(slot_index), int(cc_channel), int(cc_number))
        removed = self._mappings.pop(key, None)
        if removed:
            log.debug("[PH-3.6] remove_mapping track=%s slot=%d ch=%d cc=%d",
                      track_id, slot_index, cc_channel, cc_number)

    def remove_all_for_slot(self, track_id: str, slot_index: int) -> None:
        """Remove all mappings for a track/slot (e.g. on plugin unload)."""
        keys_to_remove = [
            k for k in self._mappings
            if k[0] == str(track_id) and k[1] == int(slot_index)
        ]
        for k in keys_to_remove:
            self._mappings.pop(k, None)
        if keys_to_remove:
            log.debug("[PH-3.6] remove_all_for_slot track=%s slot=%d count=%d",
                      track_id, slot_index, len(keys_to_remove))
            # Also clear in Rust
            try:
                from pydaw.services.rust_engine_bridge import RustEngineBridge
                bridge = RustEngineBridge.instance()
                if bridge and bridge.is_connected:
                    bridge.clear_midi_cc_param_map(str(track_id), int(slot_index))
            except Exception:
                pass

    def get_mappings_for_slot(self, track_id: str, slot_index: int) -> List[CCParamMapping]:
        """Return all mappings for a specific track/slot."""
        return [
            m for m in self._mappings.values()
            if m.track_id == str(track_id) and m.slot_index == int(slot_index)
        ]

    def get_all_mappings(self) -> List[CCParamMapping]:
        """Return all mappings."""
        return list(self._mappings.values())

    def _forward_to_rust(self, m: CCParamMapping) -> None:
        """Forward a single mapping to Rust engine."""
        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            bridge = RustEngineBridge.instance()
            if bridge and bridge.is_connected:
                idx = m.param_index if m.param_index >= 0 else m.cc_number
                bridge.midi_cc_param_map(m.track_id, m.slot_index,
                                         m.cc_number, idx)
                log.debug("[PH-3.6] forwarded to Rust: track=%s slot=%d cc=%d → param_idx=%d",
                          m.track_id, m.slot_index, m.cc_number, idx)
        except Exception:
            pass

    def sync_all_to_rust(self) -> int:
        """Re-forward all mappings to Rust (call on play/project load).

        Returns number of mappings forwarded.
        """
        count = 0
        for m in self._mappings.values():
            self._forward_to_rust(m)
            count += 1
        if count:
            log.debug("[PH-3.6] sync_all_to_rust: %d mappings forwarded", count)
        return count

    # --- Persistence ---

    def to_list(self) -> List[dict]:
        """Serialize all mappings for project JSON."""
        return [m.to_dict() for m in self._mappings.values()]

    def from_list(self, data: List[dict]) -> None:
        """Load mappings from project JSON."""
        self._mappings.clear()
        for d in (data or []):
            try:
                m = CCParamMapping.from_dict(d)
                key = (m.track_id, m.slot_index, m.cc_channel, m.cc_number)
                self._mappings[key] = m
            except Exception:
                pass
        if self._mappings:
            log.debug("[PH-3.6] loaded %d CC→Param mappings from project", len(self._mappings))
