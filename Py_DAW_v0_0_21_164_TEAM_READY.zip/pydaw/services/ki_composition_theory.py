"""ki_composition_theory.py — KK1: Musiktheorie-Engine (v0.0.20.958).

Vollständiges musiktheoretisches Fundament für die KI-Kompositions-Engine.
Rein mathematisch, keine neuronalen Netze.

Features:
  - Alle Skalen: Kirchentonarten, Dur/Moll, Harmonisch/Melodisch, Exotisch
  - Akkord-Generierung: Dreiklänge bis Nonenakkorde, Umkehrungen
  - Stimmführung: Parallelen-Verbot, Gegenbewegung, Auflösungen
  - Kadenz-System: Authentisch, Plagal, Trugschluss, Halbschluss
  - Generalbass: Bezifferte Bass → volle Akkorde
  - Tonart-Erkennung: Aus Notenfolge Tonart ableiten
  - Modulation: Diatonisch, Chromatisch, Enharmonisch

Usage:
    from pydaw.services.ki_composition_theory import (
        Scale, Chord, VoiceLeader, CadenceEngine,
        KeyDetector, Modulator, IntervalName,
    )

    # Skala erzeugen
    scale = Scale("D", "dorian")
    notes = scale.get_notes()  # [62, 64, 65, 67, 69, 71, 72, 74]

    # Akkord erzeugen
    chord = Chord.from_scale(scale, degree=1)  # Dm
    chord_notes = chord.notes  # [62, 65, 69]

    # Kadenz
    cadence = CadenceEngine(scale)
    progression = cadence.authentic()  # V → I

    # Tonart erkennen
    key = KeyDetector.detect([62, 64, 65, 67, 69, 71, 72])
    # → ("D", "dorian", 0.95)

What NO other DAW has:
    A built-in music theory engine that understands church modes,
    counterpoint rules, and can generate harmonically correct
    progressions from any epoch.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════

# Note names
NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
NOTE_NAMES_FLAT = ["C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B"]

# Enharmonic equivalents
ENHARMONIC = {
    "Db": "C#", "Eb": "D#", "Fb": "E", "Gb": "F#", "Ab": "G#",
    "Bb": "A#", "Cb": "B", "E#": "F", "B#": "C",
}

# Note name → pitch class (0–11)
_NAME_TO_PC: Dict[str, int] = {}
for i, n in enumerate(NOTE_NAMES):
    _NAME_TO_PC[n] = i
for i, n in enumerate(NOTE_NAMES_FLAT):
    _NAME_TO_PC[n] = i
for k, v in ENHARMONIC.items():
    _NAME_TO_PC[k] = _NAME_TO_PC[v]

# MIDI note 60 = Middle C (C4)
MIDDLE_C = 60


def note_name_to_pc(name: str) -> int:
    """Convert note name to pitch class (0–11)."""
    return _NAME_TO_PC.get(name, _NAME_TO_PC.get(name.capitalize(), 0))


def pc_to_note_name(pc: int, prefer_flat: bool = False) -> str:
    """Convert pitch class (0–11) to note name."""
    pc = pc % 12
    return NOTE_NAMES_FLAT[pc] if prefer_flat else NOTE_NAMES[pc]


def midi_to_name(midi: int) -> str:
    """Convert MIDI note to name + octave (e.g., 60 → 'C4')."""
    octave = (midi // 12) - 1
    pc = midi % 12
    return f"{NOTE_NAMES[pc]}{octave}"


def name_to_midi(name: str) -> int:
    """Convert name + octave to MIDI (e.g., 'C4' → 60)."""
    # Parse "C#4", "Db3", etc.
    if len(name) < 2:
        return 60
    if name[-1].isdigit():
        if len(name) >= 3 and name[-2].isdigit():
            # e.g., "-1" octave (unlikely)
            note_part = name[:-2]
            octave = int(name[-2:])
        else:
            note_part = name[:-1]
            octave = int(name[-1])
    else:
        note_part = name
        octave = 4
    pc = note_name_to_pc(note_part)
    return (octave + 1) * 12 + pc


# ═══════════════════════════════════════════════════════════════
# Intervals
# ═══════════════════════════════════════════════════════════════

class IntervalName(Enum):
    """Musical interval names."""
    UNISON = 0
    MINOR_SECOND = 1
    MAJOR_SECOND = 2
    MINOR_THIRD = 3
    MAJOR_THIRD = 4
    PERFECT_FOURTH = 5
    TRITONE = 6
    PERFECT_FIFTH = 7
    MINOR_SIXTH = 8
    MAJOR_SIXTH = 9
    MINOR_SEVENTH = 10
    MAJOR_SEVENTH = 11
    OCTAVE = 12


def interval_name(semitones: int) -> str:
    """Get human-readable interval name."""
    names = {
        0: "Unison", 1: "m2", 2: "M2", 3: "m3", 4: "M3",
        5: "P4", 6: "TT", 7: "P5", 8: "m6", 9: "M6",
        10: "m7", 11: "M7", 12: "P8",
    }
    s = semitones % 12
    octaves = semitones // 12
    base = names.get(s, f"{s}st")
    if octaves > 1:
        return f"{base}+{octaves}oct"
    return base


def is_consonant(semitones: int) -> bool:
    """Check if an interval is consonant (for counterpoint)."""
    s = abs(semitones) % 12
    # Perfect consonances: unison, fifth, octave
    # Imperfect consonances: thirds, sixths
    return s in (0, 3, 4, 7, 8, 9, 12)


def is_perfect_consonance(semitones: int) -> bool:
    """Check if interval is a perfect consonance."""
    s = abs(semitones) % 12
    return s in (0, 7, 12)


# ═══════════════════════════════════════════════════════════════
# Scale System
# ═══════════════════════════════════════════════════════════════

# Scale definitions: name → intervals from root
SCALE_INTERVALS: Dict[str, List[int]] = {
    # ── Kirchentonarten (Church Modes) ──
    "ionian":     [0, 2, 4, 5, 7, 9, 11],   # = Dur
    "dorian":     [0, 2, 3, 5, 7, 9, 10],
    "phrygian":   [0, 1, 3, 5, 7, 8, 10],
    "lydian":     [0, 2, 4, 6, 7, 9, 11],
    "mixolydian": [0, 2, 4, 5, 7, 9, 10],
    "aeolian":    [0, 2, 3, 5, 7, 8, 10],   # = Natürlich Moll
    "locrian":    [0, 1, 3, 5, 6, 8, 10],

    # ── Standard ──
    "major":           [0, 2, 4, 5, 7, 9, 11],
    "minor":           [0, 2, 3, 5, 7, 8, 10],
    "harmonic_minor":  [0, 2, 3, 5, 7, 8, 11],
    "melodic_minor":   [0, 2, 3, 5, 7, 9, 11],

    # ── Pentatonik ──
    "major_pentatonic": [0, 2, 4, 7, 9],
    "minor_pentatonic": [0, 3, 5, 7, 10],
    "blues":            [0, 3, 5, 6, 7, 10],

    # ── Jazz ──
    "whole_tone":       [0, 2, 4, 6, 8, 10],
    "diminished":       [0, 2, 3, 5, 6, 8, 9, 11],  # Ganzton-Halbton
    "diminished_half":  [0, 1, 3, 4, 6, 7, 9, 10],  # Halbton-Ganzton
    "bebop_dominant":   [0, 2, 4, 5, 7, 9, 10, 11],
    "bebop_major":      [0, 2, 4, 5, 7, 8, 9, 11],
    "altered":          [0, 1, 3, 4, 6, 8, 10],      # Super Locrian

    # ── Exotisch ──
    "hungarian_minor":  [0, 2, 3, 6, 7, 8, 11],
    "double_harmonic":  [0, 1, 4, 5, 7, 8, 11],  # Byzantinisch
    "phrygian_dominant":[0, 1, 4, 5, 7, 8, 10],  # Spanisch
    "hirajoshi":        [0, 2, 3, 7, 8],           # Japanisch
    "in_sen":           [0, 1, 5, 7, 10],          # Japanisch
    "persian":          [0, 1, 4, 5, 6, 8, 11],

    # ── Gregorianik ──
    "gregorian_mode1":  [0, 2, 3, 5, 7, 9, 10],  # Protus authenticus (= Dorian)
    "gregorian_mode3":  [0, 1, 3, 5, 7, 8, 10],  # Deuterus authenticus (= Phrygian)
    "gregorian_mode5":  [0, 2, 4, 6, 7, 9, 11],  # Tritus authenticus (= Lydian)
    "gregorian_mode7":  [0, 2, 4, 5, 7, 9, 10],  # Tetrardus authenticus (= Mixolydian)

    # ── Chromatic ──
    "chromatic":        list(range(12)),
}

# Aliases
SCALE_ALIASES: Dict[str, str] = {
    "dur": "major", "moll": "minor",
    "natürlich_moll": "minor", "nat_moll": "minor",
    "harm_moll": "harmonic_minor", "mel_moll": "melodic_minor",
    "kirche_1": "dorian", "kirche_2": "phrygian",
    "kirche_3": "lydian", "kirche_4": "mixolydian",
    "kirche_5": "aeolian", "kirche_6": "locrian",
    "church_1": "dorian", "church_2": "phrygian",
}


@dataclass
class Scale:
    """Musical scale with root note and mode.

    Examples:
        Scale("C", "major")       → C Dur
        Scale("D", "dorian")      → D Dorisch
        Scale("A", "harmonic_minor") → A Harmonisch Moll
    """

    root: str
    mode: str
    octave: int = 4

    def __post_init__(self):
        # Resolve aliases
        self.mode = SCALE_ALIASES.get(self.mode.lower(), self.mode.lower())
        if self.mode not in SCALE_INTERVALS:
            log.warning("Unknown scale mode: %s, falling back to major", self.mode)
            self.mode = "major"

    @property
    def root_pc(self) -> int:
        """Root pitch class (0–11)."""
        return note_name_to_pc(self.root)

    @property
    def root_midi(self) -> int:
        """Root MIDI note in the specified octave."""
        return (self.octave + 1) * 12 + self.root_pc

    @property
    def intervals(self) -> List[int]:
        """Scale intervals from root."""
        return SCALE_INTERVALS[self.mode]

    def get_notes(self, octaves: int = 1) -> List[int]:
        """Get MIDI notes for the scale across octaves."""
        notes = []
        for o in range(octaves):
            for interval in self.intervals:
                n = self.root_midi + o * 12 + interval
                if 0 <= n <= 127:
                    notes.append(n)
        return notes

    def get_note_names(self) -> List[str]:
        """Get note names in the scale."""
        return [pc_to_note_name((self.root_pc + i) % 12) for i in self.intervals]

    def degree_to_midi(self, degree: int, octave_offset: int = 0) -> int:
        """Convert scale degree (1-based) to MIDI note.

        degree=1 → root, degree=2 → second, etc.
        """
        idx = (degree - 1) % len(self.intervals)
        octave_add = (degree - 1) // len(self.intervals)
        return self.root_midi + self.intervals[idx] + (octave_add + octave_offset) * 12

    def contains(self, midi_note: int) -> bool:
        """Check if a MIDI note belongs to this scale."""
        pc = (midi_note - self.root_pc) % 12
        return pc in self.intervals

    def degree_of(self, midi_note: int) -> Optional[int]:
        """Get the scale degree (1-based) of a MIDI note, or None."""
        pc = (midi_note - self.root_pc) % 12
        if pc in self.intervals:
            return self.intervals.index(pc) + 1
        return None

    def parallel(self) -> "Scale":
        """Get parallel scale (same root, major↔minor)."""
        if self.mode in ("major", "ionian"):
            return Scale(self.root, "minor", self.octave)
        elif self.mode in ("minor", "aeolian"):
            return Scale(self.root, "major", self.octave)
        return Scale(self.root, self.mode, self.octave)

    def relative(self) -> "Scale":
        """Get relative scale (e.g., C major → A minor)."""
        if self.mode in ("major", "ionian"):
            # Relative minor is 3 semitones down
            new_root_pc = (self.root_pc - 3) % 12
            return Scale(pc_to_note_name(new_root_pc), "minor", self.octave)
        elif self.mode in ("minor", "aeolian"):
            # Relative major is 3 semitones up
            new_root_pc = (self.root_pc + 3) % 12
            return Scale(pc_to_note_name(new_root_pc), "major", self.octave)
        return Scale(self.root, self.mode, self.octave)

    def to_dict(self) -> dict:
        return {"root": self.root, "mode": self.mode, "octave": self.octave}

    @staticmethod
    def from_dict(d: dict) -> "Scale":
        return Scale(d["root"], d["mode"], d.get("octave", 4))

    def __repr__(self) -> str:
        return f"Scale({self.root} {self.mode})"


# ═══════════════════════════════════════════════════════════════
# Chord System
# ═══════════════════════════════════════════════════════════════

class ChordQuality(Enum):
    """Chord quality types."""
    MAJOR = "major"
    MINOR = "minor"
    DIMINISHED = "diminished"
    AUGMENTED = "augmented"
    DOMINANT_7 = "dom7"
    MAJOR_7 = "maj7"
    MINOR_7 = "min7"
    HALF_DIM_7 = "half_dim7"   # ø7
    DIM_7 = "dim7"             # °7
    SUS2 = "sus2"
    SUS4 = "sus4"
    ADD9 = "add9"
    MINOR_9 = "min9"
    DOMINANT_9 = "dom9"
    POWER = "power"             # nur Root + Quinte


# Chord quality → intervals from root
CHORD_INTERVALS: Dict[str, List[int]] = {
    "major":      [0, 4, 7],
    "minor":      [0, 3, 7],
    "diminished": [0, 3, 6],
    "augmented":  [0, 4, 8],
    "dom7":       [0, 4, 7, 10],
    "maj7":       [0, 4, 7, 11],
    "min7":       [0, 3, 7, 10],
    "half_dim7":  [0, 3, 6, 10],
    "dim7":       [0, 3, 6, 9],
    "sus2":       [0, 2, 7],
    "sus4":       [0, 5, 7],
    "add9":       [0, 4, 7, 14],
    "min9":       [0, 3, 7, 10, 14],
    "dom9":       [0, 4, 7, 10, 14],
    "power":      [0, 7],
    # Spezial
    "neapolitan":      [0, 1, 5],         # bII in first inversion
    "tristan":         [0, 3, 6, 10],     # = half_dim7 (Wagner)
    "augmented_sixth": [0, 4, 8, 10],     # It+6 / Ger+6
    "mystic":          [0, 6, 10, 16, 21, 26],  # Scriabin Prometheus
}

# Scale degree → chord quality (for diatonic chords in major)
MAJOR_DIATONIC_QUALITIES = [
    "major", "minor", "minor", "major", "major", "minor", "diminished"
]

# Scale degree → chord quality (for diatonic chords in minor)
MINOR_DIATONIC_QUALITIES = [
    "minor", "diminished", "major", "minor", "minor", "major", "major"
]

# Roman numeral labels
ROMAN_NUMERALS = ["I", "II", "III", "IV", "V", "VI", "VII"]


@dataclass
class Chord:
    """A musical chord.

    Examples:
        Chord("C", "major")        → C Major (C E G)
        Chord("D", "minor")        → D Minor (D F A)
        Chord("G", "dom7")         → G7 (G B D F)
        Chord("F#", "diminished")  → F#° (F# A C)
    """

    root: str
    quality: str
    inversion: int = 0     # 0=root, 1=first, 2=second, 3=third
    bass_note: str = ""    # Optional: explicit bass note (slash chords)

    @property
    def root_pc(self) -> int:
        return note_name_to_pc(self.root)

    @property
    def intervals(self) -> List[int]:
        return CHORD_INTERVALS.get(self.quality, [0, 4, 7])

    @property
    def notes_pc(self) -> List[int]:
        """Pitch classes of all chord tones."""
        return [(self.root_pc + i) % 12 for i in self.intervals]

    def get_notes(self, octave: int = 4, voicing: str = "close") -> List[int]:
        """Get MIDI notes for the chord.

        voicing: "close" (default), "open", "drop2", "drop3"
        """
        base = (octave + 1) * 12 + self.root_pc
        notes = [base + i for i in self.intervals]

        # Apply inversion
        for _ in range(min(self.inversion, len(notes) - 1)):
            notes[0] += 12
            notes = notes[1:] + [notes[0]]

        # Apply voicing
        if voicing == "open" and len(notes) >= 3:
            # Move middle note up an octave
            notes[1] += 12
        elif voicing == "drop2" and len(notes) >= 4:
            # Drop second note from top down an octave
            notes[-2] -= 12
            notes.sort()
        elif voicing == "drop3" and len(notes) >= 4:
            # Drop third note from top down an octave
            notes[-3] -= 12
            notes.sort()

        return sorted(notes)

    @property
    def name(self) -> str:
        """Chord name (e.g., 'Cm7', 'G', 'F#dim')."""
        suffixes = {
            "major": "", "minor": "m", "diminished": "dim",
            "augmented": "aug", "dom7": "7", "maj7": "maj7",
            "min7": "m7", "half_dim7": "ø7", "dim7": "°7",
            "sus2": "sus2", "sus4": "sus4", "add9": "add9",
            "min9": "m9", "dom9": "9", "power": "5",
        }
        suffix = suffixes.get(self.quality, self.quality)
        inv = ""
        if self.inversion > 0:
            inv = f"/{midi_to_name(self.get_notes()[0])}"
        return f"{self.root}{suffix}{inv}"

    @staticmethod
    def from_scale(scale: Scale, degree: int,
                   seventh: bool = False) -> "Chord":
        """Build a diatonic chord from a scale degree (1-based).

        Args:
            scale: The scale to build from
            degree: 1-based degree (1=tonic, 5=dominant, etc.)
            seventh: If True, build a seventh chord
        """
        idx = (degree - 1) % len(scale.intervals)
        root_pc = (scale.root_pc + scale.intervals[idx]) % 12
        root_name = pc_to_note_name(root_pc)

        # Determine quality from scale intervals
        if scale.mode in ("major", "ionian", "lydian", "mixolydian"):
            qualities = MAJOR_DIATONIC_QUALITIES
        else:
            qualities = MINOR_DIATONIC_QUALITIES

        quality = qualities[idx] if idx < len(qualities) else "major"

        if seventh:
            if quality == "major":
                quality = "maj7" if idx != 4 else "dom7"  # V → dom7
            elif quality == "minor":
                quality = "min7"
            elif quality == "diminished":
                quality = "half_dim7"

        return Chord(root_name, quality)

    @staticmethod
    def from_roman(roman: str, key: Scale) -> "Chord":
        """Parse Roman numeral chord notation.

        Examples: "I", "ii", "V7", "bVII", "viio", "IV/V"
        """
        s = roman.strip()
        flat = s.startswith("b")
        if flat:
            s = s[1:]

        # Determine degree and quality from case
        upper = s.upper()
        degree = 0
        for i, numeral in enumerate(ROMAN_NUMERALS):
            if upper.startswith(numeral):
                degree = i + 1
                s = s[len(numeral):]
                break

        if degree == 0:
            return Chord("C", "major")

        is_minor = roman.lstrip("b")[0:len(ROMAN_NUMERALS[degree-1])].islower()

        # Quality suffixes
        quality = "minor" if is_minor else "major"
        if "o" in s or "dim" in s:
            quality = "diminished"
        elif "+" in s or "aug" in s:
            quality = "augmented"

        seventh = "7" in s
        if seventh:
            if quality == "major":
                quality = "dom7" if degree == 5 else "maj7"
            elif quality == "minor":
                quality = "min7"
            elif quality == "diminished":
                quality = "half_dim7"

        root_pc = (key.root_pc + key.intervals[(degree - 1) % len(key.intervals)]) % 12
        if flat:
            root_pc = (root_pc - 1) % 12

        return Chord(pc_to_note_name(root_pc), quality)

    def to_dict(self) -> dict:
        return {
            "root": self.root, "quality": self.quality,
            "inversion": self.inversion, "name": self.name,
        }

    def __repr__(self) -> str:
        return f"Chord({self.name})"


# ═══════════════════════════════════════════════════════════════
# Voice Leading
# ═══════════════════════════════════════════════════════════════

@dataclass
class VoiceLeadingRule:
    """A single voice leading rule."""
    name: str
    description: str
    severity: str = "error"   # "error", "warning", "info"


class VoiceLeader:
    """Voice leading checker and optimizer.

    Implements classical counterpoint rules:
    - No parallel fifths or octaves
    - Prefer contrary/oblique motion
    - Leading tone resolves up to tonic
    - Seventh resolves down by step
    - Avoid voice crossing
    - Keep common tones
    """

    @staticmethod
    def check_parallels(voice1_from: int, voice1_to: int,
                         voice2_from: int, voice2_to: int) -> List[str]:
        """Check for parallel fifths/octaves between two voices."""
        issues = []
        interval_before = abs(voice1_from - voice2_from) % 12
        interval_after = abs(voice1_to - voice2_to) % 12

        # Both voices move in the same direction?
        motion1 = voice1_to - voice1_from
        motion2 = voice2_to - voice2_from
        same_direction = (motion1 > 0 and motion2 > 0) or (motion1 < 0 and motion2 < 0)

        if same_direction:
            if interval_before == 7 and interval_after == 7:
                issues.append("Parallele Quinten (verboten)")
            elif interval_before == 0 and interval_after == 0 and motion1 != 0:
                issues.append("Parallele Oktaven/Primen (verboten)")

        # Hidden (direct) fifths/octaves
        if same_direction and interval_after in (0, 7):
            if abs(motion1) > 2 or abs(motion2) > 2:
                issues.append(f"Verdeckte {'Oktave' if interval_after == 0 else 'Quinte'} (Warnung)")

        return issues

    @staticmethod
    def motion_type(v1_from: int, v1_to: int,
                     v2_from: int, v2_to: int) -> str:
        """Classify the type of motion between two voices."""
        m1 = v1_to - v1_from
        m2 = v2_to - v2_from

        if m1 == 0 and m2 == 0:
            return "stationary"
        elif m1 == 0 or m2 == 0:
            return "oblique"
        elif (m1 > 0 and m2 > 0) or (m1 < 0 and m2 < 0):
            return "parallel"
        else:
            return "contrary"

    @staticmethod
    def optimal_voice_leading(chord1: Chord, chord2: Chord,
                                octave: int = 4) -> List[int]:
        """Find the voicing of chord2 that minimizes total voice movement.

        Returns MIDI notes for chord2.
        """
        notes1 = chord1.get_notes(octave)
        notes2_base = chord2.get_notes(octave)

        # Try different inversions and pick the one with least movement
        best_notes = notes2_base
        best_cost = sum(abs(a - b) for a, b in zip(notes1, notes2_base))

        for inv in range(len(notes2_base)):
            candidate = chord2.get_notes(octave)
            # Rotate
            for _ in range(inv):
                candidate[0] += 12
                candidate = candidate[1:] + [candidate[0]]
            candidate = sorted(candidate)

            # Also try octave down
            for shift in [0, -12]:
                shifted = [n + shift for n in candidate]
                if all(0 <= n <= 127 for n in shifted):
                    cost = sum(abs(a - b) for a, b in zip(notes1, shifted))
                    if cost < best_cost:
                        best_cost = cost
                        best_notes = shifted

        return sorted(best_notes)

    @staticmethod
    def check_voice_crossing(voices: List[List[int]]) -> List[str]:
        """Check if any voices cross (higher voice goes below lower voice)."""
        issues = []
        for i in range(len(voices) - 1):
            for j in range(i + 1, len(voices)):
                for beat in range(min(len(voices[i]), len(voices[j]))):
                    if voices[i][beat] > voices[j][beat]:
                        issues.append(
                            f"Stimmkreuzung Beat {beat}: "
                            f"Stimme {i+1} ({voices[i][beat]}) > "
                            f"Stimme {j+1} ({voices[j][beat]})")
        return issues

    @staticmethod
    def resolve_leading_tone(note: int, scale: Scale) -> int:
        """Resolve a leading tone upward to the tonic."""
        leading_tone = (scale.root_pc - 1) % 12
        if note % 12 == leading_tone:
            return note + 1  # Half step up to tonic
        return note

    @staticmethod
    def resolve_seventh(note: int, chord: Chord) -> int:
        """Resolve the seventh of a chord downward by step."""
        if len(chord.intervals) >= 4:
            seventh_pc = (chord.root_pc + chord.intervals[3]) % 12
            if note % 12 == seventh_pc:
                return note - 1  # Half step down (or whole step)
        return note


# ═══════════════════════════════════════════════════════════════
# Cadence System
# ═══════════════════════════════════════════════════════════════

@dataclass
class CadenceResult:
    """A cadence (chord progression ending)."""
    name: str
    chords: List[Chord]
    roman: str

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "chords": [c.to_dict() for c in self.chords],
            "roman": self.roman,
        }


class CadenceEngine:
    """Generate cadences in any key.

    Cadences:
        authentic:    V → I  (perfekt)
        imperfect:    V → I  (unvollkommen — Umkehrung oder Sopran nicht auf Grundton)
        plagal:       IV → I (Amen-Kadenz)
        half:         ? → V  (Halbschluss)
        deceptive:    V → vi (Trugschluss)
        phrygian:     iv6 → V (Phrygischer Halbschluss)
        picardy:      V → I  (Moll → Dur-Tonika = Picardie)
    """

    def __init__(self, scale: Scale):
        self.scale = scale

    def authentic(self, seventh: bool = True) -> CadenceResult:
        """Perfect authentic cadence: V(7) → I."""
        v = Chord.from_scale(self.scale, 5, seventh=seventh)
        i = Chord.from_scale(self.scale, 1)
        return CadenceResult("Authentische Kadenz", [v, i], "V7 → I")

    def plagal(self) -> CadenceResult:
        """Plagal cadence: IV → I (Amen)."""
        iv = Chord.from_scale(self.scale, 4)
        i = Chord.from_scale(self.scale, 1)
        return CadenceResult("Plagale Kadenz (Amen)", [iv, i], "IV → I")

    def half(self) -> CadenceResult:
        """Half cadence: I → V."""
        i = Chord.from_scale(self.scale, 1)
        v = Chord.from_scale(self.scale, 5)
        return CadenceResult("Halbschluss", [i, v], "I → V")

    def deceptive(self) -> CadenceResult:
        """Deceptive cadence: V → vi."""
        v = Chord.from_scale(self.scale, 5, seventh=True)
        vi = Chord.from_scale(self.scale, 6)
        return CadenceResult("Trugschluss", [v, vi], "V7 → vi")

    def phrygian(self) -> CadenceResult:
        """Phrygian half cadence: iv6 → V (typical in Baroque)."""
        iv = Chord.from_scale(self.scale, 4)
        iv.inversion = 1
        v = Chord.from_scale(self.scale, 5)
        return CadenceResult("Phrygischer Halbschluss", [iv, v], "iv6 → V")

    def picardy(self) -> CadenceResult:
        """Picardy third: V → I with major tonic (in minor key)."""
        v = Chord.from_scale(self.scale, 5, seventh=True)
        # Force major tonic
        i = Chord(self.scale.root, "major")
        return CadenceResult("Picardische Terz", [v, i], "V7 → I (Dur)")

    def circle_of_fifths(self, length: int = 4) -> CadenceResult:
        """Circle of fifths progression: vi → ii → V → I."""
        degrees = [6, 2, 5, 1][:length]
        chords = [Chord.from_scale(self.scale, d, seventh=(d == 5)) for d in degrees]
        roman = " → ".join(ROMAN_NUMERALS[d-1] for d in degrees)
        return CadenceResult("Quintfallsequenz", chords, roman)

    def all_cadences(self) -> List[CadenceResult]:
        """Get all available cadences."""
        return [
            self.authentic(),
            self.plagal(),
            self.half(),
            self.deceptive(),
            self.phrygian(),
            self.picardy(),
            self.circle_of_fifths(),
        ]


# ═══════════════════════════════════════════════════════════════
# Key Detection
# ═══════════════════════════════════════════════════════════════

class KeyDetector:
    """Detect the key/mode of a series of MIDI notes.

    Uses the Krumhansl-Kessler key-finding algorithm:
    Correlate pitch class distribution with key profiles.
    """

    # Krumhansl-Kessler key profiles (correlation weights)
    _MAJOR_PROFILE = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52,
                       5.19, 2.39, 3.66, 2.29, 2.88]
    _MINOR_PROFILE = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54,
                       4.75, 3.98, 2.69, 3.34, 3.17]

    @classmethod
    def detect(cls, midi_notes: List[int],
               include_modes: bool = True) -> List[Tuple[str, str, float]]:
        """Detect likely key(s) from MIDI notes.

        Returns list of (root, mode, confidence) sorted by confidence.
        """
        if not midi_notes:
            return [("C", "major", 0.0)]

        # Build pitch class histogram
        histogram = [0.0] * 12
        for n in midi_notes:
            histogram[n % 12] += 1.0

        # Normalize
        total = sum(histogram) or 1.0
        histogram = [h / total for h in histogram]

        results = []

        # Test all 12 major and 12 minor keys
        for root_pc in range(12):
            # Rotate histogram to align with root
            rotated = histogram[root_pc:] + histogram[:root_pc]

            # Correlate with major profile
            corr_major = cls._correlate(rotated, cls._MAJOR_PROFILE)
            results.append((pc_to_note_name(root_pc), "major", corr_major))

            # Correlate with minor profile
            corr_minor = cls._correlate(rotated, cls._MINOR_PROFILE)
            results.append((pc_to_note_name(root_pc), "minor", corr_minor))

        # Optionally test church modes
        if include_modes:
            for mode_name, intervals in SCALE_INTERVALS.items():
                if mode_name in ("major", "minor", "chromatic"):
                    continue
                if len(intervals) != 7:
                    continue  # Only test heptatonic modes
                for root_pc in range(12):
                    # Build expected profile from intervals
                    profile = [0.5] * 12
                    for i, iv in enumerate(intervals):
                        weight = 6.0 if i == 0 else (5.0 if iv == 7 else 3.5)
                        profile[iv] = weight

                    rotated = histogram[root_pc:] + histogram[:root_pc]
                    corr = cls._correlate(rotated, profile)
                    if corr > 0.5:
                        results.append((pc_to_note_name(root_pc), mode_name, corr))

        # Sort by confidence (highest first)
        results.sort(key=lambda x: x[2], reverse=True)
        return results[:10]

    @staticmethod
    def _correlate(a: List[float], b: List[float]) -> float:
        """Pearson correlation between two profiles."""
        n = min(len(a), len(b))
        if n == 0:
            return 0.0
        mean_a = sum(a[:n]) / n
        mean_b = sum(b[:n]) / n

        cov = sum((a[i] - mean_a) * (b[i] - mean_b) for i in range(n))
        var_a = sum((a[i] - mean_a) ** 2 for i in range(n))
        var_b = sum((b[i] - mean_b) ** 2 for i in range(n))

        denom = math.sqrt(var_a * var_b)
        if denom < 1e-10:
            return 0.0
        return cov / denom


# ═══════════════════════════════════════════════════════════════
# Modulation
# ═══════════════════════════════════════════════════════════════

class Modulator:
    """Generate modulation paths between keys.

    Supports:
    - Diatonic modulation (via pivot chord)
    - Chromatic modulation (via chromatic alteration)
    - Enharmonic modulation (via reinterpretation)
    - Mediant modulation (third-related keys)
    """

    @staticmethod
    def find_pivot_chords(from_key: Scale, to_key: Scale) -> List[Dict[str, Any]]:
        """Find common chords between two keys (pivot chords).

        Returns list of {"chord": Chord, "degree_from": int, "degree_to": int}
        """
        pivots = []
        for d1 in range(1, 8):
            c1 = Chord.from_scale(from_key, d1)
            for d2 in range(1, 8):
                c2 = Chord.from_scale(to_key, d2)
                if (c1.root_pc == c2.root_pc and c1.quality == c2.quality):
                    pivots.append({
                        "chord": c1,
                        "degree_from": d1,
                        "roman_from": ROMAN_NUMERALS[d1-1],
                        "degree_to": d2,
                        "roman_to": ROMAN_NUMERALS[d2-1],
                    })
        return pivots

    @staticmethod
    def diatonic_modulation(from_key: Scale, to_key: Scale) -> List[Chord]:
        """Generate a diatonic modulation via pivot chord.

        Returns chord progression: [setup in old key, pivot, cadence in new key]
        """
        pivots = Modulator.find_pivot_chords(from_key, to_key)
        if not pivots:
            # No common chord — use chromatic approach
            return Modulator.chromatic_modulation(from_key, to_key)

        pivot = pivots[0]
        cadence = CadenceEngine(to_key)

        # Setup → Pivot → Cadence in new key
        setup = Chord.from_scale(from_key, 1)
        pivot_chord = pivot["chord"]
        auth = cadence.authentic()

        return [setup, pivot_chord] + auth.chords

    @staticmethod
    def chromatic_modulation(from_key: Scale, to_key: Scale) -> List[Chord]:
        """Generate a chromatic modulation (no pivot needed)."""
        cadence_from = CadenceEngine(from_key)
        cadence_to = CadenceEngine(to_key)

        # I → V → [chromatic shift] → V of new key → I of new key
        i_old = Chord.from_scale(from_key, 1)
        v_new = Chord.from_scale(to_key, 5, seventh=True)
        i_new = Chord.from_scale(to_key, 1)

        return [i_old, v_new, i_new]

    @staticmethod
    def enharmonic_modulation(from_key: Scale, to_key: Scale) -> List[Chord]:
        """Generate an enharmonic modulation (reinterpretation of dim7/aug6)."""
        # Use a diminished 7th chord (every note can be the root)
        dim_root_pc = (from_key.root_pc + 11) % 12  # Leading tone
        dim = Chord(pc_to_note_name(dim_root_pc), "dim7")

        # This dim7 can resolve to the new key
        i_old = Chord.from_scale(from_key, 1)
        i_new = Chord.from_scale(to_key, 1)

        return [i_old, dim, i_new]

    @staticmethod
    def distance(from_key: Scale, to_key: Scale) -> int:
        """Calculate the 'distance' between two keys on the circle of fifths."""
        pc1 = from_key.root_pc
        pc2 = to_key.root_pc

        # Distance on circle of fifths (in steps of 7 semitones)
        dist = 0
        current = pc1
        for i in range(12):
            if current == pc2:
                return min(i, 12 - i)
            current = (current + 7) % 12
        return 6  # Max distance (tritone)

    @staticmethod
    def suggest_modulation_type(from_key: Scale, to_key: Scale) -> str:
        """Suggest the best modulation type based on key distance."""
        dist = Modulator.distance(from_key, to_key)
        if dist <= 1:
            return "diatonic"
        elif dist <= 3:
            return "chromatic"
        else:
            return "enharmonic"


# ═══════════════════════════════════════════════════════════════
# Generalbass (Figured Bass)
# ═══════════════════════════════════════════════════════════════

class GeneralBass:
    """Interpret figured bass notation.

    Figures:
        (none) = 5/3 (root position triad)
        6      = 6/3 (first inversion)
        6/4    = 6/4 (second inversion)
        7      = 7/5/3 (root position seventh)
        6/5    = 6/5/3 (first inversion seventh)
        4/3    = 4/3 (second inversion seventh)
        4/2    = 4/2 (third inversion seventh)
    """

    FIGURES: Dict[str, List[int]] = {
        "":     [0, 4, 7],            # 5/3 (depends on key)
        "6":    [0, 3, 8],            # 6/3
        "6/4":  [0, 5, 9],            # 6/4
        "7":    [0, 4, 7, 10],        # 7/5/3
        "6/5":  [0, 3, 7, 8],         # 6/5/3
        "4/3":  [0, 4, 5, 9],         # 4/3
        "4/2":  [0, 2, 5, 8],         # 4/2 (= 2)
        "#":    [0, 4, 7],            # Raised third (Picardy)
        "b":    [0, 3, 7],            # Lowered third
    }

    @staticmethod
    def realize(bass_midi: int, figure: str = "",
                 scale: Optional[Scale] = None) -> List[int]:
        """Realize a figured bass note into full chord tones.

        Args:
            bass_midi: MIDI note of the bass
            figure: Figured bass notation ("", "6", "6/4", "7", etc.)
            scale: Optional scale context for diatonic realization

        Returns: List of MIDI notes (bass + upper voices)
        """
        intervals = GeneralBass.FIGURES.get(figure, [0, 4, 7])

        if scale:
            # Use diatonic intervals from the scale
            bass_degree = scale.degree_of(bass_midi)
            if bass_degree is not None:
                notes = [bass_midi]
                for iv in intervals[1:]:
                    # Find the scale note closest to bass + iv
                    target = bass_midi + iv
                    # Snap to scale
                    best = target
                    for offset in range(-2, 3):
                        candidate = target + offset
                        if scale.contains(candidate):
                            best = candidate
                            break
                    notes.append(best)
                return sorted(notes)

        # Chromatic realization
        return sorted([bass_midi + iv for iv in intervals])


# ═══════════════════════════════════════════════════════════════
# Utility: Chord Progression Generator
# ═══════════════════════════════════════════════════════════════

def generate_progression(key: Scale, pattern: str = "pop",
                          length: int = 4) -> List[Chord]:
    """Generate a chord progression from common patterns.

    Patterns:
        pop:       I V vi IV
        blues:     I I I I IV IV I I V IV I V
        jazz:      ii V I vi
        baroque:   I IV V I
        romantic:  I vi IV V
        modal:     i VII III IV (for minor/dorian)
        gospel:    I I7 IV iv I V I
        pachelbel: I V vi iii IV I IV V
    """
    PATTERNS: Dict[str, List[int]] = {
        "pop":       [1, 5, 6, 4],
        "blues12":   [1, 1, 1, 1, 4, 4, 1, 1, 5, 4, 1, 5],
        "jazz":      [2, 5, 1, 6],
        "baroque":   [1, 4, 5, 1],
        "romantic":  [1, 6, 4, 5],
        "modal":     [1, 7, 3, 4],
        "pachelbel": [1, 5, 6, 3, 4, 1, 4, 5],
        "gospel":    [1, 1, 4, 4, 1, 5, 1],
        "andalusian": [1, 7, 6, 5],  # (in Phrygian/minor)
        "circle":    [6, 2, 5, 1],   # Circle of fifths
    }

    degrees = PATTERNS.get(pattern, PATTERNS["pop"])
    if length > 0:
        # Repeat/truncate to desired length
        while len(degrees) < length:
            degrees = degrees + degrees
        degrees = degrees[:length]

    chords = []
    for d in degrees:
        seventh = (d == 5)  # V gets a 7th by default
        chords.append(Chord.from_scale(key, d, seventh=seventh))

    return chords


# ═══════════════════════════════════════════════════════════════
# All scales + info for the UI
# ═══════════════════════════════════════════════════════════════

def get_all_scale_names() -> List[Dict[str, str]]:
    """Get all available scale names with descriptions for the UI."""
    descriptions = {
        "ionian": "Ionisch (= Dur)",
        "dorian": "Dorisch — Kirchentonart, Jazz-Moll-Charakter",
        "phrygian": "Phrygisch — Spanisch, Flamenco",
        "lydian": "Lydisch — Schwebend, filmisch",
        "mixolydian": "Mixolydisch — Blues, Rock, Folk",
        "aeolian": "Äolisch (= Natürlich Moll)",
        "locrian": "Lokrisch — Instabil, selten",
        "major": "Dur",
        "minor": "Moll (natürlich)",
        "harmonic_minor": "Harmonisch Moll — Orientalisch",
        "melodic_minor": "Melodisch Moll — Jazz",
        "major_pentatonic": "Dur-Pentatonik — Einfach, offen",
        "minor_pentatonic": "Moll-Pentatonik — Blues, Rock",
        "blues": "Blues-Skala — mit Blue Note",
        "whole_tone": "Ganztonleiter — Impressionismus (Debussy)",
        "diminished": "Verminderte Skala (Ganzton-Halbton)",
        "bebop_dominant": "Bebop Dominant — Jazz",
        "hungarian_minor": "Ungarisch Moll — Zigeuner-Skala",
        "double_harmonic": "Byzantinisch — Arabisch, Indisch",
        "phrygian_dominant": "Phrygisch Dominant — Spanisch, Metal",
        "hirajoshi": "Hirajōshi — Japanisch",
        "persian": "Persisch",
        "chromatic": "Chromatisch — alle 12 Töne",
    }
    return [
        {"name": name, "description": descriptions.get(name, name),
         "notes_count": len(intervals)}
        for name, intervals in SCALE_INTERVALS.items()
        if name not in ("gregorian_mode1", "gregorian_mode3",
                        "gregorian_mode5", "gregorian_mode7")
    ]


def get_all_chord_qualities() -> List[Dict[str, str]]:
    """Get all available chord qualities for the UI."""
    descriptions = {
        "major": "Dur-Dreiklang",
        "minor": "Moll-Dreiklang",
        "diminished": "Verminderter Dreiklang",
        "augmented": "Übermäßiger Dreiklang",
        "dom7": "Dominantseptakkord",
        "maj7": "Großer Septakkord",
        "min7": "Mollseptakkord",
        "half_dim7": "Halbverminderter Septakkord (ø7)",
        "dim7": "Verminderter Septakkord (°7)",
        "sus2": "Sekundvorhalt",
        "sus4": "Quartvorhalt",
        "add9": "Add9",
        "neapolitan": "Neapolitanischer Sextakkord",
        "power": "Powerchord (Root + Quinte)",
    }
    return [
        {"quality": q, "description": descriptions.get(q, q),
         "notes_count": len(intervals)}
        for q, intervals in CHORD_INTERVALS.items()
        if q not in ("tristan", "mystic", "augmented_sixth")
    ]
