"""sentinel_api.py — SENTINEL API Server (Phase S9).

v0.0.20.905 — Phase S9 der SENTINEL_ROADMAP.

Lokaler HTTP Server auf Port 9750 (nur 127.0.0.1).
Endpoints:
  GET  /sentinel/health      → System-Status
  GET  /sentinel/crashes     → Crash-Reports
  GET  /sentinel/anomalies   → Aktive + kuerzliche Anomalien
  GET  /sentinel/blackbox    → Letzte 60s Flight Recorder
  GET  /sentinel/patterns    → Gelernte Muster
  POST /sentinel/analyze     → KI-Analyse anfordern
  POST /sentinel/heal        → Self-Healing manuell triggern

Sicherheit:
- Nur localhost (127.0.0.1) — kein Zugriff von aussen
- Optional API-Key (X-Sentinel-Key Header)
- Rate-Limiting: max 60 Requests/Minute
- Keine sensitiven Daten (keine Projekt-Dateipfade)
"""

from __future__ import annotations

import json
import logging
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Any, Callable, Dict, List, Optional
from urllib.parse import urlparse, parse_qs

log = logging.getLogger(__name__)

# Defaults
DEFAULT_PORT = 9750
DEFAULT_HOST = "127.0.0.1"
MAX_REQUESTS_PER_MINUTE = 60


class _RateLimiter:
    """Simple sliding-window rate limiter."""

    def __init__(self, max_per_minute: int = MAX_REQUESTS_PER_MINUTE):
        self._max = max_per_minute
        self._timestamps: list = []
        self._lock = threading.Lock()

    def allow(self) -> bool:
        now = time.time()
        with self._lock:
            cutoff = now - 60.0
            self._timestamps = [t for t in self._timestamps if t > cutoff]
            if len(self._timestamps) >= self._max:
                return False
            self._timestamps.append(now)
            return True


class SentinelAPIHandler(BaseHTTPRequestHandler):
    """HTTP request handler for SENTINEL API."""

    # Class-level references (set by SentinelAPIServer before starting)
    _db = None
    _recorder = None
    _anomaly = None
    _crash_analyzer = None
    _pattern_learner = None
    _api_key: str = ""
    _rate_limiter: Optional[_RateLimiter] = None
    _analyze_callback: Optional[Callable] = None

    def log_message(self, format: str, *args) -> None:
        """Redirect HTTP log to our logger (not stderr)."""
        log.debug("[SENTINEL API] %s", format % args)

    def do_GET(self) -> None:
        if not self._check_auth():
            return
        if not self._check_rate():
            return

        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        params = parse_qs(parsed.query)

        routes = {
            "/sentinel/health": self._handle_health,
            "/sentinel/crashes": self._handle_crashes,
            "/sentinel/anomalies": self._handle_anomalies,
            "/sentinel/blackbox": self._handle_blackbox,
            "/sentinel/patterns": self._handle_patterns,
        }

        handler = routes.get(path)
        if handler:
            try:
                handler(params)
            except Exception as exc:
                self._send_json(500, {"error": str(exc)})
        else:
            self._send_json(404, {"error": "Not found",
                                   "endpoints": list(routes.keys()) +
                                   ["POST /sentinel/analyze",
                                    "POST /sentinel/heal"]})

    def do_POST(self) -> None:
        if not self._check_auth():
            return
        if not self._check_rate():
            return

        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")

        # Read body
        body = {}
        try:
            content_len = int(self.headers.get("Content-Length", 0))
            if content_len > 0:
                raw = self.rfile.read(content_len)
                body = json.loads(raw.decode("utf-8"))
        except (json.JSONDecodeError, ValueError, TypeError):
            self._send_json(400, {"error": "Invalid JSON body"})
            return

        if path == "/sentinel/analyze":
            self._handle_analyze(body)
        elif path == "/sentinel/heal":
            self._handle_heal(body)
        else:
            self._send_json(404, {"error": "Not found"})

    # ══════════════════════════════════════════════════════════════
    # Auth + Rate Limit
    # ══════════════════════════════════════════════════════════════

    def _check_auth(self) -> bool:
        """Check API key if configured."""
        if not self._api_key:
            return True
        provided = self.headers.get("X-Sentinel-Key", "")
        if provided != self._api_key:
            self._send_json(401, {"error": "Unauthorized — provide X-Sentinel-Key header"})
            return False
        return True

    def _check_rate(self) -> bool:
        """Check rate limit."""
        if self._rate_limiter and not self._rate_limiter.allow():
            self._send_json(429, {"error": "Rate limit exceeded (max 60/min)"})
            return False
        return True

    # ══════════════════════════════════════════════════════════════
    # GET Handlers
    # ══════════════════════════════════════════════════════════════

    def _handle_health(self, params: dict) -> None:
        """GET /sentinel/health → System status."""
        data: Dict[str, Any] = {
            "status": "unknown",
            "cpu_percent": 0,
            "memory_mb": 0,
            "xrun_count": 0,
            "active_tracks": 0,
            "active_plugins": 0,
            "collab_connected": False,
            "anomaly_count": 0,
            "crash_count": 0,
            "uptime_seconds": 0,
            "version": self._get_version(),
        }

        # System state from recorder blackbox
        if self._recorder:
            try:
                bb = self._recorder.get_blackbox()
                sys_state = bb.get("system_state", {})
                data["cpu_percent"] = round(sys_state.get("cpu_percent", 0), 1)
                data["memory_mb"] = round(sys_state.get("memory_mb", 0), 1)
                data["xrun_count"] = sys_state.get("xrun_count", 0)
                track_state = bb.get("track_state", {})
                data["active_tracks"] = track_state.get("track_count", 0)
                data["active_plugins"] = track_state.get("plugin_count", 0)
                data["collab_connected"] = track_state.get("collab_connected", False)
            except Exception:
                pass

        # Health status from anomaly detector
        if self._anomaly:
            try:
                data["status"] = self._anomaly.get_health_status()
            except Exception:
                data["status"] = "unknown"

        # Anomaly + crash counts
        if self._db:
            try:
                active = self._db.get_active_anomalies()
                data["anomaly_count"] = len(active)
                stats = self._db.stats()
                data["crash_count"] = stats.get("crashes", 0)
            except Exception:
                pass

        self._send_json(200, data)

    def _handle_crashes(self, params: dict) -> None:
        """GET /sentinel/crashes → Crash reports."""
        limit = int(params.get("limit", [30])[0])
        limit = max(1, min(limit, 200))

        crashes = []
        if self._db:
            raw = self._db.get_crashes(limit=limit)
            for c in raw:
                # Sanitize: remove potentially sensitive file paths
                entry = {
                    "id": c.get("id"),
                    "time": c.get("crash_time", 0),
                    "type": c.get("crash_type", ""),
                    "component": c.get("component", ""),
                    "message": c.get("error_message", "")[:500],
                    "resolved": bool(c.get("resolved", 0)),
                    "resolution": c.get("resolution", ""),
                }
                # Include blackbox summary (not full data)
                try:
                    bb = json.loads(c.get("blackbox_json", "{}"))
                    entry["blackbox_summary"] = {
                        "has_metrics": bool(bb.get("metrics")),
                        "has_system_state": bool(bb.get("system_state")),
                        "metric_count": len(bb.get("metrics", [])),
                    }
                except (json.JSONDecodeError, TypeError):
                    entry["blackbox_summary"] = {}
                crashes.append(entry)

        self._send_json(200, {"crashes": crashes, "count": len(crashes)})

    def _handle_anomalies(self, params: dict) -> None:
        """GET /sentinel/anomalies → Active + recent anomalies."""
        include_resolved = params.get("include_resolved", ["false"])[0].lower() == "true"
        limit = int(params.get("limit", [50])[0])
        limit = max(1, min(limit, 200))

        anomalies = []
        if self._db:
            if include_resolved:
                raw = self._db.get_anomaly_history(limit=limit)
            else:
                raw = self._db.get_active_anomalies()

            for a in raw:
                anomalies.append({
                    "id": a.get("id"),
                    "detected_at": a.get("detected_at", 0),
                    "resolved_at": a.get("resolved_at", 0),
                    "type": a.get("anomaly_type", ""),
                    "severity": a.get("severity", 1),
                    "source": a.get("source", ""),
                    "description": a.get("description", ""),
                    "action_taken": a.get("action_taken", ""),
                    "false_positive": bool(a.get("false_positive", 0)),
                })

        self._send_json(200, {"anomalies": anomalies, "count": len(anomalies)})

    def _handle_blackbox(self, params: dict) -> None:
        """GET /sentinel/blackbox → Flight recorder data (last 60s)."""
        data: Dict[str, Any] = {"metrics": [], "system_state": {}, "collab_rates": {}}
        if self._recorder:
            try:
                data = self._recorder.get_blackbox()
                # Sanitize: remove file paths
                sys_state = data.get("system_state", {})
                sys_state.pop("project_path", None)
                sys_state.pop("home_dir", None)
            except Exception:
                pass
        self._send_json(200, data)

    def _handle_patterns(self, params: dict) -> None:
        """GET /sentinel/patterns → Learned patterns."""
        pattern_type = params.get("type", [""])[0]
        limit = int(params.get("limit", [100])[0])
        limit = max(1, min(limit, 500))

        patterns = []
        if self._db:
            raw = self._db.get_patterns(pattern_type=pattern_type, limit=limit)
            for p in raw:
                entry = {
                    "id": p.get("id"),
                    "pattern_type": p.get("pattern_type", ""),
                    "description": p.get("description", ""),
                    "confidence": p.get("confidence", 0),
                    "occurrences": p.get("occurrences", 1),
                    "last_seen": p.get("last_seen", 0),
                    "prevention": p.get("prevention", ""),
                    "auto_action": p.get("auto_action", "warn"),
                }
                try:
                    entry["conditions"] = json.loads(p.get("conditions_json", "{}"))
                except (json.JSONDecodeError, TypeError):
                    entry["conditions"] = {}
                patterns.append(entry)

        self._send_json(200, {"patterns": patterns, "count": len(patterns)})

    # ══════════════════════════════════════════════════════════════
    # POST Handlers
    # ══════════════════════════════════════════════════════════════

    def _handle_analyze(self, body: dict) -> None:
        """POST /sentinel/analyze → Request AI analysis of crash/anomaly."""
        crash_id = body.get("crash_id")
        anomaly_id = body.get("anomaly_id")

        if not crash_id and not anomaly_id:
            self._send_json(400, {"error": "Provide crash_id or anomaly_id"})
            return

        # Build analysis context
        context: Dict[str, Any] = {"request_type": "analyze"}

        if crash_id and self._db:
            crashes = self._db.get_crashes(limit=200)
            crash = None
            for c in crashes:
                if c.get("id") == crash_id:
                    crash = c
                    break
            if not crash:
                self._send_json(404, {"error": f"Crash {crash_id} not found"})
                return
            context["crash"] = {
                "id": crash.get("id"),
                "type": crash.get("crash_type", ""),
                "component": crash.get("component", ""),
                "message": crash.get("error_message", "")[:2000],
                "traceback": crash.get("traceback", "")[:3000],
            }
            try:
                context["blackbox"] = json.loads(crash.get("blackbox_json", "{}"))
            except (json.JSONDecodeError, TypeError):
                context["blackbox"] = {}

        if anomaly_id and self._db:
            anomalies = self._db.get_anomaly_history(limit=200)
            anomaly = None
            for a in anomalies:
                if a.get("id") == anomaly_id:
                    anomaly = a
                    break
            if anomaly:
                context["anomaly"] = {
                    "id": anomaly.get("id"),
                    "type": anomaly.get("anomaly_type", ""),
                    "severity": anomaly.get("severity", 0),
                    "description": anomaly.get("description", ""),
                }
                try:
                    context["evidence"] = json.loads(anomaly.get("evidence_json", "{}"))
                except (json.JSONDecodeError, TypeError):
                    context["evidence"] = {}

        # If AI callback is registered, use it
        if self._analyze_callback:
            try:
                result = self._analyze_callback(context)
                self._send_json(200, {
                    "analysis": result,
                    "source": "ai",
                })
                return
            except Exception as exc:
                log.warning("[SENTINEL API] AI analysis failed: %s", exc)
                # Fall through to local analysis

        # Local analysis fallback (pattern-based)
        local_analysis = self._local_analyze(context)
        self._send_json(200, {
            "analysis": local_analysis,
            "source": "local",
        })

    def _local_analyze(self, context: dict) -> str:
        """Generate local analysis without AI."""
        parts = ["## SENTINEL Analyse (lokal)\n"]

        crash = context.get("crash", {})
        if crash:
            parts.append(f"**Crash-Typ:** {crash.get('type', 'unknown')}")
            parts.append(f"**Komponente:** {crash.get('component', 'unknown')}")
            msg = crash.get("message", "")
            if msg:
                parts.append(f"**Fehlermeldung:** {msg[:300]}")
            tb = crash.get("traceback", "")
            if tb:
                # Extract last 5 lines of traceback
                lines = tb.strip().split("\n")
                last = lines[-5:] if len(lines) > 5 else lines
                parts.append(f"**Traceback (Ende):**\n```\n{'chr(10)'.join(last)}\n```")

        anomaly = context.get("anomaly", {})
        if anomaly:
            parts.append(f"**Anomalie-Typ:** {anomaly.get('type', 'unknown')}")
            parts.append(f"**Schwere:** Stufe {anomaly.get('severity', 0)}")
            parts.append(f"**Beschreibung:** {anomaly.get('description', '')}")

        # Check if pattern learner knows about this
        if self._pattern_learner:
            matches = self._pattern_learner.check_current_state()
            if matches:
                parts.append("\n**Bekannte Muster:**")
                for m in matches[:3]:
                    parts.append(f"- {m['description']} "
                                 f"(Confidence: {m['confidence']:.0%}, "
                                 f"Score: {m['match_score']:.0%})")
                    if m.get("prevention"):
                        parts.append(f"  → Empfehlung: {m['prevention']}")

        return "\n".join(parts)

    def _handle_heal(self, body: dict) -> None:
        """POST /sentinel/heal → Trigger self-healing action."""
        action = body.get("action", "")
        target = body.get("target", "")

        if not action:
            self._send_json(400, {"error": "Provide 'action' field",
                                   "available_actions": [
                                       "restart_plugin",
                                       "break_echo_loop",
                                       "reconnect_collab",
                                   ]})
            return

        # SAFETY: Log the request but don't auto-execute dangerous actions
        # Only safe actions are performed directly
        safe_actions = {"break_echo_loop"}

        if action in safe_actions:
            result = self._execute_heal(action, target)
            self._send_json(200, {
                "action": action,
                "target": target,
                "result": result,
                "executed": True,
            })
        else:
            # Unsafe actions need UI confirmation — just queue them
            if self._db:
                self._db.log_action(
                    action_type=f"api_heal_request_{action}",
                    target=target,
                    reason=f"API request: {action} on {target}",
                    severity=3,
                    auto=False,
                )
            self._send_json(202, {
                "action": action,
                "target": target,
                "result": "Queued — requires UI confirmation",
                "executed": False,
                "message": "This action requires user confirmation in the DAW UI.",
            })

    def _execute_heal(self, action: str, target: str) -> str:
        """Execute a safe healing action."""
        if action == "break_echo_loop" and self._anomaly:
            try:
                if hasattr(self._anomaly, "_echo_cooldowns"):
                    self._anomaly._echo_cooldowns[target] = time.time() + 5.0
                    return f"Echo loop cooldown set for '{target}' (5s)"
            except Exception as exc:
                return f"Failed: {exc}"
        return "Unknown action or target"

    # ══════════════════════════════════════════════════════════════
    # Helpers
    # ══════════════════════════════════════════════════════════════

    def _send_json(self, status: int, data: Any) -> None:
        """Send JSON response."""
        body = json.dumps(data, indent=2, ensure_ascii=False, default=str)
        body_bytes = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body_bytes)))
        self.send_header("Access-Control-Allow-Origin", "http://127.0.0.1")
        self.end_headers()
        self.wfile.write(body_bytes)

    @staticmethod
    def _get_version() -> str:
        try:
            from pathlib import Path
            # Try reading VERSION file
            for p in [Path("VERSION"), Path(__file__).parent.parent.parent / "VERSION"]:
                if p.exists():
                    return p.read_text().strip()
        except Exception:
            pass
        return "unknown"


class SentinelAPIServer:
    """Manages the SENTINEL HTTP API server lifecycle.

    Usage:
        server = SentinelAPIServer.get()
        server.start(recorder=..., anomaly=..., crash_analyzer=...)
        # ... later ...
        server.stop()
    """

    _instance: Optional["SentinelAPIServer"] = None

    @classmethod
    def get(cls) -> "SentinelAPIServer":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._httpd: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self._port = DEFAULT_PORT
        self._host = DEFAULT_HOST
        self._api_key = ""

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def port(self) -> int:
        return self._port

    @property
    def base_url(self) -> str:
        return f"http://{self._host}:{self._port}"

    def start(self, port: int = DEFAULT_PORT, api_key: str = "",
              recorder=None, anomaly=None,
              crash_analyzer=None, pattern_learner=None,
              analyze_callback: Optional[Callable] = None) -> bool:
        """Start the API server in a background thread.

        Args:
            port: Port to listen on (default 9750)
            api_key: Optional API key for auth (empty = no auth)
            recorder: SentinelRecorder instance
            anomaly: SentinelAnomaly instance
            crash_analyzer: SentinelCrashAnalyzer instance
            pattern_learner: SentinelPatternLearner instance
            analyze_callback: Optional callback for AI analysis

        Returns:
            True if started successfully.
        """
        if self._running:
            log.warning("[SENTINEL API] Already running on port %d", self._port)
            return True

        self._port = port
        self._api_key = api_key

        # Configure handler class-level references
        SentinelAPIHandler._recorder = recorder
        SentinelAPIHandler._anomaly = anomaly
        SentinelAPIHandler._crash_analyzer = crash_analyzer
        SentinelAPIHandler._pattern_learner = pattern_learner
        SentinelAPIHandler._api_key = api_key
        SentinelAPIHandler._rate_limiter = _RateLimiter(MAX_REQUESTS_PER_MINUTE)
        SentinelAPIHandler._analyze_callback = analyze_callback

        try:
            from pydaw.services.sentinel_db import SentinelDB
            SentinelAPIHandler._db = SentinelDB.get()
            SentinelAPIHandler._db.ensure_loaded()
        except Exception:
            pass

        try:
            self._httpd = HTTPServer((self._host, self._port), SentinelAPIHandler)
            self._httpd.timeout = 1.0
            self._thread = threading.Thread(
                target=self._serve_loop,
                name="sentinel-api",
                daemon=True,
            )
            self._thread.start()
            self._running = True
            log.info("[SENTINEL API] Started on %s:%d", self._host, self._port)
            return True
        except OSError as exc:
            log.warning("[SENTINEL API] Failed to start on port %d: %s",
                        self._port, exc)
            return False

    def stop(self) -> None:
        """Stop the API server."""
        self._running = False
        if self._httpd:
            try:
                self._httpd.shutdown()
            except Exception:
                pass
            self._httpd = None
        if self._thread:
            try:
                self._thread.join(timeout=3.0)
            except Exception:
                pass
            self._thread = None
        log.info("[SENTINEL API] Stopped")

    def _serve_loop(self) -> None:
        """Server loop running in background thread."""
        while self._running and self._httpd:
            try:
                self._httpd.handle_request()
            except Exception:
                pass
