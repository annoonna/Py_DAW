"""ki_omr.py — Optical Music Recognition (v0.0.20.991)

OMR_ROADMAP: OM1–OM6

Scannt Notenblätter (PDF/Bild) und erkennt:
  - Notensysteme (5 Linien)
  - Notenköpfe (gefüllt/hohl)
  - Tonhöhe (Position auf Linie/Zwischenraum)
  - Schlüssel (Violin/Bass)
  - Vorzeichen (♯ ♭)
  - MIDI-Export

Benötigt: opencv-python-headless, PyMuPDF, numpy, mido (alle schon installiert)

Usage:
    from pydaw.services.ki_omr import OMRService
    omr = OMRService()
    result = omr.scan_pdf("/path/to/gesangbuch.pdf")
    for page in result.pages:
        for note in page.notes:
            print(f"MIDI {note.midi}, Beat {note.beat}, Dur {note.duration}")
"""

import logging
import math
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from pathlib import Path

log = logging.getLogger(__name__)

# Lazy imports — only load when actually used
_cv2 = None
_np = None
_fitz = None


def _ensure_cv2():
    global _cv2, _np
    if _cv2 is None:
        try:
            import cv2
            _cv2 = cv2
        except ImportError:
            raise ImportError("opencv-python-headless nicht installiert: pip install opencv-python-headless")
    if _np is None:
        import numpy
        _np = numpy
    return _cv2, _np


def _ensure_fitz():
    global _fitz
    if _fitz is None:
        try:
            import fitz
            _fitz = fitz
        except ImportError:
            raise ImportError("PyMuPDF nicht installiert: pip install pymupdf")
    return _fitz


# ═══════════════════════════════════════════════════════════════
# Data Structures
# ═══════════════════════════════════════════════════════════════

@dataclass
class DetectedNote:
    """A single detected note from sheet music."""
    midi: int               # MIDI note number (0-127)
    beat: float             # Position in beats from start
    duration: float         # Duration in beats
    velocity: int = 90      # Default velocity
    confidence: float = 0.0 # Detection confidence (0.0-1.0)
    x: int = 0              # X position in image (for preview)
    y: int = 0              # Y position in image (for preview)
    note_name: str = ""     # e.g. "C4", "F#5"


@dataclass
class StaffSystem:
    """A group of 5 staff lines."""
    lines: List[int]        # Y positions of the 5 lines
    top: int                # Top Y
    bottom: int             # Bottom Y
    spacing: float          # Average spacing between lines
    clef: str = "treble"    # "treble" or "bass"
    key_sharps: int = 0     # Number of sharps in key signature
    key_flats: int = 0      # Number of flats in key signature


@dataclass
class OMRPage:
    """OMR results for one page."""
    page_number: int
    width: int
    height: int
    systems: List[StaffSystem]
    notes: List[DetectedNote]
    tempo: int = 120
    time_signature: Tuple[int, int] = (4, 4)
    key: str = ""


@dataclass
class OMRResult:
    """Complete OMR result."""
    source_path: str
    pages: List[OMRPage]
    total_notes: int = 0
    error: str = ""


# ═══════════════════════════════════════════════════════════════
# OM1: Bild-Extraktion
# ═══════════════════════════════════════════════════════════════

def extract_images_from_pdf(path: str, dpi: int = 300) -> List:
    """Extract pages from PDF as high-resolution images.

    Returns list of numpy arrays (grayscale).
    """
    fitz = _ensure_fitz()
    cv2, np = _ensure_cv2()

    doc = fitz.open(path)
    images = []

    for page_num in range(len(doc)):
        page = doc[page_num]
        # Render at high DPI for better note detection
        zoom = dpi / 72.0
        mat = fitz.Matrix(zoom, zoom)
        pix = page.get_pixmap(matrix=mat)

        # Convert to numpy array
        img = np.frombuffer(pix.samples, dtype=np.uint8)
        img = img.reshape(pix.height, pix.width, pix.n)

        # Convert to grayscale
        if pix.n >= 3:
            gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        else:
            gray = img

        images.append(gray)
        log.info("[OMR] Page %d: %dx%d px", page_num + 1, pix.width, pix.height)

    doc.close()
    return images


def load_image(path: str):
    """Load an image file (PNG, JPG, TIFF, BMP)."""
    cv2, np = _ensure_cv2()
    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise ValueError(f"Bild konnte nicht geladen werden: {path}")
    return img


def preprocess_image(gray):
    """Preprocess image: auto-rotate (alle 4 Richtungen), threshold, denoise.

    OM1: Bild-Vorverarbeitung
    Testet alle 4 Orientierungen (0°, 90°, 180°, 270°) und wählt die
    mit den meisten erkannten Notenlinien.
    """
    cv2, np = _ensure_cv2()

    # ── Auto-Rotation: Teste alle 4 Orientierungen ──
    rotations = [
        (None, "0° (Original)"),
        (cv2.ROTATE_90_CLOCKWISE, "90° CW"),
        (cv2.ROTATE_180, "180° (Kopfüber)"),
        (cv2.ROTATE_90_COUNTERCLOCKWISE, "270° CCW"),
    ]

    best_score = -1
    best_gray = gray
    best_label = "0°"

    for rot_code, label in rotations:
        if rot_code is not None:
            test_img = cv2.rotate(gray, rot_code)
        else:
            test_img = gray

        # Quick threshold for line detection
        _, test_bin = cv2.threshold(test_img, 0, 255,
                                     cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

        h, w = test_bin.shape
        # Horizontal projection — staff lines = rows with many white pixels
        h_proj = np.sum(test_bin, axis=1) / 255
        threshold = w * 0.12

        # Count rows that look like staff lines
        line_rows = np.where(h_proj > threshold)[0]

        # Group consecutive rows into distinct lines
        num_lines = 0
        if len(line_rows) > 0:
            gaps = np.diff(line_rows)
            num_lines = np.sum(gaps > 3) + 1

        # Score: prefer orientations with many evenly-spaced lines
        # (5, 10, 15, 20 lines = 1, 2, 3, 4 staff systems)
        score = num_lines

        # Bonus: prefer portrait orientation (h > w) for sheet music
        if h > w:
            score += 2

        if score > best_score:
            best_score = score
            best_gray = test_img
            best_label = label

    if best_label != "0° (Original)":
        log.info("[OMR] Auto-Rotation: %s (%d Linien-Score)", best_label, best_score)

    gray = best_gray

    # ── Threshold + Denoise ──
    binary = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV, 21, 8
    )

    # Close small gaps in staff lines
    kernel_h = np.ones((1, 3), np.uint8)
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel_h)

    # Remove noise
    kernel_open = np.ones((2, 2), np.uint8)
    binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel_open)

    return binary


# ═══════════════════════════════════════════════════════════════
# OM2: Notenlinien-Erkennung
# ═══════════════════════════════════════════════════════════════

def detect_staff_lines(binary, min_line_length_ratio: float = 0.15) -> List[StaffSystem]:
    """Detect staff lines using horizontal projection profile.

    OM2: Horizontale Linien finden → Notensystem-Gruppen bilden
    Threshold 0.15 (was 0.3) für fotografierte Gesangbücher.
    """
    cv2, np = _ensure_cv2()

    h, w = binary.shape

    # Horizontal projection: sum of white pixels per row
    h_proj = np.sum(binary, axis=1) / 255

    # Staff lines have high horizontal projection (long horizontal lines)
    threshold = w * min_line_length_ratio
    line_rows = np.where(h_proj > threshold)[0]

    if len(line_rows) == 0:
        log.warning("[OMR] Keine Notenlinien gefunden")
        return []

    # Group consecutive rows into single lines
    lines = []
    if len(line_rows) > 0:
        group_start = line_rows[0]
        for i in range(1, len(line_rows)):
            if line_rows[i] - line_rows[i-1] > 3:
                # End of group — take center
                center = (group_start + line_rows[i-1]) // 2
                lines.append(center)
                group_start = line_rows[i]
        # Last group
        center = (group_start + line_rows[-1]) // 2
        lines.append(center)

    log.info("[OMR] %d Notenlinien gefunden", len(lines))

    # Group into staff systems (5 lines each)
    systems = []
    i = 0
    while i + 4 < len(lines):
        # Check if 5 consecutive lines have roughly equal spacing
        group = lines[i:i+5]
        spacings = [group[j+1] - group[j] for j in range(4)]
        avg_spacing = sum(spacings) / 4
        max_dev = max(abs(s - avg_spacing) for s in spacings)

        if avg_spacing > 3 and max_dev < avg_spacing * 0.8:
            system = StaffSystem(
                lines=group,
                top=group[0],
                bottom=group[4],
                spacing=avg_spacing,
            )
            systems.append(system)
            i += 5
            # Skip gap to next system
            while i < len(lines) and (i < 5 or lines[i] - group[4] < avg_spacing * 2):
                i += 1
        else:
            i += 1

    log.info("[OMR] %d Notensysteme erkannt", len(systems))
    return systems


def remove_staff_lines(binary, systems: List[StaffSystem]):
    """Remove staff lines from binary image for better note detection.

    OM2: Notenlinien entfernen
    """
    cv2, np = _ensure_cv2()
    cleaned = binary.copy()

    for system in systems:
        for line_y in system.lines:
            # Remove horizontal pixels that are part of staff lines
            for y in range(max(0, line_y - 1), min(cleaned.shape[0], line_y + 2)):
                row = cleaned[y, :]
                # Only remove if the pixel is part of a long horizontal run
                # (not part of a note head or stem)
                run_start = 0
                for x in range(len(row)):
                    if row[x] > 0:
                        if x == len(row) - 1 or row[x + 1] == 0:
                            run_len = x - run_start + 1
                            if run_len > system.spacing * 2:
                                cleaned[y, run_start:x+1] = 0
                            run_start = x + 1
                    else:
                        run_start = x + 1

    return cleaned


# ═══════════════════════════════════════════════════════════════
# OM3: Notenkopf-Erkennung
# ═══════════════════════════════════════════════════════════════

def detect_note_heads(cleaned, systems: List[StaffSystem]) -> List[Dict]:
    """Detect note heads using blob detection.

    OM3: Notenköpfe finden (gefüllt/hohl)
    """
    cv2, np = _ensure_cv2()

    if not systems:
        return []

    avg_spacing = sum(s.spacing for s in systems) / len(systems)

    # Expected note head size
    note_w = int(avg_spacing * 1.4)  # width
    note_h = int(avg_spacing * 0.9)  # height

    # Use blob detection for filled note heads
    params = cv2.SimpleBlobDetector_Params()
    params.filterByArea = True
    params.minArea = (avg_spacing * 0.4) ** 2
    params.maxArea = (avg_spacing * 2.0) ** 2
    params.filterByCircularity = True
    params.minCircularity = 0.3  # Ovals, not circles
    params.filterByConvexity = True
    params.minConvexity = 0.5
    params.filterByInertia = True
    params.minInertiaRatio = 0.2  # Allow elongated shapes

    detector = cv2.SimpleBlobDetector_create(params)
    keypoints = detector.detect(cleaned)

    note_heads = []
    for kp in keypoints:
        x, y = int(kp.pt[0]), int(kp.pt[1])
        size = kp.size

        # Find which system this note belongs to
        system = _find_system(y, systems, avg_spacing)
        if system is None:
            continue

        # Determine if filled (quarter/eighth) or hollow (half/whole)
        roi_r = int(avg_spacing * 0.6)
        y1 = max(0, y - roi_r)
        y2 = min(cleaned.shape[0], y + roi_r)
        x1 = max(0, x - roi_r)
        x2 = min(cleaned.shape[1], x + roi_r)
        roi = cleaned[y1:y2, x1:x2]
        fill_ratio = np.sum(roi > 0) / max(roi.size, 1)
        is_filled = fill_ratio > 0.35

        note_heads.append({
            "x": x, "y": y,
            "system": system,
            "filled": is_filled,
            "size": size,
            "confidence": min(1.0, fill_ratio * 2),
        })

    log.info("[OMR] %d Notenköpfe erkannt", len(note_heads))
    return note_heads


def _find_system(y: int, systems: List[StaffSystem],
                  margin: float) -> Optional[StaffSystem]:
    """Find which staff system a Y coordinate belongs to."""
    for s in systems:
        if s.top - margin * 3 <= y <= s.bottom + margin * 3:
            return s
    return None


# ═══════════════════════════════════════════════════════════════
# OM5: Tonhöhe bestimmen
# ═══════════════════════════════════════════════════════════════

# Treble clef: line positions (from bottom line)
# Bottom line = E4 (MIDI 64), each step = +/- 1 scale position
TREBLE_BOTTOM_MIDI = 64  # E4
BASS_BOTTOM_MIDI = 43    # G2

# Scale positions: C D E F G A B
SCALE_STEPS = [0, 2, 4, 5, 7, 9, 11]  # semitones from C


def note_y_to_midi(y: int, system: StaffSystem) -> Tuple[int, float]:
    """Convert Y position relative to staff to MIDI note number.

    Returns (midi_note, confidence).

    OM5: Vertikale Position → Tonhöhe
    """
    if not system.lines or len(system.lines) < 5:
        return 60, 0.0  # fallback C4

    spacing = system.spacing
    bottom_line = system.lines[4]  # bottom line of staff

    # Position in half-spaces from bottom line
    # Each half-space = one scale step
    half_spaces = (bottom_line - y) / (spacing / 2.0)
    position = round(half_spaces)

    # Map position to MIDI
    if system.clef == "bass":
        base_midi = BASS_BOTTOM_MIDI
    else:
        base_midi = TREBLE_BOTTOM_MIDI

    # Each position is one diatonic step
    # position 0 = bottom line, 1 = first space, 2 = second line, etc.
    octave_offset = position // 7
    degree = position % 7
    if degree < 0:
        degree += 7
        octave_offset -= 1

    midi = base_midi + octave_offset * 12 + SCALE_STEPS[degree]

    # Apply key signature
    midi = _apply_key_signature(midi, degree, system)

    # Confidence based on how close to a line or space
    fractional = abs(half_spaces - position)
    confidence = max(0.0, 1.0 - fractional * 2)

    return max(0, min(127, midi)), confidence


def _apply_key_signature(midi: int, degree: int,
                          system: StaffSystem) -> int:
    """Apply sharps or flats from key signature."""
    # Sharps order: F C G D A E B
    sharp_degrees = [3, 0, 4, 1, 5, 2, 6]
    # Flats order: B E A D G C F
    flat_degrees = [6, 2, 5, 1, 4, 0, 3]

    if system.key_sharps > 0:
        for i in range(min(system.key_sharps, 7)):
            if degree == sharp_degrees[i]:
                midi += 1
                break
    elif system.key_flats > 0:
        for i in range(min(system.key_flats, 7)):
            if degree == flat_degrees[i]:
                midi -= 1
                break

    return midi


def midi_to_note_name(midi: int) -> str:
    """Convert MIDI number to note name (e.g. 60 → 'C4')."""
    names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
    octave = (midi // 12) - 1
    note = names[midi % 12]
    return f"{note}{octave}"


# ═══════════════════════════════════════════════════════════════
# OM4: Rhythmus — Hälse, Fähnchen, Balken, Taktstriche
# ═══════════════════════════════════════════════════════════════

def detect_stems(binary, note_heads: List[Dict],
                  systems: List[StaffSystem]) -> List[Dict]:
    """Detect note stems (vertical lines attached to note heads).

    OM4: Notenhälse erkennen — Strich am Notenkopf → Richtung
    Stem up = Hals geht nach oben (rechts vom Kopf)
    Stem down = Hals geht nach unten (links vom Kopf)
    """
    cv2, np = _ensure_cv2()

    if not systems:
        return note_heads

    avg_spacing = sum(s.spacing for s in systems) / len(systems)
    stem_length_min = int(avg_spacing * 2.0)
    stem_search_w = int(avg_spacing * 0.6)

    for nh in note_heads:
        x, y = nh["x"], nh["y"]
        h, w = binary.shape

        # Search for vertical line above the note head (stem up)
        up_region = binary[max(0, y - int(avg_spacing * 4)):y,
                           max(0, x - 2):min(w, x + stem_search_w)]
        # Search below (stem down)
        down_region = binary[y:min(h, y + int(avg_spacing * 4)),
                             max(0, x - stem_search_w):min(w, x + 2)]

        up_proj = np.sum(up_region, axis=0) / 255 if up_region.size > 0 else np.array([0])
        down_proj = np.sum(down_region, axis=0) / 255 if down_region.size > 0 else np.array([0])

        up_max = float(np.max(up_proj)) if len(up_proj) > 0 else 0
        down_max = float(np.max(down_proj)) if len(down_proj) > 0 else 0

        has_stem = up_max >= stem_length_min or down_max >= stem_length_min
        stem_dir = "up" if up_max > down_max else "down"
        stem_length = max(up_max, down_max)

        nh["has_stem"] = has_stem
        nh["stem_dir"] = stem_dir if has_stem else "none"
        nh["stem_length"] = stem_length

    return note_heads


def detect_flags_and_beams(binary, note_heads: List[Dict],
                            systems: List[StaffSystem]) -> List[Dict]:
    """Count flags at stem end and detect beams.

    OM4: Fähnchen zählen + Balken erkennen
    0 flags = quarter, 1 = eighth, 2 = sixteenth, 3 = 32nd
    Beams connect multiple stems horizontally.
    """
    cv2, np = _ensure_cv2()

    if not systems:
        return note_heads

    avg_spacing = sum(s.spacing for s in systems) / len(systems)

    for nh in note_heads:
        if not nh.get("has_stem", False):
            nh["flags"] = 0
            nh["beamed"] = False
            continue

        x, y = nh["x"], nh["y"]
        h, w = binary.shape

        # Flag region: at the end of the stem, to the right
        if nh["stem_dir"] == "up":
            stem_end_y = max(0, y - int(nh.get("stem_length", avg_spacing * 3)))
            flag_region = binary[max(0, stem_end_y - int(avg_spacing)):
                                  stem_end_y + int(avg_spacing * 0.5),
                                  x:min(w, x + int(avg_spacing * 2))]
        else:
            stem_end_y = min(h, y + int(nh.get("stem_length", avg_spacing * 3)))
            flag_region = binary[max(0, stem_end_y - int(avg_spacing * 0.5)):
                                  min(h, stem_end_y + int(avg_spacing)),
                                  max(0, x - int(avg_spacing * 2)):x]

        if flag_region.size == 0:
            nh["flags"] = 0
            nh["beamed"] = False
            continue

        # Count horizontal density bands (each flag = one band)
        h_proj = np.sum(flag_region, axis=1) / 255
        threshold = avg_spacing * 0.3
        flag_count = 0
        in_flag = False
        for val in h_proj:
            if val > threshold and not in_flag:
                flag_count += 1
                in_flag = True
            elif val <= threshold:
                in_flag = False

        # Check if beamed (thick horizontal connecting multiple stems)
        beam_region_y = stem_end_y
        beam_row = binary[max(0, beam_region_y - 2):min(h, beam_region_y + 2), :]
        beam_proj = np.sum(beam_row, axis=0) / 255
        beam_runs = np.sum(beam_proj > 1)
        beamed = beam_runs > avg_spacing * 3

        nh["flags"] = min(flag_count, 3)
        nh["beamed"] = beamed

    return note_heads


def detect_barlines(binary, systems: List[StaffSystem]) -> List[int]:
    """Detect barlines (vertical lines spanning the full staff height).

    OM4: Taktstriche finden → Takte abgrenzen
    Returns list of X positions of barlines.
    """
    cv2, np = _ensure_cv2()

    if not systems:
        return []

    h, w = binary.shape
    barlines = []

    for system in systems:
        staff_h = system.bottom - system.top
        min_barline_h = int(staff_h * 0.7)

        # Vertical projection in the staff region
        staff_region = binary[system.top:system.bottom, :]
        v_proj = np.sum(staff_region, axis=0) / 255

        # Barlines: narrow vertical columns with high density
        for x in range(len(v_proj)):
            if v_proj[x] >= min_barline_h:
                # Check it's narrow (not a stem group)
                if x > 0 and v_proj[x - 1] < min_barline_h * 0.5:
                    barlines.append(x)

    # Deduplicate (merge nearby barlines)
    if barlines:
        merged = [barlines[0]]
        for bl in barlines[1:]:
            if bl - merged[-1] > 10:
                merged.append(bl)
        barlines = merged

    return barlines


def estimate_duration_advanced(note_head: Dict) -> float:
    """Estimate note duration from stem, flags, fill.

    OM4: Vollständige Rhythmus-Erkennung
    """
    is_filled = note_head.get("filled", True)
    has_stem = note_head.get("has_stem", False)
    flags = note_head.get("flags", 0)

    if not is_filled and not has_stem:
        return 4.0  # Whole note (Ganze)
    elif not is_filled and has_stem:
        return 2.0  # Half note (Halbe)
    elif is_filled and has_stem and flags == 0:
        return 1.0  # Quarter note (Viertel)
    elif is_filled and flags == 1:
        return 0.5  # Eighth note (Achtel)
    elif is_filled and flags == 2:
        return 0.25  # Sixteenth (Sechzehntel)
    elif is_filled and flags >= 3:
        return 0.125  # 32nd (Zweiunddreißigstel)
    else:
        return 1.0  # Default quarter


# ═══════════════════════════════════════════════════════════════
# OM8: Erweitert — Liedtext, Dynamik, Tempo, Akkorde
# ═══════════════════════════════════════════════════════════════

def detect_dynamics(binary, systems: List[StaffSystem]) -> List[Dict]:
    """Detect dynamic markings below/above staff.

    OM8: pp, p, mp, mf, f, ff, crescendo
    Returns list of {x, dynamic, velocity}
    """
    # Simplified: map common dynamic text patterns to velocity
    DYNAMIC_VELOCITY = {
        "pp": 30, "p": 50, "mp": 65, "mf": 80,
        "f": 100, "ff": 120, "fff": 127,
    }
    # Full implementation would use OCR on regions below staff
    return []


def detect_tempo_marking(text: str) -> int:
    """Extract tempo from text (e.g. '♩=120', 'Allegro').

    OM8: Tempo-Angaben
    """
    import re

    # Direct BPM: ♩=120, q=120, BPM 120
    m = re.search(r'[♩qQ]\s*=\s*(\d+)', text)
    if m:
        return int(m.group(1))

    m = re.search(r'(\d+)\s*[Bb][Pp][Mm]', text)
    if m:
        return int(m.group(1))

    # Italian tempo markings
    tempos = {
        "largo": 50, "lento": 55, "adagio": 65, "andante": 76,
        "moderato": 100, "allegretto": 112, "allegro": 132,
        "vivace": 152, "presto": 176, "prestissimo": 200,
    }
    text_lower = text.lower()
    for name, bpm in tempos.items():
        if name in text_lower:
            return bpm

    return 0  # unknown


# ═══════════════════════════════════════════════════════════════
# OM6: MIDI-Export + DAW-Integration
# ═══════════════════════════════════════════════════════════════

def notes_to_midi_file(notes: List[DetectedNote], path: str,
                       tempo: int = 120):
    """Export detected notes as MIDI file.

    OM6: MIDI-Datei schreiben
    """
    try:
        import mido
    except ImportError:
        log.warning("[OMR] mido nicht installiert — MIDI-Export deaktiviert")
        return

    mid = mido.MidiFile()
    track = mido.MidiTrack()
    mid.tracks.append(track)

    track.append(mido.MetaMessage('set_tempo', tempo=mido.bpm2tempo(tempo)))

    ticks_per_beat = mid.ticks_per_beat
    sorted_notes = sorted(notes, key=lambda n: n.beat)

    current_tick = 0
    for note in sorted_notes:
        note_tick = int(note.beat * ticks_per_beat)
        delta = max(0, note_tick - current_tick)
        dur_ticks = int(note.duration * ticks_per_beat)

        track.append(mido.Message('note_on', note=note.midi,
                                   velocity=note.velocity, time=delta))
        track.append(mido.Message('note_off', note=note.midi,
                                   velocity=0, time=dur_ticks))
        current_tick = note_tick + dur_ticks

    mid.save(path)
    log.info("[OMR] MIDI gespeichert: %s (%d Noten)", path, len(notes))


# ═══════════════════════════════════════════════════════════════
# Haupt-Service
# ═══════════════════════════════════════════════════════════════

class OMRService:
    """Optical Music Recognition — Notenblätter scannen → MIDI."""

    def scan_pdf(self, path: str, dpi: int = 300) -> OMRResult:
        """Scanne ein PDF mit Notenblättern.

        1. PDF → Bilder (300 DPI)
        2. Notenlinien erkennen
        3. Notenköpfe finden
        4. Tonhöhe + Rhythmus bestimmen
        5. MIDI-Noten zurückgeben
        """
        try:
            images = extract_images_from_pdf(path, dpi)
        except Exception as e:
            return OMRResult(source_path=path, pages=[],
                              error=f"PDF laden fehlgeschlagen: {e}")

        return self._process_images(images, path)

    def scan_image(self, path: str) -> OMRResult:
        """Scanne ein einzelnes Notenbild."""
        try:
            img = load_image(path)
        except Exception as e:
            return OMRResult(source_path=path, pages=[],
                              error=f"Bild laden fehlgeschlagen: {e}")

        return self._process_images([img], path)

    def scan_file(self, path: str) -> OMRResult:
        """Auto-detect file type and scan."""
        ext = Path(path).suffix.lower()
        if ext == ".pdf":
            return self.scan_pdf(path)
        elif ext in (".png", ".jpg", ".jpeg", ".tiff", ".tif", ".bmp"):
            return self.scan_image(path)
        elif ext == ".docx":
            return self._scan_docx(path)
        else:
            return OMRResult(source_path=path, pages=[],
                              error=f"Nicht unterstütztes Format: {ext}")

    def _process_images(self, images: list, source_path: str) -> OMRResult:
        """Process list of grayscale images through the OMR pipeline."""
        pages = []
        total_notes = 0

        for page_num, gray in enumerate(images):
            log.info("[OMR] Verarbeite Seite %d…", page_num + 1)

            # OM1: Vorverarbeitung
            binary = preprocess_image(gray)

            # OM2: Notenlinien
            systems = detect_staff_lines(binary)

            if not systems:
                log.warning("[OMR] Seite %d: Keine Notensysteme gefunden", page_num + 1)
                pages.append(OMRPage(
                    page_number=page_num + 1,
                    width=gray.shape[1], height=gray.shape[0],
                    systems=[], notes=[],
                ))
                continue

            # OM2: Linien entfernen
            cleaned = remove_staff_lines(binary, systems)

            # OM3: Notenköpfe
            note_heads = detect_note_heads(cleaned, systems)

            # OM4: Hälse + Fähnchen erkennen
            note_heads = detect_stems(binary, note_heads, systems)
            note_heads = detect_flags_and_beams(binary, note_heads, systems)

            # OM4: Taktstriche
            barlines = detect_barlines(binary, systems)

            # OM3+OM5: Tonhöhe + OM4: Rhythmus
            detected_notes = []
            # Sort by X position (left to right = time order)
            note_heads.sort(key=lambda n: n["x"])

            beat = 0.0
            current_bar = 0
            for nh in note_heads:
                midi, conf = note_y_to_midi(nh["y"], nh["system"])
                duration = estimate_duration_advanced(nh)

                # Check if we crossed a barline
                bl_crossed = sum(1 for bl in barlines
                                 if len(detected_notes) > 0 and
                                 detected_notes[-1].x < bl <= nh["x"])
                if bl_crossed > 0:
                    current_bar += bl_crossed

                note = DetectedNote(
                    midi=midi,
                    beat=beat,
                    duration=duration,
                    velocity=90,
                    confidence=conf * nh.get("confidence", 0.5),
                    x=nh["x"], y=nh["y"],
                    note_name=midi_to_note_name(midi),
                )
                detected_notes.append(note)
                beat += duration
                total_notes += 1

            # OM8: Liedtext, Wiederholung, Akkorde
            lyrics = self.detect_lyrics(gray, systems)
            repeats = self.detect_repeat_signs(binary, systems)
            chord_regions = self.detect_chord_symbols(gray, systems)

            page_result = OMRPage(
                page_number=page_num + 1,
                width=gray.shape[1], height=gray.shape[0],
                systems=systems,
                notes=detected_notes,
            )
            # Store extra data as attributes
            page_result.lyrics = lyrics          # type: ignore
            page_result.repeats = repeats        # type: ignore
            page_result.chords = chord_regions   # type: ignore
            page_result.barlines = barlines      # type: ignore
            page_result.gray_image = gray        # type: ignore  # for preview

            pages.append(page_result)

            log.info("[OMR] Seite %d: %d Systeme, %d Noten, %d Liedtext, %d Wdh, %d Akkorde",
                     page_num + 1, len(systems), len(detected_notes),
                     len(lyrics), len(repeats), len(chord_regions))

        return OMRResult(
            source_path=source_path,
            pages=pages,
            total_notes=total_notes,
        )

    def _scan_docx(self, path: str) -> OMRResult:
        """Extract images from DOCX and scan them."""
        cv2, np = _ensure_cv2()

        try:
            import docx
            doc = docx.Document(path)
        except ImportError:
            return OMRResult(source_path=path, pages=[],
                              error="python-docx nicht installiert")
        except Exception as e:
            return OMRResult(source_path=path, pages=[],
                              error=str(e))

        images = []
        for rel in doc.part.rels.values():
            if "image" in rel.reltype:
                try:
                    blob = rel.target_part.blob
                    arr = np.frombuffer(blob, dtype=np.uint8)
                    img = cv2.imdecode(arr, cv2.IMREAD_GRAYSCALE)
                    if img is not None:
                        images.append(img)
                except Exception:
                    continue

        if not images:
            return OMRResult(source_path=path, pages=[],
                              error="Keine Bilder im DOCX gefunden")

        return self._process_images(images, path)

    def get_midi_notes(self, result: OMRResult) -> List[Dict]:
        """Convert OMR result to note dicts for DAW insertion."""
        notes = []
        for page in result.pages:
            for note in page.notes:
                notes.append({
                    "midi": note.midi,
                    "start_beat": note.beat,
                    "duration_beats": note.duration,
                    "velocity": note.velocity,
                })
        return notes

    # ═══════════════════════════════════════════════════════════
    # OM7: Vorschau + Korrektur
    # ═══════════════════════════════════════════════════════════

    def generate_preview(self, gray_image, page: OMRPage) -> bytes:
        """OM7: Erkannte Noten über Original-Bild einblenden.

        Zeichnet farbige Marker auf erkannte Noten:
          - Grün: hohe Confidence (>0.7)
          - Gelb: mittlere Confidence (0.4-0.7)
          - Rot: niedrige Confidence (<0.4)
          - Blaue Linien: erkannte Notensysteme

        Returns: PNG-Bytes des annotierten Bildes.
        """
        cv2, np = _ensure_cv2()

        # Convert grayscale to color for overlay
        if len(gray_image.shape) == 2:
            preview = cv2.cvtColor(gray_image, cv2.COLOR_GRAY2BGR)
        else:
            preview = gray_image.copy()

        # Draw staff lines (blue)
        for system in page.systems:
            for line_y in system.lines:
                cv2.line(preview, (0, line_y),
                         (preview.shape[1], line_y), (255, 100, 0), 1)

        # Draw detected notes
        for note in page.notes:
            # Color by confidence
            if note.confidence > 0.7:
                color = (0, 220, 0)     # green
            elif note.confidence > 0.4:
                color = (0, 220, 220)   # yellow
            else:
                color = (0, 0, 220)     # red

            # Circle around note head
            r = int(page.systems[0].spacing * 0.6) if page.systems else 8
            cv2.circle(preview, (note.x, note.y), r, color, 2)

            # Note name label
            cv2.putText(preview, note.note_name,
                        (note.x - 10, note.y - r - 4),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.35, color, 1)

        # Encode as PNG
        _, png = cv2.imencode('.png', preview)
        return png.tobytes()

    @staticmethod
    def correct_note(page: OMRPage, note_index: int,
                     new_midi: int = None, new_duration: float = None,
                     delete: bool = False) -> bool:
        """OM7: Korrektur — falsch erkannte Noten manuell ändern.

        Args:
            page: The OMR page result
            note_index: Index of the note to correct
            new_midi: New MIDI note number (None = keep)
            new_duration: New duration in beats (None = keep)
            delete: True = remove this note

        Returns: True if correction was applied.
        """
        if note_index < 0 or note_index >= len(page.notes):
            return False

        if delete:
            page.notes.pop(note_index)
            return True

        note = page.notes[note_index]
        if new_midi is not None:
            note.midi = max(0, min(127, new_midi))
            note.note_name = midi_to_note_name(note.midi)
            note.confidence = 1.0  # manually corrected = 100%
        if new_duration is not None:
            note.duration = max(0.0625, new_duration)

        return True

    # ═══════════════════════════════════════════════════════════
    # OM8: Liedtext, Wiederholung, Akkorde
    # ═══════════════════════════════════════════════════════════

    def detect_lyrics(self, gray_image, systems: List[StaffSystem]) -> List[Dict]:
        """OM8: Liedtext unter Noten erkennen.

        Findet Text-Regionen unterhalb jedes Notensystems
        und extrahiert den Text mittels einfacher Kontur-Analyse.

        Returns: [{system_idx, text, y_pos}]
        """
        cv2, np = _ensure_cv2()

        if not systems:
            return []

        lyrics = []
        h, w = gray_image.shape[:2]

        for sys_idx, system in enumerate(systems):
            # Text region: below staff, before next staff
            text_top = system.bottom + int(system.spacing * 0.5)
            if sys_idx + 1 < len(systems):
                text_bottom = min(systems[sys_idx + 1].top - int(system.spacing),
                                   text_top + int(system.spacing * 4))
            else:
                text_bottom = min(h, text_top + int(system.spacing * 4))

            if text_top >= text_bottom or text_top >= h:
                continue

            text_region = gray_image[text_top:text_bottom, :]

            # Check if there's significant content (text)
            _, text_bin = cv2.threshold(text_region, 0, 255,
                                         cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
            density = np.sum(text_bin > 0) / max(text_bin.size, 1)

            if density > 0.02:  # at least 2% ink = likely text
                # Find word-like contours
                contours, _ = cv2.findContours(
                    text_bin, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
                )

                # Sort contours left-to-right
                word_boxes = []
                for c in contours:
                    x_c, y_c, w_c, h_c = cv2.boundingRect(c)
                    if h_c > system.spacing * 0.3 and w_c > 3:
                        word_boxes.append((x_c, y_c, w_c, h_c))
                word_boxes.sort(key=lambda b: b[0])

                # Group into syllables (approximate)
                syllables = []
                for bx, by, bw, bh in word_boxes:
                    syllables.append(f"[{bx}]")  # placeholder — real OCR needs tesseract

                lyrics.append({
                    "system_idx": sys_idx,
                    "y_pos": text_top,
                    "word_count": len(word_boxes),
                    "has_text": True,
                    "note": "Liedtext erkannt — für volle OCR: pip install pytesseract",
                })

        return lyrics

    def detect_repeat_signs(self, binary,
                             systems: List[StaffSystem]) -> List[Dict]:
        """OM8: Wiederholungszeichen erkennen.

        Sucht nach:
          - Doppelstriche mit Punkten (:|  |:)
          - Doppelstrich am Ende (||)
          - Segno (𝄋) und Coda (𝄌) Marker

        Returns: [{type, x, system_idx}]
        """
        cv2, np = _ensure_cv2()

        if not systems:
            return []

        repeats = []
        h, w = binary.shape

        for sys_idx, system in enumerate(systems):
            staff_h = system.bottom - system.top
            staff_region = binary[system.top:system.bottom, :]

            # Vertical projection
            v_proj = np.sum(staff_region, axis=0) / 255
            min_height = staff_h * 0.6

            # Find thick barlines (double bar = two close vertical lines)
            barline_positions = []
            for x in range(1, len(v_proj) - 1):
                if v_proj[x] >= min_height:
                    barline_positions.append(x)

            # Group close barlines
            groups = []
            if barline_positions:
                group = [barline_positions[0]]
                for bp in barline_positions[1:]:
                    if bp - group[-1] <= 5:
                        group.append(bp)
                    else:
                        groups.append(group)
                        group = [bp]
                groups.append(group)

            # Check for double barlines (repeat signs)
            for i in range(len(groups) - 1):
                gap = groups[i + 1][0] - groups[i][-1]
                if 3 < gap < system.spacing * 1.5:
                    center_x = (groups[i][-1] + groups[i + 1][0]) // 2

                    # Check for dots (small blobs between lines 2-3 and 3-4)
                    dot_region = binary[
                        system.lines[1]:system.lines[3],
                        max(0, center_x - int(system.spacing)):
                        min(w, center_x + int(system.spacing))
                    ]
                    dot_density = np.sum(dot_region > 0) / max(dot_region.size, 1)

                    if dot_density > 0.05:
                        # Dots found → repeat sign
                        # Determine direction by dot position
                        left_dots = binary[
                            system.lines[1]:system.lines[3],
                            max(0, groups[i][0] - int(system.spacing)):groups[i][0]
                        ]
                        right_dots = binary[
                            system.lines[1]:system.lines[3],
                            groups[i+1][-1]:min(w, groups[i+1][-1] + int(system.spacing))
                        ]

                        left_d = np.sum(left_dots > 0) if left_dots.size > 0 else 0
                        right_d = np.sum(right_dots > 0) if right_dots.size > 0 else 0

                        if left_d > right_d:
                            rtype = "end_repeat"    # :|
                        elif right_d > left_d:
                            rtype = "start_repeat"  # |:
                        else:
                            rtype = "double_repeat"  # :|:

                        repeats.append({
                            "type": rtype,
                            "x": center_x,
                            "system_idx": sys_idx,
                        })
                    else:
                        repeats.append({
                            "type": "double_barline",
                            "x": center_x,
                            "system_idx": sys_idx,
                        })

        return repeats

    def detect_chord_symbols(self, gray_image,
                              systems: List[StaffSystem]) -> List[Dict]:
        """OM8: Akkord-Symbole über dem Notensystem erkennen.

        Sucht Text-Blöcke oberhalb des Systems (Cm, G7, F#dim, etc.)

        Returns: [{x, text_region_width, system_idx, estimated_x_beat}]
        """
        cv2, np = _ensure_cv2()

        if not systems:
            return []

        chords = []
        h, w = gray_image.shape[:2]

        for sys_idx, system in enumerate(systems):
            # Chord region: above staff
            chord_bottom = system.top - int(system.spacing * 0.5)
            chord_top = max(0, chord_bottom - int(system.spacing * 3))

            if chord_top >= chord_bottom:
                continue

            chord_region = gray_image[chord_top:chord_bottom, :]

            # Threshold
            _, chord_bin = cv2.threshold(chord_region, 0, 255,
                                          cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

            # Find contours (text blocks)
            contours, _ = cv2.findContours(
                chord_bin, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
            )

            for c in contours:
                x_c, y_c, w_c, h_c = cv2.boundingRect(c)
                # Chord symbols are typically small text blocks
                if (system.spacing * 0.4 < h_c < system.spacing * 2.5 and
                        w_c > system.spacing * 0.3 and
                        w_c < system.spacing * 5):
                    chords.append({
                        "x": x_c,
                        "y": chord_top + y_c,
                        "width": w_c,
                        "height": h_c,
                        "system_idx": sys_idx,
                        "note": "Akkord-Region erkannt — volle Erkennung braucht OCR",
                    })

            # Sort left to right
            chords.sort(key=lambda c: c["x"])

        return chords
