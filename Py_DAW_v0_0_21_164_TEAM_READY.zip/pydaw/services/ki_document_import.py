"""ki_document_import.py — Document Import for Composition (v0.0.20.987)

KK6: Dokument-Import

Supports importing text and music from various formats:
  - TXT: Plain text (always available)
  - DOCX: Word documents (python-docx if installed)
  - PDF: PDF text extraction (pymupdf/fitz if installed)
  - MusicXML: Music notation (xml.etree always available)
  - MIDI: MIDI file import (mido if installed)
  - Verse/stanza detection from formatted text

All imports are optional — graceful fallback if libraries missing.
"""

import os
import re
import logging
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple

log = logging.getLogger(__name__)


@dataclass
class ImportedDocument:
    """Result of document import."""
    source_path: str
    format: str                     # "txt", "docx", "pdf", "musicxml", "midi"
    text: str = ""                  # Extracted text
    verses: List[List[str]] = field(default_factory=list)  # Grouped into verses
    title: str = ""
    author: str = ""
    # Music data (from MusicXML/MIDI)
    midi_notes: List[int] = field(default_factory=list)
    key_signature: str = ""
    time_signature: str = ""
    tempo: int = 0
    error: str = ""


# ═══════════════════════════════════════════════════════════════
# TXT Import (always available)
# ═══════════════════════════════════════════════════════════════

def import_txt(path: str) -> ImportedDocument:
    """Import plain text file."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except UnicodeDecodeError:
        with open(path, "r", encoding="latin-1") as f:
            text = f.read()

    verses = detect_verses(text)
    title = _extract_title(text)

    return ImportedDocument(
        source_path=path, format="txt",
        text=text, verses=verses, title=title,
    )


# ═══════════════════════════════════════════════════════════════
# DOCX Import (optional: python-docx)
# ═══════════════════════════════════════════════════════════════

def import_docx(path: str) -> ImportedDocument:
    """Import Word document."""
    try:
        import docx
    except ImportError:
        return ImportedDocument(
            source_path=path, format="docx",
            error="python-docx not installed (pip install python-docx)",
        )

    try:
        doc = docx.Document(path)
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        text = "\n".join(paragraphs)
        verses = detect_verses(text)
        title = paragraphs[0] if paragraphs else ""

        return ImportedDocument(
            source_path=path, format="docx",
            text=text, verses=verses, title=title,
        )
    except Exception as e:
        return ImportedDocument(source_path=path, format="docx",
                                error=str(e))


# ═══════════════════════════════════════════════════════════════
# PDF Import (optional: pymupdf/fitz)
# ═══════════════════════════════════════════════════════════════

def import_pdf(path: str) -> ImportedDocument:
    """Import PDF (text extraction, no OCR)."""
    try:
        import fitz  # pymupdf
    except ImportError:
        return ImportedDocument(
            source_path=path, format="pdf",
            error="PyMuPDF not installed (pip install pymupdf)",
        )

    try:
        doc = fitz.open(path)
        pages_text = []
        for page in doc:
            pages_text.append(page.get_text())
        doc.close()

        text = "\n".join(pages_text)
        verses = detect_verses(text)
        title = _extract_title(text)

        return ImportedDocument(
            source_path=path, format="pdf",
            text=text, verses=verses, title=title,
        )
    except Exception as e:
        return ImportedDocument(source_path=path, format="pdf",
                                error=str(e))


# ═══════════════════════════════════════════════════════════════
# MusicXML Import (xml.etree — always available)
# ═══════════════════════════════════════════════════════════════

def import_musicxml(path: str) -> ImportedDocument:
    """Import MusicXML file (notes, key, time signature)."""
    try:
        import xml.etree.ElementTree as ET
        tree = ET.parse(path)
        root = tree.getroot()

        # Handle namespace
        ns = ""
        if root.tag.startswith("{"):
            ns = root.tag.split("}")[0] + "}"

        midi_notes = []
        key_sig = ""
        time_sig = ""
        title = ""

        # Title
        title_el = root.find(f".//{ns}work-title")
        if title_el is not None and title_el.text:
            title = title_el.text

        # Key signature
        key_el = root.find(f".//{ns}key")
        if key_el is not None:
            fifths = key_el.find(f"{ns}fifths")
            mode = key_el.find(f"{ns}mode")
            if fifths is not None:
                key_map = {-7: "Cb", -6: "Gb", -5: "Db", -4: "Ab", -3: "Eb",
                           -2: "Bb", -1: "F", 0: "C", 1: "G", 2: "D",
                           3: "A", 4: "E", 5: "B", 6: "F#", 7: "C#"}
                key_root = key_map.get(int(fifths.text), "C")
                key_mode = mode.text if mode is not None else "major"
                key_sig = f"{key_root} {key_mode}"

        # Time signature
        time_el = root.find(f".//{ns}time")
        if time_el is not None:
            beats = time_el.find(f"{ns}beats")
            beat_type = time_el.find(f"{ns}beat-type")
            if beats is not None and beat_type is not None:
                time_sig = f"{beats.text}/{beat_type.text}"

        # Notes
        for note_el in root.iter(f"{ns}note"):
            rest = note_el.find(f"{ns}rest")
            if rest is not None:
                continue

            pitch_el = note_el.find(f"{ns}pitch")
            if pitch_el is None:
                continue

            step = pitch_el.find(f"{ns}step")
            octave = pitch_el.find(f"{ns}octave")
            alter = pitch_el.find(f"{ns}alter")

            if step is not None and octave is not None:
                note_map = {"C": 0, "D": 2, "E": 4, "F": 5,
                            "G": 7, "A": 9, "B": 11}
                midi = note_map.get(step.text, 0) + (int(octave.text) + 1) * 12
                if alter is not None:
                    midi += int(float(alter.text))
                midi_notes.append(midi)

        return ImportedDocument(
            source_path=path, format="musicxml",
            midi_notes=midi_notes, key_signature=key_sig,
            time_signature=time_sig, title=title,
        )
    except Exception as e:
        return ImportedDocument(source_path=path, format="musicxml",
                                error=str(e))


# ═══════════════════════════════════════════════════════════════
# MIDI Import (optional: mido)
# ═══════════════════════════════════════════════════════════════

def import_midi(path: str) -> ImportedDocument:
    """Import MIDI file."""
    try:
        import mido
    except ImportError:
        return ImportedDocument(
            source_path=path, format="midi",
            error="mido not installed (pip install mido)",
        )

    try:
        mid = mido.MidiFile(path)
        midi_notes = []
        tempo = 120

        for track in mid.tracks:
            for msg in track:
                if msg.type == "note_on" and msg.velocity > 0:
                    midi_notes.append(msg.note)
                elif msg.type == "set_tempo":
                    tempo = int(mido.tempo2bpm(msg.tempo))

        return ImportedDocument(
            source_path=path, format="midi",
            midi_notes=midi_notes, tempo=tempo,
            title=os.path.splitext(os.path.basename(path))[0],
        )
    except Exception as e:
        return ImportedDocument(source_path=path, format="midi",
                                error=str(e))


# ═══════════════════════════════════════════════════════════════
# Verse / Stanza Detection
# ═══════════════════════════════════════════════════════════════

def detect_verses(text: str) -> List[List[str]]:
    """Detect verses/stanzas in text.

    Splits on double newlines or numbered verse markers.
    """
    # Try splitting on double newlines first
    blocks = re.split(r'\n\s*\n', text.strip())

    verses = []
    for block in blocks:
        lines = [l.strip() for l in block.split("\n") if l.strip()]
        if lines:
            # Remove verse numbers
            cleaned = []
            for line in lines:
                line = re.sub(r'^\d+[\.\)]\s*', '', line)
                if line:
                    cleaned.append(line)
            if cleaned:
                verses.append(cleaned)

    return verses


def detect_refrain(verses: List[List[str]]) -> Optional[List[str]]:
    """Detect if there's a repeating refrain."""
    if len(verses) < 3:
        return None

    # Check if any verse repeats
    for i in range(len(verses)):
        for j in range(i + 1, len(verses)):
            if verses[i] == verses[j]:
                return verses[i]
    return None


# ═══════════════════════════════════════════════════════════════
# Auto-Import (detect format from extension)
# ═══════════════════════════════════════════════════════════════

def import_document(path: str) -> ImportedDocument:
    """Auto-detect format and import document."""
    path = str(path)
    ext = Path(path).suffix.lower()

    importers = {
        ".txt": import_txt,
        ".docx": import_docx,
        ".doc": import_docx,
        ".pdf": import_pdf,
        ".xml": import_musicxml,
        ".musicxml": import_musicxml,
        ".mxl": import_musicxml,
        ".mid": import_midi,
        ".midi": import_midi,
    }

    importer = importers.get(ext)
    if importer is None:
        # Try as plain text
        return import_txt(path)

    return importer(path)


def _extract_title(text: str) -> str:
    """Extract title from first non-empty line."""
    for line in text.split("\n"):
        line = line.strip()
        if line and len(line) < 100:
            return line
    return ""
