"""Service container wiring (v0.0.15.8 + fix11)."""

from __future__ import annotations

from dataclasses import dataclass
import os

from pydaw.core.threading import ThreadPoolService
from pydaw.services.project_service import ProjectService
from pydaw.audio.audio_engine import AudioEngine
from pydaw.services.transport_service import TransportService
from pydaw.services.launcher_service import LauncherService
from pydaw.services.cliplauncher_playback import ClipLauncherPlaybackService
from pydaw.services.metronome_service import MetronomeService
from pydaw.services.midi_service import MidiService
from pydaw.services.jack_client_service import JackClientService
from pydaw.services.recording_service import RecordingService
from pydaw.services.take_service import TakeService
from pydaw.services.fluidsynth_service import FluidSynthService
from pydaw.utils.logging_setup import get_logger

from pydaw.core.settings_store import get_value
from pydaw.core.settings import SettingsKeys
from pydaw.services.midi_mapping_service import MidiMappingService
from pydaw.services.automation_playback import AutomationPlaybackService
from pydaw.audio.automatable_parameter import AutomationManager
from pydaw.services.prewarm_service import PrewarmService
from pydaw.services.clip_context_service import ClipContextService
from pydaw.services.project_tab_service import ProjectTabService
from pydaw.services.editor_timeline_adapter import EditorTimelineAdapter

log = get_logger(__name__)


@dataclass
class ServiceContainer:
    threadpool: ThreadPoolService
    project: ProjectService
    audio_engine: AudioEngine
    transport: TransportService
    launcher: LauncherService
    metronome: MetronomeService
    midi: MidiService
    midi_mapping: MidiMappingService
    jack: JackClientService
    automation_playback: AutomationPlaybackService
    automation_manager: AutomationManager
    recording: RecordingService
    take: TakeService
    fluidsynth: FluidSynthService
    prewarm: PrewarmService
    clip_context: ClipContextService
    input_monitor: "InputMonitor"  # v0.0.20.757
    project_tabs: ProjectTabService
    # v0.0.20.612: Dual-Clock Phase C — Zeitadapter für Editoren
    editor_timeline: EditorTimelineAdapter | None = None
    # v0.0.20.798 P5A: Git Integration + Review
    git: "GitIntegrationService | None" = None
    review: "ReviewService | None" = None
    # v0.0.20.798 P6A: Python Scripting
    scripting: "ScriptingService | None" = None
    # v0.0.20.910 C2C.4: Collab Service (server + client + discovery)
    collab_server: "CollabServer | None" = None
    collab_client: "CollabClient | None" = None

    @classmethod
    def create_default(cls, progress_callback=None) -> "ServiceContainer":
        def _progress(msg, pct):
            if progress_callback:
                try:
                    progress_callback(msg, pct)
                except Exception:
                    pass

        _progress("Thread-Pool initialisieren...", 0.05)
        threadpool = ThreadPoolService.create_default()
        project = ProjectService(threadpool=threadpool)

        _progress("Audio-Engine erstellen...", 0.10)
        audio_engine = AudioEngine()
        # forward engine status to the app status bus
        try:
            audio_engine.status.connect(lambda m: project.status.emit(m))
            audio_engine.error.connect(lambda m: project.error.emit(m))
        except Exception:
            pass
        # v0.0.20.428: Give ProjectService access to running VST engines for Bounce
        try:
            project._audio_engine_ref = audio_engine
        except Exception:
            pass
        transport = TransportService(
            bpm=project.ctx.project.bpm,
            time_signature=getattr(project.ctx.project, "time_signature", "4/4"),
        )
        # v0.0.21.105 / CS2-F: bind the first core/transport adapter early so
        # project-open and tab-switch bootstrap through a single Slice-0 bridge.
        try:
            project.bind_slice0_transport(transport)
            project.project_opened.connect(lambda: project.bootstrap_slice0_core_transport(transport))
        except Exception:
            pass

        # Binde AudioEngine an Project/Transport und starte/stopp-e
        # Arrangement-Playback, wenn der Transport spielt.
        try:
            audio_engine.bind_transport(project, transport)
        except Exception:
            # Fallback: AudioEngine bleibt im "none"/"silence"-Modus.
            pass
        launcher = LauncherService(project=project, transport=transport)

        # ClipLauncher realtime playback (AudioEvents/Loop) – optional service.
        try:
            cliplauncher_playback = ClipLauncherPlaybackService(
                project=project,
                transport=transport,
                audio_engine=audio_engine,
            )
            project.bind_cliplauncher_playback(cliplauncher_playback)
        except Exception:
            pass

        # Automation playback (read mode -> applies volume/pan curves while playing)
        automation_playback = AutomationPlaybackService(project=project, transport=transport)

        # Realtime parameter store lives on the AudioEngine. Mirror automation values
        # into the same RT store so DSP/FX can see timeline automation without any
        # direct GUI-thread writes into engine internals.
        rt_params = getattr(audio_engine, "rt_params", None)

        # Central Automation Manager (v0.0.20.89: Bitwig-style parameter automation)
        automation_manager = AutomationManager(rt_params=rt_params)

        # v0.0.20.173: Wire automation persistence (save/load) through ProjectService.
        # This keeps automation lanes across project reloads.
        try:
            setattr(project, 'automation_manager', automation_manager)
            # Import lanes when a project is opened/created
            project.project_opened.connect(lambda: project.load_automation_manager_from_project())
        except Exception:
            pass

        # Prewarm: prepare visible/active audio clips on BPM change (background).
        prewarm = PrewarmService(threadpool=threadpool, project_service=project, transport_service=transport)
        try:
            prewarm.status.connect(lambda m: project.status.emit(m))
            prewarm.error.connect(lambda m: project.error.emit(m))
        except Exception:
            pass

        _progress("MIDI-Controller verbinden...", 0.15)
        metronome = MetronomeService(on_status=lambda m: project.status.emit(m))
        midi = MidiService(status_cb=lambda m: project.status.emit(m), project_service=project, transport=transport)

        # v0.0.20.422: Auto-connect all available MIDI inputs at startup.
        # Users often forget to manually connect controllers via MIDI Settings.
        try:
            _midi_inputs = midi.list_inputs()
            for _inp in _midi_inputs:
                try:
                    # Skip virtual/through ports — only connect real hardware
                    _inp_lower = _inp.lower()
                    if "through" in _inp_lower or "virmidi" in _inp_lower:
                        continue
                    midi.connect_input(_inp)
                except Exception:
                    pass
            if _midi_inputs:
                _connected = midi.connected_inputs()
                if _connected:
                    log.info("MIDI: Auto-connected %d input(s): %s", len(_connected), ", ".join(_connected))
        except Exception:
            pass

        jack = JackClientService(status_cb=lambda m: project.status.emit(m))
        try:
            audio_engine.bind_jack(jack)
        except Exception:
            pass

        midi_mapping = MidiMappingService(
            project=project,
            transport=transport,
            status_cb=lambda m: project.status.emit(m),
        )
        try:
            midi.message_obj.connect(midi_mapping.handle_mido_message)
        except Exception:
            pass

        # v0.0.20.416: Bridge MidiMappingService → AutomationManager for live slider updates.
        # Emit parameter_changed directly — FX widgets listen for their parameter_id.
        try:
            def _bridge_mapping_to_am(_tid, param_id, value):
                try:
                    automation_manager.parameter_changed.emit(str(param_id), float(value))
                except Exception:
                    pass
            midi_mapping.value_applied.connect(_bridge_mapping_to_am)
        except Exception:
            pass

        # v0.0.20.397: Also route MIDI CC to AutomationManager for knob MIDI Learn
        try:
            midi.message_obj.connect(automation_manager.handle_midi_message)
        except Exception:
            pass

        # v0.0.20.431: Give MidiMappingService direct access to AutomationManager
        # so that MIDI-recorded automation points land in the SAME store
        # as UI-drawn points (fixes invisible recorded automation bug).
        try:
            midi_mapping.set_automation_manager(automation_manager)
        except Exception:
            pass

        # v0.0.20.433: Give AutomationManager access to transport + project
        # so that Fast Path MIDI Learn (CC→Knob) can also record automation.
        try:
            automation_manager.set_transport(transport)
            automation_manager.set_project(project)
        except Exception:
            pass

        # v0.0.20.440: Auto-thin recorded lanes when transport stops
        try:
            def _on_playing_changed_thin(is_playing):
                if not is_playing:
                    try:
                        removed = automation_manager.thin_recorded_lanes()
                        if removed > 0:
                            project.status.emit(f"Auto-Thin: {removed} redundante Punkte entfernt")
                    except Exception:
                        pass
            transport.playing_changed.connect(_on_playing_changed_thin)
        except Exception:
            pass

        # Try to register a visible JACK/PipeWire client (non-fatal if unavailable)
        # NOTE: This is intentionally independent from the engine backend.
        # Many users want sounddevice (PortAudio) for playback, but still want a JACK
        # client so PyDAW is visible in qpwgraph for routing/recording.
        keys = SettingsKeys()
        enable_jack = os.environ.get("PYDAW_ENABLE_JACK", "0") in ("1", "true", "True", "yes", "on")
        if enable_jack and JackClientService.probe_available():
            try:
                jack.start_async(
                    in_ports=get_value(keys.jack_in_ports, 2),
                    out_ports=get_value(keys.jack_out_ports, 2),
                    monitor_inputs_to_outputs=get_value(keys.jack_input_monitor, False),
                )
            except Exception:
                pass
        elif enable_jack and (not JackClientService.probe_available()):
            log.warning(
                "JACK client enabled, but JACK server is not reachable. "
                "Tip: start via 'pw-jack python3 main.py' or ensure PipeWire-JACK/JACK is active."
            )

        # Initialize recording service (PipeWire/JACK support)
        _progress("Recording-Service starten...", 0.20)
        recording = RecordingService()
        # v0.0.20.636: Wire buffer size from audio settings (AP2 Phase 2B)
        try:
            _keys = SettingsKeys()
            _buf = int(get_value(_keys.buffer_size, 512))
            recording.set_buffer_size(_buf)
        except Exception:
            pass
        log.info("Recording service initialized (backend: %s, buffer: %d)",
                 recording.get_backend(), recording.get_buffer_size())

        # v0.0.20.638: Load punch crossfade from settings into AudioConfig
        try:
            from pydaw.core.audio_config import audio_config
            _keys2 = SettingsKeys()
            _cf_ms = float(get_value(_keys2.punch_crossfade_ms, 10.0))
            audio_config.set_punch_crossfade_ms(_cf_ms)
        except Exception:
            pass

        # v0.0.20.639: TakeService for comping / take-lanes (AP2 Phase 2D)
        take_service = TakeService(project_service=project)
        log.info("TakeService initialized")
        
        # Initialize FluidSynth service (optional - won't crash if unavailable)
        _progress("FluidSynth laden...", 0.25)
        fluidsynth = FluidSynthService()
        try:
            fluidsynth.error.connect(lambda m: project.error.emit(m))
            fluidsynth.status.connect(lambda m: project.status.emit(m))
        except Exception:
            pass
        
        if fluidsynth.is_available():
            log.info("FluidSynth service initialized")
        else:
            log.warning("FluidSynth service not available (optional feature)")

        # ClipContextService für pyqtSlot → Editor Integration
        clip_context = ClipContextService(project_service=project)

        # v0.0.20.612: Dual-Clock Phase C — EditorTimelineAdapter
        try:
            editor_timeline = EditorTimelineAdapter(
                transport=transport,
                launcher_playback=cliplauncher_playback,
            )
            # Brücke: ClipContextService → Adapter
            clip_context.editor_focus_changed.connect(editor_timeline.set_focus)
        except Exception as exc:
            log.warning("EditorTimelineAdapter not available: %s", exc)
            editor_timeline = None

        # Multi-Project Tab Service (Bitwig-Style multi-project tabs)
        project_tabs = ProjectTabService()
        try:
            project_tabs.status.connect(lambda m: project.status.emit(m))
            project_tabs.error.connect(lambda m: project.error.emit(m))
        except Exception:
            pass

        # v0.0.20.757: InputMonitor — Echtzeit-Audio-Passthrough
        try:
            from pydaw.audio.input_monitor import InputMonitor
            input_monitor = InputMonitor()
            sr_cfg = int(audio_engine.get_effective_sample_rate()
                         if hasattr(audio_engine, 'get_effective_sample_rate') else 48000)
            input_monitor.configure(sample_rate=sr_cfg, buffer_size=512)
            log.info("InputMonitor bereit (SR=%d)", sr_cfg)
        except Exception as exc:
            log.warning("InputMonitor nicht verfügbar: %s", exc)
            input_monitor = None

        # v0.0.20.798 P5A: Git Integration Service
        _progress("Git + Review initialisieren...", 0.30)
        git_service = None
        try:
            from pydaw.services.git_integration_service import GitIntegrationService
            git_service = GitIntegrationService()
            pp = getattr(project, 'project_path', None)
            if pp:
                git_service.set_project_root(pp)
            log.info("GitIntegrationService initialized")
        except Exception as exc:
            log.warning("GitIntegrationService not available: %s", exc)

        # v0.0.20.798 P5A: Review Service
        review_service = None
        try:
            from pydaw.services.review_service import ReviewService
            review_service = ReviewService(project_service=project)
            log.info("ReviewService initialized")
        except Exception as exc:
            log.warning("ReviewService not available: %s", exc)

        # v0.0.20.798 P6A: Python Scripting Service
        _progress("Scripting + Collab initialisieren...", 0.35)
        scripting_service = None
        try:
            from pydaw.services.scripting_service import ScriptingService
            scripting_service = ScriptingService(
                project_service=project,
                transport_service=transport,
            )
            log.info("ScriptingService initialized")
        except Exception as exc:
            log.warning("ScriptingService not available: %s", exc)

        # v0.0.20.910 C2C.4: Collab Server + Client (lazy — created but not started)
        collab_srv = None
        collab_cli = None
        try:
            from pydaw.services.collab_service import CollabServer, CollabClient
            collab_srv = CollabServer(project_service=project)
            collab_cli = CollabClient()
            log.info("CollabServer + CollabClient initialized (idle)")
        except Exception as exc:
            log.warning("Collab services not available: %s", exc)

        return cls(
            threadpool=threadpool,
            project=project,
            audio_engine=audio_engine,
            transport=transport,
            launcher=launcher,
            metronome=metronome,
            midi=midi,
            midi_mapping=midi_mapping,
            jack=jack,
            automation_playback=automation_playback,
            automation_manager=automation_manager,
            recording=recording,
            take=take_service,
            fluidsynth=fluidsynth,
            prewarm=prewarm,
            clip_context=clip_context,
            project_tabs=project_tabs,
            editor_timeline=editor_timeline,
            input_monitor=input_monitor,
            git=git_service,
            review=review_service,
            scripting=scripting_service,
            collab_server=collab_srv,
            collab_client=collab_cli,
        )


    def shutdown(self) -> None:
        """Best-effort shutdown for background audio/jack/transport resources."""
        # v0.0.20.757: InputMonitor stoppen
        try:
            if getattr(self, 'input_monitor', None) is not None:
                self.input_monitor.stop()
        except Exception:
            pass
        # v0.0.20.612: EditorTimelineAdapter aufräumen
        try:
            if self.editor_timeline is not None:
                self.editor_timeline.shutdown()
        except Exception:
            pass
        # Stop recording if active
        try:
            if self.recording.is_recording():
                self.recording.stop_recording()
            self.recording.cleanup()
        except Exception:
            pass
        # Cleanup FluidSynth
        try:
            self.fluidsynth.cleanup()
        except Exception:
            pass
        # v0.0.20.910 C2C.4: Stop collab server/client
        try:
            if getattr(self, 'collab_server', None) is not None:
                self.collab_server.stop()
        except Exception:
            pass
        try:
            if getattr(self, 'collab_client', None) is not None:
                self.collab_client.disconnect()
        except Exception:
            pass
        # Stop transport timer first (it can trigger callbacks into other services).
        try:
            self.transport.stop()
        except Exception:
            pass
        # Stop launcher watchers.
        try:
            self.launcher.stop()
        except Exception:
            pass
        # Stop JACK client thread (if enabled).
        try:
            self.jack.stop()
        except Exception:
            pass
        # Stop audio engine stream.
        try:
            self.audio_engine.shutdown_instruments()
        except Exception:
            pass
        try:
            self.audio_engine.stop()
        except Exception:
            pass
        # Stop background workers.
        try:
            self.threadpool.shutdown()
        except Exception:
            pass