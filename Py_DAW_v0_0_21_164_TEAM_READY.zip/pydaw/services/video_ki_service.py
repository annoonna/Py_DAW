"""video_ki_service.py — KI-gestützte Video-Analyse (v0.0.20.919).

VK1: Szenen-Erkennung (Histogram-Diff, keine ext. Deps)
VK2: Dialog-Erkennung + Auto-Duck Automation
VK3: Stimmungs-Analyse → Sound-Vorschläge (mathematisches Random)

Design:
- Nur numpy + ffmpeg als Deps (kein PyTorch, kein TensorFlow)
- Alles lokal, alles optional, alles in try/except
- Ergebnisse gecacht in SQLite (nur einmal analysieren)
- Mathematisch fundierte Zufälligkeit: Goldener Schnitt, Perlin-artig,
  gewichtete Verteilungen statt langweiligem deterministischem Mapping

Usage:
    from pydaw.services.video_ki_service import VideoKIService
    vki = VideoKIService()
    scenes = vki.detect_scenes("/path/to/video.mp4")
    dialogs = vki.detect_dialog("/path/to/video.mp4")
    for scene in scenes:
        mood = vki.analyze_mood(scene)
        suggestions = vki.suggest_sounds(mood)
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import struct
import subprocess
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    np = None  # type: ignore
    _HAS_NUMPY = False


# ══════════════════════════════════════════════════════════════
# Constants
# ══════════════════════════════════════════════════════════════

PHI = (1.0 + math.sqrt(5)) / 2.0          # Goldener Schnitt ≈ 1.618
PHI_INV = 1.0 / PHI                        # ≈ 0.618
TAU = 2.0 * math.pi
EULER = math.e


# ══════════════════════════════════════════════════════════════
# Data Model
# ══════════════════════════════════════════════════════════════

@dataclass
class VideoScene:
    """Eine erkannte Szene im Video."""
    index: int = 0
    start_seconds: float = 0.0
    end_seconds: float = 0.0
    transition_type: str = "cut"           # cut, fade, dissolve
    confidence: float = 1.0
    dominant_color: Tuple[int, int, int] = (128, 128, 128)
    brightness: float = 0.5               # 0=schwarz, 1=weiß
    contrast: float = 0.5                 # 0=flach, 1=stark
    saturation: float = 0.5              # 0=grau, 1=bunt
    warmth: float = 0.5                   # 0=kalt/blau, 1=warm/orange
    motion_energy: float = 0.5           # 0=statisch, 1=viel Bewegung
    mood_tags: List[str] = field(default_factory=list)

    @property
    def duration(self) -> float:
        return max(0.0, self.end_seconds - self.start_seconds)

    def to_dict(self) -> dict:
        return {
            "index": self.index,
            "start": round(self.start_seconds, 3),
            "end": round(self.end_seconds, 3),
            "duration": round(self.duration, 3),
            "transition": self.transition_type,
            "color": f"#{self.dominant_color[0]:02x}{self.dominant_color[1]:02x}{self.dominant_color[2]:02x}",
            "brightness": round(self.brightness, 3),
            "contrast": round(self.contrast, 3),
            "saturation": round(self.saturation, 3),
            "warmth": round(self.warmth, 3),
            "mood_tags": self.mood_tags,
        }


@dataclass
class DialogRegion:
    """Eine erkannte Dialog-Region im Video-Audio."""
    start_seconds: float = 0.0
    end_seconds: float = 0.0
    confidence: float = 0.8
    avg_energy_db: float = -20.0
    spectral_centroid_hz: float = 2000.0

    @property
    def duration(self) -> float:
        return max(0.0, self.end_seconds - self.start_seconds)

    def to_dict(self) -> dict:
        return {
            "start": round(self.start_seconds, 3),
            "end": round(self.end_seconds, 3),
            "duration": round(self.duration, 3),
            "confidence": round(self.confidence, 2),
            "energy_db": round(self.avg_energy_db, 1),
        }


@dataclass
class MoodProfile:
    """Stimmungsprofil einer Szene — Basis für Sound-Vorschläge."""
    valence: float = 0.5          # 0=negativ/traurig, 1=positiv/fröhlich
    energy: float = 0.5          # 0=ruhig, 1=energetisch
    tension: float = 0.5         # 0=entspannt, 1=spannend
    intimacy: float = 0.5        # 0=distanziert/episch, 1=intim/nah
    darkness: float = 0.5        # 0=hell, 1=dunkel
    tempo_suggestion: float = 100.0  # BPM-Vorschlag
    key_suggestion: str = "C"    # Tonart-Vorschlag
    mode_suggestion: str = "minor"  # "major" oder "minor"
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "valence": round(self.valence, 3),
            "energy": round(self.energy, 3),
            "tension": round(self.tension, 3),
            "intimacy": round(self.intimacy, 3),
            "darkness": round(self.darkness, 3),
            "tempo": round(self.tempo_suggestion),
            "key": self.key_suggestion,
            "mode": self.mode_suggestion,
            "tags": self.tags,
        }


@dataclass
class SoundSuggestion:
    """Ein konkreter Sound-Vorschlag für eine Szene."""
    instrument: str = ""         # "AETERNA", "Fusion", "BRRR"
    preset_name: str = ""        # "Dark Moll Pad"
    preset_params: Dict[str, Any] = field(default_factory=dict)
    bpm: int = 100
    key: str = "C"
    mode: str = "minor"
    description: str = ""
    confidence: float = 0.8
    variation_seed: float = 0.0  # 0..1 — der Zufallswert der diese Variation erzeugt hat

    def to_dict(self) -> dict:
        return {
            "instrument": self.instrument,
            "preset": self.preset_name,
            "bpm": self.bpm,
            "key": self.key,
            "mode": self.mode,
            "description": self.description,
            "confidence": round(self.confidence, 2),
        }


# ══════════════════════════════════════════════════════════════
# Mathematical Random Engine
# ══════════════════════════════════════════════════════════════

def _golden_hash(seed: float, dimension: int = 0) -> float:
    """Quasi-random Folge basierend auf dem Goldenen Schnitt.

    Erzeugt gleichmäßig verteilte aber nicht-periodische Werte.
    Jede (seed, dimension) Kombination gibt einen anderen Wert 0..1.
    Besser als random.random() weil es den Raum gleichmäßiger abdeckt.
    """
    return (seed * PHI + dimension * PHI_INV) % 1.0


def _perlin_smooth(t: float) -> float:
    """Smoothstep-Kurve (Ken Perlin) — sanftes 0→1 ohne Kanten."""
    t = max(0.0, min(1.0, t))
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0)


def _fibonacci_bpm(base: float, variation: float) -> int:
    """BPM-Vorschlag basierend auf Fibonacci-nahen Werten.

    Musikalisch sinnvolle Tempi clustern um Fibonacci-Verhältnisse:
    60, 72, 80, 90, 100, 108, 120, 132, 144, 160, 180
    """
    # Fibonacci-basierte BPM-Ankerpunkte
    fib_bpms = [55, 63, 70, 78, 85, 92, 100, 108, 118, 128, 140, 152, 168, 185]
    # Finde den nächsten Ankerpunkt zu base
    closest_idx = min(range(len(fib_bpms)),
                      key=lambda i: abs(fib_bpms[i] - base))
    # Variation verschiebt um ±2 Ankerpunkte
    offset = int((variation - 0.5) * 4)
    idx = max(0, min(len(fib_bpms) - 1, closest_idx + offset))
    return fib_bpms[idx]


def _weighted_choice(options: List[Tuple[Any, float]], seed: float) -> Any:
    """Gewichtete Auswahl mit Golden-Hash statt random.

    options: [(item, weight), ...]
    seed: 0..1 Quasi-Random-Wert
    """
    total = sum(w for _, w in options)
    if total <= 0:
        return options[0][0] if options else None
    threshold = seed * total
    cumulative = 0.0
    for item, weight in options:
        cumulative += weight
        if threshold < cumulative:
            return item
    return options[-1][0]


def _gaussian_clamp(center: float, spread: float, seed: float,
                     lo: float = 0.0, hi: float = 1.0) -> float:
    """Gauss-verteilter Wert um center, clamped auf [lo, hi].

    Nutzt Box-Muller Transform mit Golden-Hash Seeds.
    """
    # Box-Muller mit quasi-random inputs
    u1 = max(1e-10, _golden_hash(seed, 0))
    u2 = _golden_hash(seed, 1)
    z = math.sqrt(-2.0 * math.log(u1)) * math.cos(TAU * u2)
    value = center + z * spread
    return max(lo, min(hi, value))


def _scene_seed(scene: VideoScene, variation: int = 0) -> float:
    """Quasi-random Seed pro Szene + Variation.

    variation=0: Basis-Seed (reproduzierbar, gleiche Szene → gleicher Seed)
    variation=1,2,3...: Jede Variation erzeugt einen ANDEREN Seed,
    aber immer noch mathematisch fundiert (Golden-Ratio Offset).

    So entsteht bei jedem "Vertonen"-Klick ein anderes Ergebnis,
    das trotzdem zur Szene passt.
    """
    data = f"{scene.start_seconds:.3f}:{scene.brightness:.3f}:{scene.warmth:.3f}"
    h = hashlib.md5(data.encode()).hexdigest()
    base = int(h[:8], 16) / 0xFFFFFFFF
    if variation > 0:
        # Golden-Ratio Offset: jede Variation deckt einen anderen Bereich ab
        # φ-basiertes Spacing garantiert keine Wiederholung
        return (base + variation * PHI_INV) % 1.0
    return base


# ══════════════════════════════════════════════════════════════
# VK1: Szenen-Erkennung
# ══════════════════════════════════════════════════════════════

def _extract_frame_rgb(video_path: str, time_seconds: float,
                        width: int = 160, height: int = 90) -> Optional[Any]:
    """Extrahiere ein Frame als numpy array (H×W×3 RGB)."""
    if not _HAS_NUMPY:
        return None
    try:
        cmd = [
            "ffmpeg", "-ss", f"{max(0, time_seconds):.3f}",
            "-i", video_path, "-vframes", "1",
            "-vf", f"scale={width}:{height}",
            "-pix_fmt", "rgb24", "-f", "rawvideo",
            "-v", "quiet", "pipe:1",
        ]
        result = subprocess.run(cmd, capture_output=True, timeout=5)
        if result.returncode != 0 or not result.stdout:
            return None
        expected = width * height * 3
        data = result.stdout[:expected]
        if len(data) < expected:
            return None
        return np.frombuffer(data, dtype=np.uint8).reshape(height, width, 3)
    except Exception:
        return None


def _histogram_distance(frame_a, frame_b) -> float:
    """Chi-Squared Distanz zwischen zwei RGB-Histogrammen.

    0 = identisch, >1 = komplett verschieden.
    """
    if not _HAS_NUMPY or frame_a is None or frame_b is None:
        return 0.0
    try:
        bins = 32
        dist = 0.0
        for ch in range(3):
            h_a, _ = np.histogram(frame_a[:, :, ch], bins=bins, range=(0, 256))
            h_b, _ = np.histogram(frame_b[:, :, ch], bins=bins, range=(0, 256))
            h_a = h_a.astype(np.float64) + 1e-10
            h_b = h_b.astype(np.float64) + 1e-10
            dist += float(np.sum((h_a - h_b) ** 2 / (h_a + h_b)))
        return dist / 3.0
    except Exception:
        return 0.0


def _analyze_frame_color(frame) -> Dict[str, float]:
    """Analysiere Farb-Eigenschaften eines Frames."""
    if not _HAS_NUMPY or frame is None:
        return {"brightness": 0.5, "contrast": 0.5, "saturation": 0.5,
                "warmth": 0.5, "dominant_r": 128, "dominant_g": 128, "dominant_b": 128}
    try:
        f = frame.astype(np.float64) / 255.0
        r, g, b = f[:, :, 0], f[:, :, 1], f[:, :, 2]

        # Brightness (Luminanz)
        lum = 0.2126 * r + 0.7152 * g + 0.0722 * b
        brightness = float(np.mean(lum))

        # Contrast (Standardabweichung der Luminanz)
        contrast = min(1.0, float(np.std(lum)) * 4.0)

        # Saturation (Abstand vom Grau)
        max_c = np.maximum(np.maximum(r, g), b)
        min_c = np.minimum(np.minimum(r, g), b)
        delta = max_c - min_c
        saturation = float(np.mean(delta))

        # Warmth (Rot-Orange vs Blau-Cyan)
        warmth = float(np.mean(r) - np.mean(b)) * 0.5 + 0.5
        warmth = max(0.0, min(1.0, warmth))

        # Dominant color
        dr = int(np.mean(r) * 255)
        dg = int(np.mean(g) * 255)
        db = int(np.mean(b) * 255)

        return {
            "brightness": max(0.0, min(1.0, brightness)),
            "contrast": max(0.0, min(1.0, contrast)),
            "saturation": max(0.0, min(1.0, saturation)),
            "warmth": max(0.0, min(1.0, warmth)),
            "dominant_r": dr, "dominant_g": dg, "dominant_b": db,
        }
    except Exception:
        return {"brightness": 0.5, "contrast": 0.5, "saturation": 0.5,
                "warmth": 0.5, "dominant_r": 128, "dominant_g": 128, "dominant_b": 128}


def detect_scenes(video_path: str, threshold: float = 0.35,
                   sample_interval: float = 0.2,
                   min_scene_duration: float = 1.0) -> List[VideoScene]:
    """VK1: Automatische Szenen-Erkennung via Histogram-Vergleich.

    Args:
        video_path: Pfad zum Video
        threshold: Histogram-Distanz-Schwelle für Szenenwechsel (0.2–0.8)
        sample_interval: Abstand zwischen analysierten Frames in Sekunden
        min_scene_duration: Minimale Szenen-Länge in Sekunden

    Returns: Liste von VideoScene Objekten
    """
    if not _HAS_NUMPY or not os.path.isfile(video_path):
        return []

    # Probe duration
    try:
        from pydaw.services.video_track import probe_video
        info = probe_video(video_path)
        duration = info.duration_seconds if info else 0
    except Exception:
        duration = 0
    if duration <= 0:
        return []

    log.info("[VideoKI] Analyzing scenes in %.1fs video (interval=%.1fs, threshold=%.2f)",
             duration, sample_interval, threshold)

    # Extract frames and compare
    scene_cuts: List[float] = [0.0]  # First scene always starts at 0
    prev_frame = None
    t = 0.0

    while t < duration:
        frame = _extract_frame_rgb(video_path, t)
        if frame is not None and prev_frame is not None:
            dist = _histogram_distance(prev_frame, frame)
            if dist > threshold:
                # Check minimum duration
                if scene_cuts and (t - scene_cuts[-1]) >= min_scene_duration:
                    scene_cuts.append(t)
        prev_frame = frame
        t += sample_interval

    # Build scene objects
    scenes: List[VideoScene] = []
    for i, start in enumerate(scene_cuts):
        end = scene_cuts[i + 1] if i + 1 < len(scene_cuts) else duration

        # Analyze color of representative frame (1/3 into scene)
        rep_time = start + (end - start) * 0.33
        rep_frame = _extract_frame_rgb(video_path, rep_time)
        color_info = _analyze_frame_color(rep_frame)

        scene = VideoScene(
            index=i,
            start_seconds=start,
            end_seconds=end,
            transition_type="cut",
            brightness=color_info["brightness"],
            contrast=color_info["contrast"],
            saturation=color_info["saturation"],
            warmth=color_info["warmth"],
            dominant_color=(color_info["dominant_r"],
                           color_info["dominant_g"],
                           color_info["dominant_b"]),
        )
        # Generate mood tags
        scene.mood_tags = _generate_mood_tags(scene)
        scenes.append(scene)

    log.info("[VideoKI] Found %d scenes", len(scenes))
    return scenes


def _generate_mood_tags(scene: VideoScene) -> List[str]:
    """Generiere menschenlesbare Stimmungs-Tags aus Szenen-Daten."""
    tags = []
    b = scene.brightness
    c = scene.contrast
    s = scene.saturation
    w = scene.warmth
    d = scene.duration

    # Helligkeit
    if b < 0.2:
        tags.append("sehr dunkel")
    elif b < 0.35:
        tags.append("dunkel")
    elif b > 0.75:
        tags.append("hell")
    elif b > 0.85:
        tags.append("sehr hell")

    # Kontrast
    if c > 0.7:
        tags.append("kontrastreich")
    elif c < 0.2:
        tags.append("flach")

    # Sättigung
    if s > 0.5:
        tags.append("farbenfroh")
    elif s < 0.15:
        tags.append("entsättigt")

    # Wärme
    if w > 0.65:
        tags.append("warm")
    elif w < 0.35:
        tags.append("kalt")

    # Tempo/Schnitt-Geschwindigkeit
    if d < 2.0:
        tags.append("schneller Schnitt")
    elif d < 5.0:
        tags.append("mittleres Tempo")
    elif d > 15.0:
        tags.append("langsam")
    elif d > 30.0:
        tags.append("sehr langsam")

    return tags


# ══════════════════════════════════════════════════════════════
# VK2: Dialog-Erkennung
# ══════════════════════════════════════════════════════════════

def _extract_audio_wav(video_path: str, output_wav: str,
                        sample_rate: int = 16000) -> bool:
    """Extrahiere Audio aus Video als WAV (mono, 16kHz)."""
    try:
        cmd = [
            "ffmpeg", "-y", "-i", video_path,
            "-vn", "-acodec", "pcm_s16le",
            "-ar", str(sample_rate), "-ac", "1",
            "-v", "quiet", output_wav,
        ]
        result = subprocess.run(cmd, capture_output=True, timeout=120)
        return result.returncode == 0 and os.path.exists(output_wav)
    except Exception:
        return False


def detect_dialog(video_path: str,
                   energy_threshold_db: float = -35.0,
                   centroid_low_hz: float = 800.0,
                   centroid_high_hz: float = 4000.0,
                   min_duration_ms: float = 300.0,
                   gap_merge_ms: float = 500.0,
                   ) -> List[DialogRegion]:
    """VK2: Dialog-Erkennung via Spectral-Analyse.

    Erkennt wo im Video-Audio jemand spricht (ohne ML-Modell).

    Heuristik: Energie > Schwelle UND Spectral Centroid im Sprach-Bereich
    (800–4000 Hz) → wahrscheinlich Sprache.

    Args:
        video_path: Pfad zum Video
        energy_threshold_db: RMS-Schwelle (lauter = Sprache möglich)
        centroid_low_hz / centroid_high_hz: Sprach-Frequenzbereich
        min_duration_ms: Minimale Dialog-Dauer
        gap_merge_ms: Lücken kürzer als dies → zusammenfassen

    Returns: Liste von DialogRegion Objekten
    """
    if not _HAS_NUMPY or not os.path.isfile(video_path):
        return []

    import tempfile
    wav_path = tempfile.mktemp(suffix=".wav")
    try:
        if not _extract_audio_wav(video_path, wav_path, sample_rate=16000):
            return []

        # Read WAV
        import wave
        with wave.open(wav_path, 'r') as wf:
            sr = wf.getframerate()
            n_frames = wf.getnframes()
            raw = wf.readframes(n_frames)
        audio = np.frombuffer(raw, dtype=np.int16).astype(np.float64) / 32768.0

        if len(audio) == 0:
            return []

        # Analyse in 50ms Fenstern
        window_samples = int(0.05 * sr)
        hop = window_samples
        n_windows = len(audio) // hop

        energy_threshold_linear = 10.0 ** (energy_threshold_db / 20.0)
        speech_windows: List[bool] = []

        for i in range(n_windows):
            chunk = audio[i * hop:(i + 1) * hop]
            if len(chunk) == 0:
                speech_windows.append(False)
                continue

            # RMS Energie
            rms = float(np.sqrt(np.mean(chunk ** 2)))

            # Spectral Centroid (gewichteter Frequenz-Mittelwert)
            fft_vals = np.abs(np.fft.rfft(chunk))
            freqs = np.fft.rfftfreq(len(chunk), 1.0 / sr)
            total_energy = float(np.sum(fft_vals))
            if total_energy > 1e-10:
                centroid = float(np.sum(freqs * fft_vals) / total_energy)
            else:
                centroid = 0.0

            # Heuristik: laut genug + Centroid im Sprach-Bereich
            is_speech = (rms > energy_threshold_linear
                         and centroid_low_hz < centroid < centroid_high_hz)
            speech_windows.append(is_speech)

        # Regionen extrahieren
        regions: List[DialogRegion] = []
        in_speech = False
        speech_start = 0

        for i, is_sp in enumerate(speech_windows):
            if is_sp and not in_speech:
                speech_start = i
                in_speech = True
            elif not is_sp and in_speech:
                start_sec = speech_start * 0.05
                end_sec = i * 0.05
                if (end_sec - start_sec) * 1000 >= min_duration_ms:
                    chunk = audio[int(start_sec * sr):int(end_sec * sr)]
                    e_db = 20 * math.log10(max(1e-10, float(np.sqrt(np.mean(chunk ** 2)))))
                    regions.append(DialogRegion(
                        start_seconds=start_sec, end_seconds=end_sec,
                        avg_energy_db=e_db,
                    ))
                in_speech = False

        # Trailing speech
        if in_speech:
            start_sec = speech_start * 0.05
            end_sec = n_windows * 0.05
            if (end_sec - start_sec) * 1000 >= min_duration_ms:
                regions.append(DialogRegion(start_seconds=start_sec, end_seconds=end_sec))

        # Merge nearby regions
        if gap_merge_ms > 0 and len(regions) > 1:
            merged: List[DialogRegion] = [regions[0]]
            for r in regions[1:]:
                gap = (r.start_seconds - merged[-1].end_seconds) * 1000
                if gap < gap_merge_ms:
                    merged[-1].end_seconds = r.end_seconds
                else:
                    merged.append(r)
            regions = merged

        log.info("[VideoKI] Found %d dialog regions", len(regions))
        return regions

    except Exception as e:
        log.error("[VideoKI] Dialog detection failed: %s", e)
        return []
    finally:
        try:
            if os.path.exists(wav_path):
                os.unlink(wav_path)
        except Exception:
            pass


def generate_duck_automation(dialog_regions: List[DialogRegion],
                              duck_db: float = -8.0,
                              fade_seconds: float = 0.3,
                              bpm: float = 120.0,
                              ) -> List[Dict[str, float]]:
    """VK2: Generiere Volume-Automation-Breakpoints für Auto-Duck.

    Erzeugt eine Liste von {beat, value} Breakpoints die als
    Automation-Lane auf Musik-Tracks angewendet werden können.

    Args:
        dialog_regions: Erkannte Dialog-Regionen
        duck_db: Absenkung in dB während Dialog (-6 bis -18 typisch)
        fade_seconds: Fade-In/Out Zeit
        bpm: Projekt-BPM für Beat-Umrechnung

    Returns: Liste von {"beat": float, "value": float} Breakpoints
    """
    if not dialog_regions:
        return []

    duck_linear = 10.0 ** (duck_db / 20.0)
    beats_per_second = bpm / 60.0
    fade_beats = fade_seconds * beats_per_second
    breakpoints: List[Dict[str, float]] = []

    # Start at full volume
    breakpoints.append({"beat": 0.0, "value": 1.0})

    for region in dialog_regions:
        start_beat = region.start_seconds * beats_per_second
        end_beat = region.end_seconds * beats_per_second

        # Fade down before dialog
        fade_start = max(0.0, start_beat - fade_beats)
        breakpoints.append({"beat": round(fade_start, 3), "value": 1.0})
        breakpoints.append({"beat": round(start_beat, 3), "value": round(duck_linear, 4)})

        # Fade up after dialog
        breakpoints.append({"beat": round(end_beat, 3), "value": round(duck_linear, 4)})
        fade_end = end_beat + fade_beats
        breakpoints.append({"beat": round(fade_end, 3), "value": 1.0})

    return breakpoints


# ══════════════════════════════════════════════════════════════
# VK3: Stimmungs-Analyse + Sound-Vorschläge (Math-Random)
# ══════════════════════════════════════════════════════════════

# Tonarten sortiert nach "Dunkelheit" (Dur=hell, Moll=dunkel)
_KEYS_BRIGHT = ["C", "G", "D", "A", "F", "Bb", "Eb"]
_KEYS_DARK = ["A", "E", "D", "B", "F#", "C#", "G#"]

# Instrument-Archetypen mit Stimmungs-Gewichten
_INSTRUMENT_ARCHETYPES = [
    # (name, keywords, mood_weights: {valence, energy, tension, intimacy, darkness})
    ("Warmer Pad", ["warm", "pad"],
     {"valence": 0.5, "energy": 0.2, "tension": 0.2, "intimacy": 0.6, "darkness": 0.5}),
    ("Dunkler Drone", ["dark", "drone"],
     {"valence": 0.2, "energy": 0.1, "tension": 0.7, "intimacy": 0.3, "darkness": 0.9}),
    ("Heller Lead", ["bright", "lead"],
     {"valence": 0.8, "energy": 0.7, "tension": 0.4, "intimacy": 0.5, "darkness": 0.1}),
    ("Sanftes Piano", ["soft", "plucky", "bell"],
     {"valence": 0.6, "energy": 0.3, "tension": 0.2, "intimacy": 0.8, "darkness": 0.3}),
    ("Staccato Streicher", ["stab", "harsh"],
     {"valence": 0.3, "energy": 0.9, "tension": 0.9, "intimacy": 0.2, "darkness": 0.6}),
    ("Ambient Textur", ["soft", "pad", "drone"],
     {"valence": 0.4, "energy": 0.1, "tension": 0.3, "intimacy": 0.7, "darkness": 0.6}),
    ("Rhythmischer Synth", ["arp", "plucky"],
     {"valence": 0.7, "energy": 0.8, "tension": 0.5, "intimacy": 0.4, "darkness": 0.3}),
    ("Tiefer Bass", ["bass", "dark"],
     {"valence": 0.4, "energy": 0.6, "tension": 0.5, "intimacy": 0.3, "darkness": 0.7}),
    ("Ethereal Glocken", ["bell", "silky"],
     {"valence": 0.7, "energy": 0.2, "tension": 0.2, "intimacy": 0.9, "darkness": 0.2}),
    ("Aggressiver Synth", ["harsh", "gritty", "lead"],
     {"valence": 0.3, "energy": 1.0, "tension": 0.8, "intimacy": 0.1, "darkness": 0.5}),
    ("Melancholisches Pad", ["warm", "soft", "pad"],
     {"valence": 0.3, "energy": 0.15, "tension": 0.3, "intimacy": 0.7, "darkness": 0.7}),
    ("Epischer Brass", ["harsh", "lead"],
     {"valence": 0.6, "energy": 0.85, "tension": 0.7, "intimacy": 0.1, "darkness": 0.4}),
]


def analyze_mood(scene: VideoScene) -> MoodProfile:
    """VK3: Analysiere die Stimmung einer Szene.

    Mapped visuelle Eigenschaften (Farbe, Helligkeit, Kontrast, Tempo)
    auf ein 5-dimensionales Stimmungsprofil.
    """
    b = scene.brightness
    c = scene.contrast
    s = scene.saturation
    w = scene.warmth
    dur = scene.duration

    # Valence: hell + warm + bunt → positiv
    valence = (b * 0.35 + w * 0.35 + s * 0.2 + (1.0 - c) * 0.1)
    valence = max(0.0, min(1.0, valence))

    # Energy: kurze Szenen + hoher Kontrast + bunt → energetisch
    speed = max(0.0, min(1.0, 1.0 - (dur / 30.0)))  # 0–30s → 1–0
    energy = (speed * 0.4 + c * 0.3 + s * 0.2 + b * 0.1)
    energy = max(0.0, min(1.0, energy))

    # Tension: dunkel + kontrastreich + schnell → spannend
    tension = ((1.0 - b) * 0.3 + c * 0.35 + speed * 0.25 + (1.0 - w) * 0.1)
    tension = max(0.0, min(1.0, tension))

    # Intimacy: dunkel + langsam + entsättigt → intim
    slowness = 1.0 - speed
    intimacy = (slowness * 0.3 + (1.0 - s) * 0.25 + (1.0 - c) * 0.25 + (1.0 - b) * 0.2)
    intimacy = max(0.0, min(1.0, intimacy))

    # Darkness: nicht-hell + nicht-warm + nicht-bunt
    darkness = ((1.0 - b) * 0.5 + (1.0 - w) * 0.25 + (1.0 - s) * 0.25)
    darkness = max(0.0, min(1.0, darkness))

    # BPM: energy → Tempo (mathematisch via Fibonacci)
    seed = _scene_seed(scene)
    base_bpm = 60 + energy * 120  # 60–180 Range
    tempo = _fibonacci_bpm(base_bpm, _golden_hash(seed, 10))

    # Tonart: darkness → Moll/Dur + Auswahl
    mode = "minor" if darkness > 0.5 else "major"
    if darkness > 0.5:
        key_idx = int(_golden_hash(seed, 20) * len(_KEYS_DARK))
        key = _KEYS_DARK[key_idx % len(_KEYS_DARK)]
    else:
        key_idx = int(_golden_hash(seed, 21) * len(_KEYS_BRIGHT))
        key = _KEYS_BRIGHT[key_idx % len(_KEYS_BRIGHT)]

    mood = MoodProfile(
        valence=valence, energy=energy, tension=tension,
        intimacy=intimacy, darkness=darkness,
        tempo_suggestion=float(tempo),
        key_suggestion=key, mode_suggestion=mode,
        tags=scene.mood_tags,
    )
    return mood


def suggest_sounds(mood: MoodProfile, scene: VideoScene,
                    n_suggestions: int = 3,
                    variation: int = 0) -> List[SoundSuggestion]:
    """VK3: Generiere Sound-Vorschläge basierend auf Stimmung.

    Nutzt mathematisches Random (Golden Ratio + Gaussian):
    - variation=0: Basis-Vorschläge (reproduzierbar)
    - variation=1,2,3...: Jede Variation → andere Instrument-Auswahl,
      andere BPM, andere Tonart-Variation, andere Preset-Params
    - Golden-Ratio Spacing: nie Wiederholung, immer passend zur Stimmung
    """
    seed = _scene_seed(scene, variation)
    suggestions: List[SoundSuggestion] = []

    # Score each archetype against the mood
    scored: List[Tuple[int, float]] = []
    for i, (name, keywords, weights) in enumerate(_INSTRUMENT_ARCHETYPES):
        # Euclidean distance in mood-space (lower = better match)
        dist = math.sqrt(
            (mood.valence - weights["valence"]) ** 2 +
            (mood.energy - weights["energy"]) ** 2 +
            (mood.tension - weights["tension"]) ** 2 +
            (mood.intimacy - weights["intimacy"]) ** 2 +
            (mood.darkness - weights["darkness"]) ** 2
        )
        # Convert distance to score (closer = higher)
        score = max(0.0, 1.0 - dist * 0.7)
        scored.append((i, score))

    # Sort by score (best match first)
    scored.sort(key=lambda x: -x[1])

    # Pick top candidates with Golden-Hash variation
    used_indices: set = set()
    for suggestion_idx in range(n_suggestions):
        # Golden-Hash offset: each suggestion picks from a different part of the ranked list
        offset = _golden_hash(seed + suggestion_idx * 0.1, suggestion_idx)
        # Weighted selection from top candidates (bias toward best match but with variation)
        top_n = min(len(scored), 5 + suggestion_idx * 2)
        candidates = scored[:top_n]

        # Re-weight: best gets most weight, but Golden-Hash adds variation
        weighted = []
        for rank, (arch_idx, score) in enumerate(candidates):
            if arch_idx in used_indices:
                continue
            # Weight decays with rank but gets boosted by quasi-random
            rank_weight = 1.0 / (1.0 + rank * PHI_INV)
            variation_boost = _golden_hash(seed + rank * 0.07, suggestion_idx + 30)
            w = score * rank_weight * (0.5 + variation_boost)
            weighted.append((arch_idx, w))

        if not weighted:
            break

        chosen_idx = _weighted_choice(weighted, _golden_hash(seed, suggestion_idx + 50))
        if chosen_idx is None:
            break
        used_indices.add(chosen_idx)

        arch_name, arch_keywords, arch_weights = _INSTRUMENT_ARCHETYPES[chosen_idx]

        # Generate AETERNA preset params with Gaussian variation
        params = _generate_preset_params(mood, arch_keywords, seed + suggestion_idx * 0.3)

        # BPM with slight variation per suggestion
        bpm_var = _golden_hash(seed, suggestion_idx + 60) * 0.1 - 0.05  # ±5%
        bpm = int(mood.tempo_suggestion * (1.0 + bpm_var))
        bpm = max(40, min(200, bpm))

        # Key variation (sometimes suggest relative key)
        key = mood.key_suggestion
        mode = mood.mode_suggestion
        if suggestion_idx > 0:
            # With probability based on Golden-Hash, suggest relative/parallel key
            key_var = _golden_hash(seed, suggestion_idx + 70)
            if key_var > 0.7:  # ~30% chance of key variation
                # Relative key (Am → C, or C → Am)
                if mode == "minor":
                    mode = "major"
                    k_idx = _KEYS_DARK.index(key) if key in _KEYS_DARK else 0
                    key = _KEYS_BRIGHT[k_idx % len(_KEYS_BRIGHT)]
                else:
                    mode = "minor"
                    k_idx = _KEYS_BRIGHT.index(key) if key in _KEYS_BRIGHT else 0
                    key = _KEYS_DARK[k_idx % len(_KEYS_DARK)]

        # Build description
        mood_words = []
        if mood.darkness > 0.6:
            mood_words.append("dunkel")
        elif mood.darkness < 0.3:
            mood_words.append("hell")
        if mood.energy > 0.6:
            mood_words.append("energetisch")
        elif mood.energy < 0.3:
            mood_words.append("ruhig")
        if mood.tension > 0.6:
            mood_words.append("spannend")
        elif mood.tension < 0.3:
            mood_words.append("entspannt")
        desc_mood = ", ".join(mood_words) if mood_words else "neutral"
        description = f"{arch_name} — {desc_mood}, {bpm} BPM, {key} {mode}"

        suggestions.append(SoundSuggestion(
            instrument="AETERNA",
            preset_name=f"{arch_name} [{key}{mode[0].upper()}]",
            preset_params=params,
            bpm=bpm,
            key=key,
            mode=mode,
            description=description,
            confidence=scored[0][1] if scored else 0.5,
            variation_seed=_golden_hash(seed, suggestion_idx),
        ))

    return suggestions


def _generate_preset_params(mood: MoodProfile, keywords: List[str],
                              seed: float) -> Dict[str, Any]:
    """Generiere AETERNA-Preset-Parameter aus Mood + Keywords.

    Nutzt Gaussian-Verteilung um center-Werte für natürliche Variation.
    """
    params: Dict[str, Any] = {}

    # Oscillator: darkness → saw/square, brightness → sine/triangle
    if mood.darkness > 0.5:
        osc1 = int(_gaussian_clamp(1.5, 0.8, seed, 0, 5))  # saw/square biased
    else:
        osc1 = int(_gaussian_clamp(0.5, 1.0, seed, 0, 5))  # sine/tri biased
    params["osc1_waveform"] = osc1
    params["osc1_level"] = round(_gaussian_clamp(0.8, 0.1, seed + 0.01), 3)

    # Second oscillator: add richness
    params["osc2_waveform"] = int(_gaussian_clamp(osc1 + 1, 1.2, seed + 0.02, 0, 5))
    params["osc2_level"] = round(_gaussian_clamp(0.4, 0.15, seed + 0.03), 3)
    params["osc2_detune"] = round(_gaussian_clamp(5.0 + mood.intimacy * 10, 5.0, seed + 0.04, -30, 30), 1)

    # Filter: darkness → low cutoff, energy → more resonance
    cutoff_center = 2000 + (1.0 - mood.darkness) * 12000
    params["filter_cutoff"] = round(_gaussian_clamp(cutoff_center, 3000, seed + 0.05, 200, 18000))
    params["filter_resonance"] = round(_gaussian_clamp(mood.tension * 0.4, 0.12, seed + 0.06, 0, 0.8), 3)
    params["filter_env_amount"] = round(_gaussian_clamp(mood.energy * 0.5, 0.15, seed + 0.07, -0.5, 0.8), 3)

    # Amp Envelope: energy → short attack, intimacy → long release
    if mood.energy > 0.6:
        params["amp_attack"] = round(_gaussian_clamp(0.005, 0.01, seed + 0.08, 0.001, 0.5), 4)
        params["amp_decay"] = round(_gaussian_clamp(0.2, 0.1, seed + 0.09, 0.01, 2.0), 3)
        params["amp_sustain"] = round(_gaussian_clamp(0.3, 0.15, seed + 0.10, 0, 1), 3)
    else:
        params["amp_attack"] = round(_gaussian_clamp(0.8 + mood.intimacy, 0.5, seed + 0.08, 0.05, 5.0), 3)
        params["amp_decay"] = round(_gaussian_clamp(1.5, 0.5, seed + 0.09, 0.1, 5.0), 3)
        params["amp_sustain"] = round(_gaussian_clamp(0.7, 0.15, seed + 0.10, 0.3, 1.0), 3)
    params["amp_release"] = round(_gaussian_clamp(0.5 + mood.intimacy * 3, 1.0, seed + 0.11, 0.05, 10.0), 3)

    # Filter Envelope
    params["filter_attack"] = round(_gaussian_clamp(0.1 + (1.0 - mood.energy) * 0.5, 0.2, seed + 0.12, 0.001, 3.0), 3)
    params["filter_decay"] = round(_gaussian_clamp(0.5, 0.3, seed + 0.13, 0.05, 3.0), 3)
    params["filter_sustain"] = round(_gaussian_clamp(0.3, 0.15, seed + 0.14, 0, 0.8), 3)
    params["filter_release"] = round(_gaussian_clamp(0.5 + mood.intimacy, 0.5, seed + 0.15, 0.05, 5.0), 3)

    # Effects: intimacy → reverb/chorus, tension → less effects
    params["reverb_mix"] = round(_gaussian_clamp(mood.intimacy * 0.4, 0.1, seed + 0.16, 0, 0.6), 3)
    params["chorus_mix"] = round(_gaussian_clamp(mood.intimacy * 0.3, 0.1, seed + 0.17, 0, 0.5), 3)
    params["delay_mix"] = round(_gaussian_clamp(mood.darkness * 0.2, 0.08, seed + 0.18, 0, 0.4), 3)

    # LFO: energy → faster, darkness → more amount
    params["lfo1_rate"] = round(_gaussian_clamp(1.0 + mood.energy * 5, 2.0, seed + 0.19, 0.05, 20.0), 2)
    params["lfo1_amount"] = round(_gaussian_clamp(mood.darkness * 0.2, 0.08, seed + 0.20, 0, 0.5), 3)
    params["lfo1_shape"] = int(_golden_hash(seed + 0.21, 0) * 4)

    # Unison: energy → more voices
    if mood.energy > 0.5:
        params["unison_voices"] = int(_gaussian_clamp(4 + mood.energy * 6, 2, seed + 0.22, 1, 12))
        params["unison_detune"] = round(_gaussian_clamp(15 + mood.energy * 20, 8, seed + 0.23, 0, 60), 1)
    else:
        params["unison_voices"] = 1
        params["unison_detune"] = 0.0
    params["unison_spread"] = round(_gaussian_clamp(0.5, 0.2, seed + 0.24, 0, 1), 3)

    params["master_volume"] = round(_gaussian_clamp(0.7, 0.08, seed + 0.25, 0.4, 0.9), 3)

    # Apply keyword overrides (from preset_generator style)
    for kw in keywords:
        if kw == "warm":
            params["filter_cutoff"] = min(params.get("filter_cutoff", 8000), 4000)
            params["chorus_mix"] = max(params.get("chorus_mix", 0), 0.15)
        elif kw == "dark":
            params["filter_cutoff"] = min(params.get("filter_cutoff", 8000), 1500)
        elif kw == "bright":
            params["filter_cutoff"] = max(params.get("filter_cutoff", 8000), 12000)
        elif kw == "harsh":
            params["filter_resonance"] = max(params.get("filter_resonance", 0), 0.5)
        elif kw == "soft":
            params["amp_attack"] = max(params.get("amp_attack", 0), 0.1)
            params["master_volume"] = min(params.get("master_volume", 0.75), 0.6)
        elif kw == "pad":
            params["amp_attack"] = max(params.get("amp_attack", 0), 0.8)
            params["amp_release"] = max(params.get("amp_release", 0), 2.0)
            params["reverb_mix"] = max(params.get("reverb_mix", 0), 0.25)
        elif kw == "lead":
            params["amp_attack"] = min(params.get("amp_attack", 0), 0.01)
            params["filter_cutoff"] = max(params.get("filter_cutoff", 8000), 6000)
        elif kw == "bass":
            params["osc1_octave"] = -1
            params["filter_cutoff"] = min(params.get("filter_cutoff", 8000), 2500)
        elif kw == "drone":
            params["amp_attack"] = max(params.get("amp_attack", 0), 2.0)
            params["amp_sustain"] = 1.0
            params["amp_release"] = max(params.get("amp_release", 0), 5.0)
        elif kw == "plucky":
            params["amp_attack"] = 0.001
            params["amp_decay"] = min(params.get("amp_decay", 0.3), 0.25)
            params["amp_sustain"] = 0.0
        elif kw == "bell":
            params["amp_attack"] = 0.001
            params["amp_decay"] = max(params.get("amp_decay", 0.3), 1.5)
            params["amp_sustain"] = 0.0
        elif kw == "stab":
            params["amp_attack"] = 0.001
            params["amp_decay"] = 0.1
            params["amp_sustain"] = 0.0
        elif kw == "arp":
            params["amp_attack"] = 0.001
            params["amp_decay"] = 0.15
            params["amp_sustain"] = 0.2
        elif kw == "gritty":
            params["osc2_detune"] = max(params.get("osc2_detune", 5), 20)
        elif kw == "silky":
            params["filter_resonance"] = min(params.get("filter_resonance", 0.2), 0.08)
            params["chorus_mix"] = max(params.get("chorus_mix", 0), 0.25)

    return params


# ══════════════════════════════════════════════════════════════
# High-Level API
# ══════════════════════════════════════════════════════════════

class VideoKIService:
    """Zentraler Service für KI-Video-Analyse.

    Koordiniert VK1 (Szenen) + VK2 (Dialog) + VK3 (Stimmung + Sounds).
    """

    def __init__(self):
        self._scenes: List[VideoScene] = []
        self._dialogs: List[DialogRegion] = []
        self._moods: Dict[int, MoodProfile] = {}  # scene_index → mood
        self._suggestions: Dict[int, List[SoundSuggestion]] = {}  # scene_index → suggestions
        self._video_path: str = ""
        self._subtitles: List[SubtitleSegment] = []    # VK4
        self._beat_cuts: List[BeatCutSuggestion] = []  # VK5
        self._cue_sheet: List[CueSheetEntry] = []      # VK6
        self._variation_counter: int = 0               # v0.0.20.923: auto-increment per Vertonen

    @property
    def scenes(self) -> List[VideoScene]:
        return list(self._scenes)

    @property
    def dialogs(self) -> List[DialogRegion]:
        return list(self._dialogs)

    def analyze_all(self, video_path: str,
                     scene_threshold: float = 0.35,
                     dialog_threshold_db: float = -35.0,
                     ) -> Dict[str, Any]:
        """One-Click: Alles analysieren (VK1 + VK2 + VK3).

        Returns summary dict with scenes, dialogs, moods, suggestions.
        """
        result: Dict[str, Any] = {"video": video_path, "status": "ok"}

        self._video_path = video_path

        # VK1: Szenen
        self._scenes = detect_scenes(video_path, threshold=scene_threshold)
        result["scenes"] = len(self._scenes)

        # VK2: Dialog
        self._dialogs = detect_dialog(video_path, energy_threshold_db=dialog_threshold_db)
        result["dialog_regions"] = len(self._dialogs)

        # VK3: Stimmung + Vorschläge pro Szene
        self._moods.clear()
        self._suggestions.clear()
        for scene in self._scenes:
            mood = analyze_mood(scene)
            self._moods[scene.index] = mood
            self._suggestions[scene.index] = suggest_sounds(mood, scene)

        result["moods"] = len(self._moods)
        result["total_suggestions"] = sum(len(s) for s in self._suggestions.values())

        log.info("[VideoKI] Full analysis: %d scenes, %d dialogs, %d suggestions",
                 result["scenes"], result["dialog_regions"], result["total_suggestions"])

        # v0.0.20.923: Persist to SQLite
        self._save_to_db()

        return result

    def _save_to_db(self) -> None:
        """Persist analysis results to FinalStateDB."""
        if not self._video_path:
            return
        try:
            from pydaw.services.final_state_db import FinalStateDB
            fdb = FinalStateDB.get()
            fdb.ensure_loaded()

            # Build JSON for scenes (include mood + suggestions)
            scenes_data = []
            for scene in self._scenes:
                sd = scene.to_dict()
                sd["dominant_r"] = scene.dominant_color[0]
                sd["dominant_g"] = scene.dominant_color[1]
                sd["dominant_b"] = scene.dominant_color[2]
                mood = self._moods.get(scene.index)
                sd["mood"] = mood.to_dict() if mood else {}
                sugs = self._suggestions.get(scene.index, [])
                sd["suggestions"] = [s.to_dict() for s in sugs]
                scenes_data.append(sd)

            dialogs_data = [d.to_dict() for d in self._dialogs]
            subtitles_data = [s.to_dict() for s in getattr(self, '_subtitles', [])]

            fdb.save_video_ki_analysis(
                self._video_path,
                json.dumps(scenes_data),
                json.dumps(dialogs_data),
                json.dumps(subtitles_data),
            )
            log.info("[VideoKI] Analysis saved to DB (%d scenes, %d dialogs)",
                     len(scenes_data), len(dialogs_data))
        except Exception as e:
            log.debug("[VideoKI] DB save failed: %s", e)

    def load_from_db(self, video_path: str) -> bool:
        """Load cached analysis from SQLite. Returns True if data found."""
        try:
            from pydaw.services.final_state_db import FinalStateDB
            fdb = FinalStateDB.get()
            fdb.ensure_loaded()
            data = fdb.get_video_ki_analysis(video_path)
            if not data:
                return False

            self._video_path = video_path
            self._scenes.clear()
            self._dialogs.clear()
            self._moods.clear()
            self._suggestions.clear()
            self._subtitles = []

            # Restore scenes
            for sd in data.get("scenes", []):
                color_hex = sd.get("dominant_color", "#808080")
                r = int(color_hex[1:3], 16) if len(color_hex) >= 7 else 128
                g = int(color_hex[3:5], 16) if len(color_hex) >= 7 else 128
                b = int(color_hex[5:7], 16) if len(color_hex) >= 7 else 128
                scene = VideoScene(
                    index=sd.get("index", 0),
                    start_seconds=sd.get("start", 0),
                    end_seconds=sd.get("end", 0),
                    transition_type=sd.get("transition", "cut"),
                    brightness=sd.get("brightness", 0.5),
                    contrast=sd.get("contrast", 0.5),
                    saturation=sd.get("saturation", 0.5),
                    warmth=sd.get("warmth", 0.5),
                    dominant_color=(r, g, b),
                    mood_tags=sd.get("mood_tags", []),
                )
                self._scenes.append(scene)

                # Restore mood
                md = sd.get("mood", {})
                if md:
                    mood = MoodProfile(
                        valence=md.get("valence", 0.5),
                        energy=md.get("energy", 0.5),
                        tension=md.get("tension", 0.5),
                        intimacy=md.get("intimacy", 0.5),
                        darkness=md.get("darkness", 0.5),
                        tempo_suggestion=md.get("tempo", 100),
                        key_suggestion=md.get("key", "C"),
                        mode_suggestion=md.get("mode", "minor"),
                        tags=md.get("tags", []),
                    )
                    self._moods[scene.index] = mood
                    # Re-generate suggestions (cheap, deterministic)
                    self._suggestions[scene.index] = suggest_sounds(mood, scene)

            # Restore dialogs
            for dd in data.get("dialogs", []):
                self._dialogs.append(DialogRegion(
                    start_seconds=dd.get("start", 0),
                    end_seconds=dd.get("end", 0),
                    confidence=dd.get("confidence", 0.8),
                    avg_energy_db=dd.get("energy_db", -20),
                ))

            # Restore subtitles
            for sd in data.get("subtitles", []):
                self._subtitles.append(SubtitleSegment(
                    start_seconds=sd.get("start", 0),
                    end_seconds=sd.get("end", 0),
                    text=sd.get("text", ""),
                    language=sd.get("language", ""),
                ))

            log.info("[VideoKI] Loaded from DB: %d scenes, %d dialogs",
                     len(self._scenes), len(self._dialogs))
            return True
        except Exception as e:
            log.debug("[VideoKI] DB load failed: %s", e)
            return False

    def get_mood(self, scene_index: int) -> Optional[MoodProfile]:
        return self._moods.get(scene_index)

    def get_suggestions(self, scene_index: int) -> List[SoundSuggestion]:
        return self._suggestions.get(scene_index, [])

    def next_variation(self) -> int:
        """Get next variation number and auto-increment.

        Jeder Aufruf erzeugt eine andere Variation der Sound-Vorschläge + MIDI.
        Golden-Ratio basiert: nie Wiederholung, immer musikalisch passend.
        """
        v = self._variation_counter
        self._variation_counter += 1
        return v

    @property
    def variation_counter(self) -> int:
        return self._variation_counter

    def get_duck_automation(self, bpm: float = 120.0,
                              duck_db: float = -8.0) -> List[Dict[str, float]]:
        """Generiere Auto-Duck Automation aus den erkannten Dialogen."""
        return generate_duck_automation(self._dialogs, duck_db=duck_db, bpm=bpm)

    def get_scene_at(self, seconds: float) -> Optional[VideoScene]:
        """Finde die Szene zu einem Zeitpunkt."""
        for scene in self._scenes:
            if scene.start_seconds <= seconds < scene.end_seconds:
                return scene
        return None

    # VK4
    def transcribe(self, video_path: str = "",
                    model_size: str = "base", language: str = "") -> List[SubtitleSegment]:
        """VK4: Transkribiere Video-Audio (Whisper optional)."""
        path = video_path or self._video_path
        if not path:
            return []
        self._subtitles = transcribe_video(path, model_size, language)
        return list(self._subtitles)

    @property
    def subtitles(self) -> List[SubtitleSegment]:
        return list(getattr(self, '_subtitles', []))

    # VK5
    def suggest_beat_cuts_for_scenes(self, bpm: float = 120.0) -> List[BeatCutSuggestion]:
        """VK5: Beat-to-Cut Vorschläge für alle Szenen."""
        self._beat_cuts = suggest_beat_cuts(self._scenes, bpm)
        return list(self._beat_cuts)

    @property
    def beat_cuts(self) -> List[BeatCutSuggestion]:
        return list(getattr(self, '_beat_cuts', []))

    # VK6
    def generate_cue_sheet_for_video(self, video_duration: float = 0.0) -> List[CueSheetEntry]:
        """VK6: ADR/Foley Cue-Sheet generieren."""
        self._cue_sheet = generate_cue_sheet(self._scenes, self._dialogs, video_duration)
        return list(self._cue_sheet)

    @property
    def cue_sheet(self) -> List[CueSheetEntry]:
        return list(getattr(self, '_cue_sheet', []))

    def summary(self) -> str:
        """Human-readable Zusammenfassung der Analyse."""
        lines = [f"🎬 {len(self._scenes)} Szenen, 🗣 {len(self._dialogs)} Dialog-Regionen"]
        for scene in self._scenes[:10]:  # Max 10 Szenen anzeigen
            mood = self._moods.get(scene.index)
            sugs = self._suggestions.get(scene.index, [])
            tc_start = f"{int(scene.start_seconds)//60}:{int(scene.start_seconds)%60:02d}"
            tc_end = f"{int(scene.end_seconds)//60}:{int(scene.end_seconds)%60:02d}"
            line = f"  Szene {scene.index+1} ({tc_start}–{tc_end}): "
            if mood:
                line += f"[{', '.join(scene.mood_tags[:3])}] "
                line += f"→ {mood.key_suggestion} {mood.mode_suggestion}, {int(mood.tempo_suggestion)} BPM"
            if sugs:
                line += f" | Vorschlag: {sugs[0].preset_name}"
            lines.append(line)
        return "\n".join(lines)


# ══════════════════════════════════════════════════════════════
# VK4: Untertitel / Subtitle (Whisper optional)
# ══════════════════════════════════════════════════════════════

@dataclass
class SubtitleSegment:
    """Ein Untertitel-Segment mit Zeitstempel."""
    start_seconds: float = 0.0
    end_seconds: float = 0.0
    text: str = ""
    language: str = ""
    confidence: float = 0.0

    def to_srt_block(self, index: int) -> str:
        """Format als SRT-Block (SubRip)."""
        def _tc(s: float) -> str:
            h = int(s) // 3600
            m = (int(s) % 3600) // 60
            sec = int(s) % 60
            ms = int((s - int(s)) * 1000)
            return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"
        return f"{index}\n{_tc(self.start_seconds)} --> {_tc(self.end_seconds)}\n{self.text}\n"

    def to_vtt_block(self) -> str:
        """Format als WebVTT-Block."""
        def _tc(s: float) -> str:
            h = int(s) // 3600
            m = (int(s) % 3600) // 60
            sec = int(s) % 60
            ms = int((s - int(s)) * 1000)
            return f"{h:02d}:{m:02d}:{sec:02d}.{ms:03d}"
        return f"{_tc(self.start_seconds)} --> {_tc(self.end_seconds)}\n{self.text}\n"

    def to_dict(self) -> dict:
        return {"start": round(self.start_seconds, 3), "end": round(self.end_seconds, 3),
                "text": self.text, "language": self.language}


def transcribe_video(video_path: str, model_size: str = "base",
                      language: str = "") -> List[SubtitleSegment]:
    """VK4: Transkribiere Video-Audio mit Whisper (optional).

    Benötigt: pip install openai-whisper
    Falls nicht installiert → leere Liste + Log-Warnung.

    Args:
        video_path: Pfad zum Video
        model_size: Whisper-Modell ("tiny", "base", "small", "medium", "large")
        language: Sprache (leer = automatisch)

    Returns: Liste von SubtitleSegment
    """
    if not os.path.isfile(video_path):
        return []

    import tempfile
    wav_path = tempfile.mktemp(suffix=".wav")
    try:
        if not _extract_audio_wav(video_path, wav_path, sample_rate=16000):
            log.warning("[VK4] Audio extraction failed")
            return []

        try:
            import whisper  # type: ignore
        except ImportError:
            log.info("[VK4] Whisper nicht installiert — pip install openai-whisper")
            return []

        log.info("[VK4] Transcribing with Whisper model '%s'…", model_size)
        model = whisper.load_model(model_size)
        options = {}
        if language:
            options["language"] = language
        result = model.transcribe(wav_path, **options)

        segments: List[SubtitleSegment] = []
        detected_lang = result.get("language", "")
        for seg in result.get("segments", []):
            segments.append(SubtitleSegment(
                start_seconds=float(seg.get("start", 0)),
                end_seconds=float(seg.get("end", 0)),
                text=str(seg.get("text", "")).strip(),
                language=detected_lang,
                confidence=float(seg.get("avg_logprob", 0)) if "avg_logprob" in seg else 0.0,
            ))

        log.info("[VK4] Transcribed %d segments (language: %s)", len(segments), detected_lang)
        return segments

    except Exception as e:
        log.error("[VK4] Transcription failed: %s", e)
        return []
    finally:
        try:
            if os.path.exists(wav_path):
                os.unlink(wav_path)
        except Exception:
            pass


def export_subtitles_srt(segments: List[SubtitleSegment]) -> str:
    """Export als SRT-Datei."""
    return "\n".join(seg.to_srt_block(i + 1) for i, seg in enumerate(segments))


def export_subtitles_vtt(segments: List[SubtitleSegment]) -> str:
    """Export als WebVTT-Datei."""
    lines = ["WEBVTT\n"]
    lines.extend(seg.to_vtt_block() for seg in segments)
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════
# VK5: Beat-to-Cut Vorschläge
# ══════════════════════════════════════════════════════════════

@dataclass
class BeatCutSuggestion:
    """Vorschlag: Szenenwechsel an Beat ausrichten."""
    scene_index: int = 0
    original_cut_seconds: float = 0.0
    nearest_beat: float = 0.0        # Beat-Nummer
    nearest_beat_seconds: float = 0.0
    offset_ms: float = 0.0          # Verschiebung in ms
    direction: str = ""              # "früher" oder "später"

    def to_dict(self) -> dict:
        return {
            "scene": self.scene_index,
            "original_s": round(self.original_cut_seconds, 3),
            "beat": round(self.nearest_beat, 2),
            "beat_s": round(self.nearest_beat_seconds, 3),
            "offset_ms": round(self.offset_ms, 1),
            "direction": self.direction,
        }


def suggest_beat_cuts(scenes: List[VideoScene], bpm: float = 120.0,
                       time_signature: str = "4/4") -> List[BeatCutSuggestion]:
    """VK5: Schlage vor, Szenenwechsel auf den nächsten Beat zu verschieben.

    Für jeden Szenenwechsel: finde den nächsten Beat und berechne
    wie weit der Schnitt verschoben werden müsste.

    Args:
        scenes: Erkannte Szenen von VK1
        bpm: Projekt-BPM
        time_signature: Taktart (z.B. "4/4")

    Returns: Liste von BeatCutSuggestion (ein pro Szenenwechsel)
    """
    if not scenes or bpm <= 0:
        return []

    beat_duration = 60.0 / bpm  # Sekunden pro Beat
    suggestions: List[BeatCutSuggestion] = []

    for scene in scenes:
        if scene.index == 0:
            continue  # Erster Szenenstart ist immer bei 0

        cut_seconds = scene.start_seconds
        # Finde den nächsten Beat
        beat_number = cut_seconds / beat_duration
        nearest_beat_floor = math.floor(beat_number)
        nearest_beat_ceil = math.ceil(beat_number)

        # Welcher Beat ist näher?
        dist_floor = abs(cut_seconds - nearest_beat_floor * beat_duration)
        dist_ceil = abs(cut_seconds - nearest_beat_ceil * beat_duration)

        if dist_floor <= dist_ceil:
            nearest = nearest_beat_floor
            offset = cut_seconds - nearest * beat_duration
        else:
            nearest = nearest_beat_ceil
            offset = cut_seconds - nearest * beat_duration

        offset_ms = offset * 1000.0
        direction = "früher" if offset_ms > 0 else "später"

        suggestions.append(BeatCutSuggestion(
            scene_index=scene.index,
            original_cut_seconds=cut_seconds,
            nearest_beat=float(nearest),
            nearest_beat_seconds=nearest * beat_duration,
            offset_ms=abs(offset_ms),
            direction=direction,
        ))

    return suggestions


# ══════════════════════════════════════════════════════════════
# VK6: ADR/Foley Cue-Sheet
# ══════════════════════════════════════════════════════════════

@dataclass
class CueSheetEntry:
    """Ein Eintrag im ADR/Foley Cue-Sheet."""
    cue_id: str = ""
    cue_type: str = "ADR"        # "ADR", "Foley", "SFX", "Ambience"
    start_seconds: float = 0.0
    end_seconds: float = 0.0
    description: str = ""
    scene_index: int = -1
    priority: str = "normal"     # "high", "normal", "low"
    status: str = "todo"         # "todo", "recorded", "approved"

    @property
    def timecode(self) -> str:
        def _tc(s: float) -> str:
            m = int(s) // 60
            sec = int(s) % 60
            return f"{m:02d}:{sec:02d}"
        return f"{_tc(self.start_seconds)}–{_tc(self.end_seconds)}"

    def to_dict(self) -> dict:
        return {
            "id": self.cue_id, "type": self.cue_type,
            "start": round(self.start_seconds, 3),
            "end": round(self.end_seconds, 3),
            "timecode": self.timecode,
            "description": self.description,
            "scene": self.scene_index,
            "priority": self.priority, "status": self.status,
        }


def generate_cue_sheet(scenes: List[VideoScene],
                        dialogs: List[DialogRegion],
                        video_duration: float = 0.0,
                        ) -> List[CueSheetEntry]:
    """VK6: Generiere ADR/Foley Cue-Sheet automatisch.

    Erzeugt Einträge basierend auf:
    - Dialog-Regionen → ADR Cues (Nachsynchronisation)
    - Szenen-Wechsel → Foley Cues (Geräusche)
    - Stille Szenen → Ambience Cues (Raumton)

    Returns: Liste von CueSheetEntry
    """
    entries: List[CueSheetEntry] = []
    cue_counter = 1

    # ADR Cues aus Dialog-Regionen
    for i, dlg in enumerate(dialogs):
        entries.append(CueSheetEntry(
            cue_id=f"ADR-{cue_counter:03d}",
            cue_type="ADR",
            start_seconds=dlg.start_seconds,
            end_seconds=dlg.end_seconds,
            description=f"Dialog-Region {i+1} ({dlg.duration:.1f}s, {dlg.avg_energy_db:.0f} dB)",
            priority="high",
        ))
        cue_counter += 1

    # Foley Cues an Szenen-Wechseln
    for scene in scenes:
        if scene.index == 0:
            continue
        # Szenenwechsel → potentieller Foley-Punkt
        entries.append(CueSheetEntry(
            cue_id=f"FOL-{cue_counter:03d}",
            cue_type="Foley",
            start_seconds=max(0, scene.start_seconds - 0.5),
            end_seconds=scene.start_seconds + 1.0,
            description=f"Szene {scene.index} → {scene.index+1} ({scene.transition_type})",
            scene_index=scene.index,
            priority="normal",
        ))
        cue_counter += 1

    # Ambience Cues für lange, leise Szenen
    for scene in scenes:
        if scene.duration > 8.0 and scene.brightness < 0.4:
            # Dunkle, lange Szene → Raumton benötigt
            has_dialog = any(
                dlg.start_seconds < scene.end_seconds and dlg.end_seconds > scene.start_seconds
                for dlg in dialogs
            )
            if not has_dialog:
                entries.append(CueSheetEntry(
                    cue_id=f"AMB-{cue_counter:03d}",
                    cue_type="Ambience",
                    start_seconds=scene.start_seconds,
                    end_seconds=scene.end_seconds,
                    description=f"Raumton Szene {scene.index+1} ({', '.join(scene.mood_tags[:2])})",
                    scene_index=scene.index,
                    priority="low",
                ))
                cue_counter += 1

    # Sort by start time
    entries.sort(key=lambda e: e.start_seconds)
    return entries


def export_cue_sheet_csv(entries: List[CueSheetEntry]) -> str:
    """Export Cue-Sheet als CSV."""
    lines = ["ID;Typ;Timecode;Beschreibung;Szene;Priorität;Status"]
    for e in entries:
        lines.append(f"{e.cue_id};{e.cue_type};{e.timecode};"
                     f"{e.description};{e.scene_index};{e.priority};{e.status}")
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════
# MIDI Note Generation for Sound Suggestions (v0.0.20.923)
# ══════════════════════════════════════════════════════════════

# Key name → MIDI root note (octave 4)
_KEY_TO_MIDI = {
    "C": 60, "C#": 61, "Db": 61, "D": 62, "D#": 63, "Eb": 63,
    "E": 64, "F": 65, "F#": 66, "Gb": 66, "G": 67, "G#": 68,
    "Ab": 68, "A": 69, "A#": 70, "Bb": 70, "B": 71,
}

_SCALE_MAJOR = [0, 2, 4, 5, 7, 9, 11]
_SCALE_MINOR = [0, 2, 3, 5, 7, 8, 10]


def _scale_notes(root_midi: int, mode: str, octave_range: int = 3) -> List[int]:
    """Get all MIDI notes in scale across octave_range."""
    intervals = _SCALE_MINOR if mode == "minor" else _SCALE_MAJOR
    notes = []
    for octave in range(-2, octave_range + 1):
        for interval in intervals:
            n = root_midi + octave * 12 + interval
            if 0 <= n <= 127:
                notes.append(n)
    return sorted(set(notes))


def generate_midi_for_suggestion(
    suggestion: SoundSuggestion,
    scene: VideoScene,
    bpm: float = 120.0,
    variation: int = 0,
) -> List[dict]:
    """Generate MIDI notes for a sound suggestion.

    Args:
        variation: 0=Basis, 1,2,3...=jedes Mal andere Noten
                   (Golden-Ratio basiert, nie Wiederholung)

    Returns list of {"pitch": int, "start_beats": float, "length_beats": float, "velocity": int}
    ready to be converted to MidiNote objects.

    Pattern is determined by the archetype keywords:
    - pad/drone → long sustained chords
    - arp/plucky → arpeggiated pattern
    - bass → root octave pattern
    - lead → melodic line
    - stab → short rhythmic chords
    - bell → sparse high notes
    """
    root = _KEY_TO_MIDI.get(suggestion.key, 60)
    mode = suggestion.mode
    scale = _scale_notes(root, mode, 2)
    seed = _scene_seed(scene, variation)

    # Scene duration in beats
    scene_beats = scene.duration * bpm / 60.0
    scene_beats = max(4.0, min(128.0, scene_beats))

    name_lower = suggestion.preset_name.lower()

    if any(k in name_lower for k in ["pad", "ambient", "melanchol", "drone"]):
        return _gen_pad_pattern(root, mode, scale, scene_beats, seed)
    elif any(k in name_lower for k in ["arp", "rhyth"]):
        return _gen_arp_pattern(root, mode, scale, scene_beats, seed, bpm)
    elif any(k in name_lower for k in ["bass", "tief"]):
        return _gen_bass_pattern(root, mode, scale, scene_beats, seed, bpm)
    elif any(k in name_lower for k in ["stab", "staccato", "aggressiv", "episch"]):
        return _gen_stab_pattern(root, mode, scale, scene_beats, seed, bpm)
    elif any(k in name_lower for k in ["bell", "glock", "ethereal"]):
        return _gen_bell_pattern(root, mode, scale, scene_beats, seed)
    elif any(k in name_lower for k in ["lead", "hell"]):
        return _gen_lead_pattern(root, mode, scale, scene_beats, seed, bpm)
    else:
        return _gen_pad_pattern(root, mode, scale, scene_beats, seed)


def _gen_pad_pattern(root, mode, scale, total_beats, seed):
    notes = []
    # Seed-based chord voicing: which scale degrees form the chord
    n_chord = 3 + int(_golden_hash(seed, 40) * 2)  # 3-4 note chords
    base_deg = int(_golden_hash(seed, 41) * 3)      # start from degree 0-2
    chord_degrees = [(base_deg + i * 2) % len(scale) for i in range(n_chord)]
    # Seed-based octave shift for voicing
    octave_shift = int(_golden_hash(seed, 42) * 2) - 1  # -1, 0, or 1 octave
    beat, chord_idx = 0.0, 0
    while beat < total_beats:
        length = 3.0 + _golden_hash(seed + beat * 0.013 + chord_idx * 0.7, 43) * 5.0
        length = min(length, total_beats - beat)
        if length < 1.0:
            break
        for i, deg in enumerate(chord_degrees):
            if deg < len(scale):
                pitch = scale[deg] + octave_shift * 12
                if 12 <= pitch <= 120:  # C0–C9
                    vel = int(55 + _golden_hash(seed + i * 0.17 + chord_idx * 0.3, 44) * 35)
                    notes.append({"pitch": pitch, "start_beats": round(beat, 3),
                                  "length_beats": round(length, 3), "velocity": vel})
        beat += length
        chord_idx += 1
        # Seed-based chord progression: shift by 1-4 scale degrees
        shift = 1 + int(_golden_hash(seed + chord_idx * 0.19, 45) * 3)
        chord_degrees = [(d + shift) % len(scale) for d in chord_degrees]
    return notes


def _gen_arp_pattern(root, mode, scale, total_beats, seed, bpm):
    notes = []
    # Seed-based step size and start position
    step_options = [0.25, 0.5, 0.75, 1.0]
    step = step_options[int(_golden_hash(seed, 50) * len(step_options))]
    start_idx = int(_golden_hash(seed, 51) * len(scale))
    direction = 1 if _golden_hash(seed, 52) > 0.4 else -1
    # Seed-based octave jump probability
    octave_jump_prob = _golden_hash(seed, 53) * 0.3
    beat, idx = 0.0, start_idx
    while beat < total_beats:
        pitch = scale[idx % len(scale)]
        # Random octave shift
        if _golden_hash(seed + beat * 0.037, 54) < octave_jump_prob:
            pitch += 12 * (1 if _golden_hash(seed + beat * 0.041, 55) > 0.5 else -1)
        pitch = max(12, min(120, pitch))  # C0–C9
        vel = int(65 + _golden_hash(seed + beat * 0.023, 56) * 45)
        notes.append({"pitch": pitch, "start_beats": round(beat, 3),
                      "length_beats": round(step * 0.8, 3), "velocity": vel})
        beat += step
        # Seed-based direction changes
        if _golden_hash(seed + beat * 0.031, 57) < 0.15:
            direction *= -1
        idx += direction
        idx = max(0, min(len(scale) - 1, idx))
    return notes


def _gen_bass_pattern(root, mode, scale, total_beats, seed, bpm):
    notes = []
    # Seed-based bass notes: pick from low scale degrees
    bass_scale = [n for n in scale if n <= root] or [root - 12, root - 5, root]
    if not bass_scale:
        bass_scale = [max(12, root - 24)]  # Deep bass C0+
    # Seed-based rhythm pattern (which beats get notes)
    rhythm_patterns = [
        [0, 2],
        [0, 1.5, 3],
        [0, 2, 3, 3.5],
        [0, 0.5, 2, 3],
        [0, 1, 2, 3],
        [0, 2.5, 3],
    ]
    pat_idx = int(_golden_hash(seed, 58) * len(rhythm_patterns))
    pattern_beats = rhythm_patterns[pat_idx]
    # Seed-based note selection probability per beat
    beat, bar = 0.0, 0
    while beat < total_beats:
        for pb in pattern_beats:
            t = beat + pb
            if t >= total_beats:
                break
            # Pick from bass_scale using seed
            note_idx = int(_golden_hash(seed + t * 0.019 + bar * 0.37, 59) * len(bass_scale))
            pitch = bass_scale[note_idx % len(bass_scale)]
            # Occasional octave variation
            if _golden_hash(seed + t * 0.043, 60) < 0.2:
                pitch += 12
            pitch = max(12, min(84, pitch))  # C0–C6 (Bass)
            vel = int(75 + _golden_hash(seed + t * 0.013, 61) * 30)
            length = 0.5 + _golden_hash(seed + t * 0.027, 62) * 1.5
            notes.append({"pitch": pitch, "start_beats": round(t, 3),
                          "length_beats": round(length, 3), "velocity": vel})
        beat += 4.0
        bar += 1
    return notes


def _gen_stab_pattern(root, mode, scale, total_beats, seed, bpm):
    notes = []
    # Seed-based chord type for stabs
    chord_types = [
        [0, 4, 7],     # major triad intervals
        [0, 3, 7],     # minor triad
        [0, 7, 12],    # power chord
        [0, 5, 7],     # sus4
        [0, 4, 7, 11], # maj7
        [0, 3, 7, 10], # min7
    ]
    chord_idx = int(_golden_hash(seed, 63) * len(chord_types))
    chord = chord_types[chord_idx]
    # Seed-based rhythm hits
    hit_patterns = [[0], [0, 2], [0, 1.5, 3], [0, 0.5, 2, 3.5]]
    hit_idx = int(_golden_hash(seed, 64) * len(hit_patterns))
    hits = hit_patterns[hit_idx]
    # Seed-based root shift per bar
    beat, bar = 0.0, 0
    while beat < total_beats:
        bar_root = root + int(_golden_hash(seed + bar * 0.23, 65) * 5) - 2
        for h in hits:
            t = beat + h
            if t >= total_beats:
                break
            if _golden_hash(seed + t * 0.017, 66) < 0.15:
                continue  # skip some hits for variety
            for interval in chord:
                pitch = bar_root + interval
                if 12 <= pitch <= 120:  # C0–C9
                    vel = int(min(127, 85 + _golden_hash(seed + interval * 0.13 + bar * 0.3, 67) * 32))
                    stab_len = 0.15 + _golden_hash(seed + t * 0.031, 68) * 0.2
                    notes.append({"pitch": pitch, "start_beats": round(t, 3),
                                  "length_beats": round(stab_len, 3), "velocity": vel})
        beat += 4.0
        bar += 1
    return notes


def _gen_bell_pattern(root, mode, scale, total_beats, seed):
    notes = []
    high_scale = [n for n in scale if n >= root + 7] or [root + 12, root + 16, root + 19]
    # Seed-based spacing and note selection
    base_spacing = 1.5 + _golden_hash(seed, 70) * 4.0
    beat = _golden_hash(seed, 71) * 2.0  # Seed-based start offset
    note_counter = 0
    while beat < total_beats:
        spacing = base_spacing + _golden_hash(seed + beat * 0.027 + note_counter * 0.5, 72) * 3.0
        idx = int(_golden_hash(seed + note_counter * 0.37, 73) * len(high_scale))
        pitch = high_scale[idx % len(high_scale)]
        # Octave variation
        if _golden_hash(seed + note_counter * 0.41, 74) < 0.25:
            pitch += 12 if pitch < 96 else -12
        pitch = max(36, min(120, pitch))  # C2–C9 (Lead)
        vel = int(40 + _golden_hash(seed + note_counter * 0.19, 75) * 40)
        note_len = 1.0 + _golden_hash(seed + note_counter * 0.29, 76) * 3.0
        notes.append({"pitch": pitch, "start_beats": round(beat, 3),
                      "length_beats": round(note_len, 3), "velocity": vel})
        beat += spacing
        note_counter += 1
    return notes


def _gen_lead_pattern(root, mode, scale, total_beats, seed, bpm):
    notes = []
    # Seed-based start position and movement style
    start_idx = int(_golden_hash(seed, 80) * len(scale))
    step_size_bias = _golden_hash(seed, 81)  # 0=small steps, 1=big leaps
    rhythm_variety = _golden_hash(seed, 82)  # 0=steady, 1=varied
    beat, idx = 0.0, start_idx
    note_counter = 0
    while beat < total_beats:
        pitch = scale[idx % len(scale)]
        # Seed-based rhythm
        if rhythm_variety > 0.5:
            step_options = [0.25, 0.5, 0.75, 1.0, 1.5]
            step_len = step_options[int(_golden_hash(seed + note_counter * 0.13, 83) * len(step_options))]
        else:
            step_len = 0.5 if _golden_hash(seed + beat * 0.023, 83) > 0.4 else 1.0
        vel = int(70 + _golden_hash(seed + note_counter * 0.17, 84) * 35)
        # Rest probability
        if _golden_hash(seed + note_counter * 0.31, 85) < 0.1:
            beat += step_len
            note_counter += 1
            continue
        notes.append({"pitch": pitch, "start_beats": round(beat, 3),
                      "length_beats": round(step_len * 0.85, 3), "velocity": vel})
        # Seed-based movement
        max_step = 1 + int(step_size_bias * 4)
        step = int(_golden_hash(seed + note_counter * 0.23, 86) * (2 * max_step + 1)) - max_step
        if step == 0:
            step = 1
        idx = max(0, min(len(scale) - 1, idx + step))
        beat += step_len
        note_counter += 1
    return notes
