"""video_smart_cut.py — KI Smart Cut Service for VE12 (v0.0.20.950).

Intelligent automatic video editing:
  - Filler word detection ("ähm", "uhh", "like", etc.) → auto-remove
  - Silence/pause detection → shorten or remove
  - Confidence analysis: mark uncertain-looking segments
  - One-click Highlight Reel (best moments)
  - "Compress to N seconds" automatic summarization

Architecture:
  SmartCutService works on a Transcript (from WhisperService).
  It analyzes words and audio to find cuttable regions.
  Results are SmartCutSuggestion objects that can be applied.

What NO other DAW has:
  - Filler word removal integrated in a music DAW
  - Beat-aware silence detection (snaps to grid)
  - Audio confidence + word confidence combined scoring

Usage:
    svc = SmartCutService()
    suggestions = svc.detect_fillers(transcript)
    svc.apply_suggestions(transcript, suggestions)
"""

from __future__ import annotations

import logging
import math
import os
import re
import subprocess
import tempfile
import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════

# Filler words by language
FILLER_WORDS: Dict[str, List[str]] = {
    "de": [
        "ähm", "äh", "ehm", "eh", "hm", "hmm", "naja", "halt",
        "sozusagen", "quasi", "irgendwie", "also", "eben",
        "gewissermaßen", "praktisch", "eigentlich", "ja",
    ],
    "en": [
        "um", "uh", "uhm", "erm", "like", "you know", "basically",
        "actually", "literally", "honestly", "right", "so",
        "I mean", "kind of", "sort of", "well",
    ],
    "fr": [
        "euh", "heu", "ben", "bah", "genre", "en fait", "voilà",
        "quoi", "du coup",
    ],
    "es": [
        "eh", "este", "pues", "bueno", "o sea", "digamos",
        "básicamente",
    ],
    "universal": [
        "hmm", "hm", "mm", "mhm", "uh", "uhh", "ah", "ahh",
    ],
}

# Minimum pause duration to flag (seconds)
MIN_PAUSE_DURATION = 0.8

# Minimum silence duration to flag (seconds)
MIN_SILENCE_DURATION = 1.5

# Confidence threshold for "uncertain" segments
LOW_CONFIDENCE_THRESHOLD = 0.4


# ═══════════════════════════════════════════════════════════════
# Data structures
# ═══════════════════════════════════════════════════════════════

class SuggestionType(Enum):
    FILLER = "filler"          # Filler word (ähm, uh, etc.)
    PAUSE = "pause"            # Silence/pause between words
    LOW_CONFIDENCE = "low_confidence"  # Uncertain transcription
    REPETITION = "repetition"  # Repeated words/phrases
    LONG_PAUSE = "long_pause"  # Extended silence


@dataclass
class SmartCutSuggestion:
    """A suggestion for an automatic cut."""
    suggestion_type: SuggestionType
    start: float              # seconds
    end: float                # seconds
    word_ids: List[str] = field(default_factory=list)  # affected word IDs
    reason: str = ""          # human-readable explanation
    confidence: float = 0.9   # how confident the suggestion is
    auto_apply: bool = False  # safe to apply automatically?

    @property
    def duration(self) -> float:
        return self.end - self.start

    def to_dict(self) -> dict:
        return {
            "type": self.suggestion_type.value,
            "start": self.start,
            "end": self.end,
            "word_ids": self.word_ids,
            "reason": self.reason,
            "confidence": self.confidence,
            "auto_apply": self.auto_apply,
        }


@dataclass
class SmartCutResult:
    """Complete analysis result."""
    fillers: List[SmartCutSuggestion] = field(default_factory=list)
    pauses: List[SmartCutSuggestion] = field(default_factory=list)
    low_confidence: List[SmartCutSuggestion] = field(default_factory=list)
    repetitions: List[SmartCutSuggestion] = field(default_factory=list)

    @property
    def all_suggestions(self) -> List[SmartCutSuggestion]:
        return self.fillers + self.pauses + self.low_confidence + self.repetitions

    @property
    def total_cut_duration(self) -> float:
        return sum(s.duration for s in self.all_suggestions)

    @property
    def auto_applicable(self) -> List[SmartCutSuggestion]:
        return [s for s in self.all_suggestions if s.auto_apply]

    def summary(self) -> str:
        parts = []
        if self.fillers:
            parts.append(f"{len(self.fillers)} Füllwörter "
                         f"({sum(s.duration for s in self.fillers):.1f}s)")
        if self.pauses:
            parts.append(f"{len(self.pauses)} Pausen "
                         f"({sum(s.duration for s in self.pauses):.1f}s)")
        if self.low_confidence:
            parts.append(f"{len(self.low_confidence)} unsichere Stellen")
        if self.repetitions:
            parts.append(f"{len(self.repetitions)} Wiederholungen")
        total = self.total_cut_duration
        if parts:
            return f"Smart Cut: {', '.join(parts)} | ~{total:.1f}s kürzbar"
        return "Keine Schnitt-Vorschläge"


# ═══════════════════════════════════════════════════════════════
# Analysis functions
# ═══════════════════════════════════════════════════════════════

def detect_fillers(transcript, language: str = "") -> List[SmartCutSuggestion]:
    """Detect filler words in transcript.
    
    Args:
        transcript: Transcript object from WhisperService
        language: Language code (auto-detect from transcript if empty)
    
    Returns:
        List of SmartCutSuggestion for each filler word found
    """
    lang = language or getattr(transcript, 'language', '') or ''
    lang = lang.lower()[:2]

    # Build filler set from language + universal
    filler_set = set()
    for w in FILLER_WORDS.get("universal", []):
        filler_set.add(w.lower())
    for w in FILLER_WORDS.get(lang, []):
        filler_set.add(w.lower())

    suggestions = []
    for word in transcript.all_words:
        if word.deleted:
            continue
        clean = word.word.strip().lower().rstrip(".,!?;:")
        if clean in filler_set:
            suggestions.append(SmartCutSuggestion(
                suggestion_type=SuggestionType.FILLER,
                start=word.start,
                end=word.end,
                word_ids=[word.word_id],
                reason=f"Füllwort: '{word.word}'",
                confidence=0.85 if word.confidence > 0.5 else 0.6,
                auto_apply=(word.confidence > 0.7),
            ))

    return suggestions


def detect_pauses(transcript,
                  min_pause: float = MIN_PAUSE_DURATION,
                  min_silence: float = MIN_SILENCE_DURATION
                  ) -> List[SmartCutSuggestion]:
    """Detect pauses and silences between words.
    
    Args:
        transcript: Transcript object
        min_pause: Minimum gap to flag as pause
        min_silence: Minimum gap to flag as long silence
    
    Returns:
        List of SmartCutSuggestion for detected gaps
    """
    words = [w for w in transcript.all_words if not w.deleted]
    if len(words) < 2:
        return []

    suggestions = []
    for i in range(len(words) - 1):
        gap = words[i + 1].start - words[i].end
        if gap >= min_silence:
            suggestions.append(SmartCutSuggestion(
                suggestion_type=SuggestionType.LONG_PAUSE,
                start=words[i].end,
                end=words[i + 1].start,
                word_ids=[],
                reason=f"Lange Pause: {gap:.1f}s",
                confidence=0.95,
                auto_apply=True,
            ))
        elif gap >= min_pause:
            suggestions.append(SmartCutSuggestion(
                suggestion_type=SuggestionType.PAUSE,
                start=words[i].end + 0.1,  # keep 100ms padding
                end=words[i + 1].start - 0.1,
                word_ids=[],
                reason=f"Pause: {gap:.1f}s",
                confidence=0.80,
                auto_apply=False,
            ))

    return suggestions


def detect_low_confidence(transcript,
                           threshold: float = LOW_CONFIDENCE_THRESHOLD
                           ) -> List[SmartCutSuggestion]:
    """Find words/segments with low transcription confidence.
    
    These are regions where Whisper was uncertain — potentially
    mumbled or unclear speech.
    """
    suggestions = []
    low_streak = []

    for word in transcript.all_words:
        if word.deleted:
            continue
        if 0 < word.confidence < threshold:
            low_streak.append(word)
        else:
            if len(low_streak) >= 2:
                # Group consecutive low-confidence words
                suggestions.append(SmartCutSuggestion(
                    suggestion_type=SuggestionType.LOW_CONFIDENCE,
                    start=low_streak[0].start,
                    end=low_streak[-1].end,
                    word_ids=[w.word_id for w in low_streak],
                    reason=f"Unsichere Erkennung: "
                           f"'{' '.join(w.word for w in low_streak)}'",
                    confidence=0.5,
                    auto_apply=False,
                ))
            low_streak = []

    # Handle trailing streak
    if len(low_streak) >= 2:
        suggestions.append(SmartCutSuggestion(
            suggestion_type=SuggestionType.LOW_CONFIDENCE,
            start=low_streak[0].start,
            end=low_streak[-1].end,
            word_ids=[w.word_id for w in low_streak],
            reason=f"Unsichere Erkennung: "
                   f"'{' '.join(w.word for w in low_streak)}'",
            confidence=0.5,
            auto_apply=False,
        ))

    return suggestions


def detect_repetitions(transcript) -> List[SmartCutSuggestion]:
    """Detect repeated words/phrases (stuttering, restarts).
    
    Patterns detected:
      - Same word repeated 2+ times: "ich ich ich"
      - False starts: "Ich wollte— ich möchte sagen"
    """
    words = [w for w in transcript.all_words if not w.deleted]
    suggestions = []

    # Simple repetition: same word 2+ times consecutively
    i = 0
    while i < len(words) - 1:
        w_clean = words[i].word.strip().lower().rstrip(".,!?;:")
        if len(w_clean) < 2:
            i += 1
            continue

        streak = [words[i]]
        j = i + 1
        while j < len(words):
            next_clean = words[j].word.strip().lower().rstrip(".,!?;:")
            if next_clean == w_clean:
                streak.append(words[j])
                j += 1
            else:
                break

        if len(streak) >= 2:
            # Keep last occurrence, suggest cutting the rest
            to_cut = streak[:-1]
            suggestions.append(SmartCutSuggestion(
                suggestion_type=SuggestionType.REPETITION,
                start=to_cut[0].start,
                end=to_cut[-1].end,
                word_ids=[w.word_id for w in to_cut],
                reason=f"Wiederholung: '{w_clean}' ×{len(streak)}",
                confidence=0.75,
                auto_apply=(len(streak) >= 3),
            ))
            i = j
        else:
            i += 1

    return suggestions


# ═══════════════════════════════════════════════════════════════
# Highlight Reel / Summarization
# ═══════════════════════════════════════════════════════════════

def compute_segment_scores(transcript) -> List[Tuple[int, float]]:
    """Score each segment by 'interestingness'.
    
    Higher scores = more likely to be a highlight.
    Scoring factors:
      - Word confidence (high = speaker was clear)
      - Speech density (words per second)
      - Absence of fillers
      - Segment length (not too short, not too long)
    
    Returns: List of (segment_index, score) sorted by score descending
    """
    scores = []
    lang = getattr(transcript, 'language', '') or ''

    filler_set = set()
    for w in FILLER_WORDS.get("universal", []):
        filler_set.add(w.lower())
    for w in FILLER_WORDS.get(lang[:2], []):
        filler_set.add(w.lower())

    for idx, seg in enumerate(transcript.segments):
        active = seg.active_words
        if not active:
            scores.append((idx, 0.0))
            continue

        duration = seg.end - seg.start
        if duration <= 0:
            scores.append((idx, 0.0))
            continue

        # Average confidence
        avg_conf = sum(w.confidence for w in active) / len(active) \
            if any(w.confidence > 0 for w in active) else 0.5

        # Speech density (words per second)
        density = len(active) / duration
        density_score = min(1.0, density / 3.0)  # normalize to ~3 wps

        # Filler ratio (fewer = better)
        filler_count = sum(1 for w in active
                           if w.word.strip().lower().rstrip(".,!?;:")
                           in filler_set)
        filler_ratio = 1.0 - (filler_count / max(1, len(active)))

        # Length preference (5-15 seconds ideal)
        if 5.0 <= duration <= 15.0:
            length_score = 1.0
        elif duration < 2.0:
            length_score = 0.3
        elif duration > 30.0:
            length_score = 0.5
        else:
            length_score = 0.7

        score = (avg_conf * 0.3 + density_score * 0.25 +
                 filler_ratio * 0.25 + length_score * 0.2)
        scores.append((idx, score))

    scores.sort(key=lambda x: x[1], reverse=True)
    return scores


def generate_highlight_reel(transcript,
                             target_duration: float = 30.0
                             ) -> List[Tuple[float, float]]:
    """Select best segments to create a highlight reel.
    
    Args:
        transcript: Transcript object
        target_duration: Target total duration in seconds
    
    Returns:
        List of (start, end) time regions, sorted chronologically
    """
    scores = compute_segment_scores(transcript)
    if not scores:
        return []

    selected = []
    total_dur = 0.0

    for seg_idx, score in scores:
        if total_dur >= target_duration:
            break
        seg = transcript.segments[seg_idx]
        dur = seg.end - seg.start
        if dur <= 0:
            continue
        selected.append((seg.start, seg.end, seg_idx))
        total_dur += dur

    # Sort chronologically
    selected.sort(key=lambda x: x[0])
    return [(s, e) for s, e, _ in selected]


def compress_to_duration(transcript,
                          target_seconds: float) -> List[str]:
    """Determine which words to delete to reach target duration.
    
    Strategy:
      1. Remove fillers first
      2. Remove pauses
      3. Remove low-confidence words
      4. Remove lowest-scored segments
    
    Returns: List of word_ids to delete
    """
    current_duration = transcript.duration
    if current_duration <= target_seconds:
        return []  # Already short enough

    to_remove = target_seconds > 0 and current_duration > target_seconds
    if not to_remove:
        return []

    excess = current_duration - target_seconds
    word_ids_to_delete = []
    removed_time = 0.0

    # Phase 1: Remove fillers
    fillers = detect_fillers(transcript)
    for s in sorted(fillers, key=lambda x: x.confidence, reverse=True):
        if removed_time >= excess:
            break
        word_ids_to_delete.extend(s.word_ids)
        removed_time += s.duration

    # Phase 2: Remove pauses (just mark regions, no word IDs)
    if removed_time < excess:
        pauses = detect_pauses(transcript, min_pause=0.5)
        for s in sorted(pauses, key=lambda x: x.duration, reverse=True):
            if removed_time >= excess:
                break
            removed_time += s.duration

    # Phase 3: Remove repetitions
    if removed_time < excess:
        reps = detect_repetitions(transcript)
        for s in reps:
            if removed_time >= excess:
                break
            word_ids_to_delete.extend(s.word_ids)
            removed_time += s.duration

    # Phase 4: Remove low-confidence words
    if removed_time < excess:
        lows = detect_low_confidence(transcript, threshold=0.5)
        for s in lows:
            if removed_time >= excess:
                break
            word_ids_to_delete.extend(s.word_ids)
            removed_time += s.duration

    return list(dict.fromkeys(word_ids_to_delete))  # deduplicate, keep order


# ═══════════════════════════════════════════════════════════════
# SmartCutService
# ═══════════════════════════════════════════════════════════════

class SmartCutService:
    """High-level service for KI Smart Cut operations."""

    def __init__(self):
        self._last_result: Optional[SmartCutResult] = None

    def analyze(self, transcript) -> SmartCutResult:
        """Run full analysis on a transcript.
        
        Returns SmartCutResult with all suggestions.
        """
        result = SmartCutResult(
            fillers=detect_fillers(transcript),
            pauses=detect_pauses(transcript),
            low_confidence=detect_low_confidence(transcript),
            repetitions=detect_repetitions(transcript),
        )
        self._last_result = result
        log.info("SmartCut analysis: %s", result.summary())
        return result

    def apply_suggestions(self, transcript,
                           suggestions: List[SmartCutSuggestion]) -> int:
        """Apply cut suggestions by marking words as deleted.
        
        Returns number of words deleted.
        """
        count = 0
        for s in suggestions:
            for wid in s.word_ids:
                if transcript.delete_word(wid):
                    count += 1
        log.info("SmartCut applied: %d words deleted", count)
        return count

    def apply_auto(self, transcript) -> int:
        """Apply only auto-safe suggestions."""
        if not self._last_result:
            self.analyze(transcript)
        if self._last_result:
            safe = self._last_result.auto_applicable
            return self.apply_suggestions(transcript, safe)
        return 0

    def highlight_reel(self, transcript,
                        target_seconds: float = 30.0
                        ) -> List[Tuple[float, float]]:
        """Generate highlight reel regions."""
        return generate_highlight_reel(transcript, target_seconds)

    def compress(self, transcript,
                  target_seconds: float) -> List[str]:
        """Get word IDs to delete to reach target duration."""
        return compress_to_duration(transcript, target_seconds)
