"""ki_arrangement.py — Arrangement & Orchestration Engine (v0.0.20.986)

KK5: Arrangement-Engine

Provides automatic arrangement generation:
  - Orchestration: instrument assignment by range/role
  - Song structure: Intro-Verse-Chorus-Bridge-Outro
  - Musical forms: Sonata, Rondo, ABA, Variation, Strophic
  - Style mixing: combine two epochs into a new style
  - Medley generation: intelligently connect multiple pieces

Usage:
    from pydaw.services.ki_arrangement import ArrangementEngine

    arr = ArrangementEngine()
    structure = arr.generate_song_structure("pop", duration_bars=64)
    orchestration = arr.orchestrate("baroque", melody, chords)
"""

import random
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from enum import Enum

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Instrument Ranges & Roles
# ═══════════════════════════════════════════════════════════════

@dataclass
class InstrumentRange:
    """MIDI note range and role for an instrument."""
    name: str
    midi_low: int
    midi_high: int
    category: str       # "strings", "brass", "woodwinds", "keys", "percussion", "voice"
    role: str           # "melody", "harmony", "bass", "rhythm", "pad"
    transposition: int = 0  # concert pitch offset

INSTRUMENTS: Dict[str, InstrumentRange] = {
    # Strings
    "violin":       InstrumentRange("Violin",       55, 100, "strings", "melody"),
    "viola":        InstrumentRange("Viola",         48, 88,  "strings", "harmony"),
    "cello":        InstrumentRange("Cello",         36, 76,  "strings", "harmony"),
    "contrabass":   InstrumentRange("Contrabass",    28, 60,  "strings", "bass"),
    # Brass
    "trumpet":      InstrumentRange("Trumpet",       54, 86,  "brass", "melody", -2),
    "french_horn":  InstrumentRange("French Horn",   41, 77,  "brass", "harmony", -7),
    "trombone":     InstrumentRange("Trombone",      34, 72,  "brass", "harmony"),
    "tuba":         InstrumentRange("Tuba",          28, 58,  "brass", "bass"),
    # Woodwinds
    "flute":        InstrumentRange("Flute",         60, 96,  "woodwinds", "melody"),
    "oboe":         InstrumentRange("Oboe",          58, 91,  "woodwinds", "melody"),
    "clarinet":     InstrumentRange("Clarinet",      50, 91,  "woodwinds", "melody", -2),
    "bassoon":      InstrumentRange("Bassoon",       34, 72,  "woodwinds", "bass"),
    # Keys
    "piano":        InstrumentRange("Piano",         21, 108, "keys", "harmony"),
    "harpsichord":  InstrumentRange("Harpsichord",   29, 89,  "keys", "harmony"),
    "organ":        InstrumentRange("Organ",         24, 108, "keys", "harmony"),
    # Voice
    "soprano":      InstrumentRange("Soprano",       60, 81,  "voice", "melody"),
    "alto":         InstrumentRange("Alto",          53, 74,  "voice", "harmony"),
    "tenor":        InstrumentRange("Tenor",         48, 69,  "voice", "harmony"),
    "bass_voice":   InstrumentRange("Bass",          40, 62,  "voice", "bass"),
    # Synths
    "synth_lead":   InstrumentRange("Synth Lead",    36, 96,  "keys", "melody"),
    "synth_pad":    InstrumentRange("Synth Pad",     36, 84,  "keys", "pad"),
    "synth_bass":   InstrumentRange("Synth Bass",    24, 60,  "keys", "bass"),
    # Rhythm
    "drums":        InstrumentRange("Drums",         35, 81,  "percussion", "rhythm"),
    "guitar":       InstrumentRange("Guitar",        40, 84,  "strings", "harmony"),
    "bass_guitar":  InstrumentRange("Bass Guitar",   28, 60,  "strings", "bass"),
}


# ═══════════════════════════════════════════════════════════════
# Song Structure
# ═══════════════════════════════════════════════════════════════

class SectionType(Enum):
    INTRO = "intro"
    VERSE = "verse"
    PRE_CHORUS = "pre_chorus"
    CHORUS = "chorus"
    BRIDGE = "bridge"
    SOLO = "solo"
    BREAKDOWN = "breakdown"
    BUILD = "build"
    DROP = "drop"
    OUTRO = "outro"
    INTERLUDE = "interlude"
    CODA = "coda"


@dataclass
class SongSection:
    """A section in a song structure."""
    section_type: SectionType
    start_bar: int
    length_bars: int
    energy: float = 0.5       # 0.0–1.0
    instruments: List[str] = field(default_factory=list)
    dynamics: str = "mf"      # pp, p, mp, mf, f, ff
    description: str = ""


@dataclass
class SongStructure:
    """Complete song structure with sections."""
    title: str
    style: str
    total_bars: int
    sections: List[SongSection]
    tempo: int = 120
    key: str = "C major"
    time_signature: Tuple[int, int] = (4, 4)


# Pre-defined song structure templates
STRUCTURE_TEMPLATES: Dict[str, List[Tuple[SectionType, int, float]]] = {
    "pop": [
        (SectionType.INTRO, 4, 0.3),
        (SectionType.VERSE, 8, 0.5),
        (SectionType.PRE_CHORUS, 4, 0.6),
        (SectionType.CHORUS, 8, 0.8),
        (SectionType.VERSE, 8, 0.5),
        (SectionType.PRE_CHORUS, 4, 0.6),
        (SectionType.CHORUS, 8, 0.9),
        (SectionType.BRIDGE, 8, 0.4),
        (SectionType.CHORUS, 8, 1.0),
        (SectionType.OUTRO, 4, 0.3),
    ],
    "rock": [
        (SectionType.INTRO, 4, 0.5),
        (SectionType.VERSE, 8, 0.6),
        (SectionType.CHORUS, 8, 0.8),
        (SectionType.VERSE, 8, 0.6),
        (SectionType.CHORUS, 8, 0.9),
        (SectionType.SOLO, 8, 0.7),
        (SectionType.CHORUS, 8, 1.0),
        (SectionType.OUTRO, 4, 0.4),
    ],
    "electronic": [
        (SectionType.INTRO, 8, 0.2),
        (SectionType.BUILD, 8, 0.5),
        (SectionType.DROP, 8, 1.0),
        (SectionType.BREAKDOWN, 8, 0.3),
        (SectionType.BUILD, 8, 0.6),
        (SectionType.DROP, 8, 1.0),
        (SectionType.OUTRO, 8, 0.2),
    ],
    "jazz": [
        (SectionType.INTRO, 4, 0.4),
        (SectionType.VERSE, 8, 0.5),      # A section (head)
        (SectionType.VERSE, 8, 0.5),      # A repeat
        (SectionType.BRIDGE, 8, 0.6),     # B section
        (SectionType.VERSE, 8, 0.5),      # A return
        (SectionType.SOLO, 16, 0.7),      # Solo choruses
        (SectionType.VERSE, 8, 0.5),      # Head out
        (SectionType.CODA, 4, 0.3),
    ],
    "classical_sonata": [
        (SectionType.INTRO, 4, 0.4),
        (SectionType.VERSE, 16, 0.6),      # Exposition: Theme 1
        (SectionType.BRIDGE, 8, 0.5),      # Transition
        (SectionType.VERSE, 16, 0.6),      # Exposition: Theme 2
        (SectionType.INTERLUDE, 4, 0.3),   # Codetta
        (SectionType.SOLO, 24, 0.7),       # Development
        (SectionType.VERSE, 16, 0.6),      # Recapitulation: Theme 1
        (SectionType.VERSE, 16, 0.6),      # Recapitulation: Theme 2
        (SectionType.CODA, 8, 0.8),
    ],
    "blues_12": [
        (SectionType.INTRO, 4, 0.4),
        (SectionType.VERSE, 12, 0.6),
        (SectionType.VERSE, 12, 0.6),
        (SectionType.SOLO, 12, 0.7),
        (SectionType.VERSE, 12, 0.6),
        (SectionType.OUTRO, 4, 0.3),
    ],
    "ambient": [
        (SectionType.INTRO, 16, 0.1),
        (SectionType.VERSE, 16, 0.3),
        (SectionType.BUILD, 8, 0.4),
        (SectionType.VERSE, 16, 0.5),
        (SectionType.BREAKDOWN, 16, 0.2),
        (SectionType.OUTRO, 16, 0.1),
    ],
    "hymn": [
        (SectionType.INTRO, 2, 0.3),
        (SectionType.VERSE, 8, 0.5),
        (SectionType.VERSE, 8, 0.6),
        (SectionType.VERSE, 8, 0.7),
        (SectionType.VERSE, 8, 0.8),
        (SectionType.CODA, 4, 0.5),
    ],
}


# ═══════════════════════════════════════════════════════════════
# Musical Forms
# ═══════════════════════════════════════════════════════════════

class MusicalForm(Enum):
    SONATA = "sonata"           # Exposition-Development-Recapitulation
    RONDO = "rondo"             # ABACABA
    TERNARY = "ternary"         # ABA
    BINARY = "binary"           # AB
    VARIATION = "variation"     # A A' A'' A'''
    STROPHIC = "strophic"       # AAA (same music, different text)
    THROUGH_COMPOSED = "through_composed"  # ABCD (no repeats)
    FUGUE = "fugue"             # Exposition-Episodes-Stretto


FORM_PATTERNS: Dict[MusicalForm, List[str]] = {
    MusicalForm.SONATA: ["Expo-A", "Trans", "Expo-B", "Dev", "Recap-A", "Recap-B", "Coda"],
    MusicalForm.RONDO: ["A", "B", "A", "C", "A", "B", "A"],
    MusicalForm.TERNARY: ["A", "B", "A'"],
    MusicalForm.BINARY: ["A", "B"],
    MusicalForm.VARIATION: ["Theme", "Var1", "Var2", "Var3", "Var4", "Finale"],
    MusicalForm.STROPHIC: ["Strophe1", "Strophe2", "Strophe3", "Strophe4"],
    MusicalForm.THROUGH_COMPOSED: ["A", "B", "C", "D"],
    MusicalForm.FUGUE: ["Expo", "Episode1", "Entry2", "Episode2", "Stretto", "Coda"],
}


# ═══════════════════════════════════════════════════════════════
# Arrangement Engine
# ═══════════════════════════════════════════════════════════════

class ArrangementEngine:
    """Generate complete song arrangements."""

    def __init__(self):
        self.instruments = INSTRUMENTS
        self.templates = STRUCTURE_TEMPLATES
        self.forms = FORM_PATTERNS

    def generate_song_structure(self, style: str = "pop",
                                 duration_bars: int = 64,
                                 tempo: int = 120,
                                 key: str = "C major") -> SongStructure:
        """Generate a song structure from a template."""
        template = self.templates.get(style, self.templates["pop"])

        # Scale template to target duration
        template_bars = sum(t[1] for t in template)
        scale = duration_bars / template_bars if template_bars > 0 else 1.0

        sections = []
        current_bar = 0
        for section_type, bars, energy in template:
            scaled_bars = max(2, round(bars * scale))
            section = SongSection(
                section_type=section_type,
                start_bar=current_bar,
                length_bars=scaled_bars,
                energy=energy,
                dynamics=self._energy_to_dynamics(energy),
            )
            sections.append(section)
            current_bar += scaled_bars

        return SongStructure(
            title=f"Untitled ({style})",
            style=style,
            total_bars=current_bar,
            sections=sections,
            tempo=tempo,
            key=key,
        )

    def orchestrate(self, style: str,
                    instruments: Optional[List[str]] = None) -> Dict[str, str]:
        """Suggest instrument assignment for a style.

        Returns: {role: instrument_name}
        """
        style_instruments = {
            "baroque": {"melody": "violin", "harmony": "harpsichord",
                        "bass": "cello", "rhythm": "harpsichord"},
            "classical": {"melody": "violin", "harmony": "viola",
                          "bass": "cello", "rhythm": "piano"},
            "romantic": {"melody": "violin", "harmony": "piano",
                         "bass": "contrabass", "rhythm": "piano"},
            "jazz": {"melody": "synth_lead", "harmony": "piano",
                     "bass": "bass_guitar", "rhythm": "drums"},
            "rock": {"melody": "guitar", "harmony": "guitar",
                     "bass": "bass_guitar", "rhythm": "drums"},
            "electronic": {"melody": "synth_lead", "harmony": "synth_pad",
                           "bass": "synth_bass", "rhythm": "drums"},
            "hymn": {"melody": "soprano", "harmony": "organ",
                     "bass": "bass_voice", "rhythm": "organ"},
        }
        return style_instruments.get(style, style_instruments["rock"])

    def generate_form(self, form: MusicalForm,
                      bars_per_section: int = 8) -> List[Dict]:
        """Generate a musical form structure.

        Returns list of {name, start_bar, length_bars, is_new_material}.
        """
        pattern = self.forms.get(form, ["A", "B", "A"])
        seen = set()
        sections = []
        bar = 0
        for name in pattern:
            is_new = name.rstrip("'0123456789") not in seen
            seen.add(name.rstrip("'0123456789"))
            sections.append({
                "name": name,
                "start_bar": bar,
                "length_bars": bars_per_section,
                "is_new_material": is_new,
            })
            bar += bars_per_section
        return sections

    def mix_styles(self, style_a: str, style_b: str,
                   mix: float = 0.5) -> Dict:
        """Create a hybrid style by mixing two epoch profiles.

        Args:
            style_a, style_b: epoch names
            mix: 0.0 = pure A, 1.0 = pure B

        Returns dict with blended parameters.
        """
        try:
            from .ki_epoch_profiles import EPOCH_PROFILES
        except ImportError:
            from pydaw.services.ki_epoch_profiles import EPOCH_PROFILES

        a = EPOCH_PROFILES.get(style_a)
        b = EPOCH_PROFILES.get(style_b)
        if a is None or b is None:
            return {"error": f"Unknown style: {style_a if a is None else style_b}"}

        # Blend tempo
        tempo_lo = int(a.tempo_range[0] * (1 - mix) + b.tempo_range[0] * mix)
        tempo_hi = int(a.tempo_range[1] * (1 - mix) + b.tempo_range[1] * mix)

        # Merge scales (union)
        scales = list(set(a.preferred_scales + b.preferred_scales))

        # Blend complexity
        complexity = a.rhythmic_complexity * (1 - mix) + b.rhythmic_complexity * mix
        swing = a.swing_amount * (1 - mix) + b.swing_amount * mix

        return {
            "name": f"{a.name} × {b.name}",
            "mix": mix,
            "tempo_range": (tempo_lo, tempo_hi),
            "preferred_scales": scales,
            "rhythmic_complexity": complexity,
            "swing": swing,
            "voices": int(a.typical_voices * (1 - mix) + b.typical_voices * mix),
            "chromaticism": a.use_chromaticism * (1 - mix) + b.use_chromaticism * mix,
        }

    def generate_medley(self, pieces: List[Dict],
                        transition_bars: int = 4) -> List[Dict]:
        """Generate a medley from multiple pieces.

        Args:
            pieces: List of {key, tempo, style, duration_bars}
            transition_bars: Bars for transition between pieces

        Returns list of medley sections with transitions.
        """
        result = []
        current_bar = 0

        for i, piece in enumerate(pieces):
            # Add transition (except before first piece)
            if i > 0:
                result.append({
                    "type": "transition",
                    "start_bar": current_bar,
                    "length_bars": transition_bars,
                    "from_key": pieces[i-1].get("key", "C"),
                    "to_key": piece.get("key", "C"),
                    "from_tempo": pieces[i-1].get("tempo", 120),
                    "to_tempo": piece.get("tempo", 120),
                })
                current_bar += transition_bars

            # Add piece
            dur = piece.get("duration_bars", 16)
            result.append({
                "type": "piece",
                "start_bar": current_bar,
                "length_bars": dur,
                **piece,
            })
            current_bar += dur

        return result

    @staticmethod
    def _energy_to_dynamics(energy: float) -> str:
        if energy < 0.2: return "pp"
        if energy < 0.35: return "p"
        if energy < 0.5: return "mp"
        if energy < 0.65: return "mf"
        if energy < 0.8: return "f"
        return "ff"

    def list_structures(self) -> List[str]:
        return list(self.templates.keys())

    def list_forms(self) -> List[str]:
        return [f.value for f in MusicalForm]

    def list_instruments(self) -> List[Dict]:
        return [{"name": k, "range": f"{v.midi_low}-{v.midi_high}",
                 "category": v.category, "role": v.role}
                for k, v in self.instruments.items()]
