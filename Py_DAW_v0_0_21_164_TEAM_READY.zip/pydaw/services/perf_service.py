"""perf_service.py — Performance-Optimierungen (v0.0.20.933).

Zentrale Performance-Infrastruktur für Py_DAW:

1. PaintThrottle — verhindert zu häufige Repaints (coalesces update() calls)
2. AsyncRunner — führt schwere Operationen im Thread aus (kein UI-Freeze)
3. MemoryGuard — überwacht Speicher, triggert GC wenn nötig
4. ProcessPriority — setzt nice/ionice für ffmpeg Subprozesse
5. FrameCache — LRU Cache mit Speicherlimit
6. setup_zram_hint() — Empfehlung für ZRAM Swap

Usage:
    from pydaw.services.perf_service import PaintThrottle, AsyncRunner

    # In a widget:
    self._throttle = PaintThrottle(self, fps_limit=15)
    self._throttle.request()  # statt self.update()

    # For background work:
    AsyncRunner.run(heavy_function, callback=on_done)
"""

from __future__ import annotations

import gc
import logging
import os
import subprocess
import sys
import threading
import time
from collections import OrderedDict
from typing import Any, Callable, Dict, Optional

log = logging.getLogger(__name__)

# Lazy Qt imports
_QTimer = None
_QObject = None


def _ensure_qt():
    global _QTimer, _QObject
    if _QTimer is None:
        try:
            from PyQt6.QtCore import QTimer, QObject
            _QTimer = QTimer
            _QObject = QObject
        except ImportError:
            pass


# ═══════════════════════════════════════════════════════════════
# 1. PaintThrottle — coalesce update() calls
# ═══════════════════════════════════════════════════════════════

class PaintThrottle:
    """Limits repaint frequency for a QWidget.

    Problem: calling widget.update() 100x/sec triggers 100 paintEvents.
    Solution: coalesce into max N per second.

    Usage:
        self._throttle = PaintThrottle(self, fps_limit=15)
        # Replace self.update() with:
        self._throttle.request()
    """

    def __init__(self, widget, fps_limit: int = 15):
        _ensure_qt()
        self._widget = widget
        self._interval = max(16, 1000 // max(1, fps_limit))  # ms between frames
        self._pending = False
        self._last_paint = 0.0

        if _QTimer is not None:
            self._timer = _QTimer()
            self._timer.setSingleShot(True)
            self._timer.timeout.connect(self._do_paint)
        else:
            self._timer = None

    def request(self) -> None:
        """Request a repaint (coalesced)."""
        if self._pending:
            return  # already scheduled

        now = time.monotonic() * 1000
        elapsed = now - self._last_paint

        if elapsed >= self._interval:
            # Enough time passed — paint immediately
            self._do_paint()
        elif self._timer is not None:
            # Schedule deferred paint
            self._pending = True
            delay = max(1, int(self._interval - elapsed))
            self._timer.start(delay)

    def _do_paint(self) -> None:
        self._pending = False
        self._last_paint = time.monotonic() * 1000
        try:
            if self._widget is not None:
                self._widget.update()
        except Exception:
            pass

    def force(self) -> None:
        """Force immediate repaint (bypasses throttle)."""
        self._pending = False
        self._last_paint = time.monotonic() * 1000
        try:
            if self._widget is not None:
                self._widget.update()
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════
# 2. AsyncRunner — fire-and-forget background tasks
# ═══════════════════════════════════════════════════════════════

class AsyncRunner:
    """Run functions in background threads with optional callback.

    The callback runs on the calling thread (via QTimer.singleShot).
    Thread-safe, no GIL contention for I/O-bound tasks.

    Usage:
        AsyncRunner.run(
            lambda: expensive_io_operation(),
            callback=lambda result: self.label.setText(str(result))
        )
    """

    @staticmethod
    def run(func: Callable, callback: Optional[Callable] = None,
            error_callback: Optional[Callable] = None) -> threading.Thread:
        """Run func in background, call callback with result on main thread."""
        def worker():
            try:
                result = func()
                if callback is not None:
                    _ensure_qt()
                    if _QTimer is not None:
                        _QTimer.singleShot(0, lambda: callback(result))
                    else:
                        callback(result)
            except Exception as e:
                if error_callback is not None:
                    _ensure_qt()
                    if _QTimer is not None:
                        _QTimer.singleShot(0, lambda: error_callback(e))
                else:
                    log.debug("[AsyncRunner] error: %s", e)

        t = threading.Thread(target=worker, daemon=True)
        t.start()
        return t


# ═══════════════════════════════════════════════════════════════
# 3. MemoryGuard — prevent OOM, trigger GC
# ═══════════════════════════════════════════════════════════════

class MemoryGuard:
    """Monitor memory usage and trigger cleanup when needed.

    Checks RSS every N seconds. If above threshold:
    - Runs gc.collect()
    - Clears caches (thumbnail, preset, etc.)
    - Logs warning

    Usage:
        guard = MemoryGuard(threshold_mb=1500)
        guard.start()
    """

    _instance: Optional[MemoryGuard] = None

    @classmethod
    def instance(cls, threshold_mb: int = 1500) -> MemoryGuard:
        if cls._instance is None:
            cls._instance = cls(threshold_mb)
        return cls._instance

    def __init__(self, threshold_mb: int = 1500):
        self._threshold_bytes = threshold_mb * 1024 * 1024
        self._check_interval = 60  # seconds
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._cleanup_callbacks: list = []

    def register_cleanup(self, callback: Callable) -> None:
        """Register a cleanup callback (called when memory is high)."""
        if callback not in self._cleanup_callbacks:
            self._cleanup_callbacks.append(callback)

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()
        log.info("[MemoryGuard] Started (threshold: %dMB, interval: %ds)",
                 self._threshold_bytes // (1024 * 1024), self._check_interval)

    def stop(self) -> None:
        self._running = False

    def _get_rss_bytes(self) -> int:
        """Get current RSS in bytes."""
        try:
            with open(f"/proc/{os.getpid()}/statm") as f:
                pages = int(f.read().split()[1])
                return pages * os.sysconf("SC_PAGE_SIZE")
        except Exception:
            try:
                import resource
                return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
            except Exception:
                return 0

    def _monitor_loop(self) -> None:
        while self._running:
            try:
                rss = self._get_rss_bytes()
                if rss > self._threshold_bytes:
                    rss_mb = rss / (1024 * 1024)
                    log.warning("[MemoryGuard] RSS %.0fMB > threshold %dMB — running cleanup",
                                rss_mb, self._threshold_bytes // (1024 * 1024))

                    # 1. Run GC
                    collected = gc.collect()
                    log.info("[MemoryGuard] GC collected %d objects", collected)

                    # 2. Run registered cleanup callbacks
                    for cb in self._cleanup_callbacks:
                        try:
                            cb()
                        except Exception as e:
                            log.debug("[MemoryGuard] cleanup callback error: %s", e)

                    # 3. Check again
                    rss_after = self._get_rss_bytes()
                    freed = (rss - rss_after) / (1024 * 1024)
                    if freed > 0:
                        log.info("[MemoryGuard] Freed %.0fMB (now %.0fMB)",
                                 freed, rss_after / (1024 * 1024))

            except Exception:
                pass

            time.sleep(self._check_interval)


# ═══════════════════════════════════════════════════════════════
# 4. ProcessPriority — nice/ionice for subprocesses
# ═══════════════════════════════════════════════════════════════

def nice_subprocess_args(cmd: list, nice_level: int = 10) -> list:
    """Wrap a command with nice/ionice for lower priority.

    ffmpeg and other CPU-heavy subprocesses should not steal time
    from the audio thread or GUI.

    Usage:
        cmd = nice_subprocess_args(["ffmpeg", "-i", ...])
        subprocess.run(cmd, ...)
    """
    if sys.platform != "linux":
        return cmd

    # nice: lower CPU priority
    # ionice -c3: idle I/O priority (only use disk when nothing else needs it)
    prefix = []
    try:
        # Check if nice is available
        if os.path.exists("/usr/bin/nice"):
            prefix = ["nice", f"-n{nice_level}"]
        # Add ionice if available
        if os.path.exists("/usr/bin/ionice"):
            prefix = ["ionice", "-c3"] + prefix
    except Exception:
        pass

    return prefix + cmd if prefix else cmd


# ═══════════════════════════════════════════════════════════════
# 5. LRU Cache with memory limit
# ═══════════════════════════════════════════════════════════════

class BoundedLRUCache:
    """Thread-safe LRU cache with maximum entry count and memory tracking.

    Usage:
        cache = BoundedLRUCache(max_entries=500, name="thumbnails")
        cache.put(key, value)
        val = cache.get(key)  # returns None if not found
    """

    def __init__(self, max_entries: int = 500, name: str = "cache"):
        self._max = max_entries
        self._name = name
        self._data: OrderedDict = OrderedDict()
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0

    def get(self, key) -> Optional[Any]:
        with self._lock:
            val = self._data.get(key)
            if val is not None:
                self._data.move_to_end(key)
                self._hits += 1
                return val
            self._misses += 1
            return None

    def put(self, key, value) -> None:
        with self._lock:
            if key in self._data:
                self._data.move_to_end(key)
                self._data[key] = value
            else:
                self._data[key] = value
                if len(self._data) > self._max:
                    # Evict oldest 10%
                    evict_count = max(1, self._max // 10)
                    for _ in range(evict_count):
                        try:
                            self._data.popitem(last=False)
                        except KeyError:
                            break

    def clear(self) -> None:
        with self._lock:
            self._data.clear()

    def stats(self) -> dict:
        with self._lock:
            total = self._hits + self._misses
            return {
                "name": self._name,
                "entries": len(self._data),
                "max": self._max,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": f"{(self._hits / max(1, total)) * 100:.1f}%",
            }

    def __len__(self) -> int:
        return len(self._data)


# ═══════════════════════════════════════════════════════════════
# 6. ZRAM Setup Hint
# ═══════════════════════════════════════════════════════════════

def check_zram_status() -> dict:
    """Check ZRAM swap status on Linux.

    Returns dict with:
        available: bool — is zram loaded?
        active: bool — is zram swap active?
        size_mb: int — total zram size
        used_mb: int — used zram
        hint: str — recommendation
    """
    result = {"available": False, "active": False, "size_mb": 0,
              "used_mb": 0, "hint": ""}

    if sys.platform != "linux":
        result["hint"] = "ZRAM ist nur auf Linux verfügbar."
        return result

    try:
        # Check if zram module is loaded
        with open("/proc/modules") as f:
            modules = f.read()
        result["available"] = "zram" in modules

        # Check if zram swap is active
        with open("/proc/swaps") as f:
            swaps = f.read()
        zram_lines = [l for l in swaps.split('\n') if 'zram' in l]
        if zram_lines:
            result["active"] = True
            for line in zram_lines:
                parts = line.split()
                if len(parts) >= 3:
                    result["size_mb"] += int(parts[2]) // 1024
                    result["used_mb"] += int(parts[3]) // 1024 if len(parts) > 3 else 0

        if result["active"]:
            result["hint"] = f"✅ ZRAM aktiv ({result['size_mb']}MB)"
        elif result["available"]:
            result["hint"] = (
                "⚠ ZRAM Modul geladen aber kein Swap aktiv.\n"
                "Aktivieren: sudo modprobe zram && "
                "echo lz4 > /sys/block/zram0/comp_algorithm && "
                "echo 4G > /sys/block/zram0/disksize && "
                "mkswap /dev/zram0 && swapon -p 100 /dev/zram0"
            )
        else:
            result["hint"] = (
                "❌ ZRAM nicht geladen.\n"
                "Installieren: sudo apt install zram-tools\n"
                "Oder: sudo modprobe zram num_devices=1"
            )

    except Exception as e:
        result["hint"] = f"ZRAM Status unbekannt: {e}"

    return result


def setup_process_optimizations() -> None:
    """Apply process-level optimizations at DAW startup.

    Called once during initialization.
    """
    try:
        # 1. Set OOM score to make DAW less likely to be killed
        try:
            with open(f"/proc/{os.getpid()}/oom_score_adj", "w") as f:
                f.write("-500")
            log.info("[Perf] OOM score adjusted to -500")
        except (PermissionError, FileNotFoundError):
            pass

        # 2. Increase file descriptor limit
        try:
            import resource
            soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
            if soft < 4096:
                resource.setrlimit(resource.RLIMIT_NOFILE, (min(4096, hard), hard))
                log.info("[Perf] File descriptor limit raised to %d", min(4096, hard))
        except Exception:
            pass

        # 3. Start memory guard
        try:
            guard = MemoryGuard.instance(threshold_mb=4000)
            guard.start()
        except Exception:
            pass

    except Exception as e:
        log.debug("[Perf] setup_process_optimizations: %s", e)
