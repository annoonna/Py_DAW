"""bassline_generator.py — Chord Progression → Bassline Generator.

v0.0.20.909 — C4.5: KI-Kompositions-Feature.

Generates bass patterns from chord progressions using musical rules.
Supports multiple styles: root, walking bass, octave, syncopated, arpeggio.

Usage:
    from pydaw.services.bassline_generator import BasslineGenerator
    from pydaw.services.chord_progression_ai import ChordProgressionAI

    ai = ChordProgressionAI()
    chords = ai.suggest_progression(key="C", scale="major", length=4)

    bass = BasslineGenerator()
    notes = bass.generate(chords, style="walking", beats_per_chord=4, octave=2)
    # → List of MidiNote-compatible dicts
"""

from __future__ import annotations

import logging
import random
from typing import Dict, List, Optional

log = logging.getLogger(__name__)

# ── Note tables ────────────────────────────────────────────────────

NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

CHORD_INTERVALS: Dict[str, List[int]] = {
    "maj":  [0, 4, 7],
    "min":  [0, 3, 7],
    "dim":  [0, 3, 6],
    "aug":  [0, 4, 8],
    "7":    [0, 4, 7, 10],
    "maj7": [0, 4, 7, 11],
    "min7": [0, 3, 7, 10],
    "sus2": [0, 2, 7],
    "sus4": [0, 5, 7],
}

# Scale patterns for walking bass approach tones
CHROMATIC_APPROACH = [-1, 1, -2, 2]  # semitones below/above target


class BasslineGenerator:
    """Generate bass patterns from chord progressions."""

    def __init__(self, seed: Optional[int] = None):
        self._rng = random.Random(seed)

    def generate(
        self,
        chords: list,
        style: str = "root",
        beats_per_chord: float = 4.0,
        octave: int = 2,
        velocity: int = 90,
        swing: float = 0.0,
    ) -> List[dict]:
        """Generate a bassline from a chord progression.

        Args:
            chords: List of ChordSuggestion objects (or dicts with root_name, quality)
            style: "root", "walking", "octave", "syncopated", "arpeggio"
            beats_per_chord: Beats per chord (usually 4 for 4/4 time)
            octave: Bass octave (2 = bass register)
            velocity: Base velocity
            swing: Swing amount (0.0 = straight, 0.5 = heavy swing)

        Returns:
            List of dicts with "pitch", "start_beats", "length_beats", "velocity".
        """
        style_fn = {
            "root": self._style_root,
            "walking": self._style_walking,
            "octave": self._style_octave,
            "syncopated": self._style_syncopated,
            "arpeggio": self._style_arpeggio,
        }.get(style, self._style_root)

        notes: List[dict] = []
        current_beat = 0.0

        for i, chord in enumerate(chords):
            root_name = self._get(chord, "root_name", "C")
            quality = self._get(chord, "quality", "maj")
            root_pc = self._name_to_pc(root_name)
            root_midi = (octave + 1) * 12 + root_pc

            next_chord = chords[(i + 1) % len(chords)] if len(chords) > 1 else chord
            next_root_pc = self._name_to_pc(self._get(next_chord, "root_name", "C"))
            next_root_midi = (octave + 1) * 12 + next_root_pc

            chord_notes = style_fn(
                root_midi=root_midi,
                quality=quality,
                beat_offset=current_beat,
                beats=beats_per_chord,
                velocity=velocity,
                swing=swing,
                next_root=next_root_midi,
            )
            notes.extend(chord_notes)
            current_beat += beats_per_chord

        return notes

    def get_style_names(self) -> List[str]:
        """List available bass styles."""
        return ["root", "walking", "octave", "syncopated", "arpeggio"]

    # ── Styles ─────────────────────────────────────────────────────

    def _style_root(self, root_midi: int, quality: str, beat_offset: float,
                    beats: float, velocity: int, swing: float,
                    next_root: int) -> List[dict]:
        """Simple root notes — one per chord."""
        return [self._note(root_midi, beat_offset, beats, velocity)]

    def _style_octave(self, root_midi: int, quality: str, beat_offset: float,
                      beats: float, velocity: int, swing: float,
                      next_root: int) -> List[dict]:
        """Root + octave alternation."""
        half = beats / 2
        return [
            self._note(root_midi, beat_offset, half, velocity),
            self._note(root_midi + 12, beat_offset + half, half, int(velocity * 0.85)),
        ]

    def _style_walking(self, root_midi: int, quality: str, beat_offset: float,
                       beats: float, velocity: int, swing: float,
                       next_root: int) -> List[dict]:
        """Walking bass — root, chord tone, passing tone, approach tone.

        Classic jazz/blues walking bass pattern.
        """
        intervals = CHORD_INTERVALS.get(quality, [0, 4, 7])
        step = beats / 4  # quarter notes

        notes_out = []
        # Beat 1: Root (strong)
        notes_out.append(self._note(root_midi, beat_offset, step, velocity))

        # Beat 2: Chord tone (3rd or 5th)
        chord_tone = root_midi + self._rng.choice(intervals[1:]) if len(intervals) > 1 else root_midi
        notes_out.append(self._note(chord_tone, beat_offset + step,
                                     step, int(velocity * 0.85)))

        # Beat 3: Passing tone or another chord tone
        if len(intervals) >= 3:
            passing = root_midi + intervals[2]
        else:
            passing = root_midi + 5  # perfect 4th
        notes_out.append(self._note(passing, beat_offset + 2 * step,
                                     step, int(velocity * 0.80)))

        # Beat 4: Chromatic approach to next root
        approach = self._rng.choice(CHROMATIC_APPROACH)
        approach_note = next_root + approach
        notes_out.append(self._note(approach_note, beat_offset + 3 * step,
                                     step, int(velocity * 0.75)))

        # Apply swing
        if swing > 0:
            notes_out = self._apply_swing(notes_out, beat_offset, step, swing)

        return notes_out

    def _style_syncopated(self, root_midi: int, quality: str, beat_offset: float,
                          beats: float, velocity: int, swing: float,
                          next_root: int) -> List[dict]:
        """Syncopated pattern — offbeat emphasis, rests, ghost notes."""
        intervals = CHORD_INTERVALS.get(quality, [0, 4, 7])
        eighth = beats / 8

        # Syncopated pattern: .X..X.X. (dots = rest, X = note)
        pattern = self._rng.choice([
            [False, True, False, False, True, False, True, False],
            [True, False, False, True, False, True, False, False],
            [False, True, False, True, False, False, True, False],
            [True, False, True, False, False, True, False, True],
        ])

        notes_out = []
        for i, hit in enumerate(pattern):
            if not hit:
                continue
            # Vary pitch between root, 5th, octave
            pitch_choices = [root_midi, root_midi + intervals[-1], root_midi + 12]
            pitch = self._rng.choice(pitch_choices)

            # Ghost notes (lower velocity) on weak beats
            vel = velocity if i in (0, 4) else int(velocity * 0.65)

            t = beat_offset + i * eighth
            notes_out.append(self._note(pitch, t, eighth * 0.9, vel))

        return notes_out

    def _style_arpeggio(self, root_midi: int, quality: str, beat_offset: float,
                        beats: float, velocity: int, swing: float,
                        next_root: int) -> List[dict]:
        """Arpeggio — play chord tones in sequence."""
        intervals = CHORD_INTERVALS.get(quality, [0, 4, 7])
        n = len(intervals)
        step = beats / max(n, 1)

        notes_out = []
        for i, iv in enumerate(intervals):
            pitch = root_midi + iv
            vel = velocity if i == 0 else int(velocity * 0.80)
            notes_out.append(self._note(pitch, beat_offset + i * step,
                                         step * 0.9, vel))

        return notes_out

    # ── Helpers ─────────────────────────────────────────────────────

    def _note(self, pitch: int, start: float, length: float, velocity: int) -> dict:
        """Create a MidiNote-compatible dict."""
        return {
            "pitch": max(0, min(127, pitch)),
            "start_beats": round(max(0.0, start), 4),
            "length_beats": round(max(0.0625, length), 4),
            "velocity": max(1, min(127, velocity)),
        }

    def _apply_swing(self, notes: List[dict], base: float,
                      step: float, amount: float) -> List[dict]:
        """Apply swing timing to notes (delay even-numbered eighth notes)."""
        for n in notes:
            rel = n["start_beats"] - base
            beat_idx = round(rel / (step / 2))
            if beat_idx % 2 == 1:  # offbeat
                n["start_beats"] += step * amount * 0.3
        return notes

    def _name_to_pc(self, name: str) -> int:
        """Convert note name to pitch class."""
        flat_map = {"Db": 1, "Eb": 3, "Fb": 4, "Gb": 6, "Ab": 8, "Bb": 10, "Cb": 11}
        name = name.strip()
        if name in flat_map:
            return flat_map[name]
        try:
            return NOTE_NAMES.index(name)
        except ValueError:
            return 0

    def _get(self, obj, attr: str, default):
        """Get attribute from object or dict."""
        if isinstance(obj, dict):
            return obj.get(attr, default)
        return getattr(obj, attr, default)
