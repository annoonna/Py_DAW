"""sentinel_patterns.py — Pattern Learning (Phase S8).

v0.0.20.905 — Phase S8 der SENTINEL_ROADMAP.

Lernt aus vergangenen Crashes und Anomalien:
- Crash-Precursor-Analyse: Was passierte in den 60s VOR einem Crash?
- Echtzeit-Pattern-Matching: Warnt wenn bekannte Muster auftreten
- False-Positive-Learning: Reduziert Confidence nach User-Feedback
- Export/Import: Patterns als JSON teilen (Community)
"""

from __future__ import annotations

import json
import logging
import time
from collections import defaultdict
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


class SentinelPatternLearner:
    """Learns from past crashes and anomalies to predict future problems.

    Analyses blackbox data from crash reports to find recurring patterns
    (precursors) that precede crashes. Then matches these patterns against
    the current system state in real-time.

    Design principles:
    - NEVER auto-act above Stufe 3 based on patterns alone
    - Only WARN the user — patterns are heuristic, not proof
    - User can mark any pattern as false positive
    - After 3x false positive, pattern is auto-disabled
    """

    _instance: Optional["SentinelPatternLearner"] = None

    @classmethod
    def get(cls) -> "SentinelPatternLearner":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db = None
        self._recorder = None
        self._anomaly = None
        self._running = False
        # Cache of active patterns for fast matching
        self._active_patterns: List[dict] = []
        self._last_pattern_reload: float = 0.0
        self._pattern_reload_interval: float = 60.0  # reload every 60s

    def start(self, recorder=None, anomaly_detector=None) -> None:
        """Start pattern learner with references to recorder + anomaly."""
        self._recorder = recorder
        self._anomaly = anomaly_detector
        try:
            from pydaw.services.sentinel_db import SentinelDB
            self._db = SentinelDB.get()
            self._db.ensure_loaded()
        except Exception as exc:
            log.debug("[SENTINEL] PatternLearner: DB not available: %s", exc)
        self._running = True
        self._reload_patterns()
        log.info("[SENTINEL] PatternLearner started (%d active patterns)",
                 len(self._active_patterns))

    def stop(self) -> None:
        self._running = False

    # ══════════════════════════════════════════════════════════════
    # Crash-Precursor Analysis (called after each crash)
    # ══════════════════════════════════════════════════════════════

    def analyze_crash(self, crash_id: int) -> Optional[dict]:
        """Analyse blackbox data from a crash report and extract patterns.

        Called automatically after SentinelCrashAnalyzer generates a report.
        Looks at the 60s of blackbox data preceding the crash to find
        recurring conditions (high CPU, memory leak, specific plugin, etc.).

        Returns the extracted pattern dict or None.
        """
        if not self._db:
            return None

        crashes = self._db.get_crashes(limit=50)
        crash = None
        for c in crashes:
            if c.get("id") == crash_id:
                crash = c
                break
        if not crash:
            return None

        blackbox = {}
        try:
            bb_raw = crash.get("blackbox_json", "{}")
            blackbox = json.loads(bb_raw) if isinstance(bb_raw, str) else bb_raw
        except (json.JSONDecodeError, TypeError):
            pass

        conditions = self._extract_conditions(crash, blackbox)
        if not conditions:
            return None

        # Check if a similar pattern already exists
        existing = self._find_similar_pattern(conditions, crash.get("crash_type", ""))
        if existing:
            # Increment occurrences + boost confidence
            pid = existing["id"]
            self._db.increment_pattern(pid)
            new_conf = min(0.95, existing.get("confidence", 0.5) + 0.1)
            self._update_pattern_confidence(pid, new_conf)
            log.info("[SENTINEL] Pattern #%d reinforced (occurrences +1, "
                     "confidence → %.2f)", pid, new_conf)
            self._reload_patterns()
            return existing

        # Create new pattern
        description = self._generate_description(crash, conditions)
        prevention = self._generate_prevention(crash, conditions)
        pattern_id = self._db.save_pattern(
            pattern_type="crash_precursor",
            description=description,
            conditions=conditions,
            confidence=0.4,  # Start low — needs confirmation
            prevention=prevention,
        )
        log.info("[SENTINEL] New pattern #%d learned: %s", pattern_id, description)
        self._reload_patterns()
        return {
            "id": pattern_id,
            "pattern_type": "crash_precursor",
            "description": description,
            "conditions": conditions,
            "confidence": 0.4,
        }

    def _extract_conditions(self, crash: dict, blackbox: dict) -> dict:
        """Extract precursor conditions from crash + blackbox data."""
        conditions: Dict[str, Any] = {}

        crash_type = crash.get("crash_type", "unknown")
        component = crash.get("component", "")
        conditions["crash_type"] = crash_type
        conditions["component"] = component

        # System state conditions
        sys_state = {}
        try:
            raw = crash.get("system_state", "{}")
            sys_state = json.loads(raw) if isinstance(raw, str) else raw
        except (json.JSONDecodeError, TypeError):
            pass

        cpu = sys_state.get("cpu_percent", 0)
        mem = sys_state.get("memory_mb", 0)
        if cpu > 60:
            conditions["high_cpu"] = True
            conditions["cpu_threshold"] = int(cpu)
        if mem > 2000:
            conditions["high_memory"] = True
            conditions["memory_threshold"] = int(mem)

        # Track/plugin state
        track_state = {}
        try:
            raw = crash.get("track_state", "{}")
            track_state = json.loads(raw) if isinstance(raw, str) else raw
        except (json.JSONDecodeError, TypeError):
            pass

        if isinstance(track_state, dict):
            track_count = track_state.get("track_count", 0)
            plugin_names = track_state.get("plugin_names", [])
            if track_count > 16:
                conditions["many_tracks"] = True
                conditions["track_count"] = track_count
            if plugin_names:
                conditions["plugins_active"] = plugin_names[:10]

        # Blackbox metrics summary
        if blackbox:
            metrics = blackbox.get("metrics", [])
            if isinstance(metrics, list):
                cpu_values = [m.get("cpu_percent", 0) for m in metrics
                              if isinstance(m, dict) and "cpu_percent" in m]
                if cpu_values:
                    avg_cpu = sum(cpu_values) / len(cpu_values)
                    max_cpu = max(cpu_values)
                    if avg_cpu > 50:
                        conditions["avg_cpu_before_crash"] = round(avg_cpu, 1)
                    if max_cpu > 80:
                        conditions["peak_cpu_before_crash"] = round(max_cpu, 1)

            collab = blackbox.get("collab_rates", {})
            if isinstance(collab, dict):
                for op, rate in collab.items():
                    if isinstance(rate, (int, float)) and rate > 10:
                        conditions.setdefault("high_collab_rates", {})[op] = rate

        return conditions

    def _find_similar_pattern(self, conditions: dict, crash_type: str) -> Optional[dict]:
        """Find an existing pattern matching these conditions."""
        if not self._db:
            return None
        patterns = self._db.get_patterns(pattern_type="crash_precursor", limit=200)
        for p in patterns:
            try:
                p_cond = json.loads(p.get("conditions_json", "{}"))
            except (json.JSONDecodeError, TypeError):
                continue
            # Match if same crash_type + component
            if (p_cond.get("crash_type") == conditions.get("crash_type") and
                    p_cond.get("component") == conditions.get("component")):
                return p
        return None

    def _generate_description(self, crash: dict, conditions: dict) -> str:
        """Generate human-readable description of the pattern."""
        parts = []
        ct = conditions.get("crash_type", "unknown")
        comp = conditions.get("component", "unknown")
        parts.append(f"{ct} in {comp}")

        if conditions.get("high_cpu"):
            parts.append(f"CPU > {conditions.get('cpu_threshold', 60)}%")
        if conditions.get("high_memory"):
            parts.append(f"Memory > {conditions.get('memory_threshold', 2000)} MB")
        if conditions.get("many_tracks"):
            parts.append(f"> {conditions.get('track_count', 16)} Tracks")
        plugins = conditions.get("plugins_active", [])
        if plugins:
            parts.append(f"Plugins: {', '.join(plugins[:3])}")

        return " | ".join(parts)

    def _generate_prevention(self, crash: dict, conditions: dict) -> str:
        """Generate prevention recommendation."""
        tips = []
        ct = conditions.get("crash_type", "")
        if ct == "echo_loop":
            tips.append("Collab device_sync Cooldown erhoehen")
        elif ct == "segfault":
            comp = conditions.get("component", "")
            if "plugin" in comp:
                tips.append("Plugin in Sandbox laden oder alternatives Plugin nutzen")
            else:
                tips.append("Projekt speichern und DAW neu starten")
        elif ct == "exception":
            tips.append("Bug-Report erstellen (Crashlog exportieren)")
        if conditions.get("high_cpu"):
            tips.append("Tracks einfrieren oder Plugin-Count reduzieren")
        if conditions.get("high_memory"):
            tips.append("Sample-Pools reduzieren oder Projekt aufteilen")
        return "; ".join(tips) if tips else "Projekt speichern und Bug-Report erstellen"

    def _update_pattern_confidence(self, pattern_id: int, confidence: float) -> None:
        """Update confidence of a pattern."""
        if not self._db:
            return
        try:
            conn = self._db._conn()
            try:
                conn.execute(
                    "UPDATE sentinel_patterns SET confidence=? WHERE id=?",
                    (confidence, pattern_id),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════
    # Real-Time Pattern Matching
    # ══════════════════════════════════════════════════════════════

    def check_current_state(self) -> List[dict]:
        """Check if current system state matches any known crash patterns.

        Returns list of matched patterns with match_score.
        Only patterns with confidence >= 0.5 are checked.
        Maximum severity from pattern matching: Stufe 3 (warning).
        """
        if not self._running or not self._db:
            return []

        # Periodically reload patterns from DB
        now = time.time()
        if now - self._last_pattern_reload > self._pattern_reload_interval:
            self._reload_patterns()

        if not self._active_patterns:
            return []

        # Get current state
        current = self._get_current_conditions()
        if not current:
            return []

        matches = []
        for pattern in self._active_patterns:
            score = self._match_score(pattern, current)
            if score >= 0.5:
                matches.append({
                    "pattern_id": pattern.get("id"),
                    "description": pattern.get("description", ""),
                    "confidence": pattern.get("confidence", 0),
                    "match_score": round(score, 2),
                    "prevention": pattern.get("prevention", ""),
                    "occurrences": pattern.get("occurrences", 1),
                    # Max severity 3 from pattern matching — NEVER auto-act
                    "severity": min(3, 2 if score < 0.8 else 3),
                })
        return matches

    def _get_current_conditions(self) -> dict:
        """Build conditions dict from current system state."""
        conditions: Dict[str, Any] = {}
        if self._recorder:
            try:
                bb = self._recorder.get_blackbox()
                sys_state = bb.get("system_state", {})
                cpu = sys_state.get("cpu_percent", 0)
                mem = sys_state.get("memory_mb", 0)
                if cpu > 60:
                    conditions["high_cpu"] = True
                    conditions["cpu_threshold"] = int(cpu)
                if mem > 2000:
                    conditions["high_memory"] = True
                    conditions["memory_threshold"] = int(mem)

                collab = bb.get("collab_rates", {})
                if isinstance(collab, dict):
                    for op, rate in collab.items():
                        if isinstance(rate, (int, float)) and rate > 10:
                            conditions.setdefault("high_collab_rates", {})[op] = rate
            except Exception:
                pass
        return conditions

    def _match_score(self, pattern: dict, current: dict) -> float:
        """Calculate how well current state matches a pattern (0..1)."""
        try:
            p_cond = json.loads(pattern.get("conditions_json", "{}"))
        except (json.JSONDecodeError, TypeError):
            return 0.0

        total_checks = 0
        matched = 0

        # CPU check
        if p_cond.get("high_cpu"):
            total_checks += 1
            if current.get("high_cpu"):
                matched += 1

        # Memory check
        if p_cond.get("high_memory"):
            total_checks += 1
            if current.get("high_memory"):
                matched += 1

        # Collab rate check
        p_collab = p_cond.get("high_collab_rates", {})
        c_collab = current.get("high_collab_rates", {})
        if p_collab:
            total_checks += 1
            for op in p_collab:
                if op in c_collab:
                    matched += 1
                    break

        # Many tracks
        if p_cond.get("many_tracks"):
            total_checks += 1
            # Can't check track count from recorder alone — skip or partial
            # We give a 0.5 partial match as we can't confirm/deny
            matched += 0.3

        if total_checks == 0:
            return 0.0

        raw_score = matched / total_checks
        # Weight by pattern confidence
        confidence = pattern.get("confidence", 0.5)
        return raw_score * confidence

    def _reload_patterns(self) -> None:
        """Reload active patterns from DB."""
        self._last_pattern_reload = time.time()
        if not self._db:
            self._active_patterns = []
            return
        try:
            all_patterns = self._db.get_patterns(limit=200)
            # Only keep crash_precursor patterns with confidence >= 0.3
            self._active_patterns = [
                p for p in all_patterns
                if p.get("pattern_type") == "crash_precursor"
                and p.get("confidence", 0) >= 0.3
                and p.get("auto_action", "warn") != "none"
            ]
        except Exception:
            self._active_patterns = []

    # ══════════════════════════════════════════════════════════════
    # False-Positive Learning
    # ══════════════════════════════════════════════════════════════

    def mark_false_positive(self, pattern_id: int) -> None:
        """User marks a pattern warning as false positive.

        Reduces confidence. After 3x false positive for same pattern,
        the pattern is auto-disabled (auto_action → 'none').
        """
        if not self._db:
            return

        patterns = self._db.get_patterns(limit=500)
        pattern = None
        for p in patterns:
            if p.get("id") == pattern_id:
                pattern = p
                break

        if not pattern:
            return

        old_conf = pattern.get("confidence", 0.5)
        new_conf = max(0.0, old_conf - 0.2)

        # Count false positives from anomaly history
        fp_count = self._count_false_positives_for_pattern(pattern_id)
        fp_count += 1  # including this one

        if fp_count >= 3:
            # Disable pattern after 3x false positive
            self._disable_pattern(pattern_id)
            log.info("[SENTINEL] Pattern #%d disabled after %d false positives",
                     pattern_id, fp_count)
        else:
            self._update_pattern_confidence(pattern_id, new_conf)
            log.info("[SENTINEL] Pattern #%d confidence reduced: %.2f → %.2f "
                     "(false positives: %d/3)",
                     pattern_id, old_conf, new_conf, fp_count)

        self._reload_patterns()

    def _count_false_positives_for_pattern(self, pattern_id: int) -> int:
        """Count how many times this pattern was marked as false positive."""
        if not self._db:
            return 0
        try:
            anomalies = self._db.get_anomaly_history(limit=500)
            count = 0
            for a in anomalies:
                if (a.get("false_positive") == 1 and
                        a.get("anomaly_type") == "crash_pattern"):
                    try:
                        evidence = json.loads(a.get("evidence_json", "{}"))
                        if evidence.get("pattern_id") == pattern_id:
                            count += 1
                    except (json.JSONDecodeError, TypeError):
                        pass
            return count
        except Exception:
            return 0

    def _disable_pattern(self, pattern_id: int) -> None:
        """Disable a pattern (set auto_action to 'none')."""
        if not self._db:
            return
        try:
            conn = self._db._conn()
            try:
                conn.execute(
                    "UPDATE sentinel_patterns SET auto_action='none', confidence=0.0 WHERE id=?",
                    (pattern_id,),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════
    # Export/Import
    # ══════════════════════════════════════════════════════════════

    def export_patterns(self, filepath: str = "") -> str:
        """Export all patterns as JSON string.

        If filepath is given, also writes to file.
        Returns the JSON string.
        """
        if not self._db:
            return "[]"

        patterns = self._db.get_patterns(limit=500)
        # Sanitize: remove internal IDs, keep relevant data
        export_data = []
        for p in patterns:
            entry = {
                "pattern_type": p.get("pattern_type", ""),
                "description": p.get("description", ""),
                "conditions": {},
                "confidence": p.get("confidence", 0),
                "occurrences": p.get("occurrences", 1),
                "prevention": p.get("prevention", ""),
                "auto_action": p.get("auto_action", "warn"),
            }
            try:
                entry["conditions"] = json.loads(p.get("conditions_json", "{}"))
            except (json.JSONDecodeError, TypeError):
                pass
            export_data.append(entry)

        json_str = json.dumps(export_data, indent=2, ensure_ascii=False)

        if filepath:
            try:
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write(json_str)
                log.info("[SENTINEL] Exported %d patterns to %s",
                         len(export_data), filepath)
            except Exception as exc:
                log.warning("[SENTINEL] Pattern export failed: %s", exc)

        return json_str

    def import_patterns(self, json_str: str = "", filepath: str = "") -> int:
        """Import patterns from JSON string or file.

        Returns count of imported patterns.
        Duplicates (same description) are skipped.
        """
        if not self._db:
            return 0

        data = []
        if filepath:
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    json_str = f.read()
            except Exception as exc:
                log.warning("[SENTINEL] Pattern import read failed: %s", exc)
                return 0

        try:
            data = json.loads(json_str)
        except (json.JSONDecodeError, TypeError):
            log.warning("[SENTINEL] Pattern import: invalid JSON")
            return 0

        if not isinstance(data, list):
            return 0

        # Get existing descriptions for dedup
        existing = self._db.get_patterns(limit=500)
        existing_descs = {p.get("description", "") for p in existing}

        imported = 0
        for entry in data:
            if not isinstance(entry, dict):
                continue
            desc = entry.get("description", "")
            if not desc or desc in existing_descs:
                continue

            conditions = entry.get("conditions", {})
            if not isinstance(conditions, dict):
                continue

            # Import with reduced confidence (community patterns start low)
            confidence = min(0.5, entry.get("confidence", 0.3))

            self._db.save_pattern(
                pattern_type=entry.get("pattern_type", "crash_precursor"),
                description=desc,
                conditions=conditions,
                confidence=confidence,
                prevention=entry.get("prevention", ""),
            )
            existing_descs.add(desc)
            imported += 1

        if imported:
            self._reload_patterns()
            log.info("[SENTINEL] Imported %d patterns", imported)

        return imported
