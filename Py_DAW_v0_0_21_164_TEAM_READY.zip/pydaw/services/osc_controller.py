"""Extended OSC Controller Protocol (P4B) — DAW control via TouchOSC/Lemur.

Extends osc_midi_input.py with full DAW control addresses:
  /transport/play, /transport/stop, /transport/record, /transport/bpm
  /track/{id}/volume, /track/{id}/pan, /track/{id}/mute, /track/{id}/solo
  /clip/launch/{scene}/{track}, /scene/launch/{scene}
  /mixer/master/volume
  /fx/{track_id}/{slot}/param/{name}

Bidirectional: sends feedback to the OSC client for UI updates.

v0.0.20.810 — Phase P4B
"""

from __future__ import annotations

import logging
import threading
from typing import Optional, Dict, Any, Callable

from PyQt6.QtCore import QObject, pyqtSignal, QTimer

log = logging.getLogger(__name__)

try:
    from pythonosc import dispatcher as osc_dispatcher  # type: ignore
    from pythonosc import osc_server, udp_client  # type: ignore
    _HAS_OSC = True
except ImportError:
    _HAS_OSC = False


class OscController(QObject):
    """Full DAW control via OSC protocol.

    Receives OSC messages for transport, mixer, clip launcher.
    Sends feedback to the client for LED/fader updates.
    """

    status = pyqtSignal(str)
    error = pyqtSignal(str)

    def __init__(
        self,
        transport=None,
        project_service=None,
        clip_launcher=None,
        midi_manager=None,
        listen_port: int = 9000,
        feedback_port: int = 9001,
        feedback_host: str = "127.0.0.1",
        parent: Optional[QObject] = None,
    ):
        super().__init__(parent)
        self._transport = transport
        self._project = project_service
        self._launcher = clip_launcher
        self._midi_manager = midi_manager
        self._listen_port = listen_port
        self._feedback_port = feedback_port
        self._feedback_host = feedback_host

        self._server = None
        self._thread = None
        self._client = None  # feedback client
        self._running = False

        # Feedback timer (30 Hz)
        self._feedback_timer = QTimer(self)
        self._feedback_timer.setInterval(33)
        self._feedback_timer.timeout.connect(self._send_feedback)

    @staticmethod
    def is_available() -> bool:
        return bool(_HAS_OSC)

    def start(self, listen_port: int = 0, feedback_host: str = "",
              feedback_port: int = 0) -> bool:
        """Start the OSC server and feedback client."""
        if not _HAS_OSC:
            try:
                self.error.emit("OSC: python-osc nicht installiert (pip install python-osc)")
            except Exception:
                pass
            return False

        if self._running:
            self.stop()

        if listen_port > 0:
            self._listen_port = listen_port
        if feedback_host:
            self._feedback_host = feedback_host
        if feedback_port > 0:
            self._feedback_port = feedback_port

        try:
            disp = osc_dispatcher.Dispatcher()

            # Transport
            disp.map("/transport/play", self._on_play)
            disp.map("/transport/stop", self._on_stop)
            disp.map("/transport/record", self._on_record)
            disp.map("/transport/bpm", self._on_bpm)
            disp.map("/transport/position", self._on_position)

            # Mixer
            disp.map("/track/*/volume", self._on_track_volume)
            disp.map("/track/*/pan", self._on_track_pan)
            disp.map("/track/*/mute", self._on_track_mute)
            disp.map("/track/*/solo", self._on_track_solo)
            disp.map("/mixer/master/volume", self._on_master_volume)

            # Clip Launcher
            disp.map("/clip/launch/*/*", self._on_clip_launch)
            disp.map("/scene/launch/*", self._on_scene_launch)

            # MIDI note passthrough
            disp.map("/note/on", self._on_note_on)
            disp.map("/note/off", self._on_note_off)
            disp.map("/cc", self._on_cc)

            disp.set_default_handler(self._on_unknown)

            self._server = osc_server.ThreadingOSCUDPServer(
                ("0.0.0.0", self._listen_port), disp
            )
            self._thread = threading.Thread(
                target=self._server.serve_forever, daemon=True
            )
            self._running = True
            self._thread.start()

            # Feedback client
            try:
                self._client = udp_client.SimpleUDPClient(
                    self._feedback_host, self._feedback_port
                )
            except Exception:
                self._client = None

            self._feedback_timer.start()

            try:
                self.status.emit(
                    f"OSC Controller: Listen :{self._listen_port}, "
                    f"Feedback → {self._feedback_host}:{self._feedback_port}"
                )
            except Exception:
                pass
            return True

        except Exception as exc:
            try:
                self.error.emit(f"OSC Controller: Start fehlgeschlagen: {exc}")
            except Exception:
                pass
            return False

    def stop(self) -> None:
        """Stop server and feedback."""
        self._running = False
        self._feedback_timer.stop()
        if self._server:
            try:
                self._server.shutdown()
            except Exception:
                pass
            self._server = None
        if self._thread:
            try:
                self._thread.join(timeout=1.0)
            except Exception:
                pass
            self._thread = None
        self._client = None

    # ── Transport handlers ────────────────────────────────────────────────

    def _on_play(self, address: str, *args) -> None:
        t = self._transport
        if t:
            try: t.play()
            except Exception: pass

    def _on_stop(self, address: str, *args) -> None:
        t = self._transport
        if t:
            try: t.stop()
            except Exception: pass

    def _on_record(self, address: str, *args) -> None:
        t = self._transport
        if t:
            try: t.toggle_record()
            except Exception: pass

    def _on_bpm(self, address: str, *args) -> None:
        if args:
            t = self._transport
            if t:
                handled = False
                ps = self._project
                if ps and hasattr(ps, 'slice0_command_set_bpm'):
                    try:
                        ps.slice0_command_set_bpm(float(args[0]), transport=t)
                        handled = True
                    except Exception:
                        handled = False
                if not handled:
                    try: t.set_bpm(float(args[0]))
                    except Exception: pass

    def _on_position(self, address: str, *args) -> None:
        if args:
            t = self._transport
            if t:
                try: t.seek(float(args[0]))
                except Exception: pass

    # ── Mixer handlers ────────────────────────────────────────────────────

    def _extract_track_index(self, address: str) -> int:
        """Extract track index from /track/{index}/param address."""
        import re
        m = re.search(r"/track/(\d+)/", address)
        return int(m.group(1)) if m else -1

    def _get_track(self, index: int):
        """Get track object by index."""
        ps = self._project
        proj = getattr(getattr(ps, 'ctx', None), 'project', None) if ps else None
        if proj is None:
            proj = getattr(ps, 'project', None)
        if proj is None:
            return None
        tracks = getattr(proj, 'tracks', [])
        if 0 <= index < len(tracks):
            return tracks[index]
        return None

    def _on_track_volume(self, address: str, *args) -> None:
        idx = self._extract_track_index(address)
        if idx >= 0 and args:
            track = self._get_track(idx)
            if track:
                track.volume = max(0.0, min(1.0, float(args[0])))

    def _on_track_pan(self, address: str, *args) -> None:
        idx = self._extract_track_index(address)
        if idx >= 0 and args:
            track = self._get_track(idx)
            if track:
                track.pan = max(-1.0, min(1.0, float(args[0])))

    def _on_track_mute(self, address: str, *args) -> None:
        idx = self._extract_track_index(address)
        if idx >= 0 and args:
            track = self._get_track(idx)
            if track:
                track.muted = bool(int(args[0]))

    def _on_track_solo(self, address: str, *args) -> None:
        idx = self._extract_track_index(address)
        if idx >= 0 and args:
            track = self._get_track(idx)
            if track:
                track.solo = bool(int(args[0]))

    def _on_master_volume(self, address: str, *args) -> None:
        if args:
            ps = self._project
            proj = getattr(getattr(ps, 'ctx', None), 'project', None) if ps else None
            if proj is None:
                proj = getattr(ps, 'project', None)
            if proj:
                master = getattr(proj, 'master_volume', None)
                if master is not None:
                    proj.master_volume = max(0.0, min(1.0, float(args[0])))

    # ── Clip Launcher handlers ────────────────────────────────────────────

    def _on_clip_launch(self, address: str, *args) -> None:
        import re
        m = re.search(r"/clip/launch/(\d+)/(\d+)", address)
        if m and self._launcher:
            scene = int(m.group(1))
            track = int(m.group(2))
            try:
                self._launcher.launch_clip_at(track, scene)
            except Exception:
                pass

    def _on_scene_launch(self, address: str, *args) -> None:
        import re
        m = re.search(r"/scene/launch/(\d+)", address)
        if m and self._launcher:
            try:
                self._launcher.launch_scene(int(m.group(1)))
            except Exception:
                pass

    # ── MIDI passthrough ──────────────────────────────────────────────────

    def _on_note_on(self, address: str, *args) -> None:
        if len(args) >= 2 and self._midi_manager:
            try:
                import mido
                msg = mido.Message("note_on", note=int(args[0]),
                                   velocity=int(args[1]),
                                   channel=int(args[2]) if len(args) > 2 else 0)
                self._midi_manager.inject_message(msg, source="osc_ctrl")
            except Exception:
                pass

    def _on_note_off(self, address: str, *args) -> None:
        if len(args) >= 1 and self._midi_manager:
            try:
                import mido
                msg = mido.Message("note_off", note=int(args[0]),
                                   velocity=0,
                                   channel=int(args[1]) if len(args) > 1 else 0)
                self._midi_manager.inject_message(msg, source="osc_ctrl")
            except Exception:
                pass

    def _on_cc(self, address: str, *args) -> None:
        if len(args) >= 2 and self._midi_manager:
            try:
                import mido
                msg = mido.Message("control_change", control=int(args[0]),
                                   value=int(args[1]),
                                   channel=int(args[2]) if len(args) > 2 else 0)
                self._midi_manager.inject_message(msg, source="osc_ctrl")
            except Exception:
                pass

    def _on_unknown(self, address: str, *args) -> None:
        """Log unknown OSC addresses for debugging."""
        log.debug("OSC unknown: %s %s", address, args)

    # ── Feedback ──────────────────────────────────────────────────────────

    def _send_feedback(self) -> None:
        """Send current state back to OSC client (30 Hz)."""
        client = self._client
        if client is None:
            return

        try:
            # Transport
            t = self._transport
            if t:
                try:
                    client.send_message("/transport/playing",
                                        1 if getattr(t, 'is_playing', False) else 0)
                    client.send_message("/transport/recording",
                                        1 if getattr(t, 'is_recording', False) else 0)
                    client.send_message("/transport/bpm",
                                        float(getattr(t, 'bpm', 120)))
                    client.send_message("/transport/position",
                                        float(getattr(t, 'position_beats', 0)))
                except Exception:
                    pass

            # Track levels (first 8)
            ps = self._project
            proj = getattr(getattr(ps, 'ctx', None), 'project', None) if ps else None
            if proj is None:
                proj = getattr(ps, 'project', None)
            if proj:
                tracks = getattr(proj, 'tracks', [])
                for i, track in enumerate(tracks[:16]):
                    try:
                        client.send_message(f"/track/{i}/volume",
                                            float(getattr(track, 'volume', 0.8)))
                        client.send_message(f"/track/{i}/mute",
                                            1 if getattr(track, 'muted', False) else 0)
                    except Exception:
                        pass
        except Exception:
            pass

    def shutdown(self) -> None:
        self.stop()
