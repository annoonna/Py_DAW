"""Rust vs Python Performance Benchmark — v0.0.21.056 (R9.3 + R9.5).

R9.3: Compares Rust engine vs Python engine performance.
R9.5: Automated release test with 20+ tracks stress test.

Usage:
    from pydaw.services.rust_performance_benchmark import (
        RustPerformanceBenchmark, ReleaseTestRunner
    )

    bench = RustPerformanceBenchmark(bridge)
    bench.run_comparison()  # Prints A/B comparison

    test = ReleaseTestRunner(bridge, project_service)
    test.run_20_track_stress_test()  # Pass/Fail
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from pydaw.services.rust_engine_bridge import RustEngineBridge

log = logging.getLogger(__name__)


class BenchmarkResult:
    """Container for benchmark data from one engine mode."""

    def __init__(self, mode: str = "unknown"):
        self.mode = mode
        self.avg_render_us: float = 0.0
        self.p95_render_us: float = 0.0
        self.p99_render_us: float = 0.0
        self.cpu_load: float = 0.0
        self.xrun_count: int = 0
        self.buffer_size: int = 512
        self.sample_rate: int = 48000
        self.active_tracks: int = 0
        self.active_plugins: int = 0
        self.duration_secs: float = 0.0

    @property
    def budget_us(self) -> float:
        """Buffer time budget in microseconds."""
        if self.sample_rate == 0:
            return 0.0
        return (self.buffer_size / self.sample_rate) * 1_000_000

    @property
    def headroom_pct(self) -> float:
        """Remaining headroom as percentage."""
        b = self.budget_us
        if b <= 0:
            return 0.0
        return max(0.0, (1.0 - self.avg_render_us / b) * 100.0)

    def from_event(self, event: dict) -> "BenchmarkResult":
        """Populate from PerformanceBenchmark event."""
        self.avg_render_us = event.get("avg_render_us", 0.0)
        self.p95_render_us = event.get("p95_render_us", 0.0)
        self.p99_render_us = event.get("p99_render_us", 0.0)
        self.cpu_load = event.get("cpu_load", 0.0)
        self.xrun_count = event.get("xrun_count", 0)
        self.buffer_size = event.get("buffer_size", 512)
        self.sample_rate = event.get("sample_rate", 48000)
        self.active_tracks = event.get("active_tracks", 0)
        self.active_plugins = event.get("active_plugins", 0)
        self.duration_secs = event.get("duration_secs", 0.0)
        return self

    def format_report(self) -> str:
        """Format as readable report string."""
        lines = [
            f"=== {self.mode} Engine Benchmark ===",
            f"  Tracks:       {self.active_tracks}",
            f"  Plugins:      {self.active_plugins}",
            f"  Sample Rate:  {self.sample_rate} Hz",
            f"  Buffer Size:  {self.buffer_size} frames",
            f"  Budget:       {self.budget_us:.0f} µs",
            f"  Avg Render:   {self.avg_render_us:.0f} µs",
            f"  P95 Render:   {self.p95_render_us:.0f} µs",
            f"  P99 Render:   {self.p99_render_us:.0f} µs",
            f"  CPU Load:     {self.cpu_load * 100:.1f}%",
            f"  Headroom:     {self.headroom_pct:.1f}%",
            f"  XRuns:        {self.xrun_count}",
        ]
        return "\n".join(lines)


class RustPerformanceBenchmark:
    """A/B comparison: Rust engine vs Python engine.

    Measures CPU load, render time, xruns for both modes.
    """

    def __init__(self, bridge: "RustEngineBridge"):
        self._bridge = bridge
        self._result: Optional[BenchmarkResult] = None
        self._waiting = False

        try:
            bridge.generic_event.connect(self._on_event)
        except Exception:
            pass

    def request_rust_benchmark(self) -> None:
        """Request benchmark data from Rust engine."""
        self._waiting = True
        self._result = None
        self._bridge.request_benchmark()
        log.info("Rust benchmark requested")

    def get_python_benchmark(self) -> BenchmarkResult:
        """Measure Python engine performance via CPU timing.

        This uses the Python audio engine's internal metrics.
        """
        result = BenchmarkResult(mode="Python")
        try:
            from pydaw.core.audio_backend_switch import audio_switch
            if audio_switch.is_python():
                # Try to get render stats from audio engine
                try:
                    from pydaw.audio.audio_engine import get_engine_stats
                    stats = get_engine_stats()
                    result.avg_render_us = stats.get("avg_render_us", 0.0)
                    result.cpu_load = stats.get("cpu_load", 0.0)
                    result.xrun_count = stats.get("xrun_count", 0)
                    result.buffer_size = stats.get("buffer_size", 512)
                    result.sample_rate = stats.get("sample_rate", 48000)
                    result.active_tracks = stats.get("active_tracks", 0)
                except Exception:
                    log.debug("Python engine stats not available")
        except Exception:
            pass
        return result

    def _on_event(self, event: dict):
        """Handle PerformanceBenchmark event."""
        if event.get("type") != "PerformanceBenchmark":
            return
        self._result = BenchmarkResult(mode="Rust").from_event(event)
        self._waiting = False
        log.info("Rust benchmark received:\n%s", self._result.format_report())

    def run_comparison(self) -> str:
        """Run full A/B comparison and return formatted report."""
        py_result = self.get_python_benchmark()
        self.request_rust_benchmark()

        # Wait for Rust result (up to 5 seconds)
        deadline = time.time() + 5.0
        while self._waiting and time.time() < deadline:
            time.sleep(0.1)

        rust_result = self._result or BenchmarkResult(mode="Rust (no data)")

        lines = [
            "╔══════════════════════════════════════════════╗",
            "║  Py_DAW Engine Performance Comparison (R9.3) ║",
            "╚══════════════════════════════════════════════╝",
            "",
            py_result.format_report(),
            "",
            rust_result.format_report(),
            "",
            "--- Comparison ---",
        ]

        if rust_result.avg_render_us > 0 and py_result.avg_render_us > 0:
            speedup = py_result.avg_render_us / rust_result.avg_render_us
            lines.append(f"  Rust is {speedup:.1f}x faster (avg render time)")
        if rust_result.cpu_load > 0 and py_result.cpu_load > 0:
            reduction = (1.0 - rust_result.cpu_load / py_result.cpu_load) * 100
            lines.append(f"  CPU reduction: {reduction:.0f}%")

        report = "\n".join(lines)
        log.info("\n%s", report)
        return report


class ReleaseTestRunner:
    """Automated release test with 20+ tracks (R9.5).

    Verifies Rust engine stability under realistic load.
    """

    def __init__(self, bridge: "RustEngineBridge", project_service=None):
        self._bridge = bridge
        self._project = project_service
        self._errors: list[str] = []
        self._passed: list[str] = []

    def run_20_track_stress_test(self) -> dict:
        """Run stress test with 20+ tracks.

        Returns dict with pass/fail results per test.
        """
        results = {
            "test": "R9.5 Release Test — 20+ Tracks",
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "checks": [],
        }

        # 1. Verify engine is running
        self._check(results, "Engine connection",
                    self._bridge.is_connected if hasattr(self._bridge, 'is_connected') else True)

        # 2. Send benchmark request and check response
        bench = RustPerformanceBenchmark(self._bridge)
        bench.request_rust_benchmark()
        # v0.0.21.057: Poll instead of blocking sleep (Qt event loop friendly)
        rust_data = None
        for _poll in range(20):
            time.sleep(0.1)
            try:
                from PyQt6.QtCore import QCoreApplication
                QCoreApplication.processEvents()
            except Exception:
                pass
            if bench._result is not None:
                rust_data = bench._result
                break

        self._check(results, "Benchmark response received", rust_data is not None)

        if rust_data:
            # 3. Check CPU load under threshold
            self._check(results, f"CPU load < 80% (actual: {rust_data.cpu_load*100:.1f}%)",
                        rust_data.cpu_load < 0.8)

            # 4. Check no xruns
            self._check(results, f"XRuns = 0 (actual: {rust_data.xrun_count})",
                        rust_data.xrun_count == 0)

            # 5. Check render time within budget
            self._check(results, f"Render time < budget ({rust_data.avg_render_us:.0f} < {rust_data.budget_us:.0f} µs)",
                        rust_data.avg_render_us < rust_data.budget_us)

            # 6. Check headroom
            self._check(results, f"Headroom > 20% (actual: {rust_data.headroom_pct:.1f}%)",
                        rust_data.headroom_pct > 20.0)

            # 7. Track count check
            self._check(results, f"Active tracks >= 20 (actual: {rust_data.active_tracks})",
                        rust_data.active_tracks >= 20)

        # 8. Transport operations
        try:
            self._bridge.send_command({"cmd": "Play"})
            time.sleep(0.5)
            self._bridge.send_command({"cmd": "Stop"})
            self._check(results, "Transport Play/Stop", True)
        except Exception as e:
            self._check(results, f"Transport Play/Stop: {e}", False)

        # 9. Seek test
        try:
            self._bridge.send_command({"cmd": "Seek", "beat": 16.0})
            time.sleep(0.2)
            self._check(results, "Transport Seek", True)
        except Exception as e:
            self._check(results, f"Transport Seek: {e}", False)

        # Summary
        total = len(results["checks"])
        passed = sum(1 for c in results["checks"] if c["passed"])
        results["summary"] = f"{passed}/{total} passed"
        results["overall_pass"] = passed == total

        report = self._format_results(results)
        log.info("\n%s", report)
        return results

    def _check(self, results: dict, name: str, passed: bool):
        """Record a test check."""
        results["checks"].append({
            "name": name,
            "passed": passed,
        })
        status = "✅" if passed else "❌"
        log.info("  %s %s", status, name)

    def _format_results(self, results: dict) -> str:
        """Format test results as readable report."""
        lines = [
            "╔═══════════════════════════════════════════╗",
            "║  R9.5 Release Test — 20+ Tracks           ║",
            "╚═══════════════════════════════════════════╝",
            f"  Date: {results['timestamp']}",
            "",
        ]
        for c in results["checks"]:
            s = "✅ PASS" if c["passed"] else "❌ FAIL"
            lines.append(f"  {s}: {c['name']}")
        lines.append("")
        lines.append(f"  Result: {results['summary']}")
        overall = "✅ ALL PASSED" if results.get("overall_pass") else "❌ SOME FAILED"
        lines.append(f"  Overall: {overall}")
        return "\n".join(lines)
