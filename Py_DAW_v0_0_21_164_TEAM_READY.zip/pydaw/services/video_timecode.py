"""video_timecode.py — Professional Timecode Utilities (VE8).

Provides:
  - Frame-accurate SMPTE timecode (HH:MM:SS:FF)
  - Drop-Frame (DF) and Non-Drop-Frame (NDF) modes
  - Timecode offset per clip (external cameras)
  - LTC (Linear Time Code) sync stub
  - Timecode parsing / validation

v0.0.20.946  VE8 Timecode Pro
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Tuple

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Enums & Constants
# ═══════════════════════════════════════════════════════════════

class TimecodeMode(Enum):
    """Timecode display mode."""
    NDF = "ndf"          # Non-Drop-Frame (standard)
    DF = "df"            # Drop-Frame (29.97/59.94 fps)


class FrameRate(Enum):
    """Standard frame rates."""
    FPS_23_976 = 23.976
    FPS_24 = 24.0
    FPS_25 = 25.0
    FPS_29_97 = 29.97
    FPS_30 = 30.0
    FPS_48 = 48.0
    FPS_50 = 50.0
    FPS_59_94 = 59.94
    FPS_60 = 60.0

    @classmethod
    def from_float(cls, fps: float) -> "FrameRate":
        """Find closest standard frame rate."""
        best = cls.FPS_24
        best_diff = abs(fps - best.value)
        for fr in cls:
            diff = abs(fps - fr.value)
            if diff < best_diff:
                best = fr
                best_diff = diff
        return best


# ═══════════════════════════════════════════════════════════════
# Timecode Data
# ═══════════════════════════════════════════════════════════════

@dataclass
class Timecode:
    """Immutable SMPTE timecode value."""
    hours: int = 0
    minutes: int = 0
    seconds: int = 0
    frames: int = 0
    drop_frame: bool = False

    def __str__(self) -> str:
        sep = ";" if self.drop_frame else ":"
        return f"{self.hours:02d}:{self.minutes:02d}:{self.seconds:02d}{sep}{self.frames:02d}"

    def to_total_frames(self, fps: float) -> int:
        """Convert timecode to total frame count."""
        nominal_fps = round(fps)
        total = (self.hours * 3600 + self.minutes * 60 + self.seconds) * nominal_fps + self.frames

        if self.drop_frame and nominal_fps == 30:
            # Drop-frame: drop 2 frames every minute except every 10th minute
            total_minutes = self.hours * 60 + self.minutes
            total -= 2 * (total_minutes - total_minutes // 10)
        elif self.drop_frame and nominal_fps == 60:
            total_minutes = self.hours * 60 + self.minutes
            total -= 4 * (total_minutes - total_minutes // 10)

        return total


# ═══════════════════════════════════════════════════════════════
# Conversion Functions
# ═══════════════════════════════════════════════════════════════

def seconds_to_timecode(seconds: float, fps: float = 24.0,
                        drop_frame: bool = False) -> Timecode:
    """Convert seconds to SMPTE timecode.

    Args:
        seconds: Time in seconds (non-negative)
        fps: Frame rate
        drop_frame: Use drop-frame counting (for 29.97/59.94 fps)

    Returns:
        Timecode object
    """
    if seconds < 0:
        seconds = 0.0

    nominal_fps = round(fps)

    if drop_frame and nominal_fps == 30:
        # 29.97fps Drop-Frame algorithm
        # Total frames at actual rate
        total_frames = round(seconds * 29.97)

        # Drop-frame compensation
        d = total_frames // 17982   # 10-minute blocks
        m = total_frames % 17982    # remainder
        if m < 2:
            m = 2  # protect first two frames of 10-min block

        frames_adjusted = total_frames + 18 * d + 2 * ((m - 2) // 1798)

        fr = frames_adjusted % 30
        secs = (frames_adjusted // 30) % 60
        mins = (frames_adjusted // 1800) % 60
        hrs = frames_adjusted // 108000

        return Timecode(hours=hrs, minutes=mins, seconds=secs,
                        frames=fr, drop_frame=True)

    elif drop_frame and nominal_fps == 60:
        total_frames = round(seconds * 59.94)
        d = total_frames // 35964
        m = total_frames % 35964
        if m < 4:
            m = 4
        frames_adjusted = total_frames + 36 * d + 4 * ((m - 4) // 3596)

        fr = frames_adjusted % 60
        secs = (frames_adjusted // 60) % 60
        mins = (frames_adjusted // 3600) % 60
        hrs = frames_adjusted // 216000

        return Timecode(hours=hrs, minutes=mins, seconds=secs,
                        frames=fr, drop_frame=True)
    else:
        # Non-Drop-Frame — simple division
        total_frames = round(seconds * fps)
        fr = total_frames % nominal_fps
        total_secs = total_frames // nominal_fps
        secs = total_secs % 60
        mins = (total_secs // 60) % 60
        hrs = total_secs // 3600
        return Timecode(hours=hrs, minutes=mins, seconds=secs, frames=fr)


def timecode_to_seconds(tc: Timecode, fps: float = 24.0) -> float:
    """Convert timecode back to seconds."""
    total_frames = tc.to_total_frames(fps)
    actual_fps = fps
    if tc.drop_frame:
        if round(fps) == 30:
            actual_fps = 29.97
        elif round(fps) == 60:
            actual_fps = 59.94
    return total_frames / actual_fps


def beats_to_timecode(beat: float, bpm: float, fps: float = 24.0,
                      drop_frame: bool = False,
                      offset_seconds: float = 0.0) -> Timecode:
    """Convert beat position to timecode, with optional offset.

    Args:
        beat: Beat position (0-based)
        bpm: Tempo
        fps: Frame rate
        drop_frame: Use drop-frame mode
        offset_seconds: Timecode offset (e.g. camera start TC)

    Returns:
        Timecode object
    """
    secs = beat * 60.0 / max(1, bpm) + offset_seconds
    return seconds_to_timecode(secs, fps, drop_frame)


def format_timecode_str(seconds: float, fps: float = 24.0,
                        drop_frame: bool = False) -> str:
    """Quick format: seconds → "HH:MM:SS:FF" string."""
    return str(seconds_to_timecode(seconds, fps, drop_frame))


def parse_timecode(text: str, fps: float = 24.0) -> Optional[Timecode]:
    """Parse a timecode string like "01:23:45:12" or "01:23:45;12" (DF).

    Returns None on parse failure.
    """
    text = text.strip()
    if not text:
        return None

    drop_frame = ";" in text
    # Normalize separator
    text = text.replace(";", ":")

    parts = text.split(":")
    if len(parts) == 4:
        try:
            h, m, s, f = int(parts[0]), int(parts[1]), int(parts[2]), int(parts[3])
            return Timecode(hours=h, minutes=m, seconds=s, frames=f,
                            drop_frame=drop_frame)
        except ValueError:
            return None
    elif len(parts) == 3:
        # MM:SS:FF (no hours)
        try:
            m, s, f = int(parts[0]), int(parts[1]), int(parts[2])
            return Timecode(hours=0, minutes=m, seconds=s, frames=f,
                            drop_frame=drop_frame)
        except ValueError:
            return None

    return None


# ═══════════════════════════════════════════════════════════════
# Clip Timecode Offset
# ═══════════════════════════════════════════════════════════════

@dataclass
class ClipTimecodeOffset:
    """Per-clip timecode offset for external camera sync."""
    clip_id: str = ""
    offset_seconds: float = 0.0
    source_fps: float = 24.0
    source_tc_start: str = "00:00:00:00"  # camera start TC


# ═══════════════════════════════════════════════════════════════
# LTC (Linear Time Code) Sync — Stub
# ═══════════════════════════════════════════════════════════════

class LTCSync:
    """Linear Time Code sync via audio track (stub/framework).

    LTC encodes SMPTE timecode as an audio signal (biphase modulation).
    This class provides the interface for future LTC reading/writing.

    Usage:
        ltc = LTCSync()
        ltc.set_audio_track(track_id)
        tc = ltc.read_timecode_at(sample_position)
    """

    def __init__(self):
        self._audio_track_id: Optional[str] = None
        self._fps: float = 24.0
        self._drop_frame: bool = False
        self._enabled: bool = False
        log.info("[LTCSync] Stub initialized — full implementation pending")

    def set_audio_track(self, track_id: str) -> None:
        """Set the audio track containing LTC signal."""
        self._audio_track_id = track_id
        log.info("[LTCSync] Audio track set: %s", track_id)

    def set_frame_rate(self, fps: float, drop_frame: bool = False) -> None:
        """Configure expected frame rate."""
        self._fps = fps
        self._drop_frame = drop_frame

    def enable(self, enabled: bool = True) -> None:
        """Enable/disable LTC sync."""
        self._enabled = enabled

    def read_timecode_at(self, sample_position: int,
                         sample_rate: int = 48000) -> Optional[Timecode]:
        """Read timecode from LTC audio at given sample position.

        NOTE: This is a stub. Full implementation requires:
        - Biphase mark decoding of the audio signal
        - Manchester encoding detection
        - 80-bit LTC word parsing
        - Error correction

        For now, returns timecode derived from sample position.
        """
        if not self._enabled:
            return None
        seconds = sample_position / max(1, sample_rate)
        return seconds_to_timecode(seconds, self._fps, self._drop_frame)

    @property
    def is_enabled(self) -> bool:
        return self._enabled
