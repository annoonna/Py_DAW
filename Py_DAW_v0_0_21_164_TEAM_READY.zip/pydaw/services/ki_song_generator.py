"""ki_song_generator.py — One-Click Song Generator (v0.0.20.986)

KK8:  KI-Entscheidungslogik (style selection, key/tempo suggestions)
KK12: One-Click Song Generator (full song from parameters)
KK14: Mathematische Basis (Golden Ratio, Fibonacci, Markov, Fractals)

Usage:
    from pydaw.services.ki_song_generator import SongGenerator

    gen = SongGenerator()
    song = gen.generate(style="baroque", key="D", mode="major",
                        tempo=92, duration_bars=64, seed=42)
    # song.tracks = [{name, notes, instrument}, ...]
"""

import math
import random
import hashlib
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple

log = logging.getLogger(__name__)

# Imports from other KI modules
try:
    from .ki_composition_theory import Scale, Chord, CadenceEngine, generate_progression
    from .ki_counterpoint import CounterpointEngine, CanonGenerator, CanonType
    from .ki_epoch_profiles import EpochEngine, EPOCH_PROFILES, RhythmEngine
    from .ki_arrangement import ArrangementEngine, SongStructure
except ImportError:
    from pydaw.services.ki_composition_theory import Scale, Chord, CadenceEngine, generate_progression
    from pydaw.services.ki_counterpoint import CounterpointEngine, CanonGenerator, CanonType
    from pydaw.services.ki_epoch_profiles import EpochEngine, EPOCH_PROFILES, RhythmEngine
    from pydaw.services.ki_arrangement import ArrangementEngine, SongStructure


# ═══════════════════════════════════════════════════════════════
# KK14: Mathematical Basis
# ═══════════════════════════════════════════════════════════════

PHI = (1 + math.sqrt(5)) / 2  # Golden Ratio ≈ 1.618
FIBONACCI = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]


def golden_proportion(total_length: int) -> int:
    """Find the golden ratio climax point in a given length."""
    return int(total_length / PHI)


def fibonacci_sections(total_bars: int, min_bars: int = 4) -> List[int]:
    """Divide total bars into Fibonacci-proportioned sections."""
    fibs = [f for f in FIBONACCI if f >= min_bars and f <= total_bars // 2]
    if not fibs:
        return [total_bars]

    sections = []
    remaining = total_bars
    for f in reversed(fibs):
        if remaining >= f:
            sections.append(f)
            remaining -= f
    if remaining > 0:
        sections.append(remaining)
    return sections


def fractal_melody(seed_melody: List[int], depth: int = 2,
                   scale_factor: float = 0.5) -> List[int]:
    """Generate a self-similar melody using fractal recursion.

    Each note of the seed generates a scaled copy of the entire melody.
    """
    if depth <= 0 or not seed_melody:
        return seed_melody

    result = []
    center = sum(seed_melody) / len(seed_melody)

    for note in seed_melody:
        offset = note - center
        sub = [int(center + (n - center) * scale_factor + offset)
               for n in seed_melody]
        result.extend(sub)

    if depth > 1:
        return fractal_melody(result[:len(result) // 2], depth - 1, scale_factor)
    return result


def markov_melody(scale: Scale, length: int = 16,
                  seed: int = 42) -> List[int]:
    """Generate melody using Markov chain on scale degrees.

    Transition probabilities favor stepwise motion and
    resolution to tonic.
    """
    rng = random.Random(seed)

    # Transition matrix (from degree → to degree probabilities)
    # Favors stepwise motion, resolution patterns
    transitions = {
        1: {1: 0.05, 2: 0.25, 3: 0.20, 4: 0.10, 5: 0.20, 6: 0.10, 7: 0.10},
        2: {1: 0.25, 2: 0.05, 3: 0.25, 4: 0.15, 5: 0.15, 6: 0.10, 7: 0.05},
        3: {1: 0.10, 2: 0.25, 3: 0.05, 4: 0.25, 5: 0.15, 6: 0.10, 7: 0.10},
        4: {1: 0.10, 2: 0.10, 3: 0.20, 4: 0.05, 5: 0.30, 6: 0.15, 7: 0.10},
        5: {1: 0.30, 2: 0.10, 3: 0.10, 4: 0.15, 5: 0.05, 6: 0.15, 7: 0.15},
        6: {1: 0.10, 2: 0.10, 3: 0.10, 4: 0.10, 5: 0.25, 6: 0.05, 7: 0.30},
        7: {1: 0.40, 2: 0.10, 3: 0.10, 4: 0.10, 5: 0.15, 6: 0.10, 7: 0.05},
    }

    melody = []
    current_degree = 1

    for i in range(length):
        midi = scale.degree_to_midi(current_degree, 0) + 60  # octave 5
        melody.append(midi)

        # Choose next degree
        probs = transitions.get(current_degree, transitions[1])
        degrees = list(probs.keys())
        weights = list(probs.values())
        current_degree = rng.choices(degrees, weights=weights, k=1)[0]

    return melody


def cellular_automaton_rhythm(rule: int = 30, steps: int = 16,
                              cells: int = 8) -> List[List[bool]]:
    """Generate rhythm patterns using 1D cellular automaton.

    Rule 30 (Wolfram) produces complex, pseudo-random patterns.
    """
    state = [False] * cells
    state[cells // 2] = True  # seed in center

    patterns = [state[:]]

    for _ in range(steps - 1):
        new_state = [False] * cells
        for i in range(cells):
            left = state[(i - 1) % cells]
            center = state[i]
            right = state[(i + 1) % cells]
            idx = (int(left) << 2) | (int(center) << 1) | int(right)
            new_state[i] = bool((rule >> idx) & 1)
        state = new_state
        patterns.append(state[:])

    return patterns


def lsystem_melody(axiom: str = "A", rules: Dict[str, str] = None,
                   iterations: int = 3,
                   note_map: Dict[str, int] = None) -> List[int]:
    """Generate melody using L-System (Lindenmayer System).

    Each character maps to a musical action.
    Default: A=up step, B=down step, +=up third, -=down third
    """
    if rules is None:
        rules = {"A": "AB+", "B": "A-B"}
    if note_map is None:
        note_map = {"A": 2, "B": -2, "+": 4, "-": -4}

    # Generate L-system string
    result = axiom
    for _ in range(iterations):
        new = ""
        for ch in result:
            new += rules.get(ch, ch)
        result = new

    # Convert to melody
    melody = [60]  # start on C4
    for ch in result[:64]:  # limit length
        delta = note_map.get(ch, 0)
        next_note = melody[-1] + delta
        next_note = max(48, min(84, next_note))  # keep in range
        melody.append(next_note)

    return melody


# ═══════════════════════════════════════════════════════════════
# KK8: Decision Logic
# ═══════════════════════════════════════════════════════════════

class StyleAdvisor:
    """Suggest style parameters based on text or mood analysis."""

    MOOD_TO_KEY = {
        "joy": ("D", "major"), "celebration": ("Bb", "major"),
        "sorrow": ("D", "minor"), "grief": ("C", "minor"),
        "peace": ("G", "major"), "meditation": ("E", "minor"),
        "triumph": ("C", "major"), "battle": ("G", "minor"),
        "love": ("F", "major"), "longing": ("A", "minor"),
        "mystery": ("Eb", "minor"), "fear": ("B", "minor"),
        "hope": ("A", "major"), "nostalgia": ("E", "major"),
    }

    MOOD_TO_TEMPO = {
        "joy": (110, 140), "celebration": (120, 150),
        "sorrow": (50, 70), "grief": (40, 60),
        "peace": (60, 80), "meditation": (50, 70),
        "triumph": (100, 130), "battle": (140, 180),
        "love": (70, 100), "longing": (60, 90),
        "mystery": (60, 90), "fear": (80, 120),
        "hope": (80, 110), "nostalgia": (70, 100),
    }

    @classmethod
    def suggest_from_mood(cls, mood: str) -> Dict:
        """Suggest key, tempo, and style from a mood keyword."""
        mood = mood.lower()
        root, mode = cls.MOOD_TO_KEY.get(mood, ("C", "major"))
        tempo_range = cls.MOOD_TO_TEMPO.get(mood, (80, 120))
        tempo = random.randint(*tempo_range)

        # Match mood to best epoch
        epoch_scores = {}
        for name, profile in EPOCH_PROFILES.items():
            score = 0
            if mood in ("joy", "celebration", "triumph"):
                score += profile.dynamic_range * 10
            elif mood in ("sorrow", "grief", "longing"):
                score += (1 - profile.dynamic_range) * 10
                score += profile.use_chromaticism * 5
            elif mood in ("peace", "meditation"):
                score += (1 - profile.rhythmic_complexity) * 10
            elif mood in ("mystery", "fear"):
                score += profile.use_chromaticism * 10
            epoch_scores[name] = score

        best_epoch = max(epoch_scores, key=epoch_scores.get)

        return {
            "key": f"{root} {mode}",
            "root": root,
            "mode": mode,
            "tempo": tempo,
            "suggested_epoch": best_epoch,
            "mood": mood,
        }

    @classmethod
    def suggest_from_text(cls, text: str) -> Dict:
        """Simple text sentiment → mood → style suggestion."""
        text_lower = text.lower()

        mood_keywords = {
            "joy": ["freude", "joy", "happy", "fröhlich", "lustig"],
            "sorrow": ["trauer", "sorrow", "sad", "traurig", "weinen"],
            "peace": ["frieden", "peace", "ruhe", "still", "sanft"],
            "triumph": ["sieg", "triumph", "glory", "herrlich", "majestät"],
            "love": ["liebe", "love", "herz", "heart", "zärtlich"],
            "hope": ["hoffnung", "hope", "licht", "light", "morgen"],
            "mystery": ["geheimnis", "mystery", "dunkel", "dark", "nacht"],
            "celebration": ["fest", "feier", "celebration", "party", "tanz"],
        }

        best_mood = "peace"
        best_count = 0
        for mood, keywords in mood_keywords.items():
            count = sum(1 for kw in keywords if kw in text_lower)
            if count > best_count:
                best_count = count
                best_mood = mood

        return cls.suggest_from_mood(best_mood)


# ═══════════════════════════════════════════════════════════════
# KK12: One-Click Song Generator
# ═══════════════════════════════════════════════════════════════

@dataclass
class GeneratedTrack:
    """A single track in a generated song."""
    name: str
    instrument: str
    notes: List[Dict]  # [{midi, start_beat, duration_beats, velocity}]
    role: str = "melody"


@dataclass
class GeneratedSong:
    """Complete generated song."""
    title: str
    style: str
    key: str
    tempo: int
    time_signature: Tuple[int, int]
    duration_bars: int
    seed: int
    tracks: List[GeneratedTrack]
    structure: SongStructure
    description: str


class SongGenerator:
    """Vollständig mathematischer Song-Generator.

    ALLE Tracks (Melodie, Harmonie, Bass, Drums) basieren auf:
      - Markov-Ketten (Übergangswahrscheinlichkeiten)
      - Fraktal-Rekursion (Selbstähnlichkeit)
      - L-Systeme (organische Entwicklung)
      - Golden Ratio (Phrase-Proportionen, Dynamik)
      - Fibonacci (Rhythmus-Subdivisions)
      - Zelluläre Automaten (Variation, Fills)
      - Intervall-Analyse (importierte Melodien scannen)
      - Transformations-Netzwerke (Variation erzeugen)
    """

    def __init__(self):
        self.epoch_engine = EpochEngine()
        self.arrangement = ArrangementEngine()
        self.advisor = StyleAdvisor()

    # ═══════════════════════════════════════════════════════════
    # MELODIE-ANALYSE (Gesangbuch scannen → Intervall-Profil)
    # ═══════════════════════════════════════════════════════════

    @staticmethod
    def analyze_melody(melody: List[int]) -> Dict:
        """Analysiere eine Melodie mathematisch.

        Extrahiert: Intervall-Histogramm, Kontur, Ambitus,
        Schwerpunkt, Tonvorrat, rhythmische Dichte.
        """
        if not melody or len(melody) < 2:
            return {"error": "Melodie zu kurz"}

        intervals = [melody[i+1] - melody[i] for i in range(len(melody)-1)]

        # Intervall-Histogramm (Markov-Übergangsmatrix Basis)
        interval_hist: Dict[int, int] = {}
        for iv in intervals:
            interval_hist[iv] = interval_hist.get(iv, 0) + 1

        # Kontur: Auf/Ab/Gleich Verhältnis
        up = sum(1 for iv in intervals if iv > 0)
        down = sum(1 for iv in intervals if iv < 0)
        same = sum(1 for iv in intervals if iv == 0)
        total = len(intervals)

        # Ambitus
        note_min, note_max = min(melody), max(melody)
        ambitus = note_max - note_min

        # Schwerpunkt (gewichteter Mittelwert)
        center = sum(melody) / len(melody)

        # Golden Ratio Climax-Position
        phi = (1 + math.sqrt(5)) / 2
        climax_pos = int(len(melody) / phi)
        climax_note = max(melody)
        actual_climax = melody.index(climax_note)

        # Tonvorrat (Pitch Class Set)
        pitch_classes = sorted(set(n % 12 for n in melody))

        return {
            "intervals": intervals,
            "interval_histogram": interval_hist,
            "contour_up": up / total,
            "contour_down": down / total,
            "contour_same": same / total,
            "ambitus": ambitus,
            "center": center,
            "note_min": note_min,
            "note_max": note_max,
            "pitch_classes": pitch_classes,
            "num_pitch_classes": len(pitch_classes),
            "golden_climax_expected": climax_pos,
            "golden_climax_actual": actual_climax,
            "length": len(melody),
        }

    @staticmethod
    def build_markov_from_melody(melody: List[int], order: int = 1) -> Dict:
        """Baue Markov-Kette aus einer analysierten Melodie.

        Ordnung 1: P(note_i+1 | note_i)
        Ordnung 2: P(note_i+1 | note_i-1, note_i)
        """
        transitions: Dict = {}
        for i in range(len(melody) - order):
            state = tuple(melody[i:i+order])
            next_note = melody[i+order]
            if state not in transitions:
                transitions[state] = {}
            transitions[state][next_note] = transitions[state].get(next_note, 0) + 1

        # Normalisiere zu Wahrscheinlichkeiten
        for state, nexts in transitions.items():
            total = sum(nexts.values())
            for note in nexts:
                nexts[note] /= total

        return transitions

    # ═══════════════════════════════════════════════════════════
    # MATHEMATISCHE TRANSFORMATIONEN (Variation erzeugen)
    # ═══════════════════════════════════════════════════════════

    @staticmethod
    def transform_inversion(melody: List[int], axis: int = 0) -> List[int]:
        """Spiegelung: Intervalle umkehren. Bach-Umkehrung."""
        if not melody:
            return melody
        if axis == 0:
            axis = melody[0]
        return [2 * axis - n for n in melody]

    @staticmethod
    def transform_retrograde(melody: List[int]) -> List[int]:
        """Krebs: Rückwärts spielen."""
        return list(reversed(melody))

    @staticmethod
    def transform_augmentation(melody: List[int], factor: float = 2.0) -> List[int]:
        """Augmentation: Intervalle vergrößern."""
        if not melody:
            return melody
        base = melody[0]
        return [base + int((n - base) * factor) for n in melody]

    @staticmethod
    def transform_diminution(melody: List[int], factor: float = 0.5) -> List[int]:
        """Diminution: Intervalle verkleinern."""
        if not melody:
            return melody
        base = melody[0]
        return [base + int((n - base) * factor) for n in melody]

    @staticmethod
    def transform_modal_shift(melody: List[int], scale: Scale,
                               shift: int = 1) -> List[int]:
        """Modale Verschiebung: Stufe hoch/runter innerhalb der Skala."""
        result = []
        for n in melody:
            degree = scale.degree_of(n)
            if degree is not None:
                new_degree = ((degree - 1 + shift) % 7) + 1
                octave = (n - 60) // 12
                result.append(scale.degree_to_midi(new_degree, octave) + 60)
            else:
                result.append(n + shift)
        return result

    @staticmethod
    def transform_ornament(melody: List[int], rng: random.Random,
                            density: float = 0.3) -> List[int]:
        """Verzierung: Durchgangstöne, Wechselnoten, Vorhalte einfügen."""
        result = []
        for i, note in enumerate(melody):
            result.append(note)
            if i < len(melody) - 1 and rng.random() < density:
                next_note = melody[i + 1]
                interval = next_note - note
                if abs(interval) > 2:
                    # Durchgangston (Passing Tone)
                    result.append(note + interval // 2)
                elif abs(interval) <= 2:
                    # Wechselnote (Neighbor Tone)
                    result.append(note + (2 if rng.random() > 0.5 else -2))
        return result

    # ═══════════════════════════════════════════════════════════
    # MATHEMATISCHE MELODIE-ERZEUGUNG
    # ═══════════════════════════════════════════════════════════

    def _generate_melody_math(self, scale: Scale, length: int,
                               method: str, seed: int,
                               rng: random.Random,
                               source_melody: List[int] = None) -> List[int]:
        """Erzeuge Melodie mit mathematischen Methoden.

        Wenn source_melody gegeben: Analysiere + erzeuge Variation.
        Sonst: Rein mathematisch generieren.
        """
        if source_melody and len(source_melody) >= 4:
            return self._generate_from_analysis(
                source_melody, scale, length, rng
            )

        # Golden Ratio Phrase-Struktur
        phi = (1 + math.sqrt(5)) / 2
        climax_pos = int(length / phi)  # Höhepunkt bei ~62%

        if method == "fractal":
            seed_notes = [scale.degree_to_midi(d, 0) + 60
                          for d in [1, 3, 5, 4, 3, 2, 1]]
            raw = fractal_melody(seed_notes, depth=2)[:length]
        elif method == "lsystem":
            raw = lsystem_melody(iterations=4)[:length]
        elif method == "cantus":
            cp = CounterpointEngine(root=scale.root, mode=scale.mode)
            raw = cp.generate_cantus_firmus(min(length, 20))
            # Extend via Fibonacci repetition
            while len(raw) < length:
                fib_len = FIBONACCI[min(len(raw) % 8, len(FIBONACCI)-1)]
                segment = raw[-fib_len:]
                raw.extend(self.transform_modal_shift(segment, scale, 1))
            raw = raw[:length]
        else:  # markov
            raw = markov_melody(scale, length, seed)

        # Golden Ratio Dynamik-Kurve (Spannung aufbauen zum Climax)
        shaped = []
        for i, note in enumerate(raw):
            # Ambitus-Expansion zum Climax hin
            progress = i / max(length - 1, 1)
            tension = 1.0 - abs(progress - 1.0/phi) * phi
            tension = max(0.0, min(1.0, tension))

            # Note zum Climax hin nach oben schieben
            shift = int(tension * 4)  # max 4 Halbtöne
            shaped.append(note + shift)

        # Fibonacci-basierte Phrasen-Grenzen
        phrase_lengths = []
        remaining = length
        fib_idx = 3  # Start bei Fibonacci(3) = 3
        while remaining > 0:
            plen = FIBONACCI[min(fib_idx, len(FIBONACCI)-1)]
            plen = min(plen, remaining)
            phrase_lengths.append(plen)
            remaining -= plen
            fib_idx = (fib_idx + 1) % (len(FIBONACCI) - 2) + 2

        return shaped

    def _generate_from_analysis(self, source: List[int], scale: Scale,
                                 target_length: int,
                                 rng: random.Random) -> List[int]:
        """Analysiere Quell-Melodie und erzeuge mathematische Variation.

        1. Intervall-Profil extrahieren
        2. Markov-Kette bauen
        3. Neue Melodie mit gleichen statistischen Eigenschaften generieren
        4. Transformation anwenden (Inversion, Augmentation, Ornamente)
        """
        analysis = self.analyze_melody(source)
        markov = self.build_markov_from_melody(source, order=1)

        # Neue Melodie aus Markov-Kette
        melody = [source[0]]  # gleicher Startton
        for _ in range(target_length - 1):
            state = (melody[-1],)
            if state in markov:
                nexts = markov[state]
                notes = list(nexts.keys())
                weights = list(nexts.values())
                next_note = rng.choices(notes, weights=weights, k=1)[0]
            else:
                # Fallback: zufälliger Skalensprung
                degree = rng.randint(1, 7)
                next_note = scale.degree_to_midi(degree, 0) + 60
            melody.append(next_note)

        # Zufällige Transformation anwenden
        transforms = [
            lambda m: m,  # Original
            lambda m: self.transform_inversion(m),
            lambda m: self.transform_modal_shift(m, scale, 2),
            lambda m: self.transform_modal_shift(m, scale, -1),
            lambda m: self.transform_ornament(m, rng, 0.3),
            lambda m: self.transform_diminution(m, 0.7),
        ]
        transform = rng.choice(transforms)
        melody = transform(melody)

        # Ambitus begrenzen
        melody = [max(48, min(84, n)) for n in melody]

        return melody[:target_length]

    # ═══════════════════════════════════════════════════════════
    # MATHEMATISCHE HARMONIE (Kontrapunkt + Transformationen)
    # ═══════════════════════════════════════════════════════════

    def _generate_harmony_math(self, melody: List[int], scale: Scale,
                                rng: random.Random) -> List[int]:
        """Mathematisch generierte Harmonie-Stimme.

        Regeln:
          - Gegenbewegung bevorzugt (Bach)
          - Terzen/Sexten bevorzugt (konsonant)
          - Golden Ratio Intervall-Wechsel
          - Fibonacci-basierte Phrase-Kopplungen
        """
        phi = (1 + math.sqrt(5)) / 2
        harmony = []

        # Konsonante Intervalle (in Halbtönen): Terz, Quarte, Quinte, Sexte
        consonances = [-3, -4, -5, 3, 4, 5, -7, -8, 7, 8]

        for i, note in enumerate(melody):
            # Golden Ratio: Intervall-Typ wechselt nach φ-Muster
            interval_idx = int(i * phi) % len(consonances)
            interval = consonances[interval_idx]

            harm_note = note + interval

            # Gegenbewegung erzwingen wenn möglich
            if i > 0 and len(harmony) > 0:
                mel_direction = note - melody[i-1]
                harm_direction = harm_note - harmony[-1]
                if mel_direction * harm_direction > 0:
                    # Gleiche Richtung → Gegenbewegung
                    harm_note = note - interval

            # In Skala quantisieren
            degree = scale.degree_of(harm_note)
            if degree is None:
                # Nächsten Skalenton finden
                for offset in [0, -1, 1, -2, 2]:
                    if scale.degree_of(harm_note + offset) is not None:
                        harm_note += offset
                        break

            # Ambitus begrenzen
            harm_note = max(48, min(78, harm_note))
            harmony.append(harm_note)

        return harmony

    # ═══════════════════════════════════════════════════════════
    # MATHEMATISCHER BASS (Walking + Fibonacci + Golden Ratio)
    # ═══════════════════════════════════════════════════════════

    def _generate_bass_math(self, melody: List[int], chords: List,
                             scale: Scale, duration_bars: int,
                             rng: random.Random) -> List[int]:
        """Mathematisch generierte Bass-Stimme.

        - Grundtöne aus Akkord-Analyse
        - Walking Bass: Fibonacci-Intervalle
        - Golden Ratio Akzente
        - Durchgangstöne nach Skalenregel
        """
        phi = (1 + math.sqrt(5)) / 2
        bass = []

        for i, chord in enumerate(chords):
            root = chord.root_pc + 36  # Oktave 2

            # Fibonacci-basiertes Walking Pattern
            fib_patterns = [
                [0],           # nur Grundton
                [0, 7],        # Grundton + Quinte
                [0, 4, 7],     # Arpeggio
                [0, 2, 4, 7],  # Walking
                [0, 2, 4, 5, 7],  # Extended Walking
            ]

            # Pattern-Auswahl nach Golden Ratio
            pattern_idx = int(i * phi) % len(fib_patterns)
            pattern = fib_patterns[pattern_idx]

            for step in pattern:
                note = root + step
                # Durchgangston (chromatisch) mit Fibonacci-Wahrscheinlichkeit
                fib_prob = FIBONACCI[i % len(FIBONACCI)] / 13.0
                if rng.random() < fib_prob * 0.3:
                    # Chromatischer Approach
                    approach = note + rng.choice([-1, 1])
                    bass.append(max(28, min(60, approach)))
                bass.append(max(28, min(60, note)))

        return bass[:duration_bars * 4]

    # ═══════════════════════════════════════════════════════════
    # HAUPT-GENERATOR
    # ═══════════════════════════════════════════════════════════

    def generate(self, style: str = "rock", key: str = "C",
                 mode: str = "major", tempo: int = 120,
                 duration_bars: int = 32, seed: int = 0,
                 method: str = "markov",
                 source_melody: List[int] = None) -> GeneratedSong:
        """Erzeuge einen vollständig mathematisch generierten Song.

        Args:
            style: Epochen-Name
            key, mode: Tonart
            tempo: BPM
            duration_bars: Taktanzahl
            seed: Random Seed (0 = zufällig)
            method: markov, fractal, lsystem, cantus
            source_melody: Optional — Quell-Melodie zum Analysieren + Variieren
        """
        if seed == 0:
            seed = random.randint(1, 999999)
        rng = random.Random(seed)

        scale = Scale(root=key, mode=mode)

        # Song-Struktur (Golden Ratio proportioniert)
        structure = self.arrangement.generate_song_structure(
            style, duration_bars, tempo, f"{key} {mode}"
        )
        instr = self.arrangement.orchestrate(style)
        melody_length = duration_bars * 4

        # ── MELODIE (mathematisch) ──
        melody = self._generate_melody_math(
            scale, melody_length, method, seed, rng, source_melody
        )

        # ── HARMONIE (mathematisch: Gegenbewegung + Golden Ratio) ──
        harmony = self._generate_harmony_math(melody, scale, rng)

        # ── AKKORDE (aus Melodie + Harmonie ableiten) ──
        chords = self._generate_chords(scale, structure, rng)

        # ── BASS (mathematisch: Walking + Fibonacci) ──
        bass_notes = self._generate_bass_math(
            melody, chords, scale, duration_bars, rng
        )

        # ── DRUMS (mathematisch: Euklid + Golden Ratio + CA) ──
        drum_notes = self._generate_drum_track(style, duration_bars, rng)

        # ── TRACKS BAUEN ──
        tracks = []

        # Golden Ratio Velocity-Kurve für melodische Stimmen
        phi = (1 + math.sqrt(5)) / 2
        def golden_velocity(i, total, base=80, accent=115):
            progress = i / max(total - 1, 1)
            tension = 1.0 - abs(progress - 1.0/phi) * phi
            tension = max(0.0, min(1.0, tension))
            return int(base + tension * (accent - base))

        # Melodie
        mel_notes = []
        for i, n in enumerate(melody):
            mel_notes.append({
                "midi": max(0, min(127, n)),
                "start_beat": i * 1.0,
                "duration_beats": 0.9,
                "velocity": golden_velocity(i, len(melody), 75, 110),
            })
        tracks.append(GeneratedTrack(
            name="Melodie", instrument=instr.get("melody", "piano"),
            notes=mel_notes, role="melody",
        ))

        # Harmonie
        harm_notes = []
        for i, n in enumerate(harmony):
            harm_notes.append({
                "midi": max(0, min(127, n)),
                "start_beat": i * 1.0,
                "duration_beats": 0.85,
                "velocity": golden_velocity(i, len(harmony), 60, 90),
            })
        tracks.append(GeneratedTrack(
            name="Harmonie", instrument=instr.get("harmony", "piano"),
            notes=harm_notes, role="harmony",
        ))

        # Bass
        bass_dicts = []
        for i, n in enumerate(bass_notes):
            bass_dicts.append({
                "midi": max(0, min(127, n)),
                "start_beat": i * (duration_bars * 4.0 / max(len(bass_notes), 1)),
                "duration_beats": 0.9,
                "velocity": golden_velocity(i, len(bass_notes), 70, 100),
            })
        tracks.append(GeneratedTrack(
            name="Bass", instrument=instr.get("bass", "bass_guitar"),
            notes=bass_dicts, role="bass",
        ))

        # Drums (bereits mathematisch)
        if drum_notes:
            tracks.append(GeneratedTrack(
                name="Drums", instrument="drums",
                notes=drum_notes, role="rhythm",
            ))

        title_hash = hashlib.md5(f"{style}{key}{seed}".encode()).hexdigest()[:6]
        title = f"{style.title()} in {key} {mode} (#{title_hash})"

        return GeneratedSong(
            title=title, style=style, key=f"{key} {mode}",
            tempo=tempo, time_signature=(4, 4),
            duration_bars=duration_bars, seed=seed,
            tracks=tracks, structure=structure,
            description=f"Math-Generated: {method}, {len(tracks)} tracks, "
                        f"seed={seed}",
        )

    def generate_from_chorale(self, chorale_id: str, key: str = None,
                               mode: str = None, style: str = "baroque",
                               tempo: int = 0, seed: int = 0,
                               duration_bars: int = 32) -> GeneratedSong:
        """Scanne Choral aus der Datenbank → Analysiere → Erzeuge Variation.

        1. Choral-Melodie laden
        2. Intervall-Profil + Markov-Kette extrahieren
        3. Neue Variation mit gleichen statistischen Eigenschaften
        4. Mathematische Transformationen anwenden
        5. Harmonie, Bass, Drums dazu generieren
        """
        try:
            from .ki_church_music import ChurchMusicEngine
        except ImportError:
            from pydaw.services.ki_church_music import ChurchMusicEngine

        church = ChurchMusicEngine()
        chorale = church.get_chorale(chorale_id)

        if chorale is None:
            # Fallback: normaler Generator
            return self.generate(style=style, key=key or "C",
                                 mode=mode or "major", seed=seed,
                                 duration_bars=duration_bars)

        # Tonart und Tempo aus Choral übernehmen wenn nicht angegeben
        if key is None:
            parts = chorale.key.split()
            key = parts[0] if parts else "C"
        if mode is None:
            parts = chorale.key.split()
            mode = parts[1] if len(parts) > 1 else "major"
        if tempo == 0:
            tempo = 72  # typisches Choral-Tempo

        return self.generate(
            style=style, key=key, mode=mode, tempo=tempo,
            duration_bars=duration_bars, seed=seed,
            method="markov",  # Markov aus Choral-Analyse
            source_melody=chorale.melody,
        )

    def generate_from_mood(self, mood: str, duration_bars: int = 32,
                           seed: int = 0) -> GeneratedSong:
        suggestion = self.advisor.suggest_from_mood(mood)
        return self.generate(
            style=suggestion["suggested_epoch"],
            key=suggestion["root"], mode=suggestion["mode"],
            tempo=suggestion["tempo"],
            duration_bars=duration_bars, seed=seed,
        )

    def generate_from_text(self, text: str, duration_bars: int = 32,
                           seed: int = 0) -> GeneratedSong:
        suggestion = self.advisor.suggest_from_text(text)
        return self.generate(
            style=suggestion["suggested_epoch"],
            key=suggestion["root"], mode=suggestion["mode"],
            tempo=suggestion["tempo"],
            duration_bars=duration_bars, seed=seed,
        )

    def _generate_chords(self, scale: Scale, structure: SongStructure,
                         rng: random.Random) -> List[Chord]:
        """Generate chord progression matching song structure."""
        cadence = CadenceEngine(scale)
        chords = []

        for section in structure.sections:
            # Choose progression based on section type
            progression = cadence.authentic().chords
            if section.energy > 0.7:
                progression = cadence.circle_of_fifths().chords
            elif section.energy < 0.3:
                progression = cadence.plagal().chords

            # Repeat to fill section
            bars = section.length_bars
            while len(chords) < section.start_bar + bars:
                chords.extend(progression)

        return chords[:structure.total_bars]

    def _generate_bass(self, chords: List[Chord], scale: Scale,
                       rng: random.Random) -> List[int]:
        """Generate bass line from chord roots."""
        bass = []
        for chord in chords:
            root = chord.root_pc + 36  # octave 2
            # Add passing tones
            bass.append(root)
            if rng.random() > 0.3:
                fifth = root + 7
                bass.append(fifth)
        return bass

    @staticmethod
    def _notes_to_dicts(notes: List[int],
                        beats_per_note: float = 1.0) -> List[Dict]:
        """Convert MIDI note list to note event dicts."""
        return [
            {
                "midi": max(0, min(127, n)),
                "start_beat": i * beats_per_note,
                "duration_beats": beats_per_note * 0.9,
                "velocity": random.randint(70, 110),
            }
            for i, n in enumerate(notes)
        ]

    @staticmethod
    def _style_to_rhythm(style: str) -> str:
        return {
            "jazz": "jazz_swing", "blues": "blues_shuffle",
            "latin": "latin_clave", "electronic": "electronic_four",
            "metal": "metal_blast", "rock": "rock_basic",
        }.get(style, "rock_basic")

    # ═══════════════════════════════════════════════════════════════
    # MATHEMATISCHE DRUM ENGINE
    # ═══════════════════════════════════════════════════════════════
    #
    # Alle Patterns basieren auf mathematischen Formeln:
    #   - Euklidische Rhythmen (Bjorklund-Algorithmus)
    #   - Goldener Schnitt (Akzent-Platzierung, Dynamik)
    #   - Fibonacci-Folge (Subdivisions, Phrase-Längen)
    #   - Primzahl-Polyrhythmik (geschichtete Patterns)
    #   - Zelluläre Automaten (Variation, Fills)
    #   - Wahrscheinlichkeitsfelder (Humanisierung)
    #
    # Vollständiger GM Drum Kit (47 Instrumente)
    # ═══════════════════════════════════════════════════════════════

    # Complete GM Drum Map (Kanal 10)
    GM_DRUMS = {
        # Kicks
        "kick_acoustic": 35, "kick": 36,
        # Snares
        "sidestick": 37, "snare": 38, "clap": 39,
        "snare_electric": 40,
        # Toms
        "tom_floor_lo": 41, "tom_floor_hi": 43,
        "tom_lo": 45, "tom_mid_lo": 47,
        "tom_mid_hi": 48, "tom_hi": 50,
        # Hi-Hat
        "hh_closed": 42, "hh_pedal": 44, "hh_open": 46,
        # Cymbals
        "crash_1": 49, "crash_2": 57,
        "ride": 51, "ride_bell": 53,
        "splash": 55, "china": 52,
        # Latin
        "tambourine": 54, "cowbell": 56,
        "vibraslap": 58, "bongo_hi": 60, "bongo_lo": 61,
        "conga_mute": 62, "conga_open": 63, "conga_lo": 64,
        "timbale_hi": 65, "timbale_lo": 66,
        "agogo_hi": 67, "agogo_lo": 68,
        "cabasa": 69, "maracas": 70,
        "whistle_short": 71, "whistle_long": 72,
        "guiro_short": 73, "guiro_long": 74,
        "claves": 75, "woodblock_hi": 76, "woodblock_lo": 77,
        "cuica_mute": 78, "cuica_open": 79,
        "triangle_mute": 80, "triangle_open": 81,
    }

    # ── Bjorklund / Euklidischer Rhythmus ──────────────────────

    @staticmethod
    def _euclidean(pulses: int, steps: int) -> List[bool]:
        """Bjorklund-Algorithmus: Verteile K Schläge gleichmäßig auf N Steps.

        E(3,8) = [x . . x . . x .] — kubanischer Tresillo
        E(5,8) = [x . x x . x x .] — westafrikanischer 5/8
        E(7,12) = [x . x x . x . x x . x .] — südindischer Rhythmus
        E(5,16) = [x . . x . . x . . x . . x . . .] — Bossa Nova

        Mathematische Basis: Euklidischer Algorithmus (GCD-verwandt)
        """
        if pulses >= steps:
            return [True] * steps
        if pulses <= 0:
            return [False] * steps

        # Bjorklund's algorithm
        pattern: List[List[bool]] = []
        remainder: List[List[bool]] = []

        for i in range(steps):
            if i < pulses:
                pattern.append([True])
            else:
                remainder.append([False])

        while len(remainder) > 1:
            new_pattern = []
            new_remainder = []
            while pattern and remainder:
                combined = pattern.pop(0) + remainder.pop(0)
                new_pattern.append(combined)
            new_remainder = pattern + remainder
            pattern = new_pattern
            remainder = new_remainder

        result = []
        for p in pattern + remainder:
            result.extend(p)
        return result

    @staticmethod
    def _golden_accents(length: int, base_vel: int = 80,
                        accent_vel: int = 115) -> List[int]:
        """Platziere Akzente nach dem Goldenen Schnitt.

        φ = (1+√5)/2 ≈ 1.618
        Akzent-Position = floor(i × φ) mod length

        Ergibt natürlich klingende, nicht-periodische Akzentmuster.
        """
        phi = (1 + math.sqrt(5)) / 2
        velocities = [base_vel] * length
        for i in range(length):
            pos = int(i * phi) % length
            # Stärke nimmt mit Golden Ratio ab
            accent = accent_vel - int(i * phi * 2) % 30
            velocities[pos] = max(base_vel, min(127, accent))
        return velocities

    @staticmethod
    def _fibonacci_subdivisions(max_subdiv: int = 8) -> List[int]:
        """Fibonacci-basierte Subdivision-Sequenz.

        [1, 1, 2, 3, 5, 8] → ergibt natürliche Rhythmus-Gruppierungen.
        """
        fibs = [1, 1]
        while fibs[-1] < max_subdiv:
            fibs.append(fibs[-1] + fibs[-2])
        return [f for f in fibs if f <= max_subdiv]

    @staticmethod
    def _prime_polyrhythm(base: int, layers: List[int],
                          steps: int = 16) -> List[List[bool]]:
        """Erzeuge Polyrhythmik durch Primzahl-Schichtung.

        layer_pattern[i] = (step × prime) mod steps < threshold

        Primzahlen erzeugen maximale rhythmische Unabhängigkeit.
        """
        result = []
        primes = [2, 3, 5, 7, 11, 13]
        for li, num_hits in enumerate(layers):
            p = primes[li % len(primes)]
            pattern = [False] * steps
            for s in range(steps):
                if (s * p) % steps < num_hits:
                    pattern[s] = True
            result.append(pattern)
        return result

    @staticmethod
    def _cellular_automaton_pattern(rule: int, length: int,
                                     seed_pos: int = -1) -> List[bool]:
        """1D Zellulärer Automat für Rhythmus-Variation.

        Rule 30: Chaotisch, pseudo-zufällig
        Rule 110: Komplex, Turing-vollständig
        Rule 90: Sierpinski-Dreieck (selbstähnlich)
        """
        if seed_pos < 0:
            seed_pos = length // 2

        state = [False] * length
        state[seed_pos % length] = True

        # Evolve several generations, return last
        for _ in range(8):
            new_state = [False] * length
            for i in range(length):
                left = state[(i - 1) % length]
                center = state[i]
                right = state[(i + 1) % length]
                idx = (int(left) << 2) | (int(center) << 1) | int(right)
                new_state[i] = bool((rule >> idx) & 1)
            state = new_state

        return state

    # ── Haupt-Drum-Generator ──────────────────────────────────

    def _generate_drum_track(self, style: str, duration_bars: int,
                              rng: random.Random) -> List[Dict]:
        """Mathematisch generierter Drum-Track.

        Jedes Instrument bekommt ein euklidisches Pattern,
        Akzente nach Golden Ratio, Fills nach Cellular Automata.
        """
        gm = self.GM_DRUMS

        # Stil-Parameter: (instrument, pulses, steps, subdivision, velocity_base)
        # pulses/steps = Euklidischer Rhythmus E(pulses, steps)
        style_layers = self._get_style_layers(style)

        notes = []
        phi = (1 + math.sqrt(5)) / 2

        for bar in range(duration_bars):
            bar_offset = bar * 4.0  # 4 beats pro Takt

            for layer in style_layers:
                instrument = layer["instrument"]
                midi = gm.get(instrument, 36)
                pulses = layer["pulses"]
                steps = layer["steps"]
                subdiv = layer.get("subdiv", 16)
                vel_base = layer.get("velocity", 90)
                swing = layer.get("swing", 0.0)
                probability = layer.get("probability", 1.0)

                # Euklidisches Pattern
                pattern = self._euclidean(pulses, steps)

                # Golden Ratio Akzente
                accents = self._golden_accents(steps, vel_base - 20, vel_base + 15)

                # Pattern auf Takt-Positionen mappen
                beat_step = 4.0 / subdiv  # z.B. 16tel = 0.25 beats

                for step_i in range(min(steps, subdiv)):
                    if not pattern[step_i % len(pattern)]:
                        continue

                    # Wahrscheinlichkeits-Gate
                    if probability < 1.0 and rng.random() > probability:
                        continue

                    beat = bar_offset + step_i * beat_step

                    # Swing (Golden Ratio basiert)
                    if swing > 0 and step_i % 2 == 1:
                        beat += swing * beat_step * (phi - 1)  # ≈ 0.618 × swing

                    # Velocity: Golden Ratio Akzente + Humanisierung
                    vel = accents[step_i % len(accents)]
                    # Fibonacci-basierte Mikro-Dynamik
                    fib_mod = [1, 1, 2, 3, 5, 3, 2, 1]
                    vel += fib_mod[(step_i + bar) % len(fib_mod)] - 3
                    vel = max(25, min(127, vel + rng.randint(-5, 5)))

                    # Timing Humanisierung (Gauss-Verteilung)
                    beat += rng.gauss(0, 0.008)

                    notes.append({
                        "midi": midi,
                        "start_beat": max(0.0, beat),
                        "duration_beats": layer.get("duration", 0.1),
                        "velocity": vel,
                    })

            # Fills: Zellulärer Automat alle 4 Takte
            if bar > 0 and (bar + 1) % 4 == 0:
                fill = self._math_fill(bar_offset + 3.0, bar, rng)
                notes.extend(fill)

            # Crash auf Bar 1, nach Fills, alle 8 Takte
            if bar > 0 and bar % 8 == 0:
                notes.append({
                    "midi": gm["crash_1"],
                    "start_beat": bar_offset,
                    "duration_beats": 1.0,
                    "velocity": 100 + rng.randint(0, 15),
                })

        return notes

    def _get_style_layers(self, style: str) -> List[Dict]:
        """Stil-spezifische Drum-Layer mit euklidischen Parametern.

        Jeder Layer: {instrument, pulses, steps, subdiv, velocity, swing, probability}
        E(pulses, steps) auf subdiv Schritte pro Takt gemappt.
        """
        gm = self.GM_DRUMS

        styles = {
            "rock": [
                {"instrument": "kick",      "pulses": 4, "steps": 16, "subdiv": 16, "velocity": 110},
                {"instrument": "snare",     "pulses": 2, "steps": 8,  "subdiv": 8,  "velocity": 108},
                {"instrument": "hh_closed", "pulses": 8, "steps": 8,  "subdiv": 8,  "velocity": 75},
                {"instrument": "hh_open",   "pulses": 1, "steps": 8,  "subdiv": 8,  "velocity": 70, "probability": 0.3},
                {"instrument": "ride",      "pulses": 0, "steps": 8,  "subdiv": 8,  "velocity": 60, "probability": 0.1},
            ],
            "pop": [
                {"instrument": "kick",      "pulses": 3, "steps": 16, "subdiv": 16, "velocity": 105},
                {"instrument": "snare",     "pulses": 2, "steps": 8,  "subdiv": 8,  "velocity": 105},
                {"instrument": "clap",      "pulses": 2, "steps": 8,  "subdiv": 8,  "velocity": 85, "probability": 0.5},
                {"instrument": "hh_closed", "pulses": 8, "steps": 16, "subdiv": 16, "velocity": 65},
                {"instrument": "tambourine","pulses": 4, "steps": 16, "subdiv": 16, "velocity": 45, "probability": 0.4},
            ],
            "jazz": [
                {"instrument": "ride",      "pulses": 5, "steps": 8,  "subdiv": 12, "velocity": 80, "swing": 0.6},
                {"instrument": "hh_pedal",  "pulses": 2, "steps": 4,  "subdiv": 4,  "velocity": 55},
                {"instrument": "kick",      "pulses": 2, "steps": 8,  "subdiv": 8,  "velocity": 70, "probability": 0.6, "swing": 0.5},
                {"instrument": "snare",     "pulses": 3, "steps": 16, "subdiv": 16, "velocity": 35, "probability": 0.3, "swing": 0.5},
                {"instrument": "ride_bell", "pulses": 1, "steps": 8,  "subdiv": 8,  "velocity": 75, "probability": 0.15},
            ],
            "blues": [
                {"instrument": "kick",      "pulses": 3, "steps": 12, "subdiv": 12, "velocity": 100, "swing": 0.5},
                {"instrument": "snare",     "pulses": 2, "steps": 4,  "subdiv": 4,  "velocity": 100},
                {"instrument": "hh_closed", "pulses": 8, "steps": 12, "subdiv": 12, "velocity": 75, "swing": 0.6},
                {"instrument": "hh_open",   "pulses": 1, "steps": 12, "subdiv": 12, "velocity": 65, "probability": 0.25},
            ],
            "electronic": [
                {"instrument": "kick",      "pulses": 4, "steps": 4,  "subdiv": 4,  "velocity": 120},
                {"instrument": "clap",      "pulses": 2, "steps": 4,  "subdiv": 4,  "velocity": 100},
                {"instrument": "hh_closed", "pulses": 8, "steps": 16, "subdiv": 16, "velocity": 55},
                {"instrument": "hh_open",   "pulses": 4, "steps": 8,  "subdiv": 8,  "velocity": 75},
                {"instrument": "ride",      "pulses": 3, "steps": 16, "subdiv": 16, "velocity": 45, "probability": 0.3},
                {"instrument": "crash_2",   "pulses": 1, "steps": 16, "subdiv": 16, "velocity": 60, "probability": 0.1},
            ],
            "hiphop": [
                {"instrument": "kick",      "pulses": 3, "steps": 16, "subdiv": 16, "velocity": 120},
                {"instrument": "snare",     "pulses": 2, "steps": 8,  "subdiv": 8,  "velocity": 110},
                {"instrument": "hh_closed", "pulses": 6, "steps": 16, "subdiv": 16, "velocity": 70},
                {"instrument": "hh_open",   "pulses": 1, "steps": 8,  "subdiv": 8,  "velocity": 65},
                {"instrument": "clap",      "pulses": 2, "steps": 8,  "subdiv": 8,  "velocity": 80, "probability": 0.4},
                {"instrument": "cowbell",   "pulses": 1, "steps": 16, "subdiv": 16, "velocity": 55, "probability": 0.1},
            ],
            "metal": [
                {"instrument": "kick",      "pulses": 12,"steps": 16, "subdiv": 16, "velocity": 120},
                {"instrument": "snare",     "pulses": 4, "steps": 8,  "subdiv": 8,  "velocity": 120},
                {"instrument": "hh_closed", "pulses": 16,"steps": 16, "subdiv": 16, "velocity": 85},
                {"instrument": "ride",      "pulses": 8, "steps": 8,  "subdiv": 8,  "velocity": 95},
                {"instrument": "crash_1",   "pulses": 1, "steps": 16, "subdiv": 16, "velocity": 100, "probability": 0.15},
                {"instrument": "china",     "pulses": 2, "steps": 16, "subdiv": 16, "velocity": 90, "probability": 0.1},
            ],
            "latin": [
                # Son Clave als Euklidisch: E(5,16) ≈ 3-2 Clave
                {"instrument": "claves",    "pulses": 5, "steps": 16, "subdiv": 16, "velocity": 100},
                {"instrument": "conga_open","pulses": 5, "steps": 8,  "subdiv": 8,  "velocity": 85},
                {"instrument": "conga_mute","pulses": 3, "steps": 8,  "subdiv": 8,  "velocity": 70},
                {"instrument": "bongo_hi",  "pulses": 7, "steps": 16, "subdiv": 16, "velocity": 65},
                {"instrument": "bongo_lo",  "pulses": 3, "steps": 16, "subdiv": 16, "velocity": 60},
                {"instrument": "timbale_hi","pulses": 3, "steps": 8,  "subdiv": 8,  "velocity": 80},
                {"instrument": "cowbell",   "pulses": 4, "steps": 8,  "subdiv": 8,  "velocity": 70},
                {"instrument": "kick",      "pulses": 2, "steps": 4,  "subdiv": 4,  "velocity": 90},
                {"instrument": "maracas",   "pulses": 8, "steps": 16, "subdiv": 16, "velocity": 40},
                {"instrument": "guiro_short","pulses": 3, "steps": 16, "subdiv": 16, "velocity": 45, "probability": 0.5},
                {"instrument": "agogo_hi",  "pulses": 2, "steps": 8,  "subdiv": 8,  "velocity": 55, "probability": 0.3},
            ],
            "baroque": [
                {"instrument": "tom_floor_lo","pulses": 2, "steps": 4, "subdiv": 4,  "velocity": 65},
                {"instrument": "tambourine", "pulses": 2, "steps": 4, "subdiv": 4,  "velocity": 40},
                {"instrument": "triangle_open","pulses": 1,"steps": 4, "subdiv": 4,  "velocity": 50, "probability": 0.5},
            ],
            "classical": [
                {"instrument": "tom_floor_lo","pulses": 1, "steps": 4, "subdiv": 4,  "velocity": 60},
                {"instrument": "tom_floor_hi","pulses": 1, "steps": 8, "subdiv": 8,  "velocity": 50, "probability": 0.3},
                {"instrument": "triangle_mute","pulses": 2,"steps": 8, "subdiv": 8,  "velocity": 35, "probability": 0.4},
            ],
            "romantic": [
                {"instrument": "tom_floor_lo","pulses": 2, "steps": 8, "subdiv": 8,  "velocity": 55},
                {"instrument": "crash_1",    "pulses": 1, "steps": 16,"subdiv": 16,  "velocity": 70, "probability": 0.1},
                {"instrument": "triangle_open","pulses": 3,"steps": 8, "subdiv": 8,  "velocity": 40, "probability": 0.4},
            ],
            "impressionism": [
                {"instrument": "triangle_open","pulses": 3,"steps": 8, "subdiv": 8,  "velocity": 40},
                {"instrument": "tambourine", "pulses": 2, "steps": 8, "subdiv": 8,  "velocity": 35, "probability": 0.3},
                {"instrument": "cabasa",     "pulses": 2, "steps": 16,"subdiv": 16,  "velocity": 30, "probability": 0.2},
            ],
            "film": [
                {"instrument": "tom_floor_lo","pulses": 3, "steps": 8, "subdiv": 8,  "velocity": 105},
                {"instrument": "tom_lo",     "pulses": 2, "steps": 8, "subdiv": 8,   "velocity": 95},
                {"instrument": "tom_mid_lo", "pulses": 2, "steps": 8, "subdiv": 8,   "velocity": 90, "probability": 0.6},
                {"instrument": "tom_hi",     "pulses": 1, "steps": 8, "subdiv": 8,   "velocity": 85, "probability": 0.4},
                {"instrument": "crash_1",    "pulses": 1, "steps": 8, "subdiv": 8,   "velocity": 110},
                {"instrument": "kick",       "pulses": 2, "steps": 4, "subdiv": 4,   "velocity": 115},
            ],
            "ambient": [
                {"instrument": "maracas",    "pulses": 2, "steps": 16,"subdiv": 16,  "velocity": 25, "probability": 0.3},
                {"instrument": "cabasa",     "pulses": 1, "steps": 8, "subdiv": 8,   "velocity": 20, "probability": 0.2},
                {"instrument": "triangle_open","pulses": 1,"steps": 16,"subdiv": 16, "velocity": 30, "probability": 0.1},
            ],
            "minimalism": [
                {"instrument": "sidestick",  "pulses": 4, "steps": 8, "subdiv": 8,   "velocity": 65},
                {"instrument": "hh_closed",  "pulses": 5, "steps": 8, "subdiv": 8,   "velocity": 50},
                {"instrument": "woodblock_hi","pulses": 3,"steps": 16,"subdiv": 16,  "velocity": 55, "probability": 0.5},
                {"instrument": "woodblock_lo","pulses": 2,"steps": 16,"subdiv": 16,  "velocity": 50, "probability": 0.4},
                {"instrument": "claves",     "pulses": 3, "steps": 16,"subdiv": 16,  "velocity": 60, "probability": 0.3},
            ],
        }

        return styles.get(style, styles["rock"])

    def _math_fill(self, start_beat: float, bar: int,
                    rng: random.Random) -> List[Dict]:
        """Mathematisch generierter Drum-Fill.

        Nutzt Zelluläre Automaten (Rule 30/90/110) für das Pattern
        und Fibonacci-Abstände für die Tom-Kaskade.
        """
        gm = self.GM_DRUMS
        notes = []

        # Wähle CA-Regel basierend auf Bar-Nummer
        rules = [30, 90, 110]
        rule = rules[bar % len(rules)]

        # Zellulärer Automat für Fill-Pattern (8 Steps = 1 Beat)
        ca_pattern = self._cellular_automaton_pattern(rule, 8, seed_pos=bar % 8)

        # Tom-Auswahl nach Fibonacci-Spirale (hoch → tief)
        toms = [gm["tom_hi"], gm["tom_mid_hi"], gm["tom_mid_lo"],
                gm["tom_lo"], gm["tom_floor_hi"], gm["tom_floor_lo"]]

        phi = (1 + math.sqrt(5)) / 2
        step_dur = 1.0 / 8.0  # 32tel-Noten

        for i, active in enumerate(ca_pattern):
            if not active:
                continue

            beat = start_beat + i * step_dur

            # Tom-Auswahl: Golden Ratio Index
            tom_idx = int(i * phi) % len(toms)
            midi = toms[tom_idx]

            # Crescendo nach Fibonacci
            fib_vel = [70, 75, 80, 85, 90, 100, 110, 120]
            vel = fib_vel[min(i, len(fib_vel) - 1)]

            notes.append({
                "midi": midi,
                "start_beat": beat,
                "duration_beats": 0.1,
                "velocity": vel + rng.randint(-5, 5),
            })

        # Crash + Kick am Ende des Fills
        notes.append({
            "midi": gm["crash_1"],
            "start_beat": start_beat + 1.0,
            "duration_beats": 0.5,
            "velocity": 115,
        })
        notes.append({
            "midi": gm["kick"],
            "start_beat": start_beat + 1.0,
            "duration_beats": 0.1,
            "velocity": 120,
        })

        return notes

    def list_methods(self) -> List[str]:
        return ["markov", "fractal", "lsystem", "cantus"]

    def list_moods(self) -> List[str]:
        return list(StyleAdvisor.MOOD_TO_KEY.keys())
