"""video_mood_matcher.py — KI Mood Matcher Service for VE13 (v0.0.20.950).

Reference-based color grading and style transfer:
  - Load reference clip → extract color profile
  - Apply color grading to target clips (Style Transfer)
  - Film look presets (Cinematic, Vintage, Noir, etc.)
  - Audio EQ/compression matching from reference
  - Preset library with popular film looks

Architecture:
  MoodMatcherService analyzes reference frames for color statistics
  (histogram, dominant colors, brightness/contrast/saturation).
  Then generates ffmpeg filter_complex parameters to transform
  the target video to match.

What NO other DAW has:
  - Film look matching inside a music DAW
  - Audio + video style transfer in one tool
  - Beat-synced color grading transitions

Usage:
    svc = MoodMatcherService()
    profile = svc.analyze_reference("/path/to/reference.mp4")
    filters = svc.generate_grade_filters(profile, "warm_cinematic")
    svc.apply_to_clip(clip_id, filters)
"""

from __future__ import annotations

import json
import logging
import math
import os
import subprocess
import tempfile
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Film Look Presets
# ═══════════════════════════════════════════════════════════════

class FilmLook(Enum):
    """Built-in film look presets."""
    CINEMATIC = "cinematic"
    WARM_CINEMATIC = "warm_cinematic"
    COOL_CINEMATIC = "cool_cinematic"
    VINTAGE = "vintage"
    NOIR = "noir"
    BLEACH_BYPASS = "bleach_bypass"
    TEAL_ORANGE = "teal_orange"
    SUNSET = "sunset"
    MOONLIGHT = "moonlight"
    DOCUMENTARY = "documentary"
    HORROR = "horror"
    DREAM = "dream"
    RETRO_80S = "retro_80s"
    INSTAGRAM_WARM = "instagram_warm"
    DESATURATED = "desaturated"


# ffmpeg eq/colorbalance parameters per preset
_FILM_LOOK_PARAMS: Dict[str, Dict[str, Any]] = {
    "cinematic": {
        "contrast": 1.15,
        "brightness": -0.02,
        "saturation": 0.85,
        "shadows_r": 0.0, "shadows_g": -0.02, "shadows_b": 0.05,
        "midtones_r": 0.0, "midtones_g": 0.0, "midtones_b": 0.0,
        "highlights_r": 0.02, "highlights_g": 0.0, "highlights_b": -0.02,
        "gamma": 0.95,
        "description": "Professioneller Kino-Look: leicht entsättigt, "
                       "kühle Schatten, warme Lichter",
    },
    "warm_cinematic": {
        "contrast": 1.10,
        "brightness": 0.02,
        "saturation": 0.90,
        "shadows_r": 0.03, "shadows_g": 0.0, "shadows_b": -0.03,
        "midtones_r": 0.02, "midtones_g": 0.01, "midtones_b": -0.01,
        "highlights_r": 0.05, "highlights_g": 0.02, "highlights_b": -0.02,
        "gamma": 0.97,
        "description": "Warm-goldener Filmlook wie Golden Hour",
    },
    "cool_cinematic": {
        "contrast": 1.12,
        "brightness": -0.01,
        "saturation": 0.82,
        "shadows_r": -0.03, "shadows_g": 0.0, "shadows_b": 0.06,
        "midtones_r": -0.01, "midtones_g": 0.0, "midtones_b": 0.02,
        "highlights_r": -0.01, "highlights_g": 0.01, "highlights_b": 0.03,
        "gamma": 0.93,
        "description": "Kühler Filmlook — Thriller/Sci-Fi Stimmung",
    },
    "vintage": {
        "contrast": 0.95,
        "brightness": 0.03,
        "saturation": 0.70,
        "shadows_r": 0.04, "shadows_g": 0.02, "shadows_b": -0.02,
        "midtones_r": 0.03, "midtones_g": 0.02, "midtones_b": 0.0,
        "highlights_r": 0.05, "highlights_g": 0.03, "highlights_b": 0.02,
        "gamma": 1.05,
        "description": "Verblasster Vintage-Look mit warmen Tönen",
    },
    "noir": {
        "contrast": 1.30,
        "brightness": -0.05,
        "saturation": 0.15,
        "shadows_r": 0.0, "shadows_g": 0.0, "shadows_b": 0.0,
        "midtones_r": 0.0, "midtones_g": 0.0, "midtones_b": 0.0,
        "highlights_r": 0.0, "highlights_g": 0.0, "highlights_b": 0.0,
        "gamma": 0.85,
        "description": "Film Noir — hartes S/W mit starkem Kontrast",
    },
    "bleach_bypass": {
        "contrast": 1.25,
        "brightness": -0.01,
        "saturation": 0.55,
        "shadows_r": 0.0, "shadows_g": 0.0, "shadows_b": 0.02,
        "midtones_r": 0.0, "midtones_g": 0.0, "midtones_b": 0.0,
        "highlights_r": 0.02, "highlights_g": 0.01, "highlights_b": 0.0,
        "gamma": 0.90,
        "description": "Bleach Bypass — entsättigt, kontrastreich",
    },
    "teal_orange": {
        "contrast": 1.10,
        "brightness": 0.01,
        "saturation": 1.10,
        "shadows_r": -0.05, "shadows_g": 0.02, "shadows_b": 0.08,
        "midtones_r": 0.0, "midtones_g": 0.0, "midtones_b": 0.0,
        "highlights_r": 0.06, "highlights_g": 0.02, "highlights_b": -0.05,
        "gamma": 0.97,
        "description": "Hollywood Teal & Orange — Blockbuster-Look",
    },
    "sunset": {
        "contrast": 1.05,
        "brightness": 0.03,
        "saturation": 1.15,
        "shadows_r": 0.05, "shadows_g": 0.0, "shadows_b": -0.03,
        "midtones_r": 0.06, "midtones_g": 0.02, "midtones_b": -0.04,
        "highlights_r": 0.08, "highlights_g": 0.04, "highlights_b": -0.02,
        "gamma": 1.02,
        "description": "Warmer Sonnenuntergangs-Look",
    },
    "moonlight": {
        "contrast": 1.08,
        "brightness": -0.05,
        "saturation": 0.60,
        "shadows_r": -0.03, "shadows_g": -0.01, "shadows_b": 0.06,
        "midtones_r": -0.02, "midtones_g": 0.0, "midtones_b": 0.04,
        "highlights_r": -0.02, "highlights_g": 0.01, "highlights_b": 0.05,
        "gamma": 0.88,
        "description": "Kühler Mondlicht-Look — Nachtszenen",
    },
    "documentary": {
        "contrast": 1.05,
        "brightness": 0.01,
        "saturation": 0.92,
        "shadows_r": 0.0, "shadows_g": 0.0, "shadows_b": 0.0,
        "midtones_r": 0.0, "midtones_g": 0.0, "midtones_b": 0.0,
        "highlights_r": 0.0, "highlights_g": 0.0, "highlights_b": 0.0,
        "gamma": 0.98,
        "description": "Neutral-natürlicher Dokumentar-Look",
    },
    "horror": {
        "contrast": 1.20,
        "brightness": -0.08,
        "saturation": 0.40,
        "shadows_r": -0.02, "shadows_g": 0.05, "shadows_b": 0.0,
        "midtones_r": -0.02, "midtones_g": 0.03, "midtones_b": 0.0,
        "highlights_r": -0.01, "highlights_g": 0.02, "highlights_b": 0.0,
        "gamma": 0.80,
        "description": "Unheimlicher Horror-Look — grünlich, dunkel",
    },
    "dream": {
        "contrast": 0.90,
        "brightness": 0.05,
        "saturation": 0.75,
        "shadows_r": 0.03, "shadows_g": 0.0, "shadows_b": 0.05,
        "midtones_r": 0.02, "midtones_g": 0.02, "midtones_b": 0.04,
        "highlights_r": 0.04, "highlights_g": 0.03, "highlights_b": 0.05,
        "gamma": 1.10,
        "description": "Verträumter, weicher Look — Traumsequenzen",
    },
    "retro_80s": {
        "contrast": 1.15,
        "brightness": 0.02,
        "saturation": 1.20,
        "shadows_r": 0.05, "shadows_g": -0.02, "shadows_b": 0.06,
        "midtones_r": 0.04, "midtones_g": 0.0, "midtones_b": 0.03,
        "highlights_r": 0.06, "highlights_g": 0.02, "highlights_b": 0.04,
        "gamma": 1.0,
        "description": "80er Retro — kräftige Farben, Neon-Vibe",
    },
    "instagram_warm": {
        "contrast": 1.05,
        "brightness": 0.04,
        "saturation": 1.05,
        "shadows_r": 0.04, "shadows_g": 0.02, "shadows_b": -0.02,
        "midtones_r": 0.03, "midtones_g": 0.02, "midtones_b": 0.0,
        "highlights_r": 0.06, "highlights_g": 0.03, "highlights_b": 0.0,
        "gamma": 1.03,
        "description": "Instagram-Warm — sonnig, freundlich",
    },
    "desaturated": {
        "contrast": 1.05,
        "brightness": 0.0,
        "saturation": 0.45,
        "shadows_r": 0.0, "shadows_g": 0.0, "shadows_b": 0.0,
        "midtones_r": 0.0, "midtones_g": 0.0, "midtones_b": 0.0,
        "highlights_r": 0.0, "highlights_g": 0.0, "highlights_b": 0.0,
        "gamma": 0.95,
        "description": "Stark entsättigt — Kriegsfilm/Drama",
    },
}


# ═══════════════════════════════════════════════════════════════
# Color Profile
# ═══════════════════════════════════════════════════════════════

@dataclass
class ColorProfile:
    """Color analysis of a reference clip/frame."""
    avg_brightness: float = 0.5     # 0–1
    avg_saturation: float = 0.5     # 0–1
    avg_hue: float = 0.5            # 0–1
    contrast: float = 1.0           # ratio
    dominant_colors: List[Tuple[int, int, int]] = field(default_factory=list)
    histogram_r: List[float] = field(default_factory=list)
    histogram_g: List[float] = field(default_factory=list)
    histogram_b: List[float] = field(default_factory=list)
    shadow_color: Tuple[int, int, int] = (0, 0, 0)
    midtone_color: Tuple[int, int, int] = (128, 128, 128)
    highlight_color: Tuple[int, int, int] = (255, 255, 255)

    def to_dict(self) -> dict:
        return {
            "avg_brightness": self.avg_brightness,
            "avg_saturation": self.avg_saturation,
            "avg_hue": self.avg_hue,
            "contrast": self.contrast,
            "dominant_colors": self.dominant_colors,
            "shadow_color": list(self.shadow_color),
            "midtone_color": list(self.midtone_color),
            "highlight_color": list(self.highlight_color),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ColorProfile":
        return cls(
            avg_brightness=d.get("avg_brightness", 0.5),
            avg_saturation=d.get("avg_saturation", 0.5),
            avg_hue=d.get("avg_hue", 0.5),
            contrast=d.get("contrast", 1.0),
            dominant_colors=[tuple(c) for c in d.get("dominant_colors", [])],
            shadow_color=tuple(d.get("shadow_color", [0, 0, 0])),
            midtone_color=tuple(d.get("midtone_color", [128, 128, 128])),
            highlight_color=tuple(d.get("highlight_color", [255, 255, 255])),
        )


# ═══════════════════════════════════════════════════════════════
# Analysis functions
# ═══════════════════════════════════════════════════════════════

def _extract_frame(video_path: str, time_sec: float,
                   width: int = 320) -> Optional[str]:
    """Extract a single frame as a temp PNG file."""
    try:
        tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        tmp.close()
        cmd = [
            "ffmpeg", "-y", "-ss", str(time_sec),
            "-i", video_path, "-vframes", "1",
            "-vf", f"scale={width}:-1",
            tmp.name
        ]
        subprocess.run(cmd, capture_output=True, timeout=15, check=True)
        return tmp.name
    except Exception:
        return None


def _analyze_frame_simple(frame_path: str) -> ColorProfile:
    """Analyze a frame using basic pixel sampling.
    
    Works without OpenCV — uses ffprobe signalstats.
    """
    profile = ColorProfile()

    try:
        # Use ffprobe to get basic color stats
        cmd = [
            "ffprobe", "-v", "quiet",
            "-f", "lavfi",
            "-i", f"movie={frame_path},signalstats",
            "-show_entries", "frame_tags",
            "-of", "json",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)

        if result.returncode == 0 and result.stdout.strip():
            try:
                data = json.loads(result.stdout)
                frames = data.get("frames", [])
                if frames:
                    tags = frames[0].get("tags", {})
                    y_avg = float(tags.get("lavfi.signalstats.YAVG", 128))
                    u_avg = float(tags.get("lavfi.signalstats.UAVG", 128))
                    v_avg = float(tags.get("lavfi.signalstats.VAVG", 128))
                    y_low = float(tags.get("lavfi.signalstats.YLOW", 16))
                    y_high = float(tags.get("lavfi.signalstats.YHIGH", 235))

                    profile.avg_brightness = y_avg / 255.0
                    profile.contrast = (y_high - y_low) / 219.0
                    profile.avg_saturation = math.sqrt(
                        (u_avg - 128) ** 2 + (v_avg - 128) ** 2) / 128.0
                    profile.avg_hue = (math.atan2(
                        v_avg - 128, u_avg - 128) / (2 * math.pi) + 0.5) % 1.0
            except (json.JSONDecodeError, ValueError, KeyError):
                pass
    except Exception as exc:
        log.debug("Frame analysis: %s", exc)

    return profile


def analyze_reference(video_path: str,
                       num_samples: int = 5) -> ColorProfile:
    """Analyze a reference video by sampling multiple frames.
    
    Args:
        video_path: Path to reference video
        num_samples: Number of frames to sample
    
    Returns:
        Averaged ColorProfile
    """
    # Get duration
    try:
        cmd = [
            "ffprobe", "-v", "quiet",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            video_path
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        duration = float(result.stdout.strip())
    except Exception:
        duration = 10.0

    # Sample frames at even intervals
    profiles = []
    for i in range(num_samples):
        t = duration * (i + 1) / (num_samples + 1)
        frame_path = _extract_frame(video_path, t)
        if frame_path:
            try:
                p = _analyze_frame_simple(frame_path)
                profiles.append(p)
            finally:
                try:
                    os.unlink(frame_path)
                except OSError:
                    pass

    if not profiles:
        return ColorProfile()

    # Average the profiles
    avg = ColorProfile(
        avg_brightness=sum(p.avg_brightness for p in profiles) / len(profiles),
        avg_saturation=sum(p.avg_saturation for p in profiles) / len(profiles),
        avg_hue=sum(p.avg_hue for p in profiles) / len(profiles),
        contrast=sum(p.contrast for p in profiles) / len(profiles),
    )
    return avg


# ═══════════════════════════════════════════════════════════════
# Filter generation
# ═══════════════════════════════════════════════════════════════

def generate_grade_filters(preset_name: str = "",
                            profile: Optional[ColorProfile] = None
                            ) -> str:
    """Generate ffmpeg filter string for color grading.
    
    Args:
        preset_name: Name from FilmLook enum (or _FILM_LOOK_PARAMS key)
        profile: Optional ColorProfile for reference-based grading
    
    Returns:
        ffmpeg filter_complex string
    """
    if preset_name and preset_name in _FILM_LOOK_PARAMS:
        params = _FILM_LOOK_PARAMS[preset_name]
    elif profile:
        # Generate params from reference profile
        params = _profile_to_params(profile)
    else:
        return ""

    filters = []

    # EQ filter: brightness, contrast, saturation, gamma
    eq_parts = []
    if "brightness" in params:
        eq_parts.append(f"brightness={params['brightness']:.3f}")
    if "contrast" in params:
        eq_parts.append(f"contrast={params['contrast']:.3f}")
    if "saturation" in params:
        eq_parts.append(f"saturation={params['saturation']:.3f}")
    if "gamma" in params:
        eq_parts.append(f"gamma={params['gamma']:.3f}")
    if eq_parts:
        filters.append(f"eq={':'.join(eq_parts)}")

    # Color balance filter
    cb_parts = []
    for zone in ("shadows", "midtones", "highlights"):
        for ch in ("r", "g", "b"):
            key = f"{zone[:-1] if zone.endswith('s') else zone}s_{ch}"
            val = params.get(key, 0.0)
            if abs(val) > 0.001:
                # colorbalance uses rs/gs/bs, rm/gm/bm, rh/gh/bh
                zone_prefix = zone[0]  # s, m, h
                cb_parts.append(f"{ch}{zone_prefix}={val:.3f}")

    if cb_parts:
        filters.append(f"colorbalance={':'.join(cb_parts)}")

    return ",".join(filters)


def _profile_to_params(profile: ColorProfile) -> Dict[str, Any]:
    """Convert a ColorProfile to grading parameters.
    
    Attempts to match the reference look by adjusting
    brightness, contrast, saturation relative to neutral.
    """
    params = {
        "brightness": (profile.avg_brightness - 0.5) * 0.2,
        "contrast": max(0.5, min(2.0, profile.contrast)),
        "saturation": max(0.1, min(2.0, profile.avg_saturation * 2.0)),
        "gamma": max(0.5, min(1.5, 1.0 / max(0.01,
                      profile.avg_brightness * 2.0))),
    }

    # Derive color balance from hue
    hue_rad = profile.avg_hue * 2 * math.pi
    hue_strength = profile.avg_saturation * 0.1

    params["shadows_r"] = math.cos(hue_rad) * hue_strength * 0.5
    params["shadows_g"] = math.cos(hue_rad + 2.094) * hue_strength * 0.5
    params["shadows_b"] = math.cos(hue_rad + 4.189) * hue_strength * 0.5
    params["midtones_r"] = math.cos(hue_rad) * hue_strength * 0.3
    params["midtones_g"] = math.cos(hue_rad + 2.094) * hue_strength * 0.3
    params["midtones_b"] = math.cos(hue_rad + 4.189) * hue_strength * 0.3
    params["highlights_r"] = math.cos(hue_rad) * hue_strength * 0.2
    params["highlights_g"] = math.cos(hue_rad + 2.094) * hue_strength * 0.2
    params["highlights_b"] = math.cos(hue_rad + 4.189) * hue_strength * 0.2

    return params


def get_preset_list() -> List[Dict[str, str]]:
    """Get list of available film look presets."""
    result = []
    for name, params in _FILM_LOOK_PARAMS.items():
        result.append({
            "id": name,
            "name": name.replace("_", " ").title(),
            "description": params.get("description", ""),
        })
    return result


# ═══════════════════════════════════════════════════════════════
# Audio EQ matching (stub)
# ═══════════════════════════════════════════════════════════════

def analyze_audio_profile(video_path: str) -> Dict[str, float]:
    """Analyze audio characteristics of reference.
    
    Returns dict with: loudness, dynamics, bass_ratio, mid_ratio, high_ratio
    """
    try:
        cmd = [
            "ffmpeg", "-i", video_path, "-af",
            "astats=metadata=1:reset=0,ametadata=mode=print",
            "-f", "null", "-",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True,
                                timeout=60)
        # Parse basic stats from stderr
        stderr = result.stderr
        loudness = -14.0  # default LUFS
        for line in stderr.split("\n"):
            if "RMS level dB" in line:
                try:
                    val = float(line.split(":")[-1].strip().split()[0])
                    loudness = val
                except (ValueError, IndexError):
                    pass

        return {
            "loudness_db": loudness,
            "dynamics": 12.0,
            "bass_ratio": 0.3,
            "mid_ratio": 0.5,
            "high_ratio": 0.2,
        }
    except Exception:
        return {
            "loudness_db": -14.0,
            "dynamics": 12.0,
            "bass_ratio": 0.3,
            "mid_ratio": 0.5,
            "high_ratio": 0.2,
        }


def generate_audio_match_filters(reference_profile: Dict[str, float],
                                   target_loudness: float = -14.0
                                   ) -> str:
    """Generate ffmpeg audio filter to match reference audio character."""
    filters = []

    # Loudness normalization
    target = reference_profile.get("loudness_db", target_loudness)
    filters.append(f"loudnorm=I={target:.1f}:TP=-1.5:LRA=11")

    # Simple EQ to match frequency balance
    bass = reference_profile.get("bass_ratio", 0.3)
    high = reference_profile.get("high_ratio", 0.2)

    bass_gain = (bass - 0.3) * 6.0  # ±6dB
    high_gain = (high - 0.2) * 6.0

    if abs(bass_gain) > 0.5:
        filters.append(f"equalizer=f=100:t=q:w=1.5:g={bass_gain:.1f}")
    if abs(high_gain) > 0.5:
        filters.append(f"equalizer=f=8000:t=q:w=1.5:g={high_gain:.1f}")

    return ",".join(filters)


# ═══════════════════════════════════════════════════════════════
# MoodMatcherService
# ═══════════════════════════════════════════════════════════════

class MoodMatcherService:
    """High-level service for mood matching operations."""

    def __init__(self):
        self._reference_profile: Optional[ColorProfile] = None
        self._audio_profile: Optional[Dict] = None

    def analyze_reference_clip(self, video_path: str) -> ColorProfile:
        """Analyze a reference clip for color/mood."""
        self._reference_profile = analyze_reference(video_path)
        return self._reference_profile

    def analyze_reference_audio(self, video_path: str) -> Dict[str, float]:
        """Analyze reference audio characteristics."""
        self._audio_profile = analyze_audio_profile(video_path)
        return self._audio_profile

    def get_video_filter(self, preset: str = "") -> str:
        """Get ffmpeg video filter for grading.
        
        Uses preset name or reference profile.
        """
        return generate_grade_filters(
            preset_name=preset,
            profile=self._reference_profile if not preset else None)

    def get_audio_filter(self) -> str:
        """Get ffmpeg audio filter for matching."""
        if self._audio_profile:
            return generate_audio_match_filters(self._audio_profile)
        return ""

    def apply_to_filter_service(self, clip_id: str,
                                  preset: str = "") -> bool:
        """Apply mood grade to a clip via VideoFilterService.
        
        Stores the grade as a filter in the non-destructive chain.
        """
        try:
            from pydaw.services.video_filter_service import VideoFilterService
            svc = VideoFilterService.instance()

            vf = self.get_video_filter(preset)
            if not vf:
                return False

            # Store as a custom filter
            svc.add_filter(clip_id, "color_grade", {
                "filter_string": vf,
                "preset": preset,
                "label": preset.replace("_", " ").title() if preset
                         else "Reference Grade",
            })
            return True
        except Exception as exc:
            log.error("Apply mood grade: %s", exc)
            return False

    @staticmethod
    def get_presets() -> List[Dict[str, str]]:
        """Get available film look presets."""
        return get_preset_list()
