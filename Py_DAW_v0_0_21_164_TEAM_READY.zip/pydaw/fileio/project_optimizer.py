# -*- coding: utf-8 -*-
"""Project Package Optimization — Dedup, Incremental, Archive.

v0.0.21.026 — Block D Phase D3.1–D3.3

Optimizes project storage with sample deduplication, incremental saves,
and compressed project archives (.pdaz).

Usage:
    from pydaw.fileio.project_optimizer import ProjectOptimizer

    opt = ProjectOptimizer(project_path)
    opt.deduplicate_samples()    # SHA-256 hash → global pool
    opt.save_incremental()       # Only changed tracks/clips
    opt.export_archive("project.pdaz")  # Compressed archive
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

log = logging.getLogger(__name__)

try:
    import zstd as _zstd
    _ZSTD = True
except ImportError:
    try:
        import zstandard as _zstd
        _ZSTD = True
    except ImportError:
        _ZSTD = False

PDAZ_MAGIC = b"PDAZ"
PDAZ_VERSION = 1


def _sha256_file(path: Path, chunk_size: int = 65536) -> str:
    """Compute SHA-256 hash of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


class SamplePool:
    """D3.1: Global sample pool with SHA-256 deduplication.

    Stores samples by hash in a central pool directory.
    Projects reference hashes instead of file paths.
    """

    def __init__(self, pool_dir: str | Path):
        self.pool_dir = Path(pool_dir)
        self.pool_dir.mkdir(parents=True, exist_ok=True)
        self._index: Dict[str, str] = {}  # hash → filename
        self._load_index()

    def _index_path(self) -> Path:
        return self.pool_dir / "pool_index.json"

    def _load_index(self) -> None:
        idx = self._index_path()
        if idx.exists():
            try:
                self._index = json.loads(idx.read_text("utf-8"))
            except Exception:
                self._index = {}

    def _save_index(self) -> None:
        try:
            self._index_path().write_text(
                json.dumps(self._index, indent=2), "utf-8")
        except Exception as e:
            log.warning("[POOL] Index save failed: %s", e)

    def add(self, file_path: Path) -> str:
        """Add a file to the pool. Returns its hash."""
        h = _sha256_file(file_path)
        if h not in self._index:
            ext = file_path.suffix
            pool_name = f"{h[:16]}{ext}"
            pool_path = self.pool_dir / pool_name
            if not pool_path.exists():
                shutil.copy2(str(file_path), str(pool_path))
            self._index[h] = pool_name
            self._save_index()
            log.info("[POOL] Added: %s → %s", file_path.name, pool_name)
        return h

    def get_path(self, hash_str: str) -> Optional[Path]:
        """Get the pool file path for a hash."""
        name = self._index.get(hash_str)
        if name:
            p = self.pool_dir / name
            if p.exists():
                return p
        return None

    def contains(self, hash_str: str) -> bool:
        return hash_str in self._index

    def stats(self) -> Dict[str, Any]:
        total_size = sum(
            (self.pool_dir / name).stat().st_size
            for name in self._index.values()
            if (self.pool_dir / name).exists()
        )
        return {
            "files": len(self._index),
            "size_mb": round(total_size / (1024 * 1024), 1),
        }


class ProjectOptimizer:
    """Optimize project storage."""

    def __init__(self, project_path: str | Path):
        self.project_path = Path(project_path)
        self.project_dir = self.project_path.parent
        self.media_dir = self.project_dir / "media"

    def deduplicate_samples(self, pool_dir: Optional[str | Path] = None) -> Dict[str, Any]:
        """D3.1: Find and deduplicate identical samples.

        Returns stats: {"duplicates": int, "saved_mb": float, "unique": int}
        """
        if pool_dir is None:
            pool_dir = self.project_dir / ".sample_pool"
        pool = SamplePool(pool_dir)

        if not self.media_dir.exists():
            return {"duplicates": 0, "saved_mb": 0, "unique": 0}

        hashes: Dict[str, List[Path]] = {}
        for f in self.media_dir.rglob("*"):
            if f.is_file() and f.suffix.lower() in {
                ".wav", ".flac", ".ogg", ".mp3", ".aiff", ".aif", ".pdac"
            }:
                h = _sha256_file(f)
                hashes.setdefault(h, []).append(f)
                pool.add(f)

        duplicates = 0
        saved_bytes = 0
        for h, files in hashes.items():
            if len(files) > 1:
                # Keep first, count rest as duplicates
                for dup in files[1:]:
                    duplicates += 1
                    saved_bytes += dup.stat().st_size

        unique = len(hashes)
        saved_mb = saved_bytes / (1024 * 1024)

        log.info(
            "[DEDUP] %d unique samples, %d duplicates (%.1f MB reclaimable)",
            unique, duplicates, saved_mb,
        )
        return {
            "duplicates": duplicates,
            "saved_mb": round(saved_mb, 1),
            "unique": unique,
            "pool_stats": pool.stats(),
        }

    def save_incremental(self, base_path: Optional[str | Path] = None) -> Path:
        """D3.2: Save only changed data as a delta file.

        Creates a .pydaw.delta.json containing only tracks/clips that
        changed since the last full save.
        """
        if base_path is None:
            base_path = self.project_path

        base_path = Path(base_path)
        if not base_path.exists():
            # No base → full save
            return base_path

        try:
            current = json.loads(self.project_path.read_text("utf-8"))
            base = json.loads(base_path.read_text("utf-8"))
        except Exception:
            return base_path

        delta = {"_delta_version": 1, "_base": str(base_path.name)}
        changed = False

        # Compare tracks
        curr_tracks = {t.get("id", ""): t for t in current.get("tracks", [])}
        base_tracks = {t.get("id", ""): t for t in base.get("tracks", [])}

        delta_tracks = []
        for tid, track in curr_tracks.items():
            if tid not in base_tracks or track != base_tracks[tid]:
                delta_tracks.append(track)
                changed = True
        if delta_tracks:
            delta["tracks"] = delta_tracks

        # Compare clips
        curr_clips = {c.get("id", ""): c for c in current.get("clips", [])}
        base_clips = {c.get("id", ""): c for c in base.get("clips", [])}

        delta_clips = []
        for cid, clip in curr_clips.items():
            if cid not in base_clips or clip != base_clips[cid]:
                delta_clips.append(clip)
                changed = True
        if delta_clips:
            delta["clips"] = delta_clips

        # Top-level fields
        for key in ("bpm", "time_signature", "name", "sample_rate"):
            if current.get(key) != base.get(key):
                delta[key] = current[key]
                changed = True

        if not changed:
            log.info("[INCREMENTAL] No changes detected")
            return base_path

        delta_path = self.project_path.with_suffix(".delta.json")
        delta_path.write_text(json.dumps(delta, separators=(",", ":")), "utf-8")

        orig_size = self.project_path.stat().st_size
        delta_size = delta_path.stat().st_size
        log.info(
            "[INCREMENTAL] Delta: %d bytes (%.0f%% of full %d bytes)",
            delta_size, delta_size / max(1, orig_size) * 100, orig_size,
        )
        return delta_path

    def export_archive(self, output_path: str | Path,
                       include_media: bool = True,
                       compress_samples: bool = False) -> Path:
        """D3.3: Export project as .pdaz archive.

        Structure:
            project.json (zstd compressed)
            media/ (original or PDAC compressed samples)
            presets/ (plugin presets)
            manifest.json (file list + hashes)
        """
        import tempfile
        import zipfile

        output_path = Path(output_path)
        if not output_path.suffix:
            output_path = output_path.with_suffix(".pdaz")

        # Build manifest
        manifest = {
            "format": "pdaz",
            "version": PDAZ_VERSION,
            "files": [],
        }

        with zipfile.ZipFile(str(output_path), "w", zipfile.ZIP_DEFLATED) as zf:
            # Project JSON
            if self.project_path.exists():
                project_data = self.project_path.read_bytes()
                if _ZSTD:
                    try:
                        cctx = _zstd.ZstdCompressor(level=10) if hasattr(_zstd, 'ZstdCompressor') else None
                        if cctx:
                            compressed = cctx.compress(project_data)
                            zf.writestr("project.json.zst", compressed)
                            manifest["files"].append({
                                "path": "project.json.zst",
                                "compressed": "zstd",
                                "orig_size": len(project_data),
                            })
                        else:
                            zf.writestr("project.json", project_data)
                            manifest["files"].append({"path": "project.json"})
                    except Exception:
                        zf.writestr("project.json", project_data)
                        manifest["files"].append({"path": "project.json"})
                else:
                    zf.writestr("project.json", project_data)
                    manifest["files"].append({"path": "project.json"})

            # Media files
            if include_media and self.media_dir.exists():
                for f in self.media_dir.rglob("*"):
                    if f.is_file():
                        rel = f.relative_to(self.project_dir)
                        h = _sha256_file(f)
                        zf.write(str(f), str(rel))
                        manifest["files"].append({
                            "path": str(rel),
                            "hash": h,
                            "size": f.stat().st_size,
                        })

            # Manifest
            zf.writestr("manifest.json",
                         json.dumps(manifest, indent=2, ensure_ascii=False))

        archive_size = output_path.stat().st_size
        log.info(
            "[PDAZ] Archive: %s (%.1f MB, %d files)",
            output_path.name, archive_size / (1024 * 1024), len(manifest["files"]),
        )
        return output_path

    @staticmethod
    def import_archive(archive_path: str | Path,
                       target_dir: str | Path) -> Path:
        """Import a .pdaz archive."""
        import zipfile

        archive_path = Path(archive_path)
        target_dir = Path(target_dir)
        target_dir.mkdir(parents=True, exist_ok=True)

        with zipfile.ZipFile(str(archive_path), "r") as zf:
            # Check for zstd-compressed project
            names = zf.namelist()
            if "project.json.zst" in names:
                data = zf.read("project.json.zst")
                if _ZSTD:
                    try:
                        dctx = _zstd.ZstdDecompressor() if hasattr(_zstd, 'ZstdDecompressor') else None
                        if dctx:
                            project_data = dctx.decompress(data)
                            (target_dir / "project.pydaw.json").write_bytes(project_data)
                    except Exception:
                        zf.extract("project.json.zst", str(target_dir))
            elif "project.json" in names:
                project_data = zf.read("project.json")
                (target_dir / "project.pydaw.json").write_bytes(project_data)

            # Extract media
            for name in names:
                if name.startswith("media/"):
                    zf.extract(name, str(target_dir))

        project_path = target_dir / "project.pydaw.json"
        log.info("[PDAZ] Imported: %s → %s", archive_path.name, target_dir)
        return project_path
