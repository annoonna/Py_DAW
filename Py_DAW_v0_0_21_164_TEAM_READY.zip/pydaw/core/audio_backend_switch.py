"""Audio Backend Kill Switch — Python ↔ Rust Toggle.

v0.0.21.053: Granulare Feature-Flags für schrittweise Rust-Migration (R1).
v0.0.21.052: Sauberer Kippschalter zwischen Python-Audio und Rust-Audio.

Regeln:
  - EINE Quelle der Wahrheit: dieser Modul
  - Wenn Python aktiv: Rust macht NULL Audio (nur Plugin-Scan)
  - Wenn Rust aktiv: Python macht NULL Audio (komplett still)
  - Kein Mischbetrieb, keine Durchleitung
  - Default: Python (sicher, getestet, funktioniert)

Verwendung:
  from pydaw.core.audio_backend_switch import audio_switch

  if audio_switch.is_rust():
      # Rust-Audio-Pfad
  else:
      # Python-Audio-Pfad

  # Toggle:
  audio_switch.set_rust(True)   # → Rust
  audio_switch.set_rust(False)  # → Python

Entfernen (später):
  1. Alle `if audio_switch.is_rust()` durch `True` ersetzen
  2. Alle `else` Python-Pfade löschen
  3. Dieses Modul löschen
"""

from __future__ import annotations

import logging

_log = logging.getLogger(__name__)

# QSettings key
_SETTINGS_KEY = "audio/backend_switch"  # "python" oder "rust"


class AudioBackendSwitch:
    """Singleton kill switch: Python oder Rust, nie beides."""

    def __init__(self) -> None:
        self._rust_active: bool = False  # Default: Python
        self._load()

    def _load(self) -> None:
        """Lade gespeicherten Zustand aus QSettings."""
        try:
            from PyQt6.QtCore import QSettings
            s = QSettings("PyDAW", "Py DAW")
            val = str(s.value(_SETTINGS_KEY, "python") or "python")
            self._rust_active = (val == "rust")
        except Exception:
            self._rust_active = False  # Fallback: Python

    def _save(self) -> None:
        """Speichere Zustand in QSettings."""
        try:
            from PyQt6.QtCore import QSettings
            s = QSettings("PyDAW", "Py DAW")
            s.setValue(_SETTINGS_KEY, "rust" if self._rust_active else "python")
            s.sync()
        except Exception:
            pass

    # --- Public API ---

    def is_rust(self) -> bool:
        """True wenn Rust-Audio aktiv, False wenn Python-Audio aktiv."""
        return self._rust_active

    def is_python(self) -> bool:
        """True wenn Python-Audio aktiv, False wenn Rust-Audio aktiv."""
        return not self._rust_active

    def set_rust(self, enabled: bool) -> None:
        """Schalte auf Rust-Audio (True) oder Python-Audio (False).

        ACHTUNG: Erfordert Neustart der Audio-Engine!
        """
        old = self._rust_active
        self._rust_active = bool(enabled)
        self._save()
        if old != self._rust_active:
            mode = "RUST" if self._rust_active else "PYTHON"
            _log.info("[AUDIO-SWITCH] Backend gewechselt → %s", mode)

    def toggle(self) -> bool:
        """Toggle zwischen Python und Rust. Gibt neuen Zustand zurück."""
        self.set_rust(not self._rust_active)
        return self._rust_active

    def label(self) -> str:
        """Menschenlesbares Label für UI."""
        return "🦀 Rust Audio" if self._rust_active else "🐍 Python Audio"

    def __repr__(self) -> str:
        return f"AudioBackendSwitch(rust={self._rust_active})"

    # --- R1: Granulare Feature-Flags (v0.0.21.053) ---

    def is_rust_audio_clips(self) -> bool:
        """True wenn Rust Audio-Clips rendert (Phase R1).

        Wenn True: Rust rendert Audio-Clips via cpal,
        Python rendert MIDI/Instrumente/FX via SharedAudioRing.
        Kann unabhängig vom Hauptschalter aktiviert werden.
        """
        try:
            from PyQt6.QtCore import QSettings
            s = QSettings("PyDAW", "Py DAW")
            return str(s.value("audio/rust_audio_clips", "false") or "false") == "true"
        except Exception:
            return False

    def set_rust_audio_clips(self, enabled: bool) -> None:
        """Aktiviert/deaktiviert Rust Audio-Clip Rendering (Phase R1)."""
        try:
            from PyQt6.QtCore import QSettings
            s = QSettings("PyDAW", "Py DAW")
            s.setValue("audio/rust_audio_clips", "true" if enabled else "false")
            s.sync()
            mode = "ON" if enabled else "OFF"
            _log.info("[AUDIO-SWITCH] Rust Audio-Clips → %s", mode)
        except Exception:
            pass

    # --- R2: MIDI Instruments (v0.0.21.053) ---

    def is_rust_midi_instruments(self) -> bool:
        """True wenn Rust MIDI-Instrumente rendert (Phase R2).

        Wenn True: Rust spielt MIDI-Noten über eingebaute Instrumente
        (ProSampler, DrumMachine, Aeterna, Fusion, MultiSample).
        Python-Instrument-Engines werden übersprungen.
        Setzt R1 (rust_audio_clips) voraus.
        """
        try:
            from PyQt6.QtCore import QSettings
            s = QSettings("PyDAW", "Py DAW")
            return str(s.value("audio/rust_midi_instruments", "false") or "false") == "true"
        except Exception:
            return False

    def set_rust_midi_instruments(self, enabled: bool) -> None:
        """Aktiviert/deaktiviert Rust MIDI-Instrument Rendering (Phase R2)."""
        try:
            from PyQt6.QtCore import QSettings
            s = QSettings("PyDAW", "Py DAW")
            s.setValue("audio/rust_midi_instruments", "true" if enabled else "false")
            s.sync()
            mode = "ON" if enabled else "OFF"
            _log.info("[AUDIO-SWITCH] Rust MIDI-Instruments → %s", mode)
        except Exception:
            pass

    # --- R4: FX Chain (v0.0.21.054) ---

    def is_rust_fx_chain(self) -> bool:
        """True wenn Rust Audio-FX-Chains rendert (Phase R4).

        Wenn True: Rust wendet FX (Gain, EQ, Compressor, Reverb, Delay) an.
        Python-FX-Processing wird übersprungen.
        """
        try:
            from PyQt6.QtCore import QSettings
            s = QSettings("PyDAW", "Py DAW")
            return str(s.value("audio/rust_fx_chain", "false") or "false") == "true"
        except Exception:
            return False

    def set_rust_fx_chain(self, enabled: bool) -> None:
        """Aktiviert/deaktiviert Rust FX-Chain (Phase R4)."""
        try:
            from PyQt6.QtCore import QSettings
            s = QSettings("PyDAW", "Py DAW")
            s.setValue("audio/rust_fx_chain", "true" if enabled else "false")
            s.sync()
            _log.info("[AUDIO-SWITCH] Rust FX-Chain → %s", "ON" if enabled else "OFF")
        except Exception:
            pass

    # --- R5: Plugin Hosting (v0.0.21.055) ---

    def is_rust_plugin_host(self) -> bool:
        """True wenn Rust VST3/CLAP/LV2 Plugins hostet (Phase R5)."""
        try:
            from PyQt6.QtCore import QSettings
            s = QSettings("PyDAW", "Py DAW")
            return str(s.value("audio/rust_plugin_host", "false") or "false") == "true"
        except Exception:
            return False

    def set_rust_plugin_host(self, enabled: bool) -> None:
        """Aktiviert/deaktiviert Rust Plugin-Hosting (Phase R5)."""
        try:
            from PyQt6.QtCore import QSettings
            s = QSettings("PyDAW", "Py DAW")
            s.setValue("audio/rust_plugin_host", "true" if enabled else "false")
            s.sync()
            _log.info("[AUDIO-SWITCH] Rust Plugin-Host → %s", "ON" if enabled else "OFF")
        except Exception:
            pass


# Singleton
audio_switch = AudioBackendSwitch()
