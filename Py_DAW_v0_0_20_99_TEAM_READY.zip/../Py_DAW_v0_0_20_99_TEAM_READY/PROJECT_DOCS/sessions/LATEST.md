## LATEST: v0.0.20.98 (2026-02-21)

**Ruler-Zoom: Full Ruler = Zoom Zone (Bitwig/Ableton-style)**

Magnifier-Cursor erscheint jetzt beim Hover über dem GESAMTEN Ruler (nicht nur obere 14px).
Loop-Handles behalten Priorität. Doppelklick im Ruler = Zoom Reset.

Geändert: arranger_canvas.py, arranger.py
Bearbeiter: Claude Opus 4.6

