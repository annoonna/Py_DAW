# 📋 Brief an Kollegen — v0.0.20.16 GPU Waveforms Toggle

**Datum:** 2026-02-08  
**Version:** v0.0.20.16 (Basis: v0.0.20.15)  
**Status:** ✅ FERTIG

---

## Hintergrund
In v0.0.20.14/15 konnte das OpenGL-Waveform-Overlay je nach Driver/Compositor den Arranger-Grid optisch verdecken (wirkt wie „Arranger kaputt“).

## Was wurde geändert?
- Neues View-Menü: **Ansicht → GPU Waveforms** (checkable)
- Shortcut: **Ctrl+Shift+G**
- Persistenz über Settings-Key: `ui/gpu_waveforms_enabled`
- Statusbar-Indikator: **GPU: ON/OFF** (permanent widget)
- ArrangerCanvas: `set_gpu_waveforms_enabled(True/False)` erstellt/zerstört Overlay zur Laufzeit
- Debug (optional): `PYDAW_GPU_WAVEFORMS=1` erzwingt beim Start ON (nicht nötig für normalen Betrieb)

## Technische Notizen
- Damit der Cursor korrekt sitzt, wird der Playhead ins Overlay in **Pixel-Koordinaten** übergeben:
  `playhead_px = beat * pixels_per_beat`
- Zoom-Änderungen syncen das Overlay automatisch.

## Test-Checkliste
1. Starten → Arranger muss normal sichtbar sein (Grid nicht verdeckt)
2. Ansicht → GPU Waveforms AN → Overlay erscheint
3. Ansicht → GPU Waveforms AUS → Arranger sofort wieder clean
4. Zoom +/- → Overlay bleibt aligned

## Nächste sinnvolle Schritte (optional)
- Overlay in Beat/Track-Koordinaten statt Pixel-Space rechnen (sauberer, v. a. für Playhead/Viewport)
- Echte Waveform-Peaks an Overlay übergeben (aktuell nur Clip-Rechtecke)
