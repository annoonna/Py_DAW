# -*- coding: utf-8 -*-
"""VST2 Worker Process — Sandboxed VST2 plugin hosting via ctypes.

v0.0.20.706 — Phase P3A/P3B

Runs as a subprocess. Loads a VST2 plugin via the existing vst2_host.py
ctypes layer, processes audio from shared memory, handles MIDI + state via IPC.

Supports both FX and Instrument modes.
"""
from __future__ import annotations

import base64
import logging
import sys
import time
from typing import Any, Dict, List, Optional, Tuple

_log = logging.getLogger(__name__)

try:
    import numpy as np
    _NP_OK = True
except ImportError:
    np = None  # type: ignore
    _NP_OK = False


def vst2_worker_entry(
    config: Any,
    input_buf: Any,
    output_buf: Any,
    ipc_socket_path: str,
) -> None:
    """VST2 worker subprocess entry point."""
    wlog = logging.getLogger(
        f"pydaw.vst2_worker.{config.track_id}.{config.slot_id}")
    logging.basicConfig(level=logging.INFO,
                        format="[VST2-WRK %(name)s] %(message)s",
                        stream=sys.stderr)

    try:
        from pydaw.services.plugin_ipc import (
            PluginIPCServer, WorkerAudioHandler,
        )
    except ImportError:
        wlog.error("plugin_ipc not importable")
        return

    ipc = PluginIPCServer(ipc_socket_path)
    if not ipc.start():
        wlog.error("IPC server start failed")
        return

    # Load VST2 plugin
    sr = int(getattr(config, "sample_rate", 48000) or 48000)
    bs = int(getattr(config, "block_size", 512) or 512)
    is_instrument = bool(getattr(config, "is_instrument", False))
    plugin = None
    plugin_fx = None
    plugin_inst = None

    try:
        if is_instrument:
            from pydaw.audio.vst2_host import Vst2InstrumentEngine
            plugin_inst = Vst2InstrumentEngine(
                path=config.plugin_path,
                track_id=config.track_id,
                device_id=config.slot_id,
                rt_params=None,
                params={},
                sr=sr,
                max_frames=bs * 2,
            )
            plugin = plugin_inst
        else:
            from pydaw.audio.vst2_host import Vst2Fx
            plugin_fx = Vst2Fx(
                path=config.plugin_path,
                track_id=config.track_id,
                device_id=config.slot_id,
                rt_params=None,
                params={},
                sr=sr,
                max_frames=bs * 2,
            )
            plugin = plugin_fx
    except Exception as e:
        wlog.error("VST2 load failed: %s", e)
        ipc.send_event({"evt": "error", "message": f"Load failed: {e}"})
        ipc.stop()
        return

    if plugin is None or not getattr(plugin, "_ok", False):
        err = getattr(plugin, "_err", "unknown")
        wlog.error("VST2 plugin not OK: %s", err)
        ipc.send_event({"evt": "error", "message": f"Plugin not OK: {err}"})
        ipc.stop()
        return

    # Restore state
    state_b64 = str(getattr(config, "state_b64", "") or "")
    if state_b64:
        try:
            raw = base64.b64decode(state_b64)
            if hasattr(plugin, "set_state"):
                plugin.set_state(raw)
            elif hasattr(plugin, "load_state"):
                plugin.load_state(raw)
        except Exception as e:
            wlog.warning("State restore failed: %s", e)

    # Worker state
    bypassed = False
    pending_midi: List[Tuple[bytes, float]] = []

    def handle_command(msg: dict) -> Optional[dict]:
        nonlocal bypassed, pending_midi
        cmd = msg.get("cmd", "")
        if cmd == "ping":
            return {"evt": "pong", "seq": msg.get("seq", 0)}
        elif cmd == "set_param":
            pid = str(msg.get("param_id", ""))
            val = float(msg.get("value", 0.0))
            try:
                if hasattr(plugin, "set_parameter"):
                    plugin.set_parameter(pid, val)
                elif hasattr(plugin, "set_param"):
                    plugin.set_param(pid, val)
            except Exception:
                pass
        elif cmd == "bypass":
            bypassed = bool(msg.get("enabled", False))
        elif cmd == "get_state":
            b64 = ""
            try:
                raw = b""
                if hasattr(plugin, "get_state"):
                    raw = plugin.get_state()
                elif hasattr(plugin, "save_state"):
                    raw = plugin.save_state()
                elif hasattr(plugin, "get_raw_state_b64"):
                    return {"evt": "state", "state_b64": plugin.get_raw_state_b64()}
                if raw:
                    b64 = base64.b64encode(raw).decode("ascii")
            except Exception:
                pass
            return {"evt": "state", "state_b64": b64}
        elif cmd == "load_state":
            try:
                raw = base64.b64decode(msg.get("state_b64", ""))
                if raw:
                    if hasattr(plugin, "set_state"):
                        plugin.set_state(raw)
                    elif hasattr(plugin, "load_state"):
                        plugin.load_state(raw)
            except Exception:
                pass
        elif cmd == "note_on":
            pitch = max(0, min(127, int(msg.get("pitch", 60))))
            vel = max(1, min(127, int(msg.get("velocity", 100))))
            if plugin_inst:
                plugin_inst.note_on(pitch, vel)
            else:
                pending_midi.append((bytes([0x90, pitch, vel]), 0.0))
        elif cmd == "note_off":
            pitch = int(msg.get("pitch", -1))
            if plugin_inst:
                plugin_inst.note_off(pitch)
            else:
                if pitch >= 0:
                    pending_midi.append((bytes([0x80, pitch & 0x7F, 0]), 0.0))
        elif cmd == "all_notes_off":
            if plugin_inst:
                if hasattr(plugin_inst, "all_notes_off"):
                    plugin_inst.all_notes_off()
                else:
                    plugin_inst.note_off(-1)
        elif cmd == "midi":
            events = msg.get("events", [])
            for ev in events:
                try:
                    if isinstance(ev, (list, tuple)) and len(ev) >= 2:
                        midi_bytes = bytes(int(b) & 0xFF for b in ev[:3])
                        pending_midi.append((midi_bytes, 0.0))
                except Exception:
                    continue
        elif cmd == "shutdown":
            raise SystemExit(0)
        return None

    ipc.set_message_handler(handle_command)
    ipc.send_event({
        "evt": "ready",
        "plugin_name": getattr(config, "plugin_name", ""),
        "param_count": 0,
        "is_instrument": is_instrument,
    })
    wlog.info("VST2 worker ready: %s (inst=%s)", config.plugin_path, is_instrument)

    audio = WorkerAudioHandler(input_buf, output_buf)

    while True:
        try:
            if is_instrument and plugin_inst:
                out = plugin_inst.pull(bs, sr)
                if out is not None:
                    audio.write_output(out, min(bs, len(out)))
                else:
                    audio.write_silence(bs)
                time.sleep(0.001)
            else:
                block = audio.read_input()
                if block is None:
                    time.sleep(0.0005)
                    continue
                frames = len(block)
                if bypassed:
                    audio.write_output(block, frames)
                else:
                    try:
                        plugin_fx.process_inplace(block, frames, sr)
                        audio.write_output(block, frames)
                    except Exception:
                        audio.write_output(block, frames)
        except SystemExit:
            break
        except Exception as e:
            wlog.error("Audio loop error: %s", e)
            time.sleep(0.001)

    try:
        ipc.stop()
    except Exception:
        pass
    wlog.info("VST2 worker shutdown")
