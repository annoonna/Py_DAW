// ============================================================================
// CLAP Plugin Host — Phase 1C
// ============================================================================
//
// Hosts CLAP plugins using the clap-sys crate.
//
// CLAP advantages over VST3:
//   - Simpler, cleaner C API (no COM)
//   - Built-in thread safety model (main-thread vs audio-thread)
//   - Extensions for parameter automation, note ports, GUI
//   - Plugin can declare its threading requirements
//
// Architecture:
//   1. Scanner: enumerate .clap files on disk
//   2. Entry: load shared library, get clap_plugin_entry
//   3. Factory: get clap_plugin_factory → iterate descriptors
//   4. Instance: create clap_plugin → activate → start_processing
//   5. Process: real-time via clap_plugin.process(clap_process)
//   6. State: save/load via clap_plugin_state extension
//
// v0.0.20.658 — AP1 Phase 1C (Claude Opus 4.6, 2026-03-20)
// ============================================================================

use std::collections::HashMap;
use std::path::{Path, PathBuf};

use log::{debug, info};
use serde::{Deserialize, Serialize};

use crate::audio_graph::AudioBuffer;
use crate::plugin_host::AudioPlugin;

// ---------------------------------------------------------------------------
// CLAP Plugin Scanner
// ---------------------------------------------------------------------------

/// Metadata for a scanned CLAP plugin.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClapPluginInfo {
    /// Reverse-domain plugin ID (e.g. "com.u-he.Diva")
    pub plugin_id: String,
    /// Human-readable name
    pub name: String,
    /// Vendor name
    pub vendor: String,
    /// Plugin description
    pub description: String,
    /// URL to plugin page
    pub url: String,
    /// Version string
    pub version: String,
    /// Feature tags (e.g. ["instrument", "synthesizer", "stereo"])
    pub features: Vec<String>,
    /// Path to the .clap file
    pub file_path: PathBuf,
}

impl ClapPluginInfo {
    /// Check if this plugin is an instrument (has note input).
    pub fn is_instrument(&self) -> bool {
        self.features
            .iter()
            .any(|f| f == "instrument" || f == "synthesizer" || f == "sampler")
    }

    /// Check if this plugin is an audio effect.
    pub fn is_effect(&self) -> bool {
        self.features.iter().any(|f| {
            f == "audio-effect"
                || f == "analyzer"
                || f == "delay"
                || f == "reverb"
                || f == "compressor"
                || f == "equalizer"
        })
    }
}

/// Scan result for CLAP plugins.
#[derive(Debug, Default)]
pub struct ClapScanResult {
    pub plugins: Vec<ClapPluginInfo>,
    pub errors: Vec<String>,
    pub scan_time_ms: u64,
}

/// Standard CLAP plugin search paths (Linux).
pub fn clap_search_paths() -> Vec<PathBuf> {
    let mut paths = Vec::new();

    if let Some(home) = std::env::var_os("HOME") {
        let home = PathBuf::from(home);
        paths.push(home.join(".clap"));
    }

    paths.push(PathBuf::from("/usr/lib/clap"));
    paths.push(PathBuf::from("/usr/local/lib/clap"));
    paths.push(PathBuf::from("/usr/lib/x86_64-linux-gnu/clap"));

    if let Some(extra) = std::env::var_os("CLAP_PATH") {
        for p in std::env::split_paths(&extra) {
            paths.push(p);
        }
    }

    paths
}

/// Scan all CLAP search paths and return discovered plugins.
pub fn scan_clap_plugins() -> ClapScanResult {
    let start = std::time::Instant::now();
    let mut result = ClapScanResult::default();

    for search_dir in clap_search_paths() {
        if !search_dir.exists() {
            continue;
        }
        debug!("Scanning CLAP directory: {}", search_dir.display());
        scan_clap_directory(&search_dir, &mut result);
    }

    result.scan_time_ms = start.elapsed().as_millis() as u64;
    info!(
        "CLAP scan complete: {} plugins found in {}ms",
        result.plugins.len(),
        result.scan_time_ms
    );
    result
}

fn scan_clap_directory(dir: &Path, result: &mut ClapScanResult) {
    let entries = match std::fs::read_dir(dir) {
        Ok(e) => e,
        Err(e) => {
            result
                .errors
                .push(format!("Cannot read {}: {}", dir.display(), e));
            return;
        }
    };

    for entry in entries.flatten() {
        let path = entry.path();

        if path.is_file()
            && path
                .extension()
                .map(|e| e.to_ascii_lowercase() == "clap")
                .unwrap_or(false)
        {
            match probe_clap_file(&path) {
                Ok(infos) => result.plugins.extend(infos),
                Err(e) => result
                    .errors
                    .push(format!("Failed to probe {}: {}", path.display(), e)),
            }
        } else if path.is_dir() {
            scan_clap_directory(&path, result);
        }
    }
}

/// Probe a .clap file and extract plugin descriptors.
///
/// A CLAP file is a shared library (.so) with a `clap_entry` symbol.
/// The entry provides a plugin factory that enumerates descriptors.
fn probe_clap_file(file_path: &Path) -> Result<Vec<ClapPluginInfo>, String> {
    // NOTE: Real implementation would:
    // 1. dlopen(file_path)
    // 2. dlsym("clap_entry") → clap_plugin_entry*
    // 3. entry.init(clap_path)
    // 4. entry.get_factory(CLAP_PLUGIN_FACTORY_ID) → clap_plugin_factory*
    // 5. factory.get_plugin_count() → iterate descriptors
    // 6. factory.get_plugin_descriptor(i) → clap_plugin_descriptor
    //
    // Stub: extract info from filename.
    let name = file_path
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("Unknown")
        .to_string();

    Ok(vec![ClapPluginInfo {
        plugin_id: format!("com.unknown.{}", name.to_lowercase()),
        name: name.clone(),
        vendor: String::new(),
        description: String::new(),
        url: String::new(),
        version: "0.0.0".to_string(),
        features: vec!["audio-effect".to_string()],
        file_path: file_path.to_path_buf(),
    }])
}

// ---------------------------------------------------------------------------
// CLAP Plugin Instance (Stub for Phase 1C)
// ---------------------------------------------------------------------------

/// A loaded CLAP plugin instance.
///
/// In the full implementation, this wraps the clap_plugin struct and its
/// extensions (params, state, audio-ports, note-ports, gui).
pub struct ClapInstance {
    info: ClapPluginInfo,
    sample_rate: f64,
    max_block_size: u32,
    is_active: bool,
    is_processing: bool,
    parameters: HashMap<u32, (f64, String)>,
    saved_state: Vec<u8>,
    latency: u32,
}

impl ClapInstance {
    pub fn new(info: ClapPluginInfo) -> Self {
        Self {
            info,
            sample_rate: 44100.0,
            max_block_size: 1024,
            is_active: false,
            is_processing: false,
            parameters: HashMap::new(),
            saved_state: Vec::new(),
            latency: 0,
        }
    }

    /// Activate the plugin instance.
    ///
    /// In real CLAP: clap_plugin.activate(sample_rate, min_frames, max_frames)
    pub fn activate(
        &mut self,
        sample_rate: f64,
        min_frames: u32,
        max_frames: u32,
    ) -> Result<(), String> {
        self.sample_rate = sample_rate;
        self.max_block_size = max_frames;
        self.is_active = true;

        info!(
            "CLAP activated: {} @ {}Hz, block={}-{}",
            self.info.name, sample_rate, min_frames, max_frames
        );
        Ok(())
    }

    /// Start processing.
    ///
    /// In real CLAP: clap_plugin.start_processing()
    pub fn start_processing(&mut self) -> Result<(), String> {
        if !self.is_active {
            return Err("Plugin not active".to_string());
        }
        self.is_processing = true;
        Ok(())
    }

    /// Stop processing.
    pub fn stop_processing(&mut self) -> Result<(), String> {
        self.is_processing = false;
        Ok(())
    }

    /// Deactivate the plugin.
    pub fn deactivate(&mut self) {
        self.is_processing = false;
        self.is_active = false;
    }
}

impl AudioPlugin for ClapInstance {
    fn process(&mut self, _buffer: &mut AudioBuffer, sample_rate: u32) {
        if !self.is_processing {
            return;
        }
        // TODO (Phase 1C FFI): Build clap_process_t and call clap_plugin.process()
        let _ = sample_rate;
    }

    fn id(&self) -> &str {
        &self.info.plugin_id
    }

    fn name(&self) -> &str {
        &self.info.name
    }

    fn set_parameter(&mut self, index: u32, value: f64) {
        if let Some(entry) = self.parameters.get_mut(&index) {
            entry.0 = value;
        } else {
            self.parameters.insert(index, (value, format!("P{}", index)));
        }
        // TODO (Phase 1C FFI): Send via clap_host.request_callback()
        // then in callback: clap_plugin_params.flush()
    }

    fn get_parameter(&self, index: u32) -> f64 {
        self.parameters.get(&index).map(|p| p.0).unwrap_or(0.0)
    }

    fn parameter_count(&self) -> u32 {
        self.parameters.len() as u32
    }

    fn parameter_name(&self, index: u32) -> String {
        self.parameters
            .get(&index)
            .map(|p| p.1.clone())
            .unwrap_or_default()
    }

    fn save_state(&self) -> Vec<u8> {
        // TODO (Phase 1C FFI): clap_plugin_state.save(stream)
        self.saved_state.clone()
    }

    fn load_state(&mut self, data: &[u8]) -> Result<(), String> {
        // TODO (Phase 1C FFI): clap_plugin_state.load(stream)
        self.saved_state = data.to_vec();
        Ok(())
    }

    fn latency_samples(&self) -> u32 {
        self.latency
    }
}

impl Drop for ClapInstance {
    fn drop(&mut self) {
        self.deactivate();
    }
}
