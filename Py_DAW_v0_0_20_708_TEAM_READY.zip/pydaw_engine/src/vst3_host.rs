// ============================================================================
// VST3 Plugin Host — Phase 1C
// ============================================================================
//
// Hosts VST3 plugins using the vst3-sys crate (raw FFI bindings).
//
// Architecture:
//   1. Scanner: enumerate .vst3 bundles on disk
//   2. Factory: load shared library, get IPluginFactory
//   3. Instance: create audio processor + edit controller
//   4. Process: real-time audio processing via IAudioProcessor
//   5. State: save/load via IComponent::getState/setState
//
// Safety:
//   - All VST3 COM calls are wrapped in safe Rust APIs
//   - Plugin process() runs on the audio thread (no allocations!)
//   - Parameter updates go through a lock-free command queue
//   - Plugin crash is caught (subprocess model in plugin_isolator.rs)
//
// v0.0.20.658 — AP1 Phase 1C (Claude Opus 4.6, 2026-03-20)
// ============================================================================

use std::collections::HashMap;
use std::path::{Path, PathBuf};

use log::{debug, info};
use serde::{Deserialize, Serialize};

use crate::audio_graph::AudioBuffer;
use crate::plugin_host::AudioPlugin;

// ---------------------------------------------------------------------------
// VST3 Plugin Scanner
// ---------------------------------------------------------------------------

/// Metadata for a scanned VST3 plugin.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Vst3PluginInfo {
    /// 32-character hex class ID (TUID)
    pub class_id: String,
    /// Human-readable name
    pub name: String,
    /// Vendor name
    pub vendor: String,
    /// Plugin category ("Instrument" | "Fx" | ...)
    pub category: String,
    /// Path to the .vst3 bundle
    pub bundle_path: PathBuf,
    /// Number of audio inputs (stereo pairs)
    pub audio_inputs: u32,
    /// Number of audio outputs (stereo pairs)
    pub audio_outputs: u32,
    /// SDK version string
    pub sdk_version: String,
}

/// Scan result for a directory of VST3 plugins.
#[derive(Debug, Default)]
pub struct Vst3ScanResult {
    pub plugins: Vec<Vst3PluginInfo>,
    pub errors: Vec<String>,
    pub scan_time_ms: u64,
}

/// Standard VST3 plugin search paths (Linux).
pub fn vst3_search_paths() -> Vec<PathBuf> {
    let mut paths = Vec::new();

    // User-local
    if let Some(home) = std::env::var_os("HOME") {
        let home = PathBuf::from(home);
        paths.push(home.join(".vst3"));
        // Flatpak/Snap compat
        paths.push(home.join(".local/lib/vst3"));
    }

    // System-wide
    paths.push(PathBuf::from("/usr/lib/vst3"));
    paths.push(PathBuf::from("/usr/local/lib/vst3"));
    paths.push(PathBuf::from("/usr/lib/x86_64-linux-gnu/vst3"));

    // Environment override
    if let Some(extra) = std::env::var_os("VST3_PATH") {
        for p in std::env::split_paths(&extra) {
            paths.push(p);
        }
    }

    paths
}

/// Scan all VST3 search paths and return discovered plugins.
pub fn scan_vst3_plugins() -> Vst3ScanResult {
    let start = std::time::Instant::now();
    let mut result = Vst3ScanResult::default();

    for search_dir in vst3_search_paths() {
        if !search_dir.exists() {
            continue;
        }
        debug!("Scanning VST3 directory: {}", search_dir.display());
        scan_directory(&search_dir, &mut result);
    }

    result.scan_time_ms = start.elapsed().as_millis() as u64;
    info!(
        "VST3 scan complete: {} plugins found in {}ms",
        result.plugins.len(),
        result.scan_time_ms
    );
    result
}

fn scan_directory(dir: &Path, result: &mut Vst3ScanResult) {
    let entries = match std::fs::read_dir(dir) {
        Ok(e) => e,
        Err(e) => {
            result.errors.push(format!("Cannot read {}: {}", dir.display(), e));
            return;
        }
    };

    for entry in entries.flatten() {
        let path = entry.path();

        if path.is_dir() {
            // Check if this is a .vst3 bundle
            if path
                .extension()
                .map(|e| e.to_ascii_lowercase() == "vst3")
                .unwrap_or(false)
            {
                match probe_vst3_bundle(&path) {
                    Ok(infos) => result.plugins.extend(infos),
                    Err(e) => result
                        .errors
                        .push(format!("Failed to probe {}: {}", path.display(), e)),
                }
            } else {
                // Recurse into subdirectories (one level)
                scan_directory(&path, result);
            }
        }
    }
}

/// Probe a .vst3 bundle and extract plugin info.
///
/// A VST3 bundle has the structure:
///   MyPlugin.vst3/
///   └── Contents/
///       └── x86_64-linux/
///           └── MyPlugin.so
fn probe_vst3_bundle(bundle_path: &Path) -> Result<Vec<Vst3PluginInfo>, String> {
    // Find the shared library inside the bundle
    let _so_path = find_vst3_binary(bundle_path)
        .ok_or_else(|| format!("No .so found in bundle {}", bundle_path.display()))?;

    // NOTE: Actually loading the .so and querying IPluginFactory requires
    // unsafe FFI via vst3-sys. This is a stub that extracts metadata from
    // the bundle path/name until the next session can do the real FFI work.
    //
    // The real implementation would:
    // 1. dlopen(so_path)
    // 2. dlsym("GetPluginFactory") → IPluginFactory*
    // 3. factory.countClasses() → iterate classes
    // 4. factory.getClassInfo(i) → PClassInfo { cid, name, category }
    //
    // For now, return a placeholder based on the bundle name.
    let name = bundle_path
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("Unknown")
        .to_string();

    Ok(vec![Vst3PluginInfo {
        class_id: format!("{:0>32X}", name_hash(&name)),
        name: name.clone(),
        vendor: String::new(),
        category: "Unknown".to_string(),
        bundle_path: bundle_path.to_path_buf(),
        audio_inputs: 1,
        audio_outputs: 1,
        sdk_version: "3.7".to_string(),
    }])
}

fn find_vst3_binary(bundle_path: &Path) -> Option<PathBuf> {
    // Linux: Contents/x86_64-linux/*.so
    let arch_dir = bundle_path.join("Contents").join("x86_64-linux");
    if arch_dir.exists() {
        if let Ok(entries) = std::fs::read_dir(&arch_dir) {
            for entry in entries.flatten() {
                let p = entry.path();
                if p.extension().map(|e| e == "so").unwrap_or(false) {
                    return Some(p);
                }
            }
        }
    }
    // Fallback: direct .so in bundle root (some plugins)
    if let Ok(entries) = std::fs::read_dir(bundle_path) {
        for entry in entries.flatten() {
            let p = entry.path();
            if p.extension().map(|e| e == "so").unwrap_or(false) {
                return Some(p);
            }
        }
    }
    None
}

fn name_hash(name: &str) -> u128 {
    use std::collections::hash_map::DefaultHasher;
    use std::hash::{Hash, Hasher};
    let mut h = DefaultHasher::new();
    name.hash(&mut h);
    h.finish() as u128
}

// ---------------------------------------------------------------------------
// VST3 Plugin Instance (Stub for Phase 1C)
// ---------------------------------------------------------------------------

/// A loaded VST3 plugin instance.
///
/// In the full implementation, this wraps the vst3-sys COM interfaces:
///   - IComponent (lifecycle)
///   - IAudioProcessor (real-time processing)
///   - IEditController (parameters, GUI)
///
/// For now, this is a safe framework that the next session fills in with
/// actual FFI calls.
pub struct Vst3Instance {
    info: Vst3PluginInfo,
    sample_rate: f64,
    max_block_size: u32,
    is_active: bool,
    is_processing: bool,
    // Parameter cache: index → (value, name)
    parameters: HashMap<u32, (f64, String)>,
    // Saved state (binary blob)
    saved_state: Vec<u8>,
    // Latency reported by plugin
    latency: u32,
}

impl Vst3Instance {
    pub fn new(info: Vst3PluginInfo) -> Self {
        Self {
            info,
            sample_rate: 44100.0,
            max_block_size: 1024,
            is_active: false,
            is_processing: false,
            parameters: HashMap::new(),
            saved_state: Vec::new(),
            latency: 0,
        }
    }

    /// Initialize the plugin (called once after loading).
    ///
    /// In real VST3: IComponent::initialize(hostContext)
    pub fn initialize(&mut self, sample_rate: f64, max_block_size: u32) -> Result<(), String> {
        self.sample_rate = sample_rate;
        self.max_block_size = max_block_size;

        // TODO (Phase 1C FFI): Call IComponent::initialize()
        // TODO: Call IAudioProcessor::setupProcessing(ProcessSetup)
        // TODO: Call IComponent::setActive(true)
        self.is_active = true;

        info!(
            "VST3 initialized: {} @ {}Hz, block={}",
            self.info.name, sample_rate, max_block_size
        );
        Ok(())
    }

    /// Start processing (called before first process() call).
    ///
    /// In real VST3: IAudioProcessor::setProcessing(true)
    pub fn start_processing(&mut self) -> Result<(), String> {
        if !self.is_active {
            return Err("Plugin not active".to_string());
        }
        self.is_processing = true;
        Ok(())
    }

    /// Stop processing.
    pub fn stop_processing(&mut self) -> Result<(), String> {
        self.is_processing = false;
        Ok(())
    }

    /// Deactivate and release resources.
    pub fn terminate(&mut self) {
        self.is_processing = false;
        self.is_active = false;
        // TODO (Phase 1C FFI): Call IComponent::setActive(false)
        // TODO: Call IComponent::terminate()
    }

    /// Get the plugin's reported latency.
    pub fn get_latency(&self) -> u32 {
        self.latency
    }
}

impl AudioPlugin for Vst3Instance {
    fn process(&mut self, _buffer: &mut AudioBuffer, sample_rate: u32) {
        if !self.is_processing {
            return;
        }
        // TODO (Phase 1C FFI): Call IAudioProcessor::process(ProcessData)
        //
        // ProcessData layout:
        //   - numSamples: buffer.frames
        //   - inputs[0].channelBuffers32: pointer to input L/R
        //   - outputs[0].channelBuffers32: pointer to output L/R
        //   - inputParameterChanges: queue of param changes
        //   - outputParameterChanges: queue of output changes
        //
        // For now: passthrough (no modification to buffer)
        let _ = sample_rate;
    }

    fn id(&self) -> &str {
        &self.info.class_id
    }

    fn name(&self) -> &str {
        &self.info.name
    }

    fn set_parameter(&mut self, index: u32, value: f64) {
        if let Some(entry) = self.parameters.get_mut(&index) {
            entry.0 = value;
        } else {
            self.parameters.insert(index, (value, format!("P{}", index)));
        }
        // TODO (Phase 1C FFI): Send to IEditController::setParamNormalized()
    }

    fn get_parameter(&self, index: u32) -> f64 {
        self.parameters.get(&index).map(|p| p.0).unwrap_or(0.0)
    }

    fn parameter_count(&self) -> u32 {
        self.parameters.len() as u32
    }

    fn parameter_name(&self, index: u32) -> String {
        self.parameters
            .get(&index)
            .map(|p| p.1.clone())
            .unwrap_or_default()
    }

    fn save_state(&self) -> Vec<u8> {
        // TODO (Phase 1C FFI): Call IComponent::getState(IBStream)
        self.saved_state.clone()
    }

    fn load_state(&mut self, data: &[u8]) -> Result<(), String> {
        // TODO (Phase 1C FFI): Call IComponent::setState(IBStream)
        self.saved_state = data.to_vec();
        Ok(())
    }

    fn latency_samples(&self) -> u32 {
        self.latency
    }
}

impl Drop for Vst3Instance {
    fn drop(&mut self) {
        self.terminate();
    }
}
