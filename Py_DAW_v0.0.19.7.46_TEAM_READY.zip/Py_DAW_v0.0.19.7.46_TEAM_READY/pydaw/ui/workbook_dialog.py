"""Workbook dialog: shows TEAM docs inside the app.

Menu: Hilfe -> Arbeitsmappe

The workbook is a simple, read-only viewer for the files in PROJECT_DOCS.
It keeps the team workflow discoverable for new contributors.

This module is intentionally defensive: missing files are handled gracefully.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)


def _safe_read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return f"(Konnte Datei nicht lesen: {path}\n{e})"


def _find_project_docs() -> Optional[Path]:
    """Try hard to locate PROJECT_DOCS.

    Priority:
    1) current working directory
    2) repository root (relative to this file)
    """
    try:
        cwd = Path.cwd()
        if (cwd / "PROJECT_DOCS").is_dir():
            return cwd / "PROJECT_DOCS"
    except Exception:
        pass

    try:
        # pydaw/ui/workbook_dialog.py -> pydaw/ui -> pydaw -> project root
        root = Path(__file__).resolve().parents[2]
        if (root / "PROJECT_DOCS").is_dir():
            return root / "PROJECT_DOCS"
    except Exception:
        pass

    return None


def _latest_session_file(sessions_dir: Path) -> Optional[Path]:
    try:
        files = [p for p in sessions_dir.glob("*.md") if p.is_file()]
        if not files:
            return None
        files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        return files[0]
    except Exception:
        return None


def _extract_next_steps(todo_text: str, max_lines: int = 60) -> str:
    """Extract a compact list of AVAILABLE tasks from TODO.md.

    This is intentionally heuristic (Markdown formatting differs over time).
    """
    lines = (todo_text or "").splitlines()
    out: list[str] = []
    current: list[str] = []

    def flush() -> None:
        nonlocal current
        if not current:
            return
        block = "\n".join(current).strip()
        if block and ("Assignee:" in block and "[ ] AVAILABLE" in block):
            out.append(block)
        current = []

    for ln in lines:
        if ln.strip().startswith("### "):
            flush()
            current = [ln]
        elif current:
            current.append(ln)
        if len(out) >= 8:
            break

    flush()

    if not out:
        # fallback: first lines
        return "\n".join(lines[:max_lines])

    header = "# Nächste Schritte (AVAILABLE Tasks)\n\n"
    return header + "\n\n---\n\n".join(out)


@dataclass
class _Tab:
    title: str
    widget: QWidget
    refresh: callable


class WorkbookDialog(QDialog):
    """QDialog that shows the team's project workbook."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Arbeitsmappe")
        self.setMinimumSize(980, 700)

        self._docs = _find_project_docs()

        top = QHBoxLayout()
        self._lbl_path = QLabel()
        self._lbl_path.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        top.addWidget(self._lbl_path, 1)

        btn_refresh = QPushButton("↻ Aktualisieren")
        btn_refresh.clicked.connect(self.refresh_all)
        top.addWidget(btn_refresh)

        self._tabs = QTabWidget()

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(10)
        root.addLayout(top)
        root.addWidget(self._tabs, 1)

        self._tab_defs: list[_Tab] = []
        self._build_tabs()
        self.refresh_all()

    def _build_tabs(self) -> None:
        def mk_text_tab(title: str) -> tuple[QWidget, QTextEdit]:
            w = QWidget()
            lay = QVBoxLayout(w)
            lay.setContentsMargins(8, 8, 8, 8)
            lay.setSpacing(6)
            te = QTextEdit()
            te.setReadOnly(True)
            te.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
            lay.addWidget(te, 1)
            self._tabs.addTab(w, title)
            return w, te

        # TODO
        w_todo, te_todo = mk_text_tab("TODO")

        def refresh_todo() -> None:
            if not self._docs:
                te_todo.setPlainText("PROJECT_DOCS nicht gefunden.\nStarte die App bitte im Projektordner.")
                return
            path = self._docs / "progress" / "TODO.md"
            te_todo.setPlainText(_safe_read_text(path))

        self._tab_defs.append(_Tab("TODO", w_todo, refresh_todo))

        # DONE
        w_done, te_done = mk_text_tab("DONE")

        def refresh_done() -> None:
            if not self._docs:
                te_done.setPlainText("PROJECT_DOCS nicht gefunden.")
                return
            path = self._docs / "progress" / "DONE.md"
            te_done.setPlainText(_safe_read_text(path))

        self._tab_defs.append(_Tab("DONE", w_done, refresh_done))

        # Latest session
        w_sess, te_sess = mk_text_tab("Letzte Session")

        def refresh_sess() -> None:
            if not self._docs:
                te_sess.setPlainText("PROJECT_DOCS nicht gefunden.")
                return
            sessions = self._docs / "sessions"
            latest = _latest_session_file(sessions)
            if not latest:
                te_sess.setPlainText("Keine Session-Logs gefunden in PROJECT_DOCS/sessions.")
                return
            te_sess.setPlainText(_safe_read_text(latest))

        self._tab_defs.append(_Tab("Letzte Session", w_sess, refresh_sess))

        # Next steps (extracted)
        w_next, te_next = mk_text_tab("Nächste Schritte")

        def refresh_next() -> None:
            if not self._docs:
                te_next.setPlainText("PROJECT_DOCS nicht gefunden.")
                return
            todo_path = self._docs / "progress" / "TODO.md"
            txt = _safe_read_text(todo_path)
            te_next.setPlainText(_extract_next_steps(txt))

        self._tab_defs.append(_Tab("Nächste Schritte", w_next, refresh_next))

        # Shortcuts & Commands (NEW - Phase 1+2 Documentation)
        w_shortcuts, te_shortcuts = mk_text_tab("Shortcuts & Befehle")

        def refresh_shortcuts() -> None:
            # This content is embedded (no file needed)
            shortcuts_content = """# 🎹 PyDAW Shortcuts & Befehle

## 📋 NOTATION EDITOR - Komplette Referenz

### 🎨 TOOL-WECHSEL (Keyboard)
```
D ............... Draw Tool (Noten zeichnen)
S ............... Select Tool (Noten auswählen)
E ............... Erase Tool (Noten löschen)
```

---

## ✨ SELECTION (mit Select Tool - "S")

### 🖱️ MAUS-GESTEN

#### Einzelne Noten:
```
Click ........................ Single Selection (löscht vorherige)
Ctrl+Click ................... Toggle in Multi-Selection
Shift+Click .................. Range Select (von letzter bis geklickter)
```

#### Mehrere Noten (Lasso):
```
Drag Rechteck ................ Lasso Selection (alle im Rechteck)
Ctrl+Drag Rechteck ........... Additive Lasso (fügt zu Selection hinzu)
```

**Tipp:** Lasso funktioniert in ALLEN Richtungen (hoch/runter/links/rechts/diagonal)!

---

## 📋 BEARBEITUNG (Keyboard Shortcuts)

### Zwischenablage:
```
Ctrl+C .......... Copy (alle selektierten Noten)
Ctrl+V .......... Paste (mit relativer Positionierung!)
Ctrl+X .......... Cut (kopiert + löscht)
```

### Löschen:
```
Delete .......... Löscht alle selektierten Noten
Backspace ....... Löscht alle selektierten Noten
```

### Undo/Redo:
```
Ctrl+Z .......... Undo (rückgängig)
```

---

## 🎼 NOTATION-SPEZIFISCH

### Note-Duration (im Draw Tool):
```
1/1 ............. Ganze Note
1/2 ............. Halbe Note
1/4 ............. Viertelnote
1/8 ............. Achtelnote
1/16 ............ Sechzehntelnote
1/32 ............ Zweiunddreißigstelnote
1/64 ............ Vierundsechzigstelnote
```

### Accidentals (im Input State):
```
♮ (Natural) ..... Keine Versetzung
♯ (Sharp) ....... Kreuz (+1 Halbton)
♭ (Flat) ........ b (-1 Halbton)
```

### Ties & Slurs (im Draw Tool):
```
Shift+Click ..... Tie Tool (Haltebogen)
Alt+Click ....... Slur Tool (Bindebogen)
```

---

## 🔍 ANSICHT (View Controls)

### Zoom:
```
Ctrl+0 ........... Reset Zoom (100%)
Ctrl++ ........... Zoom In (horizontal)
Ctrl+- ........... Zoom Out (horizontal)
Mousewheel ....... Vertikales Scrollen
Shift+Mousewheel . Horizontales Scrollen
```

### Grid/Snap:
```
1/16 ............. Standard Snap-Division
Grid/Snap Menü ... Ändern der Snap-Einstellung
```

---

## 🎵 SCALE-FUNKTIONEN

### Scale Menu (oben rechts):
```
Scale Lock aktiv ..... Nur Noten im Scale zeichenbar
Scale Lock aus ....... Alle Noten zeichenbar (chromatisch)
Scale-Hints (Cyan) ... Visualisierung der Scale-Noten im Staff
```

### Scale-Punkte (Piano-Layout):
```
Untere Reihe (7) ..... Weiße Tasten (C, D, E, F, G, A, B)
Obere Reihe (5) ...... Schwarze Tasten (C#, D#, F#, G#, A#)
Hervorgehoben ........ Root-Note
```

---

## 🎯 WORKFLOWS (Best Practices)

### Workflow 1: Schnelle Mehrfachauswahl
```
1. S (Select Tool)
2. Drag Rechteck über Noten → Lasso!
3. Ctrl+C → Kopieren
4. Click woanders
5. Ctrl+V → Einfügen mit Spacing!
```

### Workflow 2: Komplexe Selection
```
1. S (Select Tool)
2. Drag Rechteck über 5 Noten (Bar 1)
3. Ctrl+Drag Rechteck über 3 Noten (Bar 3)
4. Ctrl+Click einzelne Note (Bar 5)
→ Alle 9 Noten aus 3 Bereichen selektiert!
```

### Workflow 3: Range + Additive
```
1. Click Note A
2. Shift+Click Note Z → Range selektiert!
3. Ctrl+Drag Rechteck → Weitere hinzufügen!
4. Delete → Alle weg!
```

### Workflow 4: Copy & Paste Mehrfach
```
1. Select 5 Noten
2. Ctrl+C
3. Ctrl+V → Paste at end
4. Ctrl+V → Paste again (stepwise!)
5. Ctrl+V → And again!
→ Schnelles Pattern-Building!
```

---

## 🎨 GHOST LAYERS (Multi-Track View)

### Ghost Layer Controls:
```
+ Add Layer .......... Andere Tracks als Ghost anzeigen
Opacity Slider ....... Transparenz einstellen (0-100%)
👁 Toggle ............ Ghost Layer ein/aus
🔒 Lock .............. Ghost Layer sperren
- Remove ............. Ghost Layer entfernen
```

**Tipp:** Ghost Layers helfen beim Arrangement über mehrere Tracks!

---

## ⚡ PIANO ROLL (Parallel View)

### Piano Roll ↔ Notation:
```
Piano Roll Tab ....... Klassische MIDI-Editor View
Notation Tab ......... Notenschrift View
Beide parallel ....... Gleiche Daten, verschiedene Ansichten!
```

### Piano Roll Mouse:
```
Left Click ........... Note zeichnen
Right Click .......... Note löschen
Drag Note ............ Note verschieben
Drag Edge ............ Note-Länge ändern
Mousewheel Zoom ...... Horizontal & Vertikal
```

---

## 🎛️ TRANSPORT (Playback Controls)

### Playback:
```
Space ........... Play/Pause
Stop ............ Stop (zurück zu Anfang)
Record .......... MIDI Recording aktivieren
```

### Timeline Navigation:
```
Loop ............ Loop-Bereich aktivieren
Metronome ....... Metronom ein/aus
Count-In ........ Count-In aktivieren
```

---

## 💾 PROJEKT-MANAGEMENT

### Datei:
```
Ctrl+S .......... Speichern
Ctrl+Shift+S .... Speichern Als...
Ctrl+N .......... Neues Projekt
Ctrl+O .......... Projekt öffnen
```

### Arbeitsmappe:
```
F1 .............. Arbeitsmappe öffnen (dieses Fenster!)
```

---

## 🎼 NOTATION SPECIFICS (Advanced)

### Staff Line Mapping:
```
E4 .............. Unterste Linie (Referenz)
Jede Linie ...... +1 Halbton (chromatisch)
Ledger Lines .... Automatisch für hohe/tiefe Noten
```

### Pitch to MIDI:
```
C4 = 60 ......... Middle C
C0 = 12 ......... Tiefste Note
C8 = 108 ........ Höchste Note (sichtbar!)
```

### Scene Rect:
```
Negative Y ...... Ermöglicht C8/C9 Noten oben!
Auto-Expand ..... Scrollbar passt sich an
```

---

## 🐛 DEBUGGING & TROUBLESHOOTING

### Häufige Probleme:

**Lasso funktioniert nicht?**
→ Select Tool ("S") aktiviert? ✅
→ Shift/Alt gedrückt? (deaktiviert Lasso) ❌
→ Click + Drag (nicht nur Click!)

**Note kann nicht gezeichnet werden?**
→ Scale Lock aktiv? Check Scale Menu!
→ Note außerhalb des Scales?
→ Lösung: Scale Lock deaktivieren ODER Scale ändern

**Copy/Paste funktioniert nicht?**
→ Noten selektiert? (blau highlighted)
→ Select Tool aktiv beim Paste?

**Hohe Noten (C8/C9) nicht sichtbar?**
→ FIXED in v0.0.19.5.1.37! Scene Rect erweitert!
→ Scrollen nach oben sollte funktionieren

---

## 📊 VERSION HISTORY (Features)

### v0.0.19.5.1.41 - Phase 2 (Lasso Selection)
- ✅ Lasso (Drag Rechteck)
- ✅ Ctrl+Drag Additive
- ✅ QRubberBand Visual Feedback

### v0.0.19.5.1.40 - Phase 1 (Multi-Select)
- ✅ Ctrl+Click Multi-Select
- ✅ Shift+Click Range Select
- ✅ Multi-Note Copy/Paste/Delete

### v0.0.19.5.1.39 - Scale Lock Fix
- ✅ Scale Validation Bug gefixt
- ✅ Noten im Scale jetzt zeichenbar!

### v0.0.19.5.1.38 - Scale Dots Piano Layout
- ✅ 2 Reihen (weiße + schwarze Tasten)
- ✅ Intuitive Visualisierung

### v0.0.19.5.1.37 - C8/C9 Notes Fix
- ✅ Scene Rect mit negativem Y
- ✅ Alle Oktaven C0-C9 sichtbar!

---

## 💡 TIPPS & TRICKS

### 🚀 Power-User Workflows:

**1. Schnelles Transponieren:**
```
1. Lasso alle Noten
2. Ctrl+X (Cut)
3. Click eine Oktave höher
4. Ctrl+V → Transponiert!
```

**2. Pattern Duplication:**
```
1. Lasso 1-Bar Pattern
2. Ctrl+C
3. Ctrl+V, V, V, V... → Schnell Pattern bauen!
```

**3. Selective Editing:**
```
1. Lasso Region
2. Ctrl+Click zum Deselektieren einzelner Noten
3. Edit nur die gewollten!
```

**4. Range Cleanup:**
```
1. Click erste Note
2. Shift+Click letzte Note → Range!
3. Delete → Clean!
```

---

## 🎓 WEITERE HILFE

**Dokumentation:**
- PROJECT_DOCS/sessions/ → Alle Session-Logs
- CHANGELOG.md → Alle Änderungen
- TODO.md → Geplante Features

**Bei Problemen:**
- F1 → Diese Arbeitsmappe
- Tab "Letzte Session" → Aktuelle Änderungen
- Tab "TODO" → Was kommt noch

**Feedback:**
- Thumbs Down Button → Feedback an Entwickler
- GitHub Issues → Bug Reports & Feature Requests

---

## 🎉 FAZIT

Du hast jetzt einen **PROFESSIONELLEN DAW-Workflow**:
- ✅ Multi-Selection wie Ableton/Logic/Cubase
- ✅ Lasso Selection für große Bereiche
- ✅ Keyboard Shortcuts wie Pro Tools
- ✅ Copy/Paste mit Spacing wie Cubase

**Viel Spaß beim Komponieren! 🎹✨**
"""
            te_shortcuts.setPlainText(shortcuts_content)

        self._tab_defs.append(_Tab("Shortcuts & Befehle", w_shortcuts, refresh_shortcuts))

    def refresh_all(self) -> None:
        if self._docs:
            self._lbl_path.setText(f"PROJECT_DOCS: {self._docs}")
        else:
            self._lbl_path.setText("PROJECT_DOCS: (nicht gefunden) – starte die App bitte im Projektordner")

        for t in self._tab_defs:
            try:
                t.refresh()
            except Exception:
                pass


def build_workbook_action(parent, on_triggered) -> QAction:
    a = QAction("Arbeitsmappe…", parent)
    a.setShortcut("F1")
    a.triggered.connect(on_triggered)
    return a
