# -*- coding: utf-8 -*-
"""Pro Audio Sampler device widget (PyQt6).

Goal: bring the original "Professional Audio Sampler" UI (Qt5) into the DAW as a proper instrument device.

- Appears in Browser → Instruments (not auto-embedded)
- Can load WAV via button or Drag&Drop
- Receives note previews from ProjectService.note_preview
- Outputs audio via AudioEngine pull source (preview output keeps running when transport is stopped)
"""

from __future__ import annotations

from pathlib import Path
import uuid

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QLabel,
    QPushButton,
    QGroupBox,
    QComboBox,
    QSlider,
    QMessageBox,
    QFileDialog,
    QCheckBox,
    QTabWidget,
    QStackedLayout,
    QSizePolicy,
)

from .sampler_engine import ProSamplerEngine
from .ui_widgets import Knob, WaveformDisplay


class SamplerWidget(QWidget):
    def __init__(self, project_service=None, audio_engine=None, parent=None):
        super().__init__(parent)
        self.setObjectName("proAudioSamplerWidget")
        self.setAcceptDrops(True)

        self.project_service = project_service
        self.audio_engine = audio_engine

        self.engine = ProSamplerEngine(target_sr=48000)
        self._pull_name = f"sampler:{uuid.uuid4().hex[:8]}"

        self._build_ui()
        self._wire()

        # Register pull source
        if self.audio_engine is not None:
            try:
                self.audio_engine.register_pull_source(self._pull_name, self.engine.pull)
                self.audio_engine.ensure_preview_output()
            except Exception:
                pass

    # ----- UI
    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(10)

        top = QHBoxLayout()
        self.lbl_title = QLabel("Pro Audio Sampler")
        self.lbl_title.setObjectName("samplerTitle")
        top.addWidget(self.lbl_title, 1)

        self.btn_load = QPushButton("Load Sample (WAV)…")
        top.addWidget(self.btn_load, 0)

        self.btn_play = QPushButton("PLAY")
        self.btn_play.setCheckable(True)
        self.btn_play.setFixedWidth(90)
        top.addWidget(self.btn_play, 0)

        self.chk_loop = QCheckBox("LOOP")
        top.addWidget(self.chk_loop, 0)

        root.addLayout(top)

        # Upper controls: Sampler controls / Pitch modulation / Filters&Effects
        row = QHBoxLayout()
        row.setSpacing(10)

        # Sampler controls
        gb_controls = QGroupBox("SAMPLER CONTROLS")
        lay_c = QVBoxLayout(gb_controls)
        lay_c.setSpacing(8)

        self.lbl_file = QLabel("Drop a .wav file here")
        self.lbl_file.setStyleSheet("color:#bdbdbd;")
        lay_c.addWidget(self.lbl_file)

        self.btn_load2 = QPushButton("Load Sample")
        lay_c.addWidget(self.btn_load2)

        # master/pan
        mp = QHBoxLayout()
        self.k_master = Knob("Master Volume", 80)
        self.k_pan = Knob("Pan", 50)
        mp.addWidget(self.k_master)
        mp.addWidget(self.k_pan)
        lay_c.addLayout(mp)

        row.addWidget(gb_controls, 1)

        # Pitch modulation
        gb_pitch = QGroupBox("PITCH_MODULATION")
        lay_p = QGridLayout(gb_pitch)
        lay_p.setHorizontalSpacing(18)
        lay_p.setVerticalSpacing(8)

        self.k_glide = Knob("Glide", 5)
        self.k_speed = Knob("Speed", 3)
        self.k_repitch = Knob("Repitch", 35)
        self.k_cycles = Knob("Cycles", 0)
        self.k_textures = Knob("Textures", 10)
        self.k_grain = Knob("Grain Size", 0)

        lay_p.addWidget(self.k_glide, 0, 0)
        lay_p.addWidget(self.k_speed, 0, 1)
        lay_p.addWidget(self.k_repitch, 0, 2)
        lay_p.addWidget(self.k_cycles, 1, 0)
        lay_p.addWidget(self.k_textures, 1, 1)
        lay_p.addWidget(self.k_grain, 1, 2)

        row.addWidget(gb_pitch, 2)

        # Filters & effects
        gb_fx = QGroupBox("FILTERS_EFFECTS")
        lay_f = QGridLayout(gb_fx)
        lay_f.setHorizontalSpacing(18)
        lay_f.setVerticalSpacing(8)

        self.cb_filter = QComboBox()
        self.cb_filter.addItems(["Off", "Lowpass", "Highpass", "Bandpass"])
        self.cb_filter.setFixedWidth(140)

        lay_f.addWidget(QLabel("Filter Type"), 0, 0)
        lay_f.addWidget(self.cb_filter, 0, 1, 1, 2)

        self.k_cutoff = Knob("Cutoff", 68)
        self.k_res = Knob("Resonance", 60)
        self.k_drive = Knob("Drive", 0)

        self.k_chorus = Knob("Chorus", 0)
        self.k_reverb = Knob("Reverb", 0)
        self.k_delay = Knob("Delay", 0)
        self.k_dist = Knob("Distortion", 0)

        lay_f.addWidget(self.k_cutoff, 1, 0)
        lay_f.addWidget(self.k_res, 1, 1)
        lay_f.addWidget(self.k_drive, 1, 2)
        lay_f.addWidget(self.k_chorus, 2, 0)
        lay_f.addWidget(self.k_reverb, 2, 1)
        lay_f.addWidget(self.k_delay, 2, 2)
        lay_f.addWidget(self.k_dist, 3, 0)

        row.addWidget(gb_fx, 2)

        root.addLayout(row)

        # Waveform
        self.wave = WaveformDisplay(self.engine)
        root.addWidget(self.wave, 0)

        # Waveform / Loop sliders
        sliders = QHBoxLayout()
        sliders.setSpacing(12)

        self.s_pos = QSlider(Qt.Orientation.Horizontal)
        self.s_pos.setRange(0, 100)
        self.s_pos.setValue(0)
        self.s_pos.setToolTip("Position (Preview)")

        self.s_ls = QSlider(Qt.Orientation.Horizontal)
        self.s_ls.setRange(0, 100)
        self.s_ls.setValue(0)
        self.s_le = QSlider(Qt.Orientation.Horizontal)
        self.s_le.setRange(0, 100)
        self.s_le.setValue(100)

        sliders.addWidget(QLabel("Position"))
        sliders.addWidget(self.s_pos, 2)
        sliders.addWidget(QLabel("Loop Start"))
        sliders.addWidget(self.s_ls, 2)
        sliders.addWidget(QLabel("Loop End"))
        sliders.addWidget(self.s_le, 2)

        root.addLayout(sliders)

        # Envelope
        gb_env = QGroupBox("AHDSR_ENVELOPE")
        lay_e = QHBoxLayout(gb_env)
        lay_e.setSpacing(16)

        self.k_a = Knob("Attack", 2)
        self.k_h = Knob("Hold", 0)
        self.k_d = Knob("Decay", 15)
        self.k_s = Knob("Sustain", 100)
        self.k_r = Knob("Release", 20)
        for w in (self.k_a, self.k_h, self.k_d, self.k_s, self.k_r):
            lay_e.addWidget(w)

        root.addWidget(gb_env)

        # Footer hint
        self.lbl_hint = QLabel("Preview: PianoRoll/Notation → note_preview → Sampler")
        self.lbl_hint.setStyleSheet("color:#9a9a9a;")
        root.addWidget(self.lbl_hint)

    def _wire(self) -> None:
        self.btn_load.clicked.connect(self._load_dialog)
        self.btn_load2.clicked.connect(self._load_dialog)
        self.btn_play.toggled.connect(self._toggle_play)
        self.chk_loop.toggled.connect(self._toggle_loop)

        # knobs → engine mappings
        self.k_master.valueChanged.connect(lambda v: self.engine.set_master(gain=float(v) / 100.0))
        self.k_pan.valueChanged.connect(lambda v: self.engine.set_master(pan=(float(v) - 50.0) / 50.0))

        self.k_repitch.valueChanged.connect(lambda v: self.engine.set_repitch(0.25 + (float(v) / 100.0) * (4.0 - 0.25)))
        self.k_glide.valueChanged.connect(lambda v: self.engine.set_glide(float(v) / 100.0))
        self.k_speed.valueChanged.connect(lambda v: self.engine.set_lfo(rate_hz=0.05 + (float(v) / 100.0) * (20.0 - 0.05)))
        self.k_cycles.valueChanged.connect(lambda v: self.engine.set_lfo(depth=(float(v) / 100.0) * 0.20))
        self.k_textures.valueChanged.connect(lambda v: self.engine.set_textures(float(v) / 100.0))
        self.k_grain.valueChanged.connect(lambda v: self.engine.set_grain(float(v) / 100.0))

        self.cb_filter.currentIndexChanged.connect(self._filter_type_changed)
        self.k_cutoff.valueChanged.connect(self._cutoff_changed)
        self.k_res.valueChanged.connect(lambda v: self.engine.set_filter(q=0.25 + (float(v) / 100.0) * (12.0 - 0.25)))
        self.k_drive.valueChanged.connect(lambda v: self.engine.set_drive(1.0 + (float(v) / 100.0) * (20.0 - 1.0)))

        self.k_chorus.valueChanged.connect(lambda v: self.engine.set_fx(chorus_mix=float(v) / 100.0))
        self.k_delay.valueChanged.connect(lambda v: self.engine.set_fx(delay_mix=float(v) / 100.0))
        self.k_reverb.valueChanged.connect(lambda v: self.engine.set_fx(reverb_mix=float(v) / 100.0))
        self.k_dist.valueChanged.connect(lambda v: self.engine.set_distortion(float(v) / 100.0))

        self.k_a.valueChanged.connect(lambda v: self.engine.set_env(a=0.001 + (float(v) / 100.0) * (5.0 - 0.001)))
        self.k_h.valueChanged.connect(lambda v: self.engine.set_env(h=(float(v) / 100.0) * 5.0))
        self.k_d.valueChanged.connect(lambda v: self.engine.set_env(d=0.001 + (float(v) / 100.0) * (5.0 - 0.001)))
        self.k_s.valueChanged.connect(lambda v: self.engine.set_env(s=float(v) / 100.0))
        self.k_r.valueChanged.connect(lambda v: self.engine.set_env(r=0.001 + (float(v) / 100.0) * (10.0 - 0.001)))

        self.s_pos.valueChanged.connect(self._pos_changed)
        self.s_ls.valueChanged.connect(self._loop_slider_changed)
        self.s_le.valueChanged.connect(self._loop_slider_changed)

        # Project note preview signal
        if self.project_service is not None:
            try:
                sig = getattr(self.project_service, "note_preview", None)
                if sig is not None:
                    sig.connect(self._on_note_preview)
            except Exception:
                pass

    # ----- Interactions
    def _filter_type_changed(self, idx: int) -> None:
        mapping = {0: "off", 1: "lp", 2: "hp", 3: "bp"}
        self.engine.set_filter(ftype=mapping.get(int(idx), "off"))

    def _cutoff_changed(self, v: int) -> None:
        # log-ish mapping: 20Hz .. 20kHz
        vv = float(v) / 100.0
        cutoff = 20.0 * (1000.0 ** vv)  # 20..20000
        self.engine.set_filter(cutoff_hz=cutoff)

    def _pos_changed(self, v: int) -> None:
        # move playhead in sample (0..1)
        vv = float(v) / 100.0
        try:
            with self.engine._lock:
                if self.engine.samples is None:
                    return
                n = int(len(self.engine.samples))
                self.engine.state.position = vv * n
        except Exception:
            pass

    def _loop_slider_changed(self, _=None) -> None:  # noqa: ANN001
        ls = self.s_ls.value() / 100.0
        le = self.s_le.value() / 100.0
        if le <= ls:
            le = min(1.0, ls + 0.01)
            self.s_le.blockSignals(True)
            self.s_le.setValue(int(le * 100))
            self.s_le.blockSignals(False)
        self.engine.set_loop_norm(ls, le)

    def _toggle_loop(self, checked: bool) -> None:
        self.engine.set_loop_enabled(bool(checked))
        if checked:
            self._loop_slider_changed()

    def _toggle_play(self, checked: bool) -> None:
        # keep button text in sync
        now = bool(checked)
        try:
            if now:
                self.engine.toggle_play()
                self.btn_play.setText("STOP")
            else:
                self.engine.stop_play()
                self.btn_play.setText("PLAY")
        except Exception:
            self.btn_play.setChecked(False)
            self.btn_play.setText("PLAY")

    def _load_dialog(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Choose WAV", str(Path.home()), "WAV files (*.wav);;All files (*)")
        if not path:
            return
        self._load_wav(path)

    def _load_wav(self, path: str) -> None:
        p = Path(path)
        if p.suffix.lower() != ".wav":
            QMessageBox.information(self, "Sampler", "Bitte nur WAV-Dateien (.wav).")
            return
        ok = self.wave.load_wav_file(str(p))
        if ok:
            self.lbl_file.setText(f"Loaded: {p.name}")
            # ensure preview output stays alive
            if self.audio_engine is not None:
                try:
                    self.audio_engine.ensure_preview_output()
                except Exception:
                    pass
        else:
            QMessageBox.warning(self, "Sampler", "Konnte WAV nicht laden.")

    def _on_note_preview(self, pitch: int, velocity: int, duration_ms: int) -> None:
        # Ignore if no sample
        if self.engine.samples is None:
            return
        self.engine.note_on_preview(int(pitch), int(velocity), int(duration_ms))
        if self.audio_engine is not None:
            try:
                self.audio_engine.ensure_preview_output()
            except Exception:
                pass

    # ----- DnD
    def dragEnterEvent(self, e):  # noqa: ANN001
        if e.mimeData().hasUrls():
            for u in e.mimeData().urls():
                if u.toLocalFile().lower().endswith(".wav"):
                    e.acceptProposedAction()
                    return
        e.ignore()

    def dropEvent(self, e):  # noqa: ANN001
        if not e.mimeData().hasUrls():
            return
        for u in e.mimeData().urls():
            fp = u.toLocalFile()
            if fp.lower().endswith(".wav"):
                self._load_wav(fp)
                break

    def shutdown(self) -> None:
        # unregister pull source
        if self.audio_engine is not None:
            try:
                self.audio_engine.unregister_pull_source(self._pull_name)
            except Exception:
                pass
