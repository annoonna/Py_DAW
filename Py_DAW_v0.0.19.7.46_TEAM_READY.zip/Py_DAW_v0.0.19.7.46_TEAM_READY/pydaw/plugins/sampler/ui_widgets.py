# -*- coding: utf-8 -*-
from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np

from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QPainter, QColor, QPen, QFont
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QDial, QFrame

from .wav_io import load_wav


class Knob(QWidget):
    """Simple % knob with label (0..100)."""

    valueChanged = pyqtSignal(int)

    def __init__(self, title: str, init: int = 0, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        self.lbl = QLabel(title)
        self.lbl.setAlignment(Qt.AlignmentFlag.AlignHCenter)

        self.dial = QDial()
        self.dial.setRange(0, 100)
        self.dial.setValue(int(init))
        self.dial.setFixedSize(64, 64)
        self.dial.setNotchesVisible(True)

        self.val = QLabel(f"{int(init)}%")
        self.val.setAlignment(Qt.AlignmentFlag.AlignHCenter)

        def _on(x: int):
            self.val.setText(f"{int(x)}%")
            self.valueChanged.emit(int(x))

        self.dial.valueChanged.connect(_on)

        layout.addWidget(self.lbl)
        layout.addWidget(self.dial, 0, Qt.AlignmentFlag.AlignHCenter)
        layout.addWidget(self.val)

    def value(self) -> int:
        return int(self.dial.value())

    def setValue(self, v: int) -> None:
        self.dial.setValue(int(v))


class WaveformDisplay(QFrame):
    """Lightweight waveform view for WAV-only loading (no extra deps)."""

    def __init__(self, engine, parent=None):
        super().__init__(parent)
        self.engine = engine
        self.setMinimumHeight(130)
        self.setStyleSheet("background-color:#101010;border:1px solid #282828;")
        self.samples: Optional[np.ndarray] = None  # mono float32
        self.sample_rate: Optional[int] = None
        self.loop_start = 0.0
        self.loop_end = 1.0
        self.position = 0.0
        self.info = "No audio file loaded\nClick 'Load Sample' (WAV) or drop a .wav"

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._poll_engine)
        self.timer.start(30)

    def _poll_engine(self) -> None:
        try:
            if self.samples is None and getattr(self.engine, 'samples', None) is not None:
                self.samples = self.engine.samples
                self.sample_rate = getattr(self.engine, 'target_sr', None)
            if self.samples is not None:
                n = int(len(self.samples))
                self.position = float(getattr(self.engine.state, 'position', 0.0) / max(1, n))
                self.loop_start = float(getattr(self.engine.state, 'loop_start', 0.0))
                self.loop_end = float(getattr(self.engine.state, 'loop_end', 1.0))
        except Exception:
            pass
        self.update()

    def load_wav_file(self, path: str) -> bool:
        try:
            data, sr = load_wav(path, target_sr=48000)
            mono = data.mean(axis=1).astype(np.float32, copy=False)
            self.samples = mono
            self.sample_rate = int(sr)
            self.info = f"{Path(path).name} | {len(mono)/sr:0.2f}s | {sr}Hz"
            ok = bool(self.engine.load_wav(path))
            return ok
        except Exception as e:
            self.info = f"Load error: {e}"
            return False

    def paintEvent(self, e):  # noqa: ANN001
        p = QPainter(self)
        rect = self.rect().adjusted(8, 8, -8, -8)
        p.fillRect(rect, QColor("#111"))
        p.setPen(QPen(QColor("#2a2a2a"), 1))
        p.drawRect(rect)

        if self.samples is None or len(self.samples) < 2:
            p.setPen(QColor("#9a9a9a"))
            p.setFont(QFont("Sans", 9))
            p.drawText(rect, Qt.AlignmentFlag.AlignCenter, self.info)
            return

        samples = self.samples
        n = int(len(samples))
        W = max(1, rect.width())
        step = max(1, n // W)
        usable = samples[: n - (n % step)]
        if usable.size < step:
            p.setPen(QColor("#9a9a9a"))
            p.setFont(QFont("Sans", 9))
            p.drawText(rect, Qt.AlignmentFlag.AlignCenter, self.info)
            return

        chunk = usable.reshape(-1, step)
        mins = chunk.min(axis=1)
        maxs = chunk.max(axis=1)
        mid = rect.center().y()
        amp = rect.height() / 2.1

        p.setPen(QPen(QColor("#1bd760"), 1))
        limit = min(len(mins), rect.width())
        for i in range(limit):
            x = rect.left() + i
            y1 = int(mid - float(mins[i]) * amp)
            y2 = int(mid - float(maxs[i]) * amp)
            if y1 > y2:
                y1, y2 = y2, y1
            p.drawLine(x, y1, x, y2)

        p.setPen(QPen(QColor("#d64d2a"), 2))
        xs = rect.left() + int(self.loop_start * rect.width())
        xe = rect.left() + int(self.loop_end * rect.width())
        p.drawLine(xs, rect.top(), xs, rect.bottom())
        p.drawLine(xe, rect.top(), xe, rect.bottom())

        p.setPen(QPen(QColor("#ffaa00"), 2))
        xp = rect.left() + int(self.position * rect.width())
        p.drawLine(xp, rect.top(), xp, rect.bottom())
