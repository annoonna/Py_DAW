"""Installer helper for Py_DAW.

Usage:
    python3 install.py

It will:
- warn if you're not inside a virtual environment
- install/upgrade pip
- install requirements.txt

macOS notes:
- Audio backend uses CoreAudio via PortAudio (sounddevice).
- Some dependencies are system libs best installed via Homebrew:
  portaudio, libsndfile, fluidsynth

Linux notes:
- JACK/PipeWire system components are not installed here (distro packages).
"""

from __future__ import annotations

import os
import sys
import subprocess
import platform
import shutil
from pathlib import Path


def _run(cmd: list[str]) -> None:
    print(">>", " ".join(cmd))
    subprocess.check_call(cmd)


def _is_macos() -> bool:
    try:
        return platform.system().lower() == "darwin"
    except Exception:
        return False


def _brew_path() -> str | None:
    try:
        return shutil.which("brew")
    except Exception:
        return None


def _brew_has(brew: str, formula: str) -> bool:
    """Return True if a Homebrew formula seems installed."""
    try:
        r = subprocess.run([brew, "list", "--versions", formula], capture_output=True, text=True)
        return (r.returncode == 0) and bool((r.stdout or "").strip())
    except Exception:
        return False


def _brew_install_required() -> None:
    """Best-effort Homebrew install for macOS runtime deps.

    Safe-by-design:
    - If brew is missing: print instructions, do not fail.
    - If install fails: warn, do not fail (pip deps can still work).
    """
    if not _is_macos():
        return

    brew = _brew_path()
    if not brew:
        print("\n[macOS] Homebrew nicht gefunden.")
        print("       Installiere Homebrew (https://brew.sh) und führe dann aus:")
        print("       brew install portaudio libsndfile fluidsynth\n")
        return

    required = ["portaudio", "libsndfile", "fluidsynth"]
    missing = [f for f in required if not _brew_has(brew, f)]
    if not missing:
        print(f"[macOS] Homebrew deps OK: {', '.join(required)}")
        return

    print(f"[macOS] Installiere Homebrew deps: {', '.join(missing)}")
    try:
        _run([brew, "install", *missing])
    except Exception as exc:
        print("WARN: Homebrew install failed:", exc)
        print("      Du kannst es manuell versuchen:")
        print(f"      {brew} install {' '.join(missing)}")


def main() -> int:
    here = Path(__file__).resolve().parent
    req = here / "requirements.txt"
    if not req.exists():
        print("requirements.txt not found.")
        return 2

    in_venv = (hasattr(sys, "base_prefix") and sys.prefix != sys.base_prefix) or bool(os.environ.get("VIRTUAL_ENV"))
    if not in_venv:
        print("WARN: Es sieht so aus, als ob du NICHT in einer virtuellen Umgebung bist.")
        print("      Empfehlung: python3 -m venv myenv && source myenv/bin/activate")

    py = sys.executable
    try:
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
    except Exception as exc:
        print("WARN: pip upgrade failed:", exc)

    # macOS system deps (best-effort)
    _brew_install_required()

    _run([py, "-m", "pip", "install", "-r", str(req)])

    print("\nOK. Starte danach mit: python3 main.py")
    if _is_macos():
        print("macOS: Falls kein Sound kommt, öffne 'Audio → Audio Settings' und wähle ein Output-Device.")
        print("       Metal fallback: PYDAW_GFX_BACKEND=opengl python3 main.py")
    else:
        print("Optional: Audio/MIDI Abhängigkeiten können Systempakete erfordern (PipeWire-JACK/JACK/qpwgraph).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
