# -*- coding: utf-8 -*-
"""External plugin scanner (LV2/LADSPA/DSSI/VST).

SAFE DESIGN GOALS
-----------------
This module is intentionally *UI-only*:
- It does NOT load/host plugins.
- It does NOT touch the audio engine.
- It only scans the filesystem for installed plugins and extracts minimal metadata.

We keep this module dependency-free (stdlib only) and best-effort.
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set, Tuple


@dataclass(frozen=True)
class ExtPlugin:
    kind: str  # lv2|ladspa|dssi|vst2|vst3
    plugin_id: str  # stable identifier (LV2 URI or path)
    name: str
    path: str = ""  # filesystem path (bundle dir or binary)


def _cache_base_dir() -> Path:
    base = Path(os.path.expanduser("~/.cache")) / "ChronoScaleStudio"
    try:
        base.mkdir(parents=True, exist_ok=True)
    except Exception:
        return Path(".")
    return base


def cache_path() -> Path:
    return _cache_base_dir() / "plugin_cache.json"


def load_cache() -> Dict[str, List[ExtPlugin]]:
    p = cache_path()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}
    out: Dict[str, List[ExtPlugin]] = {}
    try:
        raw = data.get("plugins") or {}
        if not isinstance(raw, dict):
            return {}
        for kind, arr in raw.items():
            if not isinstance(arr, list):
                continue
            items: List[ExtPlugin] = []
            for it in arr:
                if not isinstance(it, dict):
                    continue
                pid = str(it.get("plugin_id") or "")
                nm = str(it.get("name") or "")
                path = str(it.get("path") or "")
                if pid:
                    items.append(ExtPlugin(str(kind), pid, nm or pid, path))
            out[str(kind)] = items
    except Exception:
        return {}
    return out


def save_cache(plugins: Dict[str, List[ExtPlugin]]) -> None:
    p = cache_path()
    try:
        data = {
            "ts": float(time.time()),
            "plugins": {k: [asdict(x) for x in v] for k, v in plugins.items()},
        }
        p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        return


def _split_env_paths(varname: str) -> List[Path]:
    raw = os.environ.get(varname) or ""
    if not raw:
        return []
    out: List[Path] = []
    for part in raw.split(os.pathsep):
        part = (part or "").strip()
        if part:
            out.append(Path(os.path.expanduser(part)))
    return out


def _linux_multiarch_libdirs() -> List[Path]:
    roots = []
    for p in (Path("/usr/lib"), Path("/usr/local/lib")):
        roots.append(p)
        try:
            for child in p.iterdir():
                if child.is_dir() and "-linux-gnu" in child.name:
                    roots.append(child)
        except Exception:
            continue
    seen: Set[str] = set()
    out: List[Path] = []
    for r in roots:
        s = str(r)
        if s not in seen:
            seen.add(s)
            out.append(r)
    return out


def default_paths(kind: str) -> List[Path]:
    kind = str(kind)
    home = Path(os.path.expanduser("~"))

    if sys.platform.startswith("linux"):
        libroots = _linux_multiarch_libdirs()
        mapping = {
            "lv2": [*(r / "lv2" for r in libroots), home / ".lv2", home / ".local/lib/lv2"],
            "ladspa": [*(r / "ladspa" for r in libroots), home / ".ladspa", home / ".local/lib/ladspa"],
            "dssi": [*(r / "dssi" for r in libroots), home / ".dssi", home / ".local/lib/dssi"],
            "vst2": [*(r / "vst" for r in libroots), home / ".vst", home / ".local/lib/vst"],
            "vst3": [*(r / "vst3" for r in libroots), home / ".vst3", home / ".local/lib/vst3"],
        }
        return [p for p in mapping.get(kind, [])]

    if sys.platform == "darwin":
        mapping = {
            "vst2": [Path("/Library/Audio/Plug-Ins/VST"), home / "Library/Audio/Plug-Ins/VST"],
            "vst3": [Path("/Library/Audio/Plug-Ins/VST3"), home / "Library/Audio/Plug-Ins/VST3"],
            "lv2": [Path("/Library/Audio/Plug-Ins/LV2"), home / "Library/Audio/Plug-Ins/LV2"],
            "ladspa": [Path("/Library/Audio/Plug-Ins/LADSPA"), home / "Library/Audio/Plug-Ins/LADSPA"],
            "dssi": [Path("/Library/Audio/Plug-Ins/DSSI"), home / "Library/Audio/Plug-Ins/DSSI"],
        }
        return [p for p in mapping.get(kind, [])]

    if sys.platform.startswith("win"):
        pf = os.environ.get("ProgramFiles") or r"C:\\Program Files"
        pf86 = os.environ.get("ProgramFiles(x86)") or r"C:\\Program Files (x86)"
        appdata = os.environ.get("APPDATA") or str(home / "AppData/Roaming")
        localappdata = os.environ.get("LOCALAPPDATA") or str(home / "AppData/Local")
        mapping = {
            "vst3": [Path(pf) / "Common Files/VST3", Path(pf86) / "Common Files/VST3", Path(localappdata) / "Programs/Common/VST3"],
            "vst2": [Path(pf) / "VSTPlugins", Path(pf) / "Steinberg/VstPlugins", Path(pf86) / "VSTPlugins", Path(pf86) / "Steinberg/VstPlugins", Path(appdata) / "VSTPlugins"],
            "lv2": [],
            "ladspa": [],
            "dssi": [],
        }
        return [p for p in mapping.get(kind, [])]

    return []


def resolve_search_paths(kind: str, extra_paths: Optional[Iterable[str]] = None) -> List[Path]:
    kind = str(kind)
    extras = [Path(os.path.expanduser(str(x))) for x in (extra_paths or []) if str(x).strip()]

    env_map = {
        "lv2": "LV2_PATH",
        "ladspa": "LADSPA_PATH",
        "dssi": "DSSI_PATH",
        "vst2": "VST_PATH",
        "vst3": "VST3_PATH",
    }
    env = _split_env_paths(env_map.get(kind, "")) if env_map.get(kind) else []

    out: List[Path] = []
    if extras:
        if any(p.exists() for p in extras):
            out = extras
    if not out:
        out = default_paths(kind)

    merged: List[Path] = []
    seen: Set[str] = set()
    for p in [*env, *out]:
        try:
            ps = str(p)
            if ps in seen:
                continue
            seen.add(ps)
            merged.append(p)
        except Exception:
            continue
    return merged


def _iter_existing_dirs(paths: Iterable[Path]) -> List[Path]:
    out: List[Path] = []
    seen: Set[str] = set()
    for p in paths:
        try:
            p = Path(p)
            if not p.exists() or not p.is_dir():
                continue
            s = str(p)
            if s in seen:
                continue
            seen.add(s)
            out.append(p)
        except Exception:
            continue
    return out


_LV2_STMT_RE = re.compile(
    r"<(?P<uri>[^>]+)>\s+a\s+[^.]*?lv2:(?:Plugin|InstrumentPlugin|EffectPlugin)[^.]*?\.",
    re.IGNORECASE | re.DOTALL,
)


def _lv2_guess_name(uri: str) -> str:
    u = str(uri)
    for sep in ("#", "/"):
        if sep in u:
            u = u.rsplit(sep, 1)[-1]
    return u or uri


def _parse_lv2_manifest(manifest_text: str) -> List[Tuple[str, str]]:
    t = manifest_text or ""
    t = re.sub(r"(^|\s)#.*$", "", t, flags=re.MULTILINE)
    found: List[Tuple[str, str]] = []
    for m in _LV2_STMT_RE.finditer(t):
        uri = m.group("uri") or ""
        stmt = m.group(0) or ""
        name = ""
        try:
            nm = re.search(r"(?:doap:name|rdfs:label)\s+\"([^\"]+)\"", stmt, flags=re.IGNORECASE)
            if nm:
                name = str(nm.group(1) or "").strip()
        except Exception:
            name = ""
        if uri:
            found.append((uri, name or _lv2_guess_name(uri)))
    return found


def scan_lv2(search_paths: Iterable[Path]) -> List[ExtPlugin]:
    items: List[ExtPlugin] = []
    seen: Set[str] = set()
    for base in _iter_existing_dirs(search_paths):
        try:
            for bundle in base.iterdir():
                try:
                    if not bundle.is_dir() or not bundle.name.lower().endswith(".lv2"):
                        continue
                    manifest = bundle / "manifest.ttl"
                    plugins: List[Tuple[str, str]] = []
                    if manifest.exists() and manifest.is_file():
                        try:
                            txt = manifest.read_text(encoding="utf-8", errors="ignore")
                            plugins = _parse_lv2_manifest(txt)
                        except Exception:
                            plugins = []
                    if not plugins:
                        pid = str(bundle)
                        if pid not in seen:
                            seen.add(pid)
                            items.append(ExtPlugin("lv2", pid, bundle.name, str(bundle)))
                        continue
                    for uri, name in plugins:
                        pid = str(uri)
                        if pid in seen:
                            continue
                        seen.add(pid)
                        items.append(ExtPlugin("lv2", pid, name, str(bundle)))
                except Exception:
                    continue
        except Exception:
            continue
    items.sort(key=lambda x: (x.name.lower(), x.plugin_id.lower()))
    return items


def _scan_shared_objects(search_paths: Iterable[Path], kind: str, exts: Tuple[str, ...]) -> List[ExtPlugin]:
    items: List[ExtPlugin] = []
    seen: Set[str] = set()
    max_items = 20000
    for base in _iter_existing_dirs(search_paths):
        try:
            for f in base.iterdir():
                if len(items) >= max_items:
                    break
                try:
                    if not f.is_file() or f.suffix.lower() not in exts:
                        continue
                    pid = str(f)
                    if pid in seen:
                        continue
                    seen.add(pid)
                    items.append(ExtPlugin(kind, pid, f.stem, str(f)))
                except Exception:
                    continue
        except Exception:
            continue
    items.sort(key=lambda x: (x.name.lower(), x.plugin_id.lower()))
    return items


def scan_ladspa(search_paths: Iterable[Path]) -> List[ExtPlugin]:
    exts = (".dll",) if sys.platform.startswith("win") else (".dylib", ".so") if sys.platform == "darwin" else (".so",)
    return _scan_shared_objects(search_paths, "ladspa", exts)


def scan_dssi(search_paths: Iterable[Path]) -> List[ExtPlugin]:
    exts = (".dll",) if sys.platform.startswith("win") else (".dylib", ".so") if sys.platform == "darwin" else (".so",)
    return _scan_shared_objects(search_paths, "dssi", exts)


def scan_vst2(search_paths: Iterable[Path]) -> List[ExtPlugin]:
    items: List[ExtPlugin] = []
    seen: Set[str] = set()
    max_items = 20000

    if sys.platform == "darwin":
        for base in _iter_existing_dirs(search_paths):
            try:
                for d in base.iterdir():
                    if len(items) >= max_items:
                        break
                    try:
                        if not d.is_dir() or not d.name.lower().endswith(".vst"):
                            continue
                        pid = str(d)
                        if pid in seen:
                            continue
                        seen.add(pid)
                        items.append(ExtPlugin("vst2", pid, d.stem, str(d)))
                    except Exception:
                        continue
            except Exception:
                continue
        items.sort(key=lambda x: (x.name.lower(), x.plugin_id.lower()))
        return items

    exts = (".dll",) if sys.platform.startswith("win") else (".so",)
    return _scan_shared_objects(search_paths, "vst2", exts)


def scan_vst3(search_paths: Iterable[Path]) -> List[ExtPlugin]:
    items: List[ExtPlugin] = []
    seen: Set[str] = set()
    max_items = 20000
    for base in _iter_existing_dirs(search_paths):
        try:
            for entry in base.iterdir():
                if len(items) >= max_items:
                    break
                try:
                    if entry.is_dir() and entry.name.lower().endswith(".vst3"):
                        pid = str(entry)
                        if pid in seen:
                            continue
                        seen.add(pid)
                        items.append(ExtPlugin("vst3", pid, entry.stem, str(entry)))
                        continue
                    if entry.is_file() and entry.suffix.lower() in (".vst3", ".dll", ".so", ".dylib"):
                        pid = str(entry)
                        if pid in seen:
                            continue
                        seen.add(pid)
                        items.append(ExtPlugin("vst3", pid, entry.stem, str(entry)))
                except Exception:
                    continue
        except Exception:
            continue
    items.sort(key=lambda x: (x.name.lower(), x.plugin_id.lower()))
    return items


def scan_all(extra_paths: Optional[Dict[str, Iterable[str]]] = None) -> Dict[str, List[ExtPlugin]]:
    extra_paths = extra_paths or {}
    return {
        "lv2": scan_lv2(resolve_search_paths("lv2", extra_paths.get("lv2"))),
        "ladspa": scan_ladspa(resolve_search_paths("ladspa", extra_paths.get("ladspa"))),
        "dssi": scan_dssi(resolve_search_paths("dssi", extra_paths.get("dssi"))),
        "vst2": scan_vst2(resolve_search_paths("vst2", extra_paths.get("vst2"))),
        "vst3": scan_vst3(resolve_search_paths("vst3", extra_paths.get("vst3"))),
    }
