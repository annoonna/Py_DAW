"""Media Sync Service — Content-addressed file streaming for collaboration.

v0.0.20.866 — Zero-config audio file sharing between collab participants.

Architecture:
  When a user adds an audio clip (drag & drop), the file is:
  1. SHA-256 hashed (background thread, non-blocking)
  2. Offered to all participants via collab op: media_offer
  3. Participants who don't have the file request it: media_request
  4. Sender streams the file in 64KB base64 chunks: media_chunk
  5. Receiver assembles the file, creates MediaItem + Clip

Features:
  - Content-addressed: same file = same hash, never sent twice
  - Chunked streaming: 64KB per chunk, non-blocking
  - Background transfer: GUI never freezes
  - Automatic: no manual steps, works transparently with drag & drop
  - Resumable: if connection drops, re-request picks up where it left off

Usage:
    sync = MediaSyncService(project_service, send_op_callback)
    sync.offer_file(path, clip_data)  # called when local user adds audio clip
    sync.handle_op(payload)           # called from collab_panel on incoming ops

"""

from __future__ import annotations

import base64
import hashlib
import logging
import os
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger(__name__)

# 64KB chunks — good balance between overhead and responsiveness
CHUNK_SIZE = 65536


@dataclass
class TransferInfo:
    """Tracks the state of an ongoing file transfer."""
    file_hash: str = ""
    file_name: str = ""
    file_size: int = 0
    total_chunks: int = 0
    received_chunks: Dict[int, bytes] = field(default_factory=dict)
    clip_data: Dict[str, Any] = field(default_factory=dict)
    started_at: float = 0.0
    sender_user_id: str = ""
    # For sending
    file_path: str = ""
    is_sending: bool = False
    is_complete: bool = False


class MediaSyncService:
    """Handles file synchronization between collab participants.

    Non-blocking, content-addressed, chunked streaming.
    """

    def __init__(self, project_service=None, send_op: Callable = None,
                 on_progress: Callable = None):
        """
        Args:
            project_service: ProjectService instance
            send_op: Callback to send a collab op: send_op(payload_dict)
            on_progress: Callback for UI progress: on_progress(hash, pct, label)
        """
        self._project = project_service
        self._send_op = send_op
        self._on_progress = on_progress

        # Known file hashes (content-addressed cache)
        # hash -> local file path
        self._known_files: Dict[str, str] = {}

        # Active incoming transfers: hash -> TransferInfo
        self._incoming: Dict[str, TransferInfo] = {}

        # Active outgoing transfers: hash -> TransferInfo
        self._outgoing: Dict[str, TransferInfo] = {}

        # Lock for thread safety
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Scan existing project media for deduplication
    # ------------------------------------------------------------------

    def scan_project_media(self) -> None:
        """Hash all existing media files in the project for deduplication."""
        try:
            ps = self._project
            if not ps:
                return
            ctx = getattr(ps, 'ctx', None)
            if not ctx:
                return
            media_dir = ctx.resolve_media_dir()
            if not media_dir or not Path(media_dir).is_dir():
                return

            count = 0
            for f in Path(media_dir).rglob("*"):
                if f.is_file() and f.suffix.lower() in (
                    ".wav", ".wave", ".flac", ".mp3", ".ogg", ".aiff", ".aif"
                ):
                    try:
                        h = self._hash_file(str(f))
                        self._known_files[h] = str(f)
                        count += 1
                    except Exception:
                        pass

            # Also check media items in project
            proj = getattr(ctx, 'project', None)
            if proj:
                for m in (getattr(proj, 'media', []) or []):
                    p = str(getattr(m, 'path', ''))
                    if p and Path(p).is_file():
                        try:
                            h = self._hash_file(p)
                            self._known_files[h] = p
                        except Exception:
                            pass

            if count:
                log.info("MediaSync: scanned %d existing files for dedup", count)
        except Exception as e:
            log.debug("MediaSync scan error: %s", e)

    # ------------------------------------------------------------------
    # Offer a file (sender side)
    # ------------------------------------------------------------------

    def offer_file(self, file_path: str, clip_data: Dict[str, Any]) -> None:
        """Offer a local audio file to all collab participants.

        Called when the local user adds an audio clip.
        Runs hashing in background thread to avoid GUI freeze.

        Args:
            file_path: Absolute path to the audio file
            clip_data: Clip metadata dict (track_id, start_beats, length_beats, label, etc.)
        """
        if not self._send_op or not file_path:
            return

        def _hash_and_offer():
            try:
                p = Path(file_path)
                if not p.is_file():
                    return
                file_hash = self._hash_file(str(p))
                file_size = p.stat().st_size
                file_name = p.name

                with self._lock:
                    self._known_files[file_hash] = str(p)

                # Send offer to all participants
                self._send_op({
                    "op_type": "media_offer",
                    "hash": file_hash,
                    "name": file_name,
                    "size": file_size,
                    "clip_data": clip_data,
                })

                log.info("MediaSync: offered '%s' (%s, %d bytes)",
                         file_name, file_hash[:12], file_size)
            except Exception as e:
                log.warning("MediaSync offer error: %s", e)

        t = threading.Thread(target=_hash_and_offer, daemon=True,
                             name="MediaSync-offer")
        t.start()

    # ------------------------------------------------------------------
    # Handle incoming ops
    # ------------------------------------------------------------------

    def handle_op(self, payload: Dict[str, Any]) -> bool:
        """Handle a media sync operation. Returns True if handled.

        Called from collab_panel._on_remote_operation for media_* ops.
        """
        op = payload.get("op_type", "")
        if op == "media_offer":
            self._handle_offer(payload)
            return True
        elif op == "media_request":
            self._handle_request(payload)
            return True
        elif op == "media_chunk":
            self._handle_chunk(payload)
            return True
        elif op == "media_complete":
            self._handle_complete(payload)
            return True
        return False

    def _handle_offer(self, payload: Dict[str, Any]) -> None:
        """Someone is offering a file. Check if we need it."""
        file_hash = str(payload.get("hash", ""))
        file_name = str(payload.get("name", ""))
        file_size = int(payload.get("size", 0))
        clip_data = payload.get("clip_data", {})
        sender = str(payload.get("_sender_user_id", ""))

        if not file_hash:
            return

        with self._lock:
            # Already have this file?
            if file_hash in self._known_files:
                local_path = self._known_files[file_hash]
                if Path(local_path).is_file():
                    log.info("MediaSync: already have '%s' (dedup)", file_name)
                    # Create the clip using our local copy
                    self._create_clip_from_local(local_path, clip_data)
                    return

            # Already downloading?
            if file_hash in self._incoming:
                return

        # Request the file
        total_chunks = max(1, (file_size + CHUNK_SIZE - 1) // CHUNK_SIZE)
        info = TransferInfo(
            file_hash=file_hash,
            file_name=file_name,
            file_size=file_size,
            total_chunks=total_chunks,
            clip_data=dict(clip_data),
            started_at=time.time(),
            sender_user_id=sender,
        )
        with self._lock:
            self._incoming[file_hash] = info

        self._send_op({
            "op_type": "media_request",
            "hash": file_hash,
        })

        self._report_progress(file_hash, 0, f"📥 {file_name}")
        log.info("MediaSync: requesting '%s' (%d bytes, %d chunks)",
                 file_name, file_size, total_chunks)

    def _handle_request(self, payload: Dict[str, Any]) -> None:
        """Someone wants a file we offered. Start streaming chunks."""
        file_hash = str(payload.get("hash", ""))
        if not file_hash:
            return

        with self._lock:
            file_path = self._known_files.get(file_hash, "")

        if not file_path or not Path(file_path).is_file():
            log.warning("MediaSync: requested file not found: %s", file_hash[:12])
            return

        # Stream in background thread
        def _stream():
            try:
                self._stream_file(file_hash, file_path)
            except Exception as e:
                log.warning("MediaSync stream error: %s", e)

        t = threading.Thread(target=_stream, daemon=True,
                             name=f"MediaSync-stream-{file_hash[:8]}")
        t.start()

    def _stream_file(self, file_hash: str, file_path: str) -> None:
        """Stream a file in chunks via collab ops."""
        p = Path(file_path)
        file_size = p.stat().st_size
        total_chunks = max(1, (file_size + CHUNK_SIZE - 1) // CHUNK_SIZE)
        file_name = p.name

        with self._lock:
            self._outgoing[file_hash] = TransferInfo(
                file_hash=file_hash,
                file_name=file_name,
                file_size=file_size,
                total_chunks=total_chunks,
                file_path=file_path,
                is_sending=True,
                started_at=time.time(),
            )

        log.info("MediaSync: streaming '%s' (%d chunks)", file_name, total_chunks)

        with open(file_path, "rb") as f:
            for chunk_idx in range(total_chunks):
                data = f.read(CHUNK_SIZE)
                if not data:
                    break

                data_b64 = base64.b64encode(data).decode("ascii")

                self._send_op({
                    "op_type": "media_chunk",
                    "hash": file_hash,
                    "chunk": chunk_idx,
                    "total": total_chunks,
                    "data": data_b64,
                })

                pct = int((chunk_idx + 1) * 100 / total_chunks)
                self._report_progress(file_hash, pct, f"📤 {file_name}")

                # Throttle to avoid flooding WebSocket (yield ~2ms per chunk)
                time.sleep(0.002)

        # Send completion marker
        self._send_op({
            "op_type": "media_complete",
            "hash": file_hash,
        })

        with self._lock:
            info = self._outgoing.pop(file_hash, None)
            if info:
                info.is_complete = True

        self._report_progress(file_hash, 100, f"✅ {file_name}")
        log.info("MediaSync: finished streaming '%s'", file_name)

    def _handle_chunk(self, payload: Dict[str, Any]) -> None:
        """Receive a file chunk."""
        file_hash = str(payload.get("hash", ""))
        chunk_idx = int(payload.get("chunk", 0))
        data_b64 = str(payload.get("data", ""))

        with self._lock:
            info = self._incoming.get(file_hash)
        if not info:
            return

        try:
            data = base64.b64decode(data_b64)
        except Exception:
            return

        info.received_chunks[chunk_idx] = data
        pct = int(len(info.received_chunks) * 100 / max(1, info.total_chunks))
        self._report_progress(file_hash, pct, f"📥 {info.file_name}")

    def _handle_complete(self, payload: Dict[str, Any]) -> None:
        """File transfer complete — assemble and create clip."""
        file_hash = str(payload.get("hash", ""))

        with self._lock:
            info = self._incoming.pop(file_hash, None)
        if not info:
            return

        # Assemble file from chunks
        try:
            assembled = b""
            for i in range(info.total_chunks):
                chunk = info.received_chunks.get(i)
                if chunk is None:
                    log.warning("MediaSync: missing chunk %d/%d for '%s'",
                                i, info.total_chunks, info.file_name)
                    self._report_progress(file_hash, -1,
                                          f"❌ {info.file_name} (unvollständig)")
                    return
                assembled += chunk

            # Verify hash
            actual_hash = hashlib.sha256(assembled).hexdigest()
            if actual_hash != file_hash:
                log.warning("MediaSync: hash mismatch for '%s'", info.file_name)
                self._report_progress(file_hash, -1,
                                      f"❌ {info.file_name} (Hash-Fehler)")
                return

            # Write to project media dir
            local_path = self._save_to_media_dir(info.file_name, assembled)
            if not local_path:
                return

            with self._lock:
                self._known_files[file_hash] = local_path

            # Create clip
            self._create_clip_from_local(local_path, info.clip_data)

            elapsed = time.time() - info.started_at
            speed = info.file_size / max(0.001, elapsed) / 1024
            self._report_progress(file_hash, 100,
                                  f"✅ {info.file_name} ({speed:.0f} KB/s)")
            log.info("MediaSync: received '%s' (%d bytes in %.1fs, %.0f KB/s)",
                     info.file_name, info.file_size, elapsed, speed)

        except Exception as e:
            log.error("MediaSync assembly error: %s", e)
            self._report_progress(file_hash, -1, f"❌ {info.file_name}")

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------

    def _hash_file(self, path: str) -> str:
        """Compute SHA-256 hash of a file."""
        h = hashlib.sha256()
        with open(path, "rb") as f:
            while True:
                chunk = f.read(CHUNK_SIZE)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    def _save_to_media_dir(self, file_name: str, data: bytes) -> str:
        """Save received file data to the project media directory."""
        try:
            ps = self._project
            if not ps:
                return ""
            ctx = getattr(ps, 'ctx', None)
            if not ctx:
                return ""
            media_dir = ctx.resolve_media_dir()
            Path(media_dir).mkdir(parents=True, exist_ok=True)

            # Avoid name collisions
            dest = Path(media_dir) / file_name
            if dest.exists():
                stem = dest.stem
                suffix = dest.suffix
                for i in range(1, 1000):
                    dest = Path(media_dir) / f"{stem}_{i}{suffix}"
                    if not dest.exists():
                        break

            dest.write_bytes(data)
            log.info("MediaSync: saved '%s' to %s", file_name, dest)
            return str(dest)
        except Exception as e:
            log.error("MediaSync save error: %s", e)
            return ""

    def _create_clip_from_local(self, local_path: str,
                                clip_data: Dict[str, Any]) -> None:
        """Create an audio clip from a local file using existing ProjectService."""
        try:
            ps = self._project
            if not ps:
                return
            from pydaw.services.project_service import ProjectService
            ProjectService._suppress_collab_notify = True
            try:
                track_id = str(clip_data.get("track_id", ""))
                start_beats = float(clip_data.get("start_beats", 0))
                source_bpm = clip_data.get("source_bpm")
                if track_id:
                    ps.add_audio_clip_from_file_at(
                        track_id, Path(local_path),
                        start_beats=start_beats,
                        source_bpm_override=source_bpm,
                    )
            finally:
                ProjectService._suppress_collab_notify = False
        except Exception as e:
            log.warning("MediaSync clip creation error: %s", e)

    # ------------------------------------------------------------------
    # Progress reporting
    # ------------------------------------------------------------------

    def _report_progress(self, file_hash: str, pct: int, label: str) -> None:
        """Report transfer progress to UI."""
        if self._on_progress:
            try:
                self._on_progress(file_hash, pct, label)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def get_active_transfers(self) -> List[Dict[str, Any]]:
        """Get list of active transfers for UI display."""
        result = []
        with self._lock:
            for h, info in self._incoming.items():
                pct = int(len(info.received_chunks) * 100 / max(1, info.total_chunks))
                result.append({
                    "hash": h[:12],
                    "name": info.file_name,
                    "size": info.file_size,
                    "pct": pct,
                    "direction": "download",
                })
            for h, info in self._outgoing.items():
                result.append({
                    "hash": h[:12],
                    "name": info.file_name,
                    "size": info.file_size,
                    "pct": 100 if info.is_complete else 50,
                    "direction": "upload",
                })
        return result

    def shutdown(self) -> None:
        """Clean up resources."""
        with self._lock:
            self._incoming.clear()
            self._outgoing.clear()
