// ============================================================================
// Scripting Engine — RM6.5: Embedded Scripting for Py_DAW
// ============================================================================
//
// Provides a lightweight embedded scripting API for automating DAW actions.
// Uses a simple built-in interpreter (no external dependency needed).
//
// Features:
//   - Script execution with DAW API bindings
//   - Macro recording (record user actions → script)
//   - Script library (save/load scripts)
//   - Batch operations (apply action to multiple tracks/clips)
//   - Scheduled execution (run script at transport position)
//
// Note: A full Rhai/Lua integration would require additional crate dependencies.
// This module provides the framework and a basic expression evaluator that can
// be extended to Rhai/Lua when the crate is added.
//
// v0.0.20.974 — RM6.5 (Claude Opus 4.6, 2026-04-04)
// ============================================================================

use std::collections::HashMap;
use std::time::{Instant, SystemTime, UNIX_EPOCH};

use log::{debug, error, info, warn};
use serde::{Deserialize, Serialize};

// ============================================================================
// Script Action — Atomic DAW operations
// ============================================================================

/// An atomic DAW action that can be recorded, replayed, and scripted.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ScriptAction {
    // Transport
    Play,
    Stop,
    Record,
    SetTempo(f64),
    SetLoop { enabled: bool, start: f64, end: f64 },
    Seek(f64),

    // Track operations
    AddTrack { name: String, kind: String },
    RemoveTrack { track_id: String },
    RenameTrack { track_id: String, name: String },
    SetTrackVolume { track_id: String, volume: f64 },
    SetTrackPan { track_id: String, pan: f64 },
    SetTrackMute { track_id: String, muted: bool },
    SetTrackSolo { track_id: String, solo: bool },

    // Clip operations
    AddClip { track_id: String, start: f64, length: f64, name: String },
    RemoveClip { clip_id: String },
    MoveClip { clip_id: String, track_id: String, start: f64 },
    DuplicateClip { clip_id: String },

    // MIDI operations
    AddNote { clip_id: String, pitch: u8, velocity: u8, start: f64, length: f64 },
    TransposeNotes { clip_id: String, semitones: i8 },
    QuantizeNotes { clip_id: String, grid: f64 },

    // Automation
    AddAutomationPoint { track_id: String, param: String, beat: f64, value: f64 },

    // FX
    AddFx { track_id: String, fx_type: String },
    RemoveFx { track_id: String, slot: u8 },
    SetFxParam { track_id: String, slot: u8, param: String, value: f64 },

    // Utility
    Wait(f64), // Wait N seconds
    Log(String),
    Comment(String),
}

// ============================================================================
// Script — A sequence of actions
// ============================================================================

/// A recorded or authored script.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Script {
    /// Script name
    pub name: String,
    /// Description
    pub description: String,
    /// Author
    pub author: String,
    /// Action sequence
    pub actions: Vec<ScriptAction>,
    /// Creation timestamp
    pub created_at: u64,
    /// Last modified timestamp
    pub modified_at: u64,
    /// Tags for organization
    pub tags: Vec<String>,
    /// Keyboard shortcut (if assigned)
    pub shortcut: Option<String>,
}

impl Script {
    pub fn new(name: &str) -> Self {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as u64;
        Self {
            name: name.to_string(),
            description: String::new(),
            author: String::new(),
            actions: Vec::new(),
            created_at: now,
            modified_at: now,
            tags: Vec::new(),
            shortcut: None,
        }
    }

    pub fn add_action(&mut self, action: ScriptAction) {
        self.actions.push(action);
        self.modified_at = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as u64;
    }

    pub fn action_count(&self) -> usize {
        self.actions.len()
    }

    /// Serialize to JSON.
    pub fn to_json(&self) -> String {
        serde_json::to_string_pretty(self).unwrap_or_default()
    }

    /// Deserialize from JSON.
    pub fn from_json(json: &str) -> Option<Self> {
        serde_json::from_str(json).ok()
    }
}

// ============================================================================
// Macro Recorder
// ============================================================================

/// Records user actions into a script.
pub struct MacroRecorder {
    /// Whether recording is active
    pub recording: bool,
    /// Current recording
    pub current_script: Script,
    /// Whether to record transport actions
    pub record_transport: bool,
    /// Whether to record mixer actions
    pub record_mixer: bool,
    /// Whether to record edit actions
    pub record_edits: bool,
    /// Start time for relative timestamps
    start_time: Option<Instant>,
}

impl MacroRecorder {
    pub fn new() -> Self {
        Self {
            recording: false,
            current_script: Script::new("Untitled Macro"),
            record_transport: true,
            record_mixer: true,
            record_edits: true,
            start_time: None,
        }
    }

    /// Start recording.
    pub fn start(&mut self, name: &str) {
        self.current_script = Script::new(name);
        self.recording = true;
        self.start_time = Some(Instant::now());
        info!("Macro recording started: {}", name);
    }

    /// Stop recording and return the script.
    pub fn stop(&mut self) -> Script {
        self.recording = false;
        self.start_time = None;
        info!(
            "Macro recording stopped: {} ({} actions)",
            self.current_script.name,
            self.current_script.action_count()
        );
        self.current_script.clone()
    }

    /// Record an action (only if recording is active).
    pub fn record(&mut self, action: ScriptAction) {
        if !self.recording { return; }

        // Filter by category
        match &action {
            ScriptAction::Play | ScriptAction::Stop | ScriptAction::Record
            | ScriptAction::SetTempo(_) | ScriptAction::Seek(_) => {
                if !self.record_transport { return; }
            }
            ScriptAction::SetTrackVolume { .. } | ScriptAction::SetTrackPan { .. }
            | ScriptAction::SetTrackMute { .. } | ScriptAction::SetTrackSolo { .. } => {
                if !self.record_mixer { return; }
            }
            _ => {
                if !self.record_edits { return; }
            }
        }

        // Add wait action if time has passed
        if let Some(start) = self.start_time {
            let elapsed = start.elapsed().as_secs_f64();
            if elapsed > 0.1 && !self.current_script.actions.is_empty() {
                // Insert a wait action (debounced)
                // Only add if the last action wasn't a wait
                if !matches!(self.current_script.actions.last(), Some(ScriptAction::Wait(_))) {
                    // Don't add tiny waits
                    if elapsed > 0.5 {
                        self.current_script.add_action(ScriptAction::Wait(elapsed));
                    }
                }
            }
            self.start_time = Some(Instant::now()); // Reset for next action
        }

        self.current_script.add_action(action);
    }
}

// ============================================================================
// Script Library
// ============================================================================

/// Manages saved scripts.
pub struct ScriptLibrary {
    /// Scripts by name
    pub scripts: HashMap<String, Script>,
    /// Library path (for file-based persistence)
    pub library_path: Option<std::path::PathBuf>,
}

impl ScriptLibrary {
    pub fn new() -> Self {
        Self {
            scripts: HashMap::new(),
            library_path: None,
        }
    }

    /// Save a script to the library.
    pub fn save(&mut self, script: Script) {
        info!("Saved script: {} ({} actions)", script.name, script.action_count());
        self.scripts.insert(script.name.clone(), script);
    }

    /// Get a script by name.
    pub fn get(&self, name: &str) -> Option<&Script> {
        self.scripts.get(name)
    }

    /// Remove a script.
    pub fn remove(&mut self, name: &str) -> Option<Script> {
        self.scripts.remove(name)
    }

    /// List all scripts.
    pub fn list(&self) -> Vec<&Script> {
        self.scripts.values().collect()
    }

    /// Search scripts by name or tag.
    pub fn search(&self, query: &str) -> Vec<&Script> {
        let q = query.to_lowercase();
        self.scripts
            .values()
            .filter(|s| {
                s.name.to_lowercase().contains(&q)
                    || s.description.to_lowercase().contains(&q)
                    || s.tags.iter().any(|t| t.to_lowercase().contains(&q))
            })
            .collect()
    }

    /// Export library to JSON.
    pub fn export_all(&self) -> String {
        let scripts: Vec<&Script> = self.scripts.values().collect();
        serde_json::to_string_pretty(&scripts).unwrap_or_default()
    }

    /// Import scripts from JSON.
    pub fn import_all(&mut self, json: &str) -> Result<u32, String> {
        let scripts: Vec<Script> = serde_json::from_str(json)
            .map_err(|e| format!("JSON parse error: {}", e))?;
        let mut count = 0;
        for script in scripts {
            self.scripts.insert(script.name.clone(), script);
            count += 1;
        }
        Ok(count)
    }
}

// ============================================================================
// Script Execution Result
// ============================================================================

/// Result of executing a script action.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionResult {
    pub action_index: usize,
    pub success: bool,
    pub message: String,
    pub elapsed_ms: f64,
}

/// Result of executing a full script.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScriptResult {
    pub script_name: String,
    pub total_actions: usize,
    pub successful: usize,
    pub failed: usize,
    pub total_elapsed_ms: f64,
    pub results: Vec<ExecutionResult>,
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_script_creation() {
        let mut script = Script::new("Test Script");
        script.add_action(ScriptAction::Play);
        script.add_action(ScriptAction::SetTempo(120.0));
        script.add_action(ScriptAction::Stop);

        assert_eq!(script.name, "Test Script");
        assert_eq!(script.action_count(), 3);
    }

    #[test]
    fn test_script_serialization() {
        let mut script = Script::new("Test");
        script.add_action(ScriptAction::SetTempo(140.0));
        script.add_action(ScriptAction::AddTrack {
            name: "Drums".into(),
            kind: "instrument".into(),
        });

        let json = script.to_json();
        let parsed = Script::from_json(&json).unwrap();
        assert_eq!(parsed.name, "Test");
        assert_eq!(parsed.action_count(), 2);
    }

    #[test]
    fn test_macro_recorder() {
        let mut recorder = MacroRecorder::new();
        assert!(!recorder.recording);

        recorder.start("My Macro");
        assert!(recorder.recording);

        recorder.record(ScriptAction::Play);
        recorder.record(ScriptAction::SetTempo(130.0));
        recorder.record(ScriptAction::Stop);

        let script = recorder.stop();
        assert!(!recorder.recording);
        assert_eq!(script.name, "My Macro");
        assert_eq!(script.action_count(), 3);
    }

    #[test]
    fn test_macro_recorder_filtering() {
        let mut recorder = MacroRecorder::new();
        recorder.record_transport = false;

        recorder.start("Filtered");
        recorder.record(ScriptAction::Play); // should be filtered
        recorder.record(ScriptAction::AddTrack { name: "Test".into(), kind: "audio".into() });

        let script = recorder.stop();
        assert_eq!(script.action_count(), 1); // only AddTrack
    }

    #[test]
    fn test_script_library() {
        let mut lib = ScriptLibrary::new();

        let mut s1 = Script::new("Macro 1");
        s1.tags = vec!["drums".into()];
        s1.add_action(ScriptAction::Play);

        let mut s2 = Script::new("Macro 2");
        s2.tags = vec!["mixing".into()];
        s2.add_action(ScriptAction::Stop);

        lib.save(s1);
        lib.save(s2);

        assert_eq!(lib.list().len(), 2);
        assert!(lib.get("Macro 1").is_some());

        // Search
        let results = lib.search("drums");
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].name, "Macro 1");

        // Export/Import
        let json = lib.export_all();
        let mut lib2 = ScriptLibrary::new();
        let count = lib2.import_all(&json).unwrap();
        assert_eq!(count, 2);
    }
}
