// ============================================================================
// Music AI & Theory Engine — v0.0.20.973 (RM7)
// ============================================================================
//
// Pure-algorithmic music theory and generation. No ML models, no Python.
// Covers: scales, chords, harmony analysis, melody/drum/bass generation.
// ============================================================================

use serde::{Deserialize, Serialize};
use crate::model::MidiNote;

// ============================================================================
// RM7.1: Scales & Chords
// ============================================================================

/// Scale definition as semitone intervals from root
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Scale {
    pub name: String,
    pub intervals: Vec<u8>, // semitones from root
}

impl Scale {
    pub fn major() -> Self { Self { name: "Major".into(), intervals: vec![0,2,4,5,7,9,11] } }
    pub fn minor() -> Self { Self { name: "Minor".into(), intervals: vec![0,2,3,5,7,8,10] } }
    pub fn harmonic_minor() -> Self { Self { name: "Harmonic Minor".into(), intervals: vec![0,2,3,5,7,8,11] } }
    pub fn melodic_minor() -> Self { Self { name: "Melodic Minor".into(), intervals: vec![0,2,3,5,7,9,11] } }
    pub fn dorian() -> Self { Self { name: "Dorian".into(), intervals: vec![0,2,3,5,7,9,10] } }
    pub fn phrygian() -> Self { Self { name: "Phrygian".into(), intervals: vec![0,1,3,5,7,8,10] } }
    pub fn lydian() -> Self { Self { name: "Lydian".into(), intervals: vec![0,2,4,6,7,9,11] } }
    pub fn mixolydian() -> Self { Self { name: "Mixolydian".into(), intervals: vec![0,2,4,5,7,9,10] } }
    pub fn locrian() -> Self { Self { name: "Locrian".into(), intervals: vec![0,1,3,5,6,8,10] } }
    pub fn pentatonic_major() -> Self { Self { name: "Pentatonic Major".into(), intervals: vec![0,2,4,7,9] } }
    pub fn pentatonic_minor() -> Self { Self { name: "Pentatonic Minor".into(), intervals: vec![0,3,5,7,10] } }
    pub fn blues() -> Self { Self { name: "Blues".into(), intervals: vec![0,3,5,6,7,10] } }
    pub fn whole_tone() -> Self { Self { name: "Whole Tone".into(), intervals: vec![0,2,4,6,8,10] } }
    pub fn diminished() -> Self { Self { name: "Diminished".into(), intervals: vec![0,2,3,5,6,8,9,11] } }
    pub fn chromatic() -> Self { Self { name: "Chromatic".into(), intervals: (0..12).collect() } }

    /// All built-in scales
    pub fn all() -> Vec<Self> {
        vec![Self::major(), Self::minor(), Self::harmonic_minor(), Self::melodic_minor(),
             Self::dorian(), Self::phrygian(), Self::lydian(), Self::mixolydian(),
             Self::locrian(), Self::pentatonic_major(), Self::pentatonic_minor(),
             Self::blues(), Self::whole_tone(), Self::diminished(), Self::chromatic()]
    }

    /// Get all MIDI pitches in this scale for a given root (0=C) across octaves
    pub fn pitches(&self, root: u8, octave_low: u8, octave_high: u8) -> Vec<u8> {
        let mut result = Vec::new();
        for oct in octave_low..=octave_high {
            for &interval in &self.intervals {
                let pitch = root + oct * 12 + interval;
                if pitch <= 127 { result.push(pitch); }
            }
        }
        result
    }

    /// Check if a pitch belongs to this scale
    pub fn contains(&self, root: u8, pitch: u8) -> bool {
        let pc = (pitch + 12 - root) % 12;
        self.intervals.contains(&pc)
    }

    /// Snap a pitch to the nearest scale degree
    pub fn snap(&self, root: u8, pitch: u8) -> u8 {
        let pc = (pitch + 12 - root) % 12;
        let octave = pitch / 12;
        let nearest = self.intervals.iter()
            .min_by_key(|&&i| {
                let d1 = (pc as i8 - i as i8).unsigned_abs();
                let d2 = (12 - d1 as i16).unsigned_abs() as u8;
                d1.min(d2)
            })
            .copied()
            .unwrap_or(0);
        let result = octave * 12 + root + nearest;
        result.min(127)
    }
}

/// Chord quality
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum ChordQuality {
    Major, Minor, Diminished, Augmented,
    Major7, Minor7, Dominant7, HalfDim7, Dim7, MinMaj7,
    Sus2, Sus4, Add9, Major9, Minor9,
    Power, // root + fifth only
}

impl ChordQuality {
    /// Intervals from root in semitones
    pub fn intervals(&self) -> Vec<u8> {
        match self {
            Self::Major => vec![0, 4, 7],
            Self::Minor => vec![0, 3, 7],
            Self::Diminished => vec![0, 3, 6],
            Self::Augmented => vec![0, 4, 8],
            Self::Major7 => vec![0, 4, 7, 11],
            Self::Minor7 => vec![0, 3, 7, 10],
            Self::Dominant7 => vec![0, 4, 7, 10],
            Self::HalfDim7 => vec![0, 3, 6, 10],
            Self::Dim7 => vec![0, 3, 6, 9],
            Self::MinMaj7 => vec![0, 3, 7, 11],
            Self::Sus2 => vec![0, 2, 7],
            Self::Sus4 => vec![0, 5, 7],
            Self::Add9 => vec![0, 4, 7, 14],
            Self::Major9 => vec![0, 4, 7, 11, 14],
            Self::Minor9 => vec![0, 3, 7, 10, 14],
            Self::Power => vec![0, 7],
        }
    }

    /// Generate MIDI notes for this chord
    pub fn to_notes(&self, root: u8, octave: u8, velocity: u8, start: f64, length: f64) -> Vec<MidiNote> {
        let base = root + octave * 12;
        self.intervals().iter().map(|&i| {
            MidiNote::new((base + i).min(127), velocity, start, length)
        }).collect()
    }
}

/// Detect chord quality from a set of MIDI pitches
pub fn detect_chord(pitches: &[u8]) -> Option<(u8, ChordQuality)> {
    if pitches.len() < 2 { return None; }
    let mut pcs: Vec<u8> = pitches.iter().map(|p| p % 12).collect();
    pcs.sort();
    pcs.dedup();

    // Try each pitch class as root
    for &root in &pcs {
        let intervals: Vec<u8> = pcs.iter().map(|&p| (p + 12 - root) % 12).collect();
        let mut sorted = intervals.clone();
        sorted.sort();

        // Match against known chord qualities
        let qualities = [
            ChordQuality::Major, ChordQuality::Minor, ChordQuality::Diminished,
            ChordQuality::Augmented, ChordQuality::Major7, ChordQuality::Minor7,
            ChordQuality::Dominant7, ChordQuality::HalfDim7, ChordQuality::Dim7,
            ChordQuality::Sus2, ChordQuality::Sus4, ChordQuality::Power,
        ];
        for q in &qualities {
            let mut qi = q.intervals();
            qi.sort();
            if qi == sorted { return Some((root, *q)); }
        }
    }
    None
}

/// Detect key/scale from a collection of notes
pub fn detect_key(notes: &[MidiNote]) -> Option<(u8, String)> {
    if notes.is_empty() { return None; }

    // Count pitch class occurrences
    let mut histogram = [0u32; 12];
    for note in notes {
        histogram[(note.pitch % 12) as usize] += 1;
    }

    // Krumhansl-Schmuckler key-finding algorithm (simplified)
    let major_profile = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88];
    let minor_profile = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17];

    let mut best_key = 0u8;
    let mut best_mode = "Major";
    let mut best_corr = f64::NEG_INFINITY;

    for root in 0..12u8 {
        for (profile, mode) in [(&major_profile, "Major"), (&minor_profile, "Minor")] {
            let mut corr = 0.0;
            for i in 0..12 {
                let rotated = (i + root as usize) % 12;
                corr += histogram[rotated] as f64 * profile[i];
            }
            if corr > best_corr {
                best_corr = corr;
                best_key = root;
                best_mode = mode;
            }
        }
    }

    let note_names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
    Some((best_key, format!("{} {}", note_names[best_key as usize], best_mode)))
}

// ============================================================================
// RM7.2: Generators
// ============================================================================

/// Simple PRNG for deterministic generation
struct Rng(u64);
impl Rng {
    fn new(seed: u64) -> Self { Self(seed) }
    fn next(&mut self) -> u64 {
        self.0 = self.0.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        self.0 >> 33
    }
    fn range(&mut self, min: u64, max: u64) -> u64 {
        if max <= min { return min; }
        min + self.next() % (max - min)
    }
    fn f64(&mut self) -> f64 { self.next() as f64 / u64::MAX as f64 }
    fn choose<'a, T>(&mut self, items: &'a [T]) -> &'a T {
        &items[self.range(0, items.len() as u64) as usize]
    }
}

/// Generate a melody following a scale
pub fn generate_melody(
    root: u8, scale: &Scale, octave: u8, bars: u32, bpm: f64, seed: u64,
) -> Vec<MidiNote> {
    let mut rng = Rng::new(seed);
    let pitches = scale.pitches(root, octave, octave + 1);
    let mut notes = Vec::new();
    let beats_per_bar = 4.0;
    let durations = [0.25, 0.5, 0.5, 1.0, 1.0, 2.0]; // weighted toward quarter/half

    let mut beat = 0.0;
    let total_beats = bars as f64 * beats_per_bar;
    let mut last_pitch_idx = pitches.len() / 2; // start in middle

    while beat < total_beats {
        // Step movement (mostly ±1-2 scale degrees)
        let step = rng.range(0, 5) as i32 - 2; // -2..2
        let new_idx = (last_pitch_idx as i32 + step).clamp(0, pitches.len() as i32 - 1) as usize;
        last_pitch_idx = new_idx;

        let pitch = pitches[new_idx];
        let duration = *rng.choose(&durations);
        let velocity = rng.range(70, 110) as u8;

        // Occasional rest
        if rng.f64() < 0.15 {
            beat += duration;
            continue;
        }

        let length = duration * 0.9; // slight gap
        notes.push(MidiNote::new(pitch, velocity, beat, length));
        beat += duration;
    }
    notes
}

/// Generate a chord progression
pub fn generate_progression(
    root: u8, mode: &str, bars: u32, seed: u64,
) -> Vec<(f64, u8, ChordQuality)> {
    let mut rng = Rng::new(seed);
    let mut progression = Vec::new();

    // Common progressions by mode
    let degrees_major = [
        vec![(0, ChordQuality::Major), (5, ChordQuality::Major), (7, ChordQuality::Major), (5, ChordQuality::Major)], // I-IV-V-IV
        vec![(0, ChordQuality::Major), (7, ChordQuality::Major), (9, ChordQuality::Minor), (5, ChordQuality::Major)], // I-V-vi-IV
        vec![(0, ChordQuality::Major), (2, ChordQuality::Minor), (5, ChordQuality::Major), (7, ChordQuality::Major)], // I-ii-IV-V
        vec![(0, ChordQuality::Major), (9, ChordQuality::Minor), (5, ChordQuality::Major), (7, ChordQuality::Major)], // I-vi-IV-V
    ];
    let degrees_minor = [
        vec![(0, ChordQuality::Minor), (3, ChordQuality::Major), (5, ChordQuality::Major), (7, ChordQuality::Major)], // i-III-IV-V
        vec![(0, ChordQuality::Minor), (5, ChordQuality::Major), (7, ChordQuality::Dominant7), (0, ChordQuality::Minor)], // i-iv-V7-i
        vec![(0, ChordQuality::Minor), (3, ChordQuality::Major), (8, ChordQuality::Major), (5, ChordQuality::Major)], // i-III-bVI-iv
    ];

    let patterns = if mode == "Minor" { &degrees_minor[..] } else { &degrees_major[..] };
    let pattern = rng.choose(patterns);

    for bar in 0..bars {
        let idx = (bar as usize) % pattern.len();
        let (degree, quality) = pattern[idx];
        let chord_root = (root + degree) % 12;
        progression.push((bar as f64 * 4.0, chord_root, quality));
    }
    progression
}

/// Generate a drum pattern
pub fn generate_drum_pattern(
    bars: u32, style: DrumStyle, seed: u64,
) -> Vec<MidiNote> {
    let mut rng = Rng::new(seed);
    let mut notes = Vec::new();

    // GM Drum Map: 36=Kick, 38=Snare, 42=HiHat Closed, 46=HiHat Open, 49=Crash
    let kick = 36u8;
    let snare = 38u8;
    let hihat = 42u8;
    let hihat_open = 46u8;
    let crash = 49u8;

    let steps = 16; // 16th note grid
    let step_len = 0.25; // 16th note in beats

    for bar in 0..bars {
        let bar_offset = bar as f64 * 4.0;

        for step in 0..steps {
            let beat = bar_offset + step as f64 * step_len;

            match style {
                DrumStyle::Rock => {
                    if step % 4 == 0 { notes.push(MidiNote::new(kick, 110, beat, 0.1)); }
                    if step % 8 == 4 { notes.push(MidiNote::new(snare, 100, beat, 0.1)); }
                    if step % 2 == 0 { notes.push(MidiNote::new(hihat, 80, beat, 0.05)); }
                }
                DrumStyle::Pop => {
                    if step == 0 || step == 6 { notes.push(MidiNote::new(kick, 105, beat, 0.1)); }
                    if step == 4 || step == 12 { notes.push(MidiNote::new(snare, 95, beat, 0.1)); }
                    notes.push(MidiNote::new(hihat, 70, beat, 0.05));
                }
                DrumStyle::HipHop => {
                    if step == 0 || step == 7 || step == 10 { notes.push(MidiNote::new(kick, 120, beat, 0.1)); }
                    if step == 4 || step == 12 { notes.push(MidiNote::new(snare, 100, beat, 0.1)); }
                    if step % 2 == 0 { notes.push(MidiNote::new(hihat, 65 + rng.range(0, 20) as u8, beat, 0.05)); }
                }
                DrumStyle::Electronic => {
                    if step % 4 == 0 { notes.push(MidiNote::new(kick, 127, beat, 0.1)); }
                    if step % 8 == 4 { notes.push(MidiNote::new(snare, 100, beat, 0.1)); }
                    notes.push(MidiNote::new(hihat, 60 + (step % 4 * 10) as u8, beat, 0.03));
                    if step == 14 && rng.f64() < 0.3 { notes.push(MidiNote::new(hihat_open, 90, beat, 0.1)); }
                }
                DrumStyle::Jazz => {
                    // Swing ride pattern
                    if step % 6 == 0 || step % 6 == 4 {
                        notes.push(MidiNote::new(51, 75 + rng.range(0, 20) as u8, beat, 0.05)); // ride
                    }
                    if step == 0 { notes.push(MidiNote::new(kick, 70, beat, 0.1)); }
                    if rng.f64() < 0.15 { notes.push(MidiNote::new(snare, 50 + rng.range(0, 30) as u8, beat, 0.05)); }
                }
            }

            // Crash on bar 1
            if bar == 0 && step == 0 { notes.push(MidiNote::new(crash, 100, beat, 0.2)); }
        }
    }
    notes
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum DrumStyle { Rock, Pop, HipHop, Electronic, Jazz }

/// Generate a bass line following a chord progression
pub fn generate_bass(
    progression: &[(f64, u8, ChordQuality)], bars: u32, style: BassStyle, seed: u64,
) -> Vec<MidiNote> {
    let mut rng = Rng::new(seed);
    let mut notes = Vec::new();
    let octave: u8 = 2; // bass octave

    for &(start_beat, root, quality) in progression {
        let chord_tones = quality.intervals();
        let base_pitch = root + octave * 12;
        let end_beat = start_beat + 4.0; // 1 bar per chord

        match style {
            BassStyle::Root => {
                notes.push(MidiNote::new(base_pitch, 100, start_beat, 3.8));
            }
            BassStyle::RootFifth => {
                notes.push(MidiNote::new(base_pitch, 100, start_beat, 1.8));
                let fifth = base_pitch + chord_tones.get(2).copied().unwrap_or(7);
                notes.push(MidiNote::new(fifth, 90, start_beat + 2.0, 1.8));
            }
            BassStyle::Walking => {
                let mut beat = start_beat;
                let mut last = base_pitch;
                while beat < end_beat {
                    let target = if rng.f64() < 0.6 {
                        base_pitch + chord_tones[rng.range(0, chord_tones.len() as u64) as usize]
                    } else {
                        // chromatic approach
                        let next_root = base_pitch;
                        if last > next_root { last - 1 } else { last + 1 }
                    };
                    let pitch = target.clamp(24, 60);
                    notes.push(MidiNote::new(pitch, 90 + rng.range(0, 15) as u8, beat, 0.9));
                    last = pitch;
                    beat += 1.0;
                }
            }
            BassStyle::Octave => {
                notes.push(MidiNote::new(base_pitch, 110, start_beat, 0.4));
                notes.push(MidiNote::new(base_pitch + 12, 90, start_beat + 0.5, 0.4));
                notes.push(MidiNote::new(base_pitch, 110, start_beat + 1.0, 0.4));
                notes.push(MidiNote::new(base_pitch + 12, 90, start_beat + 1.5, 0.4));
                notes.push(MidiNote::new(base_pitch, 110, start_beat + 2.0, 0.4));
                notes.push(MidiNote::new(base_pitch + 12, 90, start_beat + 2.5, 0.4));
                notes.push(MidiNote::new(base_pitch, 110, start_beat + 3.0, 0.9));
            }
        }
    }
    notes
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum BassStyle { Root, RootFifth, Walking, Octave }

// ============================================================================
// RM7.3: Mix Analysis (simplified)
// ============================================================================

/// Analyze frequency content of audio (simplified spectrum)
pub fn analyze_spectrum(audio: &[f32], sample_rate: u32, num_bands: usize) -> Vec<f64> {
    if audio.is_empty() || num_bands == 0 { return vec![0.0; num_bands]; }

    // Simple band-pass energy analysis (no FFT needed for coarse analysis)
    let mut bands = vec![0.0f64; num_bands];
    let nyquist = sample_rate as f64 / 2.0;

    // Band edges (logarithmic spacing from 20Hz to nyquist)
    let log_min = 20.0_f64.ln();
    let log_max = nyquist.ln();

    for band in 0..num_bands {
        let lo = ((log_min + (log_max - log_min) * band as f64 / num_bands as f64).exp()) / nyquist;
        let hi = ((log_min + (log_max - log_min) * (band + 1) as f64 / num_bands as f64).exp()) / nyquist;
        let center = (lo + hi) / 2.0;

        // Simple resonant bandpass (2nd order)
        let q = 2.0;
        let w0 = std::f64::consts::TAU * center;
        let alpha = w0.sin() / (2.0 * q);
        let b0 = alpha;
        let b1 = 0.0;
        let b2 = -alpha;
        let a0 = 1.0 + alpha;
        let a1 = -2.0 * w0.cos();
        let a2 = 1.0 - alpha;

        let mut x1 = 0.0; let mut x2 = 0.0;
        let mut y1 = 0.0; let mut y2 = 0.0;
        let mut energy = 0.0;

        for &s in audio {
            let x = s as f64;
            let y = (b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2) / a0;
            x2 = x1; x1 = x;
            y2 = y1; y1 = y;
            energy += y * y;
        }
        bands[band] = (energy / audio.len() as f64).sqrt();
    }
    bands
}

/// Detect frequency masking between two tracks
pub fn detect_masking(track_a: &[f64], track_b: &[f64], threshold_db: f64) -> Vec<bool> {
    let threshold = 10.0_f64.powf(threshold_db / 20.0);
    track_a.iter().zip(track_b.iter())
        .map(|(&a, &b)| {
            let min = a.min(b);
            let max = a.max(b);
            max > 0.0 && min / max > threshold
        })
        .collect()
}
