use std::sync::atomic::{AtomicU32, AtomicU64, Ordering};

// ============================================================================
// AtomicF32 — Lock-free f32 for audio-thread parameter access
// ============================================================================
//
// Replaces the external `atomic_float` crate with a zero-dependency impl.
// Uses AtomicU32 + f32::to_bits / f32::from_bits (standard pattern).
// ============================================================================

/// Lock-free f32 value for real-time audio parameters.
///
/// Uses bit-casting to AtomicU32 — no allocations, no locks.
pub struct AtomicF32 {
    bits: AtomicU32,
}

impl AtomicF32 {
    pub fn new(val: f32) -> Self {
        Self {
            bits: AtomicU32::new(val.to_bits()),
        }
    }

    #[inline]
    pub fn load(&self, order: Ordering) -> f32 {
        f32::from_bits(self.bits.load(order))
    }

    #[inline]
    pub fn store(&self, val: f32, order: Ordering) {
        self.bits.store(val.to_bits(), order);
    }
}

// ============================================================================
// Lock-Free Ring Buffer — Zero-lock parameter updates for audio thread
// ============================================================================
//
// This is the Rust equivalent of Python's ParamRingBuffer (ring_buffer.py).
//
// Architecture:
//   GUI Thread → write(param_id, value) → SPSC Ring → Audio Thread → drain()
//
// The ring is lock-free: single-producer (GUI), single-consumer (audio).
// No allocations, no locks, no syscalls in the hot path.
//
// Capacity is fixed at compile time (power of 2 for fast modulo via bitmask).
// ============================================================================

/// Single parameter update entry in the ring.
#[repr(C)]
#[derive(Clone, Copy)]
pub struct ParamEntry {
    /// Parameter ID (matches Python RTParamStore keys).
    pub param_id: u32,
    /// Parameter value (f64 stored as u64 bits for atomic access).
    pub value_bits: u64,
}

impl ParamEntry {
    pub fn new(param_id: u32, value: f64) -> Self {
        Self {
            param_id,
            value_bits: value.to_bits(),
        }
    }

    pub fn value(&self) -> f64 {
        f64::from_bits(self.value_bits)
    }
}

/// Ring buffer capacity — must be power of 2.
const RING_CAPACITY: usize = 4096;
const RING_MASK: usize = RING_CAPACITY - 1;

/// Lock-free SPSC (Single-Producer Single-Consumer) ring buffer.
///
/// Producer (GUI thread) calls `push()`.
/// Consumer (audio thread) calls `drain_into()`.
///
/// Overflow policy: oldest entries are silently dropped (the audio thread
/// will see the latest value on the next drain cycle anyway).
pub struct ParamRing {
    /// Ring storage (fixed size, never reallocated).
    entries: Box<[ParamEntry; RING_CAPACITY]>,
    /// Write position (only modified by producer).
    write_pos: AtomicU32,
    /// Read position (only modified by consumer).
    read_pos: AtomicU32,
}

impl ParamRing {
    pub fn new() -> Self {
        Self {
            entries: Box::new([ParamEntry { param_id: 0, value_bits: 0 }; RING_CAPACITY]),
            write_pos: AtomicU32::new(0),
            read_pos: AtomicU32::new(0),
        }
    }

    /// Push a parameter update (GUI thread). Lock-free, wait-free.
    ///
    /// If the ring is full, the oldest entry is overwritten.
    pub fn push(&self, param_id: u32, value: f64) {
        let wp = self.write_pos.load(Ordering::Relaxed) as usize;
        let idx = wp & RING_MASK;

        // Safety: we're the only writer, and we write before advancing the pointer.
        // The consumer only reads entries between read_pos and write_pos.
        unsafe {
            let ptr = self.entries.as_ptr() as *mut ParamEntry;
            (*ptr.add(idx)) = ParamEntry::new(param_id, value);
        }

        self.write_pos.store((wp + 1) as u32, Ordering::Release);
    }

    /// Drain all pending entries into a callback. Lock-free.
    ///
    /// Called from the audio thread at the start of each process cycle.
    /// The callback receives (param_id, value) for each pending update.
    pub fn drain<F: FnMut(u32, f64)>(&self, mut callback: F) {
        let wp = self.write_pos.load(Ordering::Acquire) as usize;
        let mut rp = self.read_pos.load(Ordering::Relaxed) as usize;

        // Limit drain to RING_CAPACITY to prevent infinite loop on overflow
        let available = if wp >= rp {
            wp - rp
        } else {
            (u32::MAX as usize + 1) - rp + wp
        };
        let count = available.min(RING_CAPACITY);

        for _ in 0..count {
            let idx = rp & RING_MASK;
            let entry = unsafe {
                let ptr = self.entries.as_ptr();
                *ptr.add(idx)
            };
            callback(entry.param_id, entry.value());
            rp += 1;
        }

        self.read_pos.store(rp as u32, Ordering::Release);
    }

    /// Number of pending entries.
    pub fn len(&self) -> usize {
        let wp = self.write_pos.load(Ordering::Relaxed) as usize;
        let rp = self.read_pos.load(Ordering::Relaxed) as usize;
        wp.wrapping_sub(rp)
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

// Safety: ParamRing is designed for cross-thread use (SPSC).
unsafe impl Send for ParamRing {}
unsafe impl Sync for ParamRing {}

// ---------------------------------------------------------------------------
// Audio Ring Buffer — for passing audio data lock-free
// ---------------------------------------------------------------------------

/// Lock-free ring buffer for stereo audio samples.
///
/// Used for:
/// - Input monitoring (hardware input → track)
/// - Bounce/export (track output → file writer)
///
/// Not used for the main mix path (that uses pre-allocated AudioBuffers).
pub struct AudioRing {
    /// Interleaved stereo samples.
    data: Box<[f32]>,
    capacity_frames: usize,
    write_pos: AtomicU64,
    read_pos: AtomicU64,
}

impl AudioRing {
    pub fn new(capacity_frames: usize) -> Self {
        let capacity = capacity_frames.next_power_of_two();
        Self {
            data: vec![0.0f32; capacity * 2].into_boxed_slice(),
            capacity_frames: capacity,
            write_pos: AtomicU64::new(0),
            read_pos: AtomicU64::new(0),
        }
    }

    /// Write interleaved stereo frames. Returns number of frames written.
    pub fn write(&self, samples: &[f32]) -> usize {
        let frames = samples.len() / 2;
        let mask = self.capacity_frames - 1;
        let mut wp = self.write_pos.load(Ordering::Relaxed) as usize;

        for i in 0..frames {
            let idx = (wp & mask) * 2;
            unsafe {
                let ptr = self.data.as_ptr() as *mut f32;
                *ptr.add(idx) = samples[i * 2];
                *ptr.add(idx + 1) = samples[i * 2 + 1];
            }
            wp += 1;
        }

        self.write_pos.store(wp as u64, Ordering::Release);
        frames
    }

    /// Read interleaved stereo frames into output. Returns number of frames read.
    pub fn read(&self, output: &mut [f32]) -> usize {
        let max_frames = output.len() / 2;
        let mask = self.capacity_frames - 1;
        let wp = self.write_pos.load(Ordering::Acquire) as usize;
        let mut rp = self.read_pos.load(Ordering::Relaxed) as usize;

        let available = wp.wrapping_sub(rp).min(self.capacity_frames);
        let frames = available.min(max_frames);

        for i in 0..frames {
            let idx = (rp & mask) * 2;
            output[i * 2] = self.data[idx];
            output[i * 2 + 1] = self.data[idx + 1];
            rp += 1;
        }

        self.read_pos.store(rp as u64, Ordering::Release);
        frames
    }

    pub fn available_frames(&self) -> usize {
        let wp = self.write_pos.load(Ordering::Relaxed) as usize;
        let rp = self.read_pos.load(Ordering::Relaxed) as usize;
        wp.wrapping_sub(rp).min(self.capacity_frames)
    }
}

unsafe impl Send for AudioRing {}
unsafe impl Sync for AudioRing {}

// ---------------------------------------------------------------------------
// Meter Ring — for passing metering data to GUI
// ---------------------------------------------------------------------------

/// Per-track meter snapshot.
#[derive(Clone, Copy, Default)]
pub struct MeterSnapshot {
    pub peak_l: f32,
    pub peak_r: f32,
    pub rms_l: f32,
    pub rms_r: f32,
}

/// Lock-free ring for meter data (audio → GUI, ~30Hz).
///
/// Uses a simple atomic triple-buffer: audio writes to slot A,
/// then swaps A↔B atomically. GUI reads from B (always consistent).
pub struct MeterRing {
    /// Meter data per track (indexed by track_index).
    /// Triple-buffered: [0]=write, [1]=ready, [2]=read
    buffers: [Box<[MeterSnapshot]>; 3],
    /// Which buffer is "ready" (written by audio, read by GUI).
    ready_index: AtomicU32,
    /// Track count.
    track_count: usize,
}

impl MeterRing {
    pub fn new(max_tracks: usize) -> Self {
        Self {
            buffers: [
                vec![MeterSnapshot::default(); max_tracks].into_boxed_slice(),
                vec![MeterSnapshot::default(); max_tracks].into_boxed_slice(),
                vec![MeterSnapshot::default(); max_tracks].into_boxed_slice(),
            ],
            ready_index: AtomicU32::new(1),
            track_count: max_tracks,
        }
    }

    /// Write meter data for a track (audio thread).
    pub fn write_track(&mut self, track_index: usize, snapshot: MeterSnapshot) {
        if track_index < self.track_count {
            // Always write to buffer 0
            self.buffers[0][track_index] = snapshot;
        }
    }

    /// Commit written data: swap write buffer to ready (audio thread).
    pub fn commit(&self) {
        // Swap buffer 0 (write) with buffer 1 (ready)
        self.ready_index.store(0, Ordering::Release);
    }

    /// Read all meter data (GUI thread). Returns a slice of MeterSnapshots.
    pub fn read_all(&self) -> &[MeterSnapshot] {
        let idx = self.ready_index.load(Ordering::Acquire) as usize;
        &self.buffers[idx.min(2)]
    }
}

unsafe impl Send for MeterRing {}
unsafe impl Sync for MeterRing {}

// ============================================================================
// v0.0.20.984: NS6.3 — Audio Buffer Memory Pool
// ============================================================================
//
// Pre-allocates audio buffers to avoid heap allocation in the audio callback.
// The audio thread borrows buffers from the pool instead of calling Vec::new().
// ============================================================================

/// Pre-allocated pool of audio buffers for zero-alloc audio processing.
///
/// Usage:
///   let pool = AudioBufferPool::new(16, 4096);  // 16 buffers × 4096 samples
///   let buf = pool.acquire();                    // borrow from pool
///   // ... use buf ...
///   pool.release(buf);                           // return to pool
pub struct AudioBufferPool {
    buffers: Vec<Vec<f32>>,
    /// Bitmask: bit N = buffer N is free
    free_mask: AtomicU64,
    buffer_size: usize,
}

impl AudioBufferPool {
    /// Create a new pool with `count` pre-allocated buffers of `size` samples each.
    pub fn new(count: usize, size: usize) -> Self {
        let count = count.min(64); // max 64 buffers (u64 bitmask)
        let mut buffers = Vec::with_capacity(count);
        for _ in 0..count {
            buffers.push(vec![0.0f32; size]);
        }
        // All buffers start as free
        let mask = if count >= 64 { u64::MAX } else { (1u64 << count) - 1 };
        Self {
            buffers,
            free_mask: AtomicU64::new(mask),
            buffer_size: size,
        }
    }

    /// Try to acquire a buffer from the pool. Returns None if all buffers are in use.
    ///
    /// Lock-free: uses atomic CAS on the bitmask.
    pub fn acquire(&self) -> Option<(usize, &mut [f32])> {
        loop {
            let mask = self.free_mask.load(Ordering::Acquire);
            if mask == 0 {
                return None; // no free buffers
            }
            let idx = mask.trailing_zeros() as usize;
            let new_mask = mask & !(1u64 << idx);
            if self.free_mask.compare_exchange_weak(
                mask, new_mask, Ordering::AcqRel, Ordering::Relaxed
            ).is_ok() {
                // Safety: we have exclusive access to this buffer via the bitmask
                let ptr = self.buffers[idx].as_ptr() as *mut f32;
                let slice = unsafe { std::slice::from_raw_parts_mut(ptr, self.buffer_size) };
                // Zero the buffer
                for s in slice.iter_mut() { *s = 0.0; }
                return Some((idx, slice));
            }
            // CAS failed, retry
        }
    }

    /// Release a buffer back to the pool.
    pub fn release(&self, idx: usize) {
        if idx < self.buffers.len() {
            self.free_mask.fetch_or(1u64 << idx, Ordering::Release);
        }
    }

    /// Number of free buffers.
    pub fn free_count(&self) -> usize {
        self.free_mask.load(Ordering::Relaxed).count_ones() as usize
    }

    /// Total number of buffers.
    pub fn total_count(&self) -> usize {
        self.buffers.len()
    }
}

unsafe impl Send for AudioBufferPool {}
unsafe impl Sync for AudioBufferPool {}

// ============================================================================
// v0.0.20.984: NS6.3 — Lock-Free Event Queue (audio → GUI)
// ============================================================================

/// Event types that flow from audio thread to GUI without locks.
#[derive(Clone, Debug)]
pub enum AudioEvent {
    /// Meter levels for a track
    MeterLevel { track_index: u16, peak_l: f32, peak_r: f32, rms_l: f32, rms_r: f32 },
    /// Transport position update
    TransportPosition { beat: f64, sample: u64 },
    /// XRun detected
    XRun { timestamp_us: u64 },
    /// Buffer underrun in ring
    Underrun { track_index: u16, missed_samples: u32 },
}

/// Lock-free SPSC queue for audio events (audio thread → GUI thread).
///
/// Fixed-size ring buffer. Audio thread pushes events, GUI thread drains them.
/// If the queue is full, oldest events are silently dropped (non-blocking).
pub struct EventQueue {
    /// Fixed-size buffer of events
    events: Box<[std::cell::UnsafeCell<Option<AudioEvent>>]>,
    capacity: usize,
    write_pos: AtomicU64,
    read_pos: AtomicU64,
}

impl EventQueue {
    pub fn new(capacity: usize) -> Self {
        let capacity = capacity.next_power_of_two();
        let mut events = Vec::with_capacity(capacity);
        for _ in 0..capacity {
            events.push(std::cell::UnsafeCell::new(None));
        }
        Self {
            events: events.into_boxed_slice(),
            capacity,
            write_pos: AtomicU64::new(0),
            read_pos: AtomicU64::new(0),
        }
    }

    /// Push an event (audio thread). Returns false if queue is full.
    pub fn push(&self, event: AudioEvent) -> bool {
        let w = self.write_pos.load(Ordering::Relaxed);
        let r = self.read_pos.load(Ordering::Acquire);
        if (w - r) as usize >= self.capacity {
            return false; // full
        }
        let idx = (w as usize) & (self.capacity - 1);
        // Safety: single-writer (audio thread only), UnsafeCell allows interior mutability
        unsafe { *self.events[idx].get() = Some(event); }
        self.write_pos.store(w + 1, Ordering::Release);
        true
    }

    /// Drain all available events (GUI thread).
    pub fn drain<F: FnMut(AudioEvent)>(&self, mut callback: F) {
        loop {
            let r = self.read_pos.load(Ordering::Relaxed);
            let w = self.write_pos.load(Ordering::Acquire);
            if r >= w {
                break; // empty
            }
            let idx = (r as usize) & (self.capacity - 1);
            // Safety: single-reader (GUI thread only), UnsafeCell allows interior mutability
            let event = unsafe { (*self.events[idx].get()).take() };
            self.read_pos.store(r + 1, Ordering::Release);
            if let Some(e) = event {
                callback(e);
            }
        }
    }

    /// Number of pending events.
    pub fn len(&self) -> usize {
        let w = self.write_pos.load(Ordering::Relaxed);
        let r = self.read_pos.load(Ordering::Relaxed);
        (w - r) as usize
    }
}

unsafe impl Send for EventQueue {}
unsafe impl Sync for EventQueue {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_atomic_f32() {
        let a = AtomicF32::new(3.14);
        assert!((a.load(Ordering::SeqCst) - 3.14).abs() < 0.001);
        a.store(2.71, Ordering::SeqCst);
        assert!((a.load(Ordering::SeqCst) - 2.71).abs() < 0.001);
    }

    #[test]
    fn test_param_ring() {
        let ring = ParamRing::new();
        ring.push(1, 0.5);
        ring.push(2, 0.8);
        let mut results = vec![];
        ring.drain(|id, val| results.push((id, val)));
        assert_eq!(results.len(), 2);
        assert_eq!(results[0].0, 1);
    }

    #[test]
    fn test_buffer_pool() {
        let pool = AudioBufferPool::new(4, 256);
        assert_eq!(pool.free_count(), 4);

        let (idx, buf) = pool.acquire().unwrap();
        assert_eq!(buf.len(), 256);
        assert_eq!(pool.free_count(), 3);

        pool.release(idx);
        assert_eq!(pool.free_count(), 4);
    }

    #[test]
    fn test_event_queue() {
        let q = EventQueue::new(8);
        assert!(q.push(AudioEvent::XRun { timestamp_us: 12345 }));
        assert_eq!(q.len(), 1);

        let mut events = vec![];
        q.drain(|e| events.push(e));
        assert_eq!(events.len(), 1);
        assert_eq!(q.len(), 0);
    }
}
