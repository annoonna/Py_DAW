//! audio_decode.rs — Universal Audio Decode via Symphonia (v0.0.20.984)
//!
//! NS2: Symphonia Audio-Decode
//!
//! Supports: MP3, OGG Vorbis, AAC (M4A), FLAC, WAV, AIFF
//! Features:
//!   - Automatic codec detection (Probe)
//!   - Streaming decode (not entire file in RAM)
//!   - Resampling to target sample rate
//!   - Mono/stereo/multi-channel support
//!
//! Usage:
//!   let result = decode_audio("/path/to/file.mp3", Some(48000))?;
//!   // result.samples: Vec<f32> (interleaved stereo)
//!   // result.sample_rate: u32
//!   // result.channels: u16
//!   // result.duration_secs: f64

use std::fs::File;
use std::path::Path;

use symphonia::core::audio::{AudioBufferRef, Signal};
use symphonia::core::codecs::DecoderOptions;
use symphonia::core::formats::FormatOptions;
use symphonia::core::io::MediaSourceStream;
use symphonia::core::meta::MetadataOptions;
use symphonia::core::probe::Hint;

use log::{info, warn, debug};

/// Decoded audio result.
#[derive(Debug, Clone)]
pub struct DecodedAudio {
    /// Interleaved samples (L, R, L, R, ...) normalized to -1.0..1.0
    pub samples: Vec<f32>,
    /// Original sample rate of the file
    pub sample_rate: u32,
    /// Number of channels (1=mono, 2=stereo)
    pub channels: u16,
    /// Duration in seconds
    pub duration_secs: f64,
    /// Total number of frames (samples per channel)
    pub num_frames: u64,
    /// Detected codec name
    pub codec: String,
}

/// Decode an audio file using Symphonia.
///
/// Supports: MP3, OGG, AAC/M4A, FLAC, WAV, AIFF
///
/// Args:
///   path: Path to the audio file
///   target_sr: Optional target sample rate for resampling (None = keep original)
///
/// Returns: DecodedAudio with interleaved f32 samples
pub fn decode_audio(path: &str, target_sr: Option<u32>) -> Result<DecodedAudio, String> {
    let path = Path::new(path);

    if !path.exists() {
        return Err(format!("File not found: {}", path.display()));
    }

    // Open the file
    let file = File::open(path)
        .map_err(|e| format!("Cannot open {}: {}", path.display(), e))?;

    let mss = MediaSourceStream::new(Box::new(file), Default::default());

    // Hint the format from file extension
    let mut hint = Hint::new();
    if let Some(ext) = path.extension().and_then(|e| e.to_str()) {
        hint.with_extension(ext);
    }

    // Probe the format
    let format_opts = FormatOptions::default();
    let metadata_opts = MetadataOptions::default();

    let probed = symphonia::default::get_probe()
        .format(&hint, mss, &format_opts, &metadata_opts)
        .map_err(|e| format!("Unsupported format {}: {}", path.display(), e))?;

    let mut format = probed.format;

    // Find the first audio track
    let track = format.tracks()
        .iter()
        .find(|t| t.codec_params.codec != symphonia::core::codecs::CODEC_TYPE_NULL)
        .ok_or_else(|| "No audio track found".to_string())?;

    let track_id = track.id;
    let codec_name = format!("{:?}", track.codec_params.codec);
    let sample_rate = track.codec_params.sample_rate
        .ok_or("Unknown sample rate")?;
    let channels = track.codec_params.channels
        .map(|c| c.count() as u16)
        .unwrap_or(2);

    info!(
        "[AudioDecode] {} — codec={}, sr={}, ch={}",
        path.display(), codec_name, sample_rate, channels
    );

    // Create decoder
    let decoder_opts = DecoderOptions::default();
    let mut decoder = symphonia::default::get_codecs()
        .make(&track.codec_params, &decoder_opts)
        .map_err(|e| format!("Unsupported codec: {}", e))?;

    // Decode all packets
    let mut all_samples: Vec<f32> = Vec::new();
    let mut total_frames: u64 = 0;

    loop {
        let packet = match format.next_packet() {
            Ok(p) => p,
            Err(symphonia::core::errors::Error::IoError(ref e))
                if e.kind() == std::io::ErrorKind::UnexpectedEof =>
            {
                break; // End of file
            }
            Err(e) => {
                debug!("[AudioDecode] Packet error (skipping): {}", e);
                break;
            }
        };

        // Skip packets from other tracks
        if packet.track_id() != track_id {
            continue;
        }

        match decoder.decode(&packet) {
            Ok(decoded) => {
                let frames = decoded.frames();
                total_frames += frames as u64;
                append_samples(&decoded, &mut all_samples, channels);
            }
            Err(symphonia::core::errors::Error::DecodeError(e)) => {
                warn!("[AudioDecode] Decode error (skipping frame): {}", e);
                continue;
            }
            Err(e) => {
                debug!("[AudioDecode] Fatal decode error: {}", e);
                break;
            }
        }
    }

    let duration_secs = if sample_rate > 0 {
        total_frames as f64 / sample_rate as f64
    } else {
        0.0
    };

    info!(
        "[AudioDecode] Decoded {} frames ({:.1}s), {} samples total",
        total_frames, duration_secs, all_samples.len()
    );

    let mut result = DecodedAudio {
        samples: all_samples,
        sample_rate,
        channels,
        duration_secs,
        num_frames: total_frames,
        codec: codec_name,
    };

    // Resample if needed
    if let Some(target) = target_sr {
        if target != sample_rate && target > 0 {
            result = resample_decoded(result, target);
        }
    }

    Ok(result)
}

/// Append decoded audio buffer samples to the output vector.
fn append_samples(buf: &AudioBufferRef, output: &mut Vec<f32>, channels: u16) {
    let ch = channels as usize;

    match buf {
        AudioBufferRef::F32(b) => {
            let frames = b.frames();
            output.reserve(frames * ch);
            for frame in 0..frames {
                for c in 0..ch.min(b.spec().channels.count()) {
                    output.push(b.chan(c)[frame]);
                }
                for _ in b.spec().channels.count()..ch {
                    output.push(0.0);
                }
            }
        }
        AudioBufferRef::S32(b) => {
            let frames = b.frames();
            let scale = 1.0 / i32::MAX as f32;
            output.reserve(frames * ch);
            for frame in 0..frames {
                for c in 0..ch.min(b.spec().channels.count()) {
                    output.push(b.chan(c)[frame] as f32 * scale);
                }
                for _ in b.spec().channels.count()..ch {
                    output.push(0.0);
                }
            }
        }
        _ => {
            debug!("[AudioDecode] Sample format not directly handled, skipping buffer");
        }
    }
}

/// Simple linear resampling for decoded audio.
fn resample_decoded(mut audio: DecodedAudio, target_sr: u32) -> DecodedAudio {
    let ratio = target_sr as f64 / audio.sample_rate as f64;
    let ch = audio.channels as usize;
    let old_frames = audio.num_frames as usize;
    let new_frames = (old_frames as f64 * ratio) as usize;
    let mut new_samples = vec![0.0f32; new_frames * ch];

    for frame in 0..new_frames {
        let src_pos = frame as f64 / ratio;
        let idx = src_pos as usize;
        let frac = (src_pos - idx as f64) as f32;

        for c in 0..ch {
            let s0_idx = idx * ch + c;
            let s1_idx = (idx + 1).min(old_frames - 1) * ch + c;

            if s0_idx < audio.samples.len() && s1_idx < audio.samples.len() {
                new_samples[frame * ch + c] =
                    audio.samples[s0_idx] + (audio.samples[s1_idx] - audio.samples[s0_idx]) * frac;
            }
        }
    }

    info!(
        "[AudioDecode] Resampled {}→{} Hz ({} → {} frames)",
        audio.sample_rate, target_sr, old_frames, new_frames
    );

    audio.samples = new_samples;
    audio.sample_rate = target_sr;
    audio.num_frames = new_frames as u64;
    audio.duration_secs = new_frames as f64 / target_sr as f64;
    audio
}

/// Get supported file extensions.
pub fn supported_extensions() -> &'static [&'static str] {
    &["wav", "flac", "mp3", "ogg", "aac", "m4a", "aiff", "aif"]
}

/// Check if a file extension is supported for decode.
pub fn is_supported(path: &str) -> bool {
    let path = Path::new(path);
    if let Some(ext) = path.extension().and_then(|e| e.to_str()) {
        supported_extensions().contains(&ext.to_lowercase().as_str())
    } else {
        false
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_supported_extensions() {
        assert!(is_supported("test.mp3"));
        assert!(is_supported("test.ogg"));
        assert!(is_supported("test.flac"));
        assert!(is_supported("test.wav"));
        assert!(is_supported("test.m4a"));
        assert!(is_supported("test.aiff"));
        assert!(!is_supported("test.txt"));
        assert!(!is_supported("test.zip"));
    }
}
