"""video_editor.py — Video-Editor (v0.0.20.930).

VE1: The FIRST DAW with an integrated NLE-style video editor in the
     clip editor panel — alongside Piano Roll, Audio Editor, Notation.

Features:
  - Visual timeline with real video frame thumbnails (filmstrip)
  - Beat grid overlay synced to DAW transport
  - Tools: Select, Knife (split), Trim (drag edges), Slip (shift content)
  - SMPTE timecode display (frame-accurate)
  - Scene markers from Video-KI analysis
  - Transport cursor (playhead) synced to DAW
  - Clip properties: opacity, speed, label
  - Keyboard shortcuts: S=split at playhead, Del=delete, Z=undo

What NO other DAW has:
  - Video editing INSIDE the same editor panel as MIDI/Audio
  - Beat-synced video cuts (snap to bar/beat grid)
  - AI scene markers integrated into the video timeline
  - Frame-accurate editing with SMPTE in a music DAW

Usage:
    editor = VideoEditor(project_service, transport=transport)
    editor.set_clip(clip_id)  # loads the video clip for editing
"""

from __future__ import annotations

import logging
import math
import os
import threading
from typing import Any, Dict, List, Optional, Tuple

from PyQt6.QtCore import (
    Qt, pyqtSignal, QTimer, QRectF, QPointF, QSizeF,
)
from PyQt6.QtGui import (
    QBrush, QColor, QFont, QImage, QPainter, QPen, QPixmap,
    QWheelEvent, QMouseEvent, QKeyEvent,
)
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QToolButton, QSplitter, QScrollBar, QComboBox, QDoubleSpinBox,
    QFrame, QSizePolicy, QToolBar,
)

log = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════

_HEADER_HEIGHT = 28       # ruler / time header
_TRACK_HEIGHT = 80        # clip lane height (shows frames)
_TRACK_MIN_HEIGHT = 48
_TRACK_MAX_HEIGHT = 200
_FRAME_THUMB_W = 120      # thumbnail width inside clips
_SCROLL_SPEED = 30
_DEFAULT_PX_PER_BEAT = 40

# Colors
_CLR_BG = QColor(18, 18, 28)
_CLR_HEADER = QColor(28, 28, 42)
_CLR_GRID_BAR = QColor(60, 60, 80)
_CLR_GRID_BEAT = QColor(40, 40, 55)
_CLR_PLAYHEAD = QColor(255, 80, 80)
_CLR_CLIP_BG = QColor(22, 50, 60)
_CLR_CLIP_BORDER = QColor(60, 140, 160)
_CLR_CLIP_SELECTED = QColor(100, 200, 220)
_CLR_SCENE_MARKER = QColor(255, 200, 60, 120)
_CLR_TRIM_HANDLE = QColor(255, 255, 100, 200)
_CLR_KNIFE = QColor(255, 100, 100)
_CLR_TEXT = QColor(200, 200, 216)
_CLR_SMPTE = QColor(79, 195, 247)

# Tool IDs
TOOL_SELECT = "select"
TOOL_KNIFE = "knife"
TOOL_TRIM = "trim"
TOOL_SLIP = "slip"


# ═══════════════════════════════════════════════════════════════
# Video Editor Canvas
# ═══════════════════════════════════════════════════════════════

class VideoEditorCanvas(QWidget):
    """Custom-painted video timeline canvas.

    Renders video clips as filmstrip thumbnails on a beat-synced timeline.
    All painting is done in paintEvent (no QGraphicsScene overhead).
    """

    status_message = pyqtSignal(str)
    clip_split = pyqtSignal(str, float)        # clip_id, beat_position
    clip_trimmed = pyqtSignal(str, float, str)  # clip_id, new_value, "start"|"end"
    clip_deleted = pyqtSignal(str)              # clip_id

    def __init__(self, project_service, transport=None, parent=None):
        super().__init__(parent)
        self._ps = project_service
        self._transport = transport
        self._bpm = 120.0

        # View state
        self._px_per_beat = _DEFAULT_PX_PER_BEAT
        self._scroll_x = 0.0   # beats
        self._track_height = _TRACK_HEIGHT

        # v0.0.20.934: Grid & Snap system
        self._snap_beats = 1.0     # snap resolution: 4=bar, 1=beat, 0.5=1/8, 0.25=1/16, 0=off
        self._grid_subdivisions = True  # show sub-beat grid lines

        # v0.0.20.934: Loop region (like Arranger/PianoRoll)
        self._loop_enabled = False
        self._loop_start = 0.0     # beats
        self._loop_end = 16.0      # beats
        self._loop_dragging: Optional[str] = None  # "start", "end", "body", None

        # Video clip state
        self._clip_id: Optional[str] = None
        self._clip = None
        self._video_path = ""
        self._video_duration = 0.0
        self._clip_start_beats = 0.0
        self._clip_length_beats = 0.0

        # v0.0.20.932: Multi-track + ghost clips
        self._all_tracks: List[Dict] = []
        self._ghost_enabled = True
        self._active_track_id = ""

        # v0.0.20.932: Clipboard for copy/paste
        self._clipboard: Optional[Dict] = None

        # Tool state
        self._tool = TOOL_SELECT
        self._mouse_pos = QPointF(0, 0)
        self._dragging = False
        self._drag_start = QPointF(0, 0)
        self._drag_start_beat = 0.0
        self._drag_edge: Optional[str] = None
        self._ctrl_drag_copy = False
        self._selected = True

        # Scene markers from Video-KI
        self._scene_markers: List[Dict] = []

        # Thumbnail cache
        self._thumb_svc = None

        # Playhead timer — only update when playing
        self._playhead_timer = QTimer(self)
        self._playhead_timer.setInterval(66)
        self._playhead_timer.timeout.connect(self._on_playhead_tick)
        self._playhead_timer.start()

        # v0.0.20.933: Paint throttle (max 15fps repaints)
        try:
            from pydaw.services.perf_service import PaintThrottle
            self._throttle = PaintThrottle(self, fps_limit=15)
        except Exception:
            self._throttle = None

        # Widget setup
        self.setMinimumHeight(140)
        self.setMinimumWidth(300)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_context_menu)

    def _request_paint(self) -> None:
        """Request a throttled repaint (v0.0.20.933)."""
        if self._throttle:
            self._throttle.request()
        else:
            self._request_paint()

    def _on_playhead_tick(self) -> None:
        """Playhead timer — only repaint if transport is playing."""
        try:
            if self._transport and getattr(self._transport, 'playing', False):
                self._request_paint()
        except Exception:
            pass

    # ─────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────

    def set_clip(self, clip_id: Optional[str]) -> None:
        """Load a video clip for editing.

        v0.0.20.932: Multi-track view — shows all video tracks stacked.
        Active track has full-color clips, other tracks show ghost clips.
        """
        self._clip_id = clip_id
        self._clip = None
        self._video_path = ""
        self._video_duration = 0.0
        self._scene_markers = []
        self._all_clips: List = []
        self._all_tracks = []
        self._active_track_id = ""

        if not clip_id:
            self._request_paint()
            return

        try:
            proj = self._get_project()
            if not proj:
                return
            for c in proj.clips or []:
                if str(getattr(c, 'id', '')) == str(clip_id):
                    self._clip = c
                    break
            if not self._clip or str(getattr(self._clip, 'kind', '')) != 'video':
                self._clip = None
                self._request_paint()
                return

            self._video_path = str(getattr(self._clip, 'source_path', '') or '')
            self._clip_start_beats = float(getattr(self._clip, 'start_beats', 0))
            self._clip_length_beats = float(getattr(self._clip, 'length_beats', 0))
            self._bpm = self._get_bpm()
            self._video_duration = self._clip_length_beats * 60.0 / max(1, self._bpm)
            self._active_track_id = str(getattr(self._clip, 'track_id', ''))

            # Collect ALL video clips grouped by track
            track_clips: Dict[str, List] = {}
            track_names: Dict[str, str] = {}
            for c in (proj.clips or []):
                if str(getattr(c, 'kind', '')) == 'video':
                    tid = str(getattr(c, 'track_id', ''))
                    if tid not in track_clips:
                        track_clips[tid] = []
                    track_clips[tid].append(c)
            # Get track names
            for t in (proj.tracks or []):
                tid = str(getattr(t, 'id', ''))
                if tid in track_clips:
                    track_names[tid] = str(getattr(t, 'name', f'Track {tid[:6]}'))

            # Build track list (active track first)
            for tid in sorted(track_clips.keys(),
                              key=lambda t: 0 if t == self._active_track_id else 1):
                clips = sorted(track_clips[tid],
                               key=lambda c: float(getattr(c, 'start_beats', 0)))
                self._all_tracks.append({
                    "track_id": tid,
                    "name": track_names.get(tid, f"Track {tid[:6]}"),
                    "clips": clips,
                    "is_active": tid == self._active_track_id,
                })

            # Also set _all_clips for backward compat
            self._all_clips = track_clips.get(self._active_track_id, [])
            self._all_clips.sort(key=lambda c: float(getattr(c, 'start_beats', 0)))

            # Center view on clip
            self._scroll_x = max(0, self._clip_start_beats - 2)
            self._ensure_thumb_service()

        except Exception as e:
            log.debug("[VideoEditor] set_clip: %s", e)

        self._request_paint()

    def set_tool(self, tool: str) -> None:
        """Set the active editing tool."""
        self._tool = tool
        self.setCursor(
            Qt.CursorShape.CrossCursor if tool == TOOL_KNIFE
            else Qt.CursorShape.SizeHorCursor if tool == TOOL_TRIM
            else Qt.CursorShape.ArrowCursor
        )
        self._request_paint()

    def set_scene_markers(self, markers: List[Dict]) -> None:
        """Set scene markers from Video-KI analysis."""
        self._scene_markers = list(markers) if markers else []
        self._request_paint()

    def delete_selected_clip(self) -> None:
        """Delete the currently selected clip."""
        if not self._clip:
            return
        self.clip_deleted.emit(str(self._clip_id))
        try:
            self.status_message.emit(f"🗑 Clip gelöscht")
        except Exception:
            pass

    def select_clip_at(self, beat: float) -> Optional[str]:
        """Select the clip at the given beat position. Returns clip_id or None."""
        for clip in getattr(self, '_all_clips', []):
            cs = float(getattr(clip, 'start_beats', 0))
            ce = cs + float(getattr(clip, 'length_beats', 0))
            if cs <= beat <= ce:
                cid = str(getattr(clip, 'id', ''))
                if cid != self._clip_id:
                    self._clip_id = cid
                    self._clip = clip
                    self._video_path = str(getattr(clip, 'source_path', '') or '')
                    self._clip_start_beats = cs
                    self._clip_length_beats = float(getattr(clip, 'length_beats', 0))
                    self._request_paint()
                return cid
        return None

    # v0.0.20.932: Context Menu + Clipboard + Join
    # ─────────────────────────────────────────────────────

    def _show_context_menu(self, pos) -> None:
        """Right-click context menu with all editing operations."""
        from PyQt6.QtWidgets import QMenu
        from PyQt6.QtGui import QAction
        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu { background: #2a2a3a; color: #ddd; border: 1px solid #555; }"
            "QMenu::item:selected { background: #3a5a7a; }"
            "QMenu::separator { background: #444; height: 1px; }"
        )

        beat = self._x_to_beats(pos.x())

        # ── Clip Properties (top!) ──
        a_props = menu.addAction("🎛 Clip-Eigenschaften...")
        a_props.setEnabled(self._clip is not None)
        menu.addSeparator()

        # ── Tools ──
        tools_menu = menu.addMenu("🔧 Werkzeuge")
        a_select = tools_menu.addAction("👆 Auswahl (1)")
        a_knife = tools_menu.addAction("✂ Messer (2)")
        a_trim = tools_menu.addAction("↔ Trimmen (3)")
        a_slip = tools_menu.addAction("⇄ Slip (4)")

        # ── Quick Filters ──
        filter_menu = menu.addMenu("🎨 Filter")
        a_f_warm = filter_menu.addAction("🌅 Warm (Orange-Töne)")
        a_f_cold = filter_menu.addAction("❄ Kalt (Blau-Töne)")
        a_f_bw = filter_menu.addAction("⬛ Schwarzweiß")
        a_f_vintage = filter_menu.addAction("📷 Vintage (Sepia)")
        a_f_cinema = filter_menu.addAction("🎬 Cinematic (Teal & Orange)")
        a_f_dreamy = filter_menu.addAction("💫 Dreamy (Weich + Hell)")
        a_f_dark = filter_menu.addAction("🌑 Dark & Moody")
        a_f_vivid = filter_menu.addAction("🌈 Vivid (Sättigung+)")
        filter_menu.addSeparator()
        a_f_reset = filter_menu.addAction("🔄 Filter zurücksetzen")
        for a in [a_f_warm, a_f_cold, a_f_bw, a_f_vintage, a_f_cinema,
                  a_f_dreamy, a_f_dark, a_f_vivid, a_f_reset]:
            a.setEnabled(self._clip is not None)

        # ── AI Tools ──
        ai_menu = menu.addMenu("🤖 KI-Werkzeuge")
        a_ai_beat = ai_menu.addAction("🎵 Beat-Sync Cuts — Auto-Schnitt auf Takte")
        a_ai_mood = ai_menu.addAction("🎨 Mood Color — Farbe nach Musik-Stimmung")
        a_ai_motion = ai_menu.addAction("🏃 Motion Match — Speed folgt Energie")
        a_ai_fade = ai_menu.addAction("🌅 Auto-Fade — Ein/Ausblenden")
        a_ai_scene = ai_menu.addAction("🎬 Szenen-Farbe — Pro Szene eigene Stimmung")
        a_ai_freeze = ai_menu.addAction("❄ Freeze @ Peak — Standbild bei Höhepunkt")
        for a in [a_ai_beat, a_ai_mood, a_ai_motion, a_ai_fade, a_ai_scene, a_ai_freeze]:
            a.setEnabled(self._clip is not None)

        menu.addSeparator()

        # ── Clip Operations ──
        a_split = menu.addAction("✂ Split am Playhead (S)")
        a_split.setEnabled(self._clip is not None)
        a_copy = menu.addAction("📋 Kopieren (Ctrl+C)")
        a_copy.setEnabled(self._clip is not None)
        a_paste = menu.addAction("📋 Einfügen (Ctrl+V)")
        a_paste.setEnabled(self._clipboard is not None)
        a_dup = menu.addAction("📄 Duplizieren (Ctrl+D)")
        a_dup.setEnabled(self._clip is not None)
        menu.addSeparator()

        a_join = menu.addAction("🔗 Clips verbinden (Ctrl+J)")
        a_join.setEnabled(len(getattr(self, '_all_clips', [])) > 1)
        a_delete = menu.addAction("🗑 Löschen (Del)")
        a_delete.setEnabled(self._clip is not None)
        menu.addSeparator()

        # ── View ──
        a_fit = menu.addAction("🔍 Alles einpassen (F)")
        a_ghost = menu.addAction("👻 Ghost-Clips " + ("✅" if self._ghost_enabled else "❌"))
        a_loop = menu.addAction("🔁 Loop " + ("✅" if self._loop_enabled else "❌"))

        act = menu.exec(self.mapToGlobal(pos))
        if act is None:
            return

        # ── Handle actions ──
        if act == a_props:
            self._open_properties_dialog()
        elif act == a_select:
            self.set_tool(TOOL_SELECT)
        elif act == a_knife:
            self.set_tool(TOOL_KNIFE)
        elif act == a_trim:
            self.set_tool(TOOL_TRIM)
        elif act == a_slip:
            self.set_tool(TOOL_SLIP)
        elif act == a_split:
            self.split_at_playhead()
        elif act == a_copy:
            self.copy_clip()
        elif act == a_paste:
            self.paste_clip(beat)
        elif act == a_dup:
            self.duplicate_clip()
        elif act == a_join:
            self.join_clips()
        elif act == a_delete:
            self.delete_selected_clip()
        elif act == a_fit:
            self._fit_view()
        elif act == a_ghost:
            self._ghost_enabled = not self._ghost_enabled
            self._request_paint()
        elif act == a_loop:
            self._loop_enabled = not self._loop_enabled
            if self._loop_enabled and self._clip:
                self._loop_start = self._clip_start_beats
                self._loop_end = self._clip_start_beats + self._clip_length_beats
            self._request_paint()
        # Quick Filters
        elif act == a_f_warm:
            self._apply_filter_preset("warm")
        elif act == a_f_cold:
            self._apply_filter_preset("cold")
        elif act == a_f_bw:
            self._apply_filter_preset("bw")
        elif act == a_f_vintage:
            self._apply_filter_preset("vintage")
        elif act == a_f_cinema:
            self._apply_filter_preset("cinema")
        elif act == a_f_dreamy:
            self._apply_filter_preset("dreamy")
        elif act == a_f_dark:
            self._apply_filter_preset("dark")
        elif act == a_f_vivid:
            self._apply_filter_preset("vivid")
        elif act == a_f_reset:
            self._apply_filter_preset("reset")
        # AI Tools
        elif act == a_ai_beat:
            self._open_properties_dialog_at("ai_beat_sync")
        elif act == a_ai_mood:
            self._open_properties_dialog_at("ai_mood_color")
        elif act == a_ai_motion:
            self._open_properties_dialog_at("ai_motion_match")
        elif act == a_ai_fade:
            self._open_properties_dialog_at("ai_auto_fade")
        elif act == a_ai_scene:
            self._open_properties_dialog_at("ai_scene_color")
        elif act == a_ai_freeze:
            self._open_properties_dialog_at("ai_freeze_peak")

    def _open_properties_dialog(self) -> None:
        """Open the Clip Properties dialog."""
        if not self._clip:
            return
        try:
            from pydaw.ui.video_clip_properties import ClipPropertiesDialog
            label = str(getattr(self._clip, 'label', '') or '')
            dlg = ClipPropertiesDialog(
                self._clip_id, label,
                services=getattr(self, '_ps', None),
                parent=self,
            )
            dlg.properties_changed.connect(lambda cid: self._request_paint())
            dlg.show()
        except Exception as e:
            log.error("[VideoEditor] properties dialog: %s", e)

    def _open_properties_dialog_at(self, ai_tool_id: str) -> None:
        """Open properties dialog and auto-trigger an AI tool."""
        if not self._clip:
            return
        try:
            from pydaw.ui.video_clip_properties import ClipPropertiesDialog
            label = str(getattr(self._clip, 'label', '') or '')
            dlg = ClipPropertiesDialog(
                self._clip_id, label,
                services=getattr(self, '_ps', None),
                parent=self,
            )
            dlg.properties_changed.connect(lambda cid: self._request_paint())
            dlg.show()
            # Auto-trigger the AI tool
            dlg._run_ai_tool(ai_tool_id)
        except Exception as e:
            log.error("[VideoEditor] AI tool dialog: %s", e)

    def _apply_filter_preset(self, preset: str) -> None:
        """Apply a quick filter preset to the selected clip."""
        if not self._clip:
            return
        try:
            from pydaw.services.video_filter_service import VideoFilterService, VideoFilter
            svc = VideoFilterService.instance()

            presets = {
                "warm": [("brightness", 0.05), ("saturation", 1.3), ("contrast", 1.1)],
                "cold": [("brightness", -0.05), ("saturation", 0.8), ("contrast", 1.1)],
                "bw": [("saturation", 0.0)],
                "vintage": [("saturation", 0.6), ("contrast", 1.2), ("brightness", 0.1),
                            ("vignette", 0.4)],
                "cinema": [("contrast", 1.3), ("saturation", 0.9), ("vignette", 0.2)],
                "dreamy": [("blur", 2.0), ("brightness", 0.1), ("saturation", 1.2)],
                "dark": [("brightness", -0.2), ("contrast", 1.4), ("saturation", 0.7),
                          ("vignette", 0.5)],
                "vivid": [("saturation", 1.8), ("contrast", 1.2), ("sharpen", 1.0)],
                "reset": [],
            }

            filters = presets.get(preset, [])

            svc.clear_filters(self._clip_id)
            for kind, value in filters:
                svc.set_filter(self._clip_id, VideoFilter(kind=kind, value=value))

            name = {
                "warm": "🌅 Warm", "cold": "❄ Kalt", "bw": "⬛ Schwarzweiß",
                "vintage": "📷 Vintage", "cinema": "🎬 Cinematic",
                "dreamy": "💫 Dreamy", "dark": "🌑 Dark", "vivid": "🌈 Vivid",
                "reset": "🔄 Reset",
            }.get(preset, preset)

            try:
                self.status_message.emit(f"🎨 Filter: {name}")
            except Exception:
                pass
            self._request_paint()
        except Exception as e:
            log.debug("[VideoEditor] filter preset: %s", e)

    def copy_clip(self) -> None:
        """Copy selected clip to clipboard (Ctrl+C)."""
        if not self._clip:
            return
        self._clipboard = {
            "source_path": str(getattr(self._clip, 'source_path', '') or ''),
            "length_beats": float(getattr(self._clip, 'length_beats', 0)),
            "offset_seconds": float(getattr(self._clip, 'offset_seconds', 0) or 0),
            "label": str(getattr(self._clip, 'label', '') or ''),
        }
        try:
            self.status_message.emit("📋 Clip kopiert")
        except Exception:
            pass

    def paste_clip(self, at_beat: float = -1) -> None:
        """Paste clipboard clip at playhead or given beat (Ctrl+V)."""
        if not self._clipboard:
            return
        if at_beat < 0:
            at_beat = self._get_playhead_beat()

        try:
            from pydaw.model.project import Clip
            proj = self._get_project()
            if not proj:
                return

            new_clip = Clip(
                kind="video",
                track_id=self._active_track_id,
                label=self._clipboard["label"] + " (Kopie)",
                source_path=self._clipboard["source_path"],
                start_beats=self._snap_beat(at_beat),
                length_beats=self._clipboard["length_beats"],
                offset_seconds=self._clipboard["offset_seconds"],
            )
            proj.clips.append(new_clip)

            if hasattr(self._ps, '_emit_updated'):
                self._ps._emit_updated()

            self.set_clip(str(new_clip.id))
            try:
                self.status_message.emit(f"📋 Clip eingefügt bei Beat {at_beat:.1f}")
            except Exception:
                pass
        except Exception as e:
            log.debug("[VideoEditor] paste: %s", e)

    def duplicate_clip(self) -> None:
        """Duplicate selected clip right after it (Ctrl+D)."""
        if not self._clip:
            return
        self.copy_clip()
        end_beat = self._clip_start_beats + self._clip_length_beats
        self.paste_clip(end_beat)

    def join_clips(self) -> None:
        """Join/consolidate all clips on active track (Ctrl+J).

        Creates one clip spanning from first clip start to last clip end.
        """
        clips = getattr(self, '_all_clips', [])
        if len(clips) < 2:
            return
        try:
            proj = self._get_project()
            if not proj:
                return

            min_start = min(float(getattr(c, 'start_beats', 0)) for c in clips)
            max_end = max(
                float(getattr(c, 'start_beats', 0)) + float(getattr(c, 'length_beats', 0))
                for c in clips
            )
            first = clips[0]
            source_path = str(getattr(first, 'source_path', '') or '')
            first_offset = float(getattr(first, 'offset_seconds', 0) or 0)

            # Remove all but first clip
            keep_ids = {str(getattr(first, 'id', ''))}
            proj.clips = [c for c in proj.clips
                          if str(getattr(c, 'id', '')) in keep_ids
                          or str(getattr(c, 'kind', '')) != 'video'
                          or str(getattr(c, 'track_id', '')) != self._active_track_id]

            # Extend first clip to cover all
            first.start_beats = min_start
            first.length_beats = max_end - min_start
            first.offset_seconds = first_offset
            first.label = str(getattr(first, 'label', '')).replace(" (B)", "")

            if hasattr(self._ps, '_emit_updated'):
                self._ps._emit_updated()

            self.set_clip(str(getattr(first, 'id', '')))
            try:
                self.status_message.emit(f"🔗 {len(clips)} Clips verbunden")
            except Exception:
                pass
        except Exception as e:
            log.debug("[VideoEditor] join: %s", e)

    def _fit_view(self) -> None:
        """Fit all clips in view."""
        clips = getattr(self, '_all_clips', [])
        if not clips:
            return
        min_beat = min(float(getattr(c, 'start_beats', 0)) for c in clips)
        max_beat = max(
            float(getattr(c, 'start_beats', 0)) + float(getattr(c, 'length_beats', 0))
            for c in clips
        )
        span = max(4, max_beat - min_beat + 4)
        self._px_per_beat = max(10, min(200, self.width() / span))
        self._scroll_x = max(0, min_beat - 2)
        self._request_paint()
        """Split the clip at the current playhead position."""
        if not self._clip:
            return
        beat = self._get_playhead_beat()
        cs = self._clip_start_beats
        ce = cs + self._clip_length_beats
        if cs < beat < ce:
            self.clip_split.emit(str(self._clip_id), beat)
            try:
                self.status_message.emit(f"✂ Video gesplittet bei Beat {beat:.1f}")
            except Exception:
                pass

    # ─────────────────────────────────────────────────────
    # Internal helpers
    # ─────────────────────────────────────────────────────

    def _get_project(self):
        try:
            proj = getattr(self._ps, 'project', None)
            if proj is None:
                ctx = getattr(self._ps, 'ctx', None)
                proj = getattr(ctx, 'project', None) if ctx else None
            return proj
        except Exception:
            return None

    def _get_bpm(self) -> float:
        try:
            if self._transport:
                return float(getattr(self._transport, 'bpm', 120.0) or 120.0)
            proj = self._get_project()
            if proj:
                return float(getattr(proj, 'bpm', 120.0) or 120.0)
        except Exception:
            pass
        return 120.0

    def _get_playhead_beat(self) -> float:
        try:
            if self._transport:
                return float(getattr(self._transport, 'current_beat', 0.0))
        except Exception:
            pass
        return 0.0

    def _beats_to_x(self, beat: float) -> float:
        return (beat - self._scroll_x) * self._px_per_beat

    def _x_to_beats(self, x: float) -> float:
        return x / self._px_per_beat + self._scroll_x

    def _snap_beat(self, beat: float, grid: float = -1) -> float:
        """Snap beat to grid. Uses self._snap_beats if grid=-1."""
        g = grid if grid >= 0 else self._snap_beats
        if g <= 0:
            return max(0, beat)  # free (no snap)
        return max(0, round(beat / g) * g)

    def _ensure_thumb_service(self) -> None:
        if self._thumb_svc is None:
            try:
                from pydaw.services.video_thumbnail_service import VideoThumbnailService
                self._thumb_svc = VideoThumbnailService.instance()
                self._thumb_svc.register_on_ready(self.update)
            except Exception:
                pass

    def _beat_to_video_seconds(self, beat: float) -> float:
        """Convert a beat position to seconds within the video file."""
        offset_s = float(getattr(self._clip, 'offset_seconds', 0) or 0) if self._clip else 0
        clip_start = self._clip_start_beats
        return (beat - clip_start) * 60.0 / max(1, self._bpm) + offset_s

    # ─────────────────────────────────────────────────────
    # Paint
    # ─────────────────────────────────────────────────────

    def paintEvent(self, event) -> None:
        w = self.width()
        h = self.height()
        if w < 10 or h < 10:
            return

        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)

        # Background
        p.fillRect(0, 0, w, h, _CLR_BG)

        bpm = self._get_bpm()
        self._bpm = bpm

        # Draw components
        self._draw_grid(p, w, h)
        self._draw_loop(p, w, h)             # v0.0.20.934: loop region
        self._draw_scene_markers(p, w, h)
        self._draw_ghost_tracks(p, w, h)
        self._draw_clip(p, w, h)
        self._draw_header(p, w)
        self._draw_playhead(p, w, h)
        self._draw_tool_overlay(p, w, h)
        self._draw_info_bar(p, w, h)

        p.end()

    def _draw_ghost_tracks(self, p: QPainter, w: int, h: int) -> None:
        """v0.0.20.932: Draw ghost clips from other video tracks (semi-transparent)."""
        if not self._ghost_enabled:
            return
        tracks = getattr(self, '_all_tracks', [])
        if len(tracks) <= 1:
            return

        # Ghost tracks below the active track area
        ghost_y_start = _HEADER_HEIGHT + self._track_height + 20
        ghost_h = 50  # smaller than active track

        track_idx = 0
        for track_info in tracks:
            if track_info.get("is_active"):
                continue
            y = ghost_y_start + track_idx * (ghost_h + 8)
            if y + ghost_h > h - 20:
                break

            # Track label
            p.setPen(QColor(120, 120, 150))
            p.setFont(QFont("Sans-Serif", 8))
            p.drawText(4, y - 2, f"👻 {track_info['name']}")

            # Ghost separator line
            p.setPen(QPen(QColor(50, 50, 70), 1, Qt.PenStyle.DashLine))
            p.drawLine(0, y - 4, w, y - 4)

            for clip in track_info.get("clips", []):
                cs = float(getattr(clip, 'start_beats', 0))
                cl = float(getattr(clip, 'length_beats', 0))
                x1 = self._beats_to_x(cs)
                x2 = self._beats_to_x(cs + cl)
                if x2 < 0 or x1 > w:
                    continue
                clip_x = max(0, x1)
                clip_w = min(w, x2) - clip_x
                if clip_w < 2:
                    continue

                rect = QRectF(clip_x, y, clip_w, ghost_h)

                # Semi-transparent background
                p.setOpacity(0.35)
                p.fillRect(rect, QBrush(QColor(40, 60, 80)))

                # Try to draw thumbnails
                video_path = str(getattr(clip, 'source_path', '') or '')
                if video_path and os.path.isfile(video_path):
                    self._draw_filmstrip_for_clip(p, rect, clip, video_path)

                # Border
                p.setOpacity(0.5)
                p.setPen(QPen(QColor(80, 120, 140), 1))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(rect)

                # Label
                p.setPen(QColor(150, 150, 170))
                p.setFont(QFont("Sans-Serif", 7))
                label = str(getattr(clip, 'label', '') or '')
                p.drawText(int(clip_x) + 4, int(y) + 12, label[:30])

                p.setOpacity(1.0)

            track_idx += 1

    def _draw_header(self, p: QPainter, w: int) -> None:
        """Draw time ruler at top."""
        p.fillRect(0, 0, w, _HEADER_HEIGHT, _CLR_HEADER)

        font = QFont("Monospace", 8)
        p.setFont(font)

        # Draw bar numbers
        start_beat = max(0, self._scroll_x)
        end_beat = self._x_to_beats(w)

        bar_start = int(start_beat / 4)
        bar_end = int(end_beat / 4) + 2

        for bar in range(bar_start, bar_end):
            beat = bar * 4.0
            x = self._beats_to_x(beat)
            if x < -20 or x > w + 20:
                continue

            # Bar line
            p.setPen(QPen(_CLR_GRID_BAR, 1))
            p.drawLine(int(x), 0, int(x), _HEADER_HEIGHT)

            # Bar number
            p.setPen(_CLR_TEXT)
            p.drawText(int(x) + 3, _HEADER_HEIGHT - 6, f"Bar {bar + 1}")

            # SMPTE time
            secs = beat * 60.0 / max(1, self._bpm)
            m = int(secs) // 60
            s = int(secs) % 60
            f = int((secs - int(secs)) * 24)
            p.setPen(_CLR_SMPTE)
            p.drawText(int(x) + 3, 11, f"{m:02d}:{s:02d}:{f:02d}")

        # Bottom line
        p.setPen(QPen(QColor(60, 60, 80), 1))
        p.drawLine(0, _HEADER_HEIGHT - 1, w, _HEADER_HEIGHT - 1)

    def _draw_grid(self, p: QPainter, w: int, h: int) -> None:
        """Draw beat/bar grid with subdivisions matching snap resolution."""
        start_beat = max(0, self._scroll_x)
        end_beat = self._x_to_beats(w)

        # Bar lines (every 4 beats)
        bar_start = int(start_beat / 4)
        bar_end = int(end_beat / 4) + 2
        for bar in range(bar_start, bar_end):
            beat = bar * 4.0
            x = int(self._beats_to_x(beat))
            if 0 <= x <= w:
                p.setPen(QPen(_CLR_GRID_BAR, 1))
                p.drawLine(x, _HEADER_HEIGHT, x, h)

        # Beat lines
        beat_start = int(start_beat)
        beat_end = int(end_beat) + 2
        for beat in range(beat_start, beat_end):
            if beat % 4 == 0:
                continue  # already drawn as bar line
            x = int(self._beats_to_x(beat))
            if 0 <= x <= w:
                p.setPen(QPen(_CLR_GRID_BEAT, 1))
                p.drawLine(x, _HEADER_HEIGHT, x, h)

        # Sub-beat grid lines (based on snap resolution)
        if self._grid_subdivisions and self._snap_beats > 0 and self._snap_beats < 1.0:
            sub_step = self._snap_beats
            sub_beat = max(0, int(start_beat / sub_step) * sub_step)
            p.setPen(QPen(QColor(35, 35, 50), 1, Qt.PenStyle.DotLine))
            while sub_beat <= end_beat:
                # Skip if it falls on a beat or bar line
                if abs(sub_beat - round(sub_beat)) > 0.01:
                    x = int(self._beats_to_x(sub_beat))
                    if 0 <= x <= w:
                        p.drawLine(x, _HEADER_HEIGHT, x, h)
                sub_beat += sub_step

    def _draw_loop(self, p: QPainter, w: int, h: int) -> None:
        """Draw loop region (semi-transparent overlay like Arranger)."""
        if not self._loop_enabled:
            return

        x1 = int(self._beats_to_x(self._loop_start))
        x2 = int(self._beats_to_x(self._loop_end))

        if x2 < 0 or x1 > w:
            return

        # Loop region fill
        loop_color = QColor(80, 200, 120, 30)
        p.fillRect(x1, 0, x2 - x1, h, QBrush(loop_color))

        # Loop boundaries
        p.setPen(QPen(QColor(80, 200, 120, 200), 2))
        if 0 <= x1 <= w:
            p.drawLine(x1, 0, x1, h)
        if 0 <= x2 <= w:
            p.drawLine(x2, 0, x2, h)

        # Loop markers in header
        p.setFont(QFont("Monospace", 7))
        p.setPen(QColor(80, 200, 120))
        if 0 <= x1 <= w:
            p.drawText(x1 + 2, _HEADER_HEIGHT - 3, "L")
        if 0 <= x2 <= w:
            p.drawText(x2 - 10, _HEADER_HEIGHT - 3, "R")

        # Loop handles (top of region)
        handle_w = 8
        handle_h = 10
        p.setBrush(QBrush(QColor(80, 200, 120, 180)))
        p.setPen(Qt.PenStyle.NoPen)
        if 0 <= x1 <= w:
            from PyQt6.QtGui import QPolygonF
            p.drawPolygon(QPolygonF([
                QPointF(x1, 0), QPointF(x1 + handle_w, 0), QPointF(x1, handle_h),
            ]))
        if 0 <= x2 <= w:
            from PyQt6.QtGui import QPolygonF
            p.drawPolygon(QPolygonF([
                QPointF(x2, 0), QPointF(x2 - handle_w, 0), QPointF(x2, handle_h),
            ]))

    def _draw_scene_markers(self, p: QPainter, w: int, h: int) -> None:
        """Draw Video-KI scene markers as colored vertical bands."""
        if not self._scene_markers:
            return

        for marker in self._scene_markers:
            beat = float(marker.get("beat", 0))
            x = int(self._beats_to_x(beat))
            if x < -10 or x > w + 10:
                continue

            color_str = marker.get("color", "#ffcc44")
            try:
                clr = QColor(color_str)
                clr.setAlpha(60)
            except Exception:
                clr = _CLR_SCENE_MARKER

            # Vertical line
            p.setPen(QPen(QColor(color_str), 2))
            p.drawLine(x, _HEADER_HEIGHT, x, h)

            # Label
            label = marker.get("label", "")
            if label:
                p.setPen(QColor(color_str))
                p.setFont(QFont("Monospace", 7))
                p.drawText(x + 3, _HEADER_HEIGHT + 12, label[:30])

    def _draw_clip(self, p: QPainter, w: int, h: int) -> None:
        """Draw ALL video clips on this track as filmstrips.

        v0.0.20.931: Multi-clip view — shows all clips after split.
        Selected clip gets highlight border.
        """
        clips = getattr(self, '_all_clips', [])
        if not clips and not self._clip:
            # No clip loaded — show hint
            p.setPen(_CLR_TEXT)
            p.setFont(QFont("Sans-Serif", 11))
            p.drawText(
                QRectF(0, _HEADER_HEIGHT, w, h - _HEADER_HEIGHT),
                Qt.AlignmentFlag.AlignCenter,
                "🎬 Kein Video-Clip ausgewählt\n\n"
                "Doppelklicke auf einen Video-Clip im Arranger\n"
                "oder ziehe ein Video auf die Timeline"
            )
            return

        if not clips:
            clips = [self._clip] if self._clip else []

        y = _HEADER_HEIGHT + 4
        ch = self._track_height

        for clip in clips:
            cs = float(getattr(clip, 'start_beats', 0))
            cl = float(getattr(clip, 'length_beats', 0))
            ce = cs + cl
            is_selected = (str(getattr(clip, 'id', '')) == str(self._clip_id))

            x1 = self._beats_to_x(cs)
            x2 = self._beats_to_x(ce)

            if x2 < 0 or x1 > w:
                continue

            clip_x = max(0, x1)
            clip_w = min(w, x2) - clip_x
            if clip_w < 2:
                continue

            clip_rect = QRectF(clip_x, y, clip_w, ch)

            # Clip background
            bg = QColor(22, 50, 60) if is_selected else QColor(18, 38, 48)
            p.fillRect(clip_rect, QBrush(bg))

            # Draw real frame thumbnails
            video_path = str(getattr(clip, 'source_path', '') or '')
            self._draw_filmstrip_for_clip(p, clip_rect, clip, video_path)

            # Clip border
            if is_selected:
                p.setPen(QPen(_CLR_CLIP_SELECTED, 2))
            else:
                p.setPen(QPen(_CLR_CLIP_BORDER, 1))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(clip_rect)

            # Trim handles (when selected)
            if is_selected:
                handle_w = 6
                p.fillRect(QRectF(clip_x, y, handle_w, ch), QBrush(_CLR_TRIM_HANDLE))
                p.fillRect(QRectF(clip_x + clip_w - handle_w, y, handle_w, ch),
                            QBrush(_CLR_TRIM_HANDLE))

            # Clip label
            p.setPen(QColor(220, 220, 230) if is_selected else QColor(170, 170, 180))
            p.setFont(QFont("Sans-Serif", 9, QFont.Weight.Bold))
            label = str(getattr(clip, 'label', '') or os.path.basename(video_path))
            p.drawText(int(clip_x) + 8, int(y) + 14, f"🎬 {label[:40]}")

            # Duration info
            dur_s = cl * 60.0 / max(1, self._bpm)
            p.setFont(QFont("Monospace", 7))
            p.setPen(QColor(120, 170, 190))
            p.drawText(int(clip_x) + 8, int(y + ch) - 6,
                       f"{dur_s:.1f}s | {cl:.1f} beats")

            # Gap indicator between clips
            if clip != clips[-1]:
                next_clip = clips[clips.index(clip) + 1]
                next_start = float(getattr(next_clip, 'start_beats', 0))
                if next_start > ce + 0.01:
                    gap_x1 = self._beats_to_x(ce)
                    gap_x2 = self._beats_to_x(next_start)
                    if gap_x1 > 0 and gap_x2 < w:
                        p.setPen(QPen(QColor(100, 100, 60, 100), 1, Qt.PenStyle.DashLine))
                        gap_mid_y = y + ch // 2
                        p.drawLine(int(gap_x1), gap_mid_y, int(gap_x2), gap_mid_y)

    def _draw_filmstrip_for_clip(self, p: QPainter, rect: QRectF,
                                  clip, video_path: str) -> None:
        """Draw filmstrip thumbnails for a specific clip."""
        if not video_path or not os.path.isfile(video_path):
            return
        self._ensure_thumb_service()
        svc = self._thumb_svc
        if not svc:
            return

        x0 = rect.x()
        y0 = rect.y() + 20
        cw = rect.width()
        ch = rect.height() - 26
        if ch < 16 or cw < 16:
            return

        thumb_h = max(16, int(ch))
        thumb_w = max(16, int(thumb_h * 16 / 9))
        n_frames = max(1, int(cw / max(8, thumb_w)))
        frame_w = cw / max(1, n_frames)

        cl = float(getattr(clip, 'length_beats', 0))
        clip_len_s = cl * 60.0 / max(1, self._bpm)
        offset_s = float(getattr(clip, 'offset_seconds', 0) or 0)
        step_s = clip_len_s / max(1, n_frames) if clip_len_s > 0 else 1.0

        times = [offset_s + i * step_s for i in range(n_frames)]
        missing = []

        for i, t in enumerate(times):
            fx = x0 + i * frame_w
            if fx + frame_w < 0 or fx > self.width():
                continue
            pixmap = svc.get_frame(video_path, t, thumb_w, thumb_h)
            if pixmap is not None:
                p.drawPixmap(QRectF(fx, y0, frame_w, ch).toRect(), pixmap)
            else:
                p.fillRect(QRectF(fx, y0, frame_w, ch), QBrush(QColor(25, 50, 60)))
                missing.append(t)
            if i > 0:
                p.setPen(QPen(QColor(0, 0, 0, 100), 1))
                p.drawLine(int(fx), int(y0), int(fx), int(y0 + ch))

        if missing:
            svc.request_frames(video_path, missing, thumb_w, thumb_h)

    def _draw_playhead(self, p: QPainter, w: int, h: int) -> None:
        """Draw the transport playhead cursor."""
        beat = self._get_playhead_beat()
        x = int(self._beats_to_x(beat))
        if x < 0 or x > w:
            return

        p.setPen(QPen(_CLR_PLAYHEAD, 2))
        p.drawLine(x, 0, x, h)

        # Playhead triangle at top
        p.setBrush(QBrush(_CLR_PLAYHEAD))
        p.setPen(Qt.PenStyle.NoPen)
        from PyQt6.QtGui import QPolygonF
        tri = QPolygonF([
            QPointF(x - 5, 0),
            QPointF(x + 5, 0),
            QPointF(x, 8),
        ])
        p.drawPolygon(tri)

    def _draw_tool_overlay(self, p: QPainter, w: int, h: int) -> None:
        """Draw tool-specific overlays (knife line, etc)."""
        if self._tool == TOOL_KNIFE and self._clip:
            mx = self._mouse_pos.x()
            if 0 <= mx <= w:
                p.setPen(QPen(_CLR_KNIFE, 1, Qt.PenStyle.DashLine))
                p.drawLine(int(mx), _HEADER_HEIGHT, int(mx), h)

                # Show beat position
                beat = self._x_to_beats(mx)
                p.setPen(_CLR_KNIFE)
                p.setFont(QFont("Monospace", 8))
                p.drawText(int(mx) + 4, h - 8, f"Beat {beat:.2f}")

    def _draw_info_bar(self, p: QPainter, w: int, h: int) -> None:
        """Draw info bar at bottom with tool, snap, loop, cursor info."""
        bar_h = 20
        y = h - bar_h
        p.fillRect(0, y, w, bar_h, QColor(25, 25, 40))

        p.setFont(QFont("Monospace", 8))
        p.setPen(_CLR_TEXT)

        info = f"Tool: {self._tool.upper()}"
        if self._clip:
            info += f"  |  Clip: {self._clip_start_beats:.1f}–{self._clip_start_beats + self._clip_length_beats:.1f} beats"
        info += f"  |  Zoom: {self._px_per_beat:.0f}px/beat"
        info += f"  |  BPM: {self._bpm:.0f}"

        # Snap indicator
        snap = self._snap_beats
        snap_str = {0: "OFF", 0.25: "1/16", 0.5: "1/8", 1.0: "1/4", 2.0: "1/2", 4.0: "Bar"}.get(snap, f"{snap}")
        info += f"  |  📐{snap_str}"

        # Loop indicator
        if self._loop_enabled:
            info += f"  |  🔁{self._loop_start:.0f}–{self._loop_end:.0f}"

        beat = self._x_to_beats(self._mouse_pos.x())
        secs = beat * 60.0 / max(1, self._bpm)
        info += f"  |  Cursor: Beat {beat:.2f} ({secs:.1f}s)"

        p.drawText(4, y + 14, info)

    # ─────────────────────────────────────────────────────
    # Mouse Events
    # ─────────────────────────────────────────────────────

    def mousePressEvent(self, event: QMouseEvent) -> None:
        self._mouse_pos = event.position()
        beat = self._x_to_beats(event.position().x())

        if event.button() == Qt.MouseButton.LeftButton:
            if self._tool == TOOL_KNIFE:
                # Split at click position — find which clip is under cursor
                snapped = self._snap_beat(beat)
                for clip in getattr(self, '_all_clips', []):
                    cs = float(getattr(clip, 'start_beats', 0))
                    ce = cs + float(getattr(clip, 'length_beats', 0))
                    if cs < snapped < ce:
                        cid = str(getattr(clip, 'id', ''))
                        self.clip_split.emit(cid, snapped)
                        try:
                            self.status_message.emit(f"✂ Split bei Beat {snapped:.1f}")
                        except Exception:
                            pass
                        break
                return

            if self._tool == TOOL_TRIM and self._clip:
                cs = self._clip_start_beats
                ce = cs + self._clip_length_beats
                x_start = self._beats_to_x(cs)
                x_end = self._beats_to_x(ce)
                mx = event.position().x()
                if abs(mx - x_start) < 10:
                    self._drag_edge = "start"
                    self._dragging = True
                elif abs(mx - x_end) < 10:
                    self._drag_edge = "end"
                    self._dragging = True
                return

            if self._tool == TOOL_SELECT:
                # v0.0.20.934: Check for loop handle drag in header area
                my = event.position().y()
                if my < _HEADER_HEIGHT and self._loop_enabled:
                    x_ls = self._beats_to_x(self._loop_start)
                    x_le = self._beats_to_x(self._loop_end)
                    mx = event.position().x()
                    if abs(mx - x_ls) < 12:
                        self._loop_dragging = "start"
                        self._dragging = True
                        return
                    elif abs(mx - x_le) < 12:
                        self._loop_dragging = "end"
                        self._dragging = True
                        return

                ctrl = bool(event.modifiers() & Qt.KeyboardModifier.ControlModifier)

                # Click to select clip under cursor
                selected = self.select_clip_at(beat)

                if selected and ctrl:
                    self._ctrl_drag_copy = True
                    self._dragging = True
                    self._drag_start = event.position()
                    self._drag_start_beat = beat
                elif selected and not ctrl:
                    self._ctrl_drag_copy = False
                    self._dragging = True
                    self._drag_start = event.position()
                    self._drag_start_beat = beat

                # v0.0.20.934: Snap playhead to grid on click
                snapped = self._snap_beat(beat)
                if self._transport and hasattr(self._transport, 'set_position'):
                    try:
                        self._transport.set_position(snapped)
                    except Exception:
                        pass

        elif event.button() == Qt.MouseButton.MiddleButton:
            self._dragging = True
            self._drag_start = event.position()
            self._drag_edge = None

        self._request_paint()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        self._mouse_pos = event.position()

        if self._dragging:
            if event.buttons() & Qt.MouseButton.MiddleButton:
                # Pan view
                dx = event.position().x() - self._drag_start.x()
                self._scroll_x -= dx / self._px_per_beat
                self._scroll_x = max(0, self._scroll_x)
                self._drag_start = event.position()

            elif self._loop_dragging:
                # v0.0.20.934: Loop region drag
                beat = self._snap_beat(self._x_to_beats(event.position().x()))
                if self._loop_dragging == "start":
                    self._loop_start = max(0, min(beat, self._loop_end - self._snap_beats))
                elif self._loop_dragging == "end":
                    self._loop_end = max(self._loop_start + max(0.25, self._snap_beats), beat)

            elif self._drag_edge and self._clip:
                beat = self._snap_beat(self._x_to_beats(event.position().x()))
                if self._drag_edge == "start":
                    new_start = max(0, beat)
                    if new_start < self._clip_start_beats + self._clip_length_beats - 0.25:
                        diff = new_start - self._clip_start_beats
                        self._clip_start_beats = new_start
                        self._clip_length_beats -= diff
                elif self._drag_edge == "end":
                    new_end = max(self._clip_start_beats + 0.25, beat)
                    self._clip_length_beats = new_end - self._clip_start_beats

        # Cursor shape based on position
        if self._tool == TOOL_SELECT:
            mx = event.position().x()
            my = event.position().y()

            # Loop handle cursor
            if my < _HEADER_HEIGHT and self._loop_enabled:
                x_ls = self._beats_to_x(self._loop_start)
                x_le = self._beats_to_x(self._loop_end)
                if abs(mx - x_ls) < 12 or abs(mx - x_le) < 12:
                    self.setCursor(Qt.CursorShape.SizeHorCursor)
                    self._request_paint()
                    return

            # Trim handle cursor
            if self._clip:
                cs = self._clip_start_beats
                ce = cs + self._clip_length_beats
                x_start = self._beats_to_x(cs)
                x_end = self._beats_to_x(ce)
                if abs(mx - x_start) < 8 or abs(mx - x_end) < 8:
                    self.setCursor(Qt.CursorShape.SizeHorCursor)
                else:
                    self.setCursor(Qt.CursorShape.ArrowCursor)

        self._request_paint()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if self._dragging and self._drag_edge and self._clip:
            # Apply trim to clip model
            try:
                self._clip.start_beats = self._clip_start_beats
                self._clip.length_beats = self._clip_length_beats
                self.clip_trimmed.emit(
                    str(self._clip_id),
                    self._clip_start_beats if self._drag_edge == "start"
                    else self._clip_length_beats,
                    self._drag_edge,
                )
                try:
                    self.status_message.emit(
                        f"✂ Trimmed {self._drag_edge}: {self._clip_start_beats:.1f}–"
                        f"{self._clip_start_beats + self._clip_length_beats:.1f}")
                except Exception:
                    pass
                if hasattr(self._ps, '_emit_updated'):
                    self._ps._emit_updated()
            except Exception as e:
                log.debug("[VideoEditor] trim apply: %s", e)

        elif self._dragging and self._clip and not self._drag_edge:
            # v0.0.20.932: Ctrl+drag = copy, normal drag = move
            beat = self._x_to_beats(event.position().x())
            drag_dist = abs(beat - self._drag_start_beat)
            if drag_dist > 0.5:  # minimum drag distance
                if self._ctrl_drag_copy:
                    # Copy clip to new position
                    self.copy_clip()
                    self.paste_clip(self._snap_beat(beat))
                    try:
                        self.status_message.emit(f"📄 Clip kopiert zu Beat {beat:.1f}")
                    except Exception:
                        pass
                else:
                    # Move clip to new position
                    try:
                        new_start = self._snap_beat(beat - (self._drag_start_beat - self._clip_start_beats))
                        new_start = max(0, new_start)
                        self._clip.start_beats = new_start
                        self._clip_start_beats = new_start
                        if hasattr(self._ps, '_emit_updated'):
                            self._ps._emit_updated()
                        self.set_clip(self._clip_id)
                        try:
                            self.status_message.emit(f"↔ Clip verschoben zu Beat {new_start:.1f}")
                        except Exception:
                            pass
                    except Exception as e:
                        log.debug("[VideoEditor] move: %s", e)

        self._dragging = False
        self._drag_edge = None
        self._ctrl_drag_copy = False
        # v0.0.20.934: Commit loop region to transport
        if self._loop_dragging:
            self._loop_dragging = None
            if self._transport and hasattr(self._transport, 'set_loop'):
                try:
                    self._transport.set_loop(self._loop_enabled, self._loop_start, self._loop_end)
                except Exception:
                    pass
        self._request_paint()

    def wheelEvent(self, event: QWheelEvent) -> None:
        delta = event.angleDelta().y()
        if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            # Zoom
            factor = 1.15 if delta > 0 else 0.87
            self._px_per_beat = max(10, min(200, self._px_per_beat * factor))
        else:
            # Scroll
            self._scroll_x -= delta / 120.0 * 2
            self._scroll_x = max(0, self._scroll_x)
        self._request_paint()

    def keyPressEvent(self, event: QKeyEvent) -> None:
        key = event.key()
        mods = event.modifiers()
        ctrl = bool(mods & Qt.KeyboardModifier.ControlModifier)

        # Ctrl+Key shortcuts
        if ctrl:
            if key == Qt.Key.Key_C:
                self.copy_clip()
                return
            elif key == Qt.Key.Key_V:
                self.paste_clip()
                return
            elif key == Qt.Key.Key_D:
                self.duplicate_clip()
                return
            elif key == Qt.Key.Key_J:
                self.join_clips()
                return
            elif key == Qt.Key.Key_Z:
                # Undo — delegate to project service
                try:
                    if hasattr(self._ps, 'undo'):
                        self._ps.undo()
                        self.set_clip(self._clip_id)
                except Exception:
                    pass
                return

        if key == Qt.Key.Key_S and not ctrl:
            self.split_at_playhead()
        elif key == Qt.Key.Key_Delete or key == Qt.Key.Key_Backspace:
            self.delete_selected_clip()
        elif key == Qt.Key.Key_G:
            # Toggle ghost clips
            self._ghost_enabled = not self._ghost_enabled
            self._request_paint()
            try:
                self.status_message.emit(
                    f"👻 Ghost-Clips {'AN' if self._ghost_enabled else 'AUS'}")
            except Exception:
                pass
        elif key == Qt.Key.Key_L:
            # v0.0.20.934: Toggle loop
            self._loop_enabled = not self._loop_enabled
            if self._loop_enabled and self._clip:
                # Default: loop around selected clip
                self._loop_start = self._clip_start_beats
                self._loop_end = self._clip_start_beats + self._clip_length_beats
            if self._transport and hasattr(self._transport, 'set_loop'):
                try:
                    self._transport.set_loop(self._loop_enabled, self._loop_start, self._loop_end)
                except Exception:
                    pass
            self._request_paint()
            try:
                self.status_message.emit(
                    f"🔁 Loop {'AN' if self._loop_enabled else 'AUS'}"
                    + (f" ({self._loop_start:.0f}–{self._loop_end:.0f} beats)" if self._loop_enabled else ""))
            except Exception:
                pass
        elif key == Qt.Key.Key_5:
            # Snap: Off
            self._snap_beats = 0
            try: self.status_message.emit("📐 Snap: AUS")
            except: pass
            self._request_paint()
        elif key == Qt.Key.Key_6:
            # Snap: 1 beat
            self._snap_beats = 1.0
            try: self.status_message.emit("📐 Snap: 1 Beat")
            except: pass
            self._request_paint()
        elif key == Qt.Key.Key_7:
            # Snap: 1/2 beat
            self._snap_beats = 0.5
            try: self.status_message.emit("📐 Snap: 1/2 Beat")
            except: pass
            self._request_paint()
        elif key == Qt.Key.Key_8:
            # Snap: 1/4 beat (1/16 note)
            self._snap_beats = 0.25
            try: self.status_message.emit("📐 Snap: 1/4 Beat")
            except: pass
            self._request_paint()
        elif key == Qt.Key.Key_9:
            # Snap: Bar (4 beats)
            self._snap_beats = 4.0
            try: self.status_message.emit("📐 Snap: Bar (4 Beats)")
            except: pass
            self._request_paint()
        elif key == Qt.Key.Key_1:
            self.set_tool(TOOL_SELECT)
        elif key == Qt.Key.Key_2:
            self.set_tool(TOOL_KNIFE)
        elif key == Qt.Key.Key_3:
            self.set_tool(TOOL_TRIM)
        elif key == Qt.Key.Key_4:
            self.set_tool(TOOL_SLIP)
        elif key == Qt.Key.Key_Plus or key == Qt.Key.Key_Equal:
            self._px_per_beat = min(200, self._px_per_beat * 1.2)
            self._request_paint()
        elif key == Qt.Key.Key_Minus:
            self._px_per_beat = max(10, self._px_per_beat / 1.2)
            self._request_paint()
        elif key == Qt.Key.Key_Home:
            self._scroll_x = 0
            self._request_paint()
        elif key == Qt.Key.Key_End:
            clips = getattr(self, '_all_clips', [])
            if clips:
                last_end = max(
                    float(getattr(c, 'start_beats', 0)) + float(getattr(c, 'length_beats', 0))
                    for c in clips
                )
                self._scroll_x = max(0, last_end - 8)
                self._request_paint()
        elif key == Qt.Key.Key_F:
            self._fit_view()
        elif key == Qt.Key.Key_Left:
            self._select_adjacent_clip(-1)
        elif key == Qt.Key.Key_Right:
            self._select_adjacent_clip(1)
        elif key == Qt.Key.Key_Space:
            if self._transport and hasattr(self._transport, 'toggle'):
                try:
                    self._transport.toggle()
                except Exception:
                    pass
        else:
            super().keyPressEvent(event)

    def _select_adjacent_clip(self, direction: int) -> None:
        """Select the next/previous clip on the track."""
        clips = getattr(self, '_all_clips', [])
        if not clips or not self._clip_id:
            return
        idx = -1
        for i, c in enumerate(clips):
            if str(getattr(c, 'id', '')) == str(self._clip_id):
                idx = i
                break
        if idx < 0:
            return
        new_idx = idx + direction
        if 0 <= new_idx < len(clips):
            new_clip = clips[new_idx]
            cid = str(getattr(new_clip, 'id', ''))
            self._clip_id = cid
            self._clip = new_clip
            self._video_path = str(getattr(new_clip, 'source_path', '') or '')
            self._clip_start_beats = float(getattr(new_clip, 'start_beats', 0))
            self._clip_length_beats = float(getattr(new_clip, 'length_beats', 0))
            # Scroll to selected clip
            self._scroll_x = max(0, self._clip_start_beats - 2)
            self._request_paint()


# ═══════════════════════════════════════════════════════════════
# Video Editor Widget (wraps Canvas + Toolbar)
# ═══════════════════════════════════════════════════════════════

class VideoEditor(QWidget):
    """Complete Video Editor widget with toolbar + canvas.

    Drop-in replacement for PianoRollEditor in EditorTabs.
    """

    status_message = pyqtSignal(str)

    def __init__(self, project_service, transport=None,
                 editor_timeline=None, parent=None):
        super().__init__(parent)
        self._ps = project_service
        self._transport = transport

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # ── Toolbar ──
        toolbar = QHBoxLayout()
        toolbar.setContentsMargins(4, 2, 4, 2)
        toolbar.setSpacing(4)

        lbl = QLabel("🎬 Video-Editor")
        lbl.setStyleSheet("font-weight: bold; color: #e0e0e0; font-size: 12px;")
        toolbar.addWidget(lbl)

        toolbar.addSpacing(8)

        # Tool buttons
        self._tool_btns = {}
        for tool_id, icon, tip in [
            (TOOL_SELECT, "👆", "Auswahl (1)"),
            (TOOL_KNIFE, "✂", "Messer / Split (2)"),
            (TOOL_TRIM, "↔", "Trimmen (3)"),
            (TOOL_SLIP, "⇄", "Slip / Verschieben (4)"),
        ]:
            btn = QToolButton()
            btn.setText(icon)
            btn.setToolTip(tip)
            btn.setCheckable(True)
            btn.setFixedSize(28, 24)
            btn.setStyleSheet(
                "QToolButton { background: #2a2a3a; border: 1px solid #444; "
                "border-radius: 3px; color: #ddd; font-size: 13px; }"
                "QToolButton:checked { background: #3a5a7a; border-color: #6aa; }"
                "QToolButton:hover { background: #3a3a4a; }"
            )
            btn.clicked.connect(lambda checked, t=tool_id: self._on_tool_click(t))
            toolbar.addWidget(btn)
            self._tool_btns[tool_id] = btn

        self._tool_btns[TOOL_SELECT].setChecked(True)

        toolbar.addSpacing(12)

        # Split at playhead button
        btn_split = QPushButton("✂ Split (S)")
        btn_split.setFixedHeight(24)
        btn_split.setStyleSheet(
            "QPushButton { background: #3a2a2a; border: 1px solid #804a4a; "
            "border-radius: 3px; color: #ddd; font-size: 11px; padding: 0 8px; }"
            "QPushButton:hover { background: #4a3a3a; }"
        )
        btn_split.clicked.connect(self._on_split)
        toolbar.addWidget(btn_split)

        toolbar.addSpacing(8)

        # v0.0.20.934: Snap selector
        toolbar.addWidget(QLabel("📐"))
        self._cmb_snap = QComboBox()
        self._cmb_snap.addItems(["Bar", "Beat", "1/2", "1/4", "Off"])
        self._cmb_snap.setCurrentText("Beat")
        self._cmb_snap.setFixedWidth(60)
        self._cmb_snap.setFixedHeight(22)
        self._cmb_snap.setStyleSheet(
            "QComboBox { background: #2a2a3a; color: #ddd; border: 1px solid #444; "
            "border-radius: 3px; font-size: 10px; padding: 0 4px; }"
        )
        self._cmb_snap.currentTextChanged.connect(self._on_snap_changed)
        toolbar.addWidget(self._cmb_snap)

        toolbar.addSpacing(8)

        # v0.0.20.934: Loop toggle
        self._btn_loop = QToolButton()
        self._btn_loop.setText("🔁")
        self._btn_loop.setToolTip("Loop ein/aus (L)")
        self._btn_loop.setCheckable(True)
        self._btn_loop.setFixedSize(28, 24)
        self._btn_loop.setStyleSheet(
            "QToolButton { background: #2a2a3a; border: 1px solid #444; "
            "border-radius: 3px; color: #ddd; font-size: 13px; }"
            "QToolButton:checked { background: #2a4a3a; border-color: #5a8; color: #5d8; }"
        )
        self._btn_loop.clicked.connect(self._on_loop_toggle)
        toolbar.addWidget(self._btn_loop)

        toolbar.addStretch(1)

        # SMPTE display
        self._lbl_smpte = QLabel("00:00:00:00")
        self._lbl_smpte.setStyleSheet(
            "font-family: 'Courier New', monospace; font-size: 13px; "
            "font-weight: bold; color: #4fc3f7; background: #0a0a14; "
            "border: 1px solid #333; border-radius: 3px; padding: 2px 6px;"
        )
        toolbar.addWidget(self._lbl_smpte)

        toolbar_w = QWidget()
        toolbar_w.setLayout(toolbar)
        toolbar_w.setFixedHeight(32)
        toolbar_w.setStyleSheet("background: #1e1e2e; border-bottom: 1px solid #333;")
        lay.addWidget(toolbar_w)

        # ── Canvas ──
        self._canvas = VideoEditorCanvas(project_service, transport=transport,
                                          parent=self)
        self._canvas.status_message.connect(self.status_message)
        self._canvas.clip_split.connect(self._do_split)
        self._canvas.clip_deleted.connect(self._do_delete)
        lay.addWidget(self._canvas, 1)

        # SMPTE update timer
        self._smpte_timer = QTimer(self)
        self._smpte_timer.setInterval(100)
        self._smpte_timer.timeout.connect(self._update_smpte)
        self._smpte_timer.start()

    def set_clip(self, clip_id: Optional[str]) -> None:
        """Load a video clip for editing."""
        # Only handle video clips
        if clip_id:
            try:
                proj = None
                ps = self._ps
                proj = getattr(ps, 'project', None)
                if proj is None:
                    ctx = getattr(ps, 'ctx', None)
                    proj = getattr(ctx, 'project', None) if ctx else None
                if proj:
                    for c in proj.clips or []:
                        if str(getattr(c, 'id', '')) == str(clip_id):
                            if str(getattr(c, 'kind', '')) != 'video':
                                return  # Not a video clip — ignore
                            break
            except Exception:
                pass

        self._canvas.set_clip(clip_id)

        # Try to get scene markers from VideoConnector
        try:
            from pydaw.services.video_connector import VideoConnector
            vc = VideoConnector.instance()
            vki = getattr(vc, '_video_ki_panel', None)
            if vki:
                vki_svc = getattr(vki, '_vki', None)
                if vki_svc and hasattr(vki_svc, 'scenes'):
                    bpm = self._canvas._bpm
                    markers = []
                    for scene in vki_svc.scenes:
                        beat = scene.start_seconds * bpm / 60.0
                        r, g, b = scene.dominant_color
                        markers.append({
                            "beat": beat,
                            "color": f"#{r:02x}{g:02x}{b:02x}",
                            "label": f"Szene {scene.index + 1}",
                        })
                    self._canvas.set_scene_markers(markers)
        except Exception:
            pass

    def _on_snap_changed(self, text: str) -> None:
        """v0.0.20.934: Snap resolution changed from combo."""
        snap_map = {"Bar": 4.0, "Beat": 1.0, "1/2": 0.5, "1/4": 0.25, "Off": 0}
        self._canvas._snap_beats = snap_map.get(text, 1.0)
        self._canvas._grid_subdivisions = (text in ("1/2", "1/4"))
        self._canvas._request_paint()

    def _on_loop_toggle(self, checked: bool) -> None:
        """v0.0.20.934: Loop button toggled."""
        self._canvas._loop_enabled = checked
        if checked and self._canvas._clip:
            self._canvas._loop_start = self._canvas._clip_start_beats
            self._canvas._loop_end = self._canvas._clip_start_beats + self._canvas._clip_length_beats
        transport = self._transport
        if transport and hasattr(transport, 'set_loop'):
            try:
                transport.set_loop(checked, self._canvas._loop_start, self._canvas._loop_end)
            except Exception:
                pass
        self._canvas._request_paint()

    def _on_tool_click(self, tool: str) -> None:
        for t, btn in self._tool_btns.items():
            btn.setChecked(t == tool)
        self._canvas.set_tool(tool)

    def _on_split(self) -> None:
        self._canvas.split_at_playhead()

    def _do_split(self, clip_id: str, beat: float) -> None:
        """Perform the actual clip split in the project model.

        v0.0.20.931: After split, refreshes multi-clip view to show both parts.
        """
        try:
            ps = self._ps
            proj = getattr(ps, 'project', None)
            if proj is None:
                ctx = getattr(ps, 'ctx', None)
                proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                return

            # Find clip
            src = None
            for c in proj.clips:
                if str(getattr(c, 'id', '')) == str(clip_id):
                    src = c
                    break
            if not src:
                return

            cs = float(getattr(src, 'start_beats', 0))
            cl = float(getattr(src, 'length_beats', 0))
            ce = cs + cl
            if beat <= cs or beat >= ce:
                return

            from pydaw.model.project import Clip

            # Shorten original clip
            src.length_beats = beat - cs

            # Create new clip after split point
            new_clip = Clip(
                kind="video",
                track_id=str(getattr(src, 'track_id', '')),
                label=str(getattr(src, 'label', '')) + " (B)",
                source_path=str(getattr(src, 'source_path', '')),
                start_beats=beat,
                length_beats=ce - beat,
                offset_seconds=float(getattr(src, 'offset_seconds', 0) or 0)
                    + (beat - cs) * 60.0 / max(1, self._canvas._bpm),
            )
            proj.clips.append(new_clip)

            # Emit changes → Arranger refreshes
            if hasattr(ps, '_emit_updated'):
                ps._emit_updated()
            elif hasattr(ps, '_emit_changed'):
                ps._emit_changed()

            # Refresh multi-clip view — shows both parts now
            self._canvas.set_clip(str(clip_id))

        except Exception as e:
            log.error("[VideoEditor] split: %s", e, exc_info=True)

    def _do_delete(self, clip_id: str) -> None:
        """Delete a video clip from the project."""
        try:
            ps = self._ps
            proj = getattr(ps, 'project', None)
            if proj is None:
                ctx = getattr(ps, 'ctx', None)
                proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                return

            # Remove the clip
            proj.clips = [c for c in proj.clips
                          if str(getattr(c, 'id', '')) != str(clip_id)]

            # Emit changes → Arranger refreshes
            if hasattr(ps, '_emit_updated'):
                ps._emit_updated()
            elif hasattr(ps, '_emit_changed'):
                ps._emit_changed()

            # Try to select an adjacent clip
            remaining = [c for c in proj.clips
                         if str(getattr(c, 'kind', '')) == 'video']
            if remaining:
                self._canvas.set_clip(str(getattr(remaining[0], 'id', '')))
            else:
                self._canvas.set_clip(None)

        except Exception as e:
            log.error("[VideoEditor] delete: %s", e, exc_info=True)

    def _update_smpte(self) -> None:
        try:
            if not self._transport:
                return
            beat = float(getattr(self._transport, 'current_beat', 0.0))
            bpm = float(getattr(self._transport, 'bpm', 120.0) or 120.0)
            secs = beat * 60.0 / max(1, bpm)
            h = int(secs) // 3600
            m = (int(secs) % 3600) // 60
            s = int(secs) % 60
            f = int((secs - int(secs)) * 24)
            self._lbl_smpte.setText(f"{h:02d}:{m:02d}:{s:02d}:{f:02d}")
        except Exception:
            pass
