# CHANGELOG v0.0.20.762 — BRRR Klangtuning nach ZynAdd-Referenz

**Datum:** 2026-03-23
**Autor:** Claude Opus 4.6
**Arbeitspaket:** BRRR Scrawl→Audio + Sound-Design

## Was wurde gemacht

### Scrawl → Audio (aus v761)
- `_scrawl_lookup()`: Scrawl-Tabellen modulieren ADSR-Envelopes
- Auto-Bake beim Widget-Init entfernt (Original-Sound erhalten)

### Klangtuning nach ZynAddSubFX BRRRRRR2 Referenz
Spektralanalyse der Original-WAV ergab 5 Kernprobleme, alle behoben:

| Problem | Vorher | Nachher |
|---------|--------|---------|
| FM-Ratio 25 (metallisch) | H6 dominant | FM-Ratio 5 (warm) |
| Harmonische [1,2,6] | H3=0.021 | [1,2,3,4], H3=0.302 |
| h_sum-Normalisierung | /4.1 Faktor | entfernt (tanh limitiert) |
| Kein HP-Filter | 7.3% Sub | HP@40Hz, 0.0% Sub |
| Flutter-Attack 380ms | Onset 0.054 RMS | 80ms, Onset 0.488 RMS |

## Geänderte Dateien
| Datei | Änderung |
|---|---|
| pydaw/plugins/brrr/brrr_engine.py | FM-Ratio, Harmonische, HP-Filter, Envelope-Tuning, Scrawl-Integration |
| pydaw/plugins/brrr/brrr_widget.py | Presets, Knob-Defaults, kein Auto-Bake |
| pydaw/version.py | → 0.0.20.762 |
| VERSION | → 0.0.20.762 |

## Was als nächstes zu tun ist
- Hardware-Test: BRRR v762 vs ZynAdd A/B-Vergleich
- Rust Engine Disconnect-Loop fixen
