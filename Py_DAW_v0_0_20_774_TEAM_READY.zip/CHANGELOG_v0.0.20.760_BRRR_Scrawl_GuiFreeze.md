# CHANGELOG v0.0.20.760 — BRRR Scrawl GUI-Freeze Fix

**Datum:** 2026-03-23
**Autor:** Claude Opus 4.6
**Arbeitspaket:** Kritischer Bug-Fix (Live-Report von Anno)

## Problem

BRRR Flutter Synth: Beim Zeichnen im Scrawl-Editor friert die gesamte GUI ein.
Nichts mehr bedienbar — "alles tot". Nur noch Force-Quit möglich.

## Ursache (3 Bugs gleichzeitig)

### Bug 1: ScrawlCanvas paintEvent — O(n) drawLine pro Repaint
- Während Freehand-Zeichnung sammelt der Canvas bis zu 1024 Samples
- `paintEvent()` zeichnete **jedes** Sample als einzelne `drawLine()`
- `mouseMoveEvent()` rief bei **jeder** Mausbewegung `update()` auf
- Ergebnis: 60 Mouse-Events/s × 1024 drawLine = **61.440 drawLine/s** → GUI-Thread verhungert

### Bug 2: `_persist_state()` rief `_emit_updated()` auf
- Jede Knob-Änderung → `_schedule_persist()` → 120ms Timer → `_persist_state()`
- `_persist_state()` rief `project_service._emit_updated()` auf
- `_emit_updated()` löst `project_updated` Signal aus → **kompletter UI-Rebuild aller Widgets**
  (Arranger, Mixer, Browser, Device Panel, 300+ Widgets werden neu gezeichnet)
- Bei schnellem Scrawl-Zeichnen: 8× pro Sekunde voller UI-Rebuild

### Bug 3: Scrawl-Tabellen ohne Audio-Effekt
- `buzz_scrawl_table` und `flutter_scrawl_table` werden korrekt berechnet und gespeichert
- Aber die Voice-Render-Methode `_BrrrVoice.render()` liest diese Tabellen nie
- Die Scrawl-Kurven haben daher aktuell keinen hörbaren Effekt
- (Größeres Feature-Problem — wird in separater Session gelöst)

## Fixes

### Fix 1: ScrawlCanvas Freehand-Throttle + Preview-Downsampling
- `mouseMoveEvent()`: `update()` nur noch jeden 4. Sample statt bei jedem Mouse-Event
- `paintEvent()`: Freehand-Preview auf max 128 Linien downsampled
- Ergebnis: Statt 61.440 jetzt max **1.920 drawLine/s** → GUI bleibt flüssig

### Fix 2: `_persist_state()` ohne `_emit_updated()`
- `_emit_updated()` Aufruf entfernt
- State wird weiterhin korrekt in `trk.instrument_state` geschrieben
- Wird beim nächsten `project_save()` automatisch mitgespeichert
- Kein unnötiger UI-Rebuild mehr bei Parameter-Änderungen

## Geänderte Dateien

| Datei | Änderung |
|---|---|
| `pydaw/plugins/fusion/scrawl_editor.py` | mouseMoveEvent throttle (jeder 4. Sample), paintEvent preview max 128 lines |
| `pydaw/plugins/brrr/brrr_widget.py` | _persist_state: _emit_updated() entfernt |
| `pydaw/version.py` | 0.0.20.760 |
| `VERSION` | 0.0.20.760 |

## Tests

- ✅ 314 Python-Dateien kompilieren fehlerfrei
- ✅ ScrawlCanvas: Freehand mit 500+ Samples → kein Freeze
- ✅ BRRR Knob-Drag → kein UI-Rebuild-Storm

## Bekannte offene Punkte

- Scrawl-Tabellen werden von der Engine nicht gelesen (kein Audio-Effekt)
- Rust Engine Disconnect-Loop (reconnect funktioniert, aber Ursache unklar)
- `.xiz` Import (ZynAddSubFX Presets) nicht unterstützt

## Was als nächstes zu tun ist

- [ ] BRRR: Scrawl-Tabellen in Voice.render() einbauen (Audio-Effekt)
- [ ] Rust Engine: Disconnect-Ursache finden
- [ ] Hardware-Test: BRRR Scrawl-Zeichnen → GUI bleibt flüssig?
