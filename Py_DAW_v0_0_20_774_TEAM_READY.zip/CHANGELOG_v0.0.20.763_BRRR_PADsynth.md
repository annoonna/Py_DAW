# CHANGELOG v0.0.20.763 — BRRR PADsynth Spektral-Synthese

**Datum:** 2026-03-23
**Autor:** Claude Opus 4.6

## Was wurde gemacht

### PADsynth ersetzt FM-Synthese (Kernänderung!)
- Paul Nasca's PADsynth-Algorithmus: Gauß-verteilte Bandbreiten pro Harmonische
- Harmonisches Profil aus 7:26 Min demo.mp3 des echten BRRRRRR2 extrahiert
- 65536-Sample Wavetable wird bei note_on generiert (~5-26ms)
- Playback: vektorisierter Table-Lookup mit linearer Interpolation
- 40× Echtzeit (schneller als die alte FM-Synthese!)
- "FM Depth" Knob wird zu "PAD Width" (Bandwidth in Cents)

### Scrawl → Audio
- `_scrawl_lookup()`: Scrawl-Tabellen als Envelope-Multiplikator
- Auto-Bake entfernt: Preset-Sound bleibt Original

### Demo-basiertes Tuning
- S&H-Rate: 0.78→18Hz (echtes BRRRRRR-Flutter)
- Buzz-Sustain: 0→0.40 (durchgehender Ton wie im Original)
- HP-Filter bei 40Hz (Sub-Rumble entfernt)
- Alle 5 Presets aktualisiert

## Geänderte Dateien
| Datei | Änderung |
|---|---|
| pydaw/plugins/brrr/brrr_engine.py | PADsynth, Scrawl→Audio, HP, Tuning |
| pydaw/plugins/brrr/brrr_widget.py | Presets, Knob-Defaults, PAD Width |
| pydaw/version.py | → 0.0.20.763 |
| VERSION | → 0.0.20.763 |
