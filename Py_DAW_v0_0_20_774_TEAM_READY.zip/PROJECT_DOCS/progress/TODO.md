# TODO.md — Offene Aufgaben

## v0.0.20.764 — BRRR FM Demo-Tuning (PADsynth Rollback)

- [x] (Claude Opus 4.6, 2026-03-23): **PADsynth entfernt** — R2D2-Sound, zurück zu FM
- [x] (Claude Opus 4.6, 2026-03-23): **FM Demo-Tuning** — Ratio 3, H1-H6, S&H 18Hz, HP@40Hz


- [ ] AVAILABLE: **Hardware-Test BRRR PADsynth** — A/B-Vergleich mit ZynAdd, alle Tonlagen
- [ ] AVAILABLE: **Rust Engine Disconnect** — Ursache für wiederholte Disconnects nach ScanPlugins finden
- [ ] AVAILABLE: **Rust bauen + P0A testen** — `cd pydaw_engine && cargo build --release`
- [ ] AVAILABLE: **P0D Beta-Changelog** — CHANGELOG v0.1.0-beta schreiben
- [ ] AVAILABLE: **P1A Recording-Workflow** — Input-Monitoring < 10ms, Waveform-Preview während Recording

