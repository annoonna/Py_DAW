# Py_DAW v0.1.0-beta — Release Notes

**Datum:** 2026-03-23  
**Codename:** Apollo  
**Basis:** v0.0.20.753  
**Rust-Engine:** 332/332 Tests ✅  
**Python:** 313 Dateien, 0 Fehler ✅

---

## 🎉 Was ist Py_DAW?

Py_DAW (ChronoScaleStudio) ist eine Open-Source Digital Audio Workstation in Python/PyQt6 mit Rust-Audio-Engine, die Feature-Parität mit Bitwig Studio und Ableton Live anstrebt.

---

## ✨ Highlights dieser Version

### 🎹 Neue Instrumente
- **BRRR Flutter Synth** — ZynAddSubFX BRRRRRR2-Fantasy Port. S&H-LFO springt Pitch ±3 Oktaven zufällig — das charakteristische Flattern. FM-Buzz + Noise, 5 Factory-Presets, Scrawl-Hüllkurven, Preset-Save/Load.
- **Fusion Synth** — Semi-modularer Hybrid-Synthesizer mit tauschbaren OSC/FLT/ENV Modulen, Scrawl-Oszillator, Wavetable, Automation.

### 🤖 KI-Assistent
- Claude API-Integration: Natürliche Sprache → MIDI-Pattern direkt in den Track
- Streaming-Antworten, Chat-Verlauf, 6 Quick Prompts
- Kontextbewusst: sieht BPM, Key, aktiven Clip, Noten
- Variations-Generator: 4 Alternativen gleichzeitig
- File-Upload: Bilder, ZIP, JSON, Text analysieren

### 🎚 Arranger — Audio-Editing
- **Live-Waveform-Preview** während Recording (roter "● REC" Clip)
- **Clip-Gain-Envelope** — grüne Kurve über Waveform (Bitwig-Stil), editierbar via Audio-Editor
- **Fade-Kurven** — Linear/Logarithmisch/Exponentiell/S-Kurve per Clip-Kante, Rechtsklick-Auswahl
- **Crossfade-Editor** — automatische Erkennung überlappender Clips, Equal-Power/Linear/S-Kurve

### 🎼 Piano Roll
- **Velocity-Bar** — Ableton-style Balken unter dem Piano Roll, Drag zum Ändern, Multi-Select Delta, Rechtsklick-Menü
- Default-Velocity pro Werkzeug einstellbar

### 🔧 Stabilität (Phase 0)
- Rust-Engine Auto-Reconnect mit Exponential Backoff
- Crash-Reporter: Unbehandelte Exceptions → benutzerfreundliche Fehlermeldung + Log
- First-Run Wizard: Leeres Projekt → Ton in < 30 Sekunden
- Flush-Persistenz: Ctrl+S < 500ms sichert alle Zonen
- Scrawl-Envelope auf Amplitude-Hüllkurve angewendet

---

## 📦 Instrumente & Plugins

| Plugin | ID | Kategorie |
|---|---|---|
| Pro Audio Sampler | chrono.sampler | Sampler |
| Advanced Sampler | chrono.advanced_sampler | Multi-Sample |
| Pro Drum Machine | chrono.drum_machine | Drums |
| AETERNA Synthesizer | chrono.aeterna | Flagship Synth |
| Bachs Orgel | chrono.bach_orgel | Orgel |
| Fusion Synth | chrono.fusion | Hybrid Synth |
| **BRRR Flutter Synth** | chrono.brrr | Flutter Synth |
| SF2 Soundfont | chrono.sf2 | Sampler |
| VST3 (extern) | via pedalboard | External |
| CLAP (extern) | via host | External |
| LV2 (extern) | via host | External |

---

## 🦀 Rust Audio Engine

- 332 Unit-Tests, 0 Fehler
- ALSA/PipeWire Backend
- Per-Track-Rendering mit Lock-free RTParamStore
- MIDI-Scheduler mit Loop-Region-Support
- Instrument-Typen: ProSampler, MultiSample, DrumMachine, Aeterna, Fusion, BachOrgel, Sf2
- VST3/CLAP/LV2 Plugin-Host

---

## 🖥 System-Anforderungen

- Linux x86_64 (Debian/Ubuntu/Kali)
- Python 3.13+
- Rust 1.94+
- PyQt6 6.6+
- PipeWire oder JACK
- ALSA Development Headers

---

## 🚀 Starten

```bash
cd Py_DAW_v0_0_20_753
python3 setup_all.py --with-rust   # Einmalig
./start_daw.sh                      # Starten
```

---

## 🔮 Nächste Schritte (v0.2.0)

- Input-Monitoring < 10ms (ASIO-ähnlich via PipeWire)
- Auto-Punch Recording
- Comping-Workflow (Loop-Recording → Take-Lanes → Flatten)
- Audio-Quantisierung (transientenbasiert)
- CLAP Surge XT vollständig testen
- Performance: 20 Tracks ohne XRun

---

*Entwickelt mit Claude Sonnet 4.6 — ChronoScaleStudio Team*
