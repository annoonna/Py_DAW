# CHANGELOG v0.0.20.761 — BRRR Scrawl → Audio

**Datum:** 2026-03-23
**Autor:** Claude Opus 4.6
**Arbeitspaket:** Kritischer Feature-Fix (Live-Report)

## Was wurde gemacht

### BRRR Scrawl-Tabellen haben jetzt hörbaren Effekt!

**Problem:** Die Scrawl-Kurven (`buzz_scrawl_table` / `flutter_scrawl_table`)
wurden zwar vom Widget berechnet und im Engine-Objekt gespeichert, aber die
Voice-`render()`-Methode hat sie nie gelesen. Ergebnis: Scrawl zeichnen hatte
NULL Auswirkung auf den Sound.

**Lösung:**
1. **`_scrawl_lookup()`** — Neue vektorisierte Helper-Funktion:
   - Liest die 256-Sample Scrawl-Tabelle als Envelope-Modulator
   - Position basiert auf Voice-Alter / Gesamtdauer (A+D+R)
   - Lineare Interpolation, zero-alloc, numpy-basiert

2. **`_BrrrVoice.render()`** erweitert:
   - Akzeptiert jetzt `buzz_scrawl` und `flutter_scrawl` Parameter
   - Scrawl-Tabelle wird als Multiplikator auf die ADSR-Envelope angewendet
   - Wenn keine Scrawl-Tabelle → 100% Rückwärtskompatibilität (identischer Output)

3. **`_BrrrVoice.note_on()`** berechnet jetzt `_buzz_env_total_s` und
   `_flutter_env_total_s` für die Scrawl-Positionsberechnung

4. **`BrrrEngine.pull()`** gibt Scrawl-Tabellen thread-safe an Voices weiter

### Verifiziert durch automatisierte Tests:
- Scrawl ramp (0→1) + constant 0.5 → RMS sinkt von 0.113 auf 0.010 (deutlicher Effekt)
- Scrawl = 1.0 → identischer Output wie ohne Scrawl (diff = 0.000000)
- Keine Änderungen an bestehenden Dateien außer brrr_engine.py

## Geänderte Dateien
| Datei | Änderung |
|---|---|
| pydaw/plugins/brrr/brrr_engine.py | Scrawl → Audio Integration: _scrawl_lookup(), render() erweitert, note_on() Envelope-Dauer, pull() Thread-Safe |
| pydaw/version.py | 0.0.20.760 → 0.0.20.761 |
| VERSION | 0.0.20.760 → 0.0.20.761 |

## Was als nächstes zu tun ist
- Hardware-Test: BRRR Scrawl zeichnen → Sound verändert sich hörbar?
- Rust Engine: Disconnect-Loop Ursache finden
- Rust bauen + P0A testen: `cargo build --release`

## Bekannte Probleme / Offene Fragen
- .xiz-Dateien (ZynAddSubFX Presets) werden nicht unterstützt
- Rust Engine disconnect/reconnect Loop noch nicht untersucht
