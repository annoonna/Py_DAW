"""Collaboration Server — WebSocket-based real-time project sync.

v0.0.20.797 — Phase 5A: Echtzeit-Kollaboration

Architecture:
  - Server runs inside the DAW (host starts it)
  - Clients connect via WebSocket (ws://host:port)
  - Operations are JSON messages with types:
      "sync"     — full project state (initial sync)
      "op"       — incremental operation (track add/remove/modify, clip change, etc.)
      "cursor"   — user cursor position in arranger/piano roll
      "chat"     — text chat between collaborators
      "lock"     — acquire/release edit lock on a track
      "presence" — user joined/left/idle

  - Conflict resolution: Last-Write-Wins with per-track locking
  - All ops are broadcast to all connected clients
  - Server maintains authoritative project state

Transport: asyncio + websockets (stdlib-compatible fallback via http.server)

Usage (Host):
    server = CollabServer(project_service, port=9742)
    server.start()  # Non-blocking, runs in background thread
    share_url = server.get_share_url()

Usage (Client):
    client = CollabClient("ws://192.168.1.5:9742")
    client.connect(user_name="Bob")
    client.send_op({"type": "track_volume", "track_id": "trk_1", "volume": 0.7})
"""

from __future__ import annotations

import asyncio
import json
import logging
import socket
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Set

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Operation types
# ---------------------------------------------------------------------------

OP_SYNC = "sync"
OP_OPERATION = "op"
OP_CURSOR = "cursor"
OP_CHAT = "chat"
OP_LOCK = "lock"
OP_PRESENCE = "presence"
OP_ACK = "ack"
OP_ERROR = "error"

# Operation sub-types
OPS_TRACK = "track"
OPS_CLIP = "clip"
OPS_TRANSPORT = "transport"
OPS_MIXER = "mixer"
OPS_AUTOMATION = "automation"


@dataclass
class CollabUser:
    """Connected collaborator."""
    user_id: str = ""
    name: str = "Anonymous"
    color: str = "#4A9EFF"  # user color for cursors/highlights
    joined_at: str = ""
    cursor_beat: float = 0.0
    cursor_track: str = ""
    is_idle: bool = False
    locked_tracks: List[str] = field(default_factory=list)


@dataclass
class CollabMessage:
    """A message in the collab protocol."""
    type: str = ""           # OP_* constant
    user_id: str = ""
    user_name: str = ""
    timestamp: float = 0.0
    payload: Dict[str, Any] = field(default_factory=dict)
    seq: int = 0             # sequence number for ordering

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False)

    @classmethod
    def from_json(cls, data: str) -> "CollabMessage":
        d = json.loads(data)
        return cls(
            type=d.get("type", ""),
            user_id=d.get("user_id", ""),
            user_name=d.get("user_name", ""),
            timestamp=d.get("timestamp", 0.0),
            payload=d.get("payload", {}),
            seq=d.get("seq", 0),
        )


# ---------------------------------------------------------------------------
# User colors palette
# ---------------------------------------------------------------------------

_USER_COLORS = [
    "#4A9EFF",  # blue
    "#FF6B4A",  # orange-red
    "#4AFF6B",  # green
    "#FF4AE8",  # pink
    "#FFD74A",  # yellow
    "#4AFFF0",  # cyan
    "#B44AFF",  # purple
    "#FF9E4A",  # orange
]


# ---------------------------------------------------------------------------
# Collaboration Server
# ---------------------------------------------------------------------------

class CollabServer:
    """WebSocket server for real-time collaboration.

    Runs in a background thread. Manages connected users,
    broadcasts operations, handles track locking.
    """

    def __init__(self, project_service=None, port: int = 9742):
        self._project_service = project_service
        self._port = port
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None

        # Connected clients: user_id -> CollabUser
        self._users: Dict[str, CollabUser] = {}
        # WebSocket connections: user_id -> websocket
        self._connections: Dict[str, Any] = {}
        # Track locks: track_id -> user_id
        self._track_locks: Dict[str, str] = {}
        # Operation log (last N operations for late-joiners)
        self._op_log: List[CollabMessage] = []
        self._max_op_log = 500
        # Sequence counter
        self._seq = 0
        # Callbacks for the host UI
        self._on_user_joined: Optional[Callable] = None
        self._on_user_left: Optional[Callable] = None
        self._on_operation: Optional[Callable] = None
        self._on_chat: Optional[Callable] = None

        # Session info
        self._session_id = str(uuid.uuid4())[:8]
        self._session_name = "Py_DAW Session"
        self._session_password = ""  # empty = no password

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def set_session_name(self, name: str) -> None:
        self._session_name = name

    def set_password(self, password: str) -> None:
        self._session_password = password

    def set_callbacks(self, on_user_joined=None, on_user_left=None,
                      on_operation=None, on_chat=None) -> None:
        self._on_user_joined = on_user_joined
        self._on_user_left = on_user_left
        self._on_operation = on_operation
        self._on_chat = on_chat

    # ------------------------------------------------------------------
    # Server lifecycle
    # ------------------------------------------------------------------

    def start(self) -> bool:
        """Start the collaboration server in a background thread."""
        if self._running:
            return True

        try:
            import websockets  # noqa: F401
        except ImportError:
            log.warning("websockets package not installed — collab server unavailable. "
                        "Install with: pip install websockets")
            return False

        self._running = True
        self._thread = threading.Thread(
            target=self._run_server,
            name="CollabServer",
            daemon=True,
        )
        self._thread.start()
        log.info("Collab server starting on port %d (session: %s)",
                 self._port, self._session_id)
        return True

    def stop(self) -> None:
        """Stop the collaboration server."""
        self._running = False
        if self._loop:
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread:
            self._thread.join(timeout=3)
        self._connections.clear()
        self._users.clear()
        log.info("Collab server stopped")

    def is_running(self) -> bool:
        return self._running

    def _run_server(self) -> None:
        """Background thread: run asyncio event loop with websocket server."""
        try:
            import websockets
            import websockets.server

            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)

            start_server = websockets.serve(
                self._handle_client,
                "0.0.0.0",
                self._port,
            )
            self._loop.run_until_complete(start_server)
            log.info("Collab server listening on port %d", self._port)
            self._loop.run_forever()
        except Exception as e:
            log.error("Collab server error: %s", e)
        finally:
            self._running = False

    async def _handle_client(self, websocket, path=None) -> None:
        """Handle a single client connection."""
        user_id = ""
        try:
            # Wait for handshake
            raw = await asyncio.wait_for(websocket.recv(), timeout=10)
            msg = CollabMessage.from_json(raw)

            if msg.type != OP_PRESENCE:
                await websocket.send(CollabMessage(
                    type=OP_ERROR,
                    payload={"error": "Expected presence message"},
                ).to_json())
                return

            # Check password
            if self._session_password:
                if msg.payload.get("password") != self._session_password:
                    await websocket.send(CollabMessage(
                        type=OP_ERROR,
                        payload={"error": "Invalid password"},
                    ).to_json())
                    return

            # Register user
            user_id = msg.user_id or str(uuid.uuid4())[:8]
            user_name = msg.user_name or "Anonymous"
            color_idx = len(self._users) % len(_USER_COLORS)
            user = CollabUser(
                user_id=user_id,
                name=user_name,
                color=_USER_COLORS[color_idx],
                joined_at=datetime.utcnow().isoformat(),
            )
            self._users[user_id] = user
            self._connections[user_id] = websocket

            # Send initial sync
            await self._send_initial_sync(websocket, user)

            # Notify others
            await self._broadcast(CollabMessage(
                type=OP_PRESENCE,
                user_id=user_id,
                user_name=user_name,
                payload={"action": "joined", "color": user.color},
            ), exclude=user_id)

            if self._on_user_joined:
                try:
                    self._on_user_joined(user)
                except Exception:
                    pass

            log.info("User '%s' (%s) joined collab session", user_name, user_id)

            # Main message loop
            async for raw in websocket:
                try:
                    msg = CollabMessage.from_json(raw)
                    msg.user_id = user_id
                    msg.user_name = user_name
                    await self._process_message(msg, user_id)
                except json.JSONDecodeError:
                    pass
                except Exception as e:
                    log.warning("Collab message error from %s: %s", user_id, e)

        except Exception as e:
            log.debug("Collab client disconnected: %s", e)
        finally:
            # Cleanup
            if user_id:
                self._connections.pop(user_id, None)
                user = self._users.pop(user_id, None)
                # Release locks
                self._track_locks = {
                    tid: uid for tid, uid in self._track_locks.items()
                    if uid != user_id
                }
                # Notify others
                try:
                    asyncio.ensure_future(self._broadcast(CollabMessage(
                        type=OP_PRESENCE,
                        user_id=user_id,
                        user_name=user.name if user else "?",
                        payload={"action": "left"},
                    ), exclude=user_id))
                except Exception:
                    pass

                if self._on_user_left and user:
                    try:
                        self._on_user_left(user)
                    except Exception:
                        pass
                log.info("User '%s' left collab session", user_id)

    async def _send_initial_sync(self, websocket, user: CollabUser) -> None:
        """Send full project state + user list to a newly connected client."""
        project_data = {}
        if self._project_service:
            try:
                proj = getattr(self._project_service, 'ctx', None)
                if proj:
                    project_obj = getattr(proj, 'project', None)
                    if project_obj and hasattr(project_obj, 'to_dict'):
                        project_data = project_obj.to_dict()
            except Exception:
                pass

        # User list
        users_list = [asdict(u) for u in self._users.values()]

        await websocket.send(CollabMessage(
            type=OP_SYNC,
            user_id="server",
            payload={
                "project": project_data,
                "users": users_list,
                "your_user": asdict(user),
                "session_id": self._session_id,
                "session_name": self._session_name,
                "track_locks": dict(self._track_locks),
            },
        ).to_json())

    async def _process_message(self, msg: CollabMessage, sender_id: str) -> None:
        """Process an incoming message from a client."""
        if msg.type == OP_OPERATION:
            # Check track lock
            track_id = msg.payload.get("track_id", "")
            if track_id and track_id in self._track_locks:
                lock_owner = self._track_locks[track_id]
                if lock_owner != sender_id:
                    await self._send_to(sender_id, CollabMessage(
                        type=OP_ERROR,
                        payload={"error": f"Track locked by {self._users.get(lock_owner, CollabUser()).name}"},
                    ))
                    return

            # Apply operation to local project
            self._apply_operation(msg)

            # Broadcast to all (including sender for confirmation)
            self._seq += 1
            msg.seq = self._seq
            msg.timestamp = time.time()
            self._op_log.append(msg)
            if len(self._op_log) > self._max_op_log:
                self._op_log = self._op_log[-self._max_op_log:]

            await self._broadcast(msg)

            if self._on_operation:
                try:
                    self._on_operation(msg)
                except Exception:
                    pass

        elif msg.type == OP_CURSOR:
            # Update cursor position
            user = self._users.get(sender_id)
            if user:
                user.cursor_beat = float(msg.payload.get("beat", 0))
                user.cursor_track = str(msg.payload.get("track_id", ""))
            # Broadcast to others (not sender)
            await self._broadcast(msg, exclude=sender_id)

        elif msg.type == OP_CHAT:
            msg.timestamp = time.time()
            await self._broadcast(msg)
            if self._on_chat:
                try:
                    self._on_chat(msg)
                except Exception:
                    pass

        elif msg.type == OP_LOCK:
            action = msg.payload.get("action", "")
            track_id = msg.payload.get("track_id", "")
            if action == "acquire" and track_id:
                if track_id not in self._track_locks:
                    self._track_locks[track_id] = sender_id
                    await self._broadcast(CollabMessage(
                        type=OP_LOCK,
                        user_id=sender_id,
                        user_name=msg.user_name,
                        payload={"action": "acquired", "track_id": track_id},
                    ))
                else:
                    owner = self._track_locks[track_id]
                    await self._send_to(sender_id, CollabMessage(
                        type=OP_ERROR,
                        payload={"error": f"Track already locked by {self._users.get(owner, CollabUser()).name}"},
                    ))
            elif action == "release" and track_id:
                if self._track_locks.get(track_id) == sender_id:
                    del self._track_locks[track_id]
                    await self._broadcast(CollabMessage(
                        type=OP_LOCK,
                        user_id=sender_id,
                        payload={"action": "released", "track_id": track_id},
                    ))

        elif msg.type == OP_PRESENCE:
            action = msg.payload.get("action", "")
            if action == "idle":
                user = self._users.get(sender_id)
                if user:
                    user.is_idle = True
                await self._broadcast(msg, exclude=sender_id)
            elif action == "active":
                user = self._users.get(sender_id)
                if user:
                    user.is_idle = False
                await self._broadcast(msg, exclude=sender_id)

    def _apply_operation(self, msg: CollabMessage) -> None:
        """Apply an operation to the host's project (server-side)."""
        if not self._project_service:
            return
        try:
            payload = msg.payload
            op_type = payload.get("op_type", "")

            ctx = getattr(self._project_service, 'ctx', None)
            if not ctx:
                return
            project = getattr(ctx, 'project', None)
            if not project:
                return

            if op_type == "track_volume":
                tid = payload.get("track_id", "")
                vol = float(payload.get("volume", 0.8))
                for t in (project.tracks or []):
                    if str(getattr(t, 'id', '')) == tid:
                        t.volume = vol
                        break

            elif op_type == "track_pan":
                tid = payload.get("track_id", "")
                pan = float(payload.get("pan", 0.0))
                for t in (project.tracks or []):
                    if str(getattr(t, 'id', '')) == tid:
                        t.pan = pan
                        break

            elif op_type == "track_mute":
                tid = payload.get("track_id", "")
                muted = bool(payload.get("muted", False))
                for t in (project.tracks or []):
                    if str(getattr(t, 'id', '')) == tid:
                        t.muted = muted
                        break

            elif op_type == "track_solo":
                tid = payload.get("track_id", "")
                solo = bool(payload.get("solo", False))
                for t in (project.tracks or []):
                    if str(getattr(t, 'id', '')) == tid:
                        t.solo = solo
                        break

            elif op_type == "transport_bpm":
                bpm = float(payload.get("bpm", 120.0))
                project.bpm = bpm

            elif op_type == "clip_move":
                cid = payload.get("clip_id", "")
                start = float(payload.get("start_beats", 0))
                for c in (project.clips or []):
                    if str(getattr(c, 'id', '')) == cid:
                        c.start_beats = start
                        break

            elif op_type == "track_name":
                tid = payload.get("track_id", "")
                name = str(payload.get("name", ""))
                for t in (project.tracks or []):
                    if str(getattr(t, 'id', '')) == tid:
                        t.name = name
                        break

        except Exception as e:
            log.warning("Failed to apply collab operation: %s", e)

    async def _broadcast(self, msg: CollabMessage, exclude: str = "") -> None:
        """Send message to all connected clients."""
        data = msg.to_json()
        disconnected = []
        for uid, ws in self._connections.items():
            if uid == exclude:
                continue
            try:
                await ws.send(data)
            except Exception:
                disconnected.append(uid)
        for uid in disconnected:
            self._connections.pop(uid, None)
            self._users.pop(uid, None)

    async def _send_to(self, user_id: str, msg: CollabMessage) -> None:
        """Send message to a specific client."""
        ws = self._connections.get(user_id)
        if ws:
            try:
                await ws.send(msg.to_json())
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_share_url(self) -> str:
        """Get the WebSocket URL for clients to connect."""
        hostname = self._get_local_ip()
        return f"ws://{hostname}:{self._port}"

    def get_connected_users(self) -> List[CollabUser]:
        """Get list of connected users."""
        return list(self._users.values())

    def get_session_info(self) -> Dict[str, Any]:
        """Get session metadata."""
        return {
            "session_id": self._session_id,
            "session_name": self._session_name,
            "port": self._port,
            "url": self.get_share_url(),
            "users": len(self._users),
            "has_password": bool(self._session_password),
        }

    def _get_local_ip(self) -> str:
        """Get the local network IP address."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"


# ---------------------------------------------------------------------------
# Collaboration Client
# ---------------------------------------------------------------------------

class CollabClient:
    """WebSocket client for connecting to a collaboration session.

    Runs in a background thread. Receives operations and applies
    them to the local project.
    """

    def __init__(self):
        self._url: str = ""
        self._user_id: str = str(uuid.uuid4())[:8]
        self._user_name: str = "User"
        self._connected: bool = False
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._websocket: Any = None

        # Session state received from server
        self._session_info: Dict[str, Any] = {}
        self._remote_users: Dict[str, CollabUser] = {}

        # Callbacks
        self._on_connected: Optional[Callable] = None
        self._on_disconnected: Optional[Callable] = None
        self._on_sync: Optional[Callable] = None
        self._on_operation: Optional[Callable] = None
        self._on_cursor: Optional[Callable] = None
        self._on_chat: Optional[Callable] = None
        self._on_presence: Optional[Callable] = None
        self._on_lock: Optional[Callable] = None
        self._on_error: Optional[Callable] = None

        # Pending outgoing messages
        self._send_queue: list = []

    def set_callbacks(self, **kwargs) -> None:
        """Set callback functions for events."""
        for key, val in kwargs.items():
            attr = f"_on_{key}"
            if hasattr(self, attr):
                setattr(self, attr, val)

    def connect(self, url: str, user_name: str = "User",
                password: str = "") -> bool:
        """Connect to a collaboration server."""
        if self._connected:
            return True

        try:
            import websockets  # noqa: F401
        except ImportError:
            log.warning("websockets package not installed")
            return False

        self._url = url
        self._user_name = user_name
        self._password = password
        self._connected = False

        self._thread = threading.Thread(
            target=self._run_client,
            name="CollabClient",
            daemon=True,
        )
        self._thread.start()

        # Wait for connection (up to 5 seconds)
        for _ in range(50):
            if self._connected:
                return True
            time.sleep(0.1)

        return self._connected

    def disconnect(self) -> None:
        """Disconnect from the collaboration server."""
        self._connected = False
        if self._loop:
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread:
            self._thread.join(timeout=3)
        self._websocket = None
        if self._on_disconnected:
            try:
                self._on_disconnected()
            except Exception:
                pass

    def is_connected(self) -> bool:
        return self._connected

    def _run_client(self) -> None:
        """Background thread: connect and receive messages."""
        try:
            import websockets.client

            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
            self._loop.run_until_complete(self._connect_and_listen())
        except Exception as e:
            log.error("Collab client error: %s", e)
        finally:
            self._connected = False

    async def _connect_and_listen(self) -> None:
        """Async: connect, handshake, listen for messages."""
        import websockets

        try:
            async with websockets.connect(self._url) as ws:
                self._websocket = ws

                # Send handshake
                handshake = CollabMessage(
                    type=OP_PRESENCE,
                    user_id=self._user_id,
                    user_name=self._user_name,
                    payload={
                        "action": "join",
                        "password": getattr(self, '_password', ''),
                    },
                )
                await ws.send(handshake.to_json())

                self._connected = True
                if self._on_connected:
                    try:
                        self._on_connected()
                    except Exception:
                        pass

                # Listen for messages
                async for raw in ws:
                    try:
                        msg = CollabMessage.from_json(raw)
                        self._handle_message(msg)
                    except json.JSONDecodeError:
                        pass
                    except Exception as e:
                        log.warning("Collab message handling error: %s", e)

        except Exception as e:
            log.error("Collab connection failed: %s", e)

    def _handle_message(self, msg: CollabMessage) -> None:
        """Process a message from the server."""
        if msg.type == OP_SYNC:
            self._session_info = msg.payload
            if self._on_sync:
                try:
                    self._on_sync(msg.payload)
                except Exception:
                    pass

        elif msg.type == OP_OPERATION:
            if self._on_operation:
                try:
                    self._on_operation(msg)
                except Exception:
                    pass

        elif msg.type == OP_CURSOR:
            if self._on_cursor:
                try:
                    self._on_cursor(msg)
                except Exception:
                    pass

        elif msg.type == OP_CHAT:
            if self._on_chat:
                try:
                    self._on_chat(msg)
                except Exception:
                    pass

        elif msg.type == OP_PRESENCE:
            action = msg.payload.get("action", "")
            if action == "joined":
                user = CollabUser(
                    user_id=msg.user_id,
                    name=msg.user_name,
                    color=msg.payload.get("color", "#4A9EFF"),
                )
                self._remote_users[msg.user_id] = user
            elif action == "left":
                self._remote_users.pop(msg.user_id, None)

            if self._on_presence:
                try:
                    self._on_presence(msg)
                except Exception:
                    pass

        elif msg.type == OP_LOCK:
            if self._on_lock:
                try:
                    self._on_lock(msg)
                except Exception:
                    pass

        elif msg.type == OP_ERROR:
            if self._on_error:
                try:
                    self._on_error(msg.payload.get("error", "Unknown error"))
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # Send operations
    # ------------------------------------------------------------------

    def send_op(self, payload: Dict[str, Any]) -> None:
        """Send an operation to the server."""
        if not self._connected or not self._websocket:
            return
        msg = CollabMessage(
            type=OP_OPERATION,
            user_id=self._user_id,
            user_name=self._user_name,
            timestamp=time.time(),
            payload=payload,
        )
        self._send_async(msg)

    def send_cursor(self, beat: float, track_id: str = "") -> None:
        """Send cursor position update."""
        if not self._connected or not self._websocket:
            return
        msg = CollabMessage(
            type=OP_CURSOR,
            user_id=self._user_id,
            payload={"beat": beat, "track_id": track_id},
        )
        self._send_async(msg)

    def send_chat(self, text: str) -> None:
        """Send a chat message."""
        if not self._connected or not self._websocket:
            return
        msg = CollabMessage(
            type=OP_CHAT,
            user_id=self._user_id,
            user_name=self._user_name,
            timestamp=time.time(),
            payload={"text": text},
        )
        self._send_async(msg)

    def request_lock(self, track_id: str) -> None:
        """Request an edit lock on a track."""
        if not self._connected or not self._websocket:
            return
        msg = CollabMessage(
            type=OP_LOCK,
            user_id=self._user_id,
            payload={"action": "acquire", "track_id": track_id},
        )
        self._send_async(msg)

    def release_lock(self, track_id: str) -> None:
        """Release an edit lock on a track."""
        if not self._connected or not self._websocket:
            return
        msg = CollabMessage(
            type=OP_LOCK,
            user_id=self._user_id,
            payload={"action": "release", "track_id": track_id},
        )
        self._send_async(msg)

    def _send_async(self, msg: CollabMessage) -> None:
        """Thread-safe send via asyncio."""
        if self._loop and self._websocket:
            try:
                asyncio.run_coroutine_threadsafe(
                    self._websocket.send(msg.to_json()),
                    self._loop,
                )
            except Exception:
                pass

    def get_remote_users(self) -> List[CollabUser]:
        """Get list of other connected users."""
        return list(self._remote_users.values())
