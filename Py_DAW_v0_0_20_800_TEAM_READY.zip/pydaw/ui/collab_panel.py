"""Collaboration Panel — Dock-Widget für Py_DAW (Phase 5A)

v0.0.20.797 — Echtzeit-Kollaboration, Git-Integration, Review-Mode

Tabs:
  🔀 Git     — Branch, Commit, History, Push/Pull
  👥 Collab  — Server starten/verbinden, User-Liste, Chat
  📝 Review  — Kommentare, Marker, Tasks
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from PyQt6.QtCore import QSettings, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QComboBox, QDockWidget, QFrame, QGroupBox, QHBoxLayout, QInputDialog,
    QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox,
    QPlainTextEdit, QPushButton, QSizePolicy, QSpinBox, QSplitter,
    QTabWidget, QTextEdit, QVBoxLayout, QWidget,
)

log = logging.getLogger(__name__)


class CollabPanel(QWidget):
    """Main collaboration panel with Git / Collab / Review tabs."""

    status_message = pyqtSignal(str, int)  # message, timeout_ms

    def __init__(self, parent=None, project_service=None):
        super().__init__(parent)
        self._project_service = project_service
        self._git_service = None
        self._collab_server = None
        self._collab_client = None
        self._review_service = None

        self._init_ui()

    def set_services(self, git_service=None, collab_server=None,
                     collab_client=None, review_service=None) -> None:
        """Wire up backend services."""
        self._git_service = git_service
        self._collab_server = collab_server
        self._collab_client = collab_client
        self._review_service = review_service

    # ------------------------------------------------------------------
    # UI Setup
    # ------------------------------------------------------------------

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)

        self._tabs = QTabWidget()
        self._tabs.setTabPosition(QTabWidget.TabPosition.North)

        # Tab 1: Git
        self._git_tab = self._create_git_tab()
        self._tabs.addTab(self._git_tab, "🔀 Git")

        # Tab 2: Collaboration
        self._collab_tab = self._create_collab_tab()
        self._tabs.addTab(self._collab_tab, "👥 Collab")

        # Tab 3: Review
        self._review_tab = self._create_review_tab()
        self._tabs.addTab(self._review_tab, "📝 Review")

        layout.addWidget(self._tabs)

    # ------------------------------------------------------------------
    # Git Tab
    # ------------------------------------------------------------------

    def _create_git_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(6)

        # Status bar
        status_frame = QFrame()
        status_frame.setFrameShape(QFrame.Shape.StyledPanel)
        sl = QHBoxLayout(status_frame)
        sl.setContentsMargins(6, 4, 6, 4)
        self._git_status_label = QLabel("Git: nicht initialisiert")
        self._git_status_label.setStyleSheet("font-weight: bold;")
        sl.addWidget(self._git_status_label)
        sl.addStretch()
        self._git_branch_label = QLabel("")
        self._git_branch_label.setStyleSheet("color: #4A9EFF;")
        sl.addWidget(self._git_branch_label)
        layout.addWidget(status_frame)

        # Init / Branch row
        row1 = QHBoxLayout()
        self._btn_git_init = QPushButton("🔧 Git Init")
        self._btn_git_init.setToolTip("Git-Repository im Projektordner initialisieren")
        self._btn_git_init.clicked.connect(self._on_git_init)
        row1.addWidget(self._btn_git_init)

        self._branch_combo = QComboBox()
        self._branch_combo.setMinimumWidth(120)
        self._branch_combo.currentTextChanged.connect(self._on_branch_changed)
        row1.addWidget(QLabel("Branch:"))
        row1.addWidget(self._branch_combo)

        self._btn_new_branch = QPushButton("+ Branch")
        self._btn_new_branch.clicked.connect(self._on_new_branch)
        row1.addWidget(self._btn_new_branch)
        layout.addLayout(row1)

        # Commit row
        row2 = QHBoxLayout()
        self._commit_msg = QLineEdit()
        self._commit_msg.setPlaceholderText("Commit-Nachricht (leer = auto)")
        row2.addWidget(self._commit_msg)
        self._btn_commit = QPushButton("💾 Commit")
        self._btn_commit.clicked.connect(self._on_commit)
        self._btn_commit.setStyleSheet("background-color: #2D5A27; color: white;")
        row2.addWidget(self._btn_commit)
        layout.addLayout(row2)

        # Push / Pull row
        row3 = QHBoxLayout()
        self._btn_push = QPushButton("⬆️ Push")
        self._btn_push.clicked.connect(self._on_push)
        row3.addWidget(self._btn_push)
        self._btn_pull = QPushButton("⬇️ Pull")
        self._btn_pull.clicked.connect(self._on_pull)
        row3.addWidget(self._btn_pull)
        self._btn_merge = QPushButton("🔀 Merge")
        self._btn_merge.clicked.connect(self._on_merge)
        row3.addWidget(self._btn_merge)
        self._btn_stash = QPushButton("📦 Stash")
        self._btn_stash.clicked.connect(self._on_stash)
        row3.addWidget(self._btn_stash)
        layout.addLayout(row3)

        # History list
        layout.addWidget(QLabel("Commit-History:"))
        self._git_history = QListWidget()
        self._git_history.setMaximumHeight(200)
        self._git_history.setAlternatingRowColors(True)
        layout.addWidget(self._git_history)

        # Remote setup
        remote_group = QGroupBox("Remote (GitHub/GitLab)")
        rl = QHBoxLayout(remote_group)
        self._remote_url = QLineEdit()
        self._remote_url.setPlaceholderText("https://github.com/user/project.git")
        rl.addWidget(self._remote_url)
        self._btn_add_remote = QPushButton("Hinzufügen")
        self._btn_add_remote.clicked.connect(self._on_add_remote)
        rl.addWidget(self._btn_add_remote)
        layout.addWidget(remote_group)

        layout.addStretch()
        return w

    # ------------------------------------------------------------------
    # Collab Tab
    # ------------------------------------------------------------------

    def _create_collab_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(6)

        # Host / Join
        host_group = QGroupBox("Session")
        hl = QVBoxLayout(host_group)

        row_host = QHBoxLayout()
        self._btn_host = QPushButton("🌐 Session starten")
        self._btn_host.clicked.connect(self._on_host_session)
        self._btn_host.setStyleSheet("background-color: #1A5276; color: white;")
        row_host.addWidget(self._btn_host)
        self._btn_stop_host = QPushButton("⏹️ Stoppen")
        self._btn_stop_host.clicked.connect(self._on_stop_session)
        self._btn_stop_host.setEnabled(False)
        row_host.addWidget(self._btn_stop_host)
        hl.addLayout(row_host)

        row_join = QHBoxLayout()
        self._join_url = QLineEdit()
        self._join_url.setPlaceholderText("ws://192.168.1.5:9742")
        row_join.addWidget(self._join_url)
        self._btn_join = QPushButton("🔗 Verbinden")
        self._btn_join.clicked.connect(self._on_join_session)
        row_join.addWidget(self._btn_join)
        hl.addLayout(row_join)

        self._collab_status = QLabel("Nicht verbunden")
        self._collab_status.setStyleSheet("color: #888;")
        hl.addWidget(self._collab_status)
        self._share_url_label = QLabel("")
        self._share_url_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse)
        hl.addWidget(self._share_url_label)

        layout.addWidget(host_group)

        # Connected users
        layout.addWidget(QLabel("👥 Verbundene User:"))
        self._user_list = QListWidget()
        self._user_list.setMaximumHeight(120)
        layout.addWidget(self._user_list)

        # Chat
        layout.addWidget(QLabel("💬 Chat:"))
        self._chat_display = QTextEdit()
        self._chat_display.setReadOnly(True)
        self._chat_display.setMaximumHeight(150)
        self._chat_display.setStyleSheet("background-color: #1E1E1E; color: #DDD;")
        layout.addWidget(self._chat_display)

        row_chat = QHBoxLayout()
        self._chat_input = QLineEdit()
        self._chat_input.setPlaceholderText("Nachricht eingeben...")
        self._chat_input.returnPressed.connect(self._on_send_chat)
        row_chat.addWidget(self._chat_input)
        self._btn_send_chat = QPushButton("Senden")
        self._btn_send_chat.clicked.connect(self._on_send_chat)
        row_chat.addWidget(self._btn_send_chat)
        layout.addLayout(row_chat)

        layout.addStretch()
        return w

    # ------------------------------------------------------------------
    # Review Tab
    # ------------------------------------------------------------------

    def _create_review_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(6)

        # Stats
        self._review_stats = QLabel("Keine Review-Daten")
        self._review_stats.setStyleSheet("font-weight: bold;")
        layout.addWidget(self._review_stats)

        # Add comment
        comment_group = QGroupBox("💬 Kommentar hinzufügen")
        cl = QVBoxLayout(comment_group)
        self._comment_text = QLineEdit()
        self._comment_text.setPlaceholderText("Kommentar eingeben...")
        cl.addWidget(self._comment_text)
        row_comment = QHBoxLayout()
        row_comment.addWidget(QLabel("Beat:"))
        self._comment_beat = QSpinBox()
        self._comment_beat.setRange(-1, 9999)
        self._comment_beat.setValue(-1)
        self._comment_beat.setSpecialValueText("Allgemein")
        row_comment.addWidget(self._comment_beat)
        self._btn_add_comment = QPushButton("➕ Kommentar")
        self._btn_add_comment.clicked.connect(self._on_add_comment)
        row_comment.addWidget(self._btn_add_comment)
        cl.addLayout(row_comment)
        layout.addWidget(comment_group)

        # Add task
        task_group = QGroupBox("✅ Aufgabe hinzufügen")
        tl = QHBoxLayout(task_group)
        self._task_text = QLineEdit()
        self._task_text.setPlaceholderText("Aufgabe beschreiben...")
        tl.addWidget(self._task_text)
        self._task_assignee = QLineEdit()
        self._task_assignee.setPlaceholderText("Zuweisen an...")
        self._task_assignee.setMaximumWidth(120)
        tl.addWidget(self._task_assignee)
        self._btn_add_task = QPushButton("➕")
        self._btn_add_task.clicked.connect(self._on_add_task)
        tl.addWidget(self._btn_add_task)
        layout.addWidget(task_group)

        # Comments list
        layout.addWidget(QLabel("Offene Kommentare:"))
        self._comment_list = QListWidget()
        self._comment_list.setMaximumHeight(150)
        self._comment_list.setAlternatingRowColors(True)
        layout.addWidget(self._comment_list)

        # Actions
        row_actions = QHBoxLayout()
        self._btn_resolve = QPushButton("✅ Lösen")
        self._btn_resolve.clicked.connect(self._on_resolve_comment)
        row_actions.addWidget(self._btn_resolve)
        self._btn_export_review = QPushButton("📋 Export")
        self._btn_export_review.clicked.connect(self._on_export_review)
        row_actions.addWidget(self._btn_export_review)
        self._btn_clear_resolved = QPushButton("🗑️ Gelöste entfernen")
        self._btn_clear_resolved.clicked.connect(self._on_clear_resolved)
        row_actions.addWidget(self._btn_clear_resolved)
        layout.addLayout(row_actions)

        layout.addStretch()
        return w

    # ------------------------------------------------------------------
    # Git Actions
    # ------------------------------------------------------------------

    def _on_git_init(self) -> None:
        gs = self._git_service
        if not gs:
            self.status_message.emit("Git Service nicht verfügbar", 3000)
            return
        if gs.init():
            self.status_message.emit("Git Repository initialisiert ✅", 3000)
            self.refresh_git()
        else:
            self.status_message.emit("Git Init fehlgeschlagen", 3000)

    def _on_commit(self) -> None:
        gs = self._git_service
        if not gs:
            return
        msg = self._commit_msg.text().strip()
        result = gs.commit(message=msg)
        if result:
            self.status_message.emit(
                f"Commit: {result.hash_short} — {result.message[:40]}", 3000)
            self._commit_msg.clear()
            self.refresh_git()
        else:
            self.status_message.emit("Nichts zu committen", 2000)

    def _on_branch_changed(self, name: str) -> None:
        gs = self._git_service
        if not gs or not name:
            return
        current = gs.current_branch()
        if name != current:
            gs.switch_branch(name)
            self.refresh_git()

    def _on_new_branch(self) -> None:
        gs = self._git_service
        if not gs:
            return
        name, ok = QInputDialog.getText(self, "Neuer Branch",
                                         "Branch-Name:", QLineEdit.EchoMode.Normal)
        if ok and name.strip():
            if gs.create_branch(name.strip()):
                self.status_message.emit(f"Branch '{name}' erstellt", 3000)
                self.refresh_git()

    def _on_push(self) -> None:
        gs = self._git_service
        if not gs:
            return
        ok, msg = gs.push(set_upstream=True)
        self.status_message.emit(msg, 3000)

    def _on_pull(self) -> None:
        gs = self._git_service
        if not gs:
            return
        ok, msg = gs.pull()
        self.status_message.emit(msg, 3000)
        if ok:
            self.refresh_git()

    def _on_merge(self) -> None:
        gs = self._git_service
        if not gs:
            return
        branches = gs.list_branches()
        current = gs.current_branch()
        other = [b.name for b in branches if b.name != current]
        if not other:
            self.status_message.emit("Kein anderer Branch zum Mergen", 2000)
            return
        name, ok = QInputDialog.getItem(
            self, "Branch mergen", "Branch auswählen:", other, 0, False)
        if ok and name:
            result = gs.merge_branch(name)
            if result.success:
                self.status_message.emit(f"✅ {result.message}", 3000)
            else:
                self.status_message.emit(f"⚠️ {result.message}", 5000)
            self.refresh_git()

    def _on_stash(self) -> None:
        gs = self._git_service
        if not gs:
            return
        stashes = gs.stash_list()
        if stashes:
            ok, msg = gs.stash_pop()
            self.status_message.emit(msg, 3000)
        else:
            gs.stash("Quick stash")
            self.status_message.emit("Changes stashed 📦", 2000)

    def _on_add_remote(self) -> None:
        gs = self._git_service
        if not gs:
            return
        url = self._remote_url.text().strip()
        if url:
            if gs.add_remote(url):
                self.status_message.emit(f"Remote hinzugefügt: {url}", 3000)
            else:
                self.status_message.emit("Remote hinzufügen fehlgeschlagen", 3000)

    # ------------------------------------------------------------------
    # Collab Actions
    # ------------------------------------------------------------------

    def _on_host_session(self) -> None:
        if not self._collab_server:
            from pydaw.services.collab_service import CollabServer
            self._collab_server = CollabServer(
                project_service=self._project_service,
                port=9742,
            )
        server = self._collab_server
        server.set_callbacks(
            on_user_joined=lambda u: self._refresh_users_safe(),
            on_user_left=lambda u: self._refresh_users_safe(),
            on_chat=lambda m: self._append_chat_safe(m),
        )
        if server.start():
            url = server.get_share_url()
            self._collab_status.setText(f"🟢 Session aktiv auf Port {server._port}")
            self._collab_status.setStyleSheet("color: #4AFF6B; font-weight: bold;")
            self._share_url_label.setText(f"Share-URL: {url}")
            self._btn_host.setEnabled(False)
            self._btn_stop_host.setEnabled(True)
            self.status_message.emit(f"Collab Session gestartet: {url}", 5000)
        else:
            self.status_message.emit(
                "Collab Server Fehler — pip install websockets?", 5000)

    def _on_stop_session(self) -> None:
        if self._collab_server:
            self._collab_server.stop()
        self._collab_status.setText("Nicht verbunden")
        self._collab_status.setStyleSheet("color: #888;")
        self._share_url_label.setText("")
        self._btn_host.setEnabled(True)
        self._btn_stop_host.setEnabled(False)
        self._user_list.clear()

    def _on_join_session(self) -> None:
        url = self._join_url.text().strip()
        if not url:
            return
        if not self._collab_client:
            from pydaw.services.collab_service import CollabClient
            self._collab_client = CollabClient()
        client = self._collab_client
        client.set_callbacks(
            connected=lambda: self._on_client_connected(),
            disconnected=lambda: self._on_client_disconnected(),
            chat=lambda m: self._append_chat_safe(m),
            presence=lambda m: self._refresh_users_safe(),
        )
        name, ok = QInputDialog.getText(self, "Dein Name", "Name:", text="User")
        if not ok:
            return
        if client.connect(url, user_name=name or "User"):
            self._collab_status.setText(f"🟢 Verbunden mit {url}")
            self._collab_status.setStyleSheet("color: #4AFF6B; font-weight: bold;")
            self.status_message.emit(f"Verbunden mit {url}", 3000)
        else:
            self.status_message.emit("Verbindung fehlgeschlagen", 3000)

    def _on_client_connected(self) -> None:
        try:
            self._collab_status.setText("🟢 Verbunden")
            self._collab_status.setStyleSheet("color: #4AFF6B; font-weight: bold;")
        except Exception:
            pass

    def _on_client_disconnected(self) -> None:
        try:
            self._collab_status.setText("🔴 Getrennt")
            self._collab_status.setStyleSheet("color: #FF4444;")
        except Exception:
            pass

    def _on_send_chat(self) -> None:
        text = self._chat_input.text().strip()
        if not text:
            return
        if self._collab_client and self._collab_client.is_connected():
            self._collab_client.send_chat(text)
        elif self._collab_server and self._collab_server.is_running():
            # Host sends to all
            from pydaw.services.collab_service import CollabMessage, OP_CHAT
            import time
            msg = CollabMessage(type=OP_CHAT, user_id="host",
                                user_name="Host", timestamp=time.time(),
                                payload={"text": text})
            self._append_chat(msg)
        self._chat_input.clear()

    def _append_chat_safe(self, msg) -> None:
        """Thread-safe chat append via QTimer."""
        try:
            QTimer.singleShot(0, lambda: self._append_chat(msg))
        except Exception:
            pass

    def _append_chat(self, msg) -> None:
        try:
            text = msg.payload.get("text", "") if hasattr(msg, 'payload') else str(msg)
            name = getattr(msg, 'user_name', '?')
            self._chat_display.append(f"<b>{name}:</b> {text}")
        except Exception:
            pass

    def _refresh_users_safe(self) -> None:
        try:
            QTimer.singleShot(0, self._refresh_users)
        except Exception:
            pass

    def _refresh_users(self) -> None:
        self._user_list.clear()
        users = []
        if self._collab_server and self._collab_server.is_running():
            users = self._collab_server.get_connected_users()
        elif self._collab_client and self._collab_client.is_connected():
            users = self._collab_client.get_remote_users()
        for u in users:
            item = QListWidgetItem(f"● {u.name}")
            item.setForeground(QColor(u.color))
            self._user_list.addItem(item)

    # ------------------------------------------------------------------
    # Review Actions
    # ------------------------------------------------------------------

    def _on_add_comment(self) -> None:
        rs = self._review_service
        if not rs:
            return
        text = self._comment_text.text().strip()
        if not text:
            return
        beat = float(self._comment_beat.value())
        rs.add_comment(text=text, beat=beat)
        self._comment_text.clear()
        self.refresh_review()

    def _on_add_task(self) -> None:
        rs = self._review_service
        if not rs:
            return
        text = self._task_text.text().strip()
        if not text:
            return
        assignee = self._task_assignee.text().strip()
        rs.add_task(text=text, assignee=assignee)
        self._task_text.clear()
        self.refresh_review()

    def _on_resolve_comment(self) -> None:
        rs = self._review_service
        if not rs:
            return
        item = self._comment_list.currentItem()
        if not item:
            return
        comment_id = item.data(Qt.ItemDataRole.UserRole)
        if comment_id:
            rs.resolve_comment(comment_id)
            self.refresh_review()

    def _on_export_review(self) -> None:
        rs = self._review_service
        if not rs:
            return
        summary = rs.export_summary()
        # Show in a dialog
        dlg = QMessageBox(self)
        dlg.setWindowTitle("Review Summary")
        dlg.setText(summary[:500])
        dlg.setDetailedText(summary)
        dlg.exec()

    def _on_clear_resolved(self) -> None:
        rs = self._review_service
        if not rs:
            return
        rs.clear_resolved()
        self.refresh_review()

    # ------------------------------------------------------------------
    # Refresh methods
    # ------------------------------------------------------------------

    def refresh_git(self) -> None:
        """Update Git tab UI from current state."""
        gs = self._git_service
        if not gs or not gs.is_repo_initialized():
            self._git_status_label.setText("Git: nicht initialisiert")
            self._git_branch_label.setText("")
            self._git_history.clear()
            return

        status = gs.get_status()
        clean = "✅ clean" if status.is_clean else f"⚠️ {len(status.modified)} geändert"
        self._git_status_label.setText(f"Git: {clean}")
        self._git_branch_label.setText(f"🔀 {status.branch}")

        # Update branch combo
        branches = gs.list_branches()
        self._branch_combo.blockSignals(True)
        self._branch_combo.clear()
        for b in branches:
            self._branch_combo.addItem(b.name)
            if b.is_current:
                self._branch_combo.setCurrentText(b.name)
        self._branch_combo.blockSignals(False)

        # Update history
        self._git_history.clear()
        commits = gs.get_log(max_count=20)
        for c in commits:
            self._git_history.addItem(
                f"{c.hash_short}  {c.date[:10]}  {c.message[:50]}")

        # Remote
        if status.has_remote:
            self._remote_url.setText(status.remote_url)

    def refresh_review(self) -> None:
        """Update Review tab UI from current state."""
        rs = self._review_service
        if not rs:
            return

        stats = rs.get_stats()
        self._review_stats.setText(
            f"💬 {stats['comments_open']} offen  "
            f"✅ {stats['comments_resolved']} gelöst  "
            f"📋 {stats['tasks_open']} Tasks  "
            f"🏁 {stats['markers']} Marker"
        )

        # Comments
        self._comment_list.clear()
        for c in rs.get_comments(status="open"):
            pos = f"Beat {c.beat:.0f}" if c.beat >= 0 else "📌"
            item = QListWidgetItem(f"{pos} — {c.text[:60]}  [{c.author}]")
            item.setData(Qt.ItemDataRole.UserRole, c.id)
            self._comment_list.addItem(item)

    def refresh_all(self) -> None:
        """Refresh all tabs."""
        try:
            self.refresh_git()
        except Exception:
            pass
        try:
            self.refresh_review()
        except Exception:
            pass
