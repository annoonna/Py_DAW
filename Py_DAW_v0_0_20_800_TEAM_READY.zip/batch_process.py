#!/usr/bin/env python3
"""Py_DAW Batch Processing CLI — Headless project automation.

v0.0.20.800 — Phase 6A: Batch-Processing API

Run Py_DAW scripts from the command line without opening the GUI.
Perfect for CI/CD pipelines, batch exports, automated mastering,
and project transformations.

Usage:
    # Run a script on a project
    python3 batch_process.py --project my_song.pydaw --script gain_staging.py

    # Export with custom settings
    python3 batch_process.py --project my_song.pydaw --export output.wav --format wav --bit-depth 24

    # Run inline Python
    python3 batch_process.py --project my_song.pydaw --exec "project.bpm = 140; project.save()"

    # Show project info
    python3 batch_process.py --project my_song.pydaw --info

    # Batch process multiple projects
    python3 batch_process.py --project-dir ~/Projects/ --script normalize.py

Examples:
    # Set all tracks to -6dB and export
    python3 batch_process.py --project song.pydaw \\
        --exec "for t in tracks: t.volume = 0.5" \\
        --export song_normalized.wav

    # Batch export all projects in a folder
    python3 batch_process.py --project-dir ~/Music/Projects/ \\
        --script export_stems.py
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from pathlib import Path

# Ensure pydaw is importable
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

log = logging.getLogger("pydaw.batch")


def _setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


def _load_project(project_path: str):
    """Load a Py_DAW project file. Returns (ProjectService, Project) or raises."""
    from pydaw.services.project_service import ProjectService
    from pydaw.services.threadpool_service import ThreadPoolService

    path = Path(project_path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Project file not found: {path}")

    tp = ThreadPoolService.create_default()
    ps = ProjectService(threadpool=tp)

    # Determine if it's a .pydaw file or a directory
    if path.is_dir():
        # Look for project.json inside
        pj = path / "project.json"
        if not pj.exists():
            raise FileNotFoundError(f"No project.json in {path}")
        ps.open_project(str(path))
    elif path.suffix == ".pydaw" or path.name == "project.json":
        project_dir = path.parent if path.name == "project.json" else path
        ps.open_project(str(project_dir))
    else:
        raise ValueError(f"Unknown project format: {path}")

    return ps


def _create_scripting_env(project_service, transport_service=None):
    """Create a ScriptingService for batch execution."""
    from pydaw.services.scripting_service import ScriptingService
    ss = ScriptingService(
        project_service=project_service,
        transport_service=transport_service,
    )
    # Redirect print to stdout
    ss.set_on_output(lambda text: print(text))
    return ss


def cmd_info(args) -> int:
    """Show project information."""
    ps = _load_project(args.project)
    proj = ps.ctx.project

    print(f"\n{'═' * 50}")
    print(f"  🎵 Py_DAW Project Info")
    print(f"{'═' * 50}")
    print(f"  Name:        {proj.name}")
    print(f"  BPM:         {proj.bpm}")
    print(f"  Sample Rate: {proj.sample_rate} Hz")
    print(f"  Time Sig:    {proj.time_signature}")
    print(f"  Tracks:      {len(proj.tracks)}")
    print(f"  Clips:       {len(proj.clips)}")
    print(f"{'─' * 50}")

    for i, t in enumerate(proj.tracks):
        kind = getattr(t, 'kind', '?')
        name = getattr(t, 'name', '?')
        vol = getattr(t, 'volume', 0.8)
        m = "M" if getattr(t, 'muted', False) else " "
        s = "S" if getattr(t, 'solo', False) else " "
        print(f"  [{i:2d}] {m}{s} {name:25s} ({kind:12s}) vol={vol:.2f}")

    midi_clips = sum(1 for c in proj.clips if getattr(c, 'kind', '') == 'midi')
    audio_clips = sum(1 for c in proj.clips if getattr(c, 'kind', '') == 'audio')
    print(f"{'─' * 50}")
    print(f"  MIDI Clips:  {midi_clips}")
    print(f"  Audio Clips: {audio_clips}")
    print(f"{'═' * 50}\n")
    return 0


def cmd_exec(args) -> int:
    """Execute inline Python code on a project."""
    ps = _load_project(args.project)
    ss = _create_scripting_env(ps)

    code = args.exec_code
    log.info("Executing: %s", code[:80])

    result = ss.execute(code)
    if result.output:
        print(result.output)
    if result.error:
        print(f"ERROR: {result.error}", file=sys.stderr)
        return 1

    # Auto-save if project was modified
    if args.save:
        try:
            ps.save_project()
            log.info("Project saved.")
        except Exception as e:
            log.error("Save failed: %s", e)

    log.info("Done (%.1f ms)", result.duration_ms)
    return 0


def cmd_script(args) -> int:
    """Run a Python script file on a project."""
    ps = _load_project(args.project)
    ss = _create_scripting_env(ps)

    script_path = Path(args.script).resolve()
    if not script_path.exists():
        print(f"ERROR: Script not found: {script_path}", file=sys.stderr)
        return 1

    log.info("Running script: %s", script_path)
    result = ss.execute_file(str(script_path))

    if result.output:
        print(result.output)
    if result.error:
        print(f"ERROR: {result.error}", file=sys.stderr)
        return 1

    if args.save:
        try:
            ps.save_project()
            log.info("Project saved.")
        except Exception as e:
            log.error("Save failed: %s", e)

    log.info("Done (%.1f ms)", result.duration_ms)
    return 0


def cmd_export(args) -> int:
    """Export project to audio file."""
    ps = _load_project(args.project)

    output_path = Path(args.export).resolve()
    fmt = args.format or output_path.suffix.lstrip(".")
    bit_depth = args.bit_depth or 24
    sample_rate = args.sample_rate or 48000

    log.info("Exporting to %s (%s, %d-bit, %d Hz)", output_path, fmt, bit_depth, sample_rate)

    try:
        from pydaw.services.audio_export_service import AudioExportService, ExportConfig
        export_svc = AudioExportService()
        config = ExportConfig(
            output_path=str(output_path),
            format=fmt,
            bit_depth=bit_depth,
            sample_rate=sample_rate,
            normalize=args.normalize or False,
        )
        export_svc.export_audio(ps, config, progress_callback=lambda p: None)
        log.info("Export complete: %s", output_path)
        return 0
    except ImportError:
        log.warning("AudioExportService not available, trying simple render...")
    except Exception as e:
        log.error("Export failed: %s", e)
        return 1

    return 1


def cmd_batch_dir(args) -> int:
    """Run a script on all projects in a directory."""
    project_dir = Path(args.project_dir).resolve()
    if not project_dir.is_dir():
        print(f"ERROR: Not a directory: {project_dir}", file=sys.stderr)
        return 1

    script_path = Path(args.script).resolve()
    if not script_path.exists():
        print(f"ERROR: Script not found: {script_path}", file=sys.stderr)
        return 1

    # Find all project directories (contain project.json)
    projects = []
    for entry in sorted(project_dir.iterdir()):
        if entry.is_dir() and (entry / "project.json").exists():
            projects.append(entry)

    if not projects:
        print(f"No projects found in {project_dir}")
        return 0

    print(f"\n🎵 Batch processing {len(projects)} projects with {script_path.name}\n")

    success = 0
    failed = 0
    for proj_dir in projects:
        try:
            ps = _load_project(str(proj_dir))
            ss = _create_scripting_env(ps)
            result = ss.execute_file(str(script_path))

            if result.success:
                if args.save:
                    ps.save_project()
                print(f"  ✅ {proj_dir.name}")
                if result.output:
                    for line in result.output.splitlines()[:3]:
                        print(f"     {line}")
                success += 1
            else:
                print(f"  ❌ {proj_dir.name}: {result.error[:80]}")
                failed += 1
        except Exception as e:
            print(f"  ❌ {proj_dir.name}: {e}")
            failed += 1

    print(f"\n{'═' * 40}")
    print(f"  ✅ {success} succeeded, ❌ {failed} failed")
    print(f"{'═' * 40}\n")
    return 1 if failed > 0 else 0


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="pydaw-batch",
        description="🎵 Py_DAW Batch Processing — Headless project automation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --project song.pydaw --info
  %(prog)s --project song.pydaw --exec "project.bpm = 140"
  %(prog)s --project song.pydaw --script gain_staging.py --save
  %(prog)s --project song.pydaw --export output.wav --format wav
  %(prog)s --project-dir ~/Projects/ --script normalize.py --save
        """,
    )

    parser.add_argument("--project", "-p",
                        help="Path to .pydaw project file or directory")
    parser.add_argument("--project-dir",
                        help="Process all projects in a directory")
    parser.add_argument("--script", "-s",
                        help="Python script file to run")
    parser.add_argument("--exec", "-e", dest="exec_code",
                        help="Inline Python code to execute")
    parser.add_argument("--info", "-i", action="store_true",
                        help="Show project information")
    parser.add_argument("--export", "-x",
                        help="Export to audio file (path)")
    parser.add_argument("--format", "-f",
                        choices=["wav", "flac", "mp3", "ogg"],
                        help="Export format (default: from extension)")
    parser.add_argument("--bit-depth", type=int, default=24,
                        choices=[16, 24, 32],
                        help="Export bit depth (default: 24)")
    parser.add_argument("--sample-rate", type=int, default=48000,
                        help="Export sample rate (default: 48000)")
    parser.add_argument("--normalize", action="store_true",
                        help="Normalize audio on export")
    parser.add_argument("--save", action="store_true",
                        help="Save project after script execution")
    parser.add_argument("--verbose", "-v", action="store_true",
                        help="Verbose output")

    args = parser.parse_args()
    _setup_logging(args.verbose)

    # Validate arguments
    if not args.project and not args.project_dir:
        parser.error("Either --project or --project-dir is required")

    # Batch directory mode
    if args.project_dir:
        if not args.script:
            parser.error("--script is required with --project-dir")
        return cmd_batch_dir(args)

    # Single project mode
    if args.info:
        return cmd_info(args)

    if args.exec_code:
        return cmd_exec(args)

    if args.script:
        return cmd_script(args)

    if args.export:
        return cmd_export(args)

    parser.error("One of --info, --exec, --script, or --export is required")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
