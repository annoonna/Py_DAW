# v0.0.20.176 — Aktueller Stand

## Neu (safe, Workflow-first)

### Arranger Micro-Controls (Clip-Ebene)
- ✅ **Clip ▾ Dropdown** (Hover/Selektion) für schnelle Aktionen ohne Rechtsklick.
- ✅ **Fade-Handles** (In/Out) + Overlay
  - Drag = Fade-Länge
  - **SHIFT** = Snap an Grid
- ✅ **Gain/Pan Mini-Handles** (nur Audio-Clips)
  - **G**: Drag vertikal = Gain (dB-mapped)
  - **SHIFT** während G-Drag = Quick-Pan (horizontal)
  - **P**: Drag horizontal = Pan (**SHIFT** = Fine)

### Ultra-Pro Render Workflow (Audio)
- Re-render / Restore Sources / Toggle Rendered↔Sources / Rebuild original clip state (non-destructive)

### Automation & Crash-Recovery
- Automation-Lanes persistieren nach Reload.
- Autosave/Recovery im Projektordner `.recovery/`.

## Nächster sinnvoller Schritt (Empfehlung)
- Phase 1 fortsetzen: **Clip-Gain/Pan auch im Audio-Editor** als Micro-Controls (optional, UI-only)
- Phase 2: Track-Header ▾ (Routing/Arm/Monitor/Add Device)
- Phase 3: Device ▾ + Command Palette (Ctrl+P)
