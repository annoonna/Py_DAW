# -*- coding: utf-8 -*-
"""Instrument Browser tab (Pro-DAW-Style).

Lists available internal instruments (Python plugins) and lets the user add them to the device chain.
"""

from __future__ import annotations

import json

from typing import Callable, Optional

from PyQt6.QtCore import Qt, QMimeData
from PyQt6.QtGui import QDrag
from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QLineEdit,
)

from pydaw.plugins.registry import get_instruments, InstrumentSpec



_MIME = "application/x-pydaw-plugin"


class _DragInstrumentList(QListWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSelectionMode(QListWidget.SelectionMode.SingleSelection)
        self.setDragEnabled(True)
        self.setDragDropMode(QListWidget.DragDropMode.DragOnly)
        self.setDefaultDropAction(Qt.DropAction.CopyAction)

    def startDrag(self, supportedActions):  # noqa: N802
        it = self.currentItem()
        if it is None:
            return
        pid = it.data(Qt.ItemDataRole.UserRole)
        if not isinstance(pid, str) or not pid:
            return
        payload = {"kind": "instrument", "plugin_id": pid, "name": it.text()}
        md = QMimeData()
        md.setData(_MIME, json.dumps(payload).encode("utf-8"))
        drag = QDrag(self)
        drag.setMimeData(md)
        drag.exec(Qt.DropAction.CopyAction)


class InstrumentBrowserWidget(QWidget):
    def __init__(self, on_add_instrument: Optional[Callable[[str], None]] = None, parent=None):
        super().__init__(parent)
        self._on_add = on_add_instrument
        self._items: list[InstrumentSpec] = []
        self._build()

    def _build(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        header = QLabel("Instruments")
        header.setObjectName("instrumentBrowserTitle")

        row = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Suchen…")
        self.search.textChanged.connect(self._refilter)

        self.btn_add = QPushButton("Add to Device")
        self.btn_add.clicked.connect(self._add_selected)

        row.addWidget(self.search, 1)
        row.addWidget(self.btn_add, 0)

        self.list = _DragInstrumentList()
        self.list.itemDoubleClicked.connect(lambda _: self._add_selected())

        hint = QLabel("Tipp: Doppelklick oder 'Add to Device'.")
        hint.setAlignment(Qt.AlignmentFlag.AlignLeft)
        hint.setStyleSheet("color: #9a9a9a;")

        layout.addWidget(header)
        layout.addLayout(row)
        layout.addWidget(self.list, 1)
        layout.addWidget(hint)

        self.reload()

    def reload(self) -> None:
        self._items = get_instruments()
        self._refilter()

    def _refilter(self) -> None:
        q = (self.search.text() or "").strip().lower()
        self.list.clear()
        for spec in self._items:
            hay = f"{spec.name} {spec.vendor} {spec.category} {spec.description}".lower()
            if q and q not in hay:
                continue
            it = QListWidgetItem(f"{spec.name}   —   {spec.category}")
            it.setData(Qt.ItemDataRole.UserRole, spec.plugin_id)
            if spec.description:
                it.setToolTip(spec.description)
            self.list.addItem(it)

        self.btn_add.setEnabled(self.list.count() > 0)

    def _add_selected(self) -> None:
        if self._on_add is None:
            return
        it = self.list.currentItem()
        if it is None and self.list.count() > 0:
            it = self.list.item(0)
        if it is None:
            return
        pid = it.data(Qt.ItemDataRole.UserRole)
        if isinstance(pid, str) and pid:
            self._on_add(pid)
