// ============================================================================
// Services: Time Travel + SENTINEL — v0.0.20.973 (RM6.1 + RM6.2)
// ============================================================================

use serde::{Deserialize, Serialize};
use log::{info, warn};
use std::collections::VecDeque;
use std::time::Instant;

// ============================================================================
// RM6.1: Time Travel (Session Journal)
// ============================================================================

/// A journal entry recording a user action
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JournalEntry {
    pub id: u64,
    pub timestamp: String,
    pub action_type: ActionType,
    pub description: String,
    pub tags: Vec<String>,
    /// Serialized delta (JSON diff of changed state)
    pub delta: Option<String>,
    /// Full snapshot (only for key snapshots, not every edit)
    pub snapshot: Option<Vec<u8>>,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum ActionType {
    NoteAdd, NoteDelete, NoteMove, NoteResize,
    ClipAdd, ClipDelete, ClipMove, ClipSplit, ClipTrim,
    TrackAdd, TrackDelete, TrackReorder,
    ParamChange, FxAdd, FxRemove,
    TransportPlay, TransportStop, TransportRecord,
    ProjectSave, ProjectLoad,
    Undo, Redo,
    AutoTag, // KI-generated tag
    Custom,
}

/// Time Travel engine — continuous session journaling
pub struct TimeTravelEngine {
    entries: Vec<JournalEntry>,
    max_entries: usize,
    next_id: u64,
    /// Snapshot interval (take full snapshot every N entries)
    snapshot_interval: u64,
    /// Undo tree: current position in the journal
    current_pos: usize,
}

impl TimeTravelEngine {
    pub fn new() -> Self {
        Self {
            entries: Vec::new(),
            max_entries: 100_000,
            next_id: 1,
            snapshot_interval: 50,
            current_pos: 0,
        }
    }

    /// Record an action
    pub fn record(&mut self, action: ActionType, description: &str, delta: Option<String>) {
        // Truncate any redo history
        if self.current_pos < self.entries.len() {
            self.entries.truncate(self.current_pos);
        }

        let entry = JournalEntry {
            id: self.next_id,
            timestamp: crate::model::now_iso(),
            action_type: action,
            description: description.into(),
            tags: Vec::new(),
            delta,
            snapshot: None,
        };
        self.next_id += 1;
        self.entries.push(entry);
        self.current_pos = self.entries.len();

        // Trim if over max
        if self.entries.len() > self.max_entries {
            let remove = self.entries.len() - self.max_entries;
            self.entries.drain(0..remove);
            self.current_pos = self.entries.len();
        }
    }

    /// Undo: move back one entry
    pub fn undo(&mut self) -> Option<&JournalEntry> {
        if self.current_pos > 0 {
            self.current_pos -= 1;
            self.entries.get(self.current_pos)
        } else {
            None
        }
    }

    /// Redo: move forward one entry
    pub fn redo(&mut self) -> Option<&JournalEntry> {
        if self.current_pos < self.entries.len() {
            let entry = self.entries.get(self.current_pos);
            self.current_pos += 1;
            entry
        } else {
            None
        }
    }

    /// Search journal entries by description
    pub fn search(&self, query: &str) -> Vec<&JournalEntry> {
        let query_lower = query.to_lowercase();
        self.entries.iter()
            .filter(|e| e.description.to_lowercase().contains(&query_lower)
                     || e.tags.iter().any(|t| t.to_lowercase().contains(&query_lower)))
            .collect()
    }

    /// Get entries in a time range
    pub fn entries_between(&self, from: &str, to: &str) -> Vec<&JournalEntry> {
        self.entries.iter()
            .filter(|e| e.timestamp.as_str() >= from && e.timestamp.as_str() <= to)
            .collect()
    }

    /// Generate a session heatmap: count edits per beat region
    pub fn heatmap(&self, region_size_beats: f64) -> Vec<(f64, u32)> {
        // This requires position info in the delta — simplified version
        // counts actions per time period instead
        let mut buckets: std::collections::BTreeMap<u64, u32> = std::collections::BTreeMap::new();
        for (i, _entry) in self.entries.iter().enumerate() {
            let bucket = i as u64 / 10; // group by 10 entries
            *buckets.entry(bucket).or_default() += 1;
        }
        buckets.into_iter().map(|(k, v)| (k as f64 * region_size_beats, v)).collect()
    }

    pub fn len(&self) -> usize { self.entries.len() }
    pub fn position(&self) -> usize { self.current_pos }
    pub fn can_undo(&self) -> bool { self.current_pos > 0 }
    pub fn can_redo(&self) -> bool { self.current_pos < self.entries.len() }
}

// ============================================================================
// RM6.2: SENTINEL Diagnostics
// ============================================================================

/// Anomaly severity
#[derive(Debug, Clone, Copy, PartialEq, Ord, PartialOrd, Eq, Serialize, Deserialize)]
pub enum Severity {
    Info, Warning, Error, Critical,
}

/// A detected anomaly
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Anomaly {
    pub timestamp: String,
    pub severity: Severity,
    pub category: String,
    pub message: String,
    pub metrics: std::collections::HashMap<String, f64>,
}

/// Performance metrics snapshot
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct PerfMetrics {
    pub cpu_percent: f64,
    pub audio_render_us: u64,
    pub xrun_count: u32,
    pub buffer_underruns: u32,
    pub memory_mb: f64,
    pub active_voices: u32,
    pub active_tracks: u32,
    pub disk_read_mb_s: f64,
}

/// SENTINEL diagnostics engine
pub struct SentinelEngine {
    /// Rolling metrics window (last N snapshots)
    metrics_ring: VecDeque<PerfMetrics>,
    ring_capacity: usize,
    /// Baseline (learned "normal" values)
    baseline: Option<PerfBaseline>,
    /// Anomaly log
    anomalies: Vec<Anomaly>,
    max_anomalies: usize,
    /// Blackbox: last N events as ring buffer
    blackbox: VecDeque<String>,
    blackbox_capacity: usize,
    /// Thresholds
    cpu_threshold: f64,
    render_us_threshold: u64,
    xrun_threshold: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct PerfBaseline {
    avg_cpu: f64,
    std_cpu: f64,
    avg_render_us: f64,
    std_render_us: f64,
    samples: u64,
}

impl SentinelEngine {
    pub fn new() -> Self {
        Self {
            metrics_ring: VecDeque::with_capacity(1000),
            ring_capacity: 1000,
            baseline: None,
            anomalies: Vec::new(),
            max_anomalies: 10_000,
            blackbox: VecDeque::with_capacity(1000),
            blackbox_capacity: 1000,
            cpu_threshold: 80.0,
            render_us_threshold: 10_000, // 10ms
            xrun_threshold: 0,
        }
    }

    /// Record a performance snapshot and check for anomalies
    pub fn record_metrics(&mut self, metrics: PerfMetrics) -> Vec<Anomaly> {
        let mut new_anomalies = Vec::new();

        // Check thresholds
        if metrics.cpu_percent > self.cpu_threshold {
            new_anomalies.push(Anomaly {
                timestamp: crate::model::now_iso(),
                severity: if metrics.cpu_percent > 95.0 { Severity::Critical } else { Severity::Warning },
                category: "cpu".into(),
                message: format!("CPU usage high: {:.1}%", metrics.cpu_percent),
                metrics: [("cpu".into(), metrics.cpu_percent)].into_iter().collect(),
            });
        }

        if metrics.audio_render_us > self.render_us_threshold {
            new_anomalies.push(Anomaly {
                timestamp: crate::model::now_iso(),
                severity: Severity::Warning,
                category: "render".into(),
                message: format!("Audio render slow: {}μs", metrics.audio_render_us),
                metrics: [("render_us".into(), metrics.audio_render_us as f64)].into_iter().collect(),
            });
        }

        if metrics.xrun_count > self.xrun_threshold {
            new_anomalies.push(Anomaly {
                timestamp: crate::model::now_iso(),
                severity: Severity::Error,
                category: "xrun".into(),
                message: format!("XRun detected (total: {})", metrics.xrun_count),
                metrics: [("xruns".into(), metrics.xrun_count as f64)].into_iter().collect(),
            });
            self.xrun_threshold = metrics.xrun_count; // only alert on NEW xruns
        }

        // Check against baseline (if learned)
        if let Some(ref baseline) = self.baseline {
            if baseline.samples > 100 {
                let cpu_z = (metrics.cpu_percent - baseline.avg_cpu) / baseline.std_cpu.max(0.1);
                if cpu_z > 3.0 {
                    new_anomalies.push(Anomaly {
                        timestamp: crate::model::now_iso(),
                        severity: Severity::Info,
                        category: "pattern".into(),
                        message: format!("CPU {:.1}σ above baseline ({:.1}% vs avg {:.1}%)",
                            cpu_z, metrics.cpu_percent, baseline.avg_cpu),
                        metrics: [("z_score".into(), cpu_z)].into_iter().collect(),
                    });
                }
            }
        }

        // Store metrics
        if self.metrics_ring.len() >= self.ring_capacity {
            self.metrics_ring.pop_front();
        }
        self.metrics_ring.push_back(metrics);

        // Store anomalies
        for a in &new_anomalies {
            if self.anomalies.len() >= self.max_anomalies {
                self.anomalies.remove(0);
            }
            self.anomalies.push(a.clone());
        }

        new_anomalies
    }

    /// Learn baseline from current metrics window
    pub fn learn_baseline(&mut self) {
        if self.metrics_ring.len() < 10 {
            warn!("Not enough data to learn baseline ({} samples)", self.metrics_ring.len());
            return;
        }

        let n = self.metrics_ring.len() as f64;
        let avg_cpu = self.metrics_ring.iter().map(|m| m.cpu_percent).sum::<f64>() / n;
        let std_cpu = (self.metrics_ring.iter()
            .map(|m| (m.cpu_percent - avg_cpu).powi(2)).sum::<f64>() / n).sqrt();
        let avg_render = self.metrics_ring.iter().map(|m| m.audio_render_us as f64).sum::<f64>() / n;
        let std_render = (self.metrics_ring.iter()
            .map(|m| (m.audio_render_us as f64 - avg_render).powi(2)).sum::<f64>() / n).sqrt();

        self.baseline = Some(PerfBaseline {
            avg_cpu, std_cpu, avg_render_us: avg_render, std_render_us: std_render,
            samples: self.metrics_ring.len() as u64,
        });

        info!("SENTINEL baseline learned: CPU={:.1}±{:.1}%, render={:.0}±{:.0}μs",
            avg_cpu, std_cpu, avg_render, std_render);
    }

    /// Log to blackbox
    pub fn log(&mut self, message: &str) {
        if self.blackbox.len() >= self.blackbox_capacity {
            self.blackbox.pop_front();
        }
        self.blackbox.push_back(format!("{} {}", crate::model::now_iso(), message));
    }

    /// Get recent anomalies
    pub fn recent_anomalies(&self, count: usize) -> Vec<&Anomaly> {
        self.anomalies.iter().rev().take(count).collect()
    }

    /// Get blackbox log
    pub fn blackbox_dump(&self) -> Vec<&str> {
        self.blackbox.iter().map(|s| s.as_str()).collect()
    }

    /// Get current metrics summary
    pub fn summary(&self) -> SentinelSummary {
        let latest = self.metrics_ring.back().cloned().unwrap_or_default();
        SentinelSummary {
            cpu_percent: latest.cpu_percent,
            render_us: latest.audio_render_us,
            xrun_count: latest.xrun_count,
            total_anomalies: self.anomalies.len(),
            critical_anomalies: self.anomalies.iter().filter(|a| a.severity == Severity::Critical).count(),
            baseline_learned: self.baseline.is_some(),
            metrics_collected: self.metrics_ring.len(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SentinelSummary {
    pub cpu_percent: f64,
    pub render_us: u64,
    pub xrun_count: u32,
    pub total_anomalies: usize,
    pub critical_anomalies: usize,
    pub baseline_learned: bool,
    pub metrics_collected: usize,
}
