// ============================================================================
// GPU Setup — NS4.1: WGPU Device/Adapter/Queue
// ============================================================================
//
// Handles GPU initialization with automatic backend detection:
//   1. Vulkan (Linux primary)
//   2. OpenGL (fallback)
//   3. Software (wgpu's CPU rasterizer)
//
// v0.0.20.985 — NS4 (Claude Opus 4.6, 2026-04-04)
// ============================================================================

#![allow(unused_imports)]

use std::sync::Arc;
use log::{info, warn, error};

use wgpu;

use super::GpuCapabilities;

/// Initialized GPU context with device, queue, and adapter info.
pub struct GpuContext {
    pub device: wgpu::Device,
    pub queue: wgpu::Queue,
    pub adapter_info: wgpu::AdapterInfo,
    pub capabilities: GpuCapabilities,
}

impl GpuContext {
    /// Initialize WGPU with automatic backend selection.
    ///
    /// Tries Vulkan first, then OpenGL, then software.
    /// Returns Err if no backend is available.
    pub async fn new() -> Result<Self, String> {
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor {
            backends: wgpu::Backends::VULKAN | wgpu::Backends::GL,
            ..Default::default()
        });

        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: None,
                force_fallback_adapter: false,
            })
            .await
            .ok_or("No GPU adapter found")?;

        let info = adapter.get_info();
        info!(
            "[GPU] Adapter: {} ({:?}, {:?})",
            info.name, info.backend, info.device_type
        );

        let limits = adapter.limits();

        let (device, queue) = adapter
            .request_device(
                &wgpu::DeviceDescriptor {
                    label: Some("pydaw_gpu"),
                    required_features: wgpu::Features::empty(),
                    required_limits: wgpu::Limits::downlevel_defaults(),
                    memory_hints: wgpu::MemoryHints::Performance,
                },
                None,
            )
            .await
            .map_err(|e| format!("Failed to create GPU device: {}", e))?;

        let capabilities = GpuCapabilities {
            available: true,
            backend: format!("{:?}", info.backend).to_lowercase(),
            device_name: info.name.clone(),
            vendor: format!("0x{:04X}", info.vendor),
            vram_mb: 0, // wgpu doesn't expose VRAM directly
            max_texture_size: limits.max_texture_dimension_2d,
            compute_shaders: true,
        };

        info!(
            "[GPU] Initialized: {} ({}), max texture: {}x{}",
            capabilities.device_name,
            capabilities.backend,
            capabilities.max_texture_size,
            capabilities.max_texture_size,
        );

        Ok(Self {
            device,
            queue,
            adapter_info: info,
            capabilities,
        })
    }

    /// Create a texture for video frame upload.
    pub fn create_frame_texture(&self, width: u32, height: u32) -> wgpu::Texture {
        self.device.create_texture(&wgpu::TextureDescriptor {
            label: Some("video_frame"),
            size: wgpu::Extent3d {
                width,
                height,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8UnormSrgb,
            usage: wgpu::TextureUsages::TEXTURE_BINDING
                | wgpu::TextureUsages::COPY_DST
                | wgpu::TextureUsages::RENDER_ATTACHMENT,
            view_formats: &[],
        })
    }

    /// Upload RGBA pixel data to a texture.
    pub fn upload_frame(
        &self,
        texture: &wgpu::Texture,
        rgba_data: &[u8],
        width: u32,
        height: u32,
    ) {
        self.queue.write_texture(
            wgpu::ImageCopyTexture {
                texture,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            rgba_data,
            wgpu::ImageDataLayout {
                offset: 0,
                bytes_per_row: Some(4 * width),
                rows_per_image: Some(height),
            },
            wgpu::Extent3d {
                width,
                height,
                depth_or_array_layers: 1,
            },
        );
    }

    /// Read back pixels from a texture (GPU → CPU).
    pub async fn readback_frame(
        &self,
        texture: &wgpu::Texture,
        width: u32,
        height: u32,
    ) -> Result<Vec<u8>, String> {
        let size = (width * height * 4) as u64;
        let padded_bytes_per_row = ((width * 4 + 255) / 256) * 256;

        let buffer = self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("readback"),
            size: padded_bytes_per_row as u64 * height as u64,
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
            mapped_at_creation: false,
        });

        let mut encoder = self.device.create_command_encoder(
            &wgpu::CommandEncoderDescriptor { label: Some("readback_encoder") }
        );

        encoder.copy_texture_to_buffer(
            wgpu::ImageCopyTexture {
                texture,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            wgpu::ImageCopyBuffer {
                buffer: &buffer,
                layout: wgpu::ImageDataLayout {
                    offset: 0,
                    bytes_per_row: Some(padded_bytes_per_row),
                    rows_per_image: Some(height),
                },
            },
            wgpu::Extent3d { width, height, depth_or_array_layers: 1 },
        );

        self.queue.submit(std::iter::once(encoder.finish()));

        let slice = buffer.slice(..);
        let (tx, rx) = std::sync::mpsc::channel();
        slice.map_async(wgpu::MapMode::Read, move |result| {
            tx.send(result).ok();
        });
        self.device.poll(wgpu::Maintain::Wait);

        rx.recv()
            .map_err(|e| format!("Readback failed: {}", e))?
            .map_err(|e| format!("Buffer map failed: {}", e))?;

        let data = slice.get_mapped_range();
        let mut output = vec![0u8; size as usize];

        // Remove padding
        for y in 0..height as usize {
            let src_start = y * padded_bytes_per_row as usize;
            let dst_start = y * (width as usize * 4);
            let row_bytes = width as usize * 4;
            output[dst_start..dst_start + row_bytes]
                .copy_from_slice(&data[src_start..src_start + row_bytes]);
        }

        Ok(output)
    }
}

/// Detect GPU without full initialization.
pub fn detect_gpu() -> Result<GpuCapabilities, String> {
    // Use pollster for synchronous async
    let rt = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .map_err(|e| format!("Runtime: {}", e))?;

    rt.block_on(async {
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor {
            backends: wgpu::Backends::VULKAN | wgpu::Backends::GL,
            ..Default::default()
        });

        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: None,
                force_fallback_adapter: false,
            })
            .await;

        match adapter {
            Some(a) => {
                let info = a.get_info();
                let limits = a.limits();
                Ok(GpuCapabilities {
                    available: true,
                    backend: format!("{:?}", info.backend).to_lowercase(),
                    device_name: info.name.clone(),
                    vendor: format!("0x{:04X}", info.vendor),
                    vram_mb: 0,
                    max_texture_size: limits.max_texture_dimension_2d,
                    compute_shaders: true,
                })
            }
            None => Err("No GPU adapter found".into()),
        }
    })
}
