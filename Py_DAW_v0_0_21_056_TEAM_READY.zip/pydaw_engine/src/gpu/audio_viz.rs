// ============================================================================
// GPU Audio Visualization — NS4.4: Realtime Audio Display
// ============================================================================
//
// GPU-accelerated rendering for:
//   - Waveform display (overview + zoomed)
//   - Spectrum analyzer (2D + 3D waterfall)
//   - Stereo correlation display
//   - VU meter rendering (gradient, peak hold)
//
// v0.0.20.985 — NS4 (Claude Opus 4.6, 2026-04-04)
// ============================================================================

use log::{info, debug};
use wgpu;

use super::setup::GpuContext;

/// Waveform rendering mode.
#[derive(Debug, Clone, Copy)]
pub enum WaveformMode {
    /// Standard min/max peaks
    Peaks,
    /// RMS envelope
    Rms,
    /// Combined peaks + RMS
    Combined,
}

/// Spectrum display mode.
#[derive(Debug, Clone, Copy)]
pub enum SpectrumMode {
    /// 2D frequency bars
    Bars2D,
    /// 2D continuous line
    Line2D,
    /// 3D waterfall (scrolling spectrogram)
    Waterfall3D,
}

/// VU meter style.
#[derive(Debug, Clone, Copy)]
pub enum MeterStyle {
    /// Classic analog VU
    Analog,
    /// Digital LED bars
    Digital,
    /// K-System (K-12, K-14, K-20)
    KSystem { headroom: f32 },
}

/// Configuration for the audio visualizer.
#[derive(Debug, Clone)]
pub struct AudioVizConfig {
    pub waveform_mode: WaveformMode,
    pub spectrum_mode: SpectrumMode,
    pub meter_style: MeterStyle,
    pub fft_size: u32,
    pub waveform_color: [f32; 4],    // RGBA
    pub spectrum_color_lo: [f32; 4], // low frequency color
    pub spectrum_color_hi: [f32; 4], // high frequency color
    pub background_color: [f32; 4],
    pub peak_hold_time_ms: u32,
}

impl Default for AudioVizConfig {
    fn default() -> Self {
        Self {
            waveform_mode: WaveformMode::Combined,
            spectrum_mode: SpectrumMode::Bars2D,
            meter_style: MeterStyle::Digital,
            fft_size: 4096,
            waveform_color: [0.4, 0.8, 1.0, 1.0],    // cyan
            spectrum_color_lo: [0.2, 0.6, 1.0, 1.0],  // blue
            spectrum_color_hi: [1.0, 0.3, 0.2, 1.0],  // red
            background_color: [0.08, 0.08, 0.12, 1.0], // dark
            peak_hold_time_ms: 2000,
        }
    }
}

/// WGSL shader for waveform rendering.
const WAVEFORM_SHADER: &str = r#"
struct WaveformUniforms {
    width: u32,
    height: u32,
    num_peaks: u32,
    color_r: f32,
    color_g: f32,
    color_b: f32,
    color_a: f32,
    bg_r: f32,
    bg_g: f32,
    bg_b: f32,
    bg_a: f32,
    mode: u32,  // 0=peaks, 1=rms, 2=combined
}

@group(0) @binding(0) var<uniform> params: WaveformUniforms;
@group(0) @binding(1) var<storage, read> peaks_min: array<f32>;
@group(0) @binding(2) var<storage, read> peaks_max: array<f32>;
@group(0) @binding(3) var output_tex: texture_storage_2d<rgba8unorm, write>;

@compute @workgroup_size(16, 16)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    if gid.x >= params.width || gid.y >= params.height { return; }

    let x = gid.x;
    let y = gid.y;
    let mid_y = f32(params.height) / 2.0;

    // Map x to peak index
    let peak_idx = u32(f32(x) * f32(params.num_peaks) / f32(params.width));
    if peak_idx >= params.num_peaks {
        textureStore(output_tex, vec2<i32>(i32(x), i32(y)),
                     vec4(params.bg_r, params.bg_g, params.bg_b, params.bg_a));
        return;
    }

    let min_val = peaks_min[peak_idx];
    let max_val = peaks_max[peak_idx];

    // Convert sample value to Y coordinate
    let y_min = mid_y - min_val * mid_y;
    let y_max = mid_y - max_val * mid_y;

    let fy = f32(y);
    if fy >= y_max && fy <= y_min {
        // Inside waveform
        let intensity = 1.0 - abs(fy - mid_y) / mid_y * 0.3;
        textureStore(output_tex, vec2<i32>(i32(x), i32(y)),
                     vec4(params.color_r * intensity,
                          params.color_g * intensity,
                          params.color_b * intensity,
                          params.color_a));
    } else {
        // Background
        textureStore(output_tex, vec2<i32>(i32(x), i32(y)),
                     vec4(params.bg_r, params.bg_g, params.bg_b, params.bg_a));
    }
}
"#;

/// GPU audio visualizer.
pub struct AudioVisualizer {
    config: AudioVizConfig,
    waveform_pipeline: wgpu::ComputePipeline,
    /// Waterfall history (ring of spectrum snapshots)
    waterfall_history: Vec<Vec<f32>>,
    waterfall_write_pos: usize,
    waterfall_depth: usize,
}

impl AudioVisualizer {
    /// Create a new audio visualizer.
    pub fn new(ctx: &GpuContext, config: AudioVizConfig) -> Self {
        let waveform_module = ctx.device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("waveform_shader"),
            source: wgpu::ShaderSource::Wgsl(WAVEFORM_SHADER.into()),
        });

        let layout = ctx.device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("waveform_layout"),
            bind_group_layouts: &[],
            push_constant_ranges: &[],
        });

        let waveform_pipeline = ctx.device.create_compute_pipeline(
            &wgpu::ComputePipelineDescriptor {
                label: Some("waveform_pipeline"),
                layout: Some(&layout),
                module: &waveform_module,
                entry_point: Some("main"),
                compilation_options: Default::default(),
                cache: None,
            },
        );

        let waterfall_depth = 128;

        info!(
            "[GPU AudioViz] Created: {:?} waveform, {:?} spectrum, {:?} meters",
            config.waveform_mode, config.spectrum_mode, config.meter_style
        );

        Self {
            config,
            waveform_pipeline,
            waterfall_history: vec![vec![0.0; config.fft_size as usize / 2]; waterfall_depth],
            waterfall_write_pos: 0,
            waterfall_depth,
        }
    }

    /// Push a spectrum snapshot for waterfall display.
    pub fn push_spectrum(&mut self, magnitudes: &[f32]) {
        let len = magnitudes.len().min(self.waterfall_history[0].len());
        self.waterfall_history[self.waterfall_write_pos][..len]
            .copy_from_slice(&magnitudes[..len]);
        self.waterfall_write_pos = (self.waterfall_write_pos + 1) % self.waterfall_depth;
    }

    /// Get current config.
    pub fn config(&self) -> &AudioVizConfig {
        &self.config
    }
}

/// Stereo correlation meter data.
#[derive(Debug, Clone, Copy, Default)]
pub struct StereoCorrelation {
    /// Correlation coefficient (-1.0 to 1.0)
    /// -1.0 = out of phase, 0.0 = uncorrelated, 1.0 = mono
    pub correlation: f32,
    /// Stereo balance (-1.0 = left, 0.0 = center, 1.0 = right)
    pub balance: f32,
    /// Stereo width (0.0 = mono, 1.0 = full stereo)
    pub width: f32,
}

/// Calculate stereo correlation from L/R samples.
pub fn calculate_correlation(left: &[f32], right: &[f32]) -> StereoCorrelation {
    let n = left.len().min(right.len());
    if n == 0 {
        return StereoCorrelation::default();
    }

    let mut sum_lr = 0.0f64;
    let mut sum_l2 = 0.0f64;
    let mut sum_r2 = 0.0f64;
    let mut sum_l = 0.0f64;
    let mut sum_r = 0.0f64;

    for i in 0..n {
        let l = left[i] as f64;
        let r = right[i] as f64;
        sum_lr += l * r;
        sum_l2 += l * l;
        sum_r2 += r * r;
        sum_l += l.abs();
        sum_r += r.abs();
    }

    let denom = (sum_l2 * sum_r2).sqrt();
    let correlation = if denom > 1e-10 { (sum_lr / denom) as f32 } else { 0.0 };

    let total = sum_l + sum_r;
    let balance = if total > 1e-10 {
        ((sum_r - sum_l) / total) as f32
    } else {
        0.0
    };

    let width = 1.0 - correlation.abs();

    StereoCorrelation { correlation, balance, width }
}
