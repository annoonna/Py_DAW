// ============================================================================
// Py_DAW GPU Rendering Engine — v0.0.20.985 (NS4)
// ============================================================================
//
// WGPU-based GPU rendering for:
//   - Video filters (color correction, blur, chroma key, compositing)
//   - Video preview (realtime 1080p/4K)
//   - Audio visualization (waveform, spectrum, VU meters)
//
// Feature-gated: compile with `cargo build --features gpu`
// Fallback: CPU rendering when GPU is not available
//
// Architecture:
//   GpuContext → manages wgpu Device/Queue/Adapter
//   VideoFilterPipeline → shader-based video filters
//   PreviewRenderer → frame decode → GPU → display
//   AudioVisualizer → waveform/spectrum on GPU
// ============================================================================

#[cfg(feature = "gpu")]
pub mod setup;
#[cfg(feature = "gpu")]
pub mod filters;
#[cfg(feature = "gpu")]
pub mod preview;
#[cfg(feature = "gpu")]
pub mod audio_viz;

// Always-available: CPU fallback types and capability detection
use log::{info, warn};

/// GPU capability detection result.
#[derive(Debug, Clone)]
pub struct GpuCapabilities {
    pub available: bool,
    pub backend: String,        // "vulkan", "opengl", "dx12", "metal", "software"
    pub device_name: String,
    pub vendor: String,
    pub vram_mb: u64,
    pub max_texture_size: u32,
    pub compute_shaders: bool,
}

impl Default for GpuCapabilities {
    fn default() -> Self {
        Self {
            available: false,
            backend: "none".into(),
            device_name: "No GPU".into(),
            vendor: "unknown".into(),
            vram_mb: 0,
            max_texture_size: 0,
            compute_shaders: false,
        }
    }
}

/// Detect GPU capabilities without initializing WGPU.
///
/// Returns GpuCapabilities with available=false if no GPU or feature disabled.
pub fn detect_capabilities() -> GpuCapabilities {
    #[cfg(feature = "gpu")]
    {
        match setup::detect_gpu() {
            Ok(caps) => caps,
            Err(e) => {
                warn!("[GPU] Detection failed: {}", e);
                GpuCapabilities::default()
            }
        }
    }

    #[cfg(not(feature = "gpu"))]
    {
        info!("[GPU] WGPU feature not enabled — CPU fallback active");
        GpuCapabilities::default()
    }
}

/// Check if GPU rendering is available.
pub fn is_gpu_available() -> bool {
    cfg!(feature = "gpu")
}

// ============================================================================
// CPU Fallback: Filter functions that work without GPU
// ============================================================================

/// Apply brightness/contrast adjustment (CPU fallback).
pub fn cpu_brightness_contrast(
    rgba: &mut [u8], width: u32, height: u32,
    brightness: f32, contrast: f32,
) {
    let factor = (259.0 * (contrast * 255.0 + 255.0)) / (255.0 * (259.0 - contrast * 255.0));

    for pixel in rgba.chunks_exact_mut(4) {
        for i in 0..3 {
            let val = pixel[i] as f32;
            let adjusted = factor * (val + brightness * 255.0 - 128.0) + 128.0;
            pixel[i] = adjusted.clamp(0.0, 255.0) as u8;
        }
    }
}

/// Apply saturation adjustment (CPU fallback).
pub fn cpu_saturation(rgba: &mut [u8], _width: u32, _height: u32, saturation: f32) {
    for pixel in rgba.chunks_exact_mut(4) {
        let r = pixel[0] as f32;
        let g = pixel[1] as f32;
        let b = pixel[2] as f32;
        let gray = 0.299 * r + 0.587 * g + 0.114 * b;
        pixel[0] = (gray + saturation * (r - gray)).clamp(0.0, 255.0) as u8;
        pixel[1] = (gray + saturation * (g - gray)).clamp(0.0, 255.0) as u8;
        pixel[2] = (gray + saturation * (b - gray)).clamp(0.0, 255.0) as u8;
    }
}

/// Apply box blur (CPU fallback, single-pass).
pub fn cpu_box_blur(rgba: &mut [u8], width: u32, height: u32, radius: u32) {
    if radius == 0 { return; }
    let w = width as usize;
    let h = height as usize;
    let r = radius as usize;
    let mut output = rgba.to_vec();

    for y in 0..h {
        for x in 0..w {
            let mut sum = [0u32; 4];
            let mut count = 0u32;

            let y0 = y.saturating_sub(r);
            let y1 = (y + r + 1).min(h);
            let x0 = x.saturating_sub(r);
            let x1 = (x + r + 1).min(w);

            for sy in y0..y1 {
                for sx in x0..x1 {
                    let idx = (sy * w + sx) * 4;
                    for c in 0..4 {
                        sum[c] += rgba[idx + c] as u32;
                    }
                    count += 1;
                }
            }

            let idx = (y * w + x) * 4;
            for c in 0..4 {
                output[idx + c] = (sum[c] / count) as u8;
            }
        }
    }

    rgba.copy_from_slice(&output);
}

/// Apply chroma key (green screen removal, CPU fallback).
pub fn cpu_chroma_key(
    rgba: &mut [u8], _width: u32, _height: u32,
    key_r: u8, key_g: u8, key_b: u8, threshold: f32,
) {
    for pixel in rgba.chunks_exact_mut(4) {
        let dr = (pixel[0] as f32 - key_r as f32) / 255.0;
        let dg = (pixel[1] as f32 - key_g as f32) / 255.0;
        let db = (pixel[2] as f32 - key_b as f32) / 255.0;
        let dist = (dr * dr + dg * dg + db * db).sqrt();
        if dist < threshold {
            pixel[3] = 0; // fully transparent
        } else if dist < threshold * 1.5 {
            // Soft edge
            let alpha = ((dist - threshold) / (threshold * 0.5)).clamp(0.0, 1.0);
            pixel[3] = (alpha * 255.0) as u8;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_capabilities_without_gpu_feature() {
        // Without GPU feature, should return not available
        let caps = detect_capabilities();
        if !cfg!(feature = "gpu") {
            assert!(!caps.available);
        }
    }

    #[test]
    fn test_cpu_brightness() {
        let mut rgba = vec![128u8, 128, 128, 255, 64, 64, 64, 255];
        cpu_brightness_contrast(&mut rgba, 2, 1, 0.1, 0.0);
        // Should be brighter
        assert!(rgba[0] > 128);
    }

    #[test]
    fn test_cpu_chroma_key() {
        // Green pixel should become transparent
        let mut rgba = vec![0, 255, 0, 255];
        cpu_chroma_key(&mut rgba, 1, 1, 0, 255, 0, 0.5);
        assert_eq!(rgba[3], 0); // alpha = 0
    }
}
