// ============================================================================
// GPU Video Filters — NS4.2: Shader-based Filter Pipeline
// ============================================================================
//
// WGSL compute shaders for real-time video filter processing.
// Each filter runs as a GPU compute pass on RGBA textures.
//
// Filters:
//   - Color Correction (Brightness, Contrast, Saturation, Hue)
//   - LUT-based Color Grading (3D LUT as texture)
//   - Blur (Gaussian, Box, Motion)
//   - Chroma Key (Green Screen Removal)
//   - Compositing (Alpha Blending, Blend Modes)
//
// v0.0.20.985 — NS4 (Claude Opus 4.6, 2026-04-04)
// ============================================================================

use wgpu;
use log::{info, debug};

use super::setup::GpuContext;

/// Filter parameters for color correction.
#[derive(Debug, Clone, Copy)]
pub struct ColorParams {
    pub brightness: f32,  // -1.0 to 1.0
    pub contrast: f32,    // 0.0 to 2.0 (1.0 = normal)
    pub saturation: f32,  // 0.0 to 2.0 (1.0 = normal)
    pub hue_shift: f32,   // -180.0 to 180.0 degrees
    pub temperature: f32, // -1.0 to 1.0 (cool to warm)
    pub tint: f32,        // -1.0 to 1.0 (green to magenta)
}

impl Default for ColorParams {
    fn default() -> Self {
        Self {
            brightness: 0.0,
            contrast: 1.0,
            saturation: 1.0,
            hue_shift: 0.0,
            temperature: 0.0,
            tint: 0.0,
        }
    }
}

/// Blur filter parameters.
#[derive(Debug, Clone, Copy)]
pub struct BlurParams {
    pub radius: f32,       // blur radius in pixels
    pub blur_type: BlurType,
}

#[derive(Debug, Clone, Copy)]
pub enum BlurType {
    Gaussian,
    Box,
    Motion { angle: f32 }, // angle in degrees
}

/// Chroma key parameters.
#[derive(Debug, Clone, Copy)]
pub struct ChromaKeyParams {
    pub key_color: [f32; 3],  // RGB 0.0-1.0
    pub threshold: f32,       // color distance threshold
    pub softness: f32,        // edge softness
}

/// GPU filter pipeline — manages compute shaders for video processing.
pub struct FilterPipeline {
    color_pipeline: wgpu::ComputePipeline,
    blur_pipeline: wgpu::ComputePipeline,
    chroma_pipeline: wgpu::ComputePipeline,
    composite_pipeline: wgpu::ComputePipeline,
}

/// WGSL shader source for color correction compute shader.
const COLOR_SHADER: &str = r#"
struct ColorUniforms {
    brightness: f32,
    contrast: f32,
    saturation: f32,
    hue_shift: f32,
    temperature: f32,
    tint: f32,
    width: u32,
    height: u32,
}

@group(0) @binding(0) var<uniform> params: ColorUniforms;
@group(0) @binding(1) var input_tex: texture_2d<f32>;
@group(0) @binding(2) var output_tex: texture_storage_2d<rgba8unorm, write>;

fn rgb_to_hsl(rgb: vec3<f32>) -> vec3<f32> {
    let max_c = max(rgb.r, max(rgb.g, rgb.b));
    let min_c = min(rgb.r, min(rgb.g, rgb.b));
    let l = (max_c + min_c) / 2.0;
    if max_c == min_c { return vec3(0.0, 0.0, l); }
    let d = max_c - min_c;
    let s = select(d / (2.0 - max_c - min_c), d / (max_c + min_c), l > 0.5);
    var h: f32;
    if max_c == rgb.r { h = (rgb.g - rgb.b) / d + select(0.0, 6.0, rgb.g < rgb.b); }
    else if max_c == rgb.g { h = (rgb.b - rgb.r) / d + 2.0; }
    else { h = (rgb.r - rgb.g) / d + 4.0; }
    h /= 6.0;
    return vec3(h, s, l);
}

fn hue_to_rgb(p: f32, q: f32, t_in: f32) -> f32 {
    var t = t_in;
    if t < 0.0 { t += 1.0; }
    if t > 1.0 { t -= 1.0; }
    if t < 1.0/6.0 { return p + (q - p) * 6.0 * t; }
    if t < 1.0/2.0 { return q; }
    if t < 2.0/3.0 { return p + (q - p) * (2.0/3.0 - t) * 6.0; }
    return p;
}

fn hsl_to_rgb(hsl: vec3<f32>) -> vec3<f32> {
    if hsl.y == 0.0 { return vec3(hsl.z); }
    let q = select(hsl.z + hsl.y - hsl.z * hsl.y, hsl.z * (1.0 + hsl.y), hsl.z < 0.5);
    let p = 2.0 * hsl.z - q;
    return vec3(
        hue_to_rgb(p, q, hsl.x + 1.0/3.0),
        hue_to_rgb(p, q, hsl.x),
        hue_to_rgb(p, q, hsl.x - 1.0/3.0),
    );
}

@compute @workgroup_size(16, 16)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    if gid.x >= params.width || gid.y >= params.height { return; }

    let coords = vec2<i32>(i32(gid.x), i32(gid.y));
    var color = textureLoad(input_tex, coords, 0);

    // Brightness
    color = vec4(color.rgb + vec3(params.brightness), color.a);

    // Contrast
    color = vec4((color.rgb - 0.5) * params.contrast + 0.5, color.a);

    // Saturation
    let gray = dot(color.rgb, vec3(0.299, 0.587, 0.114));
    color = vec4(mix(vec3(gray), color.rgb, params.saturation), color.a);

    // Hue shift
    if abs(params.hue_shift) > 0.001 {
        var hsl = rgb_to_hsl(color.rgb);
        hsl.x = fract(hsl.x + params.hue_shift / 360.0);
        color = vec4(hsl_to_rgb(hsl), color.a);
    }

    // Temperature (warm/cool)
    color.r += params.temperature * 0.1;
    color.b -= params.temperature * 0.1;

    // Tint (green/magenta)
    color.g += params.tint * 0.1;

    // Clamp
    color = clamp(color, vec4(0.0), vec4(1.0));

    textureStore(output_tex, coords, color);
}
"#;

/// WGSL shader for Gaussian blur (horizontal pass).
const BLUR_SHADER: &str = r#"
struct BlurUniforms {
    radius: f32,
    direction_x: f32,
    direction_y: f32,
    _pad: f32,
    width: u32,
    height: u32,
}

@group(0) @binding(0) var<uniform> params: BlurUniforms;
@group(0) @binding(1) var input_tex: texture_2d<f32>;
@group(0) @binding(2) var output_tex: texture_storage_2d<rgba8unorm, write>;

@compute @workgroup_size(16, 16)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    if gid.x >= params.width || gid.y >= params.height { return; }

    let coords = vec2<f32>(f32(gid.x), f32(gid.y));
    let direction = vec2(params.direction_x, params.direction_y);

    var color = vec4(0.0);
    var total_weight = 0.0;
    let r = i32(params.radius);

    for (var i = -r; i <= r; i++) {
        let offset = direction * f32(i);
        let sample_pos = vec2<i32>(
            clamp(i32(coords.x + offset.x), 0, i32(params.width) - 1),
            clamp(i32(coords.y + offset.y), 0, i32(params.height) - 1),
        );
        // Gaussian weight
        let sigma = params.radius / 3.0;
        let weight = exp(-f32(i * i) / (2.0 * sigma * sigma));
        color += textureLoad(input_tex, sample_pos, 0) * weight;
        total_weight += weight;
    }

    color /= total_weight;
    textureStore(output_tex, vec2<i32>(i32(gid.x), i32(gid.y)), color);
}
"#;

/// WGSL shader for chroma key (green screen removal).
const CHROMA_KEY_SHADER: &str = r#"
struct ChromaUniforms {
    key_r: f32,
    key_g: f32,
    key_b: f32,
    threshold: f32,
    softness: f32,
    _pad1: f32,
    width: u32,
    height: u32,
}

@group(0) @binding(0) var<uniform> params: ChromaUniforms;
@group(0) @binding(1) var input_tex: texture_2d<f32>;
@group(0) @binding(2) var output_tex: texture_storage_2d<rgba8unorm, write>;

@compute @workgroup_size(16, 16)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    if gid.x >= params.width || gid.y >= params.height { return; }

    let coords = vec2<i32>(i32(gid.x), i32(gid.y));
    var color = textureLoad(input_tex, coords, 0);

    let key = vec3(params.key_r, params.key_g, params.key_b);
    let diff = color.rgb - key;
    let dist = length(diff);

    if dist < params.threshold {
        color.a = 0.0;
    } else if dist < params.threshold + params.softness {
        let t = (dist - params.threshold) / params.softness;
        color.a *= t;
    }

    textureStore(output_tex, coords, color);
}
"#;

/// WGSL shader for alpha compositing (A over B).
const COMPOSITE_SHADER: &str = r#"
struct CompUniforms {
    opacity: f32,
    blend_mode: u32,  // 0=normal, 1=multiply, 2=screen, 3=overlay
    width: u32,
    height: u32,
}

@group(0) @binding(0) var<uniform> params: CompUniforms;
@group(0) @binding(1) var fg_tex: texture_2d<f32>;
@group(0) @binding(2) var bg_tex: texture_2d<f32>;
@group(0) @binding(3) var output_tex: texture_storage_2d<rgba8unorm, write>;

fn blend_multiply(a: vec3<f32>, b: vec3<f32>) -> vec3<f32> { return a * b; }
fn blend_screen(a: vec3<f32>, b: vec3<f32>) -> vec3<f32> { return 1.0 - (1.0 - a) * (1.0 - b); }
fn blend_overlay(a: vec3<f32>, b: vec3<f32>) -> vec3<f32> {
    return select(
        1.0 - 2.0 * (1.0 - a) * (1.0 - b),
        2.0 * a * b,
        b < vec3(0.5)
    );
}

@compute @workgroup_size(16, 16)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    if gid.x >= params.width || gid.y >= params.height { return; }

    let coords = vec2<i32>(i32(gid.x), i32(gid.y));
    let fg = textureLoad(fg_tex, coords, 0);
    let bg = textureLoad(bg_tex, coords, 0);

    var blended: vec3<f32>;
    switch params.blend_mode {
        case 1u: { blended = blend_multiply(fg.rgb, bg.rgb); }
        case 2u: { blended = blend_screen(fg.rgb, bg.rgb); }
        case 3u: { blended = blend_overlay(fg.rgb, bg.rgb); }
        default: { blended = fg.rgb; }
    }

    let alpha = fg.a * params.opacity;
    let result = mix(bg.rgb, blended, alpha);
    textureStore(output_tex, coords, vec4(result, max(bg.a, alpha)));
}
"#;

impl FilterPipeline {
    /// Create the filter pipeline with all compute shaders.
    pub fn new(ctx: &GpuContext) -> Self {
        let color_module = ctx.device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("color_filter"),
            source: wgpu::ShaderSource::Wgsl(COLOR_SHADER.into()),
        });

        let blur_module = ctx.device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("blur_filter"),
            source: wgpu::ShaderSource::Wgsl(BLUR_SHADER.into()),
        });

        let chroma_module = ctx.device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("chroma_key"),
            source: wgpu::ShaderSource::Wgsl(CHROMA_KEY_SHADER.into()),
        });

        let composite_module = ctx.device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("composite"),
            source: wgpu::ShaderSource::Wgsl(COMPOSITE_SHADER.into()),
        });

        let make_pipeline = |module: &wgpu::ShaderModule, label: &str| {
            let layout = ctx.device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: Some(label),
                bind_group_layouts: &[],
                push_constant_ranges: &[],
            });
            ctx.device.create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
                label: Some(label),
                layout: Some(&layout),
                module,
                entry_point: Some("main"),
                compilation_options: Default::default(),
                cache: None,
            })
        };

        info!("[GPU Filters] Compute pipelines created (color, blur, chroma, composite)");

        Self {
            color_pipeline: make_pipeline(&color_module, "color_pipeline"),
            blur_pipeline: make_pipeline(&blur_module, "blur_pipeline"),
            chroma_pipeline: make_pipeline(&chroma_module, "chroma_pipeline"),
            composite_pipeline: make_pipeline(&composite_module, "composite_pipeline"),
        }
    }
}
