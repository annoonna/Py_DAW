// ============================================================================
// GPU Video Preview — NS4.3: Realtime Preview Rendering
// ============================================================================
//
// Frame-Decode → GPU Upload → Filter → Display pipeline.
// Double-buffered for decode/display parallelism.
//
// v0.0.20.985 — NS4 (Claude Opus 4.6, 2026-04-04)
// ============================================================================

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use log::{info, debug};
use wgpu;

use super::setup::GpuContext;
use super::filters::FilterPipeline;

/// Preview rendering configuration.
#[derive(Debug, Clone)]
pub struct PreviewConfig {
    /// Preview width (can be smaller than source for performance)
    pub width: u32,
    /// Preview height
    pub height: u32,
    /// Target frame rate
    pub target_fps: f32,
    /// Show timecode overlay
    pub show_timecode: bool,
    /// Show safe areas (title/action safe)
    pub show_safe_areas: bool,
    /// Show grid overlay
    pub show_grid: bool,
}

impl Default for PreviewConfig {
    fn default() -> Self {
        Self {
            width: 1920,
            height: 1080,
            target_fps: 30.0,
            show_timecode: true,
            show_safe_areas: false,
            show_grid: false,
        }
    }
}

/// Double-buffered preview renderer.
///
/// One buffer is being decoded into while the other is being displayed.
pub struct PreviewRenderer {
    config: PreviewConfig,
    /// Double buffer: [0] = front (display), [1] = back (decode target)
    textures: [wgpu::Texture; 2],
    /// Which texture is currently the front buffer (0 or 1)
    front_index: AtomicU64,
    /// Currently rendering
    is_rendering: AtomicBool,
    /// Frame counter
    frame_count: AtomicU64,
}

impl PreviewRenderer {
    /// Create a new preview renderer.
    pub fn new(ctx: &GpuContext, config: PreviewConfig) -> Self {
        let tex0 = ctx.create_frame_texture(config.width, config.height);
        let tex1 = ctx.create_frame_texture(config.width, config.height);

        info!(
            "[GPU Preview] Created {}x{} @ {}fps, double-buffered",
            config.width, config.height, config.target_fps
        );

        Self {
            config,
            textures: [tex0, tex1],
            front_index: AtomicU64::new(0),
            is_rendering: AtomicBool::new(false),
            frame_count: AtomicU64::new(0),
        }
    }

    /// Upload a decoded frame to the back buffer.
    pub fn upload_frame(&self, ctx: &GpuContext, rgba_data: &[u8]) {
        let back_idx = 1 - self.front_index.load(Ordering::Relaxed) as usize;
        ctx.upload_frame(
            &self.textures[back_idx],
            rgba_data,
            self.config.width,
            self.config.height,
        );
    }

    /// Swap front and back buffers (call after frame is ready).
    pub fn swap_buffers(&self) {
        let current = self.front_index.load(Ordering::Relaxed);
        self.front_index.store(1 - current, Ordering::Release);
        self.frame_count.fetch_add(1, Ordering::Relaxed);
    }

    /// Get the current front buffer texture for display.
    pub fn front_texture(&self) -> &wgpu::Texture {
        let idx = self.front_index.load(Ordering::Acquire) as usize;
        &self.textures[idx]
    }

    /// Get frame count (for FPS calculation).
    pub fn frame_count(&self) -> u64 {
        self.frame_count.load(Ordering::Relaxed)
    }

    /// Get preview config.
    pub fn config(&self) -> &PreviewConfig {
        &self.config
    }

    /// Resize the preview.
    pub fn resize(&mut self, ctx: &GpuContext, width: u32, height: u32) {
        self.config.width = width;
        self.config.height = height;
        self.textures = [
            ctx.create_frame_texture(width, height),
            ctx.create_frame_texture(width, height),
        ];
        info!("[GPU Preview] Resized to {}x{}", width, height);
    }
}
